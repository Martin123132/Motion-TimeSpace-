from common import *
import numpy as np


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    accepted={}
    records=[]
    temporal=[]
    source_checks=[]
    phase_checks=[]
    for label in ('half','balanced','double'):
        for relative in ('source-even-01','collision-split-01','source-heldout-02','evolution-02','predictions-01','comparison-01'):
            path=STAGE/label/relative/'result.json'
            report=read(path)
            require(report['passed'],'completed accepted numerical work or completed physical comparison')
            accepted[str(path)]=digest(path)
            for field in ('inputs','sources','consumed'):
                for candidate,seal in report[field].items():
                    require(digest(candidate)==seal,'source unchanged: '+candidate)
                    consumed[candidate]=seal
        source_report=read(STAGE/label/'source-heldout-02/result.json')
        for model in source_report['reports']:
            for check in model['checks']:
                require(max(check[key] for key in ('fine_mean_absolute','coarse_mean_absolute','fine_remote_absolute','coarse_remote_absolute'))<GATE,'unchanged independent coefficient gate')
                source_checks.append(check)
        for model in read(STAGE/label/'source-even-01/result.json')['reports']:
            require(model['phase_difference']<ALGEBRA,'phase integration control')
            phase_checks.append(model['phase_difference'])
        evolve=read(STAGE/label/'evolution-02/result.json')
        for model in evolve['reports']:
            for name in ('source_refinement','step_refinement'):
                require(all(item['relative']<GATE for item in model[name]),'transport refinement gate')
                temporal.extend(dict(label=label,model=model['model'],control=name,**item) for item in model[name])
        prediction_end=read(STAGE/f'predictions-{label}-01.end.json')
        comparison_start=read(STAGE/f'comparison-{label}-01.start.json')
        require(datetime.fromisoformat(prediction_end['finished'])<=datetime.fromisoformat(comparison_start['created']),'physical predictions sealed before reference comparison')
        result=read(STAGE/label/'comparison-01/result.json')
        for model in result['reports']:
            target=STAGE/label/'comparison-01'/f"{model['model']}-comparison.npz"
            packet=load(target)
            consumed[str(target)]=digest(target)
            for branch_index,branch in enumerate(model['branches']):
                worst=max(branch['observables'],key=lambda item:item['relative'])
                require(branch['all_observables_within_gate']==all(row['relative']<GATE for row in branch['observables']),'honest physical verdict')
                details=[]
                for index,row in enumerate(branch['observables']):
                    errors=packet['predicted'][:,branch_index,index]-packet['reference'][:,branch_index,index]
                    maximum=int(np.argmax(abs(errors)))
                    details.append(dict(name=row['name'],maximum_probe=maximum,maximum_efold=float(packet['efold'][maximum]),
                        initial_relative=abs(float(errors[0]))/row['reference_scale'],last_relative=abs(float(errors[-1]))/row['reference_scale']))
                records.append(dict(label=label,model=model['model'],branch=branch['branch'],
                    physical_pass=branch['all_observables_within_gate'],worst_observable=worst['name'],
                    worst_relative=worst['relative'],normalized_state_relative=branch['normalized_state_relative'],
                    phase_difference=model['maximum_phase_difference'],density_difference=model['maximum_heavy_density_difference'],probe_diagnostics=details))
        require(result['all_physical_comparisons_pass']==all(item['physical_comparison_pass'] for item in result['reports']),'summary comparison verdict')
    identity_path=STAGE/'collision-identity/result.json'
    identity=read(identity_path)
    require(identity['passed'] and len(identity['reports'])==48,'independent complete collision identity checks')
    accepted[str(identity_path)]=digest(identity_path)
    for field in ('inputs','sources','consumed'):
        for path,seal in identity[field].items():
            require(digest(path)==seal,'identity source preserved')
            consumed[path]=seal
    density_path=STAGE/'density-reconstruction-proof/result.json'
    density=read(density_path)
    require(density['passed'] and len(density['identities'])==5,'derived density reconstruction')
    accepted[str(density_path)]=digest(density_path)
    for field in ('inputs','sources','consumed'):
        for path,seal in density[field].items():
            require(digest(path)==seal,'density reconstruction source retained')
            consumed[path]=seal
    background_path=COLD_BACKGROUND/'extension/freeze.json'
    maximum_drift=read(background_path)['configurations']['heavy']['tube']['final_drift_bound']
    consumed[str(background_path)]=digest(background_path)
    require(maximum_drift>=0 and density['corrector_upper']+maximum_drift<density['log_density_box'],'inherited invariant drift fits positive reconstruction box')
    density_remainder=maximum_drift/(1-density['contraction_upper'])
    diagnosis_path=STAGE/'half/heldout-diagnosis-01/result.json'
    diagnosis=read(diagnosis_path)
    require(diagnosis['passed'],'diagnosed preserved source interpolation failure')
    accepted[str(diagnosis_path)]=digest(diagnosis_path)
    failed=read(STAGE/'heldout-half-01.end.json')
    require(failed['exit_code']==1,'original failed source gate retained')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode cache')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        failed_attempts_preserved=['heldout-half-01'],compiler_receipts=[],records=records,
        maximum_source_interpolation_absolute=max(item[key] for item in source_checks for key in ('fine_mean_absolute','coarse_mean_absolute','fine_remote_absolute','coarse_remote_absolute')),
        maximum_time_refinement_relative=max(item['relative'] for item in temporal if item['control']=='step_refinement'),
        maximum_source_refinement_relative=max(item['relative'] for item in temporal if item['control']=='source_refinement'),
        maximum_phase_step_difference=max(phase_checks),
        maximum_collision_identity_absolute=max(item['absolute'] for item in identity['reports']),
        density_reconstruction=dict(contraction=density['contraction_upper'],phase_lipschitz=density['phase_lipschitz_upper'],inherited_full_background_invariant_drift=maximum_drift,log_density_invariant_only_error_bound=density_remainder,slow_state_errors_separate=True),
        numerical_validation_passed=True,physical_approximation_all_pass=all(item['physical_pass'] for item in records),
        no_new_fits=True,no_new_physical_initial_mode=True,no_late_history=True,physical_gates_unchanged=True))
    print('paired early transport completed; numerical validation passed; physical approximation results:',
        [(row['label'],row['model'],row['branch'],row['worst_relative'],row['physical_pass']) for row in records],flush=True)


if __name__=='__main__':
    main()
