from common import *
from early_source import BRANCHES
from free_math_v2 import build,dense
from full_metric_math import rows
from mean_math import relative_error
from copy import deepcopy
import numpy as np


def collision_mean(frozen,model):
    layout,source,values=frozen['layout'],frozen['source'],frozen['values']
    hubble=((source['density']+(values[0]**2+values[1]**2)/2+values[2])/3)**.5
    physical={name:source[name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
    free=build(layout,physical,frozen['thermal']['sound']['value'],hubble,frozen['masses'],WAVE,*values,1.,0.)
    unit=dense(free['groups']['collision'],layout['size'])
    require(not np.any(unit[:,layout['heavy']]),'collision has no heavy input columns')
    if model=='cold':
        return np.array([unit,unit]),frozen['thermal']['opacity']['value']/hubble
    angles=np.arange(256)*np.pi/256
    mu=source['scale']*frozen['masses'][1]/hubble
    weights=1/(mu-1.5*np.sin(2*angles))
    corrections=np.zeros((2,2,layout['size']))
    for index,theta in enumerate(angles):
        if index%32==0:
            guard()
        metric=rows(layout,source['fluid'],source['massive'],source['speeds'],source['density'],
            source['enthalpy'],source['defect'],source['defect_first'],frozen['thermal']['sound']['value'],
            source['scale'],frozen['masses'],WAVE,*values[:3],np.cos(2*theta),np.sin(2*theta))
        for number,branch in enumerate(BRANCHES):
            corrections[number]+=weights[index]*np.asarray(metric['maps'][branch]['inverse_correction'])
    corrections/=weights.sum()
    result=np.array([unit,unit])
    for number in range(2):
        result[number,layout['heavy']]+=corrections[number]@unit
    return result,frozen['thermal']['opacity']['value']/hubble


def main():
    modest()
    output=ROOT/'collision-split-01'
    output.mkdir(exist_ok=False)
    parent=ROOT/'source-even-01'
    require(read(parent/'result.json')['passed'],'frozen original mean sources')
    inputs=verify_inputs()
    consumed={str(parent/'result.json'):digest(parent/'result.json')}
    reports=[]
    for model in ('heavy','cold'):
        path=parent/f'{model}-bank.npz'
        bank=load(path)
        consumed[str(path)]=digest(path)
        units,rates=[],[]
        for index in range(0,33,2):
            source_path=parent/f'{model}-{index:02d}-source.json'
            frozen=read(source_path)
            consumed[str(source_path)]=digest(source_path)
            unit,rate=collision_mean(frozen,model)
            units.append(unit);rates.append(rate)
        units,rates=np.array(units),np.array(rates)
        remainder=bank['mean']-rates[:,None,None,None]*units
        target=output/f'{model}-bank.npz'
        np.savez_compressed(target,**bank,noncollision=remainder,collision_unit=units,collision_rate=rates)
        reconstruction=float(np.max(abs(remainder+rates[:,None,None,None]*units-bank['mean'])))
        require(reconstruction<ALGEBRA,'algebraic collision split')
        reports.append(dict(model=model,reconstruction_absolute=reconstruction,path=str(target),sha256=digest(target)))
        print(LABEL,model,'retained collision split',reconstruction,flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'source bank unmodified')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        identity='Abar=Abar_noncollision+(opacity/H)*mean(R C_unit S); C_unit S=C_unit, so mean(R C_unit) is sufficient',
        no_source_smoothing=True,physical_gates_unchanged=True))


if __name__=='__main__':
    main()

