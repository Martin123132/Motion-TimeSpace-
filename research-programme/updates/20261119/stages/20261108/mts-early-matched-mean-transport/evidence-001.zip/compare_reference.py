from common import *
from early_source import BRANCHES
import numpy as np


def main():
    modest()
    output=ROOT/'comparison-01'
    output.mkdir(exist_ok=False)
    prediction_path=ROOT/'predictions-01/result.json'
    prediction=read(prediction_path)
    require(prediction['passed'] and prediction['reference_perturbations_not_inspected'],'frozen physical predictions first')
    inputs=verify_inputs()
    consumed={str(prediction_path):digest(prediction_path)}
    frozen=read(ROOT/'source-even-01/freeze.json')
    reports=[]
    for report in prediction['reports']:
        require(digest(report['path'])==report['sha256'],'prediction unchanged')
        consumed[report['path']]=report['sha256']
        candidate=load(report['path'])
        model=report['model']
        all_references=[]
        branches=[]
        for branch_index,branch in enumerate(BRANCHES):
            original=next(row for row in frozen['metadata'][model]['reference'] if row['branch']==branch)
            require(digest(original['packet'])==original['sha256'],'original physical reference')
            consumed[original['packet']]=original['sha256']
            with np.load(original['packet']) as packet:
                names=packet['value_names']
                require(np.array_equal(names,candidate['value_names']),'same original observables')
                require(np.array_equal(packet['efold'][candidate['indices']],candidate['efold']),'original saved probe epochs exactly')
                reference=packet['values'][candidate['indices']]
                reference_state=packet['evolved_state'][candidate['indices']]
                units=packet['units']
            predicted=candidate['values'][:,0,branch_index]
            initial_contribution=candidate['values'][:,1,branch_index]
            difference=predicted-reference
            observables=[]
            for number,name in enumerate(names):
                scale=max(float(np.max(abs(reference[:,number]))),1e-80)
                absolute=float(np.max(abs(difference[:,number])))
                ratio=absolute/scale
                initial=float(np.max(abs(initial_contribution[:,number])))/scale
                remaining=float(np.max(abs(difference[:,number]-initial_contribution[:,number])))/scale
                observables.append(dict(name=str(name),maximum_absolute=absolute,reference_scale=scale,
                    relative=ratio,within_original_gate=bool(ratio<GATE),initial_mismatch_contribution=initial,
                    diagnostic_difference_minus_initial_contribution=remaining))
            normalized_error=(candidate['encoded'][:,0,branch_index]-reference_state)/units
            normalized_reference=reference_state/units
            state_ratio=float(np.max(np.linalg.norm(normalized_error,axis=1))/max(np.max(np.linalg.norm(normalized_reference,axis=1)),1e-80))
            branches.append(dict(branch=branch,observables=observables,normalized_state_relative=state_ratio,
                all_observables_within_gate=all(row['within_original_gate'] for row in observables)))
            all_references.append(reference)
        background=candidate['original_background']
        phase_difference=np.arctan2(np.sin(candidate['phase']-background[:,0]),np.cos(candidate['phase']-background[:,0])) if model=='heavy' else np.zeros(5)
        rho_difference=candidate['state'][:,3]-background[:,1]
        np.savez_compressed(output/f'{model}-comparison.npz',efold=candidate['efold'],
            reference=np.array(all_references).transpose(1,0,2),predicted=candidate['values'][:,0],
            initial_contribution=candidate['values'][:,1],phase_difference=phase_difference,rho_difference=rho_difference)
        reports.append(dict(model=model,branches=branches,maximum_phase_difference=float(np.max(abs(phase_difference))),
            maximum_heavy_density_difference=float(np.max(abs(rho_difference))),
            physical_comparison_pass=all(row['all_observables_within_gate'] for row in branches)))
        print(LABEL,model,'physical comparison',reports[-1]['physical_comparison_pass'],
            'maximum relative',[max(row['relative'] for row in branch['observables']) for branch in branches],flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'all frozen and reference sources unchanged')
    write(output/'result.json',dict(passed=True,comparison_executed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,all_physical_comparisons_pass=all(row['physical_comparison_pass'] for row in reports),
        scope='fixed short-interval retained-model approximation test, not a new observational fit or a cold-era transport claim',
        diagnostic_note='subtracting the initial-mismatch contribution is diagnostic only, never a refit or accepted modified prediction'))


if __name__=='__main__':
    main()

