from common import *
from early_source import *
from free_math_v2 import build,dense
from scipy.interpolate import CubicSpline
import numpy as np


def main():
    modest()
    output=ROOT/'heldout-diagnosis-01'
    output.mkdir(exist_ok=False)
    source=EarlySource('heavy')
    parent=ROOT/'source-even-01'
    bank=load(parent/'heavy-bank.npz')
    prediction=load(ROOT/'source-heldout-01/heavy-predictions.npz')
    phases=load(parent/'heavy-phase.npz')['phase']
    efold=float(prediction['efold'][0])
    frozen=source.frozen(efold)
    actual=source_mean(frozen,'heavy',float(phases[1]))
    np.savez_compressed(output/'first-heldout-actual.npz',mean=actual['mean'],remote=actual['remote'],endpoint=actual['endpoint'])
    checks={}
    for name in ('mean','remote'):
        for grid in ('fine','coarse'):
            discrepancy=prediction[grid+'_'+name][0]-actual[name]
            worst=np.unravel_index(np.argmax(abs(discrepancy)),discrepancy.shape)
            checks[grid+'_'+name]=dict(absolute=float(np.max(abs(discrepancy))),index=[int(value) for value in worst],
                actual=float(actual[name][worst]),predicted=float(prediction[grid+'_'+name][0][worst]),relative=relative_error(prediction[grid+'_'+name][0],actual[name]))
    collision=[]
    def groups(record):
        values=record['values']
        minimal={name:record['source'][name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
        return build(record['layout'],minimal,record['thermal']['sound']['value'],record['thermal']['opacity']['value'],
            record['masses'],WAVE,*values,1.,0.)['groups']
    for index in range(0,33,2):
        record=read(parent/f'heavy-{index:02d}-source.json')
        collision.append(dense(groups(record)['collision'],record['layout']['size']))
    collision=np.array(collision)
    target=dense(groups(frozen)['collision'],frozen['layout']['size'])
    collision_checks={}
    for grid,selection in (('fine',slice(None)),('coarse',slice(None,None,2))):
        interpolation=CubicSpline(bank['efold'][selection],collision[selection])(efold)
        error=interpolation-target
        non_collision=prediction[grid+'_mean'][0]-actual['mean']-error[None,:,:]
        collision_checks[grid]=dict(collision_absolute=float(np.max(abs(error))),remaining_absolute=float(np.max(abs(non_collision))))
    write(output/'result.json',dict(passed=True,sources=sources(),checks=checks,collision_checks=collision_checks,
        frozen=frozen,prediction_sha256=digest(ROOT/'source-heldout-01/heavy-predictions.npz'),
        note='diagnosis of preserved first heldout gate failure; no tolerance changes or accepted retry'))
    print(checks,collision_checks,flush=True)


if __name__=='__main__':
    main()

