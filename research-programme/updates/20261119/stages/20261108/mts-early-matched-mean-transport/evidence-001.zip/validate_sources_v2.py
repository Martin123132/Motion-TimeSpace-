from common import *
from early_source import *
from scipy.interpolate import CubicSpline
import numpy as np


def main():
    modest()
    output=ROOT/'source-heldout-02'
    output.mkdir(exist_ok=False)
    parent=ROOT/'source-even-01'
    split_path=ROOT/'collision-split-01/result.json'
    require(read(split_path)['passed'],'derived collision split')
    result=read(parent/'result.json')
    require(result['passed'],'complete even-node source bank')
    inputs=verify_inputs()
    consumed={str(parent/'result.json'):digest(parent/'result.json'),str(parent/'freeze.json'):digest(parent/'freeze.json')}
    consumed[str(split_path)]=digest(split_path)
    frozen=read(parent/'freeze.json')
    predicted={}
    for model in ('heavy','cold'):
        bank_path=ROOT/'collision-split-01'/f'{model}-bank.npz'
        phase_path=parent/f'{model}-phase.npz'
        consumed.update({str(path):digest(path) for path in (bank_path,phase_path)})
        bank=load(bank_path)
        efolds=np.array(frozen['metadata'][model]['efold'])[1::2]
        values={}
        source=EarlySource(model)
        rates=np.array([source.thermal(float(efold))[0]['opacity']['value']/source.hubble_mu(float(efold))[0] for efold in efolds])
        for grid,selection in (('fine',slice(None)),('coarse',slice(None,None,2))):
            values[grid+'_mean']=CubicSpline(bank['efold'][selection],bank['noncollision'][selection])(efolds)
            values[grid+'_mean']+=rates[:,None,None,None]*CubicSpline(bank['efold'][selection],bank['collision_unit'][selection])(efolds)
            values[grid+'_remote']=CubicSpline(bank['efold'][selection],bank['remote'][selection])(efolds)
        values['efold']=efolds
        path=output/f'{model}-predictions.npz'
        np.savez_compressed(path,**values)
        predicted[model]=dict(path=str(path),sha256=digest(path))
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,predictions=predicted,
        held_out_indices=list(range(1,32,2)),absolute_coefficient_gate=GATE,tolerances_unchanged=True,collision_rate='direct original table; only residual and unit coefficient interpolated'))
    reports=[]
    for model in ('heavy','cold'):
        source=EarlySource(model)
        predicted_packet=load(predicted[model]['path'])
        phases=load(parent/f'{model}-phase.npz')['phase']
        bank=load(ROOT/'collision-split-01'/f'{model}-bank.npz')
        checks=[]
        for number,index in enumerate(range(1,32,2)):
            guard()
            efold=float(predicted_packet['efold'][number])
            diagnosis=ROOT/'heldout-diagnosis-01/first-heldout-actual.npz'
            if LABEL=='half' and model=='heavy' and index==1 and diagnosis.exists():
                actual=load(diagnosis)
                actual['keys']=bank['keys']
                consumed[str(diagnosis)]=digest(diagnosis)
            else:
                actual=source_mean(source.frozen(efold),model,float(phases[index]))
            np.savez_compressed(output/f'{model}-{index:02d}-actual.npz',mean=actual['mean'],remote=actual['remote'])
            require(np.array_equal(actual['keys'],bank['keys']),'heldout remote sparse support')
            check=dict(index=index,efold=efold)
            for name in ('mean','remote'):
                for grid in ('fine','coarse'):
                    predicted_value=predicted_packet[grid+'_'+name][number]
                    absolute=float(np.max(abs(predicted_value-actual[name])))
                    relative=relative_error(predicted_value,actual[name])
                    check[grid+'_'+name+'_absolute']=absolute
                    check[grid+'_'+name+'_relative']=relative
                    require(absolute<GATE,'unchanged heldout source coefficient gate')
            checks.append(check)
            write(output/f'{model}-{index:02d}-check.json',check)
            print(LABEL,model,'heldout',index,'fine absolute',check['fine_mean_absolute'],flush=True)
        reports.append(dict(model=model,checks=checks))
    require(all(digest(path)==seal for path,seal in consumed.items()),'source bank unchanged')
    require(all(digest(row['path'])==row['sha256'] for row in predicted.values()),'heldout predictions remain frozen')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,predictions=predicted,
        reports=reports,no_fit_to_heldout=True,physical_gates_unchanged=True))


if __name__=='__main__':
    main()
