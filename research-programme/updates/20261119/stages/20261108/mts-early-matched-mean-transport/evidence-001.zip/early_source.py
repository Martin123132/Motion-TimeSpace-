from common import *
from cold_access import SavedBackground,namespace
from source_laws import exterior
from thermal_jets import evaluate as thermal_evaluate
from coupled_jets import evaluate
from stable_coupled import assemble
from factored_sparse import evaluate as sparse_evaluate
from enclose_free import complete_layout
from mean_math import phase_primitive,interpolate,relative_error
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
import numpy as np
import mpmath as mp

BRANCHES=('gr','poisson-spatial')
mp.mp.dps=70


class EarlySource:
    def __init__(self,model):
        self.model=model
        self.saved=SavedBackground(model)
        self.original=read(MATCHING/LABEL/'preparation-01'/f'{model}-mean-source.json')
        self.layout=self.original['layout']
        self.constants=read(FULL/LABEL/f'full-01/{model}-constants.json')
        self.table=load(FULL/LABEL/f'full-01/{model}-thermal.npz')
        initial,step=self.table['metadata']
        self.scale_grid=initial*np.exp(step*np.arange(self.table['values'].shape[1]))*self.table['values'][0]
        self.consumed={str(path):digest(path) for path in (
            MATCHING/LABEL/'preparation-01'/f'{model}-mean-source.json',
            MATCHING/LABEL/'phase-matching-01'/f'{model}-mean-endpoint.npz',
            FULL/LABEL/f'full-01/{model}-constants.json',FULL/LABEL/f'full-01/{model}-thermal.npz')}

    def values(self,efold):
        background=self.saved.mean(efold)
        dense,_=namespace['dense_values'](self.saved.dense,np.array([efold]))
        config=self.saved.configuration
        clock=config['initial_clock']+dense[0,2]/config['initial_hubble']
        return [float(background['slow'][0,0]),float(background['slow'][0,1]),float(background['heavy'][0]),float(clock)]

    def physical_state(self,efold):
        values=self.values(efold)
        return np.array([efold,values[0]/(np.exp(efold)*self.saved.masses[0]),*values[1:]])

    def thermal(self,efold):
        scale=mp.exp(mp.mpf(float(efold)))
        index=int(np.searchsorted(self.scale_grid,float(scale),side='right')-1)
        require(0<=index<len(self.scale_grid)-1,'same thermal table domain')
        initial,step=(mp.mpf(float(value)) for value in self.table['metadata'])
        left,right=(mp.mpf(float(value)) for value in self.table['values'][0,index:index+2])
        first,last=(mp.mpf(float(value)) for value in self.table['values'][1,index:index+2])
        second=3*(right-left)-2*first-last
        third=first+last+2*(left-right)
        time_left=initial*mp.exp(index*step)
        local=mp.findroot(lambda position:time_left*mp.exp(step*position)*(left+position*(first+position*(second+position*third)))-scale,(mp.mpf(0),mp.mpf(1)))
        require(0<=local<=1,'owned cubic inversion cell')
        error=abs(time_left*mp.exp(step*local)*(left+local*(first+local*(second+local*third)))/scale-1)
        require(error<mp.mpf('1e-55'),'high-precision thermal scale inversion')
        thermal=thermal_evaluate(self.table,index,local)
        return {name:{key:float(value) for key,value in record.items()} for name,record in thermal.items()},index,float(local)

    def frozen(self,efold):
        thermal,cell,local=self.thermal(efold)
        return dict(layout=self.layout,source=exterior(self.saved,self.constants,efold),
            masses=self.saved.masses.tolist(),values=self.values(efold),thermal=thermal,cell=cell,local=local,efold=float(efold))

    def hubble_mu(self,efold):
        background=self.saved.mean(efold)
        return float(background['hubble'][0]),float(np.exp(efold)*self.saved.masses[1]/background['hubble'][0])

    def phases(self,efolds,maximum):
        if self.model=='cold':
            return np.zeros(len(efolds)),0
        def rhs(efold,phase):
            guard()
            return [self.hubble_mu(efold)[1]-1.5*np.sin(2*phase[0])]
        solution=solve_ivp(rhs,(efolds[0],efolds[-1]),[self.original['theta']],t_eval=efolds,
            method='DOP853',rtol=2e-12,atol=2e-14,max_step=maximum)
        require(solution.success and np.isfinite(solution.y).all(),'mean-background phase solve')
        return solution.y[0],solution.nfev


def matrices(frozen,theta):
    arguments=(frozen['layout'],frozen['source'],frozen['masses'],WAVE,frozen['values'],frozen['thermal'],theta)
    direct=evaluate(*arguments)
    stable=assemble(*arguments,direct)
    return np.array([stable[branch] for branch in BRANCHES])


def source_mean(frozen,model,theta,primitive_path=None):
    compact=frozen['layout']['size']
    complete=complete_layout(frozen['layout'])
    full=sparse_evaluate(complete,frozen['source'],frozen['masses'],WAVE,frozen['values'],frozen['thermal'],1.,0.)
    remote={branch:{key:value for key,value in full['branches'][branch].items() if max(key)>=compact} for branch in BRANCHES}
    require(remote[BRANCHES[0]]==remote[BRANCHES[1]],'same remote hierarchy between gravity branches')
    keys=sorted(remote[BRANCHES[0]])
    remote_values=np.array([remote[BRANCHES[0]][key] for key in keys])
    base=matrices(frozen,0.)
    for number,branch in enumerate(BRANCHES):
        principal=np.zeros((compact,compact))
        for (row,column),value in full['branches'][branch].items():
            if max(row,column)<compact:
                principal[row,column]=value
        require(relative_error(principal,base[number])<ALGEBRA,'complete source principal block')
    if model=='cold':
        require(np.array_equal(base,matrices(frozen,1.157)),'baseline phase-independent source')
        return dict(mean=base,remote=remote_values,keys=np.array(keys,dtype=int),endpoint=np.zeros_like(base),
            closure=0.,phase_refinement=0.,primitive_bound=0.)
    angles=np.arange(256)*np.pi/256
    bank=[]
    for number,angle in enumerate(angles):
        if number%32==0:
            guard()
        bank.append(matrices(frozen,angle))
    bank=np.array(bank)
    hubble=((frozen['source']['density']+(frozen['values'][0]**2+frozen['values'][1]**2)/2+frozen['values'][2])/3)**.5
    mu=frozen['source']['scale']*frozen['masses'][1]/hubble
    angular=mu-1.5*np.sin(2*angles)
    require(np.min(angular)>0,'positive original phase clock')
    means,ends,coefficients=[],[],[]
    closures,refinements,bounds=[],[],[]
    for number,branch in enumerate(BRANCHES):
        variable=bank[:,number]-base[number]
        average=phase_primitive(variable,angular)
        lower=phase_primitive(variable[::2],angular[::2])
        mean=average['mean']+base[number]
        endpoint=interpolate(average['coefficients'],theta)
        closure=max(average['closure'],average['unresolved'])/max(float(np.max(abs(average['forcing']))),1e-80)
        refinement=max(relative_error(mean,lower['mean']+base[number]),relative_error(endpoint,interpolate(lower['coefficients'],theta)))
        bound=float(np.sum(np.linalg.norm(average['coefficients'],axis=(1,2))))
        require(closure<ALGEBRA and refinement<GATE and bound<1,'unchanged phase evaluation/inverse checks')
        means.append(mean);ends.append(endpoint);coefficients.append(average['coefficients'])
        closures.append(closure);refinements.append(refinement);bounds.append(bound)
    if primitive_path is not None:
        np.savez_compressed(primitive_path,coefficients=np.array(coefficients),mean=np.array(means),endpoint=np.array(ends),theta=np.array(theta))
    return dict(mean=np.array(means),remote=remote_values,keys=np.array(keys,dtype=int),endpoint=np.array(ends),
        closure=max(closures),phase_refinement=max(refinements),primitive_bound=max(bounds))


def original_metadata(model):
    result_path=POISSON/'evolution-result.json'
    result=read(result_path)
    require(result['passed'],'original accepted reference')
    records=[row for report in result['reports'] if report['model']==model for row in report['rows'] if row['branch'] in BRANCHES]
    paths={str(result_path):digest(result_path)}
    grid=None
    for row in records:
        require(digest(row['packet'])==row['sha256'],'original reference checksum')
        with np.load(row['packet']) as packet:
            candidate=packet['efold']
            if grid is None:
                grid=candidate.copy()
            else:
                require(np.array_equal(grid,candidate),'paired original output epochs')
        paths[row['packet']]=row['sha256']
    end=int(np.searchsorted(grid,grid[0]+.01,side='right')-1)
    indices=np.rint(np.linspace(0,end,33)).astype(int)
    require(len(np.unique(indices))==33,'sufficient saved original epochs')
    return dict(indices=indices.tolist(),efold=grid[indices].tolist(),reference=records),paths

