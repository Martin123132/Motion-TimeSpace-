from common import *
from early_source import BRANCHES,EarlySource
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
import numpy as np
import time


def evolution(bank,initial,initial_difference,coarse,steps,output_times,source):
    selected=slice(None,None,2) if coarse else slice(None)
    noncollision=CubicSpline(bank['efold'][selected],bank['noncollision'][selected])
    unit=CubicSpline(bank['efold'][selected],bank['collision_unit'][selected])
    remote=CubicSpline(bank['efold'][selected],bank['remote'][selected])
    rows,columns=bank['keys'].T
    dimension=initial.shape[1]
    compact=bank['mean'].shape[-1]
    scales=np.linalg.norm(initial,axis=1)
    require(np.all(scales>0),'nonzero original modes')
    seed=np.array([initial,initial_difference])/scales[None,:,None]
    def rhs(efold,flat):
        guard()
        values=flat.reshape(2,2,dimension)
        answer=np.zeros_like(values)
        collision_rate=source.thermal(float(efold))[0]['opacity']['value']/source.hubble_mu(float(efold))[0]
        matrix=noncollision(efold)+collision_rate*unit(efold)
        answer[:,:,:compact]=np.einsum('bij,cbj->cbi',matrix,values[:,:,:compact])
        weights=remote(efold)
        for component in range(2):
            for branch in range(2):
                answer[component,branch]+=np.bincount(rows,weights*values[component,branch,columns],minlength=dimension)
        return answer.ravel()
    begin,end=bank['efold'][[0,-1]]
    started=time.monotonic()
    solution=solve_ivp(rhs,(begin,end),seed.ravel(),t_eval=output_times,method='DOP853',
        rtol=2e-12,atol=2e-14,max_step=(end-begin)/steps)
    require(solution.success and np.all(np.isfinite(solution.y)),'short matched evolution')
    values=solution.y.T.reshape(len(output_times),2,2,dimension)*scales[None,None,:,None]
    return values,dict(success=bool(solution.success),nfev=solution.nfev,seconds=time.monotonic()-started,maximum_step=(end-begin)/steps)


def discrepancy(first,second):
    reports=[]
    for component in range(2):
        for branch in range(2):
            difference=np.linalg.norm(first[:,component,branch]-second[:,component,branch],axis=1)
            norm=np.linalg.norm(second[:,component,branch],axis=1)
            ratio=float(np.max(difference)/max(np.max(norm),1e-80))
            require(ratio<GATE,'unchanged propagated time/interpolation refinement gate')
            reports.append(dict(component=component,branch=BRANCHES[branch],absolute=float(np.max(difference)),relative=ratio))
    return reports


def main():
    modest()
    output=ROOT/'evolution-02'
    output.mkdir(exist_ok=False)
    parent=ROOT/'source-even-01'
    qualify=ROOT/'source-heldout-02/result.json'
    require(read(qualify)['passed'],'heldout source qualification before transport')
    inputs=verify_inputs()
    consumed={str(qualify):digest(qualify)}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,
        solver='DOP853',rtol=2e-12,atol=2e-14,main_steps=128,control_steps=64,
        branches=BRANCHES,components=['matched mean preparation','linear initial-mismatch contribution'],
        unchanged_gate=GATE,reference_performance_not_inspected=True))
    reports=[]
    for model in ('heavy','cold'):
        bank_path=ROOT/'collision-split-01'/f'{model}-bank.npz'
        initial_path=MATCHING/LABEL/'phase-matching-01'/f'{model}-mean-endpoint.npz'
        difference_path=MATCHING/LABEL/'phase-matching-01'/f'{model}-mean-background-endpoint-difference.npz'
        consumed.update({str(path):digest(path) for path in (bank_path,initial_path,difference_path)})
        bank=load(bank_path)
        source=EarlySource(model)
        initial=load(initial_path)['mean_state']
        difference=load(difference_path)['difference']
        packets={}
        runs=[]
        for name,coarse,steps in (('source-coarse',True,128),('step-coarse',False,64),('fine',False,128)):
            values,report=evolution(bank,initial,difference,coarse,steps,bank['efold'],source)
            path=output/f'{model}-{name}.npz'
            np.savez_compressed(path,efold=bank['efold'],state=values)
            packets[name]=values
            runs.append(dict(name=name,**report,sha256=digest(path)))
            print(LABEL,model,name,'evolved',report['nfev'],'calls',flush=True)
        source_refinement=discrepancy(packets['source-coarse'],packets['fine'])
        step_refinement=discrepancy(packets['step-coarse'],packets['fine'])
        reports.append(dict(model=model,runs=runs,source_refinement=source_refinement,step_refinement=step_refinement))
    require(all(digest(path)==seal for path,seal in consumed.items()),'frozen evolution inputs')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,reference_performance_not_inspected=True))


if __name__=='__main__':
    main()
