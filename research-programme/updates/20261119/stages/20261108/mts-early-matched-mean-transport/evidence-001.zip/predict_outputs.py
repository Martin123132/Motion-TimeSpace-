from common import *
from early_source import EarlySource,BRANCHES
from matching_source import frozen_source,apply_correction,from_physical
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from mean_math import relative_error
import numpy as np

NAMES=('Phi','Psi','D','Q','Pi','theta_c','delta_c','delta_b','delta_gamma','delta_massless')


def main():
    modest()
    output=ROOT/'predictions-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    evolution_path=ROOT/'evolution-01/result.json'
    require(read(evolution_path)['passed'],'numerical transport controls accepted before predictions')
    inputs=verify_inputs()
    consumed={str(evolution_path):digest(evolution_path)}
    reports=[]
    for model in ('heavy','cold'):
        bank_path=ROOT/'source-even-01'/f'{model}-bank.npz'
        evolved_path=ROOT/'evolution-01'/f'{model}-fine.npz'
        bank=load(bank_path)
        evolved=load(evolved_path)
        consumed.update({str(path):digest(path) for path in (bank_path,evolved_path)})
        source=EarlySource(model)
        system=open_owned(model,'predictions-01/contexts')
        energy=PhysicalEnergyMap(system)
        selected=np.arange(0,17,4)
        times=bank['efold'][selected]
        carriers=np.array([system.owner.phase(efold)[0] if model=='heavy' else 0. for efold in times])
        original_background=[]
        for efold in times:
            point=system.context['point'](efold)
            if model=='heavy':
                position=point[10]*source.saved.masses[1]*(system.background['initial_fields'][1]+point[2])
                velocity=point[3]
                original_background.append([np.arctan2(-velocity,position),(position**2+velocity**2)/2,point[12]])
            else:
                original_background.append([0.,0.,point[12]])
        values=np.empty((5,2,2,len(NAMES)))
        encoded=np.empty((5,2,2,len(system.units)))
        checks=[]
        states=[]
        with MatchedColdFibre(system) as fibre:
            for output_index,bank_index in enumerate(selected):
                efold=float(times[output_index])
                state=source.physical_state(efold)
                theta=float(bank['phase'][bank_index])
                fibre.chart_angle=float(carriers[output_index])
                frozen,maps,point,derived,paths=frozen_source(fibre,energy,state,theta)
                consumed.update(paths)
                frozen_independent=source.frozen(efold)
                thermal_error=max(abs(frozen['thermal'][name]['value']-frozen_independent['thermal'][name]['value'])/
                    max(abs(frozen_independent['thermal'][name]['value']),1e-80) for name in ('sound','opacity'))
                require(thermal_error<ALGEBRA,'independent cubic inversion versus native thermal readback')
                compact=frozen['layout']['size']
                heavy=frozen['layout']['heavy']
                primitive=bank['endpoint'][bank_index]
                for component in range(2):
                    for branch_index,branch in enumerate(BRANCHES):
                        mean_state=evolved['state'][bank_index,component,branch_index]
                        closed=mean_state.copy()
                        closed[:compact]=(np.eye(compact)+primitive[branch_index])@mean_state[:compact]
                        physical=apply_correction(closed,maps['forward_correction'][branch_index],heavy,compact)
                        normalized=from_physical(physical,maps,energy.size)
                        current=normalized*system.units
                        encoded[output_index,component,branch_index]=current
                        readout=system.evaluate(efold,current,branch)[1]
                        values[output_index,component,branch_index]=[readout[name] for name in NAMES]
                states.append(state)
                checks.append(dict(index=int(bank_index*2),efold=efold,theta=theta,carrier=carriers[output_index],
                    native_thermal_relative=thermal_error,native_hubble_shift=fibre.representation_shift))
        target=output/f'{model}-predicted.npz'
        np.savez_compressed(target,efold=times,indices=bank['indices'][selected],values=values,encoded=encoded,
            state=np.array(states),phase=bank['phase'][selected],original_background=np.array(original_background),
            value_names=np.array(NAMES),branches=np.array(BRANCHES))
        reports.append(dict(model=model,path=str(target),sha256=digest(target),checks=checks))
        print(LABEL,model,'five physical readouts frozen',flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'prediction sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        reference_perturbations_not_inspected=True,source_background_information_reused=True,
        components=['prediction from original mean-matched preparation','linear contribution of retained initial background mismatch']))


if __name__=='__main__':
    main()

