from common import *
from transformed_support import *
from build_clock_bank import maximum_relative
import time


def main():
    modest()
    output=ROOT/'primitive-validation-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    path=STAGE/'kernel-bank-01/result.json'
    result=read(path)
    require(result['passed'],'kernel and clock derivative controls')
    require(digest(result['path'])==result['sha256'],'qualified kernel bank')
    packet=load(result['path'])
    kernel_bank=KernelBank(packet)
    consumed={str(path):digest(path),result['path']:result['sha256']}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,algebra=ALGEBRA,gate=GATE,
        fractions=[.173,.463,.827],angles=[.213,1.157,2.62],physical_inputs_unchanged=True))
    records=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        source,bank,leading,paths=retained(model)
        consumed.update(paths)
        consumed.update(owner.consumed)
        mean_operator=MeanOperator(owner,bank)
        require(bank['efold'][0]==packet['efold'][0] and bank['efold'][-1]==packet['efold'][-1] if model=='heavy' else True,'clock interval ownership')
        clock_matches=[]
        if model=='heavy':
            for efold,bounds in zip(packet['efold'],result['node_bounds']):
                _,_,own=phase_clock(owner,float(efold),np.array([.213,1.157,2.62]))
                difference=abs(own['minimum_speed']/bounds['minimum_speed']-1)
                require(difference<ALGEBRA,'same physical clock across wavenumbers')
                clock_matches.append(difference)
        for fraction in (.173,.463,.827):
            efold=float(bank['efold'][0]+fraction*(bank['efold'][-1]-bank['efold'][0]))
            matrix,weights=mean_operator.values(efold)
            for theta in (.213,1.157,2.62):
                forcing=source(efold,theta)
                if model=='heavy':
                    direct=kernels(owner,efold)
                    angular=basis(theta,direct['modes'],direct['sine'])
                    angle=2*direct['modes']*theta
                    angular_rate=np.where(direct['sine'],2*direct['modes']*np.cos(angle),-2*direct['modes']*np.sin(angle))
                    coefficients=source.spline(efold)
                    slope=source.spline(efold,1)
                    mean=(direct['mean']@coefficients).reshape(source.shape)
                    primitive=(angular@direct['coefficients']@coefficients).reshape(source.shape)
                    primitive_rate=(angular@direct['derivative']@coefficients+angular@direct['coefficients']@slope).reshape(source.shape)
                    phase_derivative=(angular_rate@direct['coefficients']@coefficients).reshape(source.shape)
                    speed=phase_clock(owner,efold,np.array(theta))[0]
                    fine_mean,fine_primitive,fine_rate=kernel_bank.response(source,efold,theta)
                    identity_error=max(np.array(group_relative(speed*phase_derivative+mean,forcing)).ravel())
                    interpolation_error=max(np.array(group_relative(fine_primitive,primitive)).ravel())
                    derivative_interpolation=max(np.array(group_relative(fine_rate,primitive_rate)).ravel())
                    require(identity_error<ALGEBRA,'complete source periodic identity')
                    require(max(interpolation_error,derivative_interpolation)<GATE,'paired complete source interpolation controls')
                    finite_checks=[]
                    for width in (1e-5,5e-6):
                        values={step:kernel_bank.response(source,efold+step*width,theta)[1] for step in (-2,-1,1,2)}
                        derivative=(values[-2]-8*values[-1]+8*values[1]-values[2])/(12*width)
                        difference=max(np.array(group_relative(derivative,fine_rate)).ravel())
                        require(difference<GATE,'complete forcing fixed-phase derivative, including coefficient histories')
                        finite_checks.append(dict(width=width,relative=difference))
                    omitted_source_history=(angular@direct['derivative']@coefficients).reshape(source.shape)
                    negative=max(np.array(group_relative(omitted_source_history,primitive_rate)).ravel())
                else:
                    mean=forcing
                    primitive=np.zeros_like(forcing)
                    primitive_rate=np.zeros_like(forcing)
                    phase_derivative=np.zeros_like(forcing)
                    speed=0.
                    identity_error=interpolation_error=derivative_interpolation=negative=0.
                    finite_checks=[]
                delta=np.broadcast_to(leading['state'][8],primitive.shape).copy()
                eta=delta-primitive
                original_rhs=mean_operator.apply(delta,matrix,weights)+forcing
                transformed_rhs=mean_operator.apply(eta,matrix,weights)+mean+mean_operator.apply(primitive,matrix,weights)-primitive_rate
                reconstructed_rhs=transformed_rhs+primitive_rate+speed*phase_derivative
                rhs_error=max(np.array(group_relative(reconstructed_rhs,original_rhs)).ravel())
                require(rhs_error<ALGEBRA,'full unaveraged transformed response identity')
                records.append(dict(model=model,fraction=fraction,theta=theta,periodic_source_identity=identity_error,
                    primitive_interpolation=interpolation_error,derivative_interpolation=derivative_interpolation,
                    derivative_checks=finite_checks,omitting_source_history_derivative=negative,full_rhs_identity=rhs_error))
        print(LABEL,model,'primitive and complete-source derivative checks passed',flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,records=records,
        unchanged_source_and_tolerances=True,source_derivative_scope='exact retained forcing interpolant, not independently reconstructed microscopic R_N',
        residual_MJ_minus_JN_retained=True))


if __name__=='__main__':
    main()
