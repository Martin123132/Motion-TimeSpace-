from common import *
import numpy as np


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    accepted={}
    consumed={}
    jobs=[]
    physical=[]
    controls=[]
    diagnostics=[]
    validations=[]

    def accept(path):
        report=read(path)
        require(report['passed'],'accepted report '+str(path))
        accepted[str(path)]=digest(path)
        for name in ('inputs','sources','consumed'):
            for source,seal in report[name].items():
                require(digest(source)==seal,'unchanged accepted dependency '+source)
                consumed[source]=seal
        return report

    kernel=accept(STAGE/'kernel-bank-01/result.json')
    require(digest(kernel['path'])==kernel['sha256'],'kernel artifact')
    consumed[kernel['path']]=kernel['sha256']
    require(len(kernel['node_bounds'])==65 and len(kernel['interpolation'])==64,'fixed auxiliary clock coverage')
    require(max(kernel['maximum_closure'],kernel['maximum_normalization'],kernel['maximum_differentiated_normalization'])<ALGEBRA,'derived periodic clock identities')
    for row in kernel['node_bounds']:
        require(row['map_bound']<row['log_density_box'] and row['contraction_bound']<1 and row['minimum_speed']>0,'all-phase fixed-N branch proof')
    for row in kernel['interpolation']:
        require(max(*row['fine'].values(),*row['coarse'].values())<GATE,'independent kernel interpolation')
    for row in kernel['derivative_checks']:
        require(max(row['quadrature'].values())<ALGEBRA,'auxiliary Fourier convergence')
        require(all(max(item['kernel_derivative'],item['clock_derivative'])<GATE for item in row['finite_differences']),'independent fixed-phase derivative')
    for label in ('half','balanced','double'):
        validation=accept(STAGE/label/'primitive-validation-01/result.json')
        require(len(validation['records'])==18,'paired full-source validation coverage')
        for row in validation['records']:
            require(max(row['periodic_source_identity'],row['full_rhs_identity'])<ALGEBRA,'full physical-source transformation algebra')
            require(max(row['primitive_interpolation'],row['derivative_interpolation'])<GATE,'full-source primitive interpolation')
            require(all(check['relative']<GATE for check in row['derivative_checks']),'complete forcing-history derivative check')
            validations.append(dict(label=label,**row))
        for model in ('heavy','cold'):
            for control in ('fine','step-coarse','source-coarse'):
                report=accept(STAGE/label/'response-jobs'/f'{model}-{control}'/'result.json')
                require(report['model']==model and report['control']==control and digest(report['path'])==report['sha256'],'response job ownership')
                require(report['phase_error']<ALGEBRA,'same physical phase')
                consumed[report['path']]=report['sha256']
                for check in report['checks']:
                    require(max(check['physical_relative'],check['relative_to_correction'],*check['component_relative'])<GATE,'direct response regression for all components')
                    require(check['initial_relative']<ALGEBRA,'original-mode response offset')
                    jobs.append(dict(label=label,model=model,control=control,**check))
        evolution=accept(STAGE/label/'evolution-01/result.json')
        for model in evolution['reports']:
            for check in model['checks']:
                require(max(check['relative'],check['relative_to_correction'])<GATE,'paired transformed response controls')
        prediction=accept(STAGE/label/'predictions-01/result.json')
        comparison=accept(STAGE/label/'comparison-01/result.json')
        readout=accept(STAGE/label/'control-readout-01/result.json')
        require(comparison['all_physical_comparisons_pass'],'all original-reference physical channels')
        for record in prediction['reports']:
            require(digest(record['path'])==record['sha256'] and max(record['joins'].values())<ALGEBRA,'physical prediction and incoming continuity')
            consumed[record['path']]=record['sha256']
        for model in comparison['reports']:
            path=STAGE/label/'comparison-01'/f"{model['model']}-comparison.npz"
            packet=load(path)
            consumed[str(path)]=digest(path)
            for branch_index,branch in enumerate(model['branches']):
                require(branch['physical_pass'],'retained physical gate')
                for column,row in enumerate(branch['observables']):
                    expected=packet['reference'][:,branch_index,column]
                    candidate=packet['predicted'][:,branch_index,column]
                    relative=float(np.max(abs(candidate-expected))/max(np.max(abs(expected)),1e-80))
                    require(abs(relative-row['relative'])<ALGEBRA and relative<GATE and row['within_gate'],'recomputed original physical comparison')
                    physical.append(dict(label=label,model=model['model'],branch=branch['branch'],channel=row['name'],relative=relative))
        for model in readout['reports']:
            for check in model['checks']:
                require(check['relative']<GATE,'propagated native physical control')
                controls.append(dict(label=label,model=model['model'],**check))
        diagnosis=accept(STAGE/label/'residual-diagnosis-01/result.json')
        for row in diagnosis['records']:
            if not row['phase_absent']:
                for group in row['groups']:
                    require(group['mean_identity']<ALGEBRA,'derived moving-clock correction')
                    diagnostics.append(dict(label=label,index=row['index'],**group))
    require(len(jobs)==36 and len(physical)==120 and len(controls)==240 and len(diagnostics)==36,'planned paired validation coverage')
    parent_seals={str(Path(row['path'])):row['sha256'] for row in read(COMPLETED/'closeout.json')['artifacts']}
    for path,seal in consumed.items():
        if Path(path).is_relative_to(COMPLETED) and Path(path).name!='closeout.json':
            require(str(Path(path)) in parent_seals and seal==parent_seals[str(Path(path))],'original sealed parent input')
    for path in STAGE.rglob('freeze.json'):
        freeze=read(path)
        for source,seal in freeze['sources'].items():
            require(digest(source)==seal,'source preserved since frozen job preparation')
        consumed[str(path)]=digest(path)
    for start_path in STAGE.glob('*.start.json'):
        if start_path.name=='audit-01.start.json':
            continue
        start=read(start_path)
        end=read(start_path.with_name(start_path.name.replace('.start.json','.end.json')))
        require(end['pid']==start['pid'] and end['created']==start['created'] and end['exit_code']==0,'exact successful terminal job receipt')
        require(digest(start['source_path'])==start['source_sha256'],'executed job source retained')
    require(not list(STAGE.glob('*.not-started.json')),'all planned phase receipts resolved')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode artifacts')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        failed_attempts_preserved=[],compiler_receipts=[],physical_approximation_all_pass=True,
        jobs=jobs,physical=physical,controls=controls,diagnostics=diagnostics,validations=validations,
        minimum_all_phase_speed=min(row['minimum_speed'] for row in kernel['node_bounds']),
        maximum_kernel_identity=max(kernel['maximum_closure'],kernel['maximum_normalization'],kernel['maximum_differentiated_normalization']),
        no_physical_initial_state_reset=True,all_oscillatory_residual_terms_retained=True,original_banks_and_gates_unchanged=True,
        source_derivative_scope='retained full forcing interpolant; independent microscopic R_N remains separate',
        continuum_N_gain_bound_claimed=False,github_actions=False))
    print('clock primitive, moving mean and full paired response accepted',len(jobs),len(physical),len(controls),len(diagnostics),flush=True)


if __name__=='__main__':
    main()
