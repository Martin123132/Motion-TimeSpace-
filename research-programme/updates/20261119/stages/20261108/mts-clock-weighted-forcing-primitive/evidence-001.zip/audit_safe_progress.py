from common import *
import numpy as np


def main():
    modest()
    output=STAGE/'progress-audit-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    accepted={}
    reports={}

    def retain(path,seal=None):
        path=str(Path(path))
        if path not in consumed:
            consumed[path]=digest(path)
        if seal is not None:
            require(consumed[path]==seal,'fixed source provenance '+path)
        return path

    for path in STAGE.rglob('result.json'):
        if path.is_relative_to(output):
            continue
        report=read(path)
        require(report['passed'],'no failed science promoted')
        reports[str(path)]=report
        accepted[str(path)]=digest(path)
        for field in ('inputs','sources','consumed'):
            for source,seal in report.get(field,{}).items():
                retain(source,seal)
        if 'path' in report and 'sha256' in report:
            retain(report['path'],report['sha256'])
    kernel=reports[str(STAGE/'kernel-bank-01/result.json')]
    require(len(kernel['node_bounds'])==65 and len(kernel['interpolation'])==64,'retained kernel coverage')
    require(max(kernel['maximum_closure'],kernel['maximum_normalization'],kernel['maximum_differentiated_normalization'])<ALGEBRA,'derived kernel identities')
    require(all(row['minimum_speed']>0 and row['map_bound']<.02 and row['contraction_bound']<1 for row in kernel['node_bounds']),'fixed-N uniform phase clock proof')
    completed_jobs=[]
    pending_jobs=[]
    completed_families=[]
    pending_postprocessing=[]
    physical=[]
    regressions=[]
    diagnostics=[]
    for label in ('half','balanced','double'):
        validation=reports[str(STAGE/label/'primitive-validation-01/result.json')]
        require(len(validation['records'])==18,'paired source derivative validation exists for all three families')
        for row in validation['records']:
            require(max(row['periodic_source_identity'],row['full_rhs_identity'])<ALGEBRA,'full source identity')
            require(max(row['primitive_interpolation'],row['derivative_interpolation'])<GATE,'full source interpolation controls')
            require(all(item['relative']<GATE for item in row['derivative_checks']),'full forcing derivative check')
        family_jobs=0
        for model in ('heavy','cold'):
            for control in ('fine','step-coarse','source-coarse'):
                phase=f'response-{label}-{model}-{control}-01'
                path=STAGE/label/'response-jobs'/f'{model}-{control}'/'result.json'
                if not path.exists():
                    require(not (STAGE/f'{phase}.start.json').exists(),'unresolved started worker is not a safe pending job')
                    pending_jobs.append(dict(label=label,model=model,control=control,phase=phase,
                        script=f"job_{model}_{control.replace('-','_')}.py"))
                    continue
                report=reports[str(path)]
                packet=load(retain(report['path'],report['sha256']))
                reference_path=COMPLETED/label/'evolution-01'/f'{model}-fine.npz'
                reference=load(retain(reference_path))
                require(np.array_equal(packet['efold'],reference['efold']) and np.array_equal(packet['original'],reference['original']),'same original preparation and leading history')
                for branch_index,branch in enumerate(('gr','poisson-spatial')):
                    candidate=packet['delta'][:,:,branch_index].sum(axis=1)
                    expected=reference['delta'][:,:,branch_index].sum(axis=1)
                    absolute=float(np.max(np.linalg.norm(candidate-expected,axis=1)))
                    scale=float(np.max(np.linalg.norm(expected,axis=1)))
                    physical_scale=float(np.max(np.linalg.norm(reference['original'][:,branch_index],axis=1)))
                    relative=absolute/max(scale,1e-80)
                    physical_relative=absolute/max(physical_scale,1e-80)
                    require(max(relative,physical_relative)<GATE,'independently recomputed direct response regression')
                    regressions.append(dict(label=label,model=model,control=control,branch=branch,correction_relative=relative,physical_relative=physical_relative))
                require(report['phase_error']<ALGEBRA,'retained own phase')
                for row in report['checks']:
                    require(max(row['component_relative'])<GATE and row['initial_relative']<ALGEBRA,'separate forcing components and original initial offset')
                completed_jobs.append(dict(label=label,model=model,control=control,phase=phase))
                family_jobs+=1
        phases=('evolution-01','predictions-01','comparison-01','control-readout-01','residual-diagnosis-01')
        missing=[phase for phase in phases if str(STAGE/label/phase/'result.json') not in reports]
        pending_postprocessing.extend(dict(label=label,phase=phase) for phase in missing)
        if family_jobs==6 and not missing:
            completed_families.append(label)
            comparison=reports[str(STAGE/label/'comparison-01/result.json')]
            require(comparison['all_physical_comparisons_pass'],'all physical readouts accepted')
            for model in comparison['reports']:
                packet=load(retain(STAGE/label/'comparison-01'/f"{model['model']}-comparison.npz"))
                for branch_index,branch in enumerate(model['branches']):
                    for column,row in enumerate(branch['observables']):
                        reference=packet['reference'][:,branch_index,column]
                        predicted=packet['predicted'][:,branch_index,column]
                        relative=float(np.max(abs(predicted-reference))/max(np.max(abs(reference)),1e-80))
                        require(row['within_gate'] and relative<GATE and abs(relative-row['relative'])<ALGEBRA,'independent physical comparison at unchanged scale')
                        physical.append(dict(label=label,model=model['model'],branch=branch['branch'],channel=row['name'],relative=relative))
            for model in reports[str(STAGE/label/'control-readout-01/result.json')]['reports']:
                require(all(row['relative']<GATE for row in model['checks']),'native physical controls')
            for row in reports[str(STAGE/label/'residual-diagnosis-01/result.json')]['records']:
                if not row['phase_absent']:
                    for group in row['groups']:
                        require(group['mean_identity']<ALGEBRA,'moving-clock mean identity')
                        diagnostics.append(dict(label=label,index=row['index'],**group))
    require(completed_families and len(completed_jobs)+len(pending_jobs)==18,'explicit complete and remaining response matrix')
    deferred=[]
    for path in STAGE.glob('*.not-started.json'):
        record=read(path)
        require(not record['worker_started'],'deliberate safe dispatch hold only')
        require(any(row['phase']==record['phase'] for row in pending_jobs),'held job genuinely pending')
        require(not (STAGE/f"{record['phase']}.start.json").exists(),'deferred job has never started')
        retain(path)
        deferred.append(record)
    for path in STAGE.rglob('freeze.json'):
        freeze=read(path)
        for source,seal in freeze['sources'].items():
            retain(source,seal)
        retain(path)
    for path in STAGE.glob('*.start.json'):
        if path.name=='progress-audit-01.start.json':
            continue
        start=read(path)
        end_path=path.with_name(path.name.replace('.start.json','.end.json'))
        require(end_path.exists(),'every earlier worker terminal')
        end=read(end_path)
        require(end['exit_code']==0 and end['pid']==start['pid'] and end['created']==start['created'],'exact successful receipt')
        retain(start['source_path'],start['source_sha256'])
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode')
    parent_artifacts={str(Path(row['path'])):row['sha256'] for row in read(COMPLETED/'closeout.json')['artifacts']}
    for path,seal in consumed.items():
        require(digest(path)==seal,'retained evidence unchanged at safe checkpoint')
        if Path(path).is_relative_to(COMPLETED) and Path(path).name!='closeout.json':
            require(path in parent_artifacts and parent_artifacts[path]==seal,'sealed parent artifact')
    write(output/'result.json',dict(passed=True,full_planned_stage_complete=not pending_jobs and not pending_postprocessing,
        inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        failed_attempts_preserved=[],compiler_receipts=[],completed_families=completed_families,
        completed_jobs=completed_jobs,pending_jobs=pending_jobs,pending_postprocessing=pending_postprocessing,
        deferred=deferred,regressions=regressions,physical=physical,diagnostics=diagnostics,
        scope='verified partial progress only; unfinished matrix remains explicit, no full-stage promotion',
        minimum_all_phase_speed=min(row['minimum_speed'] for row in kernel['node_bounds']),
        physical_approximation_all_pass=True,original_banks_and_gates_unchanged=True,all_residual_terms_retained=True,
        source_derivative_scope='complete retained forcing interpolant'))
    print('safe verified progress',completed_families,'completed jobs',len(completed_jobs),'pending',len(pending_jobs),flush=True)


if __name__=='__main__':
    main()
