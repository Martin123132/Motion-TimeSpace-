from common import *
from clock_primitive import *
from real_series import RealForcing
from scipy.interpolate import CubicSpline


def retained(model):
    report_path=COMPLETED/LABEL/'forcing-02/result.json'
    report=read(report_path)
    require(report['passed'],'accepted parent forcing')
    nodes=next(row['nodes'] for row in report['reports'] if row['model']==model)
    arrays=[]
    consumed={str(report_path):digest(report_path)}
    for node in nodes:
        require(digest(node['path'])==node['sha256'],'unchanged complete forcing packet')
        packet=load(node['path'])
        arrays.append({name:packet[name] for name in ('normal_coefficients','map_coefficients')})
        consumed[node['path']]=node['sha256']
    source=RealForcing(np.array([row['efold'] for row in nodes]),arrays)
    if model=='heavy':
        modes,sine=original_basis()
        require(np.array_equal(source.modes,modes) and np.array_equal(source.use_sine,sine),'exact retained source basis including Nyquist')
    bank_path=COMPLETED/LABEL/'source-even-01'/f'{model}-bank.npz'
    original_path=COMPLETED/LABEL/'mean-evolution-01'/f'{model}-fine.npz'
    consumed.update({str(path):digest(path) for path in (bank_path,original_path)})
    return source,load(bank_path),load(original_path),consumed


class MeanOperator:
    def __init__(self,owner,bank):
        self.owner=owner
        self.noncollision=CubicSpline(bank['efold'],bank['noncollision'])
        self.collision=CubicSpline(bank['efold'],bank['collision'])
        self.remote=CubicSpline(bank['efold'],bank['remote'])
        self.rows,self.columns=bank['keys'].T
        self.compact=bank['mean'].shape[-1]

    def values(self,efold):
        opacity=self.owner.thermal(float(efold))[0]['opacity']['value']
        return self.noncollision(efold)+opacity*self.collision(efold),self.remote(efold)

    def apply(self,state,matrix,weights):
        result=np.zeros_like(state)
        result[:,:,:self.compact]=np.einsum('bij,cbj->cbi',matrix,state[:,:,:self.compact])
        for component in range(state.shape[0]):
            for branch in range(2):
                result[component,branch]+=np.bincount(self.rows,weights*state[component,branch,self.columns],minlength=state.shape[-1])
        return result


def group_relative(candidate,reference):
    difference=np.linalg.norm(candidate-reference,axis=-1)
    scale=np.maximum(np.linalg.norm(candidate,axis=-1),np.linalg.norm(reference,axis=-1))
    return (difference/np.maximum(scale,1e-80)).tolist()
