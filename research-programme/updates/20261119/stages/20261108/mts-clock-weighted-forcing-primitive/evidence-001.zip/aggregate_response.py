from common import *
import numpy as np


def main():
    modest()
    output=ROOT/'evolution-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    reports=[]
    for model in ('heavy','cold'):
        packets={}
        runs=[]
        for control in ('source-coarse','step-coarse','fine'):
            path=ROOT/'response-jobs'/f'{model}-{control}'/'result.json'
            report=read(path)
            require(report['passed'] and digest(report['path'])==report['sha256'],'completed transformed response and frozen output')
            consumed[str(path)]=digest(path)
            consumed[report['path']]=report['sha256']
            packet=load(report['path'])
            packets[control]=packet
            target=output/f'{model}-{control}.npz'
            np.savez_compressed(target,**packet)
            runs.append(dict(name=control,path=str(target),sha256=digest(target),nfev=report['nfev'],seconds=report['seconds'],
                             phase_difference=report['phase_error'],direct_regression=report['checks']))
        checks=[]
        for control in ('source-coarse','step-coarse'):
            for branch_index,branch in enumerate(('gr','poisson-spatial')):
                delta=packets[control]['delta'][:,:,branch_index].sum(axis=1)
                fine=packets['fine']['delta'][:,:,branch_index].sum(axis=1)
                absolute=float(np.max(np.linalg.norm(delta-fine,axis=1)))
                scale=float(np.max(np.linalg.norm(packets['fine']['original'][:,branch_index],axis=1)))
                correction_scale=float(np.max(np.linalg.norm(fine,axis=1)))
                relative=absolute/max(scale,1e-80)
                correction=absolute/max(correction_scale,1e-80)
                require(relative<GATE and correction<GATE,'transformed source/time controls at unchanged gates')
                checks.append(dict(control=control,branch=branch,absolute=absolute,relative=relative,
                                   relative_to_correction=correction,correction_relative=correction_scale/max(scale,1e-80)))
        reports.append(dict(model=model,runs=runs,checks=checks))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,source_control='65 versus33 auxiliary scalar kernels, original forcing bank unchanged',
        exact_unaveraged_transformation=True,all_residual_terms_retained=True,first_variation_only=True,no_reference_reset=True))
    print(LABEL,'all paired transformed-response controls pass',flush=True)


if __name__=='__main__':
    main()
