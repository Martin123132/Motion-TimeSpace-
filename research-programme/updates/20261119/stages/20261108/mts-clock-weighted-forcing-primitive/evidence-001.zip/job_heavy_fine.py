from evolve_transformed import run


if __name__=='__main__':
    run('heavy','fine')
