from common import *
from clock_primitive import *
import time


def maximum_relative(candidate,reference):
    return float(np.max(abs(candidate-reference))/max(float(np.max(abs(candidate))),float(np.max(abs(reference))),1e-80))


def main():
    modest()
    require(LABEL=='half','shared clock bank initially owned by half; others must verify equality')
    output=STAGE/'kernel-bank-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    source_path=COMPLETED/LABEL/'source-even-01/heavy-bank.npz'
    source=load(source_path)
    consumed={str(source_path):digest(source_path)}
    owner=CorrelatedSource('heavy')
    consumed.update(owner.consumed)
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    grid=np.linspace(source['efold'][0],source['efold'][-1],65)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,efold=grid.tolist(),
        auxiliary_phase_count=COUNT,phase_control_count=1025,auxiliary_coarse_stride=2,
        independent_fraction=[.173,.5,.827],angles=[0.,.213,1.157,2.62,float(np.pi)],
        algebra=ALGEBRA,gate=GATE,original_banks_unchanged=True))
    records=[]
    started=time.monotonic()
    for index,efold in enumerate(grid):
        guard()
        records.append(kernels(owner,float(efold)))
        if index%8==0:
            print('clock primitive nodes',index+1,'of',len(grid),flush=True)
    packet=dict(efold=grid,coefficients=np.array([row['coefficients'] for row in records]),
        derivative=np.array([row['derivative'] for row in records]),mean=np.array([row['mean'] for row in records]),
        mean_rate=np.array([row['mean_rate'] for row in records]),modes=records[0]['modes'],sine=records[0]['sine'])
    target=output/'heavy-kernels.npz'
    np.savez_compressed(target,**packet)
    fine=KernelBank(packet)
    coarse=KernelBank(packet,2)
    interpolation=[]
    for index in range(len(grid)-1):
        efold=float((grid[index]+grid[index+1])/2)
        direct=kernels(owner,efold)
        checks={}
        for name,evaluator in (('fine',fine),('coarse',coarse)):
            checks[name]=dict(coefficients=maximum_relative(evaluator.kernel(efold),direct['coefficients']),
                derivative=maximum_relative(evaluator.kernel(efold,1),direct['derivative']),
                mean=maximum_relative(evaluator.mean(efold),direct['mean']),
                mean_rate=maximum_relative(evaluator.mean(efold,1),direct['mean_rate']))
            require(max(checks[name].values())<GATE,'unchanged numerical gate for auxiliary Hermite interpolation')
        interpolation.append(dict(efold=efold,**checks))
    derivative_checks=[]
    angles=np.array([0.,.213,1.157,2.62,np.pi])
    for fraction in (.173,.5,.827):
        efold=float(grid[0]+fraction*(grid[-1]-grid[0]))
        direct=kernels(owner,efold)
        angular=basis(angles,direct['modes'],direct['sine'])
        high=kernels(owner,efold,1025)
        high_angular=basis(angles,high['modes'],high['sine'])
        quadrature=dict(value=maximum_relative(angular@direct['coefficients'],high_angular@high['coefficients']),
            derivative=maximum_relative(angular@direct['derivative'],high_angular@high['derivative']),
            mean=maximum_relative(direct['mean'],high['mean']))
        require(max(quadrature.values())<ALGEBRA,'independent auxiliary phase refinement without coefficient deletion')
        speed,speed_rate,_=phase_clock(owner,efold,angles)
        widths=[]
        for width in (1e-5,5e-6):
            nearby={step:kernels(owner,efold+step*width) for step in (-2,-1,1,2)}
            finite=(nearby[-2]['coefficients']-8*nearby[-1]['coefficients']+
                    8*nearby[1]['coefficients']-nearby[2]['coefficients'])/(12*width)
            nearby_speed={step:phase_clock(owner,efold+step*width,angles)[0] for step in (-2,-1,1,2)}
            finite_speed=(nearby_speed[-2]-8*nearby_speed[-1]+8*nearby_speed[1]-nearby_speed[2])/(12*width)
            record=dict(width=width,kernel_derivative=maximum_relative(angular@finite,angular@direct['derivative']),
                        clock_derivative=maximum_relative(finite_speed,speed_rate))
            require(max(record['kernel_derivative'],record['clock_derivative'])<GATE,'independent fixed-phase derivative')
            widths.append(record)
        derivative_checks.append(dict(fraction=fraction,efold=efold,quadrature=quadrature,finite_differences=widths))
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained clock inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,path=str(target),
        sha256=digest(target),seconds=time.monotonic()-started,
        node_bounds=[dict(efold=float(efold),**record['bounds']) for efold,record in zip(grid,records)],
        maximum_closure=max(row['closure'] for row in records),maximum_normalization=max(row['normalization'] for row in records),
        maximum_differentiated_normalization=max(row['differentiated_normalization'] for row in records),
        interpolation=interpolation,derivative_checks=derivative_checks,no_original_grid_changed=True,
        source_period_pi=True,scalar_clock_kernel_shared_pending_family_checks=True))
    print('complete clock-weighted primitive bank and derivative controls',time.monotonic()-started,flush=True)


if __name__=='__main__':
    main()
