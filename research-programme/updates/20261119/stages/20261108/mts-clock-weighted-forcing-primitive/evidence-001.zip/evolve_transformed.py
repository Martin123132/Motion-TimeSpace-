from common import *
from transformed_support import *
from scipy.integrate import solve_ivp
import time


def run(model,control):
    modest()
    require(model in ('heavy','cold') and control in ('fine','step-coarse','source-coarse'),'frozen paired response job')
    output=ROOT/'response-jobs'/f'{model}-{control}'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    validation=ROOT/'primitive-validation-01/result.json'
    require(read(validation)['passed'],'complete source and derivative validation')
    kernel_report_path=STAGE/'kernel-bank-01/result.json'
    kernel_report=read(kernel_report_path)
    require(kernel_report['passed'] and digest(kernel_report['path'])==kernel_report['sha256'],'derived scalar kernel bank')
    owner=CorrelatedSource(model)
    source,bank,leading,consumed=retained(model)
    consumed.update(owner.consumed)
    consumed.update({str(validation):digest(validation),str(kernel_report_path):digest(kernel_report_path),
                     kernel_report['path']:kernel_report['sha256']})
    kernel=KernelBank(load(kernel_report['path']),2 if control=='source-coarse' else 1) if model=='heavy' else None
    mean_operator=MeanOperator(owner,bank)
    shape=source.shape
    dimension=shape[-1]
    normalization=np.linalg.norm(leading['state'][0],axis=1)
    steps=2048 if control=='step-coarse' else 4096
    start,stop=bank['efold'][[0,-1]]

    def source_terms(efold,theta):
        if model=='cold':
            force=source(efold,theta)
            return force,np.zeros_like(force),np.zeros_like(force)
        return kernel.response(source,efold,theta)

    def rhs(efold,flat):
        guard()
        theta=flat[0]
        eta=flat[1:].reshape(shape)
        if model=='heavy':
            background=owner.saved.mean(efold)
            slow=background['slow'][0]
            external=background['external'][0]
            omega=np.exp(efold)*owner.saved.masses[1]
            reconstructed=reconstruct(float(background['heavy'][0]),float(external[0]),float(external[1]),
                                      float(slow[0]),float(slow[1]),omega,theta)
            phase_rate=omega/float(reconstructed['hubble'])-1.5*np.sin(2*theta)
        else:
            phase_rate=0.
        force,primitive,derivative=source_terms(efold,theta)
        matrix,weights=mean_operator.values(efold)
        delta=eta+primitive/normalization[None,:,None]
        rate=mean_operator.apply(delta,matrix,weights)+(force-derivative)/normalization[None,:,None]
        return np.concatenate([[phase_rate],rate.ravel()])

    initial_primitive=source_terms(float(start),float(bank['phase'][0]))[1]
    initial=np.concatenate([[bank['phase'][0]],(-initial_primitive/normalization[None,:,None]).ravel()])
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,model=model,control=control,
        algebra=ALGEBRA,gate=GATE,steps=steps,rtol=2e-12,atol=2e-14,original_grid=bank['efold'].tolist(),
        transformation='eta=delta-J; retain M J-J_N in full; eta(initial)=-J(initial)',
        source_control='65 versus33 auxiliary scalar-kernel nodes only; original nine forcing nodes unchanged',
        direct_response_not_read_yet=True))
    started=time.monotonic()
    solved=solve_ivp(rhs,(start,stop),initial,method='DOP853',t_eval=bank['efold'],rtol=2e-12,atol=2e-14,
                     max_step=(stop-start)/steps)
    require(solved.success and np.isfinite(solved.y).all(),'full transformed response solve')
    elapsed=time.monotonic()-started
    phase_error=float(np.max(abs(solved.y[0]-bank['phase'])))
    require(phase_error<ALGEBRA,'same independently reproduced original phase')
    eta=solved.y[1:].T.reshape(-1,*shape)*normalization[None,None,:,None]
    primitive=np.array([source_terms(float(efold),float(theta))[1] for efold,theta in zip(bank['efold'],solved.y[0])])
    delta=eta+primitive
    state=leading['state']+delta.sum(axis=1)
    target=output/'prediction.npz'
    np.savez_compressed(target,efold=bank['efold'],state=state,delta=delta,original=leading['state'],
                        phase=solved.y[0],eta=eta,primitive=primitive)
    prediction_hash=digest(target)
    reference_path=COMPLETED/LABEL/'evolution-01'/f'{model}-fine.npz'
    reference=load(reference_path)
    consumed[str(reference_path)]=digest(reference_path)
    require(np.array_equal(reference['efold'],bank['efold']) and np.array_equal(reference['original'],leading['state']),'same incoming mode and saved leading trajectory')
    checks=[]
    for branch_index,branch in enumerate(('gr','poisson-spatial')):
        difference=delta[:,:,branch_index].sum(axis=1)-reference['delta'][:,:,branch_index].sum(axis=1)
        absolute=float(np.max(np.linalg.norm(difference,axis=1)))
        base_scale=float(np.max(np.linalg.norm(leading['state'][:,branch_index],axis=1)))
        correction_scale=float(np.max(np.linalg.norm(reference['delta'][:,:,branch_index].sum(axis=1),axis=1)))
        physical=absolute/max(base_scale,1e-80)
        correction=absolute/max(correction_scale,1e-80)
        require(physical<GATE and correction<GATE,'unchanged gate for physical response and strict representation regression of correction')
        components=[]
        for component in range(2):
            absolute_component=float(np.max(np.linalg.norm(delta[:,component,branch_index]-reference['delta'][:,component,branch_index],axis=1)))
            scale=float(np.max(np.linalg.norm(reference['delta'][:,component,branch_index],axis=1)))
            relative=absolute_component/max(scale,1e-80)
            require(relative<GATE,'separate normal-form and coordinate-map response regression')
            components.append(relative)
        initial_error=float(np.linalg.norm(delta[0,:,branch_index].sum(axis=0))/normalization[branch_index])
        require(initial_error<ALGEBRA,'original zero new response preserved through derived initial offset')
        checks.append(dict(branch=branch,physical_relative=physical,relative_to_correction=correction,
            component_relative=components,initial_relative=initial_error))
    require(digest(target)==prediction_hash and all(digest(path)==seal for path,seal in consumed.items()),'frozen prediction and retained inputs')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,model=model,control=control,
        path=str(target),sha256=prediction_hash,checks=checks,nfev=solved.nfev,seconds=elapsed,phase_error=phase_error,
        no_reference_reset=True,all_residual_terms_retained=True,original_inputs_and_tolerances_unchanged=True))
    print(LABEL,model,control,'transformed response passed',elapsed,checks,flush=True)
