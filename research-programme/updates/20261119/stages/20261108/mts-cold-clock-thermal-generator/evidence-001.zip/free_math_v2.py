from common import *


def build(layout,source,sound,opacity,masses,wave,coordinate,velocity,rho,clock,cosine,sine):
    zero=coordinate*0
    hubble=((source['density']+(coordinate**2+velocity**2)/2+rho)/3)**.5
    eta0=1-(source['enthalpy']+velocity**2+rho)/(2*hubble**2)
    fraction=rho/(2*hubble**2)
    eta=eta0+fraction*cosine
    fluid=source['fluid']
    free={}
    injection={}
    groups={name:{} for name in ('drift','streaming','collision','pressure','clock','heavy')}
    def put(group,row,column,value):
        key=(row,column)
        groups[group][key]=groups[group].get(key,zero)+value
        free[key]=free.get(key,zero)+value
    def force(row,column,value):
        injection[(row,column)]=injection.get((row,column),zero)+value
    gauge=layout['alpha']
    put('drift',gauge,gauge,zero-1.5)
    force(gauge,0,fluid[0]**.5*wave/hubble)
    for name,species in (('cdm',0),('baryon',1)):
        row=layout[name]
        put('drift',row,row,eta-.5)
        put('drift',row,gauge if name=='cdm' else layout['baryon_velocity'],zero-1)
        force(row,1,3*fluid[species]**.5*hubble/wave)
    baryon=layout['baryon_velocity']
    put('drift',baryon,baryon,zero-1.5)
    force(baryon,0,fluid[1]**.5*wave/hubble)
    put('pressure',baryon,layout['baryon'],sound*wave**2/hubble**2)
    put('pressure',baryon,gauge,3*sound*(fluid[1]/fluid[0])**.5)
    for name,species in (('photon_all',2),('massless_all',3)):
        slots=layout[name]
        maximum=len(slots)-1
        ufa=name=='massless_all' and layout['ufa']
        require(maximum>2 or ufa,'retained full hierarchy or original UFA branch')
        angular=[2*degree+1 for degree in range(maximum+1)]
        angular[-1]=maximum
        for degree,row in enumerate(slots):
            put('drift',row,row,zero-1)
            if degree:
                lower=1 if degree==maximum else (zero+degree)/(2*degree+1)
                put('streaming',row,slots[degree-1],wave/hubble*lower*((zero+angular[degree])/angular[degree-1])**.5)
            if degree<maximum:
                put('streaming',row,slots[degree+1],-wave/hubble*(degree+1)/(2*degree+1)*((zero+angular[degree])/angular[degree+1])**.5)
        put('clock',slots[-1],slots[-1],-(maximum+1)/(hubble*clock))
        force(slots[0],1,2*fluid[species]**.5)
        force(slots[1],0,2*fluid[species]**.5*wave/((zero+3)**.5*hubble))
        if ufa:
            weight=(fluid[species]/2)**.5
            put('drift',slots[2],gauge,-4*weight*hubble*(eta-1)/(fluid[0]**.5*wave))
            force(slots[2],0,-4*weight)
            force(slots[2],1,-4*weight)
    polar=layout['polar_all']
    maximum=len(polar)+1
    angular={degree:(zero+2*degree+1)*(degree+1)*(degree+2)/(degree*(degree-1)) for degree in range(2,maximum+1)}
    previous=(zero+2*maximum-1)*maximum*(maximum+1)/((maximum-1)*(maximum-2))
    angular[maximum]=previous*(maximum+2)*(maximum-2)/(maximum*(2*maximum-1))/((zero+maximum)/(maximum-2))
    for degree,row in enumerate(polar,2):
        put('drift',row,row,zero-1)
        if degree>2:
            lower=(zero+degree)/(degree-2) if degree==maximum else (zero+degree)/(2*degree+1)
            put('streaming',row,polar[degree-3],wave/hubble*lower*(angular[degree]/angular[degree-1])**.5)
        if degree<maximum:
            upper=(zero+degree+3)*(degree-1)/((degree+1)*(2*degree+1))
            put('streaming',row,polar[degree-1],-wave/hubble*upper*(angular[degree]/angular[degree+1])**.5)
    put('clock',polar[-1],polar[-1],-(maximum+3)/(hubble*clock))
    collision=opacity/hubble
    ratio=4*fluid[2]/(3*fluid[1])
    dipole=layout['photon_all'][1]
    put('collision',baryon,baryon,-ratio*collision)
    put('collision',baryon,dipole,ratio**.5*collision)
    put('collision',dipole,baryon,ratio**.5*collision)
    put('collision',dipole,dipole,-collision)
    for row in layout['photon_all'][2:]+polar:
        put('collision',row,row,-collision)
    quadrupole=layout['photon_all'][2]
    put('collision',quadrupole,quadrupole,collision/10)
    put('collision',quadrupole,polar[0],(zero+6)**.5*collision/10)
    put('collision',polar[0],quadrupole,(zero+6)**.5*collision/10)
    put('collision',polar[0],polar[0],3*collision/5)
    for node,(slots,amount,speed) in enumerate(zip(layout['massive'],source['massive'],source['speeds'])):
        width=(speed**2+4*(hubble/wave)**2)**.5
        width_rate=(-speed**2*(1-speed**2)+4*(hubble/wave)**2*eta)/width**2
        diagonal=-(3-speed**2)/2
        put('drift',slots[0],slots[0],-(1+speed**2)/2+width_rate)
        put('streaming',slots[0],slots[1],-width*wave/((zero+3)**.5*hubble))
        put('streaming',slots[1],slots[0],speed**2*wave/((zero+3)**.5*hubble*width))
        extended=slots+layout['tail_by_node'][node]
        for degree in range(1,len(extended)):
            put('drift',extended[degree],extended[degree],diagonal)
            if degree>1:
                put('streaming',extended[degree],extended[degree-1],degree*wave*speed/(hubble*((zero+2*degree-1)*(2*degree+1))**.5))
            if degree<len(extended)-1:
                put('streaming',extended[degree],extended[degree+1],-(degree+1)*wave*speed/(hubble*((zero+2*degree+1)*(2*degree+3))**.5))
        force(slots[0],1,2*amount**.5*width)
        force(slots[1],0,2*amount**.5*wave/((zero+3)**.5*hubble))
    omega_s=source['scale']*masses[0]
    frequency=(wave**2+omega_s**2)**.5
    position,momentum=layout['slow']
    put('drift',position,position,omega_s**2/frequency**2)
    put('drift',momentum,momentum,zero-2)
    put('streaming',position,momentum,frequency/hubble)
    put('streaming',momentum,position,-frequency/hubble)
    force(position,0,frequency*velocity/hubble)
    force(momentum,0,-omega_s*coordinate/hubble)
    force(momentum,1,3*velocity)
    if layout['heavy']:
        position,momentum=layout['heavy']
        omega=source['scale']*masses[1]
        alpha=wave**2/(omega*hubble)
        weight=rho**.5*hubble/wave
        gamma=eta0-.5+(1.5+fraction)*cosine
        put('heavy',position,position,alpha*sine/2+gamma)
        put('heavy',position,momentum,-1+cosine-6*sine/alpha)
        put('heavy',momentum,position,alpha**2*(1+cosine)/4)
        put('heavy',momentum,momentum,-1-eta-3*cosine-alpha*sine/2+gamma)
        force(position,1,weight*3*(1-cosine))
        force(momentum,0,weight*wave**2/hubble**2)
        force(momentum,1,weight*1.5*alpha*sine)
    return dict(free=free,injection=injection,groups=groups,hubble=hubble,eta=eta,eta0=eta0)


def dense(entries,size,columns=None):
    import numpy as np
    matrix=np.zeros((size,size if columns is None else columns))
    for (row,column),value in entries.items():
        matrix[row,column]=float(value)
    return matrix
