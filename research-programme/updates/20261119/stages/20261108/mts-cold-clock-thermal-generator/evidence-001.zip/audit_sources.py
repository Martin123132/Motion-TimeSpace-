from common import *
from cold_access import SavedBackground
from enclose_free import accepted_root
from free_math_v2 import build,dense
from validate_sources import symbolic
import numpy as np


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    sealed={str(Path(item['path'])):item['sha256'] for item in read(FULL/'closeout.json')['artifacts']}
    consumed={}
    paths=[FULL/'build-thermal-readout/native/camb/cambdll.dll',FULL/'build-thermal-readout/build-result.json']
    for label in ('half','balanced','double'):
        paths.append(FULL/label/'full-01/envelope-repair-02.json')
        for model in ('heavy','cold'):
            paths.extend(FULL/label/'full-01'/(model+suffix) for suffix in ('-thermal.npz','-thermal-bound.json','-constants.json'))
            paths.extend(FULL/label/'full-01'/f'{model}-{index}-frozen.npz' for index in range(3))
    for path in paths:
        require(str(path) in sealed and digest(path)==sealed[str(path)],'sealed consumed metric/thermal/native source')
        consumed[str(path)]=sealed[str(path)]
    accepted={}
    maxima=dict(free_absolute=0.,force_absolute=0.,full_vector_relative=0.,full_vector_absolute=0.,v2_half_preservation=0.)
    native_checks=vector_checks=0
    for label in ('half','balanced','double'):
        root=accepted_root(label)
        result=read(root/'result.json')
        require(result['passed'] and result['inputs']==inputs,'qualified same-source free collector')
        implementation='collect_free.py' if label=='half' else 'collect_free_v2.py'
        math='free_math.py' if label=='half' else 'free_math_v2.py'
        for filename in (implementation,math,'common.py','native_context.py'):
            require(result['sources'][str(STAGE/filename)]==digest(STAGE/filename),'executed native derivation unchanged')
        accepted[str(root/'result.json')]=digest(root/'result.json')
        require(len(result['reports'])==6,'baseline and heavy at allthree saved epochs')
        for record in result['reports']:
            model,index=record['model'],record['index']
            freeze=read(root/f'{model}-{index}-freeze.json')
            packet=load(root/f'{model}-{index}-frozen.npz')
            require(digest(root/f'{model}-{index}-frozen.npz')==freeze['prediction_sha256'],'predictions frozen before native check')
            for check in record['checks']:
                require(max(check['free_absolute'],check['force_absolute'])<GATE,'absolute native source/injection gate')
                maxima['free_absolute']=max(maxima['free_absolute'],check['free_absolute'])
                maxima['force_absolute']=max(maxima['force_absolute'],check['force_absolute'])
                native_checks+=1
            if label=='half':
                background=SavedBackground(model)
                state=packet['state']
                for number,angle in enumerate((.239,1.157,2.613)):
                    predicted=build(freeze['layout'],freeze['source'],packet['thermal'][3],packet['thermal'][4],background.masses,dict(read(WAVES)['waves'])[label],
                        np.exp(state[0])*background.masses[0]*state[1],state[2],state[3],state[4],np.cos(2*angle),np.sin(2*angle))
                    for name,columns in (('free',None),('injection',2)):
                        actual=dense(predicted[name],freeze['layout']['size'],columns)
                        discrepancy=float(np.max(abs(actual-packet[name][number])))/max(1.,float(np.max(abs(packet[name][number]))))
                        require(discrepancy<ALGEBRA,'v2 retains original half-k coefficients')
                        maxima['v2_half_preservation']=max(maxima['v2_half_preservation'],discrepancy)
        vector=read(STAGE/label/'full-vectors/result.json')
        require(vector['passed'] and vector['inputs']==inputs and vector['entire_g192_checked'],'full native hierarchy validation')
        require(vector['sources'][str(STAGE/'validate_full_vectors.py')]==digest(STAGE/'validate_full_vectors.py'),'full vector validator unchanged')
        require(len(vector['reports'])==56,'all full vector branches phases and probes')
        for record in vector['reports']:
            require(record['relative']<GATE,'full G192 vector unchanged gate')
            maxima['full_vector_relative']=max(maxima['full_vector_relative'],record['relative'])
            maxima['full_vector_absolute']=max(maxima['full_vector_absolute'],record['absolute'])
            vector_checks+=1
        accepted[str(STAGE/label/'full-vectors/result.json')]=digest(STAGE/label/'full-vectors/result.json')
    envelope=read(STAGE/'source-envelope/result.json')
    require(envelope['passed'] and envelope['inputs']==inputs,'qualified interval source envelope')
    for filename in ('enclose_free.py','interval_jets.py','thermal_jets.py','free_math_v2.py'):
        require(envelope['sources'][str(STAGE/filename)]==digest(STAGE/filename),'executed enclosure source retained')
    for record in envelope['reports']:
        require(digest(record['path'])==record['sha256'],'envelope artifact unchanged')
        value=read(record['path'])
        require(len(value['layout']['tail_by_node'][0])==190,'entireG192 in envelope')
        require(not value['sampled_maximum_used_as_supremum'],'analytic interval not sample inference')
        thermal=STAGE/'source-envelope'/f'{record["label"]}-{record["model"]}-thermal-jets.json'
        require(digest(thermal)==value['thermal_jets_sha256'],'source-owned thermal derivative bound')
        accepted[record['path']]=record['sha256']
        accepted[str(thermal)]=digest(thermal)
    validation=read(STAGE/'source-validation/result.json')
    require(validation['passed'] and validation['inputs']==inputs and len(validation['reports'])==18,'all independent source validation cases')
    require(validation['sources'][str(STAGE/'validate_sources.py')]==digest(STAGE/'validate_sources.py'),'executed independent validator retained')
    require(validation['symbolic']==symbolic(),'exact identities rederived')
    for path,value in validation['frozen_bounds'].items():
        require(digest(path)==value,'bounds frozen through independent validation')
    accepted[str(STAGE/'source-envelope/result.json')]=digest(STAGE/'source-envelope/result.json')
    accepted[str(STAGE/'source-validation/result.json')]=digest(STAGE/'source-validation/result.json')
    failed=read(STAGE/'collect-balanced-01.end.json')
    require(failed['exit_code']==1 and failed['source_sha256']==digest(STAGE/'collect_free.py'),'preserved rejected UFA attempt')
    require('retained full massless hierarchy' in (STAGE/'collect-balanced-01.stderr.log').read_text(),'identified branch-signature gate')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no bytecode leftovers')
    counts=dict(native_free_and_injection_cases=native_checks,full_g192_vectors=vector_checks,
        independent_gradient_entries=sum(row['gradient_entries'] for row in validation['reports']),
        independent_background_clock_fixtures=sum(row['fixtures'] for row in validation['reports']),thermal_jet_checks=validation['thermal_jet_checks'])
    maxima['background_fixture_bound_ratio']=max(row['maximum_bound_ratio'] for row in validation['reports'])
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,compiler_receipts=[],
        counts=counts,maxima=maxima,summary=envelope['reports'],symbolic=validation['symbolic'],
        failed_attempts_preserved=['collect-balanced-01'],algebra=ALGEBRA,gate=GATE,
        full_preperiodic_free_background_envelope=True,thermal_first_second_derivative_envelope=True,
        full_closed_generator_derivative_envelope=False,whole_transport_error=False))
    print(json.dumps(dict(passed=True,counts=counts,maxima=maxima),indent=2),flush=True)


if __name__=='__main__':
    main()
