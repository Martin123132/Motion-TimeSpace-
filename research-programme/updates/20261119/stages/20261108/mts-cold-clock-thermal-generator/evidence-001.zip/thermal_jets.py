from common import *
from thermal_spline import bernstein,range_of
from interval_math import interval,lower,upper
import mpmath as mp


def polynomial_ranges(table,index,offset):
    values=table['values']
    coefficients=bernstein(values[offset],values[offset+1],index)
    first=[3*(coefficients[degree+1]-coefficients[degree]) for degree in range(3)]
    second=[2*(first[degree+1]-first[degree]) for degree in range(2)]
    return range_of(coefficients),range_of(first),range_of(second)


def bounds(table,parent):
    step=interval(float(table['metadata'][1]))
    reports=[]
    for record in parent['selected']:
        if len(reports)%256==0:
            guard()
        index=record['index']
        scale,scale_first,scale_second=polynomial_ranges(table,index,0)
        denominator=step*scale+scale_first
        require(lower(denominator)>0,'source scale derivative positive')
        report=dict(index=index)
        for offset,name in ((2,'sound'),(4,'opacity')):
            value,first,second=polynomial_ranges(table,index,offset)
            rate=scale*first/denominator
            acceleration=scale*((scale_first*first+scale*second)*denominator-scale*first*(step*scale_first+scale_second))/(denominator**2*denominator)
            report[name]=dict(value=[lower(value),upper(value)],first=[lower(rate),upper(rate)],second=[lower(acceleration),upper(acceleration)])
        reports.append(report)
    extrema={name:{derivative:[min(record[name][derivative][0] for record in reports),max(record[name][derivative][1] for record in reports)] for derivative in ('value','first','second')} for name in ('sound','opacity')}
    return dict(cells=reports,extrema=extrema,method='exact chain rule from retained cubic coefficients through scale inversion; outward Bernstein bounds; one-sided second derivative at cell boundaries')


def evaluate(table,index,local):
    step=mp.mpf(float(table['metadata'][1]))
    def polynomial(offset):
        values=table['values']
        left,right=(mp.mpf(float(value)) for value in values[offset,index:index+2])
        slope_left,slope_right=(mp.mpf(float(value)) for value in values[offset+1,index:index+2])
        second=3*(right-left)-2*slope_left-slope_right
        third=slope_left+slope_right+2*(left-right)
        return left+local*(slope_left+local*(second+local*third)),slope_left+local*(2*second+3*local*third),2*second+6*local*third
    scale,scale_first,scale_second=polynomial(0)
    denominator=step*scale+scale_first
    result={}
    for offset,name in ((2,'sound'),(4,'opacity')):
        value,first,second=polynomial(offset)
        rate=scale*first/denominator
        acceleration=scale*((scale_first*first+scale*second)*denominator-scale*first*(step*scale_first+scale_second))/denominator**3
        result[name]=dict(value=value,first=rate,second=acceleration)
    return result
