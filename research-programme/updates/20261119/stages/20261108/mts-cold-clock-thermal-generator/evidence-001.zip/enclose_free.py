from common import *
from cold_access import SavedBackground
from full_envelope_v2 import thermal_source
from interval_math import interval,lower,upper
from interval_jets import Jet,variable,sparse_bound
from free_math_v2 import build
from thermal_jets import bounds
import numpy as np


def accepted_root(label):
    return STAGE/label/('free-01' if label=='half' else 'free-02')


def complete_layout(layout):
    result=dict(layout)
    result['tail_by_node']=[[layout['core']+5*degree+node for degree in range(190)] for node in range(5)]
    result['size']=layout['core']+950
    return result


def main():
    modest()
    output=STAGE/'source-envelope'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),gate=GATE,algebra=ALGEBRA,
        scope='full retained G192 pre-periodic free source and injection; all four scalar/clock background variables; no continuum or total transport claim'))
    reports=[]
    for label in ('half','balanced','double'):
        root=accepted_root(label)
        old=read(FULL/label/'full-01/envelope-repair-02.json')
        for model in ('heavy','cold'):
            guard()
            background=SavedBackground(model)
            previous=next(item for item in old['envelopes'] if item['model']==model)
            box=previous['state_box']
            layout=complete_layout(read(root/f'{model}-0-freeze.json')['layout'])
            constants=read(FULL/label/f'full-01/{model}-constants.json')
            thermal_parent=read(FULL/label/f'full-01/{model}-thermal-bound.json')
            thermal_table=load(FULL/label/f'full-01/{model}-thermal.npz')
            thermal=bounds(thermal_table,thermal_parent)
            thermal_path=output/f'{label}-{model}-thermal-jets.json'
            write(thermal_path,dict(**thermal,parent_sha256=digest(FULL/label/f'full-01/{model}-thermal-bound.json'),table_sha256=digest(FULL/label/f'full-01/{model}-thermal.npz')))
            clock_error=float(background.saved['clock_error'][-1])
            require(clock_error>=0 and np.all(np.diff(background.saved['clock_error'])>=0),'retained positive accumulated clock bound')
            require(np.all(np.diff(background.saved['clock'])>0),'retained positive clock flow')
            first,last=(float(load(FULL/label/f'full-01/{model}-{index}-frozen.npz')['state'][4]) for index in (0,2))
            clock_box=[lower(interval(first)-interval(clock_error)),upper(interval(last)+interval(clock_error))]
            require(clock_box[0]>0,'positive conformal clock throughout tube')
            exterior=thermal_source(background,constants,interval(box['efold']))
            source={name:[Jet(value) for value in exterior[name]] for name in ('fluid','massive','speeds')}
            source.update({name:Jet(exterior[name]) for name in ('density','enthalpy','scale')})
            coordinate=variable(box['slow'],0)
            velocity=variable(box['slow'],1)
            rho=variable(box['rho'],2) if model=='heavy' else Jet(0)
            clock=variable(clock_box,3)
            coefficients=build(layout,source,Jet(interval(thermal['extrema']['sound']['value'])),Jet(interval(thermal['extrema']['opacity']['value'])),
                background.masses,dict(read(WAVES)['waves'])[label],coordinate,velocity,rho,clock,Jet(interval([-1,1])),Jet(interval([-1,1])))
            errors=previous['background_errors']+[clock_error]
            report=dict(label=label,model=model,layout=layout,errors=errors,state_box=dict(**box,clock=clock_box),
                free=sparse_bound(coefficients['free'],errors),injection=sparse_bound(coefficients['injection'],errors),
                groups={name:sparse_bound(entries,errors) for name,entries in coefficients['groups'].items()},
                thermal_jets_sha256=digest(thermal_path),clock_error_source=str(background.folder/'fine.npz'),
                saved_clock_error_Mpc=clock_error,clock_monotonicity='tau_N=1/H>0 and radius_tau,N>=0 in retained extend.py make_rhs; saved endpoints conditional on parent ODE arithmetic',
                phase_independent_thermal_source=True,sampled_maximum_used_as_supremum=False)
            target=output/f'{label}-{model}-envelope.json'
            write(target,report)
            reports.append(dict(label=label,model=model,path=str(target),sha256=digest(target),free_operator=report['free']['operator_bound'],
                injection_operator=report['injection']['operator_bound'],clock_operator=report['groups']['clock']['operator_bound'],clock_error=clock_error,
                size=layout['size'],nonzeros=len(coefficients['free'])))
            print(label,model,'source envelope',reports[-1],flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,
        full_preperiodic_free_background_envelope=True,thermal_first_second_derivative_envelope=True,
        full_closed_generator_derivative_envelope=False,whole_transport_error=False))


if __name__=='__main__':
    main()
