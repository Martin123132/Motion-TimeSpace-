from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from metric_math import external_constants
from thermal_spline import native_values
from free_math_v2 import build
from enclose_free import accepted_root
import numpy as np


def sparse_apply(entries,vector,size):
    result=np.zeros(size)
    for (row,column),value in entries.items():
        result[row]+=float(value)*vector[column]
    return result


def main():
    modest()
    output=ROOT/'full-vectors'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),seed=20261108,angles=[.413,2.271],branches=['gr','poisson-spatial'],
        probes='two full random unit vectors and each of five final-tail-node basis vectors',gate=GATE,algebra=ALGEBRA))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'full-vectors/contexts')
        energy=PhysicalEnergyMap(system)
        layout=read(STAGE/'source-envelope'/f'{LABEL}-{model}-envelope.json')['layout']
        size=layout['size']
        require(size==len(system.units),'entire retained G192 dimension')
        state=load(accepted_root(LABEL)/f'{model}-1-frozen.npz')['state']
        generator=np.random.default_rng(20261108)
        vectors=[generator.normal(size=size) for _ in range(2)]
        vectors=[vector/np.linalg.norm(vector) for vector in vectors]
        for node in range(5):
            vector=np.zeros(size)
            vector[layout['tail_by_node'][node][-1]]=1
            vectors.append(vector)
        with MatchedColdFibre(system) as fibre:
            for angle in (.413,2.271):
                exterior=external_constants(fibre,energy,state)
                fibre.install(state,angle)
                point=point_map(system,energy,float(state[0]))
                thermal=native_values(system.context['lib'],float(state[4]))
                fields=fibre.saved.thermal.values([state[0]])[0]
                source=dict(fluid=exterior['fluid'],massive=exterior['massive'],speeds=exterior['speeds'],density=fields[0],enthalpy=exterior['native_enthalpy'],scale=np.exp(state[0]))
                coefficients=build(layout,source,thermal[3],thermal[4],fibre.masses,system.wave,
                    np.exp(state[0])*fibre.masses[0]*state[1],state[2],state[3],state[4],np.cos(2*angle),np.sin(2*angle))
                diagonal=np.ones(energy.size)
                gamma=0.
                if model=='heavy':
                    diagonal[energy.heavy]=np.sqrt(state[3])*exterior['hubble']/system.wave
                    gamma=point['parameters']['eta0']-.5+(1.5+point['parameters']['b'])*np.cos(2*angle)
                tail_weights=point['adapted']['tail_weights'].ravel()
                require(tail_weights.size==950,'all190 levels and five massive nodes')
                predictions=[]
                for branch in ('gr','poisson-spatial'):
                    metric=point['metrics'][branch]/diagonal
                    for vector in vectors:
                        predicted=sparse_apply(coefficients['free'],vector,size)
                        predicted+=sparse_apply(coefficients['injection'],metric@vector[:energy.size],size)
                        predictions.append(predicted)
                tag=f'{model}-{angle}'
                target=output/(tag+'-frozen.npz')
                np.savez_compressed(target,vectors=vectors,predicted=predictions,state=state)
                write(output/(tag+'-freeze.json'),dict(sha256=digest(target),sources=sources()))
                for number,branch in enumerate(('gr','poisson-spatial')):
                    for index,vector in enumerate(vectors):
                        raw=np.zeros(size)
                        relative=vector[:energy.size]/diagonal
                        raw[:energy.size]=point['raw_inverse']@relative
                        raw[energy.size:]=vector[energy.size:]/tail_weights
                        derivative=system.evaluate(float(state[0]),raw*system.units,branch)[0]/system.units
                        actual=np.zeros(size)
                        actual[:energy.size]=diagonal*(point['raw_transform']@derivative[:energy.size]+point['logarithmic']@relative)
                        if model=='heavy':
                            actual[energy.heavy]+=gamma*vector[energy.heavy]
                        actual[energy.size:]=tail_weights*derivative[energy.size:]+np.tile(point['adapted']['tail_rate'],190)*vector[energy.size:]
                        expected=predictions[number*len(vectors)+index]
                        absolute=float(np.max(abs(actual-expected)))
                        relative_error=absolute/max(1.,float(np.max(abs(expected))))
                        record=dict(model=model,theta=angle,branch=branch,probe=index,absolute=absolute,relative=relative_error,
                            worst_index=int(np.argmax(abs(actual-expected))))
                        reports.append(record)
                        write(output/f'{tag}-{branch}-{index}.json',record)
                        require(relative_error<GATE,'entire retained hierarchy vector gate: '+str(record))
                print(LABEL,model,angle,'full native G192 vectors pass',max(item['relative'] for item in reports),flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,entire_g192_checked=True,
        scope='native full vector action versus derived physical free-plus-metric operator before periodic maps; original tail closure retained'))


if __name__=='__main__':
    main()
