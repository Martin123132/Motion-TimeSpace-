from common import *
from interval_math import interval,lower,upper,magnitude


class Jet:
    def __init__(self,value,gradient=None):
        self.value=value if hasattr(value,'_mpi_') else interval(value)
        self.gradient=[interval(0) for _ in range(4)] if gradient is None else [item if hasattr(item,'_mpi_') else interval(item) for item in gradient]

    @staticmethod
    def cast(value):
        return value if isinstance(value,Jet) else Jet(value)

    def __add__(self,other):
        other=self.cast(other)
        return Jet(self.value+other.value,[left+right for left,right in zip(self.gradient,other.gradient)])

    __radd__=__add__

    def __neg__(self):
        return Jet(-self.value,[-value for value in self.gradient])

    def __sub__(self,other):
        return self+-self.cast(other)

    def __rsub__(self,other):
        return self.cast(other)+-self

    def __mul__(self,other):
        other=self.cast(other)
        return Jet(self.value*other.value,[left*other.value+self.value*right for left,right in zip(self.gradient,other.gradient)])

    __rmul__=__mul__

    def __truediv__(self,other):
        other=self.cast(other)
        require(lower(abs(other.value))>0,'interval divisor excludes zero')
        return Jet(self.value/other.value,[(left*other.value-self.value*right)/other.value**2 for left,right in zip(self.gradient,other.gradient)])

    def __rtruediv__(self,other):
        return self.cast(other)/self

    def __pow__(self,power):
        require(power in (2,.5),'supported source powers')
        value=self.value**power
        coefficient=2*self.value if power==2 else 1/(2*value)
        return Jet(value,[coefficient*entry for entry in self.gradient])


def variable(value,index):
    gradient=[0]*4
    gradient[index]=1
    return Jet(value,gradient)


def sparse_bound(entries,errors):
    import mpmath as mp
    records=[]
    row_sums={}
    column_sums={}
    total=interval(0)
    for (row,column),value in sorted(entries.items()):
        derivatives=[magnitude(item) for item in value.gradient]
        bound=sum(interval(derivative)*interval(error) for derivative,error in zip(derivatives,errors))
        records.append(dict(row=row,column=column,derivatives=derivatives,bound=upper(bound)))
        row_sums[row]=row_sums.get(row,interval(0))+bound
        column_sums[column]=column_sums.get(column,interval(0))+bound
        total+=bound**2
    norm_infinity=max(upper(value) for value in row_sums.values()) if row_sums else 0.
    norm_one=max(upper(value) for value in column_sums.values()) if column_sums else 0.
    frobenius=upper(mp.iv.sqrt(total))
    operator=upper(mp.iv.sqrt(interval(norm_infinity)*interval(norm_one)))
    return dict(entries=records,frobenius_bound=frobenius,operator_bound=min(frobenius,operator),
        infinity_bound=norm_infinity,one_bound=norm_one)
