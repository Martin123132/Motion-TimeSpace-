from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from collect_full_metric import layout_of
from collect_analytic import source_at
from metric_math import external_constants
from thermal_spline import native_values
from free_math_v2 import build,dense
from mean_math import relative_error
import numpy as np


def full_layout(system,energy,point,tail=2):
    layout=layout_of(system,energy,point)
    signature=system.context['signature_values']
    for name,begin,maximum,first in (('photon_all',3,6,0),('polar_all',5,7,2),('massless_all',4,8,0)):
        last=2 if name=='massless_all' and signature[12] else int(signature[maximum])
        layout[name]=[energy.slot(int(signature[begin])+degree) for degree in range(first,last+1)]
    layout['tail_by_node']=[[energy.size+5*degree+node for degree in range(tail)] for node in range(5)]
    layout['core']=energy.size
    layout['size']=energy.size+5*tail
    return layout


def main():
    modest()
    output=ROOT/'free-02'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),angles=[.239,1.157,2.613],gate=GATE,algebra=ALGEBRA,
        parent_dll_sha256=digest(FULL/'build-thermal-readout/native/camb/cambdll.dll')))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'free-02/contexts')
        energy=PhysicalEnergyMap(system)
        with MatchedColdFibre(system) as fibre:
            for index in range(3):
                packet=load(ANALYTIC/LABEL/'analytic-01'/f'{model}-{index}.npz')
                state=packet['state']
                ext=external_constants(fibre,energy,state)
                point=point_map(system,energy,float(state[0]))
                layout=full_layout(system,energy,point)
                thermal=native_values(system.context['lib'],float(state[4]))
                fields=fibre.saved.thermal.values([state[0]])[0]
                source=dict(fluid=ext['fluid'],massive=ext['massive'],speeds=ext['speeds'],density=fields[0],enthalpy=ext['native_enthalpy'],scale=np.exp(state[0]))
                coordinate=np.exp(state[0])*fibre.masses[0]*state[1]
                diagonal=np.ones(layout['size'])
                if model=='heavy':
                    diagonal[energy.heavy]=np.sqrt(state[3])*ext['hubble']/system.wave
                predictions=[build(layout,source,float(thermal[3]),float(thermal[4]),fibre.masses,system.wave,coordinate,state[2],state[3],state[4],np.cos(2*angle),np.sin(2*angle)) for angle in (.239,1.157,2.613)]
                predicted_free=np.array([dense(row['free'],layout['size']) for row in predictions])
                predicted_force=np.array([dense(row['injection'],layout['size'],2) for row in predictions])
                target=output/f'{model}-{index}-frozen.npz'
                np.savez_compressed(target,state=state,thermal=thermal,diagonal=diagonal,free=predicted_free,injection=predicted_force)
                write(output/f'{model}-{index}-freeze.json',dict(prediction_sha256=digest(target),layout=layout,source=source,sources=sources()))
                checks=[]
                for number,angle in enumerate((.239,1.157,2.613)):
                    fresh=source_at(fibre,energy,state,angle,True)
                    actual=fresh['free']*diagonal[:,None]/diagonal[None,:]
                    if model=='heavy':
                        parameters=fresh['point']['parameters']
                        gamma=parameters['eta0']-.5+(1.5+parameters['b'])*np.cos(2*angle)
                        actual[energy.heavy,energy.heavy]+=gamma
                    force=fresh['injection']*diagonal[:,None]
                    discrepancy=actual-predicted_free[number]
                    force_discrepancy=force-predicted_force[number]
                    worst=np.unravel_index(np.argmax(abs(discrepancy)),discrepancy.shape)
                    np.savez_compressed(output/f'{model}-{index}-actual-{number}.npz',free=actual,injection=force)
                    absolute=float(np.max(abs(discrepancy)))
                    force_absolute=float(np.max(abs(force_discrepancy)))
                    check=dict(theta=angle,free_absolute=absolute,free_relative=relative_error(predicted_free[number],actual),
                        force_absolute=force_absolute,force_relative=relative_error(predicted_force[number],force),
                        worst_index=[int(value) for value in worst],actual=float(actual[worst]),predicted=float(predicted_free[number][worst]))
                    checks.append(check)
                    write(output/f'{model}-{index}-check-{number}.json',check)
                    require(max(absolute,force_absolute)<GATE,'full retained free/injection absolute coefficient gate: '+str(check))
                    collision=dense(predictions[number]['groups']['collision'],layout['size'])
                    require(np.max(abs(collision-collision.T))<ALGEBRA,'physical Thomson collision symmetric')
                    require(np.linalg.eigvalsh(collision)[-1]<ALGEBRA,'physical Thomson collision dissipative')
                reports.append(dict(model=model,index=index,checks=checks))
                print(LABEL,model,index,'derived free and force pass',max(item['free_absolute'] for item in checks),flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,gate=GATE,algebra=ALGEBRA,
        all_retained_core_rows_checked=True,tail_boundary_checked=True,scope='pre-periodic physical free generator and metric injection; no thermal/background uncertainty yet'))


if __name__=='__main__':
    main()
