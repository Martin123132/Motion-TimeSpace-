from common import *
from cold_access import SavedBackground,namespace
from validate_full_metric_v2 import external
from enclose_free import accepted_root
from free_math_v2 import build
from thermal_jets import evaluate
import mpmath as mp
import numpy as np
import sympy as sp


mp.mp.dps=70


def symbolic():
    ratio=sp.symbols('r',positive=True)
    dipole=sp.Matrix([[-ratio,sp.sqrt(ratio)],[sp.sqrt(ratio),-1]])
    vector=sp.Matrix([sp.sqrt(ratio),-1])
    quadrupole=sp.Matrix([[-sp.Rational(9,10),sp.sqrt(6)/10],[sp.sqrt(6)/10,-sp.Rational(2,5)]])
    eigenvalue=sp.symbols('lambda')
    clock,hubble,eta=sp.symbols('tau H eta',positive=True)
    clock_rate=sp.diff(1/(hubble*clock),clock)/hubble+sp.diff(1/(hubble*clock),hubble)*eta*hubble
    checks=dict(collision_dipole=(dipole+vector*vector.T)==sp.zeros(2),
        collision_quadrupole=sp.factor(quadrupole.charpoly(eigenvalue).as_expr()-(eigenvalue+1)*(eigenvalue+sp.Rational(3,10)))==0,
        clock_derivative=sp.factor(clock_rate+eta/(hubble*clock)+1/(hubble**2*clock**2))==0)
    degree=sp.symbols('ell',positive=True)
    angular=lambda value:(2*value+1)*(value+1)*(value+2)/(value*(value-1))
    checks['polarization_streaming_skew']=sp.factor((degree+3)*(degree-1)/((degree+1)*(2*degree+1))*angular(degree)-(degree+1)/(2*degree+3)*angular(degree+1))==0
    checks['intensity_streaming_skew']=sp.factor(degree/(2*degree-1)*(2*degree-1)-degree/(2*degree+1)*(2*degree+1))==0
    require(all(checks.values()),'exact collision, clock and streaming identities')
    return checks


def source_at(background,constants,efold):
    record=external(background,constants,efold)
    return dict(fluid=record['fluid'],massive=record['massive'],speeds=record['speeds'],density=record['external_density'],
        enthalpy=record['external_enthalpy'],scale=record['scale_factor'])


def thermal_check(table,report):
    records=report['cells']
    initial,step=(mp.mpf(float(value)) for value in table['metadata'])
    count=0
    def polynomial(offset,index,local):
        values=table['values']
        left,right=(mp.mpf(float(value)) for value in values[offset,index:index+2])
        first,last=(mp.mpf(float(value)) for value in values[offset+1,index:index+2])
        return (2*local**3-3*local**2+1)*left+(local**3-2*local**2+local)*first+(-2*local**3+3*local**2)*right+(local**3-local**2)*last
    for selected in sorted(set(np.linspace(0,len(records)-1,17,dtype=int).tolist())):
        record=records[selected]
        index=record['index']
        for local in map(mp.mpf,('0','.193','.5','.817','1')):
            efold=lambda value:mp.log(initial)+(index+value)*step+mp.log(polynomial(0,index,value))
            first=mp.diff(efold,local)
            second=mp.diff(efold,local,2)
            actual=evaluate(table,index,local)
            for offset,name in ((2,'sound'),(4,'opacity')):
                function=lambda value:polynomial(offset,index,value)
                source_first=mp.diff(function,local)
                source_second=mp.diff(function,local,2)
                expected={'value':function(local),'first':source_first/first,'second':(source_second*first-source_first*second)/first**3}
                for derivative,value in expected.items():
                    require(abs(actual[name][derivative]-value)<mp.mpf('1e-55')*max(abs(value),mp.mpf('1e-30')),'independent70-digit implicit scale derivative')
                    require(mp.mpf(record[name][derivative][0])<=value<=mp.mpf(record[name][derivative][1]),'thermal jet inside interval source bound')
                    count+=1
    return count


def main():
    modest()
    output=STAGE/'source-validation'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    summary=read(STAGE/'source-envelope/result.json')
    frozen={row['path']:row['sha256'] for row in summary['reports']}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),frozen_bounds=frozen,precision_digits=70,angles=[.371,2.109],
        complex_steps=['1e-30','1e-35'],stress_source='parent finite positive quadrature; original constants and bank unchanged',
        scope='differentiation independent of interval AD; source equations separately native-qualified'))
    reports=[]
    checks=symbolic()
    thermal_total=0
    for label in ('half','balanced','double'):
        root=accepted_root(label)
        for model in ('heavy','cold'):
            background=SavedBackground(model)
            constants=read(FULL/label/f'full-01/{model}-constants.json')
            table=load(FULL/label/f'full-01/{model}-thermal.npz')
            thermal=read(STAGE/'source-envelope'/f'{label}-{model}-thermal-jets.json')
            thermal_total+=thermal_check(table,thermal)
            envelope=read(STAGE/'source-envelope'/f'{label}-{model}-envelope.json')
            layout=envelope['layout']
            limits={name:{(record['row'],record['column']):record for record in envelope[name]['entries']} for name in ('free','injection')}
            masses=[mp.mpf(float(value)) for value in background.masses]
            wave=mp.mpf(dict(read(WAVES)['waves'])[label])
            for index in range(3):
                guard()
                packet=load(root/f'{model}-{index}-frozen.npz')
                state=packet['state']
                efold=mp.mpf(float(state[0]))
                source=source_at(background,constants,efold)
                sound,opacity=(mp.mpf(float(packet['thermal'][number])) for number in (3,4))
                values=[source['scale']*masses[0]*mp.mpf(float(state[1])),mp.mpf(float(state[2])),mp.mpf(float(state[3])),mp.mpf(float(state[4]))]
                local=background.mean([float(state[0])])
                dense,_=namespace['dense_values'](background.dense,np.array([float(state[0])]))
                radius=mp.mpf(float(local['radius'][0]))
                width=mp.mpf(float(local['width'][0]))
                clock_error=mp.mpf(float(dense[0,4]/background.configuration['initial_hubble']))
                gradients=fixtures=0
                largest=mp.mpf(0)
                for angle in (.371,2.109):
                    cosine,sine=mp.cos(2*mp.mpf(angle)),mp.sin(2*mp.mpf(angle))
                    def calculate(state_values):
                        return build(layout,source,sound,opacity,masses,wave,*state_values,cosine,sine)
                    before=calculate(values)
                    for component in range(4):
                        if model=='cold' and component==2:
                            continue
                        derivatives=[]
                        for step in (mp.mpf('1e-30'),mp.mpf('1e-35')):
                            shifted=values.copy()
                            shifted[component]+=mp.j*step
                            test=calculate(shifted)
                            derivatives.append({name:{key:mp.im(value)/step for key,value in test[name].items()} for name in ('free','injection')})
                        for name,entries in derivatives[-1].items():
                            for key,value in entries.items():
                                old=derivatives[0][name][key]
                                require(abs(value-old)<mp.mpf('1e-40')*max(abs(value),mp.mpf('1e-15')),'independent derivative step refinement')
                                require(abs(value)<=mp.mpf(limits[name][key]['derivatives'][component])+mp.mpf('1e-55'),'full source derivative within frozen interval bound')
                                gradients+=1
                    signs=[(-1,-1,1,1),(1,-1,-1,1),(-1,1,1,-1),(1,1,-1,-1)] if model=='heavy' else [(0,0,0,0)]
                    for direction in signs:
                        shifted=[values[0]+direction[0]*radius/mp.sqrt(2),values[1]+direction[1]*radius/mp.sqrt(2),values[2]*mp.exp(direction[2]*width),values[3]+direction[3]*clock_error]
                        after=calculate(shifted)
                        for name in ('free','injection'):
                            square=mp.mpf(0)
                            for key,value in before[name].items():
                                difference=abs(after[name][key]-value)
                                require(difference<=mp.mpf(limits[name][key]['bound']),'source entry within full frozen background/clock bound')
                                square+=difference**2
                            difference=mp.sqrt(square)
                            limit=mp.mpf(envelope[name]['frobenius_bound'])
                            require(difference<=limit,'full G192 Frobenius source bound')
                            largest=max(largest,difference/limit if limit else 0)
                        fixtures+=1
                reports.append(dict(label=label,model=model,index=index,gradient_entries=gradients,fixtures=fixtures,maximum_bound_ratio=float(largest)))
                print(label,model,index,'full source gradient/clock checks',float(largest),flush=True)
    require(all(digest(path)==value for path,value in frozen.items()),'no bound adjusted after prediction')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),frozen_bounds=frozen,reports=reports,symbolic=checks,
        thermal_jet_checks=thermal_total,precision_digits=70,physical_gates_unchanged=True))


if __name__=='__main__':
    main()
