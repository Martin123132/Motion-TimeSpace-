from common import *
from analytic_math import metric,operator
from mean_math import relative_error
import numpy as np


def main():
    modest()
    output=STAGE/'jet-check'
    output.mkdir(exist_ok=False)
    records=[]
    for label in ('half','balanced','double'):
        for index in range(3):
            path=STAGE/label/'analytic-01'/f'heavy-{index}.npz'
            packet=load(path)
            differences={}
            for direction in ('background','energy_cosine'):
                for field in ('numerator','denominator'):
                    coarse=packet[f'{direction}_{field}_coarse']
                    fine=packet[f'{direction}_{field}_fine']
                    error=relative_error(coarse,fine)
                    differences[f'{direction}_{field}']=error
                    require(error<GATE,'slow coefficient derivative refinement independently gated')
            coarse_rates=np.array([metric(packet,angle,'coarse')[1] for angle in (.127,.783,1.831,2.751)])
            fine_rates=np.array([metric(packet,angle,'fine')[1] for angle in (.127,.783,1.831,2.751)])
            differences['physical_metric_rate']=relative_error(coarse_rates,fine_rates)
            require(differences['physical_metric_rate']<GATE,'physical metric derivative refinement')
            records.append(dict(label=label,index=index,packet_sha256=digest(path),errors=differences))
    write(output/'result.json',dict(passed=True,sources=sources(),records=records,
        note='direct jet refinement; avoids normalizing every error by large streaming entries in the full generator'))
    print(json.dumps(dict(passed=True,maxima={name:max(row['errors'][name] for row in records) for name in records[0]['errors']}),indent=2),flush=True)


if __name__=='__main__':
    main()
