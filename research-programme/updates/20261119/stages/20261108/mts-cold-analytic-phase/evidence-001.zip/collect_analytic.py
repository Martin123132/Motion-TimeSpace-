from common import *
import numpy as np
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from energy_operator import stable_point,local_slow_rates,fourth
from validate_remainder import metric_angle_rate
from mean_math import phase_primitive,relative_error
from analytic_math import project,evaluate,operator,bounds,uniform_tube


ANGLES=np.arange(8)*np.pi/8


def source_at(fibre,energy,state,angle,free=False):
    fibre.install(state,float(angle))
    point=point_map(fibre.system,energy,float(state[0]))
    size=energy.size+10
    metric=np.zeros((2,2,size))
    for branch,name in enumerate(('gr','poisson-spatial')):
        metric[branch,:,:energy.size]=point['metrics'][name]
    rho=float(state[3])
    denominator=float(point['adapted']['old']['denominator'])
    constant=denominator+3*rho*np.cos(2*angle)
    normalized=denominator/constant
    result=dict(numerator=normalized*metric,denominator=normalized,point=point)
    if not free:
        return result
    sample=stable_point(fibre,energy,state,angle,np.zeros_like(metric[:,:,:energy.size]),check_native=False)
    mapping=point['maps']['gr']
    matrix=sample['matrix'][0].copy()
    matrix[:energy.size,:energy.size]=sample['relative'][0]
    matrix[:energy.size,energy.size:]=mapping['forward']@matrix[:energy.size,energy.size:]
    matrix[energy.size:,:energy.size]=matrix[energy.size:,:energy.size]@mapping['inverse']
    injection=np.zeros((size,2))
    rows=point['adapted']['rows']
    injection[:energy.size]=point['rotation']@np.column_stack([rows['psi_injection'],rows['phi_injection']])
    result.update(free=matrix-injection@metric[0],injection=injection,sample=sample)
    return result


def family(fibre,energy,state,full=False):
    points=[source_at(fibre,energy,state,angle,full) for angle in ANGLES]
    arrays={}
    errors={}
    fields=[('numerator',2),('denominator',1)]+([('free',1),('injection',1)] if full else [])
    for name,degree in fields:
        raw=np.array([item[name] for item in points])
        arrays[name],absolute=project(raw,degree)
        errors[name]=absolute/max(1.,float(np.max(abs(raw))))
        require(errors[name]<ALGEBRA,'derived finite harmonic degree: '+name)
    return arrays,errors,points[0]


def create(fibre,energy,state):
    packet,errors,first=family(fibre,energy,state,True)
    point=first['point']
    pars=point['parameters']
    fibre.install(state,0.)
    flow0=fibre.flow.copy()
    flow0[3]=-state[3]
    flowc=np.zeros(5)
    flowc[3]=3*state[3]
    for name,direction in (('background',flow0),('energy_cosine',flowc)):
        for suffix,width in (('coarse',.001),('fine',.0005)):
            shifted=[]
            for multiplier in (-2,-1,1,2):
                local,local_errors,_=family(fibre,energy,state+multiplier*width*direction)
                shifted.append(local)
                for key,value in local_errors.items():
                    errors[f'{name}_{suffix}_{multiplier}_{key}']=value
            for key in ('numerator','denominator'):
                packet[f'{name}_{key}_{suffix}']=fourth([item[key] for item in shifted],width)
    size=energy.size+10
    diagonal=np.ones(size)
    diagonal[energy.heavy]=np.sqrt(state[3])*point['adapted']['old']['hubble']/fibre.system.wave
    speed=first['sample']['matrix'][0,energy.size+5:energy.size+10,energy.size:energy.size+5].diagonal()*np.sqrt(9*7)/4
    packet.update(state=state,size=size,core=energy.size,heavy=energy.heavy,diagonal=diagonal,
        alpha=pars['alpha'],mu=pars['mu'],eta0=pars['eta0'],fraction=pars['b'],wave=fibre.system.wave,
        flow0=flow0,flowc=flowc,remote_norm=2*float(np.max(abs(speed)))+1.5)
    return packet,errors


def main():
    modest()
    output=ROOT/'analytic-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),gate=GATE,algebra=ALGEBRA,
        held_out_angles=[.293,1.671,2.831],phase_nodes=8,phase_source_degrees=dict(numerator=2,denominator=1,free=1,injection=1),
        radius=16.,retained_fourier_order=256,background_nodes='cold endpoints and saved midpoint; not a whole-path sampled maximum'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'analytic-01/contexts')
        energy=PhysicalEnergyMap(system)
        with MatchedColdFibre(system) as fibre:
            start=float(np.log(fibre.saved.target['scale_start']))
            stop=float(fibre.saved.saved['efold'][-1])
            midpoint=float(load(ENERGY/LABEL/'energy-01'/(model+'-bank.npz'))['state'][0])
            for index,efold in enumerate((start,midpoint,stop)):
                guard()
                state,tube=fibre.saved_state(efold)
                name=f'{model}-{index}'
                if model=='cold':
                    candidates=[]
                    for angle in (0.,.293,1.671,2.831):
                        candidates.append(stable_point(fibre,energy,state,angle,np.zeros((2,2,energy.size)))['matrix'])
                    error=max(relative_error(value,candidates[0]) for value in candidates[1:])
                    require(error==0.,'baseline exact phase independence')
                    if index==1:
                        reference=load(ENERGY/LABEL/'energy-01/cold-bank.npz')['matrix'][0]
                        require(relative_error(candidates[0],reference)<ALGEBRA,'saved baseline reuse')
                    np.savez_compressed(output/(name+'.npz'),state=state,matrix=candidates[0])
                    reports.append(dict(name=name,phase_error=error,background_tube=tube))
                    print(LABEL,name,'baseline phase independent',flush=True)
                    continue
                packet,degree_errors=create(fibre,energy,state)
                packet_path=output/(name+'.npz')
                np.savez_compressed(packet_path,**packet)
                angles=np.arange(256)*np.pi/256
                candidate=np.array([operator(packet,angle) for angle in angles])
                coarse=np.array([operator(packet,angle,'coarse') for angle in angles])
                width_error=relative_error(candidate,coarse)
                require(width_error<GATE,'unchanged coefficient-jet refinement')
                angular_clock=float(packet['mu'])-1.5*np.sin(2*angles)
                means=[phase_primitive(candidate[:,branch],angular_clock) for branch in range(2)]
                predicted=np.array([operator(packet,angle) for angle in (.293,1.671,2.831)])
                np.savez_compressed(output/(name+'-frozen.npz'),candidate=candidate,predicted=predicted,
                    means=np.array([item['mean'] for item in means]),primitives=np.array([item['primitive'] for item in means]))
                source_bounds=bounds(packet)
                write(output/(name+'-freeze.json'),dict(source_sha256=digest(packet_path),prediction_sha256=digest(output/(name+'-frozen.npz')),
                    sources=sources(),bounds=source_bounds,width_error=width_error,degree_errors=degree_errors))
                checks=[]
                for held,angle in enumerate((.293,1.671,2.831)):
                    slow,_=local_slow_rates(fibre,energy,state,angle,.001)
                    phase=metric_angle_rate(fibre,energy,state,angle)
                    fibre.install(state,angle)
                    direct=stable_point(fibre,energy,state,angle,slow+fibre.angular_rate*phase)
                    actual=direct['matrix']*packet['diagonal'][None,:,None]/packet['diagonal'][None,None,:]
                    gamma=float(packet['eta0'])-.5+(1.5+float(packet['fraction']))*np.cos(2*angle)
                    actual[:,energy.heavy,energy.heavy]+=gamma
                    error=relative_error(actual,predicted[held])
                    native=max(direct['scalar_residual'])
                    require(max(error,native)<GATE,'frozen rational source native test')
                    fresh=source_at(fibre,energy,state,angle,True)
                    for key in ('free','injection','numerator','denominator'):
                        discrepancy=relative_error(np.asarray(fresh[key]),np.asarray(evaluate(packet[key],angle)))
                        require(discrepancy<GATE,'independent finite-harmonic source: '+key)
                        checks.append(dict(theta=angle,component=key,error=discrepancy))
                    checks.append(dict(theta=angle,component='generator',error=error,native_scalar=native))
                saved_errors={}
                if index==1:
                    original=load(ENERGY/LABEL/'energy-01/heavy-bank.npz')
                    saved_errors['field']=relative_error(candidate,original['matrix'])
                    for branch in range(2):
                        previous=load(ENERGY/LABEL/f'energy-01/heavy-mean-{branch}.npz')
                        for key in ('mean','primitive'):
                            saved_errors[f'{key}_{branch}']=relative_error(means[branch][key],previous[key])
                    require(max(saved_errors.values())<GATE,'saved midpoint operator and mean/primitive retained')
                reports.append(dict(name=name,efold=efold,background_tube=tube,width_error=width_error,
                    degree_errors=degree_errors,checks=checks,bounds=source_bounds,saved_errors=saved_errors,
                    packet_sha256=digest(packet_path)))
                print(LABEL,name,'passed',width_error,'analytic256tail',source_bounds[0]['field_interpolation_tail_256'],flush=True)
    old=read(RELATIVE/'coefficient-01/result.json')
    parameters=next(row for row in old['reports'] if row['model']=='heavy' and row['label']==LABEL)
    inverse=next(row for row in read(JOINT/'summary/result.json')['reports'] if row['label']==LABEL)
    uniform=uniform_tube(parameters['alpha_interval'],parameters['mu_min'],inverse['bound']['hubble_max'],WAVE)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,uniform_tube_inverses=uniform,
        uniform_source_history_envelope=False,interval_roundoff_certificate=False,
        scope='analytic phase family and inverse theorem; fixed slow-state tail bounds separate from source arithmetic and slow-jet errors'))


if __name__=='__main__':
    main()
