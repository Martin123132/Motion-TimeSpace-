from common import *
from analytic_math import modes,project,evaluate,operator,bounds,uniform_tube,norm
from forced_map import source_map,symbolic_forcing
from mean_math import relative_error
from run_native import native_provenance
import ast
import numpy as np
import sympy as sp


def at_z(coefficients,coordinate,derivative=False):
    powers=modes(len(coefficients))
    factors=coordinate**powers
    if derivative:
        factors=factors*2j*powers
    return np.tensordot(factors,coefficients,axes=(0,0))


def complex_source(packet,coordinate):
    heavy=packet['heavy'].astype(int)
    size=int(packet['size'])
    identity=np.eye(size,dtype=complex)
    selector=identity[heavy]
    cosine=(coordinate+1/coordinate)/2
    sine=(coordinate-1/coordinate)/(2j)
    angles=np.arange(8)*np.pi/8
    items=[source_map(float(packet['alpha']),float(packet['mu']),float(packet['eta0']),float(packet['fraction']),angle) for angle in angles]
    fields={}
    for name,degree in (('primitive',1),('affine',1),('affine_rate',2)):
        coefficients=project(np.array([item[name] for item in items]),degree)[0]
        fields[name]=at_z(coefficients,coordinate)
    transform_rate=at_z(project(np.array([item['partial']+item['angular']*item['theta_rate'] for item in items]),2)[0],coordinate)
    transform=np.eye(2)+fields['primitive']
    affine=fields['affine']
    denominator=at_z(packet['denominator'],coordinate)
    numerator=at_z(packet['numerator'],coordinate)
    metric=numerator/denominator
    theta_rate=(at_z(packet['numerator'],coordinate,True)-metric*at_z(packet['denominator'],coordinate,True))/denominator
    slow=np.zeros_like(metric)
    for direction,factor in (('background',1.),('energy_cosine',cosine)):
        slow+=factor*(at_z(packet[f'{direction}_numerator_fine'],coordinate)-metric*at_z(packet[f'{direction}_denominator_fine'],coordinate))/denominator
    metric_rate=(float(packet['mu'])-1.5*sine)*theta_rate+slow
    free=at_z(packet['free'],coordinate)
    injection=at_z(packet['injection'],coordinate)
    matrices=[]
    denominators=[]
    feedbacks=[]
    for branch in range(2):
        small=np.eye(2)-affine@metric[branch][:,heavy]
        forward=identity.copy()
        forward[heavy]=np.linalg.solve(small,transform@selector+affine@(metric[branch]-metric[branch][:,heavy]@selector))
        inverse=identity.copy()
        inverse[heavy]=np.linalg.solve(transform,selector-affine@metric[branch])
        rate=np.zeros((size,size),dtype=complex)
        rate[heavy]=-np.linalg.solve(transform,transform_rate@inverse[heavy]+fields['affine_rate']@metric[branch]+affine@metric_rate[branch])
        value=inverse@(free+injection@metric[branch])@forward+rate@forward
        diagonal=packet['diagonal']
        value=value*diagonal[:,None]/diagonal[None,:]
        value[heavy,heavy]+=float(packet['eta0'])-.5+(1.5+float(packet['fraction']))*cosine
        matrices.append(value)
        determinant=np.linalg.det(denominator*np.eye(2)-affine@numerator[branch][:,heavy])
        denominators.append(denominator**2*np.linalg.det(transform)**2*determinant)
        feedbacks.append(float(np.linalg.norm(affine@metric[branch][:,heavy],2)))
    return np.array(matrices),np.array(denominators),feedbacks,float(np.linalg.norm(fields['primitive'],2))


def exact_checks():
    wave,enthalpy,quad,psi,free_density,eta,current,free_current=sp.symbols('k W Wq psi D eta J K',nonzero=True)
    denominator=2*wave**2+3*quad
    gr=-(free_density+3*eta*current+3*free_current+3*quad*psi)/denominator
    gr_rewrite=-psi-(free_density+3*eta*current+3*free_current-2*wave**2*psi)/denominator
    poisson=-(free_density+3*(quad-enthalpy)*psi)/denominator
    poisson_rewrite=-psi-(free_density-(2*wave**2+3*enthalpy)*psi)/denominator
    numerator,denominator_symbol,numerator_rate,denominator_rate=sp.symbols('P d Pn dn',nonzero=True)
    quotient=sp.diff(numerator/denominator_symbol,numerator)*numerator_rate+sp.diff(numerator/denominator_symbol,denominator_symbol)*denominator_rate
    alpha,mu,eta_c,sine,cosine=sp.symbols('alpha mu etaC s c',nonzero=True)
    exact=sp.sympify(symbolic_forcing()['affine'],locals={str(symbol):symbol for symbol in (alpha,mu,eta_c,sine,cosine)})
    diffcos=sp.Matrix([[-3,-3+3*alpha/(4*mu)],[-alpha**2/4,0]])
    diffsin=sp.Matrix([[-alpha/2,0],[(3+eta_c)*alpha/2,sp.Rational(3,2)*alpha-3*alpha**2/(8*mu)]])
    expected=(diffcos*sine-diffsin*cosine)/(2*mu)
    checks=dict(gr_rewrite=sp.factor(gr-gr_rewrite),poisson_defect_rewrite=sp.factor(poisson-poisson_rewrite),
        quotient_derivative=sp.factor(quotient-(numerator_rate-numerator/denominator_symbol*denominator_rate)/denominator_symbol))
    for row in range(2):
        for column in range(2):
            checks[f'affine_bound_source_{row}_{column}']=sp.factor(exact[row,column]-expected[row,column])
    require(all(value==0 for value in checks.values()),'exact metric/quotient/affine identities')
    return {name:str(value) for name,value in checks.items()}


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    provenance=native_provenance()
    checks=exact_checks()
    consumed={}
    for parent,relative_paths in (
        (RELATIVE,['coefficient-01/result.json']),
        (JOINT,['summary/result.json']),
        (COLD,['build-canonical-stress/native/camb/cambdll.dll','build-canonical-stress/build-result.json']),
        (ENERGY,[f'{label}/energy-01/{model}-bank.npz' for label in ('half','balanced','double') for model in ('heavy','cold')]+[f'{label}/energy-01/heavy-mean-{branch}.npz' for label in ('half','balanced','double') for branch in (0,1)])):
        sealed={str(Path(row['path'])):row['sha256'] for row in read(parent/'closeout.json')['artifacts']}
        for relative in relative_paths:
            path=parent/relative
            require(digest(path)==sealed[str(path)],'consumed sealed evidence: '+str(path))
            consumed[str(path)]=sealed[str(path)]
    initial=read(STAGE/'half/analytic-01/freeze.json')
    require(digest(STAGE/'analytic_math_initial.py')==initial['sources'][str(STAGE/'analytic_math.py')],'exact imported half-family source retained')
    before=ast.parse((STAGE/'analytic_math_initial.py').read_text())
    after=ast.parse((STAGE/'analytic_math.py').read_text())
    for name in ('modes','project','evaluate','angular','norm','wiener','metric','operator','uniform_tube'):
        left=next(node for node in before.body if isinstance(node,ast.FunctionDef) and node.name==name)
        right=next(node for node in after.body if isinstance(node,ast.FunctionDef) and node.name==name)
        require(ast.dump(left)==ast.dump(right),'bound-only revision: '+name)
    accepted={}
    maxima={}
    cases=[]
    all_uniform=[]
    for label in ('half','balanced','double'):
        root=STAGE/label/'analytic-01'
        report=read(root/'result.json')
        require(report['passed'] and report['inputs']==inputs,'completed same-input source run')
        for source in ('collect_analytic.py','common.py','native_context.py'):
            require(report['sources'][str(STAGE/source)]==digest(STAGE/source),'executed source unchanged')
        if label!='half':
            require(report['sources'][str(STAGE/'analytic_math.py')]==digest(STAGE/'analytic_math.py'),'executed analytic source unchanged')
        accepted[str(root/'result.json')]=digest(root/'result.json')
        require(len(report['reports'])==6,'three epochs and both models')
        old=next(row for row in read(RELATIVE/'coefficient-01/result.json')['reports'] if row['model']=='heavy' and row['label']==label)
        former=next(row for row in read(JOINT/'summary/result.json')['reports'] if row['label']==label)
        uniform=uniform_tube(old['alpha_interval'],old['mu_min'],former['bound']['hubble_max'],old['wave'])
        require(uniform==report['uniform_tube_inverses'],'uniform inverse bounds independently reproduced')
        all_uniform.append(dict(label=label,rows=uniform))
        for record in report['reports']:
            name=record['name']
            if name.startswith('cold'):
                require(record['phase_error']==0.,'baseline phase independence')
                continue
            require(digest(root/(name+'.npz'))==record['packet_sha256'],'source packet hash')
            packet=load(root/(name+'.npz'))
            frozen=read(root/(name+'-freeze.json'))
            require(digest(root/(name+'-frozen.npz'))==frozen['prediction_sha256'],'prediction frozen before native tests')
            predictions=load(root/(name+'-frozen.npz'))
            authoritative_bounds=bounds(packet)
            for field in ('width_error',):
                maxima[field]=max(maxima.get(field,0.),record[field])
                require(record[field]<GATE,'same gate')
            for field,error in record['degree_errors'].items():
                maxima['degree_error']=max(maxima.get('degree_error',0.),error)
                require(error<ALGEBRA,'finite numerator qualification')
            for check in record['checks']:
                maxima['heldout_'+check['component']]=max(maxima.get('heldout_'+check['component'],0.),check['error'])
                require(check['error']<GATE,'heldout source validation')
                if 'native_scalar' in check:
                    maxima['native_scalar']=max(maxima.get('native_scalar',0.),check['native_scalar'])
                    require(check['native_scalar']<GATE,'native scalar validation')
            for field,error in record['saved_errors'].items():
                maxima['saved_'+field]=max(maxima.get('saved_'+field,0.),error)
                require(error<GATE,'saved work retained')
            multiplied=[]
            real_error=0.
            complex_ratios=[]
            for index in range(64):
                angle=np.pi*index/64
                actual,denominators,_,_=complex_source(packet,np.exp(2j*angle))
                expected=predictions['candidate'][4*index]
                real_error=max(real_error,relative_error(actual,expected))
                multiplied.append(actual*denominators[:,None,None])
            coefficients=np.fft.fft(np.array(multiplied),axis=0)/64
            residual=float(np.max(abs(coefficients[abs(modes(64))>15])))/max(1.,float(np.max(abs(coefficients))))
            require(max(real_error,residual)<ALGEBRA,'independent analytic continuation and degree15 numerator')
            for radius in (1/16,16.):
                for phase in (.173,1.093,2.417):
                    actual,_,feedbacks,primitive=complex_source(packet,radius*np.exp(2j*phase))
                    require(primitive<uniform[0]['primitive_map_bound'],'complex T inside uniform tube bound')
                    for branch in range(2):
                        ratio=norm(actual[branch])/authoritative_bounds[branch]['field_wiener_bound']
                        require(ratio<=1 and feedbacks[branch]<uniform[branch]['metric_feedback_bound'],'complex source and uniform closure bound')
                        complex_ratios.append(ratio)
            maxima['rational_degree_residual']=max(maxima.get('rational_degree_residual',0.),residual)
            maxima['complex_real_agreement']=max(maxima.get('complex_real_agreement',0.),real_error)
            cases.append(dict(label=label,name=name,bounds=authoritative_bounds,degree15_error=residual,
                real_source_agreement=real_error,complex_bound_ratio=max(complex_ratios),background_tube=record['background_tube']))
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,provenance=provenance,consumed=consumed,
        accepted_results=accepted,sources=sources(),checks=checks,maxima=maxima,cases=cases,uniform_tube=all_uniform,
        independent_native_angles=27,baseline_phase_controls=27,complex_phase_fixtures=108,
        full_cold_history_bound=False,analytic_source_tail_theorem=True,interval_roundoff_certificate=False,
        scope='source-derived rational phase family; corrected bounds here supersede collection-time bounds; source/slow/background errors separate'))
    print(json.dumps(dict(passed=True,checks=checks,maxima=maxima,uniform_tube=all_uniform),indent=2),flush=True)


if __name__=='__main__':
    main()
