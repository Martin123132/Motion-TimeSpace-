from common import *
import numpy as np
from forced_map import source_map
from joint_math import closed_map


def modes(count):
    return np.rint(np.fft.fftfreq(count,d=1/count)).astype(int)


def project(values,degree):
    coefficients=np.fft.fft(values-values[0],axis=0)/len(values)
    coefficients[0]+=values[0]
    excluded=abs(modes(len(values)))>degree
    error=float(np.max(abs(coefficients[excluded]))) if np.any(excluded) else 0.
    coefficients[excluded]=0.
    return coefficients,error


def evaluate(coefficients,angle):
    return np.tensordot(np.exp(2j*modes(len(coefficients))*angle),coefficients,axes=(0,0)).real


def angular(coefficients,angle):
    return np.tensordot(2j*modes(len(coefficients))*np.exp(2j*modes(len(coefficients))*angle),coefficients,axes=(0,0)).real


def norm(value):
    return float(np.linalg.norm(np.asarray(value).ravel()))


def wiener(coefficients,radius):
    return sum(norm(value)*radius**abs(order) for order,value in zip(modes(len(coefficients)),coefficients))


def metric(packet,angle,width):
    numerator=evaluate(packet['numerator'],angle)
    denominator=float(evaluate(packet['denominator'],angle))
    value=numerator/denominator
    phase=(angular(packet['numerator'],angle)-value*angular(packet['denominator'],angle))/denominator
    slow=np.zeros_like(value)
    for direction,factor in (('background',1.),('energy_cosine',np.cos(2*angle))):
        jet=evaluate(packet[f'{direction}_numerator_{width}'],angle)
        jet_d=float(evaluate(packet[f'{direction}_denominator_{width}'],angle))
        slow+=factor*(jet-value*jet_d)/denominator
    rate=(float(packet['mu'])-1.5*np.sin(2*angle))*phase+slow
    return value,rate


def operator(packet,angle,width='fine'):
    heavy=packet['heavy'].astype(int)
    size=int(packet['size'])
    value,rate=metric(packet,angle,width)
    free=evaluate(packet['free'],angle)
    injection=evaluate(packet['injection'],angle)
    gamma=float(packet['eta0'])-.5+(1.5+float(packet['fraction']))*np.cos(2*angle)
    item=source_map(float(packet['alpha']),float(packet['mu']),float(packet['eta0']),float(packet['fraction']),angle)
    transform_rate=item['partial']+item['angular']*item['theta_rate']
    output=[]
    for branch in range(2):
        mapping=closed_map(item,value[branch],heavy)
        forward,inverse=mapping['forward'],mapping['inverse']
        inverse_rate=np.zeros((size,size))
        inverse_rate[heavy]=-item['inverse']@(transform_rate@inverse[heavy]+item['affine_rate']@value[branch]+item['affine']@rate[branch])
        generator=inverse@(free+injection@value[branch])@forward+inverse_rate@forward
        diagonal=packet['diagonal']
        generator=generator*diagonal[:,None]/diagonal[None,:]
        generator[heavy,heavy]+=gamma
        output.append(generator)
    return np.array(output)


def bounds(packet,radius=16.):
    angles=np.arange(8)*np.pi/8
    items=[source_map(float(packet['alpha']),float(packet['mu']),float(packet['eta0']),float(packet['fraction']),angle) for angle in angles]
    primitive=project(np.array([item['primitive'] for item in items]),1)[0]
    affine=project(np.array([item['affine'] for item in items]),1)[0]
    transform_rate=project(np.array([item['partial']+item['angular']*item['theta_rate'] for item in items]),2)[0]
    affine_rate=project(np.array([item['affine_rate'] for item in items]),2)[0]
    primitive_norm=wiener(primitive,radius)
    affine_norm=wiener(affine,radius)
    transform_rate_norm=wiener(transform_rate,radius)
    affine_rate_norm=wiener(affine_rate,radius)
    denominator=packet['denominator'].copy()
    constant=float(denominator[0].real)
    denominator[0]=0.
    denominator_tail=wiener(denominator,radius)
    denominator_inverse=1/(constant-denominator_tail)
    require(constant>denominator_tail and primitive_norm<1,'analytic denominator and T inverse')
    free_norm=wiener(packet['free'],radius)+float(packet['remote_norm'])
    injection_norm=wiener(packet['injection'],radius)
    angular_multiplier=2*np.abs(modes(8))
    metric_phase_den=wiener(packet['denominator']*angular_multiplier,radius)
    heavy=packet['heavy'].astype(int)
    condition=float(np.max(packet['diagonal'])/np.min(packet['diagonal']))
    mu=float(packet['mu'])
    inverse_clock=1/(mu-1.5*radius)
    rows=[]
    for branch in range(2):
        numerator=packet['numerator'][:,branch]
        metric_norm=wiener(numerator,radius)*denominator_inverse
        metric_heavy=wiener(numerator[:,:,heavy],radius)*denominator_inverse
        feedback=affine_norm*metric_heavy
        require(feedback<1,'analytic closed-metric inverse')
        forward=1+(primitive_norm+affine_norm*metric_norm)/(1-feedback)
        inverse=1+(primitive_norm+affine_norm*metric_norm)/(1-primitive_norm)
        metric_phase=(wiener(numerator*angular_multiplier[:,None,None],radius)+metric_norm*metric_phase_den)*denominator_inverse
        slow=0.
        for direction,factor in (('background',1.),('energy_cosine',radius)):
            slow+=factor*(wiener(packet[f'{direction}_numerator_fine'][:,branch],radius)+metric_norm*wiener(packet[f'{direction}_denominator_fine'],radius))*denominator_inverse
        metric_rate=(mu+1.5*radius)*metric_phase+slow
        inverse_rate=(transform_rate_norm*inverse+affine_rate_norm*metric_norm+affine_norm*metric_rate)/(1-primitive_norm)
        generator=free_norm+injection_norm*metric_norm
        gamma=abs(float(packet['eta0'])-.5)+(1.5+float(packet['fraction']))*radius
        field=condition*(inverse*generator+inverse_rate)*forward+gamma
        primitive_bound=field*inverse_clock
        rows.append(dict(radius=radius,primitive_map_norm=primitive_norm,affine_norm=affine_norm,
            metric_denominator_margin=constant-denominator_tail,metric_feedback=feedback,
            forward_norm=forward,inverse_norm=inverse,field_wiener_bound=field,
            periodic_primitive_wiener_bound=primitive_bound,
            field_interpolation_tail_256=2*field*radius**(-128),
            periodic_primitive_interpolation_tail_256=2*primitive_bound*radius**(-128),
            clock_mean_quadrature_error_256=field*inverse_clock*np.sqrt(mu*mu-2.25)*radius**(-256),
            scope='analytic truncation of the derived rational coefficient model at this slow state; excludes numerical input/jet error'))
    return rows


def uniform_tube(alpha_interval,mu_min,hubble_max,wave,radius=16.):
    lower,upper=alpha_interval
    primitive=radius*(5.5+upper**2/4+upper+6/lower)/(2*mu_min)
    affine=radius*(6+3*upper/(4*mu_min)+upper**2/4+upper/2+4.5*upper/2+1.5*upper+3*upper**2/(8*mu_min))/(2*mu_min)
    density=3*hubble_max**2
    denominator_ratio=3*density/(2*wave**2)
    inverse_denominator=1/(2*wave**2*(1-radius*denominator_ratio))
    pressure=density*radius*(1+2/lower)
    scaled_current=density*hubble_max**2/wave**2*(upper*radius/2+1+radius)
    free_density=density*(1+3*radius*(1+2/lower)+upper*radius/2+1+radius)
    eta=2+1.5*radius
    enthalpy=hubble_max**2*(6+3*radius)
    output=[]
    for branch in ('gr','poisson-spatial'):
        psi=density/(2*wave**2)+(1.5*scaled_current/wave**2 if branch=='gr' else 0.)
        if branch=='gr':
            phi=psi+inverse_denominator*(free_density+3*eta*scaled_current+6*scaled_current+3*pressure+2*wave**2*psi)
        else:
            phi=psi+inverse_denominator*(free_density+(2*wave**2+3*enthalpy)*psi)
        feedback=affine*(psi+phi)
        require(max(primitive,feedback,radius*denominator_ratio,1.5*radius/mu_min)<1,'whole cold tube analytic inverses')
        output.append(dict(branch=branch,radius=radius,primitive_map_bound=primitive,affine_bound=affine,
            metric_feedback_bound=feedback,normalized_denominator_contraction=radius*denominator_ratio,
            inverse_T_bound=1/(1-primitive),inverse_M_bound=1/(1-feedback),
            inverse_clock_contraction=1.5*radius/mu_min))
    return output
