from common import *
from cold_access import SavedBackground
from interval_math import enclosure
from momentum_identity import symbolic_full
from collect_metric_v2 import identities
from validate_tube import source_external,direct
from run_native import native_provenance
import ast
import mpmath as mp
import numpy as np


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    provenance=native_provenance()
    checks=identities()
    checks['full_momentum_identity']=symbolic_full()
    consumed={}
    for parent,paths in ((ANALYTIC,[f'{label}/analytic-01/{model}-{index}.npz' for label in ('half','balanced','double') for model in ('heavy','cold') for index in range(3)]+['audit/result.json']),
                         (RELATIVE,['cold-transfer-01/result.json']),
                         (COLD,['build-canonical-stress/native/camb/cambdll.dll','build-canonical-stress/build-result.json'])):
        sealed={str(Path(row['path'])):row['sha256'] for row in read(parent/'closeout.json')['artifacts']}
        for relative in paths:
            path=parent/relative
            require(digest(path)==sealed[str(path)],'sealed consumed source unchanged')
            consumed[str(path)]=sealed[str(path)]
    failed=read(STAGE/'collect-half-01.end.json')
    require(failed['exit_code']==1 and 'TypeError' in (STAGE/'collect-half-01.stderr.log').read_text(),'preserved aggregation failure identified')
    require(digest(STAGE/'collect_metric.py')==failed['source_sha256'],'exact failed source retained')
    baseline=SavedBackground('heavy')
    accepted={}
    summary=[]
    maxima={}
    gradient_checks=0
    for label in ('half','balanced','double'):
        root=STAGE/label/'metric-02'
        report=read(root/'result.json')
        require(report['passed'] and report['inputs']==inputs and report['identities']==checks,'accepted same-source run and identities')
        for filename in ('collect_metric_v2.py','metric_math.py','interval_math.py','momentum_identity.py','common.py','native_context.py'):
            require(report['sources'][str(STAGE/filename)]==digest(STAGE/filename),'executed implementation unchanged')
        accepted[str(root/'result.json')]=digest(root/'result.json')
        old=report['interval']
        constants=read(root/'heavy-constants.json')
        prior=next(row for row in read(ANALYTIC/'audit/result.json')['uniform_tube'] if row['label']==label)
        feedback={row['branch']:row['metric_feedback_bound'] for row in prior['rows']}
        wave=dict(read(WAVES)['waves'])[label]
        reproduced=enclosure(baseline,constants,old['replacement'],*old['state_box']['efold'],wave,feedback)
        for key in ('rows','state_box','absolute_background_errors','parameter_errors'):
            require(reproduced[key]==old[key],'interval envelope independently reproduced: '+key)
        require(len(report['reports'])==6,'all six model/epoch cases')
        for record in report['reports']:
            for item in record['momentum']:
                for name in ('error','absolute_error','naive_constraint_residual','baryon_pressure_residual','quadrature_residual'):
                    maxima['momentum_'+name]=max(maxima.get('momentum_'+name,0.),item[name])
                require(item['error']<GATE,'native full-row momentum identity')
            if record['model']=='cold':
                require(record['baseline_phase_error']==0,'baseline absent heavy phase')
                continue
            path=root/f'heavy-{record["index"]}-repaired.npz'
            require(digest(path)==record['repaired_sha256'],'repaired source hash')
            packet=load(path)
            require(packet['denominator'][0]==1,'exact normalized constant')
            for direction in ('background','energy_cosine'):
                for accuracy in ('fine','coarse'):
                    require(packet[f'{direction}_denominator_{accuracy}'][0]==0,'exact constant derivative zero')
            for item in record['metric_checks']:
                maxima['heavy_metric_error']=max(maxima.get('heavy_metric_error',0.),item['error'])
                require(item['error']<GATE,'independent heavy column check')
            for name,value in record['old_jet_errors'].items():
                maxima['old_'+name]=max(maxima.get('old_'+name,0.),value)
                require(value<GATE,'same jet gate')
            maxima['generator_change']=max(maxima.get('generator_change',0.),record['maximum_generator_change'])
            require(record['maximum_generator_change']<GATE,'saved generator preserved')
            state=packet['state']
            efold=mp.mpf(float(state[0]))
            external=source_external(baseline,constants,efold)
            omega=mp.exp(efold)*mp.mpf(baseline.masses[1])
            values=[mp.exp(efold)*mp.mpf(baseline.masses[0])*mp.mpf(float(state[1])),mp.mpf(float(state[2])),mp.mpf(float(state[3]))]
            for branch in range(2):
                for field in ('relative_metric','physical_metric','feedback'):
                    limits=old['rows'][branch][field]['derivatives']
                    for row in range(2):
                        for column in range(2):
                            for component in range(3):
                                def probe(value):
                                    changed=values.copy()
                                    changed[component]=value
                                    return direct(changed,external,omega,mp.mpf(wave),mp.mpf('.713'))[0][branch][field][row,column]
                                derivative=mp.diff(probe,values[component])
                                require(abs(derivative)<=mp.mpf(limits[row][column][component]),'independent70-digit derivative within interval AD bound')
                                gradient_checks+=1
        summary.append(dict(label=label,rows=old['rows'],parameter_errors=old['parameter_errors']))
    independent=read(STAGE/'tube-validation/result.json')
    require(independent['passed'] and independent['inputs']==inputs,'independent uncertainty fixtures')
    require(sum(row['fixtures'] for row in independent['reports'])==288,'all frozen fixtures')
    for path,value in independent['frozen_bounds'].items():
        require(digest(path)==value,'bounds frozen before fixtures')
    require(independent['sources'][str(STAGE/'validate_tube.py')]==digest(STAGE/'validate_tube.py'),'independent validator unchanged')
    accepted[str(STAGE/'tube-validation/result.json')]=digest(STAGE/'tube-validation/result.json')
    maxima['independent_fixture_bound_ratio']=max(value for row in independent['reports'] for value in row['maximum_bound_ratios'].values())
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,provenance=provenance,consumed=consumed,accepted_results=accepted,
        sources=sources(),checks=checks,maxima=maxima,summary=summary,gradient_checks=gradient_checks,
        full_momentum_row_checks=63,heavy_column_checks=54,independent_tube_fixtures=288,
        failed_attempts_preserved=['collect-half-01'],full_generator_background_bound=False,
        scope='exact denominator jets and retained full momentum identity; interval background sensitivity of heavy metric columns and closure inverse; parent tube and finite thermal source retained'))
    print(json.dumps(dict(passed=True,maxima=maxima,gradient_checks=gradient_checks,summary=summary),indent=2),flush=True)


if __name__=='__main__':
    main()
