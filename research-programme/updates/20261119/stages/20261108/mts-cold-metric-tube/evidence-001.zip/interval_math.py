from common import *
import mpmath as mp
import numpy as np
from metric_math import scalar_metric,affine_map


mp.iv.dps=50


def interval(value):
    return mp.iv.mpf(value)


def upper(value):
    return float(np.nextafter(float(value.b),np.inf))


def lower(value):
    return float(np.nextafter(float(value.a),-np.inf))


def magnitude(value):
    return float(np.nextafter(max(abs(float(value.a)),abs(float(value.b))),np.inf))


class Dual:
    def __init__(self,value,gradient=None):
        self.value=value if hasattr(value,'_mpi_') else interval(value)
        self.gradient=[interval(0) for _ in range(3)] if gradient is None else gradient

    @staticmethod
    def cast(value):
        return value if isinstance(value,Dual) else Dual(value)

    def __add__(self,other):
        other=self.cast(other)
        return Dual(self.value+other.value,[left+right for left,right in zip(self.gradient,other.gradient)])

    __radd__=__add__

    def __neg__(self):
        return Dual(-self.value,[-value for value in self.gradient])

    def __sub__(self,other):
        return self+-self.cast(other)

    def __rsub__(self,other):
        return self.cast(other)+-self

    def __mul__(self,other):
        other=self.cast(other)
        return Dual(self.value*other.value,[left*other.value+self.value*right for left,right in zip(self.gradient,other.gradient)])

    __rmul__=__mul__

    def __truediv__(self,other):
        other=self.cast(other)
        require(lower(abs(other.value))>0,'interval division away from zero')
        return Dual(self.value/other.value,[(left*other.value-self.value*right)/(other.value**2) for left,right in zip(self.gradient,other.gradient)])

    def __rtruediv__(self,other):
        return self.cast(other)/self

    def __pow__(self,power):
        require(power in (2,.5),'owned powers only')
        value=self.value**power
        factor=2*self.value if power==2 else 1/(2*value)
        return Dual(value,[factor*entry for entry in self.gradient])


def variable(bounds,index):
    derivative=[interval(0) for _ in range(3)]
    derivative[index]=interval(1)
    return Dual(interval(bounds),derivative)


def matmul(left,right):
    return [[sum(left[row][inner]*right[inner][column] for inner in range(2)) for column in range(2)] for row in range(2)]


def derivative_bound(matrix,errors):
    values=[]
    gradients=[]
    for row in matrix:
        bound_row=[]
        gradient_row=[]
        for item in row:
            coefficients=[magnitude(value) for value in item.gradient]
            bound_row.append(upper(sum(interval(value)*interval(error) for value,error in zip(coefficients,errors))))
            gradient_row.append(coefficients)
        values.append(bound_row)
        gradients.append(gradient_row)
    bound=upper(mp.iv.sqrt(sum(interval(value)**2 for row in values for value in row)))
    return dict(entry_bounds=values,frobenius_bound=bound,derivatives=gradients)


def matrix_bound(matrix):
    return upper(mp.iv.sqrt(sum(interval(magnitude(item.value))**2 for row in matrix for item in row)))


def thermal_interval(background,efold):
    scale=mp.iv.exp(efold)
    parameters=background.thermal.parameters
    cold=(interval(parameters['cdm'])+interval(parameters['baryon']))/scale
    radiation=(interval(parameters['photon'])+interval(parameters['massless']))/(scale**2)
    density=cold+radiation
    enthalpy_massive=interval(0)
    for mass,coefficient in zip(parameters['masses'],parameters['coefficients']):
        for node,weight in zip(background.thermal.nodes,background.thermal.weights):
            energy=mp.iv.sqrt(interval(float(node))**2+(interval(mass)*scale)**2)
            speed2=(interval(float(node))/energy)**2
            amount=interval(coefficient)/(scale**2)*energy*interval(float(weight))
            density+=amount
            enthalpy_massive+=amount*(1+speed2/3)
    return density,enthalpy_massive


def quadrature_interval(constants,efold):
    ratio=interval(constants['origin_scale'])/mp.iv.exp(efold)
    fluid=[interval(value)*ratio**power for value,power in zip(constants['fluid_origin'],(1,1,2,2))]
    massive=[]
    for density,speed in zip(constants['massive_origin'],constants['speeds_origin']):
        velocity=1/mp.iv.sqrt(1+(1/interval(speed)**2-1)/ratio**2)
        massive.append(interval(density)*ratio**2*interval(speed)/velocity)
    quantum=(interval(4)/3)*sum(massive)
    total=fluid[0]+fluid[1]+(interval(4)/3)*(fluid[2]+fluid[3])+quantum
    return total,quantum


def enclosure(background,constants,replacement,start,stop,wave,feedback_bound):
    efold=interval([start,stop])
    scale=mp.iv.exp(efold)
    initial=background.mean([start])
    rho0=float(initial['heavy'][0])
    span=stop-start
    width=replacement['heavy_width_bound']
    rho_interval=interval(rho0)*mp.iv.exp(interval([-span-width,width]))
    slow_upper=upper(interval(replacement['slow_norm_upper'])+interval(replacement['slow_error_upper']))
    coordinate=variable([-slow_upper,slow_upper],0)
    velocity=variable([-slow_upper,slow_upper],1)
    density=variable([lower(rho_interval),upper(rho_interval)],2)
    external,enthalpy_massive=thermal_interval(background,efold)
    quadrature,quantum=quadrature_interval(constants,efold)
    defect=quantum-enthalpy_massive
    hubble=((Dual(external)+(coordinate**2+velocity**2)/2+density)/3)**.5
    omega=Dual(scale*interval(background.masses[1]))
    cosine=Dual(interval([-1,1]))
    sine=Dual(interval([-1,1]))
    errors=[replacement['slow_error_upper'],replacement['slow_error_upper'],replacement['heavy_error_upper']]
    affine=affine_map(density,hubble,omega,wave,cosine,sine)
    rows=[]
    for branch in ('gr','poisson-spatial'):
        metric=scalar_metric(density,hubble,velocity,omega,wave,Dual(quadrature),Dual(defect),cosine,sine,branch)
        weight=(density**.5)*hubble/wave
        physical=[[item/weight for item in row] for row in metric]
        feedback=matmul(affine,metric)
        feedback_error=derivative_bound(feedback,errors)
        bound=matrix_bound(feedback)
        require(bound<1 and bound<=feedback_bound[branch],'whole-tube interval feedback and inherited inverse bound')
        rows.append(dict(branch=branch,relative_metric=derivative_bound(metric,errors),
            physical_metric=derivative_bound(physical,errors),feedback=feedback_error,
            feedback_contraction=bound,closed_inverse_difference=upper(interval(feedback_error['frobenius_bound'])/(1-interval(bound))**2)))
    denominator=2*wave**2+3*(Dual(quadrature)+velocity**2+density*(1-cosine))
    denominator0=2*wave**2+3*(Dual(quadrature)+velocity**2+density)
    epsilon=3*density/denominator0
    parameters={name:derivative_bound([[value]],errors) for name,value in (
        ('hubble',hubble),('alpha',wave**2/(omega*hubble)),('mu',omega/hubble),
        ('weight',(density**.5)*hubble/wave),('physical_denominator',denominator),('epsilon',epsilon))}
    return dict(rows=rows,state_box=dict(efold=[start,stop],slow=[-slow_upper,slow_upper],rho=[lower(rho_interval),upper(rho_interval)],
        hubble=[lower(hubble.value),upper(hubble.value)],defect=[lower(defect),upper(defect)]),
        absolute_background_errors=errors,parameter_errors=parameters,sampling_used_to_infer_supremum=False,
        interval_precision_digits=mp.iv.dps,
        scope='uniform background sensitivity of retained heavy metric columns and their closure feedback; external perturbation columns/free generator not included; inherited finite quadrature and saved tube assumed')
