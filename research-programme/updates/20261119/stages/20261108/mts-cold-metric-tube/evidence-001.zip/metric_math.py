import numpy as np
from common import *


def scalar_metric(rho,hubble,velocity,omega,wave,quadrature_external,defect,cosine,sine,branch):
    alpha=wave**2/(omega*hubble)
    ratio=hubble**2/wave**2
    current=[-alpha*sine/2,1-cosine]
    density=[1,0]
    denominator=2*wave**2+3*(quadrature_external+velocity**2+rho*(1-cosine))
    if branch=='gr':
        potential=[-rho/(2*wave**2)*(density[column]+3*ratio*current[column]) for column in range(2)]
        factor=1-3*defect/denominator
        rate=[-potential[column]+rho/(2*wave**2)*factor*current[column] for column in range(2)]
    else:
        require(branch=='poisson-spatial','retained branch')
        pressure=[-cosine,2*sine/alpha]
        potential=[-rho/(2*wave**2)*value for value in density]
        rate=[rho/denominator*(density[column]+3*pressure[column]+current[column]+3*defect*density[column]/(2*wave**2)) for column in range(2)]
    return [potential,rate]


def affine_map(rho,hubble,omega,wave,cosine,sine):
    alpha=wave**2/(omega*hubble)
    mu=omega/hubble
    fraction=rho/(2*hubble**2)
    cosine_difference=[[-3,-3+3*alpha/(4*mu)],[-alpha**2/4,0]]
    sine_difference=[[-alpha/2,0],[(3+fraction)*alpha/2,1.5*alpha-3*alpha**2/(8*mu)]]
    return [[(cosine_difference[row][column]*sine-sine_difference[row][column]*cosine)/(2*mu) for column in range(2)] for row in range(2)]


def denominator_jet(state,hubble,wave,mass_s,quadrature_external,quadrature_rate):
    efold,field,velocity,rho,_=state
    omega=np.exp(efold)*mass_s
    velocity_rate=-2*velocity-omega**2*field/hubble
    denominator0=2*wave**2+3*(quadrature_external+velocity**2+rho)
    denominator0_rate=3*(quadrature_rate+2*velocity*velocity_rate-rho)
    epsilon=3*rho/denominator0
    epsilon_background=epsilon*(-1-denominator0_rate/denominator0)
    epsilon_energy=3*epsilon*(1-epsilon)
    coefficients=np.zeros(8,dtype=complex)
    coefficients[0]=1.
    coefficients[1]=coefficients[-1]=-epsilon/2
    background=np.zeros(8,dtype=complex)
    background[1]=background[-1]=-epsilon_background/2
    energy=np.zeros(8,dtype=complex)
    energy[1]=energy[-1]=-epsilon_energy/2
    return dict(coefficients=coefficients,background=background,energy_cosine=energy,
        denominator0=denominator0,denominator0_rate=denominator0_rate,epsilon=epsilon,
        epsilon_background=epsilon_background,epsilon_energy=epsilon_energy)


def external_constants(fibre,energy,state):
    fibre.install(state,0.)
    scale=np.exp(state[0])
    speeds=fibre.system.context['kinetic'](float(state[4]))[1]
    fluid=energy.fluid_origin*(energy.origin_scale/scale)**np.array([1.,1.,2.,2.])
    massive=np.array(energy.massive_origin)*(energy.origin_scale/scale)**2*energy.speeds_origin/speeds
    quadrature=float(fluid[0]+fluid[1]+4/3*(fluid[2]+fluid[3]+massive.sum()))
    derivative=float(-fluid[0]-fluid[1]-8/3*(fluid[2]+fluid[3])-4/3*np.sum((1+speeds**2)*massive))
    native=fibre.system.context['observe'](float(state[4]),fibre.system.zero_native)
    native_enthalpy=float(native[0]+native[1]-state[2]**2)
    return dict(quadrature=quadrature,quadrature_rate=derivative,defect=quadrature-native_enthalpy,
        native_enthalpy=native_enthalpy,hubble=float(fibre.current[12]),fluid=fluid.tolist(),massive=massive.tolist(),speeds=speeds.tolist())
