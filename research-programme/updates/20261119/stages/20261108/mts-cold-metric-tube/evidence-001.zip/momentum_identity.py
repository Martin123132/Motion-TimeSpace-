from common import *
import numpy as np
import sympy as sp
from mean_math import relative_error


def symbolic_full():
    hubble,wave,quad,defect,defect_rate,eta,density,current,pressure,shear,baryon,root_c,gauge=sp.symbols('H k Wq defect defectN eta D Q P S Pb rootC gauge',nonzero=True)
    extra=gauge*(3*hubble*(eta*defect+defect_rate)/(root_c*wave)-wave*defect/(root_c*hubble))+3*baryon
    free_density=-density-3*pressure-wave*current/hubble+extra
    free_current=-2*current+wave/hubble*(pressure-sp.Rational(2,3)*shear)-gauge*(defect_rate+defect)/root_c
    potential=-density/(2*wave**2)-3*hubble*current/(2*wave**3)-shear/wave**2
    denominator=2*wave**2+3*quad
    actual=-(free_density+3*(eta*hubble*current+hubble*free_current)/wave+3*quad*potential)/denominator
    expected=-potential+(1-3*defect/denominator)*(current+gauge*defect/root_c)/(2*wave*hubble)-3*baryon/denominator
    residual=sp.factor((actual-expected).subs(eta,1-(quad-defect)/(2*hubble**2)))
    require(residual==0,'full retained momentum constraint with native quadrature and baryon pressure corrections')
    return str(residual)


def full_check(system,energy,point):
    old=point['adapted']['old']
    hubble=old['hubble']
    wave=system.wave
    defect=old['defect']
    denominator=old['denominator']
    density=point['physical']['density_weights']
    current=point['adapted']['rows']['current']@point['inverse_rotation']
    baryon=point['physical']['native_pressure']*np.sqrt(density[1])*hubble/wave@point['inverse_rotation']
    correction=np.zeros(energy.size)
    correction[system.alpha_slot]=defect/np.sqrt(density[0])
    factor=1-3*defect/denominator
    expected=-point['metrics']['gr'][0]+factor*(current+correction)/(2*wave*hubble)-3*baryon/denominator
    actual=point['metrics']['gr'][1]
    error=relative_error(actual,expected)
    require(error<GATE,'full native momentum row identity')
    naive=-point['metrics']['gr'][0]+current/(2*wave*hubble)
    return dict(error=error,absolute_error=float(np.max(abs(actual-expected))),
        naive_constraint_residual=float(np.max(abs(actual-naive))),
        baryon_pressure_residual=float(np.max(abs(3*baryon/denominator))),
        quadrature_residual=float(np.max(abs((factor*(current+correction)-current)/(2*wave*hubble)))),
        factor=factor,defect=float(defect),source_row_norm=float(np.linalg.norm(actual)))
