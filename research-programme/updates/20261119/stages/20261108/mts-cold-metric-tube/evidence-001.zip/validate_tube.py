from common import *
from cold_access import SavedBackground
import mpmath as mp
import itertools
import numpy as np


mp.mp.dps=70


def source_external(background,constants,efold):
    scale=mp.exp(efold)
    parameters=background.thermal.parameters
    cold=(mp.mpf(parameters['cdm'])+mp.mpf(parameters['baryon']))/scale
    radiation=(mp.mpf(parameters['photon'])+mp.mpf(parameters['massless']))/scale**2
    density=cold+radiation
    massive_enthalpy=mp.mpf(0)
    for mass,coefficient in zip(parameters['masses'],parameters['coefficients']):
        for node,weight in zip(background.thermal.nodes,background.thermal.weights):
            energy=mp.sqrt(mp.mpf(float(node))**2+(mp.mpf(mass)*scale)**2)
            speed2=(mp.mpf(float(node))/energy)**2
            amount=mp.mpf(coefficient)/scale**2*energy*mp.mpf(float(weight))
            density+=amount
            massive_enthalpy+=amount*(1+speed2/3)
    ratio=mp.mpf(constants['origin_scale'])/scale
    fluid=[mp.mpf(value)*ratio**power for value,power in zip(constants['fluid_origin'],(1,1,2,2))]
    massive=[]
    for amount,speed in zip(constants['massive_origin'],constants['speeds_origin']):
        velocity=1/mp.sqrt(1+(1/mp.mpf(speed)**2-1)/ratio**2)
        massive.append(mp.mpf(amount)*ratio**2*mp.mpf(speed)/velocity)
    quantum=mp.mpf(4)/3*sum(massive)
    quadrature=fluid[0]+fluid[1]+mp.mpf(4)/3*(fluid[2]+fluid[3])+quantum
    return density,quadrature,quantum-massive_enthalpy


def direct(values,external,omega,wave,theta):
    coordinate,velocity,rho=values
    hubble=mp.sqrt((external[0]+(coordinate**2+velocity**2)/2+rho)/3)
    cosine,sine=mp.cos(2*theta),mp.sin(2*theta)
    alpha,mu=wave**2/(omega*hubble),omega/hubble
    fraction=rho/(2*hubble**2)
    density=rho*mp.matrix([[1,0]])
    pressure=rho*mp.matrix([[-cosine,2*sine/alpha]])
    current=rho*hubble/wave*mp.matrix([[-alpha*sine/2,1-cosine]])
    quadrature=external[1]+velocity**2+rho*(1-cosine)
    denominator=2*wave**2+3*quadrature
    defect=external[2]
    eta=1-(quadrature-defect)/(2*hubble**2)
    free_density=-density-3*pressure-wave*current/hubble
    free_current=-2*current+wave*pressure/hubble
    cosine_matrix=mp.matrix([[0,1],[alpha**2/4,-3-fraction]])
    sine_matrix=mp.matrix([[alpha/2,-6/alpha],[0,-alpha/2]])
    forcing_mean=mp.matrix([[0,3],[alpha*mu,0]])
    forcing_cosine=mp.matrix([[0,-3],[0,0]])
    forcing_sine=mp.matrix([[0,0],[0,3*alpha/2]])
    affine=((forcing_cosine+sine_matrix*forcing_mean/(2*mu))*sine-(forcing_sine-cosine_matrix*forcing_mean/(2*mu))*cosine)/(2*mu)
    matrices=[]
    for branch in ('gr','poisson-spatial'):
        if branch=='gr':
            potential=-density/(2*wave**2)-3*hubble*current/(2*wave**3)
            rate=-(free_density+3*(eta*hubble*current+hubble*free_current)/wave+3*quadrature*potential)/denominator
        else:
            potential=-density/(2*wave**2)
            rate=-(free_density+3*defect*potential)/denominator
        metric=mp.matrix([list(potential),list(rate)])
        weight=mp.sqrt(rho)*hubble/wave
        feedback=affine*metric
        matrices.append(dict(relative_metric=metric,physical_metric=metric/weight,feedback=feedback,closed_inverse=(mp.eye(2)-feedback)**-1))
    parameters=dict(hubble=hubble,alpha=alpha,mu=mu,weight=weight,physical_denominator=denominator,
        epsilon=3*rho/(2*wave**2+3*(external[1]+velocity**2+rho)))
    return matrices,parameters


def norm(matrix):
    return mp.sqrt(sum(abs(value)**2 for value in matrix))


def main():
    modest()
    output=STAGE/'tube-validation'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    frozen={str(STAGE/label/'metric-02/result.json'):digest(STAGE/label/'metric-02/result.json') for label in ('half','balanced','double')}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),bounds_frozen_before_fixtures=frozen,
        precision_digits=70,angles=[.311,.991,1.913,2.901],fixture='local inherited slow-ball surface signs and asymmetric heavy-density tube; no evolution or fitted prediction'))
    reports=[]
    background=SavedBackground('heavy')
    for label in ('half','balanced','double'):
        root=STAGE/label/'metric-02'
        report=read(root/'result.json')
        require(report['passed'],'accepted interval derivation')
        constants=read(root/'heavy-constants.json')
        bounds=report['interval']
        for index in range(3):
            packet=load(ANALYTIC/label/'analytic-01'/f'heavy-{index}.npz')
            state=packet['state']
            efold=mp.mpf(float(state[0]))
            external=source_external(background,constants,efold)
            omega=mp.exp(efold)*mp.mpf(background.masses[1])
            wave=mp.mpf(float(packet['wave']))
            values=[mp.exp(efold)*mp.mpf(background.masses[0])*mp.mpf(float(state[1])),mp.mpf(float(state[2])),mp.mpf(float(state[3]))]
            local=background.mean([float(state[0])])
            radius=mp.mpf(float(local['radius'][0]))
            width=mp.mpf(float(local['width'][0]))
            maxima={}
            count=0
            for angle in (.311,.991,1.913,2.901):
                before,parameters_before=direct(values,external,omega,wave,mp.mpf(angle))
                for signs in itertools.product((-1,1),repeat=3):
                    shifted=[values[0]+signs[0]*radius/mp.sqrt(2),values[1]+signs[1]*radius/mp.sqrt(2),values[2]*mp.exp(signs[2]*width)]
                    after,parameters_after=direct(shifted,external,omega,wave,mp.mpf(angle))
                    for branch in range(2):
                        row=bounds['rows'][branch]
                        for field in ('relative_metric','physical_metric','feedback','closed_inverse'):
                            difference=norm(after[branch][field]-before[branch][field])
                            limit=row['closed_inverse_difference'] if field=='closed_inverse' else row[field]['frobenius_bound']
                            require(difference<=mp.mpf(limit),'independent70-digit fixture inside interval derivative bound')
                            key=f'{row["branch"]}_{field}'
                            maxima[key]=max(maxima.get(key,0.),float(difference/mp.mpf(limit)))
                    for name in parameters_before:
                        difference=abs(parameters_after[name]-parameters_before[name])
                        limit=bounds['parameter_errors'][name]['frobenius_bound']
                        require(difference<=mp.mpf(limit),'parameter sensitivity enclosure')
                        maxima[name]=max(maxima.get(name,0.),float(difference/mp.mpf(limit)))
                    count+=1
            reports.append(dict(label=label,index=index,fixtures=count,maximum_bound_ratios=maxima))
            print(label,index,'fixtures',count,'maximum bound ratio',max(maxima.values()),flush=True)
    require(all(digest(path)==value for path,value in frozen.items()),'bounds never adjusted to fixtures')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),frozen_bounds=frozen,reports=reports,
        precision_digits=70,scope='independent high-precision checks of analytic interval enclosures, not sample-based proof'))


if __name__=='__main__':
    main()
