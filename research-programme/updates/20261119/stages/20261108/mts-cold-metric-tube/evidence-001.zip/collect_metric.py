from common import *
import numpy as np
import sympy as sp
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from analytic_math import operator
from metric_math import scalar_metric,affine_map,denominator_jet,external_constants
from interval_math import enclosure
from mean_math import relative_error


def identities():
    rho,hubble,wave,alpha,eta,quad,defect,cosine,sine=sp.symbols('rho H k alpha eta Wq defect c s',nonzero=True)
    vector=sp.Matrix([1,0])
    reduced_current=sp.Matrix([-alpha*sine/2,1-cosine])
    pressure=rho*sp.Matrix([-cosine,2*sine/alpha])
    current=rho*hubble/wave*reduced_current
    density=rho*vector
    free_density=-density-3*pressure-wave/hubble*current
    free_current=-2*current+wave/hubble*pressure
    potential=-density/(2*wave**2)-3*hubble*current/(2*wave**3)
    denominator=2*wave**2+3*quad
    actual=-(free_density+3*(eta*hubble*current+hubble*free_current)/wave+3*quad*potential)/denominator
    expected=-potential+rho/(2*wave**2)*(1-3*defect/denominator)*reduced_current
    substituted=(actual-expected).subs(eta,1-(quad-defect)/(2*hubble**2))
    checks={f'gr_momentum_identity_{index}':sp.factor(value) for index,value in enumerate(substituted)}
    for index,value in enumerate(free_density+3*hubble*free_current/wave+density+(wave/hubble+6*hubble/wave)*current):
        checks[f'pressure_cancellation_{index}']=sp.factor(value)
    epsilon,denominator0,direction=sp.symbols('epsilon D direction',nonzero=True)
    expression=3*rho/denominator0
    energy=sp.diff(expression,rho)*3*rho+sp.diff(expression,denominator0)*9*rho
    checks['energy_direction_denominator']=sp.factor((energy-3*epsilon*(1-epsilon)).subs(epsilon,expression))
    background=sp.diff(expression,rho)*(-rho)+sp.diff(expression,denominator0)*direction
    checks['background_direction_denominator']=sp.factor((background-epsilon*(-1-direction/denominator0)).subs(epsilon,expression))
    require(all(value==0 for value in checks.values()),'exact conservation/denominator identities')
    return {name:str(value) for name,value in checks.items()}


def main():
    modest()
    output=ROOT/'metric-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    exact=identities()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),checks=exact,angles=[.239,1.157,2.613],
        gate=GATE,algebra=ALGEBRA,interval_precision=50,purpose='same full coupled model; selected heavy source columns are not a separate evolution'))
    reports=[]
    interval_result=None
    for model in ('heavy','cold'):
        system=open_owned(model,'metric-01/contexts')
        energy=PhysicalEnergyMap(system)
        with MatchedColdFibre(system) as fibre:
            constants=dict(origin_scale=float(energy.origin_scale),fluid_origin=energy.fluid_origin.tolist(),
                speeds_origin=energy.speeds_origin.tolist(),massive_origin=list(energy.massive_origin),masses=list(fibre.masses))
            write(output/(model+'-constants.json'),constants)
            for index in range(3):
                source=ANALYTIC/LABEL/'analytic-01'/f'{model}-{index}.npz'
                packet=load(source)
                state=packet['state']
                external=external_constants(fibre,energy,state)
                jet=denominator_jet(state,external['hubble'],system.wave,fibre.masses[0],external['quadrature'],external['quadrature_rate'])
                if model=='cold':
                    require(jet['epsilon']==0 and np.max(abs(jet['background']))==0 and np.max(abs(jet['energy_cosine']))==0,'baseline exact zero heavy phase')
                    records=[]
                    for angle in (0.,.239,1.157,2.613):
                        fibre.install(state,angle)
                        point=point_map(system,energy,float(state[0]))
                        records.append(float(point['adapted']['old']['denominator']))
                    require(max(records)==min(records),'baseline denominator phase independent')
                    require(abs(records[0]/jet['denominator0']-1)<ALGEBRA,'baseline total denominator')
                    reports.append(dict(model=model,index=index,baseline_phase_error=0.,external=external))
                    continue
                repaired={name:value.copy() for name,value in packet.items()}
                repaired['denominator']=jet['coefficients']
                for name,key in (('background','background'),('energy_cosine','energy_cosine')):
                    for accuracy in ('coarse','fine'):
                        repaired[f'{name}_denominator_{accuracy}']=jet[key]
                path=output/f'heavy-{index}-repaired.npz'
                np.savez_compressed(path,**repaired)
                predicted=[]
                for angle in (.239,1.157,2.613):
                    predicted.append(np.array([scalar_metric(state[3],external['hubble'],state[2],np.exp(state[0])*fibre.masses[1],system.wave,
                        external['quadrature'],external['defect'],np.cos(2*angle),np.sin(2*angle),branch) for branch in ('gr','poisson-spatial')]))
                np.savez_compressed(output/f'heavy-{index}-frozen.npz',metric=np.array(predicted),angles=[.239,1.157,2.613])
                write(output/f'heavy-{index}-freeze.json',dict(repaired_sha256=digest(path),source_sha256=digest(source),
                    prediction_sha256=digest(output/f'heavy-{index}-frozen.npz'),sources=sources()))
                metric_checks=[]
                for number,angle in enumerate((.239,1.157,2.613)):
                    fibre.install(state,angle)
                    point=point_map(system,energy,float(state[0]))
                    for branch,name in enumerate(('gr','poisson-spatial')):
                        actual=point['metrics'][name][:,energy.heavy]
                        error=relative_error(actual,predicted[number][branch])
                        require(error<GATE,'independent native metric column identity')
                        metric_checks.append(dict(theta=angle,branch=name,error=error))
                    affine=np.array(affine_map(state[3],external['hubble'],np.exp(state[0])*fibre.masses[1],system.wave,np.cos(2*angle),np.sin(2*angle)))
                    require(relative_error(affine,point['item']['affine'])<ALGEBRA,'affine source retained')
                changed=[]
                for angle in np.arange(256)*np.pi/256:
                    changed.append(operator(repaired,angle)-operator(packet,angle))
                maximum_change=float(np.max(abs(changed)))
                require(maximum_change<GATE,'exact denominator repair preserves qualified generator')
                jet_errors={}
                for name,key in (('background','background'),('energy_cosine','energy_cosine')):
                    for accuracy in ('coarse','fine'):
                        before=packet[f'{name}_denominator_{accuracy}']
                        jet_errors[f'{name}_{accuracy}']=relative_error(before,jet[key])
                        require(jet_errors[f'{name}_{accuracy}']<GATE,'saved denominator jet versus analytic law')
                reports.append(dict(model=model,index=index,external=external,jet_scalars={name:value for name,value in jet.items() if not isinstance(value,np.ndarray)},
                    metric_checks=metric_checks,maximum_generator_change=maximum_change,old_jet_errors=jet_errors,
                    repaired_sha256=digest(path)))
                print(LABEL,model,index,'metric error',max(row['error'] for row in metric_checks),'change',maximum_change,flush=True)
            if model=='heavy':
                prior=read(RELATIVE/'cold-transfer-01/result.json')
                replacement=next(row for row in prior['reports'] if row['model']=='heavy' and row['label']==LABEL)['background_replacement']
                inverse=next(row for row in read(ANALYTIC/'audit/result.json')['uniform_tube'] if row['label']==LABEL)
                feedback={row['branch']:row['metric_feedback_bound'] for row in inverse['rows']}
                start=float(np.log(fibre.saved.target['scale_start']))
                stop=float(fibre.saved.saved['efold'][-1])
                interval_result=enclosure(fibre.saved,constants,replacement,start,stop,system.wave,feedback)
                interval_result['replacement_source_sha256']=digest(RELATIVE/'cold-transfer-01/result.json')
                interval_result['replacement']=replacement
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),identities=exact,reports=reports,
        interval=interval_result,full_generator_background_bound=False,full_history_transport=False))
    print(json.dumps(dict(passed=True,interval=interval_result),indent=2),flush=True)


if __name__=='__main__':
    main()
