from common import *
from full_metric_math import rows
from free_math_v2 import build,dense
from source_laws import metric_arguments
from tangent import Tangent
import numpy as np


def split(matrix):
    value=np.array([[float(item.value if isinstance(item,Tangent) else item) for item in row] for row in matrix])
    rate=np.array([[float(item.rate if isinstance(item,Tangent) else 0) for item in row] for row in matrix])
    return value,rate


def evaluate(layout,source,masses,wave,values,thermal,theta,mode='total'):
    cosine,sine=np.cos(2*theta),np.sin(2*theta)
    fields,tangents=metric_arguments(source,masses,wave,values,thermal,cosine,sine,mode)
    clock=tangents.pop('clock')
    result=rows(layout,**fields,**tangents)
    free_source=dict(fluid=source['fluid'],massive=source['massive'],speeds=source['speeds'],density=source['density'],enthalpy=source['enthalpy'],scale=source['scale'])
    free=build(layout,free_source,thermal['sound']['value'],thermal['opacity']['value'],masses,wave,*values,cosine,sine)
    base=dense(free['free'],layout['size'])
    injection=dense(free['injection'],layout['size'],2)
    branches={}
    for name in ('gr','poisson-spatial'):
        metric,metric_rate=split(result['physical'][name])
        relative,relative_rate=split(result['metrics'][name])
        forward,forward_rate=split(result['maps'][name]['forward_correction'])
        inverse,inverse_rate=split(result['maps'][name]['inverse_correction'])
        unclosed=base+injection@metric
        closed=unclosed.copy()
        heavy=layout['heavy']
        if heavy:
            closed+=unclosed[:,heavy]@forward
            closed[heavy]+=inverse@closed+inverse_rate+inverse_rate[:,heavy]@forward
        branches[name]=dict(metric=metric,metric_rate=metric_rate,relative_metric=relative,relative_rate=relative_rate,
            forward=forward,forward_rate=forward_rate,inverse=inverse,inverse_rate=inverse_rate,closed=closed)
    return dict(branches=branches,free=base,injection=injection,hubble=float(result['hubble'].value),
        hubble_rate=float(result['hubble'].rate),denominator=float(result['denominator'].value),denominator_rate=float(result['denominator'].rate))
