from common import *
import mpmath as mp


def main():
    modest()
    candidate=mp.matrix(2,2,lambda row,column:7)
    explicit=mp.matrix([[7,7],[7,7]])
    output=STAGE/'validation-diagnosis.json'
    write(output,dict(constructor_candidate=candidate.tolist(),explicit=explicit.tolist(),
        constructor_ignores_callback=mp.norm(candidate)==0,physics_sources_changed=False))
    print('mp.matrix dimensions-plus-callback result:',candidate,flush=True)


if __name__=='__main__':
    main()
