from common import *
import mpmath as mp


def main():
    modest()
    candidate=mp.matrix(2,2,lambda row,column:7)
    explicit=mp.matrix([[7,7],[7,7]])
    write(STAGE/'validation-diagnosis-v2.json',dict(candidate=[[float(value) for value in row] for row in candidate.tolist()],
        explicit=[[float(value) for value in row] for row in explicit.tolist()],constructor_ignores_callback=mp.norm(candidate)==0,
        previous_diagnosis_failure='mpf values not JSON serializable; partial receipt preserved',physics_sources_changed=False))
    print('mp.matrix dimensions-plus-callback result:',candidate,flush=True)


if __name__=='__main__':
    main()
