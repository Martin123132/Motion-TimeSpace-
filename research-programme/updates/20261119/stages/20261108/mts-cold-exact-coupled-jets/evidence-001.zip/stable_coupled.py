from common import *
from source_laws import metric_arguments
from full_metric_math import rows
from metric_math import affine_map
from relative_math import coefficients
from coupled_jets import split
from tangent import Tangent
import numpy as np


def assemble(layout,source,masses,wave,values,thermal,theta,derived):
    heavy=layout['heavy']
    if not heavy:
        return {branch:item['closed'].copy() for branch,item in derived['branches'].items()}
    cosine,sine=np.cos(2*theta),np.sin(2*theta)
    fields,tangents=metric_arguments(source,masses,wave,values,thermal,cosine,sine)
    tangents.pop('clock')
    metric=rows(layout,**fields,**tangents)
    hubble=metric['hubble']
    density=tangents['rho']
    omega=fields['scale_factor']*masses[1]
    affine=affine_map(density,hubble,omega,wave,tangents['cosine'],tangents['sine'])
    weight=density**.5*hubble/wave
    value,rate=split([[weight*entry for entry in row] for row in affine])
    alpha=wave**2/(float(omega.value)*float(hubble.value))
    mu=float(omega.value)/float(hubble.value)
    fraction=values[2]/(2*float(hubble.value)**2)
    eta0=1-(source['enthalpy']+values[1]**2+values[2])/(2*float(hubble.value)**2)
    gamma=eta0-.5+(1.5+fraction)*cosine
    canonical=coefficients(alpha,mu,eta0,fraction,theta)
    averaged_free=derived['free'].copy()
    averaged_free[np.ix_(heavy,heavy)]=canonical['transformed']+gamma*np.eye(2)
    physical_affine=np.zeros((layout['size'],2))
    physical_affine_rate=np.zeros_like(physical_affine)
    physical_affine[heavy]=value
    physical_affine_rate[heavy]=rate
    force=derived['injection']
    free=derived['free']
    answers={}
    for branch,item in derived['branches'].items():
        metric_row,metric_rate=item['metric'],item['metric_rate']
        correction=(free@physical_affine-physical_affine_rate+force)@metric_row
        correction-=physical_affine@(metric_rate+metric_row@free+(metric_row@force)@metric_row)
        correction[heavy]=canonical['inverse']@correction[heavy]
        correction+=correction[:,heavy]@item['forward']
        answers[branch]=averaged_free+correction
    return answers
