from common import *
from tangent import Tangent
import numpy as np
import mpmath as mp


def exterior(background,constants,efold,cast=float,exp=np.exp):
    scale=exp(efold)
    parameters=background.thermal.parameters
    cold=(cast(parameters['cdm'])+cast(parameters['baryon']))/scale
    radiation=(cast(parameters['photon'])+cast(parameters['massless']))/scale**2
    density=cold+radiation
    density_first=-cold-2*radiation
    enthalpy=cold+cast(4)/3*radiation
    enthalpy_first=-cold-cast(8)/3*radiation
    enthalpy_second=cold+cast(16)/3*radiation
    massive_enthalpy=cast(0)
    massive_first=cast(0)
    massive_second=cast(0)
    for mass,coefficient in zip(parameters['masses'],parameters['coefficients']):
        for node,weight in zip(background.thermal.nodes,background.thermal.weights):
            energy=(cast(float(node))**2+(cast(mass)*scale)**2)**cast(.5)
            speed2=(cast(float(node))/energy)**2
            amount=cast(coefficient)/scale**2*energy*cast(float(weight))
            density+=amount
            density_first-=amount*(1+speed2)
            massive_enthalpy+=amount*(1+speed2/3)
            massive_first-=amount*(1+2*speed2-speed2**2/3)
            massive_second+=amount*(1+7*speed2-cast(11)/3*speed2**2+speed2**3)
    enthalpy+=massive_enthalpy
    enthalpy_first+=massive_first
    enthalpy_second+=massive_second
    origin=cast(constants['origin_scale'])
    ratio=origin/scale
    powers=(1,1,2,2)
    fluid=[cast(value)*ratio**power for value,power in zip(constants['fluid_origin'],powers)]
    fluid_first=[-power*amount for power,amount in zip(powers,fluid)]
    speeds=[1/(1+(1/cast(speed)**2-1)/ratio**2)**cast(.5) for speed in constants['speeds_origin']]
    speeds_first=[-speed*(1-speed**2) for speed in speeds]
    massive=[cast(amount)*ratio**2*cast(speed)/current for amount,speed,current in zip(constants['massive_origin'],constants['speeds_origin'],speeds)]
    massive_rates=[-(1+speed**2)*amount for amount,speed in zip(massive,speeds)]
    quantum=cast(4)/3*sum(massive)
    quantum_first=cast(4)/3*sum(massive_rates)
    quantum_second=cast(4)/3*sum(amount*(1+4*speed**2-speed**4) for amount,speed in zip(massive,speeds))
    difference_cold=((cast(constants['fluid_origin'][0])+cast(constants['fluid_origin'][1]))*origin-(cast(parameters['cdm'])+cast(parameters['baryon'])))/scale
    difference_radiation=((cast(constants['fluid_origin'][2])+cast(constants['fluid_origin'][3]))*origin**2-(cast(parameters['photon'])+cast(parameters['massless'])))/scale**2
    defect=difference_cold+cast(4)/3*difference_radiation+quantum-massive_enthalpy
    defect_first=-difference_cold-cast(8)/3*difference_radiation+quantum_first-massive_first
    defect_second=difference_cold+cast(16)/3*difference_radiation+quantum_second-massive_second
    return dict(scale=scale,fluid=fluid,fluid_first=fluid_first,massive=massive,massive_first=massive_rates,
        speeds=speeds,speeds_first=speeds_first,density=density,density_first=density_first,
        enthalpy=enthalpy,enthalpy_first=enthalpy_first,enthalpy_second=enthalpy_second,
        defect=defect,defect_first=defect_first,defect_second=defect_second)


def point_thermal(table,table_time):
    from thermal_jets import evaluate
    initial,step=(mp.mpf(float(value)) for value in table['metadata'])
    coordinate=mp.log(mp.mpf(float(table_time))/initial)/step
    index=int(mp.floor(coordinate))
    require(0<=index<table['values'].shape[1]-1,'owned thermal interior')
    return evaluate(table,index,coordinate-index),index,coordinate-index


def metric_arguments(source,masses,wave,values,thermal,cosine,sine,mode='total'):
    coordinate,velocity,rho,clock=values
    zero=coordinate*0
    hubble=((source['density']+(coordinate**2+velocity**2)/2+rho)/3)**.5
    omega=source['scale']*masses[0]
    mu=source['scale']*masses[1]/hubble
    factor=0 if mode=='phase' else 1
    phase_rate=zero if mode=='slow' else mu-1.5*sine
    tangents=dict(coordinate=Tangent(coordinate,factor*(coordinate+omega*velocity/hubble)),
        velocity=Tangent(velocity,factor*(-2*velocity-omega*coordinate/hubble)),
        rho=Tangent(rho,factor*(-1+3*cosine)*rho),clock=Tangent(clock,factor/hubble),
        cosine=Tangent(cosine,-2*sine*phase_rate),sine=Tangent(sine,2*cosine*phase_rate))
    fields={name:[Tangent(value,factor*rate) for value,rate in zip(source[name],source[name+'_first'])] for name in ('fluid','massive','speeds')}
    fields.update(external_density=Tangent(source['density'],factor*source['density_first']),
        external_enthalpy=Tangent(source['enthalpy'],factor*source['enthalpy_first']),
        defect=Tangent(source['defect'],factor*source['defect_first']),defect_rate=Tangent(source['defect_first'],factor*source['defect_second']),
        sound=Tangent(thermal['sound']['value'],factor*thermal['sound']['first']),
        scale_factor=Tangent(source['scale'],factor*source['scale']),masses=masses,wave=wave)
    return fields,tangents
