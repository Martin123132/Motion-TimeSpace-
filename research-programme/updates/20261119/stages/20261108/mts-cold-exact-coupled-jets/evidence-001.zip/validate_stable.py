from common import *
from coupled_jets import evaluate
from stable_coupled import assemble
from cold_access import SavedBackground
from mean_math import relative_error
import numpy as np


def main():
    modest()
    output=STAGE/'stable-validation'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    frozen={str(STAGE/label/'jets-01/result.json'):digest(STAGE/label/'jets-01/result.json') for label in ('half','balanced','double')}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),frozen=frozen,angles=[.239,1.157,2.613],gate=GATE,algebra=ALGEBRA))
    reports=[]
    for label in ('half','balanced','double'):
        wave=dict(read(WAVES)['waves'])[label]
        for model in ('heavy','cold'):
            masses=SavedBackground(model).masses
            for index in range(3):
                guard()
                record=read(STAGE/label/'jets-01'/f'{model}-{index}-freeze.json')
                saved=load(STAGE/label/'jets-01'/f'{model}-{index}-frozen.npz')
                layout,source,values,thermal=(record[name] for name in ('layout','source','values','thermal'))
                for angle_index,theta in enumerate((.239,1.157,2.613)):
                    derived=evaluate(layout,source,masses,wave,values,thermal,theta)
                    stable=assemble(layout,source,masses,wave,values,thermal,theta,derived)
                    for branch_index,branch in enumerate(('gr','poisson-spatial')):
                        direct=derived['branches'][branch]['closed']
                        require(np.array_equal(direct,saved['closed'][angle_index,branch_index]),'exact reproducibility of saved direct generator')
                        relative=relative_error(stable[branch],direct)
                        absolute=float(np.max(abs(stable[branch]-direct)))
                        require(relative<ALGEBRA and absolute<GATE,'factored cancellation equals direct coordinate pullback')
                        item=derived['branches'][branch]
                        heavy=layout['heavy']
                        map_error=0.
                        if heavy:
                            inverse=item['inverse']
                            forward=item['forward']
                            identity_residual=inverse+forward+inverse[:,heavy]@forward
                            map_error=float(np.max(abs(identity_residual)))
                            require(map_error<ALGEBRA,'physical inverse/forward map identity')
                        reports.append(dict(label=label,model=model,index=index,theta=theta,branch=branch,relative=relative,absolute=absolute,map_error=map_error))
                print(label,model,index,'stable cancellation passed',flush=True)
    require(all(digest(path)==value for path,value in frozen.items()),'saved predictions unchanged')
    write(output/'result.json',dict(passed=True,reports=reports,inputs=inputs,sources=sources(),frozen=frozen,scope='pointwise algebraic factorization; independent high precision follows'))


if __name__=='__main__':
    main()
