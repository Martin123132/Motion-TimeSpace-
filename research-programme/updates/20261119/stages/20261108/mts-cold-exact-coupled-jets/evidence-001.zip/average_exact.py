from common import *
from cold_access import SavedBackground
from coupled_jets import evaluate
from stable_coupled import assemble
from mean_math import phase_primitive,relative_error
import numpy as np


def main():
    modest()
    require(LABEL!='summary','one retained wave family')
    output=ROOT/'average-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    precision_path=STAGE/'independent-validation-02/result.json'
    require(read(precision_path)['passed'],'independent high-precision checks before phase averaging')
    frozen={str(precision_path):digest(precision_path)}
    for name in ('heavy-1-frozen.npz','cold-1.npz'):
        path=ANALYTIC/LABEL/'analytic-01'/name
        frozen[str(path)]=digest(path)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),frozen=frozen,phase_count=256,
        angles='theta_j=pi*j/256',gate=GATE,algebra=ALGEBRA,prediction='same saved midpoint and time-weighted phase mean; exact source derivatives and factored cancellation'))
    reports=[]
    for model in ('heavy','cold'):
        record=read(ROOT/'jets-01'/f'{model}-1-freeze.json')
        layout,source,values,thermal=(record[name] for name in ('layout','source','values','thermal'))
        masses=SavedBackground(model).masses
        if model=='cold':
            matrices=[]
            for theta in (.239,1.157,2.613):
                candidate=evaluate(layout,source,masses,WAVE,values,thermal,theta)
                matrices.append(np.array([candidate['branches'][branch]['closed'] for branch in ('gr','poisson-spatial')]))
            require(all(np.array_equal(matrices[0],value) for value in matrices[1:]),'baseline exact phase independence')
            original=load(ANALYTIC/LABEL/'analytic-01/cold-1.npz')['matrix']
            error=relative_error(matrices[0],original)
            require(error<GATE,'saved baseline retained')
            np.savez_compressed(output/'cold-control.npz',matrix=matrices[0])
            reports.append(dict(model=model,phase_error=0.,saved_relative=error))
            continue
        angles=np.arange(256)*np.pi/256
        matrices=[]
        algebra=[]
        hubble=((source['density']+(values[0]**2+values[1]**2)/2+values[2])/3)**.5
        mu=source['scale']*masses[1]/hubble
        for index,theta in enumerate(angles):
            if index%32==0:
                guard()
            candidate=evaluate(layout,source,masses,WAVE,values,thermal,theta)
            stable=assemble(layout,source,masses,WAVE,values,thermal,theta,candidate)
            matrix=np.array([stable[branch] for branch in ('gr','poisson-spatial')])
            direct=np.array([candidate['branches'][branch]['closed'] for branch in ('gr','poisson-spatial')])
            error=relative_error(matrix,direct)
            require(error<ALGEBRA,'cancellation identity over original full phase grid')
            algebra.append(error)
            matrices.append(matrix)
        matrices=np.array(matrices)
        angular=mu-1.5*np.sin(2*angles)
        require(np.min(angular)>0,'positive phase clock')
        previous=load(ANALYTIC/LABEL/'analytic-01/heavy-1-frozen.npz')
        operator_error=relative_error(matrices,previous['candidate'])
        require(operator_error<GATE,'saved midpoint generator preserved')
        means=[]
        for branch_index,branch in enumerate(('gr','poisson-spatial')):
            average=phase_primitive(matrices[:,branch_index],angular)
            mean_error=relative_error(average['mean'],previous['means'][branch_index])
            primitive_error=relative_error(average['primitive'],previous['primitives'][branch_index])
            closure=average['closure']/max(float(np.max(abs(average['forcing']))),1e-80)
            reconstruction=relative_error(average['forcing'],average['phase_derivative'])
            require(max(mean_error,primitive_error)<GATE,'saved physical mean and periodic primitive preserved')
            require(max(closure,reconstruction)<ALGEBRA,'unchanged periodic closure and derivative identity')
            target=output/f'heavy-{branch}-average.npz'
            np.savez_compressed(target,**average)
            spectral=float(np.linalg.eigvalsh((average['mean']+average['mean'].T)/2)[-1])
            primitive_size=float(np.max(np.linalg.norm(average['primitive'],axis=(1,2))))
            means.append(dict(branch=branch,mean_relative=mean_error,primitive_relative=primitive_error,
                closure_relative=closure,reconstruction_relative=reconstruction,midpoint_logarithmic_norm=spectral,
                sampled_primitive_frobenius=primitive_size,sha256=digest(target)))
        np.savez_compressed(output/'heavy-phase-bank.npz',angles=angles,matrix=matrices,angular=angular)
        reports.append(dict(model=model,operator_relative=operator_error,maximum_cancellation_relative=max(algebra),means=means))
        print(LABEL,'exact-jet mean/primitive passed',operator_error,[item['primitive_relative'] for item in means],flush=True)
    require(all(digest(path)==value for path,value in frozen.items()),'old reference and independent evidence unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),frozen=frozen,reports=reports,
        phase_grid_unchanged=True,scope='same cold midpoint time-weighted phase mean and periodic primitive; sampled norms are not whole-history bounds'))


if __name__=='__main__':
    main()
