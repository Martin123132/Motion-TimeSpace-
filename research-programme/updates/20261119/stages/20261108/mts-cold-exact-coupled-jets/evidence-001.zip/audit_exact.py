from common import *
from validate_exact_jets_v2 import symbolic


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    sealed={}
    for folder in (FREE,FULL,METRIC,ANALYTIC):
        sealed.update({str(Path(item['path'])):item['sha256'] for item in read(folder/'closeout.json')['artifacts']})
    consumed={}
    paths=[FULL/'build-thermal-readout/native/camb/cambdll.dll',FULL/'build-thermal-readout/build-result.json']
    for label in ('half','balanced','double'):
        parent=FREE/label/('free-01' if label=='half' else 'free-02')
        for model in ('heavy','cold'):
            paths.extend(FULL/label/'full-01'/(model+suffix) for suffix in ('-thermal.npz','-constants.json'))
            for index in range(3):
                paths.extend(parent/f'{model}-{index}{suffix}' for suffix in ('-frozen.npz','-freeze.json'))
                paths.append((METRIC/label/'metric-02'/f'heavy-{index}-repaired.npz') if model=='heavy' else (ANALYTIC/label/'analytic-01'/f'cold-{index}.npz'))
        paths.append(ANALYTIC/label/'analytic-01/heavy-1-frozen.npz')
    for path in paths:
        require(str(path) in sealed and digest(path)==sealed[str(path)],'sealed consumed source/packet/DLL')
        consumed[str(path)]=sealed[str(path)]
    accepted={}
    def accept(path):
        result=read(path)
        require(result['passed'] and result['inputs']==inputs,'accepted same-source result')
        for source,value in result['sources'].items():
            require(digest(source)==value,'executed source version retained')
        for frozen,value in result.get('frozen',{}).items():
            require(digest(frozen)==value,'frozen reference unchanged')
        accepted[str(path)]=digest(path)
        return result
    counts=dict(native_model_phase_cases=0,native_gravity_branch_cases=0,stable_branch_cases=0,source_derivative_checks=0,
        independent_jet_fixtures=0,independent_value_rate_entries=0,high_precision_generator_method_checks=0,full_grid_cancellation_cases=0)
    maxima={}
    def maximum(name,value):
        maxima[name]=max(maxima.get(name,0.),value)
    averages=[]
    for label in ('half','balanced','double'):
        result=accept(STAGE/label/'jets-01/result.json')
        require(len(result['reports'])==6 and result['finite_difference_jets_used_in_new_generator'] is False,'all saved models/epochs with exact jets')
        for record in result['reports']:
            model,index=record['model'],record['index']
            freeze=read(STAGE/label/'jets-01'/f'{model}-{index}-freeze.json')
            require(freeze['prediction_sha256']==digest(STAGE/label/'jets-01'/f'{model}-{index}-frozen.npz'),'frozen native predictions intact')
            require(len(record['checks'])==3,'three retained test angles')
            for check in record['checks']:
                require(max(check['native_absolute'],check['native_scalar'],check['saved_relative'],check['slow_metric_relative'])<GATE,'native/source gates unchanged')
                require(check['split_relative']<ALGEBRA,'exact directional split gate')
                for name in ('native_absolute','native_relative','native_scalar','saved_relative','slow_metric_relative','split_relative'):
                    maximum(name,check[name])
                counts['native_model_phase_cases']+=1
                counts['native_gravity_branch_cases']+=2
        average=accept(STAGE/label/'average-01/result.json')
        require(average['phase_grid_unchanged'],'original 256-node phase grid')
        heavy=next(row for row in average['reports'] if row['model']=='heavy')
        cold=next(row for row in average['reports'] if row['model']=='cold')
        require(cold['phase_error']==0 and cold['saved_relative']<GATE,'baseline phase control')
        require(heavy['operator_relative']<GATE and heavy['maximum_cancellation_relative']<ALGEBRA,'phase-grid cancellation')
        maximum('averaged_operator_relative',heavy['operator_relative'])
        maximum('phase_grid_cancellation_relative',heavy['maximum_cancellation_relative'])
        for item in heavy['means']:
            require(max(item['mean_relative'],item['primitive_relative'])<GATE,'retained mean/primitive gate')
            require(max(item['closure_relative'],item['reconstruction_relative'])<ALGEBRA,'phase closure gate')
            require(digest(STAGE/label/'average-01'/f'heavy-{item["branch"]}-average.npz')==item['sha256'],'phase result intact')
            for name in ('mean_relative','primitive_relative','closure_relative','reconstruction_relative'):
                maximum(name,item[name])
        counts['full_grid_cancellation_cases']+=256*2
        averages.append(dict(label=label,**heavy))
    stable=accept(STAGE/'stable-validation/result.json')
    require(len(stable['reports'])==108,'all stable branch cases')
    for record in stable['reports']:
        require(record['relative']<ALGEBRA and record['absolute']<GATE and record['map_error']<ALGEBRA,'stable identity and inverse gates')
        maximum('stable_absolute',record['absolute'])
        maximum('stable_relative',record['relative'])
        maximum('inverse_map_identity',record['map_error'])
        counts['stable_branch_cases']+=1
    independent=accept(STAGE/'independent-validation-02/result.json')
    require(independent['precision_digits']==70 and len(independent['reports'])==18,'all independent saved states')
    require(independent['symbolic']==symbolic(),'finite source identities rederived')
    for record in independent['reports']:
        counts['source_derivative_checks']+=record['source']['checks']
        maximum('independent_source_relative',record['source']['relative'])
        for check in record['jets']:
            require(max(check['value'],check['rate'],check['step_refinement'])<1e-28,'independent differentiation arithmetic gate')
            for name in ('value','rate','step_refinement'):
                maximum('independent_'+name+'_relative',check[name])
            counts['independent_jet_fixtures']+=1
            counts['independent_value_rate_entries']+=2*check['entries']
        for check in record['generators']:
            require(check['relative']<ALGEBRA and check['absolute']<GATE,'70-digit generator gate')
            maximum('high_precision_generator_relative',check['relative'])
            maximum('high_precision_generator_absolute',check['absolute'])
            counts['high_precision_generator_method_checks']+=1
    failures=['independent-validation-01','diagnose-validation-01']
    for name in failures:
        receipt=read(STAGE/(name+'.end.json'))
        require(receipt['exit_code']==1 and digest(receipt['source_path'])==receipt['source_sha256'],'exact failed code retained')
    require(read(STAGE/'validation-diagnosis-v2.json')['constructor_ignores_callback'],'identified validation-harness defect')
    require('independent unsimplified metric/map value' in (STAGE/'independent-validation-01.stderr.log').read_text(),'first failure retained')
    require('not JSON serializable' in (STAGE/'diagnose-validation-01.stderr.log').read_text(),'diagnosis serialization failure retained')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no bytecode leftovers')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,maxima=maxima,averages=averages,symbolic=independent['symbolic'],compiler_receipts=[],
        failed_attempts_preserved=failures,gate=GATE,algebra=ALGEBRA,exact_source_jets=True,stable_coupled_identity=True,
        full_closed_generator_derivative_envelope=False,whole_transport_error=False,new_initial_mode=False))
    print(json.dumps(dict(passed=True,counts=counts,maxima=maxima),indent=2),flush=True)


if __name__=='__main__':
    main()
