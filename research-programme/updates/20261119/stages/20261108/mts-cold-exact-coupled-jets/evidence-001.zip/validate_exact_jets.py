from common import *
from cold_access import SavedBackground
from source_laws import exterior,point_thermal,metric_arguments
from full_metric_math import rows
from validate_full_metric_v2 import external,reference,compact
from free_math_v2 import build
from coupled_jets import evaluate
from stable_coupled import assemble
from tangent import Tangent
from mean_math import relative_error
import mpmath as mp
import numpy as np
import sympy as sp


mp.mp.dps=70


def symbolic():
    density,speed=sp.symbols('rho t')
    derivative=lambda expression:sp.diff(expression,density)*(-density*(1+speed))+sp.diff(expression,speed)*(-2*speed*(1-speed))
    enthalpy=density*(1+speed/3)
    checks=dict(density_first=sp.expand(derivative(density)+density*(1+speed))==0,
        density_second=sp.expand(derivative(derivative(density))-density*(1+4*speed-speed**2))==0,
        enthalpy_first=sp.expand(derivative(enthalpy)+density*(1+2*speed-speed**2/3))==0,
        enthalpy_second=sp.expand(derivative(derivative(enthalpy))-density*(1+7*speed-sp.Rational(11,3)*speed**2+speed**3))==0)
    require(all(checks.values()),'exact finite Fermi source identities')
    return checks


def polynomial(table,cell,offset,local):
    values=table['values']
    left,right=(mp.mpf(float(value)) for value in values[offset,cell:cell+2])
    first,last=(mp.mpf(float(value)) for value in values[offset+1,cell:cell+2])
    return (2*local**3-3*local**2+1)*left+(local**3-2*local**2+local)*first+(-2*local**3+3*local**2)*right+(local**3-local**2)*last


def shifted_sound(table,cell,local,increment):
    spacing=mp.mpf(float(table['metadata'][1]))
    scale0=polynomial(table,cell,0,local)
    function=lambda value:(value-local)*spacing+mp.log(polynomial(table,cell,0,value)/scale0)
    shifted=local+increment/mp.diff(function,local)
    for iteration in range(5):
        shifted-=(function(shifted)-increment)/mp.diff(function,shifted)
    require(abs(function(shifted)-increment)<mp.mpf('1e-60'),'independent thermal scale inversion')
    return polynomial(table,cell,2,shifted)


def matrix_parts(matrix):
    return tuple(mp.matrix([[getattr(value,name,0 if name=='rate' else value) for value in row] for row in matrix]) for name in ('value','rate'))


def source_check(background,constants,efold,source):
    checks=0
    maximum=mp.mpf(0)
    for short,long in (('density','external_density'),('enthalpy','external_enthalpy'),('defect','defect')):
        for degree in ((1,) if short=='density' else (1,2)):
            expected=mp.diff(lambda position:external(background,constants,position)[long],efold,degree)
            actual=source[short+('_first' if degree==1 else '_second')]
            relative=abs(actual-expected)/max(abs(expected),mp.mpf('1e-40'))
            require(relative<mp.mpf('1e-45'),'independent finite-quadrature source derivative')
            maximum=max(maximum,relative)
            checks+=1
    return dict(checks=checks,relative=float(maximum))


def derivative_check(layout,background,constants,efold,source,masses,wave,values,table,cell,local,thermal,theta):
    cosine,sine=mp.cos(2*theta),mp.sin(2*theta)
    fields,tangents=metric_arguments(source,masses,wave,values,thermal,cosine,sine)
    rates=[tangents[name].rate for name in ('coordinate','velocity','rho','clock')]
    tangents.pop('clock')
    derived=rows(layout,**fields,**tangents)
    hubble=derived['hubble'].value
    phase_rate=source['scale']*masses[1]/hubble-mp.mpf('1.5')*sine
    predicted={}
    for branch in ('gr','poisson-spatial'):
        predicted[branch]={'physical_metric':matrix_parts(derived['physical'][branch])}
        if layout['heavy']:
            for name in ('forward_correction','inverse_correction'):
                predicted[branch][name]=matrix_parts(derived['maps'][branch][name])
    maxima={'value':mp.mpf(0),'rate':mp.mpf(0),'step_refinement':mp.mpf(0)}
    count=0
    previous={}
    for step in map(mp.mpf,('1e-30','1e-35')):
        increment=mp.j*step
        shifted_values=[value+increment*rate for value,rate in zip(values,rates)]
        shifted_source=external(background,constants,efold+increment)
        sound=shifted_sound(table,cell,local,increment)
        actual=reference(layout,shifted_source,sound,masses,wave,shifted_values[:3],theta+increment*phase_rate)
        for branch,entries in predicted.items():
            for name,(value,rate) in entries.items():
                comparison=actual[branch][name]
                real=mp.matrix(comparison.rows,comparison.cols,lambda row,column:mp.re(comparison[row,column]))
                imaginary=mp.matrix(comparison.rows,comparison.cols,lambda row,column:mp.im(comparison[row,column])/step)
                for kind,target,observed in (('value',value,real),('rate',rate,imaginary)):
                    error=mp.norm(observed-target)/max(mp.norm(target),mp.mpf('1e-30'))
                    require(error<mp.mpf('1e-28'),'independent unsimplified metric/map '+kind)
                    maxima[kind]=max(maxima[kind],error)
                key=(branch,name)
                if key in previous:
                    error=mp.norm(imaginary-previous[key])/max(mp.norm(imaginary),mp.mpf('1e-30'))
                    require(error<mp.mpf('1e-28'),'complex-step refinement')
                    maxima['step_refinement']=max(maxima['step_refinement'],error)
                previous[key]=imaginary
                count+=comparison.rows*comparison.cols
    return dict(entries=count,**{name:float(value) for name,value in maxima.items()})


def generator_check(layout,source,masses,wave,values,thermal,theta):
    fields,tangents=metric_arguments(source,masses,wave,values,thermal,mp.cos(2*theta),mp.sin(2*theta))
    tangents.pop('clock')
    metric=rows(layout,**fields,**tangents)
    free_source={name:source[name] for name in ('fluid','massive','speeds','density','enthalpy','scale')}
    free=build(layout,free_source,thermal['sound']['value'],thermal['opacity']['value'],masses,wave,*values,mp.cos(2*theta),mp.sin(2*theta))
    size=layout['size']
    base=mp.zeros(size,size)
    force=mp.zeros(size,2)
    for (row,column),value in free['free'].items():
        base[row,column]=value
    for (row,column),value in free['injection'].items():
        force[row,column]=value
    float_source={name:[float(item) for item in value] if isinstance(value,list) else float(value) for name,value in source.items()}
    float_thermal={name:{key:float(value) for key,value in entry.items()} for name,entry in thermal.items()}
    float_values=list(map(float,values))
    float_masses=list(map(float,masses))
    derived=evaluate(layout,float_source,float_masses,float(wave),float_values,float_thermal,float(theta))
    stable=assemble(layout,float_source,float_masses,float(wave),float_values,float_thermal,float(theta),derived)
    results=[]
    heavy=layout['heavy']
    for branch in ('gr','poisson-spatial'):
        physical,_=matrix_parts(metric['physical'][branch])
        unclosed=base+force*physical
        closed=unclosed
        if heavy:
            forward,_=matrix_parts(metric['maps'][branch]['forward_correction'])
            inverse,inverse_rate=matrix_parts(metric['maps'][branch]['inverse_correction'])
            selected=mp.matrix([[unclosed[row,column] for column in heavy] for row in range(size)])
            closed=unclosed+selected*forward
            rate_columns=mp.matrix([[inverse_rate[row,column] for column in heavy] for row in range(2)])
            correction=inverse*closed+inverse_rate+rate_columns*forward
            for position,row in enumerate(heavy):
                for column in range(size):
                    closed[row,column]+=correction[position,column]
        reference_array=np.array(closed.tolist(),dtype=float)
        for method,candidate in (('direct',derived['branches'][branch]['closed']),('factored',stable[branch])):
            error=relative_error(candidate,reference_array)
            absolute=float(np.max(abs(candidate-reference_array)))
            require(error<ALGEBRA and absolute<GATE,'70-digit physical generator '+method)
            results.append(dict(branch=branch,method=method,relative=error,absolute=absolute))
    return results


def main():
    modest()
    output=STAGE/'independent-validation'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    require(read(STAGE/'stable-validation/result.json')['passed'],'factored identity qualified')
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),precision_digits=70,angles=[.419,2.287],complex_steps=['1e-30','1e-35'],
        arithmetic_check='1e-28 relative with 1e-30 norm floor; not a physical gate',gate=GATE,algebra=ALGEBRA,
        method='independent unsimplified momentum, direct map inverse, complex source continuation and implicit thermal scale inversion'))
    identities=symbolic()
    reports=[]
    for label in ('half','balanced','double'):
        wave=mp.mpf(dict(read(WAVES)['waves'])[label])
        for model in ('heavy','cold'):
            background=SavedBackground(model)
            masses=list(map(lambda value:mp.mpf(float(value)),background.masses))
            constants=read(FULL/label/f'full-01/{model}-constants.json')
            table=load(FULL/label/f'full-01/{model}-thermal.npz')
            parent=FREE/label/('free-01' if label=='half' else 'free-02')
            for index in range(3):
                guard()
                saved=load(parent/f'{model}-{index}-frozen.npz')
                record=read(STAGE/label/'jets-01'/f'{model}-{index}-freeze.json')
                layout,selected=compact(record['layout'])
                state=list(map(lambda value:mp.mpf(float(value)),saved['state']))
                efold=state[0]
                source=exterior(background,constants,efold,mp.mpf,mp.exp)
                values=[source['scale']*masses[0]*state[1],state[2],state[3],state[4]]
                thermal,cell,local=point_thermal(table,float(saved['thermal'][1]))
                source_report=source_check(background,constants,efold,source)
                jets=[derivative_check(layout,background,constants,efold,source,masses,wave,values,table,cell,local,thermal,mp.mpf(angle)) for angle in ('.419','2.287')]
                generators=generator_check(record['layout'],source,masses,wave,values,thermal,mp.mpf('.419')) if index==1 else []
                report=dict(label=label,model=model,index=index,source=source_report,jets=jets,generators=generators)
                write(output/f'{label}-{model}-{index}.json',report)
                reports.append(report)
                print(label,model,index,'independent exact jets',max(item['rate'] for item in jets),flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),symbolic=identities,reports=reports,
        precision_digits=70,scope='pointwise exact retained-source differentiation and physical coupled generator; no interval enclosure or integration error claim'))


if __name__=='__main__':
    main()
