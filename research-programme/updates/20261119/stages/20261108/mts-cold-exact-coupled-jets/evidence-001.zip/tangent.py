class Tangent:
    def __init__(self,value,rate=0):
        self.value=value
        self.rate=rate

    @staticmethod
    def cast(value):
        return value if isinstance(value,Tangent) else Tangent(value)

    def __add__(self,other):
        other=self.cast(other)
        return Tangent(self.value+other.value,self.rate+other.rate)

    __radd__=__add__

    def __neg__(self):
        return Tangent(-self.value,-self.rate)

    def __sub__(self,other):
        return self+-self.cast(other)

    def __rsub__(self,other):
        return self.cast(other)+-self

    def __mul__(self,other):
        other=self.cast(other)
        return Tangent(self.value*other.value,self.rate*other.value+self.value*other.rate)

    __rmul__=__mul__

    def __truediv__(self,other):
        other=self.cast(other)
        return Tangent(self.value/other.value,(self.rate*other.value-self.value*other.rate)/other.value**2)

    def __rtruediv__(self,other):
        return self.cast(other)/self

    def __pow__(self,power):
        value=self.value**power
        return Tangent(value,power*self.value**(power-1)*self.rate)
