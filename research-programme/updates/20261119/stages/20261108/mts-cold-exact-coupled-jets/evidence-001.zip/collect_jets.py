from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from source_laws import exterior,point_thermal
from coupled_jets import evaluate
from energy_operator import stable_point
from analytic_math import operator,metric,evaluate as fourier_value
from mean_math import relative_error
import numpy as np
import mpmath as mp


mp.mp.dps=70


def parent_free(label):
    return FREE/label/('free-01' if label=='half' else 'free-02')


def old_slow(packet,theta):
    numerator=fourier_value(packet['numerator'],theta)
    denominator=float(fourier_value(packet['denominator'],theta))
    value=numerator/denominator
    answer=np.zeros_like(value)
    for direction,factor in (('background',1.),('energy_cosine',np.cos(2*theta))):
        answer+=factor*(fourier_value(packet[direction+'_numerator_fine'],theta)-value*fourier_value(packet[direction+'_denominator_fine'],theta))/denominator
    return answer


def main():
    modest()
    output=ROOT/'jets-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),angles=[.239,1.157,2.613],gate=GATE,algebra=ALGEBRA,
        prediction='exact source-law differentiation before fresh native checks; no fitted jets'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'jets-01/contexts')
        energy=PhysicalEnergyMap(system)
        background=None
        with MatchedColdFibre(system) as fibre:
            background=fibre.saved
            constants=read(FULL/LABEL/f'full-01/{model}-constants.json')
            table=load(FULL/LABEL/f'full-01/{model}-thermal.npz')
            for index in range(3):
                guard()
                parent=parent_free(LABEL)
                layout=read(parent/f'{model}-{index}-freeze.json')['layout']
                saved=load(parent/f'{model}-{index}-frozen.npz')
                state=saved['state']
                source=exterior(background,constants,float(state[0]))
                source_thermal,cell,local=point_thermal(table,float(saved['thermal'][1]))
                thermal={name:{key:float(value) for key,value in record.items()} for name,record in source_thermal.items()}
                values=[np.exp(state[0])*background.masses[0]*state[1],state[2],state[3],state[4]]
                predictions=[evaluate(layout,source,background.masses,system.wave,values,thermal,theta) for theta in (.239,1.157,2.613)]
                frozen={name:np.array([[item['branches'][branch][name] for branch in ('gr','poisson-spatial')] for item in predictions]) for name in ('metric','metric_rate','relative_metric','relative_rate','forward','forward_rate','inverse','inverse_rate','closed')}
                target=output/f'{model}-{index}-frozen.npz'
                np.savez_compressed(target,**frozen,state=state)
                write(output/f'{model}-{index}-freeze.json',dict(prediction_sha256=digest(target),sources=sources(),thermal=thermal,cell=cell,local=float(local),
                    source=source,layout=layout,values=[float(value) for value in values]))
                if model=='heavy':
                    old=load(METRIC/LABEL/'metric-02'/f'heavy-{index}-repaired.npz')
                else:
                    old=load(ANALYTIC/LABEL/'analytic-01'/f'cold-{index}.npz')
                checks=[]
                for number,theta in enumerate((.239,1.157,2.613)):
                    current=predictions[number]
                    metrics=np.array([current['branches'][branch]['relative_rate'][:,:energy.size] for branch in ('gr','poisson-spatial')])
                    native=stable_point(fibre,energy,state,theta,metrics)
                    diagonal=np.ones(layout['size'])
                    if model=='heavy':
                        diagonal[energy.heavy]=np.sqrt(state[3])*fibre.current[12]/system.wave
                    direct=native['matrix']*diagonal[None,:,None]/diagonal[None,None,:]
                    if model=='heavy':
                        gamma=native['parameters']['eta0']-.5+(1.5+native['parameters']['b'])*np.cos(2*theta)
                        direct[:,energy.heavy,energy.heavy]+=gamma
                    candidate=np.array([current['branches'][branch]['closed'] for branch in ('gr','poisson-spatial')])
                    absolute=float(np.max(abs(candidate-direct)))
                    comparison=relative_error(candidate,direct)
                    require(absolute<GATE,'derived exact-jet closed generator agrees with native source')
                    require(max(native['scalar_residual'])<GATE,'independent native scalar conversion')
                    if model=='heavy':
                        saved_operator=operator(old,theta)
                        old_metric,old_rate=metric(old,theta,'fine')
                        slow=evaluate(layout,source,background.masses,system.wave,values,thermal,theta,'slow')
                        phase=evaluate(layout,source,background.masses,system.wave,values,thermal,theta,'phase')
                        actual_slow=np.array([slow['branches'][branch]['relative_rate'] for branch in ('gr','poisson-spatial')])
                        old_slow_value=old_slow(old,theta)
                        slow_error=relative_error(actual_slow,old_slow_value)
                        total=np.array([current['branches'][branch]['relative_rate'] for branch in ('gr','poisson-spatial')])
                        phase_rate=np.array([phase['branches'][branch]['relative_rate'] for branch in ('gr','poisson-spatial')])
                        split_error=relative_error(total,actual_slow+phase_rate)
                        require(slow_error<GATE,'exact full slow metric derivative versus saved fourth-order jet')
                        require(split_error<ALGEBRA,'exact slow plus phase derivative split')
                        old_rate_error=relative_error(total,old_rate)
                    else:
                        saved_operator=old['matrix']
                        slow_error=split_error=old_rate_error=0.
                    saved_error=relative_error(candidate,saved_operator)
                    saved_absolute=float(np.max(abs(candidate-saved_operator)))
                    require(saved_error<GATE,'original qualified generator preserved')
                    record=dict(theta=theta,native_absolute=absolute,native_relative=comparison,native_scalar=max(native['scalar_residual']),
                        saved_relative=saved_error,saved_absolute=saved_absolute,slow_metric_relative=slow_error,total_metric_rate_relative=old_rate_error,split_relative=split_error)
                    checks.append(record)
                    write(output/f'{model}-{index}-check-{number}.json',record)
                reports.append(dict(model=model,index=index,checks=checks))
                print(LABEL,model,index,'exact source jets passed',max(row['native_absolute'] for row in checks),'slow',max(row['slow_metric_relative'] for row in checks),flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,finite_difference_jets_used_in_new_generator=False,
        scope='exact retained source/map directional derivative and coupled physical generator; no new evolution or full interval derivative bound'))


if __name__=='__main__':
    main()
