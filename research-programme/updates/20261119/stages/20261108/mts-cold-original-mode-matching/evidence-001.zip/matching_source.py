from common import *
from source_laws import exterior,point_thermal
from coupled_jets import evaluate
from stable_coupled import assemble
from native_joint import point_map
from thermal_spline import native_values
from mean_math import relative_error
import numpy as np
import mpmath as mp

mp.mp.dps=70
BRANCHES=('gr','poisson-spatial')


def owned_packet(model,branch):
    result_path=POISSON/'evolution-result.json'
    result=read(result_path)
    require(result['passed'],'accepted original evolution')
    record=next(row for report in result['reports'] if report['model']==model for row in report['rows'] if row['branch']==branch)
    path=Path(record['packet'])
    require(digest(path)==record['sha256'],'original trajectory hash')
    with np.load(path) as packet:
        answer={name:packet[name].copy() for name in ('units','initial_raw','value_names','wave')}
        for name in ('efold','evolved_state','values'):
            value=packet[name]
            answer[name]=value[[0,-1]].copy()
            answer[name+'_shape']=list(value.shape)
    return answer,{str(result_path):digest(result_path),str(path):record['sha256']}


def frozen_source(fibre,energy,state,theta):
    fibre.install(state,theta)
    point=point_map(fibre.system,energy,float(state[0]))
    layout_path=FREE/LABEL/('free-01' if LABEL=='half' else 'free-02')/f'{fibre.system.model}-0-freeze.json'
    layout=read(layout_path)['layout']
    require(layout['core']==energy.size and layout['size']==energy.size+10,'unchanged compact phase support')
    constants_path=FULL/LABEL/f'full-01/{fibre.system.model}-constants.json'
    constants=read(constants_path)
    table_path=FULL/LABEL/f'full-01/{fibre.system.model}-thermal.npz'
    table=load(table_path)
    source=exterior(fibre.saved,constants,float(state[0]))
    native=native_values(fibre.system.context['lib'],float(state[4]))
    source_thermal,cell,local=point_thermal(table,float(native[1]))
    thermal={name:{key:float(value) for key,value in record.items()} for name,record in source_thermal.items()}
    require(abs(float(native[2])/source['scale']-1)<ALGEBRA,'thermal scale at original epoch')
    require(relative_error(np.array([thermal['sound']['value'],thermal['opacity']['value']]),native[3:5])<ALGEBRA,'original retained thermal readback')
    values=[source['scale']*fibre.masses[0]*state[1],state[2],state[3],state[4]]
    derived=evaluate(layout,source,fibre.masses,fibre.system.wave,values,thermal,theta)
    stable=assemble(layout,source,fibre.masses,fibre.system.wave,values,thermal,theta,derived)
    require(max(relative_error(stable[branch],derived['branches'][branch]['closed']) for branch in BRANCHES)<ALGEBRA,'original-phase factored identity')
    weight=np.ones(energy.size)
    if len(energy.heavy):
        weight[energy.heavy]=np.sqrt(state[3])*fibre.current[12]/fibre.system.wave
    transform=weight[:,None]*point['raw_transform']
    inverse=point['raw_inverse']/weight[None,:]
    require(relative_error(transform@inverse,np.eye(energy.size))<ALGEBRA,'original physical core map inverse')
    tail_weights=point['adapted']['tail_weights'].ravel()
    source_paths={str(path):digest(path) for path in (layout_path,constants_path,table_path)}
    return dict(layout=layout,source=source,values=values,thermal=thermal,theta=float(theta),cell=cell,local=float(local),
        hubble=derived['hubble'],mu=float(fibre.mu),representation_shift=float(fibre.representation_shift)),dict(
        transform=transform,inverse=inverse,tail_weights=tail_weights,
        source_matrix=np.array([stable[branch] for branch in BRANCHES]),
        metric=np.array([derived['branches'][branch]['metric'] for branch in BRANCHES]),
        forward_correction=np.array([derived['branches'][branch]['forward'] for branch in BRANCHES]),
        inverse_correction=np.array([derived['branches'][branch]['inverse'] for branch in BRANCHES])),point,derived,source_paths


def to_physical(normalized,maps,core):
    return np.concatenate([maps['transform']@normalized[:core],maps['tail_weights']*normalized[core:]])


def from_physical(physical,maps,core):
    return np.concatenate([maps['inverse']@physical[:core],physical[core:]/maps['tail_weights']])


def apply_correction(vector,correction,heavy,compact):
    answer=vector.copy()
    if len(heavy):
        answer[heavy]+=correction@vector[:compact]
    return answer

