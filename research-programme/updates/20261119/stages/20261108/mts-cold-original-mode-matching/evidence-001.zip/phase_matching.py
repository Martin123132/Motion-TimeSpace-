from common import *
from matching_source import BRANCHES,apply_correction,from_physical
from coupled_jets import evaluate
from stable_coupled import assemble
from mean_math import phase_primitive,interpolate,relative_error
from factored_sparse import evaluate as sparse_evaluate
from enclose_free import complete_layout
import numpy as np


def calculate(frozen,theta):
    arguments=(frozen['layout'],frozen['source'],frozen['masses'],WAVE,frozen['values'],frozen['thermal'],theta)
    direct=evaluate(*arguments)
    stable=assemble(*arguments,direct)
    return np.array([stable[branch] for branch in BRANCHES])


def average(matrix,angular):
    constant=matrix[0].copy()
    result=phase_primitive(matrix-constant,angular)
    result['mean']+=constant
    return result


def main():
    modest()
    output=ROOT/'phase-matching-01'
    output.mkdir(exist_ok=False)
    preparation=ROOT/'preparation-01'
    prior=read(preparation/'result.json')
    require(prior['passed'],'original preparation accepted')
    inputs=verify_inputs()
    consumed={str(preparation/'result.json'):digest(preparation/'result.json')}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,phase_count=256,
        unchanged_gate=GATE,unchanged_algebra=ALGEBRA,checks='128 subset; frozen actual phase and off-grid angles; all G192 remote support',
        endpoint='bar_z=(I+C(theta0))^-1 Rphys Bphys u_original; no new amplitude'))
    reports=[]
    angles=np.arange(256)*np.pi/256
    probes=(.239,1.157,2.613)
    for model in ('heavy','cold'):
        endpoints={}
        for kind in ('exact','mean'):
            source_path=preparation/f'{model}-{kind}-source.json'
            packet_path=preparation/f'{model}-{kind}-prepared.npz'
            frozen=read(source_path)
            require(digest(packet_path)==frozen['prepared_sha256'],'sealed prepared endpoint')
            consumed.update({str(path):digest(path) for path in (source_path,packet_path)})
            packet=load(packet_path)
            compact=frozen['layout']['size']
            heavy=frozen['layout']['heavy']
            baseline=calculate(frozen,0.)
            full_layout=complete_layout(frozen['layout'])
            remote=[]
            for angle in (0.,*probes):
                full=sparse_evaluate(full_layout,frozen['source'],frozen['masses'],WAVE,frozen['values'],frozen['thermal'],np.cos(2*angle),np.sin(2*angle))
                remote.append({branch:{key:value for key,value in full['branches'][branch].items() if max(key)>=compact} for branch in BRANCHES})
            require(all(remote[0]==item for item in remote[1:]),'remote G192 rows exactly phase independent')
            if model=='cold':
                require(all(np.array_equal(baseline,calculate(frozen,angle)) for angle in probes),'baseline phase independent')
                np.savez_compressed(output/f'{model}-{kind}-endpoint.npz',mean_state=packet['closed'],closed=packet['closed'],
                    physical=packet['physical'],normalized=packet['normalized'],mean_generator=baseline)
                endpoints[kind]=packet['closed'].copy()
                reports.append(dict(model=model,kind=kind,phase_correction=0.,remote_phase_independent=True))
                continue
            matrices=[]
            for number,angle in enumerate(angles):
                if number%32==0:
                    guard()
                matrices.append(calculate(frozen,angle))
            matrices=np.asarray(matrices)
            angular=frozen['mu']-1.5*np.sin(2*angles)
            require(np.min(angular)>0,'original positive phase clock')
            mean_states=[]
            details=[]
            for index,branch in enumerate(BRANCHES):
                result=average(matrices[:,index],angular)
                lower=average(matrices[::2,index],angular[::2])
                forcing_scale=max(float(np.max(abs(result['forcing']))),1e-80)
                closure=result['closure']/forcing_scale
                reconstruction=result['unresolved']/forcing_scale
                require(max(closure,reconstruction)<ALGEBRA,'original 256-node phase closure')
                mean_refinement=relative_error(result['mean'],lower['mean'])
                at_phase=interpolate(result['coefficients'],frozen['theta'])
                low_phase=interpolate(lower['coefficients'],frozen['theta'])
                primitive_refinement=relative_error(at_phase,low_phase)
                require(max(mean_refinement,primitive_refinement)<GATE,'original grid subset convergence')
                modes=np.fft.fftfreq(256,d=1/256)
                coefficients=result['coefficients']
                supremum=float(np.sum(np.linalg.norm(coefficients,axis=(1,2))))
                require(supremum<1,'whole Fourier-polynomial endpoint inverse margin')
                probe_errors=[]
                variation_scale=max(float(np.max(abs(matrices[:,index]-matrices[0,index]))),1e-80)
                for theta in (*probes,frozen['theta']):
                    prediction=result['mean']+(frozen['mu']-1.5*np.sin(2*theta))*interpolate(coefficients*(2j*modes[:,None,None]),theta)
                    direct=calculate(frozen,theta)[index]
                    error=float(np.max(abs(prediction-direct)))/variation_scale
                    require(error<GATE,'frozen off-grid physical source prediction')
                    probe_errors.append(error)
                closed=packet['closed'][index]
                endpoint=closed.copy()
                endpoint[:compact]=np.linalg.solve(np.eye(compact)+at_phase,closed[:compact])
                recovered=endpoint.copy()
                recovered[:compact]=(np.eye(compact)+at_phase)@endpoint[:compact]
                recover_error=relative_error(recovered,closed)
                physical=apply_correction(recovered,packet['forward_correction'][index],heavy,compact)
                normalized=from_physical(physical,packet,frozen['layout']['core'])
                original_error=relative_error(normalized,packet['normalized'])
                require(max(recover_error,original_error)<ALGEBRA,'full endpoint-to-original G192 roundtrip')
                mean_states.append(endpoint)
                target=output/f'{model}-{kind}-{branch}-primitive.npz'
                np.savez_compressed(target,**result,endpoint_primitive=at_phase)
                details.append(dict(branch=branch,closure_relative=closure,reconstruction_relative=reconstruction,
                    mean_subset_relative=mean_refinement,primitive_subset_relative=primitive_refinement,
                    whole_polynomial_primitive_bound=supremum,off_grid_variation_relative=max(probe_errors),
                    closed_norm=float(np.linalg.norm(closed)),mean_norm=float(np.linalg.norm(endpoint)),
                    endpoint_correction_norm=float(np.linalg.norm(endpoint-closed)),roundtrip=recover_error,
                    original_roundtrip=original_error,primitive_sha256=digest(target)))
            endpoints[kind]=np.array(mean_states)
            np.savez_compressed(output/f'{model}-{kind}-endpoint.npz',mean_state=endpoints[kind],closed=packet['closed'],
                physical=packet['physical'],normalized=packet['normalized'],angles=angles,angular=angular)
            reports.append(dict(model=model,kind=kind,phase=frozen['theta'],mu=frozen['mu'],
                remote_phase_independent=True,branches=details))
            print(LABEL,model,kind,'phase endpoints passed',[row['endpoint_correction_norm'] for row in details],flush=True)
            del matrices
        difference=endpoints['mean']-endpoints['exact']
        np.savez_compressed(output/f'{model}-mean-background-endpoint-difference.npz',difference=difference)
        reports.append(dict(model=model,initial_mean_background_difference_norm=[float(np.linalg.norm(row)) for row in difference],
            initial_reference_norm=[float(np.linalg.norm(row)) for row in endpoints['exact']]))
    require(all(digest(path)==value for path,value in consumed.items()),'matching inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        phase_grid_unchanged=True,physical_gates_unchanged=True,new_initial_mode=False,late_evolution=False,
        scope='original initial phase/closed/mean coordinates; finite phase interpolation tested, not a continuum quadrature proof'))


if __name__=='__main__':
    main()

