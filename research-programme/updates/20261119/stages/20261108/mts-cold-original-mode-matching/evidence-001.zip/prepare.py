from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from energy_operator import stable_point
from matching_source import *
import numpy as np


def main():
    modest()
    require(LABEL!='summary','retained wave')
    output=ROOT/'preparation-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),gate=GATE,algebra=ALGEBRA,
        branches=BRANCHES,models=['heavy','cold'],prediction='same original native perturbation, physical initial phase, exact and mean background endpoint coordinates'))
    consumed={}
    reports=[]
    for model in ('heavy','cold'):
        packets={}
        for branch in BRANCHES:
            packet,paths=owned_packet(model,branch)
            packets[branch]=packet
            consumed.update(paths)
        first=packets['gr']
        require(np.array_equal(first['initial_raw'],packets['poisson-spatial']['initial_raw']),'same prepared raw mode between gravity controls')
        require(np.array_equal(first['evolved_state'][0],packets['poisson-spatial']['evolved_state'][0]),'same physical initial matter state')
        system=open_owned(model,'preparation-01/contexts')
        energy=PhysicalEnergyMap(system)
        initial=float(first['efold'][0])
        require(initial==float(system.background['efold'][0]),'original epoch')
        require(float(first['wave'])==system.wave==WAVE,'original wave')
        require(np.array_equal(first['units'],system.units),'original normalization retained')
        require(np.array_equal(first['initial_raw'],system.initial_raw),'original native preparation retained')
        initial_error=relative_error(first['evolved_state'][0],system.initial)
        require(initial_error<ALGEBRA,'original encoded preparation')
        original=system.context['point'](initial)
        fields=system.background['initial_fields']+original[[0,2]]
        velocities=original[[1,3]]
        coordinates=fields*original[10]*system.background['masses']
        phase=float(np.arctan2(-velocities[1],coordinates[1])) if model=='heavy' else 0.
        exact=np.array([initial,fields[0],velocities[0],(coordinates[1]**2+velocities[1]**2)/2,original[11]])
        original_values={}
        for branch in BRANCHES:
            evaluated=system.evaluate(initial,system.initial,branch)[1]
            reference=np.array([evaluated[str(name)] for name in first['value_names']])
            error=relative_error(reference,packets[branch]['values'][0])
            require(error<GATE,'original initial observable readback')
            original_values[branch]=dict(error=error,values=reference.tolist())
        normalized=first['evolved_state'][0]/system.units
        prepared={}
        checks=[]
        with MatchedColdFibre(system) as fibre:
            config=fibre.saved.configuration
            initial_coordinates=np.array(config['initial_energy_coordinates'])
            require(relative_error(np.column_stack([coordinates,velocities]),initial_coordinates)<ALGEBRA,'saved background and original preparation share physical initial scalars')
            mean,mean_radius=fibre.saved_state(initial)
            for kind,state in (('exact',exact),('mean',mean)):
                frozen,maps,point,derived,paths=frozen_source(fibre,energy,state,phase)
                consumed.update(paths)
                layout=frozen['layout']
                heavy=layout['heavy']
                physical=to_physical(normalized,maps,energy.size)
                roundtrip=from_physical(physical,maps,energy.size)
                round_error=relative_error(roundtrip,normalized)
                require(round_error<ALGEBRA,'all G192 original coordinates recovered')
                closure=[]
                for index,branch in enumerate(BRANCHES):
                    closed=apply_correction(physical,maps['inverse_correction'][index],heavy,layout['size'])
                    restored=apply_correction(closed,maps['forward_correction'][index],heavy,layout['size'])
                    error=relative_error(restored,physical)
                    require(error<ALGEBRA,'closed endpoint roundtrip')
                    native_metric=point['metrics'][branch].copy()
                    if heavy:
                        native_metric[:,heavy]/=np.sqrt(state[3])*fibre.current[12]/system.wave
                    metric_error=relative_error(maps['metric'][index,:,:energy.size],native_metric)
                    require(metric_error<GATE,'independent native initial metric')
                    closure.append(closed)
                    checks.append(dict(kind=kind,branch=branch,roundtrip=error,metric_relative=metric_error))
                metrics=np.array([derived['branches'][branch]['relative_rate'][:,:energy.size] for branch in BRANCHES])
                native=stable_point(fibre,energy,state,phase,metrics)
                diagonal=np.ones(layout['size'])
                if heavy:
                    diagonal[heavy]=np.sqrt(state[3])*fibre.current[12]/system.wave
                converted=native['matrix']*diagonal[None,:,None]/diagonal[None,None,:]
                if heavy:
                    gamma=native['parameters']['eta0']-.5+(1.5+native['parameters']['b'])*np.cos(2*phase)
                    converted[:,heavy,heavy]+=gamma
                generator_relative=relative_error(converted,maps['source_matrix'])
                generator_absolute=float(np.max(abs(converted-maps['source_matrix'])))
                require(generator_absolute<GATE,'early-domain native closed generator absolute gate')
                require(max(native['scalar_residual'])<GATE,'native relative scalar rows')
                target=output/f'{model}-{kind}-prepared.npz'
                np.savez_compressed(target,normalized=normalized,initial_raw=first['initial_raw'],units=system.units,
                    original_encoded=first['evolved_state'][0],physical=physical,closed=np.array(closure),state=state,
                    **maps)
                write(output/f'{model}-{kind}-source.json',dict(**frozen,masses=fibre.masses.tolist(),source_paths=paths,prepared_sha256=digest(target)))
                prepared[kind]=dict(physical=physical,closed=np.array(closure),hubble=frozen['hubble'])
                checks.append(dict(kind=kind,coordinate_roundtrip=round_error,generator_absolute=generator_absolute,
                    generator_relative=generator_relative,native_scalar=max(native['scalar_residual'])))
            differences=dict(background=mean-exact,physical=prepared['mean']['physical']-prepared['exact']['physical'],
                closed=prepared['mean']['closed']-prepared['exact']['closed'])
            np.savez_compressed(output/f'{model}-preparation-differences.npz',**differences)
            report=dict(model=model,initial_efold=initial,original_end=float(first['efold'][-1]),
                original_points=first['evolved_state_shape'][0],dimension=len(normalized),core=energy.size,phase=phase,
                carrier_chart_phase=0.,initial_encoded_error=initial_error,original_values=original_values,
                mean_radius=mean_radius,background_difference=differences['background'].tolist(),
                initial_hubble_relative_change=prepared['mean']['hubble']/prepared['exact']['hubble']-1,
                physical_difference_norm=float(np.linalg.norm(differences['physical'])),
                physical_original_norm=float(np.linalg.norm(prepared['exact']['physical'])),
                closed_difference_norm=[float(np.linalg.norm(value)) for value in differences['closed']],
                cold_entrance=float(np.log(fibre.saved.target['scale_start'])),checks=checks)
            reports.append(report)
            write(output/f'{model}-result.json',report)
            print(LABEL,model,'original matching passed',max(row.get('generator_absolute',0) for row in checks),'phase',phase,flush=True)
    require(all(digest(path)==value for path,value in consumed.items()),'consumed original source preserved')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        gates_unchanged=True,new_initial_mode=False,late_evolution=False))


if __name__=='__main__':
    main()

