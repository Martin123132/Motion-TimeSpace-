from common import *
import ast
import numpy as np


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    owned={}
    for path in inputs:
        if Path(path).name=='closeout.json':
            for item in read(path)['artifacts']:
                owned[str(Path(item['path']))]=item['sha256']
    consumed={}
    accepted={}
    reports=[]
    for label in ('half','balanced','double'):
        base=STAGE/label
        prep_path=base/'preparation-01/result.json'
        phase_path=base/'phase-matching-01/result.json'
        for path in (prep_path,phase_path):
            record=read(path)
            require(record['passed'] and not record['new_initial_mode'] and not record['late_evolution'],'accepted scoped result')
            for field in ('inputs','sources','consumed'):
                for candidate,seal in record[field].items():
                    require(digest(candidate)==seal,'consumed source unchanged: '+candidate)
                    consumed[candidate]=seal
                    if str(Path(candidate)) in owned:
                        require(owned[str(Path(candidate))]==seal,'prior sealed source retained')
            accepted[str(path)]=digest(path)
        prep=read(prep_path)
        phases=read(phase_path)
        for model in ('heavy','cold'):
            original=next(row for row in prep['reports'] if row['model']==model)
            difference=next(row for row in phases['reports'] if row['model']==model and 'initial_mean_background_difference_norm' in row)
            require(original['original_end']<original['cold_entrance'],'early reference does not falsely reach cold epoch')
            full={}
            for kind in ('exact','mean'):
                source_path=base/'preparation-01'/f'{model}-{kind}-source.json'
                packet_path=base/'preparation-01'/f'{model}-{kind}-prepared.npz'
                endpoint_path=base/'phase-matching-01'/f'{model}-{kind}-endpoint.npz'
                source=read(source_path)
                packet=load(packet_path)
                endpoint=load(endpoint_path)
                full[kind]=source
                for path in (source_path,packet_path,endpoint_path):
                    consumed[str(path)]=digest(path)
                require(endpoint['mean_state'].shape==packet['closed'].shape==(2,original['dimension']),'all branch/full-hierarchy endpoints')
                require(np.array_equal(endpoint['normalized'],packet['normalized']),'no amplitude change')
                for path,seal in source['source_paths'].items():
                    require(str(Path(path)) in owned and owned[str(Path(path))]==seal and digest(path)==seal,'all reused tables/layouts match their prior seals')
                if model=='heavy':
                    phase_record=next(row for row in phases['reports'] if row.get('model')==model and row.get('kind')==kind)
                    require(phase_record['remote_phase_independent'],'full hierarchy support')
                    for branch in phase_record['branches']:
                        path=base/'phase-matching-01'/f"{model}-{kind}-{branch['branch']}-primitive.npz"
                        require(digest(path)==branch['primitive_sha256'],'phase primitive')
                        consumed[str(path)]=digest(path)
            config=read(COLD_BACKGROUND/'extension/freeze.json')['configurations'][model]
            if model=='heavy':
                invariant=config['tube']['invariant_initial']
                ratio=full['mean']['values'][2]/full['exact']['values'][2]
                invariant_error=abs(np.log(ratio)-invariant)
                require(invariant_error<ALGEBRA,'initial density change follows saved phase invariant')
            else:
                invariant_error=0.
                require(difference['initial_mean_background_difference_norm']==[0.,0.],'baseline replacement exactly zero')
            reports.append(dict(label=label,model=model,original_early_interval=[original['initial_efold'],original['original_end']],
                cold_entrance=original['cold_entrance'],dimension=original['dimension'],invariant_identity_error=invariant_error,
                initial_background_hubble_change=original['initial_hubble_relative_change'],
                initial_matching_difference_norm=difference['initial_mean_background_difference_norm'],
                original_mean_coordinate_norm=difference['initial_reference_norm']))
    independent_path=STAGE/'independent-matching/result.json'
    independent=read(independent_path)
    require(independent['passed'] and len(independent['reports'])==12 and len(independent['identities'])==5,'independent physical matching')
    accepted[str(independent_path)]=digest(independent_path)
    for field in ('inputs','sources','consumed'):
        for path,seal in independent[field].items():
            require(digest(path)==seal,'independent evidence source')
            consumed[path]=seal
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode cache')
    maximum_native=max(check.get('generator_absolute',0.) for label in ('half','balanced','double')
        for row in read(STAGE/label/'preparation-01/result.json')['reports'] for check in row['checks'])
    branch_reports=[branch for label in ('half','balanced','double')
        for row in read(STAGE/label/'phase-matching-01/result.json')['reports'] for branch in row.get('branches',[])]
    maxima={name:max(row[name] for row in branch_reports) for name in (
        'closure_relative','reconstruction_relative','mean_subset_relative','primitive_subset_relative',
        'whole_polynomial_primitive_bound','off_grid_variation_relative','original_roundtrip')}
    print('all original-mode matching checks pass; native absolute',maximum_native,'phase maxima',maxima,flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        failed_attempts_preserved=[],compiler_receipts=[],reports=reports,phase_maxima=maxima,maximum_native_absolute=maximum_native,
        independent_phase_map_relative=max(row.get('physical_map_relative',0.) for row in independent['reports']),
        model_cases=12,gravity_endpoint_cases=24,phase_matching_cases=len(branch_reports),
        original_preparation_preserved=True,no_late_reset=True,physical_gates_unchanged=True,late_history_generated=False))


if __name__=='__main__':
    main()

