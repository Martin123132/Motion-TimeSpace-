from common import *
from mean_math import relative_error
import numpy as np
import sympy as sp
import mpmath as mp


def main():
    modest()
    output=STAGE/'independent-matching'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    position,velocity,delta_position,delta_velocity,alpha=sp.symbols('position velocity delta_position delta_velocity alpha',real=True,nonzero=True)
    radius=position**2+velocity**2
    density=(position*delta_position+velocity*delta_velocity)/(radius/2)
    phase=(velocity*delta_position-position*delta_velocity)/radius
    normal=sp.Matrix([[2*position/radius,2*velocity/radius],[alpha*velocity/radius,-alpha*position/radius]])
    vector=normal*sp.Matrix([delta_position,delta_velocity])
    checks={
        'density_tangent':sp.factor(vector[0]-density),
        'relative_phase_tangent':sp.factor(vector[1]-alpha*phase),
        'relative_determinant':sp.factor(normal.det()+2*alpha/radius),
        'inverse_position':sp.factor((normal.inv()*vector)[0]-delta_position),
        'inverse_velocity':sp.factor((normal.inv()*vector)[1]-delta_velocity)}
    require(all(value==0 for value in checks.values()),'exact physical phase/density identities')
    mp.mp.dps=70
    reports=[]
    consumed={}
    for label in ('half','balanced','double'):
        root=STAGE/label/'preparation-01'
        result=read(root/'result.json')
        require(result['passed'],'original matching evidence')
        consumed[str(root/'result.json')]=digest(root/'result.json')
        for model in ('heavy','cold'):
            for kind in ('exact','mean'):
                source_path=root/f'{model}-{kind}-source.json'
                packet_path=root/f'{model}-{kind}-prepared.npz'
                frozen=read(source_path)
                packet=load(packet_path)
                require(digest(packet_path)==frozen['prepared_sha256'],'initial vector integrity')
                consumed.update({str(path):digest(path) for path in (source_path,packet_path)})
                layout=frozen['layout']
                dimension=len(packet['normalized'])
                require(dimension==layout['core']+950,'all original G192 tails retained')
                require(np.array_equal(packet['physical'][layout['core']:],packet['tail_weights']*packet['normalized'][layout['core']:]),'all physical tails retained without reset')
                if model=='cold':
                    require(not layout['heavy'],'control has no invented heavy phase')
                    reports.append(dict(label=label,model=model,kind=kind,heavy_phase='absent',full_dimension=dimension))
                    continue
                wave=mp.mpf(dict(read(WAVES)['waves'])[label])
                omega=mp.mpf(frozen['source']['scale'])*mp.mpf(frozen['masses'][1])
                hubble=mp.sqrt((mp.mpf(frozen['source']['density'])+
                    (mp.mpf(frozen['values'][0])**2+mp.mpf(frozen['values'][1])**2)/2+mp.mpf(frozen['values'][2]))/3)
                rho=mp.mpf(frozen['values'][2])
                theta=mp.mpf(frozen['theta'])
                background_position=mp.sqrt(2*rho)*mp.cos(theta)
                background_velocity=-mp.sqrt(2*rho)*mp.sin(theta)
                gauge=mp.mpf(packet['original_encoded'][layout['alpha']])
                slots=layout['heavy']
                field_perturbation=mp.mpf(packet['initial_raw'][slots[0]])
                velocity_perturbation=mp.mpf(packet['initial_raw'][slots[1]])
                velocity_rate=-2*background_velocity-omega*background_position/hubble
                delta_u=omega*(field_perturbation+background_velocity*gauge)
                delta_v=velocity_perturbation+hubble*(velocity_rate-background_velocity)*gauge
                density_tangent=(background_position*delta_u+background_velocity*delta_v)/rho
                phase_tangent=(background_velocity*delta_u-background_position*delta_v)/(2*rho)
                scale_alpha=wave**2/(omega*hubble)
                weight=mp.sqrt(rho)*hubble/wave
                independent=np.array([float(weight*density_tangent),float(weight*scale_alpha*phase_tangent)])
                error=relative_error(independent,packet['physical'][slots])
                require(error<GATE,'independent physical phase/density mapping')
                def radial(parameter):
                    return ((background_position+parameter*delta_u)**2+(background_velocity+parameter*delta_v)**2)/2
                def angle(parameter):
                    return mp.atan2(-(background_velocity+parameter*delta_v),background_position+parameter*delta_u)
                radial_check=mp.diff(radial,0,addprec=80)/rho
                angle_check=mp.diff(angle,0,addprec=80)
                high_precision=max(abs(radial_check-density_tangent)/max(abs(density_tangent),mp.mpf('1e-80')),
                    abs(angle_check-phase_tangent)/max(abs(phase_tangent),mp.mpf('1e-80')))
                require(high_precision<mp.mpf('1e-55'),'70-digit independent tangent check')
                reports.append(dict(label=label,model=model,kind=kind,full_dimension=dimension,
                    density_contrast=float(density_tangent),relative_phase_radians=float(phase_tangent),
                    phase_scaled_variable=float(scale_alpha*phase_tangent),physical_map_relative=error,
                    high_precision_relative=str(high_precision),original_phase_radians=frozen['theta']))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,
        identities={name:str(value) for name,value in checks.items()},reports=reports,
        definition='delta=delta_rho/rho, W=alpha*delta_theta, y_h=sqrt(rho)*H/k*(delta,W); retained positive scalar gauge shift'))
    print('independent phase and density matching passed',len(reports),max(row.get('physical_map_relative',0.) for row in reports),flush=True)


if __name__=='__main__':
    main()

