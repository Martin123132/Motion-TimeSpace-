from common import *
import importlib.util

modest()
output=STAGE/'preflight-01'
output.mkdir(exist_ok=False)
inputs=verify_inputs()
for path in STAGE.glob('*.py'):
    compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
require(digest(STAGE/'real_series.py')==digest(CONTINUATION/'real_series.py'),'exact accepted real evaluator unchanged')
dependencies={}
for name in ('correlated_source','boundary_forcing','build_forcing_v2','remainder_source','real_series','matching_source','adjoint_operator'):
    specification=importlib.util.find_spec(name)
    require(specification is not None and specification.origin is not None,'retained module exists '+name)
    path=Path(specification.origin)
    require(path.is_relative_to(POST),'retained project module ownership')
    dependencies[str(path)]=digest(path)
for directory in ('representation-01','regression-01'):
    path=CONTINUATION/directory/'result.json'
    require(read(path)['passed'],'accepted parent representation/regression')
    dependencies[str(path)]=digest(path)
require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=dependencies,
    exact_real_evaluator_reused=True,all_scripts_compile=True,no_new_fit=True))
print('parent, imports, unchanged evaluator and source syntax pass',flush=True)

