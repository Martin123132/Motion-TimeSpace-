from common import *
from correlated_source import CorrelatedSource,reconstruct,BRANCHES
from scipy.interpolate import CubicSpline
from real_series import RealForcing
from scipy.integrate import solve_ivp
import numpy as np
import time


def propagate(model,owner,bank,forcing,coarse,steps,scales):
    selected=forcing[::2] if coarse else forcing
    epochs=np.array([row['efold'] for row in selected])
    arrays=[]
    for row in selected:
        with np.load(row['path']) as packet:
            arrays.append({name:packet[name].copy() for name in ('normal_coefficients','map_coefficients')})
    physical_forcing=RealForcing(epochs,arrays)
    del arrays
    noncollision=CubicSpline(bank['efold'],bank['noncollision'])
    collision=CubicSpline(bank['efold'],bank['collision'])
    remote=CubicSpline(bank['efold'],bank['remote'])
    rows,columns=bank['keys'].T
    dimension=len(scales['initial'][0])
    compact=bank['mean'].shape[-1]
    normalization=scales['norm']
    def rhs(efold,flat):
        guard()
        theta=flat[0]
        state=flat[1:].reshape(2,2,dimension)
        if model=='heavy':
            background=owner.saved.mean(efold)
            slow=background['slow'][0]
            external=background['external'][0]
            omega=np.exp(efold)*owner.saved.masses[1]
            density=reconstruct(float(background['heavy'][0]),float(external[0]),float(external[1]),float(slow[0]),float(slow[1]),omega,theta)
            phase_rate=omega/float(density['hubble'])-1.5*np.sin(2*theta)
        else:
            phase_rate=0.
        force=physical_forcing(efold,theta)
        opacity=owner.thermal(float(efold))[0]['opacity']['value']
        matrix=noncollision(efold)+opacity*collision(efold)
        derivative=force/normalization[None,:,None]
        derivative[:,:,:compact]+=np.einsum('bij,cbj->cbi',matrix,state[:,:,:compact])
        weights=remote(efold)
        for component in range(2):
            for branch in range(2):
                derivative[component,branch]+=np.bincount(rows,weights*state[component,branch,columns],minlength=dimension)
        return np.concatenate([[phase_rate],derivative.ravel()])
    initial=np.zeros(1+4*dimension)
    initial[0]=bank['phase'][0]
    start,stop=bank['efold'][[0,-1]]
    started=time.monotonic()
    solved=solve_ivp(rhs,(start,stop),initial,method='DOP853',t_eval=bank['efold'],rtol=2e-12,atol=2e-14,max_step=(stop-start)/steps)
    require(solved.success and np.isfinite(solved.y).all(),'derived inhomogeneous response evolution')
    delta=solved.y[1:].T.reshape(-1,2,2,dimension)*normalization[None,None,:,None]
    phase_error=float(np.max(abs(solved.y[0]-bank['phase'])))
    require(phase_error<ALGEBRA,'correction uses independently reproduced original candidate phase')
    return delta,dict(nfev=solved.nfev,seconds=time.monotonic()-started,phase_difference=phase_error,max_step=(stop-start)/steps)


def main():
    modest()
    output=ROOT/'evolution-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    source_path=ROOT/'forcing-02/result.json'
    source_report=read(source_path)
    require(source_report['passed'],'all derived source nodes accepted')
    regression=CONTINUATION/'regression-01/result.json'
    require(read(regression)['passed'],'real-series evaluation qualified on retained evolution')
    consumed={str(source_path):digest(source_path),str(regression):digest(regression)}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,algebra=ALGEBRA,gate=GATE,
        approximation='first variation of constants on continued mean starting from inherited corrected state, normal-form and coordinate-map forcing separated',
        omitted='feedback of remainder on the corrected state and true-background source difference; not fitted',
        comparisons=['nine versus five source epochs','4096 versus2048 maximum time steps']))
    reports=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        bank_path=ROOT/'source-even-01'/f'{model}-bank.npz'
        old_path=ROOT/'mean-evolution-01'/f'{model}-fine.npz'
        consumed.update({str(path):digest(path) for path in (bank_path,old_path)})
        bank,old=load(bank_path),load(old_path)
        forcing=next(row['nodes'] for row in source_report['reports'] if row['model']==model)
        for node in forcing:
            require(digest(node['path'])==node['sha256'],'derived forcing packet frozen')
            consumed[node['path']]=node['sha256']
        scales=dict(initial=old['state'][0],norm=np.linalg.norm(old['state'][0],axis=1))
        packets={}
        runs=[]
        for name,coarse,steps in (('source-coarse',True,4096),('step-coarse',False,2048),('fine',False,4096)):
            delta,record=propagate(model,owner,bank,forcing,coarse,steps,scales)
            corrected=old['state']+delta.sum(axis=1)
            target=output/f'{model}-{name}.npz'
            np.savez_compressed(target,efold=bank['efold'],state=corrected,delta=delta,original=old['state'])
            packets[name]=delta
            runs.append(dict(name=name,**record,path=str(target),sha256=digest(target)))
            print(LABEL,model,name,'derived response',record,flush=True)
        checks=[]
        for name in ('source-coarse','step-coarse'):
            for branch in range(2):
                difference=packets[name][:,:,branch].sum(axis=1)-packets['fine'][:,:,branch].sum(axis=1)
                absolute=float(np.max(np.linalg.norm(difference,axis=1)))
                base_scale=float(np.max(np.linalg.norm(old['state'][:,branch],axis=1)))
                correction_scale=float(np.max(np.linalg.norm(packets['fine'][:,:,branch].sum(axis=1),axis=1)))
                relative=absolute/max(base_scale,1e-80)
                relative_correction=absolute/max(correction_scale,1e-80)
                require(relative<GATE,'unchanged physical response refinement gate')
                checks.append(dict(control=name,branch=BRANCHES[branch],relative=relative,absolute=absolute,
                    relative_to_correction=relative_correction,correction_relative=correction_scale/max(base_scale,1e-80)))
        reports.append(dict(model=model,runs=runs,checks=checks))
    require(all(digest(path)==seal for path,seal in consumed.items()),'response inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,correction_not_fitted=True,first_variation_only=True,no_reference_reset=True))


if __name__=='__main__':
    main()



