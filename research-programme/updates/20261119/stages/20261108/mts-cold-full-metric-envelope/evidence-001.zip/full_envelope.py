from common import *
from interval_math import Dual,variable,interval,lower,upper,derivative_bound
from full_metric_math import rows
import mpmath as mp
import numpy as np


def thermal_source(background,constants,efold):
    scale=mp.iv.exp(efold)
    parameters=background.thermal.parameters
    cold=(interval(parameters['cdm'])+interval(parameters['baryon']))/scale
    radiation=(interval(parameters['photon'])+interval(parameters['massless']))/(scale**2)
    density=cold+radiation
    massive_enthalpy=interval(0)
    massive_enthalpy_rate=interval(0)
    for mass,coefficient in zip(parameters['masses'],parameters['coefficients']):
        for node,weight in zip(background.thermal.nodes,background.thermal.weights):
            energy=mp.iv.sqrt(interval(float(node))**2+(interval(mass)*scale)**2)
            speed2=(interval(float(node))/energy)**2
            amount=interval(coefficient)/(scale**2)*energy*interval(float(weight))
            density+=amount
            massive_enthalpy+=amount*(1+speed2/3)
            massive_enthalpy_rate-=amount*(1+2*speed2-speed2**2/3)
    ratio=interval(constants['origin_scale'])/scale
    fluid=[interval(value)*ratio**power for value,power in zip(constants['fluid_origin'],(1,1,2,2))]
    massive=[]
    speeds=[]
    for amount,speed in zip(constants['massive_origin'],constants['speeds_origin']):
        velocity=1/mp.iv.sqrt(1+(1/interval(speed)**2-1)/ratio**2)
        speeds.append(velocity)
        massive.append(interval(amount)*ratio**2*interval(speed)/velocity)
    quantum=(interval(4)/3)*sum(massive)
    quantum_rate=-(interval(4)/3)*sum(amount*(1+speed**2) for amount,speed in zip(massive,speeds))
    enthalpy=cold+interval(4)/3*radiation+massive_enthalpy
    return dict(fluid=fluid,massive=massive,speeds=speeds,density=density,enthalpy=enthalpy,
        defect=quantum-massive_enthalpy,defect_rate=quantum_rate-massive_enthalpy_rate,scale=scale)


def enclose(background,constants,layout,sound_bound,wave,replacement,start,stop):
    efold=interval([start,stop])
    exterior=thermal_source(background,constants,efold)
    mean=background.mean([start,stop])
    if background.model=='heavy':
        slow_error=replacement['slow_error_upper']
        density_error=replacement['heavy_error_upper']
        norm_upper=replacement['slow_norm_upper']
        width=replacement['heavy_width_bound']
        rho0=float(mean['heavy'][0])
        rho_interval=interval(rho0)*mp.iv.exp(interval([start-stop-width,width]))
    else:
        slow_error=float(mean['radius'][-1])
        density_error=0.
        norm_upper=upper(interval(float(np.linalg.norm(mean['slow'][0])))*mp.iv.exp(interval(stop-start)))
        rho_interval=interval(0)
    slow_upper=upper(interval(norm_upper)+interval(slow_error))
    coordinate=variable([-slow_upper,slow_upper],0)
    velocity=variable([-slow_upper,slow_upper],1)
    density=variable([lower(rho_interval),upper(rho_interval)],2) if background.model=='heavy' else Dual(0)
    result=rows(layout,[Dual(value) for value in exterior['fluid']],[Dual(value) for value in exterior['massive']],
        [Dual(value) for value in exterior['speeds']],Dual(exterior['density']),Dual(exterior['enthalpy']),
        Dual(exterior['defect']),Dual(exterior['defect_rate']),Dual(interval(sound_bound)),Dual(exterior['scale']),
        background.masses,wave,coordinate,velocity,density,Dual(interval([-1,1])),Dual(interval([-1,1])))
    errors=[slow_error,slow_error,density_error]
    reports=[]
    for branch in ('gr','poisson-spatial'):
        physical=derivative_bound(result['physical'][branch],errors)
        entry=np.asarray(physical['entry_bounds'])
        external=[index for index in range(layout['size']) if index not in layout['heavy']]
        bound=lambda selection:upper(mp.iv.sqrt(sum(interval(float(value))**2 for value in entry[:,selection].ravel())))
        maps={}
        for name in ('forward_correction','inverse_correction'):
            maps[name]=derivative_bound(result['maps'][branch][name],errors) if layout['heavy'] else dict(entry_bounds=[],frobenius_bound=0.,derivatives=[])
        reports.append(dict(branch=branch,physical_metric=physical,external_physical_metric_bound=bound(external),
            heavy_physical_metric_bound=bound(layout['heavy']) if layout['heavy'] else 0.,maps=maps))
    return dict(model=background.model,reports=reports,background_errors=errors,
        state_box=dict(efold=[start,stop],slow=[-slow_upper,slow_upper],rho=[lower(rho_interval),upper(rho_interval)],
            sound_speed_squared=sound_bound,hubble=[lower(result['hubble'].value),upper(result['hubble'].value)]),
        interval_precision_digits=mp.iv.dps,sampling_used_to_infer_supremum=False,
        scope='full instantaneous metric source and physical coordinate maps; retained thermal history at fixed scale, parent finite quadrature and scalar tube; not free-generator or transport error')
