from common import *
import numpy as np
import psutil


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    for parent,paths in ((ANALYTIC,[f'{label}/analytic-01/{model}-{index}.npz' for label in ('half','balanced','double') for model in ('heavy','cold') for index in range(3)]),
                         (METRIC,[f'{label}/metric-02/{name}' for label in ('half','balanced','double') for name in ('result.json','heavy-1-repaired.npz')]),
                         (COLD,['build-canonical-stress/camb_python.f90','build-canonical-stress/native/camb/cambdll.dll','build-canonical-stress/build-result.json'])):
        sealed={str(Path(record['path'])):record['sha256'] for record in read(parent/'closeout.json')['artifacts']}
        for relative in paths:
            path=parent/relative
            require(str(path) in sealed and digest(path)==sealed[str(path)],'sealed consumed parent')
            consumed[str(path)]=sealed[str(path)]
    build=read(STAGE/'build-thermal-readout/build-result.json')
    require(build['state']=='complete' and build['getter_only_change'] and build['mappings_removed'],'completed read-only getter build')
    for path,value in build['consumed'].items():
        require(digest(path)==value,'parent compiler source/object unchanged')
        consumed[path]=value
    native_source=STAGE/'build-thermal-readout/camb_python.f90'
    text=native_source.read_text()
    first=text.index('    subroutine mts_retained_thermal_size(')
    last=text.index('    subroutine mts_bridge_thermal_read(',first)
    require((text[:first]+text[last:]).strip()==(COLD/'build-canonical-stress/camb_python.f90').read_text().strip(),'only getter addition to native source')
    require(digest(native_source)==build['source_sha256'],'compiled source retained')
    require(digest(STAGE/'build-thermal-readout/native/camb/cambdll.dll')==build['dll_sha256'],'compiled DLL retained')
    compiler_receipts=[]
    for record in build['processes']:
        require(record['exit_code']==0,'successful owned compiler')
        for identity in [record]+record['children']:
            try:
                process=psutil.Process(identity['pid'])
                same=abs(process.create_time()-identity['created'])<.01
                require(not same,'owned compiler or child still active')
                reused=True
            except psutil.NoSuchProcess:
                reused=False
            compiler_receipts.append(dict(pid=identity['pid'],created=identity['created'],command=identity['command'],verified_absent=True,pid_reused=reused))
    accepted={str(STAGE/'build-thermal-readout/build-result.json'):digest(STAGE/'build-thermal-readout/build-result.json')}
    maxima={}
    summaries=[]
    counts=dict(native_source_rows=0,native_metric_rows=0,native_map_rows=0,thermal_readback_components=0,getter_operator_controls=0)
    for label in ('half','balanced','double'):
        root=STAGE/label/'full-01'
        report=read(root/'result.json')
        require(report['passed'] and report['inputs']==inputs,'qualified same-source collector')
        for filename in ('collect_full_metric.py','full_metric_math.py','full_envelope.py','thermal_spline.py','common.py','native_context.py'):
            require(report['sources'][str(STAGE/filename)]==digest(STAGE/filename),'executed source unchanged')
        require(len(report['reports'])==6 and len(report['envelopes'])==2,'complete models and epochs')
        accepted[str(root/'result.json')]=digest(root/'result.json')
        for record in report['reports']:
            model,index=record['model'],record['index']
            freeze=read(root/f'{model}-{index}-freeze.json')
            require(digest(root/f'{model}-{index}-frozen.npz')==freeze['prediction_sha256'],'frozen native prediction unchanged')
            for value in record['thermal_errors']:
                require(value<ALGEBRA,'original thermal readback gate')
                maxima['thermal_readback']=max(maxima.get('thermal_readback',0.),value)
                counts['thermal_readback_components']+=1
            require(record['thermal_representation']<ALGEBRA,'original enthalpy representation gate')
            maxima['thermal_representation']=max(maxima.get('thermal_representation',0.),record['thermal_representation'])
            for check in record['source_checks']:
                name=check['component']
                kind='native_map_rows' if name.endswith('correction') else 'native_metric_rows' if name in ('gr','poisson-spatial') else 'native_source_rows'
                counts[kind]+=1
                for field in ('error','physical_error'):
                    if field in check:
                        require(check[field]<GATE,'original coefficient gate')
                        maxima[kind]=max(maxima.get(kind,0.),check[field])
            if record['getter_control'] is not None:
                control=record['getter_control']
                require(control['error']<(ALGEBRA if model=='cold' else GATE),'getter preserves retained operator')
                if model=='heavy':
                    require(control['native_scalar']<GATE,'independent native scalar reference')
                maxima['getter_operator']=max(maxima.get('getter_operator',0.),control['error'])
                maxima['getter_native_scalar']=max(maxima.get('getter_native_scalar',0.),control.get('native_scalar',0.))
                counts['getter_operator_controls']+=1
        repaired=read(root/'envelope-repair-02.json')
        require(repaired['passed'] and repaired['original_result_sha256']==digest(root/'result.json'),'repaired envelope retains qualified original source')
        for filename in ('full_envelope_v2.py','repair_full_envelopes.py'):
            require(repaired['sources'][str(STAGE/filename)]==digest(STAGE/filename),'executed repaired enclosure unchanged')
        accepted[str(root/'envelope-repair-02.json')]=digest(root/'envelope-repair-02.json')
        for envelope in repaired['envelopes']:
            model=envelope['model']
            bound_path=root/(model+'-thermal-bound.json')
            bound=read(bound_path)
            require(digest(bound_path)==envelope['thermal_bound_sha256'],'thermal enclosure unchanged')
            require(digest(root/(model+'-thermal.npz'))==bound['table_sha256'],'exact thermal source table retained')
            require(not envelope['sampling_used_to_infer_supremum'],'analytic interval enclosure')
            if model=='cold':
                require(envelope['background_errors']==[0.,0.,0.],'baseline no heavy-averaging replacement')
            for record in envelope['reports']:
                summaries.append(dict(label=label,model=model,branch=record['branch'],metric_bound_Mpc=record['physical_metric']['frobenius_bound'],
                    external_metric_bound_Mpc=record['external_physical_metric_bound'],heavy_metric_bound_Mpc=record['heavy_physical_metric_bound'],
                    forward_bound=record['maps']['forward_correction']['frobenius_bound'],inverse_bound=record['maps']['inverse_correction']['frobenius_bound']))
    validation=read(STAGE/'full-validation-02/result.json')
    require(validation['passed'] and validation['inputs']==inputs,'independent validation completed')
    require(validation['sources'][str(STAGE/'validate_full_metric_v2.py')]==digest(STAGE/'validate_full_metric_v2.py'),'independent source retained')
    for path,value in validation['frozen_bounds'].items():
        require(digest(path)==value,'validation did not retune bounds')
    counts['independent_gradient_entries']=sum(row['gradient_entries'] for row in validation['reports'])
    counts['independent_background_fixtures']=sum(row['fixtures'] for row in validation['reports'])
    counts['independent_thermal_values']=sum(row['checks'] for row in validation['thermal_records'].values())
    maxima['background_fixture_bound_ratio']=max(row['maximum_bound_ratio'] for row in validation['reports'])
    require(len(validation['reports'])==18,'all models epochs scales independently checked')
    accepted[str(STAGE/'full-validation-02/result.json')]=digest(STAGE/'full-validation-02/result.json')
    failure=read(STAGE/'validate-01.end.json')
    require(failure['exit_code']==1 and failure['source_sha256']==digest(STAGE/'validate_full_metric.py'),'failed original validator retained exactly')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        compiler_receipts=compiler_receipts,counts=counts,maxima=maxima,summary=summaries,
        full_instantaneous_metric_background_bound=True,full_generator_background_bound=False,
        algebra=ALGEBRA,gate=GATE,failed_attempts_preserved=['validate-01'],
        scope='all instantaneous physical metric columns and coordinate maps; inherited scalar tube and finite source; thermal cubic enclosure; no new initial mode or transport history'))
    print(json.dumps(dict(passed=True,counts=counts,maxima=maxima,summary=summaries),indent=2),flush=True)


if __name__=='__main__':
    main()
