from common import *
from metric_math import affine_map


def multiply(left,right):
    return [[sum(left[row][inner]*right[inner][column] for inner in range(len(right))) for column in range(len(right[0]))] for row in range(len(left))]


def inverse2(matrix):
    determinant=matrix[0][0]*matrix[1][1]-matrix[0][1]*matrix[1][0]
    return [[matrix[1][1]/determinant,-matrix[0][1]/determinant],[-matrix[1][0]/determinant,matrix[0][0]/determinant]]


def add(left,right,sign=1):
    return [[left[row][column]+sign*right[row][column] for column in range(len(left[0]))] for row in range(len(left))]


def scale(matrix,factor):
    return [[factor*value for value in row] for row in matrix]


def rows(layout,fluid,massive,speeds,external_density,external_enthalpy,defect,defect_rate,sound,scale_factor,masses,wave,coordinate,velocity,rho,cosine,sine):
    size=layout['size']
    zero=rho*0
    density=[zero for _ in range(size)]
    current=density.copy()
    shear=density.copy()
    pressure=density.copy()
    baryon=density.copy()
    root=[value**.5 for value in fluid]
    hubble=((external_density+(coordinate**2+velocity**2)/2+rho)/3)**.5
    gauge=layout['alpha']
    density[gauge]=3*hubble*defect/(root[0]*wave)
    current[gauge]=(fluid[0]-defect)/root[0]
    density[layout['cdm']]=root[0]*wave/hubble
    density[layout['baryon']]=root[1]*wave/hubble
    current[layout['baryon_velocity']]=root[1]
    baryon[gauge]=3*fluid[1]*sound*hubble/(root[0]*wave)
    baryon[layout['baryon']]=sound*root[1]*wave/hubble
    for name,species in (('photon',2),('massless',3)):
        monopole,dipole,quadrupole=layout[name]
        density[monopole]=2*root[species]
        pressure[monopole]=2*root[species]/3
        current[dipole]=2*root[species]/((zero+3)**.5)
        angular=2 if name=='massless' and layout['ufa'] else 5
        shear[quadrupole]=2*root[species]/((zero+angular)**.5)
    for slots,amount,speed in zip(layout['massive'],massive,speeds):
        monopole,dipole,quadrupole=slots
        width=(speed**2+4*(hubble/wave)**2)**.5
        root_density=amount**.5
        density[monopole]=2*root_density/width
        pressure[monopole]=2*root_density*speed**2/(3*width)
        current[dipole]=2*root_density/((zero+3)**.5)
        shear[quadrupole]=2*root_density*speed/((zero+5)**.5)
    omega_s=scale_factor*masses[0]
    frequency=(wave**2+omega_s**2)**.5
    scalar=layout['slow']
    density[scalar[0]]=omega_s*coordinate/frequency
    density[scalar[1]]=velocity
    current[scalar[0]]=wave*velocity/frequency
    pressure[scalar[0]]=-omega_s*coordinate/frequency
    pressure[scalar[1]]=velocity
    heavy=layout['heavy']
    if heavy:
        omega=scale_factor*masses[1]
        alpha=wave**2/(omega*hubble)
        density[heavy[0]]=rho
        current[heavy[0]]=-rho*hubble/wave*alpha*sine/2
        current[heavy[1]]=rho*hubble/wave*(1-cosine)
        pressure[heavy[0]]=-rho*cosine
        pressure[heavy[1]]=2*rho*sine/alpha
    quadrature=fluid[0]+fluid[1]+(fluid[2]+fluid[3]+sum(massive))*4/3+velocity**2+rho*(1-cosine)
    denominator=2*wave**2+3*quadrature
    eta=1-(external_enthalpy+velocity**2+rho*(1-cosine))/(2*hubble**2)
    free_density=[-density[column]-3*pressure[column]-wave*current[column]/hubble for column in range(size)]
    free_density[gauge]+=3*hubble*(eta*defect+defect_rate)/(root[0]*wave)-wave*defect/(root[0]*hubble)
    gr_psi=[-density[column]/(2*wave**2)-3*hubble*current[column]/(2*wave**3)-shear[column]/wave**2 for column in range(size)]
    corrected=current.copy()
    corrected[gauge]+=defect/root[0]
    factor=1-3*defect/denominator
    gr_rate=[-gr_psi[column]+factor*corrected[column]/(2*wave*hubble)-3*baryon[column]/denominator for column in range(size)]
    poisson_psi=[-value/(2*wave**2) for value in density]
    poisson_rate=[-(free_density[column]+3*defect*poisson_psi[column])/denominator for column in range(size)]
    metrics={'gr':[gr_psi,gr_rate],'poisson-spatial':[poisson_psi,poisson_rate]}
    physical={}
    maps={}
    for branch,metric in metrics.items():
        readout=[row.copy() for row in metric]
        if heavy:
            weight=rho**.5*hubble/wave
            for row in readout:
                for column in heavy:
                    row[column]/=weight
            mu=omega/hubble
            fraction=rho/(2*hubble**2)
            cosine_matrix=[[0,1],[alpha**2/4,-3-fraction]]
            sine_matrix=[[alpha/2,-6/alpha],[0,-alpha/2]]
            primitive=[[(cosine_matrix[row][column]*sine-sine_matrix[row][column]*cosine)/(2*mu) for column in range(2)] for row in range(2)]
            identity=[[1,0],[0,1]]
            transform=add(identity,primitive)
            affine=affine_map(rho,hubble,omega,wave,cosine,sine)
            selected=[[metric[row][column] for column in heavy] for row in range(2)]
            small=add(identity,multiply(affine,selected),-1)
            selector=[[int(column==heavy[row]) for column in range(size)] for row in range(2)]
            forcing=scale(multiply(affine,readout),weight)
            forward=multiply(inverse2(small),add(multiply(primitive,selector),forcing))
            inverse_transform=inverse2(transform)
            inverse=add(multiply(add(inverse_transform,identity,-1),selector),multiply(inverse_transform,forcing),-1)
            maps[branch]=dict(forward_correction=forward,inverse_correction=inverse)
        else:
            maps[branch]=dict(forward_correction=[],inverse_correction=[])
        physical[branch]=readout
    return dict(metrics=metrics,physical=physical,maps=maps,density=density,current=current,shear=shear,baryon=baryon,
        free_density=free_density,hubble=hubble,denominator=denominator)
