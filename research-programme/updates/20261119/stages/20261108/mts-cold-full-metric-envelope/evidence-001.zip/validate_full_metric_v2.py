from common import *
from cold_access import SavedBackground
from full_metric_math import rows
import itertools
import mpmath as mp
import numpy as np
import sympy as sp


mp.mp.dps=70


def compact(layout):
    selected=sorted(set([layout[name] for name in ('alpha','cdm','baryon','baryon_velocity')]+layout['photon']+layout['massless']+layout['slow']+layout['heavy']+sum(layout['massive'],[])))
    lookup={value:index for index,value in enumerate(selected)}
    answer=dict(size=len(selected),ufa=layout['ufa'])
    for name in ('alpha','cdm','baryon','baryon_velocity'):
        answer[name]=lookup[layout[name]]
    for name in ('photon','massless','slow','heavy'):
        answer[name]=[lookup[value] for value in layout[name]]
    answer['massive']=[[lookup[value] for value in group] for group in layout['massive']]
    return answer,selected


def external(background,constants,efold):
    scale=mp.exp(efold)
    parameters=background.thermal.parameters
    cold=(mp.mpf(parameters['cdm'])+mp.mpf(parameters['baryon']))/scale
    radiation=(mp.mpf(parameters['photon'])+mp.mpf(parameters['massless']))/scale**2
    density=cold+radiation
    enthalpy_massive=mp.mpf(0)
    rate_massive=mp.mpf(0)
    for mass,coefficient in zip(parameters['masses'],parameters['coefficients']):
        for node,weight in zip(background.thermal.nodes,background.thermal.weights):
            energy=mp.sqrt(mp.mpf(float(node))**2+(mp.mpf(mass)*scale)**2)
            speed2=(mp.mpf(float(node))/energy)**2
            amount=mp.mpf(coefficient)/scale**2*energy*mp.mpf(float(weight))
            density+=amount
            enthalpy_massive+=amount*(1+speed2/3)
            rate_massive-=amount*(1+2*speed2-speed2**2/3)
    ratio=mp.mpf(constants['origin_scale'])/scale
    fluid=[mp.mpf(value)*ratio**power for value,power in zip(constants['fluid_origin'],(1,1,2,2))]
    speeds=[1/mp.sqrt(1+(1/mp.mpf(speed)**2-1)/ratio**2) for speed in constants['speeds_origin']]
    massive=[mp.mpf(amount)*ratio**2*mp.mpf(origin)/speed for amount,origin,speed in zip(constants['massive_origin'],constants['speeds_origin'],speeds)]
    origin=mp.mpf(constants['origin_scale'])
    normalization_cold=((mp.mpf(constants['fluid_origin'][0])+mp.mpf(constants['fluid_origin'][1]))*origin-(mp.mpf(parameters['cdm'])+mp.mpf(parameters['baryon'])))/scale
    normalization_radiation=((mp.mpf(constants['fluid_origin'][2])+mp.mpf(constants['fluid_origin'][3]))*origin**2-(mp.mpf(parameters['photon'])+mp.mpf(parameters['massless'])))/scale**2
    defect=normalization_cold+mp.mpf(4)/3*normalization_radiation+mp.mpf(4)/3*sum(massive)-enthalpy_massive
    defect_rate=-normalization_cold-mp.mpf(8)/3*normalization_radiation-mp.mpf(4)/3*sum(amount*(1+speed**2) for amount,speed in zip(massive,speeds))-rate_massive
    return dict(fluid=fluid,massive=massive,speeds=speeds,external_density=density,external_enthalpy=cold+mp.mpf(4)/3*radiation+enthalpy_massive,
        defect=defect,defect_rate=defect_rate,scale_factor=scale)


def reference(layout,source,sound,masses,wave,values,theta):
    coordinate,velocity,rho=values
    cosine,sine=mp.cos(2*theta),mp.sin(2*theta)
    derived=rows(layout,**source,sound=sound,masses=masses,wave=wave,coordinate=coordinate,velocity=velocity,rho=rho,cosine=cosine,sine=sine)
    density,current,shear,baryon=(mp.matrix([derived[name]]) for name in ('density','current','shear','baryon'))
    pressure=baryon.copy()
    for name,species in (('photon',2),('massless',3)):
        pressure[layout[name][0]]+=2*mp.sqrt(source['fluid'][species])/3
    hubble=mp.sqrt((source['external_density']+(coordinate**2+velocity**2)/2+rho)/3)
    for slots,amount,speed in zip(layout['massive'],source['massive'],source['speeds']):
        pressure[slots[0]]+=2*mp.sqrt(amount)*speed**2/(3*mp.sqrt(speed**2+4*(hubble/wave)**2))
    omega_s=source['scale_factor']*masses[0]
    pressure[layout['slow'][0]]=-omega_s*coordinate/mp.sqrt(wave**2+omega_s**2)
    pressure[layout['slow'][1]]=velocity
    heavy=layout['heavy']
    if heavy:
        omega=source['scale_factor']*masses[1]
        alpha=wave**2/(omega*hubble)
        mu=omega/hubble
        fraction=rho/(2*hubble**2)
        pressure[heavy[0]]=-rho*cosine
        pressure[heavy[1]]=2*rho*sine/alpha
    quadrature=source['fluid'][0]+source['fluid'][1]+mp.mpf(4)/3*(source['fluid'][2]+source['fluid'][3]+sum(source['massive']))+velocity**2+rho*(1-cosine)
    eta=1-(quadrature-source['defect'])/(2*hubble**2)
    denominator=2*wave**2+3*quadrature
    free_current=-2*current+wave/hubble*(pressure-mp.mpf(2)/3*shear)
    free_current[layout['alpha']]-=(source['defect_rate']+source['defect'])/mp.sqrt(source['fluid'][0])
    free_density=mp.matrix([derived['free_density']])
    answers={}
    for branch in ('gr','poisson-spatial'):
        if branch=='gr':
            potential=-density/(2*wave**2)-3*hubble*current/(2*wave**3)-shear/wave**2
            rate=-(free_density+3*hubble*(eta*current+free_current)/wave+3*quadrature*potential)/denominator
        else:
            potential=-density/(2*wave**2)
            rate=-(free_density+3*source['defect']*potential)/denominator
        metric=mp.matrix([list(potential),list(rate)])
        physical=metric.copy()
        if heavy:
            weight=mp.sqrt(rho)*hubble/wave
            for column in heavy:
                for row in range(2):
                    physical[row,column]/=weight
            cosine_matrix=mp.matrix([[0,1],[alpha**2/4,-3-fraction]])
            sine_matrix=mp.matrix([[alpha/2,-6/alpha],[0,-alpha/2]])
            force_mean=mp.matrix([[0,3],[alpha*mu,0]])
            force_cosine=mp.matrix([[0,-3],[0,0]])
            force_sine=mp.matrix([[0,0],[0,3*alpha/2]])
            primitive=(cosine_matrix*sine-sine_matrix*cosine)/(2*mu)
            affine=((force_cosine+sine_matrix*force_mean/(2*mu))*sine-(force_sine-cosine_matrix*force_mean/(2*mu))*cosine)/(2*mu)
            transform=mp.eye(2)+primitive
            selector=mp.matrix([[int(column==heavy[row]) for column in range(layout['size'])] for row in range(2)])
            heavy_metric=mp.matrix([[metric[row,column] for column in heavy] for row in range(2)])
            closure=mp.eye(2)-affine*heavy_metric
            forward=closure**-1*(transform*selector+weight*affine*physical-affine*heavy_metric*selector)-selector
            inverse=transform**-1*(selector-weight*affine*physical)-selector
        else:
            forward=inverse=mp.zeros(0,0)
        answers[branch]=dict(physical_metric=physical,forward_correction=forward,inverse_correction=inverse)
        if all(not isinstance(value,mp.mpc) for value in values):
            for name,actual in answers[branch].items():
                comparison=mp.matrix(derived['physical'][branch] if name=='physical_metric' else derived['maps'][branch][name]) if actual.rows else actual
                require(mp.norm(actual-comparison)<=mp.mpf('1e-55')*max(mp.norm(actual),mp.mpf('1e-40')),'unreduced momentum and direct map solve agree at70digits')
    return answers


def thermal_checks(table,bound):
    local,left,right,sl, sr=sp.symbols('t a b m n')
    hermite=left+local*(sl+local*(3*(right-left)-2*sl-sr+local*(sl+sr+2*(left-right))))
    bernstein=left*(1-local)**3+3*(left+sl/3)*local*(1-local)**2+3*(right-sr/3)*local**2*(1-local)+right*local**3
    require(sp.expand(hermite-bernstein)==0,'exact cubic Bernstein identity')
    values=table['values']
    initial,step=(mp.mpf(float(value)) for value in table['metadata'])
    checks=0
    for record in bound['selected']:
        if checks%512==0:
            guard()
        index=record['index']
        for offset,name in ((0,'scale'),(2,'sound_speed_squared'),(4,'opacity')):
            left,right=(mp.mpf(float(value)) for value in values[offset,index:index+2])
            slope_left,slope_right=(mp.mpf(float(value)) for value in values[offset+1,index:index+2])
            second=3*(right-left)-2*slope_left-slope_right
            third=slope_left+slope_right+2*(left-right)
            probes=[mp.mpf(0),mp.mpf('.173'),mp.mpf('.5'),mp.mpf('.927'),mp.mpf(1)]
            discriminant=4*second**2-12*third*slope_left
            if third and discriminant>=0:
                probes.extend(value for value in ((-2*second+mp.sqrt(discriminant))/(6*third),(-2*second-mp.sqrt(discriminant))/(6*third)) if 0<value<1)
            elif second:
                extremum=-slope_left/(2*second)
                if 0<extremum<1:
                    probes.append(extremum)
            for position in probes:
                polynomial=left+position*(slope_left+position*(second+position*third))
                clock=initial*mp.exp((index+position)*step)
                value=polynomial*clock if offset==0 else polynomial
                require(mp.mpf(record[name][0])<=value<=mp.mpf(record[name][1]),'independent70-digit retained cubic enclosure')
                if offset==0:
                    derivative=clock*(polynomial+(slope_left+position*(2*second+3*position*third))/step)
                    require(mp.mpf(record['scale_log_rate'][0])<=derivative<=mp.mpf(record['scale_log_rate'][1]),'scale inversion monotonicity enclosure')
                checks+=1
    require([record['index'] for record in bound['selected']]==list(range(bound['selected'][0]['index'],bound['selected'][-1]['index']+1)),'contiguous covered source cells')
    return checks


def main():
    modest()
    output=STAGE/'full-validation-02'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    frozen={str(STAGE/label/'full-01/result.json'):digest(STAGE/label/'full-01/result.json') for label in ('half','balanced','double')}
    frozen.update({str(STAGE/label/'full-01/envelope-repair-02.json'):digest(STAGE/label/'full-01/envelope-repair-02.json') for label in ('half','balanced','double')})
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),frozen_bounds=frozen,precision_digits=70,angles=[.311,1.913],complex_steps=['1e-30','1e-35'],
        scope='independent differentiation and direct unsimplified momentum/map solve; shared stress rows already checked against native; no new evolution'))
    reports=[]
    thermal_records={}
    for label in ('half','balanced','double'):
        root=STAGE/label/'full-01'
        result=read(root/'envelope-repair-02.json')
        for model in ('heavy','cold'):
            background=SavedBackground(model)
            constants=read(root/(model+'-constants.json'))
            layout,selected=compact(read(root/(model+'-layout.json')))
            table=load(root/(model+'-thermal.npz'))
            thermal_bound=read(root/(model+'-thermal-bound.json'))
            table_key=digest(root/(model+'-thermal.npz'))
            if table_key not in thermal_records:
                thermal_records[table_key]=dict(model=model,checks=thermal_checks(table,thermal_bound),bound_sha256=digest(root/(model+'-thermal-bound.json')))
            envelope=next(item for item in result['envelopes'] if item['model']==model)
            wave=mp.mpf(dict(read(WAVES)['waves'])[label])
            masses=[mp.mpf(float(value)) for value in background.masses]
            for index in range(3):
                guard()
                packet=load(root/f'{model}-{index}-frozen.npz')
                state=packet['state']
                source=external(background,constants,mp.mpf(float(state[0])))
                sound=mp.mpf(float(packet['thermal'][3]))
                values=[source['scale_factor']*masses[0]*mp.mpf(float(state[1])),mp.mpf(float(state[2])),mp.mpf(float(state[3]))]
                local=background.mean([float(state[0])])
                radius,width=mp.mpf(float(local['radius'][0])),mp.mpf(float(local['width'][0]))
                maximum_ratio=mp.mpf(0)
                gradients=fixtures=0
                for angle in (.311,1.913):
                    before=reference(layout,source,sound,masses,wave,values,mp.mpf(angle))
                    for component in range(3 if model=='heavy' else 2):
                        approximations=[]
                        for step in (mp.mpf('1e-30'),mp.mpf('1e-35')):
                            shifted=values.copy()
                            shifted[component]+=mp.j*step
                            complex_value=reference(layout,source,sound,masses,wave,shifted,mp.mpf(angle))
                            approximations.append({branch:{name:matrix.apply(lambda value:mp.im(value)/step) for name,matrix in fields.items()} for branch,fields in complex_value.items()})
                        for branch,fields in approximations[-1].items():
                            limits=next(item for item in envelope['reports'] if item['branch']==branch)
                            for name,matrix in fields.items():
                                if not matrix.rows:
                                    continue
                                require(mp.norm(matrix-approximations[0][branch][name])<mp.mpf('1e-40')*max(mp.norm(matrix),mp.mpf('1e-15')),'high precision derivative step check')
                                report=limits[name] if name=='physical_metric' else limits['maps'][name]
                                for row in range(matrix.rows):
                                    for column,original in enumerate(selected):
                                        bound=mp.mpf(report['derivatives'][row][original][component])
                                        require(abs(matrix[row,column])<=bound+mp.mpf('1e-55'),'independent complex derivative inside interval AD bound,70digit floor')
                                        gradients+=1
                    signs_list=itertools.product((-1,1),repeat=3) if model=='heavy' else [(0,0,0)]
                    for signs in signs_list:
                        shifted=[values[0]+signs[0]*radius/mp.sqrt(2),values[1]+signs[1]*radius/mp.sqrt(2),values[2]*mp.exp(signs[2]*width)]
                        after=reference(layout,source,sound,masses,wave,shifted,mp.mpf(angle))
                        for branch,fields in before.items():
                            limits=next(item for item in envelope['reports'] if item['branch']==branch)
                            for name,matrix in fields.items():
                                if not matrix.rows:
                                    continue
                                report=limits[name] if name=='physical_metric' else limits['maps'][name]
                                difference=mp.norm(after[branch][name]-matrix)
                                limit=mp.mpf(report['frobenius_bound'])
                                require(difference<=limit,'full physical metric/map fixture within frozen bound')
                                maximum_ratio=max(maximum_ratio,difference/limit if limit else 0)
                        fixtures+=1
                reports.append(dict(label=label,model=model,index=index,gradient_entries=gradients,fixtures=fixtures,maximum_bound_ratio=float(maximum_ratio)))
                print(label,model,index,'full bounds checked',float(maximum_ratio),flush=True)
    require(all(digest(path)==value for path,value in frozen.items()),'bounds unchanged after fixtures')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),frozen_bounds=frozen,reports=reports,thermal_records=thermal_records,
        precision_digits=70,derivative_arithmetic_floor='1e-55 (not a physical tolerance)',physical_tolerances_unchanged=True))


if __name__=='__main__':
    main()
