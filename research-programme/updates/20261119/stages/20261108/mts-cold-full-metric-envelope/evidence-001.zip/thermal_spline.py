from common import *
from interval_math import interval,lower,upper
import ctypes
import mpmath as mp
import numpy as np


POINTER=ctypes.POINTER(ctypes.c_double)


def extract(library):
    count=ctypes.c_int()
    metadata=np.zeros(2)
    library.mts_retained_thermal_size.argtypes=[ctypes.POINTER(ctypes.c_int),POINTER]
    library.mts_retained_thermal_size.restype=None
    library.mts_retained_thermal_size(ctypes.byref(count),metadata.ctypes.data_as(POINTER))
    require(100<count.value<1000000,'retained thermal table size')
    values=np.empty((8,count.value),order='F')
    library.mts_retained_thermal_table.argtypes=[ctypes.c_int,POINTER]
    library.mts_retained_thermal_table.restype=None
    library.mts_retained_thermal_table(count.value,values.ctypes.data_as(POINTER))
    require(np.all(np.isfinite(values)) and np.all(metadata>0),'finite retained table')
    return dict(values=values,metadata=metadata)


def native_values(library,clock):
    values=np.zeros(6)
    library.mts_bridge_thermal_read.argtypes=[ctypes.c_double,POINTER]
    library.mts_bridge_thermal_read.restype=None
    library.mts_bridge_thermal_read(clock,values.ctypes.data_as(POINTER))
    return values


def bernstein(values,slopes,index):
    left,right=interval(float(values[index])),interval(float(values[index+1]))
    slope_left,slope_right=interval(float(slopes[index])),interval(float(slopes[index+1]))
    return [left,left+slope_left/3,right-slope_right/3,right]


def range_of(coefficients):
    return interval([min(lower(value) for value in coefficients),max(upper(value) for value in coefficients)])


def source_bound(table,minimum_scale,maximum_scale):
    values=table['values']
    initial,step=(interval(float(value)) for value in table['metadata'])
    selected=[]
    for index in range(values.shape[1]-1):
        if index%256==0:
            guard()
        times=interval([lower(initial*mp.iv.exp(index*step)),upper(initial*mp.iv.exp((index+1)*step))])
        scale_polynomial=bernstein(values[0],values[1],index)
        scale_range=range_of(scale_polynomial)*times
        if upper(scale_range)<minimum_scale or lower(scale_range)>maximum_scale:
            continue
        derivatives=[3*(scale_polynomial[order+1]-scale_polynomial[order])/step for order in range(3)]
        scale_log_rate=(range_of(scale_polynomial)+range_of(derivatives))*times
        require(lower(scale_log_rate)>0,'positive scale interpolation derivative in retained cold range')
        sound=range_of(bernstein(values[2],values[3],index))
        opacity=range_of(bernstein(values[4],values[5],index))
        require(lower(sound)>0 and lower(opacity)>0,'positive retained cold thermal functions')
        selected.append(dict(index=index,scale=[lower(scale_range),upper(scale_range)],clock=[lower(times),upper(times)],
            sound_speed_squared=[lower(sound),upper(sound)],opacity=[lower(opacity),upper(opacity)],
            scale_log_rate=[lower(scale_log_rate),upper(scale_log_rate)]))
    require(len(selected)>1,'source cells cover cold interval')
    require(min(row['scale'][0] for row in selected)<=minimum_scale and max(row['scale'][1] for row in selected)>=maximum_scale,'source endpoint coverage')
    return dict(selected=selected,sound_speed_squared=[min(row['sound_speed_squared'][0] for row in selected),max(row['sound_speed_squared'][1] for row in selected)],
        opacity=[min(row['opacity'][0] for row in selected),max(row['opacity'][1] for row in selected)],
        total_cells=values.shape[1]-1,minimum_scale=minimum_scale,maximum_scale=maximum_scale,
        method='outward interval Bernstein convex hull of the actual retained cubic spline cells; no sampled maximum')


def evaluate(table,time):
    initial,step=table['metadata']
    coordinate=np.log(time/initial)/step
    index=int(coordinate)
    local=coordinate-index
    require(0<=index<table['values'].shape[1]-1,'table interior only')
    answer=[]
    for row in (0,2,4):
        left,right=table['values'][row,index:index+2]
        slope_left,slope_right=table['values'][row+1,index:index+2]
        second=3*(right-left)-2*slope_left-slope_right
        third=slope_left+slope_right+2*(left-right)
        answer.append(left+local*(slope_left+local*(second+local*third)))
    answer[0]*=time
    return np.array(answer),index
