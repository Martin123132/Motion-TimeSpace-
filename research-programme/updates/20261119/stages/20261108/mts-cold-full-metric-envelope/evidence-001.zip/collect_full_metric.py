from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from native_joint import point_map
from metric_math import external_constants
from full_metric_math import rows
from full_envelope import enclose
from thermal_spline import extract,native_values,source_bound,evaluate
from mean_math import relative_error
from energy_operator import stable_point
from analytic_math import metric,operator
import numpy as np


def layout_of(system,energy,point):
    signature=system.context['signature_values']
    return dict(size=energy.size,alpha=system.alpha_slot,cdm=energy.slot(2),baryon=energy.slot(3),baryon_velocity=energy.slot(4),
        photon=[energy.slot(int(signature[3])+index) for index in range(3)],
        massless=[energy.slot(int(signature[4])+index) for index in range(3)],ufa=bool(signature[12]),
        massive=[[energy.moment_slot(degree,node) for degree in range(3)] for node in range(5)],
        slow=point['adapted']['old']['scalars'][0]['slots'].tolist(),heavy=energy.heavy.tolist())


def main():
    modest()
    output=ROOT/'full-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),gate=GATE,algebra=ALGEBRA,
        angles=[.239,1.157,2.613],build_sha256=digest(STAGE/'build-thermal-readout/build-result.json'),
        purpose='full metric source, source-owned thermal range and endpoint coordinate maps; no new trajectories'))
    reports=[]
    envelopes=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'full-01/contexts')
        energy=PhysicalEnergyMap(system)
        table=extract(system.context['lib'])
        np.savez_compressed(output/(model+'-thermal.npz'),**table)
        with MatchedColdFibre(system) as fibre:
            start=float(np.log(fibre.saved.target['scale_start']))
            stop=float(fibre.saved.saved['efold'][-1])
            bound=source_bound(table,float(np.exp(start)),float(np.exp(stop)))
            write(output/(model+'-thermal-bound.json'),dict(**bound,table_sha256=digest(output/(model+'-thermal.npz'))))
            constants=dict(origin_scale=float(energy.origin_scale),fluid_origin=energy.fluid_origin.tolist(),
                speeds_origin=energy.speeds_origin.tolist(),massive_origin=list(energy.massive_origin),masses=list(fibre.masses))
            write(output/(model+'-constants.json'),constants)
            layout=None
            for index in range(3):
                saved=load(ANALYTIC/LABEL/'analytic-01'/f'{model}-{index}.npz')
                state=saved['state']
                external=external_constants(fibre,energy,state)
                point=point_map(system,energy,float(state[0]))
                current_layout=layout_of(system,energy,point)
                require(layout is None or current_layout==layout,'same retained operator layout')
                layout=current_layout
                thermal=native_values(system.context['lib'],float(state[4]))
                reconstructed,cell=evaluate(table,float(thermal[1]))
                native=np.array([thermal[2],thermal[3],thermal[4]])
                thermal_errors=[relative_error(np.asarray(left),np.asarray(right)) for left,right in zip(reconstructed,native)]
                require(max(thermal_errors)<ALGEBRA,'exact retained cubic readback per thermal component')
                require(cell in [row['index'] for row in bound['selected']],'native source inside bounded cells')
                require(bound['sound_speed_squared'][0]<=thermal[3]<=bound['sound_speed_squared'][1],'native sound speed within source bound')
                fields=fibre.saved.thermal.values([state[0]])[0]
                true_enthalpy=(2*fields[0]-fields[1])/3
                representation=abs(true_enthalpy/external['native_enthalpy']-1)
                require(representation<ALGEBRA,'native and retained thermal representation agree')
                defect_rate=external['quadrature_rate']-(2*fields[1]-fields[2])/3
                coordinate=np.exp(state[0])*fibre.masses[0]*state[1]
                predictions=[]
                for angle in (.239,1.157,2.613):
                    predictions.append(rows(layout,external['fluid'],external['massive'],external['speeds'],fields[0],external['native_enthalpy'],
                        external['defect'],defect_rate,float(thermal[3]),np.exp(state[0]),fibre.masses,system.wave,
                        coordinate,state[2],state[3],np.cos(2*angle),np.sin(2*angle)))
                np.savez_compressed(output/f'{model}-{index}-frozen.npz',
                    metrics=np.array([[item['metrics'][name] for name in ('gr','poisson-spatial')] for item in predictions]),
                    physical=np.array([[item['physical'][name] for name in ('gr','poisson-spatial')] for item in predictions]),
                    state=state,thermal=thermal)
                write(output/f'{model}-{index}-freeze.json',dict(prediction_sha256=digest(output/f'{model}-{index}-frozen.npz'),sources=sources()))
                checks=[]
                for number,angle in enumerate((.239,1.157,2.613)):
                    fibre.install(state,angle)
                    point=point_map(system,energy,float(state[0]))
                    predicted=predictions[number]
                    diagonal=np.ones(energy.size)
                    if model=='heavy':
                        diagonal[energy.heavy]=np.sqrt(state[3])*external['hubble']/system.wave
                    physical_baryon=point['physical']['native_pressure']*np.sqrt(external['fluid'][1])*external['hubble']/system.wave@point['inverse_rotation']
                    for name,actual in (('density',point['adapted']['rows']['density']@point['inverse_rotation']),
                        ('current',point['adapted']['rows']['current']@point['inverse_rotation']),
                        ('shear',point['adapted']['rows']['shear']@point['inverse_rotation']),
                        ('baryon',physical_baryon),
                        ('free_density',point['adapted']['rows']['free_density']@point['inverse_rotation'])):
                        error=relative_error(np.asarray(predicted[name]),actual)
                        require(error<GATE,'derived full source component: '+name)
                        checks.append(dict(theta=angle,component=name,error=error))
                    for name in ('gr','poisson-spatial'):
                        error=relative_error(np.asarray(predicted['metrics'][name]),point['metrics'][name])
                        physical_error=relative_error(np.asarray(predicted['physical'][name]),point['metrics'][name]/diagonal)
                        require(max(error,physical_error)<GATE,'full derived metric row')
                        checks.append(dict(theta=angle,component=name,error=error,physical_error=physical_error))
                        if model=='heavy':
                            for source,key in (('forward','forward_correction'),('inverse','inverse_correction')):
                                actual=point['maps'][name][source]*diagonal[:,None]/diagonal[None,:]
                                actual=actual[energy.heavy]-np.eye(energy.size)[energy.heavy]
                                error=relative_error(np.asarray(predicted['maps'][name][key]),actual)
                                require(error<GATE,'physical coordinate map reproduced')
                                checks.append(dict(theta=angle,component=name+'_'+key,error=error))
                getter_control=None
                if index==1:
                    if model=='heavy':
                        old=load(METRIC/LABEL/'metric-02/heavy-1-repaired.npz')
                        _,derivative=metric(old,.239,'fine')
                        actual=stable_point(fibre,energy,state,.239,derivative[:,:,:energy.size])
                        transformed=actual['matrix']*old['diagonal'][None,:,None]/old['diagonal'][None,None,:]
                        gamma=float(old['eta0'])-.5+(1.5+float(old['fraction']))*np.cos(2*.239)
                        transformed[:,energy.heavy,energy.heavy]+=gamma
                        error=relative_error(transformed,operator(old,.239))
                        require(error<GATE and max(actual['scalar_residual'])<GATE,'read-only getter leaves native dynamics qualified')
                        getter_control=dict(error=error,native_scalar=max(actual['scalar_residual']))
                    else:
                        actual=stable_point(fibre,energy,state,.239,np.zeros((2,2,energy.size)))
                        error=relative_error(actual['matrix'],saved['matrix'])
                        require(error<ALGEBRA,'read-only getter baseline dynamics unchanged')
                        getter_control=dict(error=error)
                reports.append(dict(model=model,index=index,thermal_errors=thermal_errors,thermal_representation=representation,
                    source_checks=checks,getter_control=getter_control))
                print(LABEL,model,index,'full source passed',max(row['error'] for row in checks),flush=True)
            write(output/(model+'-layout.json'),layout)
            if model=='heavy':
                replacement=read(METRIC/LABEL/'metric-02/result.json')['interval']['replacement']
            else:
                replacement={}
            envelope=enclose(fibre.saved,constants,layout,bound['sound_speed_squared'],system.wave,replacement,start,stop)
            envelope['thermal_bound_sha256']=digest(output/(model+'-thermal-bound.json'))
            envelope['replacement']=replacement
            envelopes.append(envelope)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,envelopes=envelopes,
        full_instantaneous_metric_background_bound=True,full_generator_background_bound=False))
    print(json.dumps(dict(passed=True,interval_summaries=[dict(model=item['model'],bounds=[dict(branch=row['branch'],physical=row['physical_metric']['frobenius_bound'],
        forward=row['maps']['forward_correction']['frobenius_bound'],inverse=row['maps']['inverse_correction']['frobenius_bound']) for row in item['reports']]) for item in envelopes]),indent=2),flush=True)


if __name__=='__main__':
    main()
