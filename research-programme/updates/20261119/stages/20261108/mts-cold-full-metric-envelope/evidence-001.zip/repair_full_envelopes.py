from common import *
from cold_access import SavedBackground
from full_envelope_v2 import enclose


def main():
    modest()
    inputs=verify_inputs()
    failed=read(STAGE/'validate-01.end.json')
    require(failed['exit_code']==1 and failed['source_sha256']==digest(STAGE/'validate_full_metric.py'),'exact failed source retained')
    for label in ('half','balanced','double'):
        guard()
        root=STAGE/label/'full-01'
        previous=read(root/'result.json')
        require(previous['passed'],'native collector qualified')
        envelopes=[]
        for original in previous['envelopes']:
            model=original['model']
            bound=read(root/(model+'-thermal-bound.json'))
            replacement=enclose(SavedBackground(model),read(root/(model+'-constants.json')),read(root/(model+'-layout.json')),
                bound['sound_speed_squared'],dict(read(WAVES)['waves'])[label],original['replacement'],*original['state_box']['efold'])
            replacement['thermal_bound_sha256']=digest(root/(model+'-thermal-bound.json'))
            replacement['replacement']=original['replacement']
            envelopes.append(replacement)
        write(root/'envelope-repair-02.json',dict(passed=True,inputs=inputs,sources=sources(),original_result_sha256=digest(root/'result.json'),envelopes=envelopes,
            correction='retain exact cold/radiation coefficient normalization mismatch in full enthalpy defect and derivative; source rows/native checks unchanged',
            reused_native_checks=True,reused_thermal_tables=True,gate=GATE,algebra=ALGEBRA))
        print(label,'full normalization retained; saved native/table checks reused',flush=True)


if __name__=='__main__':
    main()
