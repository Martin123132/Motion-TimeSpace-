import hashlib
import json
import os
import sys
from pathlib import Path
from datetime import datetime, timezone

for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[variable]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
STAGE=Path(__file__).resolve().parent
POST=STAGE.parent
LABEL=sys.argv[1] if len(sys.argv)==2 else 'summary'
if LABEL not in ('half','balanced','double','summary'):
    raise ValueError('owned family required')
ROOT=STAGE/LABEL
METRIC=POST/'mts-cold-metric-tube-20261108'
ANALYTIC=POST/'mts-cold-analytic-phase-20261108'
ENERGY=POST/'mts-cold-energy-remainder-20261108'
COLD=POST/'mts-cold-coupled-coefficients-20261107'
PHASE=POST/'mts-correlated-relative-phase-mean-20261107'
ADAPTER=POST/'mts-background-operator-bridge-20261107'
JOINT=POST/'mts-joint-relative-metric-20261107'
RELATIVE=POST/'mts-relative-phase-perturbations-20261107'
COLD_BACKGROUND=POST/'mts-cold-background-extension-20261107'
CHANNELS=POST/'mts-metric-channel-factorization-20261107'
GAIN=POST/'mts-cold-adapted-metric-gain-20261107'
ENVELOPE=POST/'mts-coupled-energy-envelope-20261107'
ORIGINAL_WAVES=POST/'mts-newton-wavelength-bounds-20261107'
ORIGINAL_POISSON=POST/'mts-independent-poisson-evolution-20261107'
ORIGINAL_ADJOINT=POST/'mts-newton-feedback-adjoint-20261107'
ORIGINAL_PRIMITIVE=POST/'mts-metric-time-primitive-20261107'
POISSON=ORIGINAL_POISSON if LABEL=='balanced' else ORIGINAL_WAVES/LABEL
ADJOINT=ORIGINAL_ADJOINT if LABEL=='balanced' else ORIGINAL_WAVES/LABEL
PRIMITIVE=ORIGINAL_PRIMITIVE if LABEL=='balanced' else ORIGINAL_WAVES/LABEL/'primitive'
SEALED=POST/'mts-native-rest-action-feedback-20261107'
PARENT=POST/'mts-joint-gravity-hamiltonian-20261107'
PREVIOUS=POST/'mts-correlated-action-mean-20261107'
TIMECHAIN=POST/'mts-canonical-full-time-chain-20261107'
BACKGROUND=POST/'mts-background-repair-20261107'
SECOND=POST/'mts-second-micromotion-20261107'
BRANCH=POST/'condensate-origin-20261003'
PRIOR=POST/'mts-metric-feedback-20261107'
SOURCE=POST/'mts-direct-tangent-20261107'
HIERARCHY=POST/'mts-retarded-hierarchy-20261107'
NATIVE=BRANCH/'native-heavy-matching-20261007/native'
EARLY=BRANCH/'native-two-field-transfer-20261007'
WAVELENGTH=POST/'mts-derived-wavelength-test-20261107'
WAVES=WAVELENGTH/'inventory-config.json'
BRIDGE=Path('C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102')
ALGEBRA,GATE=1e-10,2e-5
sys.path.extend(str(path) for path in (METRIC,ANALYTIC,ENERGY,COLD,PHASE,JOINT,RELATIVE,GAIN,CHANNELS,ENVELOPE,ORIGINAL_WAVES,ORIGINAL_PRIMITIVE,ORIGINAL_ADJOINT,ORIGINAL_POISSON,SEALED,TIMECHAIN,PREVIOUS))


def require(condition,message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)


WAVE=dict(read(WAVES)['waves']).get(LABEL)


def guard():
    require(datetime.now(timezone.utc)<datetime(2026,11,8,5,0,tzinfo=timezone.utc),'four-hour check-in cutoff')
    for path in (STAGE/'STOP-REQUESTED',ROOT/'STOP-REQUESTED',RELATIVE/'STOP-REQUESTED',COLD_BACKGROUND/'STOP-REQUESTED',BRIDGE/'STOP-REQUESTED',BRIDGE.parent/'STOP-REQUESTED',BRIDGE.parent/'execution-v3/STOP-REQUEST.json',BRIDGE/'final-epoch-kinematic-bank/STOP-REQUESTED'):
        require(not path.exists(),'owner hold: '+str(path))


def modest():
    import psutil
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([4])
    guard()


def digest(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            result.update(block)
    return result.hexdigest()


def load(path):
    import numpy as np
    with np.load(path) as packet:
        return {name:packet[name].copy() for name in packet.files}


def sources():
    return {str(path):digest(path) for path in STAGE.iterdir() if path.suffix in ('.py','.ps1','.md')}


def verify_inputs():
    expected={
        METRIC:'883d32ff81a0ce099620db0e306cfb115a13ed63aa8be49f395d50339f5fe4f8',
        ANALYTIC:'446cf20750ba1fd7b54854a12284a9adb4cd562cd1cb723dd618347f7643a7d1',
        ENERGY:'5228bde4b21246bbcecb2b4a78772bb81fe43e954c419a61ea97e3718705642a',
        COLD:'2c34fcadb4847aec5dbaf72b292023d5fc3c9647d7e1701fc553bd9bbb5bdb13',
        PHASE:'e8938262d574eb8f4448ba88d37f4158292e202e7232c3133817034e978fee30',
        JOINT:'b5928c32e1a1c58e37c02fe747a8cd776307787ad4d58a3ddc0b2b614c9018a6',
        RELATIVE:'0ed0dc3b0b30e452a9e241057d21ffa6497e16298eace03d5b58ee13a4acab5f',
        COLD_BACKGROUND:'3cf78fb90a99a5b6c6527e29b221bccfd508a7c1df589b62ab47fac8e4df580f',
        CHANNELS:'a16e7c9764cebbadc43dbf729b5f8f86310aea63a5e6b83ab8afc082717f0ed0',
        GAIN:'cd29bc225d756592906efe5c3eb8316c937af9150865fffa9a7b361e43920b5e'}
    records={}
    for folder,seal in expected.items():
        guard()
        require(digest(folder/'closeout.json')==seal,'upstream seal')
        records[str(folder/'closeout.json')]=seal
        for item in read(folder/'closeout.json')['artifacts']:
            if Path(item['path']).suffix in ('.py','.json','.npz') and Path(item['path']).parent==folder:
                require(digest(item['path'])==item['sha256'],'upstream source')
                records[item['path']]=item['sha256']
    for path,seal in read(RELATIVE/'audit-01/result.json')['consumed'].items():
        require(digest(path)==seal,'saved background input')
        records[path]=seal
    owned={str(Path(row['path'])):row['sha256'] for row in read(COLD/'closeout.json')['artifacts']}
    for label in ('half','balanced','double'):
        for relative in ('cold-midpoint-02/heavy-generator.npz','cold-midpoint-02/cold-generator.npz','cold-midpoint-02/result.json','independent-02/result.json'):
            path=COLD/label/relative
            require(str(path) in owned and digest(path)==owned[str(path)],'accepted cold evidence')
            records[str(path)]=owned[str(path)]
    return records



def check_parent():
    return verify_inputs()
