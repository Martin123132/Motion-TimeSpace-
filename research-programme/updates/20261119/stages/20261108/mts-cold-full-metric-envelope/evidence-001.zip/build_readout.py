from common import *
import os
import shutil
import subprocess
import time
import psutil


def main():
    modest()
    inputs=verify_inputs()
    root=STAGE/'build-thermal-readout'
    require(not (root/'build-result.json').exists(),'no existing build attempt')
    parent=COLD/'build-canonical-stress'
    parent_result=read(parent/'build-result.json')
    require(parent_result['state']=='complete' and digest(parent/'native/camb/cambdll.dll')==parent_result['dll_sha256'],'sealed native parent')
    text=(root/'camb_python.f90').read_text()
    first=text.index("    subroutine mts_retained_thermal_size(")
    last=text.index("    subroutine mts_bridge_thermal_read(",first)
    require((text[:first]+text[last:]).strip()==(parent/'camb_python.f90').read_text().strip(),'only read-only getters added')
    original=read(NATIVE.parent/'runs/build-1/status.json')
    consumed={str(parent/'native/camb/cambdll.dll'):parent_result['dll_sha256'],str(parent/'camb_python.f90'):digest(parent/'camb_python.f90')}
    for path,value in original['input_hashes'].items():
        require(digest(path)==value,'retained compiler input')
        consumed[path]=value
    copied=('MTSTwoField.o','mtstwofield.mod','equations.o','gaugeinterface.mod')
    for name in copied:
        source=parent/name
        shutil.copy2(source,root/name)
        consumed[str(source)]=digest(source)
        require(digest(root/name)==consumed[str(source)],'identical reused object/module')
    package=root/'native'
    package.mkdir(exist_ok=False)
    shutil.copytree(parent/'native/camb',package/'camb',ignore=shutil.ignore_patterns('__pycache__','*.pyc','*.dll','*.so'))
    shutil.copy2(parent/'native/LICENCE.txt',package/'LICENCE.txt')
    shutil.copytree(parent/'native/fortran',package/'fortran')
    objects=sorted((NATIVE/'fortran/WinMTS').glob('*.o'))
    require(len(objects)>30,'complete retained object list')
    for path in objects+list((NATIVE/'fortran/WinMTS').glob('*.mod')):
        consumed[str(path)]=digest(path)
    report=dict(state='running',inputs=inputs,sources=sources(),consumed=consumed,processes=[],commands=[],mappings=[],getter_only_change=True)
    mappings=[]
    try:
        for drive,target in (('T:',EARLY/'toolchain/mingw64'),('R:',NATIVE),('S:',root)):
            require(not Path(drive+'/').exists(),'drive mapping occupied; do not displace it')
            subprocess.run(['subst',drive,str(target)],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
            mappings.append((drive,target))
            report['mappings'].append(dict(drive=drive,target=str(target)))
        flags=['-BT:/'+suffix+'/' for suffix in ('libexec/gcc/x86_64-w64-mingw32/14.2.0','lib','bin','lib/gcc/x86_64-w64-mingw32/14.2.0','x86_64-w64-mingw32/lib')]
        flags+=['-LT:/'+suffix+'/' for suffix in ('lib','lib/gcc/x86_64-w64-mingw32/14.2.0','x86_64-w64-mingw32/lib')]
        flags+=['-shared','-static','-cpp','-fopenmp','-O2','-fcheck=bounds','-fmax-errors=4','-ffree-line-length-none']
        commands=[['T:/bin/gfortran.exe',*flags,'camb_python.f90','-c','-o','camb_python.o','-JS:/','-IS:/','-IR:/fortran/WinMTS']]
        replaced={name.lower():name for name in ('MTSTwoField.o','equations.o','camb_python.o')}
        link=['S:/'+replaced[path.name.lower()] if path.name.lower() in replaced else 'R:/fortran/WinMTS/'+path.name for path in objects]
        commands.append(['T:/bin/gfortran.exe',*flags,*link,'-o','S:/native/camb/cambdll.dll'])
        environment=dict(os.environ,PATH='T:/bin;'+os.environ['PATH'])
        with (root/'compiler.log').open('x',encoding='utf-8') as log:
            for command in commands:
                guard()
                child=subprocess.Popen(command,cwd='S:/',env=environment,stdout=log,stderr=log,creationflags=subprocess.CREATE_NO_WINDOW)
                process=psutil.Process(child.pid)
                identity=dict(pid=child.pid,created=process.create_time(),command=command,children=[])
                report['commands'].append(command)
                report['processes'].append(identity)
                known=set()
                while child.poll() is None:
                    guard()
                    for descendant in process.children(recursive=True):
                        try:
                            key=(descendant.pid,descendant.create_time())
                            if key not in known:
                                known.add(key)
                                identity['children'].append(dict(pid=key[0],created=key[1],command=descendant.cmdline()))
                        except psutil.NoSuchProcess:
                            pass
                    time.sleep(.1)
                identity['exit_code']=child.wait()
                require(identity['exit_code']==0,'compiler failed; inspect retained attempt')
        for path,value in consumed.items():
            require(digest(path)==value,'upstream preserved')
        report.update(state='complete',dll_sha256=digest(package/'camb/cambdll.dll'),source_sha256=digest(root/'camb_python.f90'),
            compiler_sha256=digest(EARLY/'toolchain/mingw64/bin/gfortran.exe'))
    except BaseException as error:
        report.update(state='failed',error=repr(error))
        raise
    finally:
        for drive,target in reversed(mappings):
            require(Path(drive+'/').resolve()==target.resolve(),'owned mapping target must match before removal')
            subprocess.run(['subst',drive,'/D'],check=True,creationflags=subprocess.CREATE_NO_WINDOW)
        report['mappings_removed']=all(not Path(drive+'/').exists() for drive,_ in mappings)
        write(root/'build-result.json',report)
        print(json.dumps(dict(state=report['state'],mappings_removed=report['mappings_removed']),indent=2),flush=True)


if __name__=='__main__':
    main()
