from common import *
import ast
import inspect
import mpmath as mp
import validate_full_metric as validator


def main():
    modest()
    output=STAGE/'reference-diagnosis'
    output.mkdir(exist_ok=False)
    failed=read(STAGE/'validate-01.end.json')
    require(failed['exit_code']==1 and failed['source_sha256']==digest(STAGE/'validate_full_metric.py'),'failed source preserved')
    tree=ast.parse(inspect.getsource(validator.reference))
    recorder=ast.parse("diagnostics.append(dict(branch=branch,field=name,absolute=str(mp.norm(actual-comparison)),relative=str(mp.norm(actual-comparison)/max(mp.norm(actual),mp.mpf('1e-40')))))").body[0]
    class ReplaceComparison(ast.NodeTransformer):
        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='require':
                return recorder
            return self.generic_visit(node)
    tree=ast.fix_missing_locations(ReplaceComparison().visit(tree))
    diagnostics=[]
    namespace=dict(vars(validator),diagnostics=diagnostics)
    exec(compile(tree,str(STAGE/'validate_full_metric.py'),'exec'),namespace)
    root=STAGE/'half/full-01'
    background=validator.SavedBackground('heavy')
    constants=read(root/'heavy-constants.json')
    layout,_=validator.compact(read(root/'heavy-layout.json'))
    packet=load(root/'heavy-0-frozen.npz')
    state=packet['state']
    source=validator.external(background,constants,mp.mpf(float(state[0])))
    true_defect=source['fluid'][0]+source['fluid'][1]+mp.mpf(4)/3*(source['fluid'][2]+source['fluid'][3]+sum(source['massive']))-source['external_enthalpy']
    difference=true_defect-source['defect']
    masses=[mp.mpf(float(value)) for value in background.masses]
    values=[source['scale_factor']*masses[0]*mp.mpf(float(state[1])),mp.mpf(float(state[2])),mp.mpf(float(state[3]))]
    namespace['reference'](layout,source,mp.mpf(float(packet['thermal'][3])),masses,mp.mpf(dict(read(WAVES)['waves'])['half']),values,mp.mpf('.311'))
    original=list(diagnostics)
    diagnostics.clear()
    source['defect']=true_defect
    namespace['reference'](layout,source,mp.mpf(float(packet['thermal'][3])),masses,mp.mpf(dict(read(WAVES)['waves'])['half']),values,mp.mpf('.311'))
    result=dict(scope='diagnostic only; exact failed validator retained; no changed gate or accepted bounds',
        normalization_defect_difference=str(difference),original=original,full_defect=list(diagnostics))
    write(output/'result.json',result)
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    main()
