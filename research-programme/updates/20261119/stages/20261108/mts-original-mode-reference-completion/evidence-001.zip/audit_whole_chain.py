from common import *
import numpy as np

INTERVALS=(REMAINDER,CONTIGUOUS,REAL_SERIES,CONTINUATION,STAGE)
BRANCHES=('gr','poisson-spatial')
NAMES=('Phi','Psi','D','Q','Pi','theta_c','delta_c','delta_b','delta_gamma','delta_massless')


def relative(candidate,reference):
    return float(np.max(abs(candidate-reference))/max(float(np.max(abs(reference))),1e-80))


def main():
    modest()
    output=STAGE/'chain-audit-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    seals={parent:{str(Path(item['path'])):item['sha256'] for item in read(parent/'closeout.json')['artifacts']}
           for parent in (CORRELATED,REMAINDER,CONTIGUOUS,REAL_SERIES,CONTINUATION)}

    def retain(path):
        path=Path(path)
        guard()
        value=digest(path)
        for parent,mapping in seals.items():
            if path.is_relative_to(parent):
                require(str(path) in mapping and mapping[str(path)]==value,'exact sealed chain input '+str(path))
        consumed[str(path)]=value
        return path

    records=[]
    channel_checks=0
    for label in ('half','balanced','double'):
        for model in ('heavy','cold'):
            segments=[]
            references=None
            names=None
            previous=None
            joins=[]
            channel_records=[]
            evolution_times=[]
            evolution_states=[]
            for interval_index,folder in enumerate(INTERVALS):
                owner=CORRELATED if folder==REMAINDER else folder
                metadata=read(retain(owner/label/'source-even-01/freeze.json'))['metadata'][model]
                identity=[(row['branch'],str(Path(row['packet'])),row['sha256']) for row in metadata['reference']]
                require([row[0] for row in identity]==list(BRANCHES),'unchanged branch order')
                if references is None:
                    references=identity
                require(identity==references,'same original reference ownership throughout chain')
                bank=load(retain(owner/label/'source-even-01'/f'{model}-bank.npz'))
                prepared=load(retain(owner/label/'preparation-01'/f'{model}-prepared.npz'))
                leading_directory='evolution-01' if folder==REMAINDER else 'mean-evolution-01'
                leading=load(retain(owner/label/leading_directory/f'{model}-fine.npz'))
                evolution=load(retain(folder/label/'evolution-01'/f'{model}-fine.npz'))
                prediction=load(retain(folder/label/'predictions-01'/f'{model}-predicted.npz'))
                comparison=load(retain(folder/label/'comparison-01'/f'{model}-comparison.npz'))
                report=read(retain(folder/label/'comparison-01/result.json'))
                require(report['passed'] and report['all_physical_comparisons_pass'],'original packet comparisons accepted')
                prediction_report=read(retain(folder/label/'predictions-01/result.json'))
                require(prediction_report['passed'] and prediction_report['reference_perturbations_not_inspected'],'frozen physical predictions')
                finished=read(retain(folder/f'predictions-{label}-01.end.json'))
                started=read(retain(folder/f'comparison-{label}-01.start.json'))
                require(datetime.fromisoformat(finished['finished'])<=datetime.fromisoformat(started['created']),'prediction predates comparison')
                current_names=tuple(str(name) for name in prediction['value_names'])
                if names is None:
                    names=current_names
                require(current_names==names==NAMES and tuple(prediction['branches'])==BRANCHES,'same ten observables and branches')
                require(len(bank['efold'])==17 and len(prediction['efold'])==5,'retained source and physical-probe counts')
                require(np.array_equal(bank['efold'],evolution['efold']),'corrected states on unchanged bank')
                require(np.array_equal(bank['efold'],leading['efold']),'leading states on unchanged bank')
                require(np.array_equal(bank['efold'][::4],prediction['efold']),'five specified physical probes')
                require(np.array_equal(bank['indices'][::4],prediction['indices']),'original reference index ownership')
                require(np.array_equal(bank['phase'][::4],prediction['phase']),'own phase used for readouts')
                require(np.array_equal(comparison['efold'],prediction['efold']),'comparison epochs')
                require(np.array_equal(comparison['predicted'],prediction['values']),'comparison uses frozen predictions')
                require(np.array_equal(evolution['state'][0],leading['state'][0]),'new correction begins at zero')
                require(np.array_equal(evolution['delta'][0],np.zeros_like(evolution['delta'][0])),'zero local increment only')
                normalization=np.linalg.norm(prepared['mean_state'],axis=1)
                require(np.all(normalization>0),'nonzero original-mode normalization')
                expected=(prepared['mean_state']/normalization[:,None])*normalization[:,None]
                require(np.array_equal(leading['state'][0],expected),'known representation round trip exactly reproduced')
                initial_roundtrip=float(np.max(np.linalg.norm(leading['state'][0]-prepared['mean_state'],axis=1)/normalization))
                require(initial_roundtrip<ALGEBRA,'unchanged representation tolerance')
                if previous is not None:
                    old_bank,old_evolution,old_prediction=previous
                    require(float(old_bank['efold'][-1])==float(bank['efold'][0]),'exact contiguous epoch')
                    require(int(old_bank['indices'][-1])==int(bank['indices'][0]),'exact contiguous reference index')
                    require(float(old_bank['phase'][-1])==float(bank['phase'][0]),'exact own-phase continuity')
                    require(np.array_equal(prepared['mean_state'],old_evolution['state'][-1]),'no physical reset at any boundary')
                    join={name:relative(prediction[name][0],old_prediction[name][-1]) for name in ('values','encoded','state','phase')}
                    require(max(join.values())<ALGEBRA,'physical readout continuity at every boundary')
                    joins.append(dict(interval=interval_index+1,roundtrip_relative=initial_roundtrip,**join))
                model_report=next(row for row in report['reports'] if row['model']==model)
                for branch_index,branch in enumerate(BRANCHES):
                    branch_report=next(row for row in model_report['branches'] if row['branch']==branch)
                    require([row['name'] for row in branch_report['observables']]==list(NAMES),'reported observable names')
                    for column,name in enumerate(NAMES):
                        expected_reference=comparison['reference'][:,branch_index,column]
                        predicted=comparison['predicted'][:,branch_index,column]
                        difference=relative(predicted,expected_reference)
                        saved=branch_report['observables'][column]
                        require(abs(difference-saved['relative'])<ALGEBRA,'recomputed original local normalization')
                        require(saved['within_gate'] and difference<GATE,'unchanged per-interval channel gate')
                        channel_records.append(dict(interval=interval_index+1,branch=branch,observable=name,relative=difference))
                        channel_checks+=1
                segments.append((prediction,comparison))
                selected=slice(None) if interval_index==0 else slice(1,None)
                evolution_times.append(evolution['efold'][selected])
                evolution_states.append(evolution['state'][selected])
                previous=(bank,evolution,prediction)
            joined={}
            for name in ('efold','indices','values','encoded','phase','state'):
                joined[name]=np.concatenate([prediction[name] if index==0 else prediction[name][1:]
                                            for index,(prediction,comparison) in enumerate(segments)])
            joined['reference']=np.concatenate([comparison['reference'] if index==0 else comparison['reference'][1:]
                                               for index,(prediction,comparison) in enumerate(segments)])
            joined['evolution_efold']=np.concatenate(evolution_times)
            joined['evolution_state']=np.concatenate(evolution_states)
            require(len(joined['efold'])==21 and len(joined['evolution_efold'])==81,'distinct joined sample counts')
            require(np.all(np.diff(joined['efold'])>0) and np.all(np.diff(joined['evolution_efold'])>0),'no overlap or reversal')
            initial_errors=[]
            final_errors=[]
            original_horizons=[]
            for branch_index,(branch,path,seal) in enumerate(references):
                path=retain(path)
                require(digest(path)==seal,'same frozen original reference')
                with np.load(path) as packet:
                    grid=packet['efold'].copy()
                    original_values=packet['values'][joined['indices']]
                    original_state=packet['evolved_state'][joined['indices']]
                    units=packet['units'].copy()
                    require(tuple(packet['value_names'])==NAMES,'original reference channels')
                require(np.isfinite(units).all() and np.all(units!=0),'original native units')
                require(np.array_equal(grid[joined['indices']],joined['efold']),'every joined epoch belongs to original reference')
                require(np.array_equal(original_values,joined['reference'][:,branch_index]),'no substituted references')
                require(int(joined['indices'][0])==0 and int(joined['indices'][-1])==len(grid)-1,'whole original horizon')
                require(joined['efold'][0]==grid[0] and joined['efold'][-1]==grid[-1],'exact original start and stop')
                initial_error=float(np.linalg.norm((joined['encoded'][0,branch_index]-original_state[0])/units)/
                                    max(np.linalg.norm(original_state[0]/units),1e-80))
                require(initial_error<ALGEBRA,'actual original native initial state recovered')
                final_error=float(np.linalg.norm((joined['encoded'][-1,branch_index]-original_state[-1])/units)/
                                  max(np.linalg.norm(original_state[-1]/units),1e-80))
                initial_errors.append(dict(branch=branch,relative=initial_error))
                final_errors.append(dict(branch=branch,relative=final_error))
                original_horizons.append((float(grid[0]),float(grid[-1]),len(grid)))
            require(original_horizons[0]==original_horizons[1],'paired gravity horizons')
            joined['value_names']=np.array(NAMES)
            joined['branches']=np.array(BRANCHES)
            target=output/f'{label}-{model}-joined.npz'
            np.savez_compressed(target,**joined)
            worst=max(channel_records,key=lambda row:row['relative'])
            records.append(dict(label=label,model=model,complete=True,intervals=5,physical_epochs=21,evolution_epochs=81,
                original_start=original_horizons[0][0],original_stop=original_horizons[0][1],
                span=original_horizons[0][1]-original_horizons[0][0],original_reference_points=original_horizons[0][2],
                worst_local_channel=worst,initial_native_errors=initial_errors,final_native_errors=final_errors,
                joins=joins,channel_checks=channel_records,joined_path=str(target),joined_sha256=digest(target)))
            print(label,model,'whole original trajectory',worst,flush=True)
    require(channel_checks==600,'five intervals times six cases times twenty branch-channels')
    require(all(digest(path)==seal for path,seal in consumed.items()),'entire consumed chain unchanged')
    write(output/'result.json',dict(passed=True,intervals=5,channel_checks=channel_checks,inputs=inputs,sources=sources(),
        consumed=consumed,records=records,original_preparation_preserved=True,local_normalizations_unchanged=True,
        algebra_gate=ALGEBRA,numerical_gate=GATE,no_new_fit=True,no_new_reference_reset=True,
        scope='Finite sampled original trajectory; each gravity branch compared to its own original numerical reference. Not a uniform error bound or an observational holdout.'))


if __name__=='__main__':
    main()
