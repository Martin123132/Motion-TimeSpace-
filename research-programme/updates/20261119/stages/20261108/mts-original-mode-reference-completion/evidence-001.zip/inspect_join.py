from common import *
import numpy as np

modest()
output=STAGE/'join-diagnosis-01'
output.mkdir(exist_ok=False)
records=[]
consumed={}
for label in ('half','balanced','double'):
    for model in ('heavy','cold'):
        paths=[CONTINUATION/label/'evolution-01'/f'{model}-fine.npz',STAGE/label/'preparation-01'/f'{model}-prepared.npz',
            STAGE/label/'mean-evolution-01'/f'{model}-fine.npz',STAGE/label/'evolution-01'/f'{model}-fine.npz']
        old,prepared,leading,corrected=[load(path) for path in paths]
        consumed.update({str(path):digest(path) for path in paths})
        incoming=old['state'][-1]
        scale=np.linalg.norm(incoming,axis=1)
        reconstructed=(incoming/scale[:,None])*scale[:,None]
        difference=leading['state'][0]-incoming
        relative=np.linalg.norm(difference,axis=1)/scale
        require(np.array_equal(incoming,prepared['mean_state']),'preparation remains byte-identical')
        require(np.array_equal(reconstructed,leading['state'][0]),'only known normalize/denormalize round trip')
        require(np.array_equal(leading['state'][0],corrected['state'][0]),'zero new correction at join')
        require(np.max(relative)<ALGEBRA,'unchanged representation gate')
        records.append(dict(label=label,model=model,relative=relative.tolist(),maximum_absolute=float(np.max(abs(difference))),
            changed_components=int(np.count_nonzero(difference)),normalization_roundtrip_exactly_explains=True))
horizons=[]
for label in ('half','balanced','double'):
    metadata_path=STAGE/label/'source-even-01/freeze.json'
    metadata=read(metadata_path)['metadata']
    consumed[str(metadata_path)]=digest(metadata_path)
    for model in ('heavy','cold'):
        boundaries=[]
        for reference in metadata[model]['reference']:
            require(digest(reference['packet'])==reference['sha256'],'original reference horizon hash')
            consumed[reference['packet']]=reference['sha256']
            with np.load(reference['packet']) as packet:
                grid=packet['efold']
                boundaries.append((float(grid[0]),float(grid[-1]),len(grid)))
        require(all(item==boundaries[0] for item in boundaries),'paired original reference horizons')
        first,last,count=boundaries[0]
        endpoint=float(metadata[model]['stop'])
        require(first<endpoint and endpoint==last,'candidate reaches exact original reference endpoint')
        horizons.append(dict(label=label,model=model,original_start=first,original_stop=last,original_count=count,
            candidate_stop=endpoint,accumulated_span=endpoint-first,remaining_span=last-endpoint,complete=endpoint==last))
write(output/'result.json',dict(horizons=horizons,passed=True,sources=sources(),consumed=consumed,records=records,
    explanation='DOP853 leading state is normalized and denormalized; preparation is byte-identical, evolution adds only independently reproduced IEEE rounding'))
print(records,flush=True)



