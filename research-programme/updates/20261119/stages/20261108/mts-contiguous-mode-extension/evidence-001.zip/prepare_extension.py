from common import *
from correlated_source import BRANCHES
import numpy as np


def main():
    modest()
    output=ROOT/'preparation-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    source_path=ROOT/'source-even-01/result.json'
    require(read(source_path)['passed'],'new sources complete')
    consumed={str(source_path):digest(source_path)}
    reports=[]
    for model in ('heavy','cold'):
        incoming_path=REMAINDER/LABEL/'evolution-01'/f'{model}-fine.npz'
        previous_path=CORRELATED/LABEL/'source-even-01'/f'{model}-bank.npz'
        bank_path=ROOT/'source-even-01'/f'{model}-bank.npz'
        comparison_path=REMAINDER/LABEL/'comparison-01/result.json'
        correction_path=REMAINDER/LABEL/'evolution-01/result.json'
        leading_path=CORRELATED/LABEL/'evolution-01/result.json'
        control_path=REMAINDER/LABEL/'control-readout-01/result.json'
        consumed.update({str(path):digest(path) for path in (incoming_path,previous_path,bank_path,comparison_path,correction_path,leading_path,control_path)})
        incoming,previous,bank=load(incoming_path),load(previous_path),load(bank_path)
        require(float(incoming['efold'][-1])==float(bank['efold'][0]),'contiguous candidate state')
        require(float(previous['phase'][-1])==float(bank['phase'][0]),'candidate phase continuity')
        require(np.array_equal(previous['keys'],bank['keys']),'complete remote support continuity')
        for name in ('mean','collision','noncollision','remote','endpoint','remote_endpoint','mean_inverse_hubble'):
            require(np.array_equal(previous[name][-1],bank[name][0]),'exact boundary source reuse '+name)
        target=output/f'{model}-prepared.npz'
        np.savez_compressed(target,mean_state=incoming['state'][-1],inherited_delta=incoming['delta'][-1],
            inherited_leading=incoming['original'][-1],phase=bank['phase'][0],efold=bank['efold'][0])
        require(np.array_equal(load(target)['mean_state'],incoming['state'][-1]),'no reference reset or rounding')
        prior=next(row for row in read(comparison_path)['reports'] if row['model']==model)
        budget=dict(observed_previous_discrepancy=prior,
            previous_leading_controls=next(row for row in read(leading_path)['reports'] if row['model']==model),
            previous_correction_controls=next(row for row in read(correction_path)['reports'] if row['model']==model),
            previous_observable_controls=read(control_path),
            status='measured initial error and refinement estimates, not a uniform bound',
            remaining=['invariant drift','saved slow-history approximation','conformal-clock/source discrepancy','higher remainder response'])
        write(output/f'{model}-inherited-error.json',budget)
        reports.append(dict(model=model,efold=float(bank['efold'][0]),phase=float(bank['phase'][0]),
            path=str(target),sha256=digest(target),state_norms=np.linalg.norm(incoming['state'][-1],axis=1).tolist(),
            inherited_error_path=str(output/f'{model}-inherited-error.json')))
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained preparation unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        no_reference_state_reset=True,no_phase_reset=True,exact_boundary_sources_reused=True))


if __name__=='__main__':
    main()

