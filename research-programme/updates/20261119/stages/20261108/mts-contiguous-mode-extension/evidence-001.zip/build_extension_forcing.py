from build_forcing_v2 import *
from boundary_forcing import boundary_forcing


def main():
    modest()
    output=ROOT/'forcing-02'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),source_indices=list(range(0,33,4)),phase_count=256,
        algebra=ALGEBRA,gate=GATE,reference_residual_not_used_to_fit=True,original_evolution='continued mean from inherited corrected endpoint, no original-reference reset'))
    reports=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        bank_path=ROOT/'source-even-01'/f'{model}-bank.npz'
        evolution_path=ROOT/'mean-evolution-01'/f'{model}-fine.npz'
        bank,evolved=load(bank_path),load(evolution_path)
        consumed.update({str(path):digest(path) for path in (bank_path,evolution_path)})
        nodes=[]
        for index in range(0,33,4):
            started=time.monotonic()
            source_path=ROOT/'source-even-01'/f'{model}-{index:02d}-source.json'
            node_path=source_path.with_name(f'{model}-{index:02d}-mean.npz')
            consumed.update({str(path):digest(path) for path in (source_path,node_path)})
            frozen,node=read(source_path),load(node_path)
            bank_index=index//2
            target=output/f'{model}-{index:02d}-forcing.npz'
            if index==0:
                inherited_path=REMAINDER/LABEL/'forcing-02'/f'{model}-32-forcing.npz'
                consumed[str(inherited_path)]=digest(inherited_path)
                record=boundary_forcing(owner,frozen,node,evolved['state'][bank_index],float(bank['phase'][bank_index]),target,load(inherited_path))
            else:
                record=node_forcing(owner,frozen,node,evolved['state'][bank_index],float(bank['phase'][bank_index]),target)
            record.update(index=index,efold=frozen['efold'],seconds=time.monotonic()-started,path=str(target),sha256=digest(target))
            write(output/f'{model}-{index:02d}-report.json',record)
            nodes.append(record)
            print(LABEL,model,'complete derived forcing',index,record,flush=True)
        reports.append(dict(model=model,nodes=nodes))
    require(all(digest(path)==seal for path,seal in consumed.items()),'original sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,no_reference_residual_fitted=True))


if __name__=='__main__':
    main()



