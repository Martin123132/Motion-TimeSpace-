from common import *
from correlated_source import CorrelatedSource,full_average
from mean_math import interpolate,relative_error
from remainder_source import map_defect,physical_map,dense_parts,Directional
from probe_remainder import complex_tree
import numpy as np
import sympy as sp


def main():
    modest()
    output=ROOT/'slow-rate-validation-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    source_result=ROOT/'forcing-02/result.json'
    require(read(source_result)['passed'],'all forcing nodes complete')
    consumed[str(source_result)]=digest(source_result)
    generator,periodic,average,slow=sp.symbols('A C Abar Cslow',commutative=False)
    identity=sp.expand(generator*(1+periodic)-(1+periodic)*average-(generator-average)-slow-(generator*periodic-periodic*average-slow))
    require(identity==0,'exact noncommuting normal-form residual identity')
    reports=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        source_path=ROOT/'source-even-01'/f'{model}-16-source.json'
        packet_path=ROOT/'forcing-02'/f'{model}-16-forcing.npz'
        frozen,packet=read(source_path),load(packet_path)
        consumed.update({str(path):digest(path) for path in (source_path,packet_path)})
        angle=1.157 if model=='heavy' else 0.
        expected=np.array([interpolate(coefficients,angle) for coefficients in packet['compact_slow_coefficients']])
        scalar=float(interpolate(packet['scalar_coefficients'],angle)[0,0])
        scalar_rate=float(interpolate(packet['scalar_slow_coefficients'],angle)[0,0])
        expected_remote=scalar_rate*packet['remote_stream']+scalar*packet['remote_stream_rate']
        write(output/f'{model}-prediction.json',dict(efold=frozen['efold'],theta=angle,widths=[1e-4,5e-5],
            derivative='fixed theta, original dense histories and source laws',gate=GATE))
        checks=[]
        for width in (1e-4,5e-5):
            values=[]
            remote=[]
            for shift in (-2,-1,1,2):
                guard()
                changed=owner.frozen(frozen['efold']+shift*width)
                current=full_average(changed,model,angle)
                require(np.array_equal(current['remote_keys'],packet['remote_keys']),'same full hierarchy during derivative test')
                values.append(current['endpoint'])
                remote.append(current['remote_endpoint']*current['remote_stream'])
                np.savez_compressed(output/f'{model}-{width}-{shift}-actual.npz',endpoint=current['endpoint'],remote=remote[-1])
            actual=(values[0]-8*values[1]+8*values[2]-values[3])/(12*width)
            actual_remote=(remote[0]-8*remote[1]+8*remote[2]-remote[3])/(12*width)
            if model=='heavy':
                errors=[relative_error(actual[index],expected[index]) for index in range(2)]
                remote_error=relative_error(actual_remote,expected_remote)
                require(max(*errors,remote_error)<GATE,'independent fixed-phase slow derivative gate')
            else:
                require(not np.any(actual) and not np.any(expected) and not np.any(actual_remote),'baseline no invented phase primitive')
                errors=[0.,0.]
                remote_error=0.
            checks.append(dict(width=width,compact_relative=errors,remote_relative=remote_error))
            print(LABEL,model,'independent slow primitive rate',checks[-1],flush=True)
        reports.append(dict(model=model,checks=checks))
    require(all(digest(path)==seal for path,seal in consumed.items()),'validation sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        exact_normal_form_identity=str(identity),physical_gates_unchanged=True,not_moving_phase_differencing=True))


if __name__=='__main__':
    main()

