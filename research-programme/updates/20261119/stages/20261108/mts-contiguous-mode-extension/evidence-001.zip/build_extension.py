from common import *
from extension_source import *
from correlated_source import full_average
import shutil


def main():
    modest()
    output=ROOT/'source-even-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    metadata,consumed={},{}
    for model in ('heavy','cold'):
        metadata[model],paths=next_metadata(model)
        consumed.update(paths)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,metadata=metadata,
        algebra=ALGEBRA,gate=GATE,source_nodes=list(range(0,33,2)),held_out_nodes=list(range(1,32,2)),
        physical_outputs=[0,8,16,24,32],phase_count=256,no_reference_state_reset=True))
    reports=[]
    old_report=read(CORRELATED/LABEL/'source-even-01/result.json')
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        consumed.update(owner.consumed)
        times=np.array(metadata[model]['efold'])
        initial=metadata[model]['incoming_phase']
        lower,lower_count=continued_phase(owner,times,initial,256)
        phases,fine_count=continued_phase(owner,times,initial,512)
        difference=float(np.max(abs(phases-lower)))
        require(difference<ALGEBRA,'unchanged phase refinement gate')
        np.savez_compressed(output/f'{model}-phase.npz',efold=times,phase=phases,coarse=lower)
        bank={name:[] for name in ('mean','collision','noncollision','remote','endpoint','remote_endpoint','mean_inverse_hubble')}
        keys=None
        nodes=[]
        for index in range(0,33,2):
            guard()
            if index==0:
                source_path=CORRELATED/LABEL/'source-even-01'/f'{model}-32-source.json'
                node_path=source_path.with_name(f'{model}-32-mean.npz')
                frozen,result=read(source_path),load(node_path)
                require(frozen['efold']==times[0],'exact source join')
                consumed.update({str(path):digest(path) for path in (source_path,node_path)})
                result['remote_keys']=result['keys']
                prior=next(row for row in old_report['reports'] if row['model']==model)['nodes'][-1]
                diagnostic={name:prior[name] for name in ('closure','phase_refinement','full_primitive_bound','root_residual')}
                if model=='heavy':
                    primitive=source_path.with_name(f'{model}-32-primitive.npz')
                    consumed[str(primitive)]=digest(primitive)
                    shutil.copyfile(primitive,output/f'{model}-00-primitive.npz')
            else:
                frozen=owner.frozen(float(times[index]))
                keep=model=='heavy' and index in (8,16,24,32)
                result=full_average(frozen,model,float(phases[index]),output/f'{model}-{index:02d}-primitive.npz' if keep else None)
                diagnostic={name:result[name] for name in ('closure','phase_refinement','full_primitive_bound','root_residual')}
            write(output/f'{model}-{index:02d}-source.json',frozen)
            require(keys is None or np.array_equal(keys,result['remote_keys']),'full hierarchy unchanged')
            keys=result['remote_keys']
            for name in bank:
                bank[name].append(result[name])
            np.savez_compressed(output/f'{model}-{index:02d}-mean.npz',**{name:result[name] for name in bank},
                keys=keys,remote_stream=result['remote_stream'],remote_drift=result['remote_drift'])
            nodes.append(dict(index=index,reused_boundary=index==0,**diagnostic))
            print(LABEL,model,'extension source',index,'passed',flush=True)
        np.savez_compressed(output/f'{model}-bank.npz',efold=times[::2],phase=phases[::2],
            indices=np.array(metadata[model]['indices'])[::2],keys=keys,**{name:np.array(values) for name,values in bank.items()})
        reports.append(dict(model=model,phase_difference=difference,phase_nfev=[lower_count,fine_count],nodes=nodes,
            incoming_phase=initial,span=metadata[model]['span']))
    require(all(digest(path)==seal for path,seal in consumed.items()),'source/history checksums unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        physical_gates_unchanged=True,no_initial_reset=True))


if __name__=='__main__':
    main()
