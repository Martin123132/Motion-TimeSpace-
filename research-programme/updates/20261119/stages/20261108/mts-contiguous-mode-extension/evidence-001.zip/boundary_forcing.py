from build_forcing_v2 import *


def boundary_forcing(owner,frozen,node,state,theta,output,cached):
    compact=frozen['layout']['size']
    keys=node['keys']
    angles=np.arange(256)*np.pi/256 if owner.model=='heavy' else np.array([0.])
    count=len(angles)
    require(np.array_equal(cached['remote_keys'],keys),'inherited complete remote support')
    parsed=[]
    for branch_index in range(2):
        coefficients=cached['compact_coefficients'][branch_index]
        derivative_coefficients=cached['compact_slow_coefficients'][branch_index]
        modes=np.fft.fftfreq(count,d=1/count)
        parsed.append(dict(mean=node['mean'][branch_index],
            primitive=np.fft.ifft(coefficients*count,axis=0).real,
            phase_derivative=np.fft.ifft(coefficients*(2j*modes[:,None,None])*count,axis=0).real,
            slow=np.fft.ifft(derivative_coefficients*count,axis=0).real,
            coefficients=coefficients,derivative_coefficients=derivative_coefficients,closure=0.))
    scalar=dict(mean=np.array([[float(node['mean_inverse_hubble'])]]),
        primitive=np.fft.ifft(cached['scalar_coefficients']*count,axis=0).real,
        phase_derivative=np.fft.ifft(cached['scalar_coefficients']*(2j*modes[:,None,None])*count,axis=0).real,
        slow=np.fft.ifft(cached['scalar_slow_coefficients']*count,axis=0).real,
        coefficients=cached['scalar_coefficients'],derivative_coefficients=cached['scalar_slow_coefficients'],closure=0.)
    scalar_value=scalar['primitive'][:,0,0]
    scalar_slow=scalar['slow'][:,0,0]
    stream=cached['remote_stream']
    stream_rate=cached['remote_stream_rate']
    drift=node['remote_drift']
    mean_remote=node['remote']
    angular=np.empty(count)
    bank=np.empty((count,2,compact,compact))
    remote=np.empty((count,len(keys)))
    map_changes=np.empty_like(bank)
    background_defects=[]
    independent=[]
    selected={0,count//3,2*count//3}
    for number,angle in enumerate(angles):
        guard()
        prepared=slow_input(owner,frozen,float(angle))
        angular[number]=prepared['angular'].value if owner.model=='heavy' else 1.
        inverse=1/prepared['hubble'].value
        remote[number]=drift+inverse*stream
        map_changes[number],_,_=map_defect(prepared['physical'],float(angle),prepared['defect'])
        background_defects.append(prepared['defect'])
        for branch_index in range(2):
            bank[number,branch_index]=parsed[branch_index]['mean']+angular[number]*parsed[branch_index]['phase_derivative'][number]
        scalar_error=abs(float(scalar['mean'][0,0])+angular[number]*float(scalar['phase_derivative'][number,0,0])-inverse)/max(abs(inverse),1e-80)
        require(scalar_error<ALGEBRA,'inherited scalar phase identity at same source')
        if number in selected:
            _,direct=evaluate_slow(owner,frozen,float(angle),keys)
            matrix_error=relative_error(direct['matrix'],bank[number])
            remote_error=relative_error(direct['remote'],remote[number])
            require(max(matrix_error,remote_error)<ALGEBRA,'independent inherited boundary operator evaluation')
            old_errors=[]
            for branch_index in range(2):
                current=parsed[branch_index]
                vector=cached['state'][branch_index]
                primitive=current['primitive'][number]
                primitive_remote=scalar_value[number]*stream
                periodic=action(primitive,primitive_remote,keys,vector)
                averaged=action(current['mean'],mean_remote,keys,vector)
                numerator=action(bank[number,branch_index],remote[number],keys,periodic)-action(primitive,primitive_remote,keys,averaged)
                numerator-=action(current['slow'][number],scalar_slow[number]*stream+scalar_value[number]*stream_rate,keys,vector)
                numerator[:compact]+=map_changes[number,branch_index]@(vector+periodic)[:compact]
                reproduced=spsolve(full_endpoint(primitive,keys,stream,scalar_value[number],len(vector)),numerator)
                old_force=interpolate(cached['coefficients'],float(angle))[branch_index]
                error=float(np.linalg.norm(reproduced-old_force)/max(np.linalg.norm(vector),1e-80))
                require(error<ALGEBRA,'inherited force reproduced on original direction')
                old_errors.append(error)
            independent.append(dict(phase_index=number,matrix_relative=matrix_error,remote_relative=remote_error,
                old_force_difference_per_state=old_errors))
    mean_error=0.
    force=np.empty((count,2,state.shape[-1]))
    normal=np.empty_like(force)
    mapped=np.empty_like(force)
    identity_errors=[]
    maximum_condition=0.
    for phase_index in range(count):
        guard()
        for branch_index in range(2):
            current=parsed[branch_index]
            primitive=current['primitive'][phase_index]
            slow=current['slow'][phase_index]
            primitive_remote=scalar_value[phase_index]*stream
            slow_remote=scalar_slow[phase_index]*stream+scalar_value[phase_index]*stream_rate
            vector=state[branch_index]
            periodic=action(primitive,primitive_remote,keys,vector)
            averaged=action(current['mean'],mean_remote,keys,vector)
            remainder=action(bank[phase_index,branch_index],remote[phase_index],keys,periodic)
            remainder-=action(primitive,primitive_remote,keys,averaged)
            remainder-=action(slow,slow_remote,keys,vector)
            map_force=np.zeros_like(vector)
            map_force[:compact]=map_changes[phase_index,branch_index]@(vector+periodic)[:compact]
            endpoint=full_endpoint(primitive,keys,stream,scalar_value[phase_index],len(vector))
            normal[phase_index,branch_index]=spsolve(endpoint,remainder)
            mapped[phase_index,branch_index]=spsolve(endpoint,map_force)
            force[phase_index,branch_index]=normal[phase_index,branch_index]+mapped[phase_index,branch_index]
            direct=action(bank[phase_index,branch_index],remote[phase_index],keys,vector+periodic)+map_force
            chain=endpoint@(averaged+force[phase_index,branch_index])
            phase_remote=float(scalar['phase_derivative'][phase_index,0,0])*stream
            chain+=action(slow+angular[phase_index]*current['phase_derivative'][phase_index],
                slow_remote+angular[phase_index]*phase_remote,keys,vector)
            identity_errors.append(relative_error(chain,direct))
            if max(identity_errors[-1:])>=ALGEBRA:
                raise ValueError('exact directional normal-form chain rule')
    coefficients=np.fft.fft(force,axis=0)/count
    normal_coefficients=np.fft.fft(normal,axis=0)/count
    map_coefficients=np.fft.fft(mapped,axis=0)/count
    modes=np.fft.fftfreq(count,d=1/count)
    physical=np.einsum('p,pbi->bi',np.exp(2j*modes*theta),coefficients).real
    weight=1/angular
    mean_force=np.einsum('p,pbi->bi',weight,force)/weight.sum()
    refinements=[]
    if count==256:
        lower_coefficients=np.fft.fft(force[::2],axis=0)/128
        lower_modes=np.fft.fftfreq(128,d=1/128)
        lower_physical=np.einsum('p,pbi->bi',np.exp(2j*lower_modes*theta),lower_coefficients).real
        lower_mean=np.einsum('p,pbi->bi',weight[::2],force[::2])/weight[::2].sum()
        for branch_index in range(2):
            scale=max(float(np.linalg.norm(force[:,branch_index],axis=1).max()),1e-80)
            error=max(float(np.linalg.norm(physical[branch_index]-lower_physical[branch_index])),
                float(np.linalg.norm(mean_force[branch_index]-lower_mean[branch_index])))/scale
            require(error<GATE,'unchanged phase refinement of omitted forcing')
            refinements.append(error)
    else:
        refinements=[0.,0.]
    np.savez_compressed(output,coefficients=coefficients,normal_coefficients=normal_coefficients,map_coefficients=map_coefficients,
        physical=physical,mean_force=mean_force,background_defect=np.array(background_defects),angular=angular,
        compact_coefficients=np.array([item['coefficients'] for item in parsed]),
        compact_slow_coefficients=np.array([item['derivative_coefficients'] for item in parsed]),
        scalar_coefficients=scalar['coefficients'],scalar_slow_coefficients=scalar['derivative_coefficients'],
        remote_keys=keys,remote_stream=stream,remote_stream_rate=stream_rate,state=state,theta=np.array(theta))
    scales=np.linalg.norm(state,axis=1)
    return dict(reused_operator=True,independent_boundary_checks=independent,
        incoming_state_change=float(np.linalg.norm(state-cached['state'])/max(np.linalg.norm(cached['state']),1e-80)),
        closure_note='boundary primitive and slow-closure checks inherited; not recomputed as zero error',mean_relative=mean_error,maximum_chain_identity=max(identity_errors),phase_refinement=refinements,
        slow_closure=max(scalar['closure'],*(item['closure'] for item in parsed)),
        physical_force_per_state=(np.linalg.norm(physical,axis=1)/scales).tolist(),
        mean_force_per_state=(np.linalg.norm(mean_force,axis=1)/scales).tolist(),
        maximum_force_per_state=(np.max(np.linalg.norm(force,axis=2),axis=0)/scales).tolist(),
        maximum_map_force_per_state=(np.max(np.linalg.norm(mapped,axis=2),axis=0)/scales).tolist(),
        maximum_background_flow_defect=np.max(np.abs(background_defects),axis=0).tolist())

