from common import *
from correlated_source import *
from scipy.interpolate import CubicSpline
import numpy as np


def main():
    modest()
    output=ROOT/'source-heldout-01'
    output.mkdir(exist_ok=False)
    parent=ROOT/'source-even-01'
    require(read(parent/'result.json')['passed'],'completed correlated even nodes')
    inputs=verify_inputs()
    consumed={str(parent/'result.json'):digest(parent/'result.json')}
    metadata=read(parent/'freeze.json')['metadata']
    predictions={}
    for model in ('heavy','cold'):
        path=parent/f'{model}-bank.npz'
        bank=load(path)
        consumed[str(path)]=digest(path)
        source=CorrelatedSource(model)
        times=np.array(metadata[model]['efold'])[1::2]
        opacities=np.array([source.thermal(float(efold))[0]['opacity']['value'] for efold in times])
        values=dict(efold=times)
        for grid,selection in (('fine',slice(None)),('coarse',slice(None,None,2))):
            values[grid+'_mean']=CubicSpline(bank['efold'][selection],bank['noncollision'][selection])(times)
            values[grid+'_mean']+=opacities[:,None,None,None]*CubicSpline(bank['efold'][selection],bank['collision'][selection])(times)
            values[grid+'_remote']=CubicSpline(bank['efold'][selection],bank['remote'][selection])(times)
        target=output/f'{model}-predictions.npz'
        np.savez_compressed(target,**values)
        predictions[model]=dict(path=str(target),sha256=digest(target))
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,predictions=predictions,
        physical_gate=GATE,algebra_gate=ALGEBRA,collision_rate='direct original opacity times correlated average of R Cunit/H'))
    reports=[]
    for model in ('heavy','cold'):
        source=CorrelatedSource(model)
        bank=load(parent/f'{model}-bank.npz')
        phases=load(parent/f'{model}-phase.npz')['phase']
        prediction=load(predictions[model]['path'])
        checks=[]
        for number,index in enumerate(range(1,32,2)):
            guard()
            efold=float(prediction['efold'][number])
            actual=full_average(source.frozen(efold),model,float(phases[index]))
            require(np.array_equal(actual['remote_keys'],bank['keys']),'all-tail support unchanged')
            np.savez_compressed(output/f'{model}-{index:02d}-actual.npz',mean=actual['mean'],remote=actual['remote'])
            check=dict(index=index,efold=efold,root_residual=actual['root_residual'])
            for name in ('mean','remote'):
                for grid in ('fine','coarse'):
                    difference=prediction[grid+'_'+name][number]-actual[name]
                    absolute=float(np.max(abs(difference)))
                    check[grid+'_'+name+'_absolute']=absolute
                    require(absolute<GATE,'unchanged correlated source coefficient gate')
            checks.append(check)
            write(output/f'{model}-{index:02d}-check.json',check)
            print(LABEL,model,'correlated heldout',index,'passed',check['fine_mean_absolute'],flush=True)
        reports.append(dict(model=model,checks=checks))
    require(all(digest(path)==seal for path,seal in consumed.items()),'source banks unchanged')
    require(all(digest(row['path'])==row['sha256'] for row in predictions.values()),'heldout predictions remained frozen')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        predictions=predictions,physical_gates_unchanged=True,no_heldout_fit=True))


if __name__=='__main__':
    main()


