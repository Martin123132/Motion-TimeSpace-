from common import *
from remainder_source import *
from correlated_source import full_average
from coupled_jets import evaluate
from stable_coupled import assemble
from matching_source import frozen_source
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from mean_math import relative_error
import time


def complex_tree(value,width):
    if isinstance(value,Directional):
        return complex(value.value,width*value.rate)
    if isinstance(value,dict):
        return {key:complex_tree(entry,width) for key,entry in value.items()}
    if isinstance(value,list):
        return [complex_tree(entry,width) for entry in value]
    return value


def main():
    modest()
    output=ROOT/'probe-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    consumed={}
    records=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        path=ROOT/'source-even-01'/f'{model}-16-source.json'
        node_path=path.with_name(f'{model}-16-mean.npz')
        frozen,node=read(path),load(node_path)
        consumed.update({str(item):digest(item) for item in (path,node_path)})
        angle=1.157 if model=='heavy' else 0.
        started=time.monotonic()
        prepared,derived=evaluate_slow(owner,frozen,angle,node['keys'])
        elapsed=time.monotonic()-started
        physical=prepared['physical']
        raw=evaluate(frozen['layout'],physical['source'],frozen['masses'],WAVE,physical['values'],frozen['thermal'],angle)
        stable=assemble(frozen['layout'],physical['source'],frozen['masses'],WAVE,physical['values'],frozen['thermal'],angle,raw)
        source_error=max(relative_error(derived['matrix'][index],stable[branch]) for index,branch in enumerate(BRANCHES))
        require(source_error<ALGEBRA,'directional source value matches retained stable generator')
        derivative_checks=[]
        for width in (1e-20,1e-25):
            complex_source=complex_tree(prepared['source'],width)
            complex_values=complex_tree(prepared['values'],width)
            complex_thermal=complex_tree(prepared['thermal'],width)
            if model=='heavy':
                density=complex(physical['values'][2])
                mean_density=complex(frozen['values'][2],-width*frozen['values'][2])
                for iteration in range(12):
                    corrector,_=invariant_corrector(density,complex_source,complex_values[0],complex_values[1],complex_source['scale']*frozen['masses'][1],angle)
                    density=mean_density*np.exp(corrector)
                rho_relative=abs(density.imag/width-prepared['values'][2].rate)/max(abs(prepared['values'][2].rate),1e-80)
                require(rho_relative<ALGEBRA,'independent implicit slow density derivative')
                complex_values[2]=density
            else:
                rho_relative=0.
            result=full_source(complete_layout(frozen['layout']),complex_source,frozen['masses'],WAVE,complex_values,
                complex_thermal,np.cos(2*angle),np.sin(2*angle))
            maximum=0.
            compact=frozen['layout']['size']
            for branch_index,branch in enumerate(BRANCHES):
                expected=np.zeros((compact,compact))
                for (row,column),value in result['branches'][branch].items():
                    if max(row,column)<compact:
                        expected[row,column]=complex(value).imag/width
                difference=abs(expected-derived['derivative'][branch_index])/(1+abs(expected))
                maximum=max(maximum,float(np.max(difference)))
                remote=np.array([complex(result['branches'][branch].get(tuple(key),0.)).imag/width for key in node['keys']])
                maximum=max(maximum,float(np.max(abs(remote-derived['remote_derivative'])/(1+abs(remote)))))
            require(maximum<ALGEBRA,'independent complex directional source derivative')
            derivative_checks.append(dict(width=width,mixed_scaled_error=maximum,rho_relative=rho_relative))
        defect,matrix,logarithmic=map_defect(physical,angle,prepared['defect'])
        zero_defect,_,_=map_defect(physical,angle,np.zeros(4))
        require(not np.any(zero_defect),'physical-flow equality gives zero coordinate defect')
        system=open_owned(model,'probe-01/contexts')
        energy=PhysicalEnergyMap(system)
        state=np.array([frozen['efold'],physical['values'][0]/(physical['source']['scale']*frozen['masses'][0]),*physical['values'][1:]])
        with MatchedColdFibre(system) as fibre:
            fibre.chart_angle=0.
            current,maps,point,direct,paths=frozen_source(fibre,energy,state,angle)
            consumed.update(paths)
            native=np.zeros_like(matrix)
            native[:energy.size,:energy.size]=maps['transform']
            native[energy.size:,energy.size:]=np.diag(maps['tail_weights'][:10])
            scaled=matrix*system.units[:len(matrix)][None,:]
            map_error=relative_error(scaled,native)
            entry_error=float(np.max(abs(scaled-native)/(1+abs(native))))
            require(max(map_error,entry_error)<ALGEBRA,'derived physical map matches retained native map')
        reports=dict(model=model,source_value_error=source_error,source_seconds=elapsed,derivative_checks=derivative_checks,
            physical_map_relative=map_error,physical_map_mixed_error=entry_error,background_flow_defect=prepared['defect'].tolist(),
            map_defect_norms=[float(np.linalg.norm(item)) for item in defect],map_logarithmic_norm=float(np.linalg.norm(logarithmic)))
        np.savez_compressed(output/f'{model}-probe.npz',matrix=derived['matrix'],derivative=derived['derivative'],
            remote=derived['remote'],remote_derivative=derived['remote_derivative'],map_defect=defect)
        records.append(reports)
        write(output/f'{model}-report.json',reports)
        print(LABEL,model,'derived source and coordinate defect passed',reports,flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,records=records,
        physical_gates_unchanged=True,no_reference_residual_fitted=True))


if __name__=='__main__':
    main()


