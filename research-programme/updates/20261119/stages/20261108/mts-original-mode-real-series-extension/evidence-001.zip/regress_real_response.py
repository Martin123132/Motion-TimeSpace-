from common import *
from evolve_real_response import propagate,CorrelatedSource
import numpy as np


def main():
    modest()
    output=STAGE/'regression-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    representation=STAGE/'representation-01/result.json'
    require(read(representation)['passed'],'frozen algebraic tests pass')
    consumed={str(representation):digest(representation)}
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),gate=ALGEBRA,steps=1024,
        label=LABEL,models=['heavy','cold'],reference='preceding retained first-response evolution, not observational data'))
    reports=[]
    source_path=CONTINUATION/LABEL/'forcing-02/result.json'
    source=read(source_path)
    consumed[str(source_path)]=digest(source_path)
    for model in ('heavy','cold'):
        bank_path=CONTINUATION/LABEL/'source-even-01'/f'{model}-bank.npz'
        leading_path=CONTINUATION/LABEL/'mean-evolution-01'/f'{model}-fine.npz'
        reference_path=CONTINUATION/LABEL/'evolution-01'/f'{model}-fine.npz'
        bank,leading,reference=[load(path) for path in (bank_path,leading_path,reference_path)]
        consumed.update({str(path):digest(path) for path in (bank_path,leading_path,reference_path)})
        forcing=next(row['nodes'] for row in source['reports'] if row['model']==model)
        for node in forcing:
            require(digest(node['path'])==node['sha256'],'unchanged regression forcing')
            consumed[node['path']]=node['sha256']
        scales=dict(initial=leading['state'][0],norm=np.linalg.norm(leading['state'][0],axis=1))
        delta,record=propagate(model,CorrelatedSource(model),bank,forcing,False,1024,scales)
        differences=delta-reference['delta']
        checks=[]
        for component in range(2):
            for branch in range(2):
                absolute=float(np.max(np.linalg.norm(differences[:,component,branch],axis=1)))
                scale=float(np.max(np.linalg.norm(reference['delta'][:,component,branch],axis=1)))
                relative=absolute/max(scale,1e-80)
                require(relative<ALGEBRA,'unchanged algebraic gate on separately propagated response')
                checks.append(dict(component=component,branch=branch,relative=relative,absolute=absolute))
        path=output/f'{model}-regression.npz'
        np.savez_compressed(path,efold=bank['efold'],delta=delta,difference=differences)
        reports.append(dict(model=model,run=record,checks=checks,path=str(path),sha256=digest(path)))
        print(model,record,'maximum relative',max(row['relative'] for row in checks),flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'regression inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,no_coefficients_dropped=True))


if __name__=='__main__':
    main()

