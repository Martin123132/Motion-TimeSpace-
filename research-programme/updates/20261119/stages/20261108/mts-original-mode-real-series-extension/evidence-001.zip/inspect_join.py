from common import *
import numpy as np

modest()
output=STAGE/'join-diagnosis-01'
output.mkdir(exist_ok=False)
records=[]
consumed={}
for label in ('half','balanced','double'):
    for model in ('heavy','cold'):
        paths=[CONTINUATION/label/'evolution-01'/f'{model}-fine.npz',STAGE/label/'preparation-01'/f'{model}-prepared.npz',
            STAGE/label/'mean-evolution-01'/f'{model}-fine.npz',STAGE/label/'evolution-01'/f'{model}-fine.npz']
        old,prepared,leading,corrected=[load(path) for path in paths]
        consumed.update({str(path):digest(path) for path in paths})
        incoming=old['state'][-1]
        scale=np.linalg.norm(incoming,axis=1)
        reconstructed=(incoming/scale[:,None])*scale[:,None]
        difference=leading['state'][0]-incoming
        relative=np.linalg.norm(difference,axis=1)/scale
        require(np.array_equal(incoming,prepared['mean_state']),'preparation remains byte-identical')
        require(np.array_equal(reconstructed,leading['state'][0]),'only known normalize/denormalize round trip')
        require(np.array_equal(leading['state'][0],corrected['state'][0]),'zero new correction at join')
        require(np.max(relative)<ALGEBRA,'unchanged representation gate')
        records.append(dict(label=label,model=model,relative=relative.tolist(),maximum_absolute=float(np.max(abs(difference))),
            changed_components=int(np.count_nonzero(difference)),normalization_roundtrip_exactly_explains=True))
write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,records=records,
    explanation='DOP853 leading state is normalized and denormalized; preparation is byte-identical, evolution adds only independently reproduced IEEE rounding'))
print(records,flush=True)


