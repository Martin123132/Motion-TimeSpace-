from common import *
from correlated_source import CorrelatedSource,correlated,full_endpoint,BRANCHES
from matching_source import frozen_source,apply_correction,from_physical
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
import numpy as np

NAMES=('Phi','Psi','D','Q','Pi','theta_c','delta_c','delta_b','delta_gamma','delta_massless')


def main():
    modest()
    output=ROOT/'control-readout-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    consumed={}
    reports=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        bank_path=ROOT/'source-even-01'/f'{model}-bank.npz'
        fine_path=ROOT/'evolution-01'/f'{model}-fine.npz'
        comparison_path=ROOT/'comparison-01'/f'{model}-comparison.npz'
        bank,fine,reference=load(bank_path),load(fine_path),load(comparison_path)['reference']
        consumed.update({str(path):digest(path) for path in (bank_path,fine_path,comparison_path)})
        controls={}
        for name in ('source-coarse','step-coarse'):
            path=ROOT/'evolution-01'/f'{model}-{name}.npz'
            controls[name]=load(path)
            consumed[str(path)]=digest(path)
        selected=np.arange(0,17,4)
        system=open_owned(model,'control-readout-01/contexts')
        energy=PhysicalEnergyMap(system)
        carriers=[system.owner.phase(float(bank['efold'][index]))[0] if model=='heavy' else 0. for index in selected]
        differences={name:np.zeros((5,2,len(NAMES))) for name in controls}
        with MatchedColdFibre(system) as fibre:
            for output_index,index in enumerate(selected):
                efold=float(bank['efold'][index])
                theta=float(bank['phase'][index])
                frozen=owner.frozen(efold)
                if model=='heavy':
                    frozen,_=correlated(frozen,theta)
                state=np.array([efold,frozen['values'][0]/(np.exp(efold)*owner.saved.masses[0]),*frozen['values'][1:]])
                node_path=ROOT/'source-even-01'/f'{model}-{2*index:02d}-mean.npz'
                node=load(node_path)
                consumed[str(node_path)]=digest(node_path)
                fibre.chart_angle=float(carriers[output_index])
                current,maps,point,direct,paths=frozen_source(fibre,energy,state,theta)
                consumed.update(paths)
                for branch_index,branch in enumerate(BRANCHES):
                    zero=system.evaluate(efold,np.zeros_like(system.units),branch)[1]
                    require(all(zero[name]==0 for name in NAMES),'linear physical readout vanishes on zero mode')
                    endpoint=full_endpoint(node['endpoint'][branch_index],node['keys'],node['remote_stream'],float(node['remote_endpoint']),len(system.units))
                    for name,control in controls.items():
                        delta=(control['delta'][index,:,branch_index]-fine['delta'][index,:,branch_index]).sum(axis=0)
                        closed=endpoint@delta
                        physical=apply_correction(closed,maps['forward_correction'][branch_index],current['layout']['heavy'],current['layout']['size'])
                        encoded=from_physical(physical,maps,energy.size)*system.units
                        values=system.evaluate(efold,encoded,branch)[1]
                        differences[name][output_index,branch_index]=[values[channel] for channel in NAMES]
        rows=[]
        for name,difference in differences.items():
            for branch_index,branch in enumerate(BRANCHES):
                for column,channel in enumerate(NAMES):
                    absolute=float(np.max(abs(difference[:,branch_index,column])))
                    scale=max(float(np.max(abs(reference[:,branch_index,column]))),1e-80)
                    relative=absolute/scale
                    require(relative<GATE,'unchanged physical observable control gate')
                    rows.append(dict(control=name,branch=branch,channel=channel,absolute=absolute,relative=relative))
            np.savez_compressed(output/f'{model}-{name}.npz',efold=bank['efold'][selected],difference=difference,reference=reference)
        reports.append(dict(model=model,checks=rows))
        print(LABEL,model,'propagated observable uncertainty',max(row['relative'] for row in rows),flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'readout inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        direct_linear_differences=True,physical_gates_unchanged=True))


if __name__=='__main__':
    main()


