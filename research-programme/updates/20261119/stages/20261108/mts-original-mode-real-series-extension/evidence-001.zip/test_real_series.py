from common import *
from real_series import *
import time


def complex_value(splines,efold,theta):
    count=splines[0].c.shape[2]
    phase=np.exp(2j*np.fft.fftfreq(count,d=1/count)*theta)
    return np.array([np.einsum('p,pbi->bi',phase,spline(efold)).real for spline in splines])


def main():
    modest()
    output=STAGE/'representation-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    probes=[(fraction,theta) for fraction in (0.,.173,.5,.871,1.) for theta in (0.,.317,1.157,2.839,27.13)]
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),probes=probes,gate=ALGEBRA,no_modes_discarded=True))
    rng=np.random.default_rng(87142)
    synthetic=[]
    for count in (1,2,8,256):
        coefficients=rng.normal(size=(count,2,7))+1j*rng.normal(size=(count,2,7))
        converted,modes,use_sine=real_coefficients(coefficients)
        errors=[]
        for theta in (0.,.317,1.157,2.839,27.13):
            phase=np.exp(2j*np.fft.fftfreq(count,d=1/count)*theta)
            original=np.einsum('p,pbi->bi',phase,coefficients).real
            angle=2*modes*theta
            predicted=np.einsum('p,pbi->bi',np.where(use_sine,np.sin(angle),np.cos(angle)),converted)
            relative=float(np.linalg.norm(predicted-original)/max(np.linalg.norm(original),1e-80))
            require(relative<ALGEBRA,'full real identity including unconstrained imaginary and Nyquist coefficients')
            errors.append(relative)
        synthetic.append(dict(count=count,maximum=max(errors)))
    records=[]
    for label in ('half','balanced','double'):
        report_path=CONTINUATION/label/'forcing-02/result.json'
        report=read(report_path)
        consumed[str(report_path)]=digest(report_path)
        for model in ('heavy','cold'):
            nodes=next(row['nodes'] for row in report['reports'] if row['model']==model)
            arrays=[]
            for node in nodes:
                require(digest(node['path'])==node['sha256'],'retained forcing data sealed')
                consumed[node['path']]=node['sha256']
                with np.load(node['path']) as packet:
                    arrays.append({key:packet[key].copy() for key in ('normal_coefficients','map_coefficients')})
            epochs=np.array([node['efold'] for node in nodes])
            splines=[CubicSpline(epochs,np.array([item[key] for item in arrays])) for key in ('normal_coefficients','map_coefficients')]
            real=RealForcing(epochs,arrays)
            errors=[]
            started=time.perf_counter()
            previous=[complex_value(splines,float(epochs[0]+fraction*(epochs[-1]-epochs[0])),theta) for fraction,theta in probes]
            old_seconds=time.perf_counter()-started
            started=time.perf_counter()
            current=[real(float(epochs[0]+fraction*(epochs[-1]-epochs[0])),theta) for fraction,theta in probes]
            new_seconds=time.perf_counter()-started
            for old,new in zip(previous,current):
                relative=np.linalg.norm((old-new).reshape(2,2,-1),axis=2)/np.maximum(np.linalg.norm(old.reshape(2,2,-1),axis=2),1e-80)
                require(float(np.max(relative))<ALGEBRA,'unchanged per-component real-series equivalence gate')
                errors.append(float(np.max(relative)))
            records.append(dict(label=label,model=model,maximum=max(errors),complex_seconds=old_seconds,real_seconds=new_seconds,speedup=old_seconds/new_seconds,
                original_phase_count=len(arrays[0]['normal_coefficients']),no_truncation=True))
            print(records[-1],flush=True)
            del arrays,splines,real
    require(all(digest(path)==seal for path,seal in consumed.items()),'saved forcing unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,synthetic=synthetic,records=records,no_harmonic_truncation=True))


if __name__=='__main__':
    main()

