from common import *
from correlated_source import CorrelatedSource,reconstruct,BRANCHES
from scipy.integrate import solve_ivp
import numpy as np


def next_metadata(model):
    original=read(CONTINUATION/LABEL/'source-even-01/freeze.json')['metadata'][model]
    incoming_path=CONTINUATION/LABEL/'evolution-01'/f'{model}-fine.npz'
    previous_bank_path=CONTINUATION/LABEL/'source-even-01'/f'{model}-bank.npz'
    incoming=load(incoming_path)
    bank=load(previous_bank_path)
    start=float(incoming['efold'][-1])
    require(start==float(bank['efold'][-1]),'same saved candidate boundary')
    consumed={str(path):digest(path) for path in (incoming_path,previous_bank_path)}
    grid=None
    for row in original['reference']:
        require(digest(row['packet'])==row['sha256'],'original reference hash')
        consumed[row['packet']]=row['sha256']
        with np.load(row['packet']) as packet:
            candidate=packet['efold'].copy()
        require(grid is None or np.array_equal(grid,candidate),'paired reference epochs')
        grid=candidate
    first=int(bank['indices'][-1])
    require(grid[first]==start,'original reference index of candidate boundary')
    last=int(np.searchsorted(grid,start+.04,side='right')-1)
    require(last>first and last<len(grid),'bounded existing reference extension')
    indices=np.rint(np.linspace(first,last,33)).astype(int)
    require(len(np.unique(indices))==33,'unchanged source/probe counts')
    return dict(indices=indices.tolist(),efold=grid[indices].tolist(),reference=original['reference'],
        incoming_state=str(incoming_path),incoming_phase=float(bank['phase'][-1]),original_first_index=first,
        initial_error_source=str(CONTINUATION/'audit-02/result.json'),start=start,stop=float(grid[last]),
        span=float(grid[last]-start),reference_values_not_read_for_interval_selection=True),consumed


def continued_phase(source,efolds,initial,steps):
    if source.model=='cold':
        require(initial==0.,'baseline phase remains absent')
        return np.zeros(len(efolds)),0
    def rhs(efold,theta):
        guard()
        background=source.saved.mean(efold)
        slow,external=background['slow'][0],background['external'][0]
        omega=np.exp(efold)*source.saved.masses[1]
        reconstructed=reconstruct(float(background['heavy'][0]),float(external[0]),float(external[1]),float(slow[0]),float(slow[1]),omega,float(theta[0]))
        return [omega/float(reconstructed['hubble'])-1.5*np.sin(2*theta[0])]
    solved=solve_ivp(rhs,(efolds[0],efolds[-1]),[initial],method='DOP853',t_eval=efolds,rtol=2e-12,atol=2e-14,
        max_step=(efolds[-1]-efolds[0])/steps)
    require(solved.success and np.isfinite(solved.y).all(),'continued own phase solve')
    require(float(solved.y[0,0])==initial,'no phase reset at joining epoch')
    return solved.y[0],solved.nfev

