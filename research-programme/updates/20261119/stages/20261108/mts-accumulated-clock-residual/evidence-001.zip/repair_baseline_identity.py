from common import *
from accumulated_support_v2 import *
from scipy.integrate import solve_ivp
import time


def main():
    modest()
    require(LABEL=='half','inspect and repair completed half baseline only')
    output=ROOT/'baseline-identity-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    prepared_path=ROOT/'preparation-03/result.json'
    residual_path=ROOT/'residual-path-01/result.json'
    adjoint_path=ROOT/'adjoint-01/result.json'
    consumed={str(path):digest(path) for path in (prepared_path,residual_path,adjoint_path)}
    require(all(read(path)['passed'] for path in (prepared_path,residual_path,adjoint_path)),'retained completed calculations')
    owner=CorrelatedSource('cold')
    source,bank,leading,paths=retained_checked('cold')
    consumed.update(paths)
    consumed.update(owner.consumed)
    operator=DualOperator(owner,bank)
    residual_record=next(row for row in read(residual_path)['reports'] if row['model']=='cold')
    original_source=np.load(residual_record['path'],mmap_mode='r')
    metadata=load(residual_record['metadata'])
    for name,hash_name in (('path','sha256'),('metadata','metadata_sha256')):
        require(digest(residual_record[name])==residual_record[hash_name],'retained rounding-source bank')
        consumed[residual_record[name]]=residual_record[hash_name]
    product_path=ROOT/'preparation-03/cold-q-fine.npz'
    product=ProductForcing(load(product_path))
    consumed[str(product_path)]=digest(product_path)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,identity='cold has J=0, a=0, q=f exactly; evaluate q and f by the same original source',
        controls=[4096,2048,4096],rtol=2e-12,atol=2e-14,algebra=ALGEBRA,gate=GATE,
        existing_heavy_results_untouched=True,reuse_adjoint_operator_solutions=True))
    largest=0.
    for index,efold in enumerate(metadata['efold']):
        guard()
        force=source(float(efold),0.)
        rounding=force-product(float(efold))
        require(np.array_equal(rounding,original_source[index]),'entire previous baseline residual is product-evaluation roundoff')
        ratio=float(np.linalg.norm(rounding)/max(np.linalg.norm(force),1e-80))
        require(ratio<ALGEBRA,'same unchanged algebra gate for source equivalence')
        require(np.count_nonzero(force-force)==0,'exact cold phase-absence identity')
        largest=max(largest,ratio)
    del original_source
    normalization=np.linalg.norm(leading['state'][0],axis=1)
    start,stop=bank['efold'][[0,-1]]
    slow_runs=[]
    for control,steps in (('fine',4096),('step-coarse',2048),('source-coarse',4096)):
        started=time.monotonic()
        def rhs(efold,flat):
            guard()
            matrix,remote=operator.values(efold)
            return (operator.apply(flat.reshape(source.shape),matrix,remote)+source(efold,0.)/normalization[None,:,None]).ravel()
        solved=solve_ivp(rhs,(start,stop),np.zeros(np.prod(source.shape)),method='DOP853',t_eval=bank['efold'],
            rtol=2e-12,atol=2e-14,max_step=(stop-start)/steps)
        require(solved.success and np.isfinite(solved.y).all(),'exact cold mean response')
        eta=solved.y.T.reshape(-1,*source.shape)*normalization[None,None,:,None]
        path=output/f'cold-{control}.npz'
        np.savez_compressed(path,efold=bank['efold'],eta=eta,delta=eta,primitive=np.zeros_like(eta),phase=bank['phase'])
        slow_runs.append(dict(model='cold',control=control,path=str(path),sha256=digest(path),initial_error=0.,steps=steps,seconds=time.monotonic()-started))
        print('cold identity response frozen',control,time.monotonic()-started,flush=True)
    adjoint_runs=[]
    for report in read(adjoint_path)['reports']:
        if report['model']!='cold':
            continue
        require(digest(report['path'])==report['sha256'],'retained source-independent adjoint solution')
        consumed[report['path']]=report['sha256']
        old=load(report['path'])
        folder=output/('adjoint-'+report['control'])
        folder.mkdir(exist_ok=False)
        for index in range(64):
            old_path=Path(report['path']).parent/f'chunk-{index:03d}.npz'
            packet=load(old_path)
            consumed[str(old_path)]=digest(old_path)
            for name in packet:
                if name.startswith(('fine_','coarse_')):
                    packet[name]=np.zeros_like(packet[name])
            np.savez_compressed(folder/f'chunk-{index:03d}.npz',**packet)
        for name in old:
            if name.startswith(('fine_','coarse_')):
                old[name]=np.zeros_like(old[name])
        path=folder/'prediction.npz'
        np.savez_compressed(path,**old)
        adjoint_runs.append(dict(model='cold',control=report['control'],path=str(path),sha256=digest(path),chunks=64,
            source_independent_adjoint_reused_from=report['path'],exact_zero_reprojection=True))
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained sources unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,largest_source_rounding_relative=largest,
        samples=8193,slow_runs=slow_runs,adjoint_runs=adjoint_runs,exact_phase_absence=True,gate_unchanged=True,
        full_response_reference_not_read=True,baseline_physical_error_not_declared_zero=True))
    print('baseline zero residual derived; complete old source noise independently identified',largest,flush=True)


if __name__=='__main__':
    main()
