from common import *
from accumulated_support_v2 import *


def main():
    modest()
    output=ROOT/'comparison-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    reports={}
    for name in ('preparation-03','residual-path-01','slow-response-01','adjoint-01'):
        path=ROOT/name/'result.json'
        reports[name]=read(path)
        require(reports[name]['passed'],'completed prerequisite '+name)
        consumed[str(path)]=digest(path)
    records=[]
    predictions={}
    for model in ('heavy','cold'):
        terminal_path=ROOT/'preparation-03'/f'{model}-terminal.npz'
        terminal=load(terminal_path)
        consumed[str(terminal_path)]=digest(terminal_path)
        rows=terminal['rows']
        slow_runs=next(row['runs'] for row in reports['slow-response-01']['reports'] if row['model']==model)
        slow={}
        dual={}
        for run in slow_runs:
            require(digest(run['path'])==run['sha256'],'frozen slow prediction')
            consumed[run['path']]=run['sha256']
            slow[run['control']]=load(run['path'])
        for run in reports['adjoint-01']['reports']:
            if run['model']==model:
                require(digest(run['path'])==run['sha256'],'frozen adjoint prediction')
                consumed[run['path']]=run['sha256']
                dual[run['control']]=load(run['path'])
        full_path=record(consumed,CLOCK_STAGE/LABEL/'response-jobs'/f'{model}-fine/prediction.npz')
        original_path=record(consumed,CLOCK_STAGE/LABEL/'comparison-01'/f'{model}-comparison.npz')
        full=load(full_path)
        original=load(original_path)
        require(np.array_equal(full['efold'],slow['fine']['efold']),'identical original saved physical epochs')
        difference=full['eta'][-1]-slow['fine']['eta'][-1]
        observed=np.einsum('obd,cbd->cbo',rows,difference)
        signed=dual['fine']['fine_signed']
        budget=dual['fine']['fine_cauchy']
        component_budget=dual['fine']['fine_component_cauchy']
        reference_scale=np.maximum(np.max(abs(original['reference']),axis=0),1e-80)
        fine_delta=observed.sum(axis=0)
        candidate=original['predicted'][-1]-fine_delta
        candidate_error=abs(candidate-original['reference'][-1])/reference_scale
        baseline_scale=np.einsum('obd,cbd->cbo',abs(rows),abs(full['eta'][-1])+abs(slow['fine']['eta'][-1]))
        checks=[]
        for branch_index,branch in enumerate(BRANCHES):
            for column,channel in enumerate(NAMES):
                denominator=component_budget[:,branch_index,column].copy()
                if model=='cold':
                    denominator=np.maximum(denominator,baseline_scale[:,branch_index,column])
                denominator=np.maximum(denominator,1e-80)
                identity=float(np.max(abs(observed[:,branch_index,column]-signed[:,branch_index,column])/denominator))
                signed_scale=np.maximum(abs(observed[:,branch_index,column]),1e-80)
                strict_identity=float(np.max(abs(observed[:,branch_index,column]-signed[:,branch_index,column])/signed_scale))
                quadrature=float(np.max(abs(signed[:,branch_index,column]-dual['fine']['coarse_signed'][:,branch_index,column])/denominator))
                time_control=float(np.max(abs(signed[:,branch_index,column]-dual['step-coarse']['fine_signed'][:,branch_index,column])/denominator))
                cauchy_scale=max(float(budget[branch_index,column]),1e-80)
                cauchy_control=abs(float(budget[branch_index,column]-dual['fine']['coarse_cauchy'][branch_index,column]))/cauchy_scale
                cauchy_time=abs(float(budget[branch_index,column]-dual['step-coarse']['fine_cauchy'][branch_index,column]))/cauchy_scale
                absolute_control=abs(float(dual['fine']['fine_absolute'][branch_index,column]-dual['fine']['coarse_absolute'][branch_index,column]))/max(float(dual['fine']['fine_absolute'][branch_index,column]),1e-80)
                slow_controls={}
                for control in ('step-coarse','source-coarse'):
                    state_difference=slow[control]['eta'][-1,:,branch_index]-slow['fine']['eta'][-1,:,branch_index]
                    physical=float(np.sum(state_difference@rows[column,branch_index]))
                    slow_controls[control]=abs(physical)/reference_scale[branch_index,column]
                numerical_pass=max(identity,quadrature,time_control,cauchy_control,cauchy_time,*slow_controls.values())<GATE
                physical_pass=candidate_error[branch_index,column]<GATE
                record_row=dict(model=model,branch=branch,channel=channel,identity=identity,strict_signed_identity=strict_identity,
                    quadrature=quadrature,time_control=time_control,cauchy_quadrature=cauchy_control,cauchy_time=cauchy_time,
                    absolute_quadrature=absolute_control,absolute_quadrature_resolved=absolute_control<GATE,
                    signed_components=signed[:,branch_index,column].tolist(),forward_components=observed[:,branch_index,column].tolist(),
                    combined_absolute=float(dual['fine']['fine_absolute'][branch_index,column]),
                    cauchy_budget=float(budget[branch_index,column]),normalized_budget=float(budget[branch_index,column]/reference_scale[branch_index,column]),
                    normalized_observed=float(abs(fine_delta[branch_index,column])/reference_scale[branch_index,column]),
                    physical_reference_error=float(candidate_error[branch_index,column]),slow_controls=slow_controls,
                    numerical_pass=bool(numerical_pass),physical_pass=bool(physical_pass),
                    identity_scale='absolute response-component budget' if model=='heavy' else 'max absolute budget and rounding-scale response')
                checks.append(record_row)
                records.append(record_row)
        path=output/f'{model}-comparison.npz'
        np.savez_compressed(path,rows=rows,observed=observed,signed=signed,budget=budget,component_budget=component_budget,
            reference_scale=reference_scale,physical_candidate=candidate,original_full=original['predicted'][-1],reference=original['reference'][-1])
        predictions[model]=dict(path=str(path),sha256=digest(path))
        print(LABEL,model,'accumulated checks',sum(row['numerical_pass'] and row['physical_pass'] for row in checks),'of',len(checks),
            'max identity',max(row['identity'] for row in checks),'max budget',max(row['normalized_budget'] for row in checks),flush=True)
    all_pass=all(row['numerical_pass'] and row['physical_pass'] for row in records)
    write(output/'result.json',dict(passed=all_pass,inputs=inputs,sources=sources(),consumed=consumed,records=records,predictions=predictions,
        no_tolerance_relaxed=True,continuum_bound_claimed=False,full_physical_error_claimed=False))
    require(all_pass,'accumulated comparison gates; preserve diagnostics and inspect before further work')


if __name__=='__main__':
    main()
