from common import *
from accumulated_support_v2 import *
from scipy.integrate import solve_ivp
import time


def main():
    modest()
    output=ROOT/'residual-path-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    preparation=ROOT/'preparation-03/result.json'
    qualified=read(preparation)
    require(qualified['passed'],'qualified mean and endpoint preparation')
    consumed={str(preparation):digest(preparation)}
    for path,seal in qualified['artifacts'].items():
        require(digest(path)==seal,'prepared source unchanged')
        consumed[path]=seal
    kernel_path=record(consumed,CLOCK_STAGE/'kernel-bank-01/heavy-kernels.npz')
    kernel=KernelBank(load(kernel_path))
    reports=[]
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,quadrature_intervals=8192,subset_intervals=4096,
        physical_phase_method='original equation and original incoming phase; no spline extrapolation',gate=GATE,algebra=ALGEBRA,
        no_full_response_reference_read=True))
    for model in ('heavy','cold'):
        started=time.monotonic()
        owner=CorrelatedSource(model)
        source,bank,leading,paths=retained_checked(model)
        consumed.update(paths)
        consumed.update(owner.consumed)
        operator=DualOperator(owner,bank)
        slow=ProductForcing(load(ROOT/'preparation-03'/f'{model}-q-fine.npz'))
        start,stop=bank['efold'][[0,-1]]
        epochs=np.linspace(start,stop,8193)
        union=np.unique(np.concatenate([epochs,bank['efold']]))
        if model=='heavy':
            def phase_rhs(efold,state):
                guard()
                background=owner.saved.mean(efold)
                scalar=background['slow'][0]
                external=background['external'][0]
                omega=np.exp(efold)*owner.saved.masses[1]
                from correlated_source import reconstruct
                rebuilt=reconstruct(float(background['heavy'][0]),float(external[0]),float(external[1]),float(scalar[0]),float(scalar[1]),omega,state[0])
                return [omega/float(rebuilt['hubble'])-1.5*np.sin(2*state[0])]
            solved=solve_ivp(phase_rhs,(start,stop),[bank['phase'][0]],method='DOP853',t_eval=union,
                rtol=2e-12,atol=2e-14,max_step=(stop-start)/4096)
            require(solved.success and np.isfinite(solved.y).all(),'same physical phase solve')
            phase=solved.y[0,np.searchsorted(union,epochs)]
            original_phase=solved.y[0,np.searchsorted(union,bank['efold'])]
            phase_error=float(np.max(abs(original_phase-bank['phase'])))
        else:
            phase=np.zeros(len(epochs))
            phase_error=0.
        require(phase_error<ALGEBRA,'original phase at all saved nodes')
        target=output/f'{model}-g.npy'
        buffer=np.lib.format.open_memmap(target,mode='w+',dtype=np.float64,shape=(len(epochs),*source.shape))
        maximum=0.
        initial_primitive=None
        for index,(efold,angle) in enumerate(zip(epochs,phase)):
            guard()
            if model=='heavy':
                mean,primitive,derivative=kernel.response(source,float(efold),float(angle))
            else:
                mean=source(float(efold),0.)
                primitive=np.zeros_like(mean)
                derivative=np.zeros_like(mean)
            matrix,remote=operator.values(float(efold))
            slow_force=source(float(efold),0.) if model=='cold' else slow(float(efold))
            residual=operator.apply(primitive,matrix,remote)-derivative+mean-slow_force
            require(np.isfinite(residual).all(),'finite complete residual')
            buffer[index]=residual
            maximum=max(maximum,float(np.max(np.linalg.norm(residual,axis=-1))))
            if index==0:
                initial_primitive=primitive.copy()
            if index%1024==0:
                buffer.flush()
                print(LABEL,model,'residual path',index,'of',8192,flush=True)
        buffer.flush()
        del buffer
        metadata=output/f'{model}-path.npz'
        np.savez_compressed(metadata,efold=epochs,phase=phase,initial_primitive=initial_primitive,terminal_primitive=primitive)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),metadata=str(metadata),metadata_sha256=digest(metadata),
            phase_error=phase_error,maximum_source_norm=maximum,seconds=time.monotonic()-started,shape=[len(epochs),*source.shape]))
        print(LABEL,model,'full retained residual saved',time.monotonic()-started,flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        identity='g=M J-J_N+fbar-q; interpolated drift error stays in g',all_forcing_components_retained=True))


if __name__=='__main__':
    main()
