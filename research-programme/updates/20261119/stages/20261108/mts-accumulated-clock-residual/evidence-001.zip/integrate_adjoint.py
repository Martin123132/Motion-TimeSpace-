from common import *
from accumulated_support_v2 import *
from scipy.integrate import solve_ivp,simpson
import time


def integrate_chunk(epochs,projected):
    total=projected.sum(axis=1)
    length=float(epochs[-1]-epochs[0])
    signed=simpson(projected,x=epochs,axis=0)
    absolute=simpson(abs(total),x=epochs,axis=0)
    component_absolute=simpson(abs(projected),x=epochs,axis=0)
    square=simpson(total**2,x=epochs,axis=0)
    component_square=simpson(projected**2,x=epochs,axis=0)
    return dict(signed=signed,absolute=absolute,component_absolute=component_absolute,
        cauchy=np.sqrt(length*np.maximum(square,0.)),component_cauchy=np.sqrt(length*np.maximum(component_square,0.)))


def main():
    modest()
    output=ROOT/'adjoint-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    preparation=ROOT/'preparation-03/result.json'
    residual_path=ROOT/'residual-path-01/result.json'
    prepared=read(preparation)
    residual_report=read(residual_path)
    require(prepared['passed'] and residual_report['passed'],'qualified fixed residual and terminal rows')
    consumed={str(path):digest(path) for path in (preparation,residual_path)}
    for path,seal in prepared['artifacts'].items():
        require(digest(path)==seal,'fixed prepared input')
        consumed[path]=seal
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,physical_channels=list(NAMES),
        controls=[4096,2048],quadrature_controls=[8192,4096],chunks=64,rtol=2e-12,atol=2e-14,
        full_response_reference_not_read=True,algebra=ALGEBRA,gate=GATE))
    reports=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        source,bank,leading,paths=retained_checked(model)
        consumed.update(paths)
        consumed.update(owner.consumed)
        operator=DualOperator(owner,bank)
        terminal=load(ROOT/'preparation-03'/f'{model}-terminal.npz')
        rows=terminal['rows']
        row_norm=np.linalg.norm(rows,axis=-1)
        require(np.all(row_norm>0),'nonzero physical terminal duals')
        record=next(record for record in residual_report['reports'] if record['model']==model)
        for name,hash_name in (('path','sha256'),('metadata','metadata_sha256')):
            require(digest(record[name])==record[hash_name],'frozen complete residual source')
            consumed[record[name]]=record[hash_name]
        metadata=load(record['metadata'])
        source_values=np.load(record['path'],mmap_mode='r')
        epochs=metadata['efold']
        require(len(epochs)==8193 and source_values.shape[1:]==source.shape,'full auxiliary quadrature coverage')
        start,stop=epochs[[0,-1]]
        for control,steps in (('fine',4096),('step-coarse',2048)):
            target=output/f'{model}-{control}'
            target.mkdir(exist_ok=False)
            state=rows/row_norm[:,:,None]
            sums=None
            coarse_sums=None
            total_evaluations=0
            started=time.monotonic()
            for chunk in range(64):
                guard()
                high=8192-128*chunk
                low=high-128
                times=epochs[low:high+1]
                def rhs(efold,flat):
                    guard()
                    matrix,remote=operator.values(float(efold))
                    return -operator.transpose(flat.reshape(rows.shape),matrix,remote).ravel()
                solved=solve_ivp(rhs,(times[-1],times[0]),state.ravel(),method='DOP853',t_eval=times[::-1],
                    rtol=2e-12,atol=2e-14,max_step=(stop-start)/steps)
                require(solved.success and np.isfinite(solved.y).all(),'full hierarchy backward adjoint')
                total_evaluations+=solved.nfev
                dual=solved.y.T[::-1].reshape(len(times),*rows.shape)
                projected=np.einsum('pcbd,pobd->pcbo',source_values[low:high+1],dual,optimize=True)*row_norm.T[None,None,:,:]
                fine=integrate_chunk(times,projected)
                coarse=integrate_chunk(times[::2],projected[::2])
                state=solved.y[:,-1].reshape(rows.shape).copy()
                if sums is None:
                    sums={name:values.copy() for name,values in fine.items()}
                    coarse_sums={name:values.copy() for name,values in coarse.items()}
                else:
                    for name in sums:
                        sums[name]+=fine[name]
                        coarse_sums[name]+=coarse[name]
                np.savez_compressed(target/f'chunk-{chunk:03d}.npz',left=times[0],right=times[-1],lambda_left=state,
                    **{'fine_'+name:values for name,values in fine.items()},
                    **{'coarse_'+name:values for name,values in coarse.items()})
                if chunk%8==0:
                    print(LABEL,model,control,'adjoint chunks',chunk+1,'of64',flush=True)
                del solved,dual,projected
            signed=sums['signed'].sum(axis=0)
            require(np.all(abs(signed)<=sums['absolute']*(1+ALGEBRA)+1e-80),'discrete absolute triangle inequality')
            require(np.all(sums['absolute']<=sums['cauchy']*(1+ALGEBRA)+1e-80),'discrete Cauchy bound')
            path=target/'prediction.npz'
            np.savez_compressed(path,lambda_initial=state*row_norm[:,:,None],row_norm=row_norm,
                **{'fine_'+name:values for name,values in sums.items()},
                **{'coarse_'+name:values for name,values in coarse_sums.items()})
            report=dict(model=model,control=control,path=str(path),sha256=digest(path),nfev=total_evaluations,
                seconds=time.monotonic()-started,chunks=64,quadrature_intervals=8192,steps=steps,full_response_reference_not_read=True)
            write(target/'result.json',dict(passed=True,**report))
            reports.append(report)
            print(LABEL,model,control,'adjoint signed/absolute predictions frozen',report['seconds'],flush=True)
        del source_values
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        no_missing_tail=True,full_response_reference_not_read=True,continuum_certification=False))


if __name__=='__main__':
    main()
