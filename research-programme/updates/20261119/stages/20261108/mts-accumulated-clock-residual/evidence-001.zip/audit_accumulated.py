from common import *
import numpy as np


def relative(candidate,reference):
    return float(np.linalg.norm(candidate-reference)/max(np.linalg.norm(candidate),np.linalg.norm(reference),1e-80))


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed={}
    accepted={}
    comparisons=[]
    preparation_rows=[]
    chunk_count=0

    def accept(path):
        report=read(path)
        require(report['passed'],'accepted report '+str(path))
        accepted[str(path)]=digest(path)
        for name in ('inputs','sources','consumed'):
            for source,seal in report[name].items():
                require(digest(source)==seal,'accepted dependency unchanged '+source)
                consumed[source]=seal
        return report

    for label in ('half','balanced','double'):
        root=STAGE/label
        prepared=accept(root/'preparation-03/result.json')
        for path,seal in prepared['artifacts'].items():
            require(digest(path)==seal,'exact prepared artifact')
            consumed[path]=seal
        for report in prepared['reports']:
            require(len(report['duality'])==6 and len(report['terminal_rows'])==6,'complete independent dual coverage')
            require(all(max(row['sparse'],row['duality'])<ALGEBRA for row in report['duality']),'independent full sparse transpose')
            require(all(row['relative']<ALGEBRA for row in report['terminal_rows']),'independent native terminal maps')
            require(all(max(row['fine'],row['coarse'],row['primitive'])<GATE for row in report['interpolation']),'derived mean controls')
            require(report['product_maximum']<ALGEBRA and all(row['relative']<ALGEBRA for row in report['product_checks']),'unchanged exact source products')
            preparation_rows.append(dict(label=label,**report))
        residual=accept(root/'residual-path-01/result.json')
        for row in residual['reports']:
            require(row['phase_error']<ALGEBRA and row['shape'][0]==8193,'original physical phase and auxiliary coverage')
            for name,hash_name in (('path','sha256'),('metadata','metadata_sha256')):
                require(digest(row[name])==row[hash_name],'source path integrity')
                consumed[row[name]]=row[hash_name]
            source=np.load(row['path'],mmap_mode='r')
            require(list(source.shape)==row['shape'] and np.isfinite(source).all(),'complete finite residual path')
            del source
        slow=accept(root/'slow-response-01/result.json')
        for report in slow['reports']:
            require({row['control'] for row in report['runs']}=={'fine','step-coarse','source-coarse'},'all slow controls')
            for row in report['runs']:
                require(digest(row['path'])==row['sha256'] and row['initial_error']<ALGEBRA,'same incoming offset and frozen slow prediction')
                consumed[row['path']]=row['sha256']
        adjoint=accept(root/'adjoint-01/result.json')
        require(len(adjoint['reports'])==4,'paired time-refined adjoints')
        for report in adjoint['reports']:
            require(digest(report['path'])==report['sha256'] and report['chunks']==64,'frozen adjoint prediction and coverage')
            consumed[report['path']]=report['sha256']
            prediction=load(report['path'])
            folder=Path(report['path']).parent
            previous_left=None
            totals={}
            for index in range(64):
                path=folder/f'chunk-{index:03d}.npz'
                packet=load(path)
                require(float(packet['right'])>float(packet['left']),'oriented adjoint chunk')
                if previous_left is not None:
                    require(float(packet['right'])==previous_left,'no chunk gap or duplicate')
                previous_left=float(packet['left'])
                for name,value in packet.items():
                    if name.startswith(('fine_','coarse_')):
                        totals[name]=totals.get(name,np.zeros_like(value))+value
                if index==63:
                    require(relative(packet['lambda_left']*prediction['row_norm'][:,:,None],prediction['lambda_initial'])<ALGEBRA,'full initial adjoint retained')
                consumed[str(path)]=digest(path)
                chunk_count+=1
            for name,value in totals.items():
                require(relative(value,prediction[name])<ALGEBRA,'independently summed adjoint budget')
            require(np.all(abs(prediction['fine_signed'].sum(axis=0))<=prediction['fine_absolute']*(1+ALGEBRA)+1e-80),'signed/absolute inequality')
            require(np.all(prediction['fine_absolute']<=prediction['fine_cauchy']*(1+ALGEBRA)+1e-80),'absolute/Cauchy inequality')
        comparison=accept(root/'comparison-01/result.json')
        require(len(comparison['records'])==40,'all paired terminal physical channels')
        for model in ('heavy','cold'):
            packet=load(comparison['predictions'][model]['path'])
            require(digest(comparison['predictions'][model]['path'])==comparison['predictions'][model]['sha256'],'frozen physical comparison')
            consumed[comparison['predictions'][model]['path']]=comparison['predictions'][model]['sha256']
            full=load(CLOCK_STAGE/label/'response-jobs'/f'{model}-fine/prediction.npz')
            current=load(root/'slow-response-01'/f'{model}-fine.npz')
            observed=np.einsum('obd,cbd->cbo',packet['rows'],full['eta'][-1]-current['eta'][-1])
            require(relative(observed,packet['observed'])<ALGEBRA,'independent full/slow physical difference')
            require(relative(packet['original_full']-observed.sum(axis=0),packet['physical_candidate'])<ALGEBRA,'same terminal physical reconstruction')
        for row in comparison['records']:
            require(row['numerical_pass'] and row['physical_pass'],'reported unchanged gates')
            require(max(row['identity'],row['quadrature'],row['time_control'],row['cauchy_quadrature'],row['cauchy_time'],
                row['physical_reference_error'],*row['slow_controls'].values())<GATE,'recomputed acceptance from stored diagnostics')
            comparisons.append(dict(label=label,**row))
    require(len(comparisons)==120 and len(preparation_rows)==6 and chunk_count==768,'complete planned matrix')
    failures={'prepare-half-01':'all original forcing knots in product subdivision',
              'prepare-half-02':"'NoneType' object is not subscriptable"}
    for phase,message in failures.items():
        require(message in (STAGE/f'{phase}.stderr.log').read_text(),'documented inspected preparation failure')
    for path in STAGE.glob('*.start.json'):
        phase=path.name.replace('.start.json','')
        if phase=='audit-01':
            continue
        start=read(path)
        end=read(STAGE/f'{phase}.end.json')
        require(start['pid']==end['pid'] and start['created']==end['created'],'same worker identity')
        require(end['exit_code']==(1 if phase in failures else 0),'only inspected failed attempts')
        require(digest(start['source_path'])==start['source_sha256'],'executed sources preserved')
    require(not list(STAGE.glob('*.not-started.json')),'full matrix has no deferred job')
    for path in STAGE.rglob('freeze.json'):
        for source,seal in read(path)['sources'].items():
            require(digest(source)==seal,'all historical frozen code retained')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode residue')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        comparisons=comparisons,preparation=preparation_rows,chunk_count=chunk_count,
        failed_attempts_preserved=list(failures),compiler_receipts=[],physical_approximation_all_pass=True,
        original_preparation_preserved=True,original_banks_and_gates_unchanged=True,continuum_certificate=False,
        inherited_source_and_background_errors_not_erased=True,github_actions=False))
    print('complete paired accumulated-response audit accepted',len(comparisons),chunk_count,flush=True)


if __name__=='__main__':
    main()
