from common import *
from transformed_support import retained,MeanOperator
from clock_primitive import KernelBank,basis,phase_clock,kernels,CorrelatedSource,COUNT
from scipy.interpolate import CubicSpline
from scipy.sparse import coo_matrix
import math
import numpy as np

NAMES=('Phi','Psi','D','Q','Pi','theta_c','delta_c','delta_b','delta_gamma','delta_massless')
BRANCHES=('gr','poisson-spatial')


def relative(candidate,reference):
    return float(np.linalg.norm(np.asarray(candidate)-np.asarray(reference))/max(np.linalg.norm(candidate),np.linalg.norm(reference),1e-80))


def record(consumed,path):
    path=owned(path)
    consumed[str(path)]=digest(path)
    return path


def retained_checked(model):
    source,bank,leading,paths=retained(model)
    for path in paths:
        owned(path)
    return source,bank,leading,paths


class DualOperator(MeanOperator):
    def transpose(self,vector,matrix,weights):
        result=np.zeros_like(vector)
        result[:,:,:self.compact]=np.einsum('bij,cbi->cbj',matrix,vector[:,:,:self.compact])
        for channel in range(vector.shape[0]):
            for branch in range(2):
                result[channel,branch]+=np.bincount(self.columns,weights*vector[channel,branch,self.rows],minlength=vector.shape[-1])
        return result

    def assembled(self,matrix,weights,dimension,branch):
        indices=np.indices((self.compact,self.compact))
        rows=np.concatenate([indices[0].ravel(),self.rows])
        columns=np.concatenate([indices[1].ravel(),self.columns])
        values=np.concatenate([matrix[branch].ravel(),weights])
        return coo_matrix((values,(rows,columns)),shape=(dimension,dimension)).tocsr()


class ProductForcing:
    def __init__(self,packet):
        self.epochs=packet['epochs']
        self.coefficients=packet['coefficients']
        self.shape=tuple(int(value) for value in packet['shape'])

    def __call__(self,efold):
        require(self.epochs[0]-1e-13<=efold<=self.epochs[-1]+1e-13,'forcing product domain')
        index=int(np.clip(np.searchsorted(self.epochs,efold,side='right')-1,0,len(self.epochs)-2))
        width=self.epochs[index+1]-self.epochs[index]
        local=(efold-(self.epochs[index]+self.epochs[index+1])/2)/width
        answer=self.coefficients[index,-1].copy()
        for coefficient in self.coefficients[index,-2::-1]:
            answer=answer*local+coefficient
        return answer.reshape(self.shape)


def product_packet(source,epochs,mean=None,drift=None):
    coefficients=[]
    for left,right in zip(epochs[:-1],epochs[1:]):
        midpoint=float((left+right)/2)
        width=right-left
        source_parts=[source.spline(midpoint,degree)*width**degree/math.factorial(degree) for degree in range(4)]
        if mean is None:
            rows=[np.ones(1),np.zeros(1),np.zeros(1),np.zeros(1)]
        else:
            rows=[(mean(midpoint,degree)+drift(midpoint,degree))*width**degree/math.factorial(degree) for degree in range(4)]
        current=np.zeros((7,source_parts[0].shape[-1]))
        for row_degree in range(4):
            for source_degree in range(4):
                current[row_degree+source_degree]+=rows[row_degree]@source_parts[source_degree]
        coefficients.append(current)
    return dict(epochs=np.array(epochs),coefficients=np.array(coefficients),shape=np.array(source.shape))


def drift_row(owner,efold,kernel_coefficients,modes,sine,count=COUNT):
    angles=np.arange(count)*np.pi/count
    speed,speed_rate,bounds=phase_clock(owner,float(efold),angles)
    probability=(1/speed)/(1/speed).sum()
    angular=basis(angles,modes,sine)
    row=-((probability*speed_rate/speed)@angular)@kernel_coefficients
    return row,bounds


def terminal_rows(model,bank,owner,folder):
    from matching_source import frozen_source,apply_correction,from_physical
    from correlated_source import correlated,full_endpoint
    from adjoint_operator import open_owned
    from physical_energy_map import PhysicalEnergyMap
    from matched_cold_fibre import MatchedColdFibre
    system=open_owned(model,folder+'/contexts')
    require(abs(system.wave/WAVE-1)<ALGEBRA,'original wavenumber ownership')
    energy=PhysicalEnergyMap(system)
    dimension=len(system.units)
    efold=float(bank['efold'][-1])
    theta=float(bank['phase'][-1])
    frozen=owner.frozen(efold)
    if model=='heavy':
        frozen,_=correlated(frozen,theta)
    state=np.array([efold,frozen['values'][0]/(np.exp(efold)*owner.saved.masses[0]),*frozen['values'][1:]])
    node_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-32-mean.npz')
    node=load(node_path)
    consumed={str(node_path):digest(node_path)}
    rows=np.zeros((len(NAMES),2,dimension))
    checks=[]
    generator=np.random.default_rng(917204)
    with MatchedColdFibre(system) as fibre:
        fibre.chart_angle=float(system.owner.phase(efold)[0]) if model=='heavy' else 0.
        current,maps,point,direct,paths=frozen_source(fibre,energy,state,theta)
        consumed.update(paths)
        for branch_index,branch in enumerate(BRANCHES):
            zero=system.evaluate(efold,np.zeros(dimension),branch)[1]
            require(all(zero[name]==0 for name in NAMES),'linear native zero readout')
            native_rows=np.empty((len(NAMES),dimension))
            for column in range(dimension):
                vector=np.zeros(dimension)
                vector[column]=system.units[column]
                output=system.evaluate(efold,vector,branch)[1]
                native_rows[:,column]=[output[name] for name in NAMES]
            physical_rows=native_rows.copy()
            physical_rows[:,:energy.size]=native_rows[:,:energy.size]@maps['inverse']
            physical_rows[:,energy.size:]=native_rows[:,energy.size:]/maps['tail_weights'][None,:]
            closed_rows=physical_rows.copy()
            if len(current['layout']['heavy']):
                closed_rows[:,:current['layout']['size']]+=physical_rows[:,current['layout']['heavy']]@maps['forward_correction'][branch_index]
            endpoint=full_endpoint(node['endpoint'][branch_index],node['keys'],node['remote_stream'],float(node['remote_endpoint']),dimension)
            rows[:,branch_index]=(endpoint.T@closed_rows.T).T
            for trial in range(3):
                vector=generator.normal(size=dimension)
                closed=endpoint@vector
                physical=apply_correction(closed,maps['forward_correction'][branch_index],current['layout']['heavy'],current['layout']['size'])
                native=from_physical(physical,maps,energy.size)*system.units
                expected=system.evaluate(efold,native,branch)[1]
                expected=np.array([expected[name] for name in NAMES])
                predicted=rows[:,branch_index]@vector
                scale=np.linalg.norm(rows[:,branch_index],axis=1)*np.linalg.norm(vector)
                error=float(np.max(abs(predicted-expected)/np.maximum(scale,1e-80)))
                require(error<ALGEBRA,'complete terminal physical dual map')
                checks.append(dict(branch=branch,trial=trial,relative=error))
    return rows,checks,consumed
