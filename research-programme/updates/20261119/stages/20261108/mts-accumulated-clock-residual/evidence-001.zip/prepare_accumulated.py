from common import *
from accumulated_support import *
import time


def main():
    modest()
    output=ROOT/'preparation-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    inputs=verify_inputs()
    consumed={}
    kernel_path=record(consumed,CLOCK_STAGE/'kernel-bank-01/heavy-kernels.npz')
    kernel_packet=load(kernel_path)
    kernel=KernelBank(kernel_packet)
    reports=[]
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),target='all ten original terminal readouts; both branches and models',
        phase_nodes=513,source_mean_nodes=65,coarse_nodes=33,quadrature_intervals=8192,time_steps=[4096,2048],algebra=ALGEBRA,gate=GATE))
    for model in ('heavy','cold'):
        guard()
        started=time.monotonic()
        owner=CorrelatedSource(model)
        source,bank,leading,paths=retained_checked(model)
        consumed.update(paths)
        consumed.update(owner.consumed)
        dimension=source.shape[-1]
        operator=DualOperator(owner,bank)
        dual_checks=[]
        generator=np.random.default_rng(119082)
        for fraction in (.173,.463,.827):
            efold=float(bank['efold'][0]+fraction*(bank['efold'][-1]-bank['efold'][0]))
            matrix,remote=operator.values(efold)
            left=generator.normal(size=(3,2,dimension))
            right=generator.normal(size=(3,2,dimension))
            forward=operator.apply(right,matrix,remote)
            transposed=operator.transpose(left,matrix,remote)
            for branch_index,branch in enumerate(BRANCHES):
                assembled=operator.assembled(matrix,remote,dimension,branch_index)
                sparse_error=max(relative(forward[:,branch_index],(assembled@right[:,branch_index].T).T),
                    relative(transposed[:,branch_index],(assembled.T@left[:,branch_index].T).T))
                dual_error=float(np.max(abs(np.sum(left[:,branch_index]*forward[:,branch_index],axis=1)-np.sum(transposed[:,branch_index]*right[:,branch_index],axis=1))/
                    np.maximum(np.linalg.norm(left[:,branch_index],axis=1)*np.linalg.norm(forward[:,branch_index],axis=1),1e-80)))
                require(max(sparse_error,dual_error)<ALGEBRA,'full hierarchy transpose and independent sparse action')
                dual_checks.append(dict(fraction=fraction,branch=branch,sparse=sparse_error,duality=dual_error))
        interpolation=[]
        if model=='heavy':
            epochs=kernel_packet['efold']
            require(max(abs(epochs[[0,-1]]-bank['efold'][[0,-1]]))<ALGEBRA,'same clock interval')
            for knot in source.spline.x:
                require(np.min(abs(epochs-knot))<1e-13,'all original forcing knots in product subdivision')
            drift=[]
            for index,efold in enumerate(epochs):
                guard()
                row,_=drift_row(owner,efold,kernel_packet['coefficients'][index],kernel_packet['modes'],kernel_packet['sine'])
                drift.append(row)
            drift=np.array(drift)
            fine=CubicSpline(epochs,drift)
            coarse=CubicSpline(epochs[::2],drift[::2])
            for fraction in (.173,.463,.827):
                efold=float(epochs[0]+fraction*(epochs[-1]-epochs[0]))
                direct=kernels(owner,efold)
                expected,_=drift_row(owner,efold,direct['coefficients'],direct['modes'],direct['sine'])
                full,_=drift_row(owner,efold,kernel.kernel(efold),kernel.modes,kernel.sine)
                errors=dict(fine=relative(fine(efold),expected),coarse=relative(coarse(efold),expected),primitive=relative(full,expected))
                require(max(errors.values())<GATE,'derived mean-row interpolation unchanged gate')
                interpolation.append(dict(fraction=fraction,**errors))
            np.savez_compressed(output/f'{model}-drift.npz',epochs=epochs,drift=drift)
            packets=[product_packet(source,epochs,kernel.mean,evaluator) for evaluator in (fine,coarse)]
        else:
            epochs=source.spline.x
            packets=[product_packet(source,epochs),product_packet(source,epochs)]
        product_checks=[]
        for name,packet in zip(('fine','source-coarse'),packets):
            evaluator=ProductForcing(packet)
            for left,right in zip(epochs[:-1],epochs[1:]):
                for fraction in (.173,.827):
                    efold=float(left+fraction*(right-left))
                    expected=source(efold,0.) if model=='cold' else ((kernel.mean(efold)+(fine if name=='fine' else coarse)(efold))@source.spline(efold)).reshape(source.shape)
                    error=relative(evaluator(efold),expected)
                    require(error<ALGEBRA,'degree-six product equals retained cubic factors')
                    product_checks.append(dict(control=name,efold=efold,relative=error))
            np.savez_compressed(output/f'{model}-q-{name}.npz',**packet)
        rows,row_checks,paths=terminal_rows(model,bank,owner,'preparation-01')
        consumed.update(paths)
        require(rows.shape==(10,2,dimension),'all ten physical channels')
        np.savez_compressed(output/f'{model}-terminal.npz',rows=rows,efold=bank['efold'],names=np.array(NAMES),branches=np.array(BRANCHES),state_scale=np.linalg.norm(leading['state'][0],axis=1))
        reports.append(dict(model=model,dimension=dimension,duality=dual_checks,terminal_rows=row_checks,interpolation=interpolation,
            product_maximum=max(row['relative'] for row in product_checks),product_checks=product_checks,seconds=time.monotonic()-started))
        print(LABEL,model,'derived mean, exact product and physical terminal duals qualified',time.monotonic()-started,flush=True)
    artifacts={str(path):digest(path) for path in output.glob('*.npz')}
    require(all(digest(path)==seal for path,seal in consumed.items()),'source input preservation')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,artifacts=artifacts,
        fixed_physical_inputs=True,full_hierarchy=True,reference_response_not_read=True))


if __name__=='__main__':
    main()
