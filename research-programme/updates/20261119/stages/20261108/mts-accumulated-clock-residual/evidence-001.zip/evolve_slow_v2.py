from common import *
from accumulated_support_v2 import *
from scipy.integrate import solve_ivp
import time


def main():
    modest()
    output=ROOT/'slow-response-01'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    preparation=ROOT/'preparation-03/result.json'
    qualified=read(preparation)
    require(qualified['passed'],'qualified exact source products')
    consumed={str(preparation):digest(preparation)}
    for path,seal in qualified['artifacts'].items():
        require(digest(path)==seal,'prepared product unchanged')
        consumed[path]=seal
    kernel_path=record(consumed,CLOCK_STAGE/'kernel-bank-01/heavy-kernels.npz')
    kernel=KernelBank(load(kernel_path))
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed,time_steps=[4096,2048],rtol=2e-12,atol=2e-14,
        incoming_eta='minus original primitive, not zero',no_full_response_reference_read=True,gate=GATE,algebra=ALGEBRA))
    reports=[]
    for model in ('heavy','cold'):
        owner=CorrelatedSource(model)
        source,bank,leading,paths=retained_checked(model)
        consumed.update(paths)
        consumed.update(owner.consumed)
        operator=DualOperator(owner,bank)
        normalization=np.linalg.norm(leading['state'][0],axis=1)
        start,stop=bank['efold'][[0,-1]]
        primitive=np.array([kernel.response(source,float(efold),float(theta))[1] for efold,theta in zip(bank['efold'],bank['phase'])]) if model=='heavy' else np.zeros((len(bank['efold']),*source.shape))
        initial=-primitive[0]/normalization[None,:,None]
        records=[]
        for control in ('fine','step-coarse','source-coarse'):
            guard()
            product=ProductForcing(load(ROOT/'preparation-03'/f"{model}-q-{'source-coarse' if control=='source-coarse' else 'fine'}.npz"))
            steps=2048 if control=='step-coarse' else 4096
            def rhs(efold,flat):
                guard()
                state=flat.reshape(source.shape)
                matrix,remote=operator.values(efold)
                return (operator.apply(state,matrix,remote)+product(efold)/normalization[None,:,None]).ravel()
            started=time.monotonic()
            solved=solve_ivp(rhs,(start,stop),initial.ravel(),method='DOP853',t_eval=bank['efold'],
                rtol=2e-12,atol=2e-14,max_step=(stop-start)/steps)
            require(solved.success and np.isfinite(solved.y).all(),'slow derived response integration')
            eta=solved.y.T.reshape(-1,*source.shape)*normalization[None,None,:,None]
            delta=eta+primitive
            target=output/f'{model}-{control}.npz'
            np.savez_compressed(target,efold=bank['efold'],eta=eta,delta=delta,primitive=primitive,phase=bank['phase'])
            initial_error=float(np.max(np.linalg.norm(delta[0],axis=-1)/normalization[None,:]))
            require(initial_error<ALGEBRA,'same original incoming increment')
            records.append(dict(control=control,path=str(target),sha256=digest(target),seconds=time.monotonic()-started,
                nfev=solved.nfev,initial_error=initial_error,steps=steps))
            print(LABEL,model,control,'slow response frozen',time.monotonic()-started,flush=True)
        reports.append(dict(model=model,runs=records))
    require(all(digest(path)==seal for path,seal in consumed.items()),'source preservation')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        full_response_reference_not_read=True,physical_initial_mode_preserved=True))


if __name__=='__main__':
    main()
