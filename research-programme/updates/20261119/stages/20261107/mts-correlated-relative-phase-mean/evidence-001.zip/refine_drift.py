from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from phase_fibre import PhaseFibre
from fibre_operator import at_state
from mean_math import reduced_operator
from collect_stable import live_rows
from refined_analysis import analyze
from run_native import native_provenance
import numpy as np


def main():
    modest()
    require(LABEL=='half','diagnosed derivative refinement')
    output=ROOT/'refined-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    prior=read(ROOT/'stable-01/result.json')
    require(not prior['passed'] and prior['errors']['gr_drift_width']<GATE,'diagnosed branch-specific remainder')
    bank=load(ROOT/'stable-01/center.npz')
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),
        previous_result=digest(ROOT/'stable-01/result.json'),phase_orders=[64,128,256],
        derivative_widths=[.001,.0005],new_samples='only plus/minus0.0005 in the two physical directions',
        inner_width=.01,numerical=GATE,algebra=ALGEBRA,
        scope='controlled derivative refinement after cancellation repair, not a retry or changed physical history grid'))
    system=open_owned('heavy','refined-01/contexts')
    energy=PhysicalEnergyMap(system)
    state=bank['state']
    before=system.context['point'](float(state[0])).copy()
    repairs={}
    with PhaseFibre(system,float(state[0])) as fibre:
        fibre.install(state,np.pi/4)
        flow0=fibre.flow.copy()
        flow0[3]=-state[3]
        flowc=np.zeros(5)
        flowc[3]=3*state[3]
        for name,direction in dict(background=flow0,energy_cosine=flowc).items():
            for sign in (-1,1):
                shifted=state+sign*.0005*direction
                matrices=[]
                native=[]
                angular=[]
                changes=[]
                for phase in range(256):
                    sample=at_state(fibre,energy,shifted,np.pi*phase/256)
                    original=np.stack([reduced_operator(sample,system,energy,branch) for branch in ('gr','poisson-spatial')])
                    stable=live_rows(sample,energy,original)
                    matrices.append(stable)
                    native.append(original)
                    angular.append(sample['angular_rate'])
                    changes.append(float(np.max(abs(stable-original))))
                    if phase%64==0:
                        print(LABEL,'refined drift',name,sign,phase,'of256',flush=True)
                tag=name+'-'+str(sign)
                np.savez_compressed(output/(tag+'.npz'),matrix=np.array(matrices),native_matrix=np.array(native),
                    angular=np.array(angular),state=shifted,direction=direction)
                repairs[tag]=max(changes)
                require(max(changes)<GATE,'native equation comparison')
    require(np.array_equal(before,system.context['point'](float(state[0]))),'context restoration')
    analyze(output,inputs,provenance,repairs)


if __name__=='__main__':
    main()
