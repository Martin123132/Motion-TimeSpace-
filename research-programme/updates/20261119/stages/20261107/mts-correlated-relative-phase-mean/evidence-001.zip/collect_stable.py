from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from phase_fibre import PhaseFibre
from fibre_operator import at_state
from stable_rows import repair
from mean_math import reduced_operator
from relative_math import coefficients
from run_native import native_provenance
from stable_analysis import analyze
import numpy as np


def live_rows(sample,energy,original):
    point=sample['point']
    pars=point['parameters']
    scalar=coefficients(pars['alpha'],pars['mu'],pars['eta0'],pars['b'],pars['theta'])
    selector=np.eye(energy.size)[energy.heavy]
    output=original.copy()
    for number,branch in enumerate(('gr','poisson-spatial')):
        mapping=point['maps'][branch]
        derivative=sample['branches'][branch]['inverse_derivative']
        scalar_rows=scalar['generator']@selector+np.outer(scalar['force_psi'],point['metrics'][branch][0])+np.outer(scalar['force_phi'],point['metrics'][branch][1])
        inverse_heavy=mapping['inverse'][np.ix_(energy.heavy,energy.heavy)].astype(np.longdouble)
        inverse_rest=mapping['inverse'][np.ix_(energy.heavy,energy.rest)].astype(np.longdouble)
        forward=mapping['forward'].astype(np.longdouble)
        stable=inverse_heavy@scalar_rows.astype(np.longdouble)@forward
        stable+=inverse_rest@original[number,energy.rest,:energy.size].astype(np.longdouble)
        stable+=derivative[energy.heavy].astype(np.longdouble)@forward
        output[number,energy.heavy,:energy.size]=stable.astype(float)
        output[number,energy.heavy,energy.size:]=(inverse_rest@original[number,energy.rest,energy.size:].astype(np.longdouble)).astype(float)
    return output


def main():
    modest()
    require(LABEL in ('balanced','double'),'remaining inherited families only')
    require(read(STAGE/'half/stable-01/result.json')['passed'],'qualified stable derivation first')
    output=ROOT/'stable-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    bank=load(ROOT/'mean-01/heavy-phases.npz')
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),
        mean_source=digest(ROOT/'mean-01/heavy-phases.npz'),half_qualification=digest(STAGE/'half/stable-01/result.json'),
        unchanged_orders=[64,128,256],unchanged_drift_widths=[.002,.001],unchanged_inner_width=.01,
        numerical=GATE,algebra=ALGEBRA,scope='same derived stable scalar rows, native other matter, fixed grids and tolerances'))
    system=open_owned('heavy','stable-01/contexts')
    energy=PhysicalEnergyMap(system)
    state=bank['state']
    before=system.context['point'](float(state[0])).copy()
    repairs={}
    with PhaseFibre(system,float(state[0])) as fibre:
        matrices=[]
        differences=[]
        for phase in range(256):
            updated=repair(fibre,energy,state,np.pi*phase/256,bank['matrix'][phase])
            matrices.append(updated)
            differences.append(float(np.max(abs(updated-bank['matrix'][phase]))))
        bank['matrix']=np.array(matrices)
        np.savez_compressed(output/'center.npz',**bank)
        repairs['center']=max(differences)
        fibre.install(state,np.pi/4)
        flow0=fibre.flow.copy()
        flow0[3]=-state[3]
        flowc=np.zeros(5)
        flowc[3]=3*state[3]
        for name,direction in dict(background=flow0,energy_cosine=flowc).items():
            for multiplier in (-4,-2,-1,1,2,4):
                shifted=state+multiplier*.001*direction
                matrices=[]
                native_matrices=[]
                angular=[]
                differences=[]
                for phase in range(256):
                    sample=at_state(fibre,energy,shifted,np.pi*phase/256)
                    original=np.stack([reduced_operator(sample,system,energy,branch) for branch in ('gr','poisson-spatial')])
                    updated=live_rows(sample,energy,original)
                    matrices.append(updated)
                    native_matrices.append(original)
                    angular.append(sample['angular_rate'])
                    differences.append(float(np.max(abs(updated-original))))
                    if phase%64==0:
                        print(LABEL,'stable native',name,multiplier,phase,'of256',flush=True)
                tag=name+'-'+str(multiplier)
                np.savez_compressed(output/(tag+'.npz'),matrix=np.array(matrices),native_matrix=np.array(native_matrices),
                    angular=np.array(angular),state=shifted,direction=direction)
                repairs[tag]=max(differences)
                require(max(differences)<GATE,'independent native equation comparison')
    require(np.array_equal(before,system.context['point'](float(state[0]))),'context restoration')
    analyze(output,inputs,provenance,repairs)


if __name__=='__main__':
    main()
