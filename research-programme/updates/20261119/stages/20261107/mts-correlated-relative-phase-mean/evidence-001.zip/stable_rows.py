from common import *
from native_joint import point_map,inverse_rate
from relative_math import coefficients
import numpy as np


def repair(fibre,energy,state,theta,original):
    fibre.install(state,theta)
    system=fibre.system
    point=point_map(system,energy,float(state[0]))
    flow,angular,mu=fibre.flow.copy(),fibre.angular_rate,fibre.mu
    width=.01/max(mu,1.)
    nearby=[]
    for step in (-2,-1,1,2):
        offset=step*width
        fibre.install(state+offset*flow,theta+offset*angular)
        nearby.append(point_map(system,energy,float(state[0]+offset)))
    fibre.install(state,theta)
    pars=point['parameters']
    scalar=coefficients(pars['alpha'],pars['mu'],pars['eta0'],pars['b'],pars['theta'])
    selector=np.eye(energy.size)[energy.heavy]
    output=original.copy()
    for number,branch in enumerate(('gr','poisson-spatial')):
        mapping=point['maps'][branch]
        values=[item['metrics'][branch] for item in nearby]
        rate=(values[0]-8*values[1]+8*values[2]-values[3])/(12*width)
        derivative=inverse_rate(point,rate,branch,energy.heavy)
        scalar_rows=scalar['generator']@selector+np.outer(scalar['force_psi'],point['metrics'][branch][0])+np.outer(scalar['force_phi'],point['metrics'][branch][1])
        inverse_heavy=mapping['inverse'][np.ix_(energy.heavy,energy.heavy)].astype(np.longdouble)
        inverse_rest=mapping['inverse'][np.ix_(energy.heavy,energy.rest)].astype(np.longdouble)
        forward=mapping['forward'].astype(np.longdouble)
        stable_core=inverse_heavy@scalar_rows.astype(np.longdouble)@forward
        stable_core+=inverse_rest@original[number,energy.rest,:energy.size].astype(np.longdouble)
        stable_core+=derivative[energy.heavy].astype(np.longdouble)@forward
        output[number,energy.heavy,:energy.size]=stable_core.astype(float)
        output[number,energy.heavy,energy.size:]=(inverse_rest@original[number,energy.rest,energy.size:].astype(np.longdouble)).astype(float)
    return output
