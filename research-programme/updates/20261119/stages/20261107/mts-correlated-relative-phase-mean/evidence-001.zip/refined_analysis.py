from common import *
from mean_math import phase_primitive,fourth_derivative,remainder,relative_error
from run_native import native_provenance
import numpy as np


def analyze(output,inputs,provenance,repairs):
    bank=load(ROOT/'stable-01/center.npz')
    saved=dict(state=bank['state'],theta=bank['theta'])
    errors={}
    reports={}
    for number,branch in enumerate(('gr','poisson-spatial')):
        terms={}
        for order in (64,128,256):
            stride=256//order
            center=phase_primitive(bank['matrix'][::stride,number],bank['angular'][::stride])
            derivatives={}
            for name in ('background','energy_cosine'):
                shifted={}
                for multiplier in (-4,-2,-1,1,2,4):
                    source=(output/(name+'-'+str(multiplier)+'.npz')) if abs(multiplier)==1 else (ROOT/'stable-01'/(name+'-'+str(multiplier//2)+'.npz'))
                    packet=load(source)
                    shifted[multiplier]=phase_primitive(packet['matrix'][::stride,number],packet['angular'][::stride])['primitive']
                derivatives[name]={factor:fourth_derivative({step:shifted[step*factor] for step in (-2,-1,1,2)},.0005*factor) for factor in (2,1)}
            for factor in (2,1):
                drift=derivatives['background'][factor]+np.cos(2*bank['theta'][::stride])[:,None,None]*derivatives['energy_cosine'][factor]
                residual=np.stack([remainder(matrix,center['mean'],local,rate) for matrix,local,rate in zip(bank['matrix'][::stride,number],center['primitive'],drift)])
                terms[order,factor]=dict(drift=drift,remainder=residual,primitive=center['primitive'],mean=center['mean'],coefficients=center['coefficients'])
        errors[branch+'_drift_width']=relative_error(terms[256,2]['drift'],terms[256,1]['drift'])
        errors[branch+'_remainder_width']=relative_error(terms[256,2]['remainder'],terms[256,1]['remainder'])
        errors[branch+'_drift_phase']=relative_error(terms[128,1]['drift'],terms[256,1]['drift'][::2])
        errors[branch+'_remainder_phase']=relative_error(terms[128,1]['remainder'],terms[256,1]['remainder'][::2])
        fine=terms[256,1]
        errors[branch+'_mean_phase']=relative_error(terms[128,1]['mean'],fine['mean'])
        errors[branch+'_primitive_phase']=relative_error(terms[128,1]['primitive'],fine['primitive'][::2])
        norm_bound=sum(float(np.linalg.norm(value,ord=2)) for value in fine['coefficients'])
        reports[branch]=dict(sampled_remainder_sup_2=max(float(np.linalg.norm(value,ord=2)) for value in fine['remainder']),
            sampled_drift_sup_2=max(float(np.linalg.norm(value,ord=2)) for value in fine['drift']),
            primitive_fourier_polynomial_bound=norm_bound,primitive_polynomial_invertible=norm_bound<1,
            remainder_phase_absolute=float(np.max(abs(terms[128,1]['remainder']-fine['remainder'][::2]))),
            remainder_width_absolute=float(np.max(abs(terms[256,2]['remainder']-fine['remainder']))),
            drift_width_absolute=float(np.max(abs(terms[256,2]['drift']-fine['drift']))))
        for name,value in fine.items():
            saved[branch+'_'+name]=value
    np.savez_compressed(output/'remainder.npz',**saved)
    require(inputs==verify_inputs() and provenance==native_provenance(),'parent integrity')
    passed=max(errors.values())<GATE and all(row['primitive_polynomial_invertible'] for row in reports.values())
    write(output/'result.json',dict(passed=passed,inputs=inputs,provenance=provenance,sources=sources(),errors=errors,
        branches=reports,repairs=repairs,packet_sha256=digest(output/'remainder.npz'),central_packet=str(ROOT/'stable-01/center.npz'),
        previous_failed_width_errors=read(ROOT/'stable-01/result.json')['errors']))
    print(json.dumps(dict(passed=passed,errors=errors,branches=reports),indent=2),flush=True)
    require(passed,'stable-row refinement gate; preserve failure without retry')


