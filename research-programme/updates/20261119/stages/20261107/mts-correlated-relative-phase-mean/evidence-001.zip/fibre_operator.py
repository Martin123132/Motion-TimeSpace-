from common import *
from native_joint import point_map,inverse_rate
from adjoint_operator import extract
import numpy as np


def at_state(fibre,energy,state,theta,derivative_width=.01):
    fibre.install(state,theta)
    system=fibre.system
    efold=float(state[0])
    point=point_map(system,energy,efold)
    flow,angular,mu=fibre.flow.copy(),fibre.angular_rate,fibre.mu
    base,injection,channels,_,_=extract(system,efold)
    originals={'gr':base,'poisson-spatial':base+injection@channels[0]}
    size=energy.size
    if system.model=='heavy':
        width=derivative_width/max(mu,1.)
        nearby=[]
        for shift in (-2,-1,1,2):
            offset=shift*width
            fibre.install(state+offset*flow,theta+offset*angular)
            nearby.append(point_map(system,energy,float(state[0]+offset)))
    else:
        width=0.
        nearby=[]
    fibre.install(state,theta)
    speed=system.context['kinetic'](fibre.current[11])[1]/fibre.current[12]
    tail_weights=point['adapted']['tail_weights'].copy()
    tail_units=system.units[size:size+5]
    core_units=system.units[energy.quadrupoles]
    boundary_raw=-3*system.wave*speed*tail_units/(5*core_units)
    outward_raw=3*system.wave*speed*core_units/(7*tail_units)
    into=point['raw_transform'][:,energy.quadrupoles]*(boundary_raw/tail_weights[0])[None,:]
    out=outward_raw[:,None]*tail_weights[0,:,None]*point['raw_inverse'][energy.quadrupoles]
    reports={}
    for branch,original in originals.items():
        mapping=point['maps'][branch]
        direct=point['raw_transform']@original@point['raw_inverse']+point['logarithmic']
        if system.model=='heavy':
            values=[item['metrics'][branch] for item in nearby]
            metric_rate=(values[0]-8*values[1]+8*values[2]-values[3])/(12*width)
            derivative=inverse_rate(point,metric_rate,branch,energy.heavy)
            inverses=[item['maps'][branch]['inverse'] for item in nearby]
            direct_derivative=(inverses[0]-8*inverses[1]+8*inverses[2]-inverses[3])/(12*width)
            derivative_error=float(np.max(abs(derivative-direct_derivative))/
                                   max(np.max(abs(derivative)),np.max(abs(direct_derivative)),1e-80))
        else:
            derivative=np.zeros_like(direct)
            derivative_error=0.
        inverse,forward=mapping['inverse'],mapping['forward']
        reports[branch]=dict(core=inverse@direct@forward+derivative@forward,
                             into=inverse@into,out=out@forward,
                             metric=point['metrics'][branch]@forward,
                             native_core=original,relative_core=direct,
                             inverse_derivative=derivative,derivative_check=derivative_error)
    return dict(point=point,branches=reports,tail_weights=tail_weights,
                tail_rate=point['adapted']['tail_rate'].copy(),speed=speed,mu=mu,angular_rate=angular,
                state=np.asarray(state).copy(),theta=theta,flow=flow)
