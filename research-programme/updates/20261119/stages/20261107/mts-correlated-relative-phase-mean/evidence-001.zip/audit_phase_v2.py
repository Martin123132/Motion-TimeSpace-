from common import *
import numpy as np
import platform


def main():
    modest()
    destination=STAGE/'audit'
    destination.mkdir(exist_ok=False)
    inputs=verify_inputs()
    accepted={}
    summary=[]
    overall={}
    for label in ('half','balanced','double'):
        root=STAGE/label
        results=[root/'result.json']+[root/folder/'result.json' for folder in ('mean-01','stable-01','full-01','heldout-01')]
        for path in results:
            report=read(path)
            require(report['passed'] and report['inputs']==inputs,'accepted stage and same parent inputs')
            for source,expected in report['sources'].items():
                require(digest(source)==expected,'tested source unchanged')
            accepted[str(path)]=digest(path)
        phase=read(root/'result.json')
        for record in phase['reports']:
            require(record['passed'],'phase probe')
            for name,value in record['errors'].items():
                overall['phase_'+name]=max(overall.get('phase_'+name,0.),value)
        mean=read(root/'mean-01/heavy-result.json')
        baseline=read(root/'mean-01/cold-result.json')
        drift=read(root/'stable-01/result.json')
        heldout=read(root/'heldout-01/result.json')
        full=read(root/'full-01/result.json')
        bank=load(root/'stable-01/center.npz')
        require(np.all(bank['angular']>0),'monotone phase clock')
        failed=read(STAGE/'half/drift-01/result.json')
        require(not failed['passed'] and failed['errors']['poisson-spatial_drift_width']>GATE,'original failed gate preserved')
        require(read(STAGE/'drift-half-01.end.json')['exit_code']==1,'failed receipt retained')
        for name,record in drift['repairs'].items():
            delta=record['max_absolute'] if isinstance(record,dict) else record
            require(delta<GATE,'stable scalar rows agree with independently native equations')
        residual=load(root/'stable-01/remainder.npz')
        require(digest(root/'mean-01/heavy-phases.npz')==mean['source_hash'],'saved phase packet')
        require(digest(root/'stable-01/remainder.npz')==drift['packet_sha256'],'saved remainder packet')
        for key in ('inputs','provenance'):
            require(drift[key]==heldout[key]==full[key],'same native provenance')
        for report,category in ((drift,'drift'),(heldout,'heldout')):
            for name,value in report['errors'].items():
                require(value<GATE,'original numerical gate')
                overall[category+'_'+name]=max(overall.get(category+'_'+name,0.),value)
        for record in full['reports']:
            for name,value in record['errors'].items():
                require(value<GATE,'native full vector gate')
                overall['full_'+name]=max(overall.get('full_'+name,0.),value)
        for branch,report in baseline['branches'].items():
            require(baseline['errors']['baseline_constant_generator']<GATE,'baseline phase independence')
            require(report['primitive_sup_2']<ALGEBRA,'baseline zero phase primitive')
        local={}
        for number,branch in enumerate(('gr','poisson-spatial')):
            inverse_clock=1/bank['angular']
            direct_mean=np.tensordot(inverse_clock,bank['matrix'][:,number],axes=1)/inverse_clock.sum()
            saved_mean=residual[branch+'_mean']
            error=float(np.max(abs(direct_mean-saved_mean)))/max(float(np.max(abs(direct_mean))),1e-80)
            require(error<ALGEBRA,'independent weighted mean recomputation')
            primitive=residual[branch+'_primitive']
            physical_drift=residual[branch+'_drift']
            exact_remainder=residual[branch+'_remainder']
            original_bank=load(root/'mean-01/heavy-phases.npz')
            stable_change=float(np.max(abs(bank['matrix']-original_bank['matrix'])))
            require(stable_change<GATE,'repaired central operator agrees without changing the model')
            largest=0.
            for matrix,oscillation,background,correction in zip(bank['matrix'][:,number],primitive,physical_drift,exact_remainder):
                left=(np.eye(len(matrix))+oscillation)@(saved_mean+correction)
                right=matrix@(np.eye(len(matrix))+oscillation)-(matrix-saved_mean)-background
                largest=max(largest,float(np.max(abs(left-right)))/max(float(np.max(abs(left))),float(np.max(abs(right))),1e-80))
            require(largest<ALGEBRA,'full noncommuting chain rule independently reconstructed')
            norm_bound=sum(float(np.linalg.norm(value,ord=2)) for value in residual[branch+'_coefficients'])
            require(norm_bound<1,'computed periodic map invertible for all polynomial phases')
            local[branch]=dict(mean=mean['branches'][branch],drift=drift['branches'][branch],heldout=heldout['branches'][branch],
                               independent_mean_error=error,chain_rule_error=largest,stable_operator_change=stable_change)
        summary.append(dict(label=label,wave=float(bank['wave']),efold=float(bank['state'][0]),mu=float(bank['mu']),
                            reference=full['reports'][0]['reference'],branches=local))
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no task bytecode')
    require(inputs==verify_inputs(),'parent integrity after all workers')
    write(destination/'result.json',dict(passed=True,inputs=inputs,sources=sources(),accepted_results=accepted,
        summaries=summary,maximum_errors=overall,python=platform.python_version(),
        original_bank_modified=False,original_physical_grids_modified=False,tolerances_modified=False,
        late_history_generated=False,phase_fibres_are_instantaneous=True,
        analytic_remainder_identity=True,continuum_cold_remainder_bound=False,
        full_g192_native_vectors=108,heldout_phase_matrix_predictions=30,
        physical_baseline_and_mts=True,github_actions=False,
        excluded_attempt='drift-half-01: precision-sensitive drift-width gate; preserved',
        scalar_rows_rederived_not_smoothed=True,
        float64_epsilon=float(np.finfo(np.float64).eps),longdouble_epsilon=float(np.finfo(np.longdouble).eps)))
    print(json.dumps(dict(passed=True,maximum_errors=overall,summary=[dict(label=row['label'],reference=row['reference']) for row in summary]),indent=2))


if __name__=='__main__':
    main()


