from common import *
from adjoint_operator import open_owned
from phase_fibre import PhaseFibre
from cold_access import namespace
from run_native import native_provenance
import numpy as np


def main():
    modest()
    output=ROOT/'external-jet-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    offsets=[-.004,-.002,-.001,-.0005,-.00025,0.,.00025,.0005,.001,.002,.004]
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),offsets=offsets,
        thermal_orders=[48,64],source=str(COLD_BACKGROUND/'thermal_candidate.py'),
        source_sha256=digest(COLD_BACKGROUND/'thermal_candidate.py'),scope='diagnose the exterior enthalpy derivative without changing a coefficient or fitting a function'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'external-jet-01/contexts')
        grid=system.background['efold']
        efold=float(grid[len(grid)//2])
        before=system.context['point'](efold).copy()
        parameters=read(COLD_BACKGROUND/'extension/freeze.json')['configurations'][model]['thermal_parameters']
        thermal=namespace['Thermal'](parameters,48)
        independent=namespace['Thermal'](parameters,64)
        rows=[]
        with PhaseFibre(system,efold) as fibre:
            for offset in offsets:
                exterior=fibre.external(efold+offset)
                density,density_rate,density_second=thermal.values([efold+offset])[0]
                check=independent.values([efold+offset])[0]
                enthalpy=(2*density-density_rate)/3
                enthalpy_rate=(2*density_rate-density_second)/3
                rows.append(dict(offset=offset,native_density=exterior['density'],native_enthalpy=exterior['enthalpy'],
                    inherited_enthalpy_rate=exterior['enthalpy_rate'],integral_density=float(density),
                    integral_enthalpy=float(enthalpy),integral_enthalpy_rate=float(enthalpy_rate),
                    density_relative=abs(exterior['density']-density)/abs(density),
                    enthalpy_relative=abs(exterior['enthalpy']-enthalpy)/abs(enthalpy),
                    rate_relative=abs(exterior['enthalpy_rate']-enthalpy_rate)/abs(enthalpy_rate),
                    thermal_refinement=float(np.max(abs(check-np.array([density,density_rate,density_second]))/abs(check)))))
            derivatives=[]
            for width in (.002,.001,.0005,.00025):
                values=[fibre.external(efold+step*width)['enthalpy'] for step in (-2,-1,1,2)]
                derivative=(values[0]-8*values[1]+8*values[2]-values[3])/(12*width)
                derivatives.append(dict(width=width,value=derivative,integral_relative=abs(derivative-rows[5]['integral_enthalpy_rate'])/abs(rows[5]['integral_enthalpy_rate'])))
        require(np.array_equal(before,system.context['point'](efold)),'restored native context')
        report=dict(model=model,rows=rows,derivative_checks=derivatives)
        reports.append(report)
        print(model,json.dumps(dict(max_density_relative=max(row['density_relative'] for row in rows),
            max_enthalpy_relative=max(row['enthalpy_relative'] for row in rows),max_rate_relative=max(row['rate_relative'] for row in rows),
            max_thermal_refinement=max(row['thermal_refinement'] for row in rows),derivative_checks=derivatives)),flush=True)
        del system
    require(inputs==verify_inputs() and provenance==native_provenance(),'parent integrity')
    write(output/'result.json',dict(diagnostic_only=True,inputs=inputs,provenance=provenance,sources=sources(),reports=reports))


if __name__=='__main__':
    main()
