from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from native_joint import point_map
from phase_fibre import PhaseFibre
from fibre_operator import at_state
from run_native import native_provenance,norm_error
import numpy as np


def main():
    modest()
    ROOT.mkdir(exist_ok=False)
    (ROOT/'contexts').mkdir()
    inputs=verify_inputs()
    provenance=native_provenance()
    write(ROOT/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),algebra=ALGEBRA,numerical=GATE,
                                 phase_offsets=[0.,.37,1.11,2.03,3.141592653589793],
                                 frozen_epoch_fraction=.5,derivative_widths=[.02,.01],
                                 purpose='instantaneous fixed-energy coefficient family; not a new history'))
    records=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'contexts')
        energy=PhysicalEnergyMap(system)
        grid=system.background['efold']
        efold=float(grid[len(grid)//2])
        original=point_map(system,energy,efold)
        before=system.context['point'](efold).copy()
        errors={}
        def check(name,value):
            errors[name]=max(errors.get(name,0.),float(value))
        with PhaseFibre(system,efold) as fibre:
            state,theta0=fibre.initial_state.copy(),fibre.initial_theta
            snapshots=[]
            for offset in (0.,.37,1.11,2.03,np.pi):
                low=at_state(fibre,energy,state,theta0+offset,.02)
                high=at_state(fibre,energy,state,theta0+offset,.01)
                point=high['point']
                check('fixed_energy_hubble',abs(fibre.current[12]-before[12])/before[12])
                observed=system.context['observe'](fibre.current[11],system.zero_native)
                check('native_friedmann',abs(observed[28]-fibre.current[12])/fibre.current[12])
                for branch,operators in high['branches'].items():
                    check(branch+'_derivative_refinement',norm_error(low['branches'][branch]['core'],operators['core']))
                    check(branch+'_inverse_product_rule',operators['derivative_check'])
                    if offset==0:
                        check(branch+'_original_metric_recovery',norm_error(point['metrics'][branch],original['metrics'][branch]))
                    for seed in (0,1,2):
                        vector=np.sin(np.arange(len(system.units))*(seed+.71)+.223)
                        mapping=point['maps'][branch]
                        physical=mapping['forward']@vector[:energy.size]
                        native=np.empty(len(vector))
                        native[:energy.size]=(point['raw_inverse']@physical)*system.units[:energy.size]
                        tail=vector[energy.size:].reshape(190,5)
                        native[energy.size:]=(tail/high['tail_weights']).reshape(-1)*system.units[energy.size:]
                        rate,values,rates,info,_,_=system.evaluate(efold,native,branch)
                        actual_relative=point['raw_transform']@(rate[:energy.size]/system.units[:energy.size])+point['logarithmic']@physical
                        actual=mapping['inverse']@actual_relative+operators['inverse_derivative']@physical
                        expected=operators['core']@vector[:energy.size]+operators['into']@tail[0]
                        check(branch+'_native_vector',norm_error(actual,expected))
                        check(branch+'_native_metric',norm_error(operators['metric']@vector[:energy.size],np.array([values['Psi'],rates['Phi']/info['H']])))
                        check(branch+'_background_clock',abs(info['H']-fibre.current[12])/fibre.current[12])
                snapshots.append(high)
                print(LABEL,model,'phase offset',offset,'worst',max(errors.values()),flush=True)
            for branch in ('gr','poisson-spatial'):
                for name in ('core','into','out','metric'):
                    check(branch+'_pi_period_'+name,norm_error(snapshots[0]['branches'][branch][name],snapshots[-1]['branches'][branch][name]))
            if model=='cold':
                for sample in snapshots:
                    check('baseline_phase_independence',norm_error(sample['branches']['gr']['core'],snapshots[0]['branches']['gr']['core']))
        after=system.context['point'](efold)
        require(np.array_equal(before,after),'native context restored exactly')
        passed=max(errors.values())<GATE
        report=dict(model=model,passed=passed,errors=errors,native_context_restored=True,
                    initial_state=state.tolist(),initial_theta=theta0,efold=efold,
                    interpretation='fixed-energy instantaneous phase fibre, not a background trajectory')
        write(ROOT/(model+'-result.json'),report)
        require(passed,'preserve phase-family failure before changing anything')
        records.append(report)
        del energy,system
    require(inputs==verify_inputs() and provenance==native_provenance(),'retained sources unchanged')
    write(ROOT/'result.json',dict(passed=True,reports=records,inputs=inputs,provenance=provenance,sources=sources()))


if __name__=='__main__':
    main()
