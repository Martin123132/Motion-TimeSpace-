from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from phase_fibre import PhaseFibre
from fibre_operator import at_state
from mean_math import reduced_operator,phase_primitive,interpolate,relative_error
from run_native import native_provenance
import numpy as np
import sympy as sp


def symbolic_checks():
    theta,mu=sp.symbols('theta mu',real=True)
    angular=mu-sp.Rational(3,2)*sp.sin(2*theta)
    checks={'clock_weighted_cosine_total_derivative':sp.simplify(sp.diff(sp.log(angular),theta)+3*sp.cos(2*theta)/angular)}
    def symbolic_matrix(prefix):
        return sp.Matrix(2,2,sp.symbols(prefix+'0:4'))
    matrix,average,primitive,drift=[symbolic_matrix(name) for name in ('b','m','q','d')]
    identity=sp.eye(2)
    numerator=matrix*primitive-primitive*average-drift
    residual=matrix*(identity+primitive)-(matrix-average+drift)-((identity+primitive)*average+numerator)
    for index,value in enumerate(residual):
        checks['noncommuting_chain_rule_'+str(index)]=sp.expand(value)
    covariance=sp.symbols('a e b',real=True)
    initial,epsilon,slope=covariance
    expression=(1+epsilon*sp.cos(2*theta))*(initial+slope*sp.cos(2*theta))
    checks['separate_average_covariance']=sp.simplify(sp.integrate(expression,(theta,0,sp.pi))/sp.pi-initial-epsilon*slope/2)
    require(all(value==0 for value in checks.values()),'exact symbolic normal-form identities')
    return {name:str(value) for name,value in checks.items()}


def main():
    modest()
    output=ROOT/'heldout-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    angles=[.123,.873,1.923,2.617,3.021]
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),angles=angles,
        mean_bank=digest(ROOT/'mean-01/heavy-phases.npz'),numerical=GATE,algebra=ALGEBRA,
        scope='frozen interpolation of the full native operator at unused phase angles; not observational holdout data'))
    bank=load(ROOT/'mean-01/heavy-phases.npz')
    count=len(bank['angular'])
    coefficients=np.fft.fft(bank['matrix'],axis=0)/count
    errors={}
    reports={}
    for number,branch in enumerate(('gr','poisson-spatial')):
        primitive=phase_primitive(bank['matrix'][:,number],bank['angular'])
        period=np.pi/np.sqrt(float(bank['mu'])**2-2.25)
        errors[branch+'_exact_phase_period']=abs(primitive['period']-period)/period
        size=int(bank['core_size'])
        sym=(primitive['mean']+primitive['mean'].T)/2
        errors[branch+'_tail_skew_symmetry']=float(np.max(abs(sym[size:size+5,size+5:])))/max(float(np.max(abs(primitive['mean']))),1e-80)
        require(errors[branch+'_tail_skew_symmetry']<ALGEBRA,'energy-normalized tail skew symmetry')
        coefficients_q=primitive['coefficients']
        errors[branch+'_primitive_outside_support']=float(np.max(abs(coefficients_q[:,size+5:,:])))+float(np.max(abs(coefficients_q[:,:,size+5:])))
        require(errors[branch+'_primitive_outside_support']<ALGEBRA,'finite support of primitive')
        reports[branch]=dict(period_exact=period,phase_polynomial_norm_bound=sum(float(np.linalg.norm(value,ord=2)) for value in coefficients_q),
            full_hierarchy_mean_logarithmic_norm=max(float(np.linalg.eigvalsh(sym[:size+5,:size+5])[-1]),float(np.diag(sym)[size:].max())),
            tail_scope='full G192 internal symmetric off-diagonals vanish in the inherited energy normalization')
    system=open_owned('heavy','heldout-01/contexts')
    energy=PhysicalEnergyMap(system)
    state=bank['state']
    before=system.context['point'](float(state[0])).copy()
    heldout=[]
    with PhaseFibre(system,float(state[0])) as fibre:
        require(np.array_equal(fibre.initial_state,state),'frozen saved state')
        for theta in angles:
            sample=at_state(fibre,energy,state,theta)
            comparisons=[]
            for number,branch in enumerate(('gr','poisson-spatial')):
                predicted=interpolate(coefficients[:,number],theta)
                actual=reduced_operator(sample,system,energy,branch)
                error=relative_error(predicted,actual)
                errors[branch+'_heldout_operator']=max(errors.get(branch+'_heldout_operator',0.),error)
                comparisons.append(dict(branch=branch,relative_error=error,absolute_error=float(np.max(abs(predicted-actual)))))
            heldout.append(dict(theta=theta,comparisons=comparisons))
    require(np.array_equal(before,system.context['point'](float(state[0]))),'context restored')
    identities=symbolic_checks()
    passed=max(errors.values())<GATE
    require(inputs==verify_inputs() and provenance==native_provenance(),'parent integrity')
    write(output/'result.json',dict(passed=passed,inputs=inputs,provenance=provenance,sources=sources(),
        errors=errors,branches=reports,heldout=heldout,symbolic_identities=identities))
    print(json.dumps(dict(passed=passed,errors=errors,branches=reports),indent=2),flush=True)
    require(passed,'frozen prediction gate')


if __name__=='__main__':
    main()
