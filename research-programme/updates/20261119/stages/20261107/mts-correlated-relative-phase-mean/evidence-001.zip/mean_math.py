from common import *
import numpy as np


def reduced_operator(sample,system,energy,branch):
    size=energy.size
    values=sample['branches'][branch]
    matrix=np.zeros((size+10,size+10))
    matrix[:size,:size]=values['core']
    matrix[:size,size:size+5]=values['into']
    matrix[size:size+5,:size]=values['out']
    weights=sample['tail_weights']
    units=system.units[size:].reshape(190,5)
    require(np.array_equal(units,np.broadcast_to(units[0],units.shape)),'retained tail normalization')
    indices=np.arange(5)
    matrix[size+indices,size+indices]=sample['tail_rate']
    matrix[size+5+indices,size+5+indices]=sample['tail_rate']
    matrix[size+indices,size+5+indices]=-4*system.wave*sample['speed']/7*weights[0]/weights[1]
    matrix[size+5+indices,size+indices]=4*system.wave*sample['speed']/9*weights[1]/weights[0]
    return matrix


def phase_primitive(matrix,angular):
    count=len(angular)
    weight=1/angular
    mean=np.einsum('p,pij->ij',weight,matrix)/weight.sum()
    forcing=(matrix-mean)/angular[:,None,None]
    modes=np.fft.fftfreq(count,d=1/count)
    coefficients=np.fft.fft(forcing,axis=0)/count
    primitive=np.zeros_like(coefficients)
    selected=(modes!=0)&(abs(modes)!=count/2)
    primitive[selected]=coefficients[selected]/(2j*modes[selected,None,None])
    values=np.fft.ifft(primitive*count,axis=0).real
    derivative=np.fft.ifft(primitive*(2j*modes[:,None,None])*count,axis=0).real
    return dict(mean=mean,forcing=forcing,primitive=values,coefficients=primitive,
                phase_derivative=derivative,closure=float(np.max(abs(coefficients[0]))),
                unresolved=float(np.max(abs(forcing-derivative))),
                period=float(np.pi*weight.mean()))


def interpolate(coefficients,theta):
    modes=np.fft.fftfreq(len(coefficients),d=1/len(coefficients))
    return np.einsum('p,pij->ij',np.exp(2j*modes*theta),coefficients).real


def fourth_derivative(samples,width):
    return (samples[-2]-8*samples[-1]+8*samples[1]-samples[2])/(12*width)


def relative_error(left,right):
    return float(np.max(abs(left-right))/max(np.max(abs(left)),np.max(abs(right)),1e-80))


def remainder(matrix,mean,primitive,drift):
    identity=np.eye(len(mean))
    numerator=matrix@primitive-primitive@mean-drift
    return np.linalg.solve(identity+primitive,numerator)
