from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from phase_fibre import PhaseFibre
from fibre_operator import at_state
from relative_math import coefficients
from mean_math import reduced_operator,relative_error
from run_native import native_provenance
import numpy as np


def tail_action(sample,system,energy,tail):
    degrees=np.arange(3,193)
    weights=sample['tail_weights']
    result=sample['tail_rate'][None,:]*tail
    lower=system.wave*degrees/(2*degrees+1)
    upper=-system.wave*(degrees+1)/(2*degrees+1)
    result[1:]+=(lower[1:,None]*sample['speed'][None,:]*weights[1:]/weights[:-1])*tail[:-1]
    result[:-1]+=(upper[:-1,None]*sample['speed'][None,:]*weights[:-1]/weights[1:])*tail[1:]
    return result


def main():
    modest()
    output=ROOT/'full-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),
        offsets=[0.,.002,-.002],angles=[.187,1.317,2.713],seeds=[0,1,2],
        numerical=GATE,algebra=ALGEBRA,
        scope='physical native full G192 rate and exact sparse support, including shifted slow states'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'full-01/contexts')
        energy=PhysicalEnergyMap(system)
        efold=float(system.background['efold'][len(system.background['efold'])//2])
        before=system.context['point'](efold).copy()
        errors={}
        reference=None
        with PhaseFibre(system,efold) as fibre:
            state=fibre.initial_state.copy()
            fibre.install(state,np.pi/4)
            direction=fibre.flow.copy()
            direction[3]=-state[3]
            for offset,theta in zip((0.,.002,-.002),(.187,1.317,2.713)):
                sample=at_state(fibre,energy,state+offset*direction,theta)
                point=sample['point']
                if offset==0 and model=='heavy':
                    reference=dict(point['parameters'])
                    reference['pressure_coefficient']=reference['alpha']**2/4
                    reference['newton_self_gravity']=-reference['b']
                    reference['leading_velocity_density_coefficient']=reference['alpha']**2/4-reference['b']
                for branch in ('gr','poisson-spatial'):
                    operators=sample['branches'][branch]
                    mapping=point['maps'][branch]
                    small=reduced_operator(sample,system,energy,branch)
                    for seed in (0,1,2):
                        vector=np.sin(np.arange(len(system.units))*(.319+seed)+.137)
                        tail=vector[energy.size:].reshape(190,5)
                        native=np.empty_like(vector)
                        physical=mapping['forward']@vector[:energy.size]
                        native[:energy.size]=(point['raw_inverse']@physical)*system.units[:energy.size]
                        native[energy.size:]=(tail/sample['tail_weights']).ravel()*system.units[energy.size:]
                        evaluation=system.evaluate(float(fibre.state[0]),native,branch)
                        rate=evaluation[0]/system.units
                        native_tail=sample['tail_weights']*rate[energy.size:].reshape(190,5)+sample['tail_rate'][None,:]*tail
                        actual_relative=point['raw_transform']@rate[:energy.size]+point['logarithmic']@physical
                        if model=='heavy':
                            pars=point['parameters']
                            direct=coefficients(pars['alpha'],pars['mu'],pars['eta0'],pars['b'],pars['theta'])
                            scalar_rate=direct['generator']@physical[energy.heavy]+direct['force_psi']*evaluation[1]['Psi']+direct['force_phi']*evaluation[2]['Phi']/evaluation[3]['H']
                            errors[branch+'_independent_scalar_equation']=max(errors.get(branch+'_independent_scalar_equation',0.),relative_error(scalar_rate,actual_relative[energy.heavy]))
                        native_core=mapping['inverse']@actual_relative+operators['inverse_derivative']@physical
                        derived_core=operators['core']@vector[:energy.size]+operators['into']@tail[0]
                        derived_tail=tail_action(sample,system,energy,tail)
                        derived_tail[0]+=operators['out']@vector[:energy.size]
                        errors[branch+'_native_core']=max(errors.get(branch+'_native_core',0.),relative_error(native_core,derived_core))
                        errors[branch+'_native_tail']=max(errors.get(branch+'_native_tail',0.),relative_error(native_tail,derived_tail))
                        if seed==0:
                            isolated=vector.copy()
                            isolated[energy.size+10:]=0.
                            isolated_tail=isolated[energy.size:].reshape(190,5)
                            expected=np.concatenate([operators['core']@isolated[:energy.size]+operators['into']@isolated_tail[0],
                                (tail_action(sample,system,energy,isolated_tail)+np.vstack([operators['out']@isolated[:energy.size],np.zeros((189,5))])).ravel()])
                            errors[branch+'_small_block']=max(errors.get(branch+'_small_block',0.),relative_error(small@isolated[:energy.size+10],expected[:energy.size+10]))
        require(np.array_equal(before,system.context['point'](efold)),'native restoration')
        report=dict(model=model,errors=errors,reference=reference,passed=max(errors.values())<GATE)
        write(output/(model+'-result.json'),report)
        require(report['passed'],'full native phase-family gate')
        reports.append(report)
        print(LABEL,model,json.dumps(errors),flush=True)
        del energy,system
    require(inputs==verify_inputs() and provenance==native_provenance(),'input integrity')
    write(output/'result.json',dict(passed=True,inputs=inputs,provenance=provenance,sources=sources(),reports=reports))


if __name__=='__main__':
    main()
