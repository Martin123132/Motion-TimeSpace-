from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from phase_fibre import PhaseFibre
from fibre_operator import at_state
from mean_math import reduced_operator,phase_primitive,fourth_derivative,remainder,relative_error
from run_native import native_provenance
import numpy as np


def main():
    modest()
    output=ROOT/'drift-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    mean_report=read(ROOT/'mean-01/result.json')
    require(mean_report['passed'],'completed frozen mean')
    bank=load(ROOT/'mean-01/heavy-phases.npz')
    state=bank['state']
    delta=1e-3
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),
        mean_source=digest(ROOT/'mean-01/heavy-phases.npz'),orders=[64,128,256],
        drift_widths=[2*delta,delta],stencil_multipliers=[-4,-2,-1,1,2,4],
        derivative_width=.01,numerical=GATE,algebra=ALGEBRA,
        scope='directional derivatives of the instantaneous primitive, no new background or perturbation evolution'))
    system=open_owned('heavy','drift-01/contexts')
    energy=PhysicalEnergyMap(system)
    efold=float(state[0])
    before=system.context['point'](efold).copy()
    errors={}
    with PhaseFibre(system,efold) as fibre:
        require(np.array_equal(fibre.initial_state,state),'same saved instantaneous state')
        fibre.install(state,np.pi/4)
        flow0=fibre.flow.copy()
        flow0[3]=-state[3]
        flowc=np.zeros(5)
        flowc[3]=3*state[3]
        directions=dict(background=flow0,energy_cosine=flowc)
        for name,direction in directions.items():
            for multiplier in (-4,-2,-1,1,2,4):
                guard()
                shifted=state+multiplier*delta*direction
                matrices=[]
                angular=[]
                for phase in range(256):
                    guard()
                    sample=at_state(fibre,energy,shifted,np.pi*phase/256)
                    matrices.append(np.stack([reduced_operator(sample,system,energy,branch) for branch in ('gr','poisson-spatial')]))
                    angular.append(sample['angular_rate'])
                    if phase%64==0:
                        print(LABEL,name,multiplier,'phase',phase,'of256',flush=True)
                np.savez_compressed(output/(name+'-'+str(multiplier)+'.npz'),matrix=np.array(matrices),
                    angular=np.array(angular),state=shifted,direction=direction)
        external=[]
        for multiplier in (-4,-2,-1,1,2,4):
            exterior=fibre.external(efold+multiplier*delta)
            external.append([multiplier,exterior['density'],exterior['enthalpy'],exterior['enthalpy_rate']])
        reference=fibre.external(efold)
        expected=2*reference['density']-3*reference['enthalpy']
        exterior_rows={int(row[0]):row[1] for row in external}
        derived={}
        for factor in (2,1):
            selected={multiplier:np.array(exterior_rows[multiplier*factor]) for multiplier in (-2,-1,1,2)}
            derived[str(factor)]=float(fourth_derivative(selected,delta*factor))
        errors['external_density_flow']=max(abs(value-expected)/max(abs(expected),1e-80) for value in derived.values())
        write(output/'external-flow.json',dict(samples=external,analytic_density_rate=expected,stencil_rates=derived,
            relative_error=errors['external_density_flow']))
    require(np.array_equal(before,system.context['point'](efold)),'restored native context')
    results={}
    saved=dict(state=state,flow0=flow0,flowc=flowc,theta=bank['theta'])
    for number,branch in enumerate(('gr','poisson-spatial')):
        terms={}
        for order in (64,128,256):
            stride=256//order
            center=phase_primitive(bank['matrix'][::stride,number],bank['angular'][::stride])
            primitive=center['primitive']
            derivatives={}
            for name in directions:
                shifted={}
                for multiplier in (-4,-2,-1,1,2,4):
                    record=load(output/(name+'-'+str(multiplier)+'.npz'))
                    shifted[multiplier]=phase_primitive(record['matrix'][::stride,number],record['angular'][::stride])['primitive']
                derivatives[name]={}
                for factor in (2,1):
                    derivatives[name][factor]=fourth_derivative({step:shifted[step*factor] for step in (-2,-1,1,2)},delta*factor)
            for factor in (2,1):
                drift=derivatives['background'][factor]+np.cos(2*bank['theta'][::stride])[:,None,None]*derivatives['energy_cosine'][factor]
                residual=np.stack([remainder(matrix,center['mean'],local,rate) for matrix,local,rate in zip(bank['matrix'][::stride,number],primitive,drift)])
                terms[order,factor]=dict(drift=drift,remainder=residual,primitive=primitive,mean=center['mean'])
        errors[branch+'_drift_width']=relative_error(terms[256,2]['drift'],terms[256,1]['drift'])
        errors[branch+'_remainder_width']=relative_error(terms[256,2]['remainder'],terms[256,1]['remainder'])
        errors[branch+'_drift_phase']=relative_error(terms[128,1]['drift'],terms[256,1]['drift'][::2])
        errors[branch+'_remainder_phase']=relative_error(terms[128,1]['remainder'],terms[256,1]['remainder'][::2])
        fine=terms[256,1]
        residual_norm=np.array([np.linalg.norm(value,ord=2) for value in fine['remainder']])
        drift_norm=np.array([np.linalg.norm(value,ord=2) for value in fine['drift']])
        q_norm=np.array([np.linalg.norm(value,ord=2) for value in fine['primitive']])
        commutator=np.array([matrix@primitive-primitive@fine['mean'] for matrix,primitive in zip(bank['matrix'][:,number],fine['primitive'])])
        numerator_bound=(np.array([np.linalg.norm(value,ord=2) for value in commutator])+drift_norm)/(1-q_norm)
        require(np.all(residual_norm<=numerator_bound*(1+ALGEBRA)),'pointwise Neumann remainder inequality')
        coefficients=phase_primitive(bank['matrix'][:,number],bank['angular'])['coefficients']
        fourier_bound=sum(float(np.linalg.norm(value,ord=2)) for value in coefficients)
        results[branch]=dict(sampled_remainder_sup_2=float(residual_norm.max()),
            sampled_neumann_upper=float(numerator_bound.max()),sampled_drift_sup_2=float(drift_norm.max()),
            primitive_fourier_polynomial_bound=fourier_bound,primitive_polynomial_invertible=fourier_bound<1,
            remainder_phase_absolute=float(np.max(abs(terms[128,1]['remainder']-terms[256,1]['remainder'][::2]))),
            remainder_width_absolute=float(np.max(abs(terms[256,2]['remainder']-terms[256,1]['remainder']))),
            drift_width_absolute=float(np.max(abs(terms[256,2]['drift']-terms[256,1]['drift']))),
            caution='phase sampled physical remainder; Fourier bound is for the computed polynomial, not an analytic unsampled remainder certificate')
        for name,value in fine.items():
            saved[branch+'_'+name]=value
        saved[branch+'_coefficients']=coefficients
        for name in directions:
            saved[branch+'_'+name+'_derivative']=derivatives[name][1]
    np.savez_compressed(output/'remainder.npz',**saved)
    require(inputs==verify_inputs() and provenance==native_provenance(),'parent integrity')
    passed=max(errors.values())<GATE and all(row['primitive_polynomial_invertible'] for row in results.values())
    write(output/'result.json',dict(passed=passed,errors=errors,branches=results,inputs=inputs,provenance=provenance,
        sources=sources(),background_or_perturbation_solves=0,baseline_phase_primitive='identically zero; no artificial heavy scalar',
        packet_sha256=digest(output/'remainder.npz')))
    print(json.dumps(dict(passed=passed,errors=errors,branches=results),indent=2),flush=True)
    require(passed,'preserve refinement failure for diagnosis; no automatic retry')


if __name__=='__main__':
    main()
