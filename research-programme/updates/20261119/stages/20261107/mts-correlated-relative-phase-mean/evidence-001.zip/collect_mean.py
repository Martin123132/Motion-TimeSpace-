from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from phase_fibre import PhaseFibre
from fibre_operator import at_state
from mean_math import reduced_operator,phase_primitive,relative_error
from run_native import native_provenance
import numpy as np


def main():
    modest()
    output=ROOT/'mean-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    require(read(ROOT/'result.json')['passed'],'phase fibre qualification')
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),
        orders=[64,128,256],phase_origin=0.,phase_period=float(np.pi),derivative_width=.01,
        epoch_fraction=.5,numerical=GATE,algebra=ALGEBRA,
        norm='sup component difference divided by larger sup component, with absolute errors also saved',
        scope='instantaneous full coupled generator; no evolved cold result'))
    summaries=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'mean-01/contexts')
        energy=PhysicalEnergyMap(system)
        grid=system.background['efold']
        efold=float(grid[len(grid)//2])
        before=system.context['point'](efold).copy()
        with PhaseFibre(system,efold) as fibre:
            state=fibre.initial_state.copy()
            count=256 if model=='heavy' else 8
            matrices=[]
            angular=[]
            snapshots=[]
            factorized={branch:[] for branch in ('gr','poisson-spatial')}
            errors=dict(tail_phase_dependence=0.,inverse_product_rule=0.)
            for phase in range(count):
                guard()
                theta=np.pi*phase/count
                sample=at_state(fibre,energy,state,theta)
                matrices.append(np.stack([reduced_operator(sample,system,energy,branch) for branch in ('gr','poisson-spatial')]))
                angular.append(sample['angular_rate'])
                tail=np.concatenate([sample['tail_rate'],sample['speed'],sample['tail_weights'].ravel()])
                if phase==0:
                    original_tail=tail.copy()
                errors['tail_phase_dependence']=max(errors['tail_phase_dependence'],relative_error(tail,original_tail))
                errors['inverse_product_rule']=max(errors['inverse_product_rule'],*(sample['branches'][branch]['derivative_check'] for branch in factorized))
                for branch in factorized:
                    mapping=sample['point']['maps'][branch]
                    factorized[branch].append(np.stack([mapping['inverse'],sample['branches'][branch]['relative_core'],mapping['forward'],sample['branches'][branch]['inverse_derivative']]))
                if phase%32==0:
                    print(LABEL,model,'coupled phase',phase,'of',count,flush=True)
            matrices,angular=np.array(matrices),np.array(angular)
            packet=dict(matrix=matrices,angular=angular,state=state,theta=np.pi*np.arange(count)/count,
                        core_size=np.array(energy.size),wave=np.array(system.wave),heavy=np.array(energy.heavy,dtype=int),
                        mu=np.array(sample['mu']),tail=original_tail)
            for branch in factorized:
                packet[branch+'_factors']=np.array(factorized[branch])
            np.savez_compressed(output/(model+'-phases.npz'),**packet)
            reports={}
            for number,branch in enumerate(factorized):
                results={}
                orders=(64,128,256) if model=='heavy' else (2,4,8)
                for order in orders:
                    result=phase_primitive(matrices[::count//order,number],angular[::count//order])
                    results[order]=result
                fine=results[orders[-1]]
                refinements=[]
                for coarse_order,fine_order in zip(orders[:-1],orders[1:]):
                    coarse,finer=results[coarse_order],results[fine_order]
                    refinements.append(dict(orders=[coarse_order,fine_order],
                        mean_relative=relative_error(coarse['mean'],finer['mean']),
                        mean_absolute=float(np.max(abs(coarse['mean']-finer['mean']))),
                        primitive_relative=relative_error(coarse['primitive'],finer['primitive'][::2]),
                        primitive_absolute=float(np.max(abs(coarse['primitive']-finer['primitive'][::2])))))
                averages=np.einsum('p,paij->aij',1/angular,np.array(factorized[branch]))/(1/angular).sum()
                separate=averages[0]@averages[1]@averages[2]+averages[3]@averages[2]
                difference=fine['mean'][:energy.size,:energy.size]-separate
                norm=max(float(np.linalg.norm(value,ord=2)) for value in fine['primitive'])
                minimum=min(float(np.linalg.svd(np.eye(len(value))+value,compute_uv=False)[-1]) for value in fine['primitive'])
                selected_mean=fine['mean'][np.ix_(energy.heavy,energy.heavy)] if len(energy.heavy) else np.empty((0,0))
                if model=='cold':
                    errors['baseline_constant_generator']=relative_error(matrices[:,number],np.broadcast_to(matrices[0,number],matrices[:,number].shape))
                reports[branch]=dict(refinements=refinements,primitive_sup_2=norm,sampled_minimum_singular=minimum,
                    closure=fine['closure'],phase_antiderivative_absolute=fine['unresolved'],period=fine['period'],
                    naive_factorization_absolute=float(np.max(abs(difference))),
                    naive_factorization_relative=relative_error(fine['mean'][:energy.size,:energy.size],separate),
                    heavy_mean=selected_mean.tolist())
                if model=='heavy':
                    require(all(item['mean_relative']<GATE and item['primitive_relative']<GATE for item in refinements),'phase refinement gate')
                    require(norm<1 and fine['unresolved']<GATE,'near-identity and primitive checks')
            write(output/(model+'-result.json'),dict(passed=max(errors.values())<GATE,errors=errors,branches=reports,
                phase_count=count,efold=efold,source_hash=digest(output/(model+'-phases.npz'))))
            require(max(errors.values())<GATE,'native phase family integrity')
            summaries.append(model)
        require(np.array_equal(before,system.context['point'](efold)),'context restored exactly')
        del energy,system
    require(inputs==verify_inputs() and provenance==native_provenance(),'parent integrity')
    write(output/'result.json',dict(passed=True,models=summaries,inputs=inputs,provenance=provenance,sources=sources()))


if __name__=='__main__':
    main()
