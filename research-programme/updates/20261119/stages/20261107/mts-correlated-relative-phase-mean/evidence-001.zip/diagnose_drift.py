from common import *
from mean_math import phase_primitive,fourth_derivative
import numpy as np


def main():
    modest()
    output=ROOT/'drift-diagnosis'
    output.mkdir(exist_ok=False)
    bank=load(ROOT/'mean-01/heavy-phases.npz')
    records=[]
    for number,branch in enumerate(('gr','poisson-spatial')):
        pieces={}
        for name in ('background','energy_cosine'):
            values={}
            for multiplier in (-4,-2,-1,1,2,4):
                packet=load(ROOT/'drift-01'/(name+'-'+str(multiplier)+'.npz'))
                values[multiplier]=phase_primitive(packet['matrix'][:,number],packet['angular'])['primitive']
            coarse=fourth_derivative({step:values[step*2] for step in (-2,-1,1,2)},.002)
            fine=fourth_derivative({step:values[step] for step in (-2,-1,1,2)},.001)
            pieces[name]=fine-coarse
            largest=np.unravel_index(np.argmax(abs(fine-coarse)),fine.shape)
            spectrum=np.fft.fft((fine-coarse)[:,largest[1],largest[2]])/256
            modes=np.fft.fftfreq(256,d=1/256)
            row=dict(branch=branch,direction=name,max_absolute=float(np.max(abs(fine-coarse))),
                index=list(map(int,largest)),heavy_slots=bank['heavy'].tolist(),
                row_is_heavy=int(largest[1]) in bank['heavy'],column_is_heavy=int(largest[2]) in bank['heavy'],
                mode_amplitudes=[dict(mode=int(modes[index]),amplitude=float(abs(spectrum[index]))) for index in np.argsort(abs(spectrum))[-8:][::-1]],
                fine=float(fine[largest]),coarse=float(coarse[largest]))
            records.append(row)
    write(output/'result.json',dict(diagnostic_only=True,records=records,sources=sources(),inputs=verify_inputs()))
    print(json.dumps(records,indent=2))


if __name__=='__main__':
    main()
