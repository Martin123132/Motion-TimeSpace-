from common import *
import ctypes
import types
import numpy as np


def make_cell(value):
    return (lambda:value).__closure__[0]


class PhaseFibre:
    def __init__(self,system,efold):
        self.system=system
        self.original_point=system.context['point']
        self.original_spline=system.background_spline
        self.original_rhs=system.native_extended_rhs
        self.anchor=float(efold)
        point=self.original_point(efold)
        self.tau_origin=float(point[11]-point[4])
        self.initial_fields=system.background['initial_fields']
        self.masses=system.background['masses']
        phi_s=self.initial_fields[0]+point[0]
        rho_h=0.
        theta=0.
        if system.model=='heavy':
            position=np.exp(efold)*self.masses[1]*(self.initial_fields[1]+point[2])
            rho_h=(position**2+point[3]**2)/2
            theta=float(np.arctan2(-point[3],position))
        self.initial_state=np.array([efold,phi_s,point[1],rho_h,point[11]],dtype=float)
        self.initial_theta=theta
        lib=system.context['lib']
        self.bridge_values=(ctypes.c_double*5).in_dll(lib,'__mtstwofield_MOD_mts_bridge_values')
        self.bridge_rates=(ctypes.c_double*5).in_dll(lib,'__mtstwofield_MOD_mts_bridge_rates')
        self.bridge_tau=ctypes.c_double.in_dll(lib,'__mtstwofield_MOD_mts_bridge_tau')
        self.cache={}
        self.state=None

    def __enter__(self):
        self.system.context['point']=self.point
        self.system.background_spline=self.spline
        original=self.original_rhs
        require('point' in original.__code__.co_freevars,'owned RHS point closure')
        closure=tuple(make_cell(self.point) if name=='point' else cell
                      for name,cell in zip(original.__code__.co_freevars,original.__closure__))
        self.system.native_extended_rhs=types.FunctionType(original.__code__,original.__globals__,
                                                          original.__name__,original.__defaults__,closure)
        self.install(self.initial_state,self.initial_theta)
        return self

    def __exit__(self,*ignored):
        self.system.context['point']=self.original_point
        self.system.background_spline=self.original_spline
        self.system.native_extended_rhs=self.original_rhs
        self.original_point(self.anchor)

    def external(self,efold):
        key=float(efold)
        if key not in self.cache:
            old=self.original_point(key)
            observed=self.system.context['observe'](old[11],self.system.zero_native)
            hubble=old[12]
            enthalpy=observed[0]+observed[1]
            hubble_rate,gravity_rate=self.original_spline(key,1)
            gravity=3*hubble*enthalpy/(2*self.system.wave**2)
            enthalpy_rate=2*self.system.wave**2/(3*hubble)*(gravity_rate-gravity*hubble_rate/hubble)
            scalar_density=scalar_enthalpy=scalar_enthalpy_rate=0.
            for species in range(2 if self.system.model=='heavy' else 1):
                field=self.initial_fields[species]+old[2*species]
                velocity=old[2*species+1]
                omega=np.exp(key)*self.masses[species]
                scalar_density+=(velocity**2+(omega*field)**2)/2
                scalar_enthalpy+=velocity**2
                scalar_enthalpy_rate+=2*velocity*old[2*species+6]
            self.cache[key]=dict(point=old.copy(),density=3*hubble**2-scalar_density,
                                 enthalpy=enthalpy-scalar_enthalpy,enthalpy_rate=enthalpy_rate-scalar_enthalpy_rate)
        return self.cache[key]

    def install(self,state,theta):
        guard()
        self.state=np.asarray(state,dtype=float).copy()
        self.theta=float(theta)
        efold,field_s,velocity_s,rho_h,clock=self.state
        require(rho_h>=0 and self.system.background['efold'][0]<=efold<=self.system.background['efold'][-1],
                'instantaneous state inside owned early background domain')
        exterior=self.external(efold)
        scale=np.exp(efold)
        rho_s=(velocity_s**2+(scale*self.masses[0]*field_s)**2)/2
        hubble=np.sqrt((exterior['density']+rho_s+rho_h)/3)
        if self.system.model=='heavy':
            field_h=np.sqrt(2*rho_h)*np.cos(theta)/(scale*self.masses[1])
            velocity_h=-np.sqrt(2*rho_h)*np.sin(theta)
        else:
            require(rho_h==0,'baseline has no heavy scalar')
            field_h=velocity_h=0.
        fields=np.array([field_s,field_h])
        velocities=np.array([velocity_s,velocity_h])
        velocity_rates=-2*velocities-(scale*self.masses)**2*fields/hubble
        enthalpy=exterior['enthalpy']+np.dot(velocities,velocities)
        hubble_rate=hubble-enthalpy/(2*hubble)
        enthalpy_rate=exterior['enthalpy_rate']+2*np.dot(velocities,velocity_rates)
        point=exterior['point'].copy()
        point[:5]=[field_s-self.initial_fields[0],velocity_s,field_h-self.initial_fields[1],velocity_h,clock-self.tau_origin]
        point[5:10]=[velocity_s/hubble,velocity_rates[0],velocity_h/hubble,velocity_rates[1],1/hubble]
        point[10:13]=[scale,clock,hubble]
        self.current=point
        self.background_value=np.array([hubble,3*hubble*enthalpy/(2*self.system.wave**2)])
        self.background_rate=np.array([hubble_rate,3*(hubble_rate*enthalpy+hubble*enthalpy_rate)/(2*self.system.wave**2)])
        self.flow=np.array([1.,velocity_s/hubble,velocity_rates[0],(-1+3*np.cos(2*theta))*rho_h,1/hubble])
        self.mu=scale*self.masses[1]/hubble if self.system.model=='heavy' else 1.
        self.angular_rate=self.mu-1.5*np.sin(2*theta) if self.system.model=='heavy' else 1.
        return self.point(efold)

    def point(self,efold):
        require(abs(efold-self.state[0])<1e-12,'fibre is an instantaneous jet, not a background extrapolation')
        self.original_point(float(efold))
        self.bridge_values[:]=self.current[:5].tolist()
        self.bridge_rates[:]=self.current[5:10].tolist()
        self.bridge_tau.value=float(self.current[11])
        return self.current.copy()

    def spline(self,efold,derivative=0):
        require(abs(efold-self.state[0])<1e-12 and derivative in (0,1),'owned local background jet')
        return (self.background_rate if derivative else self.background_value).copy()
