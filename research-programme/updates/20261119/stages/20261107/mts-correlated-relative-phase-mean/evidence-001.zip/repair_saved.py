from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from phase_fibre import PhaseFibre
from stable_rows import repair
from mean_math import phase_primitive,fourth_derivative,remainder,relative_error
from run_native import native_provenance
import numpy as np


def main():
    modest()
    require(LABEL=='half','diagnosed half family only')
    output=ROOT/'stable-01'
    output.mkdir(exist_ok=False)
    (output/'contexts').mkdir()
    inputs,provenance=verify_inputs(),native_provenance()
    require(not read(ROOT/'drift-01/result.json')['passed'],'preserved original failure')
    packets={'center':ROOT/'mean-01/heavy-phases.npz'}
    for name in ('background','energy_cosine'):
        for multiplier in (-4,-2,-1,1,2,4):
            packets[name+'-'+str(multiplier)]=ROOT/'drift-01'/(name+'-'+str(multiplier)+'.npz')
    write(output/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),
        packets={name:dict(path=str(path),sha256=digest(path)) for name,path in packets.items()},
        unchanged_orders=[64,128,256],unchanged_drift_widths=[.002,.001],unchanged_inner_width=.01,
        numerical=GATE,algebra=ALGEBRA,scope='replace cancellation-prone heavy rows by the independently derived scalar equations; reuse all saved other-matter rows'))
    system=open_owned('heavy','stable-01/contexts')
    energy=PhysicalEnergyMap(system)
    original=load(packets['center'])
    efold=float(original['state'][0])
    before=system.context['point'](efold).copy()
    repairs={}
    with PhaseFibre(system,efold) as fibre:
        for name,path in packets.items():
            packet=load(path)
            errors=[]
            matrices=[]
            for phase in range(256):
                guard()
                corrected=repair(fibre,energy,packet['state'],np.pi*phase/256,packet['matrix'][phase])
                errors.append(float(np.max(abs(corrected-packet['matrix'][phase]))))
                matrices.append(corrected)
                if phase%64==0:
                    print(LABEL,'stable saved',name,phase,'of256',flush=True)
            packet['matrix']=np.array(matrices)
            np.savez_compressed(output/(name+'.npz'),**packet)
            repairs[name]=dict(max_absolute=max(errors),source_sha256=digest(path),new_sha256=digest(output/(name+'.npz')))
            require(max(errors)<GATE,'unchanged absolute equation-agreement gate')
    require(np.array_equal(before,system.context['point'](efold)),'native context restoration')
    bank=load(output/'center.npz')
    saved=dict(state=bank['state'],theta=bank['theta'])
    errors={}
    reports={}
    for number,branch in enumerate(('gr','poisson-spatial')):
        terms={}
        for order in (64,128,256):
            stride=256//order
            center=phase_primitive(bank['matrix'][::stride,number],bank['angular'][::stride])
            derivatives={}
            for name in ('background','energy_cosine'):
                shifted={}
                for multiplier in (-4,-2,-1,1,2,4):
                    packet=load(output/(name+'-'+str(multiplier)+'.npz'))
                    shifted[multiplier]=phase_primitive(packet['matrix'][::stride,number],packet['angular'][::stride])['primitive']
                derivatives[name]={factor:fourth_derivative({step:shifted[step*factor] for step in (-2,-1,1,2)},.001*factor) for factor in (2,1)}
            for factor in (2,1):
                drift=derivatives['background'][factor]+np.cos(2*bank['theta'][::stride])[:,None,None]*derivatives['energy_cosine'][factor]
                residual=np.stack([remainder(matrix,center['mean'],local,rate) for matrix,local,rate in zip(bank['matrix'][::stride,number],center['primitive'],drift)])
                terms[order,factor]=dict(drift=drift,remainder=residual,primitive=center['primitive'],mean=center['mean'],coefficients=center['coefficients'])
        errors[branch+'_drift_width']=relative_error(terms[256,2]['drift'],terms[256,1]['drift'])
        errors[branch+'_remainder_width']=relative_error(terms[256,2]['remainder'],terms[256,1]['remainder'])
        errors[branch+'_drift_phase']=relative_error(terms[128,1]['drift'],terms[256,1]['drift'][::2])
        errors[branch+'_remainder_phase']=relative_error(terms[128,1]['remainder'],terms[256,1]['remainder'][::2])
        fine=terms[256,1]
        errors[branch+'_mean_phase']=relative_error(terms[128,1]['mean'],fine['mean'])
        errors[branch+'_primitive_phase']=relative_error(terms[128,1]['primitive'],fine['primitive'][::2])
        norm_bound=sum(float(np.linalg.norm(value,ord=2)) for value in fine['coefficients'])
        reports[branch]=dict(sampled_remainder_sup_2=max(float(np.linalg.norm(value,ord=2)) for value in fine['remainder']),
            sampled_drift_sup_2=max(float(np.linalg.norm(value,ord=2)) for value in fine['drift']),
            primitive_fourier_polynomial_bound=norm_bound,primitive_polynomial_invertible=norm_bound<1,
            remainder_phase_absolute=float(np.max(abs(terms[128,1]['remainder']-fine['remainder'][::2]))),
            remainder_width_absolute=float(np.max(abs(terms[256,2]['remainder']-fine['remainder']))),
            drift_width_absolute=float(np.max(abs(terms[256,2]['drift']-fine['drift']))))
        for name,value in fine.items():
            saved[branch+'_'+name]=value
    np.savez_compressed(output/'remainder.npz',**saved)
    require(inputs==verify_inputs() and provenance==native_provenance(),'parent integrity')
    passed=max(errors.values())<GATE and all(row['primitive_polynomial_invertible'] for row in reports.values())
    write(output/'result.json',dict(passed=passed,inputs=inputs,provenance=provenance,sources=sources(),errors=errors,
        branches=reports,repairs=repairs,original_failed_attempt_preserved=True,
        packet_sha256=digest(output/'remainder.npz')))
    print(json.dumps(dict(passed=passed,errors=errors,branches=reports),indent=2),flush=True)
    require(passed,'stable-row refinement gate; preserve failure without retry')


if __name__=='__main__':
    main()
