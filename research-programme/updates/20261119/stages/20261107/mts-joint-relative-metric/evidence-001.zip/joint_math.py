from common import *
from relative_math import physical_rows,metric_rows
from forced_map import source_map,relative_transform
import numpy as np


def closed_map(item,metric,heavy):
    size=metric.shape[1]
    identity=np.eye(size)
    if not len(heavy):
        return dict(forward=identity,inverse=identity,feedback=0.,inverse_margin=1.,residual=0.)
    selector=identity[heavy]
    lift=selector.T
    transform=np.eye(2)+item['primitive']
    affine=item['affine']
    small=np.eye(2)-affine@metric[:,heavy]
    inverse_small=np.linalg.inv(small)
    forward=identity.copy()
    forward[heavy]=inverse_small@(transform@selector+affine@(metric-metric[:,heavy]@selector))
    inverse=identity.copy()
    inverse[heavy]=item['inverse']@(selector-affine@metric)
    residual=max(np.linalg.norm(inverse@forward-identity,ord=np.inf),
                 np.linalg.norm(forward@inverse-identity,ord=np.inf))
    scale=max(1.,np.linalg.norm(forward,ord=np.inf)*np.linalg.norm(inverse,ord=np.inf))
    require(residual/scale<ALGEBRA,'closed metric transformation inverse')
    return dict(forward=forward,inverse=inverse,feedback=float(np.linalg.norm(affine@metric[:,heavy],2)),
                inverse_margin=float(np.linalg.svd(small,compute_uv=False)[-1]),residual=float(residual/scale))


def relative_block(scalar,hubble,hubble_rate):
    omega,full=scalar['omega'],scalar['full_frequency']
    position,velocity=omega*scalar['field'],scalar['velocity']
    alpha=scalar['wave']**2/(omega*hubble)
    mu=omega/hubble
    eta=hubble_rate/hubble
    fraction=(position**2+velocity**2)/(4*hubble**2)
    theta=np.arctan2(-velocity,position)
    eta0=eta-fraction*np.cos(2*theta)
    normal=relative_transform(position,velocity,alpha)
    radius=position**2+velocity**2
    position_rate=position+mu*velocity
    velocity_rate=-2*velocity-mu*position
    radius_rate=2*(position*position_rate+velocity*velocity_rate)
    normal_rate=np.array([[2*position_rate,2*velocity_rate],[alpha*velocity_rate,-alpha*position_rate]])/radius
    normal_rate[1]-=(1+eta)*normal[1]
    normal_rate-=radius_rate/radius*normal
    rescaling=np.diag([omega/full,1.])
    rescaling_rate=np.diag([omega/full*(1-omega**2/full**2),0.])
    block=normal@rescaling
    derivative=normal_rate@rescaling+normal@rescaling_rate
    item=source_map(alpha,mu,eta0,fraction,theta)
    return block,derivative,item,dict(alpha=alpha,mu=mu,eta0=eta0,b=fraction,theta=theta,rho=radius/2)


def uniform_inverse(alpha_interval,mu_min,hubble_max,wave):
    alpha_min,alpha_max=alpha_interval
    affine_bounds=np.array([
        [(alpha_max/2+3)/(2*mu_min),(3*alpha_max/(4*mu_min)+3)/(2*mu_min)],
        [(alpha_max**2/4+alpha_max*4.5/2)/(2*mu_min),(3*alpha_max**2/(8*mu_min)+1.5*alpha_max)/(2*mu_min)]])
    affine=float(np.linalg.norm(affine_bounds,'fro'))
    density=3*hubble_max**2
    pressure=density*np.sqrt(1+4/alpha_min**2)
    current=density*hubble_max/wave*np.sqrt(alpha_max**2/4+4)
    free_density=density+3*pressure+density*np.sqrt(alpha_max**2/4+4)
    psi_poisson=density/(2*wave**2)
    phi_poisson=free_density/(2*wave**2)+(1+9*hubble_max**2/wave**2)*psi_poisson
    psi_gr=psi_poisson+3*hubble_max*current/(2*wave**3)
    phi_gr=(free_density+3*pressure+12*hubble_max*current/wave)/(2*wave**2)+psi_gr
    branches={}
    for branch,psi,rate in (('gr',psi_gr,phi_gr),('poisson-spatial',psi_poisson,phi_poisson)):
        row_bound=float(np.hypot(psi,rate))
        contraction=affine*row_bound
        require(contraction<1,'uniform heavy-metric inverse condition')
        branches[branch]=dict(metric_row_bound=row_bound,feedback_product_bound=contraction,
                              inverse_norm_bound=1/(1-contraction),minimum_singular_value_bound=1-contraction)
    return dict(affine_norm_bound=affine,positive_quadrature_only=True,hubble_max=hubble_max,branches=branches)
