from common import *
from cold_access import SavedBackground
from relative_math import metric_rows
from forced_map import source_map
from joint_math import uniform_inverse,closed_map
import numpy as np


def main():
    modest()
    ROOT.mkdir(exist_ok=False)
    inputs=verify_inputs()
    old=read(RELATIVE/'coefficient-01/result.json')
    write(ROOT/'freeze.json',dict(inputs=inputs,sources=sources(),gates=[ALGEBRA,GATE],
                                 external_test_fractions=[0.,.5,3.,6.,12.],
                                 purpose='positive-quadrature fixtures check a uniform analytic bound, not new cosmologies'))
    background=SavedBackground('heavy')
    grid=background.saved['efold'][background.saved['a']>=background.target['scale_start']*(1-1e-12)]
    values=background.mean(grid)
    span=float(grid[-1]-grid[0])
    hubble_max=float(values['upper'][0]*np.exp(span)*(1+ALGEBRA))
    records=[]
    for label,wave in read(WAVES)['waves']:
        owner=next(row for row in old['reports'] if row['model']=='heavy' and row['label']==label)
        bound=uniform_inverse(owner['alpha_interval'],owner['mu_min'],hubble_max,wave)
        maximum_feedback={branch:0. for branch in bound['branches']}
        maximum_residual=0.
        count=0
        for index in np.unique(np.linspace(0,len(grid)-1,9,dtype=int)):
            guard()
            omega=values['scale'][index]*background.masses[1]
            hubble=values['hubble'][index]
            alpha,mu=wave**2/(omega*hubble),omega/hubble
            rho=values['heavy'][index]
            external_enthalpy=(2*values['external'][index,0]-values['external'][index,1])/3+values['slow'][index,1]**2
            for theta in np.linspace(.137,2*np.pi+.137,33)[:-1]:
                item=source_map(alpha,mu,values['eta0'][index],values['eta_c'][index],theta)
                eta=values['eta0'][index]+values['eta_c'][index]*np.cos(2*theta)
                for fraction in (0.,.5,3.,6.,12.):
                    quadrature=fraction*hubble**2
                    external={name:np.zeros(2) for name in ('density','current','shear','free_density','free_current')}
                    external.update(quadrature_enthalpy=quadrature,enthalpy_defect=quadrature-external_enthalpy)
                    for branch in bound['branches']:
                        metric=metric_rows(branch,wave/hubble,wave,hubble,eta,rho,alpha,theta,external)
                        rows=np.vstack([metric['psi'],metric['phi_rate']])
                        result=closed_map(item,rows,np.array([0,1]))
                        require(result['feedback']<=bound['branches'][branch]['feedback_product_bound'],'phase fixture obeys global inverse bound')
                        maximum_feedback[branch]=max(maximum_feedback[branch],result['feedback'])
                        maximum_residual=max(maximum_residual,result['residual'])
                        count+=1
        records.append(dict(label=label,wave=wave,bound=bound,maximum_sampled_feedback=maximum_feedback,
                            maximum_inverse_residual=maximum_residual,fixtures=count,
                            same_physical_window=True,source_phase_assigned=False))
        print(label,bound['branches'],flush=True)
    baseline=closed_map(None,np.zeros((2,3)),np.array([],dtype=int))
    require(np.array_equal(baseline['forward'],np.eye(3)),'baseline identity')
    require(inputs==verify_inputs(),'inputs unchanged')
    write(ROOT/'result.json',dict(passed=True,reports=records,inputs=inputs,sources=sources(),
                                 baseline_identity=True,late_metric_history_generated=False))


if __name__=='__main__':
    main()
