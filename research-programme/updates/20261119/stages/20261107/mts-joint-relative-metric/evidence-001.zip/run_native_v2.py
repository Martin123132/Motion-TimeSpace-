import common

common.check_parent=common.verify_inputs
common.ROOT=common.STAGE/(common.LABEL+'-qualified')

from run_native import main

if __name__=='__main__':
    main()
