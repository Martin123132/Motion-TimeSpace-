from common import *
import numpy as np
import platform


def main():
    modest()
    destination=STAGE/'audit'
    destination.mkdir(exist_ok=False)
    inputs=verify_inputs()
    results=[STAGE/'summary/result.json']
    for label in ('half','balanced','double'):
        results.extend([STAGE/(label+'-qualified/result.json'),STAGE/(label+'-histories/result.json')])
    native=[];histories=[];recorded_sources={}
    for path in results:
        report=read(path)
        require(report['passed'],'accepted result')
        require(report['inputs']==inputs,'same upstream evidence')
        for source,expected in report['sources'].items():
            require(digest(source)==expected,'tested implementation unchanged')
            recorded_sources[source]=expected
        if path.parent.name.endswith('-qualified'):
            native.extend(report['reports'])
        elif path.parent.name.endswith('-histories'):
            for row in report['reports']:
                require(row['passed'],'saved history accepted')
                require(digest(row['source_path'])==row['source_sha256'],'history unchanged after transport')
                packet=load(path.parent/(row['model']+'-'+row['branch']+'.npz'))
                error=np.max(abs(packet['rebuilt_readouts']-packet['original_readouts']),axis=0)/np.maximum(np.max(abs(packet['original_readouts']),axis=0),1e-80)
                require(np.array_equal(error,np.array(list(row['readout_errors'].values()))),'independent saved readout calculation')
                require(len(packet['efold'])==13 and np.all(np.diff(packet['efold'])>0),'strict original epoch selection')
                require(np.max(error)<GATE,'unchanged physical-readout gate')
                histories.append(row)
    inverse=read(STAGE/'summary/result.json')
    algebra_max=max(max(report['algebra'].values()) for report in native)
    numerical_max=max(max(report['errors'].values()) for report in native)
    require(algebra_max<ALGEBRA and numerical_max<GATE,'native qualification gates')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
    require(not list(STAGE.rglob('__pycache__')),'no task bytecode')
    failed=read(STAGE/'native-half-01.end.json')
    require(failed['exit_code']==1 and not (STAGE/'half/result.json').exists(),'preserved import failure not promoted')
    result=dict(
        passed=True,inputs=inputs,sources=sources(),
        accepted_results={str(path):digest(path) for path in results},
        native_model_wavelength_cases=len(native),
        native_vectors=sum(report['native_vectors'] for report in native),
        maximum_native_numerical_error=numerical_max,maximum_native_algebra_error=algebra_max,
        maximum_native_generator_error=max(value for report in native for name,value in report['errors'].items() if name.endswith('_native_joint_generator')),
        maximum_inverse_derivative_refinement=max(value for report in native for name,value in report['errors'].items() if name.endswith('_derivative_refinement')),
        maximum_inverse_product_rule_error=max(value for report in native for name,value in report['errors'].items() if name.endswith('_inverse_product_rule')),
        maximum_native_tail_error=max(value for report in native for name,value in report['errors'].items() if name.endswith('_native_g192_tail')),
        preserved_histories=len(histories),transported_epochs=sum(len(row['selected_indices']) for row in histories),
        maximum_saved_readout_error=max(max(row['readout_errors'].values()) for row in histories),
        maximum_saved_state_roundtrip=max(row['maximum_state_roundtrip'] for row in histories),
        phase_positive_quadrature_fixtures=sum(row['fixtures'] for row in inverse['reports']),
        maximum_cold_feedback_bound=max(branch['feedback_product_bound'] for row in inverse['reports'] for branch in row['bound']['branches'].values()),
        expected_failure=dict(attempt='native-half-01',classification='diagnosed adapter import error before first numerical sample',accepted=False),
        original_bank_modified=False,late_history_generated=False,physical_initial_mode_reselected=False,
        python=platform.python_version(),new_background_or_late_ode_solves=0,
        native_context_prefix_replays=True)
    write(destination/'result.json',result)
    print(json.dumps({key:value for key,value in result.items() if key not in ('inputs','sources','accepted_results')},indent=2))


if __name__=='__main__':
    main()
