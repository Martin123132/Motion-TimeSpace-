import common

common.check_parent=common.verify_inputs
common.ROOT=common.STAGE/(common.LABEL+'-histories')

from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from native_joint import point_map
from run_native import native_provenance,norm_error
import numpy as np


def main():
    modest()
    require(LABEL!='summary','owned family')
    inputs=verify_inputs()
    provenance=native_provenance()
    owner=ORIGINAL_POISSON if LABEL=='balanced' else ORIGINAL_WAVES
    seal='ef83002ed38f0b3b940067968e41ac9bdb971a7c211fa51304677f47feb89ef9' if LABEL=='balanced' else '9d5f2606ce7642ef477772bfee5554525bedbd463b57aa3ed0ba4834036d075b'
    require(digest(owner/'closeout.json')==seal,'owned history seal')
    result_path=POISSON/'evolution-result.json'
    ownership=next(record for record in read(owner/'closeout.json')['artifacts'] if Path(record['path'])==result_path)
    require(digest(result_path)==ownership['sha256'],'owned history result')
    result=read(result_path)
    require(result['passed'],'saved independent metric histories accepted')
    ROOT.mkdir(exist_ok=False)
    (ROOT/'contexts').mkdir()
    write(ROOT/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),sample_count=13,
                                 include_initial_and_final=True,source_result=str(result_path),
                                 source_result_sha256=ownership['sha256'],gates=[ALGEBRA,GATE],
                                 new_ode_solves=0,purpose='transport existing physical preparations and readouts without changing them'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'contexts')
        energy=PhysicalEnergyMap(system)
        previous=next(item for item in result['reports'] if item['model']==model)
        for branch in ('gr','poisson-spatial'):
            packet_record=next(item for item in previous['rows'] if item['branch']==branch)
            path=Path(packet_record['packet'])
            require(digest(path)==packet_record['sha256'],'saved history bytes')
            with np.load(path) as archive:
                grid=archive['efold']
                indices=np.unique(np.linspace(0,len(grid)-1,13,dtype=int))
                states=archive['evolved_state'][indices]
                saved_values=archive['values'][indices]
                names=archive['value_names'].tolist()
                saved_rates=archive['rates'][indices]
                saved_hubble=archive['H'][indices]
                units=archive['units']
                require(np.array_equal(units,system.units),'native history units')
            transformed=[];core_physical=[];physical_errors=[];roundtrip=[]
            outputs=('D','Q','Pi','Psi','PhiN')
            for slot,(index,state) in enumerate(zip(indices,states)):
                guard()
                efold=float(grid[index])
                point=point_map(system,energy,efold)
                mapping=point['maps'][branch]
                physical=point['raw_transform']@(state[:energy.size]/system.units[:energy.size])
                joint=mapping['inverse']@physical
                rebuilt=mapping['forward']@joint
                restored=point['raw_inverse']@rebuilt
                roundtrip.append(norm_error(restored,state[:energy.size]/system.units[:energy.size]))
                compare=[]
                for name in ('density','current','shear'):
                    row=point['adapted']['rows'][name]@point['inverse_rotation']
                    compare.append(float(row@rebuilt))
                compare.extend((point['metrics'][branch]@rebuilt).tolist())
                expected=[saved_values[slot,names.index(name)] for name in outputs[:-1]]
                expected.append(saved_rates[slot,4]/saved_hubble[slot])
                physical_errors.append((compare,expected))
                core_physical.append(physical)
                transformed.append(joint)
            actual=np.array([item[0] for item in physical_errors])
            expected=np.array([item[1] for item in physical_errors])
            per_readout=np.max(abs(actual-expected),axis=0)/np.maximum(np.max(abs(expected),axis=0),1e-80)
            require(np.max(per_readout)<GATE,'saved physical readout preservation')
            require(max(roundtrip)<ALGEBRA,'saved state roundtrip')
            report=dict(model=model,branch=branch,passed=True,source_path=str(path),source_sha256=packet_record['sha256'],
                        selected_indices=indices.tolist(),readout_errors=dict(zip(outputs,per_readout.tolist())),
                        maximum_state_roundtrip=max(roundtrip),initial_and_final_preserved=True)
            np.savez_compressed(ROOT/(model+'-'+branch+'.npz'),efold=grid[indices],indices=indices,
                                physical_core=np.array(core_physical),joint_core=np.array(transformed),
                                original_readouts=expected,rebuilt_readouts=actual,names=np.array(outputs))
            reports.append(report)
            print(LABEL,model,branch,'saved-state readout error',float(np.max(per_readout)),flush=True)
            del states,saved_values,saved_rates
        del system,energy
    require(inputs==verify_inputs() and provenance==native_provenance(),'inputs unchanged')
    write(ROOT/'result.json',dict(passed=True,reports=reports,inputs=inputs,provenance=provenance,
                                 sources=sources(),new_ode_solves=0,new_initial_mode=False,
                                 scope='13 retained early epochs per existing native history; not a late cold evolution'))


if __name__=='__main__':
    main()
