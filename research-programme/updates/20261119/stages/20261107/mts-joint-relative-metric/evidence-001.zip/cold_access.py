from common import *
import ast


path=RELATIVE/'background_access.py'
tree=ast.parse(path.read_text(encoding='utf-8-sig'))
tree.body=[node for node in tree.body if not (isinstance(node,ast.ImportFrom) and node.module=='common')]
namespace=globals().copy()
namespace['PARENT']=COLD_BACKGROUND
namespace['ROOT']=RELATIVE
exec(compile(tree,str(path),'exec'),namespace)
SavedBackground=namespace['SavedBackground']
