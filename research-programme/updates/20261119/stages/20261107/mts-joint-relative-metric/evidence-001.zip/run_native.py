from common import *
from adjoint_operator import open_owned
from compact_adjoint import CompactAdjoint
from physical_energy_map import PhysicalEnergyMap
from native_joint import point_map,finite_rate,inverse_rate,branch_operator
from relative_math import metric_rows
import numpy as np
import time


def norm_error(left,right):
    return float(np.max(abs(left-right))/max(np.max(abs(left)),np.max(abs(right)),1e-80))


def native_provenance():
    directory=ORIGINAL_WAVES
    seal='9d5f2606ce7642ef477772bfee5554525bedbd463b57aa3ed0ba4834036d075b'
    require(digest(directory/'closeout.json')==seal,'native provenance seal')
    path=directory/'source-provenance.json'
    owned=next(row for row in read(directory/'closeout.json')['artifacts'] if Path(row['path'])==path)
    require(digest(path)==owned['sha256'],'native provenance owner')
    records={str(path):owned['sha256']}
    for record in read(path):
        guard()
        require(digest(record['path'])==record['sha256'],'retained native source')
        require(digest(record['owner'])==record['owner_sha256'],'retained source owner')
        records[record['path']]=record['sha256']
    return records


def main():
    modest()
    require(LABEL!='summary','explicit native wavelength')
    inputs=verify_inputs()
    provenance=native_provenance()
    ROOT.mkdir(exist_ok=False)
    (ROOT/'contexts').mkdir()
    write(ROOT/'freeze.json',dict(inputs=inputs,provenance=provenance,sources=sources(),
                                 algebra=ALGEBRA,numerical=GATE,sample_count=17,
                                 derivative_widths_over_max_mu=[.04,.02,.01],
                                 vector_seeds=[0,1,2],branches=['gr','poisson-spatial'],
                                 diagnostic_vectors_not_cosmological_initial_modes=True))
    reports=[]
    for model in ('heavy','cold'):
        started=time.monotonic()
        record=read(CHANNELS/LABEL/(model+'-channels.json'))['coefficient_input']
        require(digest(record['path'])==record['sha256'],'retained coefficient packet')
        packet=load(record['path'])
        operator=CompactAdjoint(packet)
        system=open_owned(model,'contexts')
        energy=PhysicalEnergyMap(system)
        require(np.array_equal(operator.units,system.units),'same native normalization')
        errors={};algebra={};rows=[]
        def check(name,value,exact=False):
            target=algebra if exact else errors
            target[name]=max(target.get(name,0.),float(value))
        grid=packet['efold']
        chosen=np.unique(np.linspace(int(.04*len(grid)),int(.96*len(grid)),17,dtype=int))
        for count,index in enumerate(chosen):
            guard()
            efold=float(grid[index]+.37*(grid[index+1]-grid[index]))
            point=point_map(system,energy,efold)
            mu=point['parameters']['mu'] if model=='heavy' else 100.
            width=.04/max(mu,1.)
            require(efold-2*width>grid[0] and efold+2*width<grid[-1],'owned derivative domain')
            derivatives={branch:[] for branch in point['maps']}
            for divisor in (1,2,4):
                step=width/divisor
                samples=[point_map(system,energy,efold+shift*step) for shift in (-2,-1,1,2)]
                for branch in point['maps']:
                    metric_rate=finite_rate(samples,'metric',branch,step)
                    analytic=inverse_rate(point,metric_rate,branch,energy.heavy)
                    direct=finite_rate(samples,'inverse',branch,step)
                    derivatives[branch].append((analytic,direct))
            for branch,mapping in point['maps'].items():
                inverse_derivative=derivatives[branch][-1][0]
                if model=='heavy':
                    check(branch+'_derivative_refinement',norm_error(derivatives[branch][-2][0],inverse_derivative))
                    check(branch+'_inverse_product_rule',norm_error(inverse_derivative,derivatives[branch][-1][1]))
                else:
                    check(branch+'_baseline_identity_derivative',np.max(abs(inverse_derivative)),True)
                check(branch+'_closed_inverse',mapping['residual'],True)
                core,into_core,into_tail,speed,tail_weights=branch_operator(operator,energy,point,efold,branch)
                forward,inverse=mapping['forward'],mapping['inverse']
                transformed=inverse@core@forward+inverse_derivative@forward
                if model=='heavy':
                    pars=point['parameters'];old=point['adapted']['old']
                    local={name:np.zeros(2) for name in ('density','current','shear','free_density','free_current')}
                    local.update(quadrature_enthalpy=old['quadrature']-pars['rho']*(1-np.cos(2*pars['theta'])),
                                 enthalpy_defect=old['defect'])
                    derived=metric_rows(branch,system.wave/old['hubble'],system.wave,old['hubble'],point['adapted']['eta'],
                                        pars['rho'],pars['alpha'],pars['theta'],local)
                    local_matrix=np.vstack([derived['psi'],derived['phi_rate']])
                    check(branch+'_heavy_metric_dictionary',norm_error(local_matrix,point['metrics'][branch][:,energy.heavy]))
                for seed in range(3):
                    vector=np.sin(np.arange(len(system.units))*(.7+seed)+count+.219)
                    physical=forward@vector[:energy.size]
                    native=np.empty(len(vector))
                    native[:energy.size]=(point['raw_inverse']@physical)*system.units[:energy.size]
                    tail=vector[energy.size:].reshape(190,5)
                    native[energy.size:]=(tail/tail_weights).reshape(-1)*system.units[energy.size:]
                    rate,values,rates,info,_,_=system.evaluate(efold,native,branch)
                    physical_rate=point['raw_transform']@(rate[:energy.size]/system.units[:energy.size])+point['logarithmic']@physical
                    actual=inverse@physical_rate+inverse_derivative@physical
                    expected=transformed@vector[:energy.size]
                    boundary=np.zeros(energy.size)
                    boundary[energy.quadrupoles]=into_core*tail[0]
                    expected+=inverse@boundary
                    check(branch+'_native_joint_generator',norm_error(actual,expected))
                    metric=point['metrics'][branch]@physical
                    for name,value,target,row in (
                        ('psi',metric[0],values['Psi'],point['metrics'][branch][0]),
                        ('phi_rate',metric[1],rates['Phi']/info['H'],point['metrics'][branch][1])):
                        check(branch+'_native_'+name,abs(value-target)/max(abs(target),np.linalg.norm(row)*np.linalg.norm(physical),1e-80))
                    recovered=point['raw_transform']@(native[:energy.size]/system.units[:energy.size])
                    check(branch+'_state_roundtrip',norm_error(vector[:energy.size],inverse@recovered),True)
                    for name,key in (('density','D'),('current','Q'),('shear','Pi')):
                        row=point['adapted']['rows'][name]@point['inverse_rotation']
                        check(branch+'_native_'+name,abs(row@physical-values[key])/max(abs(values[key]),np.linalg.norm(row)*np.linalg.norm(physical),1e-80))
                    actual_tail=tail_weights*(rate[energy.size:]/system.units[energy.size:]).reshape(190,5)+point['adapted']['tail_rate']*tail
                    expected_tail=point['adapted']['tail_rate']*tail
                    lower=operator.lower[1:,None]*speed*tail_weights[1:]/tail_weights[:-1]
                    upper=operator.upper[:-1,None]*speed*tail_weights[:-1]/tail_weights[1:]
                    expected_tail[1:]+=lower*tail[:-1]
                    expected_tail[:-1]+=upper*tail[1:]
                    expected_tail[0]+=into_tail*physical[energy.quadrupoles]
                    check(branch+'_native_g192_tail',norm_error(actual_tail,expected_tail))
                rows.append(dict(efold=efold,branch=branch,feedback=mapping['feedback'],inverse_margin=mapping['inverse_margin'],
                                 heavy_relative=model=='heavy',finite_difference_width=width/4,
                                 product_rule_discrepancy=norm_error(inverse_derivative,derivatives[branch][-1][1]) if model=='heavy' else 0.))
            if count%8==0:
                print(LABEL,model,'native sample',count+1,'seconds',round(time.monotonic()-started,2),flush=True)
        passed=max(errors.values())<GATE and max(algebra.values())<ALGEBRA
        report=dict(model=model,passed=passed,errors=errors,algebra=algebra,rows=rows,
                    coefficient_input=record,seconds=time.monotonic()-started,native_vectors=17*3*2,
                    new_late_perturbation_history=False)
        write(ROOT/(model+'-result.json'),report)
        require(passed,'preserve joint native discrepancy before changing anything')
        print(LABEL,model,'passed',passed,'maximum numerical error',max(errors.values()),flush=True)
        reports.append(report)
        del energy,system,operator,packet
    require(inputs==verify_inputs() and provenance==native_provenance(),'retained inputs unchanged')
    write(ROOT/'result.json',dict(passed=True,reports=reports,inputs=inputs,provenance=provenance,sources=sources(),
                                 exact_joint_generator_qualified=True,late_history_generated=False))


if __name__=='__main__':
    main()
