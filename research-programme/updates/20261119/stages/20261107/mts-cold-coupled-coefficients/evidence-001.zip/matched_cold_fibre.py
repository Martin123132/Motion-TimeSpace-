from cold_fibre import ColdFibre
from common import *
import numpy as np

class MatchedColdFibre(ColdFibre):
    def install(self,state,theta):
        super().install(state,theta)
        supplied_hubble=float(self.current[12])
        observed=self.system.context['observe'](float(state[4]),self.system.zero_native)
        native_hubble=float(observed[28])
        enthalpy=float(observed[0]+observed[1])
        require(abs(native_hubble/supplied_hubble-1)<ALGEBRA,'native background representation within unchanged gate')
        scale=self.current[10]
        velocity_rates=-2*self.velocities-(scale*self.masses)**2*self.fields/native_hubble
        exterior=self.saved.thermal.values([state[0]])[0]
        enthalpy_rate=(2*exterior[1]-exterior[2])/3+2*np.dot(self.velocities,velocity_rates)
        hubble_rate=native_hubble-enthalpy/(2*native_hubble)
        self.current[5:10]=[self.velocities[0]/native_hubble,velocity_rates[0],self.velocities[1]/native_hubble,velocity_rates[1],1/native_hubble]
        self.current[12]=native_hubble
        self.background_value=np.array([native_hubble,3*native_hubble*enthalpy/(2*self.system.wave**2)])
        self.background_rate=np.array([hubble_rate,3*(hubble_rate*enthalpy+native_hubble*enthalpy_rate)/(2*self.system.wave**2)])
        self.flow=np.array([1.,self.velocities[0]/native_hubble,velocity_rates[0],(-1+3*np.cos(2*theta))*state[3],1/native_hubble])
        self.mu=scale*self.masses[1]/native_hubble if self.system.model=='heavy' else 1.
        self.angular_rate=self.mu-1.5*np.sin(2*theta) if self.system.model=='heavy' else 1.
        self.representation_shift=native_hubble/supplied_hubble-1
        return self.point(float(state[0]))
