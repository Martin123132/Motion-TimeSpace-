from common import *
import numpy as np
import mpmath as mp

def repaired_logarithmic(system,energy,point,efold,digits=70):
    result=point['logarithmic'].copy()
    if system.model!='heavy':
        return result
    with mp.workdps(digits):
        scalar=point['adapted']['old']['scalars'][1]
        current=system.context['point'](efold)
        convert=lambda value:mp.mpf(float(value))
        hubble=convert(current[12])
        hubble_n=convert(system.background_spline(efold,1)[0])
        wave=convert(system.wave)
        omega=convert(scalar['omega'])
        full=mp.sqrt(wave**2+omega**2)
        mu=omega/hubble
        require(system.owner.phase(efold)[1]==float(scalar['omega']/current[12]),'owned mass-rate chart')
        chart_rate=mu
        field=convert(current[2])
        velocity=convert(current[3])
        velocity_n=-2*velocity-omega**2*field/hubble
        velocity_nn=-2*velocity_n-omega**2/hubble*((2-hubble_n/hubble)*field+velocity/hubble)
        ratio=omega**2/full**2
        factors=mp.matrix([full/(mp.exp(convert(efold))*mp.sqrt(omega)),mp.sqrt(omega)/mp.exp(convert(efold))])
        carrier=mp.matrix([[ratio-mp.mpf('1.5'),chart_rate*factors[0]/factors[1]],
                           [-chart_rate*factors[1]/factors[0],-mp.mpf('.5')]])
        alpha_unit=convert(system.units[system.alpha_slot])
        shift=mp.matrix([full*velocity,hubble*(velocity_n-velocity)])*alpha_unit
        shift_n=mp.matrix([full*(ratio*velocity+velocity_n),
                          hubble_n*(velocity_n-velocity)+hubble*(velocity_nn-velocity_n)])*alpha_unit
        position=omega*field
        position_n=position+mu*velocity
        radius=position**2+velocity**2
        radius_n=2*(position*position_n+velocity*velocity_n)
        alpha=wave**2/(omega*hubble)
        alpha_n=-(1+hubble_n/hubble)*alpha
        normal=mp.matrix([[2*position,2*velocity],[alpha*velocity,-alpha*position]])/radius
        normal_n=mp.matrix([[2*position_n,2*velocity_n],
                            [alpha_n*velocity+alpha*velocity_n,-alpha_n*position-alpha*position_n]])/radius-normal*radius_n/radius
        scaling=mp.diag([omega/full,1])
        scaling_n=mp.diag([omega/full*(1-ratio),0])
        rotation=normal*scaling
        rotation_n=normal_n*scaling+normal*scaling_n
        inverse=rotation**-1
        block=rotation_n*inverse+rotation*carrier*inverse
        gauge=rotation*(shift_n-carrier*shift)/convert(point['adapted']['old']['transform'][system.alpha_slot,system.alpha_slot])
        result[energy.heavy]=0.
        for row,slot in enumerate(energy.heavy):
            result[slot,system.alpha_slot]=float(gauge[row])
            for column,target in enumerate(energy.heavy):
                result[slot,target]=float(block[row,column])
    return result
