from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre
from cold_operator_v2 import local_slow_rates,stable_point,fourth
from cold_precision_v5 import repaired_geometry
from native_joint import point_map
from mean_math import relative_error
import poisson_driver
from native_context_v2 import factory
poisson_driver.factory=factory
import numpy as np

def angular_derivative(fibre,energy,state,theta,width):
    rows=[]
    for multiplier in (-2,-1,1,2):
        fibre.install(state,theta+multiplier*width)
        point=point_map(fibre.system,energy,float(state[0]))
        rows.append(np.stack([point['metrics'][branch] for branch in ('gr','poisson-spatial')]))
    return fourth(rows,width)

def prediction(values,theta):
    modes=np.fft.fftfreq(len(values),d=1/len(values))
    coefficients=np.fft.fft(values,axis=0)/len(values)
    return np.einsum('p,pbij->bij',np.exp(2j*modes*theta),coefficients).real

def main():
    modest()
    output=ROOT/'independent-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    bank_path=ROOT/'cold-midpoint-02/heavy-generator.npz'
    bank=load(bank_path)
    angles=[.187,1.317,2.713]
    frozen=np.array([prediction(bank['matrix'],theta) for theta in angles])
    np.savez_compressed(output/'frozen-predictions.npz',angles=angles,predictions=frozen)
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),bank_sha256=digest(bank_path),
        frozen_prediction_sha256=digest(output/'frozen-predictions.npz'),angles=angles,
        epoch_fractions=[0.,.5,1.],seeds=[0,1,2],gate=GATE,algebra=ALGEBRA,
        full_tail=192,scope='held-out midpoint angles and independent native endpoint coefficient/full-vector controls'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'independent-01/contexts')
        energy=PhysicalEnergyMap(system)
        with MatchedColdFibre(system) as fibre:
            for fraction in (0.,.5,1.):
                efold=float(np.log(fibre.saved.target['scale_start'])+fraction*fibre.saved.target['efold_span'])
                state,uncertainty=fibre.saved_state(efold)
                for angle_index,theta in enumerate(angles):
                    if model=='heavy':
                        slow,_=local_slow_rates(fibre,energy,state,theta,.001)
                        first=angular_derivative(fibre,energy,state,theta,.005)
                        refined=angular_derivative(fibre,energy,state,theta,.0025)
                        fibre.install(state,theta)
                        rate=slow+fibre.angular_rate*refined
                    else:
                        rate=np.zeros((2,2,energy.size))
                    sample=stable_point(fibre,energy,state,theta,rate)
                    point=point_map(system,energy,efold)
                    derivative=repaired_geometry(system,energy,point,efold)[0] if model=='heavy' else point['logarithmic']
                    errors=dict(native_scalar=max(sample['scalar_residual']))
                    if model=='heavy':
                        alternative=stable_point(fibre,energy,state,theta,slow+fibre.angular_rate*first)
                        errors['angular_width']=float(np.max(abs(sample['matrix']-alternative['matrix'])))
                        if fraction==.5:
                            errors['heldout_prediction']=float(np.max(abs(sample['matrix']-frozen[angle_index])))
                    size=energy.size
                    weights=point['adapted']['tail_weights']
                    speed=system.context['kinetic'](float(state[4]))[1]/fibre.current[12]
                    for branch_index,branch in enumerate(('gr','poisson-spatial')):
                        mapping=point['maps'][branch]
                        for seed in (0,1,2):
                            vector=np.sin(np.arange(len(system.units))*(.319+seed)+.137)
                            tail=vector[size:].reshape(190,5)
                            physical=mapping['forward']@vector[:size]
                            native=np.empty_like(vector)
                            native[:size]=point['raw_inverse']@physical*system.units[:size]
                            native[size:]=(tail/weights).ravel()*system.units[size:]
                            evaluated=system.evaluate(efold,native,branch)[0]/system.units
                            actual_relative=point['raw_transform']@evaluated[:size]+derivative@physical
                            actual_core=mapping['inverse']@actual_relative
                            if model=='heavy':
                                actual_core[energy.heavy]+=sample['inverse_rate'][branch_index]@physical
                            predicted_core=sample['matrix'][branch_index,:size]@vector[:size+10]
                            errors[branch+'_core']=max(errors.get(branch+'_core',0.),relative_error(actual_core,predicted_core))
                            if model=='heavy':
                                errors[branch+'_heavy']=max(errors.get(branch+'_heavy',0.),relative_error(actual_core[energy.heavy],predicted_core[energy.heavy]))
                            actual_tail=weights*evaluated[size:].reshape(190,5)+point['adapted']['tail_rate']*tail
                            degrees=np.arange(3,193)
                            expected=point['adapted']['tail_rate']*tail
                            expected[1:]+=(system.wave*degrees[1:,None]/(2*degrees[1:,None]+1)*speed*weights[1:]/weights[:-1])*tail[:-1]
                            expected[:-1]-=(system.wave*(degrees[:-1,None]+1)/(2*degrees[:-1,None]+1)*speed*weights[:-1]/weights[1:])*tail[1:]
                            expected[0]+=sample['matrix'][branch_index,size:size+5,:size]@vector[:size]
                            errors[branch+'_tail']=max(errors.get(branch+'_tail',0.),relative_error(actual_tail,expected))
                    report=dict(model=model,fraction=fraction,theta=theta,errors=errors,uncertainty=uncertainty,
                        parameters=sample['parameters'],representation_shift=fibre.representation_shift,
                        passed=max(errors.values())<GATE)
                    reports.append(report)
                    write(output/(model+'-'+str(len(reports))+'.json'),report)
                    require(report['passed'],'independent cold controls unchanged gate')
                    print(LABEL,model,fraction,theta,'maximum',max(errors.values()),flush=True)
    write(output/'result.json',dict(passed=True,reports=reports,inputs=inputs,sources=sources()))

if __name__=='__main__':
    main()
