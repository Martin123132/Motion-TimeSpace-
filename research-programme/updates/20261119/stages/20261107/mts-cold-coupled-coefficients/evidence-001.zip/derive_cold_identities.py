from common import *
import sympy as sp

def main():
    modest()
    output=ROOT/'identities-01'
    output.mkdir(parents=True,exist_ok=False)
    hubble,hubble_n,omega,wave,field,velocity,perturbation,perturbation_v,expansion=sp.symbols('H HN omega k phi v dphi dv z',nonzero=True,real=True)
    velocity_prime=-2*hubble*velocity-omega**2*field
    perturbation_prime=perturbation_v
    perturbation_v_prime=-2*hubble*perturbation_v-(wave**2+omega**2)*perturbation-wave*expansion*velocity
    density=velocity*perturbation_v+omega**2*field*perturbation
    pressure=velocity*perturbation_v-omega**2*field*perturbation
    current=wave*velocity*perturbation
    def conformal(expression):
        return sp.diff(expression,velocity)*velocity_prime+sp.diff(expression,field)*velocity+sp.diff(expression,omega)*hubble*omega+sp.diff(expression,perturbation)*perturbation_prime+sp.diff(expression,perturbation_v)*perturbation_v_prime
    checks=dict(scalar_density=sp.expand(conformal(density)+hubble*(density+3*pressure)+wave*current+wave*expansion*velocity**2),
                scalar_current=sp.expand(conformal(current)+2*hubble*current-wave*pressure))
    full=sp.symbols('Omega',positive=True)
    velocity_n=velocity_prime/hubble
    velocity_nn=-2*velocity_n-omega**2/hubble*((2-hubble_n/hubble)*field+velocity/hubble)
    carrier=sp.Matrix([[omega**2/full**2-sp.Rational(3,2),full/hubble],[-omega**2/(hubble*full),-sp.Rational(1,2)]])
    shift=sp.Matrix([full*velocity,hubble*(velocity_n-velocity)])
    shift_n=sp.Matrix([full*(omega**2/full**2*velocity+velocity_n),hubble_n*(velocity_n-velocity)+hubble*(velocity_nn-velocity_n)])
    simplified_shift=sp.Matrix([sp.Rational(5,2)*full*velocity,(sp.Rational(9,2)*hubble-3*hubble_n)*velocity+omega**2*field/2])
    gauge=(shift_n-carrier*shift-simplified_shift).applyfunc(sp.factor)
    checks.update({f'gauge_{index}':gauge[index] for index in range(2)})
    position,alpha,mu,eta=sp.symbols('x alpha mu eta',nonzero=True,real=True)
    radius=position**2+velocity**2
    normal=sp.Matrix([[2*position,2*velocity],[alpha*velocity,-alpha*position]])/radius
    normal_n=normal.diff(position)*(position+mu*velocity)+normal.diff(velocity)*(-2*velocity-mu*position)+normal.diff(alpha)*(-(1+eta)*alpha)
    normal_log=(normal_n*normal.inv()+normal*sp.Matrix([[-sp.Rational(1,2),mu],[-mu,-sp.Rational(1,2)]])*normal.inv()).applyfunc(sp.factor)
    checks['carrier_mu_cancels']=sp.simplify(sum(sp.diff(value,mu)**2 for value in normal_log))
    require(all(value==0 for value in checks.values()),'exact cold scalar cancellation identities')
    write(output/'result.json',dict(passed=True,identities={name:str(value) for name,value in checks.items()},
        normal_log=[[str(normal_log[row,column]) for column in range(2)] for row in range(2)],
        simplified_gauge=[str(value) for value in simplified_shift],sources=sources()))
    print(normal_log,flush=True)

if __name__=='__main__':
    main()
