from common import *
from adjoint_operator import open_owned,extract
import poisson_driver
from native_context_v2 import factory
poisson_driver.factory=factory
from physical_energy_map import PhysicalEnergyMap
from matched_cold_fibre import MatchedColdFibre as ColdFibre
from native_joint import point_map
from relative_math import coefficients
from cold_precision_v5 import direct_rows,repaired_geometry
import numpy as np
import mpmath as mp

def main():
    modest()
    output=ROOT/'precision-repair-07'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    system=open_owned('heavy','precision-repair-07/contexts')
    energy=PhysicalEnergyMap(system)
    records=[]
    mp.mp.dps=70
    with ColdFibre(system) as fibre:
        state=load(ROOT/'cold-midpoint-01/heavy-generator.npz')['state']
        for theta in (.0,.37,.8,1.1):
            fibre.install(state,theta)
            geometry=point_map(system,energy,float(state[0]))
            pars=geometry['parameters']
            scalar=coefficients(pars['alpha'],pars['mu'],pars['eta0'],pars['b'],pars['theta'])
            base,inject,channels,_,_=extract(system,float(state[0]))
            _,meta=system.context['stress'](float(state[4]),system.zero_native)
            for branch,raw in (('gr',base),('poisson-spatial',base+inject@channels[0])):
                left=geometry['raw_transform'][energy.heavy]
                right=geometry['raw_inverse']
                derivative=repaired_geometry(system,energy,geometry,float(state[0]))[0][energy.heavy]
                expected=scalar['generator']@np.eye(energy.size)[energy.heavy]+np.outer(scalar['force_psi'],geometry['metrics'][branch][0])+np.outer(scalar['force_phi'],geometry['metrics'][branch][1])
                actual=direct_rows(system,energy,geometry,float(state[0]),raw)
                index=np.unravel_index(np.argmax(abs(actual-expected)),actual.shape)
                row,column=map(int,index)
                intermediate=[]
                for inner in range(energy.size):
                    intermediate.append(mp.fsum(mp.mpf(float(left[row,middle]))*float(raw[middle,inner]) for middle in np.flatnonzero(left[row])))
                total=mp.fsum(intermediate[inner]*float(right[inner,column]) for inner in np.flatnonzero(right[:,column]))+float(derivative[row,column])
                terms=[abs(intermediate[inner]*float(right[inner,column])) for inner in np.flatnonzero(right[:,column])]
                records.append(dict(theta=theta,branch=branch,index=[row,column],alpha_slot=system.alpha_slot,
                    error=float(actual[index]-expected[index]),rounded_product_mp_error=float(total-float(expected[index])),
                    cancellation_scale=float(mp.fsum(terms)+abs(derivative[index])),
                    native_hubble=float(meta[1]),supplied_hubble=fibre.current[12],
                    hubble_relative=float(meta[1]/fibre.current[12]-1),expected=float(expected[index]),
                    derivative=float(derivative[index])))
    write(output/'result.json',dict(records=records,sources=sources(),purpose='high-precision coordinate derivative; original failed gate retained'))
    print(records,flush=True)

if __name__=='__main__':
    main()
