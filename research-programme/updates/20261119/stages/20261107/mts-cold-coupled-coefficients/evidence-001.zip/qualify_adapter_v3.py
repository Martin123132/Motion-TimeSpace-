from common import *
from adjoint_operator import open_owned
from matched_cold_fibre import MatchedColdFibre as ColdFibre
import poisson_driver
from native_context_v2 import factory
poisson_driver.factory=factory
from physical_energy_map import PhysicalEnergyMap
from native_joint import point_map
import ctypes
import numpy as np

def relative(left,right):
    return float(np.max(abs(left-right))/max(np.max(abs(left)),np.max(abs(right)),1e-80))

def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'qualification-03'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),build=digest(STAGE/'build-canonical-stress/build-result.json'),
        gate=GATE,algebra=ALGEBRA,phase_samples=[0.,.37,1.1],scope='instantaneous cold coefficients; no late perturbation trajectory or initial phase'))
    rows=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'qualification-03/contexts')
        energy=PhysicalEnergyMap(system)
        lib=system.context['lib']
        lib.mts_bridge_thermal_read.argtypes=[ctypes.c_double,ctypes.POINTER(ctypes.c_double)]
        lib.mts_bridge_thermal_read.restype=None
        with ColdFibre(system) as fibre:
            targets=fibre.saved.target
            selected=np.linspace(float(np.log(targets['scale_start'])),float(np.log(targets['scale_end'])),3)
            for efold in selected:
                state,uncertainty=fibre.saved_state(float(efold))
                for theta in ([0.,.37,1.1] if model=='heavy' else [0.]):
                    fibre.install(state,theta)
                    point=point_map(system,energy,float(efold))
                    observed=system.context['observe'](float(state[4]),system.zero_native)
                    background_error=relative(observed[:2],fibre.expected)
                    thermal=np.zeros(6)
                    lib.mts_bridge_thermal_read(float(state[4]),thermal.ctypes.data_as(ctypes.POINTER(ctypes.c_double)))
                    scale_error=abs(thermal[0]/np.exp(efold)-1)
                    map_error=max(relative(value['forward']@value['inverse'],np.eye(energy.size)) for value in point['maps'].values())
                    rng=np.random.default_rng(20261107)
                    state_vector=rng.normal(size=len(system.units))*system.units
                    native={}
                    for branch in ('gr','poisson-spatial'):
                        derivative,values,rates,info,_,_=system.evaluate(float(efold),state_vector,branch)
                        require(np.all(np.isfinite(derivative)) and all(np.isfinite(value) for value in values.values()),'finite native response')
                        native[branch]=dict(maximum_rate=float(np.max(abs(derivative/system.units))),psi=float(values['Psi']))
                    row=dict(model=model,efold=float(efold),theta=theta,mu=fibre.mu,state=state.tolist(),uncertainty=uncertainty,
                             background_error=background_error,map_error=map_error,scale_error=scale_error,thermal=thermal.tolist(),native=native)
                    rows.append(row)
                    write(output/(model+'-'+str(len(rows))+'.json'),row)
                    require(background_error<ALGEBRA and map_error<ALGEBRA and scale_error<ALGEBRA,'native instantaneous qualification')
                    print(model,float(efold),theta,'background',background_error,'map',map_error,flush=True)
        require(not ctypes.c_int.in_dll(lib,'__mtstwofield_MOD_mts_instant_active').value,'instant mode cleared')
    write(output/'result.json',dict(passed=True,rows=rows,inputs=inputs,sources=sources()))

if __name__=='__main__':
    main()
