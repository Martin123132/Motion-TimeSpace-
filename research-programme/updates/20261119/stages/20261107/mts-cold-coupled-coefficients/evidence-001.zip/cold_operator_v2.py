from common import *
import numpy as np
from native_joint import point_map,inverse_rate
from adjoint_operator import extract
from relative_math import coefficients
from cold_precision_v5 import direct_rows

def fourth(samples,width):
    return (samples[0]-8*samples[1]+8*samples[2]-samples[3])/(12*width)

def spectral_rate(values):
    count=len(values)
    modes=np.fft.fftfreq(count,d=1/count)
    result=np.fft.ifft(np.fft.fft(values-values[0],axis=0)*(2j*modes.reshape((-1,)+(1,)*(values.ndim-1))),axis=0)
    return result.real

def metric_samples(fibre,energy,state,angles):
    rows=[]
    inverses=[]
    for angle in angles:
        fibre.install(state,float(angle))
        point=point_map(fibre.system,energy,float(state[0]))
        rows.append(np.stack([point['metrics'][branch] for branch in ('gr','poisson-spatial')]))
        inverses.append(np.stack([point['maps'][branch]['inverse'][energy.heavy] for branch in ('gr','poisson-spatial')]))
    return np.array(rows),np.array(inverses)

def local_slow_rates(fibre,energy,state,theta,width):
    fibre.install(state,theta)
    direction=fibre.flow.copy()
    metrics=[]
    inverses=[]
    for multiplier in (-2,-1,1,2):
        shifted=state+multiplier*width*direction
        fibre.install(shifted,theta)
        point=point_map(fibre.system,energy,float(shifted[0]))
        metrics.append(np.stack([point['metrics'][branch] for branch in ('gr','poisson-spatial')]))
        inverses.append(np.stack([point['maps'][branch]['inverse'][energy.heavy] for branch in ('gr','poisson-spatial')]))
    fibre.install(state,theta)
    return fourth(metrics,width),fourth(inverses,width)

def stable_point(fibre,energy,state,theta,metric_derivatives):
    fibre.install(state,theta)
    system=fibre.system
    point=point_map(system,energy,float(state[0]))
    base,injection,channels,_,_=extract(system,float(state[0]))
    matrices=[]
    raw_relative=[]
    derivative_rows=[]
    scalar_residual=[]
    size=energy.size
    tail_weights=point['adapted']['tail_weights'].copy()
    speed=system.context['kinetic'](fibre.current[11])[1]/fibre.current[12]
    tail_units=system.units[size:size+5]
    core_units=system.units[energy.quadrupoles]
    into=point['raw_transform'][:,energy.quadrupoles]*(-3*system.wave*speed*tail_units/(5*core_units)/tail_weights[0])[None,:]
    out=(3*system.wave*speed*core_units/(7*tail_units)*tail_weights[0])[:,None]*point['raw_inverse'][energy.quadrupoles]
    for number,(branch,raw) in enumerate((('gr',base),('poisson-spatial',base+injection@channels[0]))):
        mapping=point['maps'][branch]
        inverse,forward=mapping['inverse'],mapping['forward']
        relative=point['raw_transform']@raw@point['raw_inverse']+point['logarithmic']
        if system.model=='heavy':
            pars=point['parameters']
            scalar=coefficients(pars['alpha'],pars['mu'],pars['eta0'],pars['b'],pars['theta'])
            scalar_rows=scalar['generator']@np.eye(size)[energy.heavy]+np.outer(scalar['force_psi'],point['metrics'][branch][0])+np.outer(scalar['force_phi'],point['metrics'][branch][1])
            independent=direct_rows(system,energy,point,float(state[0]),raw)
            scalar_residual.append(float(np.max(abs(independent-scalar_rows))))
            relative[energy.heavy]=scalar_rows
            derivative=inverse_rate(point,metric_derivatives[number],branch,energy.heavy)
        else:
            scalar_residual.append(0.)
            derivative=np.zeros_like(relative)
        core=inverse@relative@forward+derivative@forward
        matrix=np.zeros((size+10,size+10))
        matrix[:size,:size]=core
        matrix[:size,size:size+5]=inverse@into
        matrix[size:size+5,:size]=out@forward
        indices=np.arange(5)
        matrix[size+indices,size+indices]=point['adapted']['tail_rate']
        matrix[size+5+indices,size+5+indices]=point['adapted']['tail_rate']
        matrix[size+indices,size+5+indices]=-4*system.wave*speed/7*tail_weights[0]/tail_weights[1]
        matrix[size+5+indices,size+indices]=4*system.wave*speed/9*tail_weights[1]/tail_weights[0]
        matrices.append(matrix)
        raw_relative.append(relative)
        derivative_rows.append(derivative[energy.heavy])
    return dict(matrix=np.array(matrices),relative=np.array(raw_relative),inverse_rate=np.array(derivative_rows),
                scalar_residual=scalar_residual,angular_rate=fibre.angular_rate,mu=fibre.mu,
                parameters=point['parameters'],feedback=[point['maps'][branch]['feedback'] for branch in ('gr','poisson-spatial')])
