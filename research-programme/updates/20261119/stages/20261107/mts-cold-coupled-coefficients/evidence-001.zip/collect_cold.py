from common import *
from adjoint_operator import open_owned
from physical_energy_map import PhysicalEnergyMap
from cold_fibre import ColdFibre
from cold_operator import metric_samples,spectral_rate,local_slow_rates,stable_point
from native_joint import point_map,inverse_rate
from mean_math import phase_primitive,relative_error
import numpy as np

def main():
    modest()
    require(read(STAGE/'half/qualification-02/result.json')['passed'],'native adapter qualified')
    inputs=verify_inputs()
    output=ROOT/'cold-midpoint-01'
    output.mkdir(parents=True,exist_ok=False)
    (output/'contexts').mkdir()
    angles=np.arange(256)*np.pi/256
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),gate=GATE,algebra=ALGEBRA,
        angles=angles.tolist(),orders=[64,128,256],slow_widths=[.002,.001],
        native_qualification=digest(STAGE/'half/qualification-02/result.json'),
        scope='cold midpoint instantaneous generator and physical-clock phase mean; background uncertainty retained separately'))
    reports=[]
    for model in ('heavy','cold'):
        system=open_owned(model,'cold-midpoint-01/contexts')
        energy=PhysicalEnergyMap(system)
        with ColdFibre(system) as fibre:
            efold=float(np.log(fibre.saved.target['scale_start'])+.5*fibre.saved.target['efold_span'])
            state,uncertainty=fibre.saved_state(efold)
            chosen=angles if model=='heavy' else np.array([0.])
            metrics,inverses=metric_samples(fibre,energy,state,chosen)
            np.savez_compressed(output/(model+'-metrics.npz'),metrics=metrics,inverses=inverses,state=state,angles=chosen)
            phase_rate=spectral_rate(metrics) if model=='heavy' else np.zeros_like(metrics)
            inverse_phase=spectral_rate(inverses) if model=='heavy' else np.zeros_like(inverses)
            refinements=[]
            if model=='heavy':
                for step in (4,2):
                    refinements.append(float(np.max(abs(spectral_rate(metrics[::step])-phase_rate[::step]))))
            matrices=[]
            angular=[]
            deriv_errors=[]
            width_errors=[]
            raw_errors=[]
            feedback=[]
            alternate=[]
            for index,theta in enumerate(chosen):
                guard()
                slow,slow_inverse=local_slow_rates(fibre,energy,state,float(theta),.001) if model=='heavy' else (np.zeros_like(metrics[index]),np.zeros_like(inverses[index]))
                fibre.install(state,float(theta))
                metric_rate=slow+fibre.angular_rate*phase_rate[index]
                exact=stable_point(fibre,energy,state,float(theta),metric_rate)
                matrices.append(exact['matrix'])
                angular.append(exact['angular_rate'])
                raw_errors.append(exact['scalar_residual'])
                feedback.append(exact['feedback'])
                direct=slow_inverse+fibre.angular_rate*inverse_phase[index]
                deriv_errors.append(float(np.max(abs(exact['inverse_rate']-direct))) if model=='heavy' else 0.)
                if index%32==0 and model=='heavy':
                    coarse,_=local_slow_rates(fibre,energy,state,float(theta),.002)
                    fibre.install(state,float(theta))
                    other=stable_point(fibre,energy,state,float(theta),coarse+fibre.angular_rate*phase_rate[index])
                    width_errors.append(float(np.max(abs(other['matrix']-exact['matrix']))))
                    alternate.append(other['matrix'])
                if index%32==0:
                    print(LABEL,model,'cold phase',index,'of',len(chosen),flush=True)
            matrices=np.array(matrices)
            angular=np.array(angular)
            np.savez_compressed(output/(model+'-generator.npz'),matrix=matrices,angular=angular,state=state,
                angles=chosen,metric_phase=phase_rate,inverse_phase=inverse_phase,raw_errors=raw_errors,
                inverse_derivative_error=deriv_errors,width_errors=width_errors,feedback=feedback,alternate=alternate)
            means={}
            mean_error=primitive_error=0.
            if model=='heavy':
                for branch in range(2):
                    final=phase_primitive(matrices[:,branch],angular)
                    for step in (4,2):
                        partial=phase_primitive(matrices[::step,branch],angular[::step])
                        mean_error=max(mean_error,float(np.max(abs(final['mean']-partial['mean']))))
                        primitive_error=max(primitive_error,float(np.max(abs(final['primitive'][::step]-partial['primitive']))))
                    means[str(branch)]=dict(period=final['period'],maximum_primitive=float(np.max(abs(final['primitive']))),
                        heavy_mean=final['mean'][np.ix_(energy.heavy,energy.heavy)].tolist(),maximum_mean=float(np.max(abs(final['mean']))))
                    np.savez_compressed(output/(model+'-mean-'+str(branch)+'.npz'),**final)
            report=dict(model=model,efold=efold,state=state.tolist(),uncertainty=uncertainty,means=means,
                phase_derivative_refinements=refinements,maximum_inverse_derivative_error=max(deriv_errors),
                maximum_slow_width_error=max(width_errors,default=0.),maximum_scalar_native_residual=float(np.max(raw_errors)),
                mean_error=mean_error,primitive_error=primitive_error,maximum_feedback=float(np.max(feedback)))
            reports.append(report)
            write(output/(model+'-checks.json'),report)
            require(max(deriv_errors)<GATE and max(width_errors,default=0.)<GATE,'separated derivative checks')
            require(mean_error<GATE and primitive_error<GATE,'unchanged phase refinement gate')
            require(float(np.max(raw_errors))<GATE,'independent native heavy rows')
    write(output/'result.json',dict(passed=True,reports=reports,inputs=inputs,sources=sources()))

if __name__=='__main__':
    main()
