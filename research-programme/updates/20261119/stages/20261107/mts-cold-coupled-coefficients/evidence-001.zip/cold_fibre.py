from common import *
import ctypes
import types
import numpy as np
from phase_fibre import make_cell
from cold_access import SavedBackground,namespace

class ColdFibre:
    def __init__(self,system):
        self.system=system
        self.saved=SavedBackground(system.model)
        self.original_point=system.context['point']
        self.original_spline=system.background_spline
        self.original_rhs=system.native_extended_rhs
        self.original_phase=system.owner.phase
        self.initial_fields=system.background['initial_fields']
        self.masses=np.asarray(system.background['masses'])
        self.restore_efold=float(system.background['efold'][0])
        self.restore_point=self.original_point(self.restore_efold).copy()
        self.chart_angle=0.
        lib=system.context['lib']
        pointer=ctypes.POINTER(ctypes.c_double)
        lib.mts_instantaneous_point.argtypes=[ctypes.c_double,ctypes.c_double,pointer,pointer,pointer]
        lib.mts_instantaneous_point.restype=None
        lib.mts_instantaneous_clear.argtypes=[]
        lib.mts_instantaneous_clear.restype=None
        self.lib=lib
        self.state=None

    def saved_state(self,efold):
        require(self.saved.saved['efold'][0]<=efold<=self.saved.saved['efold'][-1],'saved dense domain')
        mean=self.saved.mean(efold)
        values,_=namespace['dense_values'](self.saved.dense,np.array([efold]))
        config=self.saved.configuration
        clock=float(config['initial_clock']+values[0,2]/config['initial_hubble'])
        clock_error=float(values[0,4]/config['initial_hubble'])
        state=np.array([efold,mean['slow'][0,0]/(np.exp(efold)*self.masses[0]),
                        mean['slow'][0,1],mean['heavy'][0],clock])
        return state,dict(clock_error=clock_error,hubble_error=float(max(mean['hubble'][0]-mean['lower'][0],mean['upper'][0]-mean['hubble'][0])),
                          scalar_radius=float(mean['radius'][0]),heavy_log_width=float(mean['width'][0]))

    def __enter__(self):
        self.system.context['point']=self.point
        self.system.background_spline=self.spline
        self.system.background['initial_fields']=np.zeros(2)
        self.system.owner.phase=self.phase
        original=self.original_rhs
        require('point' in original.__code__.co_freevars,'owned RHS point closure')
        closure=tuple(make_cell(self.point) if name=='point' else cell
                      for name,cell in zip(original.__code__.co_freevars,original.__closure__))
        self.system.native_extended_rhs=types.FunctionType(original.__code__,original.__globals__,
                                                          original.__name__,original.__defaults__,closure)
        return self

    def __exit__(self,*ignored):
        self.lib.mts_instantaneous_clear()
        self.system.context['point']=self.original_point
        self.system.background_spline=self.original_spline
        self.system.native_extended_rhs=self.original_rhs
        self.system.background['initial_fields']=self.initial_fields
        self.system.owner.phase=self.original_phase
        restored=self.original_point(self.restore_efold)
        require(np.array_equal(restored,self.restore_point),'original context restored exactly')

    def install(self,state,theta):
        guard()
        self.state=np.asarray(state,dtype=float).copy()
        self.theta=float(theta)
        efold,field_s,velocity_s,rho_h,clock=self.state
        require(np.all(np.isfinite(state)) and rho_h>=0 and clock>0,'physical instantaneous state')
        scale=np.exp(efold)
        exterior=self.saved.thermal.values([efold])[0]
        rho_s=(velocity_s**2+(scale*self.masses[0]*field_s)**2)/2
        hubble=np.sqrt((exterior[0]+rho_s+rho_h)/3)
        if self.system.model=='heavy':
            field_h=np.sqrt(2*rho_h)*np.cos(theta)/(scale*self.masses[1])
            velocity_h=-np.sqrt(2*rho_h)*np.sin(theta)
        else:
            require(rho_h==0,'baseline heavy density zero')
            field_h=velocity_h=0.
        self.fields=np.ascontiguousarray([field_s,field_h])
        self.velocities=np.ascontiguousarray([velocity_s,velocity_h])
        velocity_rates=-2*self.velocities-(scale*self.masses)**2*self.fields/hubble
        exterior_enthalpy=(2*exterior[0]-exterior[1])/3
        exterior_enthalpy_rate=(2*exterior[1]-exterior[2])/3
        enthalpy=exterior_enthalpy+np.dot(self.velocities,self.velocities)
        hubble_rate=hubble-enthalpy/(2*hubble)
        enthalpy_rate=exterior_enthalpy_rate+2*np.dot(self.velocities,velocity_rates)
        self.current=np.array([field_s,velocity_s,field_h,velocity_h,clock,
            velocity_s/hubble,velocity_rates[0],velocity_h/hubble,velocity_rates[1],1/hubble,
            scale,clock,hubble])
        self.background_value=np.array([hubble,3*hubble*enthalpy/(2*self.system.wave**2)])
        self.background_rate=np.array([hubble_rate,3*(hubble_rate*enthalpy+hubble*enthalpy_rate)/(2*self.system.wave**2)])
        self.flow=np.array([1.,velocity_s/hubble,velocity_rates[0],(-1+3*np.cos(2*theta))*rho_h,1/hubble])
        self.mu=scale*self.masses[1]/hubble if self.system.model=='heavy' else 1.
        self.angular_rate=self.mu-1.5*np.sin(2*theta) if self.system.model=='heavy' else 1.
        self.expected=np.array([3*hubble**2,enthalpy-3*hubble**2])
        signature=np.ascontiguousarray(self.system.context['signature_values'],dtype=np.int32)
        self.lib.mts_operator_window(float(clock+max(1.,abs(clock)*.001)),signature.ctypes.data_as(ctypes.POINTER(ctypes.c_int)))
        return self.point(efold)

    def point(self,efold):
        require(self.state is not None and abs(efold-self.state[0])<1e-12,'instantaneous point only')
        rates=np.ascontiguousarray(self.current[5:10])
        pointer=ctypes.POINTER(ctypes.c_double)
        self.lib.mts_instantaneous_point(float(efold),float(self.current[11]),
            self.fields.ctypes.data_as(pointer),self.velocities.ctypes.data_as(pointer),rates.ctypes.data_as(pointer))
        return self.current.copy()

    def spline(self,efold,derivative=0):
        require(abs(efold-self.state[0])<1e-12 and derivative in (0,1),'owned instantaneous background jet')
        return (self.background_rate if derivative else self.background_value).copy()

    def phase(self,efold):
        require(abs(efold-self.state[0])<1e-12,'local computational chart only')
        return self.chart_angle,self.mu
