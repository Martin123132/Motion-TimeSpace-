from common import *
import ast
import platform
import numpy as np
from run_native import native_provenance
from mean_math import phase_primitive

def local_closure(entry):
    pending=[STAGE/entry]
    found=set()
    while pending:
        path=pending.pop()
        if path in found:
            continue
        found.add(path)
        tree=ast.parse(path.read_text(encoding='utf-8-sig'))
        for node in ast.walk(tree):
            names=[node.module] if isinstance(node,ast.ImportFrom) else ([item.name for item in node.names] if isinstance(node,ast.Import) else [])
            for name in names:
                if name:
                    candidate=STAGE/(name.split('.')[0]+'.py')
                    if candidate.exists():
                        pending.append(candidate)
    return found

def check_sources(report,entry):
    for path in local_closure(entry):
        require(str(path) in report['sources'] and digest(path)==report['sources'][str(path)],'executed source unchanged: '+str(path))

def main():
    modest()
    destination=STAGE/'audit'
    destination.mkdir(exist_ok=False)
    inputs=verify_inputs()
    provenance=native_provenance()
    accepted={}
    maxima={}
    summaries=[]
    control_count=0
    for label in ('half','balanced','double'):
        root=STAGE/label
        result_path=root/'cold-midpoint-02/result.json'
        result=read(result_path)
        require(result['passed'] and result['inputs']==inputs,'accepted midpoint inputs')
        check_sources(result,'collect_cold_v2.py')
        accepted[str(result_path)]=digest(result_path)
        heavy=load(root/'cold-midpoint-02/heavy-generator.npz')
        baseline=load(root/'cold-midpoint-02/cold-generator.npz')
        require(heavy['matrix'].shape[0]==256 and baseline['matrix'].shape[0]==1,'retained phase sampling')
        require(np.all(heavy['angular']>0),'monotone physical phase')
        for report in result['reports']:
            for name in ('maximum_inverse_derivative_error','maximum_slow_width_error','maximum_scalar_native_residual','mean_error','primitive_error'):
                maxima[name]=max(maxima.get(name,0.),report[name])
                require(report[name]<GATE,'unchanged numerical gate')
            require(report['maximum_hubble_representation_shift']<ALGEBRA,'native source representation')
        for branch in range(2):
            packet=load(root/f'cold-midpoint-02/heavy-mean-{branch}.npz')
            independently=np.tensordot(1/heavy['angular'],heavy['matrix'][:,branch],axes=1)/np.sum(1/heavy['angular'])
            error=float(np.max(abs(packet['mean']-independently)))/max(float(np.max(abs(independently))),1e-80)
            require(error<ALGEBRA,'physical-clock mean independently recomputed')
            recomputed=phase_primitive(heavy['matrix'][:,branch],heavy['angular'])
            require(float(np.max(abs(recomputed['primitive']-packet['primitive'])))<ALGEBRA,'primitive recomputed')
        checked_path=root/'independent-02/result.json'
        checked=read(checked_path)
        require(checked['passed'] and checked['inputs']==inputs and len(checked['reports'])==18,'independent phase/epoch coverage')
        check_sources(checked,'validate_cold_v2.py')
        accepted[str(checked_path)]=digest(checked_path)
        frozen=read(root/'independent-02/freeze.json')
        require(frozen['bank_sha256']==digest(root/'cold-midpoint-02/heavy-generator.npz'),'prediction bank frozen')
        require(frozen['frozen_prediction_sha256']==digest(root/'independent-02/frozen-predictions.npz'),'prediction freeze preserved')
        for reused in read(root/'independent-02/reused.json')['records']:
            require(digest(reused['path'])==reused['sha256'],'passing endpoint-prefix controls reused unchanged')
        coverage={(report['model'],report['fraction'],report['theta']) for report in checked['reports']}
        require(len(coverage)==18,'unique two-model three-epoch three-phase coverage')
        for report in checked['reports']:
            require(report['passed'],'native controls accepted')
            require(abs(report['representation_shift'])<ALGEBRA,'native background consistency')
            for name,value in report['errors'].items():
                maxima[name]=max(maxima.get(name,0.),value)
                require(value<GATE,'independent unchanged gate')
            control_count+=6
        summaries.append(dict(label=label,midpoint=result['reports'],independent_cases=len(checked['reports'])))
    qualifier=STAGE/'half/qualification-03/result.json'
    report=read(qualifier)
    require(report['passed'] and len(report['rows'])==12,'native API both backgrounds')
    check_sources(report,'qualify_adapter_v3.py')
    accepted[str(qualifier)]=digest(qualifier)
    identities=STAGE/'summary/identities-01/result.json'
    identity=read(identities)
    require(identity['passed'] and len(identity['identities'])==5 and all(value=='0' for value in identity['identities'].values()),'exact canonical cancellations')
    check_sources(identity,'derive_cold_identities.py')
    accepted[str(identities)]=digest(identities)
    for directory in ('build','build-canonical-stress'):
        built=read(STAGE/directory/'build-result.json')
        require(built['state']=='complete' and built['temporary_mappings_removed'],'isolated native build')
        for collection in ('original_input_hashes','reused_object_module_hashes','reused_bridge_hashes','copied_package_hashes'):
            for path,checksum in built[collection].items():
                require(digest(path)==checksum,'native input/package integrity: '+str(path))
        for name,checksum in built['source_sha256'].items():
            require(digest(STAGE/directory/name)==checksum,'native source integrity')
        require(built['dll_sha256']==digest(STAGE/directory/'native/camb/cambdll.dll'),'native binary integrity')
        accepted[str(STAGE/directory/'build-result.json')]=digest(STAGE/directory/'build-result.json')
    failed=read(STAGE/'half/cold-midpoint-01/heavy-checks.json')
    require(failed['maximum_scalar_native_residual']>GATE,'failed original precision gate retained')
    failed_starts=['build-01','qualify-01','cold-half-01','precision-repair-04','precision-repair-05','independent-half-01']
    for name in failed_starts:
        require(read(STAGE/(name+'.end.json'))['exit_code']==1,'failed attempt terminal receipt')
    compiled=[]
    for path in sorted(STAGE.rglob('*.py')):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec')
        compiled.append(str(path))
    require(not list(STAGE.rglob('__pycache__')),'no bytecode leftovers')
    write(destination/'result.json',dict(passed=True,inputs=inputs,provenance=provenance,accepted_results=accepted,
        sources=sources(),maxima=maxima,summaries=summaries,full_vector_checks=control_count,
        phase_coefficient_points=768,heldout_midpoint_angles=9,exact_identities=5,compiled=compiled,
        failed_attempts_preserved=failed_starts,platform=platform.platform(),python=platform.python_version(),
        numpy=np.__version__,float64_epsilon=np.finfo(float).eps,longdouble_epsilon=float(np.finfo(np.longdouble).eps),
        scope='cold instantaneous coupled coefficients and physical-clock means; no new late perturbation evolution'))
    print(json.dumps(dict(passed=True,maxima=maxima,full_vector_checks=control_count)),flush=True)

if __name__=='__main__':
    main()
