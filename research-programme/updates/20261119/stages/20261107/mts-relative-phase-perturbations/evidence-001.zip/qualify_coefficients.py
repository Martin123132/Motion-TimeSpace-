from common import *
from background_access import SavedBackground,verify_consumed_inputs
from relative_math import derive_symbolic,coefficients,uniform_bounds
import numpy as np
import csv


def main():
    modest()
    consumed=verify_consumed_inputs()
    derived=derive_symbolic()
    destination=ROOT/'coefficient-01'
    destination.mkdir(exist_ok=False)
    waves=read(WAVES)['waves']
    reports=[]
    table=[]
    for model in ('heavy','cold'):
        background=SavedBackground(model)
        saved=background.saved
        grid=saved['efold'][saved['a']>=background.target['scale_start']*(1-1e-12)]
        require(len(grid)>1 and abs(np.exp(grid[0])-background.target['scale_start'])<ALGEBRA,'unchanged cold grid start')
        points=background.mean(grid)
        recovery=float(np.max(abs(points['hubble']-saved['hubble'][saved['a']>=background.target['scale_start']*(1-1e-12)])/points['hubble']))
        require(recovery<ALGEBRA,'source-owned dense background readback')
        span=float(grid[-1]-grid[0])
        for label,wave in waves:
            base=dict(model=model,label=label,wave=wave,grid_points=len(grid),span=span,readback_error=recovery)
            if model=='cold':
                require(np.max(points['heavy'])==0,'baseline heavy field absent')
                base.update(relative_scalar_defined=False,control='CDM delta_N=-W+3Phi_N; W_N=-(1+eta)W+(k/H)^2Psi',heavy_averaging_bound=0.)
                reports.append(base)
                continue
            omega=points['scale']*background.masses[1]
            alpha=wave**2/(omega*points['hubble'])
            mu=omega/points['hubble']
            initial_lower=points['lower'][0]*(1-ALGEBRA)
            initial_upper=points['upper'][0]*(1+ALGEBRA)
            alpha_interval=(float(wave**2/(omega[0]*initial_upper)*np.exp(-2*span)),float(wave**2/(omega[0]*initial_lower)*np.exp(span)))
            mu_min=float(omega[0]/initial_upper)
            bound=uniform_bounds(derived,alpha_interval,mu_min,span)
            require(alpha.min()>=alpha_interval[0] and alpha.max()<=alpha_interval[1] and mu.min()>=mu_min,'sampled cold parameters inside analytic regime')
            maxima=dict(primitive=0.,inverse=0.,remainder=0.,background_generator_difference=0.)
            for index in range(len(grid)):
                delta_alpha2=wave**4/omega[index]**2*points['density_error'][index]/(3*points['lower'][index]**2*points['hubble'][index]**2)
                background_error=float(np.hypot(delta_alpha2/4,points['eta0_error'][index]))
                maxima['background_generator_difference']=max(maxima['background_generator_difference'],background_error)
                for theta in np.linspace(0,2*np.pi,33)[:-1]:
                    item=coefficients(alpha[index],mu[index],points['eta0'][index],points['eta_c'][index],theta)
                    maxima['primitive']=max(maxima['primitive'],float(np.linalg.norm(item['primitive'],2)))
                    maxima['inverse']=max(maxima['inverse'],float(np.linalg.norm(item['inverse'],2)))
                    maxima['remainder']=max(maxima['remainder'],float(np.linalg.norm(item['remainder'],2)))
                table.append(dict(model=model,label=label,efold=grid[index],a=points['scale'][index],alpha=alpha[index],mu=mu[index],
                                  eta0=points['eta0'][index],eta_c=points['eta_c'][index],background_generator_difference_bound=background_error))
            require(maxima['primitive']<=bound['primitive_bound'] and maxima['inverse']<=bound['inverse_bound'] and maxima['remainder']<=bound['remainder_bound'],'phase samples obey symbolic coefficient bounds')
            base.update(relative_scalar_defined=True,alpha_interval=alpha_interval,mu_min=mu_min,bound=bound,sampled_maxima=maxima,
                        homogeneous_gate_pass=bound['homogeneous_same_initial_relative_transfer_bound']<GATE,
                        phase_samples_are_not_a_late_phase_history=True,background_replacement_bound_not_yet_integrated=True)
            reports.append(base)
            print(model,label,'homogeneous bound',bound['homogeneous_same_initial_relative_transfer_bound'],'P',bound['primitive_bound'],flush=True)
    with (destination/'coefficients.csv').open('x',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(table[0]));writer.writeheader();writer.writerows(table)
    require(consumed==verify_consumed_inputs(),'consumed source snapshot unchanged')
    write(destination/'result.json',dict(state='coefficient_qualification_complete',passed=True,reports=reports,consumed=consumed,
                                       sources=sources(),late_phase_assigned=False,coupled_perturbation_evolution=False,
                                       acceptance_gates=dict(algebra=ALGEBRA,numerical=GATE)))


if __name__=='__main__':
    main()
