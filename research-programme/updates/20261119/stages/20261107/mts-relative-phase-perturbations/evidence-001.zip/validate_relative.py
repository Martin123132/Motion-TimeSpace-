from common import *
from background_access import SavedBackground,verify_consumed_inputs
from forced_map import symbolic_forcing,source_map,relative_transform,canonical_rate
from relative_math import coefficients,metric_rows,physical_rows
from scipy.integrate import solve_ivp
import numpy as np


def discrepancy(left,right):
    return float(np.max(abs(left-right)/(1+abs(left)+abs(right))))


def state_coefficients(point,wave):
    omega=point['scale']*read(PARENT/'extension/freeze.json')['configurations']['heavy']['masses'][1]
    alpha=wave**2/(omega*point['hubble'])
    mu=omega/point['hubble']
    return alpha,mu


def inspect_point(point,wave):
    alpha,mu=state_coefficients(point,wave)
    position,velocity=point['coordinates'][1]
    theta=point['theta']
    matrix=relative_transform(position,velocity,alpha)
    radius=position**2+velocity**2
    position_rate=position+mu*velocity
    velocity_rate=-2*velocity-mu*position
    radius_rate=2*position*position_rate+2*velocity*velocity_rate
    alpha_rate=-(1+point['eta'])*alpha
    matrix_rate=np.array([[2*position_rate,2*velocity_rate],[alpha*velocity_rate,-alpha*position_rate]])/radius
    matrix_rate[1]+=alpha_rate/alpha*matrix[1]
    matrix_rate-=radius_rate/radius*matrix
    original,_=canonical_rate(position,velocity,alpha,mu,0.,0.)
    forcing=np.array([[mu*velocity,0.],[-mu*position,3*velocity]])
    item=source_map(alpha,mu,point['eta0'],point['eta_c'],theta)
    transform=np.eye(2)+item['primitive']
    transform_rate=item['partial']+item['angular']*item['theta_rate']
    checks=dict(relative_operator=discrepancy(matrix_rate+matrix@original,item['generator']@matrix),
                relative_sources=discrepancy(matrix@forcing,item['forcing']),
                micromotion=discrepancy(item['generator']@transform-transform_rate,transform@item['transformed']),
                affine_forcing=discrepancy(item['generator']@item['affine']+item['forcing']-item['affine_rate'],transform@item['transformed_forcing']),
                source_derivative=discrepancy(-item['affine'],transform@item['forcing_derivative']))
    ratio=np.sqrt(1+alpha/mu)
    energy=np.diag([ratio,1.])
    energy_rate=np.diag([-alpha/(alpha+mu)*ratio,0.])
    full=np.array([[mu/(alpha+mu),mu*ratio],[-mu*ratio,-2.]])
    full_forcing=np.array([[ratio*mu*velocity,0.],[-mu*position,3*velocity]])
    checks['retained_full_frequency_operator']=discrepancy(energy@original+energy_rate,full@energy)
    checks['retained_full_frequency_injections']=discrepancy(energy@forcing,full_forcing)
    require(max(checks.values())<ALGEBRA,'independent coefficient identity')
    return checks


def metric_fixture(model,wave,hubble,eta,heavy_density,alpha,theta):
    ratio=wave/hubble
    density_scale=3*hubble**2
    density=np.array([0.,0.,.35,.12,.05])*density_scale
    current=np.array([0.,0.,.08,-.03,.02])*density_scale/ratio
    shear=np.array([0.,0.,.001,-.002,0.])*density_scale
    free_density=np.array([0.,0.,-.32,-.16,.01])*density_scale
    free_current=np.array([0.,0.,.04,.02,-.01])*density_scale
    external=dict(density=density,current=current,shear=shear,free_density=free_density,free_current=free_current,
                  quadrature_enthalpy=.7*density_scale,enthalpy_defect=.013*density_scale)
    output=[]
    for branch in ('gr','poisson-spatial'):
        item=metric_rows(branch,ratio,wave,hubble,eta,heavy_density,alpha,theta,external)
        total=item['rows']
        density_rate=total['free_density']+3*external['enthalpy_defect']*item['psi']+3*item['quadrature_enthalpy']*item['phi_rate']
        current_rate=total['free_current']+ratio*(item['quadrature_enthalpy']-external['enthalpy_defect'])*item['psi']
        expected_rate=-density_rate/(2*wave**2)
        if branch=='gr':
            expected_rate-=3*hubble*(eta*total['current']+current_rate)/(2*wave**3)
            expected_potential=-total['density']/(2*wave**2)-3*hubble*total['current']/(2*wave**3)-total['shear']/wave**2
        else:
            expected_potential=-total['density']/(2*wave**2)
        error=max(discrepancy(expected_rate,item['phi_rate']),discrepancy(expected_potential,item['psi']))
        require(error<ALGEBRA,'metric constraint and differentiated source identity')
        output.append(dict(model=model,branch=branch,error=error,scope='linear row fixture; not a new multi-species evolution'))
    return output


def force(efold,start,end):
    scaled=(efold-start)/(end-start)
    value=1e-6*np.array([np.cos(2*scaled),np.sin(3*scaled)])
    derivative=1e-6*np.array([-2*np.sin(2*scaled),3*np.cos(3*scaled)])/(end-start)
    return value,derivative


def evolve_probe(background,wave,start,end,times,method,tolerance):
    heavy=background.model=='heavy'
    initial=np.zeros((2,3))
    initial[:,:2]=np.eye(2)
    value,_=force(start,start,end)
    if heavy:
        point=background.resolved(start)
        alpha,mu=state_coefficients(point,wave)
        matrix=relative_transform(*point['coordinates'][1],alpha)
        item=source_map(alpha,mu,point['eta0'],point['eta_c'],point['theta'])
        original=np.linalg.solve(matrix,initial)
        shifted=initial.copy();shifted[:,2]-=item['affine']@value
        transformed=item['inverse']@shifted
    else:
        original=initial.copy();transformed=initial.copy()
    initial_state=np.concatenate([original.ravel(),transformed.ravel()])
    mass=background.masses[1]
    def rhs(efold,state):
        point=background.resolved(efold)
        value,derivative=force(efold,start,end)
        first=state[:6].reshape(2,3)
        second=state[6:].reshape(2,3)
        if heavy:
            omega=point['scale']*mass
            alpha,mu=wave**2/(omega*point['hubble']),omega/point['hubble']
            free,injection=canonical_rate(*point['coordinates'][1],alpha,mu,*value)
            item=source_map(alpha,mu,point['eta0'],point['eta_c'],point['theta'])
            first_rate=free@first
            first_rate[:,2]+=injection
            second_rate=item['transformed']@second
            second_rate[:,2]+=item['transformed_forcing']@value+item['forcing_derivative']@derivative
        else:
            matrix=np.array([[0.,-1.],[0.,-1-point['eta']]])
            injection=np.array([3*value[1],(wave/point['hubble'])**2*value[0]])
            first_rate=matrix@first;first_rate[:,2]+=injection
            second_rate=matrix@second;second_rate[:,2]+=injection
        return np.concatenate([first_rate.ravel(),second_rate.ravel()])
    solution=solve_ivp(rhs,(start,end),initial_state,method=method,rtol=tolerance,atol=tolerance/100,
                       t_eval=times,max_step=(end-start)/64)
    require(solution.success,'short prescribed-source diagnostic')
    original=solution.y[:6].T.reshape(-1,2,3)
    transformed=solution.y[6:].T.reshape(-1,2,3)
    direct=[];rebuilt=[]
    for efold,first,second in zip(times,original,transformed):
        if heavy:
            point=background.resolved(efold)
            alpha,mu=state_coefficients(point,wave)
            matrix=relative_transform(*point['coordinates'][1],alpha)
            item=source_map(alpha,mu,point['eta0'],point['eta_c'],point['theta'])
            recovered=(np.eye(2)+item['primitive'])@second
            recovered[:,2]+=item['affine']@force(efold,start,end)[0]
            direct.append(matrix@first);rebuilt.append(recovered)
        else:
            direct.append(first);rebuilt.append(second)
    direct,rebuilt=np.asarray(direct),np.asarray(rebuilt)
    error=discrepancy(direct,rebuilt)
    require(error<GATE,'canonical-to-affine evolved response check')
    return dict(efold=times,direct=direct,rebuilt=rebuilt),dict(error=error,nfev=solution.nfev,method=method,rtol=tolerance)


def main():
    modest()
    consumed=verify_consumed_inputs()
    destination=ROOT/'validation-01'
    destination.mkdir(exist_ok=False)
    backgrounds={model:SavedBackground(model) for model in ('heavy','cold')}
    end=min(background.replay['efold'][-1] for background in backgrounds.values())
    start=end-.01
    require(all(start>=background.replay['efold'][0] for background in backgrounds.values()),'shared existing early reference domain')
    controls=read(PARENT/'extension/freeze.json')['controls']
    write(destination/'freeze.json',dict(consumed=consumed,sources=sources(),shared_early_interval=[float(start),float(end)],
                                       prescribed_source='u=1e-6(cos(2s),sin(3s)); s=(N-start)/span; exact derivatives retained',
                                       initial_columns='two free relative basis vectors and zero-initial prescribed-force response',
                                       cold_control='CDM equations on its own repaired reference background',controls=controls,
                                       diagnostic_not_cosmological_initial_data=True,late_phase_assigned=False))
    symbolic=symbolic_forcing()
    identities=[];metrics=[];evolutions=[]
    for model,background in backgrounds.items():
        early_grid=background.replay['efold']
        early_points=early_grid[np.unique(np.linspace(0,len(early_grid)-1,49,dtype=int))]
        times=np.unique(np.concatenate(([start],early_grid[(early_grid>start)&(early_grid<end)],[end])))
        for label,wave in read(WAVES)['waves']:
            for point_time in early_points:
                point=background.resolved(float(point_time))
                if model=='heavy':
                    checks=inspect_point(point,wave)
                    identities.append(dict(model=model,label=label,efold=float(point_time),checks=checks))
                    alpha,mu=state_coefficients(point,wave)
                    density=point['density'][1];theta=point['theta']
                else:
                    alpha,density,theta=1.,0.,0.
                metrics.extend(metric_fixture(model,wave,point['hubble'],point['eta'],density,alpha,theta))
            controls_saved={};details=[]
            for control,method,tolerance in controls:
                packet,report=evolve_probe(background,wave,start,end,times,method,tolerance)
                np.savez_compressed(destination/(model+'-'+label+'-'+control+'.npz'),**packet)
                controls_saved[control]=packet;details.append(dict(control=control,**report))
                print(model,label,control,'identity error',report['error'],'nfev',report['nfev'],flush=True)
            refinement=max(discrepancy(controls_saved[control]['direct'],controls_saved['fine']['direct']) for control in ('base','independent'))
            require(refinement<GATE,'same unchanged independent-evolution gate')
            evolutions.append(dict(model=model,label=label,controls=details,refinement=refinement,output_points=len(times)))
    zero_rejected=False
    try:
        relative_transform(0.,0.,1.)
    except ValueError:
        zero_rejected=True
    require(zero_rejected,'zero-density relative coordinate must be refused')
    require(consumed==verify_consumed_inputs(),'consumed inputs unchanged')
    write(destination/'result.json',dict(passed=True,symbolic={key:value for key,value in symbolic.items() if key!='evaluate'},
                                       identities=identities,metric_fixture_checks=metrics,evolutions=evolutions,zero_density_rejected=zero_rejected,
                                       consumed=consumed,sources=sources(),late_history_created=False,physical_initial_mode_guessed=False,
                                       exact_forcing_derivatives_retained=True))


if __name__=='__main__':
    main()
