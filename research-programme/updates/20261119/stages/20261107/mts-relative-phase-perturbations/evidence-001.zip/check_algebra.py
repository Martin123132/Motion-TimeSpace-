from common import *
from relative_math import derive_symbolic


def main():
    modest()
    derived=derive_symbolic()
    result=dict(passed=True,identities=derived['checks'],mean=str(derived['mean']),
                cosine=str(derived['cos_matrix']),sine=str(derived['sin_matrix']),
                residual_coefficients=[str(value) for value in derived['residual_coefficients']],
                input_hashes=sources(),scope='draft symbolic identities only; no evolution or averaging qualification')
    write(ROOT/'algebra-01.json',result)
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':
    main()
