from common import *
from relative_math import coefficients
import numpy as np
import sympy as sp
from functools import lru_cache


@lru_cache(maxsize=1)
def symbolic_forcing():
    alpha,mu,eta0,eta_c,cosine,sine=sp.symbols('alpha mu eta0 etaC c s',real=True,nonzero=True)
    mean=sp.Matrix([[0,-1],[alpha**2/4,-1-eta0]])
    cos_matrix=sp.Matrix([[0,1],[alpha**2/4,-3-eta_c]])
    sin_matrix=sp.Matrix([[alpha/2,-6/alpha],[0,-alpha/2]])
    primitive=(cos_matrix*sine-sin_matrix*cosine)/(2*mu)
    forcing_mean=sp.Matrix([[0,3],[alpha*mu,0]])
    forcing_cos=sp.Matrix([[0,-3],[0,0]])
    forcing_sin=sp.Matrix([[0,0],[0,sp.Rational(3,2)*alpha]])
    difference_cos=forcing_cos+sin_matrix*forcing_mean/(2*mu)
    difference_sin=forcing_sin-cos_matrix*forcing_mean/(2*mu)
    affine=(difference_cos*sine-difference_sin*cosine)/(2*mu)
    eta=eta0+eta_c*cosine
    alpha_rate=-(1+eta)*alpha
    mu_rate=(1-eta)*mu
    eta_c_rate=eta_c*(-1-2*eta0+(3-2*eta_c)*cosine)
    partial=affine.diff(alpha)*alpha_rate+affine.diff(mu)*mu_rate+affine.diff(eta_c)*eta_c_rate
    oscillation=difference_cos*cosine+difference_sin*sine
    affine_rate=partial+(1-sp.Rational(3,2)*sine/mu)*oscillation
    generator=mean+cos_matrix*cosine+sin_matrix*sine
    correction=generator*affine-partial+sp.Rational(3,2)*sine*oscillation/mu
    forcing=forcing_mean+forcing_cos*cosine+forcing_sin*sine
    residual=generator*affine+forcing-affine_rate-(sp.eye(2)+primitive)*forcing_mean-correction
    checks={f'affine_identity_{row}_{column}':str(sp.factor(residual[row,column])) for row in range(2) for column in range(2)}
    require(all(value=='0' for value in checks.values()),'exact affine source map')
    arguments=(alpha,mu,eta0,eta_c,cosine,sine)
    return dict(checks=checks,affine=str(affine),difference_cos=str(difference_cos),difference_sin=str(difference_sin),
                evaluate=sp.lambdify(arguments,(affine,affine_rate,correction,forcing_mean,forcing),modules='numpy',cse=True))


def source_map(alpha,mu,eta0,eta_c,theta):
    values=symbolic_forcing()['evaluate'](alpha,mu,eta0,eta_c,np.cos(2*theta),np.sin(2*theta))
    affine,affine_rate,correction,forcing_mean,forcing=[np.asarray(value,dtype=float) for value in values]
    item=coefficients(alpha,mu,eta0,eta_c,theta)
    item.update(affine=affine,affine_rate=affine_rate,forcing_correction=correction,forcing_mean=forcing_mean,
                forcing=forcing,transformed_forcing=forcing_mean+item['inverse']@correction,
                forcing_derivative=-item['inverse']@affine)
    return item


def relative_transform(position,velocity,alpha):
    radius=position**2+velocity**2
    require(radius>0,'relative scalar coordinate requires positive scalar density')
    return np.array([[2*position,2*velocity],[alpha*velocity,-alpha*position]])/radius


def canonical_rate(position,velocity,alpha,mu,potential,metric_rate):
    free=np.array([[1.,mu],[-mu-alpha,-2.]])
    force=np.array([mu*velocity*potential,-mu*position*potential+3*velocity*metric_rate])
    return free,force
