from common import *
import ast
import numpy as np
from numpy.polynomial.legendre import leggauss


BACKGROUND=POST/'mts-background-repair-20261107'


def selected_definitions(path,names,namespace):
    tree=ast.parse(path.read_text(encoding='utf-8-sig'))
    selected=[]
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.ClassDef)) and node.name in names:
            selected.append(node)
        elif isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id in names for target in node.targets):
            selected.append(node)
    require(len(selected)==len(names),'source-owned definition selection')
    exec(compile(ast.Module(body=selected,type_ignores=[]),str(path),'exec'),namespace)


namespace=globals().copy()
selected_definitions(PARENT/'thermal_candidate.py',{'FERMI','PANELS','Thermal'},namespace)
selected_definitions(PARENT/'phase_math.py',{'tube'},namespace)
selected_definitions(BACKGROUND/'common.py',{'dense_values'},namespace)
Thermal=namespace['Thermal']
tube=namespace['tube']
dense_values=namespace['dense_values']


class SavedBackground:
    def __init__(self,model):
        self.model=model
        frozen=read(PARENT/'extension/freeze.json')
        self.configuration=frozen['configurations'][model]
        self.target=frozen['target']
        self.folder=PARENT/('split-envelope' if model=='heavy' else 'extension/cold')
        self.saved=load(self.folder/'fine.npz')
        self.dense=load(self.folder/'fine-dense.npz')
        self.replay=load(PARENT/'extension'/model/'resolved-replay.npz')
        self.replay_dense=load(PARENT/'extension'/model/'resolved-replay-dense.npz')
        self.thermal=Thermal(self.configuration['thermal_parameters'])
        self.masses=np.asarray(self.configuration['masses'])
        self.initial=np.asarray(self.configuration['initial_energy_coordinates'])
        self.units=np.linalg.norm(self.initial,axis=1)
        self.units=np.where(self.units>0,self.units,1.)

    def mean(self,efold):
        efold=np.atleast_1d(efold)
        states,derivatives=dense_values(self.dense,efold)
        slow=states[:,:2]*self.configuration['slow_unit']
        radius=np.maximum(states[:,3],0)*self.configuration['slow_unit']
        norm=np.linalg.norm(slow,axis=1)
        external=self.thermal.values(efold)
        if self.configuration['tube'] is None:
            heavy,width,drift,inverse=(np.zeros_like(efold) for index in range(4))
        else:
            heavy,width,drift,inverse=tube(self.configuration['tube'],efold)
        density=external[:,0]+heavy+norm**2/2
        hubble=np.sqrt(density/3)
        lower=np.sqrt((external[:,0]+heavy*np.exp(-width)+np.maximum(norm-radius,0)**2/2)/3)
        upper=np.sqrt((external[:,0]+heavy*np.exp(width)+(norm+radius)**2/2)/3)
        error_heavy=heavy*np.expm1(width)
        error_density=error_heavy+norm*radius+radius**2/2
        eta0=(external[:,1]+slow[:,0]**2-2*slow[:,1]**2-heavy)/(6*hubble**2)
        eta_error=(4*norm*radius+2*radius**2+error_heavy)/(6*lower**2)+abs(eta0)*error_density/(3*lower**2)
        return dict(efold=efold,scale=np.exp(efold),hubble=hubble,lower=lower,upper=upper,slow=slow,
                    radius=radius,heavy=heavy,width=width,eta0=eta0,eta0_error=eta_error,
                    density_error=error_density,external=external,eta_c=heavy/(2*hubble**2))

    def resolved(self,efold):
        values,_=dense_values(self.replay_dense,np.array([efold]))
        coordinates=values[0,:4].reshape(2,2)*self.units[:,None]
        external=self.thermal.values([efold])[0]
        density=np.sum(coordinates**2,axis=1)/2
        hubble=np.sqrt((external[0]+density.sum())/3)
        eta0=(external[1]+coordinates[0,0]**2-2*coordinates[0,1]**2-density[1])/(6*hubble**2)
        eta_c=density[1]/(2*hubble**2)
        theta=np.arctan2(-coordinates[1,1],coordinates[1,0]) if density[1]>0 else None
        eta=eta0+(eta_c*np.cos(2*theta) if theta is not None else 0.)
        return dict(scale=float(np.exp(efold)),hubble=float(hubble),coordinates=coordinates,density=density,
                    eta0=float(eta0),eta_c=float(eta_c),eta=float(eta),theta=theta)


def verify_consumed_inputs():
    owned={}
    for directory,expected in ((PARENT,PARENT_SEAL),(CHANNELS,'a16e7c9764cebbadc43dbf729b5f8f86310aea63a5e6b83ab8afc082717f0ed0'),
                               (BACKGROUND,'c12e8dbaedc7bb230c0448248664c0c4b4e285b567e22c499019438bb5c2b3cf')):
        seal=directory/'closeout.json'
        require(digest(seal)==expected,'input stage seal unchanged')
        owned[str(seal)]=expected
        for item in read(seal)['artifacts']:
            owned[str(Path(item['path']))]=item['sha256']
    paths=[PARENT/'extension/freeze.json',PARENT/'split-envelope/freeze.json',PARENT/'final-validation/result.json',
           PARENT/'phase_math.py',PARENT/'thermal_candidate.py',BACKGROUND/'common.py',CHANNELS/'metric_channels.py',CHANNELS/'DERIVATION.md']
    for folder in (PARENT/'split-envelope',PARENT/'extension/cold'):
        paths.extend(folder/name for name in ('fine.npz','fine-dense.npz'))
    for model in ('heavy','cold'):
        paths.extend(PARENT/'extension'/model/name for name in ('resolved-replay.npz','resolved-replay-dense.npz'))
    for path in paths:
        guard()
        require(str(path) in owned,'consumed path has a retained seal: '+str(path))
        require(digest(path)==owned[str(path)],'consumed source changed: '+str(path))
    require(read(PARENT/'final-validation/result.json')['passed'],'accepted cold background')
    return {str(path):owned[str(path)] for path in paths}|{str(WAVES):digest(WAVES)}
