import os
import hashlib
import json
from pathlib import Path
from datetime import datetime,timezone

for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[name]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PARENT=POST/'mts-cold-background-extension-20261107'
CHANNELS=POST/'mts-metric-channel-factorization-20261107'
GAIN=POST/'mts-cold-adapted-metric-gain-20261107'
WAVES=POST/'mts-derived-wavelength-test-20261107/inventory-config.json'
BRIDGE=Path('C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102')
PARENT_SEAL='3cf78fb90a99a5b6c6527e29b221bccfd508a7c1df589b62ab47fac8e4df580f'
ALGEBRA,GATE=1e-10,2e-5


def require(condition,message):
    if not condition:
        raise ValueError(message)


def guard():
    session=read(ROOT/'session.json')
    require(datetime.now(timezone.utc)<datetime.fromisoformat(session['stop_utc']),'fresh four-hour check-in cutoff')
    for path in (ROOT/'STOP-REQUESTED',PARENT/'STOP-REQUESTED',BRIDGE/'STOP-REQUESTED',BRIDGE.parent/'STOP-REQUESTED',BRIDGE.parent/'execution-v3/STOP-REQUEST.json',BRIDGE/'final-epoch-kinematic-bank/STOP-REQUESTED'):
        require(not path.exists(),'owner hold '+str(path))


def modest():
    import psutil
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([4])
    guard()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)


def digest(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            result.update(block)
    return result.hexdigest()


def load(path):
    import numpy as np
    with np.load(path) as packet:
        return {name:packet[name].copy() for name in packet.files}


def verify_parent():
    for directory,expected in ((PARENT,PARENT_SEAL),(CHANNELS,'a16e7c9764cebbadc43dbf729b5f8f86310aea63a5e6b83ab8afc082717f0ed0'),(GAIN,'cd29bc225d756592906efe5c3eb8316c937af9150865fffa9a7b361e43920b5e')):
        require(digest(directory/'closeout.json')==expected,'retained stage seal')
        for record in read(directory/'closeout.json')['artifacts']:
            guard()
            require(digest(record['path'])==record['sha256'],'retained artifact changed')


def sources():
    return {str(path):digest(path) for path in ROOT.iterdir() if path.suffix in ('.py','.ps1','.md')}
