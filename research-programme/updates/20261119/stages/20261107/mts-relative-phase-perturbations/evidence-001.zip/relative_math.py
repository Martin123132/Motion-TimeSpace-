from common import *
import numpy as np
import sympy as sp


def derive_symbolic():
    position,velocity,pert_position,pert_velocity,alpha,mu,eta,potential,metric_rate=sp.symbols('x v X Y alpha mu eta Psi PhiN',real=True,nonzero=True)
    radius=position**2+velocity**2
    density=2*(position*pert_position+velocity*pert_velocity)/radius
    divergence=-alpha*(position*pert_velocity-velocity*pert_position)/radius
    cosine=(position**2-velocity**2)/radius
    sine=-2*position*velocity/radius
    rates={position:position+mu*velocity,velocity:-2*velocity-mu*position,
           pert_position:pert_position+mu*pert_velocity+mu*velocity*potential,
           pert_velocity:-2*pert_velocity-(mu+alpha)*pert_position-mu*position*potential+3*velocity*metric_rate,
           alpha:-(1+eta)*alpha}
    def derivative(expression):
        return sum(sp.diff(expression,variable)*rate for variable,rate in rates.items())
    density_expected=alpha*sine*density/2-(1-cosine+6*sine/alpha)*divergence+3*(1-cosine)*metric_rate
    divergence_expected=alpha**2*(1+cosine)*density/4-(1+eta+3*cosine+alpha*sine/2)*divergence+alpha*mu*potential+sp.Rational(3,2)*alpha*sine*metric_rate
    pressure=velocity*pert_velocity-position*pert_position
    actual_density=position*pert_position+velocity*pert_velocity
    current_scaled=alpha*velocity*pert_position
    pressure_expected=radius/2*(-cosine*density+2*sine*divergence/alpha)
    current_expected=radius/2*((1-cosine)*divergence-alpha*sine*density/2)
    checks=dict(density_rate=sp.factor(derivative(density)-density_expected),
                divergence_rate=sp.factor(derivative(divergence)-divergence_expected),
                pressure_dictionary=sp.factor(pressure-pressure_expected),
                scaled_current_dictionary=sp.factor(current_scaled-current_expected),
                density_dictionary=sp.factor(actual_density-radius*density/2),
                scalar_continuity=sp.factor(derivative(actual_density)+actual_density+3*pressure+alpha*velocity*pert_position-3*velocity**2*metric_rate))
    require(all(value==0 for value in checks.values()),'relative canonical identities')
    slope,fraction,cosine,sine=sp.symbols('eta0 etaC c s',real=True)
    mean=sp.Matrix([[0,-1],[alpha**2/4,-1-slope]])
    cos_matrix=sp.Matrix([[0,1],[alpha**2/4,-3-fraction]])
    sin_matrix=sp.Matrix([[alpha/2,-6/alpha],[0,-alpha/2]])
    numerator=cos_matrix*sine-sin_matrix*cosine
    generator=mean+cos_matrix*cosine+sin_matrix*sine
    slope_full=slope+fraction*cosine
    alpha_rate=-(1+slope_full)*alpha
    fraction_rate=fraction*(-1-2*slope+(3-2*fraction)*cosine)
    mu_log=1-slope_full
    partial=numerator.diff(alpha)*alpha_rate+numerator.diff(fraction)*fraction_rate
    residual=sp.expand(generator*numerator-numerator*mean-partial+mu_log*numerator+3*sine*(cos_matrix*cosine+sin_matrix*sine))
    coefficients=[sp.zeros(2) for index in range(5)]
    for row in range(2):
        for column in range(2):
            polynomial=sp.Poly(sp.expand(residual[row,column]),cosine,sine)
            require(set(polynomial.monoms())<={(0,0),(1,0),(0,1),(2,0),(0,2),(1,1)},'finite exact harmonic support')
            constant=polynomial.coeff_monomial(1)
            cos_first=polynomial.coeff_monomial(cosine)
            sin_first=polynomial.coeff_monomial(sine)
            cos_squared=polynomial.coeff_monomial(cosine**2)
            sin_squared=polynomial.coeff_monomial(sine**2)
            mixed=polynomial.coeff_monomial(cosine*sine)
            entries=[constant+(cos_squared+sin_squared)/2,cos_first,sin_first,(cos_squared-sin_squared)/2,mixed/2]
            for index,entry in enumerate(entries):
                coefficients[index][row,column]=sp.factor(entry)
    return dict(checks={name:str(value) for name,value in checks.items()},symbols=(alpha,slope,fraction),
                mean=mean,cos_matrix=cos_matrix,sin_matrix=sin_matrix,residual_coefficients=coefficients)


def matrices(alpha,eta0,eta_c):
    return (np.array([[0.,-1.],[alpha**2/4,-1-eta0]]),
            np.array([[0.,1.],[alpha**2/4,-3-eta_c]]),
            np.array([[alpha/2,-6/alpha],[0.,-alpha/2]]))


def coefficients(alpha,mu,eta0,eta_c,theta):
    mean,cos_matrix,sin_matrix=matrices(alpha,eta0,eta_c)
    cosine,sine=np.cos(2*theta),np.sin(2*theta)
    generator=mean+cos_matrix*cosine+sin_matrix*sine
    numerator=cos_matrix*sine-sin_matrix*cosine
    primitive=numerator/(2*mu)
    eta=eta0+eta_c*cosine
    alpha_rate=-(1+eta)*alpha
    eta_c_rate=eta_c*(-1-2*eta0+(3-2*eta_c)*cosine)
    cos_rate=np.array([[0.,0.],[alpha*alpha_rate/2,-eta_c_rate]])
    sin_rate=np.array([[alpha_rate/2,6*alpha_rate/alpha**2],[0.,-alpha_rate/2]])
    partial=(cos_rate*sine-sin_rate*cosine-(1-eta)*numerator)/(2*mu)
    angular=(cos_matrix*cosine+sin_matrix*sine)/mu
    remainder=generator@primitive-primitive@mean-partial+1.5*sine*angular
    inverse=np.linalg.inv(np.eye(2)+primitive)
    return dict(mean=mean,generator=generator,primitive=primitive,partial=partial,angular=angular,
                remainder=remainder,transformed=mean+inverse@remainder,inverse=inverse,
                force_psi=np.array([0.,alpha*mu]),force_phi=np.array([3*(1-cosine),1.5*alpha*sine]),
                theta_rate=mu-1.5*sine,eta=eta)


def physical_rows(density,alpha,ratio,theta):
    cosine,sine=np.cos(2*theta),np.sin(2*theta)
    return dict(density=density*np.array([1.,0.]),current=density/ratio*np.array([-alpha*sine/2,1-cosine]),
                pressure=density*np.array([-cosine,2*sine/alpha]),enthalpy=density*(1-cosine))


def metric_rows(branch,ratio,wave,hubble,eta,density,alpha,theta,external):
    heavy=physical_rows(density,alpha,ratio,theta)
    size=len(external['density'])
    total={name:np.array(external[name],copy=True) for name in ('density','current','shear','free_density','free_current')}
    total['density'][:2]+=heavy['density']
    total['current'][:2]+=heavy['current']
    total['free_density'][:2]+=-heavy['density']-3*heavy['pressure']-ratio*heavy['current']
    total['free_current'][:2]+=-2*heavy['current']+ratio*heavy['pressure']
    enthalpy=external['quadrature_enthalpy']+heavy['enthalpy']
    denominator=2*wave**2+3*enthalpy
    require(denominator>0,'metric channel denominator')
    if branch=='gr':
        potential=-total['density']/(2*wave**2)-3*hubble*total['current']/(2*wave**3)-total['shear']/wave**2
        rate=-(total['free_density']+3*(eta*hubble*total['current']+hubble*total['free_current'])/wave+3*enthalpy*potential)/denominator
    else:
        require(branch=='poisson-spatial','retained gravity branch')
        potential=-total['density']/(2*wave**2)
        rate=-(total['free_density']+3*external['enthalpy_defect']*potential)/denominator
    return dict(psi=potential,phi_rate=rate,denominator=denominator,quadrature_enthalpy=enthalpy,rows=total)


def monomial_bound(expression,symbols,alpha_interval):
    limits={symbols[0]:alpha_interval,symbols[1]:(-2.,2.),symbols[2]:(0.,1.5)}
    result=0.
    for term in sp.Add.make_args(sp.expand(expression)):
        coefficient=term
        magnitude=1.
        for symbol in symbols:
            exponent=term.as_powers_dict().get(symbol,0)
            coefficient=coefficient/symbol**exponent
            lower,upper=limits[symbol]
            chosen=lower if exponent<0 else max(abs(lower),abs(upper))
            magnitude*=chosen**float(exponent)
        require(not coefficient.free_symbols,'explicit coefficient bound')
        result+=abs(float(coefficient))*magnitude
    return result


def uniform_bounds(derivation,alpha_interval,mu_min,span):
    symbols=derivation['symbols']
    def norm_bound(matrix):
        values=np.array([[monomial_bound(matrix[row,column],symbols,alpha_interval) for column in range(2)] for row in range(2)])
        return float(np.linalg.norm(values,'fro'))
    primitive=(norm_bound(derivation['cos_matrix'])+norm_bound(derivation['sin_matrix']))/(2*mu_min)
    require(primitive<1,'uniform micromotion inverse')
    residual=sum(norm_bound(matrix) for matrix in derivation['residual_coefficients'])/(2*mu_min)
    transformed=residual/(1-primitive)
    gain=1+max(1.,alpha_interval[1]**2/4)/2
    bound=np.exp(gain*span)/(1-primitive)*(2*primitive+(1+primitive)*np.expm1(transformed*span))
    return dict(primitive_bound=primitive,remainder_bound=residual,transformed_remainder_bound=transformed,
                inverse_bound=1/(1-primitive),mean_logarithmic_norm_bound=gain,
                homogeneous_same_initial_relative_transfer_bound=float(bound),span=span,
                scope='homogeneous relative-state transfer along the same exact background coefficient path; metric sources excluded, background replacement not silently included')
