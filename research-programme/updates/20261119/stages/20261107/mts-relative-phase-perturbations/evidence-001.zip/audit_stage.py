from common import *
from background_access import SavedBackground, verify_consumed_inputs
from relative_math import derive_symbolic, coefficients
from forced_map import source_map
import numpy as np
import sympy as sp
import platform
import scipy


def main():
    modest()
    consumed = verify_consumed_inputs()
    destination = ROOT / 'audit-01'
    destination.mkdir(exist_ok=False)
    results = {
        name: read(ROOT / name / 'result.json')
        for name in ('coefficient-01', 'cold-transfer-01', 'validation-01')
    }
    for name, result in results.items():
        require(result['passed'], 'completed stage: ' + name)
        require(result['consumed'] == consumed, 'same consumed inputs: ' + name)
        source_records = result.get('sources', result.get('source', {}))
        require(bool(source_records), 'source snapshot exists')
        for path, expected in source_records.items():
            require(digest(path) == expected, 'run source unchanged: ' + path)
    write(destination / 'freeze.json', dict(
        consumed=consumed, sources=sources(),
        evidence={name: digest(ROOT / name / 'result.json') for name in results},
        additional_odes=False, algebra_gate=ALGEBRA, numerical_gate=GATE))
    derived = derive_symbolic()
    harmonic_function = sp.lambdify(
        derived['symbols'], derived['residual_coefficients'], modules='numpy', cse=True)
    harmonic_error = 0.
    harmonic_count = 0
    wronskians = []
    baseline_checks = []
    omission_detection = 0.
    for model in ('heavy', 'cold'):
        background = SavedBackground(model)
        for label, wave in read(WAVES)['waves']:
            packet = load(ROOT / 'cold-transfer-01' / model / (label + '-fine.npz'))
            efolds = packet['efold']
            values = background.mean(efolds)
            expected = np.exp(efolds[0] - efolds) * values['hubble'][0] / values['hubble']
            errors = []
            for control in ('base', 'fine', 'independent'):
                transfer = load(ROOT / 'cold-transfer-01' / model / (label + '-' + control + '.npz'))['transfer']
                error = float(np.max(abs(np.linalg.det(transfer) - expected)))
                require(error < GATE, 'Liouville identity on saved mean background')
                errors.append(dict(control=control,absolute_error=error))
            wronskians.append(dict(model=model,label=label,controls=errors))
            if model == 'cold':
                transfer = packet['transfer']
                error = max(float(np.max(abs(transfer[:, 1, 1] - expected))),
                            float(np.max(abs(transfer[:, 0, 0] - 1))),
                            float(np.max(abs(transfer[:, 1, 0]))))
                require(error < GATE, 'independent baseline velocity law')
                baseline_checks.append(dict(label=label,absolute_error=error))
                continue
            for index in np.unique(np.linspace(0, len(efolds) - 1, 9, dtype=int)):
                alpha = wave**2 / (values['scale'][index] * background.masses[1] * values['hubble'][index])
                mu = values['scale'][index] * background.masses[1] / values['hubble'][index]
                eta0, fraction = values['eta0'][index], values['eta_c'][index]
                harmonic_matrices = harmonic_function(alpha, eta0, fraction)
                for theta in np.linspace(.123, 2*np.pi+.123, 18)[:-1]:
                    item = coefficients(alpha, mu, eta0, fraction, theta)
                    harmonics = (1, np.cos(2*theta), np.sin(2*theta),
                                 np.cos(4*theta), np.sin(4*theta))
                    reconstructed = sum(matrix*factor for matrix, factor in zip(harmonic_matrices, harmonics))/(2*mu)
                    error = float(np.max(abs(reconstructed-item['remainder']) /
                                         (1+abs(reconstructed)+abs(item['remainder']))))
                    harmonic_error = max(harmonic_error, error)
                    harmonic_count += 1
            point = background.resolved(float(background.replay['efold'][0]))
            alpha = wave**2 / (point['scale'] * background.masses[1] * point['hubble'])
            mu = point['scale'] * background.masses[1] / point['hubble']
            forcing = source_map(alpha, mu, point['eta0'], point['eta_c'], point['theta'])
            omission_detection = max(omission_detection, float(np.linalg.norm(forcing['affine'], 2)))
    require(harmonic_error < ALGEBRA, 'symbolic residual equals direct differentiated transformation')
    require(omission_detection > ALGEBRA, 'omitting the source-derivative map is detectably not an identity')
    validation = results['validation-01']
    maxima = {
        name: max(row['checks'][name] for row in validation['identities'])
        for name in validation['identities'][0]['checks']
    }
    for row in results['cold-transfer-01']['reports']:
        require(row['combined_bound_passes_gate'], 'homogeneous bound passes unchanged gate')
    require(consumed == verify_consumed_inputs(), 'consumed inputs remain unchanged')
    summary = dict(
        passed=True, symbolic_identities=10,
        early_coefficient_states=len(validation['identities']),
        coefficient_maxima=maxima,
        metric_row_fixtures=len(validation['metric_fixture_checks']),
        maximum_metric_fixture_error=max(row['error'] for row in validation['metric_fixture_checks']),
        independent_harmonic_checks=harmonic_count, harmonic_maximum_error=harmonic_error,
        nonzero_source_derivative_omission_residual=omission_detection,
        wronskians=wronskians, independent_baseline_velocity_checks=baseline_checks,
        maximum_canonical_affine_evolution_error=max(
            control['error'] for row in validation['evolutions'] for control in row['controls']),
        maximum_fine_canonical_affine_evolution_error=max(
            control['error'] for row in validation['evolutions'] for control in row['controls']
            if control['control']=='fine'),
        maximum_short_evolution_refinement=max(row['refinement'] for row in validation['evolutions']),
        maximum_cold_transfer_refinement=max(
            row['maximum_refinement_error'] for row in results['cold-transfer-01']['reports']),
        consumed=consumed, sources=sources(),
        software=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,sympy=sp.__version__),
        numerical_gate=GATE,algebra_gate=ALGEBRA,
        scope='homogeneous cold transfer, early prescribed-source equivalence, and metric algebra; not a coupled late history')
    write(destination / 'result.json', summary)
    print(json.dumps({name: value for name, value in summary.items()
                      if name not in ('consumed','sources','wronskians','independent_baseline_velocity_checks')}, indent=2))


if __name__ == '__main__':
    main()
