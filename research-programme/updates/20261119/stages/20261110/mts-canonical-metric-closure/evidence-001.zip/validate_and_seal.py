from support import *
import numpy as np


def main():
    with worker("validation"):
        checks = []
        def require(name, condition):
            checks.append(dict(name=name, passed=bool(condition)))
            if not condition:
                raise ValueError(name)
        proof = read(ROOT / "proof.json")
        defects = read(ROOT / "defects-proof.json")
        accepted = read(ROOT / "precision-sources-result.json")
        failed = read(ROOT / "sources-result.json")
        require("18 source identities", proof["passed"] and proof["count"] == 18)
        require("4 defect identities", defects["passed"] and len(defects["identities"]) == 4)
        require("75 unchanged source gates", accepted["passed"] and len(accepted["checks"]) == 75 and all(row["passed"] and row["gate"] in (ALGEBRA, GATE) for row in accepted["checks"]))
        require("failed attempt retained and not promoted", not failed["passed"] and read(ROOT / "sources-end.json")["state"] == "failed")
        require("new readout unchanged physical inputs", read(ROOT / "precision-representation.json")["physical_inputs_unchanged"])
        require("numerical artifact hash", digest(ROOT / "precision-source-replay.npz") == accepted["output_sha256"])
        require("original source script retained", digest(ROOT / "check_sources_attempt01.py") == accepted["code_sha256"] == failed["code_sha256"])
        require("precision driver recorded", digest(ROOT / "check_sources.py") == read(ROOT / "precision-representation.json")["implementation_sha256"])
        require("no invented late evolution", accepted["actual_late_hierarchy_evolved"] is False and all(accepted["late_adapter"].values()))
        with np.load(ROOT / "precision-source-replay.npz") as packet:
            require("399 modes and9points", packet["wave"].shape == (399,) and packet["positions"].shape == (9,))
            for choice in ("D0", "D01"):
                require(choice + " source shape finite", packet[choice + "_source_history"].shape == (9, 399, 3) and np.isfinite(packet[choice + "_source_history"]).all())
                require(choice + " constraint shape finite", packet[choice + "_metric_port_history"].shape == (9, 399, 3) and np.isfinite(packet[choice + "_metric_port_history"]).all())
        protected = read(ROOT / "precision-frozen-inputs.json")["hashes"]
        for path, checksum in protected.items():
            guard()
            if digest(path) != checksum:
                raise ValueError("preserved input changed: " + path)
        require("all preserved input hashes", True)
        for path in ROOT.glob("*.py"):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        require("Python in-memory compilation", True)
        require("no bytecode", not list(ROOT.rglob("__pycache__")) and not list(ROOT.rglob("*.pyc")))
        cleanup = []
        for path in ROOT.glob("*-start.json"):
            identity = read(path)
            if identity["pid"] == os.getpid():
                continue
            alive = False
            try:
                process = psutil.Process(identity["pid"])
                alive = abs(process.create_time() - identity["created"]) < .01 and process.cmdline() == identity["command"] and process.is_running()
            except psutil.NoSuchProcess:
                pass
            cleanup.append(dict(receipt=path.name, pid=identity["pid"], exact_process_running=alive))
            require("worker exited " + path.name, not alive)
        write("validation.json", dict(passed=True, checks=checks, previous_workers=cleanup, input_count=len(protected), code_sha256=digest(__file__)))
    artifacts = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.rglob("*")) if path.is_file()}
    write("closeout.json", dict(state="verified_progress", utc=datetime.now(timezone.utc).isoformat(), previous_goal_turn="receipt-only/no-progress; next safe calculation executed",
          goal_complete=False, input_hashes=protected, artifacts=artifacts, no_running_numerical_job=True,
          finalizer_pid=os.getpid(), finalizer_exit_requires_external_confirmation=True,
          accepted=["proof.json", "defects-proof.json", "precision-sources-result.json", "validation.json"],
          failed_preserved=["sources-result.json"], late_coupled_evolution_completed=False))
    print(json.dumps(dict(state="verified_progress", input_count=len(protected), artifacts=len(artifacts), closeout_sha256=digest(ROOT / "closeout.json"), finalizer_pid=os.getpid())), flush=True)


if __name__ == "__main__":
    main()
