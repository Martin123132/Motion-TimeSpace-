from support import *
import check_sources_attempt01 as replay
import mpmath as mp
import numpy as np


def precise_quadrature(values, wave, relative, canonical, potential, lapse, angle):
    result = []
    with mp.workdps(60):
        mass, hubble, carrier = [mp.mpf(float(values[name])) for name in ("mass", "hubble", "carrier")]
        slope0 = mp.mpf(values["slope0"])
        for index in range(len(wave)):
            background = mp.exp(-mp.j * mp.mpf(float(angle[index]))) / mp.sqrt(carrier)
            background_prime = (slope0 - hubble - mp.j * carrier) * background
            state = mp.mpc(complex(relative[index]))
            momentum = mp.mpc(complex(canonical[index]))
            metric_phi, metric_psi = mp.mpf(float(potential[index])), mp.mpf(float(lapse[index]))
            perturbation = background * state
            derivative = background * momentum + (metric_psi + 3 * metric_phi) * background_prime - hubble * perturbation
            denominator = abs(background_prime)**2 + mass**2 * abs(background)**2
            kinetic = mp.re(mp.conj(background_prime) * derivative) - abs(background_prime)**2 * metric_psi
            mass_term = mass**2 * mp.re(mp.conj(background) * perturbation)
            phase_current = -2 * mass * mp.re(mp.conj(background_prime) * perturbation) / denominator
            result.append([float(2 * (kinetic + mass_term) / denominator), float(phase_current), float(2 * (kinetic - mass_term) / denominator)])
    return np.array(result)


if __name__ == "__main__":
    if read(ROOT / "sources-result.json")["passed"]:
        raise ValueError("precision repair requires the preserved failed attempt")
    replay.original_quadrature_sources = precise_quadrature
    replay.worker = lambda name: worker("precision-" + name)
    replay.write = lambda name, value: write("precision-" + name, value)
    original_save = np.savez_compressed
    def save_separate(path, **arrays):
        if Path(path) != ROOT / "source-replay.npz":
            raise ValueError("unexpected output path")
        return original_save(ROOT / "precision-source-replay.npz", **arrays)
    replay.np.savez_compressed = save_separate
    def separate_digest(path):
        path = Path(path)
        if path in (ROOT / "source-replay.npz", ROOT / "frozen-inputs.json"):
            path = path.with_name("precision-" + path.name)
        return digest(path)
    replay.digest = separate_digest
    replay.main()
    write("precision-representation.json", dict(reason="rotated real-quadrature stress evaluated at60digits before returning double sources; its cancelling direct readout failed1e-10 at about2e-9", tolerances_unchanged=True, physical_inputs_unchanged=True,
          implementation_sha256=digest(__file__), original_implementation_sha256=digest(ROOT / "check_sources_attempt01.py"),
          sources_result_sha256=digest(ROOT / "precision-sources-result.json")))
