from support import *
import sympy as sym


def main():
    with worker("proof"):
        checks = []

        def identity(name, expression):
            guard()
            remainder = sym.factor(sym.expand(expression))
            if remainder != 0:
                raise ValueError(name + ": " + str(remainder))
            checks.append(name)

        field, speed, perturbation, momentum, hubble, mass2, wave, potential, lapse, potential_prime = sym.symbols(
            "field speed perturbation momentum hubble mass2 wave potential lapse potential_prime", real=True)
        combined = lapse + 3 * potential
        difference = 3 * potential - lapse
        field_rate = speed
        speed_rate = -2 * hubble * speed - mass2 * field
        perturbation_rate = momentum + combined * speed
        momentum_rate = -2 * hubble * momentum - (wave**2 + mass2) * perturbation + mass2 * difference * field
        rates = {field: field_rate, speed: speed_rate, perturbation: perturbation_rate, momentum: momentum_rate,
                 mass2: 2 * hubble * mass2, potential: potential_prime}

        def derivative(expression):
            return sum(sym.diff(expression, variable) * rate for variable, rate in rates.items())

        dstar = speed * momentum + mass2 * field * perturbation
        pstar = speed * momentum - mass2 * field * perturbation
        density = dstar + 3 * speed**2 * potential
        pressure = pstar + 3 * speed**2 * potential
        current = wave * speed * perturbation
        identity("real scalar energy conservation", derivative(density) + hubble * (density + 3 * pressure) + wave * current - 3 * speed**2 * potential_prime)
        identity("real scalar momentum conservation", derivative(current) + 2 * hubble * current - wave * (pressure + speed**2 * lapse))
        velocity = sym.symbols("velocity", real=True)
        metric_only = (sym.Rational(3, 2) * (lapse + potential)**2 * speed**2 - mass2 * (sym.Rational(3, 2) * potential**2 - 3 * lapse * potential - lapse**2 / 2) * field**2) / 2
        lagrangian = (velocity**2 - (wave**2 + mass2) * perturbation**2) / 2 - combined * speed * velocity + mass2 * difference * field * perturbation + metric_only
        hamiltonian = (momentum + combined * speed)**2 / 2 + (wave**2 + mass2) * perturbation**2 / 2 - mass2 * difference * field * perturbation - metric_only
        identity("Legendre momentum", sym.diff(lagrangian, velocity) - (velocity - combined * speed))
        identity("Legendre transform", (momentum * velocity - lagrangian).subs(velocity, momentum + combined * speed) - hamiltonian)
        identity("Hamilton field equation", sym.diff(hamiltonian, momentum) - perturbation_rate)
        identity("Hamilton momentum equation including a squared weight", -sym.diff(hamiltonian, perturbation) - 2 * hubble * momentum - momentum_rate)
        for coordinate in (lapse, potential):
            identity("fixed canonical momentum metric variation " + str(coordinate), sym.diff(hamiltonian, coordinate) + sym.diff(lagrangian, coordinate).subs(velocity, momentum + combined * speed))
        background_energy = (speed**2 + mass2 * field**2) / 2
        background_pressure = (speed**2 - mass2 * field**2) / 2
        identity("lapse measure source", sym.diff(hamiltonian, lapse) - (density - combined * background_energy))
        identity("spatial trace measure source", sym.diff(hamiltonian, potential) - 3 * (pressure + (lapse - potential) * background_pressure))

        total_density, total_pressure, total_current, enthalpy, anisotropy = sym.symbols("total_density total_pressure total_current enthalpy anisotropy", real=True)
        lapse_closed = potential - anisotropy / wave**2
        metric_rate = -hubble * lapse_closed + total_current / (2 * wave)
        hubble_rate = hubble**2 - enthalpy / 2
        density_rate = -hubble * (total_density + 3 * total_pressure) - wave * total_current + 3 * enthalpy * metric_rate
        current_rate = -2 * hubble * total_current + wave * (total_pressure + enthalpy * lapse_closed - 2 * anisotropy / 3)
        constraint = 2 * wave**2 * potential + total_density + 3 * hubble * total_current / wave
        constraint_rate = 2 * wave**2 * metric_rate + density_rate + 3 * (hubble_rate * total_current + hubble * current_rate) / wave
        identity("full total-stress constraint propagation", constraint_rate + hubble * constraint)
        dstar_total = sym.symbols("dstar_total", real=True)
        denominator = 2 * wave**2 + 3 * enthalpy
        solved_potential = -(dstar_total + 3 * hubble * total_current / wave) / denominator
        identity("compensated constraint elimination", constraint.subs(total_density, dstar_total + 3 * enthalpy * potential).subs(potential, solved_potential))
        omitted_slip_residual = sym.factor(constraint_rate + 2 * hubble * anisotropy + hubble * constraint)
        if omitted_slip_residual != 2 * hubble * anisotropy:
            raise ValueError("anisotropic stress negative control failed")

        rest_density, rest_current, rest_enthalpy = sym.symbols("rest_density rest_current rest_enthalpy", real=True)
        denominator_real = 2 * wave**2 + 3 * (speed**2 + rest_enthalpy)
        scalar_row = sym.Matrix([[mass2 * field + 3 * hubble * speed, speed]])
        state = sym.Matrix([perturbation, momentum])
        coupling = sym.Matrix([4 * speed, 2 * mass2 * field])
        slip = sym.Matrix([-speed, mass2 * field])
        base = sym.Matrix([[0, 1], [-(wave**2 + mass2), -2 * hubble]])
        rest = rest_density + 3 * hubble * rest_current / wave
        metric_solution = -(scalar_row.dot(state) + rest) / denominator_real
        direct = sym.Matrix([perturbation_rate, momentum_rate]).subs(lapse, potential - anisotropy / wave**2).subs(potential, metric_solution)
        reduced = (base - coupling * scalar_row / denominator_real) * state - coupling * rest / denominator_real + slip * anisotropy / wave**2
        for index in range(2):
            identity("explicit real feedback matrix " + str(index), direct[index] - reduced[index])

        lambda0, lambdak, lambda0_prime, lambdak_prime, response, response_prime, relative, combined_symbol, combined_prime, hubble_prime = sym.symbols(
            "lambda0 lambdak lambda0_prime lambdak_prime response response_prime relative combined combined_prime hubble_prime")
        physical0 = lambda0 - hubble
        canonical = lambdak * relative + response - combined_symbol * physical0
        relative_rate = (lambdak - lambda0) * relative + response
        omega0 = mass2 - hubble_prime - hubble**2
        omegak = wave**2 + omega0
        canonical_rate = lambdak_prime * relative + lambdak * relative_rate + response_prime - combined_prime * physical0 - combined_symbol * (lambda0_prime - hubble_prime)
        equation = canonical_rate + lambda0 * canonical + omegak * relative - hubble * combined_symbol * physical0 - mass2 * (combined_symbol - 2 * lapse)
        residual0 = lambda0_prime + lambda0**2 + omega0
        residualk = lambdak_prime + lambdak**2 + omegak
        response_equation = response_prime + (lambda0 + lambdak) * response - combined_prime * physical0 + 2 * mass2 * lapse - combined_symbol * residual0 + residualk * relative
        identity("unrestricted affine response including carrier residual", equation - response_equation)

        real_part, imag_part, canonical_real, canonical_imag, slope0, slopek, carrier, sideband, response_real, response_imag = sym.symbols(
            "real_part imag_part canonical_real canonical_imag slope0 slopek carrier sideband response_real response_imag", real=True)
        relative_complex = real_part + sym.I * imag_part
        physical0_complex = slope0 - hubble - sym.I * carrier
        canonical_complex = canonical_real + sym.I * canonical_imag
        denominator_carrier = carrier**2 + (slope0 - hubble)**2 + mass2
        normalized_dstar = 2 * sym.re(sym.conjugate(physical0_complex) * (canonical_complex - hubble * relative_complex) + mass2 * relative_complex) / denominator_carrier
        normalized_pstar = normalized_dstar - 4 * mass2 * real_part / denominator_carrier
        normalized_current = 2 * wave * sym.re(sym.conjugate(physical0_complex) * relative_complex) / denominator_carrier
        normalized_enthalpy = 2 * ((slope0 - hubble)**2 + carrier**2) / denominator_carrier
        plane = (slopek - sym.I * sideband) * relative_complex + response_real + sym.I * response_imag - combined * physical0_complex
        replacements = {canonical_real: sym.re(plane), canonical_imag: sym.im(plane)}
        old_density = 2 * (((slope0 - hubble) * (slopek - hubble) + carrier * sideband + mass2) * real_part
                           + ((slope0 - hubble) * sideband - carrier * (slopek - hubble)) * imag_part
                           + (slope0 - hubble) * response_real - carrier * response_imag) / denominator_carrier - normalized_enthalpy * lapse
        identity("saved affine density source recovered", (normalized_dstar + 3 * normalized_enthalpy * potential).subs(replacements) - old_density)
        identity("saved affine pressure source recovered", (normalized_pstar + 3 * normalized_enthalpy * potential).subs(replacements) - (old_density - 4 * mass2 * real_part / denominator_carrier))
        identity("metric source row in canonical envelope", normalized_dstar + 3 * hubble * normalized_current / wave - 2 * ((mass2 + 2 * hubble * (slope0 - hubble)) * real_part - 2 * hubble * carrier * imag_part + (slope0 - hubble) * canonical_real - carrier * canonical_imag) / denominator_carrier)
        write("proof.json", dict(passed=True, identities=checks, count=len(checks), negative_control=str(omitted_slip_residual), code_sha256=digest(__file__), exact_scope="real scalar on shell and canonical algebra; not a late hierarchy evolution or exact WKB background"))
        print("PASS", len(checks), "exact identities; anisotropic stress omission detected", flush=True)


if __name__ == "__main__":
    main()
