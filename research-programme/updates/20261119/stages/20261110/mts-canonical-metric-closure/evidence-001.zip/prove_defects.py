from support import *
import sympy as sym


def main():
    with worker("defects"):
        field, speed, perturbation, momentum, hubble, mass2, wave, potential, lapse, potential_prime = sym.symbols(
            "field speed perturbation momentum hubble mass2 wave potential lapse potential_prime", real=True)
        background_defect, field_defect, momentum_defect = sym.symbols("background_defect field_defect momentum_defect", real=True)
        rates = {field: speed, speed: -2 * hubble * speed - mass2 * field + background_defect,
                 perturbation: momentum + (lapse + 3 * potential) * speed + field_defect,
                 momentum: -2 * hubble * momentum - (wave**2 + mass2) * perturbation + mass2 * (3 * potential - lapse) * field + momentum_defect,
                 mass2: 2 * hubble * mass2, potential: potential_prime}
        density = speed * momentum + mass2 * field * perturbation + 3 * speed**2 * potential
        pressure = density - 2 * mass2 * field * perturbation
        current = wave * speed * perturbation
        energy_defect = background_defect * (momentum + 6 * speed * potential) + mass2 * field * field_defect + speed * momentum_defect
        current_defect = wave * (background_defect * perturbation + speed * field_defect)
        derivative = lambda expression: sum(sym.diff(expression, variable) * rate for variable, rate in rates.items())
        checks = {}
        checks["off_shell_energy"] = derivative(density) + hubble * (density + 3 * pressure) + wave * current - 3 * speed**2 * potential_prime - energy_defect
        checks["off_shell_momentum"] = derivative(current) + 2 * hubble * current - wave * (pressure + speed**2 * lapse) - current_defect
        total_density, total_pressure, total_current, enthalpy, anisotropy, energy_error, current_error, friedmann_error = sym.symbols(
            "total_density total_pressure total_current enthalpy anisotropy energy_error current_error friedmann_error", real=True)
        lapse_value = potential - anisotropy / wave**2
        metric_rate = -hubble * lapse_value + total_current / (2 * wave)
        density_rate = -hubble * (total_density + 3 * total_pressure) - wave * total_current + 3 * enthalpy * metric_rate + energy_error
        current_rate = -2 * hubble * total_current + wave * (total_pressure + enthalpy * lapse_value - 2 * anisotropy / 3) + current_error
        hubble_rate = hubble**2 - enthalpy / 2 + friedmann_error
        constraint = 2 * wave**2 * potential + total_density + 3 * hubble * total_current / wave
        constraint_rate = 2 * wave**2 * metric_rate + density_rate + 3 * (hubble_rate * total_current + hubble * current_rate) / wave
        checks["inhomogeneous_constraint_propagation"] = constraint_rate + hubble * constraint - energy_error - 3 * hubble * current_error / wave - 3 * friedmann_error * total_current / wave
        compensated = sym.symbols("compensated", real=True)
        denominator = 2 * wave**2 + 3 * enthalpy
        solved = -(compensated + 3 * hubble * total_current / wave) / denominator
        newton = -compensated / (2 * wave**2)
        checks["exact_Newton_difference"] = solved - newton - 3 * enthalpy * compensated / (2 * wave**2 * denominator) + 3 * hubble * total_current / (wave * denominator)
        for name, expression in checks.items():
            if sym.factor(expression) != 0:
                raise ValueError(name + ": " + str(sym.factor(expression)))
        write("defects-proof.json", dict(passed=True, identities=list(checks), code_sha256=digest(__file__),
              scope="exact algebraic identities and analytical triangle bound; no numerical uniform enclosure claimed"))
        print("PASS", len(checks), "off-shell and Newton comparison identities", flush=True)


if __name__ == "__main__":
    main()
