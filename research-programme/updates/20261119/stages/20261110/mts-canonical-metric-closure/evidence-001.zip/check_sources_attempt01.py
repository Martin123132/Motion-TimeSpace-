from support import *
import numpy as np
sys.path.insert(0, str(ACTION))
import action_model
from retained import model
sys.path.remove(str(ACTION))


def source_map(values, wave, relative, canonical, potential):
    mass = values["mass"]
    physical0 = values["slope0"] - values["hubble"] - 1j * values["carrier"]
    denominator = abs(physical0)**2 + mass**2
    kinetic = np.real(np.conjugate(physical0) * (canonical - values["hubble"] * relative))
    enthalpy = 2 * abs(physical0)**2 / denominator
    dstar = 2 * (kinetic + mass**2 * relative.real) / denominator
    pstar = 2 * (kinetic - mass**2 * relative.real) / denominator
    current = 2 * wave * np.real(np.conjugate(physical0) * relative) / denominator
    sources = np.column_stack((dstar + 3 * enthalpy * potential, -mass * current / wave, pstar + 3 * enthalpy * potential))
    return sources, dstar, current, enthalpy


def original_quadrature_sources(values, wave, relative, canonical, potential, lapse, angle):
    mass, hubble, carrier = values["mass"], values["hubble"], values["carrier"]
    background = np.exp(-1j * angle) / np.sqrt(carrier)
    physical_background = (values["slope0"] - hubble - 1j * carrier) * background
    perturbation = background * relative
    derivative = background * canonical + (lapse + 3 * potential) * physical_background - hubble * perturbation
    background_denominator = abs(physical_background)**2 + mass**2 * abs(background)**2
    kinetic = np.real(np.conjugate(physical_background) * derivative) - abs(physical_background)**2 * lapse
    mass_term = mass**2 * np.real(np.conjugate(background) * perturbation)
    density = 2 * (kinetic + mass_term) / background_denominator
    pressure = 2 * (kinetic - mass_term) / background_denominator
    current = 2 * wave * np.real(np.conjugate(physical_background) * perturbation) / background_denominator
    return np.column_stack((density, -mass * current / wave, pressure))


def main():
    with worker("sources"):
        if not read(ROOT / "proof.json")["passed"]:
            raise ValueError("proof gate")
        protected = input_hashes()
        extra_paths = [HIERARCHY / "build-corrected/camb_python.f90", POST / "MTS-CLOSED-LINEAR-METRIC-RESPONSE.md",
                       POST / "MTS-JOINT-GRAVITY-HAMILTONIAN-AND-CANONICAL-MEAN.md"]
        for path in extra_paths:
            protected[str(path)] = digest(path)
        write("frozen-inputs.json", dict(hashes=protected, gate=GATE, algebra=ALGEBRA, original_bank_grids_tolerances=True))
        with np.load(ACTION / "conservation.npz") as packet:
            saved = {name: packet[name].copy() for name in packet.files}
        with np.load(TRANSPORT / "transport.npz") as packet:
            scales = packet["normalizer"].copy()
            cold_scales = packet["cold_scale"].copy()
            cold_final = packet["cold_final"].copy()
        heavy = action_model.StableCase("heavy")
        cold = model.Case("cold")
        wave = heavy.wave
        if not np.array_equal(wave, cold.wave) or not np.array_equal(wave, saved["wave"]):
            raise ValueError("paired mode ownership")
        checks, rows, arrays = [], [], dict(wave=wave, positions=saved["positions"])

        def check(name, error, gate=ALGEBRA):
            error = float(error)
            checks.append(dict(name=name, error=error, gate=gate, passed=bool(np.isfinite(error) and abs(error) <= gate)))

        for choice in ("D0", "D01"):
            source_history, constraint_history = [], []
            for point, position in enumerate(saved["positions"]):
                guard()
                values = action_model.local(heavy, float(position))
                relative_components = saved[choice + "_relative_history"][point]
                relative = relative_components[:, 0] + 1j * relative_components[:, 1]
                physical0 = values["slope0"] - values["hubble"] - 1j * values["carrier"]
                combined = values["lapse"] + 3 * values["potential"]
                canonical = (values["slopek"] - 1j * values["sideband"]) * relative + values["choices"][choice]["response"] - combined * physical0
                mapped, dstar, current, enthalpy = source_map(values, wave, relative, canonical, values["potential"])
                source_scale = scales[:, [0, 1, 0]]
                check(choice + " saved source replay " + str(point), np.max(abs((mapped - saved[choice + "_source_history"][point]) / source_scale)))
                direct = original_quadrature_sources(values, wave, relative, canonical, values["potential"], values["lapse"], np.linspace(.1, 2.3, len(wave)))
                check(choice + " original real quadrature action stress " + str(point), np.max(abs((mapped - direct) / source_scale)))
                source_history.append(mapped)
                hubble, mass = values["hubble"], values["mass"]
                density_weight = float(heavy.background["matching_density"]) / np.exp(model.CENTER + position)
                scalar_enthalpy = density_weight * enthalpy
                rest_enthalpy = max(3 * hubble**2 - density_weight, .1 * hubble**2)
                total_enthalpy = scalar_enthalpy + rest_enthalpy
                rest_density = density_weight * scales[:, 0] * (.13 + .07 * np.sin(np.arange(len(wave))))
                rest_current = density_weight * wave / mass * scales[:, 1] * (.17 + .09 * np.cos(np.arange(len(wave))))
                anisotropy = .03 * density_weight * scales[:, 0] * wave**2 / (wave**2 + 3 * hubble**2)
                total_dstar = density_weight * dstar + rest_density
                total_current = density_weight * current + rest_current
                denominator = 2 * wave**2 + 3 * total_enthalpy
                potential = -(total_dstar + 3 * hubble * total_current / wave) / denominator
                lapse = potential - anisotropy / wave**2
                independent = original_quadrature_sources(values, wave, relative, canonical, potential, lapse, np.linspace(.4, 1.9, len(wave)))
                physical_density = density_weight * independent[:, 0] + rest_density + 3 * rest_enthalpy * potential
                constraint = 2 * wave**2 * potential + physical_density + 3 * hubble * total_current / wave
                constraint_scale = (2 * wave**2 + 3 * total_enthalpy) * abs(potential) + abs(total_dstar) + abs(3 * hubble * total_current / wave)
                constraint_scale = np.maximum(constraint_scale, 1e-100)
                check(choice + " metric elimination original stress " + str(point), np.max(abs(constraint) / constraint_scale))
                check(choice + " anisotropic metric slip " + str(point), np.max(abs(wave**2 * (potential - lapse) - anisotropy) / np.maximum(abs(anisotropy), 1e-100)))
                failed_constraint = 2 * wave**2 * potential + density_weight * dstar + rest_density + 3 * hubble * total_current / wave
                rows.append(dict(preparation=choice, point=point, omitted_measure_source_max=float(np.max(abs(failed_constraint) / constraint_scale)), min_denominator=float(np.min(denominator)), sources="declared synthetic rest-state port; not a hierarchy prediction"))
                constraint_history.append(np.column_stack((potential, lapse, constraint / constraint_scale)))
            arrays[choice + "_source_history"] = np.array(source_history)
            arrays[choice + "_metric_port_history"] = np.array(constraint_history)
        with np.load(ACTION / "action-evolution.npz") as packet:
            cold_action = packet["cold_action_final"].copy()
        check("cold saved action versus Euler unchanged", np.max(abs((cold_action - cold_final) / cold_scales)), GATE)
        for point, position in enumerate(saved["positions"]):
            mass, hubble, _, _, _ = cold.jets(float(position))
            potential, lapse = cold.metrics["full"](position).T
            if point == len(saved["positions"]) - 1:
                density, current = cold_action.T
            elif point == 0:
                density, current = cold.history["density"][:, 3], cold.history["current"][:, 3]
            else:
                continue
            dstar = density - 3 * potential
            other_enthalpy = .4 * hubble**2
            cold_weight = 2.6 * hubble**2
            rest_density = .07 * cold_weight * cold_scales[:, 0]
            rest_current = .03 * cold_weight * cold_scales[:, 1]
            total_current = cold_weight * current + rest_current
            denominator = 2 * wave**2 + 3 * (cold_weight + other_enthalpy)
            solution = -(cold_weight * dstar + rest_density + 3 * hubble * total_current / wave) / denominator
            rebuilt = cold_weight * (dstar + 3 * solution) + rest_density + 3 * other_enthalpy * solution
            residual = 2 * wave**2 * solution + rebuilt + 3 * hubble * total_current / wave
            normalizer = np.maximum(abs(rebuilt) + abs(2 * wave**2 * solution) + abs(3 * hubble * total_current / wave), 1e-100)
            check("cold metric port " + str(point), np.max(abs(residual) / normalizer))
        if not all(row["omitted_measure_source_max"] > ALGEBRA for row in rows):
            raise ValueError("measure omission mutation was not detected")
        adapter = (HIERARCHY / "build-corrected/camb_python.f90").read_text()
        adapter_checks = dict(averaged_selector_rejected="heavy averaged selector not authorized" in adapter,
                              neutrino_memory_rejected="unsupported neutrino perturbative memory" in adapter,
                              operator_zeros_excluded_selector="full=0" in adapter and "full(mts_capture_map(1:dimension))=vector" in adapter)
        if not all(adapter_checks.values()):
            raise ValueError("late adapter status changed; inspect before proceeding")
        for path, checksum in protected.items():
            guard()
            if digest(path) != checksum:
                raise ValueError("input modified during replay " + path)
        np.savez_compressed(ROOT / "source-replay.npz", **arrays)
        result = dict(passed=all(row["passed"] for row in checks), checks=checks, source_count=2 * len(saved["positions"]) * len(wave),
                      synthetic_metric_cases=rows, late_adapter=adapter_checks, original_inputs_unchanged=True,
                      actual_late_hierarchy_evolved=False, fitted_parameters=0,
                      code_sha256=digest(__file__), support_sha256=digest(ROOT / "support.py"),
                      output_sha256=digest(ROOT / "source-replay.npz"), frozen_sha256=digest(ROOT / "frozen-inputs.json"))
        write("sources-result.json", result)
        print(json.dumps(dict(passed=result["passed"], checks=len(checks), maximum_error=max(row["error"] for row in checks), source_count=result["source_count"], late_adapter=adapter_checks)), flush=True)
        if not result["passed"]:
            raise ValueError("source checks failed; inspect saved result")


if __name__ == "__main__":
    main()
