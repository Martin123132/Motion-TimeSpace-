import os
import sys
for setting in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[setting] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
ACTION = POST / "mts-metric-reduced-action-20261110"
TRANSPORT = POST / "mts-changing-metric-transport-20261110"
BACKGROUND = POST / "mts-background-derivatives-20261110"
HIERARCHY = POST / "mts-retarded-hierarchy-20261107"
START = time.monotonic()
ALGEBRA, GATE = 1e-10, 2e-5


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(name, value):
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def guard():
    if time.monotonic() - START > 900:
        raise RuntimeError("bounded worker deadline")
    for directory in (ROOT, POST, ACTION, TRANSPORT):
        if (directory / "STOP-REQUESTED").exists():
            raise RuntimeError("owner hold: " + str(directory))


@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), started=datetime.now(timezone.utc).isoformat())
    write(name + "-start.json", identity)
    try:
        guard()
        yield
    except BaseException as error:
        write(name + "-end.json", dict(**identity, state="failed", error=repr(error)))
        raise
    else:
        write(name + "-end.json", dict(**identity, state="completed", elapsed=time.monotonic() - START))


def input_hashes():
    seal_path = ACTION / "closeout.json"
    if digest(seal_path) != "e3bc182fb787afd12ae56daac68fe7ccd2ccf715ecdce1b1b17af2bbf89e1271":
        raise ValueError("changed retained action seal")
    seal = read(seal_path)
    result = dict(seal["input_hashes"])
    result[str(seal_path)] = digest(seal_path)
    for name, row in seal["artifacts"].items():
        result[str(ACTION / name)] = row["sha256"]
    for path, checksum in result.items():
        guard()
        if digest(path) != checksum:
            raise ValueError("changed retained input " + path)
    return result
