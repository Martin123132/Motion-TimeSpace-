from live_support import *
import argparse
import sympy as sp


def symbolic():
    background,velocity,mode,mode_velocity,beta,rate,hubble,mass2,wave,dilation,field_error,velocity_error,sound2=sp.symbols('b v u w beta r H mu2 k z Ef Eb cs2',real=True)
    density=beta*(velocity*mode_velocity+mass2*background*mode)
    pressure=beta*(velocity*mode_velocity-mass2*background*mode)
    current=beta*wave*velocity*mode
    derivatives={background:velocity+field_error,velocity:-2*hubble*velocity-mass2*background+velocity_error,mode:mode_velocity,mode_velocity:-2*hubble*mode_velocity-(wave**2+mass2)*mode-wave*dilation*velocity,beta:rate*beta,mass2:2*rate*mass2}
    def differentiate(expression):
        return sum(sp.diff(expression,variable)*value for variable,value in derivatives.items())
    averaged=sound2*(density+3*hubble*current/wave)
    residual=pressure-averaged
    density_remainder=-3*hubble*residual-wave*dilation*(beta*velocity**2-1)+(rate-hubble)*density+beta*velocity_error*mode_velocity+beta*mass2*field_error*mode+2*beta*(rate-hubble)*mass2*background*mode
    current_remainder=wave*residual+(rate-hubble)*current+beta*wave*velocity_error*mode
    identities=dict(density_remainder=sp.simplify(differentiate(density)-(-3*hubble*averaged-wave*current-wave*dilation+density_remainder))==0,current_remainder=sp.simplify(differentiate(current)-(-hubble*current+wave*averaged+current_remainder))==0,regular_pressure_relation=sp.simplify(wave*velocity*(pressure-density)+2*mass2*background*current)==0,turning_point_pressure=sp.simplify((pressure+density).subs(velocity,0))==0)
    write('symbolic.json',dict(passed=all(identities.values()),identities=identities,instantaneous_pressure_relation_requires_nonzero_velocity=True,turning_point_velocity_not_recovered_from_instantaneous_density_current=True))
    require(all(identities.values()),'exact parent-to-carrier identities')
    return identities


def validate():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    contract=read(ROOT/'contract.json')
    checks={}
    summaries={}
    carrier={}
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    for case in contract['cases']:
        label=case+'-live'
        report=read(ROOT/(label+'-result.json'))
        require(report['completed'] and report['passed'],'all declared paired runs pass '+case)
        require(read(ROOT/(label+'-native-release.json'))['released'],'native release '+case)
        capture=packet(ROOT/(label+'-capture.npz'))
        seeds=packet(ROOT/(label+'-seeds.npz'))
        inverse=packet(response_packet(case))
        active,kept,fields,first=[report[name] for name in ('active','kept','fields','first')]
        require(np.array_equal(seeds['native_seed'][seeds['indices']],inverse['inverse_state'][-1]),'saved reconstructed endpoint used')
        require(np.array_equal(seeds['native_seed'][seeds['untouched']],capture['reference'][0,seeds['untouched']]),'non-block state unchanged')
        require(np.all(capture['signature']==capture['signature'][0]),'fixed regime '+case)
        require(len(capture['clock'])==65 and capture['clock'][0]==inverse['clock'][-1],'original forward time interval '+case)
        require(np.all(capture['reference'][:,first+4]==0) if fields==2 else True,'coherent selector retained')
        selected=np.flatnonzero(capture['cache_mask'][0])
        runs={}
        for variant,entry in report['runs'].items():
            path=ROOT/(label+'-'+variant+'.npz')
            require(digest(path)==entry['packet_sha256'],'run packet unchanged')
            data=packet(path)
            runs[variant]=data
            prefix=case+'/'+variant+'/'
            for actual,reference,name in [(data['vector'][:,:active],capture['reference'][:,:active],'state'),(data['derivative'][:,:active],capture['derivative_reference'][:,:active],'derivative'),(data['observation'],capture['observation_reference'],'observer'),(data['state'][:,kept:],data['reference'][:,kept:],'moments'),(data['cache'][:,selected],capture['cache_reference'][:,selected],'cache')]:
                checks[prefix+name]=columns(actual,reference,name+'_')
            intended=seeds['reconstructed' if variant.startswith('reconstructed') else 'captured']
            checks[prefix+'seed_arithmetic']=columns(data['state'][0:1],(intended/seeds['normalization']*seeds['normalization'])[None,:],'coord_',ALGEBRA)
            recalculated=[]
            for component in range(fields):
                moment=data['state'][:,kept+4*component:kept+4*component+4].reshape(-1,2,2)
                jets=data['jets'][:,component]
                background=np.column_stack([jets[:,0],jets[:,1]/jets[:,5]])
                perturbation=np.einsum('tij,ti->tj',moment,background)/np.sum(background**2,axis=1)[:,None]
                remainder=moment-background[:,:,None]*perturbation[:,None,:]
                recalculated.append(remainder.reshape(-1,4))
                stress=np.column_stack([jets[:,5]**2*moment[:,1,1]+jets[:,4]*moment[:,0,0],jets[:,5]**2*moment[:,1,1]-jets[:,4]*moment[:,0,0],jets[:,5]*moment[:,1,0]])
                checks[prefix+'direct_stress'+str(component)]=columns(stress,data['observation'][:,32+5*component:35+5*component],'source_',ALGEBRA)
            recalculated=np.concatenate(recalculated,axis=1)
            checks[prefix+'transverse']=columns(recalculated+data['reference'][:,kept:],data['reference'][:,kept:],'moment_')
            require(np.array_equal(recalculated,data['transverse']),'saved transverse calculation exact')
            if fields==2:
                scale,rate,hubble,dilation=data['extra'].T
                beta=scale/density0
                field,velocity,field_first,velocity_first,mass2,omega=data['jets'][:,1].T
                mode,mode_velocity=data['vector'][:,first+2:first+4].T
                mode_prime,velocity_prime=data['derivative'][:,first+2:first+4].T
                density=beta*(velocity*mode_velocity+mass2*field*mode)
                current=beta*velocity*mode
                pressure=beta*(velocity*mode_velocity-mass2*field*mode)
                direct=np.column_stack([rate*density+beta*(rate*velocity_first*mode_velocity+velocity*velocity_prime+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_prime),rate*current+beta*(rate*velocity_first*mode+velocity*mode_prime)])
                ports=data['carrier_terms']
                checks[prefix+'carrier_sources']=columns(np.column_stack([density,current,pressure]),ports[:,:3],'source_',ALGEBRA)
                checks[prefix+'carrier_direct_derivative']=columns(direct,ports[:,11:13],'rate_',ALGEBRA)
                full=np.column_stack([ports[:,4]+ports[:,6]+ports[:,7]+ports[:,8],ports[:,5]+ports[:,9]+ports[:,10]])
                checks[prefix+'carrier_identity']=columns(full,direct,'rate_',ALGEBRA)
                if variant=='reconstructed-step256':
                    carrier=dict(pressure_relative_to_averaged=comparison(ports[:,3],pressure),uncorrected_carrier=columns(ports[:,4:6],direct,'rate_'),pressure_only_carrier=columns(ports[:,4:6]+ports[:,[6,9]],direct,'rate_'),full_carrier=columns(full,direct,'rate_',ALGEBRA),kinetic_factor_range=[float(np.min(ports[:,13])),float(np.max(ports[:,13]))],correction_peak_magnitudes=dict(density_pressure=float(np.max(abs(ports[:,6]))),density_kinetic=float(np.max(abs(ports[:,7]))),density_representation=float(np.max(abs(ports[:,8]))),current_pressure=float(np.max(abs(ports[:,9]))),current_representation=float(np.max(abs(ports[:,10])))),scope='instantaneous coherent-state remainder on same background; not a held-out test or rejection of averaging')
        for left,right in [('captured-step128','captured-step256'),('reconstructed-step128','reconstructed-step256'),('reconstructed-step256','captured-step256')]:
            for name in ('vector','derivative','observation'):
                width=active if name in ('vector','derivative') else 40
                checks[case+'/'+left+'_vs_'+right+'/'+name]=columns(runs[left][name][:,:width],runs[right][name][:,:width],name+'_')
        summaries[case]=dict(runs={variant:entry['worst'] for variant,entry in report['runs'].items()},reconstructed_vs_captured={name:max((row['normalized'] for row in checks[case+'/reconstructed-step256_vs_captured-step256/'+name].values() if row['normalized'] is not None),default=0.) for name in ('vector','derivative','observation')},active_cache_count=len(selected),native_release=True)
    identities=symbolic()
    prior_workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='validate-start.json':
            continue
        identity=read(path)
        end=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(identity)
        require(outcome['exited'],'prior worker exited')
        prior_workers.append(dict(name=path.stem.removesuffix('-start'),identity=identity,state=end['state'],outcome=outcome))
    passed=all_pass(checks)
    write('validation.json',dict(passed=passed,checks=checks,check_count=sum(len(group) for group in checks.values()),summaries=summaries,carrier=carrier,identities=identities,workers=prior_workers))
    print(json.dumps(dict(passed=passed,checks=sum(len(group) for group in checks.values()),identities=len(identities),summaries=summaries,carrier=carrier),default=convert),flush=True)
    require(passed,'independent numerical verification')


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['passed'],'validated live continuation')
    artifacts={}
    for path in sorted(ROOT.iterdir()):
        if path.is_file() and path.name not in ('seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json','closeout.json'):
            artifacts[path.name]=dict(sha256=digest(path),bytes=path.stat().st_size)
    write('closeout.json',dict(implementation_validated=True,paired_live_continuation_passed=True,physical_endpoint_from_projected_sources=True,retarded_history_required_before_start=True,future_rest_history_used_by_rhs=False,live_metric_and_species=True,averaged_carrier_residual_derived=True,averaged_residual_suppression_proved=False,late_averaged_selector_activated=False,galactic_population_selected=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    seal=read(ROOT/'closeout.json')
    check_hashes(seal['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in seal['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='postseal-start.json':
            continue
        worker_identity=read(path)
        end=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(worker_identity)
        require(outcome['exited'],'task-owned worker exited')
        workers.append(dict(name=path.stem.removesuffix('-start'),identity=worker_identity,state=end['state'],outcome=outcome))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode caches')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,prior_workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('validate','seal','postseal'))
    arguments=parser.parse_args()
    with worker(arguments.operation) as identity:
        if arguments.operation=='validate':
            validate()
        elif arguments.operation=='seal':
            seal()
        else:
            postseal(identity)
