from live_support import *


with worker('freeze'):
    require(digest(RESPONSE/'closeout.json')==EXPECTED,'retained response seal')
    seal=read(RESPONSE/'closeout.json')
    check_hashes(seal['input_hashes'])
    check_hashes({str(RESPONSE/name):row['sha256'] for name,row in seal['artifacts'].items()})
    cleanup=read(RESPONSE/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['verifier_external_exit_check']['exited'],'previous final cleanup')
    require(exited(cleanup['verifier_identity'])['exited'],'previous verifier not running')
    lower,upper=2892,2956
    references={}
    paths=[RESPONSE/'closeout.json',COUPLED/'run_coupled.py',COUPLED/'native-build-result.json',COUPLED/'native/camb/cambdll.dll',COUPLED/'native/fortran/camb_python.f90',COUPLED/'native/fortran/MTSTwoField.f90',POST/'mts-late-hierarchy-port-20261110/RESULTS.md',POST/'mts-early-canonical-state-bridge-20261110/STATE-COVARIANCE-BRIDGE.md',PROJECTION/'frozen-projection.npz',SOURCE/'heavy-equation-quintic.npz',SOURCE/'quintic_model.py',POST/'mts-metric-feedback-20261107/observer.dll',BRANCH/'native-heavy-matching-20261007/matching_common.py',BRANCH/'radiation-and-slow-field-transfer-20261007/radiation_common.py']
    for case in ('cold','heavy'):
        paths.extend([response_packet(case),HANDOFF/('early-'+case+'-restart.npz'),BACKGROUND/(case+'-candidate-background.npz'),TRANSFER/(case+'-transfer-capture.npz')])
        earlier=packet(paths[-2])
        full=packet(HANDOFF/('early-'+case+'-restart.npz'))
        inverse=packet(response_packet(case))
        require(inverse['clock'][-1]==full['full_clock'][lower],'reconstruction ends at start, no future forcing')
        references[case]=dict(clock_bounds=full['full_clock'][[lower,upper]],scale_bounds=full['requested_scale'][[lower,upper]],matching_scale=float(earlier.get('matching_scale',0)),heavy_exact_limit=.00028)
    paths.extend(sorted(ROOT.glob('*.py')))
    write('frozen-inputs.json',{str(path):digest(path) for path in paths})
    write('contract.json',dict(windows={'matching':[lower,upper]},cases=['cold','heavy'],integration=dict(method='DOP853',rtol=1e-10,atol=1e-12,steps=[128,256]),gate=GATE,algebra=ALGEBRA,references=references,seed_modes=['captured','reconstructed'],projection_end=lower,physical_grid_unchanged=True,bank_unchanged=True,no_future_driving_history=True,pressure_fit=False,goal_complete=False))
    print(json.dumps(dict(frozen=True,window=[lower,upper],references=references,input_count=len(paths)),default=convert),flush=True)
