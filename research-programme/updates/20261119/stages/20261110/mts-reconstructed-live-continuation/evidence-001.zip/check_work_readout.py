from live_support import *
from decimal import Decimal,localcontext


with worker('work-readout'):
    original=read(ROOT/'work-boundary.json')
    require(original['passed'],'original boundary identities')
    check_hashes(original['input_hashes'])
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    rows={}
    with localcontext() as context:
        context.prec=50
        def number(value):
            return Decimal.from_float(float(value))
        for case in ('cold','heavy'):
            data=packet(ROOT/(case+'-live-reconstructed-step256.npz'))
            for component in range(1 if case=='cold' else 2):
                actuals=[]
                errors=[]
                for extra,jet in zip(data['extra'],data['jets'][:,component]):
                    scale,rate,hubble,dilation=map(number,extra)
                    field,velocity,field_first,velocity_first,mass2,omega=map(number,jet)
                    beta=scale/number(density0)
                    virial=beta*field*velocity
                    derivative=rate*virial+beta*rate*(field_first*velocity+field*velocity_first)
                    defect=beta*((rate*field_first-velocity)*velocity+(rate*velocity_first+2*hubble*velocity+mass2*field)*field)
                    energy=beta*(velocity**2+mass2*field**2)/2
                    reconstructed=energy+derivative/2+(2*hubble-rate)*virial/2-defect/2
                    actual=beta*velocity**2
                    actuals.append(actual)
                    errors.append(abs(reconstructed-actual))
                peak=max(map(abs,actuals))
                require(peak>0,'retained kinetic factor is not exactly zero')
                relative=max(errors)/peak
                rows[case+('/heavy' if component else '/slow')]=dict(passed=bool(relative<=number(ALGEBRA)),unshifted_kinetic_factor_range=[str(min(actuals)),str(max(actuals))],decomposition_absolute_error=str(max(errors)),decomposition_peak_relative_error=str(relative),gate=ALGEBRA,precision_decimal_digits=50)
    require(all(row['passed'] for row in rows.values()),'unshifted kinetic identity including tiny slow control')
    write('work-boundary-readout-precision.json',dict(passed=True,rows=rows,reporting_correction='Original work-boundary.json computed its displayed kinetic range as (beta*v*v-1)+1. This rounds tiny slow kinetic factors to zero. Use the direct unshifted ranges here; original heavy result and work equations are unchanged.',original_result_sha256=digest(ROOT/'work-boundary.json')))
    print(json.dumps(dict(passed=True,rows=rows)),flush=True)
