from live_support import *
import ast
from scipy.integrate import solve_ivp


def sources(script,prior_path,table_path,clock_path,observer_owner,factory_path,local):
    result=read(ROOT/'frozen-inputs.json')
    result[str(ROOT/'contract.json')]=digest(ROOT/'contract.json')
    check_hashes(result)
    return result


def validate_capture(captured,prior,active,label,lower,upper):
    names=[str(value) for value in prior['standard_names']]
    indices=[names.index('mts_'+name+'_'+suffix) for suffix in ('s','h') for name in ('dphi','dphidot','drho','dp','q')]
    expected=np.column_stack([prior['observer'][lower:upper+1],prior['standard'][lower:upper+1][:,indices]])
    require(np.array_equal(captured['observation_reference'],expected),'identical native source and metric observations')
    require(np.array_equal(captured['clock'],prior['full_clock'][lower:upper+1]),'unchanged physical clocks')
    require(np.all(captured['signature']==captured['signature'][0]),'fixed native regime')
    old=packet(TRANSFER/(label.split('-')[0]+'-transfer-capture.npz'))
    for name in ('reference','derivative_reference','observation_reference','cache_reference','cache_mask','signature'):
        require(np.array_equal(captured[name][0],old[name][-1]),'exact prior endpoint '+name)
    checks=dict(state=columns(captured['restarted'][:,:active],captured['reference'][:,:active],'state_'),observation=columns(captured['observation_restarted'],captured['observation_reference'],'observable_'))
    chosen=np.flatnonzero(captured['cache_mask'][0])
    checks['cache']=columns(captured['cache_restarted'][:,chosen],captured['cache_reference'][:,chosen],'cache_')
    np.savez_compressed(ROOT/(label+'-capture.npz'),**captured)
    write(label+'-capture-check.json',dict(passed=all_pass(checks),checks=checks,active=active,previous_endpoint_exact=True,original_full_history_exact=True))
    require(all_pass(checks),'native restart controls')


def moment_transverse(states,jets,kept,fields):
    values=[]
    for component in range(fields):
        moment=states[:,kept+4*component:kept+4*component+4].reshape(-1,2,2)
        background=np.column_stack([jets[:,component,0],jets[:,component,1]/jets[:,component,5]])
        recovered=np.einsum('tij,ti->tj',moment,background)/np.sum(background**2,axis=1)[:,None]
        values.append((moment-background[:,:,None]*recovered[:,None,:]).reshape(-1,4))
    return np.concatenate(values,axis=1)


def carrier_terms(values,first,fields,density0):
    if fields!=2:
        return np.zeros(16)
    scale,rate,hubble,dilation=values['extra']
    beta=scale/density0
    field,velocity,field_first,velocity_first,mass2,omega=values['jets'][1]
    mode,mode_velocity=values['vector'][first+2:first+4]
    mode_first,velocity_mode_first=values['derivative'][first+2:first+4]
    density=beta*(velocity*mode_velocity+mass2*field*mode)
    current=beta*velocity*mode
    pressure=beta*(velocity*mode_velocity-mass2*field*mode)
    field_defect=rate*field_first-velocity
    velocity_defect=rate*velocity_first+2*hubble*velocity+mass2*field
    sound2=(1/mass2)/(np.sqrt(1+1/mass2)+1)**2
    averaged=sound2*(density+3*hubble*current)
    pressure_residual=pressure-averaged
    base_density=-3*hubble*averaged-current-dilation
    base_current=-hubble*current+averaged
    corrections=np.array([-3*hubble*pressure_residual,-dilation*(beta*velocity**2-1),(rate-hubble)*density+beta*velocity_defect*mode_velocity+beta*mass2*field_defect*mode+2*beta*(rate-hubble)*mass2*field*mode,pressure_residual,(rate-hubble)*current+beta*velocity_defect*mode])
    direct_density=rate*density+beta*(rate*velocity_first*mode_velocity+velocity*velocity_mode_first+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_first)
    direct_current=rate*current+beta*(rate*velocity_first*mode+velocity*mode_first)
    return np.r_[density,current,pressure,averaged,base_density,base_current,corrections,direct_density,direct_current,beta*velocity**2,field_defect,velocity_defect]


def continuation(captured,reference,reference_jets,direct,expected,label,kept,fields,active,pack,dimension,sample,scalar,pointers):
    case=label.split('-')[0]
    contract=read(ROOT/'contract.json')
    times=captured['clock']
    first=int(captured['signature'][0,2])-1
    inverse=packet(response_packet(case))
    require(inverse['clock'][-1]==times[0],'no future rest history in recovered endpoint')
    indices=np.array([*range(first,first+2*fields),1])
    require(np.array_equal(inverse['reference'][-1],captured['reference'][0,indices]),'same physical state ordering')
    seeded=captured['reference'][0].copy()
    seeded[indices]=inverse['inverse_state'][-1]
    untouched=np.array([index for index in range(len(seeded)) if index not in indices])
    require(np.array_equal(seeded[untouched],captured['reference'][0,untouched]),'all other native state unchanged')
    packed=np.zeros(dimension)
    jets=np.zeros((2,6))
    pack(float(times[0]),dimension,*pointers(seeded,packed,jets))
    require(scalar('status','phase').value==1,'reconstructed endpoint packing')
    kept_indices=np.array([index for index in range(active) if not first<=index<first+2*fields])
    start_values=sample(times[0],reference[0])
    normalization=np.maximum(abs(reference[0]),abs(start_values['rhs'])*(times[-1]-times[0]))
    normalization[normalization==0]=1.
    chosen=np.flatnonzero(captured['cache_mask'][0])
    seeds={'captured':reference[0].copy(),'reconstructed':packed}
    np.savez_compressed(ROOT/(label+'-seeds.npz'),native_seed=seeded,captured_native_seed=captured['reference'][0],indices=indices,untouched=untouched,normalization=normalization,reconstructed=packed,captured=reference[0],jets=jets)
    zero=sample(times[0],np.zeros(dimension))
    flipped=sample(times[0],-reference[0])
    control_checks=dict(zero=comparison(zero['rhs'],np.zeros(dimension),ALGEBRA),sign=comparison(flipped['rhs'],-start_values['rhs'],ALGEBRA))
    kicked=reference[0].copy()
    cdm_index=int(np.flatnonzero(kept_indices==1)[0])
    amplitude=max(abs(kicked[cdm_index]),1.)/4
    kicked[cdm_index]+=amplitude
    kicked_values=sample(times[0],kicked)
    predicted=start_values['observation'][12]*amplitude/(2*start_values['extra'][2])
    control_checks['cdm_live_metric']=comparison(kicked_values['extra'][3]-start_values['extra'][3],predicted,ALGEBRA)
    for component in range(fields):
        background=np.array([jets[component,0],jets[component,1]/jets[component,5]])
        change=np.outer(background,np.array([0.,-predicted*background[1]])).ravel()
        section=slice(kept+4*component,kept+4*component+4)
        control_checks['metric_phase_'+str(component)]=comparison(kicked_values['rhs'][section]-start_values['rhs'][section],change,ALGEBRA)
    if fields==2:
        kicked=reference[0].copy()
        kicked[kept+4:kept+8]*=1.25
        kicked_values=sample(times[0],kicked)
        control_checks['phase_live_metric']=comparison(kicked_values['extra'][3]-start_values['extra'][3],start_values['observation'][37]/(8*start_values['extra'][2]),ALGEBRA)
        control_checks['phase_momentum_constraint']=comparison(kicked_values['derivative'][0]-start_values['derivative'][0],start_values['observation'][39]/8,ALGEBRA)
    write(label+'-controls.json',dict(passed=all(row['passed'] for row in control_checks.values()),checks=control_checks))
    require(all(row['passed'] for row in control_checks.values()),'genuine bidirectional live coupling')
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    results={}
    saved={}
    for steps in contract['integration']['steps']:
        for mode,seed in seeds.items():
            variant=mode+'-step'+str(steps)
            def rhs(tau,normalized):
                return sample(tau,normalized*normalization)['rhs']/normalization
            solution=solve_ivp(rhs,(times[0],times[-1]),seed/normalization,method='DOP853',t_eval=times,rtol=contract['integration']['rtol'],atol=contract['integration']['atol'],max_step=(times[-1]-times[0])/steps)
            require(solution.success and solution.y.shape==(dimension,len(times)),'completed coupled continuation')
            state=solution.y.T*normalization
            evaluated=[sample(tau,row) for tau,row in zip(times,state)]
            observed={name:np.array([row[name] for row in evaluated]) for name in evaluated[0]}
            transverse=moment_transverse(state,observed['jets'],kept,fields)
            checks=dict(state=columns(observed['vector'][:,:active],captured['reference'][:,:active],'state_'),observer=columns(observed['observation'],captured['observation_reference'],'observable_'),derivative=columns(observed['derivative'][:,:active],captured['derivative_reference'][:,:active],'derivative_'),moments=columns(state[:,kept:],reference[:,kept:],'moment_'),transverse=columns(transverse+reference[:,kept:],reference[:,kept:],'moment_'),cache=columns(observed['cache'][:,chosen],captured['cache_reference'][:,chosen],'cache_'))
            ports=np.array([carrier_terms(row,first,fields,density0) for row in evaluated])
            if fields==2:
                direct_carrier=ports[:,11:13]
                corrected=np.column_stack([ports[:,4]+np.sum(ports[:,6:9],axis=1),ports[:,5]+np.sum(ports[:,9:11],axis=1)])
                checks['carrier_identity']=columns(corrected,direct_carrier,'rate_',ALGEBRA)
            destination=ROOT/(label+'-'+variant+'.npz')
            np.savez_compressed(destination,clock=times,state=state,reference=reference,transverse=transverse,normalization=normalization,carrier_terms=ports,kept_indices=kept_indices,**observed)
            worst={group:max((row['normalized'] for row in entries.values() if row['normalized'] is not None),default=0.) for group,entries in checks.items()}
            results[variant]=dict(passed=all_pass(checks),checks=checks,worst=worst,evaluations=solution.nfev,packet_sha256=digest(destination))
            saved[variant]=observed
            print(json.dumps(dict(case=case,variant=variant,passed=all_pass(checks),worst=worst,evaluations=solution.nfev)),flush=True)
    comparisons={}
    for left,right in [('captured-step128','captured-step256'),('reconstructed-step128','reconstructed-step256'),('reconstructed-step256','captured-step256')]:
        for name in ('vector','derivative','observation'):
            width=active if name in ('vector','derivative') else 40
            comparisons[left+'_vs_'+right+'_'+name]=columns(saved[left][name][:,:width],saved[right][name][:,:width],name+'_')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write(label+'-result.json',dict(completed=True,passed=all(row['passed'] for row in results.values()) and all_pass(comparisons),cases=case,runs=results,comparisons=comparisons,dimension=dimension,active=active,kept=kept,fields=fields,first=first,live_metric=True,live_rest_species=True,future_history_used_by_rhs=False,seed_history_ends_at_start=True,saved_window_specific_pressure_used_as_instantaneous_law=False,late_averaged_selector_activated=False,scope='original coherent parent continuation, not silently substituted into the averaged late carrier'))


def main():
    source=COUPLED/'run_coupled.py'
    require(digest(source)==read(COUPLED/'closeout.json')['artifacts']['run_coupled.py']['sha256'],'retained driver seal')
    changes=[]
    class Adapt(ast.NodeTransformer):
        def visit_ImportFrom(self,node):
            if node.module=='coupled_math':
                node.module='live_support'
                changes.append('support')
            return node
        def visit_Assign(self,node):
            targets=[target.id for target in node.targets if isinstance(target,ast.Name)]
            replacements=dict(label="args.case+'-live'",build="read(COUPLED/'native-build-result.json')",local="COUPLED/'native'",source_hashes='sources(Path(__file__),prior_path,table_path,clock_path,observer_owner,factory_path,local)')
            for target,value in replacements.items():
                if target in targets:
                    node.value=ast.parse(value,mode='eval').body
                    changes.append(target)
            return self.generic_visit(node)
        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='require' and len(node.value.args)==2 and isinstance(node.value.args[1],ast.Constant):
                if node.value.args[1].value=='original coupled handoff exact':
                    changes.append('capture')
                    return ast.parse('validate_capture(captured,prior,active,label,lower,upper)').body[0]
                if node.value.args[1].value=='same-state source and independent product derivative':
                    changes.append('continuation')
                    return [node,*ast.parse("continuation(captured,reference,reference_jets,direct,expected,label,kept,fields,active,pack,dimension,sample,scalar,pointers)\nreturn").body]
            return self.generic_visit(node)
        def visit_Try(self,node):
            node=self.generic_visit(node)
            if node.finalbody and any(isinstance(item,ast.Expr) and isinstance(item.value,ast.Call) and isinstance(item.value.func,ast.Name) and item.value.func.id=='reset' for item in node.finalbody):
                node.finalbody.extend(ast.parse("write(label+'-native-release.json',dict(released=cleared))\nrequire(cleared,'native owner released')").body)
                changes.append('release')
            return node
    tree=Adapt().visit(ast.parse(source.read_text()))
    require(changes==['support','label','build','local','source_hashes','capture','continuation','release'],'bounded native reuse adapter')
    namespace=dict(__file__=__file__,__name__='live_adapter',sources=sources,validate_capture=validate_capture,continuation=continuation)
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()


if __name__=='__main__':
    main()
