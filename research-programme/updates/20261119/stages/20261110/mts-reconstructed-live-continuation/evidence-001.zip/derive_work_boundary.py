from live_support import *
import sympy as sp


with worker('work-boundary'):
    require(read(ROOT/'validation.json')['passed'],'completed paired live continuation')
    field,velocity,beta,rate,hubble,mass2,field_error,velocity_error,dilation,dilation_prime=sp.symbols('b v beta r H mu2 Ef Eb z zp',real=True)
    energy=beta*(velocity**2+mass2*field**2)/2
    virial=beta*field*velocity
    virial_prime=rate*virial+beta*((velocity+field_error)*velocity+field*(-2*hubble*velocity-mass2*field+velocity_error))
    defect=beta*(field_error*velocity+velocity_error*field)
    kinetic=beta*velocity**2-1
    split=(energy-1)+virial_prime/2+(2*hubble-rate)*virial/2-defect/2
    wave=sp.symbols('k',real=True)
    boundary_derivative=-wave*(dilation_prime*virial+dilation*virial_prime)/2
    history=-wave*dilation*(energy-1)+wave*dilation_prime*virial/2-wave*(2*hubble-rate)*dilation*virial/2+wave*dilation*defect/2
    identities=dict(virial_decomposition=sp.simplify(kinetic-split)==0,metric_work_boundary_history=sp.simplify(-wave*dilation*kinetic-boundary_derivative-history)==0,constant_metric_flat_exact_background=sp.simplify((split-(energy-1)-virial_prime/2).subs({hubble:0,rate:0,field_error:0,velocity_error:0}))==0)
    require(all(identities.values()),'symbolic kinetic work boundary identity')
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    checks={}
    summaries={}
    hashes={str(Path(__file__)):digest(Path(__file__)),str(ROOT/'validation.json'):digest(ROOT/'validation.json')}
    for case in ('cold','heavy'):
        path=ROOT/(case+'-live-reconstructed-step256.npz')
        hashes[str(path)]=digest(path)
        data=packet(path)
        scale,rate,hubble,dilation=data['extra'].T
        beta=scale/density0
        fields=1 if case=='cold' else 2
        for component in range(fields):
            field,velocity,field_first,velocity_first,mass2,omega=data['jets'][:,component].T
            virial=beta*field*velocity
            direct_prime=rate*virial+beta*rate*(field_first*velocity+field*velocity_first)
            field_error=rate*field_first-velocity
            velocity_error=rate*velocity_first+2*hubble*velocity+mass2*field
            defect=beta*(field_error*velocity+velocity_error*field)
            energy=beta*(velocity**2+mass2*field**2)/2
            pieces=np.column_stack([energy-1,direct_prime/2,(2*hubble-rate)*virial/2,-defect/2])
            kinetic=beta*velocity**2-1
            key=case+('/heavy' if component else '/slow')
            checks[key]=dict(kinetic=comparison(np.sum(pieces,axis=1),kinetic,ALGEBRA),work=comparison(-dilation*np.sum(pieces,axis=1),-dilation*kinetic,ALGEBRA))
            summaries[key]=dict(energy_range=[float(np.min(energy)),float(np.max(energy))],kinetic_factor_range=[float(np.min(kinetic+1)),float(np.max(kinetic+1))],virial_boundary_values=[float(virial[0]),float(virial[-1])],metric_boundary_contribution=float(-(dilation[-1]*virial[-1]-dilation[0]*virial[0])/2),pointwise_piece_peaks=np.max(abs(pieces),axis=0).tolist(),positive_population_selected=False,interpretation='physical late-carrier normalization' if component else 'algebra control only; slow field is not the heavy dust carrier')
            np.savez_compressed(ROOT/(case+'-virial-'+str(component)+'.npz'),clock=data['clock'],pieces=pieces,kinetic=kinetic,virial=virial,virial_prime=direct_prime,dilation=dilation,defect=defect,energy=energy)
    check_hashes(hashes)
    require(all_pass(checks),'paired numerical virial identities')
    write('work-boundary.json',dict(passed=True,identities=identities,checks=checks,summaries=summaries,input_hashes=hashes,metric_history_integrals_evaluated=False,boundary_alone_assumed_sufficient=False,averaging_suppression_proved=False))
    print(json.dumps(dict(passed=True,identities=len(identities),summaries=summaries),default=convert),flush=True)
