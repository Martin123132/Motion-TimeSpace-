import os
import sys
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[name]='1'
sys.dont_write_bytecode=True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime,timezone
import psutil
import numpy as np

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
RESPONSE=POST/'mts-projection-response-20261110'
COUPLED=POST/'mts-coupled-phase-stress-20261110'
TRANSFER=POST/'mts-phase-transfer-memory-20261110'
PROJECTION=POST/'mts-coherent-projection-20261110'
HANDOFF=POST/'mts-early-state-handoff-20261110'
SOURCE=POST/'mts-native-source-conservation-20261110'
BACKGROUND=POST/'mts-regular-slow-background-20261110'
BRANCH=POST/'condensate-origin-20261003'
EXPECTED='7a926499d756c66ba80243f32960b06d8103196f7448670b5cf2c33ae43fbb71'
GATE,ALGEBRA=2e-5,1e-10
START=time.monotonic()


def require(condition,message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def convert(value):
    if isinstance(value,np.generic):
        return value.item()
    if isinstance(value,np.ndarray):
        return value.tolist()
    raise TypeError(type(value).__name__)


def write(name,value):
    payload=json.dumps(value,indent=2,allow_nan=False,default=convert)
    with (ROOT/name).open('x',encoding='utf-8') as stream:
        stream.write(payload)


def guard():
    require(time.monotonic()-START<900,'worker deadline')
    for folder in (ROOT,POST,RESPONSE,COUPLED,TRANSFER,HANDOFF,PROJECTION,BRANCH):
        require(not (folder/'STOP-REQUESTED').exists(),'owner hold '+str(folder))


def exited(identity):
    try:
        process=psutil.Process(identity['pid'])
        same=abs(process.create_time()-identity['created'])<.01 and process.cmdline()==identity['command']
    except psutil.NoSuchProcess:
        return dict(exited=True,reason='PID absent')
    return dict(exited=not same,reason='original process live' if same else 'PID reused; untouched')


@contextmanager
def worker(name):
    process=psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity=dict(pid=process.pid,created=process.create_time(),command=process.cmdline(),utc=datetime.now(timezone.utc).isoformat())
    write(name+'-start.json',identity)
    try:
        guard()
        yield identity
    except BaseException as error:
        write(name+'-end.json',dict(**identity,state='failed',error=repr(error)))
        raise
    else:
        write(name+'-end.json',dict(**identity,state='completed',elapsed=time.monotonic()-START))


def check_hashes(mapping):
    for path,checksum in mapping.items():
        guard()
        require(Path(path).is_file() and digest(path)==checksum,'unchanged source '+path)


def comparison(actual,reference,tolerance=GATE):
    error=float(np.max(abs(np.asarray(actual)-reference)))
    peak=float(np.max(abs(reference)))
    return dict(passed=error<=tolerance*peak,absolute_error=error,reference_peak=peak,normalized=error/peak if peak else (0. if error==0 else None),tolerance=tolerance)


def columns(actual,reference,prefix,tolerance=GATE):
    return {prefix+str(index):comparison(actual[:,index],reference[:,index],tolerance) for index in range(reference.shape[1])}


def packet(path):
    with np.load(path,allow_pickle=False) as saved:
        return {name:saved[name].copy() for name in saved.files}


def response_packet(case):
    return RESPONSE/(case+'-response-'+('resume-' if case=='heavy' else '')+'fineT-order8.npz')


def all_pass(checks):
    return all(row['passed'] for group in checks.values() for row in group.values())
