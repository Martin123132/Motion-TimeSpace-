import os
import sys
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True

import ast
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import psutil

STAGE = Path(__file__).resolve().parent
HANDOFF = STAGE.parent / "MTS-GALACTIC-POPULATION-HANDOFF-20261110.md"


def digest(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    require(not (STAGE / "closeout.json").exists(), "existing seal")
    reports = [read(STAGE / name) for name in ("result.json", "unit-result.json", "smooth-result.json")]
    expected_counts = (308, 333, 222)
    hashes = {}
    for result, expected in zip(reports, expected_counts):
        require(result["passed"] and len(result["checks"]) == expected, "recorded check count")
        for check in result["checks"]:
            require(check["passed"] and check["gate"] in (1e-10, 2e-5) and
                    abs(check["error"]) <= check["gate"], "unchanged check gate")
        collections = [result.get("sources", {}), result.get("inputs", {}),
                       result.get("inherited_seed", {}).get("source_hashes", {})]
        for collection in collections:
            for path, checksum in collection.items():
                require(path not in hashes or hashes[path] == checksum, "conflicting provenance")
                hashes[path] = checksum
    for path, checksum in hashes.items():
        require(digest(path) == checksum, "changed evidence: " + path)
    require(reports[1]["original_result_sha256"] == digest(STAGE / "result.json"), "original result link")
    previous = STAGE.parent / "mts-full-cell-flow-completion-20261110/closeout.json"
    require(digest(previous) == "a4aefbed6f99f7c58a89bed241041fc719ecf1a87c18f16292114b04ab5959e7",
            "saved numerical stage preserved")
    for path in STAGE.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    paths = [line.strip() for line in HANDOFF.read_text().splitlines() if line.startswith("D:/")]
    require(paths and all(Path(path).is_file() for path in paths), "handoff source paths")
    receipts = []
    for prefix in ("worker", "unit-worker", "smooth-worker"):
        start = read(STAGE / (prefix + "-start.json"))
        end = read(STAGE / (prefix + "-end.json"))
        require(end["state"] == "completed" and all(start[key] == end[key] for key in ("pid", "created", "command")),
                "terminal identity")
        target = {"worker": "result.json", "unit-worker": "unit-result.json",
                  "smooth-worker": "smooth-result.json"}[prefix]
        require(end["result_sha256"] == digest(STAGE / target), "worker output receipt")
        same = False
        reused = False
        try:
            live = psutil.Process(start["pid"])
            same = abs(live.create_time() - start["created"]) < 0.01
            reused = not same
        except psutil.NoSuchProcess:
            pass
        require(not same, "owned worker remains active")
        receipts.append(dict(pid=start["pid"], created=start["created"], command=start["command"],
                             absent=True, pid_reused=reused))
    random = np.random.default_rng(20261112)
    bracket_cases = 0
    maximum_excess = 0.0
    for case in range(30):
        raw = random.normal(size=(6, 6)) + 1j * random.normal(size=(6, 6))
        hamiltonian = (raw + raw.conj().T) / 2
        energies, vectors = np.linalg.eigh(hamiltonian)
        raw = random.normal(size=(6, 4)) + 1j * random.normal(size=(6, 4))
        covariance = raw @ raw.conj().T
        covariance /= np.trace(covariance).real
        weights = np.diag(vectors.conj().T @ covariance @ vectors).real
        total = float(weights.sum())
        sharp = float(weights[energies < 0].sum())
        for width in (0.01, 0.2, 1.0):
            smooth = float(weights @ (0.5 - np.arctan(energies / width) / np.pi))
            for epsilon in (0.1, 0.5, 2.0):
                near = float(weights[abs(energies) <= epsilon].sum())
                bound = near / 2 + min(0.5, width / (np.pi * epsilon)) * (total - near)
                excess = max(0.0, abs(smooth - sharp) - bound)
                maximum_excess = max(maximum_excess, excess)
                require(excess <= 1e-10, "smooth-to-sharp count bracket")
                bracket_cases += 1
    require(not list(STAGE.rglob("__pycache__")), "no bytecode artifacts")
    write(STAGE / "validation.json", dict(passed=True, preserved_input_files=len(hashes),
          checked_handoff_paths=len(paths), suite_counts=expected_counts,
          original_308_included_in_333=True, independent_bracket_cases=bracket_cases,
          maximum_bracket_excess=maximum_excess, source_hashes=hashes,
          supported_interface="energy_units.py and smooth_escape.py",
          sharp_full_halo_gap_claimed=False, galaxy_prediction_claimed=False,
          parent_action_changed=False, source_bank_changed=False))
    write(STAGE / "CLEANUP.json", dict(time=datetime.now(timezone.utc).isoformat(),
          workers=receipts, all_numerical_workers_exited=True, processes_killed=[],
          temporary_apps_started=[], unrelated_processes_changed=False,
          github_actions=False, sealer=dict(pid=process.pid, created=process.create_time(),
                                           command=process.cmdline())))
    artifacts = []
    for path in sorted([path for path in STAGE.rglob("*") if path.is_file()] + [HANDOFF]):
        artifacts.append(dict(path=str(path), bytes=path.stat().st_size, sha256=digest(path)))
    write(STAGE / "closeout.json", dict(passed=True, time=datetime.now(timezone.utc).isoformat(),
          status="derived-population-readout-and-gap-free-control-not-galaxy-formation",
          artifacts=artifacts, total_bytes=sum(row["bytes"] for row in artifacts),
          goal_complete=False, no_automatic_handoff=True, no_galaxy_files_modified=True))
    print(json.dumps(dict(closeout_sha256=digest(STAGE / "closeout.json"), artifacts=len(artifacts),
                          bytes=sum(row["bytes"] for row in artifacts), input_files=len(hashes),
                          bracket_cases=bracket_cases, sealer_pid=process.pid)))


if __name__ == "__main__":
    main()
