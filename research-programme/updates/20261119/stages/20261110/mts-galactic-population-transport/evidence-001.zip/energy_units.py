import numpy as np
import population_transport as normalized

ALGEBRA_GATE = normalized.ALGEBRA_GATE
NUMERICAL_GATE = normalized.NUMERICAL_GATE
transported_bound_population = normalized.transported_bound_population
retained_number_flux = normalized.retained_number_flux


def energy_scale(hamiltonian, threshold=0.0):
    matrix = np.asarray(hamiltonian, dtype=complex)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1] or not np.isfinite(matrix).all():
        raise ValueError("finite square Hamiltonian required")
    if not np.isfinite(threshold):
        raise ValueError("finite escape threshold required")
    shifted = matrix - threshold * np.eye(len(matrix))
    scale = float(np.max(abs(shifted)))
    if not np.isfinite(scale) or scale == 0:
        raise ValueError("no separated spectrum at the escape threshold")
    return shifted, scale


def spectral_data(hamiltonian, derivative=None, threshold=0.0, threshold_guard=1e-12):
    shifted, scale = energy_scale(hamiltonian, threshold)
    derivative = None if derivative is None else np.asarray(derivative, dtype=complex) / scale
    data = normalized.spectral_data(shifted / scale, derivative, threshold=0.0,
                                    threshold_guard=threshold_guard)
    if data["gap"] is not None:
        data["gap"] *= scale
    return data


def population_balance(hamiltonian, derivative, occupation, hbar=1.0, extra_source=None):
    shifted, scale = energy_scale(hamiltonian)
    data = normalized.population_balance(shifted / scale, np.asarray(derivative, dtype=complex) / scale,
                                         occupation, hbar=hbar / scale, extra_source=extra_source)
    if data["gap"] is not None:
        data["gap"] *= scale
    return data
