import os
import sys
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True

import numpy as np
import psutil
from datetime import datetime, timezone
import check_population_transport as test
import energy_units as units
import population_transport as original

test.spectral_data = units.spectral_data
test.population_balance = units.population_balance


def main():
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    test.guard()
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(),
                    affinity=process.cpu_affinity(), priority=process.nice(),
                    started=datetime.now(timezone.utc).isoformat())
    test.write(test.STAGE / "unit-worker-start.json", identity)
    try:
        sources = {str(path): test.digest(path) for path in test.STAGE.iterdir()
                   if path.suffix in (".py", ".md")}
        original_result = test.read(test.STAGE / "result.json")
        for path, checksum in {**original_result["sources"], **original_result["inputs"]}.items():
            if test.digest(path) != checksum:
                raise ValueError("original evidence changed: " + path)
        special = test.special_checks()
        random = test.random_checks()
        rotating = [test.rotating_well(duration) for duration in (0.5, 4.0)]
        test.check("same-final-H-different-history",
                   np.linalg.norm(np.array(rotating[0]["final_hamiltonian"]) -
                                  np.array(rotating[1]["final_hamiltonian"])))
        boundary = test.boundary_checks()
        seed = test.inherited_seed()
        hamiltonian = np.array([[-1.0, 0.2j], [-0.2j, 1.0]])
        derivative = np.array([[0.1, 0.7], [0.7, -0.2]])
        occupation = np.array([[0.4, 0.2j], [-0.2j, 0.6]])
        reference = units.population_balance(hamiltonian, derivative, occupation)
        projector_reference = units.spectral_data(hamiltonian, derivative)
        rescaling = []
        for factor in (1e-80, 1.0, 1e80):
            balance = units.population_balance(factor * hamiltonian, factor * derivative, occupation, hbar=factor)
            projector = units.spectral_data(factor * (hamiltonian + 10 * np.eye(2)),
                                             factor * derivative, threshold=10 * factor)
            for key in ("rate", "bound", "unbound", "geometric_rate_bound", "rotation_rate"):
                test.check("energy-rescale-" + str(factor) + "-" + key, balance[key] - reference[key])
            test.check("energy-gap-rescale-" + str(factor), balance["gap"] / factor - reference["gap"])
            test.check("escape-shift-projector-" + str(factor),
                       np.linalg.norm(projector["projector"] - projector_reference["projector"]))
            test.check("escape-shift-rate-" + str(factor),
                       np.linalg.norm(projector["projector_rate"] - projector_reference["projector_rate"]))
            rescaling.append(dict(energy_factor=factor, bound=balance["bound"], rate=balance["rate"]))
        test.expect_error("raw-tiny-energy-interface-refused",
                          lambda: original.spectral_data(1e-80 * hamiltonian))
        for path, checksum in sources.items():
            if test.digest(path) != checksum:
                raise ValueError("source changed during unit check")
        result = dict(passed=True, checks=test.CHECKS, special=special, random=random, rotating=rotating,
                      boundary=boundary, inherited_seed=seed, energy_rescaling=rescaling,
                      sources=sources, original_result_sha256=test.digest(test.STAGE / "result.json"),
                      supported_interface="energy_units.py", no_physical_changes=True)
        test.write(test.STAGE / "unit-result.json", result)
        test.write(test.STAGE / "unit-worker-end.json", dict(**identity, state="completed",
                   finished=datetime.now(timezone.utc).isoformat(),
                   result_sha256=test.digest(test.STAGE / "unit-result.json")))
        print("Unit-safe checks:", len(test.CHECKS), "passed")
    except Exception as error:
        test.write(test.STAGE / "unit-worker-end.json", dict(**identity, state="failed",
                   finished=datetime.now(timezone.utc).isoformat(), error=repr(error), checks=test.CHECKS))
        raise


if __name__ == "__main__":
    main()
