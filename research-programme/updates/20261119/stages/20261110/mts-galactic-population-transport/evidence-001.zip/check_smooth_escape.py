import os
import sys
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True
from datetime import datetime, timezone
import numpy as np
import psutil
import check_population_transport as audit
from smooth_escape import smooth_escape_readout
from energy_units import spectral_data


def main():
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(),
                    affinity=process.cpu_affinity(), priority=process.nice(),
                    started=datetime.now(timezone.utc).isoformat())
    audit.guard()
    audit.write(audit.STAGE / "smooth-worker-start.json", identity)
    try:
        sources = {str(path): audit.digest(path) for path in audit.STAGE.iterdir()
                   if path.suffix in (".py", ".md")}
        hamiltonian = np.diag([-1.0, 0.0])
        derivative = np.diag([0.0, 1.0])
        occupation = np.diag([0.0, 1.0])
        crossing = smooth_escape_readout(hamiltonian, derivative, occupation, 0.2)
        audit.check("crossing-count", crossing["count"] - 0.5)
        audit.check("crossing-rate", crossing["rate"] + 1 / (np.pi * 0.2))
        audit.check("crossing-sharp-bound", abs(crossing["rate"]) - crossing["count_rate_bound"])
        audit.expect_error("sharp-gap-not-fabricated", lambda: spectral_data(hamiltonian))
        degenerate = smooth_escape_readout(np.zeros((2, 2)), np.array([[0.0, 0.3], [0.3, 0.0]]),
                                           np.full((2, 2), 0.5), 0.2)
        audit.check("degenerate-offdiagonal", degenerate["rate"] + 0.3 / (np.pi * 0.2))
        random = np.random.default_rng(20261111)
        reports = []
        for case in range(30):
            raw = random.normal(size=(6, 6)) + 1j * random.normal(size=(6, 6))
            matrix = (raw + raw.conj().T) / 2
            raw = random.normal(size=(6, 6)) + 1j * random.normal(size=(6, 6))
            variation = (raw + raw.conj().T) / 4
            raw = random.normal(size=(6, 3)) + 1j * random.normal(size=(6, 3))
            state = raw @ raw.conj().T
            state /= np.trace(state).real
            value = smooth_escape_readout(matrix, variation, state, 0.2)
            eigenvalues = np.linalg.eigvalsh(value["window"])
            audit.check("window-positive-" + str(case), max(0.0, -eigenvalues.min(), eigenvalues.max() - 1))
            audit.check("window-commutes-" + str(case),
                        np.linalg.norm(matrix @ value["window"] - value["window"] @ matrix))
            audit.check("window-operator-bound-" + str(case),
                        max(0.0, np.linalg.norm(value["window_rate"], 2) - value["operator_bound"]))
            audit.check("window-count-bound-" + str(case), max(0.0, abs(value["rate"]) - value["count_rate_bound"]))
            differences = []
            for step in (1e-4, 5e-5):
                plus = smooth_escape_readout(matrix + step * variation, variation, state, 0.2)["window"]
                minus = smooth_escape_readout(matrix - step * variation, variation, state, 0.2)["window"]
                error = float(np.linalg.norm((plus - minus) / (2 * step) - value["window_rate"]) /
                              max(1.0, np.linalg.norm(value["window_rate"])))
                audit.check("window-finite-difference-" + str(case) + "-" + str(step),
                            error, audit.NUMERICAL_GATE)
                differences.append(error)
            audit.check("window-refinement-" + str(case), max(0.0, differences[1] - differences[0]))
            reports.append(dict(case=case, count=value["count"], rate=value["rate"],
                                bound=value["count_rate_bound"], finite_differences=differences))
        for factor in (1e-80, 1.0, 1e80):
            scaled = smooth_escape_readout(factor * (hamiltonian + 10 * np.eye(2)),
                                           factor * derivative, occupation, 0.2 * factor, threshold=10 * factor)
            audit.check("smooth-energy-unit-count-" + str(factor), scaled["count"] - crossing["count"])
            audit.check("smooth-energy-unit-rate-" + str(factor), scaled["rate"] - crossing["rate"])
        moving = smooth_escape_readout(hamiltonian, derivative + 7 * np.eye(2), occupation, 0.2, threshold_rate=7)
        audit.check("moving-escape-reference", moving["rate"] - crossing["rate"])
        for path, checksum in sources.items():
            if audit.digest(path) != checksum:
                raise ValueError("source changed during smooth-window check")
        result = dict(passed=True, checks=audit.CHECKS, random=reports, sources=sources,
                      crossing={key: value for key, value in crossing.items()
                                if key not in ("window", "window_rate")},
                      no_spectral_gap_assumed=True, observable="energy-resolution-weighted count, not sharp bound mass",
                      no_galaxy_predictions=True)
        audit.write(audit.STAGE / "smooth-result.json", result)
        audit.write(audit.STAGE / "smooth-worker-end.json", dict(**identity, state="completed",
                   finished=datetime.now(timezone.utc).isoformat(),
                   result_sha256=audit.digest(audit.STAGE / "smooth-result.json")))
        print("Gap-free readout checks:", len(audit.CHECKS), "passed")
    except Exception as error:
        audit.write(audit.STAGE / "smooth-worker-end.json", dict(**identity, state="failed",
                   finished=datetime.now(timezone.utc).isoformat(), error=repr(error), checks=audit.CHECKS))
        raise


if __name__ == "__main__":
    main()
