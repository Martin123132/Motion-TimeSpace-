import os
import sys

for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
import time
import numpy as np
import psutil
from scipy.integrate import solve_ivp
from scipy.linalg import expm
from scipy import constants
from population_transport import (
    ALGEBRA_GATE, NUMERICAL_GATE, spectral_data, population_balance,
    transported_bound_population, retained_number_flux,
)

STAGE = Path(__file__).resolve().parent
POST = STAGE.parent
BRIDGE = Path("C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102")
START = time.monotonic()
CHECKS = []


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def guard():
    if time.monotonic() - START > 600:
        raise RuntimeError("bounded test deadline")
    for path in (STAGE / "STOP-REQUESTED", POST / "STOP-REQUESTED",
                 BRIDGE / "STOP-REQUESTED", BRIDGE.parent / "STOP-REQUESTED",
                 BRIDGE.parent / "execution-v3/STOP-REQUEST.json"):
        if path.exists():
            raise RuntimeError("owner hold: " + str(path))


def check(name, value, gate=ALGEBRA_GATE):
    guard()
    value = float(value)
    passed = bool(np.isfinite(value) and abs(value) <= gate)
    CHECKS.append(dict(name=name, error=value, gate=gate, passed=passed))
    if not passed:
        raise AssertionError(name + ": " + str(value))


def expect_error(name, operation):
    try:
        operation()
    except ValueError:
        check(name, 0.0)
    else:
        check(name, 1.0)


def random_checks():
    random = np.random.default_rng(20261110)
    reports = []
    for case in range(30):
        size = 6
        raw = random.normal(size=(size, size)) + 1j * random.normal(size=(size, size))
        vectors = np.linalg.qr(raw)[0]
        energies = np.array([-2.4, -1.2, -0.4, 0.7, 1.3, 2.5])
        hamiltonian = (vectors * energies) @ vectors.conj().T
        raw = random.normal(size=(size, size)) + 1j * random.normal(size=(size, size))
        derivative = (raw + raw.conj().T) / 4
        raw = random.normal(size=(size, 4)) + 1j * random.normal(size=(size, 4))
        occupation = raw @ raw.conj().T
        occupation *= 2.5 / np.trace(occupation).real
        data = spectral_data(hamiltonian, derivative)
        projector, rate = data["projector"], data["projector_rate"]
        identity = np.eye(size)
        balance = population_balance(hamiltonian, derivative, occupation)
        check("projector-" + str(case), np.linalg.norm(projector @ projector - projector))
        check("commutator-" + str(case), np.linalg.norm(hamiltonian @ projector - projector @ hamiltonian))
        check("tangent-projector-" + str(case), np.linalg.norm(projector @ rate @ projector) +
              np.linalg.norm((identity - projector) @ rate @ (identity - projector)))
        check("occupation-rate-" + str(case), balance["rate"] - balance["geometric_rate"])
        check("capture-bound-" + str(case),
              max(0.0, abs(balance["geometric_rate"]) - balance["geometric_rate_bound"]))
        check("spectral-gap-bound-" + str(case), max(0.0, data["rotation_rate"] - data["derivative_bound"]))
        differences = []
        for step in (1e-3, 5e-4):
            plus = spectral_data(hamiltonian + step * derivative)["projector"]
            minus = spectral_data(hamiltonian - step * derivative)["projector"]
            difference = np.linalg.norm((plus - minus) / (2 * step) - rate) / max(np.linalg.norm(rate), 1.0)
            differences.append(float(difference))
            check("projector-finite-difference-" + str(case) + "-" + str(step), difference, NUMERICAL_GATE)
        check("projector-refinement-" + str(case), max(0.0, differences[1] - differences[0]))
        reports.append(dict(case=case, finite_differences=differences, **balance))
    return reports


def rotating_well(duration):
    gap = 2.0
    angle = np.pi / 3
    speed = angle / duration
    energies = np.diag([-gap / 2, gap / 2])
    generator = np.array([[0.0, -1.0], [1.0, 0.0]])
    initial = np.diag([0.0, 1.0]).astype(complex)

    def operators(clock):
        rotation = expm(generator * speed * clock)
        hamiltonian = rotation @ energies @ rotation.T
        derivative = speed * (generator @ hamiltonian - hamiltonian @ generator)
        return hamiltonian, derivative

    def rhs(clock, state):
        guard()
        propagator = state[:4].reshape(2, 2)
        hamiltonian, derivative = operators(clock)
        occupation = propagator @ initial @ propagator.conj().T
        work = np.trace(derivative @ occupation)
        return np.r_[(-1j * hamiltonian @ propagator).reshape(-1), work]

    times = np.linspace(0, duration, 129)
    initial_vector = np.r_[np.eye(2, dtype=complex).reshape(-1), 0j]
    solution = solve_ivp(rhs, (0.0, duration), initial_vector, method="DOP853",
                         t_eval=times, rtol=2e-12, atol=2e-14)
    if not solution.success:
        raise RuntimeError(solution.message)
    probability = angle**2 / (angle**2 + (gap * duration / 2)**2)
    probability *= np.sin(np.sqrt(angle**2 + (gap * duration / 2)**2))**2
    maximum_unitarity = 0.0
    maximum_rate_error = 0.0
    maximum_bound_excess = 0.0
    for clock, state in zip(times, solution.y.T):
        propagator = state[:4].reshape(2, 2)
        hamiltonian, derivative = operators(clock)
        occupation = propagator @ initial @ propagator.conj().T
        balance = population_balance(hamiltonian, derivative, occupation)
        maximum_unitarity = max(maximum_unitarity, float(np.linalg.norm(propagator.conj().T @ propagator - np.eye(2))))
        maximum_rate_error = max(maximum_rate_error, abs(balance["rate"] - balance["geometric_rate"]))
        maximum_bound_excess = max(maximum_bound_excess,
                                  abs(balance["rate"]) - balance["geometric_rate_bound"])
    propagator = solution.y[:4, -1].reshape(2, 2)
    final_hamiltonian = operators(duration)[0]
    final_occupation = propagator @ initial @ propagator.conj().T
    projector = spectral_data(final_hamiltonian)["projector"]
    actual = transported_bound_population(initial, propagator, projector)
    energy_change = float(np.trace(final_hamiltonian @ final_occupation - energies @ initial).real)
    work = float(solution.y[4, -1].real)
    check("rotating-probability-" + str(duration), actual - probability, NUMERICAL_GATE)
    check("rotating-unitarity-" + str(duration), maximum_unitarity)
    check("rotating-rate-" + str(duration), maximum_rate_error)
    check("rotating-rate-bound-" + str(duration), maximum_bound_excess)
    check("rotating-work-" + str(duration), energy_change - work, NUMERICAL_GATE)
    check("integrated-angle-bound-" + str(duration), max(0.0, np.arcsin(np.sqrt(actual)) - angle))
    return dict(duration=duration, gap=gap, angle=angle, predicted_probability=float(probability),
                numerical_probability=actual, energy_change=energy_change, external_work=work,
                unitary_error=maximum_unitarity, final_hamiltonian=final_hamiltonian.real.tolist())


def boundary_checks():
    amplitude = 0.8
    secondary = 0.6
    wave_number = 3.0
    mass = 2.3
    hbar = 1.0
    speed = 0.13
    reports = []
    for scale in (1.0, 1.5):
        frequency = hbar * wave_number**2 / (2 * mass * scale**2)
        errors = []
        for clock in np.linspace(0, 0.6, 17):
            radius = 1.1 + speed * clock
            points = np.array([0.0, radius])
            phase = wave_number * points - frequency * clock
            envelope = (amplitude + secondary * np.exp(1j * phase)) / np.sqrt(2 * np.pi)
            derivative = 1j * wave_number * secondary * np.exp(1j * phase) / np.sqrt(2 * np.pi)
            density, current = retained_number_flux(envelope[None, :], derivative[None, :],
                                                     hbar, mass, scale)
            direct = speed / (2 * np.pi) + amplitude * secondary / (np.pi * wave_number) * (
                (wave_number * speed - frequency) * np.cos(phase[1]) +
                frequency * np.cos(frequency * clock))
            flux = current[0] - current[1] + speed * density[1]
            errors.append(abs(float(direct - flux)))
        check("moving-aperture-" + str(scale), max(errors))
        reports.append(dict(scale_factor=scale, maximum_flux_error=max(errors)))
    return reports


def special_checks():
    hamiltonian = np.diag([-1.0, 1.0])
    derivative = np.array([[0.0, 2.0], [2.0, 0.0]])
    coherent = np.full((2, 2), 0.5, dtype=complex)
    balance = population_balance(hamiltonian, derivative, coherent)
    diagonal = population_balance(hamiltonian, derivative, np.diag([0.5, 0.5]))
    check("sharp-rate-bound", abs(balance["rate"]) - balance["geometric_rate_bound"])
    check("sharp-rate-value", balance["rate"] + 1.0)
    check("discarded-coherence-loses-transfer", diagonal["rate"])
    propagator = expm(-1j * hamiltonian * 3.7)
    check("static-no-capture", transported_bound_population(coherent, propagator, np.diag([1.0, 0.0])) - 0.5)
    zero = population_balance(hamiltonian, derivative, np.zeros((2, 2)))
    check("empty-state-no-production", zero["rate"] + zero["total"])
    extra = np.diag([0.3, -0.1])
    added = population_balance(hamiltonian, derivative, coherent, extra_source=extra)
    check("explicit-source-not-lost", added["rate"] - balance["rate"] - 0.3)
    expect_error("threshold-crossing-rejected", lambda: spectral_data(np.diag([-1.0, 0.0])))
    expect_error("nonhermitian-rejected", lambda: spectral_data(np.array([[-1.0, 1.0], [0.0, 1.0]])))
    expect_error("negative-occupation-rejected", lambda: population_balance(hamiltonian, derivative, np.diag([-0.1, 1.1])))
    for sign in (-1, 1):
        data = spectral_data(sign * np.diag([1.0, 2.0]), derivative)
        check("constant-rank-edge-" + str(sign), np.linalg.norm(data["projector_rate"]))
    return dict(coherent_rate=balance["rate"], dephased_rate=diagonal["rate"],
                sharp_bound=balance["geometric_rate_bound"], static_population=0.5)


def inherited_seed():
    folder = POST / "mts-covariance-dynamics-20261107"
    seed = read(folder / "seed-result.json")
    gauge = read(folder / "gauge-result.json")
    closeout = read(folder / "closeout.json")
    paths = {}
    for report in (seed, gauge):
        for path, expected in report["source_hashes"].items():
            if digest(path) != expected:
                raise ValueError("changed inherited source: " + path)
            paths[path] = expected
    check("seed-csv-hash", int(digest(folder / "primordial-seed.csv") != seed["seed_sha256"]))
    check("gauge-csv-hash", int(digest(folder / "gauge-seed.csv") != gauge["output_sha256"]))
    check("old-validation-hash", int(digest(folder / closeout["validation"]["path"]) != closeout["validation"]["sha256"]))
    check("old-replay-hash", int(digest(folder / closeout["physical_replay"]["path"]) != closeout["physical_replay"]["sha256"]))
    with (folder / "primordial-seed.csv").open() as stream:
        rows = list(csv.DictReader(stream))
    check("saved-row-count", len(rows) - 1197)
    check("retained-primordial-amplitude", seed["primordial"]["AS"] / 2.1e-9 - 1)
    check("retained-primordial-tilt", seed["primordial"]["NS"] - 0.9653)
    epochs = []
    for epoch in sorted({float(row["nominal_a"]) for row in rows}):
        group = [row for row in rows if float(row["nominal_a"]) == epoch]
        check("retained-modes-" + str(epoch), len(group) - 399)
        epochs.append(dict(scale_factor=epoch, modes=len(group),
                           k_min=min(float(row["k_Mpc_inverse"]) for row in group),
                           k_max=max(float(row["k_Mpc_inverse"]) for row in group)))
    inverse_mpc = seed["mass_inverse_Mpc"]
    mass_energy = inverse_mpc * constants.hbar * constants.c / (constants.parsec * 1e6 * constants.electron_volt)
    mass = mass_energy * constants.electron_volt / constants.c**2
    kappa = constants.hbar / mass / (constants.parsec * 1e3 * 1e3)
    check("retained-heavy-mass-conversion", mass_energy / 9.585761787277403e-25 - 1)
    check("retained-kappa-conversion", kappa / 2000.0 - 1)
    for filename in ("seed-result.json", "gauge-result.json", "primordial-seed.csv", "gauge-seed.csv",
                     "closeout.json", closeout["validation"]["path"], closeout["physical_replay"]["path"]):
        path = folder / filename
        paths[str(path)] = digest(path)
    return dict(source_hashes=paths, epochs=epochs, mass_energy_eV=mass_energy,
                kappa_kpc_km_s=kappa, primordial=seed["primordial"], finite_band_only=True,
                no_realization_generated=True, no_galaxy_occupation_assigned=True,
                gauge_interface=gauge["scope"], unresolved_old_derivative_check=closeout["direct_derivative_check"])


def main():
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([4])
    guard()
    start = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(),
                 started=datetime.now(timezone.utc).isoformat(), affinity=process.cpu_affinity(),
                 priority=process.nice(), thread_environment={name: os.environ[name] for name in
                 ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS")})
    write(STAGE / "worker-start.json", start)
    try:
        sources = {str(path): digest(path) for path in STAGE.iterdir() if path.suffix in (".py", ".md", ".ps1")}
        owned = [POST / name for name in (
            "MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md",
            "MTS-COVARIANCE-TO-GRAVITATING-STATE.md", "MTS-RETAINED-HIERARCHY-AND-RETARDED-COUPLING.md",
            "MTS-DWARF-FORCE-TO-EXPANSION-JERK.md", "mts-independent-poisson-evolution-20261107/DERIVATION.md",
            "condensate-origin-20261003/motion-bath-matching-20261006/49-real-motion-envelope-and-existing-bath-matching.md",
            "condensate-origin-20261003/heavy-interaction-and-condensate-bridge-20261007/52-heavy-mode-interactions-and-condensate-coherence.md",
            "condensate-origin-20261003/radiation-and-slow-field-transfer-20261007/radiation_common.py",
            "condensate-origin-20261003/native-heavy-matching-20261007/55-native-heavy-matching-and-late-matter.md",
            "5152-Y5-R2FR-primordial-motion-occupation-dust-limit-Jeans-window-and-formation-source-arbitration.md",
            "mts-full-cell-flow-completion-20261110/closeout.json",
        )]
        inputs = {str(path): digest(path) for path in owned}
        write(STAGE / "frozen-inputs.json", dict(sources=sources, inputs=inputs,
              gates=[ALGEBRA_GATE, NUMERICAL_GATE], numerical_seed=20261110,
              imported_method_sources=["https://arxiv.org/abs/1712.00445",
                                      "https://arxiv.org/abs/2005.11359",
                                      "https://arxiv.org/abs/1610.08297"]))
        special = special_checks()
        random = random_checks()
        rotating = [rotating_well(duration) for duration in (0.5, 4.0)]
        check("same-final-H-different-history",
              np.linalg.norm(np.array(rotating[0]["final_hamiltonian"]) - np.array(rotating[1]["final_hamiltonian"])))
        boundary = boundary_checks()
        seed = inherited_seed()
        for path, expected in {**sources, **inputs, **seed["source_hashes"]}.items():
            if digest(path) != expected:
                raise ValueError("source changed during checks: " + path)
        result = dict(passed=True, completed=datetime.now(timezone.utc).isoformat(),
                      checks=CHECKS, random_projectors=random, rotating_control=rotating,
                      boundary_controls=boundary, special_controls=special, inherited_seed=seed,
                      sources=sources, inputs=inputs, no_fits=True, no_galaxy_predictions=True,
                      no_parent_action_change=True, finite_dimensional_controls=True)
        write(STAGE / "result.json", result)
        write(STAGE / "worker-end.json", dict(**start, finished=datetime.now(timezone.utc).isoformat(),
              state="completed", result_sha256=digest(STAGE / "result.json")))
        print(json.dumps(dict(checks=len(CHECKS), passed=True, rotating=[row["numerical_probability"] for row in rotating],
                              mass_energy_eV=seed["mass_energy_eV"], kappa=seed["kappa_kpc_km_s"])))
    except Exception as error:
        write(STAGE / "worker-end.json", dict(**start, finished=datetime.now(timezone.utc).isoformat(),
                                             state="failed", error=repr(error), checks=CHECKS))
        raise


if __name__ == "__main__":
    main()
