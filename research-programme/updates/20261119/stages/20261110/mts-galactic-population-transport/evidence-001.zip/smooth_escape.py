import numpy as np
from scipy.linalg import eigh
from population_transport import hermitian, covariance


def smooth_escape_readout(hamiltonian, derivative, occupation, width, threshold=0.0, threshold_rate=0.0):
    matrix = np.asarray(hamiltonian, dtype=complex)
    derivative = np.asarray(derivative, dtype=complex)
    occupation = covariance(occupation)
    if matrix.shape != occupation.shape or derivative.shape != matrix.shape:
        raise ValueError("matching square operator shapes required")
    if not np.isfinite([width, threshold, threshold_rate]).all() or width <= 0:
        raise ValueError("finite positive energy resolution required")
    if not np.isfinite(matrix).all() or not np.isfinite(derivative).all():
        raise ValueError("finite operators required")
    shifted = matrix - threshold * np.eye(len(matrix))
    scale = max(float(np.max(abs(shifted))), width)
    normalized = hermitian(shifted / scale, "scaled Hamiltonian")
    variation = hermitian((derivative - threshold_rate * np.eye(len(matrix))) / scale, "scaled derivative")
    energies, vectors = eigh(normalized)
    resolution = width / scale
    arguments = energies / resolution
    weights = 0.5 - np.arctan(arguments) / np.pi
    divided = np.empty((len(energies), len(energies)))
    for row in range(len(energies)):
        for column in range(len(energies)):
            difference = energies[row] - energies[column]
            if difference == 0:
                divided[row, column] = -1 / (np.pi * resolution * (1 + arguments[row]**2))
            else:
                angle_difference = np.arctan2(difference / resolution,
                                              1 + arguments[row] * arguments[column])
                divided[row, column] = -angle_difference / (np.pi * difference)
    if not np.isfinite(divided).all():
        raise ValueError("energy resolution outside representable range")
    window = (vectors * weights) @ vectors.conj().T
    derivative_basis = vectors.conj().T @ variation @ vectors
    window_rate = vectors @ (divided * derivative_basis) @ vectors.conj().T
    total = float(np.trace(occupation).real)
    count = float(np.trace(window @ occupation).real)
    rate = float(np.trace(window_rate @ occupation).real)
    operator_bound = float(np.linalg.norm(variation, 2) / (np.pi * resolution))
    return dict(window=window, window_rate=window_rate, total=total, count=count, rate=rate,
                operator_bound=operator_bound, count_rate_bound=total * operator_bound)
