import numpy as np
from scipy.linalg import eigh

ALGEBRA_GATE = 1e-10
NUMERICAL_GATE = 2e-5


def hermitian(matrix, name):
    matrix = np.asarray(matrix, dtype=complex)
    if matrix.ndim != 2 or matrix.shape[0] != matrix.shape[1] or not np.isfinite(matrix).all():
        raise ValueError(name + " must be a finite square matrix")
    scale = max(float(np.linalg.norm(matrix)), 1.0)
    if np.linalg.norm(matrix - matrix.conj().T) > ALGEBRA_GATE * scale:
        raise ValueError(name + " must be Hermitian")
    return matrix


def covariance(matrix):
    matrix = hermitian(matrix, "occupation")
    if np.linalg.eigvalsh(matrix).min() < -ALGEBRA_GATE * max(float(np.linalg.norm(matrix)), 1.0):
        raise ValueError("negative occupation")
    return matrix


def spectral_data(hamiltonian, derivative=None, threshold=0.0, threshold_guard=1e-12):
    hamiltonian = hermitian(hamiltonian, "Hamiltonian")
    energies, vectors = eigh(hamiltonian)
    if not np.isfinite(threshold) or not np.isfinite(threshold_guard) or threshold_guard <= 0:
        raise ValueError("finite threshold and positive numerical guard required")
    if np.min(abs(energies - threshold)) <= threshold_guard:
        raise ValueError("threshold crossing: no smooth fixed-rank projector")
    selected = energies < threshold
    bound_vectors = vectors[:, selected]
    unbound_vectors = vectors[:, ~selected]
    projector = bound_vectors @ bound_vectors.conj().T
    projector_rate = np.zeros_like(hamiltonian)
    rank = int(selected.sum())
    gap = None
    rotation = 0.0
    derivative_bound = 0.0
    if derivative is not None:
        derivative = hermitian(derivative, "Hamiltonian derivative")
        if derivative.shape != hamiltonian.shape:
            raise ValueError("Hamiltonian derivative shape mismatch")
    if 0 < rank < len(energies):
        gap = float(energies[~selected].min() - energies[selected].max())
        if derivative is not None:
            cross = unbound_vectors.conj().T @ derivative @ bound_vectors
            denominator = energies[selected][None, :] - energies[~selected][:, None]
            block = unbound_vectors @ (cross / denominator) @ bound_vectors.conj().T
            projector_rate = block + block.conj().T
            rotation = float(np.linalg.norm(cross / denominator, 2))
            derivative_bound = float(np.linalg.norm(cross, 2) / gap)
    return dict(projector=projector, projector_rate=projector_rate, rank=rank,
                gap=gap, rotation_rate=rotation, derivative_bound=derivative_bound)


def population_balance(hamiltonian, derivative, occupation, hbar=1.0, extra_source=None):
    occupation = covariance(occupation)
    hamiltonian = hermitian(hamiltonian, "Hamiltonian")
    if occupation.shape != hamiltonian.shape or not np.isfinite(hbar) or hbar <= 0:
        raise ValueError("shape or hbar mismatch")
    data = spectral_data(hamiltonian, derivative)
    projector = data["projector"]
    total = float(np.trace(occupation).real)
    bound = float(np.trace(projector @ occupation).real)
    unbound = float(np.trace((np.eye(len(projector)) - projector) @ occupation).real)
    evolution = -1j * (hamiltonian @ occupation - occupation @ hamiltonian) / hbar
    source_rate = 0.0
    if extra_source is not None:
        extra_source = hermitian(extra_source, "extra source")
        if extra_source.shape != occupation.shape:
            raise ValueError("source shape mismatch")
        evolution = evolution + extra_source
        source_rate = float(np.trace(projector @ extra_source).real)
    geometric = float(np.trace(data["projector_rate"] @ occupation).real)
    direct = float(np.trace(data["projector_rate"] @ occupation + projector @ evolution).real)
    bound_rate = 2 * data["rotation_rate"] * np.sqrt(max(bound, 0.0) * max(unbound, 0.0))
    return dict(total=total, bound=bound, unbound=unbound, rate=direct,
                geometric_rate=geometric, extra_source_rate=source_rate,
                geometric_rate_bound=float(bound_rate), rotation_rate=data["rotation_rate"],
                spectral_derivative_bound=data["derivative_bound"], gap=data["gap"])


def transported_bound_population(initial_occupation, propagator, final_projector):
    initial_occupation = covariance(initial_occupation)
    propagator = np.asarray(propagator, dtype=complex)
    final_projector = hermitian(final_projector, "final projector")
    shape = initial_occupation.shape
    if propagator.shape != shape or final_projector.shape != shape or not np.isfinite(propagator).all():
        raise ValueError("transport shape mismatch")
    identity = np.eye(shape[0])
    if np.linalg.norm(propagator.conj().T @ propagator - identity) > NUMERICAL_GATE:
        raise ValueError("propagator is not unitary within the retained gate")
    if np.linalg.norm(final_projector @ final_projector - final_projector) > ALGEBRA_GATE:
        raise ValueError("final projector is not idempotent")
    capture_operator = propagator.conj().T @ final_projector @ propagator
    return float(np.trace(capture_operator @ initial_occupation).real)


def retained_number_flux(envelopes, derivatives, hbar, mass, scale_factor=1.0):
    envelopes = np.asarray(envelopes, dtype=complex)
    derivatives = np.asarray(derivatives, dtype=complex)
    if envelopes.shape != derivatives.shape or envelopes.ndim != 2:
        raise ValueError("factors and one-direction derivatives need shape (factors, points)")
    if not np.isfinite(envelopes).all() or not np.isfinite(derivatives).all():
        raise ValueError("finite factors required")
    if min(hbar, mass, scale_factor) <= 0 or not np.isfinite([hbar, mass, scale_factor]).all():
        raise ValueError("positive finite physical constants required")
    density = np.sum(abs(envelopes)**2, axis=0)
    current = hbar / (mass * scale_factor**2) * np.sum((envelopes.conj() * derivatives).imag, axis=0)
    return density, current
