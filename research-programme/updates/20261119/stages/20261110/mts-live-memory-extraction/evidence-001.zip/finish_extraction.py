import argparse
from extraction_support import *
from run_extraction import physical_sources


def collect():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    contract=read(ROOT/'contract.json')
    weights=packet(PROJECTION/'frozen-projection.npz')['weights']
    require(len(weights)==902,'original signed extraction weights')
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    numerical={}
    candidates={}
    results={}
    input_hashes={str(Path(__file__)):digest(Path(__file__))}
    for case in ('cold','heavy'):
        require(read(ROOT/(case+'-preflight.json'))['passed'],'paired full-window preflight')
        lock=read(ROOT/(case+'-seed-lock.json'))
        capture=packet(ROOT/(case+'-capture.npz'))
        source=packet(TRANSFER/(case+'-transfer-source-readout.npz'))
        require(np.array_equal(source['clock'],capture['clock']),'same canonical source clock')
        active=read(ROOT/(case+'-preflight-native-status.json'))['active']
        dimension=lock['dimension']
        reference_sources=np.array([physical_sources(case,{key:source[key][index] for key in ('extra','observation','vector','jets')},lock['first'],density0) for index in range(902)])
        projected_reference=weights@reference_sources
        streams={}
        for config in contract['configs']:
            stream=case+'-'+config['name']
            portions=[]
            previous=None
            restart_checks={}
            for first in (0,256,512,768):
                last=min(first+256,901)
                label=case+'-batch-'+config['name']+'-'+str(first).zfill(4)+'-'+str(last).zfill(4)
                end=read(ROOT/(label+'-end.json'))
                require(end['state']=='completed' and exited(end)['exited'],'completed exited batch')
                require(read(ROOT/(label+'-native-release.json'))['released'],'native batch owner released')
                report=read(ROOT/(label+'-result.json'))
                path=ROOT/(label+'.npz')
                require(report['completed'] and report['first']==first and report['last']==last and digest(path)==report['packet_sha256'],'verified ordered packet')
                data=packet(path)
                require(np.array_equal(data['clock'],capture['clock'][first:last+1]),'original node coverage')
                require(all(np.all(np.isfinite(value)) for value in data.values()),'finite packet')
                if previous is not None:
                    require(report['previous_packet_sha256']==previous['sha256'],'linked restart hash')
                    require(np.array_equal(data['normalized_state'][0],previous['data']['normalized_state'][-1]),'bit-identical normalized restart')
                    require(np.array_equal(data['normalization'],previous['data']['normalization']),'fixed initial normalization across restarts')
                    for key in ('candidate','physical_sources','observation','actual_physical_derivative'):
                        restart_checks[str(first)+'/'+key]=comparison(data[key][0],previous['data'][key][-1],ALGEBRA)
                previous=dict(data=data,sha256=digest(path))
                portions.append(data)
                input_hashes[str(path)]=digest(path)
            common=('clock','normalized_state','state','candidate','phase','vector','observation','derivative','actual_physical_derivative','predicted_rate','exact_candidate_rate','physical_sources','uncorrected_sources','cache','extra','jets')
            merged={key:np.concatenate([data[key] if index==0 else data[key][1:] for index,data in enumerate(portions)],axis=0) for key in common}
            require(np.array_equal(merged['clock'],capture['clock']) and len(merged['clock'])==902,'exact complete unique original coverage')
            require(np.array_equal(merged['candidate'],merged['state'][:,:dimension]+merged['state'][:,dimension:]),'predictive candidate only')
            require(np.array_equal(merged['state'][0,dimension:],np.zeros(dimension)),'zero initial correction')
            if case=='cold':
                require(np.array_equal(merged['state'][:,dimension:],np.zeros_like(merged['state'][:,dimension:])),'actual baseline remains unmodified')
            reconstructed_sources=np.array([physical_sources(case,{key:merged[key][index] for key in ('extra','observation','vector','jets')},lock['first'],density0) for index in range(902)])
            numerical[stream+'/readout']=columns(merged['physical_sources'],reconstructed_sources,'source_',ALGEBRA)
            numerical[stream+'/restart']=restart_checks
            chosen=np.flatnonzero(capture['cache_mask'][0])
            numerical[stream+'/cache']=columns(merged['cache'][:,chosen],capture['cache_reference'][:,chosen],'entry_',ALGEBRA)
            candidates[stream+'/state']=columns(merged['vector'][:,:active],capture['reference'][:,:active],'component_')
            candidates[stream+'/source']=columns(merged['observation'],capture['observation_reference'],'component_')
            candidates[stream+'/actual_evolution']=columns(merged['actual_physical_derivative'][:,:active],capture['derivative_reference'][:,:active],'component_')
            candidates[stream+'/equation_residual']=columns(merged['predicted_rate'],merged['exact_candidate_rate'],'component_')
            candidates[stream+'/physical']=columns(merged['physical_sources'],reference_sources,'source_')
            projected=weights@merged['physical_sources']
            candidates[stream+'/projection']=columns(projected[None,:],projected_reference[None,:],'source_')
            results[stream]=dict(reference=projected_reference,prediction=projected,uncorrected=weights@merged['uncorrected_sources'],projection_checks=candidates[stream+'/projection'],maximum_rest_correction=float(np.max(abs(merged['state'][:,dimension:dimension+lock['offset']]))),worst={key:max((row['normalized'] for row in candidates[stream+'/'+key].values() if row['normalized'] is not None),default=0.) for key in ('state','source','actual_evolution','equation_residual','physical')})
            path=ROOT/(stream+'-merged.npz')
            require(not path.exists(),'never overwrite merged results')
            np.savez_compressed(path,**merged)
            results[stream]['packet_sha256']=digest(path)
            streams[config['name']]=merged
        for left,right in (('step128-h1','step256-h1'),('step256-h1','step256-h2')):
            for key in ('vector','observation','actual_physical_derivative','physical_sources'):
                width=active if key in ('vector','actual_physical_derivative') else streams[right][key].shape[1]
                numerical[case+'/'+left+'/'+right+'/'+key]=columns(streams[left][key][:,:width],streams[right][key][:,:width],'component_')
            numerical[case+'/'+left+'/'+right+'/projection']=columns((weights@streams[left]['physical_sources'])[None,:],(weights@streams[right]['physical_sources'])[None,:],'source_')
    check_hashes(input_hashes)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('validation.json',dict(completed=True,numerical_checks_passed=all_pass(numerical),candidate_checks_passed=all_pass(candidates),numerical=numerical,candidates=candidates,numerical_count=sum(len(group) for group in numerical.values()),candidate_count=sum(len(group) for group in candidates.values()),results=results,current_rest_feedback=True,original_signed_weights=True,old_late_selector_replaced=False,input_hashes=input_hashes))
    summary={name:dict(reference=result['reference'],prediction=result['prediction'],uncorrected=result['uncorrected'],worst=result['worst']) for name,result in results.items()}
    print(json.dumps(dict(numerical=all_pass(numerical),candidate=all_pass(candidates),numerical_checks=sum(len(group) for group in numerical.values()),candidate_checks=sum(len(group) for group in candidates.values()),results=summary),default=convert),flush=True)


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    validation=read(ROOT/'validation.json')
    require(validation['completed'] and validation['numerical_checks_passed'],'complete numerically verified live extraction')
    check_hashes(validation['input_hashes'])
    require((ROOT/'RESULTS.md').is_file() and (ROOT/'NEXT.md').is_file(),'saved result and next task')
    excluded={'closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json'}
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write('closeout.json',dict(live_extraction_completed=True,candidate_checks_passed=validation['candidate_checks_passed'],current_rest_feedback=True,saved_future_rest_input=False,original_signed_weights=True,retained_background=True,old_late_selector_replaced=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        label=path.name.removesuffix('-start.json')
        if label=='postseal':
            continue
        owner=read(path)
        ending=read(ROOT/(label+'-end.json'))
        outcome=exited(owner)
        require(outcome['exited'] and ending['state']=='completed','task worker completed and exited')
        require(all(ending[key]==owner[key] for key in ('pid','created','command')),'matching worker receipts')
        release=ROOT/(label+'-native-release.json')
        if release.exists():
            require(read(release)['released'],'native owner released')
        workers.append(dict(name=label,identity=owner,outcome=outcome))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('collect','seal','postseal'))
    arguments=parser.parse_args()
    with worker(arguments.operation) as identity:
        if arguments.operation=='postseal':
            postseal(identity)
        else:
            globals()[arguments.operation]()
