import sys
from pathlib import Path
from time import monotonic

LIVE_MEMORY=Path(__file__).resolve().parent.parent/'mts-live-carrier-memory-20261110'
sys.path.insert(0,str(LIVE_MEMORY))
import live_memory_support as owner
import live_memory_model as retained_model
from live_memory_support import *
from checked_live_memory_model import CheckedLiveMemory

ROOT=Path(__file__).resolve().parent
LIVE_MEMORY=ROOT.parent/'mts-live-carrier-memory-20261110'
EXPECTED_LIVE_MEMORY='d95943ea2b43737d5c55d449bc8cf3c5d34c6be34d8c410b7f87da4d2cbc7a35'
owner.shared.ROOT=ROOT
owner.shared.START=monotonic()
inherited_guard=owner.guard
last_owner_check=[-float('inf')]


def guard():
    inherited_guard()
    current=monotonic()
    if current-last_owner_check[0]>=1:
        require(not (LIVE_MEMORY/'STOP-REQUESTED').exists(),'owner hold '+str(LIVE_MEMORY))
        last_owner_check[0]=current


retained_model.guard=guard


class ExtractionMemory(CheckedLiveMemory):
    def __init__(self,*arguments,steps,**keywords):
        super().__init__(*arguments,**keywords)
        self.steps=steps

    def stencil(self,time,divisor):
        step=float(self.steps[str(divisor)])
        if time-2*step<self.lower:
            offsets=np.array([0.,1.,2.,3.,4.])
            weights=np.array([-25.,48.,-36.,16.,-3.])/12
        elif time+2*step>self.upper:
            offsets=np.array([-4.,-3.,-2.,-1.,0.])
            weights=np.array([3.,-16.,36.,-48.,25.])/12
        else:
            offsets=np.array([-2.,-1.,0.,1.,2.])
            weights=np.array([1.,-8.,0.,8.,-1.])/12
        require(np.min(time+step*offsets)>=self.lower and np.max(time+step*offsets)<=self.upper,'native derivative within original extraction')
        return step,offsets,weights
