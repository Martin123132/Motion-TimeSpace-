from extraction_support import *


with worker('freeze'):
    require(digest(LIVE_MEMORY/'closeout.json')==EXPECTED_LIVE_MEMORY,'retained live-memory result')
    sealed=read(LIVE_MEMORY/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(LIVE_MEMORY/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    cleanup=read(LIVE_MEMORY/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and not cleanup['verifier_exit_requires_final_external_check'] and exited(cleanup['verifier_identity'])['exited'],'previous worker closed')
    sources=dict(sealed['input_hashes'])
    paths=[LIVE_MEMORY/'closeout.json',LIVE_MEMORY/'CLEANUP-VERIFIED.json',LIVE_MEMORY/'checked_live_memory_model.py',LIVE_MEMORY/'live_memory_model.py',LIVE_MEMORY/'live_memory_support.py',LIVE_MEMORY/'next-window-inputs.json',ROOT/'PROTOCOL.md']
    steps={}
    integration_steps={}
    for case in ('cold','heavy'):
        short_path=LIVE/(case+'-live-capture.npz')
        short=packet(short_path)['clock']
        span=float(short[-1]-short[0])
        steps[case]={str(divisor):span/divisor for divisor in (768,1024,4096,8192)}
        integration_steps[case]={str(divisor):span/divisor for divisor in (128,256)}
        capture_path=TRANSFER/(case+'-transfer-capture.npz')
        capture=packet(capture_path)
        full=packet(HANDOFF/('early-'+case+'-restart.npz'))
        require(len(capture['clock'])==902 and np.array_equal(capture['clock'],full['full_clock'][1991:2893]),'original extraction grid')
        require(len(np.unique(capture['signature'],axis=0))==1,'retained fixed native regime')
        paths.extend([short_path,capture_path,TRANSFER/(case+'-transfer-source-readout.npz')])
    paths.extend(sorted(ROOT.glob('*.py')))
    sources.update({str(path):digest(path) for path in paths})
    check_hashes(sources)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write('frozen-inputs.json',sources)
    write('contract.json',dict(previous_turn='progress',windows={'matching':[1991,2892]},cases=['cold','heavy'],configs=[dict(name='step128-h1',steps=128,derivative_divisor=4096,checker_divisor=768),dict(name='step256-h1',steps=256,derivative_divisor=4096,checker_divisor=768),dict(name='step256-h2',steps=256,derivative_divisor=8192,checker_divisor=1024)],absolute_metric_steps=steps,absolute_maximum_steps=integration_steps,integration=dict(method='DOP853',rtol=1e-10,atol=1e-12),gate=GATE,algebra=ALGEBRA,batch_intervals=256,node_count=902,current_rest_feedback=True,physical_grid_bank_parameters_and_weights_unchanged=True,new_averaged_background=False,goal_complete=False))
    print(json.dumps(dict(frozen=True,inputs=len(sources),metric_steps=steps,maximum_steps=integration_steps)),flush=True)
