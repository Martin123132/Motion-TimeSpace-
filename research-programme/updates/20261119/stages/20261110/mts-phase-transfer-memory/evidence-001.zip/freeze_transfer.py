from transfer_support import *


def main():
    with worker('freeze-transfer'):
        require(digest(PREVIOUS/'closeout.json')==EXPECTED,'latest coupled stage seal')
        seal=read(PREVIOUS/'closeout.json')
        require(seal['paired_live_phase_stress_passed'] and not seal['early_to_late_transfer_complete'],'distinct prior scientific state')
        mapping=dict(seal['input_hashes'])
        mapping.update({str(PREVIOUS/name):row['sha256'] for name,row in seal['artifacts'].items()})
        mapping[str(PREVIOUS/'closeout.json')]=EXPECTED
        check_hashes(mapping)
        cleanup=read(PREVIOUS/'CLEANUP-VERIFIED.json')
        require(cleanup['passed'] and exited(cleanup['verifier_identity'])['exited'],'previous verifier exited')
        require(all(exited(row['identity'])['exited'] for row in cleanup['workers']+cleanup['compiler_children']),'previous workers/helpers exited')
        with np.load(PROJECTION/'frozen-projection.npz',allow_pickle=False) as packet:
            selected=packet['selected']
            require(len(selected)==902 and np.all(np.diff(selected)==1),'original signed temporal support')
            report=dict(previous_goal_turn='verified progress: actual coupled phase stress, not merely a plan',windows=dict(matching=[int(selected[0]),int(selected[-1])]),selected_count=len(selected),weight_sum=float(packet['weights'].sum()),weight_absolute_sum=float(abs(packet['weights']).sum()),original_projection_sha256=digest(PROJECTION/'frozen-projection.npz'),gate=GATE,algebra=ALGEBRA,orders=[4,8],history_strides=[1,2],endpoint='rightmost saved support, not a redefinition of the historical center',derived_identity='S*Y_right = projection(Y) + sum_j cumulative_weight_j * integral_j(source_rhs)',all_physical_inputs_unchanged=True,coarse_grained_late_population_derived=False)
        write('contract.json',report)
        write('frozen-inputs.json',mapping)
        print(json.dumps(report),flush=True)


if __name__=='__main__':
    main()
