from transfer_support import *
import sympy as sp


def prove():
    identities={}
    for size in (2,3,5,7):
        weights=sp.symbols('weight0:'+str(size))
        values=sp.symbols('value0:'+str(size))
        projected=sum(weight*value for weight,value in zip(weights,values))
        memory=sum(sum(weights[:index+1])*(values[index+1]-values[index]) for index in range(size-1))
        identities['endpoint_stencil_'+str(size)]=sp.expand(projected+memory-sum(weights)*values[-1])==0
    field,velocity,mode,mode_velocity,mass2,rate,hubble,dilation,wave=sp.symbols('b v u w mu2 rate H z k',nonzero=True)
    field_first,velocity_first=sp.symbols('b_N v_N')
    density=velocity*mode_velocity+mass2*field*mode
    pressure=velocity*mode_velocity-mass2*field*mode
    current=wave*velocity*mode
    mode_velocity_first=-2*hubble*mode_velocity-(wave**2+mass2)*mode-wave*dilation*velocity
    density_first=rate*velocity_first*mode_velocity+velocity*mode_velocity_first+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_velocity
    current_first=wave*(rate*velocity_first*mode+velocity*mode_velocity)
    field_defect=rate*field_first-velocity
    velocity_defect=rate*velocity_first+2*hubble*velocity+mass2*field
    density_expected=(rate-hubble)*density-3*hubble*pressure-wave*current-wave*dilation*velocity**2+velocity_defect*mode_velocity+mass2*field_defect*mode+2*(rate-hubble)*mass2*field*mode
    current_expected=(rate-2*hubble)*current+wave*pressure+wave*velocity_defect*mode
    identities['scaled_density_equation']=sp.expand(rate*density+density_first-density_expected)==0
    identities['scaled_current_equation']=sp.expand(rate*current+current_first-current_expected)==0
    rest,second_density=sp.symbols('z_rest D_second')
    live_dilation=rest+(density+second_density)/(2*wave*hubble)
    exact=mode_velocity_first.subs(dilation,live_dilation)
    eliminated=-(wave**2+mass2)*mode-2*hubble*mode_velocity-velocity*(density+second_density)/(2*hubble)-wave*velocity*rest
    identities['self_gravity_elimination']=sp.simplify(exact-eliminated)==0
    return identities


def main():
    with worker('analyze-transfer'):
        identities=prove()
        require(all(identities.values()),'exact finite-support and action-source identities')
        reports={}
        for case in ('cold','heavy'):
            label=case+'-transfer'
            report=read(ROOT/(label+'-transfer-result.json'))
            with np.load(ROOT/(label+'-source-readout.npz'),allow_pickle=False) as data:
                source={name:data[name].copy() for name in data.files}
            weights=source['weights']
            cumulative=source['cumulative']
            names=[str(value) for value in source['names']]
            fields=2 if case=='heavy' else 1
            predicted={}
            comparisons={}
            terms={}
            for variant,metadata in report['variants'].items():
                path=ROOT/(label+'-'+variant+'.npz')
                require(digest(path)==metadata['packet_sha256'],'frozen source integrals')
                with np.load(path,allow_pickle=False) as data:
                    memory=cumulative@data['increments']
                    prediction=(source['projected']+memory)/weights.sum()
                    require(np.array_equal(prediction,data['prediction']),'exact memory reconstruction')
                    terms[variant]=cumulative@data['integrals']
                predicted[variant]=prediction
                comparisons[variant]={name:comparison(prediction[index],source['endpoint'][index]) for index,name in enumerate(names)}
            comparisons['quadrature']={name:comparison(predicted['stride1-order4'][index],predicted['stride1-order8'][index]) for index,name in enumerate(names)}
            comparisons['history']={name:comparison(predicted['stride2-order8'][index],predicted['stride1-order8'][index]) for index,name in enumerate(names)}
            require(all(row['passed'] for group in comparisons.values() for row in group.values()),'unchanged endpoint/refinement gates')
            selected=predicted['stride1-order8']
            with np.load(PROJECTION/'frozen-projection.npz',allow_pickle=False) as frozen:
                beta=source['extra'][-1,0]/float(frozen['density0'])
                norm=float(frozen['original_norm'])
            hubble=source['extra'][-1,2]
            potential=source['observation'][-1,7]-hubble*source['observation'][-1,5]
            metric={}
            ablation={}
            for sector in (['s','h','cdm'] if case=='heavy' else ['s','cdm']):
                density_index=names.index(sector+'_D')
                current_index=names.index(sector+'_Q') if sector!='cdm' else None
                sector_rows={}
                for variant,values in [('without_memory',source['projected']/weights.sum()),('with_memory',selected)]:
                    density_change=(values[density_index]-source['endpoint'][density_index])/beta
                    current_change=0. if current_index is None else (values[current_index]-source['endpoint'][current_index])/beta
                    phi_change=-(density_change+3*hubble*current_change)/2
                    sector_rows[variant]=dict(density_change=float(density_change),current_change=float(current_change),z_change=float(density_change/(2*hubble)),eta_prime_change=float(current_change/2),potential_change=float(phi_change),potential_relative=float(abs(phi_change/potential)))
                metric[sector]=sector_rows
                if sector!='cdm':
                    component=0 if sector=='s' else 1
                    offset=11*component
                    for name,position in [('pressure_work',offset+1),('metric_work',offset+2),('current_transport',offset)]:
                        ablated=selected[density_index]-terms['stride1-order8'][position]/weights.sum()
                        ablation[sector+'_'+name]=comparison(ablated,source['endpoint'][density_index])
            memory_ledger={}
            density_names=['current_transport','pressure_work','metric_work','clock_rescaling','velocity_defect','field_defect','mass_clock_defect']
            current_names=['dilution','pressure_flux','velocity_defect']
            for component,sector in enumerate(['s','h'] if fields==2 else ['s']):
                offset=11*component
                memory_ledger[sector]=dict(density=dict(zip(density_names,terms['stride1-order8'][offset:offset+7].tolist())),current=dict(zip(current_names,terms['stride1-order8'][offset+7:offset+10].tolist())),pressure=float(terms['stride1-order8'][offset+10]))
            memory_ledger['cdm']=dict(density_metric_work=float(terms['stride1-order8'][-1]))
            reports[case]=dict(passed=True,comparisons=comparisons,metric=metric,ablation=ablation,memory_ledger=memory_ledger,legacy_norm=norm,endpoint_scale=float(source['extra'][-1,0]),endpoint_hubble=float(hubble),endpoint_potential=float(potential),source_names=names,projected=source['projected'].tolist(),endpoint=source['endpoint'].tolist(),predicted_endpoint=selected.tolist())
            print(json.dumps(dict(case=case,passed=True,metric=metric,ablation=ablation)),flush=True)
        write('transfer-analysis.json',dict(passed=True,cases=reports,identities=identities,full_retarded_kernel_evaluated=False,finite_support_boundary_memory_evaluated=True,no_new_physical_closure=True))


if __name__=='__main__':
    main()
