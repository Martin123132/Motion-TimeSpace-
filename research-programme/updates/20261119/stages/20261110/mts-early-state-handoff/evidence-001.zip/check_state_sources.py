from handoff_support import *
import numpy as np
from scipy.interpolate import CubicSpline
from run_early import comparison, columns
sys.path.insert(0, str(PREVIOUS))
from quintic_model import functions as quintic_functions


def identities():
    import sympy as symbolic
    field, velocity, mass2, shift, eta, hubble, sync_u, sync_w = symbolic.symbols('field velocity mass2 shift eta hubble sync_u sync_w')
    coordinate = sync_u + velocity * shift
    momentum = sync_w - mass2 * field * shift - 3 * eta * velocity
    potential = eta - hubble * shift
    density = velocity * momentum + mass2 * field * coordinate + 3 * velocity**2 * potential
    pressure = velocity * momentum - mass2 * field * coordinate + 3 * velocity**2 * potential
    checks = dict(density_gauge=symbolic.expand(density - (velocity * sync_w + mass2 * field * sync_u - 3 * hubble * velocity**2 * shift)) == 0, pressure_gauge=symbolic.expand(pressure - (velocity * sync_w - mass2 * field * sync_u - (3 * hubble * velocity**2 + 2 * mass2 * field * velocity) * shift)) == 0, current_gauge=symbolic.expand(velocity * coordinate - (velocity * sync_u + velocity**2 * shift)) == 0)
    jacobian = symbolic.Matrix([coordinate, momentum]).jacobian([sync_u, sync_w])
    checks['coordinate_jacobian_one'] = symbolic.simplify(jacobian.det() - 1) == 0
    checks['no_velocity_division'] = all(symbolic.denom(expression) == 1 for expression in (coordinate, momentum))
    require(all(checks.values()), 'retained state/source identities')
    return checks


def reconstruct(case, packet, variant):
    names = [str(name) for name in packet['observation_names']]
    values = packet['observation_' + variant]
    observed = dict(zip(names, values.T))
    state, derivative = packet['reference' if variant == 'reference' else 'restarted'], packet['derivative_' + variant]
    scale, hubble, eta, alpha = [observed[name] for name in ('a_native', 'H_native', 'eta_sync', 'sigma')]
    phi = eta - hubble * alpha
    psi = phi - observed['Pi']
    source_checks = dict(eta_coordinate=comparison(state[:, 0], eta, ALGEBRA), cdm_coordinate=comparison(state[:, 1], observed['delta_cdm64'], ALGEBRA), momentum_constraint=comparison(derivative[:, 0], observed['Q_sync'] / 2, ALGEBRA), poisson_constraint=comparison(phi, -(observed['D_sync'] + 3 * hubble * observed['Q_sync']) / 2, ALGEBRA), weyl_constraint=comparison((phi + psi) / 2, observed['Weyl'], ALGEBRA))
    data = dict(Phi=phi, Psi=psi, eta=eta, alpha=alpha, delta_cdm_N=state[:, 1] - 3 * hubble * alpha, dstar_cdm_over_rho=state[:, 1] - 3 * eta)
    functions, masses = {}, {}
    with np.load(BACKGROUND / (case + '-candidate-background.npz'), allow_pickle=False) as table:
        functions['s'] = [CubicSpline(table['efold'], table[name], bc_type='natural') for name in ('phi_s', 'phidot_s')]
        masses['s'] = float(table['slow_mass_mpc'])
        if case == 'heavy':
            with np.load(PREVIOUS / 'heavy-equation-quintic.npz', allow_pickle=False) as clock:
                functions['h'], _ = quintic_functions(clock)
            masses['h'] = float(table['heavy_mass_mpc'])
    index = int(packet['signature'][0, 2]) - 1
    crossings = {}
    for offset, suffix in enumerate(functions):
        field, velocity = [function(np.log(scale)) for function in functions[suffix]]
        mass2 = (scale * masses[suffix])**2
        sync_u, sync_w = state[:, index + 2 * offset], state[:, index + 2 * offset + 1]
        coordinate = sync_u + velocity * alpha
        momentum = sync_w - mass2 * field * alpha - 3 * eta * velocity
        density_sync, pressure_sync, current_sync = velocity * sync_w + mass2 * field * sync_u, velocity * sync_w - mass2 * field * sync_u, velocity * sync_u
        for name, value in [('dphi', sync_u), ('dphidot', sync_w), ('drho', density_sync), ('dp', pressure_sync), ('q', current_sync)]:
            source_checks[suffix + '_native_' + name] = comparison(value, observed['mts_' + name + '_' + suffix], ALGEBRA)
        kinetic, potential_energy = velocity * momentum, mass2 * field * coordinate
        sources = dict(u=coordinate, p=momentum, D=kinetic + potential_energy + 3 * velocity**2 * phi, P=kinetic - potential_energy + 3 * velocity**2 * phi, Q=velocity * coordinate, Dstar=kinetic + potential_energy, canonical_momentum=scale**2 * momentum)
        gauge_sources = dict(D=density_sync - 3 * hubble * velocity**2 * alpha, P=pressure_sync - (3 * hubble * velocity**2 + 2 * mass2 * field * velocity) * alpha, Q=current_sync + velocity**2 * alpha)
        for name, value in gauge_sources.items():
            source_checks[suffix + '_gauge_' + name] = comparison(sources[name], value, ALGEBRA)
        data.update({suffix + '_' + name: value for name, value in sources.items()})
        crossings[suffix] = dict(field=int(np.count_nonzero(field[1:] * field[:-1] < 0)), velocity=int(np.count_nonzero(velocity[1:] * velocity[:-1] < 0)))
    require(all(np.isfinite(value).all() for value in data.values()), 'finite division-free canonical state')
    return data, source_checks, crossings


def main():
    with worker('state-sources'):
        proof = identities()
        inputs = {str(path): digest(path) for path in (Path(__file__), ROOT / 'run_early.py', ROOT / 'handoff_support.py', PREVIOUS / 'quintic_model.py')}
        reports = {}
        for prefix in ('early-', 'early-tca-'):
            for case in ('cold', 'heavy'):
                label = prefix + case
                report = read(ROOT / (label + '-result.json'))
                path = ROOT / (label + '-restart.npz')
                require(report['passed'] and digest(path) == report['packet_sha256'], 'accepted coupled restart')
                inputs[str(path)] = digest(path)
                with np.load(path, allow_pickle=False) as packet:
                    reference, source_reference, crossings = reconstruct(case, packet, 'reference')
                    restarted, source_restarted, _ = reconstruct(case, packet, 'restarted')
                    if prefix == 'early-tca-':
                        require(np.all(packet['signature'][:, 11] == 1) and np.all(packet['cache_mask'][:, :2] == 1), 'actual active tight-coupling caches')
                        require(np.max(abs(packet['cache_reference'][:, 0])) > 0 and np.max(abs(packet['cache_reference'][:, 1])) > 0, 'nonzero physical photon caches')
                    differences = {name: comparison(restarted[name], value) for name, value in reference.items()}
                    destination = ROOT / (label + '-canonical-sources.npz')
                    np.savez_compressed(destination, names=np.array(list(reference)), reference=np.column_stack(list(reference.values())), restarted=np.column_stack(list(restarted.values())), clock=packet['clock'])
                passed = all(row['passed'] for row in list(source_reference.values()) + list(source_restarted.values()) + list(differences.values()))
                reports[label] = dict(passed=passed, source_reference=source_reference, source_restarted=source_restarted, canonical_parity=differences, crossings=crossings, packet_sha256=digest(destination))
                print(json.dumps(dict(label=label, passed=passed, worst_source=max(row['normalized'] for row in list(source_reference.values()) + list(source_restarted.values()) if row['normalized'] is not None), worst_canonical=max(row['normalized'] for row in differences.values() if row['normalized'] is not None), crossings=crossings)), flush=True)
        check_hashes(inputs)
        write('state-source-result.json', dict(passed=all(report['passed'] for report in reports.values()), identities=proof, cases=reports, source_hashes=inputs, coupled_not_forced=True, portable_restart=False))


if __name__ == '__main__':
    main()
