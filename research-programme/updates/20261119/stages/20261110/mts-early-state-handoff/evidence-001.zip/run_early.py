from handoff_support import *
import argparse
import ast
import ctypes
import numpy as np


def comparison(actual, reference, tolerance=GATE):
    absolute = float(np.max(abs(actual - reference)))
    scale = float(np.max(abs(reference)))
    normalized = absolute / scale if scale else (0.0 if absolute == 0 else None)
    return dict(passed=absolute <= tolerance * scale, absolute_max=absolute, reference_peak=scale, normalized=normalized, tolerance=tolerance)


def columns(actual, reference, names, tolerance=GATE):
    return {name: comparison(actual[:, index], reference[:, index], tolerance) for index, name in enumerate(names)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    args = parser.parse_args()
    label = 'early-' + args.case
    with worker(label):
        build = read(ROOT / 'native-build-result.json')
        local = ROOT / 'native'
        require(build['state'] == 'completed' and build['temporary_mapping_removed'], 'completed isolated build')
        require(digest(local / 'camb/cambdll.dll') == build['dll_sha256'], 'instrumented binary')
        require(all(exited(row['identity'])['exited'] for row in build['children']), 'compiler children exited')
        frozen = read(ROOT / 'frozen-handoff.json')
        lower, upper = frozen['saved_indices']
        require((lower, upper) == (2591, 2890), 'unchanged bounded handoff')
        prior_label = 'native-' + args.case + ('-quintic-owned' if args.case == 'heavy' else '-quintic')
        prior_path = PREVIOUS / (prior_label + '.npz')
        require(digest(prior_path) == read(PREVIOUS / (prior_label + '-result.json'))['packet_sha256'], 'accepted previous native history')
        table_path = BACKGROUND / (args.case + '-candidate-background.npz')
        require(digest(table_path) == read(BACKGROUND / 'background-check-result.json')['cases'][args.case]['candidate_sha256'], 'unchanged background')
        clock_path = PREVIOUS / 'heavy-equation-quintic.npz'
        observer_owner = POST / 'mts-metric-feedback-20261107'
        observer_source = observer_owner / 'observe_native.py'
        observer_names = ast.literal_eval(next(node.value for node in ast.parse(observer_source.read_text()).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'NAMES' for target in node.targets)))
        require(len(observer_names) == 30 and observer_names[27:] == ['a_native', 'H_native', 'tau_native'], 'native observation ABI')
        require(digest(observer_owner / 'observer.dll') == read(observer_owner / 'compiler-shortpath-receipt.json')['dll_sha256'], 'unchanged real64 observer')
        factory_source = BRANCH / 'native-heavy-matching-20261007/matching_common.py'
        hashes = dict(build['source_hashes'])
        for path in (Path(__file__), ROOT / 'handoff_support.py', ROOT / 'EARLY-RESTART-CONTRACT.md', ROOT / 'frozen-handoff.json', prior_path, table_path, clock_path, local / 'camb/cambdll.dll', factory_source, observer_source, observer_owner / 'observer.dll'):
            hashes[str(path)] = digest(path)
        write(label + '-frozen.json', hashes)
        sys.path.insert(0, str(local))
        import camb
        from camb.mts import MTSTwoField
        require(Path(camb.__file__).resolve().parent == (local / 'camb').resolve(), 'isolated native import')
        sys.path.append(str(BRANCH / 'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        factory = next(node for node in ast.parse(factory_source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_source), 'exec'), namespace)
        params = namespace['params_for'](table_path)
        if args.case == 'heavy':
            with np.load(clock_path, allow_pickle=False) as packet:
                model = params.DarkEnergy.copy()
                model.set_table('SetHeavyClock', packet['efold'], packet['H'], packet['H_N'])
                params.DarkEnergy = model
        observer_dll = ctypes.CDLL(str(observer_owner / 'observer.dll'))
        callback = ctypes.cast(observer_dll.source_func_, ctypes.c_void_p)
        library = ctypes.CDLL(str(local / 'camb/cambdll.dll'))
        reset = library.mts_early_reset
        reset.argtypes, reset.restype = [], None
        copy = library.mts_early_copy
        copy.argtypes = [ctypes.c_int, ctypes.c_int] + [ctypes.c_void_p] * 11
        copy.restype = None
        def scalar(name):
            return ctypes.c_int.in_dll(library, 'mts_early_' + name)
        with np.load(prior_path, allow_pickle=False) as packet:
            scales = packet['requested_scale'].copy()
            prior_clock, prior_standard, prior_observer = [packet[name].copy() for name in ('clock', 'standard', 'observer')]
        native = camb.get_background(params)
        try:
            clock = np.ascontiguousarray(native.conformal_time(1 / scales - 1, tol=1e-10))
            require(np.array_equal(clock, prior_clock), 'identical native clock')
            native.Params.Accuracy.IntTolBoost = 6
            native.Params.Accuracy.lAccuracyBoost = 4
            standard_names = list(camb.model.evolve_names)
            scalar_names = [name for name in standard_names if name.startswith('mts_')][:10]
            require(len(scalar_names) == 10 and scalar_names[0] == 'mts_dphi_s', 'ten scalar diagnostic columns')
            count = len(standard_names) + len(observer_names)
            output = np.zeros((1, len(clock), count))
            reset()
            scalar('begin').value = lower + 1
            scalar('end').value = upper + 1
            wave = np.array([1.], dtype=np.float64)
            code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(1)), wave, ctypes.byref(ctypes.c_int(len(clock))), clock, ctypes.byref(ctypes.c_int(count)), output, ctypes.byref(ctypes.c_int(len(observer_names))), ctypes.byref(callback))
            metadata = {name: scalar(name).value for name in ('begin', 'end', 'count', 'nvar', 'active', 'status')}
            write(label + '-native-status.json', dict(native_error_code=int(code), **metadata))
            require(code == 0 and metadata['status'] == 2 and np.isfinite(output).all(), 'native coupled fork completed')
            require(metadata['count'] == upper - lower + 1, 'complete window coverage')
            samples, dimension = metadata['count'], metadata['nvar']
            arrays = {name: np.zeros((samples, dimension)) for name in ('reference', 'restarted', 'derivative_reference', 'derivative_restarted')}
            arrays.update({name: np.zeros((samples, 40)) for name in ('observation_reference', 'observation_restarted')})
            arrays.update({name: np.zeros((samples, 23)) for name in ('cache_reference', 'cache_restarted')})
            arrays['cache_mask'] = np.zeros((samples, 23), dtype=np.int32)
            arrays['signature'] = np.zeros((samples, 96), dtype=np.int32)
            arrays['clock'] = np.zeros(samples)
            copy(dimension, samples, *[ctypes.c_void_p(values.ctypes.data) for values in arrays.values()])
            require(scalar('status').value == 2, 'complete state export')
            require(np.array_equal(arrays['clock'], clock[lower:upper + 1]), 'restart clocks exact')
            require(all(np.isfinite(value).all() for value in arrays.values()), 'all exported diagnostics finite')
            standard, observer = output[0, :, :len(standard_names)], output[0, :, len(standard_names):]
            parity = dict(standard_exact=np.array_equal(standard, prior_standard), observer_exact=np.array_equal(observer, prior_observer), clock_exact=True)
            require(all(parity.values()), 'fork did not change uninterrupted native solution')
            initial = {name: bool(np.array_equal(arrays[name + '_reference'][0], arrays[name + '_restarted'][0])) for name in ('derivative', 'observation', 'cache')}
            initial['state'] = bool(np.array_equal(arrays['reference'][0], arrays['restarted'][0]))
            require(all(initial.values()), 'exact full-state and active-cache copy')
            require(np.all(arrays['signature'] == arrays['signature'][0]) and np.all(arrays['cache_mask'] == arrays['cache_mask'][0]), 'fixed regime and cache activity')
            active = metadata['active']
            checks = dict(state=columns(arrays['restarted'][:, :active], arrays['reference'][:, :active], ['state_' + str(index + 1) for index in range(active)]), derivative=columns(arrays['derivative_restarted'][:, :active], arrays['derivative_reference'][:, :active], ['derivative_' + str(index + 1) for index in range(active)]), observation=columns(arrays['observation_restarted'], arrays['observation_reference'], observer_names + scalar_names))
            selected = np.flatnonzero(arrays['cache_mask'][0])
            checks['cache'] = columns(arrays['cache_restarted'][:, selected], arrays['cache_reference'][:, selected], ['cache_' + str(index + 1) for index in selected])
            constraints = {}
            for variant in ('reference', 'restarted'):
                observed = dict(zip(observer_names, arrays['observation_' + variant][:, :30].T))
                algebraic_shear = (observed['D_sync'] / 2 + observed['eta_sync']) / observed['H_native'] + 1.5 * observed['Q_sync']
                constraints[variant] = dict(friedmann=comparison(3 * observed['H_native']**2, observed['R'], ALGEBRA), shear=comparison(observed['sigma'], algebraic_shear, ALGEBRA))
            destination = ROOT / (label + '-restart.npz')
            np.savez_compressed(destination, **arrays, observation_names=np.array(observer_names + scalar_names), standard=standard, observer=observer, full_clock=clock, standard_names=np.array(standard_names), requested_scale=scales, active=np.array(active))
        finally:
            reset()
            cleared = scalar('count').value == 0 and scalar('nvar').value == 0 and scalar('status').value == 0
            del native
        require(cleared, 'native capture owner detached and buffers released')
        check_hashes(hashes)
        passed = all(row['passed'] for group in checks.values() for row in group.values()) and all(row['passed'] for group in constraints.values() for row in group.values())
        failed = {group: [name for name, row in rows.items() if not row['passed']] for group, rows in checks.items()}
        worst = {group: max((row['normalized'] for row in rows.values() if row['normalized'] is not None), default=0) for group, rows in checks.items()}
        write(label + '-result.json', dict(completed=True, passed=passed, case=args.case, metadata=metadata, checks=checks, constraints=constraints, worst=worst, failed=failed, original_parity=parity, initial_copy=initial, native_buffers_released=cleared, packet_sha256=digest(destination), source_hashes=hashes, fixed_regime=True, actual_coupled_native_restart=True, portable_checkpoint=False, no_physical_reseeding=True, state_background_owner='retained live CAMBdata and thermal tables'))
        print(json.dumps(dict(case=args.case, passed=passed, worst=worst, failed=failed, active=active, allocated=dimension, tight_coupling=int(arrays['signature'][0, 11]))), flush=True)


if __name__ == '__main__':
    main()
