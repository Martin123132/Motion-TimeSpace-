from handoff_support import *
import shutil


def main():
    with worker('bootstrap-early'):
        native = PREVIOUS / 'native'
        target = ROOT / 'native'
        require(not target.exists(), 'isolated new native copy')
        copied = {}
        for folder in ('camb', 'fortran', 'forutils'):
            shutil.copytree(native / folder, target / folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.dll', '*.o', '*.mod', 'WinMTS', '.git'))
            for path in sorted((target / folder).rglob('*')):
                if path.is_file():
                    relative = path.relative_to(target)
                    checksum = digest(native / relative)
                    require(digest(path) == checksum, 'identical native source copy')
                    copied[str(relative)] = checksum
        write('native-bootstrap-result.json', dict(completed=True, copied_source_hashes=copied, original=str(native), candidate=str(target)))
        print(json.dumps(dict(copied=len(copied))), flush=True)


if __name__ == '__main__':
    main()
