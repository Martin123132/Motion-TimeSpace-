from handoff_support import *
import ast


def main():
    source = PREVIOUS / 'build_native.py'
    sealed = read(PREVIOUS / 'closeout.json')['artifacts']['build_native.py']['sha256']
    require(digest(source) == sealed, 'retained serial build driver')
    tree = ast.parse(source.read_text(encoding='utf-8'))
    changes = []

    class Adapt(ast.NodeTransformer):
        def visit_ImportFrom(self, node):
            if node.module == 'source_support':
                changes.append('support')
                node.module = 'handoff_support'
            return node

        def visit_Set(self, node):
            if all(isinstance(value, ast.Constant) for value in node.elts) and {value.value for value in node.elts} == {'fortran/MTSTwoField.f90', 'camb/mts.py'}:
                changes.append('declared_file')
                return ast.Set(elts=[ast.Constant('fortran/camb_python.f90')])
            return self.generic_visit(node)

    tree = Adapt().visit(tree)
    require(changes == ['support', 'declared_file'], 'bounded build adapter')
    namespace = dict(__file__=__file__, __name__='early_native_build', NATIVE=PREVIOUS / 'native')
    exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'), namespace)
    namespace['main']()


if __name__ == '__main__':
    main()
