from handoff_support import *
import numpy as np
from scipy.interpolate import CubicSpline, CubicHermiteSpline
sys.path.insert(0, str(PREVIOUS))
from quintic_model import functions as quintic_functions
from source_model import native_replay
retained = native_replay.retained


class Context(retained.Context):
    def __init__(self, case, representation):
        self.case = case
        self.representation = representation
        configuration = read(ROOT / 'frozen-handoff.json')
        lower, upper = configuration['saved_indices']
        indices = np.arange(lower - 8, upper + 9)
        self.target = np.arange(lower, upper + 1) - (lower - 8)
        label = 'native-' + case + ('-quintic' if case == 'cold' else '-quintic-owned')
        report = read(PREVIOUS / (label + '-result.json'))
        require(report['completed'], 'completed repaired native history')
        require(digest(PREVIOUS / (label + '.npz')) == report['packet_sha256'], 'repaired native history hash')
        with np.load(PREVIOUS / (label + '.npz'), allow_pickle=False) as packet:
            standard = {str(name): packet['standard'][indices, index] for index, name in enumerate(packet['names'])}
            observer = {str(name): packet['observer'][indices, index] for index, name in enumerate(packet['observer_names'])}
            clock = packet['clock'][indices].copy()
        scale, hubble, eta, alpha = [observer[name] for name in ('a_native', 'H_native', 'eta_sync', 'sigma')]
        potential = eta - hubble * alpha
        lapse = potential - observer['Pi']
        weyl_error = retained.difference((potential + lapse) / 2, observer['Weyl'])
        require(weyl_error['normalized'] < ALGEBRA, 'double metric convention')
        self.data = dict(clock=clock, a=scale, H=hubble, eta=eta, alpha=alpha, Phi=potential, Psi=lapse, dstar_cdm_over_rho=observer['delta_cdm64'] - 3 * eta, current_cdm_over_rho=alpha, delta_cdm_N=observer['delta_cdm64'] - 3 * hubble * alpha)
        self.fields = ['s'] if case == 'cold' else ['s', 'h']
        self.field_functions, masses, source_checks = {}, {}, {}
        with np.load(BACKGROUND / (case + '-candidate-background.npz'), allow_pickle=False) as table:
            self.field_functions['s'] = (CubicSpline(table['efold'], table['phi_s'], bc_type='natural'), CubicSpline(table['efold'], table['phidot_s'], bc_type='natural'))
            masses['s'] = float(table['slow_mass_mpc'])
            if case == 'heavy':
                with np.load(PREVIOUS / 'heavy-equation-quintic.npz', allow_pickle=False) as packet:
                    self.field_functions['h'], derivatives = quintic_functions(packet)
                masses['h'] = float(table['heavy_mass_mpc'])
        self.parameters = dict(masses=masses)
        for suffix in self.fields:
            field, velocity = [function(np.log(scale)) for function in self.field_functions[suffix]]
            mass2 = (scale * masses[suffix])**2
            sync_u, sync_w = standard['mts_dphi_' + suffix], standard['mts_dphidot_' + suffix]
            coordinate = sync_u + velocity * alpha
            momentum = sync_w - mass2 * field * alpha - 3 * eta * velocity
            kinetic, potential_energy = velocity * momentum, mass2 * field * coordinate
            sources = dict(u=coordinate, p=momentum, D=kinetic + potential_energy + 3 * velocity**2 * potential, P=kinetic - potential_energy + 3 * velocity**2 * potential, Q=velocity * coordinate, Dstar=kinetic + potential_energy, Pi=scale**2 * momentum)
            self.data.update({suffix + '_' + name: values for name, values in sources.items()})
            native_sources = dict(D=standard['mts_drho_' + suffix] - 3 * hubble * velocity**2 * alpha, P=standard['mts_dp_' + suffix] - (3 * hubble * velocity**2 + 2 * mass2 * field * velocity) * alpha, Q=standard['mts_q_' + suffix] + velocity**2 * alpha)
            for name, values in native_sources.items():
                check = retained.difference(sources[name], values)
                require(check['normalized'] < ALGEBRA, 'new window source recovery')
                source_checks[suffix + '_' + name] = check
        selected = np.arange(len(indices)) if representation == 'fine' else np.unique(np.r_[np.arange(0, len(indices), 2), len(indices) - 1, self.target[0], self.target[-1]])
        self.scale = CubicHermiteSpline(clock[selected], scale[selected], scale[selected] * hubble[selected])
        self.scale_prime = self.scale.derivative()
        self.potential = CubicSpline(clock[selected], potential[selected])
        self.lapse = CubicSpline(clock[selected], lapse[selected])
        self.clock = clock[self.target]
        state_names = ['dstar_cdm_over_rho', 'current_cdm_over_rho'] + [suffix + '_' + name for suffix in self.fields for name in ('u', 'p')]
        self.data['reference_state'] = np.column_stack([self.data[name][self.target] for name in state_names])
        self.normalization = np.max(abs(self.data['reference_state']), axis=0)
        require(np.all(self.normalization > 0), 'component normalization')
        self.provenance = dict(source_recovery=source_checks, weyl=weyl_error)


def advance(context, substeps, initial):
    values = np.empty_like(context.data['reference_state'])
    values[0] = initial
    normalized = initial / context.normalization
    for index in range(len(context.clock) - 1):
        guard()
        left, right = context.clock[index:index + 2]
        step = (right - left) / substeps
        for inner in range(substeps):
            clock = left + inner * step
            first = context.rhs(clock, normalized)
            second = context.rhs(clock + step / 2, normalized + step * first / 2)
            third = context.rhs(clock + step / 2, normalized + step * second / 2)
            fourth = context.rhs(clock + step, normalized + step * third)
            normalized += step * (first + 2 * second + 2 * third + fourth) / 6
        values[index + 1] = normalized * context.normalization
    require(np.isfinite(values).all(), 'finite continuation')
    return values


def main():
    with worker('adjacent-window'):
        inputs = previous_inputs()
        inputs.update({str(path): digest(path) for path in (Path(__file__), ROOT / 'handoff_support.py', ROOT / 'PROTOCOL.md')})
        write('frozen-inputs.json', inputs)
        write('frozen-handoff.json', dict(saved_indices=[2591, 2890], previous_indices=[2292, 2591], intervals=299, guard_nodes=8, initialization=['carried', 'native_seeded_control'], numerical_gate=GATE, algebra_gate=ALGEBRA, frozen_before_evaluation=True))
        reports = {}
        for case in ('cold', 'heavy'):
            case_report = {}
            for initialization in ('carried', 'native_seeded_control'):
                outputs, runs = {}, {}
                for variant in ('fine2', 'fine4', 'coarse4'):
                    context = Context(case, 'coarse' if variant == 'coarse4' else 'fine')
                    prior_label = case + ('-quintic' if case == 'cold' else '-quintic-owned')
                    prior_path = PREVIOUS / ('replay-' + prior_label + '-' + variant + '.npz')
                    prior_report = read(PREVIOUS / 'owned-candidate-result.json')['cases'][prior_label]['runs'][variant]
                    require(digest(prior_path) == prior_report['packet_sha256'], 'saved incoming endpoint')
                    with np.load(prior_path, allow_pickle=False) as prior:
                        require(prior['clock'][-1] == context.clock[0], 'exact shared endpoint time')
                        incoming = prior['state'][-1].copy()
                    initial = incoming if initialization == 'carried' else context.data['reference_state'][0].copy()
                    state = advance(context, int(variant[-1]), initial)
                    require(np.array_equal(state[0], initial), 'no handoff reset')
                    observed = context.observe(state)
                    checks = {name: retained.difference(values, context.data[name][context.target]) for name, values in observed.items()}
                    destination = ROOT / (case + '-' + initialization + '-' + variant + '.npz')
                    np.savez_compressed(destination, clock=context.clock, state=state, incoming=incoming, **observed)
                    runs[variant] = dict(passed=all(row['passed'] for row in checks.values()), checks=checks, initial_state_exact=True, source_recovery=context.provenance['source_recovery'], packet_sha256=digest(destination), incoming_sha256=digest(prior_path))
                    outputs[variant] = observed
                refinement = {name: retained.difference(outputs['fine2'][name], values) for name, values in outputs['fine4'].items()}
                history = {name: retained.difference(outputs['coarse4'][name], values) for name, values in outputs['fine4'].items()}
                passed = all(run['passed'] for run in runs.values()) and all(row['passed'] for row in list(refinement.values()) + list(history.values()))
                case_report[initialization] = dict(passed=passed, runs=runs, refinement=refinement, history_sensitivity=history)
                print(json.dumps(dict(case=case, initialization=initialization, passed=passed, worst=max(row['normalized'] for row in runs['fine4']['checks'].values()), failed=[name for name, row in runs['fine4']['checks'].items() if not row['passed']])), flush=True)
            reports[case] = case_report
        check_hashes(inputs)
        write('adjacent-window-result.json', dict(completed=True, paired_carried_passed=all(reports[case]['carried']['passed'] for case in reports), paired_native_seeded_passed=all(reports[case]['native_seeded_control']['passed'] for case in reports), cases=reports, source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'PROTOCOL.md', ROOT / 'frozen-handoff.json')}, still_forced_canonical_replay=True, full_native_state_restart_tested=False))


if __name__ == '__main__':
    main()
