from handoff_support import *
import ast


def main():
    source = ROOT / 'run_early.py'
    frozen = read(ROOT / 'early-heavy-frozen.json')
    require(digest(source) == frozen[str(source)], 'accepted matching-window adapter preserved')
    tree = ast.parse(source.read_text(encoding='utf-8'))
    changes = dict(label=0, protocol=0, indices=0, provenance=0)

    class Adapt(ast.NodeTransformer):
        def visit_Constant(self, node):
            if node.value == 'early-':
                changes['label'] += 1
                return ast.Constant('early-tca-')
            if node.value == 'frozen-handoff.json':
                changes['protocol'] += 1
                return ast.Constant('frozen-tca-handoff.json')
            return node

        def visit_Tuple(self, node):
            if len(node.elts) == 2 and all(isinstance(value, ast.Constant) for value in node.elts) and [value.value for value in node.elts] == [2591, 2890]:
                changes['indices'] += 1
                return ast.Tuple(elts=[ast.Constant(512), ast.Constant(520)], ctx=ast.Load())
            return self.generic_visit(node)

        def visit_For(self, node):
            if isinstance(node.target, ast.Name) and node.target.id == 'path' and isinstance(node.iter, ast.Tuple):
                changes['provenance'] += 1
                node.iter.elts.extend(ast.parse('ROOT / "run_early.py", ROOT / "TIGHT-COUPLING-CONTROL.md"', mode='eval').body.elts)
            return self.generic_visit(node)

    tree = Adapt().visit(tree)
    require(changes == dict(label=1, protocol=2, indices=1, provenance=1), 'only declared early-control changes')
    namespace = dict(__file__=__file__, __name__='early_cache_control')
    exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'), namespace)
    namespace['main']()


if __name__ == '__main__':
    main()
