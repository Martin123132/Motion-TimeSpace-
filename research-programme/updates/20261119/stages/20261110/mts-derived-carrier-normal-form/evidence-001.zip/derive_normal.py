from normal_model import *
import argparse


def freeze():
    require(digest(PREVIOUS/'closeout.json')==EXPECTED_PREVIOUS,'verified predecessor seal')
    old=read(PREVIOUS/'closeout.json')
    check_hashes(old['input_hashes'])
    check_hashes({str(PREVIOUS/name):row['sha256'] for name,row in old['artifacts'].items()})
    transferred=read(TRANSFER/'closeout.json')
    paths=[PREVIOUS/'closeout.json',PREVIOUS/'CLEANUP-VERIFIED.json',TRANSFER/'closeout.json',PROJECTION/'frozen-projection.npz',PROJECTION/'frozen-projection.json',COUPLED/'native/fortran/MTSTwoField.f90',SOURCE/'DERIVATION.md',POST/'mts-late-hierarchy-port-20261110/RESULTS.md',LIVE/'live_support.py']
    for case in ('cold','heavy'):
        for window in ('live','extraction'):
            path=input_path(case,window)
            seal=old if window=='live' else transferred
            require(digest(path)==seal['artifacts'][path.name]['sha256'],'saved packet provenance')
            paths.append(path)
        label=case+'-source-state'+('-balanced-check' if case=='heavy' else '')
        paths.extend([PREVIOUS/(label+'-result.json'),TRANSFER/(case+'-transfer-capture.npz')])
    paths.extend(sorted(ROOT.glob('*.py')))
    paths.append(ROOT/'PROTOCOL.md')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write('frozen-inputs.json',{str(path):digest(path) for path in paths})
    write('contract.json',dict(previous_turn='progress',previous_seal=EXPECTED_PREVIOUS,windows=['extraction','live'],cases=['cold','heavy'],wave_mpc_inverse=1.,numerical_gate=GATE,algebra_gate=ALGEBRA,saved_data_only=True,new_physical_integration=False,new_fit=False,curve_bank_parameters_tolerances_changed=False,old_late_selector_replaced=False,acceptance='exact identities and native source reconstruction; late-only failures retained as diagnostic results',projection='original 902 signed weights, no altered window or positive ensemble assumption'))
    print(json.dumps(dict(frozen=True,inputs=len(paths))),flush=True)


def symbolic():
    import sympy as symbolic_math
    check_hashes(read(ROOT/'frozen-inputs.json'))
    field,velocity,mode,mode_velocity,beta,rate,hubble,mass,frequency,wave,dilation,field_error,velocity_error=symbolic_math.symbols('b v u w beta r H mu omega k z Ef Eb',real=True)
    summed=frequency+mass
    difference=wave**2/summed
    sound2=wave**2/summed**2
    cosine=field*mode+velocity*mode_velocity/(mass*frequency)
    sine=velocity*mode/mass-field*mode_velocity/frequency
    fast_cosine=field*mode-velocity*mode_velocity/(mass*frequency)
    fast_sine=-velocity*mode/mass-field*mode_velocity/frequency
    derivatives={field:velocity+field_error,velocity:-2*hubble*velocity-mass**2*field+velocity_error,mode:mode_velocity,mode_velocity:-2*hubble*mode_velocity-frequency**2*mode-wave*dilation*velocity,mass:rate*mass,frequency:rate*mass**2/frequency,beta:rate*beta}
    def derivative(expression):
        return sum(symbolic_math.diff(expression,variable)*value for variable,value in derivatives.items())
    def is_zero(expression):
        numerator=symbolic_math.fraction(symbolic_math.cancel(expression))[0]
        return symbolic_math.rem(numerator,wave**2-frequency**2+mass**2,wave)==0
    gamma=4*hubble+rate*(1+mass**2/frequency**2)
    cosine_rhs=-difference*sine-gamma*(cosine-fast_cosine)/2+field_error*mode+velocity_error*mode_velocity/(mass*frequency)-wave*dilation*velocity**2/(mass*frequency)
    sine_rhs=difference*cosine-gamma*sine/2+rate*(1-mass**2/frequency**2)*fast_sine/2+velocity_error*mode/mass-field_error*mode_velocity/frequency+wave*dilation*field*velocity/frequency
    density_factor=beta*mass*summed/2
    current_factor=beta*wave*mass/2
    density=density_factor*cosine
    current=current_factor*sine
    physical_density=beta*(velocity*mode_velocity+mass**2*field*mode)
    physical_pressure=beta*(velocity*mode_velocity-mass**2*field*mode)
    physical_current=beta*wave*velocity*mode
    perturbation_virial=beta*(field*mode_velocity+velocity*mode)
    amplitude=field**2+velocity**2/mass**2
    flat={hubble:0,rate:0,dilation:0,field_error:0,velocity_error:0}
    matrix=symbolic_math.Matrix([[field,velocity/(mass*frequency)],[velocity/mass,-field/frequency]])
    checks={
        'dispersion_relation':is_zero((frequency-mass)-difference),
        'sound_coefficient':is_zero(sound2-(frequency-mass)/summed),
        'slow_frequency_squared':is_zero(difference**2-wave**2*sound2),
        'regular_inverse_determinant':is_zero(matrix.det()+amplitude/frequency),
        'inverse_mode':is_zero((field*cosine+velocity*sine/mass)/amplitude-mode),
        'inverse_velocity':is_zero(frequency*(velocity*cosine/mass-field*sine)/amplitude-mode_velocity),
        'physical_density_split':is_zero(physical_density-density+beta*mass*difference*fast_cosine/2),
        'physical_pressure_split':is_zero(physical_pressure-sound2*density+density_factor*fast_cosine),
        'physical_current_split':is_zero(physical_current-current+current_factor*fast_sine),
        'perturbation_virial_split':is_zero(perturbation_virial+beta*(difference*sine+summed*fast_sine)/2),
        'boundary_current_normalization':is_zero(physical_current-wave*perturbation_virial/2-beta*wave*(summed*sine+difference*fast_sine)/4),
        'slow_cosine_evolution':is_zero(derivative(cosine)-cosine_rhs),
        'slow_sine_evolution':is_zero(derivative(sine)-sine_rhs),
        'frozen_slow_density':is_zero(derivative(density).subs(flat)+wave*current),
        'frozen_slow_current':is_zero(derivative(current).subs(flat)-wave*sound2*density),
        'frozen_fast_cosine':is_zero(derivative(fast_cosine).subs(flat)+summed*fast_sine),
        'frozen_fast_sine':is_zero(derivative(fast_sine).subs(flat)-summed*fast_cosine),
        'equal_mode_amplitudes':is_zero(cosine**2+sine**2-fast_cosine**2-fast_sine**2),
        'action_amplitude':is_zero(cosine**2+sine**2-amplitude*(mode**2+mode_velocity**2/frequency**2))
    }
    expansion_density=rate*(2+mass/frequency)-gamma/2
    expansion_current=2*rate-gamma/2
    density_rhs=-wave*current+expansion_density*density+density_factor*gamma*fast_cosine/2-beta*wave*summed*velocity**2*dilation/(2*frequency)+density_factor*(field_error*mode+velocity_error*mode_velocity/(mass*frequency))
    current_rhs=wave*sound2*density+expansion_current*current+current_factor*rate*(1-mass**2/frequency**2)*fast_sine/2+beta*wave**2*mass*field*velocity*dilation/(2*frequency)+current_factor*(velocity_error*mode/mass-field_error*mode_velocity/frequency)
    checks['full_normal_density_rhs']=is_zero(derivative(density)-density_rhs)
    checks['full_normal_current_rhs']=is_zero(derivative(current)-current_rhs)
    small=symbolic_math.symbols('epsilon',positive=True)
    checks['nonrelativistic_sound_limit']=symbolic_math.limit(4/(symbolic_math.sqrt(1+small**2)+1)**2,small,0)==1
    require(all(checks.values()),'symbolic normal-form identities')
    write('symbolic.json',dict(passed=True,identities=checks,count=len(checks),relation='omega^2=mu^2+k^2; nonzero mu, omega, beta and positive background amplitude; k>0 for current inverse',new_physics_not_assumed=True))
    print(json.dumps(dict(symbolic_passed=True,identities=len(checks))),flush=True)


def analyze():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'symbolic.json')['passed'],'derived identities first')
    frozen=packet(PROJECTION/'frozen-projection.npz')
    density0=float(frozen['density0'])
    reports={}
    for case in ('cold','heavy'):
        for window in ('extraction','live'):
            guard()
            saved=packet(input_path(case,window))
            first=source_first(case,window)
            name=case+'-'+window
            if case=='cold':
                scale,rate,hubble,dilation=saved['extra'].T
                factor=saved['observation'][:,12]*scale/density0
                density=factor*saved['vector'][:,1]
                actual=factor*saved['derivative'][:,1]
                predicted=-factor*dilation
                checks=dict(dust=dict(equation=comparison(predicted,actual,ALGEBRA),constant_normalization=comparison(factor,np.full_like(factor,factor[0]),ALGEBRA)))
                data=dict(clock=saved['clock'],density=density,current=np.zeros_like(density),pressure=np.zeros_like(density),direct=actual,predicted=predicted)
                report=dict(passed=all_pass(checks),checks=checks,source='actual retained CDM, not heavy oscillatory variables',normalization=float(factor[0]))
            else:
                data=heavy_normal(saved,first,density0)
                checks=heavy_checks(data)
                if window=='live':
                    checks['saved_boundary_state']=columns(data['boundary_sources'],saved['state'][:,-2:],'source_',ALGEBRA)
                late_checks=columns(data['late'],data['direct'],'slow_source_')
                without_fast=columns(data['operator']+data['metric']+data['representation'],data['direct'],'slow_source_')
                report=dict(passed=all_pass(checks),checks=checks,late_only_controls=late_checks,drop_fast_controls=without_fast,sound2_range=[float(np.min(data['sound2'])),float(np.max(data['sound2']))],normal_form='exact time-dependent invertible coordinates; slow label refers to frozen dispersion, not assumed averaged dynamics',residual_peaks={key:np.max(abs(data[key]),axis=0) for key in ('expansion_residual','phase','metric_residual','representation')},rate_peaks=np.max(abs(data['direct']),axis=0))
                if window=='extraction':
                    weights=frozen['weights']
                    require(len(weights)==len(data['clock']),'original 902-node support')
                    projected={key:weights@data[key] for key in ('physical','slow','fast','direct','late','expansion_residual','phase','metric_residual','representation')}
                    coefficient=float(frozen['sound2'])
                    slow_prediction=coefficient*projected['slow'][0]
                    coefficient_history=float(weights@((data['sound2']-coefficient)*data['slow'][:,0]))
                    exact_pressure=slow_prediction+coefficient_history+projected['fast'][2]
                    pressure_check=comparison(exact_pressure,projected['physical'][2],ALGEBRA)
                    checks['projection']=dict(pressure_split=pressure_check,full_stress=comparison(projected['slow']+projected['fast'],projected['physical'],ALGEBRA))
                    old_pressure=coefficient*(projected['physical'][0]+3*read(PROJECTION/'frozen-projection.json')['original_hubble']*projected['physical'][1])
                    report['projection']=dict(values=projected,constant_coefficient=coefficient,slow_pressure_prediction=slow_prediction,coefficient_history=coefficient_history,fast_pressure=projected['fast'][2],exact_reassembled_pressure=exact_pressure,slow_only_check=comparison(slow_prediction,projected['physical'][2]),existing_late_pressure=old_pressure,existing_late_check=comparison(old_pressure,projected['physical'][2]),weight_sum=float(np.sum(weights)),absolute_weight_sum=float(np.sum(abs(weights))),fast_endpoint_to_projection={key:dict(endpoint=float(data['fast'][-1,index]),projected=float(projected['fast'][index])) for index,key in enumerate(('density','current','pressure'))})
                    data['projection_weights']=weights
                    data['projected_physical']=projected['physical']
                    data['projected_slow']=projected['slow']
                    data['projected_fast']=projected['fast']
                report['passed']=all_pass(checks)
            target=ROOT/(name+'.npz')
            require(not target.exists(),'no output overwrite')
            np.savez_compressed(target,**data)
            report['packet_sha256']=digest(target)
            reports[name]=report
            print(json.dumps(dict(case=case,window=window,identities_passed=report['passed'],late_only_controls=report.get('late_only_controls'),sound2=report.get('sound2_range')),default=convert),flush=True)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('analysis.json',dict(passed=all(row['passed'] for row in reports.values()),runs=reports,full_goal_complete=False))
    require(all(row['passed'] for row in reports.values()),'paired saved-history normal-form checks')


def verify():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    result=read(ROOT/'analysis.json')
    require(result['passed'] and read(ROOT/'symbolic.json')['passed'],'completed derived normal-form analysis')
    checks={}
    for name,row in result['runs'].items():
        path=ROOT/(name+'.npz')
        require(digest(path)==row['packet_sha256'],'unchanged result packet')
        data=packet(path)
        if name.startswith('heavy'):
            checks.update({name+'/'+key:value for key,value in heavy_checks(data).items()})
            checks[name+'/slow_pressure']=dict(coefficient=comparison(data['slow'][:,2],data['sound2']*data['slow'][:,0],ALGEBRA))
            if 'projection_weights' in data:
                checks[name+'/projected_stress']=columns((data['projection_weights']@(data['slow']+data['fast']))[None,:],data['projected_physical'][None,:],'stress_',ALGEBRA)
        else:
            checks[name+'/dust']=dict(equation=comparison(data['predicted'],data['direct'],ALGEBRA))
    count=sum(len(group) for group in checks.values())
    require(all_pass(checks),'independent saved-packet verification')
    write('validation.json',dict(passed=True,checks=checks,count=count,identities=read(ROOT/'symbolic.json')['count'],late_only_failures_not_hidden=True))
    print(json.dumps(dict(verified=True,comparisons=count,identities=read(ROOT/'symbolic.json')['count'])),flush=True)


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['passed'],'verified normal form')
    require((ROOT/'RESULTS.md').is_file() and (ROOT/'DERIVATION.md').is_file(),'scientific writeup saved')
    excluded={'closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json'}
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write('closeout.json',dict(implementation_validated=True,exact_normal_form_derived=True,retained_frozen_sound_coefficient_derived=True,expanding_metric_remainders_derived_and_evaluated=True,old_late_selector_replaced=False,galactic_occupation_selected=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='postseal-start.json':
            continue
        owner=read(path)
        ending=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(owner)
        require(outcome['exited'] and ending['state']=='completed','prior worker completed and exited')
        workers.append(dict(name=path.stem,identity=owner,outcome=outcome))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode left')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('freeze','symbolic','analyze','verify','seal','postseal'))
    arguments=parser.parse_args()
    with worker(arguments.operation) as identity:
        if arguments.operation=='postseal':
            postseal(identity)
        else:
            globals()[arguments.operation]()
