from normal_support import *


def heavy_normal(data,first,density0):
    scale,rate,hubble,dilation=data['extra'].T
    field,velocity,field_first,velocity_first,mass2,frequency=data['jets'][:,1].T
    mass=np.sqrt(mass2)
    beta=scale/density0
    wave=1.
    require(np.all(mass>0) and np.all(frequency>0),'positive oscillator frequencies')
    require(np.allclose(frequency**2,mass2+wave**2,rtol=ALGEBRA,atol=0),'native oscillator frequency')
    mode,mode_velocity=data['vector'][:,first+2:first+4].T
    mode_prime,mode_velocity_prime=data['derivative'][:,first+2:first+4].T
    field_prime=rate*field_first
    velocity_prime=rate*velocity_first
    field_error=field_prime-velocity
    velocity_error=velocity_prime+2*hubble*velocity+mass2*field
    summed=frequency+mass
    difference=wave**2/summed
    sound2=(wave/summed)**2
    ratio=mass2/frequency**2
    amplitude2=field**2+(velocity/mass)**2
    require(np.all(amplitude2>0),'nonzero background for regular oscillator map')
    cosine=field*mode+velocity*mode_velocity/(mass*frequency)
    sine=velocity*mode/mass-field*mode_velocity/frequency
    fast_cosine=field*mode-velocity*mode_velocity/(mass*frequency)
    fast_sine=-velocity*mode/mass-field*mode_velocity/frequency
    density_factor=beta*mass*summed/2
    current_factor=beta*wave*mass/2
    density=density_factor*cosine
    current=current_factor*sine
    pressure=sound2*density
    fast_density=-beta*mass*difference*fast_cosine/2
    fast_current=-current_factor*fast_sine
    fast_pressure=-density_factor*fast_cosine
    physical=np.column_stack([beta*(velocity*mode_velocity+mass2*field*mode),beta*wave*velocity*mode,beta*(velocity*mode_velocity-mass2*field*mode)])
    slow=np.column_stack([density,current,pressure])
    fast=np.column_stack([fast_density,fast_current,fast_pressure])
    denominator_prime_ratio=rate*(1+ratio)
    cosine_prime=field_prime*mode+field*mode_prime+(velocity_prime*mode_velocity+velocity*mode_velocity_prime)/(mass*frequency)-denominator_prime_ratio*velocity*mode_velocity/(mass*frequency)
    sine_prime=(velocity_prime-rate*velocity)*mode/mass+velocity*mode_prime/mass-(field_prime-rate*ratio*field)*mode_velocity/frequency-field*mode_velocity_prime/frequency
    gamma=4*hubble+rate*(1+ratio)
    force=-wave*dilation*velocity
    cosine_expected=-difference*sine-gamma*(cosine-fast_cosine)/2+field_error*mode+velocity_error*mode_velocity/(mass*frequency)+velocity*force/(mass*frequency)
    sine_expected=difference*cosine-gamma*sine/2+rate*(1-ratio)*fast_sine/2+velocity_error*mode/mass-field_error*mode_velocity/frequency-field*force/frequency
    direct=np.column_stack([density_factor*(cosine_prime+rate*(2+mass/frequency)*cosine),current_factor*(sine_prime+2*rate*sine)])
    drift_density=rate*(2+mass/frequency)-gamma/2
    drift_current=2*rate-gamma/2
    operator=np.column_stack([-wave*current+drift_density*density,wave*sound2*density+drift_current*current])
    phase=np.column_stack([density_factor*gamma*fast_cosine/2,current_factor*rate*(1-ratio)*fast_sine/2])
    metric=np.column_stack([-beta*wave*summed*velocity**2*dilation/(2*frequency),beta*wave**2*mass*field*velocity*dilation/(2*frequency)])
    representation=np.column_stack([density_factor*(field_error*mode+velocity_error*mode_velocity/(mass*frequency)),current_factor*(velocity_error*mode/mass-field_error*mode_velocity/frequency)])
    late_pressure=sound2*(density+3*hubble*current/wave)
    late=np.column_stack([-3*hubble*late_pressure-wave*current-wave*dilation,-hubble*current+wave*late_pressure])
    expansion_residual=np.column_stack([(drift_density+3*hubble*sound2)*density+9*hubble**2*sound2*current/wave,(drift_current+hubble-3*hubble*sound2)*current])
    metric_residual=metric+np.column_stack([wave*dilation,np.zeros_like(dilation)])
    recovered=np.column_stack([(field*cosine+(velocity/mass)*sine)/amplitude2,frequency*((velocity/mass)*cosine-field*sine)/amplitude2])
    double_cosine=(field**2-(velocity/mass)**2)/amplitude2
    double_sine=2*field*velocity/mass/amplitude2
    fast_reconstructed=np.column_stack([double_cosine*cosine+double_sine*sine,-double_sine*cosine+double_cosine*sine])
    virial=beta*field*velocity
    perturbation_virial=beta*(field*mode_velocity+velocity*mode)
    boundary_sources=np.column_stack([physical[:,0]+(3*hubble*perturbation_virial+wave*dilation*virial)/2,physical[:,1]-wave*perturbation_virial/2])
    boundary_reconstructed=np.column_stack([density+fast_density+(3*hubble*perturbation_virial+wave*dilation*virial)/2,beta*wave*(summed*sine+difference*fast_sine)/4])
    native_mode=np.column_stack([mode_velocity,-2*hubble*mode_velocity-frequency**2*mode-wave*dilation*velocity])
    envelope=np.sqrt(amplitude2*(mode**2+(mode_velocity/frequency)**2))
    return dict(clock=data['clock'],beta=beta,scale=scale,rate=rate,hubble=hubble,dilation=dilation,mass=mass,frequency=frequency,sound2=sound2,cosine=cosine,sine=sine,fast_cosine=fast_cosine,fast_sine=fast_sine,physical=physical,slow=slow,fast=fast,direct=direct,operator=operator,phase=phase,metric=metric,representation=representation,late=late,expansion_residual=expansion_residual,metric_residual=metric_residual,recovered=recovered,original=np.column_stack([mode,mode_velocity]),cosine_sine_prime=np.column_stack([cosine_prime,sine_prime]),cosine_sine_expected=np.column_stack([cosine_expected,sine_expected]),fast_reconstructed=fast_reconstructed,boundary_sources=boundary_sources,boundary_reconstructed=boundary_reconstructed,native_mode=native_mode,original_mode_prime=np.column_stack([mode_prime,mode_velocity_prime]),envelope=envelope,density_envelope=density_factor*envelope,fast_density_envelope=beta*mass*difference*envelope/2,current_envelope=current_factor*envelope,fast_pressure_envelope=density_factor*envelope,field_error=field_error,velocity_error=velocity_error)


def heavy_checks(data):
    pairs={
        'inverse':(data['recovered'],data['original']),
        'stress_split':(data['slow']+data['fast'],data['physical']),
        'two_frequency_chain':(data['cosine_sine_expected'],data['cosine_sine_prime']),
        'full_evolution':(data['operator']+data['phase']+data['metric']+data['representation'],data['direct']),
        'late_plus_residual':(data['late']+data['expansion_residual']+data['phase']+data['metric_residual']+data['representation'],data['direct']),
        'dependent_fast_state':(data['fast_reconstructed'],np.column_stack([data['fast_cosine'],data['fast_sine']])),
        'boundary_coordinates':(data['boundary_reconstructed'],data['boundary_sources']),
        'native_equations':(data['native_mode'],data['original_mode_prime'])
    }
    checks={name:columns(actual,reference,name+'_',ALGEBRA) for name,(actual,reference) in pairs.items()}
    checks['amplitudes']=dict(slow=comparison(data['cosine']**2+data['sine']**2,data['envelope']**2,ALGEBRA),fast=comparison(data['fast_cosine']**2+data['fast_sine']**2,data['envelope']**2,ALGEBRA),density_ratio=comparison(data['fast_density_envelope'],data['sound2']*data['density_envelope'],ALGEBRA))
    return checks
