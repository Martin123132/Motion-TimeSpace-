import sys
from pathlib import Path
from time import monotonic

LIVE=Path(__file__).resolve().parent.parent/'mts-reconstructed-live-continuation-20261110'
sys.path.insert(0,str(LIVE))
import live_support as shared
shared.ROOT=Path(__file__).resolve().parent
shared.START=monotonic()
from live_support import *

PREVIOUS=POST/'mts-live-boundary-source-state-20261110'
EXPECTED_PREVIOUS='fb21f132f5c5190a117da0ad9d46ce44fee61d78507823b6f07fb63f6d90f283'
inherited_guard=shared.guard


def guard():
    inherited_guard()
    for directory in (PREVIOUS,LIVE,POST/'mts-coupled-memory-budget-20261110'):
        require(not (directory/'STOP-REQUESTED').exists(),'owner hold '+str(directory))


shared.guard=guard


def input_path(case,window):
    if window=='extraction':
        return TRANSFER/(case+'-transfer-source-readout.npz')
    label=case+'-source-state'+('-balanced-check' if case=='heavy' else '')
    return PREVIOUS/(label+'-reconstructed-step256-h2.npz')


def source_first(case,window):
    if window=='extraction':
        return int(packet(TRANSFER/(case+'-transfer-capture.npz'))['signature'][0,2])-1
    label=case+'-source-state'+('-balanced-check' if case=='heavy' else '')
    return read(PREVIOUS/(label+'-result.json'))['first']
