from response_support import *
from scipy.interpolate import CubicSpline,CubicHermiteSpline
sys.path.insert(0,str(SOURCE))
from quintic_model import functions as quintic_functions


class Response:
    def __init__(self,case,stride):
        self.case=case
        self.stride=stride
        with np.load(PREVIOUS/(case+'-transfer-source-readout.npz'),allow_pickle=False) as data:
            self.saved={name:data[name].copy() for name in data.files}
        with np.load(PREVIOUS/(case+'-transfer-capture.npz'),allow_pickle=False) as data:
            self.capture={name:data[name].copy() for name in data.files}
        with np.load(PROJECTION/'frozen-projection.npz',allow_pickle=False) as data:
            self.frozen={name:data[name].copy() for name in data.files}
        self.times=self.saved['clock']
        self.fields=2 if case=='heavy' else 1
        self.dimension=2*self.fields+1
        first=int(self.capture['signature'][0,2])-1
        self.native_indices=[*range(first,first+2*self.fields),1]
        self.reference=self.capture['reference'][:,self.native_indices]
        self.reference_derivative=self.capture['derivative_reference'][:,self.native_indices]
        self.scale=np.max(abs(self.reference),axis=0)
        require(np.all(self.scale>0),'nonzero coordinate similarity scales')
        self.names=[name+'_'+suffix for suffix in (['s','h'] if self.fields==2 else ['s']) for name in ('u','w')]+['delta_cdm']
        self.source_names=[suffix+'_'+name for suffix in (['s','h'] if self.fields==2 else ['s']) for name in ('D','Q','P')]+['cdm_D']
        nodes=np.unique(np.r_[np.arange(0,len(self.times),stride),len(self.times)-1])
        self.check_indices=nodes
        scale=self.saved['extra'][:,0]
        rate=self.saved['extra'][:,1]
        self.expansion=CubicHermiteSpline(self.times[nodes],scale[nodes],(scale*rate)[nodes])
        self.cdm_constant=self.saved['observation'][0,12]*scale[0]
        with np.load(HANDOFF/('early-'+case+'-restart.npz'),allow_pickle=False) as data:
            selected=self.frozen['selected']
            guarded=np.arange(int(selected[0])-8,int(selected[-1])+9)
            chosen=np.unique(np.r_[guarded[::stride],guarded[-1],selected[0],selected[-1]])
            clock=data['full_clock'][chosen]
            observed=data['observer'][chosen]
        rest_density=np.sum(observed[:,13:17]*observed[:,20:24],axis=1)
        self.hubble=CubicSpline(clock,observed[:,28])
        self.rest_density=CubicSpline(clock,rest_density)
        self.eta=CubicSpline(clock,observed[:,7])
        self.functions=[]
        with np.load(BACKGROUND/(case+'-candidate-background.npz'),allow_pickle=False) as data:
            self.masses=[float(data['slow_mass_mpc'])]
            self.functions.append([CubicSpline(data['efold'],data[key],bc_type='natural') for key in ('phi_s','phidot_s')])
            if self.fields==2:
                self.masses.append(float(data['heavy_mass_mpc']))
        if self.fields==2:
            with np.load(SOURCE/'heavy-equation-quintic.npz',allow_pickle=False) as data:
                functions,_=quintic_functions(data)
                self.functions.append(functions)
        self.unknown=np.array([2,3] if case=='heavy' else [self.dimension-1])
        self.project_rows=np.array([3,4] if case=='heavy' else [3*self.fields])

    def coefficients(self,clock):
        clocks=np.atleast_1d(clock)
        scale=np.asarray(self.expansion(clocks))
        hubble=np.asarray(self.hubble(clocks))
        require(np.all(scale>0) and np.all(hubble>0),'positive retained background')
        count=len(clocks)
        matrix=np.zeros((count,self.dimension,self.dimension))
        forcing=np.zeros((count,self.dimension))
        density_row=np.zeros((count,self.dimension))
        source_rows=np.zeros((count,3*self.fields+1,self.dimension))
        for component,(mass,functions) in enumerate(zip(self.masses,self.functions)):
            field=functions[0](np.log(scale))
            velocity=functions[1](np.log(scale))
            mass2=(scale*mass)**2
            index=2*component
            matrix[:,index,index+1]=1.
            matrix[:,index+1,index]=-(1+mass2)
            matrix[:,index+1,index+1]=-2*hubble
            forcing[:,index+1]=-velocity
            density_row[:,index]=mass2*field
            density_row[:,index+1]=velocity
            source_rows[:,3*component,index]=mass2*field
            source_rows[:,3*component,index+1]=velocity
            source_rows[:,3*component+1,index]=velocity
            source_rows[:,3*component+2,index]=-mass2*field
            source_rows[:,3*component+2,index+1]=velocity
        density_row[:,-1]=self.cdm_constant/scale
        forcing[:,-1]=-1.
        source_rows[:,-1,-1]=self.cdm_constant/scale
        matrix+=forcing[:,:,None]*density_row[:,None,:]/(2*hubble[:,None,None])
        rest=(self.rest_density(clocks)/2+self.eta(clocks))/hubble
        matrix=matrix*self.scale[None,None,:]/self.scale[None,:,None]
        forcing=forcing/self.scale[None,:]
        rows=source_rows*self.scale[None,None,:]*(scale/float(self.frozen['density0']))[:,None,None]
        return matrix,forcing,rest,rows

    def same_state_check(self):
        selected=self.check_indices
        matrix,forcing,rest,rows=self.coefficients(self.times[selected])
        normalized=self.reference[selected]/self.scale
        derivative=(np.einsum('tij,tj->ti',matrix,normalized)+forcing*rest[:,None])*self.scale
        recovered=np.einsum('tij,tj->ti',rows,normalized)
        derivative_checks=columns(derivative,self.reference_derivative[selected],self.names,ALGEBRA)
        source_checks=columns(recovered,self.saved['sources'][selected],self.source_names,ALGEBRA)
        return dict(passed=all(row['passed'] for row in list(derivative_checks.values())+list(source_checks.values())),derivative=derivative_checks,sources=source_checks)
