from response_model import *
import sympy as sp


def prove():
    rows=sp.symbols('a b c d e f',real=True)
    source0,source1,known0,known1,known_pressure=sp.symbols('Y0 Y1 h0 h1 hP')
    matrix=sp.Matrix([[rows[0],rows[1]],[rows[2],rows[3]]])
    pressure_row=sp.Matrix([[rows[4],rows[5]]])
    inverse=matrix.inv()
    state=inverse*sp.Matrix([source0-known0,source1-known1])
    coefficient=pressure_row*inverse
    predicted=known_pressure+(coefficient*sp.Matrix([source0-known0,source1-known1]))[0]
    checks=dict(projection_recovery=all(sp.simplify(value)==0 for value in matrix*state-sp.Matrix([source0-known0,source1-known1])),pressure_elimination=sp.simplify(predicted-known_pressure-(pressure_row*state)[0])==0)
    wave,hubble,velocity,field,mass2,mode,mode_velocity,cold_density,cold_delta,rest=sp.symbols('k H v b mu2 u w Rc dc zrest',nonzero=True)
    density=velocity*mode_velocity+mass2*field*mode+cold_density*cold_delta
    live=rest+density/(2*wave*hubble)
    scalar_first=-2*hubble*mode_velocity-(wave**2+mass2)*mode-wave*velocity*live
    block_first=-(wave**2+mass2)*mode-2*hubble*mode_velocity-velocity*density/(2*hubble)-wave*velocity*rest
    checks['scalar_density_feedback']=sp.simplify(scalar_first-block_first)==0
    checks['dust_density_feedback']=sp.simplify(-wave*live+cold_density*cold_delta/(2*hubble)+(velocity*mode_velocity+mass2*field*mode)/(2*hubble)+wave*rest)==0
    return checks


def packet_path(case,variant,report):
    return ROOT/report.get('packet_name',case+'-response-'+variant+'.npz')


def main():
    with worker('derive-closure'):
        identities=prove()
        require(all(identities.values()),'exact response/pressure elimination')
        results={}
        for case,report_name in [('cold','cold-response-result.json'),('heavy','heavy-response-resume-result.json')]:
            report=read(ROOT/report_name)
            require(report['completed'] and report['forward_passed'] and report['inverse_passed'],'paired forward/inverse calculations')
            context=Response(case,1)
            packets={}
            closure={}
            for variant,entry in report['runs'].items():
                path=packet_path(case,variant,entry)
                require(digest(path)==entry['packet_sha256'],'verified response packet')
                with np.load(path,allow_pickle=False) as data:
                    packet={name:data[name].copy() for name in data.files}
                packets[variant]=packet
                selected=packet['selected_rows']
                unknown=packet['unknown']
                full=packet['projection_response']
                block=full[np.ix_(selected,unknown)]
                pressure_index=5 if case=='heavy' else None
                if pressure_index is not None:
                    coefficient=np.linalg.solve(block.T,full[pressure_index,unknown])
                    offset=packet['known_projection'][pressure_index]-coefficient@packet['known_projection'][selected]
                    prediction=float(coefficient@packet['reference_projection'][selected]+offset)
                    reference=float(packet['reference_projection'][pressure_index])
                    check=comparison(prediction,reference)
                    no_history=comparison(float(coefficient@packet['reference_projection'][selected]),reference)
                    delta=np.array([.01,-.015])
                    perturbed=packet['initial'].copy()
                    perturbed[unknown]+=delta
                    direct=full@perturbed+packet['projected_forcing']
                    reconstructed=float(coefficient@direct[selected]+offset)
                    linear_control=comparison(reconstructed,float(direct[pressure_index]),ALGEBRA)
                    require(check['passed'] and linear_control['passed'],'pressure from D/Q with independent response column control')
                    closure[variant]=dict(coefficients=coefficient.tolist(),history_offset=float(offset),prediction=prediction,reference=reference,check=check,omitting_history=no_history,linear_response_control=linear_control,pressure_used_as_input=False)
            fine=packets['fineT-order8']
            matrix=fine['conditioned_response']
            selected=fine['selected_rows']
            unknown=fine['unknown']
            row_scale=fine['row_scale']
            fine_initial=fine['recovered_initial'][unknown]
            refinements={}
            for name,variant in [('fundamental','coarseT-order8'),('quadrature','fineT-order4'),('history','coarseHistory-order8')]:
                packet=packets[variant]
                changed=packet['projection_response'][np.ix_(selected,unknown)]/row_scale[:,None]
                delta_matrix=changed-matrix
                delta_known=(packet['known_projection'][selected]-fine['known_projection'][selected])/row_scale
                changed_initial=packet['recovered_initial'][unknown]
                measured=changed_initial-fine_initial
                predicted=-np.linalg.solve(matrix,delta_matrix@changed_initial+delta_known)
                matrix_bound=float(np.linalg.norm(np.linalg.solve(matrix,delta_matrix),ord=np.inf))
                forcing_bound=float(np.linalg.norm(np.linalg.solve(matrix,delta_known),ord=np.inf))
                action_bound=float(np.linalg.norm(np.linalg.solve(matrix,delta_matrix@fine_initial),ord=np.inf))
                require(matrix_bound<1,'measured refinement remains inside inverse stability radius')
                bound=(forcing_bound+action_bound)/(1-matrix_bound)
                rounding=32*np.finfo(float).eps*max(1.,float(np.max(abs(fine_initial))))*float(np.linalg.cond(matrix))
                require(np.max(abs(measured))<=bound+rounding,'conditional finite-refinement inverse bound')
                identity_error=float(np.max(abs(measured-predicted)))
                require(identity_error<=rounding,'affine inverse error attribution up to explicit roundoff')
                state_checks=columns(packet['state'],fine['state'],context.names)
                source_checks=columns(packet['sources'],fine['sources'],context.source_names)
                projection_checks=columns(packet['projected_sources'][None,:],fine['projected_sources'][None,:],context.source_names)
                require(all(row['passed'] for group in (state_checks,source_checks,projection_checks) for row in group.values()),'same gates for all refinement comparisons')
                refinements[name]=dict(state=state_checks,sources=source_checks,projection=projection_checks,measured_seed_change=measured.tolist(),predicted_seed_change=predicted.tolist(),matrix_inverse_perturbation_norm=matrix_bound,known_history_inverse_perturbation_norm=forcing_bound,conditional_seed_change_bound=bound,rounding_allowance=rounding,inverse_identity_error=identity_error)
            target=fine['reference_projection'][selected]
            known=fine['known_projection'][selected]
            remainder=target-known
            cancellation=np.divide(abs(target)+abs(known),abs(remainder),out=np.full_like(remainder,np.inf),where=remainder!=0)
            require(np.isfinite(cancellation).all(),'finite projected initial-state signal')
            results[case]=dict(passed=True,refinements=refinements,closure=closure,unknown_dimension=len(unknown),scaled_condition=float(np.linalg.cond(matrix)),raw_response_condition=float(np.linalg.cond(fine['projection_response'][np.ix_(selected,unknown)])),rhs_cancellation_ratios=cancellation.tolist(),reference_initial=fine['initial'].tolist(),recovered_initial=fine['recovered_initial'].tolist())
            print(json.dumps(dict(case=case,condition=results[case]['scaled_condition'],rhs_cancellation=cancellation.tolist(),fine_closure=closure.get('fineT-order8'),maximum_inverse_sensitivity=max(float(np.max(abs(row['measured_seed_change']))) for row in refinements.values()))),flush=True)
        write('derived-closure.json',dict(passed=True,identities=identities,cases=results,closure_is_history_dependent=True,universal_local_sound_speed_law=False,paired_full_reduced_evolution=False))


if __name__=='__main__':
    main()
