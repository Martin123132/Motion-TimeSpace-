from response_model import *
from derive_closure import prove,packet_path
from numpy.polynomial.legendre import leggauss
import argparse


def fundamental_checks(context,packet):
    times=context.times
    fundamental=packet['fundamental']
    matrix,_,_,_=context.coefficients(times)
    expected=np.einsum('tij,tjk->tik',matrix,fundamental)
    indices=np.arange(3,len(times)-3)
    actual=[]
    for index in indices:
        local=times[index-3:index+4]-times[index]
        width=max(abs(local))
        vandermonde=np.array([(local/width)**power for power in range(7)])
        target=np.zeros(7)
        target[1]=1.
        weights=np.linalg.solve(vandermonde,target)/width
        actual.append(np.einsum('t,tij->ij',weights,fundamental[index-3:index+4]))
    actual=np.array(actual)
    rows=columns(actual.reshape(len(indices),-1),expected[indices].reshape(len(indices),-1),['matrix_'+str(index) for index in range(context.dimension**2)])
    nodes,weights=leggauss(8)
    half=np.diff(times)/2
    clocks=((times[:-1]+times[1:])[:,None]/2+half[:,None]*nodes).ravel()
    coefficients,_,_,_=context.coefficients(clocks)
    traces=np.trace(coefficients,axis1=1,axis2=2).reshape(-1,8)
    integrated=np.r_[0.,np.cumsum(half*(traces@weights))]
    signs,logdet=np.linalg.slogdet(fundamental)
    require(np.all(signs>0),'nonsingular positive fundamental determinant')
    rows['liouville']=comparison(logdet,integrated)
    return rows


def validate():
    all_checks={}
    summaries={}
    closure=read(ROOT/'derived-closure.json')
    require(closure['passed'] and closure['closure_is_history_dependent'] and not closure['paired_full_reduced_evolution'],'correct conditional scientific scope')
    for case,report_name in [('cold','cold-response-result.json'),('heavy','heavy-response-resume-result.json')]:
        report=read(ROOT/report_name)
        require(report['completed'] and report['forward_passed'] and report['inverse_passed'],'successful paired response/inverse')
        check_hashes(report['source_hashes'])
        for variant,run in report['runs'].items():
            context=Response(case,run['stride'])
            path=packet_path(case,variant,run)
            require(digest(path)==run['packet_sha256'],'response packet checksum')
            with np.load(path,allow_pickle=False) as data:
                packet={name:data[name].copy() for name in data.files}
            require(np.array_equal(packet['clock'],context.times),'same original 902 output epochs')
            require(np.array_equal(packet['initial'],context.reference[0]/context.scale),'retained initial physical seed')
            require(np.array_equal(packet['normalization'],context.scale),'declared numerical similarity scales')
            algebra=context.same_state_check()
            require(algebra['passed'],'same-state native source block')
            initial=packet['initial']
            particular=np.einsum('tij,tj->ti',packet['fundamental'],packet['accumulated'])
            homogeneous=np.einsum('tij,j->ti',packet['fundamental'],initial)
            state=(homogeneous+particular)*context.scale
            require(np.array_equal(state,packet['state']),'retarded superposition recomputed')
            require(np.array_equal(packet['accumulated'][1:],np.cumsum(packet['integral_increments'],axis=0)),'retarded cumulative integrals')
            _,_,_,rows=context.coefficients(context.times)
            sources=np.einsum('tij,tj->ti',rows,homogeneous+particular)
            projected=context.frozen['weights']@sources
            reference_projection=context.frozen['weights']@context.saved['sources']
            checks=dict(state=columns(state,context.reference,context.names),sources=columns(sources,context.saved['sources'],context.source_names),projection=columns(projected[None,:],reference_projection[None,:],context.source_names))
            require(checks==run['checks'],'all forward numerical comparisons independently recomputed')
            full=np.einsum('t,tij,tjk->ik',context.frozen['weights'],rows,packet['fundamental'])
            forced=context.frozen['weights']@np.einsum('tij,tj->ti',rows,particular)
            require(np.array_equal(full,packet['projection_response']) and np.array_equal(forced,packet['projected_forcing']),'projection operator and history term recomputed')
            unknown,selected=context.unknown,context.project_rows
            raw=full[np.ix_(selected,unknown)]
            row_scale=np.max(abs(raw),axis=1)
            conditioned=raw/row_scale[:,None]
            singular=np.linalg.svd(conditioned,compute_uv=False)
            rank=int(np.count_nonzero(singular>singular[0]*len(unknown)*np.finfo(float).eps))
            require(rank==len(unknown) and rank==run['rank'],'actual physical projection rank')
            require(np.array_equal(conditioned,packet['conditioned_response']),'same conditioned response')
            known=initial.copy()
            known[unknown]=0.
            known_projected=full@known+forced
            recovered=known.copy()
            recovered[unknown]=np.linalg.solve(conditioned,(reference_projection[selected]-known_projected[selected])/row_scale)
            inverse_state=(np.einsum('tij,j->ti',packet['fundamental'],recovered)+particular)*context.scale
            inverse_projected=full@recovered+forced
            inverse=dict(seed=dict(passed=bool(np.max(abs(recovered-initial))<=GATE),normalized_absolute_max=float(np.max(abs(recovered-initial))),gate=GATE),state=columns(inverse_state,context.reference,context.names),projection=columns(inverse_projected[None,:],reference_projection[None,:],context.source_names))
            require(inverse==run['inverse_checks'],'all inverse comparisons independently recomputed')
            require(not run['pressure_used_for_inverse'] and run['rest_history_supplied'] and not run['new_full_reduced_coupled_run'],'no pressure target or hidden full-coupling claim')
            prefix=case+'/'+variant
            all_checks.update({prefix+'/'+group+'/'+name:row for group,group_checks in checks.items() for name,row in group_checks.items()})
            all_checks.update({prefix+'/inverse/'+group+'/'+name:row for group in ('state','projection') for name,row in inverse[group].items()})
            all_checks[prefix+'/inverse/seed']=dict(passed=inverse['seed']['passed'])
            all_checks.update({prefix+'/native/'+group+'/'+name:row for group in ('derivative','sources') for name,row in algebra[group].items()})
            transport=fundamental_checks(context,packet)
            all_checks.update({prefix+'/fundamental/'+name:row for name,row in transport.items()})
            if case=='heavy':
                coefficient=np.linalg.solve(raw.T,full[5,unknown])
                history=known_projected[5]-coefficient@known_projected[selected]
                pressure=float(coefficient@reference_projection[selected]+history)
                recorded=closure['cases'][case]['closure'][variant]
                require(np.array_equal(coefficient,recorded['coefficients']) and history==recorded['history_offset'],'derived pressure coefficients/history')
                all_checks[prefix+'/pressure_elimination']=comparison(pressure,float(reference_projection[5]))
                require(not recorded['pressure_used_as_input'],'pressure held out of reconstruction')
            summaries[prefix]=dict(condition=run['condition'],rank=rank,worst_state=max(row['normalized'] or 0 for row in checks['state'].values()),fundamental_derivative_worst=max(row['normalized'] or 0 for row in transport.values()),inverse_seed_error=inverse['seed']['normalized_absolute_max'])
    identities=prove()
    require(all(identities.values()) and identities==closure['identities'],'exact symbolic pressure/source derivation')
    require(all(row['passed'] for row in all_checks.values()),'all derived response, history and inverse checks')
    return dict(passed=True,checks=all_checks,summaries=summaries,identities=identities)


def cleanup(exclude):
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        label=path.name.removesuffix('-start.json')
        if label==exclude:
            continue
        require((ROOT/(label+'-end.json')).exists(),'terminal worker receipt')
        identity=read(path)
        outcome=exited(identity)
        require(outcome['exited'],'owned process exited '+label)
        workers.append(dict(name=label,identity=identity,state=read(ROOT/(label+'-end.json'))['state'],outcome=outcome))
    return workers


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=('validate','seal','postseal'))
    args=parser.parse_args()
    with worker(args.mode):
        if args.mode=='validate':
            check_hashes(read(ROOT/'frozen-inputs.json'))
            for path in ROOT.glob('*.py'):
                compile(path.read_text(),str(path),'exec')
            require(not list(ROOT.rglob('__pycache__')),'no cache residue')
            result=validate()
            result['workers']=cleanup('validate')
            write('validation.json',result)
            print(json.dumps(dict(passed=True,checks=len(result['checks']),identities=len(result['identities']),workers=len(result['workers']))),flush=True)
        elif args.mode=='seal':
            require(read(ROOT/'validation.json')['passed'],'validation passed')
            artifacts={str(path.relative_to(ROOT)):dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('seal-start.json','seal-end.json')}
            write('closeout.json',dict(implementation_validated=True,paired_retarded_response_passed=True,projection_state_identifiability_passed=True,history_dependent_pressure_derived=True,saved_rest_history_required=True,window_specific_pressure_relation=True,pressure_fitted=False,fully_reduced_live_continuation_passed=False,positive_ensemble_preparation_derived=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts,workers=cleanup('seal')))
            print(json.dumps(dict(sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)
        else:
            seal=read(ROOT/'closeout.json')
            check_hashes({str(ROOT/name):row['sha256'] for name,row in seal['artifacts'].items()})
            check_hashes(seal['input_hashes'])
            workers=cleanup('postseal')
            write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=read(ROOT/'postseal-start.json'),verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
            print(json.dumps(dict(passed=True,sha256=digest(ROOT/'closeout.json'),workers=len(workers))),flush=True)


if __name__=='__main__':
    main()
