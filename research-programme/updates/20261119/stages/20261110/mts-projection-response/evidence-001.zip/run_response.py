from response_model import *
from scipy.integrate import solve_ivp
from numpy.polynomial.legendre import leggauss
import argparse


def evaluate_kernel(context,solution,order):
    nodes,weights=leggauss(order)
    midpoints=(context.times[:-1]+context.times[1:])/2
    halfwidth=np.diff(context.times)/2
    clocks=(midpoints[:,None]+halfwidth[:,None]*nodes).ravel()
    matrices=solution.sol(clocks).T.reshape(-1,context.dimension,context.dimension)
    _,forcing,rest,_=context.coefficients(clocks)
    integrands=np.linalg.solve(matrices,(forcing*rest[:,None])[:,:,None])[:,:,0]
    inverse_residual=np.einsum('tij,tj->ti',matrices,integrands)-forcing*rest[:,None]
    inverse_scale=np.max(abs(forcing*rest[:,None]))
    require(np.max(abs(inverse_residual))<=ALGEBRA*inverse_scale,'retarded fundamental inverse residual')
    increments=np.einsum('iqd,q,i->id',integrands.reshape(len(midpoints),order,context.dimension),weights,halfwidth)
    accumulated=np.vstack([np.zeros(context.dimension),np.cumsum(increments,axis=0)])
    fundamental=solution.sol(context.times).T.reshape(-1,context.dimension,context.dimension)
    initial=context.reference[0]/context.scale
    particular=np.einsum('tij,tj->ti',fundamental,accumulated)
    homogeneous=np.einsum('tij,j->ti',fundamental,initial)
    normalized=homogeneous+particular
    _,_,_,rows=context.coefficients(context.times)
    sources=np.einsum('tij,tj->ti',rows,normalized)
    source_forcing=np.einsum('tij,tj->ti',rows,particular)
    projection=np.einsum('t,tij,tjk->ik',context.frozen['weights'],rows,fundamental)
    projected_forcing=context.frozen['weights']@source_forcing
    projected_sources=context.frozen['weights']@sources
    reference_projection=context.frozen['weights']@context.saved['sources']
    state=normalized*context.scale
    checks=dict(state=columns(state,context.reference,context.names),sources=columns(sources,context.saved['sources'],context.source_names),projection=columns(projected_sources[None,:],reference_projection[None,:],context.source_names))
    pressure_mode={}
    if context.case=='heavy':
        error=abs(projected_sources[5]-reference_projection[5])
        pressure_mode=dict(passed=error<=PRESSURE_GATE*float(context.frozen['original_norm']),absolute_error=float(error),over_original_norm=float(error/float(context.frozen['original_norm'])),gate=PRESSURE_GATE,pressure_relative=float(error/abs(reference_projection[5])))
    unknown=context.unknown
    selected=context.project_rows
    response=projection[np.ix_(selected,unknown)]
    row_scale=np.max(abs(response),axis=1)
    require(np.all(row_scale>0),'nonzero projection response rows')
    conditioned=response/row_scale[:,None]
    singular=np.linalg.svd(conditioned,compute_uv=False)
    rank=int(np.count_nonzero(singular>singular[0]*max(conditioned.shape)*np.finfo(float).eps))
    condition=float(np.linalg.cond(conditioned))
    require(rank==len(unknown) and condition*np.finfo(float).eps<ALGEBRA/10,'identified and numerically invertible projected physical block')
    known_initial=initial.copy()
    known_initial[unknown]=0.
    known_projection=projection@known_initial+projected_forcing
    recovered_unknown=np.linalg.solve(conditioned,(reference_projection[selected]-known_projection[selected])/row_scale)
    recovered_initial=known_initial.copy()
    recovered_initial[unknown]=recovered_unknown
    inverse_state=(np.einsum('tij,j->ti',fundamental,recovered_initial)+particular)*context.scale
    inverse_projection=projection@recovered_initial+projected_forcing
    inverse_checks=dict(seed=dict(passed=bool(np.max(abs(recovered_initial-initial))<=GATE),normalized_absolute_max=float(np.max(abs(recovered_initial-initial))),gate=GATE),state=columns(inverse_state,context.reference,context.names),projection=columns(inverse_projection[None,:],reference_projection[None,:],context.source_names))
    controls=[]
    for index in range(len(unknown)):
        kick=np.zeros(len(unknown))
        kick[index]=[.01,-.015][index]
        target=response@kick
        recovered=np.linalg.solve(conditioned,target/row_scale)
        controls.append(comparison(recovered,kick,ALGEBRA))
    packet=dict(clock=context.times,state=state,reference=context.reference,source_rows=rows,sources=sources,reference_sources=context.saved['sources'],fundamental=fundamental,particular=particular,homogeneous=homogeneous,initial=initial,accumulated=accumulated,integral_increments=increments,projection_response=projection,projected_forcing=projected_forcing,projected_sources=projected_sources,reference_projection=reference_projection,known_projection=known_projection,conditioned_response=conditioned,row_scale=row_scale,singular_values=singular,recovered_initial=recovered_initial,inverse_state=inverse_state,inverse_projection=inverse_projection,unknown=unknown,selected_rows=selected,normalization=context.scale)
    passed=all(row['passed'] for group in checks.values() for row in group.values()) and (not pressure_mode or pressure_mode['passed'])
    inverse_passed=inverse_checks['seed']['passed'] and all(row['passed'] for group in ('state','projection') for row in inverse_checks[group].values())
    report=dict(passed=passed,inverse_passed=inverse_passed,checks=checks,inverse_checks=inverse_checks,pressure_mode=pressure_mode,rank=rank,condition=condition,singular_values=singular.tolist(),unit_column_controls=controls,fundamental_condition_max=float(np.max(np.linalg.cond(fundamental))),retarded_inverse_residual=float(np.max(abs(inverse_residual))/inverse_scale),source_projection_used_for_inverse=[context.source_names[index] for index in selected],pressure_used_for_inverse=False,rest_history_supplied=True,new_full_reduced_coupled_run=False)
    return packet,report


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=('cold','heavy'))
    args=parser.parse_args()
    label=args.case+'-response'
    with worker(label):
        contract=read(ROOT/'contract.json')
        sources={str(path):digest(path) for path in (Path(__file__),ROOT/'response_model.py',ROOT/'response_support.py',ROOT/'contract.json',PREVIOUS/(args.case+'-transfer-source-readout.npz'),PREVIOUS/(args.case+'-transfer-capture.npz'),HANDOFF/('early-'+args.case+'-restart.npz'),PROJECTION/'frozen-projection.npz',BACKGROUND/(args.case+'-candidate-background.npz'),SOURCE/'heavy-equation-quintic.npz',SOURCE/'quintic_model.py')}
        write(label+'-frozen.json',sources)
        results={}
        for config in contract['configs']:
            context=Response(args.case,config['stride'])
            algebra=context.same_state_check()
            write(label+'-'+config['name']+'-algebra.json',algebra)
            require(algebra['passed'],'source block reproduces same-state native equations')
            calls=0

            def rhs(clock,flat):
                nonlocal calls
                calls+=1
                if calls%32==0:
                    guard()
                matrix,_,_,_=context.coefficients(clock)
                return (matrix[0]@flat.reshape(context.dimension,context.dimension)).ravel()

            solution=solve_ivp(rhs,(context.times[0],context.times[-1]),np.eye(context.dimension).ravel(),method='DOP853',rtol=config['rtol'],atol=config['rtol']*.01,max_step=(context.times[-1]-context.times[0])/config['maximum_steps'],dense_output=True)
            require(solution.success,'completed action-derived fundamental matrix')
            for order in config['orders']:
                variant=config['name']+'-order'+str(order)
                packet,report=evaluate_kernel(context,solution,order)
                destination=ROOT/(label+'-'+variant+'.npz')
                np.savez_compressed(destination,**packet)
                report.update(packet_sha256=digest(destination),evaluations=solution.nfev,stride=config['stride'],maximum_steps=config['maximum_steps'],rtol=config['rtol'],order=order,source_names=context.source_names,state_names=context.names)
                results[variant]=report
                print(json.dumps(dict(case=args.case,variant=variant,passed=report['passed'],inverse_passed=report['inverse_passed'],condition=report['condition'],seed_error=report['inverse_checks']['seed']['normalized_absolute_max'],worst_state=max(row['normalized'] or 0 for row in report['checks']['state'].values()),pressure=report['pressure_mode'])),flush=True)
        check_hashes(sources)
        write(label+'-result.json',dict(completed=True,forward_passed=all(row['passed'] for row in results.values()),inverse_passed=all(row['inverse_passed'] for row in results.values()),runs=results,source_hashes=sources))


if __name__=='__main__':
    main()
