from response_support import *
import ast


def main():
    source=ROOT/'derive_closure.py'
    changes=[]

    class Adapt(ast.NodeTransformer):
        def visit_Call(self,node):
            if isinstance(node.func,ast.Name) and node.func.id=='abs' and len(node.args)==1 and ast.unparse(node.args[0])=="row['measured_seed_change']":
                node.args[0]=ast.Call(func=ast.Attribute(value=ast.Name(id='np',ctx=ast.Load()),attr='asarray',ctx=ast.Load()),args=[node.args[0]],keywords=[])
                changes.append('list_display')
                return node
            if isinstance(node.func,ast.Name) and node.func.id=='worker' and len(node.args)==1 and isinstance(node.args[0],ast.Constant) and node.args[0].value=='derive-closure':
                node.args[0]=ast.Constant('derive-closure-checked')
                changes.append('receipt')
            return self.generic_visit(node)

    tree=Adapt().visit(ast.parse(source.read_text()))
    require(changes==['receipt','list_display'],'display-only closure adapter')
    namespace=dict(__file__=__file__,__name__='closure_display_checked')
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()


if __name__=='__main__':
    main()
