from response_support import *


def main():
    with worker('freeze-response'):
        require(digest(PREVIOUS/'closeout.json')==EXPECTED,'latest transfer stage')
        seal=read(PREVIOUS/'closeout.json')
        require(seal['paired_finite_support_transfer_passed'] and not seal['projected_state_identifiability_tested'],'previous scientific distinction')
        mapping=dict(seal['input_hashes'])
        mapping.update({str(PREVIOUS/name):row['sha256'] for name,row in seal['artifacts'].items()})
        mapping[str(PREVIOUS/'closeout.json')]=EXPECTED
        check_hashes(mapping)
        cleanup=read(PREVIOUS/'CLEANUP-VERIFIED.json')
        require(cleanup['passed'] and exited(cleanup['verifier_identity'])['exited'],'previous verifier exited')
        require(all(exited(row['identity'])['exited'] for row in cleanup['workers']),'previous workers exited')
        report=dict(previous_goal_turn='verified progress: derived and tested finite-support source transfer',gate=GATE,algebra=ALGEBRA,pressure_mode_gate=PRESSURE_GATE,cases=['cold','heavy'],wave=1.,support=[1991,2892],block='all retained real scalars plus synchronous CDM density; eta and remaining species form supplied rest history',unknown_seed=dict(cold=['cdm_delta'],heavy=['u_h','w_h']),known_seeds='all remaining retained initial coordinates',source_projection='same original 902 signed weights',source_equations_unchanged=True,rest_history_is_supplied=True,configs=[dict(name='coarseT',stride=1,maximum_steps=512,rtol=4e-11,orders=[8]),dict(name='fineT',stride=1,maximum_steps=1024,rtol=1e-11,orders=[4,8]),dict(name='coarseHistory',stride=2,maximum_steps=1024,rtol=1e-11,orders=[8])],normalized_atol_ratio=.01,similarity_scale='per-coordinate maximum absolute saved physical state; numerical units only',row_scale='maximum absolute response in each unknown-seed projection row',inverse_control_perturbation=[.01,-.015],physical_or_pressure_fits=False,prospective_observational_test=False)
        write('contract.json',report)
        write('frozen-inputs.json',mapping)
        print(json.dumps(dict(frozen=True,verified_inputs=len(mapping),configs=report['configs'])),flush=True)


if __name__=='__main__':
    main()
