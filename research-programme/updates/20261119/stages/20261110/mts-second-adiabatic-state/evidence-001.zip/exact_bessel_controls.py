import os
import sys
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
import json
import hashlib
import time
from pathlib import Path
from fractions import Fraction
from datetime import datetime, timezone
import numpy as np
import mpmath as mp
import psutil

ROOT = Path(__file__).resolve().parent
SAVED = ROOT.parent / "mts-formation-state-bundle-20261110"
START = time.monotonic()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, data):
    with (ROOT / name).open("x") as stream:
        json.dump(data, stream, indent=2, allow_nan=False)


def fraction_value(text):
    fraction = Fraction(text)
    return mp.mpf(fraction.numerator) / fraction.denominator


def spectral_norm(matrix):
    gram = matrix.T * matrix
    largest = (gram[0, 0] + gram[1, 1] + mp.sqrt((gram[0, 0] - gram[1, 1])**2 + 4 * gram[0, 1]**2)) / 2
    return mp.sqrt(max(largest, mp.mpf(0)))


def bessel_frame(mu_initial, hubble, wave, position):
    argument = mu_initial * mp.exp(position) / hubble
    order = mp.sqrt(1 - (wave / hubble)**2)
    normalization = mp.sqrt(mp.pi / (2 * hubble))
    first, second = mp.besselj(order, argument), mp.bessely(order, argument)
    first_prime = (mp.besselj(order - 1, argument) - mp.besselj(order + 1, argument)) / 2
    second_prime = (mp.bessely(order - 1, argument) - mp.bessely(order + 1, argument)) / 2
    return normalization * mp.matrix([[first, second],
                                     [hubble * argument * first_prime, hubble * argument * second_prime]])


def frequency(mu_initial, hubble, wave, position, order):
    mu = mu_initial * mp.exp(position)
    gradient = (wave / mu)**2
    adiabatic = (hubble / mu)**2
    root = mp.sqrt(1 + gradient)
    if order == 0:
        return mu * root, 1 / (1 + gradient)
    polynomial = 3 + 12 * gradient + 4 * gradient**2
    denominator = 8 * (1 + gradient)**3 - adiabatic * polynomial
    derivative_gradient = 24 * (1 + gradient)**2 - adiabatic * (12 + 8 * gradient)
    derivative_adiabatic = -polynomial
    log_rate = 1 + 5 * gradient / (1 + gradient) - 2 * (
        gradient * derivative_gradient + adiabatic * derivative_adiabatic) / denominator
    return mu * denominator / (8 * (1 + gradient)**mp.mpf("2.5")), log_rate


def approximate_frame(mu, hubble, wave, position, order):
    value, log_rate = frequency(mu, hubble, wave, position, order)
    phase = mp.quad(lambda location: frequency(mu, hubble, wave, location, order)[0] / hubble, [0, position]) if position else mp.mpf(0)
    root = mp.sqrt(value)
    cosine, sine = mp.cos(phase), mp.sin(phase)
    slope = -hubble * log_rate / 2
    return mp.matrix([[cosine / root, sine / root],
                      [slope * cosine / root - root * sine, slope * sine / root + root * cosine]])


def main():
    worker = psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
    write("exact-control-start.json", identity)
    try:
        mp.mp.dps = 80
        proof = json.loads((ROOT / "proof.json").read_text())
        with np.load(SAVED / "late-heavy.npz") as packet:
            columns, values = packet["columns"].tolist(), packet["values"]
        selected = values[values[:, columns.index("nominal_a")] == .01]
        probes = [(0.0, 0)]
        for target in (1e-5, .001):
            index = int(np.argmin(abs(selected[:, columns.index("k_Mpc_inverse")] - target)))
            probes.append((float(selected[index, columns.index("k_Mpc_inverse")]), index))
        span = mp.mpf(.001)
        results = []
        for wave_float, index in probes:
            if time.monotonic() - START > 900:
                raise RuntimeError("bounded exact-control run")
            row = selected[index]
            mu = mp.mpf(float(row[columns.index("a")])) * mp.mpf(float(row[columns.index("test_mass_Mpc_inverse")]))
            hubble = mp.mpf(float(row[columns.index("H_conformal_Mpc_inverse")]))
            wave = mp.mpf(wave_float)
            if wave > hubble:
                raise ValueError("preselected exact-control Bessel order is not real")
            start, end = bessel_frame(mu, hubble, wave, mp.mpf(0)), bessel_frame(mu, hubble, wave, span)
            exact_transport = end * start**-1
            wronskian = max(abs(mp.det(start) - 1), abs(mp.det(end) - 1), abs(mp.det(exact_transport) - 1))
            if wronskian > mp.mpf("1e-60"):
                raise ValueError("exact reference precision")
            record = dict(k=wave_float, mu=mp.nstr(mu, 50), H=mp.nstr(hubble, 50), wronskian_error=mp.nstr(wronskian, 12), orders=[])
            for order, key in ((0, "solution_error_zeroth_upper"), (2, "solution_error_second_upper")):
                first = approximate_frame(mu, hubble, wave, mp.mpf(0), order)
                last = approximate_frame(mu, hubble, wave, span, order)
                coefficient_map = last**-1 * exact_transport * first
                difference = coefficient_map - mp.eye(2)
                error = spectral_norm(difference)
                mixing = abs((difference[0, 0] - difference[1, 1] + 1j * (difference[1, 0] + difference[0, 1])) / 2)
                bound = fraction_value(proof["certificate"][key])
                if error > bound or mixing > bound:
                    raise ValueError("analytic certificate contradicted")
                record["orders"].append(dict(order=order, coefficient_norm_error=mp.nstr(error, 30),
                    mixing_modulus=mp.nstr(mixing, 30), analytical_upper_bound=mp.nstr(bound, 30)))
            results.append(record)
        output = dict(passed=True, precision_digits=80, mpmath_version=mp.__version__, probes=results,
            same_exact_operator_for_both_orders=True, probe_choice_fixed_by_control_plan=True,
            proof_sha256=digest(ROOT / "proof.json"), code_sha256=digest(__file__),
            does_not_certify_binary64_implementation_to_analytic_order=True)
        write("exact-controls.json", output)
        write("exact-control-end.json", dict(**identity, state="completed", result_sha256=digest(ROOT / "exact-controls.json")))
        print(json.dumps(results))
    except Exception as error:
        write("exact-control-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
