import os
import sys
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
import json
import hashlib
from pathlib import Path
from fractions import Fraction
from datetime import datetime, timezone
import numpy as np
import sympy as sym
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / "mts-averaged-state-action-20261110"
SAVED = POST / "mts-formation-state-bundle-20261110"


def digest(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            checksum.update(block)
    return checksum.hexdigest()


def write(name, data):
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, allow_nan=False)


def formulae():
    gradient, adiabatic = sym.symbols("gradient adiabatic", nonnegative=True)
    polynomial = 3 + 12 * gradient + 4 * gradient**2
    denominator = 8 * (1 + gradient)**3 - adiabatic * polynomial
    squared_frequency = denominator**2 / (64 * (1 + gradient)**5)
    log_rate = sym.factor(1 + 5 * gradient / (1 + gradient) -
        2 * (gradient * sym.diff(denominator, gradient) + adiabatic * sym.diff(denominator, adiabatic)) / denominator)
    residual = sym.factor(1 + gradient - adiabatic - squared_frequency +
        adiabatic * (log_rate**2 / 4 + gradient * sym.diff(log_rate, gradient) +
                     adiabatic * sym.diff(log_rate, adiabatic)))
    numerator = sym.cancel(residual * 64 * (1 + gradient)**5 * denominator**2 / adiabatic**2)
    coefficients = sym.Poly(numerator, gradient, adiabatic)
    log_rate_difference = sym.factor((log_rate.subs(gradient, 0) - log_rate) / 2)
    angle, frequency, frequency_prime = sym.symbols("angle frequency frequency_prime", positive=True)
    real = sym.cos(angle) / sym.sqrt(frequency)
    imag = sym.sin(angle) / sym.sqrt(frequency)
    real_prime = -sym.sqrt(frequency) * sym.sin(angle) - frequency_prime * sym.cos(angle) / (2 * frequency**sym.Rational(3, 2))
    imag_prime = sym.sqrt(frequency) * sym.cos(angle) - frequency_prime * sym.sin(angle) / (2 * frequency**sym.Rational(3, 2))
    mixing = sym.Matrix([[sym.sin(angle) * sym.cos(angle), sym.sin(angle)**2],
                         [-sym.cos(angle)**2, -sym.sin(angle) * sym.cos(angle)]])
    identities = [
        sym.cancel(residual - adiabatic**2 * numerator / (64 * (1 + gradient)**5 * denominator**2)),
        sym.simplify(real * imag_prime - imag * real_prime - 1),
        sym.simplify(sym.trace(mixing.T * mixing) - 1),
        sym.simplify(mixing.det()),
        sym.cancel(residual.subs(adiabatic, 0)),
        sym.cancel(sym.diff(residual, adiabatic).subs(adiabatic, 0))]
    if any(value != 0 for value in identities):
        raise ValueError(identities)
    return dict(variables=[str(gradient), str(adiabatic)], denominator=str(denominator),
        logarithmic_rate=str(log_rate), gamma_over_H=str(log_rate_difference),
        numerator_terms=[[list(powers), str(coefficient)] for powers, coefficient in coefficients.terms()],
        numerator=str(numerator), residual=str(residual),
        identities=[str(value) for value in identities])


def certificate(formula, packets):
    gradient_max, adiabatic_max = Fraction(1, 80000), Fraction(1, 10**12)
    mu_min, mu_max = Fraction(1490), Fraction(1510)
    hubble_min, hubble_max = Fraction(12, 10000), Fraction(14, 10000)
    span = Fraction(1, 1000)
    rows = 0
    for packet in packets:
        with np.load(packet) as data:
            columns = data["columns"].tolist()
            selected = data["values"][data["values"][:, columns.index("nominal_a")] == .01]
        if len(selected) != 399:
            raise ValueError("retained candidate slice")
        for row in selected:
            scale = Fraction.from_float(float(row[columns.index("a")]))
            mass = Fraction.from_float(float(row[columns.index("test_mass_Mpc_inverse")]))
            mu = scale * mass
            wave = Fraction.from_float(float(row[columns.index("k_Mpc_inverse")]))
            hubble = Fraction.from_float(float(row[columns.index("H_conformal_Mpc_inverse")]))
            if not (mu_min <= mu and mu / (1 - span) <= mu_max and hubble_min <= hubble <= hubble_max and 0 < wave <= 5):
                raise ValueError("frozen physical box failed")
            if not ((wave / mu)**2 <= gradient_max and (hubble / mu)**2 <= adiabatic_max):
                raise ValueError("frozen dimensionless box failed")
            rows += 1
    polynomial_bound = 3 + 12 * gradient_max + 4 * gradient_max**2
    denominator_lower = 8 - adiabatic_max * polynomial_bound
    if denominator_lower <= 0:
        raise ValueError("positive frequency not certified")
    numerator_bound = sum(abs(Fraction(coefficient)) * gradient_max**powers[0] * adiabatic_max**powers[1]
        for powers, coefficient in formula["numerator_terms"])
    coefficient_second = numerator_bound / (64 * denominator_lower**2)
    frequency_lower_second = mu_min * (1 - adiabatic_max * polynomial_bound / 8)
    time_upper = span / hubble_min
    exponent_second = time_upper * mu_max**2 * adiabatic_max**2 * coefficient_second / frequency_lower_second
    coefficient_zeroth = 1 + 1 / (1 + gradient_max) - Fraction(5, 4) / (1 + gradient_max)**2
    exponent_zeroth = time_upper * mu_max**2 * adiabatic_max * coefficient_zeroth / mu_min
    if not (0 <= exponent_second < exponent_zeroth < 1):
        raise ValueError("certificate exponent range")
    error_second = exponent_second / (1 - exponent_second)
    error_zeroth = exponent_zeroth / (1 - exponent_zeroth)
    simple_second, simple_zeroth = Fraction(2, 10**21), Fraction(1, 10**9)
    if not (error_second <= simple_second and error_zeroth <= simple_zeroth):
        raise ValueError("simple outward certificate failed")
    return dict(verified_rows_both_models=rows, applies_to_heavy_and_homogeneous_carrier=True,
        cold_box_is_comparison_only=True, gradient_max=str(gradient_max), adiabatic_max=str(adiabatic_max),
        numerator_absolute_bound=str(numerator_bound), denominator_lower=str(denominator_lower),
        coefficient_second_upper=str(coefficient_second),
        exponent_second_upper=str(exponent_second), exponent_zeroth_upper=str(exponent_zeroth),
        solution_error_second_upper=str(error_second), solution_error_zeroth_upper=str(error_zeroth),
        simple_second_bound=str(simple_second), simple_zeroth_bound=str(simple_zeroth),
        second_bound_decimal=float(error_second), zeroth_bound_decimal=float(error_zeroth),
        coefficient_norm_only=True, numerical_rounding_not_included=True,
        background_assumption="constant conformal H on specified rectangle and interval",
        same_initial_q_and_qprime=True)


def main():
    worker = psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(),
                    started=datetime.now(timezone.utc).isoformat())
    write("proof-start.json", identity)
    try:
        sources = {}
        seal_path = PREVIOUS / "closeout.json"
        if digest(seal_path) != "5ebec9f083e826748932a89c782667d7bbd399c3e3174824c7271afee7a29cf6":
            raise ValueError("previous stage seal changed")
        seal = json.loads(seal_path.read_text())
        sources[str(seal_path)] = digest(seal_path)
        for name, value in seal["artifacts"].items():
            path = PREVIOUS / name
            if digest(path) != value["sha256"]:
                raise ValueError("previous artifact changed")
            sources[str(path)] = value["sha256"]
        for path, checksum in seal["input_hashes"].items():
            if digest(path) != checksum:
                raise ValueError("inherited input changed")
            sources[path] = checksum
        for path in ROOT.iterdir():
            if path.suffix in (".py", ".md"):
                sources[str(path)] = digest(path)
        formula = formulae()
        bounds = certificate(formula, [SAVED / "late-heavy.npz", SAVED / "late-cold.npz"])
        result = dict(passed=True, formula=formula, certificate=bounds, sources=sources)
        write("proof.json", result)
        write("proof-end.json", dict(**identity, state="completed", result_sha256=digest(ROOT / "proof.json")))
        print(json.dumps(dict(polynomial_terms=len(formula["numerator_terms"]), identities=len(formula["identities"]),
            second_bound=bounds["second_bound_decimal"], zeroth_bound=bounds["zeroth_bound_decimal"],
            gamma_over_H=formula["gamma_over_H"])))
    except Exception as error:
        write("proof-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
