import json
from fractions import Fraction
from datetime import datetime, timezone
import derive_residual_bound as base

sym = base.sym
ROOT = base.ROOT


def identities():
    mass, wave, hubble, hubble_prime = sym.symbols("mass wave hubble hubble_prime")
    background, sideband, background_prime, sideband_prime, background_second, sideband_second = sym.symbols(
        "background sideband background_prime sideband_prime background_second sideband_second", nonzero=True)
    real, imag = sym.symbols("real imag")
    slope0 = -hubble - background_prime / (2 * background)
    slopek = -hubble - sideband_prime / (2 * sideband)
    denominator = background**2 + mass**2 + slope0**2
    gamma = (background_prime / background - sideband_prime / sideband) / 2
    beat = sideband - background
    derivative_variables = ((mass, hubble * mass), (hubble, hubble_prime),
        (background, background_prime), (sideband, sideband_prime),
        (background_prime, background_second), (sideband_prime, sideband_second),
        (real, gamma * real + beat * imag), (imag, gamma * imag - beat * real))
    derivative = lambda value: sum(sym.diff(value, variable) * rate for variable, rate in derivative_variables)
    density = 2 * ((slope0 * slopek + background * sideband + mass**2) * real +
                   (slope0 * sideband - background * slopek) * imag) / denominator
    pressure = 2 * ((slope0 * slopek + background * sideband - mass**2) * real +
                    (slope0 * sideband - background * slopek) * imag) / denominator
    phase = 2 * mass * (background * imag - slope0 * real) / denominator
    equation_of_state = (background**2 + slope0**2 - mass**2) / denominator
    residual0 = mass**2 - hubble_prime - hubble**2 - background**2 - background_second / (2 * background) + sym.Rational(3, 4) * (background_prime / background)**2
    residualk = mass**2 + wave**2 - hubble_prime - hubble**2 - sideband**2 - sideband_second / (2 * sideband) + sym.Rational(3, 4) * (sideband_prime / sideband)**2
    background_remainder = 2 * slope0 * residual0 / denominator
    energy_remainder = 2 * ((slope0 * real - background * imag) * residualk +
                           (slopek * real + sideband * imag) * residual0) / denominator - density * background_remainder
    phase_remainder = -2 * mass * residual0 * real / denominator - phase * background_remainder
    residuals = [
        derivative(denominator) / denominator - hubble - background_prime / background + 3 * hubble * equation_of_state - background_remainder,
        derivative(density) - wave**2 * phase / mass + 3 * hubble * (pressure - equation_of_state * density) - energy_remainder,
        derivative(phase) - 3 * hubble * equation_of_state * phase + mass * pressure - phase_remainder]
    answers = [str(sym.cancel(value)) for value in residuals]
    if any(value != "0" for value in answers):
        raise ValueError("source conservation identity failed")
    return answers


def bounds():
    proof = json.loads((ROOT / "proof.json").read_text())
    certificate = proof["certificate"]
    gradient, adiabatic = Fraction(certificate["gradient_max"]), Fraction(certificate["adiabatic_max"])
    denominator = Fraction(certificate["denominator_lower"])
    polynomial = 3 + 12 * gradient + 4 * gradient**2
    derivative_bound = 24 * (1 + gradient)**2 + adiabatic * (12 + 8 * gradient)
    logarithmic_bound = 1 + 5 * gradient + 2 * (gradient * derivative_bound + adiabatic * polynomial) / denominator
    hubble_min, hubble_max = Fraction(12, 10000), Fraction(14, 10000)
    slope_bound = hubble_max * (1 + logarithmic_bound / 2)
    residual_bound = 1510**2 * adiabatic**2 * Fraction(certificate["coefficient_second_upper"])
    source_denominator = Fraction(1490**2)
    energy_bound = 2 * residual_bound * (3 * slope_bound + 2 * 1511) / source_denominator / hubble_min
    phase_bound = 2 * residual_bound * (1510 + slope_bound) / source_denominator / hubble_min
    if not (1511**2 >= 1510**2 + 5**2 and energy_bound < Fraction(1, 10**17) and phase_bound < Fraction(1, 10**17)):
        raise ValueError("source enclosure failed")
    return dict(energy_per_efold_upper=str(energy_bound), phase_per_efold_upper=str(phase_bound),
        energy_bound_decimal=float(energy_bound), phase_bound_decimal=float(phase_bound),
        residual_coefficient_upper=str(residual_bound), physical_amplitude_slope_upper=str(slope_bound),
        norm="max(abs(R),abs(I),abs(delta),abs(S))", instantaneous_not_terminal=True)


def main():
    worker = base.psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
    base.write("conservation-start.json", identity)
    try:
        answers = identities()
        certificate = bounds()
        result = dict(passed=True, identities=answers, certificate=certificate,
            proof_sha256=base.digest(ROOT / "proof.json"), code_sha256=base.digest(__file__),
            document_sha256=base.digest(ROOT / "SOURCE-CONSERVATION.md"))
        base.write("conservation.json", result)
        base.write("conservation-end.json", dict(**identity, state="completed", result_sha256=base.digest(ROOT / "conservation.json")))
        print(json.dumps(dict(identities=answers, energy_bound=certificate["energy_bound_decimal"],
                              phase_bound=certificate["phase_bound_decimal"])))
    except Exception as error:
        base.write("conservation-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
