import json
from datetime import datetime, timezone
from fractions import Fraction
import mpmath as mp
import transport_second_order as transport

np, ROOT = transport.np, transport.ROOT


def numeric_residual_check():
    mp.mp.dps = 80
    proof = json.loads((ROOT / "proof.json").read_text())
    certificate = proof["certificate"]
    rational = lambda text: mp.mpf(Fraction(text).numerator) / Fraction(text).denominator
    maximum_gradient = rational(certificate["gradient_max"])
    maximum_adiabatic = rational(certificate["adiabatic_max"])
    coefficient = rational(certificate["coefficient_second_upper"])
    maximum_disagreement = mp.mpf(0)
    rows = 0
    for gradient in (mp.mpf(0), maximum_gradient / 3, maximum_gradient):
        for adiabatic in (maximum_adiabatic / 4, maximum_adiabatic / 2, maximum_adiabatic):
            wave, hubble = mp.sqrt(gradient), mp.sqrt(adiabatic)
            def frequency(mass):
                omega = mp.sqrt(mass**2 + wave**2)
                return omega - hubble**2 * (3 * mass**4 + 12 * mass**2 * wave**2 + 4 * wave**4) / (8 * omega**5)
            value = frequency(mp.mpf(1))
            first = hubble * mp.diff(frequency, mp.mpf(1))
            second = hubble**2 * (mp.diff(frequency, mp.mpf(1), 2) + mp.diff(frequency, mp.mpf(1)))
            direct = 1 + wave**2 - hubble**2 - value**2 - second / (2 * value) + mp.mpf(3) * first**2 / (4 * value**2)
            denominator = 8 * (1 + gradient)**3 - adiabatic * (3 + 12 * gradient + 4 * gradient**2)
            polynomial = sum(mp.mpf(term) * gradient**powers[0] * adiabatic**powers[1]
                             for powers, term in proof["formula"]["numerator_terms"])
            factored = adiabatic**2 * polynomial / (64 * (1 + gradient)**5 * denominator**2)
            maximum_disagreement = max(maximum_disagreement, abs(direct - factored) / max(abs(factored), mp.mpf("1e-100")))
            if not (value > 0 and abs(direct) <= adiabatic**2 * coefficient):
                raise ValueError("residual enclosure contradicted")
            rows += 1
    if maximum_disagreement > mp.mpf("1e-45"):
        raise ValueError("independent residual expression")
    return dict(points=rows, maximum_relative_disagreement=mp.nstr(maximum_disagreement, 30))


def frame_rounding():
    case = transport.case_data("heavy")
    result = {}
    for target in (1e-5, .03, .1, 1, 5):
        index = int(np.argmin(abs(case["wave"] - target)))
        for position in (0.0, .001):
            computed = transport.frame(case, position, 2)
            mass = mp.mpf(float(case["mu"][index])) * mp.exp(mp.mpf(position))
            wave, hubble = mp.mpf(float(case["wave"][index])), mp.mpf(float(case["hubble"][index]))
            def frequency(current_mass, current_wave):
                omega = mp.sqrt(current_mass**2 + current_wave**2)
                return omega - hubble**2 * (3 * current_mass**4 + 12 * current_mass**2 * current_wave**2 + 4 * current_wave**4) / (8 * omega**5)
            homogeneous, sideband = frequency(mass, mp.mpf(0)), frequency(mass, wave)
            log_homogeneous = mass * mp.diff(lambda value: frequency(value, mp.mpf(0)), mass) / homogeneous
            log_sideband = mass * mp.diff(lambda value: frequency(value, wave), mass) / sideband
            slope_homogeneous = -hubble * (1 + log_homogeneous / 2)
            slope_sideband = -hubble * (1 + log_sideband / 2)
            denominator = homogeneous**2 + mass**2 + slope_homogeneous**2
            matrix = mp.matrix([[2 * (slope_homogeneous * slope_sideband + homogeneous * sideband + mass**2) / denominator,
                                 2 * (slope_homogeneous * sideband - homogeneous * slope_sideband) / denominator],
                                [-2 * mass * slope_homogeneous / denominator, 2 * mass * homogeneous / denominator]])
            pressure = mp.matrix([[2 * (slope_homogeneous * slope_sideband + homogeneous * sideband - mass**2) / denominator,
                                   matrix[0, 1]]])
            weight = 2 * sideband / homogeneous / mp.det(matrix)
            expected_values = {**{"matrix" + str(row) + str(column): matrix[row, column] for row in range(2) for column in range(2)},
                               "pressure0": pressure[0, 0], "pressure1": pressure[0, 1], "weight": weight,
                               "beat": sideband - homogeneous}
            actual_values = {**{"matrix" + str(row) + str(column): computed["matrix"][index, row, column] for row in range(2) for column in range(2)},
                             "pressure0": computed["pressure"][index, 0], "pressure1": computed["pressure"][index, 1],
                             "weight": computed["weight"][index], "beat": computed["beat"][index]}
            for key, expected in expected_values.items():
                error = float(abs(mp.mpf(float(actual_values[key])) - expected) / max(abs(expected), mp.mpf("1e-100")))
                result[key] = max(result.get(key, 0.0), error)
                if error > 1e-10:
                    raise ValueError("implementation rounding " + key + ": " + str(error))
    return result


def main():
    worker = transport.psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(transport.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
    transport.write("validation-start.json", identity)
    try:
        for path, checksum in transport.proof["sources"].items():
            if transport.digest(path) != checksum:
                raise ValueError("changed input")
        report = json.loads((ROOT / "transport-result.json").read_text())
        if transport.digest(ROOT / "transport.npz") != report["output_sha256"]:
            raise ValueError("changed export")
        residual = numeric_residual_check()
        rounding = frame_rounding()
        exact = json.loads((ROOT / "exact-controls.json").read_text())
        if not exact["passed"]:
            raise ValueError("exact controls failed")
        result = dict(passed=True, independent_residual=residual, rounding_relative_maxima=rounding,
            proof_sha256=transport.digest(ROOT / "proof.json"), transport_sha256=transport.digest(ROOT / "transport-result.json"),
            exact_controls_sha256=transport.digest(ROOT / "exact-controls.json"), code_sha256=transport.digest(__file__),
            no_analytic_bound_claim_for_machine_rounding=True)
        transport.write("validation.json", result)
        transport.write("validation-end.json", dict(**identity, state="completed"))
        print(json.dumps(dict(residual=residual, rounding=rounding)))
    except Exception as error:
        transport.write("validation-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
