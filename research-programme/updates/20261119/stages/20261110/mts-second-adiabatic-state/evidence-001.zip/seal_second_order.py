import ast
import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
worker = psutil.Process()
worker.cpu_affinity([4])
worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(name):
    return json.loads((ROOT / name).read_text())


with (ROOT / "seal-start.json").open("x") as stream:
    json.dump(identity, stream)
try:
    proof = read("proof.json")
    transport = read("transport-result.json")
    exact = read("exact-controls.json")
    conservation = read("conservation.json")
    validation = read("validation.json")
    assert all(report["passed"] for report in (proof, transport, exact, conservation, validation))
    assert transport["proof_sha256"] == digest(ROOT / "proof.json")
    assert transport["code_sha256"] == digest(ROOT / "transport_second_order.py")
    assert transport["output_sha256"] == digest(ROOT / "transport.npz")
    assert transport["control_plan_sha256"] == digest(ROOT / "CONTROL-PLAN.md")
    assert exact["proof_sha256"] == digest(ROOT / "proof.json")
    assert exact["code_sha256"] == digest(ROOT / "exact_bessel_controls.py")
    assert conservation["proof_sha256"] == digest(ROOT / "proof.json")
    assert conservation["code_sha256"] == digest(ROOT / "verify_source_conservation.py")
    assert conservation["document_sha256"] == digest(ROOT / "SOURCE-CONSERVATION.md")
    assert validation["proof_sha256"] == digest(ROOT / "proof.json")
    assert validation["transport_sha256"] == digest(ROOT / "transport-result.json")
    assert validation["exact_controls_sha256"] == digest(ROOT / "exact-controls.json")
    assert validation["code_sha256"] == digest(ROOT / "validate_second_order.py")
    for path, checksum in proof["sources"].items():
        assert Path(path).is_file() and digest(path) == checksum, path
    assert all(value == "0" for value in proof["formula"]["identities"] + conservation["identities"])
    cleanup = []
    for prefix in ("proof", "transport", "exact-control", "conservation", "validation"):
        start, end = read(prefix + "-start.json"), read(prefix + "-end.json")
        assert start["pid"] == end["pid"] and start["created"] == end["created"] and end["state"] == "completed"
        live = psutil.pid_exists(start["pid"]) and abs(psutil.Process(start["pid"]).create_time() - start["created"]) < .001
        assert not live, "task-owned worker remains live"
        cleanup.append(dict(prefix=prefix, pid=start["pid"], created=start["created"], command=start["command"], exited=True))
    for path in ROOT.glob("*.py"):
        ast.parse(path.read_text(), filename=str(path))
    assert not list(ROOT.rglob("__pycache__"))
    receipt = ROOT.parent / "MTS-GALAXY-RECEIPT-20261110-07.md"
    manifest = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size)
                for path in ROOT.rglob("*") if path.is_file()}
    result = dict(state="verified", time=datetime.now(timezone.utc).isoformat(), artifacts=manifest,
        input_hashes=proof["sources"], source_count=len(proof["sources"]), cleanup=cleanup, sealer=identity,
        external_receipt=dict(path=str(receipt), sha256=digest(receipt), status="received-parent-only; sender-reported"),
        exact_symbolic_identities=9, exact_Bessel_controls=3, heavy_rows=399, cold_rows=399,
        domain="constant conformal H; unforced; frozen box and e-fold interval",
        rigorous_coefficient_error_bound="2e-21", binary64_accuracy_not_equal_to_bound=True,
        physical_initial_source_comparisons_not_same_microstate=True,
        no_live_native_closure_changed=True, no_galaxy_file_edits=True, no_github=True,
        no_new_observational_fit=True, no_relay_or_timer=True, broad_goal_complete=False)
    with (ROOT / "closeout.json").open("x") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
    checksum = digest(ROOT / "closeout.json")
    with (ROOT / "seal-end.json").open("x") as stream:
        json.dump(dict(**identity, state="completed", closeout_sha256=checksum), stream)
    print(json.dumps(dict(closeout_sha256=checksum, artifacts=len(manifest), sources=len(proof["sources"]),
                         cleanup=cleanup, sealer_pid=worker.pid)))
except Exception as error:
    with (ROOT / "seal-end.json").open("x") as stream:
        json.dump(dict(**identity, state="failed", error=repr(error)), stream)
    raise
