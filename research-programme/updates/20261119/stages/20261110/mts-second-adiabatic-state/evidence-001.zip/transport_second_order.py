import os
import sys
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
import json
import hashlib
import time
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import sympy as sym
import psutil
from numpy.polynomial.legendre import leggauss

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
SAVED = POST / "mts-formation-state-bundle-20261110"
PREVIOUS = POST / "mts-averaged-state-action-20261110"
SPAN, ALGEBRA, GATE = .001, 1e-10, 2e-5
START = time.monotonic()
CHECKS = []


def guard():
    if time.monotonic() - START > 900:
        raise RuntimeError("bounded second-order probe expired")
    for path in (ROOT / "STOP-REQUESTED", POST / "STOP-REQUESTED"):
        if path.exists():
            raise RuntimeError("owner hold")


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def write(name, data):
    with (ROOT / name).open("x") as stream:
        json.dump(data, stream, indent=2, allow_nan=False)


def check(name, error, gate=ALGEBRA):
    error = float(error)
    if not np.isfinite(error) or abs(error) > gate:
        raise ValueError(name + ": " + str(error))
    CHECKS.append(dict(name=name, error=error, gate=gate, passed=True))


proof = json.loads((ROOT / "proof.json").read_text())
gradient_symbol, adiabatic_symbol = sym.symbols("gradient adiabatic")
gamma_function = sym.lambdify((gradient_symbol, adiabatic_symbol),
    sym.sympify(proof["formula"]["gamma_over_H"], locals={"gradient": gradient_symbol, "adiabatic": adiabatic_symbol}), "numpy")


def case_data(model):
    with np.load(SAVED / ("late-" + model + ".npz")) as packet:
        columns, values = packet["columns"].tolist(), packet["values"]
    values = values[values[:, columns.index("nominal_a")] == .01]
    get = lambda name: values[:, columns.index(name)].copy()
    with np.load(PREVIOUS / (model + "-connection.npz")) as packet:
        initial, normalizer = packet["initial"].copy(), packet["normalizer"].copy()
        original, first = packet["original"].copy(), packet["corrected"].copy()
        old_template = packet["template"].copy()
    if len(initial) != 399:
        raise ValueError("same saved399rows")
    return dict(model=model, wave=get("k_Mpc_inverse"), scale=get("a"), mass=get("test_mass_Mpc_inverse"),
        mu=get("a") * get("test_mass_Mpc_inverse"), hubble=get("H_conformal_Mpc_inverse"),
        initial=initial, normalizer=normalizer, original=original, first=first, old_template=old_template)


def frame(case, position, order):
    mu = case["mu"] * np.exp(position)
    gradient = (case["wave"] / mu)**2
    adiabatic = (case["hubble"] / mu)**2
    ratio = np.sqrt(1 + gradient)
    difference = gradient / (ratio + 1)
    if order == 0:
        homogeneous, sideband = np.ones_like(ratio), ratio
        log_homogeneous = np.ones_like(ratio)
        gamma = gradient / (2 * (1 + gradient))
    elif order == 2:
        homogeneous = 1 - 3 * adiabatic / 8
        sideband = ratio - adiabatic * (3 + 12 * gradient + 4 * gradient**2) / (8 * ratio**5)
        log_homogeneous = (8 + 3 * adiabatic) / (8 - 3 * adiabatic)
        gamma = gamma_function(gradient, adiabatic)
        difference = difference * (1 + adiabatic *
            (3 * ratio**4 - ratio**3 - ratio**2 - 5 * ratio - 5) / (8 * ratio**5))
    else:
        raise ValueError("unknown order")
    hratio = case["hubble"] / mu
    slope_homogeneous = -hratio * (1 + log_homogeneous / 2)
    slope_sideband = -hratio * (1 + (log_homogeneous - 2 * gamma) / 2)
    homogeneous_squared_minus_one = (-3 * adiabatic / 4 + 9 * adiabatic**2 / 64) if order == 2 else np.zeros_like(ratio)
    denominator = 2 + homogeneous_squared_minus_one + slope_homogeneous**2
    mixed = slope_homogeneous * difference - hratio * homogeneous * gamma
    product = homogeneous**2 + homogeneous * difference
    matrix = np.empty((399, 2, 2))
    matrix[:, 0, 0] = 2 * (slope_homogeneous * slope_sideband + product + 1) / denominator
    matrix[:, 0, 1] = 2 * mixed / denominator
    matrix[:, 1, 0] = -2 * slope_homogeneous / denominator
    matrix[:, 1, 1] = 2 * homogeneous / denominator
    pressure = np.column_stack((
        2 * (slope_homogeneous * slope_sideband + homogeneous_squared_minus_one + homogeneous * difference) / denominator,
        2 * mixed / denominator))
    weight = 2 * sideband / homogeneous / np.linalg.det(matrix)
    background_pressure = (homogeneous_squared_minus_one + slope_homogeneous**2) / denominator
    return dict(matrix=matrix, pressure=pressure, weight=weight, beat=mu * difference,
        relative_amplitude_frequency=homogeneous / sideband, background_pressure=background_pressure,
        frequency=mu * sideband, homogeneous_frequency=mu * homogeneous, gamma=gamma)


def propagate(case, order, points):
    nodes, weights = leggauss(points)
    phase = np.zeros(399)
    for node, weight in zip(nodes, weights):
        guard()
        position = SPAN * (node + 1) / 2
        phase += weight * frame(case, position, order)["beat"] / case["hubble"] * SPAN / 2
    first, last = frame(case, 0, order), frame(case, SPAN, order)
    amplification = np.sqrt(last["relative_amplitude_frequency"] / first["relative_amplitude_frequency"])
    rotation = np.empty((399, 2, 2))
    rotation[:, 0, 0] = np.cos(phase)
    rotation[:, 0, 1] = np.sin(phase)
    rotation[:, 1, 0] = -np.sin(phase)
    rotation[:, 1, 1] = np.cos(phase)
    relative_transport = amplification[:, None, None] * rotation
    initial_relative = np.linalg.solve(first["matrix"], case["initial"][:, :, None])[:, :, 0]
    final_relative = np.einsum("nij,nj->ni", relative_transport, initial_relative)
    final = np.einsum("nij,nj->ni", last["matrix"], final_relative)
    transport = last["matrix"] @ relative_transport @ np.linalg.inv(first["matrix"])
    weighted_error = np.max(abs(np.linalg.det(transport) * last["weight"] / first["weight"] - 1))
    check("order" + str(order) + " weighted symplectic " + str(points), weighted_error)
    initial_pressure = np.einsum("ni,ni->n", first["pressure"], initial_relative)
    final_pressure = np.einsum("ni,ni->n", last["pressure"], final_relative)
    return dict(final=final, transport=transport, initial_pressure=initial_pressure, final_pressure=final_pressure,
                weight_initial=first["weight"], weight_final=last["weight"], phase=phase,
                background_pressure_initial=first["background_pressure"], weighted_error=float(weighted_error))


def main():
    worker = psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    guard()
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
    write("transport-start.json", identity)
    try:
        for path, checksum in proof["sources"].items():
            if digest(path) != checksum:
                raise ValueError("changed inherited input")
        heavy, cold = case_data("heavy"), case_data("cold")
        check("same original mode set", np.max(abs(heavy["wave"] - cold["wave"])))
        variants = {}
        for order in (0, 2):
            for count in (8, 16, 32):
                variants[(order, count)] = propagate(heavy, order, count)
        reference0, reference2 = variants[(0, 32)], variants[(2, 32)]
        refinements = []
        for order in (0, 2):
            for lower, higher in ((8, 16), (16, 32)):
                error = float(np.max(abs((variants[(order, lower)]["final"] - variants[(order, higher)]["final"]) /
                                        heavy["normalizer"])))
                check("quadrature refinement " + str((order, lower, higher)), error, GATE)
                refinements.append(dict(order=order, lower=lower, higher=higher, error=error))
        old_match = float(np.max(abs((reference0["final"] - heavy["old_template"]) / heavy["normalizer"])))
        check("independent old template replay", old_match, GATE)
        comparisons = dict(old_template_replay=old_match,
            old_template_to_second=float(np.max(abs((reference0["final"] - reference2["final"]) / heavy["normalizer"]))),
            original_to_second=float(np.max(abs((heavy["original"] - reference2["final"]) / heavy["normalizer"]))),
            first_order_to_second=float(np.max(abs((heavy["first"] - reference2["final"]) / heavy["normalizer"]))))
        cold_final = cold["initial"].copy()
        cold_final[:, 0] += cold["wave"]**2 / (cold["mu"] * cold["hubble"]) * cold["initial"][:, 1] * (-np.expm1(-SPAN))
        cold_error = float(np.max(abs((cold_final - cold["original"]) / cold["normalizer"])))
        check("cold exact continuation", cold_error, GATE)
        output = ROOT / "transport.npz"
        if output.exists():
            raise ValueError("preserve output")
        np.savez_compressed(output, wave=heavy["wave"], initial=heavy["initial"], normalizer=heavy["normalizer"],
            old_final=reference0["final"], second_final=reference2["final"], original_final=heavy["original"],
            first_final=heavy["first"], cold_final=cold_final, second_transport=reference2["transport"],
            weight_initial=reference2["weight_initial"], weight_final=reference2["weight_final"],
            old_pressure_initial=reference0["initial_pressure"], second_pressure_initial=reference2["initial_pressure"],
            second_pressure_final=reference2["final_pressure"], old_phase=reference0["phase"], second_phase=reference2["phase"],
            background_pressure_initial=reference2["background_pressure_initial"])
        result = dict(passed=True, heavy_rows=399, cold_rows=399, comparisons=comparisons, refinements=refinements,
            cold_error=cold_error, maximum_weighted_error=max(value["weighted_error"] for value in variants.values()),
            maximum_background_pressure=float(abs(reference2["background_pressure_initial"]).max()),
            checks=CHECKS, output_sha256=digest(output), proof_sha256=digest(ROOT / "proof.json"),
            code_sha256=digest(__file__), control_plan_sha256=digest(ROOT / "CONTROL-PLAN.md"),
            fixed_initial_physical_delta_S=True, fixed_microscopic_initial_data_between_orders=False,
            bound_not_numerical_precision=True)
        write("transport-result.json", result)
        write("transport-end.json", dict(**identity, state="completed", result_sha256=digest(ROOT / "transport-result.json")))
        print(json.dumps(dict(comparisons=comparisons, refinements=refinements, cold_error=cold_error,
                              background_pressure=result["maximum_background_pressure"])))
    except Exception as error:
        write("transport-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
