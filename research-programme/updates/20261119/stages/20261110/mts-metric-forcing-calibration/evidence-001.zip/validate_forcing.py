from common import *
from fractions import Fraction
import ast
import numpy as np
import sympy as sym
from numpy.polynomial.legendre import leggauss
import test_forcing as numerical


def physical_integral(case):
    nodes, weights = leggauss(16)
    width = SPAN / 512
    result = np.zeros((399, 2, 2))
    for first in range(0, 512, 8):
        guard()
        positions = (((np.arange(first, first + 8) + .5) * width)[:, None] + nodes[None, :] * width / 2).ravel()
        carrier, sideband = numerical.templates(case, positions)
        mass = case["mu"][None, :] * np.exp(positions[:, None])
        force = np.zeros_like(carrier)
        force[..., 1, 0] = -2 * mass**2 * case["lapse"][None, :]
        transformed = numerical.inverse_unit(sideband) @ force @ carrier
        result += np.einsum("t,tnij->nij", np.tile(weights, 8) * width / 2, transformed) / case["hubble"][:, None, None]
    return result


def elimination_identity():
    hubble, hubble_prime, mass, carrier, carrier_prime = sym.symbols("hubble hubble_prime mass carrier carrier_prime")
    potential, lapse, potential_prime, lapse_prime, residual = sym.symbols("potential lapse potential_prime lapse_prime residual")
    combined, difference = lapse + 3 * potential, 3 * potential - lapse
    combined_prime = lapse_prime + 3 * potential_prime
    carrier_second = -(mass**2 - hubble_prime - hubble**2) * carrier + residual * carrier
    force_one_prime = combined_prime * (carrier_prime - hubble * carrier) + combined * (carrier_second - hubble_prime * carrier - hubble * carrier_prime)
    force_two = hubble * combined * (carrier_prime - hubble * carrier) + mass**2 * difference * carrier
    expected = combined_prime * (carrier_prime - hubble * carrier) - 2 * mass**2 * lapse * carrier + combined * residual * carrier
    result = str(sym.expand(force_one_prime + force_two - expected))
    if result != "0":
        raise ValueError("off-shell/source elimination")
    return result


def main():
    with worker("validation"):
        proof, report = read(ROOT / "proof.json"), read(ROOT / "numerical.json")
        if not proof["passed"] or not report["passed"]:
            raise ValueError("earlier gates failed")
        for key, filename in (("proof_sha256", "proof.json"), ("code_sha256", "test_forcing.py"),
                              ("common_sha256", "common.py"), ("protocol_sha256", "PROTOCOL.md"),
                              ("output_sha256", "forced-transport.npz"), ("budgets_sha256", "metric-budgets.json")):
            if report[key] != digest(ROOT / filename):
                raise ValueError("result dependency differs " + filename)
        for path, checksum in proof["sources"].items():
            guard()
            if digest(path) != checksum:
                raise ValueError("source changed " + path)
        case = numerical.case_data("heavy")
        with np.load(ROOT / "forced-transport.npz") as packet:
            arrays = {name: packet[name].copy() for name in packet.files}
        for name, value in arrays.items():
            if not np.isfinite(value).all() or len(value) != 399:
                raise ValueError("invalid output " + name)
        pressure = []
        for lower, higher in ((128, 256), (256, 512)):
            error = float(np.max(abs(arrays["source" + str(lower)][:, 2] - arrays["source" + str(higher)][:, 2]) / case["normalizer"][:, 0]))
            numerical.check("pressure source-block quadrature " + str((lower, higher)), error, GATE)
            pressure.append(dict(lower=lower, higher=higher, error=error))
        initial = numerical.physical_coordinates(case, arrays["initial_canonical"])
        integral = physical_integral(case)
        physical_final = numerical.propagate(case, initial, integral)
        canonical_final = physical_final.copy()
        canonical_final[:, 3, :] -= (case["lapse"] + 3 * case["potential"])[:, None] * (canonical_final[:, 1, :] - case["hubble"][:, None] * canonical_final[:, 0, :])
        difference = numerical.normalized(case, canonical_final, arrays["perturbation_scale"]) - numerical.normalized(case, arrays["final512"], arrays["perturbation_scale"])
        physical_error = float(np.max(abs(difference)))
        numerical.check("all399physical versus canonical forced reduction", physical_error, ALGEBRA)
        stress = numerical.stress(case, canonical_final, SPAN)
        block_scale = case["normalizer"][:, [0, 1, 0]]
        source_error = float(np.max(abs(stress - arrays["source512"]) / block_scale))
        numerical.check("physical versus canonical stress block", source_error, GATE)
        exact = {key: Fraction(value) for key, value in proof["enclosure"]["exact"].items()}
        budgets = []
        for index, wave in enumerate(case["wave"]):
            bound = 2 * exact["J_coefficient_D"] * abs(Fraction(float(case["lapse"][index])))
            radius = 2 * exact["J_coefficient_D"] * Fraction(float(case["lapse_rounding"][index])) * exact["source_error_factor"]
            truncation = bound * exact["forced_error_factor"]
            if radius < 0:
                raise ValueError("negative source radius")
            budgets.append(dict(wave=float(wave), J_exact=str(bound), J=float(bound),
                                metric_error_per_c0_exact=str(radius), metric_error_per_c0=float(radius),
                                forced_truncation_per_c0_exact=str(truncation), forced_truncation_per_c0=float(truncation)))
        write("physical-metric-budgets.json", dict(initial_condition="same physical q,qprime, not same metric-shifted P",
                                                  excludes="initial-state uncertainty, general metric histories, machine error", rows=budgets))
        np.savez_compressed(ROOT / "physical-control.npz", physical_final=physical_final, integral=integral, source=stress)
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(), filename=str(path))
        if list(ROOT.rglob("__pycache__")):
            raise ValueError("bytecode residue")
        report = dict(passed=True, source_elimination_identity=elimination_identity(), pressure_refinement=pressure,
                      physical_coordinate_error=physical_error, physical_stress_error=source_error,
                      maximum_physical_J=max(row["J"] for row in budgets),
                      maximum_physical_forcing_truncation=max(row["forced_truncation_per_c0"] for row in budgets),
                      maximum_physical_metric_rounding=max(row["metric_error_per_c0"] for row in budgets),
                      checks=numerical.CHECKS, code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"),
                      numerical_sha256=digest(ROOT / "numerical.json"), proof_sha256=digest(ROOT / "proof.json"),
                      plan_sha256=digest(ROOT / "PHYSICAL-METRIC-BOUND.md"), output_sha256=digest(ROOT / "physical-control.npz"),
                      budget_sha256=digest(ROOT / "physical-metric-budgets.json"))
        write("validation.json", report)
        print(json.dumps(report))


if __name__ == "__main__":
    main()
