import os
import sys
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
SECOND = POST / "mts-second-adiabatic-state-20261110"
SAVED = POST / "mts-formation-state-bundle-20261110"
PREVIOUS = POST / "mts-averaged-state-action-20261110"
SPAN, ALGEBRA, GATE = .001, 1e-10, 2e-5
START = time.monotonic()


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(name, value):
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def guard():
    if time.monotonic() - START > 900:
        raise RuntimeError("bounded worker exceeded900seconds")
    for parent in (ROOT, POST):
        if (parent / "STOP-REQUESTED").exists():
            raise RuntimeError("owner hold")


@contextmanager
def worker(prefix):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    guard()
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(),
                    started=datetime.now(timezone.utc).isoformat())
    write(prefix + "-start.json", identity)
    try:
        yield identity
    except Exception as error:
        write(prefix + "-end.json", dict(**identity, state="failed", error=repr(error)))
        raise
    else:
        write(prefix + "-end.json", dict(**identity, state="completed", elapsed=time.monotonic() - START))


def inherited_sources():
    closeout = read(SECOND / "closeout.json")
    if digest(SECOND / "closeout.json") != "faae12b7210520df111f5d302039a8596346594db51a4dcb9255867cee1fc714":
        raise ValueError("prior seal differs")
    sources = dict(closeout["input_hashes"])
    for name, entry in closeout["artifacts"].items():
        sources[str(SECOND / name)] = entry["sha256"]
    for path in (SECOND / "closeout.json", POST / "MTS-NATIVE-GAUGE-AND-PHYSICAL-EVOLUTION.md",
                 POST / "MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md",
                 POST / "condensate-origin-20261003/motion-bath-matching-20261006/49-real-motion-envelope-and-existing-bath-matching.md"):
        sources[str(path)] = digest(path)
    for path, checksum in sources.items():
        guard()
        if digest(path) != checksum:
            raise ValueError("inherited source changed " + path)
    return sources
