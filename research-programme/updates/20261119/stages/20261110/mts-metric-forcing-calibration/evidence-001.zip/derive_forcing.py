from common import *
from fractions import Fraction
import sympy as sym


def identities():
    scale, hubble, hubble_prime, mass, wave = sym.symbols("scale hubble hubble_prime mass wave", nonzero=True)
    potential, lapse, potential_prime, lapse_prime = sym.symbols("potential lapse potential_prime lapse_prime")
    field, speed, perturbation, derivative, second, momentum = sym.symbols("field speed perturbation derivative second momentum")
    combined, difference = lapse + 3 * potential, 3 * potential - lapse
    parameter = sym.symbols("parameter")
    volume = sym.sqrt(1 + 2 * parameter * lapse) * (1 - 2 * parameter * potential)**sym.Rational(3, 2)
    checks = {}

    def exact(name, value):
        guard()
        result = str(sym.factor(value))
        if result != "0":
            raise ValueError(name + ": " + result)
        checks[name] = result

    exact("metric kinetic coefficient", sym.diff(volume / (1 + 2 * parameter * lapse), parameter).subs(parameter, 0) + combined)
    exact("metric potential coefficient", sym.diff(volume, parameter).subs(parameter, 0) + difference)
    lagrangian = scale**2 * (derivative**2 - (wave**2 + mass**2) * perturbation**2) / 2 - scale**2 * combined * speed * derivative + scale**2 * mass**2 * difference * field * perturbation
    rates = {scale: hubble * scale, mass: hubble * mass, hubble: hubble_prime, field: speed,
             speed: -2 * hubble * speed - mass**2 * field, perturbation: derivative,
             derivative: second, potential: potential_prime, lapse: lapse_prime}
    total = lambda expression: sum(sym.diff(expression, variable) * rate for variable, rate in rates.items())
    euler = (total(sym.diff(lagrangian, derivative)) - sym.diff(lagrangian, perturbation)) / scale**2
    expected = second + 2 * hubble * derivative + (wave**2 + mass**2) * perturbation - speed * (lapse_prime + 3 * potential_prime) + 2 * mass**2 * field * lapse
    exact("Euler equation from expanded action", euler - expected)
    exact("derivative-free momentum", (sym.diff(lagrangian, derivative) / scale**2).subs(derivative, momentum + combined * speed) - momentum)

    carrier, carrier_momentum, coordinate, coordinate_prime, canonical = sym.symbols("carrier carrier_momentum coordinate coordinate_prime canonical")
    force_one = combined * (carrier_momentum - hubble * carrier)
    force_two = hubble * force_one + mass**2 * difference * carrier
    frequency_squared = wave**2 + mass**2 - hubble_prime - hubble**2
    canonical_lagrangian = coordinate_prime**2 / 2 - frequency_squared * coordinate**2 / 2 - force_one * coordinate_prime + force_two * coordinate
    rescaled = lagrangian.subs({field: carrier / scale, speed: (carrier_momentum - hubble * carrier) / scale,
                               perturbation: coordinate / scale, derivative: (coordinate_prime - hubble * coordinate) / scale})
    exact("canonical rescaling including boundary derivative", rescaled + hubble * coordinate * coordinate_prime + hubble_prime * coordinate**2 / 2 - canonical_lagrangian)
    exact("canonical momentum", sym.diff(canonical_lagrangian, coordinate_prime) - coordinate_prime + force_one)
    hamiltonian = (canonical + force_one)**2 / 2 + frequency_squared * coordinate**2 / 2 - force_two * coordinate
    exact("Legendre transform", (canonical * coordinate_prime - canonical_lagrangian).subs(coordinate_prime, canonical + force_one) - hamiltonian)
    exact("Hamilton coordinate equation", sym.diff(hamiltonian, canonical) - canonical - force_one)
    exact("Hamilton momentum equation", -sym.diff(hamiltonian, coordinate) + frequency_squared * coordinate - force_two)
    exact("triangular force row1", force_one - (-hubble * combined * carrier + combined * carrier_momentum))
    exact("triangular force row2", force_two - ((mass**2 * difference - hubble**2 * combined) * carrier + hubble * combined * carrier_momentum))
    force_one_symbol, force_two_symbol, omega_squared = sym.symbols("force_one force_two omega_squared")
    force_one_prime, force_two_prime, omega_prime = sym.symbols("force_one_prime force_two_prime omega_prime")
    energy = (canonical + force_one_symbol)**2 / 2 + omega_squared * coordinate**2 / 2 - force_two_symbol * coordinate
    flow_rates = {coordinate: canonical + force_one_symbol, canonical: -omega_squared * coordinate + force_two_symbol,
                  force_one_symbol: force_one_prime, force_two_symbol: force_two_prime, omega_squared: omega_prime}
    energy_prime = sum(sym.diff(energy, variable) * rate for variable, rate in flow_rates.items())
    exact("time-dependent Hamilton work", energy_prime - (canonical + force_one_symbol) * force_one_prime - omega_prime * coordinate**2 / 2 + force_two_prime * coordinate)

    background_energy = (speed**2 + mass**2 * field**2) / 2
    density = (speed * momentum + 3 * speed**2 * potential + mass**2 * field * perturbation) / background_energy
    pressure = (speed * momentum + 3 * speed**2 * potential - mass**2 * field * perturbation) / background_energy
    current = wave * speed * perturbation / background_energy
    eos = (speed**2 - mass**2 * field**2) / (2 * background_energy)
    rates[perturbation] = momentum + speed * combined
    rates[momentum] = -2 * hubble * momentum - (wave**2 + mass**2) * perturbation + mass**2 * difference * field
    exact("background stress conservation", total(background_energy) + hubble * (1 + 3 * eos) * background_energy)
    exact("forced energy conservation", total(density) + wave * current - 3 * (1 + eos) * potential_prime + 3 * hubble * (pressure - eos * density))
    exact("forced momentum conservation", total(current) + hubble * (1 - 3 * eos) * current - wave * (pressure + (1 + eos) * lapse))
    exact("lapse retained in canonical stress", (speed * derivative - speed**2 * lapse + mass**2 * field * perturbation).subs(derivative, momentum + combined * speed) - density * background_energy)

    time_value, amplitude = sym.symbols("time_value amplitude", real=True)
    flat_solution = -2 * mass**2 * lapse * amplitude * (sym.cos(mass * time_value) - sym.cos(sym.sqrt(mass**2 + wave**2) * time_value)) / wave**2
    exact("flat sourced field solution", sym.diff(flat_solution, time_value, 2) + (mass**2 + wave**2) * flat_solution + 2 * mass**2 * lapse * amplitude * sym.cos(mass * time_value))
    exact("flat initial field", flat_solution.subs(time_value, 0))
    exact("flat initial field derivative", sym.diff(flat_solution, time_value).subs(time_value, 0))
    zero_solution = -mass * lapse * amplitude * time_value * sym.sin(mass * time_value)
    exact("homogeneous resonant forcing", sym.diff(zero_solution, time_value, 2) + mass**2 * zero_solution + 2 * mass**2 * lapse * amplitude * sym.cos(mass * time_value))
    exact("flat Phi cancellation", (-combined + difference) * mass**2 + 2 * mass**2 * lapse)
    return checks


def enclosure():
    certificate = read(SECOND / "proof.json")["certificate"]
    gradient, adiabatic = Fraction(certificate["gradient_max"]), Fraction(certificate["adiabatic_max"])
    denominator = Fraction(certificate["denominator_lower"])
    polynomial = 3 + 12 * gradient + 4 * gradient**2
    frequency_min = 1490 * (1 - adiabatic * polynomial / 8)
    frequency_max = Fraction(1511)
    hubble_max = Fraction(14, 10000)
    denominator_derivative = 24 * (1 + gradient)**2 + adiabatic * (12 + 8 * gradient)
    log_rate_bound = 1 + 5 * gradient + 2 * (gradient * denominator_derivative + adiabatic * polynomial) / denominator
    shear = hubble_max * log_rate_bound / (2 * frequency_min)
    duration = Fraction(1, 1000) / Fraction(12, 10000)
    coefficient_c = duration * (1 + shear)**2 * (2 * hubble_max * frequency_max / frequency_min + frequency_max + hubble_max**2 / frequency_min)
    coefficient_d = duration * (1 + shear)**2 * Fraction(1510**2) / frequency_min
    exponent = Fraction(certificate["exponent_second_upper"])
    homogeneous_error = exponent / (1 - exponent)
    forced_error_factor = 2 * exponent / (1 - 2 * exponent)
    source_error_factor = 1 / (1 - 2 * exponent)
    if not (0 < exponent < Fraction(1, 100) and 1490 < frequency_max and frequency_max**2 > 1510**2 + 25):
        raise ValueError("enclosure domain")
    exact = dict(frequency_min=frequency_min, frequency_max=frequency_max, shear=shear,
                 J_coefficient_C=coefficient_c, J_coefficient_D=coefficient_d,
                 exponent=exponent, homogeneous_error=homogeneous_error,
                 forced_error_factor=forced_error_factor, source_error_factor=source_error_factor)
    return dict(exact={name: str(value) for name, value in exact.items()},
                display={name: float(value) for name, value in exact.items()},
                proof="exp(x)<=1/(1-x) for0<=x<1; all enclosing arithmetic rational",
                domain="prior frozen constant-H box; same canonical initial state; continuous exact arithmetic",
                excludes=["rounding of implementation", "variable-H history", "gravity backreaction"])


if __name__ == "__main__":
    with worker("proof"):
        sources = inherited_sources()
        result = dict(passed=True, identities=identities(), enclosure=enclosure(), sources=sources,
                      code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"),
                      protocol_sha256=digest(ROOT / "PROTOCOL.md"), derivation_sha256=digest(ROOT / "DERIVATION.md"))
        write("proof.json", result)
        print(json.dumps(dict(identities=len(result["identities"]), enclosure=result["enclosure"]["display"], sources=len(sources))))
