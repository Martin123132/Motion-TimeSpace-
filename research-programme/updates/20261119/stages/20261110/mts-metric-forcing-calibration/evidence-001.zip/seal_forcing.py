from common import *
from fractions import Fraction
import ast
import numpy as np


def check_binding(report, key, filename):
    if report[key] != digest(ROOT / filename):
        raise ValueError("changed binding " + filename)


def main():
    with worker("seal") as identity:
        proof, numerical, validation = (read(ROOT / name) for name in ("proof.json", "numerical.json", "validation.json"))
        if not all(report["passed"] for report in (proof, numerical, validation)):
            raise ValueError("unsatisfied stage gate")
        if len(proof["identities"]) != 21 or any(value != "0" for value in proof["identities"].values()) or validation["source_elimination_identity"] != "0":
            raise ValueError("symbolic contract")
        for key, filename in (("code_sha256", "derive_forcing.py"), ("common_sha256", "common.py"),
                              ("protocol_sha256", "PROTOCOL.md"), ("derivation_sha256", "DERIVATION.md")):
            check_binding(proof, key, filename)
        for key, filename in (("code_sha256", "test_forcing.py"), ("common_sha256", "common.py"),
                              ("protocol_sha256", "PROTOCOL.md"), ("proof_sha256", "proof.json"),
                              ("output_sha256", "forced-transport.npz"), ("budgets_sha256", "metric-budgets.json")):
            check_binding(numerical, key, filename)
        for key, filename in (("code_sha256", "validate_forcing.py"), ("common_sha256", "common.py"),
                              ("plan_sha256", "PHYSICAL-METRIC-BOUND.md"), ("proof_sha256", "proof.json"),
                              ("numerical_sha256", "numerical.json"), ("output_sha256", "physical-control.npz"),
                              ("budget_sha256", "physical-metric-budgets.json")):
            check_binding(validation, key, filename)
        for report in (numerical, validation):
            if not all(row["passed"] and abs(row["error"]) <= row["gate"] for row in report["checks"]):
                raise ValueError("numeric gates")
        if numerical["fixed_tolerances"] != dict(algebra=ALGEBRA, numerical=GATE):
            raise ValueError("changed gates")
        if (numerical["heavy_rows"], numerical["cold_rows"], numerical["carrier_quadratures"]) != (399, 399, 2):
            raise ValueError("coverage mismatch")
        sources = dict(proof["sources"])
        schema = SAVED / "SCHEMA.md"
        sources[str(schema)] = digest(schema)
        for path, checksum in sources.items():
            guard()
            if digest(path) != checksum:
                raise ValueError("changed preserved source " + path)
        for filename in ("metric-budgets.json", "physical-metric-budgets.json"):
            rows = read(ROOT / filename)["rows"]
            if len(rows) != 399:
                raise ValueError("budget coverage")
            for row in rows:
                for name, value in row.items():
                    if name.endswith("_exact") and Fraction(value) < 0:
                        raise ValueError("invalid rational budget")
        cleanup = []
        for prefix in ("proof", "numerical", "validation"):
            start, end = read(ROOT / (prefix + "-start.json")), read(ROOT / (prefix + "-end.json"))
            if end["state"] != "completed" or start["pid"] != end["pid"] or start["created"] != end["created"]:
                raise ValueError("worker receipt mismatch")
            try:
                live = abs(psutil.Process(start["pid"]).create_time() - start["created"]) < .001
            except psutil.NoSuchProcess:
                live = False
            if live:
                raise ValueError("owned worker remains live")
            cleanup.append(dict(**start, exited=True))
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(), filename=str(path))
        if list(ROOT.rglob("__pycache__")):
            raise ValueError("bytecode residue")
        for filename in ("RESULTS.md", "NEXT.md"):
            if not (ROOT / filename).is_file() or (ROOT / filename).stat().st_size < 100:
                raise ValueError("missing handoff")
        manifest = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size)
                    for path in ROOT.rglob("*") if path.is_file()}
        result = dict(state="verified", time=datetime.now(timezone.utc).isoformat(), artifacts=manifest,
                      input_hashes=sources, input_count=len(sources), cleanup=cleanup, sealer=identity,
                      symbolic_identities=22, numeric_checks=len(numerical["checks"]) + len(validation["checks"]),
                      heavy_rows=399, cold_rows=399, scope="action-derived forced higher-order scalar/state interface",
                      probe="constant conformal H and supplied potentials; s in[0,.001]",
                      full_counter_rotating_integral=True, fixed_metric_coupling=True,
                      exact_enclosure_not_binary64_accuracy=True, large_metric_budget_not_fractional_observable_error=True,
                      local_population_not_selected=True, original_sources_unchanged=True,
                      no_live_native_replacement=True, no_galaxy_edits=True, no_github=True, no_timer_or_relay=True,
                      broad_goal_complete=False)
        write("closeout.json", result)
        print(json.dumps(dict(closeout_sha256=digest(ROOT / "closeout.json"), artifacts=len(manifest),
                              inputs=len(sources), cleanup=cleanup, sealer=identity, numeric_checks=result["numeric_checks"])))


if __name__ == "__main__":
    main()
