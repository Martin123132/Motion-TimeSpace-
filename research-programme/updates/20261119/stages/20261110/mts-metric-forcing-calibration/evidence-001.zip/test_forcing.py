from common import *
import importlib.util
from fractions import Fraction
import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.integrate import solve_ivp

CHECKS = []


def check(name, error, gate=ALGEBRA):
    error = float(error)
    if not np.isfinite(error) or abs(error) > gate:
        raise ValueError(name + ": " + str(error))
    CHECKS.append(dict(name=name, error=error, gate=gate, passed=True))


def source_module(name, path):
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def case_data(model):
    with np.load(SAVED / ("late-" + model + ".npz")) as packet:
        columns, values = packet["columns"].tolist(), packet["values"].copy()
    values = values[values[:, columns.index("nominal_a")] == .01]
    if len(values) != 399:
        raise ValueError("frozen399mode coverage")
    get = lambda name: values[:, columns.index(name)].copy()
    case = dict(model=model, wave=get("k_Mpc_inverse"), hubble=get("H_conformal_Mpc_inverse"),
                mu=get("a") * get("test_mass_Mpc_inverse"), potential=get("Phi"), lapse=get("Psi"),
                potential_rounding=get("Phi_rounding"), lapse_rounding=get("Psi_rounding"))
    case["density"] = get("heavy_delta_N" if model == "heavy" else "delta_cdm_N")
    case["velocity"] = get("heavy_u_N") if model == "heavy" else get("theta_cdm_N") / case["wave"]
    case["phase"] = -case["mu"] * case["velocity"] / case["wave"]
    with np.load(PREVIOUS / (model + "-probe.npz")) as packet:
        case["normalizer"] = packet["normalizer"].copy()
        case["saved_final"] = packet["hamilton"].copy()
    return case


def frequency_values(case, positions):
    positions = np.asarray(positions).reshape(-1, 1)
    mass = case["mu"][None, :] * np.exp(positions)
    hubble = case["hubble"][None, :]
    gradient, adiabatic = (case["wave"][None, :] / mass)**2, (hubble / mass)**2
    ratio = np.sqrt(1 + gradient)
    polynomial = 3 + 12 * gradient + 4 * gradient**2
    denominator = 8 * (1 + gradient)**3 - adiabatic * polynomial
    derivative_gradient = 24 * (1 + gradient)**2 - adiabatic * (12 + 8 * gradient)
    log_sideband = 1 + 5 * gradient / (1 + gradient) - 2 * (gradient * derivative_gradient - adiabatic * polynomial) / denominator
    log_carrier = (8 + 3 * adiabatic) / (8 - 3 * adiabatic)
    frequency_carrier = mass * (1 - 3 * adiabatic / 8)
    frequency_sideband = mass * (ratio - adiabatic * polynomial / (8 * ratio**5))
    beat = mass * gradient / (ratio + 1) * (1 + adiabatic * (3 * ratio**4 - ratio**3 - ratio**2 - 5 * ratio - 5) / (8 * ratio**5))
    return mass, frequency_carrier, frequency_sideband, -hubble * log_carrier / 2, -hubble * log_sideband / 2, beat


def template_matrix(frequency, slope, angle):
    amplitude = 1 / np.sqrt(frequency)
    cosine, sine = np.cos(angle), np.sin(angle)
    matrix = np.empty((*frequency.shape, 2, 2))
    matrix[..., 0, 0] = amplitude * cosine
    matrix[..., 0, 1] = amplitude * sine
    matrix[..., 1, 0] = amplitude * (slope * cosine - frequency * sine)
    matrix[..., 1, 1] = amplitude * (slope * sine + frequency * cosine)
    return matrix


def inverse_unit(matrix):
    inverse = np.empty_like(matrix)
    inverse[..., 0, 0] = matrix[..., 1, 1]
    inverse[..., 0, 1] = -matrix[..., 0, 1]
    inverse[..., 1, 0] = -matrix[..., 1, 0]
    inverse[..., 1, 1] = matrix[..., 0, 0]
    return inverse


def templates(case, positions):
    positions = np.asarray(positions).reshape(-1, 1)
    mass, carrier_frequency, sideband_frequency, carrier_slope, sideband_slope, _ = frequency_values(case, positions)
    carrier_angle = case["mu"] / case["hubble"] * np.expm1(positions) + 3 * case["hubble"] / (8 * case["mu"]) * np.expm1(-positions)
    nodes, weights = leggauss(8)
    beat_angle = np.zeros_like(mass)
    for node, weight in zip(nodes, weights):
        beat_angle += weight * frequency_values(case, positions * (node + 1) / 2)[-1] * positions / (2 * case["hubble"])
    return (template_matrix(carrier_frequency, carrier_slope, carrier_angle),
            template_matrix(sideband_frequency, sideband_slope, carrier_angle + beat_angle))


def force_matrix(case, positions):
    positions = np.asarray(positions).reshape(-1, 1)
    mass = case["mu"][None, :] * np.exp(positions)
    hubble = case["hubble"][None, :]
    combined = case["lapse"] + 3 * case["potential"]
    difference = 3 * case["potential"] - case["lapse"]
    matrix = np.empty((*mass.shape, 2, 2))
    matrix[..., 0, 0] = -hubble * combined
    matrix[..., 0, 1] = combined
    matrix[..., 1, 0] = mass**2 * difference - hubble**2 * combined
    matrix[..., 1, 1] = hubble * combined
    return matrix


def integrate_force(case, panels):
    nodes, weights = leggauss(16)
    result = np.zeros((len(case["wave"]), 2, 2))
    width = SPAN / panels
    for first_panel in range(0, panels, 8):
        guard()
        centers = (np.arange(first_panel, min(first_panel + 8, panels)) + .5) * width
        positions = (centers[:, None] + nodes[None, :] * width / 2).ravel()
        quadrature_weights = np.tile(weights, len(centers)) * width / 2
        carrier, sideband = templates(case, positions)
        integrand = inverse_unit(sideband) @ force_matrix(case, positions) @ carrier
        result += np.einsum("t,tnij->nij", quadrature_weights, integrand) / case["hubble"][:, None, None]
    return result


def prepare(case):
    previous = source_module("sealed_second_transport", SECOND / "transport_second_order.py")
    source_map = previous.frame(case, 0, 2)
    target = np.column_stack((case["density"] + (1 + source_map["background_pressure"]) * case["lapse"], case["phase"]))
    relative = np.linalg.solve(source_map["matrix"], target[:, :, None])[:, :, 0]
    _, carrier_frequency, sideband_frequency, carrier_slope, sideband_slope, _ = frequency_values(case, [0])
    carrier_frequency, sideband_frequency = carrier_frequency[0], sideband_frequency[0]
    carrier_slope, sideband_slope = carrier_slope[0], sideband_slope[0]
    amplitude = 1 / np.sqrt(carrier_frequency)
    states = np.zeros((len(case["wave"]), 4, 2))
    states[:, 0, 0] = amplitude
    states[:, 1, 0] = amplitude * carrier_slope
    states[:, 1, 1] = -amplitude * carrier_frequency
    states[:, 2, :] = amplitude[:, None] * relative
    physical_prime = amplitude[:, None] * np.column_stack((sideband_slope * relative[:, 0] + sideband_frequency * relative[:, 1],
                                                          sideband_slope * relative[:, 1] - sideband_frequency * relative[:, 0]))
    force_one = (case["lapse"] + 3 * case["potential"])[:, None] * (states[:, 1, :] - case["hubble"][:, None] * states[:, 0, :])
    states[:, 3, :] = physical_prime - force_one
    scale = np.maximum.reduce((np.linalg.norm(relative, axis=1),
                               abs(case["lapse"] * case["mu"] / case["hubble"]) * SPAN,
                               abs(case["lapse"]) + 3 * abs(case["potential"]), np.full(len(relative), 1e-100)))
    return states, scale, relative


def physical_coordinates(case, states):
    result = states.copy()
    force_one = (case["lapse"] + 3 * case["potential"])[:, None] * (states[:, 1, :] - case["hubble"][:, None] * states[:, 0, :])
    result[:, 3, :] += force_one
    return result


def normalized(case, states, scale):
    result = physical_coordinates(case, states)
    mass_root = np.sqrt(case["mu"])
    result[:, 0, :] *= mass_root[:, None]
    result[:, 1, :] /= mass_root[:, None]
    result[:, 2, :] *= (mass_root / scale)[:, None]
    result[:, 3, :] /= (mass_root * scale)[:, None]
    return result.transpose(0, 2, 1)


def propagate(case, initial, integral):
    carrier_first, sideband_first = (value[0] for value in templates(case, [0]))
    carrier_final, sideband_final = (value[0] for value in templates(case, [SPAN]))
    carrier_coefficients = inverse_unit(carrier_first) @ initial[:, :2, :]
    sideband_coefficients = inverse_unit(sideband_first) @ initial[:, 2:, :]
    final = np.empty_like(initial)
    final[:, :2, :] = carrier_final @ carrier_coefficients
    final[:, 2:, :] = sideband_final @ (sideband_coefficients + integral @ carrier_coefficients)
    return final


def stress(case, states, position):
    physical = physical_coordinates(case, states)
    carrier, carrier_prime, perturbation, perturbation_prime = (physical[:, index, :] for index in range(4))
    mass = case["mu"] * np.exp(position)
    hubble, lapse = case["hubble"][:, None], case["lapse"][:, None]
    speed = carrier_prime - hubble * carrier
    perturbation_speed = perturbation_prime - hubble * perturbation
    denominator = np.mean(speed**2 + mass[:, None]**2 * carrier**2, axis=1)
    kinetic = speed * perturbation_speed - speed**2 * lapse
    potential = mass[:, None]**2 * carrier * perturbation
    density = 2 * np.mean(kinetic + potential, axis=1) / denominator
    pressure = 2 * np.mean(kinetic - potential, axis=1) / denominator
    current = 2 * case["wave"] * np.mean(speed * perturbation, axis=1) / denominator
    return np.column_stack((density, -mass * current / case["wave"], pressure))


def direct_controls(case, initial, scale, expected):
    indices = np.array([int(np.argmin(abs(case["wave"] - target))) for target in (.03, .1, 1, 5)])
    selected = {name: value[indices] if isinstance(value, np.ndarray) else value for name, value in case.items()}
    start = normalized(selected, initial[indices], scale[indices])
    reference = normalized(selected, expected[indices], scale[indices])
    mass_initial = selected["mu"][:, None]
    hubble = selected["hubble"][:, None]
    wave = selected["wave"][:, None]
    lapse = selected["lapse"][:, None]
    scales = scale[indices, None]

    def rhs(position, flattened):
        guard()
        values = flattened.reshape(start.shape)
        mass = mass_initial * np.exp(position)
        carrier_omega = mass**2 - hubble**2
        result = np.empty_like(values)
        result[..., 0] = mass_initial / hubble * values[..., 1]
        result[..., 1] = -carrier_omega / (hubble * mass_initial) * values[..., 0]
        result[..., 2] = mass_initial / hubble * values[..., 3]
        result[..., 3] = -(carrier_omega + wave**2) / (hubble * mass_initial) * values[..., 2] - 2 * lapse * mass**2 / (hubble * mass_initial * scales) * values[..., 0]
        return result.ravel()

    finals, reports = [], []
    for relative_tolerance, absolute_tolerance in ((2e-11, 2e-13), (2e-12, 2e-14)):
        solution = solve_ivp(rhs, (0, SPAN), start.ravel(), method="DOP853", rtol=relative_tolerance,
                             atol=absolute_tolerance, t_eval=[SPAN])
        if not solution.success:
            raise ValueError(solution.message)
        final = solution.y[:, -1].reshape(start.shape)
        error = float(np.max(abs(final - reference)))
        check("independent physical KG rtol " + str(relative_tolerance), error, GATE)
        finals.append(final)
        reports.append(dict(rtol=relative_tolerance, atol=absolute_tolerance, evaluations=solution.nfev,
                            error=error, per_mode=np.max(abs(final - reference), axis=(1, 2)).tolist()))
    refinement = float(np.max(abs(finals[0] - finals[1])))
    check("direct KG tolerance refinement", refinement, GATE)
    altered = dict(selected)
    altered["potential"] = selected["potential"] + selected["lapse"] / 2
    adjusted = initial[indices].copy()
    adjusted[:, 3, :] -= (3 * (altered["potential"] - selected["potential"]))[:, None] * (adjusted[:, 1, :] - selected["hubble"][:, None] * adjusted[:, 0, :])
    changed = propagate(altered, adjusted, integrate_force(altered, 512))
    phi_error = float(np.max(abs(normalized(altered, changed, scale[indices]) - reference)))
    check("constant Phi cancels at same physical preparation", phi_error, ALGEBRA)
    return dict(indices=indices.tolist(), waves=selected["wave"].tolist(), reports=reports,
                refinement=refinement, constant_Phi_cancellation=phi_error)


def cold_control(case):
    damping = np.exp(-SPAN)
    change = -np.expm1(-SPAN)
    acceleration = case["wave"] * case["lapse"] / case["hubble"]
    velocity = case["velocity"] * damping + acceleration * change
    density = case["density"] - case["wave"] / case["hubble"] * (case["velocity"] * change + acceleration * (SPAN - change))
    final = np.column_stack((density - 3 * case["potential"], -case["mu"] * np.exp(SPAN) * velocity / case["wave"]))
    error = float(np.max(abs((final - case["saved_final"]) / case["normalizer"])))
    check("all399cold exact metric-held replay", error, GATE)
    return final, error


def metric_budgets(case, proof):
    bounds = {name: Fraction(value) for name, value in proof["enclosure"]["exact"].items()}
    rows = []
    for index in range(len(case["wave"])):
        potential = Fraction(float(case["potential"][index]))
        lapse = Fraction(float(case["lapse"][index]))
        radius = Fraction(float(case["lapse_rounding"][index])) + 3 * Fraction(float(case["potential_rounding"][index]))
        if radius < 0:
            raise ValueError("negative metric radius")
        integral_bound = bounds["J_coefficient_C"] * abs(lapse + 3 * potential) + bounds["J_coefficient_D"] * abs(3 * potential - lapse)
        source_bound = (bounds["J_coefficient_C"] + bounds["J_coefficient_D"]) * radius * bounds["source_error_factor"]
        truncation = integral_bound * bounds["forced_error_factor"]
        rows.append(dict(wave=float(case["wave"][index]), J_exact=str(integral_bound),
                         source_error_per_unit_c0_exact=str(source_bound), forced_truncation_per_unit_c0_exact=str(truncation),
                         J=float(integral_bound), source_error_per_unit_c0=float(source_bound), forced_truncation_per_unit_c0=float(truncation)))
    return rows


def main():
    with worker("numerical"):
        proof = read(ROOT / "proof.json")
        for path, checksum in proof["sources"].items():
            guard()
            if digest(path) != checksum:
                raise ValueError("changed inherited source " + path)
        heavy, cold = case_data("heavy"), case_data("cold")
        check("same399mode grid", np.max(abs(heavy["wave"] - cold["wave"])))
        for case in (heavy, cold):
            if not (np.all(case["mu"] >= 1490) and np.all(case["mu"] * np.exp(SPAN) <= 1510)
                    and np.all(case["hubble"] >= .0012) and np.all(case["hubble"] <= .0014)
                    and np.all(case["wave"] > 0) and np.all(case["wave"] <= 5)):
                raise ValueError("prior certificate box not applicable")
        initial, scale, relative = prepare(heavy)
        initial_stress = stress(heavy, initial, 0)
        initial_target = np.column_stack((heavy["density"], heavy["phase"]))
        check("prepared ensemble reproduces saved density and current", np.max(abs((initial_stress[:, :2] - initial_target) / heavy["normalizer"])))
        integrals, states, spectra = {}, {}, {}
        for panels in (128, 256, 512):
            integrals[panels] = integrate_force(heavy, panels)
            states[panels] = propagate(heavy, initial, integrals[panels])
            spectra[panels] = stress(heavy, states[panels], SPAN)
            print("completed panels=" + str(panels), flush=True)
        refinement = []
        for lower, higher in ((128, 256), (256, 512)):
            error = float(np.max(abs(normalized(heavy, states[lower], scale) - normalized(heavy, states[higher], scale))))
            source_error = float(np.max(abs((spectra[lower][:, :2] - spectra[higher][:, :2]) / heavy["normalizer"])))
            check("full forced field quadrature " + str((lower, higher)), error, GATE)
            check("forced source quadrature " + str((lower, higher)), source_error, GATE)
            refinement.append(dict(lower=lower, higher=higher, state_error=error, density_current_error=source_error))
        controls = direct_controls(heavy, initial, scale, states[512])
        cold_final, cold_error = cold_control(cold)
        budgets = metric_budgets(heavy, proof)
        target = ROOT / "forced-transport.npz"
        if target.exists():
            raise ValueError("preserve existing output")
        np.savez_compressed(target, wave=heavy["wave"], initial_canonical=initial, initial_source=initial_stress,
                            perturbation_scale=scale, initial_relative=relative, final128=states[128], final256=states[256],
                            final512=states[512], source128=spectra[128], source256=spectra[256], source512=spectra[512],
                            integral128=integrals[128], integral256=integrals[256], integral512=integrals[512], cold_final=cold_final)
        write("metric-budgets.json", dict(scope="constant supplied metric; exact rational bounds per unit initial carrier coefficient norm",
                                         excludes="initial-state uncertainty and general time-varying metric error", rows=budgets))
        result = dict(passed=True, heavy_rows=399, cold_rows=399, carrier_quadratures=2,
                      refinements=refinement, direct_controls=controls, cold_error=cold_error,
                      maximum_J=max(row["J"] for row in budgets),
                      maximum_forced_truncation_per_unit_c0=max(row["forced_truncation_per_unit_c0"] for row in budgets),
                      maximum_metric_rounding_per_unit_c0=max(row["source_error_per_unit_c0"] for row in budgets),
                      checks=CHECKS, fixed_tolerances=dict(algebra=ALGEBRA, numerical=GATE),
                      full_counter_rotating_integral=True, ensemble_not_time_average=True,
                      proof_sha256=digest(ROOT / "proof.json"), code_sha256=digest(__file__),
                      common_sha256=digest(ROOT / "common.py"), protocol_sha256=digest(ROOT / "PROTOCOL.md"),
                      output_sha256=digest(target), budgets_sha256=digest(ROOT / "metric-budgets.json"))
        write("numerical.json", result)
        print(json.dumps({name: value for name, value in result.items() if name not in ("checks",)}))


if __name__ == "__main__":
    main()
