import argparse
import ast
from live_memory_support import *


def validate():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'balanced-chain-contract.json')['source_hashes'])
    original_class=next(node for node in ast.parse((ROOT/'run_checked_mapping.py').read_text()).body if isinstance(node,ast.ClassDef) and node.name=='CheckedLiveMemory')
    reusable_class=next(node for node in ast.parse((ROOT/'checked_live_memory_model.py').read_text()).body if isinstance(node,ast.ClassDef))
    require(ast.dump(original_class)==ast.dump(reusable_class),'reusable model exactly matches accepted corrected class')
    checks={}
    results={}
    for case,label in (('cold','cold-live-memory'),('heavy','heavy-live-memory-balanced-chain')):
        report=read(ROOT/(label+'-result.json'))
        require(report['completed'],'all current-state runs complete')
        preflight=read(ROOT/(label+'-preflight.json'))
        require(preflight['passed'] and all_pass(preflight['checks']),'current-source chain and metric preflight')
        require(read(ROOT/(label+'-native-release.json'))['released'],'native owner released')
        require(read(ROOT/(label+'-capture-check.json'))['passed'],'original native and cache controls')
        capture=packet(ROOT/(label+'-capture.npz'))
        initial=packet(ROOT/(label+'-seeds.npz'))
        transformed=packet(ROOT/(label+'-preflight.npz'))['reference']
        active=report['active']
        dimension=report['dimension']
        packets={}
        for name,row in report['runs'].items():
            path=ROOT/(label+'-'+name+'.npz')
            require(digest(path)==row['packet_sha256'],'saved packet unchanged')
            data=packet(path)
            require(all(np.all(np.isfinite(value)) for value in data.values()),'finite saved arrays')
            require(np.array_equal(data['clock'],capture['clock']),'same65 output epochs')
            require(np.array_equal(data['candidate'],data['state'][:,:dimension]+data['state'][:,dimension:]),'candidate is base plus predictive correction')
            require(np.array_equal(data['initial'][dimension:],np.zeros(dimension)),'zero correction initially')
            mode=name.split('-')[0]
            require(np.array_equal(data['initial'][:dimension],initial[mode]),'retained initial state')
            checks[label+'/'+name+'/initial']={'state':comparison(data['state'][0],data['initial'],ALGEBRA)}
            checks[label+'/'+name+'/state']=columns(data['vector'][:,:active],capture['reference'][:,:active],'component_')
            checks[label+'/'+name+'/sources']=columns(data['observation'],capture['observation_reference'],'component_')
            checks[label+'/'+name+'/actual_derivative']=columns(data['actual_physical_derivative'][:,:active],capture['derivative_reference'][:,:active],'component_')
            checks[label+'/'+name+'/coordinates']=columns(data['candidate'],transformed,'component_')
            checks[label+'/'+name+'/equation_residual']=columns(data['predicted_rate'],data['exact_candidate_rate'],'component_')
            selected=np.flatnonzero(capture['cache_mask'][0])
            checks[label+'/'+name+'/cache']=columns(data['cache'][:,selected],capture['cache_reference'][:,selected],'component_')
            if case=='cold':
                require(np.array_equal(data['state'][:,dimension:],np.zeros_like(data['state'][:,dimension:])),'actual baseline has exactly zero correction')
            else:
                require(np.max(abs(data['state'][:,dimension:dimension+report['kept']]))>0,'rest correction actually evolves')
            kept_indices=np.array([index for index in range(active) if not report['first']<=index<report['first']+2*report['fields']])
            checks[label+'/'+name+'/retained_derivative_decode']=columns(data['actual_physical_derivative'][:,kept_indices],data['predicted_rate'][:,:report['kept']],'component_',ALGEBRA)
            packets[name]=data
        for left,right in [('reconstructed-step128-h1','reconstructed-step256-h1'),('reconstructed-step256-h1','reconstructed-step256-h2'),('reconstructed-step256-h2','captured-step256-h2')]:
            for key in ('vector','observation','actual_physical_derivative'):
                width=40 if key=='observation' else active
                checks[label+'/'+left+'/'+right+'/'+key]=columns(packets[left][key][:,:width],packets[right][key][:,:width],'component_')
        fine=packets['reconstructed-step256-h2']
        results[case]=dict(worst_fine=report['runs']['reconstructed-step256-h2']['worst'],maximum_rest_correction=report['runs']['reconstructed-step256-h2']['maximum_rest_correction'],uncorrected_sources=columns(fine['uncorrected_observation'],capture['observation_reference'],'component_'),corrected_sources=columns(fine['observation'],capture['observation_reference'],'component_'),all_original_run_gates_passed=report['passed'])
    passed=all_pass(checks) and all(value['all_original_run_gates_passed'] for value in results.values())
    write('validation.json',dict(passed=passed,checks=checks,count=sum(len(group) for group in checks.values()),results=results,reusable_checked_class_verified=True,current_rest_feedback=True,saved_future_rest_input=False,background_replaced=False,original_failed_attempts_preserved=True))
    print(json.dumps(dict(passed=passed,checks=sum(len(group) for group in checks.values()),worst_fine={case:value['worst_fine'] for case,value in results.items()},rest_corrections={case:value['maximum_rest_correction'] for case,value in results.items()}),default=convert),flush=True)


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['passed'],'paired live-memory validation')
    require((ROOT/'RESULTS.md').is_file() and (ROOT/'NEXT.md').is_file(),'saved result and next')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    excluded={'closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json'}
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write('closeout.json',dict(live_predictive_memory_validated=True,current_rest_feedback=True,prescribed_future_rest_history=False,retained_native_background=True,old_late_selector_replaced=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    allowed={'heavy-live-memory-stable-remainder':(22136,1794347014.0632088),'heavy-live-memory-checked-mapping':(25020,1794347156.186133)}
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        label=path.name.removesuffix('-start.json')
        if label=='postseal':
            continue
        owner=read(path)
        ending=read(ROOT/(label+'-end.json'))
        outcome=exited(owner)
        require(outcome['exited'],'prior owned worker exited')
        require(all(ending[key]==owner[key] for key in ('pid','created','command')),'matching identity')
        documented_failure=False
        if ending['state']!='completed':
            require(label in allowed and (owner['pid'],owner['created'])==allowed[label],'only documented failed preflights')
            require(ending['state']=='failed' and 'preflight' in ending['error'],'known diagnostic failures')
            require(read(ROOT/(label+'-native-release.json'))['released'],'failed native owner released')
            documented_failure=True
        workers.append(dict(name=label,identity=owner,outcome=outcome,recorded_state=ending['state'],documented_preflight_failure=documented_failure))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True,no_processes_killed=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('validate','seal','postseal'))
    arguments=parser.parse_args()
    with worker(arguments.operation) as identity:
        if arguments.operation=='postseal':
            postseal(identity)
        else:
            globals()[arguments.operation]()
