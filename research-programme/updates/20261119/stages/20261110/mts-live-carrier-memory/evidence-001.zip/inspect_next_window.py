from live_memory_support import *


with worker('next-window'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    results={}
    for case in ('cold','heavy'):
        source_path=TRANSFER/(case+'-transfer-source-readout.npz')
        capture_path=TRANSFER/(case+'-transfer-capture.npz')
        native_path=HANDOFF/('early-'+case+'-restart.npz')
        source=packet(source_path)
        capture=packet(capture_path)
        native=packet(native_path)
        indices=np.searchsorted(native['full_clock'],source['clock'])
        clock_match=bool(np.all(indices<len(native['full_clock'])) and np.array_equal(native['full_clock'][indices],source['clock']))
        signature_rows=np.unique(capture['signature'],axis=0)
        results[case]=dict(source_path=str(source_path),source_nodes=len(source['clock']),capture_path=str(capture_path),capture_nodes=len(capture['clock']),capture_matches_source_clock=bool(np.array_equal(capture['clock'],source['clock'])),unique_capture_signatures=len(signature_rows),native_path=str(native_path),native_indices=[int(indices[0]),int(indices[-1])],native_clock_match=clock_match,contiguous_native_indices=bool(np.all(np.diff(indices)==1)),paths_sha256={str(path):digest(path) for path in (source_path,capture_path,native_path)})
    write('next-window-inputs.json',dict(inspection_only=True,results=results,no_new_integration=True,script_sha256=digest(Path(__file__))))
    print(json.dumps(results),flush=True)
