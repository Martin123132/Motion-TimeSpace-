import ast
import run_live_memory as driver
from live_memory_model import *


class StableLiveMemory(LiveMemory):
    def memory_rhs(self,time,state,divisor):
        exact,approximate,unused=self.evaluate(time,state[:self.dimension],divisor)
        unused,correction_rate,unused=self.evaluate(time,state[self.dimension:],divisor)
        remainder=exact-approximate
        return np.r_[approximate,correction_rate+remainder]


check_hashes(read(ROOT/'frozen-inputs.json'))
require(not (ROOT/'heavy-live-memory-start.json').exists(),'no original heavy run to replace')
write('stable-remainder-contract.json',dict(reason='Arithmetic review before the first heavy dispatch: form the exact-minus-effective remainder before adding the small correction rate, preserving exact zero rest remainder rather than cancellation against the large base rate.',source_sha256=digest(Path(__file__)),original_model_sha256=digest(ROOT/'live_memory_model.py'),physical_equations_grids_tolerances_or_seeds_changed=False,cold_results_reused='cold-live-memory-result.json; correction stays exactly zero so both evaluation orders coincide'))
source=ROOT/'run_live_memory.py'
tree=ast.parse(source.read_text())
changes=[]
class Adapter(ast.NodeTransformer):
    def visit_Constant(self,node):
        if node.value=="args.case+'-live-memory'":
            changes.append('distinct_worker_label')
            return ast.copy_location(ast.Constant("args.case+'-live-memory-stable-remainder'"),node)
        return node
tree=Adapter().visit(tree)
require(changes==['distinct_worker_label'],'only output label changed in dispatch')
namespace=dict(__file__=__file__,__name__='stable_live_memory_driver')
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
namespace['LiveMemory']=StableLiveMemory
namespace['main']()
