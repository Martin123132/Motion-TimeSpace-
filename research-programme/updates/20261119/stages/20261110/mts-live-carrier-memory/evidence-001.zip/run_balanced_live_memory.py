import ast
from live_memory_model import *


check_hashes(read(ROOT/'frozen-inputs.json'))
for prefix in ('heavy-live-memory-stable-remainder','heavy-live-memory-checked-mapping'):
    ending=read(ROOT/(prefix+'-end.json'))
    require(ending['state']=='failed' and 'preflight' in ending['error'] and exited(ending)['exited'],'previous preflight exited')
    require(read(ROOT/(prefix+'-native-release.json'))['released'],'previous native owner released')
for case in ('cold','heavy'):
    diagnosis=read(ROOT/(case+'-live-memory-chain-diagnostic-diagnosis.json'))
    require(all(all(row['passed'] for row in diagnosis['checks'][str(divisor)].values()) for divisor in (768,1024)),'paired usable checker band')
class_source=ROOT/'run_checked_mapping.py'
node=next(item for item in ast.parse(class_source.read_text()).body if isinstance(item,ast.ClassDef) and item.name=='CheckedLiveMemory')
class_scope=dict(LiveMemory=LiveMemory,np=np)
exec(compile(ast.Module(body=[node],type_ignores=[]),str(class_source),'exec'),class_scope)
write('balanced-chain-contract.json',dict(independent_check_divisors=[768,1024],physical_metric_divisors=[4096,8192],gate=GATE,algebra=ALGEBRA,tolerance_or_physical_integrator_changed=False,diagnostic_informed_checker_selection=True,source_hashes={str(path):digest(path) for path in (Path(__file__),class_source,ROOT/'run_live_memory.py',ROOT/'cold-live-memory-chain-diagnostic-diagnosis.json',ROOT/'heavy-live-memory-chain-diagnostic-diagnosis.json')}))
source=ROOT/'run_live_memory.py'
tree=ast.parse(source.read_text())
changes=[]
class Adapter(ast.NodeTransformer):
    def visit_Constant(self,node):
        if node.value=="args.case+'-live-memory'":
            changes.append('distinct_label')
            return ast.copy_location(ast.Constant("args.case+'-live-memory-balanced-chain'"),node)
        return node
    def visit_Call(self,node):
        if isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='engine' and node.func.attr=='stencil':
            require(ast.unparse(node.args[-1])=='divisor // 4','only independent checker step changes')
            node.args[-1]=ast.parse('768 if divisor==4096 else 1024',mode='eval').body
            changes.append('checker_step')
        return self.generic_visit(node)
tree=Adapter().visit(tree)
require(changes==['checker_step','distinct_label'],'bounded checker-only driver changes')
namespace=dict(__file__=__file__,__name__='balanced_live_memory_driver')
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
namespace['LiveMemory']=class_scope['CheckedLiveMemory']
namespace['main']()
