from live_memory_model import *


class CheckedLiveMemory(LiveMemory):
    def geometry(self,values,hubble_prime=0.):
        result=super().geometry(values,hubble_prime)
        scale,rate,hubble,rest=values['extra']
        field,velocity,field_first,velocity_first,mass2,frequency=values['jets'][1]
        current_factor=scale/self.density0*np.sqrt(mass2)/2
        result['mapping_prime'][1,1]=-current_factor*(rate*field_first+rate*(2-mass2/frequency**2)*field)/frequency
        return result

    def memory_rhs(self,time,state,divisor):
        exact,approximate,unused=self.evaluate(time,state[:self.dimension],divisor)
        unused,correction_rate,unused=self.evaluate(time,state[self.dimension:],divisor)
        remainder=exact-approximate
        return np.r_[approximate,correction_rate+remainder]
