import ast
import sympy as symbolic
import run_live_memory as driver
from live_memory_model import *


class CheckedLiveMemory(LiveMemory):
    def geometry(self,values,hubble_prime=0.):
        result=super().geometry(values,hubble_prime)
        scale,rate,hubble,rest=values['extra']
        field,velocity,field_first,velocity_first,mass2,frequency=values['jets'][1]
        current_factor=scale/self.density0*np.sqrt(mass2)/2
        result['mapping_prime'][1,1]=-current_factor*(rate*field_first+rate*(2-mass2/frequency**2)*field)/frequency
        return result

    def memory_rhs(self,time,state,divisor):
        exact,approximate,unused=self.evaluate(time,state[:self.dimension],divisor)
        unused,correction_rate,unused=self.evaluate(time,state[self.dimension:],divisor)
        remainder=exact-approximate
        return np.r_[approximate,correction_rate+remainder]


check_hashes(read(ROOT/'frozen-inputs.json'))
failed=read(ROOT/'heavy-live-memory-stable-remainder-end.json')
require(failed['state']=='failed' and 'preflight' in failed['error'] and exited(failed)['exited'],'original heavy preflight stopped and exited')
require(read(ROOT/'heavy-live-memory-stable-remainder-native-release.json')['released'],'original native owner released')
beta,mass,field,frequency,rate,field_prime=symbolic.symbols('beta mass field frequency rate field_prime',nonzero=True)
entry=-beta*mass*field/(2*frequency)
derived=sum(symbolic.diff(entry,variable)*derivative for variable,derivative in ((beta,rate*beta),(mass,rate*mass),(field,field_prime),(frequency,rate*mass**2/frequency)))
expected=-beta*mass/(2*frequency)*(field_prime+rate*(2-mass**2/frequency**2)*field)
identity=symbolic.simplify(derived-expected)
require(identity==0,'correct map product rule')
write('checked-mapping-contract.json',dict(identity=str(identity),repair='restore background-field factor in mapping_prime[1,1], as in retained prop_model.py',script_sha256=digest(Path(__file__)),original_failed_owner=failed,original_model_sha256=digest(ROOT/'live_memory_model.py'),previous_correct_model_sha256=digest(CARRIER/'prop_model.py'),bank_grid_parameters_tolerances_or_seeds_changed=False,cold_baseline_reused=True))
source=ROOT/'run_live_memory.py'
tree=ast.parse(source.read_text())
changes=[]
class Adapter(ast.NodeTransformer):
    def visit_Constant(self,node):
        if node.value=="args.case+'-live-memory'":
            changes.append('distinct_worker_label')
            return ast.copy_location(ast.Constant("args.case+'-live-memory-checked-mapping'"),node)
        return node
tree=Adapter().visit(tree)
require(changes==['distinct_worker_label'],'only output label changed in dispatch')
namespace=dict(__file__=__file__,__name__='checked_live_memory_driver')
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
namespace['LiveMemory']=CheckedLiveMemory
namespace['main']()
