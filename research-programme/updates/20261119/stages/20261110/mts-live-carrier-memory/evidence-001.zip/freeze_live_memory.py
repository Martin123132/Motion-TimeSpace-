from live_memory_support import *


with worker('freeze'):
    require(digest(MEMORY_STAGE/'closeout.json')==EXPECTED_MEMORY,'retained predictive memory result')
    previous=read(MEMORY_STAGE/'closeout.json')
    check_hashes(previous['input_hashes'])
    check_hashes({str(MEMORY_STAGE/name):row['sha256'] for name,row in previous['artifacts'].items()})
    cleanup=read(MEMORY_STAGE/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and not cleanup['verifier_exit_requires_final_external_check'] and exited(cleanup['verifier_identity'])['exited'],'previous owner exited')
    source_hashes=read(LIVE/'frozen-inputs.json')
    additions=[MEMORY_STAGE/'closeout.json',MEMORY_STAGE/'CLEANUP-VERIFIED.json',MEMORY_STAGE/'CURRENT-STATE-MEMORY-LIFT.md',MEMORY_STAGE/'memory_support.py',CARRIER/'prop_support.py',CARRIER/'prop_model.py',SOURCESTATE/'source_state.py',SOURCESTATE/'closeout.json',LIVE/'run_live.py',LIVE/'live_support.py',PHASE/'phase_model.py',PHASE/'phase_support.py',NORMAL/'normal_support.py',ROOT/'PROTOCOL.md']
    for case in ('cold','heavy'):
        additions.extend([LIVE/(case+'-live-seeds.npz'),LIVE/(case+'-live-capture.npz')])
    additions.extend(sorted(ROOT.glob('*.py')))
    source_hashes.update({str(path):digest(path) for path in additions})
    check_hashes(source_hashes)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write('frozen-inputs.json',source_hashes)
    write('contract.json',dict(previous_turn='progress',windows={'matching':[2892,2956]},cases=['cold','heavy'],configs=[dict(name='step128-h1',steps=128,derivative_divisor=4096),dict(name='step256-h1',steps=256,derivative_divisor=4096),dict(name='step256-h2',steps=256,derivative_divisor=8192)],integration=dict(method='DOP853',rtol=1e-10,atol=1e-12),seed_modes='reconstructed all, captured fine control',gate=GATE,algebra=ALGEBRA,independent_chain_divisors=[1024,2048],current_native_rest_source=True,saved_future_rest_history=False,same_physical_bank_grid_parameters=True,new_averaged_background=False,goal_complete=False))
    print(json.dumps(dict(frozen=True,inputs=len(source_hashes),window=[2892,2956])),flush=True)
