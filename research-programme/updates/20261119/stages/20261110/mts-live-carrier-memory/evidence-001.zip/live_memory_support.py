import sys
from pathlib import Path
from time import monotonic

MEMORY_STAGE=Path(__file__).resolve().parent.parent/'mts-predictive-carrier-memory-20261110'
sys.path.insert(0,str(MEMORY_STAGE))
import memory_support as prior_support
from memory_support import *

ROOT=Path(__file__).resolve().parent
MEMORY_STAGE=ROOT.parent/'mts-predictive-carrier-memory-20261110'
SOURCESTATE=ROOT.parent/'mts-live-boundary-source-state-20261110'
EXPECTED_MEMORY='3df05e13a8295eafad673c6a9c9b77f21e486b659690303b2488c236f9c5f9a3'
shared=prior_support.retained_model.phase_module.retained.shared
shared.ROOT=ROOT
shared.START=monotonic()
base_guard=prior_support.base_guard
last_check=[-float('inf')]


def guard():
    current=monotonic()
    if current-last_check[0]>=1:
        base_guard()
        for folder in (MEMORY_STAGE,CARRIER,SOURCESTATE):
            require(not (folder/'STOP-REQUESTED').exists(),'owner hold '+str(folder))
        last_check[0]=current

