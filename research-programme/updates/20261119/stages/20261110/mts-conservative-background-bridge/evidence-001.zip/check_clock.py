from bridge_support import *
import numpy as np
from scipy.interpolate import CubicSpline


def main():
    with worker("clock"):
        require(preserved() == read(ROOT / "frozen-inputs.json"), "same sources")
        source = read(ROOT / "normalization-result.json")
        require(not source["passed"], "retain first coordinate-gate failure")
        rows = []
        for report in source["reports"]:
            with np.load(BACKGROUND / (report["case"] + "-background.npz"), allow_pickle=False) as packet:
                positions = packet["position"].copy()
                clock = packet["states"][:, 3].copy()
            require(np.all(np.diff(clock) > 0), "monotone saved conformal clock")
            inverse = CubicSpline(clock, positions)
            checks = []
            for entry in report["captured_checks"]:
                position = float(inverse(clock[0] + entry["fraction"] * (clock[-1] - clock[0])))
                expected_scale = float(np.exp(-np.log(11.) + position))
                error = float(abs(entry["inferred_actual_scale"] / expected_scale - 1))
                checks.append(dict(fraction=entry["fraction"], efold_offset=position,
                                   expected_scale=expected_scale, captured_scale=entry["inferred_actual_scale"],
                                   scale_error=error, amplitude_error=entry["amplitude_error"],
                                   passed=error <= ALGEBRA and entry["amplitude_error"] <= ALGEBRA))
            rows.append(dict(case=report["case"], checks=checks,
                             passed=all(entry["passed"] for entry in checks)
                             and max(report["standard_matter_error"], report["standard_radiation_error"]) <= ALGEBRA))
        result = dict(passed=all(row["passed"] for row in rows), reports=rows,
                      code_sha256=digest(__file__), normalization_sha256=digest(ROOT / "normalization-result.json"),
                      interpretation="Saved probe fraction is conformal-time fraction, not log-scale-factor fraction.",
                      new_native_initialization=False, new_evolution=False)
        write("normalization-clock-result.json", result)
        print(json.dumps(result, indent=2))
        require(result["passed"], "correct saved clock coordinates")


if __name__ == "__main__":
    main()
