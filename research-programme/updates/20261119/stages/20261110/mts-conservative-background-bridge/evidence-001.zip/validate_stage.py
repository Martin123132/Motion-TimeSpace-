from bridge_support import *
from background_bridge import ReferenceBackground, SPAN
import numpy as np


def main():
    with worker("validation"):
        checks = []

        def check(name, condition, **details):
            checks.append(dict(name=name, passed=bool(condition), **details))

        inputs = preserved()
        check("inherited inputs frozen", inputs == read(ROOT / "frozen-inputs.json"), count=len(inputs))
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            check("compile " + path.name, True)
        check("no local bytecode", not list(ROOT.rglob("__pycache__")))
        normalization = read(ROOT / "normalization-result.json")
        clock = read(ROOT / "normalization-clock-result.json")
        background = read(ROOT / "background-result.json")
        derivative = read(ROOT / "derivative-result.json")
        for report, name in ((normalization, "extract_normalization.py"), (clock, "check_clock.py"),
                             (background, "run_background.py"), (derivative, "verify_derivatives.py")):
            check("source hash " + name, report["code_sha256"] == digest(ROOT / name))
        check("original coordinate failure retained", not normalization["passed"]
              and read(ROOT / "normalization-end.json")["state"] == "failed")
        check("same normalization used by corrected clock", clock["normalization_sha256"] == digest(ROOT / "normalization-result.json"))
        check("correct coordinate gate passes", clock["passed"]
              and all(row["passed"] for case in clock["reports"] for row in case["checks"]))
        check("background normalization hash", background["normalization_sha256"] == digest(ROOT / "normalization-result.json"))
        check("derivative background hash", derivative["background_result_sha256"] == digest(ROOT / "background-result.json"))
        for report in (background, derivative):
            check("bridge model unchanged", report["model_sha256"] == digest(ROOT / "background_bridge.py"))
        for path, checksum in normalization["source_hashes"].items():
            check("native normalization source " + path, Path(path).is_file() and digest(path) == checksum)
        check("paired actual backgrounds", {row["case"] for row in background["reports"]} == {"cold", "heavy"} and len(background["reports"]) == 2)
        for report in background["reports"]:
            case = report["case"]
            owner = ReferenceBackground(case)
            with np.load(ROOT / (case + "-background.npz"), allow_pickle=False) as packet:
                check(case + " output hash", digest(ROOT / (case + "-background.npz")) == report["numerical_result_sha256"])
                check(case + " finite packet", all(np.all(np.isfinite(packet[name])) for name in packet.files))
                check(case + " same saved positions", np.array_equal(packet["position"], owner.saved["position"])
                      and packet["position"].shape == (33,) and packet["position"][0] == 0 and packet["position"][-1] == SPAN)
                check(case + " same initial slow data", np.array_equal(packet["states"][0, :2], owner.saved["states"][0, :2]))
                recomputed_constraint = float(np.max(abs(packet["jets"][:, 4] / (3 * packet["states"][:, 2]**2) - 1)))
                recomputed_refinement = float(np.max(abs(packet["states"] - packet["coarse_states"]) / packet["normalization"]))
                recomputed_grid = float(np.max(abs(packet["states"] - packet["alternate_states"]) / packet["normalization"]))
                check(case + " Friedmann directly from packet", recomputed_constraint == report["friedmann_error"] and recomputed_constraint <= ALGEBRA)
                check(case + " solver refinement directly from packet", recomputed_refinement == report["integration_refinement"] and recomputed_refinement <= GATE)
                check(case + " reference-grid refinement directly from packet", recomputed_grid == report["reference_grid_change"] and recomputed_grid <= GATE)
                check(case + " independently propagated clock", packet["states"][0, 3] == 0 and np.all(np.diff(packet["states"][:, 3]) > 0))
                check(case + " bad initial H rejected", abs(packet["jets"][0, 4] / (3 * (1.01 * packet["states"][0, 2])**2) - 1) > ALGEBRA)
                check(case + " carrier scope", packet["carrier"].shape == ((33, 6) if case == "heavy" else (0, 6)))
                original = next(row for row in normalization["reports"] if row["case"] == case)
                check(case + " mass and abundance unchanged", owner.neutrino_mass == original["neutrino_mass_over_temperature"]
                      and owner.neutrino_amplitude == original["amplitude_mpc_minus2"] and report["no_mass_or_abundance_retuning"])
            check(case + " derivative checks", len(report["derivative_controls"]) == 6
                  and all(row["passed"] and max(row["errors"]) <= GATE for row in report["derivative_controls"]))
            check(case + " pressure clock and grid jets", report["pressure_clock_jet_error"] <= ALGEBRA and report["reference_jet_grid_change"] <= GATE)
        check("three exact identities", derivative["proof"]["passed"] and len(derivative["proof"]["identities"]) == 3)
        check("independent derivative coverage", len(derivative["derivatives"]) == 30
              and {(row["case"], row["position"], row["degree"]) for row in derivative["derivatives"]}
              == {(case, position, degree) for case in ("cold", "heavy") for position in (0., .0005, .001) for degree in range(5)}
              and all(row["passed"] and max(row["errors_scaled_by_density_pressure"]) <= ALGEBRA for row in derivative["derivatives"]))
        check("independent carrier coverage", len(derivative["carriers"]) == 3
              and all(row["passed"] and max(row["relative_errors"]) <= ALGEBRA for row in derivative["carriers"]))
        check("mixed pressure diagnostic honestly labelled", len(derivative["mixed_old_pressure_diagnostics"]) == 6
              and all(row["diagnostic_only"] for row in derivative["mixed_old_pressure_diagnostics"]))
        check("no production or perturbation rerun", not background["production_changed"] and not background["new_perturbation_evolution"])
        for path in (ACTION / "action_model.py", ACTION / "series.py",
                     POST / "mts-source-complete-radiation-20261110/native_port.py"):
            check("cited retained interface " + str(path), path.is_file() and str(path) in inputs)
        processes = []
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name == "validation-start.json":
                continue
            identity = read(path)
            status = exited(identity)
            terminal = read(ROOT / path.name.replace("-start.json", "-end.json"))
            expected = "failed" if path.name == "normalization-start.json" else "completed"
            check("worker exited " + path.name, status["exited"])
            check("worker terminal " + path.name, terminal["state"] == expected
                  and all(terminal[key] == identity[key] for key in ("pid", "created", "command")))
            processes.append(dict(receipt=path.name, identity=identity, status=status, ending=terminal["state"]))
        result = dict(passed=all(row["passed"] for row in checks), checks=checks, workers=processes,
                      code_sha256=digest(__file__), inputs=len(inputs), source_hashes=normalization["source_hashes"],
                      scientific_outcome="Shared-distribution neutrino stresses propagated through paired late backgrounds and coherent scalar-carrier derivatives.",
                      new_background_reference=True, new_perturbation_evolution=False, production_changed=False)
        write("validation.json", result)
        print(json.dumps(dict(passed=result["passed"], checks=len(checks), inputs=len(inputs),
                              failed=[row for row in checks if not row["passed"]]), indent=2))
        require(result["passed"], "paired background bridge validation")


if __name__ == "__main__":
    main()
