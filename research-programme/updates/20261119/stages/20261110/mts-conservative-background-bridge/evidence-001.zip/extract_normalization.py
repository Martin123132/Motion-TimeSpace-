from bridge_support import *
import numpy as np


def main():
    with worker("normalization"):
        inputs = preserved()
        write("frozen-inputs.json", inputs)
        sys.path.insert(0, str(MATCHING))
        import matching_common as retained
        require(Path(retained.camb.__file__).resolve().is_relative_to(MATCHING / "native"), "retained native import")
        omega_m, slow_ratio = retained.previous.inherited_parameters()
        previous = read(BACKGROUND / "background-result.json")
        captured = read(POST / "mts-residual-species-budget-20261110/neutrino-prediction-result.json")
        continuum = read(POST / "mts-residual-species-budget-20261110/continuum-reference.json")
        reports = []
        for case in ("cold", "heavy"):
            guard()
            source = next(row for row in previous["models"] if row["model"] == case)
            with np.load(source["background_source"], allow_pickle=False) as table:
                fraction = float(table["fraction"])
            params = retained.previous.base_params(omega_m, fraction)
            native = retained.camb.get_background(params, no_thermo=True)
            count = int(native.Params.nu_mass_eigenstates)
            require(count == 1, "same single thermal eigenstate")
            mass = float(native.nu_masses[0])
            amplitude = float(native.grhormass[0])
            degeneracy = float(native.Params.nu_mass_degeneracies[0])
            target = float(params.omnuh2 / (params.H0 / 100)**2 * native.grhocrit / amplitude)
            with np.load(BACKGROUND / (case + "-background.npz"), allow_pickle=False) as packet:
                unit = float(packet["unit"])
                radiation = float(packet["standard_radiation"])
                matter = float(packet["standard_matter"])
                saved_scale = float(np.exp(-np.log(11.) + packet["position"][0]))
            matter_error = abs((native.grhob + native.grhoc) / (3 * unit**2 * matter) - 1)
            radiation_error = abs((native.grhog + native.grhornomass) / (3 * unit**2 * radiation) - 1)
            comparisons = []
            for fraction_time in (0., .5, 1.):
                entry = next(row for row in continuum["reports"] if row["case"] == case and row["fraction"] == fraction_time)
                sample = next(row for row in captured["reports"] if row["case"] == case and row["enabled"] and row["fraction"] == fraction_time)
                requested_scale = saved_scale * np.exp(.001 * fraction_time)
                inferred_scale = entry["am"] / mass
                normalization_from_source = sample["quadrature_enthalpy"] / entry["five_node_enthalpy"] * inferred_scale**2
                comparisons.append(dict(fraction=fraction_time, captured_am=entry["am"],
                                        inferred_actual_scale=inferred_scale, requested_scale=requested_scale,
                                        scale_difference=float(inferred_scale / requested_scale - 1),
                                        amplitude_from_captured_weights=normalization_from_source,
                                        amplitude_error=float(abs(normalization_from_source / amplitude - 1))))
            densities = native.get_background_densities(np.array([1.]), vars=["nu"])
            present_density = float(densities["nu"][0])
            reports.append(dict(case=case, heavy_fraction=fraction, omega_m=float(omega_m), inferred_slow_ratio=float(slow_ratio),
                                nominal_input_mnu_eV=float(retained.previous.NEUTRINO_MASS),
                                input_omnuh2=float(params.omnuh2), input_H0=float(params.H0),
                                input_Tcmb=float(params.TCMB), eigenstate_count=count,
                                neutrino_mass_over_temperature=mass, amplitude_mpc_minus2=amplitude,
                                degeneracy=degeneracy, grhor=float(native.grhor), grhocrit=float(native.grhocrit),
                                grhob=float(native.grhob), grhoc=float(native.grhoc), grhog=float(native.grhog),
                                grhornomass=float(native.grhornomass), target_dimensionless_density=target,
                                native_present_dimensionless_density=present_density / amplitude,
                                native_density_target_error=float(present_density / (amplitude * target) - 1),
                                standard_matter_error=float(matter_error), standard_radiation_error=float(radiation_error),
                                captured_checks=comparisons, source_background=source["background_source"],
                                passed=bool(max(matter_error, radiation_error, *(row["amplitude_error"] for row in comparisons)) <= ALGEBRA
                                            and max(abs(row["scale_difference"]) for row in comparisons) <= ALGEBRA)))
        paths = [MATCHING / "native/fortran/results.f90", MATCHING / "native/fortran/massive_neutrinos.f90",
                 MATCHING / "native/camb/model.py", MATCHING / "native/camb/constants.py",
                 POST / "condensate-origin-20261003/radiation-and-slow-field-transfer-20261007/radiation_common.py"]
        result = dict(passed=all(row["passed"] for row in reports), reports=reports,
                      source_hashes={str(path): digest(path) for path in paths}, code_sha256=digest(__file__),
                      native_module_path=retained.camb.__file__,
                      convention="Hold the actual native inferred mass and temperature/degeneracy amplitude fixed; report rather than cancel changes in represented present density.",
                      new_fit=False, new_perturbation_evolution=False)
        write("normalization-result.json", result)
        print(json.dumps(result, indent=2))
        require(result["passed"], "native initialization versus saved source normalization")


if __name__ == "__main__":
    main()
