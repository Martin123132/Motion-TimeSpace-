from bridge_support import *


def main():
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    seal = read(ROOT / "closeout.json")
    require(seal["state"] == "verified_progress_conservative_background_bridge", "expected seal")
    for path, checksum in seal["input_hashes"].items():
        guard()
        require(digest(path) == checksum, "inherited hash " + path)
    for name, entry in seal["artifacts"].items():
        require(digest(ROOT / name) == entry["sha256"] and (ROOT / name).stat().st_size == entry["bytes"], "artifact " + name)
    workers = []
    for path in sorted(ROOT.glob("*-start.json")):
        identity = read(path)
        status = exited(identity)
        terminal = read(ROOT / path.name.replace("-start.json", "-end.json"))
        require(status["exited"], "worker live " + path.name)
        require(all(terminal[key] == identity[key] for key in ("pid", "created", "command")), "terminal identity")
        workers.append(dict(receipt=path.name, identity=identity, status=status, ending=terminal["state"]))
    require(not list(ROOT.rglob("__pycache__")), "no bytecode")
    write("CLEANUP-VERIFIED.json", dict(passed=True, utc=datetime.now(timezone.utc).isoformat(),
          seal_sha256=digest(ROOT / "closeout.json"), input_count=len(seal["input_hashes"]),
          artifacts=len(seal["artifacts"]), workers=workers,
          verifier_identity=dict(pid=process.pid, created=process.create_time(), command=process.cmdline()),
          verifier_exit="Confirm this short verifier exited from its launching tool result.",
          apps_started=[], servers_started=[], continuing_job=False, unrelated_processes_changed=False,
          cleanup_action="Verified task-owned workers exited; no process killed."))
    print(json.dumps(dict(passed=True, seal_sha256=digest(ROOT / "closeout.json"),
                          inherited_files=len(seal["input_hashes"]), artifacts=len(seal["artifacts"]),
                          exited_workers=len(workers), verifier_pid=process.pid)))


if __name__ == "__main__":
    main()
