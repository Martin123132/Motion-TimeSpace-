from bridge_support import *
from background_bridge import ReferenceBackground, CENTER, SPAN
from scipy.interpolate import CubicSpline
import numpy as np


def main():
    with worker("background"):
        require(preserved() == read(ROOT / "frozen-inputs.json"), "same retained sources")
        normalization = read(ROOT / "normalization-result.json")
        reports = []
        for case in ("cold", "heavy"):
            guard()
            owner = ReferenceBackground(case, 64)
            coarse, scales = owner.solve(2e-11)
            fine, fine_scales = owner.solve(2e-12)
            require(np.array_equal(scales, fine_scales), "same initial normalization")
            alternate = ReferenceBackground(case, 32)
            alternate_solution, alternate_scales = alternate.solve(2e-12)
            positions = owner.saved["position"].copy()
            states = fine.sol(positions).T * scales
            coarse_states = coarse.sol(positions).T * scales
            alternate_states = alternate_solution.sol(positions).T * alternate_scales
            jets = np.array([owner.jets(position, state) for position, state in zip(positions, states)])
            alternate_jets = np.array([alternate.jets(position, state) for position, state in zip(positions, alternate_states)])
            carrier = np.array([owner.carrier(position, state) for position, state in zip(positions, states)]) if case == "heavy" else np.empty((0, 6))
            refinement = float(np.max(abs((states - coarse_states) / scales)))
            grid_error = float(np.max(abs((states - alternate_states) / scales)))
            constraint = float(np.max(abs(jets[:, 4] / (3 * states[:, 2]**2) - 1)))
            pressure_clock = max(owner.pressure_clock_error(position, state) for position, state in zip(positions, states))
            jet_scales = np.maximum(abs(jets), np.column_stack([states[:, 2]**power for power in (1, 2, 3, 4, 2, 2, 3, 4)]))
            jet_grid_error = float(np.max(abs(jets - alternate_jets) / jet_scales))
            saved_changes = np.max(abs(states - owner.saved["states"]) / scales, axis=0)
            controls = []
            for position in (.00025, .0005, .00075):
                for step in (1e-5, 5e-6):
                    sample = position + np.array([-2., -1., 0., 1., 2.]) * step
                    sample_states = fine.sol(sample).T * scales
                    sample_jets = np.array([owner.jets(location, state) for location, state in zip(sample, sample_states)])
                    derivative = (sample_jets[0, :3] - 8 * sample_jets[1, :3] + 8 * sample_jets[3, :3] - sample_jets[4, :3]) / (12 * step) * sample_jets[2, 0]
                    errors = abs(derivative - sample_jets[2, 1:4]) / sample_jets[2, 0]**np.array([2, 3, 4])
                    controls.append(dict(position=position, step=step, errors=errors.tolist(), passed=bool(max(errors) <= GATE)))
            present = owner.parts(-CENTER, 0., 0.)
            entry = next(row for row in normalization["reports"] if row["case"] == case)
            represented_density = present["neutrino"] / owner.neutrino_amplitude
            density_shift = represented_density / entry["target_dimensionless_density"] - 1
            passed = refinement <= GATE and grid_error <= GATE and jet_grid_error <= GATE and constraint <= ALGEBRA and pressure_clock <= ALGEBRA and all(row["passed"] for row in controls)
            np.savez_compressed(ROOT / (case + "-background.npz"), position=positions, states=states,
                                coarse_states=coarse_states, alternate_states=alternate_states,
                                jets=jets, alternate_jets=alternate_jets, carrier=carrier, normalization=scales,
                                original_states=owner.saved["states"], original_jets=owner.saved["jets"])
            result = dict(case=case, passed=bool(passed), integration_refinement=refinement,
                          reference_grid_change=grid_error, reference_jet_grid_change=jet_grid_error,
                          friedmann_error=constraint, pressure_clock_jet_error=pressure_clock,
                          maximum_changes_from_saved_by_state=saved_changes.tolist(),
                          saved_state_order=["slow field", "slow conformal velocity", "conformal H", "elapsed conformal time"],
                          derivative_controls=controls, native_target_density=entry["target_dimensionless_density"],
                          reference_present_dimensionless_density=represented_density,
                          represented_present_density_shift=float(density_shift),
                          original_native_target_error=entry["native_density_target_error"],
                          evaluations=[coarse.nfev, fine.nfev, alternate_solution.nfev],
                          no_mass_or_abundance_retuning=True, new_perturbation_evolution=False,
                          numerical_result_sha256=digest(ROOT / (case + "-background.npz")))
            reports.append(result)
            print(json.dumps(result, indent=2), flush=True)
        result = dict(passed=all(row["passed"] for row in reports), reports=reports,
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "background_bridge.py"),
                      normalization_sha256=digest(ROOT / "normalization-result.json"),
                      production_changed=False, new_background_reference=True, new_perturbation_evolution=False)
        write("background-result.json", result)
        require(result["passed"], "paired background, derivative and carrier clock control")


if __name__ == "__main__":
    main()
