from bridge_support import *
from background_bridge import ReferenceBackground, CENTER
import numpy as np
import mpmath as mp
import sympy as sym
from scipy.interpolate import PPoly


def prove():
    field, velocity, mass, hubble, density, pressure = sym.symbols(
        "field velocity mass hubble density pressure", real=True, nonzero=True)
    scalar_density = (velocity**2 + mass**2 * field**2) / 2
    scalar_pressure = (velocity**2 - mass**2 * field**2) / 2
    scalar_rate = (sym.diff(scalar_density, field) * velocity / hubble
                   + sym.diff(scalar_density, velocity) * (-2 * velocity - mass**2 * field / hubble)
                   + sym.diff(scalar_density, mass) * mass)
    identities = dict(
        slow_energy=scalar_rate + scalar_density + 3 * scalar_pressure,
        propagated_friedmann=6 * hubble * (-(density + 3 * pressure) / (6 * hubble)) + density + 3 * pressure,
        pressure_clock=(-2 * (-(density + 3 * pressure) / 6) - hubble**2 - pressure).subs(density, 3 * hubble**2))
    for name, expression in identities.items():
        require(sym.simplify(expression) == 0, name)
    return dict(passed=True, identities=list(identities),
                neutrino_recurrence="R_N=2R-3S, P=S-R; initial R is the actual shell integral, not a free constant.")


def independent_neutrino(owner, position, degree):
    nodes = [mp.mpf(float(value)) for value in owner.nodes]
    weights = [mp.mpf(float(value)) for value in owner.weights]
    amplitude = mp.mpf(owner.neutrino_amplitude)
    mass0 = mp.mpf(owner.neutrino_mass)
    efold0 = mp.mpf(float(CENTER + position))

    def integrals(offset, pressure=False):
        scale = mp.exp(efold0 + offset)
        mass = scale * mass0
        result = mp.mpf(0)
        for node, weight in zip(nodes, weights):
            energy = mp.sqrt(node**2 + mass**2)
            if pressure:
                primitive = (node * energy * (2 * node**2 - 3 * mass**2) + 3 * mass**4 * mp.asinh(node / mass)) / 8
                result += 4 * weight * primitive / (3 * node**4)
            else:
                primitive = (node * energy * (2 * node**2 + mass**2) - mass**4 * mp.asinh(node / mass)) / 8
                result += 4 * weight * primitive / node**4
        return amplitude / scale**2 * result

    return [mp.diff(lambda offset: integrals(offset, pressure), 0, degree) for pressure in (False, True)]


def independent_carrier(owner, position, jets):
    mass0 = mp.exp(mp.mpf(float(CENTER + position))) * mp.mpf(owner.heavy_mass)
    hubble0, prime, density, pressure0, pressure_prime = [mp.mpf(float(jets[index])) for index in (0, 1, 4, 5, 6)]
    wave = mp.mpf(5)

    def values(offset):
        mass = mass0 * mp.exp(offset)
        hubble = hubble0 + prime / hubble0 * offset
        pressure = pressure0 + pressure_prime / hubble0 * offset
        ratio = mp.sqrt(1 + (wave / mass)**2)
        pressure_piece = 3 * pressure / (8 * mass)
        carrier = mass + pressure_piece
        beat = (wave**2 / mass / (ratio + 1)) * (
            1 - pressure / mass**2 * (3 * ratio**2 + ratio + 1) / (8 * ratio**3)
            - hubble**2 / mass**2 * (ratio + 1) * (2 * ratio**2 + 5) / (8 * ratio**5))
        return mass, carrier, pressure_piece, beat

    result = list(values(mp.mpf(0)))
    carrier_rate = hubble0 * mp.diff(lambda offset: values(offset)[1], 0)
    sideband_rate = hubble0 * mp.diff(lambda offset: values(offset)[1] + values(offset)[3], 0)
    result.extend([-carrier_rate / (2 * result[1]), -sideband_rate / (2 * (result[1] + result[3]))])
    return result


def main():
    with worker("derivatives"):
        require(read(ROOT / "background-result.json")["passed"], "completed paired background")
        require(preserved() == read(ROOT / "frozen-inputs.json"), "same inputs")
        mp.mp.dps = 60
        proof = prove()
        derivatives, carriers, mixed = [], [], []
        for case in ("cold", "heavy"):
            owner = ReferenceBackground(case)
            with np.load(ROOT / (case + "-background.npz"), allow_pickle=False) as packet:
                positions, states, jets = packet["position"].copy(), packet["states"].copy(), packet["jets"].copy()
                saved_carriers = packet["carrier"].copy()
            old_log = PPoly(owner.saved["nu_coefficients"], owner.saved["nu_knots"])
            for index in (0, 16, 32):
                guard()
                position, state = positions[index], states[index]
                scale, neutrino, neutrino_pressure = owner.neutrino_series(position)
                for degree in range(5):
                    expected = independent_neutrino(owner, position, degree)
                    actual = [neutrino.coefficients[degree, 0], neutrino_pressure.coefficients[degree, 0]]
                    errors = [float(abs(mp.mpf(float(value)) * mp.factorial(degree) - target)
                                    / abs(mp.mpf(float(series.value[0]))))
                              for value, target, series in zip(actual, expected, (neutrino, neutrino_pressure))]
                    derivatives.append(dict(case=case, position=float(position), degree=degree,
                                            errors_scaled_by_density_pressure=errors, passed=max(errors) <= ALGEBRA))
                if case == "heavy":
                    expected = independent_carrier(owner, position, jets[index])
                    errors = [float(abs(mp.mpf(float(actual)) - target) / abs(target))
                              for actual, target in zip(saved_carriers[index], expected)]
                    carriers.append(dict(position=float(position), relative_errors=errors, passed=max(errors) <= ALGEBRA,
                                         pressure_frequency_piece=float(expected[2]), beat=float(expected[3])))
                efold = CENTER + position
                old_density = 3 * owner.unit**2 * np.exp(old_log(efold) - 2 * efold)
                old_pressure = old_density * (1 - old_log(efold, 1)) / 3
                mixed_residual = float(neutrino.coefficients[1, 0] + neutrino.value[0] + 3 * old_pressure)
                mixed.append(dict(case=case, position=float(position), incompatible_neutrino_energy_budget_per_efold=mixed_residual,
                                  relative_to_total_density=float(abs(mixed_residual) / jets[index, 4]),
                                  diagnostic_only=True))
        report = dict(passed=proof["passed"] and all(row["passed"] for row in derivatives + carriers),
                      proof=proof, derivatives=derivatives, carriers=carriers, mixed_old_pressure_diagnostics=mixed,
                      decimal_precision=mp.mp.dps, code_sha256=digest(__file__),
                      model_sha256=digest(ROOT / "background_bridge.py"),
                      background_result_sha256=digest(ROOT / "background-result.json"))
        write("derivative-result.json", report)
        print(json.dumps(dict(passed=report["passed"], identities=proof["identities"],
                              derivative_cases=len(derivatives),
                              largest_derivative_error=max(max(row["errors_scaled_by_density_pressure"]) for row in derivatives),
                              carriers=carriers, mixed=mixed,
                              failed=[row for row in derivatives + carriers if not row["passed"]]), indent=2))
        require(report["passed"], "independent background recurrence and carrier derivatives")


if __name__ == "__main__":
    main()
