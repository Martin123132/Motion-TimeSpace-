from bridge_support import *
import importlib.util
import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline

sys.path.insert(0, str(SOURCE))
from shell_model import moments

series_specification = importlib.util.spec_from_file_location("retained_background_series", ACTION / "series.py")
series_module = importlib.util.module_from_spec(series_specification)
series_specification.loader.exec_module(series_module)
Series, ORDER = series_module.Series, series_module.ORDER
CENTER, SPAN = -np.log(11.), .001


def summed(series):
    return Series(coefficients=np.sum(series.coefficients, axis=1, keepdims=True))


class ReferenceBackground:
    def __init__(self, case, count=64):
        require(case in ("cold", "heavy") and count in (32, 64), "fixed reference family")
        self.case, self.count = case, count
        require(read(ROOT / "normalization-clock-result.json")["passed"], "verified native normalization and clock")
        report = next(row for row in read(ROOT / "normalization-result.json")["reports"] if row["case"] == case)
        self.neutrino_mass = report["neutrino_mass_over_temperature"]
        self.neutrino_amplitude = report["amplitude_mpc_minus2"]
        with np.load(SOURCE / "shell-rules.npz", allow_pickle=False) as packet:
            self.nodes = packet["gauss" + str(count) + "_nodes"].copy()
            self.weights = packet["gauss" + str(count) + "_weights"].copy()
        with np.load(BACKGROUND / (case + "-background.npz"), allow_pickle=False) as packet:
            self.saved = {name: packet[name].copy() for name in packet.files}
        self.unit = float(self.saved["unit"])
        self.slow_mass = float(self.saved["slow_mass"])
        self.heavy_mass = float(self.saved["heavy_mass"])
        self.dust_amplitude = 3 * self.unit**2 * float(self.saved["standard_matter"]) + float(self.saved["matching_density"])
        self.radiation_amplitude = 3 * self.unit**2 * float(self.saved["standard_radiation"])

    def parts(self, position, field, velocity):
        scale = np.exp(CENTER + position)
        values = moments(self.nodes, self.weights, scale * self.neutrino_mass)
        prefactor = self.neutrino_amplitude / scale**2
        neutrino = float(prefactor * values["density"])
        neutrino_pressure = float(prefactor * values["pressure"])
        dust = self.dust_amplitude / scale
        radiation = self.radiation_amplitude / scale**2
        scalar_mass = scale * self.slow_mass
        scalar_density = (velocity**2 + scalar_mass**2 * field**2) / 2
        scalar_pressure = (velocity**2 - scalar_mass**2 * field**2) / 2
        density = dust + radiation + neutrino + scalar_density
        pressure = radiation / 3 + neutrino_pressure + scalar_pressure
        return dict(density=density, pressure=pressure, neutrino=neutrino,
                    neutrino_pressure=neutrino_pressure, scale=scale, scalar_mass=scalar_mass,
                    neutrino_enthalpy=float(prefactor * values["enthalpy"]))

    def solve(self, tolerance):
        field, velocity = self.saved["states"][0, :2]
        hubble = np.sqrt(self.parts(0., field, velocity)["density"] / 3)
        initial = np.array([field, velocity, hubble, 0.])
        normalization = np.array([max(abs(field), 1e-100), max(abs(velocity), 1e-100), hubble, SPAN / hubble])

        def rhs(position, normalized):
            guard()
            field, velocity, hubble, clock = normalized * normalization
            values = self.parts(position, field, velocity)
            return np.array([velocity / hubble,
                             -2 * velocity - values["scalar_mass"]**2 * field / hubble,
                             -(values["density"] + 3 * values["pressure"]) / (6 * hubble),
                             1 / hubble]) / normalization

        solution = solve_ivp(rhs, (0, SPAN), initial / normalization, method="DOP853",
                             rtol=tolerance, atol=tolerance / 100, dense_output=True)
        require(solution.success, "background integration: " + solution.message)
        return solution, normalization

    def neutrino_series(self, position):
        efold = Series(CENTER + position)
        efold.coefficients[1] = 1
        scale = efold.exp()
        mass = scale * self.neutrino_mass
        energy = (mass**2 + self.nodes**2).sqrt()
        enthalpy = summed(4 * self.weights * energy / (3 * self.nodes)) * self.neutrino_amplitude / scale**2
        values = moments(self.nodes, self.weights, float(mass.value[0]))
        density = Series(float(values["density"]) * self.neutrino_amplitude / float(scale.value[0])**2)
        for degree in range(ORDER):
            density.coefficients[degree + 1] = (2 * density.coefficients[degree] - 3 * enthalpy.coefficients[degree]) / (degree + 1)
        return scale, density, enthalpy - density

    def series(self, position, state):
        scale, neutrino, neutrino_pressure = self.neutrino_series(position)
        field, velocity, hubble = [Series(value) for value in state[:3]]
        scalar_mass = scale * self.slow_mass
        dust, radiation = self.dust_amplitude / scale, self.radiation_amplitude / scale**2
        for degree in range(ORDER):
            density = dust + radiation + neutrino + (velocity**2 + scalar_mass**2 * field**2) / 2
            pressure = radiation / 3 + neutrino_pressure + (velocity**2 - scalar_mass**2 * field**2) / 2
            rates = [velocity / hubble, -2 * velocity - scalar_mass**2 * field / hubble,
                     -(density + 3 * pressure) / (6 * hubble)]
            for series, rate in zip((field, velocity, hubble), rates):
                series.coefficients[degree + 1] = rate.coefficients[degree] / (degree + 1)
        density = dust + radiation + neutrino + (velocity**2 + scalar_mass**2 * field**2) / 2
        pressure = radiation / 3 + neutrino_pressure + (velocity**2 - scalar_mass**2 * field**2) / 2
        return dict(scale=scale, field=field, velocity=velocity, hubble=hubble,
                    density=density, pressure=pressure, neutrino=neutrino, neutrino_pressure=neutrino_pressure)

    def jets(self, position, state):
        values = self.series(position, state)
        hubble = values["hubble"]
        derivatives = [hubble]
        for unused in range(3):
            derivatives.append(hubble * derivatives[-1].derivative())
        pressure = values["pressure"]
        pressure_prime = hubble * pressure.derivative()
        return np.array([item.value[0] for item in derivatives] +
                        [values["density"].value[0], pressure.value[0], pressure_prime.value[0],
                         (hubble * pressure_prime.derivative()).value[0]])

    def carrier(self, position, state):
        values = self.series(position, state)
        hubble, pressure = values["hubble"], values["pressure"]
        mass = values["scale"] * self.heavy_mass
        wave = 5.
        gradient = Series(wave**2) / mass**2
        ratio = (1 + gradient).sqrt()
        pressure_piece = 3 * pressure / (8 * mass)
        carrier = mass + pressure_piece
        beat = mass * gradient / (ratio + 1) * (
            1 - pressure / mass**2 * (3 * ratio**2 + ratio + 1) / (8 * ratio**3)
            - hubble**2 / mass**2 * (ratio + 1) * (2 * ratio**2 + 5) / (8 * ratio**5))
        sideband = carrier + beat
        slope0 = -hubble * carrier.derivative() / (2 * carrier)
        slopek = -hubble * sideband.derivative() / (2 * sideband)
        return np.array([mass.value[0], carrier.value[0], pressure_piece.value[0], beat.value[0],
                         slope0.value[0], slopek.value[0]])

    def pressure_clock_error(self, position, state):
        values = self.series(position, state)
        hubble = values["hubble"]
        metric_pressure = -2 * hubble * hubble.derivative() - hubble**2
        mismatch = metric_pressure.coefficients[:4] - values["pressure"].coefficients[:4]
        return float(np.max(abs(mismatch)) / float(hubble.value[0]**2))
