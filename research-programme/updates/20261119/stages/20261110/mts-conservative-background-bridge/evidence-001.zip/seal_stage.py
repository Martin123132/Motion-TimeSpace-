from bridge_support import *


def main():
    with worker("seal"):
        validation = read(ROOT / "validation.json")
        require(validation["passed"] and validation["code_sha256"] == digest(ROOT / "validate_stage.py"), "validated same code")
        inputs = preserved()
        require(inputs == read(ROOT / "frozen-inputs.json"), "frozen source set")
        for path, checksum in validation["source_hashes"].items():
            require(digest(path) == checksum, "normalization source " + path)
            require(path not in inputs or inputs[path] == checksum, "conflicting source hash")
            inputs[path] = checksum
        compiled = []
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            compiled.append(path.name)
        for name in ("PROTOCOL.md", "DERIVATION.md", "RESULTS.md", "NEXT.md", "CLOCK-COORDINATE-REPAIR.md"):
            require((ROOT / name).is_file(), "document " + name)
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name != "seal-start.json":
                require(exited(read(path))["exited"], "worker live " + path.name)
        require(not list(ROOT.rglob("__pycache__")), "no bytecode")
    artifacts = {}
    for path in sorted(ROOT.iterdir()):
        require(path.is_file() and path.name != "closeout.json", "unexpected artifact or reseal")
        artifacts[path.name] = dict(sha256=digest(path), bytes=path.stat().st_size)
    write("closeout.json", dict(state="verified_progress_conservative_background_bridge",
          utc=datetime.now(timezone.utc).isoformat(), goal_complete=False, input_hashes=inputs,
          artifacts=artifacts, validation_checks=len(validation["checks"]), compiled=compiled,
          new_background_reference=True, new_perturbation_evolution=False, production_changed=False,
          new_fitted_parameters=0, next="NEXT.md"))
    print(json.dumps(dict(seal_sha256=digest(ROOT / "closeout.json"), inputs=len(inputs),
                          artifacts=len(artifacts), checks=len(validation["checks"]))))


if __name__ == "__main__":
    main()
