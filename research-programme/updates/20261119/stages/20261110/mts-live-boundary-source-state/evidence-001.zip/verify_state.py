from state_support import *
import argparse


def validate():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'balanced-check-contract.json')['sources'])
    require(not read(ROOT/'heavy-source-state-derivative-check.json')['passed'],'preserved failed original heavy diagnostic')
    checks={}
    summaries={}
    turning_controls={}
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    for case in ('cold','heavy'):
        label=case+'-source-state'+('-balanced-check' if case=='heavy' else '')
        result=read(ROOT/(label+'-result.json'))
        require(result['completed'] and result['passed'] and len(result['runs'])==6,'six completed source-state runs '+case)
        require(read(ROOT/(label+'-native-release.json'))['released'],'native owner released '+case)
        require(read(ROOT/(label+'-derivative-check.json'))['passed'],'independent local derivatives '+case)
        require(read(ROOT/(label+'-controls.json'))['passed'],'source feedback controls '+case)
        capture=packet(ROOT/(label+'-capture.npz'))
        derivatives=packet(ROOT/(label+'-local-derivatives.npz'))
        seeds=packet(ROOT/(label+'-seeds.npz'))
        first,kept,fields,active=[result[name] for name in ('first','kept','fields','active')]
        selected=np.flatnonzero(capture['cache_mask'][0])
        control=read(ROOT/(label+'-controls.json'))
        amplitude=max(abs(seeds['phase_captured'][1]),1.)/4
        expected_metric=capture['observation_reference'][0,12]*amplitude/(2*capture['observation_reference'][0,28])
        checks[case+'/rest_feedback']={'metric':comparison(control['checks']['rest_state_feedback']['metric_change'],expected_metric,ALGEBRA)}
        for divisor in ('4096','8192'):
            columns_used=[result['source_dimension']-2,result['source_dimension']-1] if fields==2 else [1]
            checks[case+'/directional_'+divisor]=columns(derivatives['directional_'+divisor][:,columns_used],derivatives['rhs_'+divisor][:,columns_used],'source_')
            if fields==2:
                checks[case+'/tail_preflight_'+divisor]=columns(derivatives['tails_'+divisor],derivatives['rhs_'+divisor][:,-2:],'source_',ALGEBRA)
        checks[case+'/metric_step']=columns(derivatives['metric_4096'],derivatives['metric_8192'],'metric_')
        runs={}
        for name,entry in result['runs'].items():
            path=ROOT/(label+'-'+name+'.npz')
            require(digest(path)==entry['packet_sha256'],'run packet sealed at production')
            data=packet(path)
            runs[name]=data
            prefix=case+'/'+name+'/'
            for actual,reference,group in [(data['vector'][:,:active],capture['reference'][:,:active],'state'),(data['derivative'][:,:active],capture['derivative_reference'][:,:active],'derivative'),(data['observation'],capture['observation_reference'],'observer'),(data['state'],derivatives['projected_reference'],'source'),(data['phase'],derivatives['reference'],'phase'),(data['cache'][:,selected],capture['cache_reference'][:,selected],'cache')]:
                checks[prefix+group]=columns(actual,reference,group+'_')
            initial=seeds['reconstructed' if name.startswith('reconstructed') else 'captured']
            checks[prefix+'initial']=columns(data['state'][0:1],(initial/seeds['normalization']*seeds['normalization'])[None,:],'state_',ALGEBRA)
            if fields==2:
                offset=kept+4
                require(np.array_equal(data['state'][:,:offset],data['phase'][:,:offset]),'unchanged rest/slow coordinates')
                require(np.array_equal(data['source_rhs'][:,:offset],data['rhs'][:,:offset]),'unchanged native rest RHS')
                scale,rate,hubble,dilation=data['extra'].T
                hubble_prime,dilation_prime=data['metric_rates'].T
                beta=scale/density0
                field,velocity,field_first,velocity_first,mass2,omega=data['jets'][:,1].T
                mode,mode_velocity=data['vector'][:,first+2:first+4].T
                mode_prime,velocity_prime=data['derivative'][:,first+2:first+4].T
                density=beta*(velocity*mode_velocity+mass2*field*mode)
                current=beta*velocity*mode
                virial=beta*field*velocity
                perturbation_virial=beta*(field*mode_velocity+velocity*mode)
                restored=np.column_stack([density+(3*hubble*perturbation_virial+dilation*virial)/2,current-perturbation_virial/2])
                checks[prefix+'coordinate_map']=columns(restored,data['state'][:,-2:],'source_',ALGEBRA)
                density_prime=rate*density+beta*(rate*velocity_first*mode_velocity+velocity*velocity_prime+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_prime)
                current_prime=rate*current+beta*(rate*velocity_first*mode+velocity*mode_prime)
                virial_prime=rate*virial+beta*rate*(field_first*velocity+field*velocity_first)
                perturbation_prime=rate*perturbation_virial+beta*(rate*field_first*mode_velocity+field*velocity_prime+rate*velocity_first*mode+velocity*mode_prime)
                rhs=np.column_stack([density_prime+(3*hubble_prime*perturbation_virial+3*hubble*perturbation_prime+dilation_prime*virial+dilation*virial_prime)/2,current_prime-perturbation_prime/2])
                checks[prefix+'source_product_rhs']=columns(rhs,data['source_rhs'][:,-2:],'source_',ALGEBRA)
                checks[prefix+'source_tail_rhs']=columns(data['tail_rates'],rhs,'source_',ALGEBRA)
                moment=np.einsum('ti,tj->tij',np.column_stack([field,velocity/omega]),np.column_stack([mode,mode_velocity/omega])).reshape(-1,4)
                checks[prefix+'physical_phase_rank']=columns(moment,data['phase'][:,offset:],'moment_',ALGEBRA)
                require(np.all(1-9*hubble/(4*np.sqrt(mass2))>0),'sampled regularity condition')
                require(np.all(data['condition']<1.01),'well-conditioned energy-scaled source map')
            else:
                require(np.array_equal(data['source_rhs'],data['rhs']) and np.array_equal(data['state'],data['phase']),'baseline is unchanged native phase state')
        for left,right in [('captured-step128-h1','captured-step256-h1'),('reconstructed-step128-h1','reconstructed-step256-h1'),('captured-step256-h1','captured-step256-h2'),('reconstructed-step256-h1','reconstructed-step256-h2'),('reconstructed-step256-h2','captured-step256-h2')]:
            for key in ('vector','derivative','observation'):
                width=active if key in ('vector','derivative') else 40
                checks[case+'/'+left+'_vs_'+right+'/'+key]=columns(runs[left][key][:,:width],runs[right][key][:,:width],key+'_')
        fine=runs['reconstructed-step256-h2']
        summaries[case]=dict(runs={name:entry['worst'] for name,entry in result['runs'].items()},native_dimension=active,phase_dimension=result['phase_dimension'],source_dimension=result['source_dimension'],maximum_condition=float(np.max(fine['condition'])),cache_count=len(selected),physical_rhs_unchanged_for_baseline=(case=='cold'))
        if fields==2:
            scale,rate,hubble,dilation=fine['extra'][0]
            field,velocity,field_first,velocity_first,mass2,omega=fine['jets'][0,1]
            beta=scale/density0
            energy=(velocity**2+mass2*field**2)/2
            original=fine['vector'][0,first+2:first+4]
            for title,field,velocity in [('velocity_zero',np.sqrt(2*energy/mass2),0.),('field_zero',0.,np.sqrt(2*energy))]:
                factor=1+field*velocity/(4*hubble)
                matrix=beta*np.array([[factor*mass2*field+1.5*hubble*velocity,factor*velocity+1.5*hubble*field],[velocity/2,-field/2]])
                recovered=np.linalg.solve(matrix,matrix@original)
                row=comparison(recovered,original,ALGEBRA)
                turning_controls[title]=dict(**row,determinant=float(np.linalg.det(matrix)),kind='synthetic instantaneous phase control at retained positive energy and background, not a new cosmological solution')
            summaries[case]['actual_background_sign_changes']={name:int(np.count_nonzero(np.diff(np.sign(fine['jets'][:,1,index])))) for name,index in [('field',0),('velocity',1)]}
    require(all(row['passed'] for row in turning_controls.values()),'exact-zero phase controls')
    passed=all_pass(checks)
    write('validation.json',dict(passed=passed,checks=checks,check_count=sum(len(group) for group in checks.values()),summaries=summaries,turning_point_controls=turning_controls,original_heavy_preflight_passed=False,balanced_coordinate_diagnostic_passed=True,present_state_only_rhs=True))
    print(json.dumps(dict(passed=passed,checks=sum(len(group) for group in checks.values()),summaries=summaries,turning_controls=turning_controls),default=convert),flush=True)
    require(passed,'independent live-source verification')


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['passed'],'validated accepted route')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json')}
    write('closeout.json',dict(implementation_validated=True,paired_live_source_coordinate_evolution_passed=True,present_state_metric_derivative=True,local_derivative_numerically_approximated=True,saved_future_metric_used_by_rhs=False,physical_modes_removed=False,exact_tails_retained=True,original_heavy_preflight_passed=False,balanced_coordinate_check_passed=True,old_averaged_selector_replaced=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='postseal-start.json':
            continue
        owner=read(path)
        end=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(owner)
        require(outcome['exited'],'prior worker exited')
        require(end['state']=='completed' or path.name=='heavy-source-state-start.json','only documented diagnostic failure')
        workers.append(dict(name=path.stem,identity=owner,state=end['state'],outcome=outcome))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('validate','seal','postseal'))
    args=parser.parse_args()
    with worker(args.operation) as identity:
        if args.operation=='validate':
            validate()
        elif args.operation=='seal':
            seal()
        else:
            postseal(identity)
