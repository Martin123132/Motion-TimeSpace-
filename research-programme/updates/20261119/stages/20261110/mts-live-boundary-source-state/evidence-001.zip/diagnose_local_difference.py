from state_support import *
import ast
import source_state
from source_state import SourceState
import run_state


def diagnose(captured,reference,reference_jets,direct,expected,label,kept,fields,active,pack,dimension,sample,scalar,pointers):
    times=captured['clock']
    first=int(captured['signature'][0,2])-1
    engine=SourceState(sample,times,kept,fields,first,dimension,float(packet(PROJECTION/'frozen-projection.npz')['density0']))
    selected=[engine.w_dimension-2,engine.w_dimension-1] if fields==2 else [1]
    divisions=[256,512,1024,2048,4096,8192]
    write(label+'-diagnostic-contract.json',dict(divisors=divisions,scope='independent coordinate chain finite difference only',physical_rhs_metric_divisor=8192,gate=GATE,reason='Original h2 independent chain fails while h1 passes; distinguish derivative truncation and arithmetic noise before any retry'))
    values=[sample(tau,row) for tau,row in zip(times,reference)]
    physical=[]
    metrics=[]
    for tau,state,observed in zip(times,reference,values):
        metric=engine.metric_rates(tau,state,observed,8192)
        physical.append(engine.rates(observed,metric)[0][selected])
        metrics.append(metric)
    physical=np.array(physical)
    results={}
    arrays={}
    for divisor in divisions:
        estimated=np.array([engine.directional(tau,state,observed,divisor)[selected] for tau,state,observed in zip(times,reference,values)])
        arrays['chain_'+str(divisor)]=estimated
        checks=columns(estimated,physical,'source_')
        results[str(divisor)]=dict(passed=all(row['passed'] for row in checks.values()),checks=checks)
    np.savez_compressed(ROOT/(label+'-diagnostic.npz'),clock=times,physical=physical,metric_rates=np.array(metrics),**arrays)
    write(label+'-diagnostic.json',dict(completed=True,results=results,no_evolution_run=True,no_physical_equation_changed=True))
    print(json.dumps(results),flush=True)


if __name__=='__main__':
    source=ROOT/'run_state.py'
    require(digest(source)==read(ROOT/'frozen-inputs.json')[str(source)],'original frozen driver')
    tree=ast.parse(source.read_text())
    count=0
    for node in ast.walk(tree):
        if isinstance(node,ast.keyword) and node.arg=='label' and isinstance(node.value,ast.Constant) and node.value.value=="args.case+'-source-state'":
            node.value=ast.Constant("args.case+'-source-state-stencil-diagnosis'")
            count+=1
        if isinstance(node,ast.keyword) and node.arg=='continuation' and isinstance(node.value,ast.Name):
            node.value=ast.Name(id='diagnose',ctx=ast.Load())
            count+=1
    require(count==2,'bounded diagnostic adapter')
    namespace=dict(__file__=__file__,__name__='diagnostic_adapter',diagnose=diagnose)
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()
