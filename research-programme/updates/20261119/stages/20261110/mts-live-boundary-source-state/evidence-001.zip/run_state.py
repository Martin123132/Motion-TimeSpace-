from source_state import *
import ast
from scipy.integrate import solve_ivp
import run_live as previous_driver
require(previous_driver.ROOT==ROOT,'isolated in-process output root')
sources=previous_driver.sources
validate_capture=previous_driver.validate_capture


def continuation(captured,reference,reference_jets,direct,expected,label,kept,fields,active,pack,dimension,sample,scalar,pointers):
    case=label.split('-')[0]
    contract=read(ROOT/'contract.json')
    times=captured['clock']
    first=int(captured['signature'][0,2])-1
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    engine=SourceState(sample,times,kept,fields,first,dimension,density0)
    old_seeds=packet(LIVE/(case+'-live-seeds.npz'))
    require(np.array_equal(old_seeds['captured'],reference[0]),'original starting phase state')
    phase_seeds={name:old_seeds[name] for name in ('captured','reconstructed')}
    seeds={name:engine.forward(state,sample(times[0],state)) for name,state in phase_seeds.items()}
    projected_reference=np.array([engine.forward(state,sample(tau,state)) for tau,state in zip(times,reference)])
    metric_comparisons={}
    rates={}
    directional={}
    products={}
    tails={}
    inverses=[]
    conditions=[]
    stored_metric=packet(MEMORY/(case+'-live-fine8.npz'))
    for divisor in (4096,8192):
        metric_rows=[]
        rate_rows=[]
        direct_rows=[]
        tail_rows=[]
        for tau,state in zip(times,reference):
            values=sample(tau,state)
            metric=engine.metric_rates(tau,state,values,divisor)
            rhs,tail=engine.rates(values,metric)
            metric_rows.append(metric)
            rate_rows.append(rhs)
            direct_rows.append(engine.directional(tau,state,values,divisor))
            tail_rows.append(tail)
            if divisor==8192:
                recovered,_,condition=engine.inverse(tau,engine.forward(state,values))
                inverses.append(recovered)
                conditions.append(condition)
        rates[str(divisor)]=np.array(metric_rows)
        products[str(divisor)]=np.array(rate_rows)
        directional[str(divisor)]=np.array(direct_rows)
        tails[str(divisor)]=np.array(tail_rows)
        metric_comparisons['history_control_'+str(divisor)]=columns(rates[str(divisor)],np.column_stack([stored_metric['node_H_prime'],stored_metric['node_z_prime']]),'rate_')
        selected_coordinates=[engine.w_dimension-2,engine.w_dimension-1] if fields==2 else [1]
        metric_comparisons['coordinate_chain_'+str(divisor)]=columns(directional[str(divisor)][:,selected_coordinates],products[str(divisor)][:,selected_coordinates],'transformed_or_cdm_')
        if fields==2:
            metric_comparisons['retained_tail_'+str(divisor)]=columns(tails[str(divisor)],products[str(divisor)][:,-2:],'source_',ALGEBRA)
    metric_comparisons['metric_step']=columns(rates['4096'],rates['8192'],'rate_')
    metric_comparisons['forward_inverse']=columns(np.array(inverses),reference,'phase_',ALGEBRA)
    np.savez_compressed(ROOT/(label+'-local-derivatives.npz'),clock=times,reference=reference,projected_reference=projected_reference,inverse=np.array(inverses),condition=np.array(conditions),**{'metric_'+name:value for name,value in rates.items()},**{'rhs_'+name:value for name,value in products.items()},**{'directional_'+name:value for name,value in directional.items()},**{'tails_'+name:value for name,value in tails.items()})
    write(label+'-derivative-check.json',dict(passed=all_pass(metric_comparisons),checks=metric_comparisons,maximum_condition=float(np.max(conditions)),history_only_used_for_validation=True))
    require(all_pass(metric_comparisons),'current-state derivative and coordinate preflight')
    zero_rhs,_=engine.evaluate(times[0],np.zeros(engine.w_dimension),8192)
    base_rhs,base_values=engine.evaluate(times[0],seeds['captured'],8192)
    reverse_rhs,_=engine.evaluate(times[0],-seeds['captured'],8192)
    controls=dict(zero=comparison(zero_rhs,np.zeros(engine.w_dimension),ALGEBRA),sign=comparison(reverse_rhs,-base_rhs,ALGEBRA))
    changed_phase=phase_seeds['captured'].copy()
    changed_phase[1]+=max(abs(changed_phase[1]),1.)/4
    changed_w=engine.forward(changed_phase,sample(times[0],changed_phase))
    changed_rhs,changed=engine.evaluate(times[0],changed_w,8192)
    controls['rest_state_feedback']=dict(passed=bool(np.max(abs(changed_rhs-base_rhs))>0 and changed['extra'][3]!=base_values['extra'][3]),metric_change=float(changed['extra'][3]-base_values['extra'][3]))
    if fields==2:
        changed_phase=phase_seeds['captured'].copy()
        changed_phase[kept+4:kept+8]*=1.25
        changed_w=engine.forward(changed_phase,sample(times[0],changed_phase))
        changed_rhs,changed=engine.evaluate(times[0],changed_w,8192)
        expected_density=base_values['observation'][37]/4
        controls['heavy_state_feedback']=comparison(changed['extra'][3]-base_values['extra'][3],expected_density/(2*base_values['extra'][2]),ALGEBRA)
    write(label+'-controls.json',dict(passed=all(row['passed'] for row in controls.values()),checks=controls))
    require(all(row['passed'] for row in controls.values()),'live source-coordinate controls')
    normalization=np.maximum(abs(seeds['captured']),abs(base_rhs)*(times[-1]-times[0]))
    normalization[normalization==0]=1.
    np.savez_compressed(ROOT/(label+'-seeds.npz'),captured=seeds['captured'],reconstructed=seeds['reconstructed'],normalization=normalization,phase_captured=phase_seeds['captured'],phase_reconstructed=phase_seeds['reconstructed'])
    reports={}
    recorded={}
    for config in contract['configs']:
        for mode,seed in seeds.items():
            name=mode+'-'+config['name']
            def rhs(tau,normalized):
                value,_=engine.evaluate(tau,normalized*normalization,config['derivative_divisor'])
                return value/normalization
            solution=solve_ivp(rhs,(times[0],times[-1]),seed/normalization,method='DOP853',t_eval=times,rtol=contract['integration']['rtol'],atol=contract['integration']['atol'],max_step=(times[-1]-times[0])/config['steps'])
            require(solution.success and solution.y.shape==(engine.w_dimension,len(times)),'completed source-state evolution')
            state=solution.y.T*normalization
            evaluated=[engine.evaluate(tau,row,config['derivative_divisor']) for tau,row in zip(times,state)]
            source_rhs=np.array([pair[0] for pair in evaluated])
            observed={key:np.array([pair[1][key] for pair in evaluated]) for key in evaluated[0][1]}
            chosen=np.flatnonzero(captured['cache_mask'][0])
            checks=dict(state=columns(observed['vector'][:,:active],captured['reference'][:,:active],'state_'),observer=columns(observed['observation'],captured['observation_reference'],'observable_'),derivative=columns(observed['derivative'][:,:active],captured['derivative_reference'][:,:active],'derivative_'),source_coordinates=columns(state,projected_reference,'coord_'),phase=columns(observed['phase'],reference,'phase_'),cache=columns(observed['cache'][:,chosen],captured['cache_reference'][:,chosen],'cache_'))
            if fields==2:
                checks['tail_identity']=columns(observed['tail_rates'],source_rhs[:,-2:],'rate_',ALGEBRA)
            path=ROOT/(label+'-'+name+'.npz')
            np.savez_compressed(path,clock=times,state=state,source_rhs=source_rhs,reference=projected_reference,normalization=normalization,**observed)
            worst={group:max((row['normalized'] for row in entries.values() if row['normalized'] is not None),default=0.) for group,entries in checks.items()}
            reports[name]=dict(passed=all_pass(checks),checks=checks,worst=worst,evaluations=solution.nfev,packet_sha256=digest(path))
            recorded[name]=observed
            print(json.dumps(dict(case=case,variant=name,passed=all_pass(checks),worst=worst,evaluations=solution.nfev)),flush=True)
    comparisons={}
    for left,right in [('captured-step128-h1','captured-step256-h1'),('reconstructed-step128-h1','reconstructed-step256-h1'),('captured-step256-h1','captured-step256-h2'),('reconstructed-step256-h1','reconstructed-step256-h2'),('reconstructed-step256-h2','captured-step256-h2')]:
        for name in ('vector','derivative','observation'):
            width=active if name in ('vector','derivative') else 40
            comparisons[left+'_vs_'+right+'/'+name]=columns(recorded[left][name][:,:width],recorded[right][name][:,:width],name+'_')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write(label+'-result.json',dict(completed=True,passed=all(entry['passed'] for entry in reports.values()) and all_pass(comparisons),runs=reports,comparisons=comparisons,fields=fields,kept=kept,first=first,active=active,phase_dimension=dimension,source_dimension=engine.w_dimension,present_state_metric_derivative=True,saved_future_metric_used_by_rhs=False,exact_tails_retained=True,physical_modes_removed=False,old_averaged_selector_activated=False))


def main():
    source=COUPLED/'run_coupled.py'
    require(digest(source)==read(COUPLED/'closeout.json')['artifacts']['run_coupled.py']['sha256'],'retained native driver')
    changes=[]
    class Adapt(ast.NodeTransformer):
        def visit_ImportFrom(self,node):
            if node.module=='coupled_math':
                node.module='state_support'
                changes.append('support')
            return node
        def visit_Assign(self,node):
            targets=[target.id for target in node.targets if isinstance(target,ast.Name)]
            replacements=dict(label="args.case+'-source-state'",build="read(COUPLED/'native-build-result.json')",local="COUPLED/'native'",source_hashes='sources(Path(__file__),prior_path,table_path,clock_path,observer_owner,factory_path,local)')
            for target,value in replacements.items():
                if target in targets:
                    node.value=ast.parse(value,mode='eval').body
                    changes.append(target)
            return self.generic_visit(node)
        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='require' and len(node.value.args)==2 and isinstance(node.value.args[1],ast.Constant):
                if node.value.args[1].value=='original coupled handoff exact':
                    changes.append('capture')
                    return ast.parse('validate_capture(captured,prior,active,label,lower,upper)').body[0]
                if node.value.args[1].value=='same-state source and independent product derivative':
                    changes.append('evolve')
                    return [node,*ast.parse('continuation(captured,reference,reference_jets,direct,expected,label,kept,fields,active,pack,dimension,sample,scalar,pointers)\nreturn').body]
            return self.generic_visit(node)
        def visit_Try(self,node):
            node=self.generic_visit(node)
            if node.finalbody and any(isinstance(item,ast.Expr) and isinstance(item.value,ast.Call) and isinstance(item.value.func,ast.Name) and item.value.func.id=='reset' for item in node.finalbody):
                node.finalbody.extend(ast.parse("write(label+'-native-release.json',dict(released=cleared))\nrequire(cleared,'native owner released')").body)
                changes.append('release')
            return node
    tree=Adapt().visit(ast.parse(source.read_text()))
    require(changes==['support','label','build','local','source_hashes','capture','evolve','release'],'bounded reuse adapter')
    namespace=dict(__file__=__file__,__name__='source_state_driver',sources=sources,validate_capture=validate_capture,continuation=continuation)
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()


if __name__=='__main__':
    main()
