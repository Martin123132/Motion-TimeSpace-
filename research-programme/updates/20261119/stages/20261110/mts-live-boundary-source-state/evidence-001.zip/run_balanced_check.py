from state_support import *
import ast


source=ROOT/'run_state.py'
require(digest(source)==read(ROOT/'frozen-inputs.json')[str(source)],'unchanged original source driver')
diagnosis=read(ROOT/'heavy-source-state-stencil-diagnosis-diagnostic.json')
require(all(diagnosis['results'][str(value)]['passed'] for value in (512,1024,2048,4096)),'saved independent step plateau')
cold=read(ROOT/'cold-source-state-stencil-diagnosis-diagnostic.json')
require(all(cold['results'][str(value)]['passed'] for value in (1024,2048)),'paired baseline diagnostic')
if not (ROOT/'balanced-check-contract.json').exists():
    write('balanced-check-contract.json',dict(physical_metric_divisors=[4096,8192],independent_chain_divisors=[1024,2048],physical_integration_changed=False,gate=GATE,algebra=ALGEBRA,original_heavy_preflight_passed=False,baseline_evolution_reused='cold-source-state-result.json',reason='Separate the cancellation-sensitive independent coordinate difference from the physical metric stencil. h=span/256 truncates; very small h=span/8192 amplifies numerical noise. Both frozen adjacent intermediate checks must pass; old failure remains.',sources={str(path):digest(path) for path in (source,ROOT/'source_state.py',ROOT/'heavy-source-state-stencil-diagnosis-diagnostic.json',ROOT/'cold-source-state-stencil-diagnosis-diagnostic.json',ROOT/'cold-source-state-result.json',Path(__file__))}))
changes=[]


class Adapt(ast.NodeTransformer):
    def visit_Call(self,node):
        if isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name) and node.func.value.id=='engine' and node.func.attr=='directional':
            require(isinstance(node.args[-1],ast.Name) and node.args[-1].id=='divisor','only independent chain divisor')
            node.args[-1]=ast.BinOp(left=node.args[-1],op=ast.FloorDiv(),right=ast.Constant(4))
            changes.append('independent_chain_divisor')
        return self.generic_visit(node)
    def visit_keyword(self,node):
        if node.arg=='label' and isinstance(node.value,ast.Constant) and node.value.value=="args.case+'-source-state'":
            node.value=ast.Constant("args.case+'-source-state-balanced-check'")
            changes.append('distinct_label')
        return self.generic_visit(node)


tree=Adapt().visit(ast.parse(source.read_text()))
require(changes==['independent_chain_divisor','distinct_label'],'diagnostic-only bounded adjustment')
namespace=dict(__file__=__file__,__name__='balanced_source_state')
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
namespace['main']()
