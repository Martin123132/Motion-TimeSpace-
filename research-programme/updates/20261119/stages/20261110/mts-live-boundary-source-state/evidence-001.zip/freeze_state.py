from state_support import *


with worker('freeze'):
    require(digest(MEMORY/'closeout.json')==EXPECTED,'retained memory seal')
    seal=read(MEMORY/'closeout.json')
    check_hashes(seal['input_hashes'])
    check_hashes({str(MEMORY/name):row['sha256'] for name,row in seal['artifacts'].items()})
    cleanup=read(MEMORY/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and exited(cleanup['verifier_identity'])['exited'],'prior cleanup')
    sources=read(LIVE/'frozen-inputs.json')
    additions=[MEMORY/'closeout.json',LIVE/'run_live.py',LIVE/'live_support.py',LIVE/'contract.json',PROJECTION/'frozen-projection.npz']
    for case in ('cold','heavy'):
        additions.extend([LIVE/(case+'-live-capture.npz'),LIVE/(case+'-live-seeds.npz'),LIVE/(case+'-live-reconstructed-step256.npz'),MEMORY/(case+'-live-fine8.npz')])
    additions.extend(sorted(ROOT.glob('*.py')))
    sources.update({str(path):digest(path) for path in additions})
    check_hashes(sources)
    write('frozen-inputs.json',sources)
    write('contract.json',dict(windows={'matching':[2892,2956]},cases=['cold','heavy'],configs=[dict(name='step128-h1',steps=128,derivative_divisor=4096),dict(name='step256-h1',steps=256,derivative_divisor=4096),dict(name='step256-h2',steps=256,derivative_divisor=8192)],integration=dict(method='DOP853',rtol=1e-10,atol=1e-12),seed_modes=['captured','reconstructed'],gate=GATE,algebra=ALGEBRA,derivative='five-point local time derivative at fixed current phase state plus exact linear metric state-direction term; no saved future history',same_original_bank_and_output_grid=True,retained_tails=True,old_averaged_selector=False,goal_complete=False))
    print(json.dumps(dict(frozen=True,inputs=len(sources),paired_configs=3,seed_modes=2)),flush=True)
