import sys
from pathlib import Path
from time import monotonic
LIVE=Path(__file__).resolve().parent.parent/'mts-reconstructed-live-continuation-20261110'
sys.path.insert(0,str(LIVE))
import live_support as shared
shared.ROOT=Path(__file__).resolve().parent
shared.START=monotonic()
from live_support import *
LIVE=POST/'mts-reconstructed-live-continuation-20261110'
MEMORY=POST/'mts-coupled-memory-budget-20261110'
EXPECTED='5d546dcff64df2ea6e474952d4073ce6b679f7d24f85ed758b8e8b20c3bf6836'
retained_guard=shared.guard


def guard():
    retained_guard()
    for folder in (LIVE,MEMORY):
        require(not (folder/'STOP-REQUESTED').exists(),'owner hold '+str(folder))


shared.guard=guard
