import os
for thread_key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[thread_key] = "1"
import json
import hashlib
import time
from pathlib import Path
from decimal import Decimal, localcontext
from datetime import datetime, timezone
import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
BRANCH = POST / "condensate-origin-20261003"
SPECTRUM = BRANCH / "resolved-matter-spectrum-20261007"
EARLY = BRANCH / "native-two-field-transfer-20261007"
ALGEBRA, GATE = 1e-10, 2e-5
COUNTS, MAXIMA = {}, {}
START = time.monotonic()


def checksum(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            result.update(block)
    return result.hexdigest()


def expect(condition, label):
    if not condition:
        raise ValueError(label)
    COUNTS[label] = COUNTS.get(label, 0) + 1


def compare(left, right, norm, label, gate=ALGEBRA):
    error = abs(float(left - right)) / max(abs(float(norm)), 1e-100)
    MAXIMA[label] = max(MAXIMA.get(label, 0.0), error)
    expect(np.isfinite(error) and error <= gate, label)


def load_table(name):
    with np.load(ROOT / (name + ".npz")) as packet:
        columns = packet["columns"].tolist()
        values = packet["values"]
        rows = [dict(zip(columns, row)) for row in values]
        raw = packet["raw_values"].copy()
        names = packet["raw_names"].tolist()
    expect(np.isfinite(values).all(), "finite table")
    expect(len({(row["nominal_a"], row["k_Mpc_inverse"]) for row in rows}) == len(rows), "unique row keys")
    return rows, raw, names


def direct_raw_replay(name, rows, raw, names):
    early, model = name.split("-")
    if early == "early":
        paths = sorted((SPECTRUM / "runs/exact-grid").glob("chunk-*.npz")) if model == "heavy" else [EARLY / "runs/final-bg8-start/cold.npz"]
    else:
        paths = sorted((SPECTRUM / "runs" / model).glob("chunk-*.npz"))
    indexed = {(row["nominal_a"], row["k_Mpc_inverse"]): index for index, row in enumerate(rows)}
    covered = set()
    epochs = sorted({row["nominal_a"] for row in rows})
    for path in paths:
        expect(time.monotonic() - START < 900, "bounded validator")
        with np.load(path) as packet:
            expect(packet["names"].tolist() == names, "native names identical")
            indices = [int(np.argmin(abs(packet["requested_scale"] - epoch))) for epoch in epochs]
            for wave, history in zip(packet["modes"], packet["values"]):
                if wave > 5:
                    continue
                for epoch, native_index in zip(epochs, indices):
                    index = indexed[(epoch, float(wave))]
                    expect(np.array_equal(raw[index], history[native_index]), "raw native replay byte values")
                    expect(rows[index]["conformal_time_Mpc"] == float(packet["conformal_time"][native_index]), "native clock replay")
                    covered.add(index)
    expect(len(covered) == len(rows), "all exported rows replayed")


def canonical(rows, raw, names):
    with localcontext() as context:
        context.prec = 60
        number = lambda value: Decimal.from_float(float(value))
        for row, native in zip(rows, raw):
            for label, suffix in (("slow", "s"), ("heavy", "h")):
                if label + "_canonical_q" not in row:
                    continue
                scale, hubble = number(row["a"]), number(row["H_conformal_Mpc_inverse"])
                wave, curvature = number(row["k_Mpc_inverse"]), number(row["Phi"])
                base = number(row[label + "_field_background"])
                velocity = number(row[label + "_conformal_velocity_background"])
                mass = number(row[label + "_mass_Mpc_inverse"])
                field = number(row[label + "_canonical_q"]) / (scale * scale.sqrt())
                normal = number(row[label + "_canonical_p"]) / scale.sqrt() - Decimal("1.5") * hubble * field + 3 * curvature * velocity
                density = velocity * normal + (scale * mass)**2 * base * field
                pressure = velocity * normal - (scale * mass)**2 * base * field
                current = wave * velocity * field
                alpha = number(row["alpha_Mpc"])
                original = [number(native[names.index("mts_" + part + "_" + suffix)]) for part in ("drho", "dp", "q")]
                gauge = [-3 * hubble * velocity**2 * alpha,
                         (-3 * hubble * velocity**2 - 2 * (scale * mass)**2 * base * velocity) * alpha,
                         wave * velocity**2 * alpha]
                expected = [left + right for left, right in zip(original, gauge)]
                norm = max(*(abs(value) for value in expected + original), Decimal("1e-100"))
                for actual, target in zip((density, pressure, current), expected):
                    compare(actual, target, norm, "decimal canonical to native source", GATE)
                omitted = velocity * (normal - 3 * curvature * velocity) + (scale * mass)**2 * base * field
                predicted_error = -3 * curvature * velocity**2
                compare(omitted - density, predicted_error, max(abs(density), abs(predicted_error)),
                        "metric volume negative control")
                compare(field, number(row[label + "_field_N"]), max(abs(field), Decimal("1e-100")), "decimal field inverse")
                if label == "heavy":
                    real, imag, power = row["heavy_relative_B_real"], row["heavy_relative_B_imag"], row["curvature_power"]
                    matrix = np.array([[row["heavy_covariance_rr"], row["heavy_covariance_ri"]],
                                       [row["heavy_covariance_ri"], row["heavy_covariance_ii"]]])
                    expected_matrix = power * np.outer([real, imag], [real, imag])
                    compare(np.max(abs(matrix - expected_matrix)), 0, np.max(abs(expected_matrix)), "early covariance components")
                    compare(row["heavy_anomalous_real"], power * (real**2 - imag**2), power * (real**2 + imag**2), "anomalous real")
                    compare(row["heavy_anomalous_imag"], power * 2 * real * imag, power * (real**2 + imag**2), "anomalous imaginary")


def late_heavy(rows, raw, names):
    with np.load(SPECTRUM / "runs/projection/a225-w6-d8.npz") as packet:
        constant, mass = float(packet["matching_density"]), float(packet["heavy_mass_mpc"])
    for row, native in zip(rows, raw):
        scale, hubble, wave = row["a"], row["H_conformal_Mpc_inverse"], row["k_Mpc_inverse"]
        density_s = native[names.index("mts_drho_h")] * scale / constant
        velocity_s = native[names.index("mts_q_h")] * scale / constant
        alpha = -hubble * native[names.index("v_newtonian_cdm")] / wave**2
        density, velocity = density_s - 3 * hubble * alpha, velocity_s + wave * alpha
        compare(row["heavy_delta_N"], density, max(abs(density), abs(density_s)), "late density replay")
        compare(-wave * row["heavy_spatial_phase"] / (scale * mass), velocity, max(abs(velocity), abs(velocity_s)), "late phase current")
        ratio = (wave / (scale * mass))**2
        sound = ratio / (np.sqrt(1 + ratio) + 1)**2
        recorded = native[names.index("mts_dp_h")] * scale / constant
        compare(sound * (density_s + 3 * hubble * velocity_s / wave), recorded, recorded, "stable native pressure")
        power = row["curvature_power"]
        expected_matrix = power * np.outer([density / 2, row["heavy_spatial_phase"]], [density / 2, row["heavy_spatial_phase"]])
        actual_matrix = np.array([[row["heavy_NR_covariance_rr"], row["heavy_NR_covariance_ri"]],
                                  [row["heavy_NR_covariance_ri"], row["heavy_NR_covariance_ii"]]])
        compare(np.max(abs(actual_matrix - expected_matrix)), 0, np.max(abs(expected_matrix)), "late covariance components")
        compare(row["heavy_density_phase_covariance"], 2 * actual_matrix[0, 1], max(abs(actual_matrix[0, 1]), 1e-100), "density phase covariance factor")
        scaled = actual_matrix / max(np.trace(actual_matrix), 1e-100)
        expect(np.linalg.eigvalsh(scaled).min() >= -ALGEBRA, "positive covariance")
        expected_screen = (wave > hubble / np.sqrt(GATE) and wave < 2 * scale * mass * np.sqrt(GATE) / (1 - GATE))
        expect(bool(row["both_scale_screens_pass"]) == expected_screen, "analytic overlap screen")


def main():
    worker = psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
    (ROOT / "validation-02-start.json").write_text(json.dumps(identity), encoding="utf-8")
    try:
        result = json.loads((ROOT / "result.json").read_text())
        for path, expected in result["inputs"].items():
            expect(checksum(path) == expected, "preserved input hash")
        for output in result["outputs"]:
            expect(checksum(output["path"]) == output["sha256"], "output hash")
        tables = {}
        for name in ("early-heavy", "early-cold", "late-heavy", "late-cold"):
            rows, raw, names = load_table(name)
            direct_raw_replay(name, rows, raw, names)
            canonical(rows, raw, names)
            if name == "late-heavy":
                late_heavy(rows, raw, names)
            tables[name] = rows
        paired, _, _ = load_table("paired-late")
        for heavy, cold, joint in zip(tables["late-heavy"], tables["late-cold"], paired):
            for field in ("nominal_a", "k_Mpc_inverse", "curvature_power"):
                expect(heavy[field] == cold[field] == joint[field], "paired common preparation")
            compare(joint["density_cross_power"], heavy["curvature_power"] * heavy["heavy_delta_N"] * cold["delta_cdm_N"],
                    joint["density_cross_power"], "paired cross power")
        diagnostics = []
        for epoch in (.0003, .0005, .001, .003, .01):
            subset = [row for row in tables["late-heavy"] if row["nominal_a"] == epoch]
            subset.sort(key=lambda row: row["k_Mpc_inverse"])
            accepted = [row for row in subset if row["both_scale_screens_pass"]]
            entry = dict(a=epoch, modes=len(subset), scale_screened=len(accepted),
                screened_relative_pressure_pass=int(sum(row["heavy_pressure_fractional_difference"] <= GATE for row in accepted)),
                full_band_density_rms_trapezoid=float(np.sqrt(np.trapezoid(
                    [row["curvature_power"] * row["heavy_delta_N"]**2 for row in subset],
                    np.log([row["k_Mpc_inverse"] for row in subset])))),
                full_band_phase_rms_trapezoid=float(np.sqrt(np.trapezoid(
                    [row["curvature_power"] * row["heavy_spatial_phase"]**2 for row in subset],
                    np.log([row["k_Mpc_inverse"] for row in subset])))),
                constant_comoving_number_per_m3=subset[0]["heavy_comoving_number_per_m3"])
            diagnostics.append(entry)
        expect(all(row["constant_comoving_number_per_m3"] == diagnostics[0]["constant_comoving_number_per_m3"] for row in diagnostics),
               "comoving abundance constant")
        output = dict(passed=True, counts=COUNTS, maxima=MAXIMA, diagnostics=diagnostics,
                      result_sha256=checksum(ROOT / "result.json"), validator_sha256=checksum(__file__), identity=identity)
        with (ROOT / "validation-02.json").open("x") as stream:
            json.dump(output, stream, indent=2, allow_nan=False)
        (ROOT / "validation-02-end.json").write_text(json.dumps(dict(**identity, state="completed")), encoding="utf-8")
        print(json.dumps(dict(checks=sum(COUNTS.values()), maxima=MAXIMA, diagnostics=diagnostics)))
    except Exception as error:
        (ROOT / "validation-02-end.json").write_text(json.dumps(dict(**identity, state="failed", error=repr(error))), encoding="utf-8")
        raise


if __name__ == "__main__":
    main()
