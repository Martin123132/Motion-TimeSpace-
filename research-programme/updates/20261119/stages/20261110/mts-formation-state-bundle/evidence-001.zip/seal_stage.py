import ast
import hashlib
import json
from pathlib import Path
from datetime import datetime, timezone
import psutil

root = Path(__file__).resolve().parent
worker = psutil.Process()
worker.cpu_affinity([4])
worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())


def digest(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            value.update(block)
    return value.hexdigest()


def read(name):
    return json.loads((root / name).read_text(encoding="utf-8"))


with (root / "seal-start.json").open("x") as stream:
    json.dump(identity, stream)
try:
    result, validation, volume = read("result.json"), read("validation-02.json"), read("volume-result.json")
    assert result["passed"] and validation["passed"] and volume["passed"]
    assert validation["result_sha256"] == digest(root / "result.json")
    assert validation["validator_sha256"] == digest(root / "validate_bundle.py")
    assert volume["source_sha256"] == digest(root / "add_volume_state.py")
    assert volume["derivation_sha256"] == digest(root / "VOLUME-MEASURE.md")
    assert volume["output_sha256"] == digest(root / "volume-state.npz")
    for path, checksum in {**result["inputs"], **volume["inputs"]}.items():
        assert Path(path).is_file() and digest(path) == checksum, path
    for output in result["outputs"]:
        assert digest(output["path"]) == output["sha256"]
    cleanup = []
    for prefix, state in (("worker", "failed"), ("completion", "completed"),
                          ("validation", "failed"), ("validation-02", "completed"), ("volume", "completed")):
        start, end = read(prefix + "-start.json"), read(prefix + "-end.json")
        assert start["pid"] == end["pid"] and start["created"] == end["created"] and end["state"] == state
        alive = psutil.pid_exists(start["pid"]) and abs(psutil.Process(start["pid"]).create_time() - start["created"]) < .001
        assert not alive, "stage-owned worker still live"
        cleanup.append(dict(receipt=prefix, pid=start["pid"], created=start["created"], command=start["command"],
                            exited=True, preserved_outcome=state))
    assert read("worker-end.json")["error"] == "ValueError('retained averaged pressure')"
    assert "int64" in read("validation-end.json")["error"]
    assert read("completion-end.json")["result_sha256"] == digest(root / "result.json")
    assert all(value == "0" for value in read("symbolic.json")["residuals"])
    for path in root.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    assert not list(root.rglob("__pycache__"))
    handoff = root.parent / "MTS-GALACTIC-STATE-BUNDLE-HANDOFF-20261110.md"
    manifest = {str(path.relative_to(root)): dict(sha256=digest(path), bytes=path.stat().st_size)
                for path in root.rglob("*") if path.is_file()}
    closeout = dict(state="verified", time=datetime.now(timezone.utc).isoformat(), artifacts=manifest,
        external_handoff=dict(path=str(handoff), sha256=digest(handoff), status="prepared-not-sent"),
        retained_input_count=len(result["inputs"]), input_hashes=result["inputs"],
        physical_rows=5199, paired_derived_rows=1995, volume_derived_rows=1995,
        symbolic_identities=9, validation_scalar_checks=sum(validation["counts"].values()),
        volume_scalar_checks=volume["scalar_checks"], cleanup=cleanup, sealer=identity,
        invalid_partial_artifacts=["validation.json"], scientific_scope="RESULTS.md; SCHEMA.md; VOLUME-MEASURE.md",
        no_native_rerun=True, no_new_fit=True, no_galaxy_file_changes=True, no_github=True,
        no_full_hierarchy_restart=True, no_realization_or_local_halo_population_selected=True)
    with (root / "closeout.json").open("x") as stream:
        json.dump(closeout, stream, indent=2, allow_nan=False)
    end = dict(**identity, state="completed", closeout_sha256=digest(root / "closeout.json"))
    with (root / "seal-end.json").open("x") as stream:
        json.dump(end, stream, indent=2)
    print(json.dumps(dict(closeout_sha256=end["closeout_sha256"], artifacts=len(manifest),
        bytes=sum(item["bytes"] for item in manifest.values()), inputs=len(result["inputs"]),
        cleanup=cleanup, sealer_pid=worker.pid)))
except Exception as error:
    with (root / "seal-end.json").open("x") as stream:
        json.dump(dict(**identity, state="failed", error=repr(error)), stream)
    raise
