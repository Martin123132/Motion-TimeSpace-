import json
from datetime import datetime, timezone
import build_bundle as core

np, Path = core.np, core.Path


def recover_early():
    failed = core.read(core.STAGE / "worker-end.json")
    core.require(failed["state"] == "failed" and failed["error"] == "ValueError('retained averaged pressure')",
                 "expected diagnosed attempt")
    core.require(not core.psutil.pid_exists(failed["pid"]) or
                 abs(core.psutil.Process(failed["pid"]).create_time() - failed["created"]) > .001,
                 "original worker exited")
    for path, checksum in failed["inputs"].items():
        core.protect(path, checksum)
    for path, checksum in core.read(core.STAGE / "symbolic.json")["sources"].items():
        core.protect(path, checksum)
    outputs, reports = [], []
    for model, count in (("heavy", 1197), ("cold", 12)):
        path = core.protect(core.STAGE / ("early-" + model + ".npz"))
        with np.load(path) as packet:
            columns, values = packet["columns"].tolist(), packet["values"]
            core.require(len(values) == count and np.isfinite(values).all(), "saved early coverage")
            report = dict(model=model, rows=count)
            for suffix in ("source_roundtrip", "canonical_roundtrip"):
                report["maximum_" + suffix] = float(max(values[:, index].max() for index, column in enumerate(columns)
                                                        if column.endswith(suffix)))
            reports.append(report)
            outputs.append(dict(path=str(path), sha256=core.digest(path), rows=count, columns=len(columns)))
    return outputs, reports


def late():
    seal_path = core.protect(core.SPECTRUM / "results/stage-integrity.json")
    seal = core.read(seal_path)
    outputs, reports, retained = [], [], {}
    epochs = (.0003, .0005, .001, .003, .01)
    for model in ("heavy", "cold"):
        folder = core.SPECTRUM / "runs" / model
        status_path = core.protect(folder / "status.json", seal["file_hashes"]["runs/" + model + "/status.json"])
        status = core.read(status_path)
        core.require(status["state"] == "complete" and status["completed"] == 412, "inherited complete coverage")
        for path, checksum in status["input_hashes"].items():
            core.protect(path, checksum)
        source = core.SPECTRUM / "runs/projection/a225-w6-d8.npz" if model == "heavy" else core.EARLY / "runs/backgrounds/cold.npz"
        core.protect(source, status["source_hash"])
        background = core.background_functions(source)
        constant = float(background["data"]["matching_density"]) if model == "heavy" else 0.0
        mass = background["heavy_mass"]
        mpc = core.constants.parsec * 1e6
        particle_mass = core.constants.hbar * mass / (core.constants.c * mpc)
        mean_number = constant * core.constants.c**2 / (8 * np.pi * core.constants.G * mpc**2 * particle_mass)
        rows, raw_values, names = [], [], None
        for path in sorted(folder.glob("chunk-*.npz")):
            core.guard()
            with np.load(path) as packet:
                packet_names = packet["names"].tolist()
                core.require(names is None or names == packet_names, "constant native column order")
                names = packet_names
                indices = [int(np.argmin(abs(packet["requested_scale"] - epoch))) for epoch in epochs]
                core.require(all(abs(packet["requested_scale"][index] / epoch - 1) < core.ALGEBRA
                                 for index, epoch in zip(indices, epochs)), "exact saved target epochs")
                for wave, history in zip(packet["modes"], packet["values"]):
                    if wave > 5:
                        continue
                    for epoch, index in zip(epochs, indices):
                        raw = history[index]
                        row = core.metric(raw, names, float(wave))
                        row.update(nominal_a=epoch, requested_a=float(packet["requested_scale"][index]),
                                   conformal_time_Mpc=float(packet["conformal_time"][index]))
                        core.scalar_state(row, raw, names, background, "slow")
                        scale, hubble = row["a"], row["H_conformal_Mpc_inverse"]
                        ratio = float(wave / (scale * mass))
                        dispersion = ratio**2 / (np.sqrt(1 + ratio**2) + 1)**2
                        horizon = float((hubble / wave)**2)
                        row.update(test_mass_Mpc_inverse=mass, gradient_ratio=ratio,
                                   leading_frequency_error=dispersion, horizon_scale_screen=horizon,
                                   H_over_am=hubble / (scale * mass),
                                   both_scale_screens_pass=float(max(dispersion, horizon) < core.GATE))
                        if model == "heavy":
                            core.require(raw[names.index("mts_averaged_chart")] == 1, "averaged chart retained")
                            core.require(raw[names.index("mts_dphi_h")] == 0 and raw[names.index("mts_dphidot_h")] == 0,
                                         "unused raw heavy slots")
                            source_scale = constant / scale
                            density_s = float(raw[names.index("mts_drho_h")]) / source_scale
                            velocity_s = float(raw[names.index("mts_q_h")]) / source_scale
                            density = density_s - 3 * hubble * row["alpha_Mpc"]
                            velocity = velocity_s + wave * row["alpha_Mpc"]
                            phase = -scale * mass * velocity / wave
                            pressure = float(raw[names.index("mts_dp_h")]) / source_scale
                            invariant = density_s + 3 * hubble * velocity_s / wave
                            predicted = dispersion * invariant
                            pressure_norm = max(abs(pressure), abs(predicted), 1e-100)
                            stable_error = abs(predicted - pressure) / pressure_norm
                            core.require(stable_error < core.ALGEBRA, "stable retained pressure")
                            naive = dispersion * (density + 3 * hubble * velocity / wave)
                            direct_pressure = ratio**2 * density / 4
                            mode_scale = max(abs(density), abs(density_s), abs(velocity), abs(velocity_s), 1e-100)
                            relative, power = complex(density / 2, phase), row["curvature_power"]
                            row.update(heavy_delta_N=density, heavy_u_N=velocity, heavy_theta_N=wave * velocity,
                                heavy_spatial_phase=phase, heavy_relative_NR_real=relative.real, heavy_relative_NR_imag=relative.imag,
                                heavy_NR_covariance_rr=power * relative.real**2,
                                heavy_NR_covariance_ri=power * relative.real * relative.imag,
                                heavy_NR_covariance_ii=power * relative.imag**2,
                                heavy_density_phase_covariance=power * density * phase,
                                heavy_pressure_retained=pressure, heavy_pressure_NR=direct_pressure,
                                heavy_pressure_source_error=abs(direct_pressure - pressure) / mode_scale,
                                heavy_pressure_fractional_difference=abs(direct_pressure - pressure) / pressure_norm,
                                heavy_pressure_stable_reconstruction=stable_error,
                                heavy_pressure_naive_cancellation=abs(naive - pressure) / pressure_norm,
                                heavy_comoving_density=invariant,
                                heavy_delta_rounding=3 * abs(hubble) * row["alpha_rounding_Mpc"],
                                heavy_phase_rounding=scale * mass * row["alpha_rounding_Mpc"],
                                heavy_comoving_number_per_m3=mean_number, heavy_source_scale=source_scale,
                                heavy_linear_density_per_log_rms=float(np.sqrt(power) * abs(density)))
                            core.require(abs(-wave**2 * phase / (scale * mass) - wave * velocity) <
                                         core.ALGEBRA * max(abs(wave * velocity), 1e-100), "phase-current roundtrip")
                        rows.append(row)
                        raw_values.append(raw.copy())
        core.require(len(rows) == 1995, "late main-band coverage")
        if model == "heavy":
            core.check("late-covariance-positive", core.audit_covariance(rows, "heavy_relative_NR_real", "heavy_relative_NR_imag"))
        outputs.append(core.save_table("late-" + model, rows, names, raw_values,
            exact_late_carrier_phase_supplied=np.array(False), full_hierarchy_restart=np.array(False)))
        retained[model] = rows
        for epoch in epochs:
            group = [row for row in rows if row["nominal_a"] == epoch]
            allowed = [row for row in group if row["both_scale_screens_pass"]]
            report = dict(model=model, a=epoch, modes=len(group), both_scale_screens_pass=len(allowed),
                minimum_k_screen=min((row["k_Mpc_inverse"] for row in allowed), default=None),
                maximum_k_screen=max((row["k_Mpc_inverse"] for row in allowed), default=None),
                max_H_over_am=max(row["H_over_am"] for row in group),
                max_frequency_error=max(row["leading_frequency_error"] for row in group),
                maximum_slow_source_error=max(row["slow_source_roundtrip"] for row in group))
            if model == "heavy":
                for label, field in (("max_NR_pressure_source_error", "heavy_pressure_source_error"),
                        ("max_NR_pressure_fractional_difference", "heavy_pressure_fractional_difference"),
                        ("max_linear_density_per_log_rms", "heavy_linear_density_per_log_rms"),
                        ("max_native_pressure_error", "heavy_pressure_stable_reconstruction"),
                        ("max_naive_cancellation", "heavy_pressure_naive_cancellation")):
                    report[label] = max(row[field] for row in group)
                report["screened_max_NR_pressure_source_error"] = max((row["heavy_pressure_source_error"] for row in allowed), default=None)
                report["screened_max_NR_pressure_fractional_difference"] = max((row["heavy_pressure_fractional_difference"] for row in allowed), default=None)
            reports.append(report)
    paired = []
    for heavy, cold in zip(retained["heavy"], retained["cold"]):
        for field in ("nominal_a", "k_Mpc_inverse", "curvature_power", "requested_a"):
            core.require(heavy[field] == cold[field], "same paired " + field)
        paired.append(dict(nominal_a=heavy["nominal_a"], k_Mpc_inverse=heavy["k_Mpc_inverse"],
            curvature_power=heavy["curvature_power"], heavy_delta=heavy["heavy_delta_N"],
            heavy_phase=heavy["heavy_spatial_phase"], cold_delta=cold["delta_cdm_N"], cold_theta=cold["theta_cdm_N"],
            density_cross_power=heavy["curvature_power"] * heavy["heavy_delta_N"] * cold["delta_cdm_N"],
            heavy_cold_same_scale_screen=float(heavy["both_scale_screens_pass"] and cold["both_scale_screens_pass"])))
    outputs.append(core.save_table("paired-late", paired, [], [[] for row in paired]))
    return outputs, reports


def main():
    worker = core.psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(core.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    core.guard()
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(),
                    started=datetime.now(timezone.utc).isoformat(), affinity=worker.cpu_affinity())
    core.write(core.STAGE / "completion-start.json", identity)
    try:
        core.protect(Path(__file__))
        early_outputs, early_reports = recover_early()
        late_outputs, late_reports = late()
        for path, checksum in core.INPUTS.items():
            core.require(core.digest(path) == checksum, "preserved source")
        result = dict(passed=True, outputs=early_outputs + late_outputs, early_reports=early_reports,
                      late_reports=late_reports, inputs=core.INPUTS, checks=core.CHECKS,
                      symbolic_identities=len(core.read(core.STAGE / "symbolic.json")["residuals"]),
                      gates=[core.ALGEBRA, core.GATE], no_native_evolution=True, no_new_fit=True,
                      full_all_species_restart=False, exact_late_fast_phase_recovered=False,
                      no_nonlinear_realization_generated=True, no_halo_population_selected=True,
                      original_gauge_derivative_resolution_unchanged=True)
        core.write(core.STAGE / "result.json", result)
        core.write(core.STAGE / "completion-end.json", dict(**identity, state="completed",
                   result_sha256=core.digest(core.STAGE / "result.json"), finished=datetime.now(timezone.utc).isoformat()))
        print(json.dumps(dict(early=early_reports, late=late_reports)))
    except Exception as error:
        core.write(core.STAGE / "completion-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
