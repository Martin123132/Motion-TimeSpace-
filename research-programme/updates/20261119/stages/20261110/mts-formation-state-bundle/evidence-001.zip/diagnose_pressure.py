import json
import build_bundle as bundle

np = bundle.np
background = bundle.SPECTRUM / 'runs/projection/a225-w6-d8.npz'
with np.load(background) as packet:
    constant = float(packet['matching_density'])
    mass = float(packet['heavy_mass_mpc'])
report = dict(rows=0, naive_max=0.0, native_max=0.0, failures=0, examples=[])
for path in sorted((bundle.SPECTRUM / 'runs/heavy').glob('chunk-*.npz')):
    with np.load(path) as packet:
        names = packet['names'].tolist()
        for wave, history in zip(packet['modes'], packet['values']):
            if wave > 5:
                continue
            for raw in history[:5]:
                row = bundle.metric(raw, names, float(wave))
                scale, hubble = row['a'], row['H_conformal_Mpc_inverse']
                density = float(raw[names.index('mts_drho_h')]) * scale / constant
                velocity = float(raw[names.index('mts_q_h')]) * scale / constant
                recorded = float(raw[names.index('mts_dp_h')]) * scale / constant
                ratio = wave / (scale * mass)
                sound = ratio**2 / (np.sqrt(1 + ratio**2) + 1)**2
                stable = sound * (density + 3 * hubble * velocity / wave)
                naive = sound * (density - 3 * hubble * row['alpha_Mpc'] +
                    3 * hubble * (velocity + wave * row['alpha_Mpc']) / wave)
                error = abs(naive - recorded) / max(abs(recorded), abs(naive), 1e-100)
                native_error = abs(stable - recorded) / max(abs(recorded), abs(stable), 1e-100)
                report['rows'] += 1
                report['naive_max'] = max(report['naive_max'], float(error))
                report['native_max'] = max(report['native_max'], float(native_error))
                if error > bundle.ALGEBRA:
                    report['failures'] += 1
                    if len(report['examples']) < 3:
                        report['examples'].append(dict(k=float(wave), a=scale,
                            density=density, velocity=velocity, recorded=recorded,
                            naive=float(naive), stable=float(stable)))
bundle.write(bundle.STAGE / 'pressure-diagnosis.json', report)
print(json.dumps(report))
