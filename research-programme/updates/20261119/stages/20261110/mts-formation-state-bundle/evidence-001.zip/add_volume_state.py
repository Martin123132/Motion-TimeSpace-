import os
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import psutil

root = Path(__file__).resolve().parent
worker = psutil.Process()
worker.cpu_affinity([4])
worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
with (root / 'volume-start.json').open('x') as stream:
    json.dump(identity, stream)
try:
    inputs = {}
    tables = {}
    for name in ('late-heavy', 'late-cold'):
        path = root / (name + '.npz')
        inputs[str(path)] = hashlib.sha256(path.read_bytes()).hexdigest()
        with np.load(path) as packet:
            columns = packet['columns'].tolist()
            tables[name] = [dict(zip(columns, row)) for row in packet['values']]
    result = json.loads((root / 'result.json').read_text())
    for output in result['outputs']:
        if output['path'] in inputs:
            assert inputs[output['path']] == output['sha256']
    rows, errors = [], []
    for heavy, cold in zip(tables['late-heavy'], tables['late-cold']):
        assert heavy['nominal_a'] == cold['nominal_a'] and heavy['k_Mpc_inverse'] == cold['k_Mpc_inverse']
        physical, potential = heavy['heavy_delta_N'], heavy['Phi']
        coordinate = physical - 3 * potential
        cold_coordinate = cold['delta_cdm_N'] - 3 * cold['Phi']
        amplitude, phase, power = coordinate / 2, heavy['heavy_spatial_phase'], heavy['curvature_power']
        errors.append(abs(coordinate + 3 * potential - physical) / max(abs(physical), abs(3 * potential), 1e-100))
        errors.append(abs(cold_coordinate + 3 * cold['Phi'] - cold['delta_cdm_N']) /
                      max(abs(cold['delta_cdm_N']), abs(3 * cold['Phi']), 1e-100))
        matrix = power * np.outer([amplitude, phase], [amplitude, phase])
        errors.append(max(0.0, -float(np.linalg.eigvalsh(matrix / max(float(np.trace(matrix)), 1e-100)).min())))
        rows.append(dict(nominal_a=heavy['nominal_a'], k_Mpc_inverse=heavy['k_Mpc_inverse'],
            primordial_power=power, heavy_physical_density=physical, heavy_coordinate_number_contrast=coordinate,
            cold_physical_density=cold['delta_cdm_N'], cold_coordinate_number_contrast=cold_coordinate,
            heavy_coordinate_amplitude_real=amplitude, heavy_spatial_phase=phase,
            heavy_covariance_rr=matrix[0, 0], heavy_covariance_ri=matrix[0, 1], heavy_covariance_ii=matrix[1, 1],
            density_only_coordinate_error=3 * potential))
    assert len(rows) == 1995 and max(errors) < 1e-10
    columns = list(rows[0])
    values = np.array([[row[key] for key in columns] for row in rows])
    assert np.isfinite(values).all()
    path = root / 'volume-state.npz'
    assert not path.exists()
    np.savez_compressed(path, columns=np.array(columns), values=values,
                        approximation=np.array('linear metric measure; leading NR positive-frequency number; no new dynamics'))
    report = dict(passed=True, rows=len(rows), scalar_checks=len(errors), maximum_error=max(errors),
        gate=1e-10, inputs=inputs, output_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        derivation_sha256=hashlib.sha256((root / 'VOLUME-MEASURE.md').read_bytes()).hexdigest())
    with (root / 'volume-result.json').open('x') as stream:
        json.dump(report, stream, indent=2)
    with (root / 'volume-end.json').open('x') as stream:
        json.dump(dict(**identity, state='completed'), stream)
    print(json.dumps(report))
except Exception as error:
    with (root / 'volume-end.json').open('x') as stream:
        json.dump(dict(**identity, state='failed', error=repr(error)), stream)
    raise
