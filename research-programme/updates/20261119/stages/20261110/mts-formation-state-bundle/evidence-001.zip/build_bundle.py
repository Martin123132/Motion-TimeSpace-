import os
import sys
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True

import csv
import hashlib
import json
import time
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import psutil
import sympy as sym
from scipy.interpolate import CubicSpline
from scipy import constants

STAGE = Path(__file__).resolve().parent
POST = STAGE.parent
BRANCH = POST / "condensate-origin-20261003"
SPECTRUM = BRANCH / "resolved-matter-spectrum-20261007"
OLD = POST / "mts-covariance-dynamics-20261107"
EARLY = BRANCH / "native-two-field-transfer-20261007"
BRIDGE = Path("C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102")
START = time.monotonic()
ALGEBRA, GATE = 1e-10, 2e-5
INPUTS = {}
CHECKS = []


def guard():
    if time.monotonic() - START > 900:
        raise RuntimeError("bounded extraction time exceeded")
    for path in (STAGE / "STOP-REQUESTED", POST / "STOP-REQUESTED",
                 BRIDGE / "STOP-REQUESTED", BRIDGE.parent / "STOP-REQUESTED",
                 BRIDGE.parent / "execution-v3/STOP-REQUEST.json"):
        if path.exists():
            raise RuntimeError("owner hold: " + str(path))


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def protect(path, expected=None):
    path = Path(path)
    checksum = digest(path)
    if expected is not None and checksum != expected:
        raise ValueError("changed inherited file: " + str(path))
    if str(path) in INPUTS and INPUTS[str(path)] != checksum:
        raise ValueError("inconsistent provenance: " + str(path))
    INPUTS[str(path)] = checksum
    return path


def require(condition, name):
    guard()
    if not condition:
        raise ValueError(name)


def check(name, error, gate=ALGEBRA):
    error = float(error)
    require(np.isfinite(error) and abs(error) <= gate, name + ": " + str(error))
    CHECKS.append(dict(name=name, error=error, gate=gate, passed=True))


def half_ulp(value):
    single = np.float32(value)
    return 0.5 * max(abs(float(np.nextafter(single, np.float32(np.inf))) - float(single)),
                     abs(float(single) - float(np.nextafter(single, np.float32(-np.inf)))))


def symbolic():
    scale, hubble, mass, wave = sym.symbols("scale hubble mass wave", positive=True)
    base, speed, delta, delta_speed, alpha, curvature, lapse = sym.symbols(
        "base speed delta delta_speed alpha curvature lapse", real=True)
    field = delta + speed * alpha
    normal = delta_speed + (-3 * hubble * speed - (scale * mass)**2 * base) * alpha
    canonical_field = scale**sym.Rational(3, 2) * field
    canonical_momentum = sym.sqrt(scale) * (normal - 3 * curvature * speed + sym.Rational(3, 2) * hubble * field)
    recovered_field = canonical_field / scale**sym.Rational(3, 2)
    recovered_normal = canonical_momentum / sym.sqrt(scale) - sym.Rational(3, 2) * hubble * recovered_field + 3 * curvature * speed
    original = sym.Matrix([speed * delta_speed + (scale * mass)**2 * base * delta,
                           speed * delta_speed - (scale * mass)**2 * base * delta, wave * speed * delta])
    direct = sym.Matrix([speed * normal + (scale * mass)**2 * base * field,
                         speed * normal - (scale * mass)**2 * base * field, wave * speed * field])
    expected = original + sym.Matrix([-3 * hubble * speed**2 * alpha,
                 (-3 * hubble * speed**2 - 2 * (scale * mass)**2 * base * speed) * alpha,
                 wave * speed**2 * alpha])
    transform = sym.Matrix([[scale**sym.Rational(3, 2), 0],
                 [sym.Rational(3, 2) * hubble * sym.sqrt(scale), scale**(-sym.Rational(3, 2))]])
    residuals = list(direct - expected) + [recovered_field - field, recovered_normal - normal, transform.det() - 1]
    residuals += [sym.diff(canonical_momentum.subs(curvature, sym.Symbol("eta") / wave - hubble * alpha), alpha) -
                  sym.sqrt(scale) * (sym.Rational(3, 2) * hubble * speed - (scale * mass)**2 * base)]
    fluid_delta, fluid_speed = sym.symbols("fluid_delta fluid_speed", real=True)
    density = fluid_delta - 3 * hubble * alpha
    velocity = fluid_speed + wave * alpha
    phase = -scale * mass * velocity / wave
    residuals += [density + 3 * hubble * velocity / wave - fluid_delta - 3 * hubble * fluid_speed / wave,
                  -wave**2 * phase / (scale * mass) - wave * velocity]
    answer = [str(sym.simplify(value)) for value in residuals]
    require(all(value == "0" for value in answer), "symbolic canonical/gauge identities")
    return answer


def metric(raw, names, wave):
    value = lambda name: float(raw[names.index(name)])
    scale, hubble = value("a"), value("H")
    velocity, weyl = value("v_newtonian_cdm"), value("Weyl")
    alpha = -hubble * velocity / wave**2
    curvature = value("etak") / wave - hubble * alpha
    lapse = 2 * weyl / wave**2 - curvature
    alpha_error = abs(hubble / wave**2) * half_ulp(velocity)
    row = dict(a=scale, H_conformal_Mpc_inverse=hubble, k_Mpc_inverse=wave,
               alpha_Mpc=alpha, Phi=curvature, Psi=lapse,
               alpha_rounding_Mpc=alpha_error, Phi_rounding=abs(hubble) * alpha_error,
               Psi_rounding=2 * half_ulp(weyl) / wave**2 + abs(hubble) * alpha_error,
               delta_cdm_N=value("delta_cdm") - 3 * hubble * alpha,
               theta_cdm_N=wave**2 * alpha,
               delta_baryon_N=value("delta_baryon") - 3 * hubble * alpha,
               theta_baryon_N=-hubble * value("v_newtonian_baryon"),
               delta_cdm_rounding=half_ulp(value("delta_cdm")) + 3 * abs(hubble) * alpha_error,
               theta_cdm_rounding=wave**2 * alpha_error,
               curvature_power=2.1e-9 * (wave / .05)**(-.0347))
    return row


def background_functions(path):
    with np.load(path) as packet:
        data = {name: packet[name].copy() for name in packet.files}
    result = dict(data=data, slow_mass=float(data["slow_mass_mpc"]), heavy_mass=float(data["heavy_mass_mpc"]))
    for label, grid, field, speed in (("slow", "efold", "phi_s", "phidot_s"),
                                     ("heavy", "heavy_efold", "phi_h", "phidot_h")):
        if grid in data:
            result[label] = (CubicSpline(data[grid], data[field]), CubicSpline(data[grid], data[speed]))
    return result


def scalar_state(row, raw, names, background, label):
    scale, wave, hubble = row["a"], row["k_Mpc_inverse"], row["H_conformal_Mpc_inverse"]
    alpha, curvature = row["alpha_Mpc"], row["Phi"]
    field_spline, velocity_spline = background[label]
    base, speed = float(field_spline(np.log(scale))), float(velocity_spline(np.log(scale)))
    mass = background[label + "_mass"]
    suffix = "h" if label == "heavy" else "s"
    delta = float(raw[names.index("mts_dphi_" + suffix)])
    delta_speed = float(raw[names.index("mts_dphidot_" + suffix)])
    field = delta + speed * alpha
    normal = delta_speed + (-3 * hubble * speed - (scale * mass)**2 * base) * alpha
    canonical_field = scale**1.5 * field
    canonical_momentum = scale**.5 * (normal - 3 * curvature * speed + 1.5 * hubble * field)
    density = speed * normal + (scale * mass)**2 * base * field
    pressure = speed * normal - (scale * mass)**2 * base * field
    current = wave * speed * field
    old_source = np.array([float(raw[names.index("mts_" + term + "_" + suffix)])
                           for term in ("drho", "dp", "q")])
    expected = old_source + np.array([-3 * hubble * speed**2 * alpha,
                (-3 * hubble * speed**2 - 2 * (scale * mass)**2 * base * speed) * alpha,
                wave * speed**2 * alpha])
    actual = np.array([density, pressure, current])
    source_norm = max(float(np.max(abs(expected))), float(np.max(abs(old_source))), 1e-100)
    source_error = float(np.max(abs(actual - expected)) / source_norm)
    require(source_error <= GATE, "native scalar source reconstruction " + label)
    recovered_field = canonical_field / scale**1.5
    recovered_normal = canonical_momentum / scale**.5 - 1.5 * hubble * recovered_field + 3 * curvature * speed
    roundtrip = max(abs(recovered_field - field) / max(abs(field), 1e-100),
                    abs(recovered_normal - normal) / max(abs(normal), abs(3 * curvature * speed), 1e-100))
    require(roundtrip <= ALGEBRA, "canonical roundtrip " + label)
    values = dict(field_background=base, conformal_velocity_background=speed, mass_Mpc_inverse=mass,
                  field_N=field, normal_velocity_N=normal, canonical_q=canonical_field,
                  canonical_p=canonical_momentum, canonical_pi=scale**2 * (normal - 3 * curvature * speed),
                  D_N=density, P_N=pressure, Q_N=current, source_roundtrip=source_error,
                  canonical_roundtrip=roundtrip, omitted_volume_D_error=-3 * curvature * speed**2,
                  field_rounding=abs(speed) * row["alpha_rounding_Mpc"],
                  normal_velocity_rounding=abs(-3 * hubble * speed - (scale * mass)**2 * base) * row["alpha_rounding_Mpc"])
    if label == "heavy":
        mean_q = scale**1.5 * base
        mean_p = scale**.5 * (speed + 1.5 * hubble * base)
        denominator = mass * mean_q + 1j * mean_p
        relative = (mass * canonical_field + 1j * canonical_momentum) / denominator
        alpha_coefficient = (mass * scale**1.5 * speed +
                              1j * scale**.5 * (1.5 * hubble * speed - (scale * mass)**2 * base)) / denominator
        power = row["curvature_power"]
        error = abs(alpha_coefficient) * row["alpha_rounding_Mpc"]
        values.update(mean_q=mean_q, mean_p=mean_p, relative_B_real=float(relative.real),
                      relative_B_imag=float(relative.imag), B_rounding=float(error),
                      covariance_rr=float(power * relative.real**2),
                      covariance_ri=float(power * relative.real * relative.imag),
                      covariance_ii=float(power * relative.imag**2),
                      anomalous_real=float((power * relative**2).real),
                      anomalous_imag=float((power * relative**2).imag),
                      covariance_norm_rounding=float(power * (2 * abs(relative) * error + error**2)))
    row.update({label + "_" + name: float(value) for name, value in values.items()})


def save_table(name, rows, raw_names, raw_values, **extra):
    keys = list(rows[0])
    require(all(list(row) == keys for row in rows), "consistent export schema " + name)
    values = np.array([[row[key] for key in keys] for row in rows], dtype=float)
    require(np.isfinite(values).all(), "finite state export")
    path = STAGE / (name + ".npz")
    require(not path.exists(), "new output only")
    np.savez_compressed(path, columns=np.array(keys), values=values,
                        raw_names=np.array(raw_names), raw_values=np.array(raw_values), **extra)
    return dict(path=str(path), sha256=digest(path), rows=len(rows), columns=len(keys))


def audit_covariance(rows, real_key, imag_key):
    maximum = 0.0
    for row in rows:
        vector = np.array([row[real_key], row[imag_key]])
        norm = float(vector @ vector)
        if norm:
            scaled = np.outer(vector, vector) / norm
            maximum = max(maximum, max(0.0, -float(np.linalg.eigvalsh(scaled).min())))
    return maximum


def early_bundle():
    old_seed, old_gauge = read(OLD / "seed-result.json"), read(OLD / "gauge-result.json")
    for result in (old_seed, old_gauge):
        for path, checksum in result["source_hashes"].items():
            protect(path, checksum)
    protect(OLD / "primordial-seed.csv", old_seed["seed_sha256"])
    protect(OLD / "gauge-seed.csv", old_gauge["output_sha256"])
    protect(OLD / "seed-result.json")
    protect(OLD / "gauge-result.json")
    with (OLD / "gauge-seed.csv").open(newline="") as stream:
        gauge_rows = {(row["model"], float(row["nominal_a"]), float(row["k_Mpc_inverse"])): row
                      for row in csv.DictReader(stream)}
    cold_status = read(EARLY / "runs/final-bg8-start/status.json")
    cold_path = EARLY / "runs/final-bg8-start/cold.npz"
    cold_background = EARLY / "runs/backgrounds/cold.npz"
    pinned = {str(Path(path)).casefold(): checksum for path, checksum in cold_status["input_hashes"].items()}
    protect(cold_background, pinned[str(cold_background).casefold()])
    outputs = []
    reports = []
    for model in ("heavy", "cold"):
        background_path = EARLY / "runs/backgrounds" / (model + ".npz")
        background = background_functions(background_path)
        paths = sorted((SPECTRUM / "runs/exact-grid").glob("chunk-*.npz")) if model == "heavy" else [cold_path]
        rows, raw_values, names = [], [], None
        for path in paths:
            guard()
            with np.load(path) as packet:
                packet_names = packet["names"].tolist()
                require(names is None or packet_names == names, "constant early column order")
                names = packet_names
                values = packet["values"]
                indices = [int(np.argmin(abs(packet["requested_scale"] - epoch)))
                           for epoch in (.0002, .000225, .00025)]
                for wave, history in zip(packet["modes"], values):
                    if wave > 5:
                        continue
                    for epoch, index in zip((.0002, .000225, .00025), indices):
                        raw = history[index]
                        row = metric(raw, names, float(wave))
                        row.update(nominal_a=epoch, conformal_time_Mpc=float(packet["conformal_time"][index]),
                                   requested_a=float(packet["requested_scale"][index]))
                        scalar_state(row, raw, names, background, "slow")
                        if model == "heavy":
                            require(raw[names.index("mts_averaged_chart")] == 0, "raw real-field chart")
                            scalar_state(row, raw, names, background, "heavy")
                            old = gauge_rows[(model, epoch, float(wave))]
                            actual = np.array([row["heavy_" + key + "_N"] for key in ("D", "P", "Q")])
                            reference = np.array([float(old["heavy_" + key + "_newton"]) for key in ("D", "P", "Q")])
                            difference = float(np.max(abs(actual - reference)) / max(np.max(abs(reference)), 1e-100))
                            require(difference < ALGEBRA, "retained gauge-source comparison")
                            row["retained_gauge_source_error"] = difference
                        rows.append(row)
                        raw_values.append(raw.copy())
        require(len(rows) == (1197 if model == "heavy" else 12), "early coverage")
        if model == "heavy":
            check("early-correlated-covariance", audit_covariance(rows, "heavy_relative_B_real", "heavy_relative_B_imag"))
        outputs.append(save_table("early-" + model, rows, names, raw_values))
        reports.append(dict(model=model, rows=len(rows),
            maximum_source_roundtrip=max(row[key] for row in rows for key in row if key.endswith("source_roundtrip")),
            maximum_canonical_roundtrip=max(row[key] for row in rows for key in row if key.endswith("canonical_roundtrip")),
            exact_fast_phase_chart=model == "heavy", full_radiation_restart=False))
    return outputs, reports


def late_bundle():
    seal = read(SPECTRUM / "results/stage-integrity.json")
    protect(SPECTRUM / "results/stage-integrity.json")
    outputs, reports, retained = [], [], {}
    for model in ("heavy", "cold"):
        folder = SPECTRUM / "runs" / model
        status_path = folder / "status.json"
        protect(status_path, seal["file_hashes"]["runs/" + model + "/status.json"])
        status = read(status_path)
        require(status["state"] == "complete" and status["completed"] == 412, "late saved coverage")
        for path, checksum in status["input_hashes"].items():
            protect(path, checksum)
        source = SPECTRUM / "runs/projection/a225-w6-d8.npz" if model == "heavy" else EARLY / "runs/backgrounds/cold.npz"
        require(digest(source) == status["source_hash"], "late background owner")
        background = background_functions(source)
        density_constant = float(background["data"]["matching_density"]) if model == "heavy" else 0.0
        mass = background["heavy_mass"]
        mpc = constants.parsec * 1e6
        particle_mass = constants.hbar * mass / (constants.c * mpc)
        mean_number = density_constant * constants.c**2 / (8 * np.pi * constants.G * mpc**2 * particle_mass)
        rows, raw_values, names = [], [], None
        for path in sorted(folder.glob("chunk-*.npz")):
            guard()
            with np.load(path) as packet:
                packet_names = packet["names"].tolist()
                require(names is None or names == packet_names, "same late columns")
                names = packet_names
                indices = [int(np.argmin(abs(packet["requested_scale"] - epoch)))
                           for epoch in (.0003, .0005, .001, .003, .01)]
                values = packet["values"]
                for wave, history in zip(packet["modes"], values):
                    if wave > 5:
                        continue
                    for epoch, index in zip((.0003, .0005, .001, .003, .01), indices):
                        raw = history[index]
                        row = metric(raw, names, float(wave))
                        row.update(nominal_a=epoch, requested_a=float(packet["requested_scale"][index]),
                                   conformal_time_Mpc=float(packet["conformal_time"][index]))
                        scalar_state(row, raw, names, background, "slow")
                        scale, hubble = row["a"], row["H_conformal_Mpc_inverse"]
                        ratio = float(wave / (scale * mass))
                        dispersion = ratio**2 / (np.sqrt(1 + ratio**2) + 1)**2
                        horizon = float((hubble / wave)**2)
                        row.update(test_mass_Mpc_inverse=mass, gradient_ratio=ratio,
                                   leading_frequency_error=dispersion, horizon_scale_screen=horizon,
                                   H_over_am=float(hubble / (scale * mass)),
                                   both_scale_screens_pass=float(max(dispersion, horizon) < GATE))
                        if model == "heavy":
                            require(raw[names.index("mts_averaged_chart")] == 1, "late averaged chart")
                            require(raw[names.index("mts_dphi_h")] == 0 and raw[names.index("mts_dphidot_h")] == 0,
                                    "expected unused averaged raw-field slots")
                            source_scale = density_constant / scale
                            density_s = float(raw[names.index("mts_drho_h")]) / source_scale
                            velocity_s = float(raw[names.index("mts_q_h")]) / source_scale
                            density = density_s - 3 * hubble * row["alpha_Mpc"]
                            velocity = velocity_s + wave * row["alpha_Mpc"]
                            phase = -scale * mass * velocity / wave
                            pressure = float(raw[names.index("mts_dp_h")]) / source_scale
                            predicted = dispersion * (density + 3 * hubble * velocity / wave)
                            pressure_norm = max(abs(pressure), abs(predicted), 1e-100)
                            require(abs(predicted - pressure) / pressure_norm < ALGEBRA, "retained averaged pressure")
                            direct_pressure = ratio**2 * density / 4
                            mode_scale = max(abs(density), abs(density_s), abs(velocity), abs(velocity_s), 1e-100)
                            relative = complex(density / 2, phase)
                            power = row["curvature_power"]
                            row.update(heavy_delta_N=density, heavy_u_N=velocity, heavy_theta_N=wave * velocity,
                                       heavy_spatial_phase=phase, heavy_relative_NR_real=relative.real,
                                       heavy_relative_NR_imag=relative.imag,
                                       heavy_density_phase_covariance=power * relative.real * relative.imag,
                                       heavy_NR_covariance_rr=power * relative.real**2,
                                       heavy_NR_covariance_ii=power * relative.imag**2,
                                       heavy_pressure_retained=pressure, heavy_pressure_NR=direct_pressure,
                                       heavy_pressure_source_error=abs(direct_pressure - pressure) / mode_scale,
                                       heavy_pressure_fractional_difference=abs(direct_pressure - pressure) / pressure_norm,
                                       heavy_delta_rounding=3 * abs(hubble) * row["alpha_rounding_Mpc"],
                                       heavy_phase_rounding=scale * mass * row["alpha_rounding_Mpc"],
                                       heavy_comoving_number_per_m3=mean_number,
                                       heavy_source_scale=source_scale,
                                       heavy_linear_density_per_log_rms=float(np.sqrt(power) * abs(density)))
                            require(abs(-wave**2 * phase / (scale * mass) - wave * velocity) <
                                    ALGEBRA * max(abs(wave * velocity), 1e-100), "phase-current roundtrip")
                        rows.append(row)
                        raw_values.append(raw.copy())
        require(len(rows) == 1995, "late main-band coverage")
        if model == "heavy":
            check("late-correlated-covariance", audit_covariance(rows, "heavy_relative_NR_real", "heavy_relative_NR_imag"))
        outputs.append(save_table("late-" + model, rows, names, raw_values,
                                  exact_late_carrier_phase_supplied=np.array(False),
                                  full_hierarchy_restart=np.array(False)))
        retained[model] = rows
        for epoch in (.0003, .0005, .001, .003, .01):
            group = [row for row in rows if row["nominal_a"] == epoch]
            report = dict(model=model, a=epoch, modes=len(group),
                          both_scale_screens_pass=sum(row["both_scale_screens_pass"] > 0 for row in group),
                          minimum_k_screen=min((row["k_Mpc_inverse"] for row in group if row["both_scale_screens_pass"]), default=None),
                          maximum_k_screen=max((row["k_Mpc_inverse"] for row in group if row["both_scale_screens_pass"]), default=None),
                          max_H_over_am=max(row["H_over_am"] for row in group),
                          max_frequency_error=max(row["leading_frequency_error"] for row in group),
                          maximum_slow_source_error=max(row["slow_source_roundtrip"] for row in group))
            if model == "heavy":
                report.update(max_NR_pressure_source_error=max(row["heavy_pressure_source_error"] for row in group),
                              max_NR_pressure_fractional_difference=max(row["heavy_pressure_fractional_difference"] for row in group),
                              max_linear_density_per_log_rms=max(row["heavy_linear_density_per_log_rms"] for row in group))
            reports.append(report)
    keys = lambda rows: [(row["nominal_a"], row["k_Mpc_inverse"]) for row in rows]
    require(keys(retained["heavy"]) == keys(retained["cold"]), "paired mode/epoch ordering")
    for heavy, cold in zip(retained["heavy"], retained["cold"]):
        require(heavy["curvature_power"] == cold["curvature_power"], "same primordial spectrum")
        require(abs(heavy["requested_a"] / cold["requested_a"] - 1) < ALGEBRA, "same requested physical slice")
    paired = [dict(nominal_a=heavy["nominal_a"], k_Mpc_inverse=heavy["k_Mpc_inverse"],
                   curvature_power=heavy["curvature_power"],
                   heavy_delta=heavy["heavy_delta_N"], heavy_phase=heavy["heavy_spatial_phase"],
                   cold_delta=cold["delta_cdm_N"], cold_theta=cold["theta_cdm_N"],
                   density_cross_power=heavy["curvature_power"] * heavy["heavy_delta_N"] * cold["delta_cdm_N"],
                   heavy_cold_same_scale_screen=float(heavy["both_scale_screens_pass"] and cold["both_scale_screens_pass"]))
              for heavy, cold in zip(retained["heavy"], retained["cold"])]
    outputs.append(save_table("paired-late", paired, [], [[] for row in paired]))
    return outputs, reports


def main():
    worker = psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    guard()
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(),
                    started=datetime.now(timezone.utc).isoformat(), affinity=worker.cpu_affinity(), priority=worker.nice())
    write(STAGE / "worker-start.json", identity)
    try:
        sources = {str(path): digest(path) for path in STAGE.iterdir() if path.suffix in (".py", ".md")}
        for name in ("MTS-NATIVE-GAUGE-AND-PHYSICAL-EVOLUTION.md",
                     "MTS-COVARIANCE-TO-GRAVITATING-STATE.md",
                     "mts-galactic-population-transport-20261110/closeout.json",
                     "condensate-origin-20261003/native-heavy-matching-20261007/55-native-heavy-matching-and-late-matter.md"):
            protect(POST / name)
        identities = symbolic()
        write(STAGE / "symbolic.json", dict(passed=True, residuals=identities, sources=sources))
        early_outputs, early_reports = early_bundle()
        late_outputs, late_reports = late_bundle()
        for path, checksum in {**INPUTS, **sources}.items():
            require(digest(path) == checksum, "preserved input " + path)
        result = dict(passed=True, time=datetime.now(timezone.utc).isoformat(), outputs=early_outputs + late_outputs,
                      early_reports=early_reports, late_reports=late_reports, checks=CHECKS,
                      symbolic_identities=len(identities), sources=sources, inputs=INPUTS,
                      no_native_evolution=True, no_new_fit=True, full_all_species_restart=False,
                      early_fast_phase_information_retained=True, exact_late_fast_phase_recovered=False,
                      no_nonlinear_realization_generated=True, no_halo_population_selected=True,
                      original_gauge_derivative_resolution_unchanged=True, gates=[ALGEBRA, GATE])
        write(STAGE / "result.json", result)
        write(STAGE / "worker-end.json", dict(**identity, state="completed",
              finished=datetime.now(timezone.utc).isoformat(), result_sha256=digest(STAGE / "result.json")))
        print(json.dumps(dict(early=early_reports, late=late_reports, outputs=len(result["outputs"]))))
    except Exception as error:
        write(STAGE / "worker-end.json", dict(**identity, state="failed", error=repr(error),
                                            finished=datetime.now(timezone.utc).isoformat(), inputs=INPUTS, checks=CHECKS))
        raise


if __name__ == "__main__":
    main()
