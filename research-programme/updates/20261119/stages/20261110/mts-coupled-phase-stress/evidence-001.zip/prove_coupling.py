from coupled_support import *
import sympy as sp


def proofs():
    wave,mass2,omega,hubble,rate,field,velocity,field_first,velocity_first,mode,mode_velocity,dilation=sp.symbols('k mu2 omega H rate b v b_N v_N u w z', nonzero=True, real=True)
    background=sp.Matrix([field,velocity/omega])
    perturbation=sp.Matrix([mode,mode_velocity/omega])
    chi=rate*mass2/omega**2
    background_first=sp.Matrix([rate*field_first,rate*velocity_first/omega-chi*velocity/omega])
    defect=sp.Matrix([rate*field_first-velocity,(rate*velocity_first+2*hubble*velocity+mass2*field)/omega])
    background_matrix=sp.Matrix([[0,omega],[-mass2/omega,-2*hubble-chi]])+defect*background.T/(background.dot(background))
    perturbation_matrix=sp.Matrix([[0,omega],[-omega,-2*hubble-chi]])
    force=sp.Matrix([0,-wave*dilation*velocity/omega])
    mode_first=mode_velocity
    velocity_mode_first=-2*hubble*mode_velocity-(wave**2+mass2)*mode-wave*dilation*velocity
    perturbation_first=sp.Matrix([mode_first,velocity_mode_first/omega-chi*mode_velocity/omega])
    moment=background*perturbation.T
    transport=background_matrix*moment+moment*perturbation_matrix.T+background*force.T
    product=background_first*perturbation.T+background*perturbation_first.T
    identities={}

    def record(prefix,expression):
        values=list(expression) if isinstance(expression,sp.MatrixBase) else [expression]
        for index,value in enumerate(values):
            residual=sp.factor(value).subs(omega**2,wave**2+mass2)
            identities[prefix+'_'+str(index)]=bool(sp.simplify(residual)==0)

    record('background_chain',background_matrix*background-background_first)
    record('physical_product_rhs',transport-product)
    record('recover_two_degrees',moment.T*background/background.dot(background)-perturbation)
    density=velocity*mode_velocity+mass2*field*mode
    pressure=velocity*mode_velocity-mass2*field*mode
    current=wave*velocity*mode
    record('density',omega**2*moment[1,1]+mass2*moment[0,0]-density)
    record('pressure',omega**2*moment[1,1]-mass2*moment[0,0]-pressure)
    record('current',wave*omega*moment[1,0]-current)
    field_defect=rate*field_first-velocity
    velocity_defect=rate*velocity_first+2*hubble*velocity+mass2*field
    density_first=rate*velocity_first*mode_velocity+velocity*velocity_mode_first+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_first
    current_first=wave*(rate*velocity_first*mode+velocity*mode_first)
    record('off_shell_density',density_first+hubble*(density+3*pressure)+wave*current+wave*dilation*velocity**2-velocity_defect*mode_velocity-mass2*field_defect*mode-2*(rate-hubble)*mass2*field*mode)
    record('off_shell_current',current_first+2*hubble*current-wave*pressure-wave*velocity_defect*mode)
    background_density=(velocity**2+mass2*field**2)/2
    background_pressure=(velocity**2-mass2*field**2)/2
    background_density_first=velocity*rate*velocity_first+rate*mass2*field**2+mass2*field*rate*field_first
    record('off_shell_background',background_density_first+hubble*(background_density+3*background_pressure)-velocity*velocity_defect-mass2*field*field_defect-(rate-hubble)*mass2*field**2)
    coordinate,step,clock,origin,coef0,coef1,coef2,coef3=sp.symbols('coordinate step clock origin c0 c1 c2 c3',positive=True)
    polynomial=coef0+coef1*coordinate+coef2*coordinate**2+coef3*coordinate**3
    fraction=sp.log(clock/origin)/step
    scale=clock*polynomial.subs(coordinate,fraction)
    record('native_clock_derivative',sp.diff(scale,clock)-scale/clock-sp.diff(polynomial,coordinate).subs(coordinate,fraction)/step)
    return identities


def main():
    with worker('symbolic-coupling'):
        identities=proofs()
        require(all(identities.values()),'exact phase-source/clock identities')
        write('symbolic-result.json',dict(passed=True,identities=identities,source_hash=digest(__file__)))
        print(json.dumps(dict(passed=True,identities=len(identities))),flush=True)


if __name__=='__main__':
    main()
