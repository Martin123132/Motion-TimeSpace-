from coupled_math import *
from run_checked import validate_capture
import ast


def controls(sample, times, reference, kept, fields, scalar, label):
    position=len(times)//2
    state=reference[position].copy()
    base=sample(times[position],state)
    checks={}
    if fields==2:
        jet=base['jets'][1]
        background=np.array([jet[0],jet[1]/jet[5]])
        perpendicular=np.array([-background[1],background[0]])/np.linalg.norm(background)
        moment=state[kept+4:kept+8].reshape(2,2)
        addition=np.outer(perpendicular,np.array([1.,0.]))*np.linalg.norm(moment)/8
        changed=state.copy()
        changed[kept+4:kept+8]+=addition.ravel()
        probe=sample(times[position],changed)
        expected_density=jet[4]*addition[0,0]+jet[5]**2*addition[1,1]
        expected_current=jet[5]*addition[1,0]
        checks['unprojected_density']=comparison(probe['observation'][37]-base['observation'][37],expected_density,ALGEBRA)
        checks['unprojected_current']=comparison(probe['observation'][39]-base['observation'][39],expected_current,ALGEBRA)
        checks['unprojected_metric']=comparison(probe['extra'][3]-base['extra'][3],expected_density/(2*base['extra'][2]),ALGEBRA)
        checks['recovered_primitive_unchanged']=comparison(probe['observation'][35:37],base['observation'][35:37],ALGEBRA)
    state_repeat=sample(times[position],state)
    checks['no_override_leak']=dict(passed=all(np.array_equal(base[name],state_repeat[name]) for name in base))
    try:
        sample(times[0]-max((times[-1]-times[0])/100,1e-8),state)
    except ValueError as error:
        checks['outside_window_rejected']=dict(passed=scalar('status','phase').value==-14,error=str(error),status=scalar('status','phase').value)
    else:
        checks['outside_window_rejected']=dict(passed=False)
    report=dict(passed=all(row['passed'] for row in checks.values()),checks=checks,transverse_probe_is_nonphysical_diagnostic=True,rank_projection=False)
    write(label+'-controls.json',report)
    require(report['passed'],'live-source negative controls')
    print(json.dumps(report),flush=True)


def main():
    source=ROOT/'run_coupled.py'
    require(digest(source)==read(ROOT/'cold-matching-frozen.json')[str(source)],'original driver unchanged')
    changes=[]

    class Adapt(ast.NodeTransformer):
        def visit_Assign(self,node):
            if any(isinstance(target,ast.Name) and target.id=='label' for target in node.targets):
                node.value=ast.BinOp(left=node.value,op=ast.Add(),right=ast.Constant('-controls'))
                changes.append('label')
            return self.generic_visit(node)

        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='require' and len(node.value.args)==2 and isinstance(node.value.args[1],ast.Constant):
                if node.value.args[1].value=='original coupled handoff exact':
                    changes.append('active_capture')
                    return ast.parse('validate_capture(captured,prior,active,label)').body[0]
                if node.value.args[1].value=='bidirectional live coupling controls':
                    changes.append('controls')
                    return [node,*ast.parse('controls(sample,times,reference,kept,fields,scalar,label)\nreturn').body]
            return self.generic_visit(node)

    tree=Adapt().visit(ast.parse(source.read_text()))
    require(changes==['label','active_capture','controls'],'bounded negative-controls adapter')
    namespace=dict(__file__=__file__,__name__='live_controls',validate_capture=validate_capture,controls=controls)
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()


if __name__=='__main__':
    main()
