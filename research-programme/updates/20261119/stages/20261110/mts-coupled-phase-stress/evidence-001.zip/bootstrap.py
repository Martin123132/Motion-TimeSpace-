from coupled_support import *
import shutil


def main():
    with worker('bootstrap'):
        require(digest(PREVIOUS / 'closeout.json') == EXPECTED, 'latest verified stage')
        seal = read(PREVIOUS / 'closeout.json')
        mapping = dict(seal['input_hashes'])
        mapping.update({str(PREVIOUS / name): row['sha256'] for name, row in seal['artifacts'].items()})
        mapping[str(PREVIOUS / 'closeout.json')] = EXPECTED
        check_hashes(mapping)
        cleanup = read(PREVIOUS / 'CLEANUP-VERIFIED.json')
        require(cleanup['passed'] and exited(cleanup['verifier_identity'])['exited'], 'previous verifier exited')
        require(all(exited(row['identity'])['exited'] for row in cleanup['workers']), 'previous workers exited')
        target = ROOT / 'native'
        require(not target.exists(), 'new isolated native destination')
        copied = {}
        for relative in read(HANDOFF / 'native-bootstrap-result.json')['copied_source_hashes']:
            source = NATIVE / relative
            destination = target / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            copied[relative] = digest(source)
            require(digest(destination) == copied[relative], 'exact source copy')
        write('native-bootstrap-result.json', dict(completed=True, copied_source_hashes=copied, original=str(NATIVE), candidate=str(target)))
        write('frozen-inputs.json', mapping)
        write('contract.json', dict(previous_goal_turn='no progress: receipt-only relay; resumed the saved concrete calculation', numerical_gate=GATE, algebra_gate=ALGEBRA, windows=dict(matching=[2591,2890], tca=[512,520]), cases=['cold','heavy'], integration=dict(method='DOP853', coarse_rtol=4e-10, fine_rtol=1e-10, normalized_atol_fraction=.01, max_step_fraction=1/64), unchanged=['action','mass','coupling','background','initial physical state','bank','observation grids','acceptance tolerances'], direct_stress=True, live_metric=True, rank_projection=False, new_physical_modes=False))
        print(json.dumps(dict(copied=len(copied), verified_inputs=len(mapping), completed=True)), flush=True)


if __name__ == '__main__':
    main()
