from coupled_math import *
import ast


def validate_capture(captured, prior, active, label):
    mask = np.ones(96,dtype=bool)
    tight = bool(np.all(captured['signature'][:,11]==1) and np.all(prior['signature'][:,11]==1))
    if tight:
        mask[5]=False
    checks = {name:bool(np.array_equal(values,prior[name])) for name,values in captured.items() if name!='signature'}
    checks['active_signature_exact'] = bool(np.array_equal(captured['signature'][:,mask],prior['signature'][:,mask]))
    report = dict(passed=all(checks.values()),checks=checks,excluded_inactive_polarization_index=tight,original_polind=prior['signature'][:,5].tolist(),current_polind=captured['signature'][:,5].tolist(),reason='SetupScalarArrayIndices assigns EV%polind only outside TightCoupling; active pig/pigdot remain checked exactly')
    np.savez_compressed(ROOT/(label+'-capture.npz'),**captured)
    write(label+'-capture-check.json',report)
    require(report['passed'],'exact physical capture including all active caches and regime fields')


def main():
    refinement = '--step-refinement' in sys.argv
    if refinement:
        sys.argv.remove('--step-refinement')
    source = ROOT/'run_coupled.py'
    require(digest(source)==read(ROOT/'cold-matching-frozen.json')[str(source)],'original driver unchanged')
    if refinement and not (ROOT/'step-refinement-contract.json').exists():
        write('step-refinement-contract.json',dict(reason='matching fine run misses derivative_96; reduce internal max step without changing grids, bank or gates',method='DOP853',rtol=1e-10,normalized_atol=1e-12,max_steps=[128,256],gate=GATE,cases=['cold','heavy'],windows=['matching','tca']))
    changes = []

    class Adapt(ast.NodeTransformer):
        def visit_Assign(self,node):
            if any(isinstance(target,ast.Name) and target.id=='label' for target in node.targets):
                node.value=ast.BinOp(left=node.value,op=ast.Add(),right=ast.Constant('-stepcheck' if refinement else '-capture-fixed'))
                changes.append('label')
            if refinement and any(isinstance(target,ast.Name) and target.id=='refinement' for target in node.targets):
                node=ast.parse("refinement=columns(states['step128']['observation'],states['step256']['observation'],'observable_')").body[0]
                changes.append('comparison')
            return self.generic_visit(node)

        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='require' and len(node.value.args)==2 and isinstance(node.value.args[1],ast.Constant) and node.value.args[1].value=='original coupled handoff exact':
                changes.append('active_capture')
                return ast.parse('validate_capture(captured,prior,active,label)').body[0]
            return self.generic_visit(node)

        def visit_For(self,node):
            if refinement and isinstance(node.target,ast.Tuple) and [value.id for value in node.target.elts]==['variant','rtol']:
                node.iter=ast.parse("[('step128',1e-10),('step256',1e-10)]",mode='eval').body
                changes.append('step_runs')
            return self.generic_visit(node)

        def visit_Call(self,node):
            if refinement and isinstance(node.func,ast.Name) and node.func.id=='solve_ivp':
                for keyword in node.keywords:
                    if keyword.arg=='max_step':
                        keyword.value=ast.parse("(times[-1]-times[0])/int(variant.removeprefix('step'))",mode='eval').body
                        changes.append('max_step')
            return self.generic_visit(node)

    tree=Adapt().visit(ast.parse(source.read_text()))
    expected=['label','active_capture']+(['step_runs','max_step','comparison'] if refinement else [])
    require(changes==expected,'bounded capture/step adapter')
    namespace=dict(__file__=__file__,__name__='checked_phase',validate_capture=validate_capture)
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()


if __name__=='__main__':
    main()
