from coupled_support import *
import ast


def main():
    source = SOURCE / 'build_native.py'
    require(digest(source) == read(SOURCE / 'closeout.json')['artifacts']['build_native.py']['sha256'], 'retained serial build driver')
    changes = []

    class Adapt(ast.NodeTransformer):
        def visit_ImportFrom(self, node):
            if node.module == 'source_support':
                changes.append('support')
                node.module = 'coupled_support'
            return node

        def visit_Set(self, node):
            if all(isinstance(value, ast.Constant) for value in node.elts) and {value.value for value in node.elts} == {'fortran/MTSTwoField.f90', 'camb/mts.py'}:
                changes.append('declared_files')
                return ast.Set(elts=[ast.Constant('fortran/MTSTwoField.f90'), ast.Constant('fortran/camb_python.f90')])
            return self.generic_visit(node)

    tree = Adapt().visit(ast.parse(source.read_text(encoding='utf-8')))
    require(changes == ['support', 'declared_files'], 'bounded serial build adapter')
    namespace = dict(__file__=__file__, __name__='coupled_native_build')
    exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'), namespace)
    namespace['main']()


if __name__ == '__main__':
    main()
