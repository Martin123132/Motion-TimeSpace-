from coupled_math import *
from prove_coupling import proofs
import argparse


def numerical_validation():
    checks={}
    summaries={}
    conservation={}
    for case in ('cold','heavy'):
        for window in ('matching','tca'):
            label=case+'-'+window+'-stepcheck'
            report=read(ROOT/(label+'-result.json'))
            require(report['completed'] and report['passed'],'paired refined calculation completed '+label)
            require(report['live_metric'] and report['direct_stress'] and not report['rank_projection'],'actual source-coupled representation')
            require(report['native_owner_released'],'owner detached')
            check_hashes(report['source_hashes'])
            capture=read(ROOT/(label+'-capture-check.json'))
            require(capture['passed'] and all(capture['checks'].values()),'exact active capture')
            require(capture['excluded_inactive_polarization_index']==(window=='tca'),'only inactive TCA polarization index excluded')
            prior_path=HANDOFF/('early-'+('tca-' if window=='tca' else '')+case+'-restart.npz')
            with np.load(prior_path,allow_pickle=False) as data:
                prior={name:data[name].copy() for name in data.files}
            active=int(prior['active'])
            first=int(prior['signature'][0,2])-1
            kept,fields=report['kept'],report['fields']
            observations={}
            for variant in ('step128','step256'):
                name=label+'-'+variant
                path=ROOT/(name+'.npz')
                require(digest(path)==report['runs'][variant]['packet_sha256'],'immutable phase packet')
                with np.load(path,allow_pickle=False) as data:
                    packet={key:data[key].copy() for key in data.files}
                require(np.array_equal(packet['clock'],prior['clock']),'unchanged output epochs')
                require(np.array_equal(packet['state'][0],packet['reference'][0]),'exact inherited physical seed')
                selected=np.flatnonzero(prior['cache_mask'][0])
                groups=dict(state=columns(packet['vector'][:,:active],prior['reference'][:,:active],'state_'), observation=columns(packet['observation'],prior['observation_reference'],'observable_'), derivative=columns(packet['derivative'][:,:active],prior['derivative_reference'][:,:active],'derivative_'), moment=columns(packet['state'][:,kept:],packet['reference'][:,kept:],'moment_'),cache=columns(packet['cache'][:,selected],prior['cache_reference'][:,selected],'cache_'))
                remainder=transverse(packet['state'],packet['jets'],kept,fields)
                require(np.array_equal(remainder,packet['transverse']),'recomputed physical-subspace deviation')
                groups['physicality']={str(index):comparison(remainder[:,index]+packet['reference'][:,kept+index],packet['reference'][:,kept+index]) for index in range(4*fields)}
                require(groups==report['runs'][variant]['checks'],'independent recomputation of every accepted check')
                checks.update({name+'/'+group+'/'+key:row for group,rows in groups.items() for key,row in rows.items()})
                source_checks={}
                for component in range(fields):
                    moment=packet['state'][:,kept+4*component:kept+4*component+4].reshape(-1,2,2)
                    jet=packet['jets'][:,component]
                    omega,mass2=jet[:,5],jet[:,4]
                    background=np.column_stack([jet[:,0],jet[:,1]/omega])
                    recovered=np.einsum('tij,ti->tj',moment,background)/np.sum(background**2,axis=1)[:,None]
                    original=first+2*component
                    obs=30+5*component
                    source_checks[str(component)+'_u']=comparison(recovered[:,0],packet['vector'][:,original],ALGEBRA)
                    source_checks[str(component)+'_w']=comparison(recovered[:,1]*omega,packet['vector'][:,original+1],ALGEBRA)
                    density=omega**2*moment[:,1,1]+mass2*moment[:,0,0]
                    pressure=omega**2*moment[:,1,1]-mass2*moment[:,0,0]
                    current=omega*moment[:,1,0]
                    source_checks[str(component)+'_D']=comparison(density,packet['observation'][:,obs+2],ALGEBRA)
                    source_checks[str(component)+'_P']=comparison(pressure,packet['observation'][:,obs+3],ALGEBRA)
                    source_checks[str(component)+'_Q']=comparison(current,packet['observation'][:,obs+4],ALGEBRA)
                    expected=np.array([expected_moment_rhs(item,extra[1],extra[2],extra[3],value) for item,extra,value in zip(jet,packet['extra'],moment)])
                    source_checks[str(component)+'_independent_rhs']=comparison(expected.reshape(-1,4),packet['rhs'][:,kept+4*component:kept+4*component+4],ALGEBRA)
                    clock_derivative=packet['extra'][:,1]
                    hubble=packet['extra'][:,2]
                    source_checks[str(component)+'_clock_readout']=comparison(packet['extra'][:,0],packet['observation'][:,27],ALGEBRA)
                    field_defect=clock_derivative*jet[:,2]-jet[:,1]
                    velocity_defect=clock_derivative*jet[:,3]+2*hubble*jet[:,1]+mass2*jet[:,0]
                    conservation[name+'/'+str(component)]=dict(field_defect_peak=float(np.max(abs(field_defect))),velocity_defect_peak=float(np.max(abs(velocity_defect))),thermal_rate_minus_friedmann_peak=float(np.max(abs(clock_derivative-hubble))),background_norm_min=float(np.min(np.sum(background**2,axis=1))))
                for key,row in source_checks.items():
                    checks[name+'/direct/'+key]=row
                if fields==2:
                    require(np.all(packet['vector'][:,first+4]==0),'unchanged exact coherent branch selector')
                observations[variant]=packet['observation']
                summaries[name]=report['runs'][variant]['worst']
            refinement=columns(observations['step128'],observations['step256'],'observable_')
            require(refinement==report['refinement'],'recomputed step sensitivity')
            checks.update({label+'/refinement/'+key:row for key,row in refinement.items()})
            algebra=read(ROOT/(label+'-algebra.json'))
            feedback=read(ROOT/(label+'-feedback.json'))
            require(algebra['passed'] and feedback['passed'],'same-state product and two-way perturbation tests')
            checks.update({label+'/algebra/'+group+'/'+key:row for group,rows in algebra['checks'].items() for key,row in rows.items()})
            checks.update({label+'/feedback/'+key:row for key,row in feedback['checks'].items()})
    require(all(row['passed'] for row in checks.values()),'all independently recomputed coupled comparisons')
    original=read(ROOT/'heavy-matching-result.json')
    require(not original['passed'] and not original['runs']['fine']['checks']['derivative']['derivative_96']['passed'],'original numerical failure retained')
    diagnosis=read(ROOT/'cold-tca-capture-diagnosis.json')
    require(all(row['exact'] for key,row in diagnosis.items() if key!='signature'),'diagnosed TCA mismatch only inactive signature')
    require(all(index[1]==5 for index in diagnosis['signature']['first_indices']),'inactive polarization-index ownership')
    for label in ('heavy-matching-controls','cold-tca-controls'):
        require(read(ROOT/(label+'-controls.json'))['passed'],'negative live-source/owner guards')
    return dict(passed=True,checks=checks,summaries=summaries,off_shell_background_diagnostics=conservation,old_adaptive_only_pair_passed=False,refined_live_pair_passed=True)


def cleanup_rows(exclude):
    rows=[]
    for path in sorted(ROOT.glob('*-start.json')):
        label=path.name.removesuffix('-start.json')
        if label in exclude:
            continue
        end=ROOT/(label+'-end.json')
        require(end.exists(),'terminal worker receipt '+label)
        identity=read(path)
        outcome=exited(identity)
        require(outcome['exited'],'task-owned worker exited '+label)
        rows.append(dict(name=label,identity=identity,state=read(end)['state'],outcome=outcome))
    build=read(ROOT/'native-build-result.json')
    children=[dict(identity=row['identity'],outcome=exited(row['identity'])) for row in build['children']]
    require(all(row['outcome']['exited'] for row in children),'compiler helpers all exited')
    import ctypes
    buffer=ctypes.create_unicode_buffer(32768)
    size=ctypes.windll.kernel32.QueryDosDeviceW(build['temporary_drive'],buffer,len(buffer))
    require(not size or buffer.value.casefold()!=('\\??\\'+str(POST)).casefold(),'owned build mapping removed')
    return rows,children


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=('validate','seal','postseal'))
    args=parser.parse_args()
    with worker(args.mode):
        if args.mode=='validate':
            check_hashes(read(ROOT/'frozen-inputs.json'))
            bootstrap=read(ROOT/'native-bootstrap-result.json')
            changed=[]
            for relative,checksum in bootstrap['copied_source_hashes'].items():
                require(digest(NATIVE/relative)==checksum,'original native sources preserved')
                if digest(ROOT/'native'/relative)!=checksum:
                    changed.append(relative.replace('\\','/'))
            require(set(changed)=={'fortran/MTSTwoField.f90','fortran/camb_python.f90'},'declared isolated native changes only')
            check_hashes(read(ROOT/'native-build-result.json')['source_hashes'])
            for path in ROOT.glob('*.py'):
                compile(path.read_text(),str(path),'exec')
            require(not list(ROOT.rglob('__pycache__')),'no Python cache residue')
            result=numerical_validation()
            identities=proofs()
            require(all(identities.values()),'independently rerun symbolic identities')
            result['symbolic_identities']=identities
            result['source_files_changed']=changed
            result['workers'],result['compiler_children']=cleanup_rows({'validate'})
            write('validation.json',result)
            print(json.dumps(dict(passed=True,comparisons=len(result['checks']),identities=len(identities),workers_exited=len(result['workers']),compiler_children=len(result['compiler_children']))),flush=True)
        elif args.mode=='seal':
            validation=read(ROOT/'validation.json')
            require(validation['passed'],'validation passed')
            rows,children=cleanup_rows({'seal'})
            artifacts={str(path.relative_to(ROOT)):dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('seal-start.json','seal-end.json')}
            result=dict(implementation_validated=True,paired_live_phase_stress_passed=True,original_adaptive_only_pair_passed=False,physical_mode_count_unchanged=True,early_to_late_transfer_complete=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts,workers=rows,compiler_children=children)
            write('closeout.json',result)
            print(json.dumps(dict(seal_sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)
        else:
            seal=read(ROOT/'closeout.json')
            check_hashes({str(ROOT/name):row['sha256'] for name,row in seal['artifacts'].items()})
            check_hashes(seal['input_hashes'])
            rows,children=cleanup_rows({'postseal'})
            identity=read(ROOT/'postseal-start.json')
            write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=rows,compiler_children=children,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
            print(json.dumps(dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers_exited=len(rows))),flush=True)


if __name__=='__main__':
    main()
