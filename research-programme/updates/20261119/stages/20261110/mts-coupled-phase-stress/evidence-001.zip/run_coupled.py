from coupled_math import *
import argparse
import ast
import ctypes
from scipy.integrate import solve_ivp


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('window', choices=('matching', 'tca'))
    args = parser.parse_args()
    label = args.case + '-' + args.window
    with worker(label):
        contract = read(ROOT / 'contract.json')
        lower, upper = contract['windows'][args.window]
        build = read(ROOT / 'native-build-result.json')
        local = ROOT / 'native'
        require(build['state'] == 'completed' and build['temporary_mapping_removed'], 'completed isolated build')
        require(all(exited(row['identity'])['exited'] for row in build['children']), 'compiler helpers exited')
        require(digest(local / 'camb/cambdll.dll') == build['dll_sha256'], 'frozen native binary')
        prior_path = HANDOFF / ('early-' + ('tca-' if args.window == 'tca' else '') + args.case + '-restart.npz')
        table_path = BACKGROUND / (args.case + '-candidate-background.npz')
        clock_path = SOURCE / 'heavy-equation-quintic.npz'
        observer_owner = POST / 'mts-metric-feedback-20261107'
        factory_path = BRANCH / 'native-heavy-matching-20261007/matching_common.py'
        source_hashes = {str(path): digest(path) for path in (Path(__file__), ROOT / 'coupled_math.py', ROOT / 'coupled_support.py', ROOT / 'contract.json', local / 'camb/cambdll.dll', prior_path, table_path, clock_path, observer_owner / 'observer.dll', factory_path)}
        write(label + '-frozen.json', source_hashes)
        require(source_hashes[str(prior_path)] == read(HANDOFF / 'closeout.json')['artifacts'][prior_path.name]['sha256'], 'sealed native reference')
        sys.path.insert(0, str(local))
        import camb
        from camb.mts import MTSTwoField
        require(Path(camb.__file__).resolve().parent == (local / 'camb').resolve(), 'isolated native import')
        sys.path.append(str(BRANCH / 'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        factory = next(node for node in ast.parse(factory_path.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_path), 'exec'), namespace)
        params = namespace['params_for'](table_path)
        if args.case == 'heavy':
            with np.load(clock_path, allow_pickle=False) as packet:
                model = params.DarkEnergy.copy()
                model.set_table('SetHeavyClock', packet['efold'], packet['H'], packet['H_N'])
                params.DarkEnergy = model
        observer_dll = ctypes.CDLL(str(observer_owner / 'observer.dll'))
        callback = ctypes.cast(observer_dll.source_func_, ctypes.c_void_p)
        library = ctypes.CDLL(str(local / 'camb/cambdll.dll'))
        reset = library.mts_early_reset
        reset.argtypes, reset.restype = [], None
        copy = library.mts_early_copy
        copy.argtypes, copy.restype = [ctypes.c_int, ctypes.c_int] + [ctypes.c_void_p] * 11, None
        initialize = library.mts_phase_init
        initialize.argtypes, initialize.restype = [], None
        pack = library.mts_phase_pack
        pack.argtypes, pack.restype = [ctypes.c_double, ctypes.c_int] + [ctypes.c_void_p] * 3, None
        evaluate = library.mts_phase_evaluate
        evaluate.argtypes, evaluate.restype = [ctypes.c_double, ctypes.c_int] + [ctypes.c_void_p] * 8, None

        def scalar(name, family='early'):
            return ctypes.c_int.in_dll(library, 'mts_' + family + '_' + name)

        def pointers(*arrays):
            return [ctypes.c_void_p(value.ctypes.data) for value in arrays]

        with np.load(prior_path, allow_pickle=False) as packet:
            prior = {name: packet[name].copy() for name in packet.files}
        native = camb.get_background(params)
        try:
            clock = np.ascontiguousarray(native.conformal_time(1 / prior['requested_scale'] - 1, tol=1e-10))
            require(np.array_equal(clock, prior['full_clock']), 'identical original clock')
            native.Params.Accuracy.IntTolBoost = 6
            native.Params.Accuracy.lAccuracyBoost = 4
            standard_names = list(camb.model.evolve_names)
            output = np.zeros((1, len(clock), len(standard_names) + 30))
            reset()
            scalar('begin').value, scalar('end').value = lower + 1, upper + 1
            wave = np.array([1.])
            code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(1)), wave, ctypes.byref(ctypes.c_int(len(clock))), clock, ctypes.byref(ctypes.c_int(output.shape[-1])), output, ctypes.byref(ctypes.c_int(30)), ctypes.byref(callback))
            metadata = {name: scalar(name).value for name in ('count','nvar','active','status')}
            write(label + '-native-status.json', dict(code=int(code), **metadata))
            require(code == 0 and metadata['status'] == 2, 'native capture completed')
            parity = dict(standard=np.array_equal(output[0,:,:len(standard_names)], prior['standard']), observer=np.array_equal(output[0,:,len(standard_names):], prior['observer']))
            require(all(parity.values()), 'disabled instrumentation leaves original 4253 outputs exact')
            samples, allocated, active = metadata['count'], metadata['nvar'], metadata['active']
            captured = {name: np.zeros((samples, allocated)) for name in ('reference','restarted','derivative_reference','derivative_restarted')}
            captured.update({name: np.zeros((samples,40)) for name in ('observation_reference','observation_restarted')})
            captured.update({name: np.zeros((samples,23)) for name in ('cache_reference','cache_restarted')})
            captured['cache_mask'] = np.zeros((samples,23), dtype=np.int32)
            captured['signature'] = np.zeros((samples,96), dtype=np.int32)
            captured['clock'] = np.zeros(samples)
            copy(allocated, samples, *pointers(*captured.values()))
            require(all(np.array_equal(values,prior[name]) for name,values in captured.items()), 'original coupled handoff exact')
            require(np.all(captured['signature'] == captured['signature'][0]), 'no regime change')
            initialize()
            require(scalar('status','phase').value == 1, 'valid live native phase owner')
            dimension, kept, fields = [scalar(name,'phase').value for name in ('dimension','kept','fields')]
            first = int(captured['signature'][0,2]) - 1
            kept_indices = np.array([index for index in range(active) if not first <= index < first + 2 * fields])
            times = captured['clock']
            reference = np.zeros((samples,dimension))
            reference_jets = np.zeros((samples,2,6))
            for index,tau in enumerate(times):
                pack(tau,dimension,*pointers(captured['reference'][index],reference[index],reference_jets[index]))
            require(scalar('status','phase').value == 1, 'phase packing completed')
            sizes = dict(rhs=(dimension,), observation=(40,), vector=(allocated,), derivative=(allocated,), cache=(23,), jets=(2,6), extra=(4,))

            def sample(tau, state):
                guard()
                values = {name: np.zeros(shape) for name,shape in sizes.items()}
                state = np.ascontiguousarray(state)
                evaluate(float(tau),dimension,*pointers(state,*values.values()))
                require(scalar('status','phase').value == 1, 'native coupled RHS status')
                require(all(np.isfinite(value).all() for value in values.values()), 'finite coupled RHS')
                return values

            direct = {name: [] for name in sizes}
            expected = []
            for index,tau in enumerate(times):
                values = sample(tau,reference[index])
                for name in sizes:
                    direct[name].append(values[name])
                derivative = list(captured['derivative_reference'][index,kept_indices])
                for component in range(fields):
                    jet = values['jets'][component]
                    field,velocity,field_first,velocity_first,mass2,omega = jet
                    rate,hubble,dilation = values['extra'][1:]
                    background = np.array([field,velocity/omega])
                    background_first = np.array([rate*field_first,rate*velocity_first/omega-rate*mass2*velocity/omega**3])
                    original = first+2*component
                    perturbation = np.array([captured['reference'][index,original],captured['reference'][index,original+1]/omega])
                    perturbation_first = np.array([captured['derivative_reference'][index,original],captured['derivative_reference'][index,original+1]/omega-rate*mass2*captured['reference'][index,original+1]/omega**3])
                    derivative.extend((np.outer(background_first,perturbation)+np.outer(background,perturbation_first)).ravel())
                expected.append(derivative)
            direct = {name: np.array(values) for name,values in direct.items()}
            expected = np.array(expected)
            checks = dict(roundtrip=columns(direct['vector'][:,:active],captured['reference'][:,:active],'state_',ALGEBRA), source=columns(direct['observation'],captured['observation_reference'],'observable_',ALGEBRA), rhs=columns(direct['rhs'],expected,'coordinate_',ALGEBRA))
            algebra_pass = all(row['passed'] for group in checks.values() for row in group.values())
            write(label + '-algebra.json', dict(passed=algebra_pass, checks=checks))
            require(algebra_pass, 'same-state source and independent product derivative')
            base = sample(times[0],reference[0])
            changed = reference[0].copy()
            cold_index = int(np.flatnonzero(kept_indices==1)[0])
            amplitude = max(abs(changed[cold_index]),1.)/4
            changed[cold_index] += amplitude
            kicked = sample(times[0],changed)
            predicted_z = base['observation'][12]*amplitude/(2*base['extra'][2])
            feedback = dict(cdm_to_metric=comparison(kicked['extra'][3]-base['extra'][3],predicted_z,ALGEBRA))
            for component in range(fields):
                jet = base['jets'][component]
                background = np.array([jet[0],jet[1]/jet[5]])
                expected_change = np.outer(background,np.array([0.,-predicted_z*background[1]])).ravel()
                section = slice(kept+4*component,kept+4*component+4)
                feedback['metric_to_phase_'+str(component)] = comparison(kicked['rhs'][section]-base['rhs'][section],expected_change,ALGEBRA)
            if fields==2:
                changed = reference[0].copy()
                changed[kept+4:kept+8] *= 1.25
                kicked = sample(times[0],changed)
                expected_density = base['observation'][37]/4
                expected_current = base['observation'][39]/4
                feedback['phase_to_metric'] = comparison(kicked['extra'][3]-base['extra'][3],expected_density/(2*base['extra'][2]),ALGEBRA)
                feedback['phase_to_momentum_constraint'] = comparison(kicked['derivative'][0]-base['derivative'][0],expected_current/2,ALGEBRA)
            write(label + '-feedback.json', dict(passed=all(row['passed'] for row in feedback.values()), checks=feedback))
            require(all(row['passed'] for row in feedback.values()), 'bidirectional live coupling controls')
            normalization = np.max(abs(reference),axis=0)
            normalization[normalization==0] = 1.
            runs,states = {},{}
            for variant,rtol in [('coarse',contract['integration']['coarse_rtol']),('fine',contract['integration']['fine_rtol'])]:
                def rhs(tau,normalized):
                    return sample(tau,normalized*normalization)['rhs']/normalization
                solution = solve_ivp(rhs,(times[0],times[-1]),reference[0]/normalization,method='DOP853',t_eval=times,rtol=rtol,atol=rtol*.01,max_step=(times[-1]-times[0])/64)
                require(solution.success and solution.y.shape==(dimension,samples), 'completed independent phase evolution')
                state = solution.y.T*normalization
                observed = {name: [] for name in sizes}
                for tau,row in zip(times,state):
                    values = sample(tau,row)
                    for name in sizes:
                        observed[name].append(values[name])
                observed = {name:np.array(values) for name,values in observed.items()}
                transverse_values = transverse(state,observed['jets'],kept,fields)
                comparisons = dict(state=columns(observed['vector'][:,:active],captured['reference'][:,:active],'state_'), observation=columns(observed['observation'],captured['observation_reference'],'observable_'), derivative=columns(observed['derivative'][:,:active],captured['derivative_reference'][:,:active],'derivative_'), moment=columns(state[:,kept:],reference[:,kept:],'moment_'))
                physicality = {}
                for index in range(fields*4):
                    physicality[str(index)] = comparison(transverse_values[:,index]+reference[:,kept+index],reference[:,kept+index])
                comparisons['physicality'] = physicality
                selected = np.flatnonzero(captured['cache_mask'][0])
                comparisons['cache'] = columns(observed['cache'][:,selected],captured['cache_reference'][:,selected],'cache_')
                path = ROOT/(label+'-'+variant+'.npz')
                np.savez_compressed(path,state=state,reference=reference,reference_jets=reference_jets,clock=times,kept_indices=kept_indices,transverse=transverse_values,expected_rhs=expected,**observed)
                passed = all(row['passed'] for group in comparisons.values() for row in group.values())
                worst = {group:max((row['normalized'] for row in rows.values() if row['normalized'] is not None),default=0.) for group,rows in comparisons.items()}
                runs[variant] = dict(passed=passed,checks=comparisons,worst=worst,evaluations=solution.nfev,rtol=rtol,packet_sha256=digest(path))
                states[variant] = observed
                print(json.dumps(dict(case=args.case,window=args.window,variant=variant,passed=passed,worst=worst,evaluations=solution.nfev)),flush=True)
            refinement = columns(states['coarse']['observation'],states['fine']['observation'],'observable_')
        finally:
            reset()
            cleared = scalar('status','phase').value==0 and scalar('count').value==0
            del native
        require(cleared, 'native owner detached, override disabled, buffers released')
        check_hashes(source_hashes)
        passed = all(row['passed'] for row in runs.values()) and all(row['passed'] for row in refinement.values())
        write(label+'-result.json',dict(completed=True,passed=passed,metadata=metadata,dimension=dimension,fields=fields,kept=kept,original_parity=parity,algebra_pass=algebra_pass,feedback=feedback,runs=runs,refinement=refinement,source_hashes=source_hashes,native_owner_released=cleared,live_metric=True,direct_stress=True,rank_projection=False,portable_restart=False))


if __name__=='__main__':
    main()
