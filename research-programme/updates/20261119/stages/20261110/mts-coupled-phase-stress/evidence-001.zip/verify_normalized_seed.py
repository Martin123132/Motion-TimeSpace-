from coupled_math import *
import ast


def verify_normalized_seed(packet):
    seed=packet['reference'][0]
    normalization=np.max(abs(packet['reference']),axis=0)
    normalization[normalization==0]=1.
    normalized=seed/normalization
    represented=normalized*normalization
    require(np.array_equal(packet['state'][0],represented),'exact normalized seed arithmetic reproduced')
    require(np.all((normalized==0)|(abs(normalized)>=np.finfo(float).tiny)),'normal-range normalized seed')
    bound=2*np.finfo(float).eps*abs(seed)
    require(np.all(abs(represented-seed)<=bound),'initial difference bounded by division/multiplication roundoff')
    require(np.array_equal(represented[seed==0],seed[seed==0]),'exact zero seed entries remain zero')


def main():
    source=ROOT/'verify_coupled.py'
    changes=[]

    class Adapt(ast.NodeTransformer):
        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='require' and len(node.value.args)==2 and isinstance(node.value.args[1],ast.Constant) and node.value.args[1].value=='exact inherited physical seed':
                changes.append('seed_roundoff')
                return ast.parse('verify_normalized_seed(packet)').body[0]
            return self.generic_visit(node)

        def visit_Call(self,node):
            if isinstance(node.func,ast.Name) and node.func.id=='worker':
                changes.append('distinct_receipt')
                node.args[0]=ast.parse("args.mode+'-normalized-seed' if args.mode=='validate' else args.mode",mode='eval').body
            return self.generic_visit(node)

        def visit_Set(self,node):
            if len(node.elts)==1 and isinstance(node.elts[0],ast.Constant) and node.elts[0].value=='validate':
                changes.append('cleanup_exclusion')
                return ast.Set(elts=[ast.Constant('validate-normalized-seed')])
            return self.generic_visit(node)

    tree=Adapt().visit(ast.parse(source.read_text()))
    require(changes==['seed_roundoff','distinct_receipt','cleanup_exclusion'],'validator changes only seed arithmetic and receipt identity')
    namespace=dict(__file__=__file__,__name__='normalized_seed_validation',verify_normalized_seed=verify_normalized_seed)
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()


if __name__=='__main__':
    main()
