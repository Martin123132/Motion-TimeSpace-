from coupled_support import *
import numpy as np


def comparison(actual, reference, tolerance=GATE):
    absolute = float(np.max(abs(np.asarray(actual) - reference)))
    peak = float(np.max(abs(reference)))
    return dict(passed=absolute <= tolerance * peak, absolute_error=absolute, reference_peak=peak, normalized=absolute / peak if peak else (0.0 if absolute == 0 else None), tolerance=tolerance)


def columns(actual, reference, prefix, tolerance=GATE):
    return {prefix + str(index): comparison(actual[:, index], reference[:, index], tolerance) for index in range(reference.shape[1])}


def expected_moment_rhs(jet, rate, hubble, dilation, moment, wave=1.):
    field, velocity, field_first, velocity_first, mass2, omega = jet
    background = np.array([field, velocity / omega])
    chi = rate * mass2 / omega**2
    defect = np.array([rate * field_first - velocity, (rate * velocity_first + 2 * hubble * velocity + mass2 * field) / omega])
    background_matrix = np.array([[0., omega], [-mass2 / omega, -2 * hubble - chi]]) + np.outer(defect, background) / (background @ background)
    perturbation_matrix = np.array([[0., omega], [-omega, -2 * hubble - chi]])
    force = np.array([0., -wave * dilation * background[1]])
    return background_matrix @ moment + moment @ perturbation_matrix.T + np.outer(background, force)


def transverse(states, jets, kept, fields):
    result = []
    for component in range(fields):
        moment = states[:, kept + 4 * component:kept + 4 * component + 4].reshape(-1, 2, 2)
        background = np.column_stack([jets[:, component, 0], jets[:, component, 1] / jets[:, component, 5]])
        recovered = np.einsum('tij,ti->tj', moment, background) / np.sum(background**2, axis=1)[:, None]
        remainder = moment - background[:, :, None] * recovered[:, None, :]
        result.append(remainder.reshape(-1, 4))
    return np.concatenate(result, axis=1)
