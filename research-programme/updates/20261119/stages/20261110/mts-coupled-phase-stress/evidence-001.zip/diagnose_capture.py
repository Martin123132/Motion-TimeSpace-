from coupled_math import *
import ast


def audit_capture(captured, prior, active):
    rows = {}
    for name,actual in captured.items():
        reference = prior[name]
        unequal = np.argwhere(actual!=reference)
        row = dict(exact=len(unequal)==0, unequal_count=len(unequal), first_indices=unequal[:10].tolist(), comparison=comparison(actual,reference))
        if name in ('reference','restarted','derivative_reference','derivative_restarted'):
            row['active'] = columns(actual[:,:active],reference[:,:active],'coordinate_',ALGEBRA)
            row['active_exact'] = bool(np.array_equal(actual[:,:active],reference[:,:active]))
        rows[name] = row
    np.savez_compressed(ROOT/'cold-tca-capture-diagnosis.npz',**captured)
    write('cold-tca-capture-diagnosis.json',rows)
    print(json.dumps({name:{key:value for key,value in row.items() if key not in ('active','first_indices')} for name,row in rows.items()}),flush=True)
    raise SystemExit(0)


def main():
    source = ROOT/'run_coupled.py'
    tree = ast.parse(source.read_text())
    changes = []

    class Adapt(ast.NodeTransformer):
        def visit_Assign(self,node):
            if any(isinstance(target,ast.Name) and target.id=='label' for target in node.targets):
                node.value = ast.BinOp(left=node.value,op=ast.Add(),right=ast.Constant('-capture-diagnosis'))
                changes.append('label')
            return self.generic_visit(node)

        def visit_Expr(self,node):
            if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id=='require' and len(node.value.args)==2 and isinstance(node.value.args[1],ast.Constant) and node.value.args[1].value=='original coupled handoff exact':
                changes.append('capture_audit')
                return ast.parse('audit_capture(captured,prior,active)').body[0]
            return self.generic_visit(node)

    tree = Adapt().visit(tree)
    require(changes==['label','capture_audit'],'bounded capture diagnosis adapter')
    namespace = dict(__file__=__file__,__name__='capture_diagnosis',audit_capture=audit_capture)
    exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
    namespace['main']()


if __name__=='__main__':
    main()
