from common import *
from operators import Operators, preparation, defects, norm
import numpy as np


def main():
    with worker("preparation"):
        write("frozen-inputs.json", preserved())
        require(read(ROOT/"proof.json")["passed"], "derived identities")
        operator = Operators("heavy", canonical=True)
        try:
            packets, rows, refinements = {}, [], []
            last_states, last_jets = None, None
            for divisions in (4, 8, 16):
                jets = operator.jets(0, divisions)
                states, reports, responses = preparation(operator, jets)
                row = dict(divisions=divisions, preparations=reports, defects={name:defects(operator, jets, state) for name,state in states.items()})
                if last_states is not None:
                    hubble = float(jets["hubble"][0])
                    coefficient_scale = max(norm(jets["combined"][0]*operator.scale), 1e-100)
                    refine = dict(divisions=divisions, state_errors={name:norm((state-last_states[name])/operator.scale) for name,state in states.items()},
                                  first_row_error=norm((jets["combined"][1]-last_jets["combined"][1])*operator.scale)/(hubble*coefficient_scale),
                                  second_row_error=norm((jets["combined"][2]-last_jets["combined"][2])*operator.scale)/(hubble**2*coefficient_scale))
                    refinements.append(refine)
                rows.append(row)
                for name,state in states.items():
                    packets[name+"_initial_"+str(divisions)] = state
                for name,response in responses.items():
                    packets[name+"_row_"+str(divisions)] = np.asarray(response, dtype=complex if np.iscomplexobj(response) else float)
                last_states, last_jets = states, jets
                print(json.dumps(row), flush=True)
            packets["normalization"] = operator.scale
            np.savez_compressed(ROOT/"preparations.npz", **packets)
            passed = all(prep["passed"] for row in rows for prep in row["preparations"].values())
            passed = passed and max(refinements[-1]["state_errors"].values())<=GATE and refinements[-1]["first_row_error"]<=GATE and refinements[-1]["second_row_error"]<=GATE
            report = dict(passed=passed, rows=rows, refinements=refinements, gate=GATE, algebra_gate=ALGEBRA,
                          numerical_operator_derivatives=True, supplied_future_perturbation_state_used=False,
                          conditional_initial_state_not_formation_law=True, code_sha256=digest(__file__), operators_sha256=digest(ROOT/"operators.py"))
            write("preparation-result.json", report)
            print(json.dumps(dict(passed=passed, refinements=refinements)), flush=True)
            require(passed, "live-preparation derivative/refinement gates")
        finally:
            operator.close()


if __name__ == "__main__":
    main()
