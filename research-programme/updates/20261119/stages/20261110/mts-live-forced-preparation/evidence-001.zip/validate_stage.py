from common import *
import numpy as np


def exited(identity):
    try:
        process = psutil.Process(identity["pid"])
        created, command = process.create_time(), process.cmdline()
    except psutil.NoSuchProcess:
        return dict(exited=True, reason="PID absent")
    same = abs(created-identity["created"]) < .01 and command == identity["command"]
    return dict(exited=not same, reason="original identity live" if same else "PID reused; not touched", observed_creation=created, observed_command=command)


def main():
    with worker("validation"):
        checks = []

        def check(name, condition, **details):
            checks.append(dict(name=name, passed=bool(condition), **details))

        frozen = preserved()
        check("inherited sources unchanged", frozen==read(ROOT/"frozen-inputs.json"), count=len(frozen))
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            check("compile "+path.name, True)
        check("no bytecode cache", not list(ROOT.rglob("__pycache__")))
        proof, preparation, controls, radiation, evolution = [read(ROOT/name) for name in ("proof.json", "preparation-result.json", "controls-result.json", "radiation-diagnosis.json", "evolution-result.json")]
        check("row and unrestricted metric identities", proof["passed"] and len(proof["identities"])==4)
        check("live preparation passes unchanged gates", preparation["passed"] and preparation["gate"]==GATE and preparation["algebra_gate"]==ALGEBRA)
        check("radiation derivation and measurement", radiation["passed"] and len(radiation["exact_identities"])==3)
        check("numerical evolution verified", evolution["numerical_passed"])
        check("conservation failure not hidden", not controls["all_metric_gates_passed"] and not evolution["conservation_passed"])
        check("full off-shell identity retained", controls["all_identity_gates_passed"])
        check("no repair silently applied", not radiation["source_repair_applied"])
        check("no future trajectories used for preparation", not preparation["supplied_future_perturbation_state_used"])
        readout = read(ROOT/"physical-readout.json")
        check("readout source hash", readout["code_sha256"]==digest(ROOT/"physical_readout.py"))
        check("physical readout scope and coverage", len(readout["rows"])==6 and readout["pressure_normalized_by_energy_not_pressure"])
        for report, script in ((proof, "prove_rows.py"), (preparation, "check_preparation.py"), (controls, "check_controls.py"), (radiation, "diagnose_radiation.py"), (evolution, "evolve_preparations.py")):
            check("source hash "+script, report["code_sha256"]==digest(ROOT/script))
            if "operators_sha256" in report:
                check("operator hash for "+script, report["operators_sha256"]==digest(ROOT/"operators.py"))
        for model in ("native_heavy", "native_cold", "canonical"):
            entries = [row for row in controls["reports"] if row["model"]==model]
            check("paired endpoint/stencil coverage "+model, len(entries)==6 and {row["endpoint"] for row in entries}=={0, 1} and {row["divisions"] for row in entries}=={4, 8, 16})
            check("honest physical gate "+model, all(row["physics_gate_passed"]==(row["residuals"]["metric_error"]<=GATE) for row in entries))
        ablations = []
        for row in radiation["reports"]:
            for species, values in row["species"].items():
                components = values["components"]
                denominator = max(max(abs(value) for value in components.values()), 1e-100)
                full_error = abs(sum(components.values())-values["measured"])/denominator
                omitted_error = abs(sum(value for name,value in components.items() if name!="omitted_heavy")-values["measured"])/denominator
                check("source identity "+row["model"]+str(row["endpoint"])+str(row["divisions"])+species, full_error<=GATE)
                if row["model"]!="native_cold":
                    check("algebraic omitted-heavy ablation "+row["model"]+str(row["endpoint"])+str(row["divisions"])+species, omitted_error>.99)
                else:
                    check("cold heavy source absent "+str(row["endpoint"])+str(row["divisions"])+species, components["omitted_heavy"]==0)
                ablations.append(dict(model=row["model"], endpoint=row["endpoint"], divisions=row["divisions"], species=species, full_error=full_error, omitted_heavy_error=omitted_error))
        with np.load(ROOT/"preparations.npz") as packet:
            scale = packet["normalization"].copy()
            check("95-state preparation packets", scale.shape==(95,) and np.all(scale>0))
            for label in ("D0", "D01"):
                previous = None
                for steps in (128, 256):
                    path = ROOT/(label+"-"+str(steps)+".npz")
                    with np.load(path) as evolved:
                        check("same initial preparation "+label+str(steps), np.array_equal(evolved["initial"], packet[label+"_initial_16"]))
                        check("same normalization "+label+str(steps), np.array_equal(evolved["normalization"], scale))
                        final = evolved["final"].copy()
                    if previous is not None:
                        difference = float(np.max(abs(final-previous)/scale))
                        saved = read(ROOT/(label+"-"+str(steps)+".json"))["refinement"]
                        check("recomputed evolution refinement "+label, difference==saved and difference<=GATE)
                    previous = final
        hashes = {}
        for path in sorted(ROOT.glob("*.npz")):
            with np.load(path) as packet:
                check("finite readable packet "+path.name, all(np.all(np.isfinite(packet[name])) for name in packet.files))
            hashes[path.name] = digest(path)
        identities = []
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name=="validation-start.json":
                continue
            identity = read(path)
            status = exited(identity)
            ending = ROOT/path.name.replace("-start.json", "-end.json")
            check("worker exited "+path.name, status["exited"] and ending.exists())
            identities.append(dict(receipt=path.name, identity=identity, status=status))
        report = dict(passed=all(row["passed"] for row in checks), checks=checks, input_count=len(frozen), workers=identities, packet_hashes=hashes,
                      ablations=ablations, ablation_scope="algebraic prediction of the measured residual; not a repaired forward evolution",
                      scientific_outcome="conditional preparation derived and evolved; retained radiation omission identified; conservation gate explicitly failed")
        write("validation.json", report)
        require(report["passed"], "implementation/provenance validation")
        print(json.dumps(dict(passed=report["passed"], checks=len(checks), inputs=len(frozen), workers=len(identities))))


if __name__ == "__main__":
    main()
