from common import *
from bridge_imports import NativePort, CanonicalBlock, action_model
import numpy as np


def norm(value):
    return float(np.max(abs(value)))


def relative(residual, terms):
    return norm(residual) / max(*(norm(term) for term in terms), 1e-100)


class Operators:
    def __init__(self, label, canonical=False):
        self.port = NativePort(label)
        self.block = CanonicalBlock(self.port) if canonical else None
        self.cache = {}
        self.span = float(self.port.times[-1] - self.port.times[0])
        if canonical:
            with np.load(PREVIOUS / "canonical-initial.npz") as packet:
                self.scale = packet["normalization"].copy()
        else:
            self.scale = self.port.scale.copy()

    def sample(self, fraction):
        guard()
        require(0 <= fraction <= 1, "inside retained native regime")
        if fraction in self.cache:
            return self.cache[fraction]
        port = self.port
        stamp = float(port.times[0] + fraction * self.span)
        if fraction == 1:
            stamp = float(port.times[-1])
        if self.block is not None:
            bridge = self.block.system(stamp)
            matrix = bridge["matrix"]
            observer, background, mapping = bridge["observer"], bridge["background"], bridge["mapping"]
            hubble = bridge["hubble"]
            potential, lapse, alpha = bridge["potential"], bridge["lapse"], bridge["alpha"]
            native_enthalpy = background[port.columns["R"]] + background[port.columns["Pbar"]]
            enthalpy = native_enthalpy - bridge["native_rho"] + bridge["enthalpy"]
            heavy_density = bridge["rho"] * bridge["density"]
            heavy_current = bridge["rho"] * bridge["current"]
            heavy_pressure = bridge["rho"] * bridge["pressure"]
            heavy_enthalpy = bridge["enthalpy"]
        else:
            background, observer = port.observer_matrix(stamp)
            matrix = port.matrix(stamp)
            mapping = np.eye(port.dimension)
            hubble = background[port.columns["H_native"]]
            enthalpy = background[port.columns["R"]] + background[port.columns["Pbar"]]
            potential = -(observer[port.columns["D_sync"]] + 3*hubble*observer[port.columns["Q_sync"]]/port.wave)/(2*port.wave**2)
            lapse = potential-observer[port.columns["Pi"]]/port.wave**2
            alpha = observer[port.columns["sigma"]]/port.wave
            heavy_density = heavy_current = heavy_pressure = np.zeros(port.dimension)
            heavy_enthalpy = 0.
        density = observer[port.columns["D_sync"]] @ mapping - 3*hubble*enthalpy*alpha
        current = observer[port.columns["Q_sync"]] @ mapping + enthalpy*port.wave*alpha
        anisotropy = observer[port.columns["Pi"]] @ mapping
        result = dict(matrix=matrix, phi=potential, psi=lapse, combined=3*potential+lapse,
                      density=density, current=current, anisotropy=anisotropy, hubble=np.array(hubble),
                      enthalpy=np.array(enthalpy), heavy_density=heavy_density, heavy_current=heavy_current,
                      heavy_pressure=heavy_pressure, heavy_enthalpy=np.array(heavy_enthalpy),
                      scale_factor=np.array(background[port.columns["a_native"]]))
        self.cache[fraction] = result
        return result

    def jets(self, endpoint, divisions):
        require(endpoint in (0, 1), "endpoint stencil")
        direction = 1 if endpoint == 0 else -1
        samples = [self.sample(endpoint+direction*index/divisions) for index in range(5)]
        spacing = np.longdouble(direction*self.span/divisions)
        first_weights = np.array([-25, 48, -36, 16, -3], dtype=np.longdouble)/12
        second_weights = np.array([35, -104, 114, -56, 11], dtype=np.longdouble)/12
        result = {}
        for name in samples[0]:
            values = np.stack([sample[name] for sample in samples]).astype(np.longdouble)
            shifted = values-values[0]
            first = np.tensordot(first_weights, shifted, axes=(0, 0))/spacing
            second = np.tensordot(second_weights, shifted, axes=(0, 0))/spacing**2
            result[name] = (values[0], first, second)
        return result

    def scalar_jets(self):
        require(self.block is not None, "canonical scalar only")
        scale_factor = float(self.sample(0)["scale_factor"])
        mass, hubble = action_model.background_series(self.block.case, float(np.log(scale_factor)+np.log(11.)))
        pressure = -2*hubble*hubble.derivative()-hubble**2
        gradient = action_model.Series(self.block.case.wave**2)/mass**2
        ratio = (1+gradient).sqrt()
        carrier = mass+3*pressure/(8*mass)
        beat = mass*gradient/(ratio+1)*(1-pressure/mass**2*(3*ratio**2+ratio+1)/(8*ratio**3)-hubble**2/mass**2*(ratio+1)*(2*ratio**2+5)/(8*ratio**5))
        sideband = carrier+beat
        slope0 = -hubble*carrier.derivative()/(2*carrier)
        slopek = -hubble*sideband.derivative()/(2*sideband)
        physical = slope0-hubble-1j*carrier
        rate = slope0+slopek-1j*(carrier+sideband)
        values = self.block.coefficients(scale_factor)
        require(abs(complex(physical.value[0])-values["physical0"]) < ALGEBRA, "same scalar coefficient")
        return dict(physical=complex(physical.value[0]), physical_prime=complex((hubble*physical.derivative()).value[0]),
                    rate=complex(rate.value[0]), rate_prime=complex((hubble*rate.derivative()).value[0]),
                    mass2=float((mass**2).value[0]), mass2_prime=float((2*hubble*mass**2).value[0]))

    def close(self):
        self.port.close()


def preparation(operator, jets):
    scalar = operator.scalar_jets()
    matrix, matrix_prime, unused = jets["matrix"]
    combined, combined_partial, combined_second = jets["combined"]
    lapse, lapse_partial, unused = jets["psi"]
    first = combined_partial+combined@matrix
    second = combined_second+2*combined_partial@matrix+combined@matrix_prime+(combined@matrix)@matrix
    lapse_total = lapse_partial+lapse@matrix
    leading = (scalar["physical"]*first-2*scalar["mass2"]*lapse)/scalar["rate"]
    leading_total = (scalar["physical_prime"]*first+scalar["physical"]*second-2*scalar["mass2_prime"]*lapse-2*scalar["mass2"]*lapse_total)/scalar["rate"]-scalar["rate_prime"]*leading/scalar["rate"]
    correction = -leading_total/scalar["rate"]
    port = operator.port
    observed = port.observe(port.times[0], port.initial)
    initial_alpha = observed[port.columns["sigma"]]/port.wave
    initial_hubble = observed[port.columns["H_native"]]
    physical_targets = [port.initial[port.selected[0]]-3*initial_hubble*initial_alpha,
                        port.initial[port.selected[1]]+port.wave*initial_alpha]
    initial_bridge = operator.block.system(port.times[0])
    states, reports, rows = {}, {}, {}
    for label, response in (("D0", leading), ("D01", leading+correction)):
        condition = scalar["physical"]*combined-response
        condition = condition.astype(np.clongdouble)
        condition[-2] += 1
        condition[-1] += 1j
        constraints = np.array([initial_bridge["density"], initial_bridge["current"], condition.real, condition.imag], dtype=np.longdouble)
        target = np.array(physical_targets+[0., 0.], dtype=np.longdouble)
        initial = np.r_[port.initial[port.remaining], np.zeros(4)]
        right = target-constraints@initial
        row_scale = np.max(abs(constraints[:, -4:]), axis=1)
        require(np.all(row_scale>0), "nonzero preparation rows")
        linear = np.asarray(constraints[:, -4:]/row_scale[:, None], dtype=float)
        initial[-4:] = np.linalg.solve(linear, np.asarray(right/row_scale, dtype=float))
        residual = constraints@initial-target
        denominator = np.maximum(np.sum(abs(constraints*initial[None, :]), axis=1), abs(target))
        residual_error = float(np.max(abs(residual)/np.maximum(denominator, np.longdouble(1e-100))))
        states[label] = initial
        rows[label] = np.asarray(condition, dtype=complex)
        reports[label] = dict(condition_number=float(np.linalg.cond(linear)), residual=residual.astype(float).tolist(),
                              residual_error=residual_error, passed=residual_error<=ALGEBRA,
                              leading_on_state=[float((leading@initial).real), float((leading@initial).imag)],
                              correction_on_state=[float((correction@initial).real), float((correction@initial).imag)],
                              correction_ratio=float(abs(correction@initial)/max(abs(leading@initial), 1e-100)))
    return states, reports, dict(first=first, second=second, leading=leading, correction=correction, **rows)


def defects(operator, jets, state):
    state = state.astype(np.longdouble)
    derivative = jets["matrix"][0]@state
    value = lambda name: jets[name][0]@state
    rate = lambda name: jets[name][1]@state+jets[name][0]@derivative
    wave = operator.port.wave
    hubble, hubble_prime = jets["hubble"][:2]
    enthalpy = jets["enthalpy"][0]
    potential, lapse = value("phi"), value("psi")
    density, current, anisotropy = [value(name) for name in ("density", "current", "anisotropy")]
    potential_prime, density_prime, current_prime = [rate(name) for name in ("phi", "density", "current")]
    metric = potential_prime+hubble*lapse-current/(2*wave)
    background = hubble_prime-hubble**2+enthalpy/2
    constraint = 2*wave**2*potential+density+3*hubble*current/wave
    constraint_prime = 2*wave**2*potential_prime+density_prime+3*(hubble_prime*current+hubble*current_prime)/wave
    terms = np.array([density_prime, hubble*density, wave*current, -3*enthalpy*potential_prime,
                      3*hubble*current_prime/wave, 6*hubble**2*current/wave, -3*hubble*enthalpy*lapse,
                      2*hubble*anisotropy, 3*background*current/wave], dtype=np.longdouble)
    budget = np.sum(terms)
    law_residual = constraint_prime+hubble*constraint-budget-(2*wave**2+3*enthalpy)*metric
    report = dict(metric_residual=float(metric), metric_error=relative(metric, [potential_prime, hubble*lapse, current/(2*wave)]),
                  constraint_error=relative(constraint, [2*wave**2*potential, density, 3*hubble*current/wave]),
                  background_residual=float(background), background_error=relative(background, [hubble_prime, hubble**2, enthalpy/2]),
                  total_budget=float(budget), identity_error=relative(law_residual, terms),
                  independently_differentiated_metric=True)
    if operator.block is not None:
        heavy_density, heavy_current, heavy_pressure = [value(name) for name in ("heavy_density", "heavy_current", "heavy_pressure")]
        heavy_enthalpy = jets["heavy_enthalpy"][0]
        density_terms = [rate("heavy_density"), hubble*(heavy_density+3*heavy_pressure), wave*heavy_current, -3*heavy_enthalpy*potential_prime]
        current_terms = [rate("heavy_current"), 2*hubble*heavy_current, -wave*heavy_pressure, -wave*heavy_enthalpy*lapse]
        energy_error, momentum_error = np.sum(density_terms), np.sum(current_terms)
        heavy_budget = energy_error+3*hubble*momentum_error/wave
        report.update(heavy_energy_residual=float(energy_error), heavy_energy_error=relative(energy_error, density_terms),
                      heavy_current_residual=float(momentum_error), heavy_current_error=relative(momentum_error, current_terms),
                      heavy_budget=float(heavy_budget), rest_plus_background_budget=float(budget-heavy_budget))
    return report
