from common import *
from check_controls import RadiationOperators, radiation_budget
from operators import defects, norm
from bridge_imports import evolve_exponential
import numpy as np


def main():
    with worker("evolution"):
        require(read(ROOT/"preparation-result.json")["passed"], "live preparation gate")
        require(read(ROOT/"radiation-diagnosis.json")["passed"], "identified retained approximation defect")
        operator = RadiationOperators("heavy", canonical=True)
        try:
            with np.load(ROOT/"preparations.npz") as packet:
                states = {name:packet[name+"_initial_16"].copy() for name in ("D0", "D01")}
                scale = packet["normalization"].copy()
            with np.load(PREVIOUS/"canonical-256.npz") as packet:
                prior_final = packet["final"].copy()
            with np.load(PREVIOUS/"canonical-initial.npz") as packet:
                prior_initial = packet["initial"].copy()
            final_jets = operator.jets(1, 16)
            reports, final_states = [], {}
            for label, initial in states.items():
                previous = None
                for steps in (128, 256):
                    final = evolve_exponential(lambda stamp: operator.block.system(stamp)["matrix"], initial, operator.port.times, steps, scale)
                    refinement = None if previous is None else norm((final-previous)/scale)
                    residuals = defects(operator, final_jets, final)
                    radiation = radiation_budget(operator, final_jets, final)
                    row = dict(preparation=label, steps=steps, refinement=refinement,
                               initial_change_from_native_metric_D0=norm((initial-prior_initial)/scale),
                               final_change_from_native_metric_D0=norm((final-prior_final)/scale),
                               defects=residuals, radiation=radiation, metric_gate_passed=residuals["metric_error"]<=GATE,
                               physical_failure_remains_explicit=True)
                    np.savez_compressed(ROOT/(label+"-"+str(steps)+".npz"), initial=initial, final=final, normalization=scale, times=operator.port.times)
                    write(label+"-"+str(steps)+".json", row)
                    reports.append(row)
                    previous = final
                    print(json.dumps(row), flush=True)
                final_states[label] = previous
            result = dict(numerical_passed=all(row["refinement"]<=GATE for row in reports if row["refinement"] is not None),
                          conservation_passed=all(row["metric_gate_passed"] for row in reports), reports=reports,
                          D01_vs_D0_final=norm((final_states["D01"]-final_states["D0"])/scale),
                          unchanged_cold_control="controls-result.json: independently differentiated native_cold endpoints",
                          code_sha256=digest(__file__), operators_sha256=digest(ROOT/"operators.py"),
                          scope="conditional preparation comparison using unchanged RHS; known omitted-source defect not repaired here")
            write("evolution-result.json", result)
            require(result["numerical_passed"], "paired new preparation integration refinement")
        finally:
            operator.close()


if __name__ == "__main__":
    main()
