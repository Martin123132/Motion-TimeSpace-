import os
import sys
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / "mts-gauge-source-bridge-20261110"
PORT = POST / "mts-late-hierarchy-port-20261110"
ACTION = POST / "mts-metric-reduced-action-20261110"
CLOSURE = POST / "mts-canonical-metric-closure-20261110"
BRANCH = POST / "condensate-origin-20261003"
NATIVE = BRANCH / "native-heavy-matching-20261007/native"
START = time.monotonic()
ALGEBRA, GATE = 1e-10, 2e-5


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(name, value):
    encoded = json.dumps(value, indent=2, allow_nan=False)
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        stream.write(encoded)


def guard():
    require(time.monotonic() - START < 900, "bounded worker deadline")
    for directory in (ROOT, POST, PREVIOUS, PORT):
        require(not (directory / "STOP-REQUESTED").exists(), "owner hold: " + str(directory))


@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())
    write(name + "-start.json", identity)
    try:
        guard()
        yield
    except BaseException as error:
        write(name + "-end.json", dict(**identity, state="failed", error=repr(error)))
        raise
    else:
        write(name + "-end.json", dict(**identity, state="completed", elapsed=time.monotonic() - START))


def preserved():
    expected = "b38c7a30eca992eab70d20d86c2579d5a19fbac7b83a1381065ddaecd8a18588"
    require(digest(PREVIOUS / "closeout.json") == expected, "previous seal")
    seal = read(PREVIOUS / "closeout.json")
    result = dict(seal["input_hashes"])
    result[str(PREVIOUS / "closeout.json")] = expected
    result.update({str(PREVIOUS / name): row["sha256"] for name, row in seal["artifacts"].items()})
    result[str(PREVIOUS / "CLEANUP-VERIFIED.json")] = digest(PREVIOUS / "CLEANUP-VERIFIED.json")
    for path, checksum in result.items():
        guard()
        require(digest(path) == checksum, "changed retained input: " + path)
    return result
