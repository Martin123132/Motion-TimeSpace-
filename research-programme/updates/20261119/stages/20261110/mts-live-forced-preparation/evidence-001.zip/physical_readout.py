from common import *
from operators import Operators
import numpy as np


def main():
    with worker("readout"):
        require(read(ROOT/"evolution-result.json")["numerical_passed"], "completed paired evolution")
        operator = Operators("heavy", canonical=True)
        try:
            packets, reports = {}, []
            for endpoint in (0, 1):
                bridge = operator.block.system(operator.port.times[endpoint])
                matrix = np.array([bridge[name] for name in ("density", "current", "pressure", "potential", "lapse")], dtype=np.longdouble)
                if endpoint == 0:
                    with np.load(PREVIOUS/"canonical-initial.npz") as packet:
                        reference_state = packet["initial"].copy()
                else:
                    with np.load(PREVIOUS/"canonical-256.npz") as packet:
                        reference_state = packet["final"].copy()
                reference = matrix@reference_state
                scales = np.maximum(abs(reference), np.longdouble(1e-100))
                scales[2] = scales[0]
                values = {}
                for label in ("D0", "D01"):
                    with np.load(ROOT/(label+"-256.npz")) as packet:
                        state = packet["initial" if endpoint==0 else "final"].copy()
                    physical = matrix@state
                    values[label] = physical
                    reports.append(dict(endpoint=endpoint, preparation=label, values=physical.astype(float).tolist(),
                                        absolute_change_from_prior=(physical-reference).astype(float).tolist(),
                                        scaled_change_from_prior=(abs(physical-reference)/scales).astype(float).tolist()))
                reports.append(dict(endpoint=endpoint, comparison="D01 versus D0", absolute_change=(values["D01"]-values["D0"]).astype(float).tolist(),
                                    scaled_change=(abs(values["D01"]-values["D0"])/scales).astype(float).tolist()))
                packets["source_matrix_"+str(endpoint)] = matrix.astype(float)
                packets["reference_"+str(endpoint)] = reference.astype(float)
                packets["normalization_"+str(endpoint)] = scales.astype(float)
            np.savez_compressed(ROOT/"physical-readout.npz", **packets)
            write("physical-readout.json", dict(rows=reports, columns=["density/Rh", "current/Rh", "pressure/Rh", "Phi", "Psi"],
                  pressure_normalized_by_energy_not_pressure=True,
                  qualification="conditional state/preparation comparison, not numerical error on every observable or observational fit",
                  code_sha256=digest(__file__)))
            print(json.dumps(reports[-1]), flush=True)
        finally:
            operator.close()


if __name__ == "__main__":
    main()
