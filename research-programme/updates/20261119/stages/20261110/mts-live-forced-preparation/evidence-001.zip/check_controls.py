from common import *
from operators import Operators, defects, relative
import numpy as np


class RadiationOperators(Operators):
    def sample(self, fraction):
        result = super().sample(fraction)
        if "gamma_density" in result:
            return result
        port = self.port
        require(np.array_equal(port.reference["signature"][[13, 14]], [1, 1]), "both retained radiation-streaming approximations active")
        stamp = float(port.times[0]+fraction*self.span)
        if fraction == 1:
            stamp = float(port.times[-1])
        if self.block is not None:
            bridge = self.block.system(stamp)
            observer, background, mapping = bridge["observer"], bridge["background"], bridge["mapping"]
            alpha = bridge["alpha"]
        else:
            background, observer = port.observer_matrix(stamp)
            mapping = np.eye(port.dimension)
            alpha = observer[port.columns["sigma"]]/port.wave
        hubble = float(result["hubble"])
        for species in ("gamma", "massless"):
            rho = background[port.columns["R_"+species]]
            density_sync = observer[port.columns["delta_"+species+"64"]] @ mapping
            current_sync = observer[port.columns["q_"+species+"64"]] @ mapping
            result[species+"_density"] = rho*(density_sync-4*hubble*alpha)
            result[species+"_current"] = rho*(current_sync+4*port.wave*alpha/3)
            result[species+"_enthalpy"] = np.array(4*rho/3)
        baryon_velocity = observer[port.columns["v_baryon64"]]@mapping
        baryon_pressure = observer[port.columns["delta_p_b"]]@mapping
        baryon_rho = background[port.columns["R_baryon"]]
        result["gamma_drag"] = -baryon_rho*(baryon_velocity@result["matrix"]+hubble*baryon_velocity-port.wave*baryon_pressure)
        return result


def radiation_budget(operator, jets, state):
    state = state.astype(np.longdouble)
    derivative = jets["matrix"][0]@state
    value = lambda name: jets[name][0]@state
    rate = lambda name: jets[name][1]@state+jets[name][0]@derivative
    hubble, wave = jets["hubble"][0], operator.port.wave
    phi_prime, lapse = rate("phi"), value("psi")
    rows, total = {}, np.longdouble(0)
    for species in ("gamma", "massless"):
        density, current = value(species+"_density"), value(species+"_current")
        enthalpy = jets[species+"_enthalpy"][0]
        exchange = value("gamma_drag") if species == "gamma" else np.longdouble(0)
        energy_terms = [rate(species+"_density"), 2*hubble*density, wave*current, -3*enthalpy*phi_prime]
        current_terms = [rate(species+"_current"), 2*hubble*current, -wave*(density/3+enthalpy*lapse), -exchange]
        energy, momentum = np.sum(energy_terms), np.sum(current_terms)
        contribution = energy+3*hubble*momentum/wave
        rows[species] = dict(energy_residual=float(energy), current_residual_after_Thomson_exchange=float(momentum),
                            energy_error=relative(energy, energy_terms), current_error=relative(momentum, current_terms),
                            budget=float(contribution))
        total += contribution
    return dict(species=rows, combined=float(total), treatment="zero radiation anisotropy follows retained RSA flags; photon Thomson momentum exchange subtracted using baryon RHS")


def main():
    with worker("controls"):
        require(read(ROOT/"preparation-result.json")["passed"], "preparation derivative gate")
        reports = []
        for label, canonical in (("heavy", False), ("cold", False), ("heavy", True)):
            operator = RadiationOperators(label, canonical)
            try:
                if canonical:
                    with np.load(ROOT/"preparations.npz") as packet:
                        first = packet["D0_initial_16"].copy()
                    with np.load(PREVIOUS/"canonical-256.npz") as packet:
                        last = packet["final"].copy()
                    tag = "canonical"
                else:
                    first = operator.port.initial
                    with np.load(operator.port.owner/"precision.npz") as packet:
                        last = packet["state"][-1].copy()
                    tag = "native_"+label
                for endpoint,state in ((0, first), (1, last)):
                    for divisions in (4, 8, 16):
                        jets = operator.jets(endpoint, divisions)
                        residuals = defects(operator, jets, state)
                        radiation = radiation_budget(operator, jets, state)
                        row = dict(model=tag, endpoint=endpoint, divisions=divisions, residuals=residuals, radiation=radiation,
                                   nonradiation_budget_remainder=residuals["total_budget"]-radiation["combined"],
                                   physics_gate_passed=residuals["metric_error"]<=GATE,
                                   identity_gate_passed=residuals["identity_error"]<=ALGEBRA,
                                   state_scope="new live D0 initial; saved prior conditional endpoint, not its new evolution" if canonical else "unchanged independently evolved native control")
                        reports.append(row)
                    print(json.dumps(reports[-1]), flush=True)
                np.savez_compressed(ROOT/(tag+"-control-states.npz"), initial=first, final=last, normalization=operator.scale)
            finally:
                operator.close()
        result = dict(completed=True, all_metric_gates_passed=all(row["physics_gate_passed"] for row in reports),
                      all_identity_gates_passed=all(row["identity_gate_passed"] for row in reports), reports=reports,
                      code_sha256=digest(__file__), operators_sha256=digest(ROOT/"operators.py"),
                      physics_failure_is_retained_not_promoted=True)
        write("controls-result.json", result)
        require(result["all_identity_gates_passed"], "off-shell algebraic identity")


if __name__ == "__main__":
    main()
