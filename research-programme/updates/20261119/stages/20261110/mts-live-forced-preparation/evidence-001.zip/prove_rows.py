from common import *
import sympy as sym


def main():
    with worker("proof"):
        stamp = sym.symbols("stamp", real=True)
        state = sym.Matrix([sym.Function("y" + str(index))(stamp) for index in range(2)])
        matrix = sym.Matrix(2, 2, lambda row, column: sym.Function("a" + str(row) + str(column))(stamp))
        row = sym.Matrix([[sym.Function("c" + str(index))(stamp) for index in range(2)]])
        rates = {sym.diff(state[index], stamp): (matrix * state)[index] for index in range(2)}
        first = sym.diff((row * state)[0], stamp).subs(rates)
        second = sym.diff(first, stamp).subs(rates)
        checks = dict(row_first=first-((row.diff(stamp)+row*matrix)*state)[0],
                      row_second=second-((row.diff(stamp, 2)+2*row.diff(stamp)*matrix+row*matrix.diff(stamp)+row*matrix**2)*state)[0])
        density, pressure, current, hubble, enthalpy, wave, phi, anisotropy, error_d, error_q, error_h, error_phi = sym.symbols("density pressure current hubble enthalpy wave phi anisotropy error_d error_q error_h error_phi", real=True)
        lapse = phi-anisotropy/wave**2
        phi_rate = -hubble*lapse+current/(2*wave)+error_phi
        density_rate = -hubble*(density+3*pressure)-wave*current+3*enthalpy*phi_rate+error_d
        current_rate = -2*hubble*current+wave*(pressure+enthalpy*lapse-2*anisotropy/3)+error_q
        hubble_rate = hubble**2-enthalpy/2+error_h
        constraint = 2*wave**2*phi+density+3*hubble*current/wave
        constraint_rate = 2*wave**2*phi_rate+density_rate+3*(hubble_rate*current+hubble*current_rate)/wave
        checks["unrestricted_metric_defect_identity"] = constraint_rate+hubble*constraint-error_d-3*hubble*error_q/wave-3*error_h*current/wave-(2*wave**2+3*enthalpy)*error_phi
        combination = density_rate+hubble*density+wave*current-3*enthalpy*phi_rate+3*hubble*current_rate/wave+6*hubble**2*current/wave-3*hubble*enthalpy*lapse+2*hubble*anisotropy+3*error_h*current/wave
        checks["pressure_free_total_budget"] = combination-error_d-3*hubble*error_q/wave-3*error_h*current/wave
        for name, expression in checks.items():
            require(sym.simplify(expression)==0, name)
        write("proof.json", dict(passed=True, identities=list(checks), code_sha256=digest(__file__)))
        print("PASS", len(checks), "exact row/metric identities")


if __name__ == "__main__":
    main()
