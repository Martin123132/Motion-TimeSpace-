from common import *
from validate_stage import exited


def main():
    with worker("seal"):
        validation = read(ROOT/"validation.json")
        require(validation["passed"], "implementation validation")
        require(not read(ROOT/"evolution-result.json")["conservation_passed"], "retain known failed physical gate")
        inputs = preserved()
        require(inputs==read(ROOT/"frozen-inputs.json"), "unchanged frozen inputs")
        workers = []
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name=="seal-start.json":
                continue
            identity = read(path)
            status = exited(identity)
            require(status["exited"], "worker still live: "+path.name)
            workers.append(dict(receipt=path.name, identity=identity, status=status))
        require(not list(ROOT.rglob("__pycache__")), "no bytecode")
    artifacts = {}
    for path in sorted(ROOT.iterdir()):
        require(path.is_file() and path.name!="closeout.json", "unexpected artifact or reseal")
        artifacts[path.name] = dict(sha256=digest(path), bytes=path.stat().st_size)
    write("closeout.json", dict(state="verified_progress_with_identified_physical_failure", goal_complete=False,
          utc=datetime.now(timezone.utc).isoformat(), input_hashes=inputs, artifacts=artifacts, workers=workers,
          verified=["live conditional D0/D01 derivation", "paired preparation evolutions", "independent differentiated metric test", "omitted radiation source diagnosis"],
          failed=["retained heavy/canonical metric conservation gate"], source_repair_applied=False,
          qualification="A validated failure diagnosis is not a conservation pass. The correction is derived but still needs a consistent forward test.",
          next="NEXT.md", cleanup="Verify seal process exit and save CLEANUP-VERIFIED.json outside seal."))
    print(json.dumps(dict(seal_sha256=digest(ROOT/"closeout.json"), inputs=len(inputs), artifacts=len(artifacts), validation_checks=len(validation["checks"]))))


if __name__ == "__main__":
    main()
