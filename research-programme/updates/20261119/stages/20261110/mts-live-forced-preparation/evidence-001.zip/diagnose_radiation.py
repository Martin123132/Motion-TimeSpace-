from common import *
from check_controls import RadiationOperators, radiation_budget
from operators import defects, relative
import numpy as np
import sympy as sym


class SourceOperators(RadiationOperators):
    def sample(self, fraction):
        result = super().sample(fraction)
        if "omitted_heavy" in result:
            return result
        port = self.port
        stamp = float(port.times[0]+fraction*self.span)
        if fraction == 1:
            stamp = float(port.times[-1])
        if self.block is not None:
            bridge = self.block.system(stamp)
            observer, background, mapping = bridge["observer"], bridge["background"], bridge["mapping"]
            heavy_sync = bridge["rho"]*bridge["density_star"]+3*bridge["enthalpy"]*bridge["eta"]
        else:
            background, observer = port.observer_matrix(stamp)
            mapping = np.eye(port.dimension)
            heavy_sync = np.zeros(port.dimension)
            if port.label == "heavy":
                heavy_sync[port.selected[0]] = port.matching_density/background[port.columns["a_native"]]
        width = len(result["matrix"])
        matter = np.zeros(width)
        for species in ("cdm", "baryon", "massive"):
            matter += background[port.columns["R_"+species]]*(observer[port.columns["delta_"+species+"64"]]@mapping)
        radiation = np.zeros(width)
        for species in ("gamma", "massless"):
            rho = background[port.columns["R_"+species]]
            density_sync = observer[port.columns["delta_"+species+"64"]]@mapping
            result[species+"_sync_density"] = density_sync
            result[species+"_rho"] = np.array(rho)
            radiation += rho*density_sync
        total = observer[port.columns["D_sync"]]@mapping
        result["omitted_heavy"] = heavy_sync
        result["omitted_slow"] = total-matter-radiation-heavy_sync
        result["radiation_feedback"] = radiation
        return result


def prove():
    rho, hubble, hubble_prime, alpha, alpha_prime, eta_prime, delta, delta_prime, flux, wave, zfull, zmatter, dmissing = sym.symbols("rho hubble hubble_prime alpha alpha_prime eta_prime delta delta_prime flux wave zfull zmatter dmissing", real=True)
    density = rho*(delta-4*hubble*alpha)
    current = rho*(flux+4*wave*alpha/3)
    density_prime = -2*hubble*density+rho*(delta_prime-4*hubble_prime*alpha-4*hubble*alpha_prime)
    phi_prime = eta_prime-hubble_prime*alpha-hubble*alpha_prime
    error = density_prime+2*hubble*density+wave*current-4*rho*phi_prime
    transformed = error.subs(eta_prime, wave*(wave*alpha-zfull)/3)
    target = rho*(delta_prime+wave*flux+4*wave*zfull/3)
    require(sym.factor(transformed-target)==0, "radiation gauge defect identity")
    missing = target.subs(flux, -4*zmatter/3).subs(zfull, zmatter+dmissing/(2*wave*hubble))
    require(sym.factor(missing-rho*delta_prime-2*rho*dmissing/(3*hubble))==0, "omitted source identity")
    source, pressure = sym.symbols("source pressure", real=True)
    old_derivative = -hubble*zmatter
    extra_z = source/(2*wave*hubble)
    extra_derivative = -hubble*extra_z-(source+3*pressure)/(2*wave)
    require(sym.factor(-4*extra_derivative/wave-(4*source+6*pressure)/wave**2)==0, "leading stressed RSA density correction")
    return ["radiation_gauge_defect", "omitted_source_prediction", "leading_stressed_RSA_density_correction"]


def main():
    with worker("radiation-diagnosis"):
        identities = prove()
        require(read(ROOT/"controls-result.json")["all_identity_gates_passed"], "completed fair controls")
        reports, packets = [], {}
        for label, canonical in (("heavy", False), ("cold", False), ("heavy", True)):
            operator = SourceOperators(label, canonical)
            tag = "canonical" if canonical else "native_"+label
            try:
                with np.load(ROOT/(tag+"-control-states.npz")) as packet:
                    states = [packet["initial"].copy(), packet["final"].copy()]
                for endpoint, state in enumerate(states):
                    for divisions in (8, 16):
                        jets = operator.jets(endpoint, divisions)
                        derivative = jets["matrix"][0]@state
                        hubble = jets["hubble"][0]
                        actual = radiation_budget(operator, jets, state)
                        total = defects(operator, jets, state)
                        species_rows = {}
                        components = np.zeros(4, dtype=np.longdouble)
                        for species in ("gamma", "massless"):
                            rho = jets[species+"_rho"][0]
                            density_rate = jets[species+"_sync_density"][1]@state+jets[species+"_sync_density"][0]@derivative
                            terms = np.array([rho*density_rate]+[2*rho*(jets[name][0]@state)/(3*hubble) for name in ("omitted_heavy", "omitted_slow", "radiation_feedback")], dtype=np.longdouble)
                            predicted = np.sum(terms)
                            residual = np.longdouble(actual["species"][species]["energy_residual"])
                            error = relative(predicted-residual, terms)
                            species_rows[species] = dict(predicted=float(predicted), measured=float(residual), normalized_identity_error=error,
                                                        components=dict(zip(("source_history", "omitted_heavy", "omitted_slow", "radiation_feedback"), terms.astype(float).tolist())),
                                                        passed=error<=GATE)
                            components += terms
                        row = dict(model=tag, endpoint=endpoint, divisions=divisions, species=species_rows,
                                   combined_components=dict(zip(("source_history", "omitted_heavy", "omitted_slow", "radiation_feedback"), components.astype(float).tolist())),
                                   radiation_fraction_of_total_budget=actual["combined"]/total["total_budget"],
                                   heavy_source_fraction_of_radiation_energy=float(components[1]/sum(actual["species"][species]["energy_residual"] for species in ("gamma", "massless"))),
                                   metric_gate_passed=total["metric_error"]<=GATE)
                        reports.append(row)
                    print(json.dumps(row), flush=True)
                for fraction, sample in operator.cache.items():
                    for name in ("omitted_heavy", "omitted_slow", "radiation_feedback", "gamma_sync_density", "massless_sync_density"):
                        packets[tag+"_"+str(fraction)+"_"+name] = sample[name]
            finally:
                operator.close()
        np.savez_compressed(ROOT/"radiation-source-rows.npz", **packets)
        passed = all(species["passed"] for row in reports for species in row["species"].values())
        write("radiation-diagnosis.json", dict(passed=passed, exact_identities=identities, reports=reports, code_sha256=digest(__file__),
                                               source_repair_applied=False, measured_failure_not_a_conservation_pass=True))
        require(passed, "omitted-source algebra predicts measured radiation defects")


if __name__ == "__main__":
    main()
