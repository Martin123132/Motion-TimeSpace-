from mode_support import *
from mode_operator import ModeBoundary
import argparse
import numpy as np
from scipy.linalg import expm


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('iteration', type=int, choices=(0, 1, 2))
    parser.add_argument('steps', type=int, choices=(128, 256))
    parser.add_argument('--from-step', type=int, default=0)
    args = parser.parse_args()
    first = args.from_step
    require(0 <= first < args.steps and first % 32 == 0, 'bounded packet start')
    tag = f'{args.case}-i{args.iteration}-s{args.steps}'
    name = tag + f'-from{first:03d}'
    with worker(name):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'retained sources')
        require(read(ROOT / 'prepare-result.json')['passed'], 'prepared physical state')
        names = ['mode_support.py', 'mode_operator.py', 'run_mode.py', 'PROTOCOL.md', 'prepare-result.json', args.case + '-initial.npz']
        if args.iteration:
            names += [f'{args.case}-boundary{args.iteration}.npz', f'{args.case}-boundary{args.iteration}-result.json']
        frozen = {filename: digest(ROOT / filename) for filename in names}
        with np.load(ROOT / (args.case + '-initial.npz'), allow_pickle=False) as packet:
            initial, scale, times = np.r_[packet['initial'], 1.], np.r_[packet['normalization'], 1.], packet['times'].copy()
        previous = frozen[args.case + '-initial.npz']
        if first:
            receipt_path = ROOT / (tag + f'-chunk{first:03d}.json')
            receipt = read(receipt_path)
            require(receipt['frozen'] == frozen and receipt['last'] == first, 'same resume inputs')
            require(exited(read(ROOT / (receipt['worker'] + '-start.json')))['exited'], 'prior worker exited')
            require(read(ROOT / (receipt['worker'] + '-end.json'))['state'] == 'completed', 'no failed-run retry')
            require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'restart hash')
            with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
                initial = packet['states'][-1].copy()
            previous = digest(receipt_path)
        operator = ModeBoundary(args.case, args.iteration)
        try:
            require(np.array_equal(operator.port.times, times), 'same physical clock')
            boundaries = np.linspace(*times, args.steps + 1)
            lower, upper = (3 - 2 * np.sqrt(3.)) / 12, (3 + 2 * np.sqrt(3.)) / 12
            state, saved, begin_index = initial / scale, [initial.copy()], first
            for index in range(first, args.steps):
                guard()
                begin, end = boundaries[index:index + 2]
                interval = end - begin
                early = operator.matrix(begin + (.5 - np.sqrt(3.) / 6) * interval) * scale[None, :] / scale[:, None]
                late = operator.matrix(begin + (.5 + np.sqrt(3.) / 6) * interval) * scale[None, :] / scale[:, None]
                state = expm(interval * (lower * early + upper * late)) @ (expm(interval * (upper * early + lower * late)) @ state)
                require(np.all(np.isfinite(state)) and abs(state[-1] - 1) <= ALGEBRA, 'finite physical state and constant coordinate')
                saved.append(state * scale)
                if (index + 1) % 32 == 0:
                    packet_name = tag + f'-chunk{index + 1:03d}.npz'
                    require(not (ROOT / packet_name).exists(), 'no packet overwrite')
                    np.savez_compressed(ROOT / packet_name, states=np.array(saved), times=boundaries[begin_index:index + 2], normalization=scale)
                    receipt_name = tag + f'-chunk{index + 1:03d}.json'
                    write(receipt_name, dict(first=begin_index, last=index + 1, worker=name, previous_sha256=previous,
                          packet=packet_name, packet_sha256=digest(ROOT / packet_name), frozen=frozen))
                    previous = digest(ROOT / receipt_name)
                    begin_index, saved = index + 1, [state * scale]
                    print(json.dumps(dict(run=tag, completed=begin_index, target=args.steps, elapsed=time.monotonic() - START)), flush=True)
                    if time.monotonic() - START > 720:
                        break
            if begin_index == args.steps:
                saved = []
                previous = frozen[args.case + '-initial.npz']
                for last in range(32, args.steps + 1, 32):
                    receipt_path = ROOT / (tag + f'-chunk{last:03d}.json')
                    receipt = read(receipt_path)
                    require(receipt['previous_sha256'] == previous and receipt['frozen'] == frozen, 'linked mode packets')
                    require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'packet hash')
                    with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
                        values = packet['states'].copy()
                    if saved:
                        require(np.array_equal(saved[-1][-1], values[0]), 'continuous restart')
                    saved.append(values if last == 32 else values[1:])
                    previous = digest(receipt_path)
                require(not (ROOT / (tag + '.npz')).exists(), 'no trajectory overwrite')
                np.savez_compressed(ROOT / (tag + '.npz'), states=np.concatenate(saved), times=boundaries, normalization=scale)
                write(tag + '-result.json', dict(full_run=True, steps=args.steps, worker=name, frozen=frozen,
                      packet_sha256=digest(ROOT / (tag + '.npz')), terminal_receipt_sha256=previous))
            write(name + '-progress.json', dict(completed_through=begin_index, full_run=begin_index == args.steps))
        finally:
            operator.close()
    if begin_index != args.steps:
        sys.exit(3)


if __name__ == '__main__':
    main()
