import os
import sys
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[name] = '1'
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
WIDE = POST / 'mts-longer-coupled-window-20261110'
RAD = POST / 'mts-source-complete-radiation-20261110'
PORT = POST / 'mts-late-hierarchy-port-20261110'
EXPECTED = 'fcda9bd84bc56bcadea4a3657dd842033debfeaa488aa0b79e116259dd38a3c3'
GATE, ALGEBRA, SPAN, WAVE = 2e-5, 1e-10, .01, 1.
START = time.monotonic()
sys.path.insert(0, str(WIDE))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    with (ROOT / name).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False))


def guard():
    require(time.monotonic() - START < 900, 'bounded worker deadline')
    for directory in (ROOT, POST, WIDE, RAD, PORT):
        require(not (directory / 'STOP-REQUESTED').exists(), 'owner hold ' + str(directory))


@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())
    write(name + '-start.json', identity)
    try:
        guard()
        yield identity
    except BaseException as error:
        write(name + '-end.json', dict(**identity, state='failed', error=repr(error)))
        raise
    else:
        write(name + '-end.json', dict(**identity, state='completed', elapsed=time.monotonic() - START))


def exited(identity):
    try:
        process = psutil.Process(identity['pid'])
        same = abs(process.create_time() - identity['created']) < .01 and process.cmdline() == identity['command']
    except psutil.NoSuchProcess:
        return dict(exited=True, reason='PID absent')
    return dict(exited=not same, reason='original identity live' if same else 'PID reused; untouched')


def preserved():
    require(digest(WIDE / 'closeout.json') == EXPECTED, 'previous seal')
    seal = read(WIDE / 'closeout.json')
    result = dict(seal['input_hashes'])
    result[str(WIDE / 'closeout.json')] = EXPECTED
    result.update({str(WIDE / name): row['sha256'] for name, row in seal['artifacts'].items()})
    result[str(WIDE / 'CLEANUP-VERIFIED.json')] = digest(WIDE / 'CLEANUP-VERIFIED.json')
    for path, checksum in result.items():
        guard()
        require(digest(path) == checksum, 'changed source ' + path)
    return result
