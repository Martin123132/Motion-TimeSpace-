from mode_support import *
from mode_operator import ModeBoundary, trajectory, response17, reference
from shared_operator import defects
import argparse
import numpy as np


def conservative_rows(operator, stamp, matrix):
    context = operator.port.context(stamp)
    nodes, weights = operator.port.nodes.astype(np.longdouble), operator.port.weights.astype(np.longdouble)
    scale, hubble, wave = [np.longdouble(context[key]) for key in ('scale', 'hubble', 'wave')]
    speed = nodes / np.sqrt(nodes**2 + (scale * context['neutrino_mass'])**2)
    prefactor = context['neutrino_amplitude'] * weights / scale**2
    density, current, pressure, anisotropy = np.zeros((4, len(matrix)), dtype=np.longdouble)
    indices = 6 + 17 * np.arange(len(nodes))
    density[indices] = prefactor / speed
    current[indices + 1] = prefactor
    pressure[indices] = prefactor * speed / 3
    anisotropy[indices + 2] = prefactor * speed
    position = float(operator.port.position_spline(stamp - operator.port.times[0]))
    parts = operator.port.owner.parts(position, *operator.port.state_spline(position)[:2])
    enthalpy = np.longdouble(parts['neutrino']) + np.longdouble(parts['neutrino_pressure'])
    shared = 4 * np.sum(prefactor / speed) / 3
    energy = np.array([-hubble * (density + 3 * pressure), density @ matrix,
                       hubble * (density + 3 * pressure), wave * current, -enthalpy * matrix[1]])
    momentum = np.array([-2 * hubble * current, current @ matrix, 2 * hubble * current,
                         -wave * pressure, 2 * wave * anisotropy / 3])
    errors = [float(np.max(abs(np.sum(terms, axis=0)) / np.maximum(np.sum(abs(terms), axis=0), 1e-100)))
              for terms in (energy, momentum)]
    error_enthalpy = float(abs(enthalpy - shared) / abs(shared))
    return dict(energy_error=errors[0], current_error=errors[1], enthalpy_error=error_enthalpy,
                passed=max(*errors, error_enthalpy) <= ALGEBRA)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('iteration', type=int, choices=(1, 2))
    args = parser.parse_args()
    with worker(f'analyse-{args.case}-i{args.iteration}'):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'retained sources')
        operator = ModeBoundary(args.case, args.iteration)
        try:
            coarse, old_clock, scale = trajectory(args.case, args.iteration, 128)
            fine, clock, fine_scale = trajectory(args.case, args.iteration, 256)
            require(np.array_equal(scale, fine_scale), 'same state norm')
            state_error = float(np.max(abs(fine[::2] - coarse) / scale))
            positions = np.linspace(0., SPAN, 9)
            targets = operator.port.times[0] + operator.port.state_spline(positions)[:, 3]
            fractions = (targets - operator.port.times[0]) / operator.span
            fractions[0], fractions[-1] = 0., 1.
            aligned = []
            for states, times in ((coarse, old_clock), (fine, clock)):
                values = []
                for target in targets:
                    index = min(int(np.searchsorted(times, target, side='right')) - 1, len(times) - 1)
                    require(index >= 0, 'covered probe')
                    values.append(reference.analysis_module.advance(operator, states[index], times[index], target, scale))
                aligned.append(np.array(values))
            aligned_error = float(np.max(abs(aligned[0] - aligned[1]) / scale))
            fields = ['phi', 'psi', 'density', 'current', 'anisotropy'] + (['heavy_density', 'heavy_current', 'heavy_pressure'] if args.case == 'heavy' else [])
            readouts, earlier, diagnostics, conservation, source_order = [], [], [], [], []
            for index, fraction in enumerate(fractions):
                sample = operator.sample(float(fraction), keep_matrix=False)
                readouts.append({name: float(sample[name].astype(np.longdouble) @ aligned[1][index].astype(np.longdouble)) for name in fields})
                earlier.append({name: float(sample[name].astype(np.longdouble) @ aligned[0][index].astype(np.longdouble)) for name in fields})
                for divisions in (16, 32):
                    jets = reference.analysis_module.jets_inside(operator, float(fraction), divisions)
                    diagnostics.append(dict(fraction=float(fraction), divisions=divisions, metrics=defects(operator, jets, aligned[1][index])))
                    if divisions == 32:
                        state = aligned[1][index].astype(np.longdouble)
                        matrix = jets['matrix'][0].astype(np.longdouble)
                        rate = matrix @ state
                        source_order.append(dict(position=float(positions[index]), density=float(jets['missing_density'][0] @ state),
                            pressure=float(jets['missing_pressure'][0] @ state),
                            density_rate=float(jets['missing_density'][1] @ state + jets['missing_density'][0] @ rate),
                            pressure_rate=float(jets['missing_pressure'][1] @ state + jets['missing_pressure'][0] @ rate)))
                        conservation.append(conservative_rows(operator, float(operator.port.times[0] + fraction * operator.span), matrix))
            compare = reference.analysis_module.field_comparison
            source_steps = {name: compare(np.array([row[name] for row in earlier]), np.array([row[name] for row in readouts])) for name in fields}
            metric = reference.sample_metric(operator.core, fine[:, :-1], clock)
            exact, low = reference.respond(operator.core, clock, metric, targets, 64, 10, 1)
            quadrature, unused = reference.respond(operator.core, clock, metric, targets, 64, 6, 1)
            interpolation, unused = reference.respond(operator.core, clock, metric, targets, 64, 10, 2)
            momentum, unused = reference.respond(operator.core, clock, metric, targets, 128, 10, 1)
            actual = []
            nodes, weights = reference.rule(64)
            for stamp, state in zip(targets, aligned[1]):
                context = operator.port.context(float(stamp))
                speed = nodes / np.sqrt(nodes**2 + (context['scale'] * context['neutrino_mass'])**2)
                prefactor = context['neutrino_amplitude'] / context['scale']**2
                modes = state[6:6 + 64 * 17].reshape(64, 17)
                actual.append([np.sum(prefactor * weights * modes[:, 0] / speed), np.sum(prefactor * weights * modes[:, 1]),
                               np.sum(prefactor * weights * speed * modes[:, 2])])
            checks = {name: {field: compare(value[:, index], exact[:, index]) for index, field in enumerate(('density', 'current', 'anisotropy'))}
                      for name, value in (('characteristic', np.array(actual)), ('quadrature', quadrature),
                                          ('interpolation', interpolation), ('momentum', momentum))}
            final_boundary = response17(operator.core, clock, metric, clock, 10)
            supplied = np.array([operator.boundary(float(stamp)) for stamp in clock])
            fixed_point = compare(supplied, final_boundary)
            phase = reference.phase_control(operator.core, clock, 64)
            peak = max(abs(row['density']) for row in source_order)
            ordering = dict(source_peak_density=peak,
                density_rate_over_k_peak_density=max(abs(row['density_rate']) for row in source_order) / (WAVE * peak) if peak else None,
                pressure_over_peak_density=max(abs(row['pressure']) for row in source_order) / peak if peak else None,
                pressure_rate_over_k_peak_density=max(abs(row['pressure_rate']) for row in source_order) / (WAVE * peak) if peak else None)
            numerical = max(state_error, aligned_error) <= GATE and all(row['passed'] for row in source_steps.values())
            passed = numerical and fixed_point['passed'] and phase['passed'] and all(row['passed'] for group in checks.values() for row in group.values())
            passed = passed and all(row['metrics']['metric_error'] <= GATE and row['metrics']['identity_error'] <= ALGEBRA for row in diagnostics)
            passed = passed and all(row['passed'] for row in conservation)
            tag = f'{args.case}-i{args.iteration}-analysis'
            np.savez_compressed(ROOT / (tag + '.npz'), coarse=aligned[0], fine=aligned[1], target_times=targets,
                                metric=metric, times=clock, exact_moments=exact, actual_moments=np.array(actual),
                                final_boundary=final_boundary, supplied_boundary=supplied)
            report = dict(case=args.case, iteration=args.iteration, wave=WAVE, passed=passed, numerical_passed=numerical,
                          state_difference=state_error, aligned_difference=aligned_error, source_step_checks=source_steps,
                          positions=positions.tolist(), readouts=readouts, diagnostics=diagnostics, conservation=conservation,
                          checks=checks, fixed_point=fixed_point, phase=phase, source_order=source_order, ordering=ordering,
                          code_sha256=digest(__file__), model_sha256=digest(ROOT / 'mode_operator.py'),
                          packet_sha256=digest(ROOT / (tag + '.npz')))
            write(tag + '-result.json', report)
            print(json.dumps(dict(case=args.case, passed=passed, state_difference=state_error,
                 aligned_difference=aligned_error, source_step_maximum=max(row['relative_difference'] for row in source_steps.values()),
                 fixed_point=fixed_point, characteristic=checks['characteristic'], ordering=ordering,
                 metric_error=max(row['metrics']['metric_error'] for row in diagnostics))), flush=True)
        finally:
            operator.close()


if __name__ == '__main__':
    main()
