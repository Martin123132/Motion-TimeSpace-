from mode_support import *
import ast
import ctypes
import numpy as np


def main():
    with worker('preflight'):
        inputs = preserved()
        cleanup = read(WIDE / 'CLEANUP-VERIFIED.json')
        require(cleanup['passed'] and cleanup['seal_sha256'] == EXPECTED, 'verified previous cleanup')
        for row in cleanup['workers']:
            require(exited(row['identity'])['exited'], 'previous worker exited')
        require(exited(cleanup['verifier_identity'])['exited'], 'previous verifier exited')
        for case in ('cold', 'heavy'):
            require(read(WIDE / (case + '-refinement512-result.json'))['passed'], 'preceding paired physical pass')
        write('frozen-inputs.json', inputs)
        from wide_operator import action_model
        available = action_model.StableCase('heavy').wave
        require(np.any(available == WAVE), 'preselected mode belongs to retained family')
        build = RAD / 'build'
        require(digest(build / 'native/camb/cambdll.dll') == read(RAD / 'build-result.json')['dll_sha256'], 'retained isolated DLL')
        sys.path.insert(0, str(build / 'native'))
        import camb
        from camb.mts import MTSTwoField
        branch = POST / 'condensate-origin-20261003'
        sys.path.append(str(branch / 'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        source = branch / 'native-heavy-matching-20261007/matching_common.py'
        factory = next(node for node in ast.parse(source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(source), 'exec'), namespace)
        library = camb.baseconfig.camblib
        library.mts_capture_reset.argtypes = []
        library.mts_capture_reset.restype = None
        observer_dll = ctypes.CDLL(str(POST / 'mts-metric-feedback-20261107/observer.dll'))
        observer_function = ctypes.cast(observer_dll.source_func_, ctypes.c_void_p)
        reports = []
        for case in ('cold', 'heavy'):
            config = read(PORT / 'runs' / (case + '-v4') / 'config.json')
            with np.load(PORT / 'runs' / (case + '-v4') / 'capture.npz', allow_pickle=False) as packet:
                names = packet['observer_names'].tolist()
                original_signature = packet['signature'].copy()
            native = camb.get_background(namespace['params_for'](Path(config['table'])))
            try:
                positions = np.linspace(0., SPAN, 17)
                redshifts = 11 * np.exp(-positions) - 1
                times = np.ascontiguousarray(native.conformal_time(redshifts, tol=1e-10))
                thermal = native.get_background_redshift_evolution(redshifts, vars=['opacity', 'cs2b'])
                values = np.column_stack([thermal[name] for name in ('opacity', 'cs2b')])
                with np.load(WIDE / (case + '-thermal-regime.npz'), allow_pickle=False) as packet:
                    old_values = packet['values'][::40].copy()
                thermal_error = float(np.max(abs(values - old_values) / np.maximum(abs(old_values), 1e-100)))
                native.Params.Accuracy.IntTolBoost = 6
                native.Params.Accuracy.lAccuracyBoost = 4
                library.mts_capture_reset()
                for name in ('step', 'kind', 'count', 'tangent'):
                    ctypes.c_int.in_dll(library, 'mts_probe_' + name).value = 0
                for name, value in (('begin', 1), ('end', len(times)), ('q_index', 1)):
                    ctypes.c_int.in_dll(library, 'mts_capture_' + name).value = value
                modes = np.array([WAVE])
                columns = len(camb.model.evolve_names) + len(names)
                output = np.zeros((1, len(times), columns))
                code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(1)), modes,
                       ctypes.byref(ctypes.c_int(len(times))), times, ctypes.byref(ctypes.c_int(columns)), output,
                       ctypes.byref(ctypes.c_int(len(names))), ctypes.byref(observer_function))
                require(code == 0, 'independent mode native capture')
                signature = np.array(list((ctypes.c_int * 96).in_dll(library, 'mts_capture_signature')))
                snapshots = ctypes.c_int.in_dll(library, 'mts_capture_count').value
                supported = bool(np.array_equal(signature[[11, 13, 14, 16, 17, 18, 20, 30, 40, 70]], [0, 1, 1, 0, 0, 0, 1, 5, 16, 0])
                                 and np.all(signature[23:26] == 0))
                np.savez_compressed(ROOT / (case + '-mode-regime.npz'), times=times, positions=positions,
                                    observed=output, signature=signature, thermal=values)
                report = dict(case=case, wave=WAVE, snapshots=snapshots, supported=supported,
                              same_full_signature=bool(np.array_equal(signature, original_signature)), thermal_error=thermal_error,
                              passed=bool(supported and snapshots == 17 and thermal_error <= GATE),
                              packet_sha256=digest(ROOT / (case + '-mode-regime.npz')))
                reports.append(report)
                print(json.dumps(report), flush=True)
            finally:
                library.mts_capture_reset()
                del native
        result = dict(passed=all(row['passed'] for row in reports), reports=reports, retained_modes=available.tolist(),
                      code_sha256=digest(__file__), no_new_primordial_prediction=True, new_fitted_parameters=0,
                      signature_consistency_source=str(build / 'camb_python.f90'), signature_source_sha256=digest(build / 'camb_python.f90'))
        write('preflight-result.json', result)
        require(result['passed'], 'native mode regime gate')


if __name__ == '__main__':
    main()
