from mode_support import *
from mode_operator import trajectory, reference
import argparse
import csv
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('iteration', type=int, choices=(1, 2))
    args = parser.parse_args()
    with worker(f'validation-i{args.iteration}'):
        checks, reports, comparisons, matching = [], [], [], []

        def check(name, value):
            checks.append(dict(name=name, passed=bool(value)))

        check('inherited source preservation', preserved() == read(ROOT / 'frozen-inputs.json'))
        for filename, code in (('preflight-result.json', 'preflight.py'), ('prepare-result.json', 'prepare_mode.py')):
            result = read(ROOT / filename)
            check(filename, result['passed'] and result['code_sha256'] == digest(ROOT / code))
        for case in ('cold', 'heavy'):
            report = read(ROOT / f'{case}-i{args.iteration}-analysis-result.json')
            check(case + ' analysis code', report['code_sha256'] == digest(ROOT / 'analyse_mode.py'))
            check(case + ' analysis model', report['model_sha256'] == digest(ROOT / 'mode_operator.py'))
            check(case + ' analysis hash', report['packet_sha256'] == digest(ROOT / f'{case}-i{args.iteration}-analysis.npz'))
            check(case + ' fixed mode and nine probes', report['wave'] == WAVE and len(report['readouts']) == 9 and np.array_equal(report['positions'], np.linspace(0., SPAN, 9)))
            check(case + ' complete derivative controls', len(report['diagnostics']) == 18 and len(report['conservation']) == 9)
            fine, clock, scale = trajectory(case, args.iteration, 256)
            coarse, coarse_clock, coarse_scale = trajectory(case, args.iteration, 128)
            check(case + ' state error reproduction', float(np.max(abs(fine[::2] - coarse) / scale)) == report['state_difference'])
            check(case + ' same state scales', np.array_equal(scale, coarse_scale))
            with np.load(ROOT / (case + '-initial.npz'), allow_pickle=False) as initial:
                check(case + ' exact initial physical state', np.array_equal(fine[0, :-1], initial['initial']) and np.array_equal(coarse[0, :-1], initial['initial']))
            with np.load(ROOT / f'{case}-i{args.iteration}-analysis.npz', allow_pickle=False) as packet:
                check(case + ' common-probe state reproduction', float(np.max(abs(packet['fine'] - packet['coarse']) / scale)) == report['aligned_difference'])
                for index, field in enumerate(('density', 'current', 'anisotropy')):
                    calculated = reference.analysis_module.field_comparison(packet['actual_moments'][:, index], packet['exact_moments'][:, index])
                    check(case + ' characteristic report ' + field, calculated == report['checks']['characteristic'][field])
                check(case + ' boundary report', reference.analysis_module.field_comparison(packet['supplied_boundary'], packet['final_boundary']) == report['fixed_point'])
                with np.load(WIDE / (case + '-refinement512-analysis.npz'), allow_pickle=False) as old:
                    check(case + ' same physical epoch for k5 comparison', np.array_equal(packet['target_times'], old['target_times']))
            numerical = max(report['state_difference'], report['aligned_difference']) <= GATE and all(row['relative_difference'] <= GATE for row in report['source_step_checks'].values())
            physical = numerical and report['fixed_point']['relative_difference'] <= GATE and report['phase']['passed']
            physical = physical and all(row['relative_difference'] <= GATE for group in report['checks'].values() for row in group.values())
            physical = physical and all(row['metrics']['metric_error'] <= GATE and row['metrics']['identity_error'] <= ALGEBRA for row in report['diagnostics'])
            physical = physical and all(max(row['energy_error'], row['current_error'], row['enthalpy_error']) <= ALGEBRA for row in report['conservation'])
            check(case + ' physical acceptance recomputed', bool(physical) == report['passed'] and bool(numerical) == report['numerical_passed'])
            reports.append(report)
            old = read(WIDE / (case + '-refinement512-result.json'))
            for position, current, previous in zip(report['positions'], report['readouts'], old['readouts']):
                comparisons.append(dict(case=case, delta_lna=position, k1_phi=current['phi'], k5_phi=previous['phi'],
                    k1_k2_phi_over_theta=WAVE**2 * current['phi'] / 1e-6, k5_k2_phi_over_theta=25 * previous['phi'] / 1e-6,
                    k1_density=current['density'], k5_density=previous['density'], k1_current=current['current'], k5_current=previous['current']))
            config = read(PORT / 'runs' / (case + '-v4') / 'config.json')
            with np.load(config['table'], allow_pickle=False) as table:
                row = dict(case=case, source=config['table'], sha256=digest(config['table']), keys=table.files)
                if 'modes' in table:
                    row.update(mode_min=float(np.min(table['modes'])), mode_max=float(np.max(table['modes'])),
                               contains_k1=bool(np.any(table['modes'] == WAVE)), covers_k1=bool(np.min(table['modes']) <= WAVE <= np.max(table['modes'])))
                    check(case + ' native matching mode covered', row['covers_k1'])
                for key in ('matching_scale', 'matching_density', 'fraction'):
                    if key in table:
                        row[key] = float(table[key])
                matching.append(row)
        for path in sorted(ROOT.glob('*-chunk*.json')):
            receipt = read(path)
            check(path.name + ' extent', receipt['last'] - receipt['first'] == 32)
            check(path.name + ' packet', digest(ROOT / receipt['packet']) == receipt['packet_sha256'])
            check(path.name + ' frozen', all(digest(ROOT / name) == checksum for name, checksum in receipt['frozen'].items()))
        for path in sorted(ROOT.glob('*-start.json')):
            if path.name == f'validation-i{args.iteration}-start.json':
                continue
            identity = read(path)
            ending = read(ROOT / path.name.replace('-start.json', '-end.json'))
            check(path.name + ' identity', all(identity[key] == ending[key] for key in ('pid', 'created', 'command')))
            check(path.name + ' exited', exited(identity)['exited'])
            check(path.name + ' completed', ending['state'] == 'completed')
        for path in ROOT.glob('*.py'):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
        check('no bytecode', not list(ROOT.rglob('__pycache__')))
        with (ROOT / f'wavelength-comparison-i{args.iteration}.csv').open('x', encoding='utf-8', newline='') as stream:
            writer = csv.DictWriter(stream, fieldnames=list(comparisons[0]))
            writer.writeheader()
            writer.writerows(comparisons)
        write(f'matching-input-map-i{args.iteration}.json', matching)
        result = dict(passed=all(row['passed'] for row in checks), checks=checks, iteration=args.iteration,
                      paired_physics_passed=all(row['passed'] for row in reports), reports=reports,
                      gates=dict(numerical=GATE, algebra=ALGEBRA), code_sha256=digest(__file__),
                      new_fitted_parameters=0, actual_primordial_replay=False)
        write(f'validation-i{args.iteration}.json', result)
        print(json.dumps(dict(passed=result['passed'], checks=len(checks), paired_physics_passed=result['paired_physics_passed'],
                              failed=[row['name'] for row in checks if not row['passed']])), flush=True)
        require(result['passed'], 'mode validation')


if __name__ == '__main__':
    main()
