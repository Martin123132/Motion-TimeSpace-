from mode_support import *
from mode_operator import ModeOperator, trajectory, response17, reference, requested_times
from angular_boundary import kernel17_controls
import argparse
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('iteration', type=int, choices=(1, 2))
    args = parser.parse_args()
    with worker(f'bank-{args.case}-i{args.iteration}'):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'retained sources')
        controls = kernel17_controls()
        operator = ModeOperator(args.case)
        try:
            states, clock, scale = trajectory(args.case, args.iteration - 1)
            metric = reference.sample_metric(operator, states[:, :-1], clock)
            targets = requested_times(operator)
            values = response17(operator, clock, metric, targets, 10)
            indices = np.unique(np.linspace(0, len(targets) - 1, 33).astype(int))
            coarse = response17(operator, clock, metric, targets[indices], 6)
            difference = float(np.max(abs(values[indices] - coarse)) / max(np.max(abs(values)), 1e-100))
            tag = f'{args.case}-boundary{args.iteration}'
            require(not (ROOT / (tag + '.npz')).exists(), 'no bank overwrite')
            np.savez_compressed(ROOT / (tag + '.npz'), times=targets, values=values,
                                source_clock=clock, source_metric=metric, control_indices=indices, coarse=coarse)
            report = dict(case=args.case, iteration=args.iteration, wave=WAVE, passed=difference <= GATE,
                          quadrature_difference=difference, kernel_errors=controls, count=len(targets),
                          source_sha256=digest(ROOT / f'{args.case}-i{args.iteration - 1}-s256.npz'),
                          code_sha256=digest(__file__), model_sha256=digest(ROOT / 'mode_operator.py'),
                          packet_sha256=digest(ROOT / (tag + '.npz')))
            write(tag + '-result.json', report)
            print(json.dumps(report), flush=True)
            require(report['passed'], 'new-mode boundary quadrature')
        finally:
            operator.close()


if __name__ == '__main__':
    main()
