from mode_support import *
from wide_operator import WidePort, WideOperator, SharedCanonical, Series, action_model, Operators, clone
from angular_boundary import BoundaryOperator, response17, reference, requested_times
import types
import numpy as np


class ModePort(WidePort):
    def __init__(self, case, wave=WAVE):
        super().__init__(case, 64)
        self.wave = float(wave)
        self.cache = None


class ModeOperator(WideOperator):
    def __init__(self, case, wave=WAVE):
        require(read(ROOT / 'preflight-result.json')['passed'], 'native wavelength gate')
        self.port = ModePort(case, wave)
        self.facade = types.SimpleNamespace(Series=Series, background_series=self.port.background_series,
                                           RESIDUAL_FUNCTION=action_model.RESIDUAL_FUNCTION)
        self.block = SharedCanonical(self.port, self.facade) if case == 'heavy' else None
        self.scalar_jets = types.MethodType(clone(Operators.scalar_jets, action_model=self.facade), self)
        self.span = float(self.port.times[-1] - self.port.times[0])
        self.last_system = None


class ModeBoundary(BoundaryOperator):
    def __init__(self, case, iteration):
        self.core = ModeOperator(case)
        self.port, self.block, self.span = self.core.port, self.core.block, self.core.span
        self.case, self.iteration = case, iteration
        if iteration:
            tag = f'{case}-boundary{iteration}'
            result = read(ROOT / (tag + '-result.json'))
            require(result['passed'] and result['model_sha256'] == digest(__file__), 'same accepted mode bank')
            require(digest(ROOT / (tag + '.npz')) == result['packet_sha256'], 'mode bank hash')
            with np.load(ROOT / (tag + '.npz'), allow_pickle=False) as packet:
                self.times, self.values = packet['times'].copy(), packet['values'].copy()
            self.lookup = {float(stamp).hex(): index for index, stamp in enumerate(self.times)}

    def matrix(self, stamp):
        if self.iteration:
            return super().matrix(stamp)
        base = self.core.system(stamp)['matrix']
        matrix = np.zeros((len(base) + 1, len(base) + 1))
        matrix[:-1, :-1] = base
        return matrix


def trajectory(case, iteration, steps=256):
    tag = f'{case}-i{iteration}-s{steps}'
    result = read(ROOT / (tag + '-result.json'))
    require(result['full_run'] and result['steps'] == steps, 'complete mode trajectory')
    require(exited(read(ROOT / (result['worker'] + '-start.json')))['exited'], 'mode worker exited')
    require(read(ROOT / (result['worker'] + '-end.json'))['state'] == 'completed', 'successful mode trajectory')
    require(digest(ROOT / (tag + '.npz')) == result['packet_sha256'], 'mode trajectory hash')
    with np.load(ROOT / (tag + '.npz'), allow_pickle=False) as packet:
        require(np.max(abs(packet['states'][:, -1] - 1)) <= ALGEBRA, 'constant affine coordinate')
        return tuple(packet[name].copy() for name in ('states', 'times', 'normalization'))
