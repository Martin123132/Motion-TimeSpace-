from mode_support import *
from mode_operator import ModeOperator, WideOperator
import numpy as np


def main():
    with worker('prepare'):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'unchanged inherited sources')
        reports = []
        for case in ('cold', 'heavy'):
            control = ModeOperator(case, 5.)
            original = WideOperator(case, 64)
            parity = []
            try:
                for fraction in (0., .5, 1.):
                    stamp = float(control.port.times[0] + fraction * control.span)
                    new, old = control.system(stamp), original.system(stamp)
                    scale = np.maximum(np.max(abs(old['matrix']), axis=1), 1e-100)
                    matrix_error = float(np.max(np.max(abs(new['matrix'] - old['matrix']), axis=1) / scale))
                    sources = {name: float(np.max(abs(new[name] - old[name])) / max(np.max(abs(old[name])), 1e-100))
                               for name in ('potential', 'lapse', 'alpha')}
                    parity.append(dict(fraction=fraction, matrix_error=matrix_error, sources=sources))
            finally:
                control.close()
                original.close()
            operator = ModeOperator(case)
            try:
                coarse, coarse_report = operator.prepare(16)
                initial, fine_report = operator.prepare(32)
                scale = np.maximum(abs(initial), 1e-6)
                coefficients = None
                if case == 'heavy':
                    coefficients = operator.block.coefficients(operator.port.context(operator.port.times[0])['scale'])
                    scale[-2:] = max(coefficients['mass'], 1.) * max(np.max(abs(initial[-4:-2])), 1e-6)
                difference = float(np.max(abs(coarse - initial) / scale))
                modes = initial[6:6 + 64 * 17].reshape(64, 17)
                require(np.array_equal(modes[:, 0], np.full(64, 4e-6)) and np.count_nonzero(modes[:, 1:]) == 0, 'same controlled monopole seed')
                require(operator.port.wave == WAVE, 'actual new operator wave')
                passed = bool(coarse_report['passed'] and fine_report['passed'] and difference <= GATE
                              and all(row['matrix_error'] <= ALGEBRA and max(row['sources'].values()) <= ALGEBRA for row in parity))
                np.savez_compressed(ROOT / (case + '-initial.npz'), initial=initial, normalization=scale,
                                    coarse_initial=coarse, times=operator.port.times)
                report = dict(case=case, passed=passed, coarse=coarse_report, fine=fine_report, stencil_difference=difference,
                              wave=WAVE, k5_parity=parity, dimension=len(initial), actual_primordial_replay=False,
                              packet_sha256=digest(ROOT / (case + '-initial.npz')))
                reports.append(report)
                print(json.dumps(report), flush=True)
            finally:
                operator.close()
        result = dict(passed=all(row['passed'] for row in reports), reports=reports,
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / 'mode_operator.py'))
        write('prepare-result.json', result)
        require(result['passed'], 'physical preparation and unchanged k5 control')


if __name__ == '__main__':
    main()
