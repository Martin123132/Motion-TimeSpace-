from mode_support import *
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('iteration', type=int, choices=(1, 2))
    args = parser.parse_args()
    with worker('seal'):
        validation = read(ROOT / f'validation-i{args.iteration}.json')
        require(validation['passed'] and validation['code_sha256'] == digest(ROOT / 'validate_mode.py'), 'same validated evidence')
        dispersion = read(ROOT / 'dispersion-consistency-result.json')
        require(dispersion['algebra_passed'] and dispersion['code_sha256'] == digest(ROOT / 'dispersion_consistency.py'), 'same algebra diagnostic')
        require(dispersion['post_test_diagnostic'] and not dispersion['additional_wavelength_prediction'], 'post-test scope retained')
        for row in dispersion['modes']:
            require(all(digest(path) == checksum for path, checksum in row['source_hashes'].items()), 'dispersion source hashes')
        inputs = preserved()
        require(inputs == read(ROOT / 'frozen-inputs.json'), 'unchanged inherited inputs')
        for name in ('PROTOCOL.md', 'DERIVATION.md', 'RESULTS.md', 'NEXT.md', 'GALAXY-UPDATE-09-RECEIPT.md'):
            require((ROOT / name).is_file(), 'required document ' + name)
        for path in ROOT.glob('*.py'):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
        for path in ROOT.glob('*-start.json'):
            if path.name != 'seal-start.json':
                require(exited(read(path))['exited'], 'worker exited ' + path.name)
        require(not list(ROOT.rglob('__pycache__')), 'no bytecode')
    artifacts = {path.name: dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file()}
    require(len(artifacts) == len(list(ROOT.iterdir())), 'no unexpected directories')
    write('closeout.json', dict(state='verified_progress_independent_wavelength', utc=datetime.now(timezone.utc).isoformat(),
          goal_complete=False, iteration=args.iteration, wave=WAVE, input_hashes=inputs, artifacts=artifacts,
          validation_checks=len(validation['checks']), paired_physics_passed=validation['paired_physics_passed'],
          production_changed=False, new_fitted_parameters=0, next='NEXT.md'))
    print(json.dumps(dict(seal_sha256=digest(ROOT / 'closeout.json'), inputs=len(inputs), artifacts=len(artifacts),
                          checks=len(validation['checks']), paired_physics_passed=validation['paired_physics_passed'])), flush=True)


if __name__ == '__main__':
    main()
