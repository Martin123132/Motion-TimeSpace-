from mode_support import *
from mode_operator import ModeOperator
import numpy as np


def main():
    with worker('dispersion-consistency'):
        require(read(ROOT / 'validation-i1.json')['paired_physics_passed'], 'accepted independent mode')
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'same sources')
        coefficients, modes = [], []
        for wave in (1., 5.):
            operator = ModeOperator('heavy', wave)
            try:
                for position in (0., SPAN / 2, SPAN):
                    scale = float(np.exp(-np.log(11.) + position))
                    values = operator.block.coefficients(scale)
                    mass, hubble = values['mass'], values['hubble']
                    exact = wave**2 / (np.sqrt(mass**2 + wave**2) + mass)
                    leading = wave**2 / (2 * mass)
                    retained = -values['difference'].imag
                    polynomial_error = abs(exact**2 + 2 * mass * exact - wave**2) / wave**2
                    coefficients.append(dict(wave=wave, delta_lna=position, conformal_mass=mass,
                        hubble_over_mass=hubble / mass, wave_over_mass=wave / mass,
                        frozen_background_slow_frequency=exact, retained_w2_beat=retained,
                        leading_quartic_coefficient=leading**2, exact_frequency_squared=exact**2,
                        leading_relative_difference=abs(leading**2 / exact**2 - 1),
                        w2_relative_difference=abs(retained / exact - 1),
                        polynomial_error=polynomial_error, algebra_passed=bool(polynomial_error <= ALGEBRA)))
            finally:
                operator.close()
            paths = {case: ROOT / f'{case}-i1-analysis-result.json' if wave == 1 else WIDE / f'{case}-refinement512-result.json' for case in ('cold', 'heavy')}
            reports = {case: read(path) for case, path in paths.items()}
            require(all(row['passed'] for row in reports.values()), 'accepted paired modes')
            cold, heavy = [reports[case]['readouts'][-1]['phi'] for case in ('cold', 'heavy')]
            difference = heavy - cold
            proxy = sum(row['source_step_checks']['phi']['absolute_difference'] for row in reports.values())
            modes.append(dict(wave=wave, cold_phi=cold, heavy_phi=heavy, absolute_shift=difference,
                fractional_shift=difference / abs(cold), timestep_difference_proxy=proxy,
                proxy_relative_to_shift=proxy / abs(difference), source_hashes={str(path): digest(path) for path in paths.values()}))
        ratio_absolute = modes[1]['absolute_shift'] / modes[0]['absolute_shift']
        ratio_fractional = modes[1]['fractional_shift'] / modes[0]['fractional_shift']
        proxy_relative = sum(row['proxy_relative_to_shift'] for row in modes)
        result = dict(algebra_passed=all(row['algebra_passed'] for row in coefficients), coefficients=coefficients, modes=modes,
            absolute_shift_ratio=ratio_absolute, leading_absolute_ratio=25., relative_departure_from_absolute_scaling=ratio_absolute / 25 - 1,
            fractional_shift_ratio=ratio_fractional, leading_fractional_ratio_if_baseline_transfer_flat=625.,
            relative_departure_from_fractional_scaling=ratio_fractional / 625 - 1,
            baseline_scaled_potential_ratio=abs(modes[0]['cold_phi'] / (25 * modes[1]['cold_phi'])),
            relative_ratio_timestep_proxy=proxy_relative, new_fitted_coefficients=0, post_test_diagnostic=True,
            certified_error_bound=False, additional_wavelength_prediction=False, code_sha256=digest(__file__),
            inherited_coefficient_source=str(POST / 'mts-gauge-source-bridge-20261110/canonical_block.py'))
        write('dispersion-consistency-result.json', result)
        print(json.dumps(dict(algebra_passed=result['algebra_passed'], absolute_shift_ratio=ratio_absolute,
            fractional_shift_ratio=ratio_fractional, relative_ratio_timestep_proxy=proxy_relative,
            maximum_wave_over_mass=max(row['wave_over_mass'] for row in coefficients),
            maximum_w2_relative_difference=max(row['w2_relative_difference'] for row in coefficients))), flush=True)


if __name__ == '__main__':
    main()
