from replay_model import *
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('variant', choices=('fine2', 'fine4', 'coarse4'))
    args = parser.parse_args()
    label = args.case + '-' + args.variant
    with worker(label):
        context = Context(args.case, 'coarse' if args.variant == 'coarse4' else 'fine')
        path_hashes = {str(path): digest(path) for path in (ROOT / 'replay_model.py', Path(__file__), ROOT / 'replay_support.py', ROOT / 'frozen-replay.json')}
        state = advance(context, int(args.variant[-1]))
        observables = context.observe(state)
        checks = {name: difference(values, context.data[name][context.target]) for name, values in observables.items()}
        np.savez_compressed(ROOT / (label + '.npz'), clock=context.clock, state=state, **observables)
        require(all(digest(path) == expected for path, expected in path_hashes.items()), 'replay code frozen')
        result = dict(completed=True, source_replay_passed=all(row['passed'] for row in checks.values()), case=args.case, variant=args.variant, checks=checks, code_hashes=path_hashes, packet_sha256=digest(ROOT / (label + '.npz')), substeps=int(args.variant[-1]), intervals=len(context.clock) - 1, metric_evolved=False, native_bank_modified=False)
        write(label + '-result.json', result)
        worst = max(checks, key=lambda name: float('inf') if checks[name]['normalized'] is None else checks[name]['normalized'])
        print(json.dumps(dict(completed=True, source_replay_passed=result['source_replay_passed'], case=args.case, variant=args.variant, worst=worst, discrepancy=checks[worst], failed=[name for name, row in checks.items() if not row['passed']])), flush=True)


if __name__ == '__main__':
    main()
