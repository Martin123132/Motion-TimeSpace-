from replay_model import *


def half_ulp32(values):
    quantized = np.asarray(values, dtype=np.float32)
    require(np.array_equal(quantized.astype(np.float64), values), 'native column exactly float32 representable')
    upper = np.nextafter(quantized, np.float32(np.inf)).astype(np.float64)
    lower = np.nextafter(quantized, np.float32(-np.inf)).astype(np.float64)
    return np.maximum(upper - values, values - lower) / 2


def cubic_uniform_bound(clock, uncertainties, start, stop):
    basis = CubicSpline(clock, np.eye(len(clock)))
    coefficient_bounds = np.sum(abs(basis.c) * uncertainties[None, None, :], axis=2)
    widths = np.diff(clock)
    interval_bounds = sum(coefficient_bounds[index] * widths**(3 - index) for index in range(4))
    return float(np.max(interval_bounds[start:stop]))


def main():
    with worker('precision-budget'):
        reports = {}
        for case in ('cold', 'heavy'):
            context = Context(case, 'fine')
            if case == 'cold':
                source = EARLY / 'runs/final-bg8-start/cold.npz'
                with np.load(source, allow_pickle=False) as packet:
                    names = packet['names'].tolist()
                    raw = packet['values'][int(np.flatnonzero(packet['modes'] == 1.)[0])]
            else:
                source = PREVIOUS / 'k1-early-source.npz'
                with np.load(source, allow_pickle=False) as packet:
                    names, raw = packet['names'].tolist(), packet['values'].copy()
            indices = context.data['fine_indices']
            velocity_error = half_ulp32(raw[indices, names.index('v_newtonian_cdm')])
            weyl_error = half_ulp32(raw[indices, names.index('Weyl')])
            half_ulp32(raw[indices, names.index('delta_cdm')])
            hubble = context.data['H']
            alpha_error = abs(hubble) * velocity_error
            potential_error = abs(hubble) * alpha_error
            lapse_error = 2 * weyl_error + potential_error
            start, stop = int(context.target[0]), int(context.target[-1])
            potential_bound = cubic_uniform_bound(context.data['clock'], potential_error, start, stop)
            lapse_bound = cubic_uniform_bound(context.data['clock'], lapse_error, start, stop)
            common_bound = lapse_bound + 3 * potential_bound
            field, velocity, mass2 = context.background(context.clock, 's')
            scale, driving_hubble, potential, lapse = context.geometry(context.clock)
            require(np.all(driving_hubble > 0), 'expanding interval')
            omega = float(np.sqrt(np.max(1 + mass2)))
            logarithmic_norm_bound = float(np.max(abs(omega - (1 + mass2) / omega))) / 2
            target_error = alpha_error[context.target]
            initial_field_bound = abs(velocity[0]) * target_error[0]
            initial_momentum_bound = abs(mass2[0] * field[0]) * target_error[0]
            initial_norm = float(np.hypot(omega * initial_field_bound, initial_momentum_bound))
            force_bound = common_bound * float(np.hypot(omega * np.max(abs(velocity)), np.max(abs(mass2 * field))))
            elapsed = context.clock - context.clock[0]
            exponent = np.exp(logarithmic_norm_bound * elapsed)
            integral = np.expm1(logarithmic_norm_bound * elapsed) / logarithmic_norm_bound if logarithmic_norm_bound else elapsed
            norm_bound = exponent * initial_norm + integral * force_bound
            field_bound = norm_bound / omega + abs(velocity) * target_error
            momentum_bound = norm_bound + abs(mass2 * field) * target_error
            with np.load(ROOT / (case + '-fine4.npz'), allow_pickle=False) as packet:
                field_difference = abs(packet['s_u'] - context.data['s_u'][context.target])
                momentum_difference = abs(packet['s_p'] - context.data['s_p'][context.target])
            reports[case] = dict(float32_columns_confirmed=['v_newtonian_cdm', 'Weyl', 'delta_cdm'], metric_quantization_only=True, primitive_integration_error_included=False, background_defect_included=False, maximum_field_difference_over_quantization_envelope=float(np.max(field_difference / field_bound)), maximum_momentum_difference_over_quantization_envelope=float(np.max(momentum_difference / momentum_bound)), field_envelope_peak=float(np.max(field_bound)), momentum_envelope_peak=float(np.max(momentum_bound)), potential_driver_bound=potential_bound, lapse_driver_bound=lapse_bound, log_norm_bound=logarithmic_norm_bound, actual_old_replay_passed=False, source=str(source), source_sha256=digest(source))
            np.savez_compressed(ROOT / (case + '-metric-precision-envelope.npz'), clock=context.clock, field_bound=field_bound, momentum_bound=momentum_bound, field_difference=field_difference, momentum_difference=momentum_difference)
        code_source = BRANCH / 'native-heavy-matching-20261007/native/fortran/equations.f90'
        write('precision-budget-result.json', dict(completed=True, cases=reports, assumptions=['IEEE nearest float32 rounding of native transfer columns', 'same frozen cubic interpolation and background', 'ordinary float64 bound arithmetic, not directed-rounding interval certification'], source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'replay_model.py', code_source)}))
        print(json.dumps(reports), flush=True)


if __name__ == '__main__':
    main()
