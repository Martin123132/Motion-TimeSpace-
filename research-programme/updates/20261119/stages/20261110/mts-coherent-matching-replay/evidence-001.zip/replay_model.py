from replay_support import *
import numpy as np
from scipy.interpolate import CubicSpline, CubicHermiteSpline


class Context:
    def __init__(self, case, representation):
        self.case = case
        self.representation = representation
        self.frozen = read(ROOT / 'frozen-replay.json')
        self.parameters = self.frozen['cases'][case]
        path = ROOT / (case + '-frozen-window.npz')
        require(digest(path) == self.parameters['frozen_sha256'], 'frozen packet ' + case)
        with np.load(path, allow_pickle=False) as saved:
            self.data = {key: saved[key].copy() for key in saved.files}
        selection = np.arange(len(self.data['clock'])) if representation == 'fine' else self.data['coarse_indices']
        clock = self.data['clock'][selection]
        scale = self.data['a'][selection]
        self.scale = CubicHermiteSpline(clock, scale, scale * self.data['H'][selection])
        self.scale_prime = self.scale.derivative()
        self.potential = CubicSpline(clock, self.data['Phi'][selection])
        self.lapse = CubicSpline(clock, self.data['Psi'][selection])
        self.target = self.data['target_indices']
        self.clock = self.data['clock'][self.target]
        self.fields = list(self.parameters['masses'])
        self.normalization = self.data['normalization']
        self.field_functions = {}
        with np.load(EARLY / ('runs/backgrounds/' + case + '.npz'), allow_pickle=False) as background:
            for suffix in self.fields:
                efold = background['heavy_efold' if suffix == 'h' else 'efold']
                require(np.log(self.scale(self.clock[0])) >= efold[0] and np.log(self.scale(self.clock[-1])) <= efold[-1], 'background inside table')
                self.field_functions[suffix] = (CubicSpline(efold, background['phi_' + suffix], bc_type='natural'), CubicSpline(efold, background['phidot_' + suffix], bc_type='natural'))

    def geometry(self, clock):
        scale = self.scale(clock)
        return scale, self.scale_prime(clock) / scale, self.potential(clock), self.lapse(clock)

    def background(self, clock, suffix):
        scale = self.scale(clock)
        field, velocity = self.field_functions[suffix]
        return field(np.log(scale)), velocity(np.log(scale)), (scale * self.parameters['masses'][suffix])**2

    def rhs(self, clock, normalized_state):
        state = normalized_state * self.normalization
        scale, hubble, potential, lapse = self.geometry(clock)
        result = np.empty_like(state)
        result[0] = -state[1]
        result[1] = -hubble * state[1] + lapse
        for index, suffix in enumerate(self.fields):
            offset = 2 + 2 * index
            field, velocity, mass2 = self.background(clock, suffix)
            field_delta, momentum = state[offset:offset + 2]
            result[offset] = momentum + (lapse + 3 * potential) * velocity
            result[offset + 1] = -2 * hubble * momentum - (1 + mass2) * field_delta + mass2 * (3 * potential - lapse) * field
        return result / self.normalization

    def observe(self, state):
        scale, hubble, potential, lapse = self.geometry(self.clock)
        output = dict(dstar_cdm_over_rho=state[:, 0], current_cdm_over_rho=state[:, 1], delta_cdm_N=state[:, 0] + 3 * potential)
        for index, suffix in enumerate(self.fields):
            offset = 2 + 2 * index
            field_delta, momentum = state[:, offset], state[:, offset + 1]
            field, velocity, mass2 = self.background(self.clock, suffix)
            kinetic = velocity * momentum
            mass_term = mass2 * field * field_delta
            metric_term = 3 * velocity**2 * potential
            entries = dict(u=field_delta, p=momentum, D=kinetic + mass_term + metric_term, P=kinetic - mass_term + metric_term, Q=velocity * field_delta, Dstar=kinetic + mass_term, Pi=scale**2 * momentum)
            output.update({suffix + '_' + name: value for name, value in entries.items()})
        return output


def difference(actual, reference):
    actual, reference = np.asarray(actual), np.asarray(reference)
    absolute = float(np.max(abs(actual - reference)))
    scale = float(np.max(abs(reference)))
    normalized = absolute / scale if scale else (0. if absolute == 0 else None)
    return dict(passed=normalized is not None and normalized <= GATE, absolute_max=absolute, reference_peak=scale, normalized=normalized, tolerance=GATE)


def advance(context, substeps):
    values = np.empty_like(context.data['reference_state'])
    values[0] = context.data['reference_state'][0]
    normalized = values[0] / context.normalization
    for index in range(len(context.clock) - 1):
        guard()
        left, right = context.clock[index:index + 2]
        step = (right - left) / substeps
        for inner in range(substeps):
            clock = left + inner * step
            first = context.rhs(clock, normalized)
            second = context.rhs(clock + step / 2, normalized + step * first / 2)
            third = context.rhs(clock + step / 2, normalized + step * second / 2)
            fourth = context.rhs(clock + step, normalized + step * third)
            normalized = normalized + step * (first + 2 * second + 2 * third + fourth) / 6
        values[index + 1] = normalized * context.normalization
    require(np.isfinite(values).all(), 'finite replay state')
    return values
