from replay_model import *
import sympy as sym


def prove_repair():
    hubble, mass2, field, velocity, potential, lapse, density, current, sync_u, sync_momentum = sym.symbols('H mu2 b v Phi Psi dc Uc us Ws', real=True)
    background_rate = -2 * hubble * velocity - mass2 * field
    density_rate, current_rate = -current, -hubble * current + lapse
    delta = density + 3 * (potential + hubble * current)
    sync_u_rate = sync_momentum + velocity * delta
    sync_momentum_rate = -2 * hubble * sync_momentum - (1 + mass2) * sync_u + mass2 * field * delta
    new_u = sync_u + velocity * current
    new_p = sync_momentum + velocity * density - mass2 * field * current
    new_u_rate = sync_u_rate + background_rate * current + velocity * current_rate
    new_p_rate = sync_momentum_rate + background_rate * density + velocity * density_rate - (2 * hubble * mass2 * field + mass2 * velocity) * current - mass2 * field * current_rate
    expressions = dict(field_map=new_u_rate - new_p - (lapse + 3 * potential) * velocity, momentum_map=new_p_rate + 2 * hubble * new_p + (1 + mass2) * new_u - mass2 * (3 * potential - lapse) * field, background_momentum=2 * hubble * velocity + background_rate + mass2 * field)
    proof = {name: str(sym.simplify(value)) for name, value in expressions.items()}
    require(all(value == '0' for value in proof.values()), 'on-shell repaired identities')
    return proof


def evolve(context, substeps):
    initial = context.data['reference_state'][0]
    scale0, hubble0, potential0, lapse0 = context.geometry(context.clock[0])
    field0, velocity0, mass20 = context.background(context.clock[0], 's')
    field0, velocity0 = float(field0), float(velocity0)
    mass = context.parameters['masses']['s']
    momentum0 = scale0**2 * velocity0
    offset_scale = abs(velocity0) * (context.clock[-1] - context.clock[0])
    require(momentum0 != 0 and offset_scale > 0, 'nonzero inherited slow seed')
    sync_u0 = initial[2] - velocity0 * initial[1]
    sync_momentum0 = initial[3] - velocity0 * initial[0] + mass20 * field0 * initial[1]
    physical = np.array([initial[0], initial[1], 0., momentum0, initial[2], initial[3], sync_u0, sync_momentum0])
    normalization = np.array([*context.normalization[:2], offset_scale, abs(momentum0), *context.normalization[2:4], abs(sync_u0), abs(sync_momentum0)])
    require(np.all(normalization > 0), 'repair state normalization')
    normalized = physical / normalization
    values = np.empty((len(context.clock), len(normalized)))
    values[0] = physical

    def rhs(clock, state):
        density, current, offset, momentum, field_delta, canonical_p, sync_u, sync_momentum = state * normalization
        scale, hubble, potential, lapse = context.geometry(clock)
        field, velocity = field0 + offset, momentum / scale**2
        mass2 = (scale * mass)**2
        delta = density + 3 * (potential + hubble * current)
        result = np.array([-current, -hubble * current + lapse, velocity, -scale**4 * mass**2 * field, canonical_p + (lapse + 3 * potential) * velocity, -2 * hubble * canonical_p - (1 + mass2) * field_delta + mass2 * (3 * potential - lapse) * field, sync_momentum + velocity * delta, -2 * hubble * sync_momentum - (1 + mass2) * sync_u + mass2 * field * delta])
        return result / normalization

    for index in range(len(context.clock) - 1):
        guard()
        left, right = context.clock[index:index + 2]
        step = (right - left) / substeps
        for inner in range(substeps):
            clock = left + inner * step
            first = rhs(clock, normalized)
            second = rhs(clock + step / 2, normalized + step * first / 2)
            third = rhs(clock + step / 2, normalized + step * second / 2)
            fourth = rhs(clock + step, normalized + step * third)
            normalized += step * (first + 2 * second + 2 * third + fourth) / 6
        values[index + 1] = normalized * normalization
    scale, hubble, potential, lapse = context.geometry(context.clock)
    field, velocity = field0 + values[:, 2], values[:, 3] / scale**2
    mass2 = (scale * mass)**2
    field_direct, momentum_direct = values[:, 4], values[:, 5]
    field_from_sync = values[:, 6] + velocity * values[:, 1]
    momentum_from_sync = values[:, 7] + velocity * values[:, 0] - mass2 * field * values[:, 1]
    outputs = {}
    for label, field_delta, canonical_p in [('direct', field_direct, momentum_direct), ('sync', field_from_sync, momentum_from_sync)]:
        kinetic, potential_term = velocity * canonical_p, mass2 * field * field_delta
        metric = 3 * velocity**2 * potential
        outputs[label] = dict(u=field_delta, p=canonical_p, D=kinetic + potential_term + metric, P=kinetic - potential_term + metric, Q=velocity * field_delta, Dstar=kinetic + potential_term, Pi=scale**2 * canonical_p)
    old_field, old_velocity, old_mass2 = context.background(context.clock, 's')
    field_change = field0 - old_field + values[:, 2]
    energy_change = ((velocity - old_velocity) * (velocity + old_velocity) + mass2 * field_change * (field + old_field)) / 2
    closure_error = energy_change / (3 * hubble**2)
    file = context.case + '-repair' + str(substeps) + '.npz'
    np.savez_compressed(ROOT / file, clock=context.clock, state=values, normalization=normalization, field=field, field_offset=values[:, 2], velocity=velocity, background_energy_change=energy_change, background_fractional_change=closure_error, **{label + '_' + name: entry for label, rows in outputs.items() for name, entry in rows.items()})
    checks = {name: difference(outputs['sync'][name], reference) for name, reference in outputs['direct'].items()}
    original = {name: difference(reference, context.data['s_' + name][context.target]) for name, reference in outputs['direct'].items()}
    return outputs, dict(completed=True, checks=checks, gauge_passed=all(row['passed'] for row in checks.values()), original_history_comparison=original, same_original_background=False, peak_background_fractional_change=float(np.max(abs(closure_error))), maximum_velocity_change_fraction=float(np.max(abs(velocity - old_velocity))) / float(np.max(abs(old_velocity))), packet_sha256=digest(ROOT / file))


def main():
    with worker('repair-test'):
        proof = prove_repair()
        reports = {}
        for case in ('cold', 'heavy'):
            context = Context(case, 'fine')
            lower, lower_report = evolve(context, 2)
            higher, higher_report = evolve(context, 4)
            refinement = {name: difference(lower['direct'][name], values) for name, values in higher['direct'].items()}
            passed = all(row['passed'] for row in refinement.values()) and higher_report['gauge_passed'] and lower_report['gauge_passed'] and higher_report['peak_background_fractional_change'] < GATE
            reports[case] = dict(passed=passed, fine2=lower_report, fine4=higher_report, refinement=refinement)
        write('local-repair-result.json', dict(completed=True, local_candidate_passed=all(row['passed'] for row in reports.values()), original_replay_passed=False, proof=proof, cases=reports, coupled_metric_evolved=False, original_background_modified=False, primordial_velocity_recomputed=False, source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'LOCAL-REPAIR-CONTRACT.md', ROOT / 'replay_model.py', ROOT / 'frozen-replay.json')}))
        print(json.dumps({case: dict(local_candidate_passed=row['passed'], gauge_error=max(value['normalized'] for value in row['fine4']['checks'].values()), time_error=max(value['normalized'] for value in row['refinement'].values()), background_fractional_change=row['fine4']['peak_background_fractional_change'], velocity_change=row['fine4']['maximum_velocity_change_fraction']) for case, row in reports.items()}), flush=True)


if __name__ == '__main__':
    main()
