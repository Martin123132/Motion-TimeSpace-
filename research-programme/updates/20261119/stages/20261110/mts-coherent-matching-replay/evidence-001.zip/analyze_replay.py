from replay_model import *


def main():
    with worker('analyze'):
        reports = {}
        for case in ('cold', 'heavy'):
            fine, coarse = Context(case, 'fine'), Context(case, 'coarse')
            outputs = {}
            for variant in ('fine2', 'fine4', 'coarse4'):
                report = read(ROOT / (case + '-' + variant + '-result.json'))
                require(report['completed'], 'completed original run')
                check_hashes(report['code_hashes'])
                path = ROOT / (case + '-' + variant + '.npz')
                require(digest(path) == report['packet_sha256'], 'original run packet hash')
                with np.load(path, allow_pickle=False) as packet:
                    outputs[variant] = {key: packet[key].copy() for key in report['checks']}
            time_error = {name: difference(outputs['fine2'][name], values) for name, values in outputs['fine4'].items()}
            history_error = {name: difference(outputs['coarse4'][name], values) for name, values in outputs['fine4'].items()}
            heldout = np.setdiff1d(fine.target, fine.data['coarse_indices'])
            clock = fine.data['clock'][heldout]
            scale, hubble, potential, lapse = coarse.geometry(clock)
            heldout_checks = {name: difference(actual, fine.data[name][heldout]) for name, actual in [('a', scale), ('H', hubble), ('Phi', potential), ('Psi', lapse)]}
            scale, hubble, potential, lapse = fine.geometry(fine.clock)
            alpha = fine.data['alpha'][fine.target]
            eta = fine.data['eta'][fine.target]
            alpha_spline = CubicSpline(fine.data['clock'], fine.data['alpha'])
            dstar_spline = CubicSpline(fine.data['clock'], fine.data['dstar_cdm_over_rho'])
            alpha_defect = alpha_spline(fine.clock, 1) - lapse + hubble * alpha
            z_defect = -dstar_spline(fine.clock, 1) - alpha
            background = {}
            for suffix in fine.fields:
                field, velocity, mass2 = fine.background(fine.clock, suffix)
                field_function, velocity_function = fine.field_functions[suffix]
                velocity_prime = velocity_function(np.log(scale), 1) * hubble
                field_prime = field_function(np.log(scale), 1) * hubble
                field_defect = field_prime - velocity
                velocity_defect = velocity_prime + 2 * hubble * velocity + mass2 * field
                denominator = float(np.max(abs(velocity_prime) + abs(2 * hubble * velocity) + abs(mass2 * field)))
                background[suffix] = dict(velocity_equation_defect_peak=float(np.max(abs(velocity_defect))), velocity_equation_component_peak=denominator, normalized_velocity_equation_defect=float(np.max(abs(velocity_defect))) / denominator, field_derivative_defect_peak=float(np.max(abs(field_defect))), field_derivative_quantization_warning=bool(np.ptp(field) < 1e-10 * np.max(abs(field))), predicted_u_forcing_peak=float(np.max(abs(alpha * velocity_defect))), predicted_p_forcing_peak=float(np.max(abs(-3 * eta * velocity_defect - mass2 * alpha * field_defect))))
            reports[case] = dict(time_refinement=time_error, history_sensitivity=history_error, withheld_metric_samples=heldout_checks, background_equation_diagnostics=background, alpha_derivative_defect_peak=float(np.max(abs(alpha_defect))), alpha_derivative_force_peak=float(np.max(abs(lapse) + abs(hubble * alpha))), synchronous_metric_derivative_defect_peak=float(np.max(abs(z_defect))), metric_derivative_warning='Differentiating quantized saved transfer columns is diagnostic, not an independent high-precision metric residual.')
        source_paths = [EARLY / 'prepare_backgrounds.py', EARLY / 'native_common.py', BRANCH / 'radiation-and-slow-field-transfer-20261007/radiation_common.py']
        write('analysis-result.json', dict(completed=True, paired_replay_passed=False, cases=reports, extra_source_hashes={str(path): digest(path) for path in source_paths}, original_failures_preserved=True, code_sha256=digest(__file__)))
        print(json.dumps({case: dict(time_error=max(row['normalized'] for row in value['time_refinement'].values()), history_error=max(row['normalized'] for row in value['history_sensitivity'].values()), heldout_error=max(row['normalized'] for row in value['withheld_metric_samples'].values()), background=value['background_equation_diagnostics'], alpha_defect=value['alpha_derivative_defect_peak'], metric_defect=value['synchronous_metric_derivative_defect_peak']) for case, value in reports.items()}), flush=True)


if __name__ == '__main__':
    main()
