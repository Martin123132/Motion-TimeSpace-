from replay_support import *
import numpy as np
from scipy.interpolate import CubicSpline


def main():
    with worker('prepare'):
        inputs = preserved()
        heavy_path = PREVIOUS / 'heavy-canonical-early-state.npz'
        cold_path = PREVIOUS / 'cold-canonical-early-state.npz'
        with np.load(heavy_path, allow_pickle=False) as heavy:
            scales = heavy['a'].copy()
            requested = heavy['requested_scale'].copy()
        with np.load(cold_path, allow_pickle=False) as cold:
            require(np.array_equal(requested, cold['requested_scale']), 'same original requested schedule')
        with np.load(EARLY / 'runs/backgrounds/heavy.npz', allow_pickle=False) as background:
            phase_of_scale = CubicSpline(background['heavy_efold'], background['phase_h'])
        center = read(PREVIOUS / 'projection-reproduction.json')['center']
        phase = phase_of_scale(np.log(scales))
        middle = float(phase_of_scale(np.log(center)))
        candidates = np.flatnonzero(abs(phase - middle) <= 2 * np.pi)
        require(len(candidates) > 100, 'dense saved phase interval')
        left, right = int(candidates[0]), int(candidates[-1])
        require(np.array_equal(candidates, np.arange(left, right + 1)), 'contiguous short window')
        lower, upper = left - 8, right + 8
        require(lower >= 0 and upper < len(scales), 'saved guards exist')
        fine = np.arange(lower, upper + 1)
        coarse = np.unique(np.r_[fine[::2], fine[-1], left, right])
        target = np.arange(left, right + 1)
        recovery = read(PREVIOUS / 'recovery-result.json')
        cases = {}
        for case, source in [('cold', cold_path), ('heavy', heavy_path)]:
            with np.load(source, allow_pickle=False) as saved:
                selected = {key: saved[key][fine] if saved[key].ndim else saved[key] for key in saved.files}
                clock = saved['clock'][target]
                field_names = list(recovery['cases'][case]['fields'])
                names = ['dstar_cdm_over_rho', 'current_cdm_over_rho'] + [suffix + '_' + component for suffix in field_names for component in ('u', 'p')]
                reference = np.column_stack([saved[name][target] for name in names])
                normalization = np.max(abs(reference), axis=0)
                require(np.all(normalization > 0), 'nonzero state scales')
                np.savez_compressed(ROOT / (case + '-frozen-window.npz'), **selected, fine_indices=fine, coarse_indices=coarse - lower, target_indices=target - lower, state_names=np.array(names), reference_state=reference, normalization=normalization)
                cases[case] = dict(source=str(source), source_sha256=digest(source), clock_range=[float(clock[0]), float(clock[-1])], scale_range=[float(saved['a'][left]), float(saved['a'][right])], state_names=names, state_normalization=normalization.tolist(), masses={suffix: row['mass_mpc_inverse'] for suffix, row in recovery['cases'][case]['fields'].items()}, fraction=0. if case == 'cold' else .5, frozen_sha256=digest(ROOT / (case + '-frozen-window.npz')))
        inputs.update({str(path): digest(path) for path in (ROOT / 'PROTOCOL.md', ROOT / 'prepare_replay.py', ROOT / 'replay_support.py')})
        write('frozen-inputs.json', inputs)
        report = dict(passed=True, center=center, phase_center=middle, phase_halfwidth=2 * np.pi, phase_bounds=[float(phase[left]), float(phase[right])], saved_indices=[left, right], intervals=right - left, guard_nodes=8, fine_nodes=len(fine), coarse_nodes=len(coarse), cases=cases, numerical_gate=GATE, algebra_gate=ALGEBRA, runs=['fine2', 'fine4', 'coarse4'], source_hashes=inputs)
        write('frozen-replay.json', report)
        print(json.dumps({key: report[key] for key in ('passed', 'saved_indices', 'intervals', 'fine_nodes', 'coarse_nodes', 'phase_bounds', 'cases')}), flush=True)


if __name__ == '__main__':
    main()
