from replay_model import *
import sympy as sym


def prove_ports():
    hubble, mass2, wave, field, velocity, alpha, eta, potential, lapse, eta_prime = sym.symbols('H mu2 k b v alpha eta Phi Psi eta_prime', real=True)
    sync_u, sync_w, defect_b, defect_f, defect_a, defect_g, defect_z = sym.symbols('us ws Eb Ef Ea Eg Ez', real=True)
    z_metric = (defect_z + wave**2 * alpha - 3 * eta_prime) / wave
    field_prime = velocity + defect_f
    velocity_prime = -2 * hubble * velocity - mass2 * field + defect_b
    alpha_prime = lapse - hubble * alpha + defect_a
    potential_value = eta - hubble * alpha + defect_g
    new_u = sync_u + velocity * alpha
    new_p = sync_w - mass2 * field * alpha - 3 * eta * velocity
    new_u_prime = sync_w + velocity_prime * alpha + velocity * alpha_prime
    sync_w_prime = -2 * hubble * sync_w - (wave**2 + mass2) * sync_u - wave * z_metric * velocity
    new_p_prime = sync_w_prime - 2 * hubble * mass2 * field * alpha - mass2 * field_prime * alpha - mass2 * field * alpha_prime - 3 * eta_prime * velocity - 3 * eta * velocity_prime
    field_port = alpha * defect_b + velocity * defect_a - 3 * velocity * defect_g
    momentum_port = -mass2 * alpha * defect_f - 3 * eta * defect_b - mass2 * field * defect_a - velocity * defect_z - 3 * mass2 * field * defect_g
    expressions = dict(field_port=new_u_prime - new_p - (lapse + 3 * potential_value) * velocity - field_port, momentum_port=new_p_prime + 2 * hubble * new_p + (wave**2 + mass2) * new_u - mass2 * (3 * potential_value - lapse) * field - momentum_port)
    proof = {name: str(sym.simplify(value)) for name, value in expressions.items()}
    require(all(value == '0' for value in proof.values()), 'derived defect ports')
    return proof


def response(context, substeps):
    alpha_function = CubicSpline(context.data['clock'], context.data['alpha'])
    eta_function = CubicSpline(context.data['clock'], context.data['eta'])
    cold_function = CubicSpline(context.data['clock'], context.data['dstar_cdm_over_rho'])
    scales = context.normalization[2:].reshape(len(context.fields), 2)
    state = np.zeros((len(context.fields), 2, 2))
    states = np.empty((len(context.clock), *state.shape))
    states[0] = state

    def equation(clock, normalized):
        value = normalized * scales[:, None, :]
        scale, hubble, potential, lapse = context.geometry(clock)
        alpha, eta = alpha_function(clock), eta_function(clock)
        defect_a = alpha_function(clock, 1) - lapse + hubble * alpha
        defect_g = potential - eta + hubble * alpha
        defect_z = -cold_function(clock, 1) - alpha
        result = np.empty_like(value)
        for index, suffix in enumerate(context.fields):
            field, velocity, mass2 = context.background(clock, suffix)
            field_function, velocity_function = context.field_functions[suffix]
            defect_f = field_function(np.log(scale), 1) * hubble - velocity
            defect_b = velocity_function(np.log(scale), 1) * hubble + 2 * hubble * velocity + mass2 * field
            forcing = np.array([[alpha * defect_b, -mass2 * alpha * defect_f - 3 * eta * defect_b], [velocity * defect_a - 3 * velocity * defect_g, -mass2 * field * defect_a - velocity * defect_z - 3 * mass2 * field * defect_g]])
            result[index, :, 0] = value[index, :, 1]
            result[index, :, 1] = -2 * hubble * value[index, :, 1] - (1 + mass2) * value[index, :, 0]
            result[index] += forcing
        return result / scales[:, None, :]

    for index in range(len(context.clock) - 1):
        guard()
        left, right = context.clock[index:index + 2]
        step = (right - left) / substeps
        for inner in range(substeps):
            clock = left + inner * step
            first = equation(clock, state)
            second = equation(clock + step / 2, state + step * first / 2)
            third = equation(clock + step / 2, state + step * second / 2)
            fourth = equation(clock + step, state + step * third)
            state += step * (first + 2 * second + 2 * third + fourth) / 6
        states[index + 1] = state * scales[:, None, :]
    return states


def main():
    with worker('defect-diagnostic'):
        proof = prove_ports()
        reports = {}
        for case in ('cold', 'heavy'):
            context = Context(case, 'fine')
            predicted = response(context, 4)
            with np.load(ROOT / (case + '-fine4.npz'), allow_pickle=False) as packet:
                original = packet['state'].copy()
            responses = {}
            for label, contribution in [('background', predicted[:, :, 0, :]), ('metric', predicted[:, :, 1, :]), ('sum', predicted.sum(axis=2))]:
                amended = original.copy()
                amended[:, 2:] += contribution.reshape(len(context.clock), -1)
                observables = context.observe(amended)
                checks = {name: difference(values, context.data[name][context.target]) for name, values in observables.items()}
                responses[label] = checks
            np.savez_compressed(ROOT / (case + '-predicted-defect-response.npz'), clock=context.clock, response=predicted)
            reports[case] = dict(diagnostic_only=True, coefficient_fitted=False, action_changed=False, responses=responses, packet_sha256=digest(ROOT / (case + '-predicted-defect-response.npz')))
        write('defect-diagnostic-result.json', dict(completed=True, proof=proof, cases=reports, source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'OFFSHELL-DIAGNOSIS.md', ROOT / 'replay_model.py')}))
        print(json.dumps({case: {label: {name: row['normalized'] for name, row in checks.items() if name in ('s_u', 's_p', 'h_u', 'h_p')} for label, checks in result['responses'].items()} for case, result in reports.items()}), flush=True)


if __name__ == '__main__':
    main()
