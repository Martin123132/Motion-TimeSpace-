from common import *
from radiation_model import RadiationOperators
from bridge_imports import defects, norm, relative, preparation
import numpy as np


def main():
    with worker("correction-check"):
        require(read(ROOT/"external-port-result.json")["passed"] and read(ROOT/"proof.json")["passed"], "source port and derivation gates")
        checks,reports,packets=[],[],{}

        def check(name,error):
            checks.append(dict(name=name,error=float(error),gate=ALGEBRA,passed=error<=ALGEBRA))

        for label,canonical in (("heavy",False),("cold",False),("heavy",True)):
            operator=RadiationOperators(label,canonical,enabled=False)
            tag="canonical" if canonical else "native_"+label
            try:
                if canonical:
                    with np.load(RETAINED/"D0-256.npz") as packet:
                        states=[packet["initial"].copy(),packet["final"].copy()]
                else:
                    with np.load(operator.port.owner/"precision.npz") as packet:
                        states=[operator.port.initial.copy(),packet["state"][-1].copy()]
                original_rows={}
                for enabled in (False,True):
                    operator.enabled=enabled
                    if operator.block is not None:
                        operator.block.enabled=enabled
                    operator.cache.clear()
                    operator.systems.clear()
                    for endpoint,state in enumerate(states):
                        for divisions in (8,16):
                            jets=operator.jets(endpoint,divisions)
                            residuals=defects(operator,jets,state)
                            report=dict(model=tag,enabled=enabled,endpoint=endpoint,divisions=divisions,defects=residuals,
                                        metric_gate_passed=residuals["metric_error"]<=GATE,scope="same saved state, corrected source/operator, before new evolution")
                            reports.append(report)
                        system=operator.systems[endpoint]
                        stamp=float(operator.port.times[endpoint])
                        native_state=system["mapping"]@state
                        increments=system["increments"]@state
                        direct=operator.port.radiation_call(operator.port.rhs,stamp,native_state,increments)
                        actual=system["matrix"]@state
                        selected=operator.port.remaining if canonical else np.arange(operator.port.dimension)
                        expected=direct[selected]
                        check(tag+" direct RHS "+str(enabled)+str(endpoint),relative(actual[:len(selected)]-expected,[actual[:len(selected)],expected]))
                        observed=operator.port.radiation_call(operator.port.observe,stamp,native_state,increments)
                        predicted=system["background"]+system["full_observer"]@state
                        check(tag+" direct observer "+str(enabled)+str(endpoint),relative(observed-predicted,[observed,predicted]))
                        if canonical:
                            values=system["coefficients"]
                            position=complex(*state[-4:-2])
                            momentum=complex(*state[-2:])
                            phi=system["potential"]@state
                            psi=system["lapse"]@state
                            combined=3*phi+psi
                            first_terms=[values["difference"]*position,momentum,combined*values["physical0"]]
                            second_terms=[-(values["lambda0"]+values["lambdak"])*momentum,-values["residual"]*position,
                                          combined*(values["hubble"]-values["lambdak"])*values["physical0"],values["mass"]**2*(3*phi-psi)]
                            check("canonical direct field "+str(enabled)+str(endpoint),relative(complex(*actual[-4:-2])-sum(first_terms),first_terms))
                            check("canonical direct momentum "+str(enabled)+str(endpoint),relative(complex(*actual[-2:])-sum(second_terms),second_terms))
                        saved_key=tag+"_"+str(int(enabled))+"_"+str(endpoint)
                        packets[saved_key+"_matrix"]=system["matrix"]
                        packets[saved_key+"_increments"]=system["increments"]
                        packets[saved_key+"_state"]=state
                        if not enabled:
                            original_rows[endpoint]=operator.sample(endpoint)
                        else:
                            report["source_change_norm"]=norm((operator.sample(endpoint)["matrix"]-original_rows[endpoint]["matrix"])*operator.scale[None,:]/operator.scale[:,None])
                        print(json.dumps(report),flush=True)
                if canonical:
                    prep_reports,prep_states=[],{}
                    for divisions in (8,16):
                        states_new,reports_new,response=preparation(operator,operator.jets(0,divisions))
                        for choice,state in states_new.items():
                            prep_states[choice+"_initial_"+str(divisions)]=state
                        prep_reports.append(dict(divisions=divisions,preparations=reports_new))
                    refine={choice:norm((prep_states[choice+"_initial_16"]-prep_states[choice+"_initial_8"])/operator.scale) for choice in ("D0","D01")}
                    np.savez_compressed(ROOT/"corrected-preparations.npz",**prep_states,normalization=operator.scale,times=operator.port.times)
                    write("corrected-preparation-result.json",dict(passed=all(value<=GATE for value in refine.values()) and all(value["passed"] for row in prep_reports for value in row["preparations"].values()),
                          reports=prep_reports,refinement=refine,code_sha256=digest(__file__),model_sha256=digest(ROOT/"radiation_model.py")))
            finally:
                operator.close()
        np.savez_compressed(ROOT/"correction-control-packets.npz",**packets)
        result=dict(implementation_passed=all(row["passed"] for row in checks),corrected_metric_passed=all(row["metric_gate_passed"] for row in reports if row["enabled"]),
                    checks=checks,reports=reports,gate=GATE,code_sha256=digest(__file__),model_sha256=digest(ROOT/"radiation_model.py"))
        write("correction-result.json",result)
        require(result["implementation_passed"],"source-consistent implementation")
        require(read(ROOT/"corrected-preparation-result.json")["passed"],"new live preparation")


if __name__=="__main__":
    main()
