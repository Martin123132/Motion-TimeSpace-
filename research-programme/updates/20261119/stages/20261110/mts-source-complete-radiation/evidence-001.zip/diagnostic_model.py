from common import *
from radiation_model import RadiationOperators
from bridge_imports import relative
import numpy as np


class DiagnosticOperators(RadiationOperators):
    def sample(self,fraction):
        result=super().sample(fraction)
        if "gamma_density" in result:
            return result
        system=self.systems[fraction]
        port=self.port
        background,observer=system["background"],system["full_observer"]
        hubble,alpha=system["hubble"],system["alpha"]
        for species in ("gamma","massless"):
            rho=background[port.columns["R_"+species]]
            result[species+"_density"]=rho*(observer[port.columns["delta_"+species+"64"]]-4*hubble*alpha)
            result[species+"_current"]=rho*(observer[port.columns["q_"+species+"64"]]+4*port.wave*alpha/3)
            result[species+"_enthalpy"]=np.array(4*rho/3)
        baryon_velocity=observer[port.columns["v_baryon64"]]
        baryon_pressure=observer[port.columns["delta_p_b"]]
        baryon_rho=background[port.columns["R_baryon"]]
        result["gamma_drag"]=-baryon_rho*(baryon_velocity@result["matrix"]+hubble*baryon_velocity-port.wave*baryon_pressure)
        result["missing_density"]=system["missing_density"]
        result["missing_pressure"]=system["missing_pressure"]
        return result

    def jets_at(self,fraction,divisions):
        if fraction in (0,1):
            return self.jets(fraction,divisions)
        require(2/divisions<=fraction<=1-2/divisions,"centered stencil inside captured regime")
        samples=[self.sample(fraction+offset/divisions) for offset in (-2,-1,0,1,2)]
        spacing=np.longdouble(self.span/divisions)
        first_weights=np.array([1,-8,0,8,-1],dtype=np.longdouble)/12
        second_weights=np.array([-1,16,-30,16,-1],dtype=np.longdouble)/12
        result={}
        for name in samples[0]:
            values=np.stack([sample[name] for sample in samples]).astype(np.longdouble)
            shifted=values-values[2]
            result[name]=(values[2],np.tensordot(first_weights,shifted,axes=(0,0))/spacing,
                          np.tensordot(second_weights,shifted,axes=(0,0))/spacing**2)
        return result


def source_diagnostics(operator,jets,state):
    state=state.astype(np.longdouble)
    derivative=jets["matrix"][0]@state
    value=lambda name:jets[name][0]@state
    rate=lambda name:jets[name][1]@state+jets[name][0]@derivative
    hubble,wave=jets["hubble"][0],operator.port.wave
    phi_prime,lapse=rate("phi"),value("psi")
    species_rows={}
    for species in ("gamma","massless"):
        density,current=value(species+"_density"),value(species+"_current")
        enthalpy=jets[species+"_enthalpy"][0]
        exchange=value("gamma_drag") if species=="gamma" else np.longdouble(0)
        energy_terms=[rate(species+"_density"),2*hubble*density,wave*current,-3*enthalpy*phi_prime]
        current_terms=[rate(species+"_current"),2*hubble*current,-wave*(density/3+enthalpy*lapse),-exchange]
        energy,momentum=np.sum(energy_terms),np.sum(current_terms)
        species_rows[species]=dict(energy_residual=float(energy),current_residual_after_exchange=float(momentum),
                                  energy_error=relative(energy,energy_terms),current_error=relative(momentum,current_terms),
                                  constraint_budget=float(energy+3*hubble*momentum/wave))
    density,pressure=value("missing_density"),value("missing_pressure")
    source_scale=max(abs(density),np.longdouble(1e-100))
    return dict(radiation=species_rows,density_rate_over_k_density=float(abs(rate("missing_density"))/(wave*source_scale)),
                pressure_over_density=float(abs(pressure)/source_scale),pressure_rate_over_k_density=float(abs(rate("missing_pressure"))/(wave*source_scale)),
                scope="sampled actual-trajectory source-order indicators, not a uniform bound or validity for arbitrary fast states")
