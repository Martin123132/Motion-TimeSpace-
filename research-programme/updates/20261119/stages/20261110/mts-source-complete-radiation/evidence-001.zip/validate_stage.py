from common import *
from summarize_evolution import CASES, summarize
import csv
import numpy as np


def exited(identity):
    try:
        process = psutil.Process(identity["pid"])
        created, command = process.create_time(), process.cmdline()
    except psutil.NoSuchProcess:
        return dict(exited=True, reason="PID absent")
    same = abs(created - identity["created"]) < .01 and command == identity["command"]
    return dict(exited=not same, reason="original identity live" if same else "PID reused; not touched",
                observed_creation=created, observed_command=command)


def identities():
    records = []
    for path in sorted(ROOT.glob("*-start.json")):
        records.append((path.name, read(path)))
    for index, identity in enumerate(read(ROOT / "build-result.json")["processes"]):
        records.append(("compiler-" + str(index), identity))
        for child_index, child in enumerate(identity["children"]):
            records.append(("compiler-" + str(index) + "-child-" + str(child_index), child))
    return records


def main():
    with worker("validation"):
        checks = []

        def check(name, condition, **details):
            checks.append(dict(name=name, passed=bool(condition), **details))

        frozen = preserved()
        check("inherited sources unchanged", frozen == read(ROOT / "frozen-inputs.json"), count=len(frozen))
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            check("compile " + path.name, True)
        check("no bytecode", not list(ROOT.rglob("__pycache__")))
        build = read(ROOT / "build-result.json")
        check("isolated build complete", build["state"] == "complete" and all(row["exit_code"] == 0 for row in build["processes"]))
        check("temporary mappings removed by owner", build["temporary_mappings_removed"])
        check("new native library hash", digest(ROOT / "build/native/camb/cambdll.dll") == build["dll_sha256"])
        for name, expected in build["sources"].items():
            check("compiled source " + name, digest(ROOT / "build" / name) == expected)
        check("original objects untouched", all(digest(path) == expected for path, expected in build["original_objects"].items()))
        proof, external, correction, preparation, summary = [read(ROOT / name) for name in
            ("proof.json", "external-port-result.json", "correction-result.json", "corrected-preparation-result.json", "evolution-summary.json")]
        check("four exact feedback identities", proof["passed"] and len(proof["identities"]) == 4)
        check("source port controls", external["passed"] and len(external["checks"]) == 40 and all(row["error"] <= ALGEBRA for row in external["checks"]))
        check("disabled port retains capture", external["original_capture_equal"])
        check("injection state reset", external["injection_reset_after_each_call"])
        check("direct native and canonical equations", correction["implementation_passed"] and all(row["error"] <= ALGEBRA for row in correction["checks"]))
        check("same frozen physics gate", correction["gate"] == summary["gate"] == GATE)
        check("same frozen algebra gate", summary["algebra_gate"] == ALGEBRA)
        check("preparation recomputed using live corrected source", preparation["passed"] and max(preparation["refinement"].values()) <= GATE)
        check("actual coupled repair, no fitted parameter", summary["source_repair_applied"] and summary["new_fitted_parameters"] == 0)
        for report, filename in ((proof, "prove_feedback.py"), (external, "check_external_port.py"), (correction, "check_correction.py"),
                                 (preparation, "check_correction.py"), (summary, "summarize_evolution.py")):
            check("report source " + filename, report["code_sha256"] == digest(ROOT / filename))
        check("native adapter hash", external["native_port_sha256"] == digest(ROOT / "native_port.py"))
        for report in (correction, preparation):
            check("reported corrected operator hash", report["model_sha256"] == digest(ROOT / "radiation_model.py"))
        recomputed_summary = []
        for case in CASES:
            filename = "evolution-" + case + "-result.json"
            report = read(ROOT / filename)
            recomputed_summary.extend(summarize(report))
            check("summary input hash " + case, summary["input_hashes"][filename] == digest(ROOT / filename))
            for key, name in (("code_sha256", "evolve_corrected.py"), ("model_sha256", "radiation_model.py"), ("diagnostic_sha256", "diagnostic_model.py")):
                check("evolution code " + case + " " + key, report[key] == digest(ROOT / name))
            canonical = case in ("D0", "D01")
            counts = (128, 256) if canonical else (64, 128)
            dimension = 95 if canonical else (93 if case == "heavy" else 91)
            check("four paired runs " + case, {(row["enabled"], row["steps"]) for row in report["reports"]} == {(enabled, steps) for enabled in (False, True) for steps in counts})
            histories = {}
            fixed_initial = None
            fixed_scale = None
            for enabled in (False, True):
                previous = None
                for steps in counts:
                    name = case + ("-corrected-" if enabled else "-original-") + str(steps)
                    saved = read(ROOT / (name + ".json"))
                    check("embedded report matches " + name, saved in report["reports"])
                    with np.load(ROOT / (name + ".npz")) as packet:
                        history, scale, initial, times = [packet[key].copy() for key in ("history", "normalization", "initial", "times")]
                    check("state and probe shapes " + name, history.shape == (9, dimension) and scale.shape == initial.shape == (dimension,) and times.shape == (9,))
                    check("positive fixed normalization " + name, np.all(scale > 0))
                    check("initial probe exact " + name, np.array_equal(history[0], initial))
                    check("monotonic diagnostic times " + name, np.all(np.diff(times) > 0))
                    if fixed_initial is None:
                        fixed_initial, fixed_scale = initial, scale
                    check("same initial and scale in ablation " + name, np.array_equal(initial, fixed_initial) and np.array_equal(scale, fixed_scale))
                    if canonical:
                        with np.load(ROOT / "corrected-preparations.npz") as prepared:
                            check("actual recomputed preparation " + name, np.array_equal(initial, prepared[case + "_initial_16"]) and np.array_equal(scale, prepared["normalization"]))
                    if previous is not None:
                        difference = float(np.max(abs(history - previous) / scale))
                        check("independent refinement " + name, difference == saved["refinement"] and difference <= GATE)
                    previous = history
                    expected_probes = {(index / 8, divisions) for index in (range(9) if steps == counts[-1] else (0, 4, 8)) for divisions in ((16, 32) if steps == counts[-1] else (16,))}
                    check("probe and stencil coverage " + name, {(row["fraction"], row["divisions"]) for row in saved["diagnostics"]} == expected_probes)
                    metric_passed = all(row["metrics"]["metric_error"] <= GATE for row in saved["diagnostics"])
                    check("metric gate faithfully reported " + name, metric_passed == saved["metric_passed"])
                    check("independent metric derivative " + name, all(row["metrics"]["independently_differentiated_metric"] for row in saved["diagnostics"]))
                    check("algebraic constraints " + name, all(row["metrics"]["constraint_error"] <= ALGEBRA and row["metrics"]["identity_error"] <= ALGEBRA for row in saved["diagnostics"]))
                    check("original failure and corrected pass retained " + name, metric_passed == (enabled or case == "cold"))
                histories[enabled] = previous
            state_change = float(np.max(abs(histories[True] - histories[False]) / fixed_scale))
            check("source ablation state norm " + case, state_change == report["corrected_minus_original_state_norm"] == summary["state_changes"][case])
        check("summary independently reconstructed", recomputed_summary == summary["rows"])
        check("sampled corrected metric gates pass", summary["corrected_metric_gate_passed"] and all(row["metric_gate_passed"] for row in recomputed_summary if row["enabled"]))
        individual_pass = all(row["individual_radiation_gates_passed"] for row in recomputed_summary if row["enabled"])
        check("remaining radiation failures not relabelled", not individual_pass and summary["all_individual_radiation_gates_passed"] == individual_pass)
        with (ROOT / "radiation-error-budget.csv").open(encoding="utf-8", newline="") as stream:
            rows = list(csv.DictReader(stream))
        check("error budget parses without malformed rows", len(rows) == 16 and all(None not in row and all(value is not None for value in row.values()) for row in rows))
        packet_hashes = {}
        for path in sorted(ROOT.glob("*.npz")):
            with np.load(path) as packet:
                check("finite packet " + path.name, all(np.all(np.isfinite(packet[name])) for name in packet.files))
            packet_hashes[path.name] = digest(path)
        processes = []
        for name, identity in identities():
            if name == "validation-start.json":
                continue
            status = exited(identity)
            check("identity exited " + name, status["exited"])
            if name.endswith("-start.json"):
                ending = read(ROOT / name.replace("-start.json", "-end.json"))
                check("completed receipt " + name, ending["state"] == "completed" and ending["pid"] == identity["pid"] and ending["created"] == identity["created"])
            processes.append(dict(receipt=name, identity=identity, status=status))
        result = dict(passed=all(row["passed"] for row in checks), checks=checks, workers=processes, input_count=len(frozen), packet_hashes=packet_hashes,
                      scientific_outcome="derived leading source repair passes sampled metric gate; individual radiation-rate gates remain open in both MTS and cold control",
                      qualification="Implementation/provenance checks do not count as separate physical discoveries.")
        write("validation.json", result)
        print(json.dumps(dict(passed=result["passed"], checks=len(checks), inputs=len(frozen), identities=len(processes), failed=[row for row in checks if not row["passed"]])))
        require(result["passed"], "stage implementation and provenance validation")


if __name__ == "__main__":
    main()
