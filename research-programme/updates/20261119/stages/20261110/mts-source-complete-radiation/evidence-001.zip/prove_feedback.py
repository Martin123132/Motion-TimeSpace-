from common import *
import sympy as sym


def main():
    with worker("proof"):
        hubble, eta, phi, beta, heavy_enthalpy, heavy_pressure, slow_pressure = sym.symbols("hubble eta phi beta heavy_enthalpy heavy_pressure slow_pressure", real=True)
        alpha=(eta-phi)/hubble
        physical_pressure=heavy_pressure+3*heavy_enthalpy*phi
        synchronous=physical_pressure-beta*alpha+slow_pressure
        fixed=heavy_pressure+slow_pressure-beta*eta/hubble
        feedback=3*heavy_enthalpy+beta/hubble
        wave, density, density_weight, pressure_weight, current_weight, numerator, denominator = sym.symbols("wave density density_weight pressure_weight current_weight numerator denominator", real=True)
        solved=-(numerator+density_weight*density+pressure_weight*fixed+3*hubble*current_weight*density/wave)/(denominator+pressure_weight*feedback)
        equation=denominator*phi+numerator+density_weight*density+pressure_weight*(fixed+feedback*phi)+3*hubble*current_weight*density/wave
        checks=dict(pressure_clock_sign=synchronous-fixed-feedback*phi,
                    corrected_metric_elimination=equation.subs(phi, solved))
        heavy_current, normalization, old_phi = sym.symbols("heavy_current normalization old_phi", real=True)
        image=(heavy_current-heavy_enthalpy*wave*(eta-phi)/hubble)/normalization
        old_image=image.subs(phi, old_phi)
        checks["native_current_image_update"] = image-old_image-heavy_enthalpy*wave*(phi-old_phi)/(normalization*hubble)
        gamma, baryon, opacity, old_q, increment, velocity = sym.symbols("gamma baryon opacity old_q increment velocity", real=True)
        drag=lambda flux:-gamma/baryon*opacity*(sym.Rational(4,3)*velocity-flux)
        checks["baryon_drag_increment"] = drag(old_q+increment)-drag(old_q)-gamma/baryon*opacity*increment
        for name,expression in checks.items():
            require(sym.factor(expression)==0, name)
        write("proof.json", dict(passed=True, identities=list(checks), code_sha256=digest(__file__)))
        print("PASS", len(checks), "source/metric identities")


if __name__=="__main__":
    main()
