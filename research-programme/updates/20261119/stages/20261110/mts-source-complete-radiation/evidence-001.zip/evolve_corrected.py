from common import *
from diagnostic_model import DiagnosticOperators,source_diagnostics
from bridge_imports import defects,norm
import argparse
import numpy as np
from scipy.linalg import expm


def evolve(factory,initial,times,steps,scale):
    first_weight=(3-2*np.sqrt(3.))/12
    second_weight=(3+2*np.sqrt(3.))/12
    first_node,second_node=.5-np.sqrt(3.)/6,.5+np.sqrt(3.)/6
    boundaries=np.linspace(times[0],times[-1],steps+1)
    state=initial/scale
    history=[initial.copy()]
    require(steps%8==0,"eight diagnostic segments")
    for index,(begin,end) in enumerate(zip(boundaries[:-1],boundaries[1:])):
        guard()
        interval=end-begin
        early_matrix=factory(begin+first_node*interval)*scale[None,:]/scale[:,None]
        late_matrix=factory(begin+second_node*interval)*scale[None,:]/scale[:,None]
        first=interval*(second_weight*early_matrix+first_weight*late_matrix)
        second=interval*(first_weight*early_matrix+second_weight*late_matrix)
        state=expm(second)@(expm(first)@state)
        if (index+1)%(steps//8)==0:
            history.append(state*scale)
    return np.array(history)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("case",choices=("heavy","cold","D0","D01"))
    case=parser.parse_args().case
    canonical=case in ("D0","D01")
    with worker("evolution-"+case):
        require(read(ROOT/"correction-result.json")["implementation_passed"],"source-consistent operator")
        require(read(ROOT/"corrected-preparation-result.json")["passed"],"live preparation")
        operator=DiagnosticOperators("heavy" if canonical else case,canonical,enabled=False)
        try:
            if canonical:
                with np.load(ROOT/"corrected-preparations.npz") as packet:
                    initial=packet[case+"_initial_16"].copy()
                    scale=packet["normalization"].copy()
                counts=(128,256)
            else:
                initial=operator.port.initial.copy()
                scale=operator.scale
                counts=(64,128)
            reports=[]
            fine_histories={}
            for enabled in (False,True):
                operator.enabled=enabled
                if operator.block is not None:
                    operator.block.enabled=enabled
                operator.cache.clear()
                operator.systems.clear()
                previous=None
                for steps in counts:
                    history=evolve(lambda stamp:operator.system(stamp)["matrix"],initial,operator.port.times,steps,scale)
                    refinement=None if previous is None else norm((history-previous)/scale)
                    name=case+"-"+("corrected" if enabled else "original")+"-"+str(steps)
                    np.savez_compressed(ROOT/(name+".npz"),history=history,normalization=scale,times=np.linspace(*operator.port.times,9),initial=initial)
                    diagnostics=[]
                    for index in (0,4,8) if steps==counts[0] else range(9):
                        fraction=index/8
                        for divisions in (16,32) if steps==counts[-1] else (16,):
                            jets=operator.jets_at(fraction,divisions)
                            metrics=defects(operator,jets,history[index])
                            sources=source_diagnostics(operator,jets,history[index])
                            diagnostics.append(dict(fraction=fraction,divisions=divisions,metrics=metrics,sources=sources))
                    row=dict(case=case,enabled=enabled,steps=steps,refinement=refinement,diagnostics=diagnostics,
                             metric_passed=all(row["metrics"]["metric_error"]<=GATE for row in diagnostics),
                             identity_passed=all(row["metrics"]["identity_error"]<=ALGEBRA for row in diagnostics))
                    write(name+".json",row)
                    reports.append(row)
                    print(json.dumps(dict(case=case,enabled=enabled,steps=steps,refinement=refinement,
                          maximum_metric_error=max(row["metrics"]["metric_error"] for row in diagnostics),
                          maximum_scalar_energy_error=max((row["metrics"].get("heavy_energy_error",0) for row in diagnostics)),
                          maximum_scalar_current_error=max((row["metrics"].get("heavy_current_error",0) for row in diagnostics)))),flush=True)
                    previous=history
                fine_histories[str(enabled)]=previous
            result=dict(case=case,numerical_passed=all(row["refinement"]<=GATE for row in reports if row["refinement"] is not None),
                        corrected_metric_passed=all(row["metric_passed"] for row in reports if row["enabled"]),
                        identities_passed=all(row["identity_passed"] for row in reports),
                        corrected_minus_original_state_norm=norm((fine_histories["True"]-fine_histories["False"])/scale),
                        reports=reports,code_sha256=digest(__file__),model_sha256=digest(ROOT/"radiation_model.py"),diagnostic_sha256=digest(ROOT/"diagnostic_model.py"),
                        frozen_initial_for_source_ablation=True,scope="nine trajectory probes with two derivative stencils; not a uniform enclosure")
            write("evolution-"+case+"-result.json",result)
            require(result["numerical_passed"] and result["identities_passed"],"integration and algebra controls")
        finally:
            operator.close()


if __name__=="__main__":
    main()
