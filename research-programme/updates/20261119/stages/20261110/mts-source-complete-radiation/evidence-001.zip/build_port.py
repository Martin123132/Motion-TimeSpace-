from common import *
import shutil
import subprocess


def main():
    with worker("build"):
        inputs = preserved()
        write("frozen-inputs.json", inputs)
        destination = ROOT/"build"
        package = destination/"native"
        package.mkdir(exist_ok=False)
        shutil.copytree(PORT/"build-v3/native/camb", package/"camb", ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.dll", "*.so"))
        shutil.copy2(NATIVE/"LICENCE.txt", package/"LICENCE.txt")
        (package/"fortran").mkdir()
        shutil.copy2(NATIVE/"fortran/HighLExtrapTemplate_lenspotentialCls.dat", package/"fortran/HighLExtrapTemplate_lenspotentialCls.dat")
        objects = sorted((NATIVE/"fortran/WinMTS").glob("*.o"))
        require(len(objects)>30, "retained object coverage")
        require({"equations.o", "camb_python.o"}.issubset({path.name.lower() for path in objects}), "replace only intended objects")
        preserved_objects = {str(path):digest(path) for path in objects}
        report = dict(state="running", processes=[], commands=[], original_objects=preserved_objects,
                      sources={name:digest(destination/name) for name in ("equations.f90", "camb_python.f90")})
        mappings = []
        try:
            for drive,target in (("T:", EARLY/"toolchain/mingw64"), ("R:", NATIVE), ("S:", destination)):
                require(not Path(drive+"/").exists(), "occupied mapping "+drive)
                subprocess.run(["subst", drive, str(target)], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
                mappings.append((drive, target))
            flags = ["-BT:/"+suffix+"/" for suffix in ("libexec/gcc/x86_64-w64-mingw32/14.2.0", "lib", "bin", "lib/gcc/x86_64-w64-mingw32/14.2.0", "x86_64-w64-mingw32/lib")]
            flags += ["-LT:/"+suffix+"/" for suffix in ("lib", "lib/gcc/x86_64-w64-mingw32/14.2.0", "x86_64-w64-mingw32/lib")]
            flags += ["-shared", "-static", "-cpp", "-fopenmp", "-O2", "-fcheck=bounds", "-fmax-errors=4", "-ffree-line-length-none"]
            commands = [["T:/bin/gfortran.exe", *flags, name+".f90", "-c", "-o", name+".o", "-JS:/", "-IS:/", "-IR:/fortran/WinMTS"] for name in ("equations", "camb_python")]
            linked = ["S:/"+path.name if path.name.lower() in ("equations.o", "camb_python.o") else "R:/fortran/WinMTS/"+path.name for path in objects]
            commands.append(["T:/bin/gfortran.exe", *flags, *linked, "-o", "S:/native/camb/cambdll.dll"])
            environment = dict(os.environ, PATH="T:/bin;"+os.environ["PATH"])
            with (destination/"compiler.log").open("x", encoding="utf-8") as log:
                for command in commands:
                    guard()
                    process = subprocess.Popen(command, cwd="S:/", env=environment, stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
                    owner = psutil.Process(process.pid)
                    identity = dict(pid=process.pid, created=owner.create_time(), command=owner.cmdline(), children=[])
                    report["processes"].append(identity)
                    report["commands"].append(command)
                    known = set()
                    while process.poll() is None:
                        for child in owner.children(recursive=True):
                            try:
                                key=(child.pid, child.create_time())
                                if key not in known:
                                    known.add(key)
                                    identity["children"].append(dict(pid=key[0], created=key[1], command=child.cmdline()))
                            except psutil.NoSuchProcess:
                                pass
                        time.sleep(.1)
                    identity["exit_code"] = process.wait()
                    require(identity["exit_code"]==0, "compiler failed; keep log")
            for path,expected in preserved_objects.items():
                require(digest(path)==expected, "original object changed")
            report.update(state="complete", dll_sha256=digest(package/"camb/cambdll.dll"))
        except BaseException as error:
            report.update(state="failed", error=repr(error))
            raise
        finally:
            unmapped=[]
            for drive,target in reversed(mappings):
                inventory=subprocess.check_output(["subst"], text=True)
                owned=any(line.lower().startswith(drive.lower()+"\\:") and line.split("=>",1)[-1].strip().lower()==str(target).lower() for line in inventory.splitlines())
                require(owned, "mapping ownership changed; do not remove "+drive)
                subprocess.run(["subst", drive, "/D"], check=True, creationflags=subprocess.CREATE_NO_WINDOW)
                unmapped.append(drive)
            report["temporary_mappings_removed"] = len(unmapped)==len(mappings)
            write("build-result.json", report)
        print(json.dumps(dict(state=report["state"], mappings_removed=report["temporary_mappings_removed"])))


if __name__ == "__main__":
    main()
