from common import *
from validate_stage import exited, identities


def main():
    with worker("seal"):
        validation = read(ROOT / "validation.json")
        summary = read(ROOT / "evolution-summary.json")
        require(validation["passed"], "implementation and provenance validation")
        require(summary["corrected_metric_gate_passed"], "sampled corrected metric gate")
        require(not summary["all_individual_radiation_gates_passed"], "retain individual radiation qualification")
        inputs = preserved()
        require(inputs == read(ROOT / "frozen-inputs.json"), "unchanged inputs at seal")
        for name in ("RESULTS.md", "NEXT.md", "DERIVATION.md", "PROTOCOL.md"):
            require((ROOT / name).is_file(), "missing documentation " + name)
        workers = []
        for name, identity in identities():
            if name == "seal-start.json":
                continue
            status = exited(identity)
            require(status["exited"], "task identity still live: " + name)
            workers.append(dict(receipt=name, identity=identity, status=status))
        require(not list(ROOT.rglob("__pycache__")), "no bytecode")
    artifacts = {}
    for path in sorted(ROOT.rglob("*")):
        if path.is_file():
            require(path.name != "closeout.json", "refuse reseal")
            artifacts[path.relative_to(ROOT).as_posix()] = dict(sha256=digest(path), bytes=path.stat().st_size)
    write("closeout.json", dict(state="verified_progress_with_source_complete_leading_radiation", goal_complete=False,
          utc=datetime.now(timezone.utc).isoformat(), input_hashes=inputs, artifacts=artifacts, workers=workers,
          verified=["action-stress-derived leading radiation correction", "consistent native gravity and baryon source injection",
                    "live corrected canonical preparation", "paired forward evolution and time-step refinement",
                    "independently differentiated metric gate at nine probes"],
          unresolved=["individual radiation-rate errors", "higher RSA/time/opacity orders and derivative conditioning",
                      "historical full-span archive discrepancy", "formation-selected local wave occupation"],
          source_repair_applied=True, new_fitted_parameters=0,
          qualification="The metric gate passes on the sampled short window. Individual radiation-rate failures remain explicit in MTS and cold control. No uniform enclosure or observational gain is claimed.",
          next="NEXT.md", cleanup="Post-seal process exit and hashes must be checked separately."))
    print(json.dumps(dict(seal_sha256=digest(ROOT / "closeout.json"), inputs=len(inputs), artifacts=len(artifacts), validation_checks=len(validation["checks"]))))


if __name__ == "__main__":
    main()
