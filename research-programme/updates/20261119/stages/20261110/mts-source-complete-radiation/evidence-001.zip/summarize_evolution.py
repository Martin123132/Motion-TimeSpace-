from common import *
import csv


CASES = ("heavy", "cold", "D0", "D01")


def summarize(report):
    rows = []
    for enabled in (False, True):
        fine = max((entry for entry in report["reports"] if entry["enabled"] == enabled), key=lambda entry: entry["steps"])
        samples = fine["diagnostics"]
        row = dict(case=report["case"], enabled=enabled, steps=fine["steps"], refinement=fine["refinement"],
                   maximum_metric_error=max(sample["metrics"]["metric_error"] for sample in samples),
                   maximum_constraint_error=max(sample["metrics"]["constraint_error"] for sample in samples),
                   maximum_identity_error=max(sample["metrics"]["identity_error"] for sample in samples),
                   maximum_absolute_total_budget=max(abs(sample["metrics"]["total_budget"]) for sample in samples))
        if report["case"] in ("D0", "D01"):
            for name in ("heavy_energy_error", "heavy_current_error"):
                row["maximum_" + name] = max(sample["metrics"][name] for sample in samples)
        row["radiation"] = {}
        for species in ("gamma", "massless"):
            values = [sample["sources"]["radiation"][species] for sample in samples]
            data = {"maximum_" + name: max(abs(value[name]) for value in values) for name in
                    ("energy_residual", "current_residual_after_exchange", "energy_error", "current_error", "constraint_budget")}
            for name in ("energy_residual", "current_residual_after_exchange"):
                by_fraction = {}
                for sample in samples:
                    by_fraction.setdefault(sample["fraction"], {})[sample["divisions"]] = sample["sources"]["radiation"][species][name]
                data["maximum_stencil_difference_" + name] = max(abs(pair[32] - pair[16]) for pair in by_fraction.values())
            data["energy_gate_passed"] = data["maximum_energy_error"] <= GATE
            data["current_gate_passed"] = data["maximum_current_error"] <= GATE
            row["radiation"][species] = data
        row["metric_gate_passed"] = row["maximum_metric_error"] <= GATE
        row["individual_radiation_gates_passed"] = all(data["energy_gate_passed"] and data["current_gate_passed"] for data in row["radiation"].values())
        rows.append(row)
    return rows


def main():
    with worker("summary"):
        rows = []
        inputs = {}
        state_changes = {}
        for case in CASES:
            path = ROOT / ("evolution-" + case + "-result.json")
            report = read(path)
            inputs[path.name] = digest(path)
            rows.extend(summarize(report))
            state_changes[case] = report["corrected_minus_original_state_norm"]
        result = dict(rows=rows, gate=GATE, algebra_gate=ALGEBRA, input_hashes=inputs,
                      source_repair_applied=True, new_fitted_parameters=0,
                      corrected_metric_gate_passed=all(row["metric_gate_passed"] for row in rows if row["enabled"]),
                      all_individual_radiation_gates_passed=all(row["individual_radiation_gates_passed"] for row in rows if row["enabled"]),
                      state_changes=state_changes, state_change_units="frozen component-normalized state norm, not observational percent or integration error",
                      derivative_comparison="16/32 one-sided or centered stencils; their difference is a sensitivity diagnostic, not a certified error bound",
                      scope="same short k=5/Mpc, z=10 window; nine trajectory probes, not a uniform enclosure or a new data fit",
                      code_sha256=digest(__file__))
        write("evolution-summary.json", result)
        fields = ["case", "enabled", "species", "maximum_metric_error", "refinement", "maximum_energy_error", "maximum_current_error",
                  "maximum_energy_residual", "maximum_current_residual_after_exchange", "maximum_constraint_budget",
                  "maximum_stencil_difference_energy_residual", "maximum_stencil_difference_current_residual_after_exchange",
                  "energy_gate_passed", "current_gate_passed"]
        with (ROOT / "radiation-error-budget.csv").open("x", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=fields)
            writer.writeheader()
            for row in rows:
                for species, data in row["radiation"].items():
                    output = {name: row[name] for name in ("case", "enabled", "maximum_metric_error", "refinement")}
                    output.update(species=species)
                    output.update({name: data[name] for name in fields if name in data})
                    writer.writerow(output)
        print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
