from common import *
from bridge_imports import NativePort, CanonicalBlock, action_model, Operators
import numpy as np


def scalar_indices(port):
    field=int(port.reference["signature"][2])
    mapping=port.reference["mapping"]
    return np.array([int(np.flatnonzero(mapping==field+offset)[0]) for offset in (0, 1)])


def slow_stress(port, observer):
    indices=scalar_indices(port)
    density=np.zeros(port.dimension)
    density[indices]=observer[port.columns["D_sync"], indices]
    pressure=density.copy()
    pressure[indices[0]] *= -1
    return density, pressure


def pressure_clock(block, scale_factor):
    mass,hubble=action_model.background_series(block.case, float(np.log(scale_factor)+np.log(11.)))
    total_pressure=-2*hubble*hubble.derivative()-hubble**2
    carrier_shift=3*total_pressure/(8*mass)
    carrier=mass+carrier_shift
    slope=-hubble*carrier.derivative()/(2*carrier)
    pressure_numerator=(slope-hubble)**2+carrier_shift*(2*mass+carrier_shift)
    scale_series=mass/block.port.mass
    pressure=block.initial_rho/block.initial_weight*pressure_numerator/(scale_series**2*carrier)
    beta=hubble*pressure.derivative()-2*hubble*pressure
    return float(pressure.value[0]), float(beta.value[0])


def corrected_system(port, stamp, block=None, base=None, enabled=True):
    require(np.array_equal(port.reference["signature"][[13, 14, 16, 17]], [1, 1, 0, 0]), "supported late RSA/thermal regime")
    if base is None:
        background,observer=port.observer_matrix(stamp)
    else:
        background,observer=base["background"],base["observer"]
    hubble=background[port.columns["H_native"]]
    scale_factor=background[port.columns["a_native"]]
    gamma=background[port.columns["R_gamma"]]
    massless=background[port.columns["R_massless"]]
    opacity=float(port.native.get_background_time_evolution(np.array([stamp]), vars=["opacity"])["opacity"][0])
    gains,output_gains=port.radiation_columns(stamp)
    slow_density,slow_pressure=slow_stress(port, observer)
    wave=port.wave
    radiation=gamma+massless
    density_weight=4*radiation/wave**2-2*gamma*opacity/(wave**2*hubble)
    pressure_weight=6*radiation/wave**2
    current_weight=-2*radiation/(3*wave*hubble)
    beta,mean_pressure=0.,0.
    if block is not None:
        mapping=base["mapping"].copy()
        enthalpy=base["enthalpy"]
        eta=base["eta"]
        density=slow_density@mapping+base["rho"]*base["density_star"]+3*enthalpy*eta
        mean_pressure,beta=pressure_clock(block, scale_factor)
        pressure_fixed=slow_pressure@mapping+base["rho"]*(base["pressure"]-3*base["coefficients"]["enthalpy_ratio"]*base["potential"])-beta*eta/hubble
        pressure_feedback=3*enthalpy+beta/hubble
        old_denominator=2*wave**2+3*enthalpy
        numerator=-old_denominator*base["potential"]
    else:
        mapping=np.eye(port.dimension)
        enthalpy=0.
        eta=observer[port.columns["eta_sync"]]
        density=slow_density.copy()
        pressure_fixed=slow_pressure.copy()
        if port.label=="heavy":
            rho=port.matching_density/scale_factor
            density[port.selected[0]] += rho
            ratio=(wave/(port.mass*scale_factor))**2
            sound=ratio/(np.sqrt(1+ratio)+1)**2
            pressure_fixed[port.selected[0]] += rho*sound
            pressure_fixed[port.selected[1]] += rho*sound*3*hubble/wave
        pressure_feedback=0.
        old_denominator=2*wave**2
        numerator=observer[port.columns["D_sync"]]+3*hubble*observer[port.columns["Q_sync"]]/wave
    addition=density_weight*density+pressure_weight*pressure_fixed+3*hubble*current_weight*density/wave
    denominator=old_denominator+int(enabled)*pressure_weight*pressure_feedback
    require(denominator>0, "positive corrected constraint denominator")
    potential=-(numerator+int(enabled)*addition)/denominator
    alpha=(eta-potential)/hubble
    synchronous_pressure=pressure_fixed+pressure_feedback*potential
    scalar_density=density
    delta_massless=int(enabled)*(4*density+6*synchronous_pressure)/wave**2
    delta_gamma=delta_massless-int(enabled)*2*opacity*density/(wave**2*hubble)
    delta_current=-int(enabled)*2*density/(3*wave*hubble)
    increments=np.array([delta_gamma,delta_current,delta_massless,delta_current])
    if block is not None:
        difference=potential-base["potential"]
        current_image=enthalpy*wave/(base["native_rho"]*hubble)*difference
        mapping[port.selected[1]] += current_image
        matrix=base["matrix"].copy()
        probe=np.zeros(port.dimension)
        probe[port.selected[1]]=1
        matrix[:len(port.remaining)] += np.outer(port.rhs(stamp,probe)[port.remaining],current_image)+gains[port.remaining]@increments
        coefficients=base["coefficients"]
        combined_delta=4*difference
        first=coefficients["physical0"]*combined_delta
        second=(coefficients["hubble"]-coefficients["lambdak"])*coefficients["physical0"]*combined_delta+2*coefficients["mass"]**2*difference
        matrix[-4] += first.real
        matrix[-3] += first.imag
        matrix[-2] += second.real
        matrix[-1] += second.imag
    else:
        matrix=port.matrix(stamp)+gains@increments
    full_observer=observer@mapping+output_gains@increments
    anisotropy=full_observer[port.columns["Pi"]]
    lapse=potential-anisotropy/wave**2
    result=dict(matrix=matrix,mapping=mapping,observer=observer,background=background,full_observer=full_observer,
                potential=potential,lapse=lapse,alpha=alpha,eta=eta,hubble=hubble,scale_factor=scale_factor,
                increments=increments,gains=gains,output_gains=output_gains,opacity=opacity,
                missing_density=scalar_density,missing_pressure=synchronous_pressure,denominator=denominator,
                heavy_mean_pressure=mean_pressure,pressure_clock_beta=beta)
    if block is not None:
        result.update({name:base[name] for name in ("coefficients","rho","enthalpy","native_rho","density_star","current")})
        result["density"]=base["density"]+3*coefficients["enthalpy_ratio"]*difference
        result["pressure"]=base["pressure"]+3*coefficients["enthalpy_ratio"]*difference
    return result


class RadiationBlock(CanonicalBlock):
    def __init__(self, port, enabled=True):
        super().__init__(port)
        self.enabled=enabled

    def system(self, stamp):
        base=super().system(stamp)
        return corrected_system(self.port,stamp,block=self,base=base,enabled=self.enabled)


class RadiationOperators(Operators):
    def __init__(self,label,canonical=False,enabled=True):
        self.port=NativePort(label)
        self.block=RadiationBlock(self.port,enabled) if canonical else None
        self.enabled=enabled
        self.cache={}
        self.systems={}
        self.span=float(self.port.times[-1]-self.port.times[0])
        if canonical:
            with np.load(PREVIOUS/"canonical-initial.npz") as packet:
                self.scale=packet["normalization"].copy()
        else:
            self.scale=self.port.scale.copy()

    def system(self,stamp):
        return self.block.system(stamp) if self.block is not None else corrected_system(self.port,stamp,enabled=self.enabled)

    def sample(self,fraction):
        guard()
        require(0<=fraction<=1,"inside captured regime")
        if fraction in self.cache:
            return self.cache[fraction]
        port=self.port
        stamp=float(port.times[0]+fraction*self.span) if fraction!=1 else float(port.times[-1])
        system=self.system(stamp)
        self.systems[fraction]=system
        background,observer=system["background"],system["full_observer"]
        hubble=system["hubble"]
        enthalpy=background[port.columns["R"]]+background[port.columns["Pbar"]]
        if self.block is not None:
            enthalpy+=system["enthalpy"]-system["native_rho"]
        alpha=system["alpha"]
        result=dict(matrix=system["matrix"],phi=system["potential"],psi=system["lapse"],combined=3*system["potential"]+system["lapse"],
                    density=observer[port.columns["D_sync"]]-3*hubble*enthalpy*alpha,
                    current=observer[port.columns["Q_sync"]]+enthalpy*port.wave*alpha,
                    anisotropy=observer[port.columns["Pi"]],hubble=np.array(hubble),enthalpy=np.array(enthalpy),
                    scale_factor=np.array(system["scale_factor"]))
        if self.block is not None:
            result.update(heavy_density=system["rho"]*system["density"],heavy_current=system["rho"]*system["current"],
                          heavy_pressure=system["rho"]*system["pressure"],heavy_enthalpy=np.array(system["enthalpy"]))
        else:
            result.update(heavy_density=np.zeros(port.dimension),heavy_current=np.zeros(port.dimension),
                          heavy_pressure=np.zeros(port.dimension),heavy_enthalpy=np.array(0.))
        self.cache[fraction]=result
        return result
