from common import *
from model import *


def main():
    with worker("continuity"):
        with np.load(ROOT / "transport.npz") as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        with np.load(ROOT / "dressing.npz") as archive:
            dressed = archive["final_source"].copy()
        arrays, reports = {}, []
        for name in ("heavy", "cold"):
            case = Case(name)
            velocity_curve = CubicSpline(case.history["original_offsets"], case.history["current"].T, axis=0)
            pressure_values = case.history["pressure"] if name == "heavy" else np.zeros_like(case.history["current"])
            pressure_curve = CubicSpline(case.history["original_offsets"], pressure_values.T, axis=0)
            mass_initial = case.mass * np.exp(CENTER)
            mass_final = mass_initial * np.exp(SPAN)
            initial_density = case.history["density"][:, 3]
            initial_phase = -mass_initial * case.history["current"][:, 3] / case.wave
            native = np.column_stack((case.history["density"][:, 4], -mass_final * case.history["current"][:, 4] / case.wave))
            scale = saved["normalizer"] if name == "heavy" else np.column_stack((saved["cold_scale"][:, 0], mass_final * saved["cold_scale"][:, 1] / case.wave))
            endpoints, fluxes = [], []
            for order in (8, 16, 32):
                nodes, weights = leggauss(order)
                positions = (nodes + 1) * SPAN / 2
                mass, hubble, *_ = case.jets(positions)
                velocity, pressure = velocity_curve(positions), pressure_curve(positions)
                lapse = case.metrics["full"](positions)[..., 1]
                weights = weights * SPAN / 2
                density_velocity = np.einsum("t,tn->n", weights, -case.wave[None, :] * velocity / hubble[:, None])
                density_pressure = np.einsum("t,tn->n", weights, -3 * pressure)
                density_metric = 3 * (case.metrics["full"](SPAN)[:, 0] - case.metrics["full"](0)[:, 0])
                phase_force = np.einsum("t,tn->n", weights, -mass[:, None] * (lapse + pressure) / hubble[:, None])
                endpoints.append(np.column_stack((initial_density + density_velocity + density_pressure + density_metric, initial_phase + phase_force)))
                fluxes.append(np.column_stack((density_velocity, density_pressure, density_metric, phase_force)))
            signed_errors = (endpoints[-1] - native) / scale
            refinements = [float(np.max(abs((endpoints[index + 1] - endpoints[index]) / scale))) for index in (0, 1)]
            failed = np.flatnonzero(np.max(abs(signed_errors), axis=1) > GATE)
            rows = [dict(wave=float(case.wave[index]), density_residual=float(signed_errors[index, 0]), current_residual=float(signed_errors[index, 1])) for index in failed]
            report = dict(model=name, all399modes=True, refinements=refinements, implementation_passed=all(value <= GATE for value in refinements),
                          density_max=float(np.max(abs(signed_errors[:, 0]))), current_max=float(np.max(abs(signed_errors[:, 1]))),
                          continuity_passed=bool(np.max(abs(signed_errors)) <= GATE), failing_modes=len(failed), failures=rows)
            if name == "heavy":
                microscopic_residual = (dressed[:, :2] - native) / scale
                discrepancy_difference = microscopic_residual - signed_errors
                report["microscopic_minus_native_integral_density_max"] = float(np.max(abs(discrepancy_difference[:, 0])))
                report["microscopic_minus_native_integral_current_max"] = float(np.max(abs(discrepancy_difference[:, 1])))
                arrays["heavy_residual_difference"] = discrepancy_difference
            reports.append(report)
            arrays.update({name + "_" + key: value for key, value in dict(wave=case.wave, native=native, predicted=endpoints[-1], signed_errors=signed_errors, fluxes=fluxes[-1], scale=scale).items()})
        np.savez_compressed(ROOT / "continuity.npz", **arrays)
        result = dict(implementation_passed=all(row["implementation_passed"] for row in reports), models=reports,
                      diagnostic_only=True, establishes_native_code_fault=False, tolerances_unchanged=True,
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "model.py"), common_sha256=digest(ROOT / "common.py"),
                      contract_sha256=digest(ROOT / "CONTINUITY-CONTRACT.md"), primary_sha256=digest(ROOT / "transport-result.json"),
                      dressing_sha256=digest(ROOT / "dressing-result.json"), output_sha256=digest(ROOT / "continuity.npz"))
        write("continuity-result.json", result)
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
