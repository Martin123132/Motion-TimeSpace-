from common import *
from model import *
from scipy.integrate import solve_ivp


def main():
    with worker("direct-low"):
        with np.load(ROOT / "transport.npz") as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        with np.load(ROOT / "dressing.npz") as archive:
            prepared = archive["initial"].copy()
        with np.load(ROOT / "phase-full.npz") as archive:
            reference = archive["dressed_final8192"].copy()
            reference_source = archive["dressed_source8192"].copy()
        indices = np.array([int(np.argmax(np.max(saved["native_errors"][:, :2], axis=1)))])
        case = Case("heavy", indices)
        scales = saved["microscopic_scale"][indices]
        start = normalized(case, prepared[indices], scales, 0)
        expected = normalized(case, reference[indices], scales, SPAN)
        mass_initial = case.mass * np.exp(CENTER)
        evaluations = 0

        def rhs(position, flattened):
            nonlocal evaluations
            evaluations += 1
            if evaluations % 128 == 0:
                guard()
            values = flattened.reshape(start.shape)
            mass, hubble, first, *_ = case.jets(position)
            potentials = case.metrics["full"](position)
            slopes = case.metrics["full"](position, 1)
            combined_s = (slopes[:, 1] + 3 * slopes[:, 0])[:, None]
            lapse = potentials[:, 1, None]
            carrier_omega = mass**2 - first - hubble**2
            result = np.empty_like(values)
            result[..., 0] = mass_initial / hubble * values[..., 1]
            result[..., 1] = -carrier_omega / (hubble * mass_initial) * values[..., 0]
            result[..., 2] = mass_initial / hubble * values[..., 3]
            result[..., 3] = -(carrier_omega + case.wave[:, None]**2) / (hubble * mass_initial) * values[..., 2]
            result[..., 3] += combined_s / scales[:, None] * (values[..., 1] - hubble / mass_initial * values[..., 0]) - 2 * lapse * mass**2 / (hubble * mass_initial * scales[:, None]) * values[..., 0]
            return result.ravel()

        finals, reports = [], []
        for tolerance in (2e-11, 2e-12):
            began = time.monotonic()
            solution = solve_ivp(rhs, (0, SPAN), start.ravel(), method="DOP853", rtol=tolerance, atol=tolerance / 100, t_eval=[SPAN])
            if not solution.success:
                raise ValueError(solution.message)
            final = solution.y[:, -1].reshape(start.shape)
            finals.append(final)
            field_error = float(np.max(abs(final - expected)))
            physical_values = final.transpose(0, 2, 1).copy()
            physical_values[:, 0, :] /= np.sqrt(mass_initial)
            physical_values[:, 1, :] *= np.sqrt(mass_initial)
            physical_values[:, 2, :] *= (scales / np.sqrt(mass_initial))[:, None]
            physical_values[:, 3, :] *= (scales * np.sqrt(mass_initial))[:, None]
            hubble = case.jets(SPAN)[1]
            potentials = case.metrics["full"](SPAN)
            canonical = physical_values.copy()
            canonical[:, 3, :] -= (potentials[:, 1] + 3 * potentials[:, 0])[:, None] * (canonical[:, 1, :] - hubble * canonical[:, 0, :])
            sources_final = stress(case, canonical, SPAN)
            source_errors = abs((sources_final - reference_source[indices]) / saved["normalizer"][indices][:, [0, 1, 0]])[0]
            reports.append(dict(tolerance=tolerance, evaluations=solution.nfev, elapsed=time.monotonic() - began,
                                field_error=field_error, source_errors=source_errors.tolist(),
                                passed=bool(field_error <= GATE and np.max(source_errors) <= GATE)))
            print(json.dumps(reports[-1]), flush=True)
        refinement = float(np.max(abs(finals[0] - finals[1])))
        np.savez_compressed(ROOT / "direct-low.npz", indices=indices, expected=expected, coarse=finals[0], fine=finals[1])
        result = dict(passed=all(row["passed"] for row in reports) and refinement <= GATE,
                      wave=float(case.wave[0]), reports=reports, refinement=refinement,
                      post_diagnosis_regression_not_holdout=True, physical_equation_not_transport_basis=True,
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "model.py"), common_sha256=digest(ROOT / "common.py"),
                      contract_sha256=digest(ROOT / "LOW-K-DIRECT-CONTRACT.md"), repaired_sha256=digest(ROOT / "phase-full-result.json"),
                      output_sha256=digest(ROOT / "direct-low.npz"))
        write("direct-low-result.json", result)
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
