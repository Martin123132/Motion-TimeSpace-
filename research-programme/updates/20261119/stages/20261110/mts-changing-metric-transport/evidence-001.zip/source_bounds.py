from common import *
from model import Case
from fractions import Fraction
import sympy as sym
import numpy as np


def rational(value):
    return Fraction(float(value))


def spline_basis():
    nodes = [-4, -2, -1, 0, 1, 2, 4]
    matrix = sym.zeros(24, 24)
    targets = sym.zeros(24, 7)
    row = 0
    for segment in range(6):
        width = nodes[segment + 1] - nodes[segment]
        matrix[row, 4 * segment + 3] = 1
        targets[row, segment] = 1
        row += 1
        for coefficient, value in enumerate((width**3, width**2, width, 1)):
            matrix[row, 4 * segment + coefficient] = value
        targets[row, segment + 1] = 1
        row += 1
    for segment in range(5):
        width = nodes[segment + 1] - nodes[segment]
        for coefficient, value in enumerate((3 * width**2, 2 * width, 1, 0)):
            matrix[row, 4 * segment + coefficient] = value
        matrix[row, 4 * (segment + 1) + 2] = -1
        row += 1
        matrix[row, 4 * segment], matrix[row, 4 * segment + 1] = 6 * width, 2
        matrix[row, 4 * (segment + 1) + 1] = -2
        row += 1
    matrix[row, 0], matrix[row, 4] = 1, -1
    row += 1
    matrix[row, 16], matrix[row, 20] = 1, -1
    solution = matrix.inv() * targets
    if matrix * solution != targets:
        raise ValueError("exact not-a-knot interpolation identity")
    selected = solution[12:16, :]
    return [[Fraction(int(selected[power, node].p), int(selected[power, node].q)) for node in range(7)] for power in range(4)]


def exact_ulp(value):
    single = np.float32(value)
    if float(single) != float(value):
        raise ValueError("transfer not exactly represented float32")
    upper = rational(np.nextafter(single, np.float32(np.inf))) - rational(single)
    lower = rational(single) - rational(np.nextafter(single, np.float32(-np.inf)))
    return max(upper, lower) / 2


def input_radii(case, mode):
    raw, names = case.history["raw_values"][mode], case.history["raw_names"].tolist()
    wave = rational(case.wave[mode])
    result = []
    for epoch in range(7):
        hubble = rational(raw[epoch, names.index("H")])
        velocity = raw[epoch, names.index("v_newtonian_cdm")]
        weyl = raw[epoch, names.index("Weyl")]
        etak = rational(raw[epoch, names.index("etak")])
        alpha = -hubble * rational(velocity) / wave**2
        potential = etak / wave - hubble * alpha
        lapse = 2 * rational(weyl) / wave**2 - potential
        shared = hubble**2 * exact_ulp(velocity) / wave**2
        potential_error = shared + abs(potential - rational(case.history["potential"][mode, epoch]))
        lapse_error = shared + 2 * exact_ulp(weyl) / wave**2 + abs(lapse - rational(case.history["lapse"][mode, epoch]))
        result.append((potential_error, lapse_error))
    return result


def main():
    with worker("source-bound"):
        bound = read(ROOT / "background-bound.json")
        basis = spline_basis()
        basis_absolute = [sum(abs(basis[power][node]) for power in range(4)) for node in range(7)]
        case = Case("heavy")
        span = rational(SPAN)
        if [rational(value) / span for value in case.history["original_offsets"]] != list(map(Fraction, [-4, -2, -1, 0, 1, 2, 4])):
            raise ValueError("source knot geometry differs")
        coefficients = case.metrics["full"].c[:, 3, :, :]
        certificate = bound["models"][0]
        coefficient_c = Fraction(certificate["J_coefficient_C_upper"])
        coefficient_d = Fraction(certificate["J_coefficient_D_upper"])
        exponent = Fraction(certificate["exponent_upper"])
        error_factor = Fraction(certificate["forced_error_factor_upper"])
        rows = []
        for mode in range(399):
            guard()
            actual = [[rational(coefficients[power, mode, field]) * span**(3 - power) for power in range(4)] for field in range(2)]
            knot_values = [[rational(case.history[name][mode, epoch]) for epoch in range(7)] for name in ("potential", "lapse")]
            ideal = [[sum(basis[power][node] * knot_values[field][node] for node in range(7)) for power in range(4)] for field in range(2)]
            coefficient_error = [sum(abs(actual[field][power] - ideal[field][power]) for power in range(4)) for field in range(2)]
            radii = input_radii(case, mode)
            source_error = [sum(basis_absolute[node] * radii[node][field] for node in range(7)) + coefficient_error[field] for field in range(2)]
            combined = sum(abs(actual[1][power] + 3 * actual[0][power]) for power in range(4))
            difference = sum(abs(3 * actual[0][power] - actual[1][power]) for power in range(4))
            integral_bound = coefficient_c * combined + coefficient_d * difference
            radius = (coefficient_c + coefficient_d) * (source_error[1] + 3 * source_error[0]) / (1 - 2 * exponent)
            truncation = error_factor * integral_bound
            rows.append(dict(wave=float(case.wave[mode]), J_exact=str(integral_bound), forced_truncation_per_c0_exact=str(truncation),
                             source_rounding_per_c0_exact=str(radius), potential_radius_exact=str(source_error[0]), lapse_radius_exact=str(source_error[1]),
                             J=float(integral_bound), forced_truncation_per_c0=float(truncation), source_rounding_per_c0=float(radius)))
        np.savez_compressed(ROOT / "source-polynomials.npz", coefficients=coefficients, offsets=case.history["original_offsets"], wave=case.wave)
        result = dict(passed=True, exact_spline_basis=[[str(value) for value in row] for row in basis], rows=rows,
                      maximum_J=max(row["J"] for row in rows), maximum_forced_truncation=max(row["forced_truncation_per_c0"] for row in rows),
                      maximum_source_rounding=max(row["source_rounding_per_c0"] for row in rows),
                      scope="exact stored source polynomial; float32 Vcdm/Weyl quantization plus geometry/coefficient assembly error",
                      excludes=["initial-state uncertainty", "true source-history interpolation error", "native integration error", "background model uncertainty", "runtime evaluation rounding"],
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "model.py"), common_sha256=digest(ROOT / "common.py"),
                      bound_sha256=digest(ROOT / "background-bound.json"), output_sha256=digest(ROOT / "source-polynomials.npz"))
        write("source-bound.json", result)
        print(json.dumps({key: result[key] for key in ("maximum_J", "maximum_forced_truncation", "maximum_source_rounding")}))


if __name__ == "__main__":
    main()
