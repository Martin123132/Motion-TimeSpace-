from common import *
from model import *
from scipy.integrate import solve_ivp


def template_scaled(values, mass):
    result = values.copy()
    result[..., 0, :] *= np.sqrt(mass)[..., None]
    result[..., 1, :] /= np.sqrt(mass)[..., None]
    return result


def main():
    with worker("interpolation"):
        with np.load(ROOT / "transport.npz") as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        checks = []

        def check(name, error):
            checks.append(dict(name=name, error=float(error), gate=GATE, passed=bool(np.isfinite(error) and error <= GATE)))

        positions = np.linspace(0, SPAN, 65)
        for name in ("heavy", "cold"):
            case, coarse = Case(name), Case(name, stride=2)
            state_scale = np.maximum(np.max(abs(case.state_spline(positions)), axis=0), 1e-100)
            check(name + " background 17 versus33 saved points", np.max(abs((coarse.state_spline(positions) - case.state_spline(positions)) / state_scale)))
            jets, coarse_jets = np.array(case.jets(positions)), np.array(coarse.jets(positions))
            check(name + " pressure jets17 versus33", np.max(abs(jets - coarse_jets) / np.maximum(np.max(abs(jets), axis=1), 1e-100)[:, None]))
            if name == "heavy":
                templates = {order: case.templates(positions, order) for order in (8, 16, 32)}
                for lower, higher in ((8, 16), (16, 32)):
                    carrier_error = np.max(abs(template_scaled(templates[lower][0] - templates[higher][0], jets[0])))
                    sideband_error = np.max(abs(template_scaled(templates[lower][1] - templates[higher][1], jets[0][:, None])))
                    check("carrier phase order " + str((lower, higher)), carrier_error)
                    check("sideband phase order " + str((lower, higher)), sideband_error)
        indices = np.array([int(np.argmin(abs(saved["wave"] - target))) for target in (.03, .1, 1., 5.)])
        case = Case("heavy", indices, stride=2)
        result = integrate(case, 8192, phase_order=32)["full"]
        final = propagate(case, saved["initial"][indices], result)
        source = stress(case, final, SPAN)
        check("four physical modes:17point background and32phase forcing", np.max(abs((source - saved["source8192"][indices]) / saved["normalizer"][indices][:, [0, 1, 0]])))
        check("four physical modes:normalized fields", np.max(abs(normalized(case, final, saved["microscopic_scale"][indices], SPAN) - normalized(case, saved["final8192"][indices], saved["microscopic_scale"][indices], SPAN))))
        cold = Case("cold", stride=2)
        initial = np.column_stack((cold.history["density"][:, 3] - 3 * cold.metrics["full"](0)[:, 0], cold.history["current"][:, 3]))
        scale = saved["cold_scale"]

        def rhs(position, flattened):
            guard()
            values = flattened.reshape(399, 2) * scale
            hubble = cold.jets(position)[1]
            lapse = cold.metrics["full"](position)[:, 1]
            return (np.column_stack((-cold.wave * values[:, 1] / hubble, -values[:, 1] + cold.wave * lapse / hubble)) / scale).ravel()

        solution = solve_ivp(rhs, (0, SPAN), (initial / scale).ravel(), method="DOP853", rtol=2e-12, atol=2e-14, t_eval=[SPAN])
        if not solution.success:
            raise ValueError(solution.message)
        cold_final = solution.y[:, -1].reshape(399, 2) * scale
        cold_final[:, 0] += 3 * cold.metrics["full"](SPAN)[:, 0]
        check("cold physical Euler with17point background", np.max(abs((cold_final - saved["cold_final"]) / scale)))
        np.savez_compressed(ROOT / "interpolation.npz", indices=indices, positions=positions, final=final, source=source, cold_final=cold_final)
        report = dict(passed=all(row["passed"] for row in checks), checks=checks,
                      scope="sampled template/jet controls all399modes; integrated background control four preselected heavy modes and all399cold modes; not an interval proof of interpolation error",
                      code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"), model_sha256=digest(ROOT / "model.py"),
                      primary_sha256=digest(ROOT / "transport-result.json"), output_sha256=digest(ROOT / "interpolation.npz"))
        write("interpolation-result.json", report)
        print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
