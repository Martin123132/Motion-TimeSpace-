from common import *
from model import *
from scipy.integrate import solve_ivp
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("group", choices=("pilot", "remaining"))
    arguments = parser.parse_args()
    with worker("direct-" + arguments.group):
        with np.load(ROOT / "transport.npz") as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        targets = (.03,) if arguments.group == "pilot" else (.1, 1., 5.)
        indices = np.array([int(np.argmin(abs(saved["wave"] - target))) for target in targets])
        case = Case("heavy", indices)
        initial, scales = saved["initial"][indices], saved["microscopic_scale"][indices]
        start = normalized(case, initial, scales, 0)
        expected = normalized(case, saved["final8192"][indices], scales, SPAN)
        mass_initial = case.mass * np.exp(CENTER)
        steps = 0

        def rhs(position, flattened):
            nonlocal steps
            steps += 1
            if steps % 128 == 0:
                guard()
            values = flattened.reshape(start.shape)
            mass, hubble, first, *_ = case.jets(position)
            potentials = case.metrics["full"](position)
            slopes = case.metrics["full"](position, 1)
            combined_prime = (slopes[:, 1] + 3 * slopes[:, 0])[:, None]
            lapse = potentials[:, 1, None]
            carrier_omega = mass**2 - first - hubble**2
            result = np.empty_like(values)
            result[..., 0] = mass_initial / hubble * values[..., 1]
            result[..., 1] = -carrier_omega / (hubble * mass_initial) * values[..., 0]
            result[..., 2] = mass_initial / hubble * values[..., 3]
            result[..., 3] = -(carrier_omega + case.wave[:, None]**2) / (hubble * mass_initial) * values[..., 2]
            result[..., 3] += combined_prime / scales[:, None] * (values[..., 1] - hubble / mass_initial * values[..., 0]) - 2 * lapse * mass**2 / (hubble * mass_initial * scales[:, None]) * values[..., 0]
            return result.ravel()

        finals, rows = [], []
        for tolerance in (2e-11, 2e-12):
            guard()
            started = time.monotonic()
            solution = solve_ivp(rhs, (0, SPAN), start.ravel(), method="DOP853", rtol=tolerance,
                                 atol=tolerance / 100, t_eval=[SPAN])
            if not solution.success:
                raise ValueError(solution.message)
            final = solution.y[:, -1].reshape(start.shape)
            finals.append(final)
            error = np.max(abs(final - expected), axis=(1, 2))
            physical_values = final.transpose(0, 2, 1).copy()
            physical_values[:, 0, :] /= np.sqrt(mass_initial)
            physical_values[:, 1, :] *= np.sqrt(mass_initial)
            physical_values[:, 2, :] *= (scales / np.sqrt(mass_initial))[:, None]
            physical_values[:, 3, :] *= (scales * np.sqrt(mass_initial))[:, None]
            hubble = case.jets(SPAN)[1]
            potentials = case.metrics["full"](SPAN)
            canonical = physical_values.copy()
            canonical[:, 3, :] -= (potentials[:, 1] + 3 * potentials[:, 0])[:, None] * (canonical[:, 1, :] - hubble * canonical[:, 0, :])
            sources_final = stress(case, canonical, SPAN)
            source_error = np.max(abs((sources_final - saved["source8192"][indices]) / saved["normalizer"][indices][:, [0, 1, 0]]), axis=1)
            rows.append(dict(tolerance=tolerance, evaluations=solution.nfev, elapsed=time.monotonic() - started,
                             field_errors=error.tolist(), source_errors=source_error.tolist(),
                             passed=bool(np.max(error) <= GATE and np.max(source_error) <= GATE)))
            print(json.dumps(dict(group=arguments.group, **rows[-1])), flush=True)
        refinement = float(np.max(abs(finals[0] - finals[1])))
        np.savez_compressed(ROOT / ("direct-" + arguments.group + ".npz"), indices=indices, expected=expected,
                            initial=start, coarse=finals[0], fine=finals[1])
        result = dict(passed=all(row["passed"] for row in rows) and refinement <= GATE, waves=case.wave.tolist(),
                      indices=indices.tolist(), reports=rows, refinement=refinement,
                      source_derivative="analytic derivative of the same supplied metric interpolant, not a raw finite difference",
                      scope="linear physical KG response with explicit quadratures; no finite-amplitude realization claim",
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "model.py"), common_sha256=digest(ROOT / "common.py"),
                      transport_sha256=digest(ROOT / "transport-result.json"), output_sha256=digest(ROOT / ("direct-" + arguments.group + ".npz")))
        write("direct-" + arguments.group + "-result.json", result)
        print(json.dumps(dict(group=arguments.group, passed=result["passed"], refinement=refinement)))


if __name__ == "__main__":
    main()
