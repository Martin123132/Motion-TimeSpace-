from common import *
import ast
import numpy as np


if __name__ == "__main__":
    with worker("seal") as identity:
        validation = read(ROOT / "validation.json")
        if not validation["passed"] or not all(row["passed"] for row in validation["checks"]):
            raise ValueError("unpassed implementation validation")
        if validation["code_sha256"] != digest(ROOT / "validate_transport.py"):
            raise ValueError("validation code changed")
        files = {"bound": "background-bound.json", "source": "source-bound.json", "primary": "transport-result.json",
                 "pilot": "direct-pilot-result.json", "remaining": "direct-remaining-result.json",
                 "dressing": "dressing-result.json", "interpolation": "interpolation-result.json"}
        for name, filename in files.items():
            if validation["report_hashes"][name] != digest(ROOT / filename):
                raise ValueError("changed validated report " + filename)
        extras = {}
        for prefix, code, contract, upstream in (
            ("continuity", "native_continuity.py", "CONTINUITY-CONTRACT.md", {"primary_sha256": "transport-result.json", "dressing_sha256": "dressing-result.json"}),
            ("phase-endpoint", "phase_repair.py", "PHASE-REPAIR-CONTRACT.md", {"primary_sha256": "transport-result.json", "dressing_sha256": "dressing-result.json", "continuity_sha256": "continuity-result.json"}),
            ("phase-full", "phase_repair.py", "PHASE-REPAIR-CONTRACT.md", {"primary_sha256": "transport-result.json", "dressing_sha256": "dressing-result.json", "continuity_sha256": "continuity-result.json"}),
            ("direct-low", "direct_repaired_low.py", "LOW-K-DIRECT-CONTRACT.md", {"repaired_sha256": "phase-full-result.json"}),
        ):
            report = read(ROOT / (prefix + "-result.json"))
            if not report.get("implementation_passed", report.get("passed", False)):
                raise ValueError("supplemental implementation failed " + prefix)
            bindings = dict(upstream, code_sha256=code, contract_sha256=contract, model_sha256="model.py", common_sha256="common.py", output_sha256=prefix + ".npz")
            if any(report[key] != digest(ROOT / filename) for key, filename in bindings.items()):
                raise ValueError("supplemental binding mismatch " + prefix)
            extras[prefix] = report
        with np.load(ROOT / "transport.npz") as original, np.load(ROOT / "phase-full.npz") as repaired:
            for row in extras["phase-full"]["comparisons"]:
                errors = abs((repaired[row["preparation"] + "_source" + str(row["panels"])] - original["native"]) / original["normalizer"][:, [0, 1, 0]])
                if row["density_current_passed"] != bool(np.max(errors[:, :2]) <= GATE) or row["failing_density_current_modes"] != int(np.sum(np.max(errors[:, :2], axis=1) > GATE)):
                    raise ValueError("repaired scientific report mismatch")
        for path in ROOT.glob("*.npz"):
            with np.load(path) as packet:
                if any(not np.all(np.isfinite(packet[key])) for key in packet.files if np.issubdtype(packet[key].dtype, np.number)):
                    raise ValueError("nonfinite packet " + path.name)
        inputs = sources()
        if read(ROOT / "background-bound.json")["sources"] != inputs:
            raise ValueError("changed input manifest")
        cleanup = []
        for prefix in ("bound", "transport", "source-bound", "direct-pilot", "direct-remaining", "dressing", "interpolation", "validation", "continuity", "phase-endpoint", "phase-full", "direct-low"):
            start, end = read(ROOT / (prefix + "-start.json")), read(ROOT / (prefix + "-end.json"))
            if end["state"] != "completed" or any(start[key] != end[key] for key in ("pid", "created", "command")):
                raise ValueError("worker terminal receipt " + prefix)
            try:
                process = psutil.Process(start["pid"])
                live = abs(process.create_time() - start["created"]) < .001
            except psutil.NoSuchProcess:
                live = False
            if live:
                raise ValueError("owned worker still live " + prefix)
            cleanup.append(dict(stage=prefix, **start, exited=True))
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        if list(ROOT.rglob("__pycache__")):
            raise ValueError("bytecode residue")
        for name in ("RESULTS.md", "NEXT.md", "BOUND-DERIVATION.md", "DRESSING-DERIVATION.md"):
            if not (ROOT / name).is_file() or (ROOT / name).stat().st_size < 100:
                raise ValueError("missing stage documentation " + name)
        primary, dressing = read(ROOT / "transport-result.json"), read(ROOT / "dressing-result.json")
        manifest = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size)
                    for path in ROOT.rglob("*") if path.is_file()}
        report = dict(state="verified_experiment", time=datetime.now(timezone.utc).isoformat(), artifacts=manifest,
                      input_hashes=inputs, cleanup=cleanup, sealer=identity,
                      implementation_checks=len(validation["checks"]), exact_dressing_identities=validation["exact_dressing_identities"],
                      primary_native_comparison_passed=primary["native_comparison_passed"],
                      original_conditional_dressed_comparison_passed=dressing["native_density_current_passed"],
                      repaired_comparisons=extras["phase-full"]["comparisons"],
                      current_density_current_interface_passed=all(row["density_current_passed"] for row in extras["phase-full"]["comparisons"]) and primary["cold"]["native_pass"],
                      independent_repaired_low_mode_passed=extras["direct-low"]["passed"],
                      preparation_is_conditional=True, parent_formation_state_selected=False,
                      no_original_native_changes=True, no_galaxy_edits=True, no_github=True, no_relay_or_timer=True,
                      broad_goal_complete=False)
        write("closeout.json", report)
        print(json.dumps(dict(closeout_sha256=digest(ROOT / "closeout.json"), artifacts=len(manifest),
                              sources=len(inputs), cleanup=cleanup, sealer=identity)), flush=True)
