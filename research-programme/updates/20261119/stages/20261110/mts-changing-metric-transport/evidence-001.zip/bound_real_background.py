from common import *
from rational_interval import Interval, exponential, fraction, BITS
from fractions import Fraction
import numpy as np
import sympy as sym


def evaluate(expression, variables):
    if expression in variables:
        return variables[expression]
    if expression.is_Rational:
        return Interval(Fraction(int(expression.p), int(expression.q)))
    if expression.is_Add:
        return sum((evaluate(term, variables) for term in expression.args), Interval(0))
    if expression.is_Mul:
        result = Interval(1)
        for term in expression.args:
            result *= evaluate(term, variables)
        return result
    if expression.is_Pow and expression.args[1].is_Integer:
        return evaluate(expression.args[0], variables)**int(expression.args[1])
    raise ValueError("unsupported symbolic interval node " + str(expression))


def certificate(model, formula):
    with np.load(PREP / (model + "-background.npz")) as archive:
        packet = {name: archive[name].copy() for name in archive.files}
    center = fraction(float(-np.log(11.)))
    span = fraction(float(packet["position"][-1]))
    domain = Interval(center, center + span)
    fraction_of_initial = Fraction(1, 100)
    initial = [fraction(float(value)) for value in packet["states"][0, :3]]
    boxes = [Interval(value - abs(value) * fraction_of_initial, value + abs(value) * fraction_of_initial) for value in initial]
    field, speed, hubble = boxes
    scale = exponential(domain)
    scalar_mass = Interval(float(packet["slow_mass"])) * scale
    massive = Interval(float(packet["heavy_mass"])) * scale
    unit = Interval(float(packet["unit"]))
    knots = packet["nu_knots"]
    index = int(np.searchsorted(knots, float(center), side="right") - 1)
    if not (fraction(float(knots[index])) <= domain.lower and domain.upper <= fraction(float(knots[index + 1]))):
        raise ValueError("nu interval crosses a spline knot")
    offset = domain - float(knots[index])
    cubic, quadratic, linear, constant = (Interval(float(value)) for value in packet["nu_coefficients"][:, index])
    logarithm = ((cubic * offset + quadratic) * offset + linear) * offset + constant
    slope = (3 * cubic * offset + 2 * quadratic) * offset + linear
    curvature, third_log = 6 * cubic * offset + 2 * quadratic, 6 * cubic
    neutrino = 3 * unit**2 * exponential(logarithm - 2 * domain)
    nu_slope, nu_w = slope - 2, (1 - slope) / 3
    nu_pressure_n = neutrino * (nu_slope * nu_w - curvature / 3)
    nu_pressure_nn = neutrino * ((nu_slope**2 + curvature) * nu_w - 2 * nu_slope * curvature / 3 - third_log / 3)
    dust = (3 * unit**2 * float(packet["standard_matter"]) + float(packet["matching_density"])) / scale
    radiation = 3 * unit**2 * float(packet["standard_radiation"]) / scale**2
    density = dust + radiation + neutrino + (speed**2 + scalar_mass**2 * field**2) / 2
    pressure = radiation / 3 + neutrino * nu_w + (speed**2 - scalar_mass**2 * field**2) / 2
    hubble_first = -(density + 3 * pressure) / 6
    rhs = [speed / hubble, -2 * speed - scalar_mass**2 * field / hubble, hubble_first / hubble]
    inclusions = []
    for name, value, box, rate in zip(("field", "speed", "hubble"), initial, boxes, rhs):
        image = value + Interval(0, span) * rate
        passed = box.contains(image, strict=True)
        if not passed:
            raise ValueError("Picard inclusion failed " + model + ":" + name)
        inclusions.append(dict(variable=name, initial=str(value), box=box.record(), rhs=rate.record(),
                               image=image.record(), strict_inclusion=True))
    scalar_pressure_first = -2 * hubble * speed**2 - hubble * scalar_mass**2 * field**2 - 2 * scalar_mass**2 * field * speed
    pressure_first = -2 * hubble * radiation / 3 + hubble * nu_pressure_n + scalar_pressure_first
    density_first = -hubble * (density + 3 * pressure)
    hubble_second = -(density_first + 3 * pressure_first) / 6
    scalar_pressure_second = (-2 * hubble_first + 8 * hubble**2 - 2 * scalar_mass**2) * speed**2 + (-hubble_first * scalar_mass**2 - 2 * hubble**2 * scalar_mass**2 + 2 * scalar_mass**4) * field**2 + 2 * hubble * scalar_mass**2 * field * speed
    pressure_second = (-2 * hubble_first + 4 * hubble**2) * radiation / 3 + hubble**2 * nu_pressure_nn + hubble_first * nu_pressure_n + scalar_pressure_second
    density_second = -hubble_first * (density + 3 * pressure) - hubble * (density_first + 3 * pressure_first)
    hubble_third = -(density_second + 3 * pressure_second) / 6
    symbols = sym.symbols(" ".join(formula["variables"]), real=True)
    local = dict(zip(formula["variables"], symbols))
    ratio = Interval(1, 1 + Fraction(25, 2) / massive.lower**2)
    reduced = [hubble / massive, hubble_first / massive**2, hubble_second / massive**3, hubble_third / massive**4]
    variables = dict(zip(symbols, [ratio, *reduced]))
    numerator = sym.sympify(formula["residual_numerator"], locals=local)
    denominator = sym.sympify(formula["residual_denominator"], locals=local)
    numerator_bound = Interval(0)
    for powers, coefficient in sym.Poly(numerator, *symbols).terms():
        term = Interval(abs(int(coefficient)))
        for symbol, exponent in zip(symbols, powers):
            term *= Interval(variables[symbol].magnitude())**exponent
        numerator_bound += term
    denominator_box = evaluate(denominator, variables)
    if denominator_box.lower <= 0:
        raise ValueError("positive residual denominator not established")
    residual = numerator_bound / denominator_box
    frequency = evaluate(sym.sympify(formula["frequency"], locals=local), variables)
    first = evaluate(sym.sympify(formula["first_derivative"], locals=local), variables)
    if frequency.lower <= 0 or hubble.lower <= 0:
        raise ValueError("positive frequency/background not established")
    duration = Interval(span) / hubble
    exponent = duration * massive * residual / frequency
    if exponent.upper >= Fraction(1, 100):
        raise ValueError("error bound not small")
    homogeneous = exponent / (1 - exponent)
    forced_factor = 2 * exponent / (1 - 2 * exponent)
    shear = Interval(first.magnitude()) / (2 * frequency**2)
    frequency_min = massive.lower * frequency.lower
    frequency_max = massive.upper * frequency.upper
    coefficient_c = duration * (1 + shear)**2 * (2 * Interval(hubble.magnitude()) * frequency_max / frequency_min + frequency_max + Interval(hubble.magnitude())**2 / frequency_min)
    coefficient_d = duration * (1 + shear)**2 * massive**2 / frequency_min
    return dict(model=model, conditional_initial_state=True, efold_domain=domain.record(), span=str(span),
                picard_inclusions=inclusions, field_box=field.record(), speed_box=speed.record(),
                H_jets=[value.record() for value in (hubble, hubble_first, hubble_second, hubble_third)],
                mu=massive.record(), reduced_jets=[value.record() for value in reduced], ratio=ratio.record(),
                frequency_over_mu=frequency.record(), frequency_min=str(frequency_min), frequency_max=str(frequency_max),
                residual_over_mu2_upper=str(residual.upper), duration_upper=str(duration.upper), exponent_upper=str(exponent.upper),
                homogeneous_error_upper=str(homogeneous.upper), forced_error_factor_upper=str(forced_factor.upper),
                J_coefficient_C_upper=str(coefficient_c.upper), J_coefficient_D_upper=str(coefficient_d.upper),
                display=dict(exponent=float(exponent.upper), homogeneous_error=float(homogeneous.upper),
                             forced_error_factor=float(forced_factor.upper), duration=float(duration.upper),
                             J_C=float(coefficient_c.upper), J_D=float(coefficient_d.upper)),
                covers="all0<=k<=5; entire saved short interval; exact retained background ODE with given initial values",
                excludes=["initial-data uncertainty", "neutrino table model error", "floating-point evolution", "metric forcing/interpolation error"],
                background_packet_sha256=digest(PREP / (model + "-background.npz")))


if __name__ == "__main__":
    with worker("bound"):
        hashes = sources()
        formula = read(PREP / "proof.json")["formula"]
        reports = [certificate(model, formula) for model in ("heavy", "cold")]
        result = dict(passed=True, arithmetic="outward-rounded rational dyadic intervals", fraction_bits=BITS,
                      models=reports, sources=hashes, code_sha256=digest(__file__),
                      interval_code_sha256=digest(ROOT / "rational_interval.py"), common_sha256=digest(ROOT / "common.py"),
                      protocol_sha256=digest(ROOT / "PROTOCOL.md"))
        write("background-bound.json", result)
        print(json.dumps([dict(model=row["model"], **row["display"]) for row in reports]))
