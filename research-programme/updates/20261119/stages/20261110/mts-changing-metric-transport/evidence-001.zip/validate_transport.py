from common import *
from model import *
from rational_interval import Interval, exponential, fraction
from bound_real_background import certificate
from source_bounds import spline_basis
from fractions import Fraction
import mpmath as mp
import ast


def main():
    with worker("validation"):
        inputs = sources()
        checks = []

        def check(name, passed):
            checks.append(dict(name=name, passed=bool(passed)))

        reports = {name: read(ROOT / filename) for name, filename in (
            ("bound", "background-bound.json"), ("source", "source-bound.json"),
            ("primary", "transport-result.json"), ("pilot", "direct-pilot-result.json"),
            ("remaining", "direct-remaining-result.json"), ("dressing", "dressing-result.json"),
            ("interpolation", "interpolation-result.json"))}
        bindings = {
            "bound": {"code_sha256": "bound_real_background.py", "interval_code_sha256": "rational_interval.py", "protocol_sha256": "PROTOCOL.md"},
            "source": {"code_sha256": "source_bounds.py", "bound_sha256": "background-bound.json", "output_sha256": "source-polynomials.npz"},
            "primary": {"code_sha256": "transport.py", "protocol_sha256": "PROTOCOL.md", "bound_sha256": "background-bound.json", "output_sha256": "transport.npz"},
            "pilot": {"code_sha256": "direct_controls.py", "transport_sha256": "transport-result.json", "output_sha256": "direct-pilot.npz"},
            "remaining": {"code_sha256": "direct_controls.py", "transport_sha256": "transport-result.json", "output_sha256": "direct-remaining.npz"},
            "dressing": {"code_sha256": "dressing_diagnostic.py", "contract_sha256": "DRESSING-DERIVATION.md", "primary_sha256": "transport-result.json", "bank_sha256": "transport.npz", "output_sha256": "dressing.npz"},
            "interpolation": {"code_sha256": "interpolation_controls.py", "primary_sha256": "transport-result.json", "output_sha256": "interpolation.npz"},
        }
        for name, report in reports.items():
            mapping = dict(bindings[name], common_sha256="common.py")
            if "model_sha256" in report:
                mapping["model_sha256"] = "model.py"
            check(name + " source/output bindings", all(report[key] == digest(ROOT / filename) for key, filename in mapping.items()))
        check("preserved source manifest", reports["bound"]["sources"] == inputs)
        for name in ("bound", "source", "pilot", "remaining", "interpolation"):
            check(name + " implementation acceptance", reports[name]["passed"])
        check("primary implementation acceptance", reports["primary"]["implementation_checks_passed"])
        check("alternative implementation acceptance", reports["dressing"]["implementation_passed"])
        check("alternative not presented as selected population", reports["dressing"]["conditional_preparation"] and not reports["dressing"]["selects_formation_population"] and not reports["dressing"]["primary_result_replaced"])
        check("dressing exact identities", all(reports["dressing"]["exact_identities"].values()))
        formula = read(PREP / "proof.json")["formula"]
        numerator = sym.sympify(formula["residual_numerator"], locals=dict(zip(FORMULA["variables"], SYMBOLS)))
        polynomial = sym.Poly(numerator, *SYMBOLS)
        check("all91residual coefficients are exact integers", len(polynomial.terms()) == 91 and all(value.is_Integer for value in polynomial.coeffs()))
        for name, retained in zip(("heavy", "cold"), reports["bound"]["models"]):
            regenerated = certificate(name, formula)
            check(name + " exact certificate replay", regenerated == retained)
            case = Case(name)
            check(name + " all399modes within certified wave interval", len(case.wave) == 399 and np.all((case.wave > 0) & (case.wave <= 5)))
            boxes = [retained["field_box"], retained["speed_box"], retained["H_jets"][0]]
            check(name + " saved trajectory inside proved box", all(Fraction(boxes[column]["lower"]) <= fraction(float(value)) <= Fraction(boxes[column]["upper"]) for column in range(3) for value in case.background["states"][:, column]))
            check(name + " saved jets inside derived intervals", all(Fraction(retained["H_jets"][column]["lower"]) <= fraction(float(value)) <= Fraction(retained["H_jets"][column]["upper"]) for column in range(4) for value in case.background["jets"][:, column]))
        samples = [Fraction(-7, 3), Fraction(-1, 13), Fraction(0), Fraction(1, 17), Fraction(11, 3)]
        arithmetic_passed = True
        for left in samples:
            for right in samples:
                interval_left, interval_right = Interval(left), Interval(right)
                for actual, expected in ((interval_left + interval_right, left + right), (interval_left - interval_right, left - right), (interval_left * interval_right, left * right)):
                    arithmetic_passed &= actual.lower <= expected <= actual.upper
                if right:
                    actual = interval_left / interval_right
                    arithmetic_passed &= actual.lower <= left / right <= actual.upper
        check("outward basic arithmetic endpoint controls", arithmetic_passed)
        check("even power across zero", (Interval(-2, 3)**2).contains(Interval(0, 9)))
        try:
            Interval(-1, 1).reciprocal()
            rejected_zero = False
        except ValueError:
            rejected_zero = True
        check("zero-containing division rejected", rejected_zero)
        mp.mp.dps = 100
        exp_passed = True
        for value in map(Fraction, ("-12", "-3", "-0.125", "0", "0.125", "3", "12")):
            enclosed = exponential(Interval(value))
            expected = mp.exp(mp.mpf(value.numerator) / value.denominator)
            exp_passed &= mp.mpf(enclosed.lower.numerator) / enclosed.lower.denominator <= expected <= mp.mpf(enclosed.upper.numerator) / enclosed.upper.denominator
        check("100digit exponential spot controls", exp_passed)
        basis = spline_basis()
        nodes = [-4, -2, -1, 0, 1, 2, 4]
        check("exact spline reproduces all cubics", all(sum(basis[power][node] * nodes[node]**degree for node in range(7)) == int(3 - power == degree) for power in range(4) for degree in range(4)))
        check("saved exact spline basis", reports["source"]["exact_spline_basis"] == [[str(value) for value in row] for row in basis])
        check("all399source bounds nonnegative", len(reports["source"]["rows"]) == 399 and all(Fraction(row[key]) >= 0 for row in reports["source"]["rows"] for key in ("J_exact", "forced_truncation_per_c0_exact", "source_rounding_per_c0_exact")))
        with np.load(ROOT / "transport.npz") as archive:
            errors = archive["native_errors"]
            check("original scientific failure retained accurately", reports["primary"]["heavy_native_failing_density_current_modes"] == int(np.sum(np.max(errors[:, :2], axis=1) > GATE)) and reports["primary"]["native_comparison_passed"] == bool(np.max(errors[:, :2]) <= GATE and reports["primary"]["cold"]["native_pass"]))
            wave = archive["wave"].copy()
            primary_failing_rows = [dict(wave=float(wave[index]), density_error=float(errors[index, 0]), current_error=float(errors[index, 1]), pressure_block_error=float(errors[index, 2])) for index in np.flatnonzero(np.max(errors[:, :2], axis=1) > GATE)]
        with np.load(ROOT / "dressing.npz") as archive:
            errors = archive["errors"]
            check("conditional scientific comparison reported accurately", reports["dressing"]["density_current_failing_modes"] == int(np.sum(np.max(errors[:, :2], axis=1) > GATE)) and reports["dressing"]["native_density_current_passed"] == bool(np.max(errors[:, :2]) <= GATE))
            dressed_failing_rows = [dict(wave=float(wave[index]), density_error=float(errors[index, 0]), current_error=float(errors[index, 1]), pressure_block_error=float(errors[index, 2])) for index in np.flatnonzero(np.max(errors[:, :2], axis=1) > GATE)]
        for path in ROOT.glob("*.npz"):
            with np.load(path) as archive:
                check(path.name + " finite numeric packet", all(np.all(np.isfinite(archive[key])) for key in archive.files if np.issubdtype(archive[key].dtype, np.number)))
        check("direct physical controls cover all four declared modes", sorted(reports["pilot"]["waves"] + reports["remaining"]["waves"]) == [.03, .1, 1., 5.])
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        check("no bytecode leftovers", not list(ROOT.rglob("__pycache__")))
        report = dict(passed=all(row["passed"] for row in checks), checks=checks, input_count=len(inputs),
                      primary_failing_rows=primary_failing_rows, dressed_failing_rows=dressed_failing_rows,
                      implementation_validation_not_scientific_promotion=True, exact_dressing_identities=len(reports["dressing"]["exact_identities"]),
                      code_sha256=digest(__file__), report_hashes={name: digest(ROOT / filename) for name, filename in (("bound", "background-bound.json"), ("source", "source-bound.json"), ("primary", "transport-result.json"), ("pilot", "direct-pilot-result.json"), ("remaining", "direct-remaining-result.json"), ("dressing", "dressing-result.json"), ("interpolation", "interpolation-result.json"))})
        write("validation.json", report)
        print(json.dumps(report), flush=True)
        if not report["passed"]:
            raise ValueError("validation failed; inspect saved report, do not promote")


if __name__ == "__main__":
    main()
