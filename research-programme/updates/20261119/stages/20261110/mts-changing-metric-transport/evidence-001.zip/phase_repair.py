from common import *
from model import *
import argparse
import mpmath as mp


class StableCase(Case):
    def phases(self, positions, phase_order=16):
        positions = np.asarray(positions).reshape(-1)
        nodes, weights = leggauss(phase_order)
        carrier_phase = np.zeros(len(positions))
        beat_phase = np.zeros((len(positions), len(self.wave)))
        for node, weight in zip(nodes, weights):
            frequency = self.frequency(positions * (node + 1) / 2)
            carrier_phase += weight * positions / 2 * frequency["carrier"] / frequency["hubble"]
            beat_phase += (weight * positions / 2 / frequency["hubble"])[:, None] * frequency["beat"]
        return carrier_phase, beat_phase

    def templates(self, positions, phase_order=16):
        positions = np.asarray(positions).reshape(-1)
        values = self.frequency(positions)
        carrier_phase, beat_phase = self.phases(positions, phase_order)
        carrier = matrix(values["carrier"], values["slope0"], carrier_phase)
        carrier_cosine, carrier_sine = np.cos(carrier_phase)[:, None], np.sin(carrier_phase)[:, None]
        beat_cosine, beat_sine = np.cos(beat_phase), np.sin(beat_phase)
        cosine = carrier_cosine * beat_cosine - carrier_sine * beat_sine
        sine = carrier_sine * beat_cosine + carrier_cosine * beat_sine
        amplitude = 1 / np.sqrt(values["sideband"])
        sideband = np.empty((*values["sideband"].shape, 2, 2))
        sideband[..., 0, 0], sideband[..., 0, 1] = amplitude * cosine, amplitude * sine
        sideband[..., 1, 0] = amplitude * (values["slopek"] * cosine - values["sideband"] * sine)
        sideband[..., 1, 1] = amplitude * (values["slopek"] * sine + values["sideband"] * cosine)
        return carrier, sideband


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("endpoint", "full"))
    arguments = parser.parse_args()
    with worker("phase-" + arguments.stage):
        case = StableCase("heavy")
        with np.load(ROOT / "transport.npz") as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        with np.load(ROOT / "dressing.npz") as archive:
            dressed_initial = archive["initial"].copy()
        scales = saved["normalizer"][:, [0, 1, 0]]
        states = {"undressed": saved["initial"], "dressed": dressed_initial}
        arrays, comparisons, refinements = {}, [], []
        orders = (8192,) if arguments.stage == "endpoint" else (4096, 8192)
        previous = {}
        for panels in orders:
            integral = saved["integral8192"] if arguments.stage == "endpoint" else integrate(case, panels)["full"]
            arrays["integral" + str(panels)] = integral
            for preparation, initial in states.items():
                final = propagate(case, initial, integral)
                source = stress(case, final, SPAN)
                error = abs((source - saved["native"]) / scales)
                if preparation in previous:
                    refinements.append(dict(preparation=preparation, panels=[4096, 8192],
                                            source_error=float(np.max(abs((source - previous[preparation]) / scales)))))
                previous[preparation] = source
                comparisons.append(dict(preparation=preparation, panels=panels,
                                        density_max=float(np.max(error[:, 0])), current_max=float(np.max(error[:, 1])),
                                        pressure_block_max=float(np.max(error[:, 2])),
                                        failing_density_current_modes=int(np.sum(np.max(error[:, :2], axis=1) > GATE)),
                                        density_current_passed=bool(np.max(error[:, :2]) <= GATE)))
                arrays[preparation + "_final" + str(panels)] = final
                arrays[preparation + "_source" + str(panels)] = source
            print(json.dumps(dict(stage=arguments.stage, panels=panels, comparisons=comparisons[-2:])), flush=True)
        mp.mp.dps = 80
        worst_index = int(np.argmax(np.max(saved["native_errors"][:, :2], axis=1)))
        indices = sorted(set([0, worst_index] + [int(np.argmin(abs(case.wave - target))) for target in (.03, .1, 1., 5.)]))
        carrier_phase, beat_phase = case.phases([SPAN])
        controls = []
        for index in indices:
            carrier_value, beat_value = float(carrier_phase[0]), float(beat_phase[0, index])
            high_phase = mp.mpf(carrier_value) + mp.mpf(beat_value)
            expected_cosine, expected_sine = mp.cos(high_phase), mp.sin(high_phase)
            stable_cosine = np.cos(carrier_value) * np.cos(beat_value) - np.sin(carrier_value) * np.sin(beat_value)
            stable_sine = np.sin(carrier_value) * np.cos(beat_value) + np.cos(carrier_value) * np.sin(beat_value)
            legacy_cosine, legacy_sine = np.cos(carrier_value + beat_value), np.sin(carrier_value + beat_value)
            stable_error = float(max(abs(mp.mpf(float(stable_cosine)) - expected_cosine), abs(mp.mpf(float(stable_sine)) - expected_sine)))
            legacy_error = float(max(abs(mp.mpf(float(legacy_cosine)) - expected_cosine), abs(mp.mpf(float(legacy_sine)) - expected_sine)))
            controls.append(dict(wave=float(case.wave[index]), carrier_phase=carrier_value, beat_phase=beat_value,
                                 rounded_beat=(carrier_value + beat_value) - carrier_value, stable_rotation_error=stable_error,
                                 legacy_rotation_error=legacy_error, passed=stable_error <= ALGEBRA))
        np.savez_compressed(ROOT / ("phase-" + arguments.stage + ".npz"), **arrays)
        result = dict(stage=arguments.stage, implementation_passed=all(row["passed"] for row in controls) and all(row["source_error"] <= GATE for row in refinements),
                      comparisons=comparisons, refinements=refinements, rotation_controls=controls,
                      original_failures_preserved=True, fitted_coefficient=False, arithmetic="unchanged binary64; angle addition evaluated without summing carrier and beat",
                      unchanged_cold_control=read(ROOT / "transport-result.json")["cold"],
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "model.py"), common_sha256=digest(ROOT / "common.py"),
                      contract_sha256=digest(ROOT / "PHASE-REPAIR-CONTRACT.md"), primary_sha256=digest(ROOT / "transport-result.json"),
                      dressing_sha256=digest(ROOT / "dressing-result.json"), continuity_sha256=digest(ROOT / "continuity-result.json"),
                      output_sha256=digest(ROOT / ("phase-" + arguments.stage + ".npz")))
        write("phase-" + arguments.stage + "-result.json", result)
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
