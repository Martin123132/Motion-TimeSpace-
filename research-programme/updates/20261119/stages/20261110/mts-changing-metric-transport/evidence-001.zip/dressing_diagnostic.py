from common import *
from model import *

SECOND_FUNCTION = sym.lambdify(SYMBOLS, sym.sympify(FORMULA["second_derivative"], locals=dict(zip(FORMULA["variables"], SYMBOLS))), "numpy", cse=True)


def rates(case, positions):
    positions = np.asarray(positions)
    mass, hubble, first, second, third = case.jets(positions)
    values = case.frequency(positions)
    reduced = [hubble / mass, first / mass**2, second / mass**3, third / mass**4]
    ratio = np.sqrt(1 + (case.wave[None, :] / mass[:, None])**2)
    carrier_rate = values["slope0"] - 1j * values["carrier"]
    sideband_rate = values["slopek"] - 1j * values["sideband"]
    carrier_first = mass**2 * FIRST_FUNCTION(np.ones_like(mass), *reduced)
    sideband_first = mass[:, None]**2 * FIRST_FUNCTION(ratio, *[value[:, None] for value in reduced])
    carrier_second = mass**3 * SECOND_FUNCTION(np.ones_like(mass), *reduced)
    sideband_second = mass[:, None]**3 * SECOND_FUNCTION(ratio, *[value[:, None] for value in reduced])
    carrier_rate_prime = -carrier_second / (2 * values["carrier"]) + (carrier_first / values["carrier"])**2 / 2 - 1j * carrier_first
    sideband_rate_prime = -sideband_second / (2 * values["sideband"]) + (sideband_first / values["sideband"])**2 / 2 - 1j * sideband_first
    potentials = case.metrics["full"](positions)
    slopes = case.metrics["full"](positions, 1)
    curvatures = case.metrics["full"](positions, 2)
    combined_s = slopes[..., 1] + 3 * slopes[..., 0]
    combined_ss = curvatures[..., 1] + 3 * curvatures[..., 0]
    combined_prime = hubble[:, None] * combined_s
    combined_second = first[:, None] * combined_s + hubble[:, None]**2 * combined_ss
    lapse = potentials[..., 1]
    lapse_prime = hubble[:, None] * slopes[..., 1]
    source = combined_prime * (carrier_rate - hubble)[:, None] - 2 * mass[:, None]**2 * lapse
    source_prime = combined_second * (carrier_rate - hubble)[:, None] + combined_prime * (carrier_rate_prime - first)[:, None] - 4 * (hubble * mass**2)[:, None] * lapse - 2 * mass[:, None]**2 * lapse_prime
    rate_sum = carrier_rate[:, None] + sideband_rate
    rate_sum_prime = carrier_rate_prime[:, None] + sideband_rate_prime
    dressing = source / rate_sum
    dressing_prime = source_prime / rate_sum - source * rate_sum_prime / rate_sum**2
    return dressing, dressing_prime, rate_sum, source


def prepare_dressed(case):
    values = case.frequency([0])
    mass, hubble = values["mass"][0], values["hubble"][0]
    frequency0, frequencyk = values["carrier"][0], values["sideband"][0]
    slope0, slopek = values["slope0"][0], values["slopek"][0]
    physical_slope0, physical_slopek = slope0 - hubble, slopek - hubble
    denominator = frequency0**2 + mass**2 + physical_slope0**2
    dressing = rates(case, [0])[0][0]
    density_offset = 2 * (physical_slope0 * dressing.real - frequency0 * dressing.imag) / denominator
    mapping = np.empty((len(case.wave), 2, 2))
    mapping[:, 0, 0] = 2 * (physical_slope0 * physical_slopek + frequency0 * frequencyk + mass**2) / denominator
    mapping[:, 0, 1] = 2 * (physical_slope0 * frequencyk - frequency0 * physical_slopek) / denominator
    mapping[:, 1, 0], mapping[:, 1, 1] = -2 * mass * physical_slope0 / denominator, 2 * mass * frequency0 / denominator
    eos = (frequency0**2 + physical_slope0**2 - mass**2) / denominator
    density = case.history["density"][case.indices, 3]
    phase = -mass * case.history["current"][case.indices, 3] / case.wave
    potential, lapse = case.metrics["full"](0).T
    target = np.column_stack((density + (1 + eos) * lapse - density_offset, phase))
    relative = np.linalg.solve(mapping, target[..., None])[..., 0]
    states = prepare(case)[0]
    amplitude = 1 / np.sqrt(frequency0)
    states[:, 2, :] = amplitude * relative
    physical_prime = amplitude * np.column_stack((slopek * relative[:, 0] + frequencyk * relative[:, 1] + dressing.real,
                                                   slopek * relative[:, 1] - frequencyk * relative[:, 0] + dressing.imag))
    states[:, 3, :] = physical_prime - (lapse + 3 * potential)[:, None] * (states[:, 1, :] - hubble * states[:, 0, :])
    return states, dressing, density_offset


def identities():
    ratio, mass = sym.symbols("ratio mass", positive=True)
    realpart, imagpart, lapse, density = sym.symbols("realpart imagpart lapse density", real=True)
    fraction = (ratio - 1) / (ratio + 1)
    coefficient = 2 * mass / (ratio + 1)
    field_density = (1 + ratio) * realpart + (coefficient / mass - 1) * lapse
    field_pressure = (ratio - 1) * realpart + (coefficient / mass - 1) * lapse
    solved_real = (density + fraction * lapse) / (1 + ratio)
    expressions = {
        "forced_density": field_density - ((1 + ratio) * realpart - fraction * lapse),
        "forced_pressure": field_pressure.subs(realpart, solved_real) - (fraction * density - fraction * (1 - fraction) * lapse),
        "density_evolution": (1 + ratio) * mass * (ratio - 1) * imagpart - mass * (ratio**2 - 1) * imagpart,
        "current_evolution": -mass * (ratio - 1) * solved_real - coefficient * lapse + mass * (fraction * density + (1 - fraction + fraction**2) * lapse),
        "zero_wave_pressure": field_pressure.subs(ratio, 1),
        "zero_wave_force": (-mass * (ratio - 1) * solved_real - coefficient * lapse).subs(ratio, 1) + mass * lapse,
        "forced_projection_coefficient": (-sym.I * mass * (1 + ratio)) * (-sym.I * coefficient * lapse) + 2 * mass**2 * lapse,
    }
    field, rate, rate_prime, omega_squared, source = sym.symbols("field rate rate_prime omega_squared source")
    field_prime = sym.Symbol("field_prime")
    residual = rate_prime + rate**2 + omega_squared
    expressions["fast_response_identity"] = source - omega_squared * field - rate_prime * field - rate * field_prime + rate * (field_prime - rate * field) - (source - residual * field)
    checked = {name: bool(sym.factor(value) == 0) for name, value in expressions.items()}
    if not all(checked.values()):
        raise ValueError(checked)
    return checked


def main():
    with worker("dressing"):
        provenance = sources()
        proof = identities()
        case = Case("heavy")
        with np.load(ROOT / "transport.npz") as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        initial, initial_dressing, density_offset = prepare_dressed(case)
        final = propagate(case, initial, saved["integral8192"])
        initial_source = stress(case, initial, 0)
        final_source = stress(case, final, SPAN)
        scales = saved["normalizer"][:, [0, 1, 0]]
        initial_expected = stress(case, saved["initial"], 0)
        initial_error = float(np.max(abs((initial_source[:, :2] - initial_expected[:, :2]) / scales[:, :2])))
        errors = abs((final_source - saved["native"]) / scales)
        positions = np.linspace(0, SPAN, 17)
        dressing, derivative, rate_sum, source = rates(case, positions)
        indicator = abs(derivative) / (abs(rate_sum) * np.maximum(np.max(abs(dressing), axis=0), 1e-100)[None, :])
        algebra_error = float(np.max(abs(rate_sum * dressing - source) / np.maximum(abs(source), 1e-100)))
        carrier_first, sideband_first = case.templates([0])
        carrier_last, sideband_last = case.templates([SPAN])
        homogeneous_change = sideband_last[0] @ inverse(sideband_first[0]) @ (initial[:, 2:, :] - saved["initial"][:, 2:, :])
        predicted_difference = np.zeros_like(final)
        predicted_difference[:, 2:, :] = homogeneous_change
        difference_error = float(np.max(abs(normalized(case, final - saved["final8192"] - predicted_difference, saved["microscopic_scale"], SPAN))))
        implementation_passed = initial_error <= ALGEBRA and algebra_error <= ALGEBRA and difference_error <= ALGEBRA
        np.savez_compressed(ROOT / "dressing.npz", initial=initial, final=final, initial_source=initial_source,
                            final_source=final_source, native=saved["native"], errors=errors, scales=scales,
                            positions=positions, dressing=dressing, derivative=derivative, indicator=indicator,
                            initial_dressing=initial_dressing, density_offset=density_offset)
        result = dict(conditional_preparation=True, selects_formation_population=False, primary_result_replaced=False,
                      exact_identities=proof, initial_density_current_error=initial_error,
                      algebraic_dressing_error=algebra_error, homogeneous_difference_error=difference_error,
                      implementation_passed=implementation_passed, density_current_max=float(np.max(errors[:, :2])),
                      density_current_failing_modes=int(np.sum(np.max(errors[:, :2], axis=1) > GATE)),
                      pressure_block_max=float(np.max(errors[:, 2])), native_density_current_passed=bool(np.max(errors[:, :2]) <= GATE),
                      sampled_adiabatic_indicator_max=float(np.max(indicator)), indicator_is_uniform_bound=False,
                      unchanged_cold_control=read(ROOT / "transport-result.json")["cold"],
                      contract_sha256=digest(ROOT / "DRESSING-DERIVATION.md"), code_sha256=digest(__file__),
                      model_sha256=digest(ROOT / "model.py"), common_sha256=digest(ROOT / "common.py"),
                      primary_sha256=digest(ROOT / "transport-result.json"), bank_sha256=digest(ROOT / "transport.npz"),
                      output_sha256=digest(ROOT / "dressing.npz"), verified_input_count=len(provenance))
        write("dressing-result.json", result)
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
