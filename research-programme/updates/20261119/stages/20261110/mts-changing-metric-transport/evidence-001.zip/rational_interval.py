from fractions import Fraction

BITS = 192
QUANTUM_DENOMINATOR = 1 << BITS


def fraction(value):
    if isinstance(value, Fraction):
        return value
    return Fraction(value)


def lower_round(value):
    value = fraction(value)
    return Fraction(value.numerator * QUANTUM_DENOMINATOR // value.denominator, QUANTUM_DENOMINATOR)


def upper_round(value):
    value = fraction(value)
    return Fraction(-((-value.numerator * QUANTUM_DENOMINATOR) // value.denominator), QUANTUM_DENOMINATOR)


class Interval:
    def __init__(self, lower, upper=None):
        self.lower = lower_round(lower)
        self.upper = upper_round(lower if upper is None else upper)
        if self.lower > self.upper:
            raise ValueError("inverted interval")

    def __add__(self, other):
        other = as_interval(other)
        return Interval(self.lower + other.lower, self.upper + other.upper)

    __radd__ = __add__

    def __neg__(self):
        return Interval(-self.upper, -self.lower)

    def __sub__(self, other):
        return self + (-as_interval(other))

    def __rsub__(self, other):
        return as_interval(other) - self

    def __mul__(self, other):
        other = as_interval(other)
        products = [self.lower * other.lower, self.lower * other.upper, self.upper * other.lower, self.upper * other.upper]
        return Interval(min(products), max(products))

    __rmul__ = __mul__

    def reciprocal(self):
        if self.lower <= 0 <= self.upper:
            raise ValueError("interval contains zero divisor")
        return Interval(1 / self.upper, 1 / self.lower)

    def __truediv__(self, other):
        return self * as_interval(other).reciprocal()

    def __rtruediv__(self, other):
        return as_interval(other) / self

    def __pow__(self, exponent):
        exponent = int(exponent)
        if exponent < 0:
            return self.reciprocal()**(-exponent)
        if exponent == 0:
            return Interval(1)
        if exponent % 2 == 0 and self.lower <= 0 <= self.upper:
            return Interval(0, max(abs(self.lower), abs(self.upper))**exponent)
        values = [self.lower**exponent, self.upper**exponent]
        return Interval(min(values), max(values))

    def magnitude(self):
        return max(abs(self.lower), abs(self.upper))

    def contains(self, other, strict=False):
        other = as_interval(other)
        return (self.lower < other.lower and other.upper < self.upper) if strict else (self.lower <= other.lower and other.upper <= self.upper)

    def record(self):
        return dict(lower=str(self.lower), upper=str(self.upper), display=[float(self.lower), float(self.upper)])


def as_interval(value):
    return value if isinstance(value, Interval) else Interval(value)


def exp_point(value):
    value = fraction(value)
    halvings = 0
    while abs(value) > Fraction(1, 8):
        value /= 2
        halvings += 1
    argument = Interval(value)
    term, total = Interval(1), Interval(1)
    for degree in range(1, 49):
        term = term * argument / degree
        total += term
    remainder = term.magnitude() * abs(value) / 49 / (1 - abs(value) / 50)
    enclosed = Interval(total.lower - remainder, total.upper + remainder)
    if enclosed.lower <= 0:
        raise ValueError("exponential positivity")
    for _ in range(halvings):
        enclosed = enclosed**2
    return enclosed


def exponential(value):
    value = as_interval(value)
    return Interval(exp_point(value.lower).lower, exp_point(value.upper).upper)
