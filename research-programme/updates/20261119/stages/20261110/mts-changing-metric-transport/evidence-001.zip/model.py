from common import *
import numpy as np
import sympy as sym
from scipy.interpolate import CubicSpline, PPoly
from numpy.polynomial.legendre import leggauss

CENTER = -np.log(11.)
FORMULA = read(PREP / "proof.json")["formula"]
SYMBOLS = sym.symbols(" ".join(FORMULA["variables"]), real=True)
FIRST_FUNCTION = sym.lambdify(SYMBOLS, sym.sympify(FORMULA["first_derivative"], locals=dict(zip(FORMULA["variables"], SYMBOLS))), "numpy", cse=True)


class Case:
    def __init__(self, name, indices=None, stride=1):
        self.name = name
        with np.load(PREP / (name + "-history.npz")) as packet:
            self.history = {key: packet[key].copy() for key in packet.files}
        with np.load(PREP / (name + "-background.npz")) as packet:
            self.background = {key: packet[key].copy() for key in packet.files}
        self.indices = np.arange(399) if indices is None else np.asarray(indices)
        self.wave = self.history["wave"][self.indices]
        self.mass = float(self.background["heavy_mass"])
        self.nu = PPoly(self.background["nu_coefficients"], self.background["nu_knots"])
        self.state_spline = CubicSpline(self.background["position"][::stride], self.background["states"][::stride, :3], axis=0)
        self.metrics = {}
        for variant, selection in (("full", np.arange(7)), ("coarse", np.array([0, 1, 3, 5, 6]))):
            values = np.stack((self.history["potential"][self.indices][:, selection], self.history["lapse"][self.indices][:, selection]), axis=-1)
            self.metrics[variant] = CubicSpline(self.history["original_offsets"][selection], values.transpose(1, 0, 2), axis=0)

    def jets(self, positions):
        positions = np.asarray(positions)
        efold = CENTER + positions
        scale = np.exp(efold)
        field, speed, hubble = np.moveaxis(self.state_spline(positions), -1, 0)
        unit = float(self.background["unit"])
        scalar_mass = scale * float(self.background["slow_mass"])
        dust = (3 * unit**2 * float(self.background["standard_matter"]) + float(self.background["matching_density"])) / scale
        radiation = 3 * unit**2 * float(self.background["standard_radiation"]) / scale**2
        logarithm, slope, curvature, third_log = (self.nu(efold, order) for order in range(4))
        neutrino = 3 * unit**2 * np.exp(logarithm - 2 * efold)
        nu_slope, nu_w = slope - 2, (1 - slope) / 3
        nu_pressure_n = neutrino * (nu_slope * nu_w - curvature / 3)
        nu_pressure_nn = neutrino * ((nu_slope**2 + curvature) * nu_w - 2 * nu_slope * curvature / 3 - third_log / 3)
        density = dust + radiation + neutrino + (speed**2 + scalar_mass**2 * field**2) / 2
        pressure = radiation / 3 + neutrino * nu_w + (speed**2 - scalar_mass**2 * field**2) / 2
        first = -(density + 3 * pressure) / 6
        pressure_first = -2 * hubble * radiation / 3 + hubble * nu_pressure_n - 2 * hubble * speed**2 - hubble * scalar_mass**2 * field**2 - 2 * scalar_mass**2 * field * speed
        density_first = -hubble * (density + 3 * pressure)
        second = -(density_first + 3 * pressure_first) / 6
        pressure_second = (-2 * first + 4 * hubble**2) * radiation / 3 + hubble**2 * nu_pressure_nn + first * nu_pressure_n + (-2 * first + 8 * hubble**2 - 2 * scalar_mass**2) * speed**2 + (-first * scalar_mass**2 - 2 * hubble**2 * scalar_mass**2 + 2 * scalar_mass**4) * field**2 + 2 * hubble * scalar_mass**2 * field * speed
        density_second = -first * (density + 3 * pressure) - hubble * (density_first + 3 * pressure_first)
        third = -(density_second + 3 * pressure_second) / 6
        return scale * self.mass, hubble, first, second, third

    def frequency(self, positions):
        positions = np.asarray(positions).reshape(-1)
        mass, hubble, first, second, third = self.jets(positions)
        reduced = [hubble / mass, first / mass**2, second / mass**3, third / mass**4]
        gradient = (self.wave[None, :] / mass[:, None])**2
        ratio = np.sqrt(1 + gradient)
        carrier_correction = -3 * (2 * reduced[1] + reduced[0]**2) / 8
        carrier = 1 + carrier_correction
        pressure_effective = -2 * first - hubble**2
        beat = mass[:, None] * gradient / (ratio + 1) * (1 - pressure_effective[:, None] / mass[:, None]**2 * (3 * ratio**2 + ratio + 1) / (8 * ratio**3) - reduced[0][:, None]**2 * (ratio + 1) * (2 * ratio**2 + 5) / (8 * ratio**5))
        sideband = carrier[:, None] + beat / mass[:, None]
        carrier_first = reduced[0] + 3 * reduced[0]**3 / 8 - 3 * reduced[2] / 4
        sideband_first = FIRST_FUNCTION(ratio, *[value[:, None] for value in reduced])
        return dict(mass=mass, hubble=hubble, carrier=mass * carrier, sideband=mass[:, None] * sideband,
                    slope0=-mass * carrier_first / (2 * carrier), slopek=-mass[:, None] * sideband_first / (2 * sideband),
                    beat=beat, carrier_correction=carrier_correction)

    def templates(self, positions, phase_order=16):
        positions = np.asarray(positions).reshape(-1)
        values = self.frequency(positions)
        nodes, weights = leggauss(phase_order)
        carrier_phase = np.zeros(len(positions))
        beat_phase = np.zeros((len(positions), len(self.wave)))
        for node, weight in zip(nodes, weights):
            sample = positions * (node + 1) / 2
            frequency = self.frequency(sample)
            carrier_phase += weight * positions / 2 * frequency["carrier"] / frequency["hubble"]
            beat_phase += (weight * positions / 2 / frequency["hubble"])[:, None] * frequency["beat"]
        carrier = matrix(values["carrier"], values["slope0"], carrier_phase)
        sideband = matrix(values["sideband"], values["slopek"], carrier_phase[:, None] + beat_phase)
        return carrier, sideband

    def force(self, positions, variant="full"):
        positions = np.asarray(positions).reshape(-1)
        mass, hubble, *_ = self.jets(positions)
        potentials = self.metrics[variant](positions)
        combined = potentials[..., 1] + 3 * potentials[..., 0]
        difference = 3 * potentials[..., 0] - potentials[..., 1]
        result = np.empty((len(positions), len(self.wave), 2, 2))
        result[..., 0, 0] = -hubble[:, None] * combined
        result[..., 0, 1] = combined
        result[..., 1, 0] = mass[:, None]**2 * difference - hubble[:, None]**2 * combined
        result[..., 1, 1] = hubble[:, None] * combined
        return result


def matrix(frequency, slope, phase):
    amplitude = 1 / np.sqrt(frequency)
    cosine, sine = np.cos(phase), np.sin(phase)
    result = np.empty((*frequency.shape, 2, 2))
    result[..., 0, 0] = amplitude * cosine
    result[..., 0, 1] = amplitude * sine
    result[..., 1, 0] = amplitude * (slope * cosine - frequency * sine)
    result[..., 1, 1] = amplitude * (slope * sine + frequency * cosine)
    return result


def inverse(matrix_value):
    result = np.empty_like(matrix_value)
    result[..., 0, 0], result[..., 0, 1] = matrix_value[..., 1, 1], -matrix_value[..., 0, 1]
    result[..., 1, 0], result[..., 1, 1] = -matrix_value[..., 1, 0], matrix_value[..., 0, 0]
    return result


def prepare(case):
    values = case.frequency([0])
    mass, hubble = values["mass"][0], values["hubble"][0]
    frequency0, frequencyk = values["carrier"][0], values["sideband"][0]
    amplitude = 1 / np.sqrt(frequency0)
    slope0, slopek = values["slope0"][0], values["slopek"][0]
    physical_slope0, physical_slopek = slope0 - hubble, slopek - hubble
    denominator = frequency0**2 + mass**2 + physical_slope0**2
    source_map = np.empty((len(case.wave), 2, 2))
    source_map[:, 0, 0] = 2 * (physical_slope0 * physical_slopek + frequency0 * frequencyk + mass**2) / denominator
    source_map[:, 0, 1] = 2 * (physical_slope0 * frequencyk - frequency0 * physical_slopek) / denominator
    source_map[:, 1, 0], source_map[:, 1, 1] = -2 * mass * physical_slope0 / denominator, 2 * mass * frequency0 / denominator
    eos = (frequency0**2 + physical_slope0**2 - mass**2) / denominator
    density = case.history["density"][case.indices, 3]
    current = case.history["current"][case.indices, 3]
    phase = -mass * current / case.wave
    potential, lapse = case.metrics["full"](0).T
    target = np.column_stack((density + (1 + eos) * lapse, phase))
    relative = np.linalg.solve(source_map, target[:, :, None])[:, :, 0]
    states = np.zeros((len(case.wave), 4, 2))
    states[:, 0, 0] = amplitude
    states[:, 1, 0], states[:, 1, 1] = amplitude * slope0, -amplitude * frequency0
    states[:, 2, :] = amplitude * relative
    physical_prime = amplitude * np.column_stack((slopek * relative[:, 0] + frequencyk * relative[:, 1],
                                                   slopek * relative[:, 1] - frequencyk * relative[:, 0]))
    states[:, 3, :] = physical_prime - (lapse + 3 * potential)[:, None] * (states[:, 1, :] - hubble * states[:, 0, :])
    normalization = np.column_stack((np.maximum.reduce((abs(density), 3 * abs(potential), np.full(len(case.wave), 1e-100))),
                                    np.maximum.reduce((abs(phase), abs(mass * lapse / hubble) * SPAN, np.full(len(case.wave), 1e-100)))))
    microscopic_scale = np.maximum.reduce((np.linalg.norm(relative, axis=1), abs(mass * lapse / hubble) * SPAN,
                                           abs(lapse) + 3 * abs(potential), np.full(len(case.wave), 1e-100)))
    return states, normalization, microscopic_scale


def physical(case, states, position, variant="full"):
    mass, hubble, *_ = case.jets(position)
    potentials = case.metrics[variant](position)
    combined = potentials[:, 1] + 3 * potentials[:, 0]
    result = states.copy()
    result[:, 3, :] += combined[:, None] * (states[:, 1, :] - hubble * states[:, 0, :])
    return result


def normalized(case, states, scale, position, variant="full"):
    result = physical(case, states, position, variant)
    mass_root = np.sqrt(case.mass * np.exp(CENTER))
    result[:, 0, :] *= mass_root
    result[:, 1, :] /= mass_root
    result[:, 2, :] *= (mass_root / scale)[:, None]
    result[:, 3, :] /= (mass_root * scale)[:, None]
    return result.transpose(0, 2, 1)


def propagate(case, initial, integral):
    carrier_first, sideband_first = case.templates([0])
    carrier_final, sideband_final = case.templates([SPAN])
    carrier_coefficients = inverse(carrier_first[0])[None, :, :] @ initial[:, :2, :]
    sideband_coefficients = inverse(sideband_first[0]) @ initial[:, 2:, :]
    result = np.empty_like(initial)
    result[:, :2, :] = carrier_final[0][None, :, :] @ carrier_coefficients
    result[:, 2:, :] = sideband_final[0] @ (sideband_coefficients + integral @ carrier_coefficients)
    return result


def stress(case, states, position, variant="full"):
    mass, hubble, *_ = case.jets(position)
    values = physical(case, states, position, variant)
    carrier, carrier_prime, perturbation, perturbation_prime = (values[:, index, :] for index in range(4))
    speed, perturbed_speed = carrier_prime - hubble * carrier, perturbation_prime - hubble * perturbation
    lapse = case.metrics[variant](position)[:, 1]
    denominator = np.mean(speed**2 + mass**2 * carrier**2, axis=1)
    kinetic = speed * perturbed_speed - speed**2 * lapse[:, None]
    potential = mass**2 * carrier * perturbation
    density = 2 * np.mean(kinetic + potential, axis=1) / denominator
    pressure = 2 * np.mean(kinetic - potential, axis=1) / denominator
    current = 2 * case.wave * np.mean(speed * perturbation, axis=1) / denominator
    return np.column_stack((density, -mass * current / case.wave, pressure))


def integrate(case, panels, variants=("full",), phase_order=16):
    nodes, weights = leggauss(16)
    width = SPAN / panels
    integrals = {variant: np.zeros((len(case.wave), 2, 2)) for variant in variants}
    for first in range(0, panels, 8):
        guard()
        centers = (np.arange(first, min(first + 8, panels)) + .5) * width
        positions = (centers[:, None] + nodes[None, :] * width / 2).ravel()
        quadrature = np.tile(weights, len(centers)) * width / 2
        carrier, sideband = case.templates(positions, phase_order)
        hubble = case.jets(positions)[1]
        for variant in variants:
            transformed = inverse(sideband) @ case.force(positions, variant) @ carrier[:, None, :, :]
            integrals[variant] += np.einsum("t,tnij->nij", quadrature / hubble, transformed)
    return integrals
