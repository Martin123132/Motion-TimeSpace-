from common import *
from model import *
from scipy.integrate import solve_ivp

CHECKS = []


def check(name, error, gate=GATE):
    error = float(error)
    if not np.isfinite(error) or abs(error) > gate:
        raise ValueError(name + ": " + str(error))
    CHECKS.append(dict(name=name, error=error, gate=gate, passed=True))


def cold_control():
    case = Case("cold")
    potential = case.metrics["full"](0)[:, 0]
    density, current = case.history["density"][:, 3], case.history["current"][:, 3]
    initial = np.column_stack((density - 3 * potential, current))
    hubble = case.jets(0)[1]
    lapse = case.metrics["full"](0)[:, 1]
    scale = np.column_stack((np.maximum.reduce((abs(density), 3 * abs(potential), np.full(399, 1e-100))),
                            np.maximum.reduce((abs(current), abs(case.wave * lapse / hubble) * SPAN, np.full(399, 1e-100)))))
    finals, source_finals = [], []
    for variant, tolerance in (("full", 2e-11), ("full", 2e-12), ("coarse", 2e-12)):
        def rhs(position, flattened):
            guard()
            values = flattened.reshape(399, 2) * scale
            hubble = case.jets(position)[1]
            lapse = case.metrics[variant](position)[:, 1]
            return (np.column_stack((-case.wave * values[:, 1] / hubble, -values[:, 1] + case.wave * lapse / hubble)) / scale).ravel()
        solved = solve_ivp(rhs, (0, SPAN), (initial / scale).ravel(), method="DOP853", rtol=tolerance, atol=tolerance / 100, t_eval=[SPAN])
        if not solved.success:
            raise ValueError(solved.message)
        final = solved.y[:, -1].reshape(399, 2) * scale
        final[:, 0] += 3 * case.metrics[variant](SPAN)[:, 0]
        finals.append(final)
    check("cold solver refinement", np.max(abs((finals[0] - finals[1]) / scale)))
    check("cold source interpolation", np.max(abs((finals[2] - finals[1]) / scale)))
    expected = np.column_stack((case.history["density"][:, 4], case.history["current"][:, 4]))
    native_errors = np.max(abs((finals[1] - expected) / scale), axis=1)
    return dict(final=finals[1], native=expected, scale=scale, native_errors=native_errors), dict(
        native_max=float(native_errors.max()), native_pass=bool(np.all(native_errors <= GATE)))


def main():
    with worker("transport"):
        bound = read(ROOT / "background-bound.json")
        for path, checksum in bound["sources"].items():
            guard()
            if digest(path) != checksum:
                raise ValueError("changed input " + path)
        case = Case("heavy")
        initial, normalizer, microscopic_scale = prepare(case)
        target = np.column_stack((case.history["density"][:, 3], -case.mass * np.exp(CENTER) * case.history["current"][:, 3] / case.wave))
        check("initial density/current preparation", np.max(abs((stress(case, initial, 0)[:, :2] - target) / normalizer)), ALGEBRA)
        integrals, finals, source_results = {}, {}, {}
        for panels in (2048, 4096, 8192):
            variants = ("full", "coarse") if panels == 8192 else ("full",)
            result = integrate(case, panels, variants)
            integrals[panels] = result["full"]
            finals[panels] = propagate(case, initial, result["full"])
            source_results[panels] = stress(case, finals[panels], SPAN)
            if panels == 8192:
                coarse_final = propagate(case, initial, result["coarse"])
                coarse_source = stress(case, coarse_final, SPAN, "coarse")
            print(json.dumps(dict(event="quadrature_completed", panels=panels, elapsed=time.monotonic() - START)), flush=True)
        refinement = []
        for lower, higher in ((2048, 4096), (4096, 8192)):
            field_error = float(np.max(abs(normalized(case, finals[lower], microscopic_scale, SPAN) - normalized(case, finals[higher], microscopic_scale, SPAN))))
            source_error = float(np.max(abs((source_results[lower] - source_results[higher]) / normalizer[:, [0, 1, 0]])))
            check("field quadrature " + str((lower, higher)), field_error)
            check("source quadrature " + str((lower, higher)), source_error)
            refinement.append(dict(lower=lower, higher=higher, field_error=field_error, source_error=source_error))
        interpolation_error = float(np.max(abs((coarse_source - source_results[8192]) / normalizer[:, [0, 1, 0]])))
        check("heavy source interpolation", interpolation_error)
        endpoint_mass = case.mass * np.exp(CENTER + SPAN)
        native = np.column_stack((case.history["density"][:, 4], -endpoint_mass * case.history["current"][:, 4] / case.wave,
                                  case.history["pressure"][:, 4]))
        native_errors = abs((source_results[8192] - native) / normalizer[:, [0, 1, 0]])
        cold_arrays, cold_report = cold_control()
        output = dict(wave=case.wave, initial=initial, normalizer=normalizer, microscopic_scale=microscopic_scale,
                      final2048=finals[2048], final4096=finals[4096], final8192=finals[8192],
                      source2048=source_results[2048], source4096=source_results[4096], source8192=source_results[8192],
                      integral8192=integrals[8192], coarse_final=coarse_final, coarse_source=coarse_source,
                      native=native, native_errors=native_errors,
                      **{"cold_" + name: value for name, value in cold_arrays.items()})
        np.savez_compressed(ROOT / "transport.npz", **output)
        report = dict(implementation_checks_passed=True, native_comparison_passed=bool(np.max(native_errors[:, :2]) <= GATE and cold_report["native_pass"]),
                      heavy_native_density_current_max=float(np.max(native_errors[:, :2])), heavy_native_pressure_block_max=float(np.max(native_errors[:, 2])),
                      heavy_native_failing_density_current_modes=int(np.count_nonzero(np.max(native_errors[:, :2], axis=1) > GATE)),
                      cold=cold_report, refinements=refinement, source_interpolation_error=interpolation_error,
                      checks=CHECKS, code_sha256=digest(__file__), model_sha256=digest(ROOT / "model.py"),
                      common_sha256=digest(ROOT / "common.py"), protocol_sha256=digest(ROOT / "PROTOCOL.md"),
                      bound_sha256=digest(ROOT / "background-bound.json"), output_sha256=digest(ROOT / "transport.npz"))
        write("transport-result.json", report)
        print(json.dumps(report))


if __name__ == "__main__":
    main()
