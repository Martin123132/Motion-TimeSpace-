from common import *
from decimal import Decimal, localcontext
from fractions import Fraction
import numpy as np


def main():
    modest()
    output = ROOT / 'addition-oracle-01'
    output.mkdir(exist_ok=False)
    inputs = verify_inputs()
    consumed = {}
    discrepancies = []
    count = 0
    names = ('current', 'phase', 'cross', 'current_and_phase', 'adjoint_interpolation', 'adjoint_steps')
    prior_report_path = SECOND_CELL / LABEL / 'accumulation-01/result.json'
    present_report_path = ROOT / 'all-source-projection-01/result.json'
    prior_report = read(prior_report_path)
    present_report = read(present_report_path)
    consumed[str(prior_report_path)] = digest(prior_report_path)
    consumed[str(present_report_path)] = digest(present_report_path)
    for model in ('heavy', 'cold'):
        prior_row = next(row for row in prior_report['reports'] if row['model'] == model)
        present_row = next(row for row in present_report['reports'] if row['model'] == model)
        for row in (prior_row, present_row):
            require(digest(row['path']) == row['sha256'], 'unchanged numerical inputs')
            consumed[row['path']] = row['sha256']
        prior = load(prior_row['path'])
        present = load(present_row['path'])
        pairs = [
            ('fine_signed', prior['fine_signed'], present['signed']),
            ('coarse_signed', prior['coarse_signed'], present['coarse_signed']),
            ('fine_triangle_budget', prior['fine_triangle_budget'], present['budget']),
            ('coarse_triangle_budget', prior['coarse_triangle_budget'], present['coarse_budget']),
            ('quadrature_absolute_sum', prior['quadrature_absolute_sum'], abs(present['signed'] - present['coarse_signed'])),
            ('budget_change_absolute_sum', prior['budget_change_absolute_sum'], abs(present['budget'] - present['coarse_budget'])),
        ]
        for column, name in enumerate(names):
            pairs.append((name, prior['change_' + name], present['changes'][column]))
            pairs.append((name + '_absolute_sum', prior['change_' + name + '_absolute_sum'], abs(present['changes'][column])))
        for name, left, right in pairs:
            answer = left + right
            for index in np.ndindex(answer.shape):
                count += 1
                exact_sum = Fraction.from_float(float(left[index])) + Fraction.from_float(float(right[index]))
                exact = float(exact_sum)
                actual = float(answer[index])
                require(actual == exact, 'exact-rational correctly-rounded addition')
                with localcontext() as context:
                    context.prec = 90
                    decimal = float(Decimal.from_float(float(left[index])) + Decimal.from_float(float(right[index])))
                if actual != decimal:
                    require(float(np.nextafter(actual, decimal)) == decimal, 'oracle discrepancy is one binary64 ULP')
                    midpoint = (Fraction.from_float(actual) + Fraction.from_float(decimal)) / 2
                    require(exact_sum == midpoint, 'finite-decimal double rounding at an exact binary midpoint')
                    discrepancies.append(dict(model=model,quantity=name,index=index,
                        left=float(left[index]).hex(),right=float(right[index]).hex(),
                        numpy=actual.hex(),decimal90=decimal.hex(),exact_rational=exact.hex(),
                        exact_halfway_case=True))
    require(all(digest(path) == checksum for path, checksum in consumed.items()), 'oracle audit input integrity')
    write(output / 'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,
        cases=count,exact_rational_disagreements=0,finite_decimal_disagreements=len(discrepancies),
        discrepancies=discrepancies,numerical_inputs_changed=False,tolerances_changed=False,
        conclusion='The production binary64 additions are correctly rounded; the 90-digit decimal round-trip is not an exact bitwise oracle at binary halfway cases.'))
    print('exact-rational addition cases',count,'pass; decimal-oracle halfway cases',len(discrepancies),flush=True)


if __name__ == '__main__':
    main()
