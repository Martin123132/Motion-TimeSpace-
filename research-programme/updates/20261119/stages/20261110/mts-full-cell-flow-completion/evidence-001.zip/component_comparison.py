from common import *
from continuation_audit import integrate, independently_integrate
from response_support import NAMES
from decimal import Decimal, localcontext
import numpy as np


def exact_difference(weights, left, right):
    result=np.zeros(left.shape[1:])
    with localcontext() as context:
        context.prec=90
        for index in np.ndindex(result.shape):
            result[index]=float(sum(Decimal.from_float(float(weight))*
                (Decimal.from_float(float(left[(node,)+index]))-Decimal.from_float(float(right[(node,)+index])))
                for node,weight in enumerate(weights)))
    return result


def main():
    modest()
    output=ROOT/'component-comparison-01'
    output.mkdir(exist_ok=False)
    consumed={}
    manifests={}
    def saved(owner,path):
        if owner not in manifests:
            manifests[owner]={str(Path(row['path']).resolve()):row['sha256'] for row in read(owner/'closeout.json')['artifacts']}
        checksum=manifests[owner][str(Path(path).resolve())]
        require(digest(path)==checksum,'sealed component input')
        consumed[str(path)]=checksum
        return load(path)
    def current(path):
        consumed[str(path)]=digest(path)
        return read(path)
    source=current(ROOT/'all-source-projection-01/result.json')
    audit=current(STAGE/'completed-audit/result.json')
    require(source['passed'] and audit['passed'],'validated complete source and flow')
    require(audit['completed_ordinals']==list(range(158)) and audit['node_count']==2750,'exact complete MTS coverage')
    require(all(row['complete_cell'] for row in source['reports']),'both complete source cells')
    require(digest(audit['accumulated'])==audit['accumulated_sha256'],'audited flow bytes')
    consumed[audit['accumulated']]=audit['accumulated_sha256']
    accumulated=load(audit['accumulated'])
    columns=[list(NAMES).index(name) for name in ('Pi','delta_massless')]
    reports=[]
    for model in ('heavy','cold'):
        entry=next(row for row in source['reports'] if row['model']==model)
        require(digest(entry['path'])==entry['sha256'],'complete source projection bytes')
        consumed[entry['path']]=entry['sha256']
        complete=load(entry['path'])
        metric=saved(DIRECT_SOURCE,DIRECT_SOURCE/LABEL/'metric-projection-01'/f'{model}-metric-projection.npz')
        flow=saved(DIRECT_SOURCE,DIRECT_SOURCE/LABEL/'stress-balance-01'/f'{model}-stress-balance.npz')
        original=saved(REFINEMENT,REFINEMENT/LABEL/'source-attribution-01'/f'{model}-attribution.npz')
        require(np.array_equal(metric['weights'],flow['weights']) and
                np.array_equal(metric['refinement_weights'],flow['refinement_weights']),'same old integration rules')
        require(np.array_equal(metric['reference_scale'],complete['reference_scale'][:,columns]),'same terminal observable normalization')
        if model=='heavy':
            new_flow=accumulated['fine']
            flow_refinement=accumulated['quadrature']
        else:
            baseline=saved(SEGMENT_STAGE,SEGMENT_STAGE/LABEL/'projection-01/cold-segments.npz')
            require(np.all(baseline['controls'][...,2]==0),'saved baseline has zero heavy-flow component')
            new_flow=integrate(np.ones(len(baseline['fine'])),baseline['fine'][...,2])
            flow_refinement=integrate(np.ones(len(baseline['delta'])),baseline['delta'][...,2])
        remainder=exact_difference(metric['weights'],original['original'],flow['components'][...,2])
        coarse_remainder=exact_difference(metric['weights']-metric['refinement_weights'],
                                          original['original'],flow['components'][...,2])
        old_identity=metric['original_fine']-flow['fine'][...,2]
        algebra=float(np.max(abs(remainder-old_identity)/metric['budget']))
        require(algebra<ALGEBRA,'independent old nonflow integral identity')
        hybrid=remainder+new_flow
        coarse_hybrid=coarse_remainder+new_flow-flow_refinement
        direct=complete['signed'][:,columns]
        direct_coarse=complete['coarse_signed'][:,columns]
        direct_nonflow=direct-new_flow
        discrepancy=direct-hybrid
        identity_error=float(np.max(abs(discrepancy-(direct_nonflow-remainder))/metric['budget']))
        require(identity_error<ALGEBRA,'direct minus hybrid equals nonflow mismatch')
        diagnostics=abs(discrepancy)/metric['budget']
        rows=[]
        for branch,name in enumerate(('gr','poisson')):
            for channel,observable in enumerate(('Pi','delta_massless')):
                index=(branch,channel)
                rows.append(dict(branch=name,channel=observable,
                    direct_minus_hybrid_over_original_budget=float(discrepancy[index]/metric['budget'][index]),
                    direct_minus_hybrid_over_reference=float(discrepancy[index]/metric['reference_scale'][index]),
                    comparison_pass=bool(diagnostics[index]<GATE),
                    old_nonflow_refinement_over_original_budget=float((remainder-coarse_remainder)[index]/metric['budget'][index]),
                    hybrid_refinement_over_original_budget=float((hybrid-coarse_hybrid)[index]/metric['budget'][index])))
        target=output/(model+'-components.npz')
        np.savez_compressed(target,direct=direct,direct_coarse=direct_coarse,hybrid=hybrid,
            coarse_hybrid=coarse_hybrid,old_remainder=remainder,old_coarse_remainder=coarse_remainder,
            new_flow=new_flow,flow_refinement=flow_refinement,direct_nonflow=direct_nonflow,
            discrepancy=discrepancy,budget=metric['budget'],reference_scale=metric['reference_scale'])
        reports.append(dict(model=model,path=str(target),sha256=digest(target),rows=rows,
            numerical_pass_count=sum(row['comparison_pass'] for row in rows),
            original_remainder_identity_error=algebra,comparison_identity_error=identity_error,
            full_source_pass_count=entry['numerical_pass_count']))
        print(model,'direct versus hybrid',reports[-1]['numerical_pass_count'],'of4; maximum difference/budget',
              float(np.max(diagnostics)),flush=True)
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'unchanged source evidence')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,
        identity='Q_new(S) - [Q_old(S-F)+Q_new(F)] = Q_new(S-F)-Q_old(S-F)',
        full_source_retained=True,no_flow_removal=True,no_new_native_calls=True,
        algebra_gate=ALGEBRA,comparison_gate=GATE,
        mixed_grid_agreement_is_not_a_continuum_certificate=True,no_automatic_source_promotion=True))


if __name__=='__main__':
    main()

