from common import *
from all_source_projection import source_catalog
from response_support import NAMES, BRANCHES
from decimal import Decimal, localcontext
import numpy as np


CONTROL_NAMES = ('current', 'phase', 'cross', 'current_and_phase',
                 'adjoint_interpolation', 'adjoint_steps')


def checked_sum(left, right):
    answer = left + right
    with localcontext() as context:
        context.prec = 90
        for index in np.ndindex(answer.shape):
            exact = float(Decimal.from_float(float(left[index])) +
                          Decimal.from_float(float(right[index])))
            require(float(answer[index]) == exact, 'independent cumulative addition')
    return answer


def main():
    modest()
    inputs = verify_inputs()
    consumed = {}
    manifests = {}

    def inherited(owner, path, json_file=False):
        path = Path(path)
        if owner not in manifests:
            manifests[owner] = {str(Path(row['path']).resolve()): row['sha256']
                               for row in read(owner / 'closeout.json')['artifacts']}
        checksum = manifests[owner][str(path.resolve())]
        require(digest(path) == checksum, 'sealed cumulative input')
        consumed[str(path)] = checksum
        return read(path) if json_file else load(path)

    def current_json(path):
        consumed[str(path)] = digest(path)
        return read(path)

    def current_array(path, checksum):
        require(digest(path) == checksum, 'new cell evidence unchanged')
        consumed[str(path)] = checksum
        return load(path)

    audit = current_json(STAGE / 'completed-audit/result.json')
    full = current_json(ROOT / 'all-source-projection-01/result.json')
    comparison = current_json(ROOT / 'component-comparison-01/result.json')
    require(audit['passed'] and full['passed'] and comparison['passed'], 'completed full-cell checks')
    require(audit['completed_ordinals'] == list(range(158)) and audit['node_count'] == 2750,
            'exact complete frozen coverage')
    require(all(row['complete_cell'] for row in full['reports']), 'both full source cells')
    require(full['channel_names'] == list(NAMES), 'same observable order')
    require(full['diagnostic_names'] == ['quadrature', 'budget'] + list(CONTROL_NAMES),
            'same source-control order')
    prior = inherited(SECOND_CELL, SECOND_CELL / LABEL / 'accumulation-01/result.json', True)
    require(prior['completed'] and prior['original_cell_indices'] == [[0, 4], [4, 8]],
            'use exactly the previous two-cell total')
    old_total = inherited(REFINEMENT, REFINEMENT / LABEL / 'accumulation-01/result.json', True)
    second_grid = inherited(SECOND_CELL, SECOND_CELL / LABEL / 'grid-01/result.json', True)
    third_grid = inherited(THIRD_CELL, THIRD_CELL / LABEL / 'grid-01/result.json', True)
    frozen = inherited(FROZEN_STAGE, FROZEN_STAGE / LABEL / 'freeze-01/result.json', True)
    baseline_weights = inherited(SEGMENT_STAGE, SEGMENT_STAGE / LABEL / 'exact-weights-01/result.json', True)
    derivation_path = SEGMENT_STAGE / 'DERIVATION.md'
    derivation_checksum = manifests[SEGMENT_STAGE][str(derivation_path.resolve())]
    require(digest(derivation_path) == derivation_checksum, 'sealed direct-measure derivation')
    consumed[str(derivation_path)] = derivation_checksum
    heavy_catalog = source_catalog(frozen, audit['completed_ordinals'])
    output = ROOT / 'accumulation-01'
    output.mkdir(exist_ok=False)
    reports = []
    records = []
    for model in ('heavy', 'cold'):
        guard()
        previous_entry = next(row for row in prior['reports'] if row['model'] == model)
        previous = inherited(SECOND_CELL, previous_entry['path'])
        present_entry = next(row for row in full['reports'] if row['model'] == model)
        present = current_array(present_entry['path'], present_entry['sha256'])
        previous_third_entry = next(row for row in old_total['reports'] if row['model'] == model)
        previous_third = inherited(REFINEMENT, previous_third_entry['path'])
        require(np.array_equal(previous_third['reference_scale'], previous['reference_scale']),
                'old and repaired three-cell totals use the same reference')
        grids = []
        for owner, metadata in ((SECOND_CELL, second_grid), (THIRD_CELL, third_grid)):
            entry = next(row for row in metadata['reports'] if row['model'] == model)
            grids.append(inherited(owner, entry['path']))
        require(all(grids[0][key][-1] == grids[1][key][0] for key in grids[0]),
                'same adjacent physical state, phase and measure endpoints')
        require(np.array_equal(previous['boundaries'][-2:], [grids[0]['efold'][0], grids[0]['efold'][-1]]),
                'two-cell boundary provenance')
        require(np.array_equal(previous['reference_scale'], present['reference_scale']),
                'same terminal adjoint observable normalization')
        require(abs(float(present['volume']) - float(grids[1]['efold'][-1] - grids[1]['efold'][0])) <
                ALGEBRA * float(present['volume']), 'complete direct dN volume')
        left = inherited(SECOND_CELL, SECOND_CELL / LABEL / 'projection-cell02' / (model + '-projection.npz'))
        if model == 'heavy':
            endpoint_entries = (heavy_catalog[0][0], heavy_catalog[157][-1])
        else:
            segments = next(row['segments'] for row in baseline_weights['reports'] if row['model'] == 'cold')
            endpoint_entries = tuple(dict(path=str(SEGMENT_STAGE / LABEL / 'points-01' /
                                         ('cold-' + format(index, '03d') + '-flow-result.json')))
                                     for index in (segments[0]['indices'][0], segments[-1]['indices'][-1]))
        endpoints = []
        for endpoint in endpoint_entries:
            receipt = current_json(Path(endpoint['path']))
            source = current_array(receipt['source'], receipt['source_sha256'])
            phase = current_array(receipt['phase'], receipt['phase_sha256'])
            endpoints.append((source, phase))
        require(float(endpoints[0][0]['efold']) == float(grids[1]['efold'][0]) and
                float(endpoints[-1][0]['efold']) == float(grids[1]['efold'][-1]),
                'projected source has exact third-cell endpoints')
        require(np.array_equal(left['projected'][-1], endpoints[0][0]['projected']) and
                np.array_equal(left['phase_projected'][-1], endpoints[0][1]['projected']),
                'shared boundary source and controls unchanged')
        arrays = {
            'fine_signed': checked_sum(previous['fine_signed'], present['signed']),
            'coarse_signed': checked_sum(previous['coarse_signed'], present['coarse_signed']),
            'fine_triangle_budget': checked_sum(previous['fine_triangle_budget'], present['budget']),
            'coarse_triangle_budget': checked_sum(previous['coarse_triangle_budget'], present['coarse_budget']),
            'quadrature_absolute_sum': checked_sum(previous['quadrature_absolute_sum'],
                                                    abs(present['signed'] - present['coarse_signed'])),
            'budget_change_absolute_sum': checked_sum(previous['budget_change_absolute_sum'],
                                                       abs(present['budget'] - present['coarse_budget'])),
        }
        expected_names = set('change_' + name for name in CONTROL_NAMES) | {'change_clock_measure'}
        actual_names = {name for name in previous if name.startswith('change_') and
                        not name.endswith('_absolute_sum')}
        require(actual_names == expected_names, 'all inherited numerical controls accounted for')
        for column, name in enumerate(CONTROL_NAMES):
            key = 'change_' + name
            arrays[key] = checked_sum(previous[key], present['changes'][column])
            arrays[key + '_absolute_sum'] = checked_sum(previous[key + '_absolute_sum'],
                                                        abs(present['changes'][column]))
        arrays['change_clock_measure'] = previous['change_clock_measure'].copy()
        arrays['change_clock_measure_absolute_sum'] = previous['change_clock_measure_absolute_sum'].copy()
        scale = previous['reference_scale']
        budget = np.maximum(arrays['fine_triangle_budget'], 1e-80)
        model_rows = []
        for branch, branch_name in enumerate(BRANCHES):
            for column, name in enumerate(NAMES):
                index = (branch, column)
                previous_row = next(row for row in prior['records'] if row['model'] == model and
                                    row['branch'] == branch_name and row['channel'] == name)
                present_row = next(row for row in present_entry['rows'] if row['branch'] == branch_name and
                                   row['channel'] == name)
                diagnostics = dict(quadrature=float(arrays['quadrature_absolute_sum'][index] / budget[index]),
                                   budget=float(arrays['budget_change_absolute_sum'][index] / budget[index]))
                diagnostics.update({key.removeprefix('change_'):
                                    float(arrays[key + '_absolute_sum'][index] / budget[index])
                                    for key in sorted(actual_names)})
                cell_passes = previous_row['cell_numerical_passes'] + [present_row['numerical_comparison_pass']]
                inside = bool(abs(arrays['fine_signed'][index]) <= budget[index] * (1 + GATE))
                passed = bool(previous_row['numerical_pass'] and all(cell_passes) and
                              max(diagnostics.values()) < GATE and inside)
                row = dict(model=model, branch=branch_name, channel=name, cell_numerical_passes=cell_passes,
                           numerical_pass=passed, cauchy_check=inside, diagnostics=diagnostics,
                           signed_contribution=float(arrays['fine_signed'][index]),
                           triangle_budget=float(budget[index]),
                           physical_contribution_fraction=float(arrays['fine_signed'][index] / scale[index]),
                           physical_budget_fraction=float(budget[index] / scale[index]),
                           physical_quadrature_change_allowance=float(arrays['quadrature_absolute_sum'][index] / scale[index]),
                           change_from_previous_three_cell_fraction=float(
                               (arrays['fine_signed'][index] - previous_third['fine_signed'][index]) / scale[index]))
                records.append(row)
                model_rows.append(row)
        target = output / (model + '-accumulation.npz')
        np.savez_compressed(target, reference_scale=scale,
                            boundaries=np.r_[previous['boundaries'], grids[1]['efold'][-1]], **arrays)
        reports.append(dict(model=model, path=str(target), sha256=digest(target),
                            passed=sum(row['numerical_pass'] for row in model_rows),
                            cell_pass_counts=previous_entry['cell_pass_counts'] + [present_entry['numerical_pass_count']],
                            largest_physical_contribution=max(abs(row['physical_contribution_fraction']) for row in model_rows),
                            largest_physical_budget=max(row['physical_budget_fraction'] for row in model_rows),
                            largest_physical_quadrature_change_allowance=max(row['physical_quadrature_change_allowance'] for row in model_rows),
                            largest_change_from_previous_three_cell_fraction=max(
                                abs(row['change_from_previous_three_cell_fraction']) for row in model_rows)))
        print(model, 'three cells:', reports[-1]['passed'], 'of20; contribution',
              reports[-1]['largest_physical_contribution'], 'budget', reports[-1]['largest_physical_budget'], flush=True)
    require(all(digest(path) == checksum for path, checksum in consumed.items()), 'unchanged cumulative evidence')
    write(output / 'result.json', dict(passed=True, completed=True, inputs=inputs, sources=sources(), consumed=consumed,
          reports=reports, records=records, original_cell_indices=[[0, 4], [4, 8], [8, 12]],
          exact_two_cell_input=True, same_terminal_adjoint=True, no_response_reset=True,
          third_cell_measure='direct dN, with exact frozen-interval moments',
          third_cell_clock_measure_control='not applicable: no approximate phase-to-N Jacobian is used',
          inherited_clock_measure_controls_retained=True,
          physical_phase_and_current_source_controls_retained=True,
          third_cell_derivation_source=str(SEGMENT_STAGE / 'DERIVATION.md'),
          coarser_cumulative_rule_not_invented=True,
          cancellation_cannot_mask_failed_cell=True, whole_history_error_claimed=False,
          continuum_budget_certificate=False, no_new_background_solve=True,
          all_numerical_controls_pass=all(row['numerical_pass'] for row in records),
          unchanged_gates=[ALGEBRA, GATE]))


if __name__ == '__main__':
    main()
