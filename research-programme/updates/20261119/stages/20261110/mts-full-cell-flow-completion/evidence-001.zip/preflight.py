from common import *
import full_cell_sources
import continuation_audit
import all_source_projection


def main():
    modest()
    consumed=verify_inputs()
    output=ROOT/'preflight-01'
    output.mkdir(parents=True,exist_ok=False)
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    require(Path(full_cell_sources.__file__).resolve()==FROZEN_STAGE/'full_cell_sources.py','unchanged original source implementation')
    require(full_cell_sources.ROOT==ROOT and full_cell_sources.FROZEN_STAGE==FROZEN_STAGE,'new ownership and original freeze')
    for name in ('continuation_audit.py','all_source_projection.py'):
        require((STAGE/name).read_text().rstrip()==(PREVIOUS_STAGE/name).read_text().rstrip(),'unchanged audit and full-source mathematics')
    parent_audit=(FROZEN_STAGE/'full_cell_audit_v2.py').read_text()
    expected=parent_audit.replace(
        "batches=[ROOT/'batches/probe-result.json'] if mode=='probe' else sorted((ROOT/'batches').glob('batch*-result.json'))",
        "batches=[ROOT/'batches/probe-result.json'] if mode=='probe' else sorted(path for parent in (*INHERITED_BATCH_STAGES,STAGE) for path in (parent/LABEL/'batches').glob('batch*-result.json'))")
    require(expected.rstrip()==(STAGE/'continuation_audit.py').read_text().rstrip(),'original audit mathematics unchanged')
    manifests={}
    for parent in INHERITED_BATCH_STAGES:
        manifests[parent]={str(Path(row['path']).resolve()):row['sha256'] for row in read(parent/'closeout.json')['artifacts']}
    def sealed(parent,path):
        checksum=manifests[parent][str(path.resolve())]
        require(digest(path)==checksum,'sealed inherited input')
        consumed[str(path)]=checksum
    freeze_path=FROZEN_STAGE/LABEL/'freeze-01/result.json'
    parent_path=PREVIOUS_STAGE/'completed-audit/result.json'
    sealed(FROZEN_STAGE,freeze_path)
    sealed(PREVIOUS_STAGE,parent_path)
    frozen,parent=read(freeze_path),read(parent_path)
    expected_ordinals=list(range(136))+[157]
    require(frozen['points']==2750 and len(frozen['segments'])==158,'same complete-cell freeze')
    require(parent['passed'] and parent['completed_ordinals']==expected_ordinals,'exact inherited coverage')
    require(parent['node_count']==2393,'exact inherited node count')
    require(PROBE_SEGMENT==136 and PROBE_SEGMENT not in expected_ordinals,'first unfinished segment')
    require(digest(frozen['path'])==frozen['sha256'],'unchanged complete grid bytes')
    consumed[frozen['path']]=frozen['sha256']
    for owner,numbers in ((FROZEN_STAGE,range(5)),(MIDDLE_STAGE,range(5,12)),(PREVIOUS_STAGE,range(12,17))):
        for number in numbers:
            sealed(owner,owner/LABEL/'batches'/f'batch{number:02d}-result.json')
    catalog=all_source_projection.source_catalog(frozen,expected_ordinals)
    require(sorted(catalog)==expected_ordinals,'both inherited catalogues retained')
    for ordinal,entries in catalog.items():
        require([entry['index'] for entry in entries]==frozen['segments'][ordinal]['indices'],'complete inherited node identities')
    remaining=[row for row in frozen['segments'] if row['ordinal'] not in expected_ordinals]
    require(len(remaining)==21 and sum(len(row['indices']) for row in remaining)==357,'remaining work exact')
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'preflight inputs unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,
        inherited_segments=137,inherited_nodes=2393,frozen_segments=158,frozen_nodes=2750,
        remaining_segments=21,remaining_nodes=357,probe_ordinal=136,physical_code_unchanged=True,
        complete_prior_catalogue_retained=True,no_history_or_native_calls=True,unchanged_gates=[ALGEBRA,GATE]))
    print('final-panel adapter checked:137 inherited segments;21 remaining;original freeze retained',flush=True)


if __name__=='__main__':
    main()


