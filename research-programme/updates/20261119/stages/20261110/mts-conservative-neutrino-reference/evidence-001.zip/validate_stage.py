from shell_support import *
from check_reference import MASS_GRID
import csv
import numpy as np


def exited(identity):
    try:
        process = psutil.Process(identity["pid"])
        created, command = process.create_time(), process.cmdline()
    except psutil.NoSuchProcess:
        return dict(exited=True, reason="PID absent")
    same = abs(created - identity["created"]) < .01 and command == identity["command"]
    return dict(exited=not same, reason="original identity live" if same else "PID reused; not touched",
                observed_creation=created, observed_command=command)


def main():
    with worker("validation-complete"):
        checks = []

        def check(name, condition, **details):
            checks.append(dict(name=name, passed=bool(condition), **details))

        inputs = preserved()
        check("frozen inherited inputs", inputs == read(ROOT / "frozen-inputs.json"), count=len(inputs))
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            check("compile " + path.name, True)
        check("no bytecode cache", not list(ROOT.rglob("__pycache__")))
        proof = read(ROOT / "proof.json")
        reference = read(ROOT / "reference-result.json")
        construction = read(ROOT / "construction-result.json")
        check("eight background identities", proof["passed"] and len(proof["identities"]) == 8)
        check("five kinetic identities", construction["kinetics"]["passed"] and len(construction["kinetics"]["identities"]) == 5)
        for report, name in ((proof, "prove_shell.py"), (reference, "check_reference.py"), (construction, "verify_construction.py")):
            check("source hash " + name, digest(ROOT / name) == report["code_sha256"])
        for report in (reference, construction):
            check("model source hash", report["model_sha256"] == digest(ROOT / "shell_model.py"))
        check("independent-check input hash", construction["reference_sha256"] == digest(ROOT / "reference-result.json"))
        check("original tolerances", reference["gate"] == GATE and reference["algebra_gate"] == ALGEBRA)
        check("no production change or new evolution", not reference["production_changed"] and not reference["saved_evolutions_rerun"]
              and not construction["production_changed"] and not construction["new_evolution"])
        saved = read(SOURCE / "continuum-reference.json")["reports"]
        masses = set(MASS_GRID) | {entry["am"] for entry in saved}
        names = {"native5", "gauss16", "gauss32", "gauss64"}
        expected = {(name, mass) for name in names for mass in masses}
        check("full frozen reference coverage", len(reference["rows"]) == len(expected)
              and {(row["rule"], row["am"]) for row in reference["rows"]} == expected,
              mass_count=len(masses), case_count=len(expected))
        check("manufactured multipole coverage", len(construction["discrete"]["rows"]) == len(expected)
              and {(row["rule"], row["am"]) for row in construction["discrete"]["rows"]} == expected)
        check("both baseline and heavy original backgrounds retained",
              {(entry["case"], entry["fraction"]) for entry in saved}
              == {(case, fraction) for case in ("cold", "heavy", "D0", "D01") for fraction in (0., .5, 1.)})
        for row in reference["rows"]:
            expected_saved = [dict(case=entry["case"], fraction=entry["fraction"])
                              for entry in saved if entry["am"] == row["am"]]
            check("source mapping " + row["rule"] + " " + str(row["am"]), row["saved_cases"] == expected_saved)
            check("conservation and positive occupation " + row["rule"] + " " + str(row["am"]),
                  row["conservation_passed"] and row["positive_occupation_bound"])
        check("coarse accuracy failures retained",
              not reference["summaries"]["native5"]["continuum_accuracy_passed"]
              and not reference["summaries"]["gauss16"]["continuum_accuracy_passed"])
        check("both fine reference rules pass",
              reference["summaries"]["gauss32"]["continuum_accuracy_passed"]
              and reference["summaries"]["gauss64"]["continuum_accuracy_passed"])
        check("independent primitive accuracy", construction["primitives"]["passed"]
              and len(construction["primitives"]["rows"]) == 36
              and construction["primitives"]["maximum_relative_error"] <= ALGEBRA)
        check("all kinetic and negative controls",
              all(row["passed"] and row["one_sided_weight_mutation_error"] > ALGEBRA
                  for row in construction["discrete"]["rows"]))
        check("all limiting cases", len(construction["discrete"]["limits"]) == 4
              and all(row["passed"] for row in construction["discrete"]["limits"]))
        with np.load(ROOT / "shell-rules.npz", allow_pickle=False) as packet:
            check("rule packet complete", set(packet.files) == {name + suffix for name in names for suffix in ("_nodes", "_weights")})
            for name, count in (("native5", 5), ("gauss16", 16), ("gauss32", 32), ("gauss64", 64)):
                nodes, weights = packet[name + "_nodes"], packet[name + "_weights"]
                check("positive finite rule " + name, nodes.shape == weights.shape == (count,)
                      and np.all(np.isfinite(nodes)) and np.all(np.isfinite(weights))
                      and np.all(nodes > 0) and np.all(weights > 0) and np.all(np.diff(nodes) > 0))
        check("first attempt failure preserved", read(ROOT / "reference-end.json")["state"] == "failed"
              and "not JSON serializable" in read(ROOT / "reference-end.json")["error"]
              and (ROOT / "check_reference_attempt1.py").is_file())
        cited = [
            SOURCE / "DERIVATION.md", SOURCE / "check_neutrino.py",
            SOURCE / "neutrino-prediction-result.json",
            POST / "condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/massive_neutrinos.f90",
        ]
        for path in cited:
            check("cited source exists " + str(path), path.is_file() and str(path) in inputs)
        csv_rows = []
        for row in reference["rows"]:
            csv_rows.append(dict(rule=row["rule"], am=row["am"], saved_cases=json.dumps(row["saved_cases"]),
                                 density_relative_error=row["relative_moment_errors"]["density"],
                                 pressure_relative_error=row["relative_moment_errors"]["pressure"],
                                 enthalpy_relative_error=row["relative_moment_errors"]["enthalpy"],
                                 density_derivative_error=row["derivative_errors_scaled_by_density_or_pressure"]["density_log_mass_rate"],
                                 pressure_derivative_error=row["derivative_errors_scaled_by_density_or_pressure"]["pressure_log_mass_rate"],
                                 conservation_passed=row["conservation_passed"], continuum_accuracy_passed=row["continuum_accuracy_passed"]))
        with (ROOT / "reference-comparison.csv").open(encoding="utf-8", newline="") as stream:
            parsed = list(csv.DictReader(stream))
        check("CSV complete and well formed", len(parsed) == 60 and all(None not in row and None not in row.values() for row in parsed))
        check("CSV reuses exact original rows", parsed == [{key: str(value) for key, value in row.items()} for row in csv_rows])
        processes = []
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name == "validation-complete-start.json":
                continue
            identity = read(path)
            status = exited(identity)
            terminal = read(ROOT / path.name.replace("-start.json", "-end.json"))
            expected_state = "failed" if path.name in ("reference-start.json", "validation-start.json") else "completed"
            check("worker exited " + path.name, status["exited"])
            check("terminal receipt " + path.name, terminal["state"] == expected_state
                  and all(terminal[key] == identity[key] for key in ("pid", "created", "command")))
            processes.append(dict(receipt=path.name, identity=identity, status=status, ending=terminal["state"]))
        result = dict(passed=all(row["passed"] for row in checks), checks=checks, workers=processes,
                      input_count=len(inputs), code_sha256=digest(__file__), cited_paths=[str(path) for path in cited],
                      scientific_outcome="One positive distribution derives matched background and linear perturbation moments; separately tested fine quadratures approximate the retained thermal continuum.",
                      production_repair_applied=False, new_evolution=False,
                      native5_continuum_gate=False, gauss16_continuum_gate=False,
                      gauss32_continuum_gate=True, gauss64_continuum_gate=True)
        write("validation-complete.json", result)
        print(json.dumps(dict(passed=result["passed"], checks=len(checks), inputs=len(inputs),
                              failed=[row for row in checks if not row["passed"]]), indent=2))
        require(result["passed"], "honest stage validation")


if __name__ == "__main__":
    main()
