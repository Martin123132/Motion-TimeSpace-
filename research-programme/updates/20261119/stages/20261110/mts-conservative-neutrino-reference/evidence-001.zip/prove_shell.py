from shell_support import *
import sympy as sym


def main():
    with worker("proof"):
        inputs = preserved()
        write("frozen-inputs.json", inputs)
        momentum, mass, weight, scale, hubble = sym.symbols("momentum mass weight scale hubble", positive=True)
        energy = sym.sqrt(momentum**2 + mass**2)
        density_integral = (momentum * energy * (2 * momentum**2 + mass**2) - mass**4 * sym.asinh(momentum / mass)) / 8
        pressure_integral = (momentum * energy * (2 * momentum**2 - 3 * mass**2) + 3 * mass**4 * sym.asinh(momentum / mass)) / 8
        rate_integral = mass**2 * momentum * energy / 2 - 3 * mass**4 * sym.asinh(momentum / mass) / 2 + mass**4 * momentum / energy
        identities = {}
        identities["density_primitive"] = sym.diff(density_integral, momentum) - momentum**2 * energy
        identities["pressure_primitive"] = sym.diff(pressure_integral, momentum) - momentum**4 / energy
        identities["pressure_derivative_primitive"] = sym.diff(rate_integral, momentum) - mass**2 * momentum**4 / energy**3
        density = 4 * weight * density_integral / momentum**4
        pressure = 4 * weight * pressure_integral / (3 * momentum**4)
        enthalpy = 4 * weight * energy / (3 * momentum)
        identities["shared_enthalpy"] = density + pressure - enthalpy
        identities["mass_derivative_density"] = mass * sym.diff(density, mass) - density + 3 * pressure
        identities["mass_derivative_pressure"] = mass * sym.diff(pressure, mass) + 4 * weight * rate_integral / (3 * momentum**4)
        identities["background_continuity"] = hubble * (-2 * density + mass * sym.diff(density, mass) + density + 3 * pressure) / scale**2
        identities["enthalpy_derivative"] = mass * sym.diff(density + pressure, mass) - 4 * weight * mass**2 / (3 * momentum * energy)
        for name, expression in identities.items():
            require(sym.simplify(expression) == 0, name)
        result = dict(passed=True, identities=list(identities), code_sha256=digest(__file__),
                      meaning="Exact finite-shell kinetic identities for positive masses and momenta; the massless limit is separately tested.")
        write("proof.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    main()
