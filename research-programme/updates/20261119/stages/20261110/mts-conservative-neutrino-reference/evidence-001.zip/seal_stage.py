from shell_support import *
from validate_stage import exited


def main():
    with worker("seal"):
        validation = read(ROOT / "validation-complete.json")
        require(validation["passed"], "validated stage")
        require(validation["code_sha256"] == digest(ROOT / "validate_stage.py"), "same validator")
        inputs = preserved()
        require(inputs == read(ROOT / "frozen-inputs.json"), "same inherited sources")
        for name in ("DERIVATION.md", "RESULTS.md", "NEXT.md", "PROTOCOL.md", "SERIALIZATION-REPAIR.md"):
            require((ROOT / name).is_file(), "document " + name)
        compiled, workers = [], []
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            compiled.append(path.name)
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name == "seal-start.json":
                continue
            identity = read(path)
            status = exited(identity)
            require(status["exited"], "worker still live " + path.name)
            workers.append(dict(receipt=path.name, identity=identity, status=status))
        require(not list(ROOT.rglob("__pycache__")), "no bytecode")
    artifacts = {}
    for path in sorted(ROOT.iterdir()):
        require(path.is_file() and path.name != "closeout.json", "unexpected artifact or reseal")
        artifacts[path.name] = dict(sha256=digest(path), bytes=path.stat().st_size)
    write("closeout.json", dict(state="verified_progress_conservative_neutrino_reference", goal_complete=False,
          utc=datetime.now(timezone.utc).isoformat(), input_hashes=inputs, artifacts=artifacts,
          workers=workers, compiled_after_validation=compiled, validation_checks=len(validation["checks"]),
          exact_identities=13, finite_reference_cases=60, independent_primitive_cases=36,
          retained_negative_results=["native5 continuum accuracy", "gauss16 continuum accuracy"],
          production_repair_applied=False, new_evolution=False, new_fitted_parameters=0,
          next="NEXT.md", cleanup="Check exited identities and this manifest from a separate post-seal worker."))
    print(json.dumps(dict(seal_sha256=digest(ROOT / "closeout.json"), inputs=len(inputs),
                          artifacts=len(artifacts), validation_checks=len(validation["checks"]))))


if __name__ == "__main__":
    main()
