from shell_support import *
from validate_stage import exited


def main():
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline())
    seal = read(ROOT / "closeout.json")
    require(seal["state"] == "verified_progress_conservative_neutrino_reference", "expected seal")
    for path, checksum in seal["input_hashes"].items():
        guard()
        require(digest(path) == checksum, "inherited hash " + path)
    for name, entry in seal["artifacts"].items():
        require(digest(ROOT / name) == entry["sha256"], "artifact hash " + name)
        require((ROOT / name).stat().st_size == entry["bytes"], "artifact length " + name)
    require(not list(ROOT.rglob("__pycache__")), "no bytecode")
    workers = []
    for path in sorted(ROOT.glob("*-start.json")):
        receipt = read(path)
        status = exited(receipt)
        require(status["exited"], "task-owned worker live " + path.name)
        terminal = read(ROOT / path.name.replace("-start.json", "-end.json"))
        require(all(terminal[key] == receipt[key] for key in ("pid", "created", "command")), "same worker identity")
        workers.append(dict(receipt=path.name, identity=receipt, status=status, ending=terminal["state"]))
    write("CLEANUP-VERIFIED.json", dict(passed=True, utc=datetime.now(timezone.utc).isoformat(),
          seal_sha256=digest(ROOT / "closeout.json"), inherited_files=len(seal["input_hashes"]),
          artifacts=len(seal["artifacts"]), workers=workers, verifier_identity=identity,
          verifier_exit="Confirm this short verifier's exit via its launching tool result.",
          apps_started=[], servers_started=[], other_processes_changed=False,
          continuing_job=False, cleanup_action="Verified task-owned calculation identities absent; nothing killed."))
    print(json.dumps(dict(passed=True, seal_sha256=digest(ROOT / "closeout.json"),
                          inherited_files=len(seal["input_hashes"]), artifacts=len(seal["artifacts"]),
                          exited_workers=len(workers), verifier_pid=identity["pid"])))


if __name__ == "__main__":
    main()
