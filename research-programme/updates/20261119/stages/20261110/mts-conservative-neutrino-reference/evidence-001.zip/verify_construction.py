from shell_support import *
from shell_model import radial_primitives, native_rule, reference_rule, moments
import numpy as np
import mpmath as mp
import sympy as sym


def symbolic_kinetics():
    momentum, mass, weight, scale, hubble, wave = sym.symbols(
        "momentum mass weight scale hubble wave", positive=True)
    monopole, dipole, quadrupole, geometry = sym.symbols(
        "monopole dipole quadrupole geometry", real=True)
    speed = momentum / sym.sqrt(momentum**2 + mass**2)
    density_weight = weight / (scale**2 * speed)
    current_weight = weight / scale**2
    stress_weight = weight * speed / scale**2
    density = density_weight * monopole
    current = current_weight * dipole
    pressure = stress_weight * monopole / 3
    anisotropy = stress_weight * quadrupole
    enthalpy = 4 * density_weight / 3
    density_weight_prime = hubble * (scale * sym.diff(density_weight, scale)
                                    + mass * sym.diff(density_weight, mass))
    current_weight_prime = hubble * scale * sym.diff(current_weight, scale)
    density_prime = density_weight_prime * monopole - wave * density_weight * (
        4 * geometry / 3 + speed * dipole)
    current_prime = current_weight_prime * dipole + wave * current_weight * speed * (
        monopole - 2 * quadrupole) / 3
    energy = density_prime + hubble * (density + 3 * pressure) + wave * current + wave * geometry * enthalpy
    momentum_budget = current_prime + 2 * hubble * current - wave * pressure + 2 * wave * anisotropy / 3
    identities = {
        "density_weight_derivative": density_weight_prime + hubble * (1 + speed**2) * density_weight,
        "current_weight_derivative": current_weight_prime + 2 * hubble * current_weight,
        "positive_moment_relation": current_weight**2 - density_weight * stress_weight,
        "shell_energy_conservation": energy,
        "shell_current_conservation": momentum_budget,
    }
    for name, expression in identities.items():
        require(sym.simplify(expression) == 0, name)
    return dict(passed=True, identities=list(identities),
                scope="Linear collisionless synchronous hierarchy; no fluid or relativistic-tail replacement.")


def primitive_checks():
    mp.mp.dps = 60
    rows = []
    for momentum_value in (.1, 1., 13., 59.9):
        for ratio in (0., 1e-8, .1, 1., 3.999999999, 4., 4.000000001, 10., 1e6):
            guard()
            mass_value = momentum_value * ratio
            momentum = mp.mpf(float(momentum_value))
            mass = mp.mpf(float(mass_value))
            actual = radial_primitives([momentum_value], mass_value)
            if mass == 0:
                reference = [momentum**4 / 4, momentum**4 / 4, mp.mpf(0)]
            else:
                def energy(position):
                    return mp.sqrt((momentum * position)**2 + mass**2)
                reference = [
                    mp.quad(lambda position: momentum**3 * position**2 * energy(position), [0, 1]),
                    mp.quad(lambda position: momentum**5 * position**4 / energy(position), [0, 1]),
                    mp.quad(lambda position: mass**2 * momentum**5 * position**4 / energy(position)**3, [0, 1]),
                ]
            errors = []
            for calculated, expected in zip(actual, reference):
                difference = abs(mp.mpf(float(calculated[0])) - expected)
                errors.append(float(difference / abs(expected)) if expected else float(difference))
            rows.append(dict(momentum=momentum_value, mass=mass_value,
                             relative_primitive_errors=errors, passed=max(errors) <= ALGEBRA))
    return dict(passed=all(row["passed"] for row in rows), rows=rows,
                maximum_relative_error=max(max(row["relative_primitive_errors"]) for row in rows),
                mpmath_decimal_precision=mp.mp.dps,
                method="Independent integration of each primitive, including both sides of the small-ratio series switch.")


def discrete_checks():
    report = read(ROOT / "reference-result.json")
    rules = {"native5": native_rule(), **{"gauss" + str(count): reference_rule(count) for count in (16, 32, 64)}}
    rows, limits = [], []
    for name, (nodes, weights) in rules.items():
        for entry in [row for row in report["rows"] if row["rule"] == name]:
            mass = entry["am"]
            values = moments(nodes, weights, mass)
            speed = nodes / np.sqrt(nodes**2 + mass**2)
            monopoles = np.cos(nodes)
            dipoles = np.sin(nodes)
            quadrupoles = np.cos(nodes / 3)
            density_weights = weights / speed
            current_weights = weights
            stress_weights = weights * speed
            hubble, wave, geometry = np.longdouble(.7), np.longdouble(5), np.longdouble(-.23)
            density = np.sum(density_weights * monopoles)
            current = np.sum(current_weights * dipoles)
            pressure = np.sum(stress_weights * monopoles) / 3
            anisotropy = np.sum(stress_weights * quadrupoles)
            density_prime = np.sum(-hubble * (1 + speed**2) * density_weights * monopoles
                                   - wave * density_weights * (4 * geometry / 3 + speed * dipoles))
            current_prime = -2 * hubble * current + wave * np.sum(
                current_weights * speed * (monopoles - 2 * quadrupoles)) / 3
            energy_terms = [density_prime, hubble * (density + 3 * pressure),
                            wave * current, wave * geometry * (values["density"] + values["pressure"])]
            current_terms = [current_prime, 2 * hubble * current, -wave * pressure,
                             2 * wave * anisotropy / 3]
            energy_error = float(abs(sum(energy_terms)) / max(abs(value) for value in energy_terms))
            current_error = float(abs(sum(current_terms)) / max(abs(value) for value in current_terms))
            mutated_weights = weights.copy()
            mutated_weights[np.argmax(density_weights)] *= np.longdouble(1.01)
            mutated = moments(nodes, mutated_weights, mass)
            broken_energy = energy_terms[:-1] + [wave * geometry * (mutated["density"] + mutated["pressure"])]
            broken_error = float(abs(sum(broken_energy)) / max(abs(value) for value in broken_energy))
            rows.append(dict(rule=name, am=mass, saved_cases=entry["saved_cases"],
                             energy_error=energy_error, current_error=current_error,
                             one_sided_weight_mutation_error=broken_error,
                             passed=energy_error <= ALGEBRA and current_error <= ALGEBRA and broken_error > ALGEBRA))
        massless = moments(nodes, weights, 0)
        asymptotic_mass = np.longdouble(1e6)
        asymptotic = moments(nodes, weights, asymptotic_mass)
        expected_number = np.sum(4 * weights / (3 * nodes))
        expected_pressure = np.sum(4 * weights * nodes / 15)
        limit_errors = dict(
            massless_density=float(abs(massless["density"] - np.sum(weights)) / np.sum(weights)),
            massless_pressure=float(abs(3 * massless["pressure"] - massless["density"]) / massless["density"]),
            nonrelativistic_density=float(abs(asymptotic["density"] / asymptotic_mass - expected_number) / expected_number),
            nonrelativistic_pressure=float(abs(asymptotic_mass * asymptotic["pressure"] - expected_pressure) / expected_pressure))
        limits.append(dict(rule=name, errors=limit_errors, passed=max(limit_errors.values()) <= ALGEBRA))
    return dict(passed=all(row["passed"] for row in rows + limits), rows=rows, limits=limits,
                qualification="Manufactured multipoles test algebra/implementation, not re-evolved cold or MTS perturbations.")


def main():
    with worker("construction"):
        require(read(ROOT / "reference-result.json")["passed"], "completed separate reference")
        require(preserved() == read(ROOT / "frozen-inputs.json"), "frozen source histories")
        kinetic = symbolic_kinetics()
        primitives = primitive_checks()
        discrete = discrete_checks()
        report = dict(passed=kinetic["passed"] and primitives["passed"] and discrete["passed"],
                      kinetics=kinetic, primitives=primitives, discrete=discrete,
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "shell_model.py"),
                      reference_sha256=digest(ROOT / "reference-result.json"),
                      longdouble_significand_bits=np.finfo(np.longdouble).nmant,
                      production_changed=False, new_evolution=False)
        write("construction-result.json", report)
        print(json.dumps(dict(passed=report["passed"], exact_identities=len(kinetic["identities"]),
                              primitive_cases=len(primitives["rows"]),
                              maximum_primitive_error=primitives["maximum_relative_error"],
                              discrete_cases=len(discrete["rows"]), limits=discrete["limits"],
                              failed_primitive=[row for row in primitives["rows"] if not row["passed"]],
                              failed_discrete=[row for row in discrete["rows"] if not row["passed"]]), indent=2))
        require(report["passed"], "independent primitive, kinetic and limit checks")


if __name__ == "__main__":
    main()
