from shell_support import *
import math
import numpy as np
from numpy.polynomial.legendre import leggauss

NORMALIZATION = 7 * math.pi**4 / 120


def radial_primitives(momentum, mass):
    momentum = np.asarray(momentum, dtype=np.longdouble)
    mass = np.longdouble(mass)
    require(mass >= 0 and np.all(momentum > 0), "physical momentum and mass")
    if mass == 0:
        common = momentum**4 / 4
        return common, common.copy(), np.zeros_like(common)
    ratio = momentum / mass
    density, pressure, pressure_rate = [np.empty_like(momentum) for unused in range(3)]
    small = ratio < .25
    if np.any(small):
        values = ratio[small]
        outputs = []
        for exponent, initial_power in ((.5, 3), (-.5, 5), (-1.5, 5)):
            coefficient = np.longdouble(1)
            total = np.zeros_like(values)
            for index in range(20):
                if index:
                    coefficient *= (np.longdouble(exponent) - index + 1) / index
                total += coefficient * values**(2 * index + initial_power) / (2 * index + initial_power)
            outputs.append(mass**4 * total)
        density[small], pressure[small], pressure_rate[small] = outputs
    if np.any(~small):
        values = momentum[~small]
        energy = np.sqrt(values**2 + mass**2)
        logarithm = np.arcsinh(values / mass)
        density[~small] = (values * energy * (2 * values**2 + mass**2) - mass**4 * logarithm) / 8
        pressure[~small] = (values * energy * (2 * values**2 - 3 * mass**2) + 3 * mass**4 * logarithm) / 8
        pressure_rate[~small] = mass**2 * values * energy / 2 - 3 * mass**4 * logarithm / 2 + mass**4 * values / energy
    require(np.all(density > 0) and np.all(pressure > 0) and np.all(pressure_rate >= 0), "positive radial primitives")
    return density, pressure, pressure_rate


def native_rule():
    saved = read(SOURCE / "continuum-reference.json")
    nodes = np.array(saved["nodes"], dtype=np.longdouble)
    weights = np.array(saved["unnormalized_weights"], dtype=np.longdouble) / np.longdouble(NORMALIZATION)
    return nodes, weights


def reference_rule(count):
    require(count in (16, 32, 64), "frozen reference family")
    abscissa, integration_weights = leggauss(count)
    nodes = np.asarray(30 * (abscissa + 1), dtype=np.longdouble)
    exponential = np.exp(-nodes)
    derivative = exponential / (1 + exponential)**2
    weights = np.asarray(30 * integration_weights, dtype=np.longdouble) * nodes**4 * derivative / (4 * np.longdouble(NORMALIZATION))
    require(np.all(weights > 0), "positive shell weights")
    return nodes, weights


def moments(nodes, weights, mass):
    nodes = np.asarray(nodes, dtype=np.longdouble)
    weights = np.asarray(weights, dtype=np.longdouble)
    density_integrals, pressure_integrals, pressure_rate_integrals = radial_primitives(nodes, mass)
    energy = np.sqrt(nodes**2 + np.longdouble(mass)**2)
    density = np.sum(4 * weights * density_integrals / nodes**4)
    pressure = np.sum(4 * weights * pressure_integrals / (3 * nodes**4))
    enthalpy = np.sum(4 * weights * energy / (3 * nodes))
    density_log_mass_rate = density - 3 * pressure
    pressure_log_mass_rate = -np.sum(4 * weights * pressure_rate_integrals / (3 * nodes**4))
    enthalpy_log_mass_rate = np.sum(4 * weights * np.longdouble(mass)**2 / (3 * nodes * energy))
    return dict(density=density, pressure=pressure, enthalpy=enthalpy,
                density_log_mass_rate=density_log_mass_rate, pressure_log_mass_rate=pressure_log_mass_rate,
                enthalpy_log_mass_rate=enthalpy_log_mass_rate,
                occupation_at_zero=np.sum(4 * np.longdouble(NORMALIZATION) * weights / nodes**4),
                massless_density=np.sum(weights), nonrelativistic_number=np.sum(4 * weights / (3 * nodes)))
