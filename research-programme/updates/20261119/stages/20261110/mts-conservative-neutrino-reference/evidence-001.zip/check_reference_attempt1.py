from shell_support import *
from shell_model import moments, native_rule, reference_rule, NORMALIZATION
import math
import numpy as np
from scipy.integrate import quad

MASS_GRID = (0., 1e-6, .1, 1., 10., 32.4, 70., 100., 1000.)


def continuum(mass):
    def integrands(momentum):
        energy = math.hypot(momentum, mass)
        exponential = math.exp(-momentum)
        occupation = exponential / (1 + exponential)
        if energy == 0:
            return (0., 0., 0., 0.)
        return (momentum**2 * energy * occupation / NORMALIZATION,
                momentum**4 * occupation / (3 * energy * NORMALIZATION),
                momentum**2 * mass**2 * occupation / (energy * NORMALIZATION),
                -momentum**4 * mass**2 * occupation / (3 * energy**3 * NORMALIZATION))
    values, errors = {}, {}
    for index, name in enumerate(("density", "pressure", "density_log_mass_rate", "pressure_log_mass_rate")):
        value, error = quad(lambda momentum: integrands(momentum)[index], 0, np.inf, epsabs=1e-11, epsrel=2e-13, limit=160)
        values[name], errors[name] = value, error
    values["enthalpy"] = values["density"] + values["pressure"]
    values["enthalpy_log_mass_rate"] = values["density_log_mass_rate"] + values["pressure_log_mass_rate"]
    return values, errors


def test_case(name, mass, nodes, weights, reference, estimated_errors):
    calculated = moments(nodes, weights, mass)
    errors = {key: float(abs(calculated[key] - reference[key]) / max(abs(reference[key]), 1e-100)) for key in ("density", "pressure", "enthalpy")}
    derivative_errors = {key: float(abs(calculated[key] - reference[key]) / max(abs(reference["density" if key.startswith("density") else "pressure"]), 1e-100)) for key in ("density_log_mass_rate", "pressure_log_mass_rate")}
    enthalpy_identity_error = float(abs(calculated["density"] + calculated["pressure"] - calculated["enthalpy"]) / calculated["enthalpy"])
    derivative_identity_error = float(abs(calculated["density_log_mass_rate"] + calculated["pressure_log_mass_rate"] - calculated["enthalpy_log_mass_rate"]) / calculated["enthalpy"])
    return dict(rule=name, am=float(mass), values={key: float(value) for key, value in calculated.items()},
                continuum=reference, estimated_continuum_errors=estimated_errors,
                relative_moment_errors=errors, derivative_errors_scaled_by_density_or_pressure=derivative_errors,
                enthalpy_identity_error=enthalpy_identity_error, derivative_identity_error=derivative_identity_error,
                conservation_passed=max(enthalpy_identity_error, derivative_identity_error) <= ALGEBRA,
                continuum_accuracy_passed=max(*errors.values(), *derivative_errors.values()) <= GATE,
                positive_occupation_bound=0 < calculated["occupation_at_zero"] <= 1)


def main():
    with worker("reference"):
        require(read(ROOT / "proof.json")["passed"], "derived shell identities")
        require(preserved() == read(ROOT / "frozen-inputs.json"), "same inherited inputs")
        rules = {"native5": native_rule(), **{"gauss" + str(count): reference_rule(count) for count in (16, 32, 64)}}
        rows = []
        saved = read(SOURCE / "continuum-reference.json")["reports"]
        masses = sorted(set(MASS_GRID) | {row["am"] for row in saved})
        for mass in masses:
            reference, estimated_errors = continuum(mass)
            for name, (nodes, weights) in rules.items():
                row = test_case(name, mass, nodes, weights, reference, estimated_errors)
                row["saved_cases"] = [dict(case=entry["case"], fraction=entry["fraction"]) for entry in saved if entry["am"] == mass]
                rows.append(row)
        np.savez_compressed(ROOT / "shell-rules.npz", **{name + "_" + field: values[index] for name, values in rules.items() for index, field in enumerate(("nodes", "weights"))})
        summaries = {}
        for name in rules:
            selected = [row for row in rows if row["rule"] == name]
            summaries[name] = dict(conservation_passed=all(row["conservation_passed"] for row in selected),
                                   continuum_accuracy_passed=all(row["continuum_accuracy_passed"] for row in selected),
                                   maximum_relative_moment_error=max(value for row in selected for value in row["relative_moment_errors"].values()),
                                   maximum_derivative_error=max(value for row in selected for value in row["derivative_errors_scaled_by_density_or_pressure"].values()),
                                   maximum_identity_error=max(max(row["enthalpy_identity_error"], row["derivative_identity_error"]) for row in selected),
                                   maximum_saved_background_moment_error=max(value for row in selected if row["saved_cases"] for value in row["relative_moment_errors"].values()),
                                   occupation_at_zero=selected[0]["values"]["occupation_at_zero"],
                                   failed_masses=[row["am"] for row in selected if not row["continuum_accuracy_passed"]])
        result = dict(rows=rows, summaries=summaries, gate=GATE, algebra_gate=ALGEBRA,
                      passed=all(row["conservation_passed"] and row["positive_occupation_bound"] for row in rows) and summaries["gauss64"]["continuum_accuracy_passed"],
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "shell_model.py"),
                      production_changed=False, saved_evolutions_rerun=False,
                      derivative_comparison="Errors normalized by density or pressure, not a derivative that vanishes in the massless limit.",
                      qualification="Finite-shell identities are exact algebra; continuum accuracy is sampled numerical reference evidence, not a uniform enclosure.")
        write("reference-result.json", result)
        print(json.dumps(dict(passed=result["passed"], summaries=summaries, mass_count=len(masses)), indent=2))
        require(result["passed"], "conservative reference construction")


if __name__ == "__main__":
    main()
