from common import *
import difflib
import importlib.util
import shutil


def main():
    with worker("build-v2"):
        source = ROOT / "build/camb_python.f90"
        original = source.read_text(encoding="utf-8")
        unused_guard = "        if (.not.EV%MassiveNuApprox(eigen)) then\n            if (EV%G11(eigen)/=0 .or. EV%G30(eigen)/=0) error stop 'inactive neutrino memory nonzero'\n        end if\n"
        require(original.count(unused_guard) == 1, "known inactive-only guard")
        updated = original.replace(unused_guard, "")
        destination = ROOT / "build-v2"
        destination.mkdir(exist_ok=False)
        (destination / "camb_python.f90").write_text(updated, encoding="utf-8")
        (ROOT / "adapter-v2.diff").write_text("".join(difflib.unified_diff(original.splitlines(True), updated.splitlines(True), fromfile="build/camb_python.f90", tofile="build-v2/camb_python.f90")), encoding="utf-8")
        owner = POST / "mts-state-feedback-20261107/build_probe.py"
        specification = importlib.util.spec_from_file_location("retained_isolated_builder", owner)
        builder = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(builder)
        builder.ROOT = destination
        builder.main()
        auxiliary = destination / "native/fortran"
        auxiliary.mkdir(exist_ok=False)
        import_data = NATIVE / "fortran/HighLExtrapTemplate_lenspotentialCls.dat"
        shutil.copy2(import_data, auxiliary / import_data.name)
        require(digest(import_data) == digest(auxiliary / import_data.name), "import data")
        write(ROOT / "build-v2-complete.json", dict(passed=True, parent_adapter_sha256=digest(source), adapter_sha256=digest(destination / "camb_python.f90"),
              inactive_memory_not_read=True, active_memory_mapping_unchanged=True, original_equations_unchanged=True, builder_sha256=digest(owner), source_sha256=digest(__file__)))


if __name__ == "__main__":
    main()
