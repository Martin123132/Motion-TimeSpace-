import os
import sys
for setting in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[setting] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PARENT = POST / "mts-canonical-metric-closure-20261110"
HIERARCHY = POST / "mts-retarded-hierarchy-20261107"
BRANCH = POST / "condensate-origin-20261003"
PRIOR = POST / "mts-metric-feedback-20261107"
NATIVE = BRANCH / "native-heavy-matching-20261007/native"
EARLY = BRANCH / "native-two-field-transfer-20261007"
SPECTRUM = BRANCH / "resolved-matter-spectrum-20261007"
BRIDGE = Path("C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102")
START = time.monotonic()
GATE, ALGEBRA = 2e-5, 1e-10


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, value):
    encoded = json.dumps(value, indent=2, allow_nan=False)
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(encoded)


def guard():
    require(time.monotonic() - START < 900, "bounded worker deadline")
    for path in (ROOT / "STOP-REQUESTED", POST / "STOP-REQUESTED", PARENT / "STOP-REQUESTED", BRIDGE / "STOP-REQUESTED", BRIDGE.parent / "execution-v3/STOP-REQUEST.json"):
        require(not path.exists(), "owner hold: " + str(path))


def modest():
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    guard()


@contextmanager
def worker(name):
    modest()
    process = psutil.Process()
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), started=datetime.now(timezone.utc).isoformat())
    write(ROOT / (name + "-start.json"), identity)
    try:
        yield
    except BaseException as error:
        write(ROOT / (name + "-end.json"), dict(**identity, state="failed", error=repr(error)))
        raise
    else:
        write(ROOT / (name + "-end.json"), dict(**identity, state="completed", elapsed=time.monotonic() - START))


def preserved():
    require(digest(PARENT / "closeout.json") == "afce7e9dd9cadbceadc7fd33bc8b70b9f3893f80c06416c909b54d089ca7d6ec", "parent seal")
    seal = read(PARENT / "closeout.json")
    inputs = dict(seal["input_hashes"])
    inputs[str(PARENT / "closeout.json")] = digest(PARENT / "closeout.json")
    inputs.update({str(PARENT / name): row["sha256"] for name, row in seal["artifacts"].items()})
    for path, checksum in inputs.items():
        guard()
        require(digest(path) == checksum, "retained input changed: " + path)
    return inputs
