from common import *
import difflib
import importlib.util
import shutil


def main():
    with worker("build-v3"):
        source = ROOT / "build-v2/camb_python.f90"
        original = source.read_text(encoding="utf-8")
        declaration = "    integer(c_int), bind(C, name='mts_capture_begin') :: mts_capture_begin = 0"
        capture_call = "        if (mts_capture_begin>0 .and. j>=mts_capture_begin .and. j<=mts_capture_end) call mts_capture_store(EV,tau,y,yprime)"
        require(original.count(declaration) == 1 and original.count(capture_call) == 1, "known capture interface")
        updated = original.replace(declaration, declaration + "\n    integer(c_int), bind(C, name='mts_capture_q_index') :: mts_capture_q_index = 1")
        updated = updated.replace(capture_call, "        if (mts_capture_begin>0 .and. EV%q_ix==mts_capture_q_index .and. j>=mts_capture_begin .and. j<=mts_capture_end) call mts_capture_store(EV,tau,y,yprime)")
        destination = ROOT / "build-v3"
        destination.mkdir(exist_ok=False)
        (destination / "camb_python.f90").write_text(updated, encoding="utf-8")
        (ROOT / "adapter-v3.diff").write_text("".join(difflib.unified_diff(original.splitlines(True), updated.splitlines(True), fromfile="build-v2/camb_python.f90", tofile="build-v3/camb_python.f90")), encoding="utf-8")
        owner = POST / "mts-state-feedback-20261107/build_probe.py"
        specification = importlib.util.spec_from_file_location("retained_isolated_builder", owner)
        builder = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(builder)
        builder.ROOT = destination
        builder.main()
        auxiliary = destination / "native/fortran"
        auxiliary.mkdir(exist_ok=False)
        import_data = NATIVE / "fortran/HighLExtrapTemplate_lenspotentialCls.dat"
        shutil.copy2(import_data, auxiliary / import_data.name)
        write(ROOT / "build-v3-complete.json", dict(passed=True, parent_adapter_sha256=digest(source), adapter_sha256=digest(destination / "camb_python.f90"),
              selected_mode_capture_only=True, original_equations_unchanged=True, code_sha256=digest(__file__)))


if __name__ == "__main__":
    main()
