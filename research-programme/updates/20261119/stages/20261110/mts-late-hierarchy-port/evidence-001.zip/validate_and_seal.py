from common import *
import numpy as np


def exact_process_live(identity):
    try:
        process = psutil.Process(identity["pid"])
        return abs(process.create_time() - identity["created"]) < .01 and process.is_running()
    except psutil.NoSuchProcess:
        return False


def main():
    with worker("validation"):
        checks, receipts = [], []
        def check(name, condition):
            checks.append(dict(name=name, passed=bool(condition)))
            require(condition, name)
        inputs = read(ROOT / "frozen-inputs.json")
        for directory_name in ("build", "build-v2", "build-v3"):
            directory = ROOT / directory_name
            build = read(directory / "build-result.json")
            check(directory_name + " build completed", build["state"] == "complete")
            check(directory_name + " adapter ownership", digest(directory / "camb_python.f90") == build["source_sha256"])
            check(directory_name + " DLL ownership", digest(directory / "native/camb/cambdll.dll") == build["dll_sha256"])
            check(directory_name + " temporary mappings released", build["temporary_mappings_removed"])
            inputs.update(build["original_input_hashes"])
            inputs.update(build["reused_object_module_hashes"])
            for process in build["processes"]:
                for identity in [process, *process["children"]]:
                    live = exact_process_live(identity)
                    receipts.append(dict(owner=directory_name, pid=identity["pid"], creation=identity["created"], command=identity["command"], running=live))
                    check("compiler exited " + str(identity["pid"]), not live)
        for label, expected_dimension in (("heavy", 93), ("cold", 91)):
            directory = ROOT / "runs" / (label + "-v4")
            config = read(directory / "config.json")
            reference = read(directory / "scoped-reference.json")
            capture = read(directory / "capture.json")
            operator = read(directory / "operator.json")
            result = read(directory / "result.json")
            check(label + " unchanged driver", config["code_sha256"] == digest(ROOT / "run_port.py") == result["code_sha256"])
            check(label + " fixed benchmark settings", config["wave"] == 5. and config["full_schedule_count"] == 61 and config["tolerance"] == [2e-11, 2e-12] and config["numerical_gate"] == GATE and config["algebra_gate"] == ALGEBRA)
            check(label + " explicit native and historical scope", reference["passed"] and reference["native_overlap"] == 0 and reference["late_historical_overlap"] <= GATE and not reference["full_historical_passed"])
            check(label + " capture artifact ownership", capture["output_sha256"] == digest(directory / "capture.npz"))
            check(label + " late dimension and selector", capture["dimension"] == expected_dimension and capture["selector_value"] == (1 if label == "heavy" else 0))
            check(label + " operator gates", operator["passed"] and all(row["passed"] for row in operator["checks"]))
            check(label + " independent integration and controls", result["passed"] and len(result["reports"]) == 4 and all(row["passed"] for row in result["reports"]))
            check(label + " no future species forcing or new scalar block", result["future_species_forcing"] is False and result["native_scalar_block_unchanged"] is True)
            inputs[config["packet"]] = config["packet_sha256"]
            inputs[config["table"]] = config["table_sha256"]
            inputs[str(SPECTRUM / "runs" / label / "status.json")] = config["status_sha256"]
            inputs[str(NATIVE.parent / "matching_common.py")] = config["factory_sha256"]
            inputs[str(PRIOR / "observer.dll")] = config["observer_dll_sha256"]
            with np.load(directory / "capture.npz") as packet:
                check(label + " active-memory untested explicitly", np.count_nonzero(packet["memory_indices"]) == 0)
                check(label + " actual captured shape", packet["state"].shape == (2, expected_dimension) and np.isfinite(packet["state"]).all())
            with np.load(directory / "precision.npz") as packet:
                check(label + " independent result finite", packet["state"].shape == (2, expected_dimension) and np.isfinite(packet["state"]).all())
        metric = read(ROOT / "metric-result-fixed.json")
        check("paired gravity and precision identities", metric["passed"] and len(metric["metric_checks"]) == 10 and all(row["passed"] for row in metric["metric_checks"] + metric["refinements"]))
        check("metric checker source", metric["code_sha256"] == digest(ROOT / "check_metric.py"))
        check("native-control failed archive gate retained", read(ROOT / "native-batch-control.json")["passed"] is False)
        check("scoped acceptance decided explicitly", (ROOT / "REPLAY-SCOPE-DECISION.md").is_file())
        partial = ROOT / "metric-result.json"
        try:
            read(partial)
            partial_failed = False
        except json.JSONDecodeError:
            partial_failed = True
        check("known partial failed report not promoted", partial_failed and read(ROOT / "metric-check-end.json")["state"] == "failed")
        for path, checksum in inputs.items():
            guard()
            check("input " + path, digest(path) == checksum)
        for path in ROOT.glob("*.py"):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        check("all new scripts compile in memory", True)
        check("no bytecode", not list(ROOT.rglob("__pycache__")) and not list(ROOT.rglob("*.pyc")))
        for path in ROOT.glob("*-start.json"):
            identity = read(path)
            if identity["pid"] == os.getpid():
                continue
            live = exact_process_live(identity)
            receipts.append(dict(owner=path.name, pid=identity["pid"], creation=identity["created"], command=identity["command"], running=live))
            check("worker exited " + path.name, not live)
            ending = path.with_name(path.name.replace("-start.json", "-end.json"))
            if path.name == "port-heavy-start.json":
                check("native-stop receipt from exec", not live and not ending.exists())
            else:
                check("worker terminal receipt " + path.name, ending.is_file() and read(ending)["state"] in ("completed", "failed"))
        write(ROOT / "native-error-stop-receipt.json", dict(state="failed_terminal", pid=36740, creation=1794303016.3438783, tool_exit_code=1,
              error="inactive neutrino memory nonzero", pid_confirmed_absent=True, python_finally_bypassed=True, source="exec terminal exit and subsequent identity inspection; not a retry of a live worker"))
        write(ROOT / "validation.json", dict(passed=True, checks=checks, receipts=receipts, input_count=len(inputs), accepted_runs=["heavy-v4", "cold-v4"],
              historical_full_span_passed=False, active_neutrino_memory_numerically_validated=False, code_sha256=digest(__file__)))
    artifacts = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.rglob("*")) if path.is_file()}
    write(ROOT / "closeout.json", dict(state="verified_progress", utc=datetime.now(timezone.utc).isoformat(), previous_goal_turn="progress",
          goal_complete=False, input_hashes=inputs, artifacts=artifacts, accepted_runs=["runs/heavy-v4", "runs/cold-v4"],
          physical_scope="retained all-species late hierarchy port/control, not new scalar-response insertion or historical full-span reproduction",
          finalizer_pid=os.getpid(), finalizer_exit_requires_external_confirmation=True))
    print(json.dumps(dict(state="verified_progress", inputs=len(inputs), artifacts=len(artifacts), checks=len(checks), seal=digest(ROOT / "closeout.json"), finalizer_pid=os.getpid())), flush=True)


if __name__ == "__main__":
    main()
