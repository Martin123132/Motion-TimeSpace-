from common import *
import numpy as np


def main():
    with worker("capture-diagnostic"):
        reports = []
        for label in ("heavy-v2", "cold-v2"):
            directory = ROOT / "runs" / label
            if not (directory / "capture.npz").exists():
                continue
            with np.load(directory / "capture.npz") as packet:
                standard = packet["standard"].copy()
                original = packet["original_standard"].copy()
                names = packet["names"].tolist()
            normalized = abs(standard - original) / np.maximum(np.max(abs(original), axis=0), 1e-30)
            ordered = np.argsort(np.max(normalized, axis=0))[::-1]
            rows = []
            for column in ordered[:15]:
                position = int(np.argmax(normalized[:, column]))
                rows.append(dict(name=names[column], error=float(normalized[position, column]), position=position,
                                 reference=float(original[position, column]), replay=float(standard[position, column])))
            report = dict(model=label, dimension=read(directory / "capture.json")["dimension"], worst=rows)
            reports.append(report)
            print(json.dumps(report), flush=True)
        write(ROOT / "capture-diagnostic.json", dict(reports=reports, code_sha256=digest(__file__)))


if __name__ == "__main__":
    main()
