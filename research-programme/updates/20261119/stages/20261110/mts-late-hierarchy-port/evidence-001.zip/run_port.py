from common import *
import argparse
import ast
import ctypes
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import expm

POINTER = ctypes.POINTER(ctypes.c_double)


def pointer(values):
    return values.ctypes.data_as(POINTER)


def ratio(left, right):
    return float(np.max(abs(left - right) / np.maximum(np.max(abs(right), axis=0), 1e-30)))


def main(label, build_name="build", tag="", original_context=False, batch_context=False, scoped_reference=False):
    with worker("port-" + label + tag):
        require(read(ROOT / "build-complete.json")["passed"], "adapter build gate")
        build_root = ROOT / build_name
        build = read(build_root / "build-result.json")
        require(digest(build_root / "native/camb/cambdll.dll") == build["dll_sha256"], "adapter DLL")
        sys.path.insert(0, str(build_root / "native"))
        import camb
        from camb.mts import MTSTwoField
        sys.path.append(str(BRANCH / "radiation-and-slow-field-transfer-20261007"))
        import radiation_common
        factory_owner = NATIVE.parent / "matching_common.py"
        factory = next(node for node in ast.parse(factory_owner.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == "params_for")
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_owner), "exec"), namespace)
        status = read(SPECTRUM / "runs" / label / "status.json")
        table_path = SPECTRUM / "runs/projection" / (status["arguments"]["projection"] + ".npz") if label == "heavy" else EARLY / "runs/backgrounds/cold.npz"
        require(digest(table_path) == status["source_hash"], "retained branch/background source")
        packet_path = None
        for candidate in sorted((SPECTRUM / "runs" / label).glob("chunk-*.npz")):
            with np.load(candidate) as packet:
                hits = np.flatnonzero(packet["modes"] == 5.)
                if len(hits):
                    require(len(hits) == 1 and packet_path is None, "unique retained k5")
                    packet_path = candidate
                    full_times = np.ascontiguousarray(packet["conformal_time"])
                    scales = packet["requested_scale"].copy()
                    reference_names = packet["names"].tolist()
                    reference_values = packet["values"][hits[0]].copy()
                    original_modes = packet["modes"].copy()
                    original_target = int(hits[0])
        require(packet_path is not None, "retained k5 present")
        require(digest(packet_path) == status["input_hashes"][str(packet_path)], "original packet ownership")
        offsets = np.log(scales) + np.log(11.)
        first = int(np.argmin(abs(offsets)))
        last = int(np.argmin(abs(offsets - .001)))
        require(abs(offsets[first]) < 1e-12 and abs(offsets[last] - .001) < 1e-12 and last > first, "fixed late interval")
        destination = ROOT / "runs" / (label + tag)
        destination.mkdir(parents=True, exist_ok=False)
        observer_owner = PRIOR / "observe_native.py"
        observer_names = ast.literal_eval(next(node.value for node in ast.parse(observer_owner.read_text()).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "NAMES" for target in node.targets)))
        names = list(camb.model.evolve_names)
        require(names == reference_names, "unchanged standard column contract")
        lib = camb.baseconfig.camblib
        observer_dll = ctypes.CDLL(str(PRIOR / "observer.dll"))
        observer_function = ctypes.cast(observer_dll.source_func_, ctypes.c_void_p)
        flags = {name: ctypes.c_int.in_dll(lib, "mts_probe_" + name) for name in ("step", "kind", "count", "tangent")}
        capture = {name: ctypes.c_int.in_dll(lib, "mts_capture_" + name) for name in ("begin", "end", "count", "dimension", "native_dimension", "selector", "selector_value", "dynamic_dimension")}
        mapping = (ctypes.c_int * 512).in_dll(lib, "mts_capture_map")
        signature = (ctypes.c_int * 96).in_dll(lib, "mts_capture_signature")
        memory = (ctypes.c_int * 12).in_dll(lib, "mts_capture_memory_indices")
        lib.mts_capture_reset.argtypes = []
        lib.mts_capture_reset.restype = None
        lib.mts_capture_copy.argtypes = [ctypes.c_int, ctypes.c_int, POINTER, POINTER, POINTER]
        lib.mts_capture_copy.restype = None
        lib.mts_operator_rhs.argtypes = [ctypes.c_double, ctypes.c_int, POINTER, POINTER]
        lib.mts_operator_rhs.restype = None
        lib.mts_operator_observe.argtypes = [ctypes.c_double, ctypes.c_int, POINTER, ctypes.c_int, POINTER]
        lib.mts_operator_observe.restype = None
        params = namespace["params_for"](table_path, background_boost=status["arguments"]["bg"])
        native = camb.get_background(params)
        if original_context or batch_context:
            regenerated_times = native.conformal_time(1 / scales - 1, tol=1e-10)
            require(np.max(abs(regenerated_times - full_times) / np.maximum(abs(full_times), 1.)) < 1e-12, "original conformal clock")
        native.Params.Accuracy.IntTolBoost = 6
        native.Params.Accuracy.lAccuracyBoost = 4
        lib.mts_capture_reset()
        for flag in flags.values():
            flag.value = 0
        if original_context:
            for prior_packet in sorted((SPECTRUM / "runs" / label).glob("chunk-*.npz")):
                if prior_packet == packet_path:
                    break
                guard()
                with np.load(prior_packet) as warmup:
                    warm_modes = warmup["modes"].copy()
                native.get_time_evolution(warm_modes, full_times, vars=names, lAccuracyBoost=4)
                print(label, "restored context", prior_packet.name, flush=True)
        if original_context or batch_context:
            ctypes.c_int.in_dll(lib, "mts_capture_q_index").value = original_target + 1
        selected_modes = original_modes if original_context or batch_context else np.array([5.])
        selected_index = original_target if original_context or batch_context else 0
        capture["begin"].value, capture["end"].value = first + 1, last + 1
        write(destination / "config.json", dict(model=label, wave=5., first=first, last=last, full_schedule_count=len(full_times), packet=str(packet_path), packet_sha256=digest(packet_path), table=str(table_path), table_sha256=digest(table_path), status_sha256=digest(SPECTRUM / "runs" / label / "status.json"),
              factory_sha256=digest(factory_owner), observer_dll_sha256=digest(PRIOR / "observer.dll"), adapter_sha256=build["dll_sha256"], code_sha256=digest(__file__),
              tolerance=[2e-11, 2e-12], atol_ratio=.01, numerical_gate=GATE, algebra_gate=ALGEBRA, new_physics_inserted=False,
              original_context=original_context, batch_context=batch_context, scoped_reference=scoped_reference, selected_modes=selected_modes.tolist(), selected_index=selected_index))
        print(label, "capture starting", len(full_times), "original times", flush=True)
        try:
            count = len(names) + len(observer_names)
            output = np.zeros((len(selected_modes), len(full_times), count))
            code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(len(selected_modes))), selected_modes, ctypes.byref(ctypes.c_int(len(full_times))), full_times, ctypes.byref(ctypes.c_int(count)), output, ctypes.byref(ctypes.c_int(len(observer_names))), ctypes.byref(observer_function))
            require(code == 0, "native full-cadence capture")
            standard = output[selected_index, :, :len(names)].copy()
            observed = output[selected_index, first:last + 1, len(names):].copy()
            overlap = ratio(standard, reference_values)
            dimension = capture["dimension"].value
            snapshots = capture["count"].value
            require(snapshots == last - first + 1 and 0 < dimension <= 512, "captured interval coverage")
            captured = np.zeros((dimension, snapshots), order="F")
            captured_rate = np.zeros_like(captured, order="F")
            times = np.zeros(snapshots)
            lib.mts_capture_copy(dimension, snapshots, pointer(captured), pointer(captured_rate), pointer(times))
            require(np.array_equal(times, full_times[first:last + 1]), "exact original clock")
            state_map = np.array(list(mapping)[:dimension])
            regime = np.array(list(signature))
            memory_indices = np.array(list(memory)).reshape(6, 2)
            selector, selector_value = capture["selector"].value, capture["selector_value"].value
            dynamic_dimension = capture["dynamic_dimension"].value
            reference, rate_reference = captured.T.copy(), captured_rate.T.copy()
            np.savez_compressed(destination / "capture.npz", full_times=full_times, standard=standard, original_standard=reference_values, names=np.array(names), times=times, state=reference, derivative=rate_reference, observer=observed, observer_names=np.array(observer_names), mapping=state_map, signature=regime, memory_indices=memory_indices, selector=selector, selector_value=selector_value, dynamic_dimension=dynamic_dimension)
            write(destination / "capture.json", dict(passed=overlap <= GATE, overlap=overlap, dimension=dimension, native_dimension=capture["native_dimension"].value, dynamic_dimension=dynamic_dimension, snapshots=snapshots, selector=selector, selector_value=selector_value, memory_indices=memory_indices.tolist(), signature=regime.tolist(), output_sha256=digest(destination / "capture.npz")))
            if scoped_reference:
                require(batch_context or original_context, "reference uses original batch")
                native_control_path = ROOT / (label + "-native-batch-control.npz")
                with np.load(native_control_path) as control:
                    current_native = control["group"][int(control["target"])].copy()
                native_overlap = ratio(standard, current_native)
                late_overlap = ratio(standard[first:last + 1], reference_values[first:last + 1])
                write(destination / "scoped-reference.json", dict(passed=native_overlap <= GATE and late_overlap <= GATE, native_overlap=native_overlap, late_historical_overlap=late_overlap,
                      full_historical_overlap=overlap, full_historical_passed=overlap <= GATE, current_native_sha256=digest(native_control_path), decision_sha256=digest(ROOT / "REPLAY-SCOPE-DECISION.md")))
                require(native_overlap <= GATE and late_overlap <= GATE, "current native and historical late reference")
            else:
                require(overlap <= GATE, "historical full-span output mismatch; attribution requires native control")
            require(selector_value == (1 if label == "heavy" else 0), "late selector ownership")

            def rhs(stamp, vector):
                guard()
                vector = np.ascontiguousarray(vector, dtype=np.float64)
                result = np.empty(dimension)
                lib.mts_operator_rhs(float(stamp), dimension, pointer(vector), pointer(result))
                return result

            def observe(stamp, vector):
                vector = np.ascontiguousarray(vector, dtype=np.float64)
                result = np.empty(len(observer_names))
                lib.mts_operator_observe(float(stamp), dimension, pointer(vector), len(observer_names), pointer(result))
                return result

            checks = []
            def check(name, error, gate=ALGEBRA):
                checks.append(dict(name=name, error=float(error), gate=gate, passed=bool(np.isfinite(error) and abs(error) <= gate)))
            check("captured derivative replay", ratio(np.array([rhs(stamp, state) for stamp, state in zip(times, reference)]), rate_reference))
            check("captured observer replay", ratio(np.array([observe(stamp, state) for stamp, state in zip(times, reference)]), observed))
            matrices = []
            for stamp in np.linspace(times[0], times[-1], 5):
                matrix = np.column_stack([rhs(stamp, basis) for basis in np.eye(dimension)])
                vector = np.sin(np.arange(1, dimension + 1)) / (1 + np.arange(dimension))
                second = np.cos(np.arange(1, dimension + 1)) / (2 + np.arange(dimension))
                check("zero RHS " + str(stamp), np.max(abs(rhs(stamp, np.zeros(dimension)))))
                check("linear matrix " + str(stamp), ratio(matrix @ vector, rhs(stamp, vector)))
                check("negative RHS " + str(stamp), ratio(rhs(stamp, -vector), -rhs(stamp, vector)))
                check("superposition " + str(stamp), ratio(rhs(stamp, vector + second), rhs(stamp, vector) + rhs(stamp, second)))
                zero_observer = observe(stamp, np.zeros(dimension))
                check("observer affine superposition " + str(stamp), ratio(observe(stamp, vector + second) - zero_observer, observe(stamp, vector) + observe(stamp, second) - 2 * zero_observer))
                matrices.append(matrix)
            np.savez_compressed(destination / "operator.npz", matrices=matrices, matrix_times=np.linspace(times[0], times[-1], 5))
            write(destination / "operator.json", dict(passed=all(row["passed"] for row in checks), checks=checks))
            require(all(row["passed"] for row in checks), "operator ownership/linearity gate")
            initial = reference[0]
            offsets = np.linspace(0., times[-1] - times[0], 17)
            frozen = np.array([expm(matrices[0] * offset) @ initial for offset in offsets])
            normalization = np.maximum(np.max(abs(frozen), axis=0), np.maximum(abs(initial), max(float(np.max(abs(initial))) * 1e-20, 1e-30)))
            require(np.isfinite(normalization).all() and np.all(normalization > 0), "initial-operator scale")
            first_step = min(1e-4, 1e-3 / max(1., float(np.max(np.sum(abs(matrices[0]), axis=1)))))
            np.savez_compressed(destination / "scale.npz", normalization=normalization, initial=initial, frozen_states=frozen, offsets=offsets, initial_operator=matrices[0])
            reports = []
            for tag, tolerance, amplitude in (("full", 2e-11, 1.), ("precision", 2e-12, 1.), ("negative", 2e-11, -1.), ("zero", 2e-11, 0.)):
                solution = solve_ivp(lambda stamp, state: rhs(stamp, state * normalization) / normalization, (times[0], times[-1]), amplitude * initial / normalization, method="DOP853", rtol=tolerance, atol=tolerance / 100, first_step=first_step, t_eval=times)
                require(solution.success and np.isfinite(solution.y).all(), "independent short hierarchy integration")
                prediction = solution.y.T * normalization
                predicted_observer = np.array([observe(stamp, state) for stamp, state in zip(times, prediction)])
                state_error = float(np.max(abs(prediction - amplitude * reference) / normalization))
                observer_zero = np.array([observe(stamp, np.zeros(dimension)) for stamp in times])
                observer_target = observer_zero + amplitude * (observed - observer_zero)
                observer_error = ratio(predicted_observer, observer_target)
                np.savez_compressed(destination / (tag + ".npz"), times=times, state=prediction, observer=predicted_observer)
                reports.append(dict(tag=tag, tolerance=tolerance, evaluations=solution.nfev, state_error=state_error, observer_error=observer_error, passed=state_error <= GATE and observer_error <= GATE))
                write(destination / (tag + ".json"), reports[-1])
                print(label, tag, dimension, state_error, observer_error, flush=True)
            write(destination / "result.json", dict(passed=all(row["passed"] for row in reports), reports=reports, captured_initial_state=True, future_species_forcing=False, native_scalar_block_unchanged=True, code_sha256=digest(__file__)))
            require(all(row["passed"] for row in reports), "paired hierarchy accuracy gate")
        finally:
            for flag in flags.values():
                flag.value = 0
            lib.mts_capture_reset()
            del native


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("model", choices=("heavy", "cold"))
    parser.add_argument("--build", default="build")
    parser.add_argument("--tag", default="")
    parser.add_argument("--original-context", action="store_true")
    parser.add_argument("--batch-context", action="store_true")
    parser.add_argument("--scoped-reference", action="store_true")
    arguments = parser.parse_args()
    main(arguments.model, arguments.build, arguments.tag, arguments.original_context, arguments.batch_context, arguments.scoped_reference)
