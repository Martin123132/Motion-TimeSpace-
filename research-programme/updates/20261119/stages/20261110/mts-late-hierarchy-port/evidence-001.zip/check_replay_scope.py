from common import *
import numpy as np


def main():
    with worker("replay-scope"):
        reports = []
        for label in ("heavy", "cold"):
            version = "-v3" if label == "heavy" else "-v2"
            directory = ROOT / "runs" / (label + version)
            config = read(directory / "config.json")
            with np.load(directory / "capture.npz") as packet:
                captured = packet["standard"].copy()
                old = packet["original_standard"].copy()
                names = packet["names"].tolist()
            with np.load(ROOT / (label + "-native-batch-control.npz")) as native:
                native_now = native["group"][int(native["target"])] if label == "heavy" else native["single"]
                exact_current_match = np.array_equal(native_now, captured)
            selection = slice(config["first"], config["last"] + 1)
            denominator = np.maximum(np.max(abs(old[selection]), axis=0), 1e-30)
            error = np.max(abs(captured[selection] - old[selection]) / denominator, axis=0)
            worst = [dict(name=names[index], error=float(error[index])) for index in np.argsort(error)[::-1][:10]]
            report = dict(model=label, native_reference="original DLL, same invocation context now", exact_current_match=bool(exact_current_match), late_only_max=float(np.max(error)), late_only_worst=worst)
            reports.append(report)
            print(json.dumps(report), flush=True)
        write(ROOT / "replay-scope.json", dict(reports=reports, code_sha256=digest(__file__)))


if __name__ == "__main__":
    main()
