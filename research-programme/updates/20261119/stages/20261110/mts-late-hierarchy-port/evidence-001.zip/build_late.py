from common import *
import difflib
import importlib.util
import shutil


def main():
    with worker("build"):
        inputs = preserved()
        source = HIERARCHY / "build-corrected/camb_python.f90"
        builder_path = POST / "mts-state-feedback-20261107/build_probe.py"
        for path in (source, builder_path):
            inputs[str(path)] = digest(path)
        write(ROOT / "frozen-inputs.json", inputs)
        original = source.read_text(encoding="utf-8")
        updated = original
        changes = []
        def replace(old, new, count=1):
            nonlocal updated
            require(updated.count(old) == count, "adapter edit occurrence: " + old[:70])
            updated = updated.replace(old, new)
            changes.append(dict(old=old, new=new, occurrences=count))
        replace("    integer(c_int), bind(C, name='mts_capture_selector') :: mts_capture_selector = 0",
                "    integer(c_int), bind(C, name='mts_capture_selector') :: mts_capture_selector = 0\n    integer(c_int), bind(C, name='mts_capture_selector_value') :: mts_capture_selector_value = 0\n    integer(c_int), bind(C, name='mts_capture_dynamic_dimension') :: mts_capture_dynamic_dimension = 0\n    integer(c_int), bind(C, name='mts_capture_memory_indices') :: mts_capture_memory_indices(2,6) = 0")
        replace("    mts_capture_selector=0\n", "    mts_capture_selector=0\n    mts_capture_selector_value=0\n    mts_capture_dynamic_dimension=0\n    mts_capture_memory_indices=0\n")
        replace("        if (EV%MassiveNuApprox(eigen)) error stop 'unsupported neutrino perturbative memory'\n        if (EV%G11(eigen)/=0 .or. EV%G30(eigen)/=0) error stop 'unexpected perturbative memory'",
                "        if (.not.EV%MassiveNuApprox(eigen)) then\n            if (EV%G11(eigen)/=0 .or. EV%G30(eigen)/=0) error stop 'inactive neutrino memory nonzero'\n        end if")
        replace("            if (vector(selector)/=0) error stop 'heavy averaged selector not authorized'",
                "            if (vector(selector)/=0 .and. vector(selector)/=1) error stop 'invalid discrete heavy selector'")
        replace("        mts_capture_selector=selector\n", "        mts_capture_selector=selector\n        if (selector>0) mts_capture_selector_value=nint(vector(selector))\n")
        replace("        mts_capture_dimension=column\n", "        mts_capture_dynamic_dimension=column\n        do eigen=1,State%CP%Nu_mass_eigenstates\n            if (.not.EV%MassiveNuApprox(eigen)) cycle\n            if (column+2>512) error stop 'memory state dimension exceeds allocation'\n            mts_capture_memory_indices(:,eigen)=[column+1,column+2]\n            mts_capture_map(column+1:column+2)=[-100-2*eigen,-101-2*eigen]\n            column=column+2\n        end do\n        mts_capture_dimension=column\n")
        replace("        if (selector/=mts_capture_selector) error stop 'discrete selector changed'", "        if (selector/=mts_capture_selector) error stop 'discrete selector position changed'\n        if (selector>0) then\n            if (nint(vector(selector))/=mts_capture_selector_value) error stop 'discrete selector value changed'\n        end if")
        replace("    mts_captured_y(:,mts_capture_count)=vector(mts_capture_map(1:mts_capture_dimension))\n    mts_captured_dy(:,mts_capture_count)=derivative(mts_capture_map(1:mts_capture_dimension))",
                "    mts_captured_y(:,mts_capture_count)=0\n    mts_captured_dy(:,mts_capture_count)=0\n    column=mts_capture_dynamic_dimension\n    mts_captured_y(1:column,mts_capture_count)=vector(mts_capture_map(1:column))\n    mts_captured_dy(1:column,mts_capture_count)=derivative(mts_capture_map(1:column))\n    do eigen=1,State%CP%Nu_mass_eigenstates\n        if (.not.EV%MassiveNuApprox(eigen)) cycle\n        mts_captured_y(mts_capture_memory_indices(:,eigen),mts_capture_count)=[EV%G11(eigen),EV%G30(eigen)]\n    end do")
        reconstruct = """    subroutine mts_operator_reconstruct(vector,full,local_ev)
    real(dl), intent(in) :: vector(:)
    real(dl), intent(out) :: full(:)
    type(EvolutionVars), intent(out) :: local_ev
    integer :: eigen,column
    local_ev=mts_operator_ev
    full=0
    column=mts_capture_dynamic_dimension
    full(mts_capture_map(1:column))=vector(1:column)
    if (mts_capture_selector>0) full(mts_capture_selector)=real(mts_capture_selector_value,dl)
    do eigen=1,State%CP%Nu_mass_eigenstates
        if (.not.local_ev%MassiveNuApprox(eigen)) cycle
        local_ev%G11(eigen)=vector(mts_capture_memory_indices(1,eigen))
        local_ev%G30(eigen)=vector(mts_capture_memory_indices(2,eigen))
    end do
    end subroutine

"""
        replace("    subroutine mts_operator_rhs(tau,dimension,vector,derivative) bind(C,name='mts_operator_rhs')", reconstruct + "    subroutine mts_operator_rhs(tau,dimension,vector,derivative) bind(C,name='mts_operator_rhs')")
        replace("    full(mts_capture_map(1:dimension))=vector", "    call mts_operator_reconstruct(vector,full,local_ev)", 2)
        replace("    derivative=rate(mts_capture_map(1:dimension))", "    derivative=0\n    derivative(1:mts_capture_dynamic_dimension)=rate(mts_capture_map(1:mts_capture_dynamic_dimension))")
        destination = ROOT / "build"
        destination.mkdir(exist_ok=False)
        (destination / "camb_python.f90").write_text(updated, encoding="utf-8")
        (ROOT / "adapter.diff").write_text("".join(difflib.unified_diff(original.splitlines(True), updated.splitlines(True), fromfile=str(source), tofile="build/camb_python.f90")), encoding="utf-8")
        write(ROOT / "adapter-transform.json", dict(source=str(source), source_sha256=digest(source), changes=changes, generated_sha256=digest(destination / "camb_python.f90"), generator_sha256=digest(__file__)))
        specification = importlib.util.spec_from_file_location("retained_isolated_builder", builder_path)
        builder = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(builder)
        builder.ROOT = destination
        builder.main()
        auxiliary = destination / "native/fortran"
        auxiliary.mkdir(exist_ok=False)
        import_data = NATIVE / "fortran/HighLExtrapTemplate_lenspotentialCls.dat"
        shutil.copy2(import_data, auxiliary / import_data.name)
        require(digest(import_data) == digest(auxiliary / import_data.name), "native package import data")
        for path, checksum in inputs.items():
            require(digest(path) == checksum, "parent input changed during adapter build")
        write(ROOT / "build-complete.json", dict(passed=True, import_data_sha256=digest(import_data), native_equations_changed=False,
              build_result_sha256=digest(destination / "build-result.json"), transform_sha256=digest(ROOT / "adapter-transform.json")))
        print("late adapter built; original native equations unchanged", flush=True)


if __name__ == "__main__":
    main()
