from common import *
import ast
import numpy as np


def main():
    with worker("native-batch-control"):
        sys.path.insert(0, str(NATIVE))
        import camb
        from camb.mts import MTSTwoField
        sys.path.append(str(BRANCH / "radiation-and-slow-field-transfer-20261007"))
        import radiation_common
        owner = NATIVE.parent / "matching_common.py"
        factory = next(node for node in ast.parse(owner.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == "params_for")
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(owner), "exec"), namespace)
        reports = []
        for label in ("heavy", "cold"):
            config = read(ROOT / "runs" / (label + "-v2") / "config.json")
            with np.load(config["packet"]) as packet:
                modes = packet["modes"].copy()
                times = packet["conformal_time"].copy()
                reference = packet["values"].copy()
                names = packet["names"].tolist()
            target = int(np.flatnonzero(modes == 5.)[0])
            model = camb.get_background(namespace["params_for"](Path(config["table"])))
            model.Params.Accuracy.IntTolBoost = 6
            single = model.get_time_evolution(np.array([5.]), times, vars=names, lAccuracyBoost=4)[0]
            del model
            model = camb.get_background(namespace["params_for"](Path(config["table"])))
            model.Params.Accuracy.IntTolBoost = 6
            group = model.get_time_evolution(modes, times, vars=names, lAccuracyBoost=4)
            del model
            denominator = np.maximum(np.max(abs(reference[target]), axis=0), 1e-30)
            single_error = float(np.max(abs(single - reference[target]) / denominator))
            group_error = float(np.max(abs(group[target] - reference[target]) / denominator))
            with np.load(ROOT / "runs" / (label + "-v2") / "capture.npz") as captured:
                adapter_error = float(np.max(abs(single - captured["standard"]) / denominator))
            np.savez_compressed(ROOT / (label + "-native-batch-control.npz"), modes=modes, times=times, names=names, single=single, group=group, reference=reference, target=target)
            report = dict(model=label, modes=modes.tolist(), target=target, single_original_error=single_error, group_original_error=group_error, single_adapter_error=adapter_error,
                          original_dll_sha256=digest(NATIVE / "camb/cambdll.dll"), passed=group_error <= GATE and adapter_error <= GATE)
            reports.append(report)
            print(json.dumps(report), flush=True)
        write(ROOT / "native-batch-control.json", dict(passed=all(row["passed"] for row in reports), reports=reports, code_sha256=digest(__file__)))


if __name__ == "__main__":
    main()
