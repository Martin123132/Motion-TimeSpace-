from common import *
import numpy as np


def normalized(residual, terms):
    return float(np.max(abs(residual)) / max(max(float(np.max(abs(term))) for term in terms), 1e-100))


def main():
    with worker("metric-check-fixed"):
        reports, refinements = [], []
        for label in ("heavy", "cold"):
            destination = ROOT / "runs" / (label + "-v4")
            require(read(destination / "result.json")["passed"], "completed independent native hierarchy")
            with np.load(destination / "capture.npz") as packet:
                names = packet["observer_names"].tolist()
                reference = packet["observer"].copy()
                native_dimension = len(packet["mapping"])
                memory_count = int(np.count_nonzero(packet["memory_indices"]))
            with np.load(destination / "scale.npz") as packet:
                scale = packet["normalization"].copy()
            states = {}
            for tag in ("capture", "full", "precision", "negative", "zero"):
                with np.load(destination / (tag + ".npz")) as packet:
                    observer = packet["observer"].copy()
                    if tag != "capture":
                        states[tag] = packet["state"].copy()
                value = lambda name: observer[:, names.index(name)]
                wave = 5.
                hubble = value("H_native")
                enthalpy = value("R") + value("Pbar")
                alpha = value("sigma") / wave
                potential = value("eta_sync") - hubble * alpha
                lapse = 2 * value("Weyl") - potential
                density = value("D_sync") - 3 * hubble * enthalpy * alpha
                current = value("Q_sync") + enthalpy * value("sigma")
                compensated = value("D_sync") - 3 * enthalpy * value("eta_sync")
                denominator = 2 * wave**2 + 3 * enthalpy
                closed_potential = -(compensated + 3 * hubble * current / wave) / denominator
                potential_rate = value("Weyl_prime") + value("Pi_prime") / (2 * wave**2)
                metric_rhs = -hubble * lapse + current / (2 * wave)
                errors = dict(
                    friedmann=normalized(value("R") - 3 * hubble**2, [value("R"), 3 * hubble**2]),
                    hamiltonian=normalized(2 * wave**2 * potential + density + 3 * hubble * current / wave, [2 * wave**2 * potential, density, 3 * hubble * current / wave]),
                    anisotropic_slip=normalized(potential - lapse - value("Pi") / wave**2, [potential, lapse, value("Pi") / wave**2]),
                    momentum=normalized(potential_rate - metric_rhs, [potential_rate, hubble * lapse, current / (2 * wave)]),
                    compensated_closure=normalized(closed_potential - potential, [closed_potential, potential]),
                    lapse_acceleration=normalized((value("sigma_prime") + hubble * value("sigma")) / wave - lapse, [lapse, value("sigma_prime") / wave, hubble * value("sigma") / wave]))
                reports.append(dict(model=label, case=tag, errors=errors, positive_denominator=bool(np.all(denominator > 0)), passed=bool(max(errors.values()) <= ALGEBRA and np.all(denominator > 0))))
            precision = float(np.max(abs(states["full"] - states["precision"]) / scale))
            negative = float(np.max(abs(states["full"] + states["negative"]) / scale))
            zero = float(np.max(abs(states["zero"]) / scale))
            refinements.append(dict(model=label, dimension=native_dimension, active_memory_coordinates=memory_count,
                                    precision_difference=precision, sign_difference=negative, zero_error=zero,
                                    passed=max(precision, negative, zero) <= GATE))
        result = dict(passed=all(row["passed"] for row in reports + refinements), metric_checks=reports, refinements=refinements,
                      scope="endpoint and RHS identities of the independently evolved retained late hierarchy; scalar block not yet replaced", code_sha256=digest(__file__))
        write(ROOT / "metric-result-fixed.json", result)
        print(json.dumps(dict(passed=result["passed"], maximum_metric_error=max(max(row["errors"].values()) for row in reports), refinements=refinements)), flush=True)
        require(result["passed"], "metric identities/refinement")


if __name__ == "__main__":
    main()
