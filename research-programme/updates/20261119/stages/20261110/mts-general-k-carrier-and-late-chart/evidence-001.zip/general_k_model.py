import numpy as np


def require_wave(wave):
    if not np.isfinite(wave) or wave <= 0:
        raise ValueError("The current coordinate requires a finite positive wavenumber")


def harmonics(parameters, wave):
    require_wave(wave)
    mass, hubble, energy, beta = parameters
    frequency = np.sqrt(mass**2 + wave**2)
    summed = frequency + mass
    difference = wave**2 / summed
    sound2 = (wave / summed)**2
    ratio = mass**2 / frequency**2
    gamma = hubble * (5 + ratio)
    denominator = 1 / (2 * wave * hubble * beta)
    gravity_mean = -wave * energy * summed / (2 * frequency)
    gravity_sine = -wave**2 * energy / (2 * frequency)
    mean = np.zeros((3, 3), dtype=np.result_type(parameters))
    cosine2, sine2, cosine4, sine4 = (mean.copy() for index in range(4))
    mean[0, 0] = -hubble * (1 - mass / frequency)**2 / 2 + denominator * gravity_mean * (1 + sound2 / 2)
    mean[0, 1] = -wave
    mean[0, 2] = gravity_mean
    mean[1, 0] = wave * sound2
    mean[1, 1] = -hubble * (1 + ratio) / 2 + denominator * gravity_sine * difference / (2 * wave)
    cosine2[0, 0] = gamma / 2 - denominator * gravity_mean * (1 + sound2)
    cosine2[1, 1] = hubble * (1 - ratio) / 2
    cosine2[0, 2] = -gravity_mean
    sine2[0, 1] = -gamma * summed / (2 * wave) + denominator * gravity_mean * difference / wave
    sine2[1, 0] = wave * hubble * (1 - ratio) / (2 * summed) + denominator * gravity_sine
    sine2[1, 2] = gravity_sine
    cosine4[0, 0] = denominator * gravity_mean * sound2 / 2
    cosine4[1, 1] = -denominator * gravity_sine * difference / (2 * wave)
    sine4[0, 1] = -denominator * gravity_mean * difference / (2 * wave)
    sine4[1, 0] = -denominator * gravity_sine * sound2 / 2
    return mean, cosine2, sine2, cosine4, sine4


def periodic(theta, parameters, wave):
    mean, cosine2, sine2, cosine4, sine4 = harmonics(parameters, wave)
    return mean + cosine2 * np.cos(2 * theta) + sine2 * np.sin(2 * theta) + cosine4 * np.cos(4 * theta) + sine4 * np.sin(4 * theta)


def micromotion(theta, parameters, wave):
    mass = parameters[0]
    mean, cosine2, sine2, cosine4, sine4 = harmonics(parameters, wave)
    return (cosine2 * np.sin(2 * theta) - sine2 * np.cos(2 * theta)) / (2 * mass) + (cosine4 * np.sin(4 * theta) - sine4 * np.cos(4 * theta)) / (4 * mass)


def micromotion_prime(theta, parameters, wave, theta_prime, parameter_rates, step=1e-20):
    result = np.imag(micromotion(theta + step * 1j, parameters.astype(complex), wave)) / step * theta_prime
    for index in range(4):
        shifted = parameters.astype(complex)
        shifted[index] += step * 1j
        result += np.imag(micromotion(theta, shifted, wave)) / step * parameter_rates[index]
    return result


def effective(parameters, wave):
    mass, hubble, energy, beta = parameters
    mean, cosine2, sine2, cosine4, sine4 = harmonics(parameters, wave)
    commutator = (sine2 @ cosine2 - cosine2 @ sine2) / (4 * mass) + (sine4 @ cosine4 - cosine4 @ sine4) / (8 * mass)
    derivatives = []
    for index in (2, 1):
        shifted = parameters.astype(complex)
        shifted[index] += 1e-20j
        derivatives.append(np.imag(harmonics(shifted, wave)[2]) / 1e-20)
    drift = 3 * hubble * (sine2 + energy * derivatives[0]) / (4 * mass) + energy * derivatives[1] / (8 * beta * mass)
    return mean, commutator, drift


def primitive_map(field, velocity, mass, beta, wave):
    require_wave(wave)
    frequency = np.sqrt(mass**2 + wave**2)
    density_factor = beta * mass * (frequency + mass) / 2
    current_factor = beta * wave * mass / 2
    return np.array([
        [density_factor * field, density_factor * velocity / (mass * frequency)],
        [current_factor * velocity / mass, -current_factor * field / frequency],
    ])


def primitive_map_prime(field, velocity, field_prime, velocity_prime, mass, beta, rate, wave):
    frequency = np.sqrt(mass**2 + wave**2)
    density_factor = beta * mass * (frequency + mass) / 2
    current_factor = beta * wave * mass / 2
    density_rate = rate * (2 + mass / frequency)
    denominator_rate = rate * (1 + mass**2 / frequency**2)
    return np.array([
        [density_factor * (field_prime + density_rate * field), density_factor * (velocity_prime + (density_rate - denominator_rate) * velocity) / (mass * frequency)],
        [current_factor * (velocity_prime + rate * velocity) / mass, -current_factor * (field_prime + rate * (2 - mass**2 / frequency**2) * field) / frequency],
    ])


def source_rows(field, velocity, mass, beta, wave):
    require_wave(wave)
    amplitude2 = field**2 + (velocity / mass)**2
    if amplitude2 <= 0 or mass <= 0 or beta <= 0:
        raise ValueError("Positive mass, normalization and nonzero background are required")
    frequency = np.sqrt(mass**2 + wave**2)
    summed = frequency + mass
    difference = wave**2 / summed
    sound2 = (wave / summed)**2
    cosine = (field**2 - (velocity / mass)**2) / amplitude2
    sine = 2 * field * velocity / (mass * amplitude2)
    return np.array([
        [1 - sound2 * cosine, -difference * sine / wave],
        [wave * sine / summed, 1 - cosine],
        [sound2 - cosine, -summed * sine / wave],
    ])


def geometry(values, density0, wave, hubble_prime=0.):
    scale, rate, hubble, rest = values["extra"]
    field, velocity, field_first, velocity_first, mass2, saved_frequency = values["jets"][1]
    mass = np.sqrt(mass2)
    frequency = np.sqrt(mass2 + wave**2)
    if not np.isclose(saved_frequency, frequency, rtol=1e-10, atol=0):
        raise ValueError("Native sample frequency does not match the requested wavenumber")
    beta = scale / density0
    field_prime, velocity_prime = rate * field_first, rate * velocity_first
    amplitude2 = field**2 + velocity**2 / mass2
    if min(scale, hubble, beta, mass, amplitude2) <= 0:
        raise ValueError("Regular positive expanding background required")
    theta = np.arctan2(-velocity / mass, field)
    theta_prime = (field * (-velocity_prime / mass + rate * velocity / mass) + velocity / mass * field_prime) / amplitude2
    energy = beta * (velocity**2 + mass2 * field**2) / 2
    energy_prime = rate * energy + beta * (velocity * velocity_prime + mass2 * field * field_prime + rate * mass2 * field**2)
    parameters = np.array([mass, hubble, energy, beta])
    parameter_rates = np.array([rate * mass, hubble_prime, energy_prime, rate * beta])
    mean, commutator, drift = effective(parameters, wave)
    return dict(
        mapping=primitive_map(field, velocity, mass, beta, wave),
        mapping_prime=primitive_map_prime(field, velocity, field_prime, velocity_prime, mass, beta, rate, wave),
        transform=np.eye(3) + micromotion(theta, parameters, wave),
        transform_prime=micromotion_prime(theta, parameters, wave, theta_prime, parameter_rates),
        generator=mean + commutator + drift,
        background=np.array([field, velocity / frequency]), frequency=frequency, beta=beta,
    )


def synchronous_to_canonical(mode, mode_velocity, field, velocity, mass2, eta, alpha):
    return np.array([mode + velocity * alpha, mode_velocity - 3 * eta * velocity - mass2 * field * alpha])


def canonical_to_synchronous(mode, momentum, field, velocity, mass2, eta, alpha):
    return np.array([mode - velocity * alpha, momentum + 3 * eta * velocity + mass2 * field * alpha])


def transformed_defects(mode_defect, velocity_defect, field_defect, background_defect, shift_defect, lapse_defect, field, velocity, mass2, hubble, rate, eta, alpha):
    return np.array([
        mode_defect + background_defect * alpha + velocity * lapse_defect,
        velocity_defect + velocity * shift_defect + 2 * (hubble - rate) * mass2 * field * alpha - mass2 * field_defect * alpha - 3 * eta * background_defect - mass2 * field * lapse_defect,
    ])
