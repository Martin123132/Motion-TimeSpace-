import numpy as np


def metric_port(eta, hubble, wave, rest_density_sync, rest_current_sync, scalar_compensated_density, scalar_current, scalar_enthalpy, anisotropic_stress):
    values = (eta,hubble,wave,rest_density_sync,rest_current_sync,scalar_compensated_density,scalar_current,scalar_enthalpy,anisotropic_stress)
    if not all(np.all(np.isfinite(value)) for value in values):
        raise ValueError("Finite current-state source inputs required")
    if wave <= 0 or np.any(np.asarray(hubble) <= 0) or np.any(np.asarray(scalar_enthalpy) < 0):
        raise ValueError("Positive wavenumber, expanding background and nonnegative scalar enthalpy required")
    denominator = 2 * wave**2 + 3 * scalar_enthalpy
    numerator = rest_density_sync + scalar_compensated_density + 3 * hubble * (rest_current_sync + scalar_current) / wave
    potential = -numerator / denominator
    alpha = (eta - potential) / hubble
    return dict(
        potential=potential,
        lapse=potential - anisotropic_stress / wave**2,
        alpha=alpha,
        density_sync=scalar_compensated_density + 3 * scalar_enthalpy * eta,
        current_sync=scalar_current - wave * scalar_enthalpy * alpha,
        denominator=denominator,
    )


def scalar_pressure_sync(pressure_compensated, field, velocity, mass2, eta, alpha):
    return pressure_compensated + 3 * velocity**2 * eta + 2 * mass2 * field * velocity * alpha
