from common import *
import argparse


def verified_inputs():
    accepted = read(ROOT/"accepted-validation.json")
    port = read(ROOT/"native-port-validation.json")
    require(accepted["passed"] and port["passed"],"both accepted calculations passed")
    original = read(ROOT/"validation.json")
    require(not original["passed"],"preserve original double-precision failure")
    require([row["name"] for row in original["checks"] if not row["passed"]]==["k0.2/mu300.0/n64/mean","k0.2/mu300.0/n128/mean"],"exact documented numerical failures")
    inputs = dict(read(ROOT/"frozen-inputs.json"))
    inputs.update(accepted["input_hashes"])
    inputs.update(port["input_hashes"])
    inputs[str(ROOT/"native-port-validation.json")] = digest(ROOT/"native-port-validation.json")
    inputs[str(ROOT/"accepted-validation.json")] = digest(ROOT/"accepted-validation.json")
    check_hashes(inputs)
    return inputs


def seal():
    inputs = verified_inputs()
    for path in ROOT.glob("*.py"):
        compile(path.read_text(encoding="utf-8"),str(path),"exec")
    require((ROOT/"RESULTS.md").is_file() and (ROOT/"NEXT.md").is_file(),"saved interpretation and next work")
    excluded = {"closeout.json","seal-accepted-end.json","postseal-accepted-start.json","postseal-accepted-end.json","CLEANUP-VERIFIED.json"}
    artifacts = {path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write("closeout.json",dict(derived_general_k=True,derived_canonical_defect_map=True,derived_current_native_metric_port=True,original_binary64_suite_passed=False,accepted_precision_suite_passed=True,paired_saved_native_port_passed=True,new_late_forward_evolution=False,new_initial_state_or_population=False,goal_complete=False,input_hashes=inputs,artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/"closeout.json"),artifacts=len(artifacts))),flush=True)


def postseal(owner):
    sealed = read(ROOT/"closeout.json")
    verified_inputs()
    check_hashes(sealed["input_hashes"])
    check_hashes({str(ROOT/name):row["sha256"] for name,row in sealed["artifacts"].items()})
    failures = {"freeze":"KeyError('runs/cold-v4/config.json')","test":"ValueError('fixed-gate general-k and gauge checks')"}
    receipts = []
    observed_failures = set()
    for path in sorted(ROOT.glob("*-start.json")):
        label = path.name.removesuffix("-start.json")
        if label=="postseal-accepted":
            continue
        original,ending = read(path),read(ROOT/(label+"-end.json"))
        require(exited(original),"task-owned worker exited "+label)
        require(all(original[key]==ending[key] for key in ("pid","created","command")),"consistent process identity")
        if label in failures:
            require(ending["state"]=="failed" and ending["error"]==failures[label],"specifically audited failed receipt")
            observed_failures.add(label)
        else:
            require(ending["state"]=="completed","completed remaining worker "+label)
        receipts.append(dict(label=label,identity=original,state=ending["state"],exited=True))
    require(observed_failures==set(failures),"both historical failures preserved")
    require(not list(ROOT.rglob("__pycache__")),"no bytecode artifacts")
    write("CLEANUP-VERIFIED.json",dict(passed=True,workers=receipts,preserved_failed_workers=sorted(observed_failures),verifier_identity=owner,verifier_exit_requires_external_check=True,continuing_workers_authorized=False))
    print(json.dumps(dict(passed=True,prior_workers_exited=len(receipts),preserved_failed_workers=sorted(observed_failures),verifier_pid=owner["pid"])),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("operation",choices=("seal","postseal"))
    operation=parser.parse_args().operation
    with worker(operation+"-accepted") as owner:
        if operation=="seal":
            seal()
        else:
            postseal(owner)
