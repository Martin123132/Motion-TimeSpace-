from common import *
import mpmath as precision
import numpy as np
import general_k_model as model


def primitive_mapping(values, wave):
    field, velocity, mass, beta = values
    frequency = precision.sqrt(mass**2 + wave**2)
    density_factor = beta * mass * (frequency + mass) / 2
    current_factor = beta * wave * mass / 2
    return precision.matrix([
        [density_factor * field, density_factor * velocity / (mass * frequency)],
        [current_factor * velocity / mass, -current_factor * field / frequency],
    ])


def angular_mean(wave_value, mass_value, count, digits):
    with precision.workdps(digits):
        wave, mass, hubble, energy, beta = [precision.mpf(value) for value in (wave_value, mass_value, .02, .003, 7.)]
        frequency = precision.sqrt(mass**2 + wave**2)
        amplitude = precision.sqrt(2 * energy / (beta * mass**2))
        step = precision.mpf(10) ** (-digits // 2)
        total = precision.zeros(3)
        for index in range(count):
            if index % 16 == 0:
                guard()
            theta = 2 * precision.pi * index / count
            field, velocity = amplitude * precision.cos(theta), -mass * amplitude * precision.sin(theta)
            values = [field, velocity, mass, beta]
            rates = [velocity, -2 * hubble * velocity - mass**2 * field, hubble * mass, hubble * beta]
            mapping = primitive_mapping(values, wave)
            derivative = primitive_mapping([value + step * 1j * rate for value, rate in zip(values, rates)], wave).apply(lambda value: precision.im(value) / step)
            inverse = mapping**-1
            primitive = precision.matrix([[0, 1], [-frequency**2, -2 * hubble]])
            opened = (derivative + mapping * primitive) * inverse
            gravity = mapping * precision.matrix([0, -wave * velocity])
            density = precision.matrix([[beta * mass**2 * field, beta * velocity]]) * inverse
            closed = opened + gravity * density / (2 * wave * hubble * beta)
            for row in range(2):
                for column in range(2):
                    total[row, column] += closed[row, column]
                total[row, 2] += gravity[row]
        total /= count
        return [[precision.nstr(total[row, column], digits) for column in range(3)] for row in range(3)]


def relative(left, right):
    with precision.workdps(100):
        first = [precision.mpf(value) for row in left for value in row]
        second = [precision.mpf(value) for row in right for value in row]
        denominator = max(max(abs(value) for value in first + second), precision.mpf("1e-100"))
        return float(max(abs(actual - expected) for actual, expected in zip(first, second)) / denominator)


def main():
    frozen = read(ROOT / "frozen-inputs.json")
    check_hashes(frozen)
    inputs = {str(ROOT / name): digest(ROOT / name) for name in ("verify_angular_precision.py", "ANGULAR-PRECISION-PROTOCOL.md", "validation.json", "test-start.json", "test-end.json")}
    require(read(ROOT / "test-end.json")["state"] == "failed" and exited(read(ROOT / "test-start.json")), "original failed checker exited")
    write("angular-precision-inputs.json", inputs)
    original = read(ROOT / "validation.json")
    failures = [row["name"] for row in original["checks"] if not row["passed"]]
    require(failures == ["k0.2/mu300.0/n64/mean", "k0.2/mu300.0/n128/mean"], "only documented angular means failed")
    rows, refinements = [], []
    for wave in (.2, 1., 5., 12.):
        for mass in (.5, 3., 30., 300.):
            expected = [[repr(float(value)) for value in row] for row in model.harmonics(np.array([mass, .02, .003, 7.]), wave)[0]]
            means = {}
            for count in (64, 128):
                lower, higher = angular_mean(wave, mass, count, 60), angular_mean(wave, mass, count, 90)
                error_lower, error_higher, precision_error = relative(lower, expected), relative(higher, expected), relative(lower, higher)
                name = f"k{wave}/mu{mass}/n{count}/mean"
                original_row = next(row for row in original["checks"] if row["name"] == name)
                rows.append(dict(name=name, binary64_original=original_row, mean60=lower, mean90=higher, error60=error_lower, error90=error_higher, precision_error=precision_error, passed=max(error_lower,error_higher,precision_error)<=ALGEBRA))
                means[count] = higher
            error = relative(means[64], means[128])
            refinements.append(dict(wave=wave,mass=mass,error=error,passed=error<=ALGEBRA))
    unaffected = [row for row in original["checks"] if not row["name"].endswith("/mean")]
    require(len(unaffected) == 482 and len(rows) == 32, "all means checked with unchanged remaining suite")
    accepted = all(row["passed"] for row in unaffected + rows + refinements) and all(row["passed"] for row in original["symbolic"]["identities"].values())
    check_hashes(inputs)
    check_hashes(frozen)
    write("accepted-validation.json", dict(passed=accepted, original_double_precision_suite_passed=False,original_double_precision_validation_sha256=digest(ROOT/"validation.json"),unchanged_numerical_checks=len(unaffected),higher_precision_mean_checks=len(rows),phase_grid_refinements=len(refinements),symbolic_identities=original["symbolic_count"],rows=rows,refinements=refinements,gate=ALGEBRA,input_hashes=inputs,original_inputs=frozen,new_late_evolution=False,precision_library=precision.__version__))
    print(json.dumps(dict(passed=accepted,original_checks_retained=len(unaffected),higher_precision_means=len(rows),grid_refinements=len(refinements),max_mean_error=max(row["error90"] for row in rows),max_precision_difference=max(row["precision_error"] for row in rows),max_grid_difference=max(row["error"] for row in refinements))),flush=True)
    require(accepted,"unchanged-gate angular precision verification")


if __name__ == "__main__":
    with worker("angular-precision"):
        main()
