import os
import sys
for setting in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[setting] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / "mts-live-memory-extraction-20261110"
PHASE = POST / "mts-phase-corrected-carrier-20261110"
CHECKED = POST / "mts-live-carrier-memory-20261110"
LATE = POST / "mts-late-hierarchy-port-20261110"
CANONICAL = POST / "mts-canonical-metric-closure-20261110"
START = time.monotonic()
GATE, ALGEBRA = 2e-5, 1e-10


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    checksum = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            checksum.update(block)
    return checksum.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(name, value):
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def check_hashes(mapping):
    for path, expected in mapping.items():
        guard()
        require(digest(path) == expected, "unchanged input " + path)


def guard():
    require(time.monotonic() - START < 900, "bounded worker deadline")
    bridge = Path("C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102")
    holds = [folder / "STOP-REQUESTED" for folder in (ROOT, POST, PREVIOUS, PHASE, CHECKED, LATE, CANONICAL, bridge)]
    holds.append(bridge.parent / "execution-v3/STOP-REQUEST.json")
    for path in holds:
        require(not path.exists(), "owner hold " + str(path))


def identity():
    process = psutil.Process()
    return dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())


def exited(owner):
    if not psutil.pid_exists(owner["pid"]):
        return True
    return psutil.Process(owner["pid"]).create_time() != owner["created"]


@contextmanager
def worker(name):
    guard()
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    owner = identity()
    write(name + "-start.json", owner)
    try:
        yield owner
    except BaseException as error:
        write(name + "-end.json", dict(**owner, state="failed", error=repr(error)))
        raise
    else:
        write(name + "-end.json", dict(**owner, state="completed", elapsed=time.monotonic() - START))
