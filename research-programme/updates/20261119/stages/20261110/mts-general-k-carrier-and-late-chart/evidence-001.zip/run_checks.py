from common import *
import argparse
import ast
import numpy as np
import sympy as symbolic
import general_k_model as model


def packet(path):
    with np.load(path, allow_pickle=False) as saved:
        return {name: saved[name].copy() for name in saved.files}


def freeze():
    stages = {
        PREVIOUS: "a1cac2de6db7a1dcd0091205a771599991aaaa92cc22e80b63d7bc047feca90a",
        PHASE: "22760b701ea5207c8331673150878f0ffc0a337e52034a6cad9f6c359f168b11",
        CHECKED: "d95943ea2b43737d5c55d449bc8cf3c5d34c6be34d8c410b7f87da4d2cbc7a35",
        LATE: "e863d5b1068e2f008035a9133a98b9671dbf6e22eed4cc861b9b2da52c2ecd60",
        CANONICAL: "afce7e9dd9cadbceadc7fd33bc8b70b9f3893f80c06416c909b54d089ca7d6ec",
    }
    sources = {}
    for stage, expected in stages.items():
        require(digest(stage / "closeout.json") == expected, "retained stage seal " + stage.name)
        sources[str(stage / "closeout.json")] = expected
    selections = {
        PREVIOUS: ["heavy-step256-h2-merged.npz", "cold-step256-h2-merged.npz", "contract.json", "RESULTS.md", "frozen-inputs.json"],
        PHASE: ["phase_model.py", "DERIVATION.md"],
        CHECKED: ["live_memory_model.py", "checked_live_memory_model.py"],
        LATE: ["check_metric.py", "run_port.py", "RESULTS.md", "NEXT.md"],
        CANONICAL: ["DERIVATION.md", "DEFECT-AND-NEWTON-BOUND.md"],
    }
    for case in ("cold", "heavy"):
        selections[LATE].extend("runs/" + case + "-v4/" + name for name in ("config.json", "result.json", "capture.npz", "full.npz", "precision.npz", "negative.npz", "zero.npz"))
    for stage, names in selections.items():
        artifacts = {Path(name): row for name, row in read(stage / "closeout.json")["artifacts"].items()}
        for name in names:
            path = stage / name
            require(digest(path) == artifacts[Path(name)]["sha256"], "retained accepted artifact " + str(path))
            sources[str(path)] = digest(path)
    projection = POST / "mts-coherent-projection-20261110/frozen-projection.npz"
    retained_projection = [expected for path, expected in read(PREVIOUS / "frozen-inputs.json").items() if Path(path) == projection]
    require(len(retained_projection) == 1 and digest(projection) == retained_projection[0], "retained source normalization")
    sources[str(projection)] = retained_projection[0]
    for path in (ROOT / "PROTOCOL.md", ROOT / "DERIVATION.md", ROOT / "common.py", ROOT / "general_k_model.py", ROOT / "run_checks.py"):
        if path.suffix == ".py":
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        sources[str(path)] = digest(path)
    write("frozen-inputs.json", sources)
    print(json.dumps(dict(frozen=True, inputs=len(sources))), flush=True)


def old_model():
    namespace = dict(np=np, require=require)
    tree = ast.parse((PHASE / "phase_model.py").read_text())
    names = {"harmonics", "periodic", "micromotion", "micromotion_prime", "effective"}
    selected = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    require(len(selected) == len(names), "exact retained phase functions")
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(PHASE / "phase_model.py"), "exec"), namespace)
    for path, name in ((CHECKED / "live_memory_model.py", "LiveMemory"), (CHECKED / "checked_live_memory_model.py", "CheckedLiveMemory")):
        selected = [node for node in ast.parse(path.read_text()).body if isinstance(node, ast.ClassDef) and node.name == name]
        require(len(selected) == 1, "retained corrected geometry class")
        exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), namespace)
    return namespace


def symbolic_checks():
    field, velocity, mass2, wave, hubble, rate, eta, alpha, mode, mode_velocity, shift, lapse = symbolic.symbols("b v mu2 k H r eta alpha u w z Psi", real=True)
    field_defect, background_defect, mode_defect, velocity_defect, shift_defect, lapse_defect = symbolic.symbols("Ef Eb euS ewS eshift elapse", real=True)
    potential = eta - hubble * alpha
    rates = {
        field: velocity + field_defect,
        velocity: -2 * hubble * velocity - mass2 * field + background_defect,
        mass2: 2 * rate * mass2,
        eta: (wave**2 * alpha - wave * shift - shift_defect) / 3,
        alpha: lapse - hubble * alpha + lapse_defect,
        mode: mode_velocity + mode_defect,
        mode_velocity: -2 * hubble * mode_velocity - (wave**2 + mass2) * mode - wave * shift * velocity + velocity_defect,
    }
    canonical_mode, momentum = model.synchronous_to_canonical(mode, mode_velocity, field, velocity, mass2, eta, alpha)
    derivative = lambda expression: sum(symbolic.diff(expression, coordinate) * value for coordinate, value in rates.items())
    exact_defects = [
        derivative(canonical_mode) - momentum - (lapse + 3 * potential) * velocity,
        derivative(momentum) + 2 * hubble * momentum + (wave**2 + mass2) * canonical_mode - mass2 * (3 * potential - lapse) * field,
    ]
    expected_defects = model.transformed_defects(mode_defect, velocity_defect, field_defect, background_defect, shift_defect, lapse_defect, field, velocity, mass2, hubble, rate, eta, alpha)
    density = velocity * mode_velocity + mass2 * field * mode
    pressure = velocity * mode_velocity - mass2 * field * mode
    current = wave * velocity * mode
    density_compensated = velocity * momentum + mass2 * field * canonical_mode
    recovered = model.canonical_to_synchronous(canonical_mode, momentum, field, velocity, mass2, eta, alpha)
    identities = dict(
        mode_inverse=recovered[0] - mode,
        velocity_inverse=recovered[1] - mode_velocity,
        compensated_density=density_compensated - (density - 3 * velocity**2 * eta),
        physical_density=density_compensated + 3 * velocity**2 * potential - (density - 3 * hubble * velocity**2 * alpha),
        physical_current=wave * velocity * canonical_mode - (current + wave * velocity**2 * alpha),
        physical_pressure=velocity * momentum - mass2 * field * canonical_mode + 3 * velocity**2 * potential - (pressure - (3 * hubble * velocity**2 + 2 * mass2 * field * velocity) * alpha),
        canonical_mode_defect=exact_defects[0] - expected_defects[0],
        canonical_momentum_defect=exact_defects[1] - expected_defects[1],
    )
    total_density, total_current, enthalpy = symbolic.symbols("Dsync Qsync St", real=True)
    new_current = total_current + wave * enthalpy * alpha
    compensated = total_density - 3 * enthalpy * eta
    identities["total_metric_feedback"] = (2 * wave**2 + 3 * enthalpy) * potential + compensated + 3 * hubble * new_current / wave - (2 * wave**2 * eta - 2 * wave**2 * hubble * alpha + total_density + 3 * hubble * total_current / wave)
    identities["cold_compensated_density"] = total_density - 3 * hubble * enthalpy * alpha - 3 * enthalpy * potential - (total_density - 3 * enthalpy * eta)
    output = {name: dict(passed=symbolic.expand(expression) == 0, residual=str(symbolic.expand(expression))) for name, expression in identities.items()}
    require(all(row["passed"] for row in output.values()), "exact arbitrary-defect gauge identities")
    return dict(identities=output, derived_defects=[str(symbolic.expand(value)) for value in exact_defects])


def test():
    frozen = read(ROOT / "frozen-inputs.json")
    check_hashes(frozen)
    proofs = symbolic_checks()
    checks = []

    def check(name, actual, expected, tolerance=ALGEBRA, scale_terms=()):
        actual, expected = np.asarray(actual), np.asarray(expected)
        scale = max([float(np.max(abs(actual))), float(np.max(abs(expected))), 1e-100] + [float(np.max(abs(term))) for term in scale_terms])
        error = float(np.max(abs(actual - expected))) / scale
        checks.append(dict(name=name, error=error, tolerance=tolerance, passed=bool(np.isfinite(error) and error <= tolerance)))

    legacy = old_model()
    for wave in (0.2, 1., 5., 12.):
        for mass in (0.5, 3., 30., 300.):
            guard()
            parameters = np.array([mass, .02, .003, 7.])
            hubble, energy, beta = parameters[1:]
            frequency = np.sqrt(mass**2 + wave**2)
            amplitude = np.sqrt(2 * energy / (beta * mass**2))
            label = f"k{wave}/mu{mass}"
            mean, cosine2, sine2, cosine4, sine4 = model.harmonics(parameters, wave)
            for count in (64, 128):
                primitive_operators, harmonic_operators, direct_sources, reconstructed_sources = [], [], [], []
                mapping_rates, independent_rates, inverses = [], [], []
                average_drift, average_commutator = [], []
                for theta in 2 * np.pi * np.arange(count) / count:
                    field, velocity = amplitude * np.cos(theta), -mass * amplitude * np.sin(theta)
                    mapping = model.primitive_map(field, velocity, mass, beta, wave)
                    field_prime, velocity_prime = velocity, -2 * hubble * velocity - mass**2 * field
                    arguments = np.array([field, velocity, mass, beta], dtype=complex)
                    argument_rates = np.array([field_prime, velocity_prime, hubble * mass, hubble * beta])
                    step = 1e-20
                    changed = arguments + step * 1j * argument_rates
                    independent_prime = np.imag(model.primitive_map(*changed, wave)) / step
                    mapping_prime = model.primitive_map_prime(field, velocity, field_prime, velocity_prime, mass, beta, hubble, wave)
                    mapping_rates.append(mapping_prime)
                    independent_rates.append(independent_prime)
                    primitive = np.array([[0., 1.], [-frequency**2, -2 * hubble]])
                    opened = np.linalg.solve(mapping.T, (independent_prime + mapping @ primitive).T).T
                    gravity = mapping @ np.array([0., -wave * velocity])
                    physical_row = np.array([beta * mass**2 * field, beta * velocity]) @ np.linalg.inv(mapping)
                    independent = np.zeros((3, 3))
                    independent[:2, :2] = opened + np.outer(gravity, physical_row) / (2 * wave * hubble * beta)
                    independent[:2, 2] = gravity
                    periodic = model.periodic(theta, parameters, wave)
                    primitive_operators.append(independent)
                    harmonic_operators.append(periodic)
                    sample = np.array([.7, -.3 * frequency])
                    normal = mapping @ sample
                    direct_sources.append(beta * np.array([velocity * sample[1] + mass**2 * field * sample[0], wave * velocity * sample[0], velocity * sample[1] - mass**2 * field * sample[0]]))
                    reconstructed_sources.append(model.source_rows(field, velocity, mass, beta, wave) @ normal)
                    inverses.append(np.linalg.solve(mapping, normal) / np.array([1., frequency]))
                    phase_rate = -1.5 * hubble * np.sin(2 * theta)
                    parameter_rates = np.array([0., energy * np.cos(2 * theta) / (2 * beta), 3 * hubble * energy * np.cos(2 * theta), 0.])
                    average_drift.append(-model.micromotion_prime(theta, parameters, wave, phase_rate, parameter_rates))
                    average_commutator.append((periodic - mean) @ model.micromotion(theta, parameters, wave))
                primitive_operators, harmonic_operators = np.array(primitive_operators), np.array(harmonic_operators)
                for row in range(2):
                    check(label + f"/n{count}/operator_row{row}", harmonic_operators[:, row], primitive_operators[:, row])
                    check(label + f"/n{count}/map_prime_row{row}", np.array(mapping_rates)[:, row], np.array(independent_rates)[:, row])
                for source in range(3):
                    check(label + f"/n{count}/source{source}", np.array(reconstructed_sources)[:, source], np.array(direct_sources)[:, source])
                check(label + f"/n{count}/inverse", inverses, np.tile([.7, -.3], (count, 1)))
                check(label + f"/n{count}/mean", np.mean(primitive_operators, axis=0), mean)
                unused, commutator, drift = model.effective(parameters, wave)
                check(label + f"/n{count}/drift", np.mean(average_drift, axis=0), drift)
                check(label + f"/n{count}/commutator", np.mean(average_commutator, axis=0), commutator)
            if wave == 1:
                for index, values in enumerate(model.harmonics(parameters, wave)):
                    check(label + f"/legacy_harmonic{index}", values, legacy["harmonics"](parameters)[index])
                for index, values in enumerate(model.effective(parameters, wave)):
                    check(label + f"/legacy_effective{index}", values, legacy["effective"](parameters)[index])
    for invalid in (0., -1., float("nan")):
        rejected = False
        try:
            model.harmonics(np.array([3., .02, .003, 7.]), invalid)
        except ValueError:
            rejected = True
        require(rejected, "invalid current-coordinate wavenumber rejected")
    correct_wave = model.periodic(.37, np.array([3., .02, .003, 7.]), 5.)
    wrong_wave = legacy["periodic"](.37, np.array([3., .02, .003, 7.]))
    wrong_wave_error = float(np.max(abs(correct_wave - wrong_wave)))
    require(wrong_wave_error > GATE, "negative control rejects relabelled k=1 operator")
    saved = packet(PREVIOUS / "heavy-step256-h2-merged.npz")
    density0 = float(packet(POST / "mts-coherent-projection-20261110/frozen-projection.npz")["density0"])
    old_engine = legacy["CheckedLiveMemory"](None, [0, 1], 0, 2, 0, 6, density0)
    for index in (0, 225, 450, 675, 901):
        values = dict(extra=saved["extra"][index], jets=saved["jets"][index])
        for hubble_prime in (0., .013):
            old_geometry = old_engine.geometry(values, hubble_prime)
            new_geometry = model.geometry(values, density0, 1., hubble_prime)
            for name in old_geometry:
                check(f"saved_k1/{index}/{hubble_prime}/{name}", new_geometry[name], old_geometry[name])
    late_records = []
    for case in ("cold", "heavy"):
        destination = LATE / "runs" / (case + "-v4")
        require(read(destination / "result.json")["passed"], "accepted paired native late control")
        capture = packet(destination / "capture.npz")
        names = capture["observer_names"].tolist()
        require(capture["times"].shape == (2,) and capture["full_times"].shape == (61,), "actual late endpoint and full-schedule coverage")
        require(capture["state"].shape[1] == (93 if case == "heavy" else 91), "retained late state dimensions")
        for tag in ("capture", "full", "precision", "negative", "zero"):
            data = capture if tag == "capture" else packet(destination / (tag + ".npz"))
            value = lambda name: data["observer"][:, names.index(name)]
            wave = 5.
            hubble, eta = value("H_native"), value("eta_sync")
            alpha = value("sigma") / wave
            potential = eta - hubble * alpha
            lapse = 2 * value("Weyl") - potential
            enthalpy = value("R") + value("Pbar")
            compensated = value("D_sync") - 3 * enthalpy * eta
            current = value("Q_sync") + wave * enthalpy * alpha
            closed = -(compensated + 3 * hubble * current / wave) / (2 * wave**2 + 3 * enthalpy)
            check(case + "/" + tag + "/canonical_total_constraint", closed, potential)
            potential_prime = value("Weyl_prime") + value("Pi_prime") / (2 * wave**2)
            check(case + "/" + tag + "/current_momentum", current, 2 * wave * (potential_prime + hubble * lapse), scale_terms=(2 * wave * potential_prime, 2 * wave * hubble * lapse))
            check(case + "/" + tag + "/lapse_chart", (value("sigma_prime") + hubble * value("sigma")) / wave, lapse)
            cold_density = value("R_cdm") * (value("delta_cdm64") - 3 * hubble * alpha)
            cold_compensated = value("R_cdm") * (value("delta_cdm64") - 3 * eta)
            check(case + "/" + tag + "/cold_compensated", cold_density - 3 * value("R_cdm") * potential, cold_compensated)
            cold_current = value("R_cdm") * value("sigma")
            check(case + "/" + tag + "/cold_current", cold_current, wave * value("R_cdm") * alpha)
            late_records.append(dict(case=case, tag=tag, endpoints=2, potential=potential.tolist(), current=current.tolist(), cold_current=cold_current.tolist()))
    check_hashes(frozen)
    result = dict(passed=all(row["passed"] for row in checks), symbolic=proofs, checks=checks, numerical_count=len(checks), symbolic_count=len(proofs["identities"]), negative_control_error=wrong_wave_error, late_records=late_records, late_forward_evolution_performed=False, canonical_scalar_initial_phase_selected=False, inputs=frozen)
    write("validation.json", result)
    print(json.dumps(dict(passed=result["passed"], numerical=len(checks), symbolic=result["symbolic_count"], worst=max(checks, key=lambda row: row["error"]), failures=[row for row in checks if not row["passed"]], negative_control=wrong_wave_error)), flush=True)
    require(result["passed"], "fixed-gate general-k and gauge checks")


def seal():
    frozen = read(ROOT / "frozen-inputs.json")
    check_hashes(frozen)
    validation = read(ROOT / "validation.json")
    require(validation["passed"], "verified derivation and saved-data checks")
    require((ROOT / "RESULTS.md").is_file() and (ROOT / "NEXT.md").is_file(), "saved results and next step")
    artifacts = {path.name: dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ("closeout.json", "seal-end.json", "postseal-start.json", "postseal-end.json", "CLEANUP-VERIFIED.json")}
    write("closeout.json", dict(derived_general_k=True,derived_canonical_defect_map=True,late_forward_evolution_performed=False,goal_complete=False,input_hashes=frozen,artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/"closeout.json"),artifacts=len(artifacts))),flush=True)


def postseal(owner):
    sealed = read(ROOT / "closeout.json")
    check_hashes(sealed["input_hashes"])
    check_hashes({str(ROOT/name): row["sha256"] for name,row in sealed["artifacts"].items()})
    receipts = []
    for path in sorted(ROOT.glob("*-start.json")):
        label = path.name.removesuffix("-start.json")
        if label == "postseal":
            continue
        original = read(path)
        ending = read(ROOT / (label + "-end.json"))
        documented_failure = label == "freeze" and ending["state"] == "failed" and ending.get("error") == "KeyError('runs/cold-v4/config.json')"
        require(exited(original) and (ending["state"] == "completed" or documented_failure), "completed or specifically audited failed worker exited " + label)
        require(all(original[key] == ending[key] for key in ("pid","created","command")), "worker identity continuity")
        receipts.append(dict(label=label, identity=original, exited=True, state=ending["state"], documented_failure=documented_failure))
    require(not list(ROOT.rglob("__pycache__")), "no bytecode residue")
    write("CLEANUP-VERIFIED.json", dict(passed=True,workers=receipts,verifier_identity=owner,verifier_exit_requires_external_check=True,continuing_workers_authorized=False))
    print(json.dumps(dict(passed=True,prior_workers=len(receipts),verifier_pid=owner["pid"])),flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("freeze","test","seal","postseal"))
    parser.add_argument("--receipt-suffix", default="")
    arguments = parser.parse_args()
    operation = arguments.operation
    require(not arguments.receipt_suffix or operation == "freeze" and arguments.receipt_suffix == "native-paths", "only the documented pre-freeze path repair uses a new receipt")
    label = operation + ("-" + arguments.receipt_suffix if arguments.receipt_suffix else "")
    with worker(label) as owner:
        if operation == "postseal":
            postseal(owner)
        else:
            globals()[operation]()
