from common import *
import numpy as np
import sympy as symbolic
from native_source_port import metric_port, scalar_pressure_sync


def main():
    frozen = read(ROOT / "frozen-inputs.json")
    check_hashes(frozen)
    require(read(ROOT / "accepted-validation.json")["passed"], "accepted general-k component")
    inputs = {str(ROOT/name):digest(ROOT/name) for name in ("native_source_port.py","verify_native_port.py","CURRENT-NATIVE-PORT.md","accepted-validation.json")}
    write("native-port-inputs.json", inputs)
    eta, hubble, wave, rest_density, rest_current, compensated, current, scalar_enthalpy, rest_enthalpy, anisotropy = symbolic.symbols("eta H k Dr Qr Dhstar Qh Sh Sr Pi", nonzero=True)
    numerator = rest_density + compensated + 3 * hubble * (rest_current + current) / wave
    potential = -numerator / (2 * wave**2 + 3 * scalar_enthalpy)
    alpha = (eta - potential) / hubble
    density_sync = compensated + 3 * scalar_enthalpy * eta
    current_sync = current - wave * scalar_enthalpy * alpha
    total_enthalpy = scalar_enthalpy + rest_enthalpy
    total_compensated = rest_density - 3 * rest_enthalpy * eta + compensated
    total_current = rest_current + wave * rest_enthalpy * alpha + current
    identities = {
        "native_shift_constraint": 2 * wave**2 * hubble * alpha - (rest_density + density_sync + 2 * wave**2 * eta + 3 * hubble * (rest_current + current_sync) / wave),
        "full_canonical_constraint": (2 * wave**2 + 3 * total_enthalpy) * potential + total_compensated + 3 * hubble * total_current / wave,
        "inverse_density": density_sync - 3 * scalar_enthalpy * eta - compensated,
        "inverse_current": current_sync + wave * scalar_enthalpy * alpha - current,
    }
    field, velocity, mass2, pressure_star = symbolic.symbols("b v mu2 Pstar")
    pressure_sync = scalar_pressure_sync(pressure_star, field, velocity, mass2, eta, alpha)
    identities["inverse_pressure"] = pressure_sync - (3 * hubble * velocity**2 + 2 * mass2 * field * velocity) * alpha - (pressure_star + 3 * velocity**2 * potential)
    proofs = {name:dict(passed=symbolic.cancel(expression)==0,residual=str(symbolic.cancel(expression))) for name,expression in identities.items()}
    checks, wrong_chart = [], []
    def check(name, actual, expected, terms=()):
        scale = max([float(np.max(abs(actual))),float(np.max(abs(expected))),1e-100]+[float(np.max(abs(term))) for term in terms])
        error = float(np.max(abs(actual-expected)))/scale
        checks.append(dict(name=name,error=error,tolerance=ALGEBRA,passed=bool(np.isfinite(error) and error<=ALGEBRA)))
    for case in ("cold","heavy"):
        destination = LATE/"runs"/(case+"-v4")
        with np.load(destination/"capture.npz") as packet:
            names = packet["observer_names"].tolist()
        for tag in ("capture","full","precision","negative","zero"):
            with np.load(destination/(tag+".npz")) as packet:
                observer = packet["observer"].copy()
            value = lambda name:observer[:,names.index(name)]
            wave = 5.
            hubble, eta = value("H_native"),value("eta_sync")
            alpha = value("sigma")/wave
            reference_potential = eta-hubble*alpha
            reference_lapse = 2*value("Weyl")-reference_potential
            component_enthalpy = value("R_cdm")
            component_density = component_enthalpy*value("delta_cdm64")
            rest_density = value("D_sync")-component_density
            compensated = component_density-3*component_enthalpy*eta
            current = component_enthalpy*wave*alpha
            result = metric_port(eta,hubble,wave,rest_density,value("Q_sync"),compensated,current,component_enthalpy,value("Pi"))
            prefix = case+"/"+tag
            check(prefix+"/potential",result["potential"],reference_potential)
            check(prefix+"/alpha",result["alpha"],alpha)
            check(prefix+"/lapse",result["lapse"],reference_lapse)
            check(prefix+"/component_density",result["density_sync"],component_density)
            check(prefix+"/component_current",result["current_sync"],np.zeros_like(current),terms=(current,wave*component_enthalpy*result["alpha"]))
            if tag=="capture":
                numerator = rest_density+compensated+3*hubble*(value("Q_sync")+current)/wave
                wrong_potential = -numerator/(2*wave**2+3*(value("R")+value("Pbar")))
                error = float(np.max(abs(wrong_potential-reference_potential)))/float(np.max(abs(reference_potential)))
                wrong_chart.append(dict(case=case,error=error,detected=error>ALGEBRA))
    check_hashes(inputs)
    check_hashes(frozen)
    passed = all(row["passed"] for row in checks) and all(row["passed"] for row in proofs.values()) and all(row["detected"] for row in wrong_chart)
    write("native-port-validation.json",dict(passed=passed,identities=proofs,checks=checks,wrong_chart_controls=wrong_chart,input_hashes=inputs,endpoint_count_per_branch=2,original_schedule_count=61,new_heavy_phase_chosen=False,new_late_evolution=False))
    print(json.dumps(dict(passed=passed,symbolic=len(proofs),paired_checks=len(checks),worst=max(row["error"] for row in checks),wrong_chart_controls=wrong_chart)),flush=True)
    require(passed,"native metric source connection")


if __name__=="__main__":
    with worker("native-port"):
        main()
