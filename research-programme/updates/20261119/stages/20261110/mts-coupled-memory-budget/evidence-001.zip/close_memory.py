from memory_support import *
import argparse


def validate():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    analysis=read(ROOT/'analysis.json')
    require(analysis['passed'] and all(value['passed'] for value in analysis['coordinate_map'].values()),'budget and coordinate checks')
    require(all(analysis['identities'].values()),'symbolic checks')
    for case in ('cold','heavy'):
        report=read(ROOT/(case+'-result.json'))
        require(report['passed'] and len(report['runs'])==8,'paired coverage')
        for key,row in report['runs'].items():
            path=ROOT/(case+'-'+key.replace('/','-')+'.npz')
            require(digest(path)==row['packet_sha256'],'packet unchanged')
            data=packet(path)
            require(np.all(np.isfinite(data['integrals'])) and np.all(np.isfinite(data['predictions'])),'finite output')
            for position,name in enumerate(data['prediction_names']):
                checks=columns(data['predictions'][position:position+1],data['target'][None,:],'source_')
                require(all(checks[label]['passed']==row['controls'][str(name)][label]['passed'] for label in checks),'positive and negative classifications unchanged')
            require(row['passed'] and row['bound_passed'],'fixed acceptance checks')
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='validate-start.json':
            continue
        identity=read(path)
        end=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(identity)
        require(end['state']=='completed' and outcome['exited'],'completed prior worker')
        workers.append(dict(identity=identity,outcome=outcome,name=path.stem))
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('validation.json',dict(passed=True,paired_variants=16,comparison_checks=analysis['check_count'],symbolic_identities=len(analysis['identities']),workers=workers,negative_controls_preserved=True,new_independent_evolution=False))
    print(json.dumps(dict(passed=True,variants=16,checks=analysis['check_count'],identities=len(analysis['identities']),workers_exited=len(workers))),flush=True)


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['passed'],'validated memory result')
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json')}
    write('closeout.json',dict(implementation_validated=True,paired_memory_budget_passed=True,signed_weight_boundaries_retained=True,conditional_energy_bound_evaluated=True,zero_remainder_reduction_authorized=False,regular_source_coordinates_derived=True,source_coordinate_inverse_tested=True,independent_source_coordinate_evolution_tested=False,old_late_carrier_replaced=False,positive_ensemble_or_galactic_population_selected=False,certified_uniform_averaging_bound=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    result=read(ROOT/'closeout.json')
    check_hashes(result['input_hashes'])
    check_hashes({str(ROOT/name):entry['sha256'] for name,entry in result['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='postseal-start.json':
            continue
        owner=read(path)
        end=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(owner)
        require(outcome['exited'] and end['state']=='completed','owned worker clean exit')
        workers.append(dict(name=path.stem,identity=owner,state=end['state'],outcome=outcome))
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('validate','seal','postseal'))
    args=parser.parse_args()
    with worker(args.operation) as identity:
        if args.operation=='validate':
            validate()
        elif args.operation=='seal':
            seal()
        else:
            postseal(identity)
