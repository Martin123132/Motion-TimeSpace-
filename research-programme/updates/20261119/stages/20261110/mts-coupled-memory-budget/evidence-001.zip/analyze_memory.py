from memory_support import *
import sympy as sp


def proofs():
    beta,field,velocity,mode,mode_velocity,mass2,rate,hubble,wave,dilation,field_error,velocity_error,hubble_prime,dilation_prime=sp.symbols('beta b v u w mu2 r H k z Ef Eb Hp zp',real=True)
    density=beta*(velocity*mode_velocity+mass2*field*mode)
    current=beta*wave*velocity*mode
    pressure=beta*(velocity*mode_velocity-mass2*field*mode)
    virial=beta*field*velocity
    perturbation_virial=beta*(field*mode_velocity+velocity*mode)
    derivatives={beta:rate*beta,field:velocity+field_error,velocity:-2*hubble*velocity-mass2*field+velocity_error,mode:mode_velocity,mode_velocity:-2*hubble*mode_velocity-(wave**2+mass2)*mode-wave*dilation*velocity,mass2:2*rate*mass2,hubble:hubble_prime,dilation:dilation_prime}
    def differentiate(value):
        return sum(sp.diff(value,variable)*derivative for variable,derivative in derivatives.items())
    sound2=sp.symbols('cs2',real=True)
    averaged=sound2*(density+3*hubble*current/wave)
    tail=((2*hubble-rate)*perturbation_virial+beta*wave**2*field*mode+wave*dilation*virial-beta*(field_error*mode_velocity+velocity_error*mode))/2-averaged
    representation_D=(rate-hubble)*density+beta*velocity_error*mode_velocity+beta*mass2*field_error*mode+2*beta*(rate-hubble)*mass2*field*mode
    representation_Q=(rate-hubble)*current+beta*wave*velocity_error*mode
    energy=beta*(velocity**2+mass2*field**2)/2
    perturbation_energy=beta*(mode_velocity**2+mass2*mode**2)/2
    defect=beta*(field_error*velocity+velocity_error*field)
    kinetic_history=-wave*dilation*(energy-1)+wave*dilation_prime*virial/2-wave*(2*hubble-rate)*dilation*virial/2+wave*dilation*defect/2
    history_D=sp.Rational(3,2)*hubble_prime*perturbation_virial-3*hubble*tail+kinetic_history+representation_D
    history_Q=wave*tail+representation_Q
    smooth_density=density+(3*hubble*perturbation_virial+wave*dilation*virial)/2
    smooth_current=current-wave*perturbation_virial/2
    rest=sp.symbols('zrest',real=True)
    substituted=smooth_density.subs(dilation,rest+(density/beta)/(2*wave*hubble))
    matrix=sp.Matrix([substituted-wave*virial*rest/2,smooth_current]).jacobian([mode,mode_velocity])
    determinant=-beta**2*wave*((1+field*velocity/(4*hubble))*(mass2*field**2+velocity**2)+3*hubble*field*velocity)/2
    coefficient0,coefficient1,value0,value1,value2=sp.symbols('C0 C1 X0 X1 X2')
    identities=dict(pressure_virial=sp.simplify(differentiate(perturbation_virial)/2+tail-(pressure-averaged))==0,smooth_density_equation=sp.simplify(differentiate(smooth_density)-(-3*hubble*averaged-wave*current-wave*dilation+history_D))==0,smooth_current_equation=sp.simplify(differentiate(smooth_current)-(-hubble*current+wave*averaged+history_Q))==0,kinetic_amplitude_square=sp.simplify(energy**2/mass2-virial**2-beta**2*(velocity**2-mass2*field**2)**2/(4*mass2))==0,perturbation_amplitude_square=sp.simplify(4*energy*perturbation_energy/mass2-perturbation_virial**2-beta**2*(velocity*mode_velocity-mass2*field*mode)**2/mass2)==0,affine_source_map=sp.simplify(sp.Matrix([substituted-wave*virial*rest/2,smooth_current])-matrix*sp.Matrix([mode,mode_velocity]))==sp.zeros(2,1),source_map_determinant=sp.simplify(matrix.det()-determinant)==0,weighted_boundary=sp.expand(coefficient0*(value1-value0)+coefficient1*(value2-value1)-(-coefficient0*value0+(coefficient0-coefficient1)*value1+coefficient1*value2))==0)
    require(all(identities.values()),'exact memory, amplitude and coordinate-map identities')
    write('symbolic.json',dict(passed=True,identities=identities,matrix=[[str(value) for value in matrix.row(index)] for index in range(2)],determinant=str(determinant),sufficient_regular_condition='k>0, H>0, beta>0, mu>9H/4, and rho_h<=3H^2 with nonzero positive heavy energy'))
    return identities


def coordinate_check(window):
    path=PREVIOUS/'heavy-live-reconstructed-step256.npz' if window=='live' else TRANSFER/'heavy-transfer-source-readout.npz'
    data=packet(path)
    capture=packet(PREVIOUS/'heavy-live-capture.npz' if window=='live' else TRANSFER/'heavy-transfer-capture.npz')
    first=int(capture['signature'][0,2])-1
    density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
    scale,rate,hubble,dilation=data['extra'].T
    beta=scale/density0
    field,velocity,field_first,velocity_first,mass2,omega=data['jets'][:,1].T
    mass=np.sqrt(mass2)
    mode,mode_velocity=data['vector'][:,first+2:first+4].T
    observed=data['observation']
    rest_density=observed[:,12]*observed[:,19]+np.sum(observed[:,13:17]*observed[:,20:24],axis=1)+observed[:,32]
    rest=(rest_density/2+observed[:,7])/hubble
    density=beta*(velocity*mode_velocity+mass2*field*mode)
    current=beta*velocity*mode
    virial=beta*field*velocity
    perturbation_virial=beta*(field*mode_velocity+velocity*mode)
    actual=np.column_stack([density+(3*hubble*perturbation_virial+dilation*virial)/2,current-perturbation_virial/2])
    factor=1+field*velocity/(4*hubble)
    matrices=np.empty((len(beta),2,2))
    matrices[:,0,0]=beta*(factor*mass2*field+1.5*hubble*velocity)
    matrices[:,0,1]=beta*(factor*velocity+1.5*hubble*field)
    matrices[:,1,0]=beta*velocity/2
    matrices[:,1,1]=-beta*field/2
    offset=np.column_stack([virial*rest/2,np.zeros(len(beta))])
    state=np.column_stack([mode,mode_velocity])
    predicted=np.einsum('tij,tj->ti',matrices,state)+offset
    recovered=np.linalg.solve(matrices,(actual-offset)[:,:,None])[:,:,0]
    determinants=np.linalg.det(matrices)
    expected=-beta**2*((1+field*velocity/(4*hubble))*(mass2*field**2+velocity**2)+3*hubble*field*velocity)/2
    scaled=matrices.copy()
    scaled[:,:,0]/=mass[:,None]
    row_scale=np.linalg.norm(scaled,axis=2)
    conditioned=scaled/row_scale[:,:,None]
    conditions=np.linalg.cond(conditioned)
    energy=(velocity**2+mass2*field**2)/2
    margin=1-9*hubble/(4*mass)
    positive_density_bound=bool(np.all(energy<=3*hubble**2*(1+ALGEBRA)))
    checks=dict(forward=columns(predicted,actual,'source_',ALGEBRA),inverse=columns(recovered,state,'state_',ALGEBRA),determinant={'value':comparison(determinants,expected,ALGEBRA)},metric={'constraint':comparison(rest+(density/beta)/(2*hubble),dilation,ALGEBRA)})
    require(all_pass(checks) and positive_density_bound and np.min(margin)>0,'regular source-coordinate map')
    np.savez_compressed(ROOT/(window+'-source-coordinate-map.npz'),clock=data['clock'],matrices=matrices,offset=offset,state=state,actual=actual,predicted=predicted,recovered=recovered,determinant=determinants,condition=conditions,lower_margin=margin,background_fraction=energy/(3*hubble**2))
    return dict(passed=True,checks=checks,scaled_condition_max=float(np.max(conditions)),sufficient_margin_min=float(np.min(margin)),background_fraction_max=float(np.max(energy/(3*hubble**2))),phase_turning_points_require_no_velocity_division=True,pressure_fitted=False,independent_live_coordinate_evolution_tested=False,old_averaged_law_equivalent=False)


with worker('analyze'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    identities=proofs()
    checks={}
    summaries={}
    for case in ('cold','heavy'):
        results=read(ROOT/(case+'-result.json'))
        require(results['completed'] and results['passed'],'saved memory pair completed')
        for window in ('live','projection'):
            fine=packet(ROOT/(case+'-'+window+'-fine8.npz'))
            for config in ('fine4','fine8','degree7','stride2'):
                name=case+'-'+window+'-'+config
                data=packet(ROOT/(name+'.npz'))
                report=results['runs'][window+'/'+config]
                require(digest(ROOT/(name+'.npz'))==report['packet_sha256'],'saved packet hash')
                terms={str(key):data['integrals'][:,index] for index,key in enumerate(data['term_names'])}
                totals={name:float(data['interval_weights']@value) for name,value in terms.items()}
                boundary=data['boundary_coefficients']
                direct=np.array([totals['pressure_D']+totals['kinetic_D']+totals['representation_D'],totals['pressure_Q']+totals['representation_Q']])
                kinetic_boundary=-boundary@(data['node_z']*data['node_J'])/2
                pressure_boundary=np.array([-1.5*boundary@(data['node_H']*data['node_S']),boundary@data['node_S']/2])
                history=np.array([totals['pressure_history_D']+sum(totals[key] for key in ('kinetic_normalization','kinetic_metric','kinetic_expansion','kinetic_representation'))+totals['representation_D'],totals['pressure_history_Q']+totals['representation_Q']])
                assembled=pressure_boundary+np.array([kinetic_boundary,0])+history
                checks[name+'/budget']=columns(assembled[None,:],direct[None,:],'source_')
                checks[name+'/refinement']=columns(data['predictions'][2:4],fine['predictions'][2:4],'source_')
                checks[name+'/saved_direct']=columns(direct[None,:],data['direct_remainder'][None,:],'source_',ALGEBRA)
                for group,group_checks in report['checks'].items():
                    checks[name+'/'+group]=group_checks
                if config=='fine8':
                    summaries[case+'/'+window]=dict(initial=data['initial'],target=data['target'],direct_remainder=direct,boundary_terms=pressure_boundary+np.array([kinetic_boundary,0]),remaining_history=history,conditional_bound=data['bounds'],conditional_bound_over_endpoint=report['bounds_over_endpoint'],endpoint_checks=report['controls'],boundary_only_prediction=data['initial']+np.array([totals['base_D'],totals['base_Q']])+pressure_boundary+np.array([kinetic_boundary,0]))
    coordinates={window:coordinate_check(window) for window in ('live','projection')}
    passed=all_pass(checks)
    write('analysis.json',dict(passed=passed,checks=checks,check_count=sum(len(group) for group in checks.values()),identities=identities,summaries=summaries,coordinate_map=coordinates,zero_remainder_or_boundary_only_authorized=False,certified_uniform_averaging_bound=False))
    print(json.dumps(dict(passed=passed,checks=sum(len(group) for group in checks.values()),identities=len(identities),coordinates=coordinates,summaries={key:{name:value for name,value in entry.items() if name not in ('endpoint_checks',)} for key,entry in summaries.items()}),default=convert),flush=True)
    require(passed,'independent assembled memory checks')
