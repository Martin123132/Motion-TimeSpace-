from memory_support import *
from scipy.interpolate import CubicSpline,CubicHermiteSpline,make_interp_spline
sys.path.insert(0,str(SOURCE))
from quintic_model import functions as field_functions


class History:
    def __init__(self,case,window,stride,degree):
        self.case,self.window=case,window
        self.saved=packet(PREVIOUS/(case+'-live-reconstructed-step256.npz') if window=='live' else TRANSFER/(case+'-transfer-source-readout.npz'))
        capture=packet(PREVIOUS/(case+'-live-capture.npz') if window=='live' else TRANSFER/(case+'-transfer-capture.npz'))
        self.first=int(capture['signature'][0,2])-1
        self.times=self.saved['clock']
        self.frozen=packet(PROJECTION/'frozen-projection.npz')
        self.density0=float(self.frozen['density0'])
        self.fields=2 if case=='heavy' else 1
        self.indices=[*range(self.first,self.first+2*self.fields),1]
        selected=np.unique(np.r_[np.arange(0,len(self.times),stride),len(self.times)-1])
        self.selected=selected
        self.epochs=self.times[selected]
        self.states=CubicHermiteSpline(self.epochs,self.saved['vector'][selected][:,self.indices],self.saved['derivative'][selected][:,self.indices],axis=0)
        scale=self.saved['extra'][:,0]
        rate=self.saved['extra'][:,1]
        self.scale=CubicHermiteSpline(self.epochs,scale[selected],(scale*rate)[selected])
        observed=self.saved['observation']
        self.metric=make_interp_spline(self.epochs,observed[selected][:,[0,2,7,28]],k=degree)
        self.eta_rhs=make_interp_spline(self.epochs,observed[selected,8],k=degree)
        self.direct_z=make_interp_spline(self.epochs,self.saved['extra'][selected,3],k=degree)
        self.cdm_factor=float(observed[0,12]*scale[0]/self.density0)
        table=packet(BACKGROUND/(case+'-candidate-background.npz'))
        if case=='heavy':
            self.functions,_=field_functions(packet(SOURCE/'heavy-equation-quintic.npz'))
            self.mass=float(table['heavy_mass_mpc'])
        else:
            self.functions=[CubicSpline(table['efold'],table[name],bc_type='natural') for name in ('phi_s','phidot_s')]
            self.mass=float(table['slow_mass_mpc'])
        self.weight=np.ones(len(self.times)-1) if window=='live' else self.frozen['weights'].cumsum()[:-1]
        self.boundary=np.r_[-self.weight[0],self.weight[:-1]-self.weight[1:],self.weight[-1]]
        self.original_sources=self.readout(self.saved['vector'],self.saved['jets'],self.saved['extra'])

    def readout(self,states,jets,extra):
        beta=extra[:,0]/self.density0
        if self.case=='cold':
            return np.column_stack([self.cdm_factor*states[:,1],np.zeros(len(beta))])
        field,velocity,field_first,velocity_first,mass2,omega=jets[:,1].T
        mode,mode_velocity=states[:,self.first+2:self.first+4].T
        return np.column_stack([beta*(velocity*mode_velocity+mass2*field*mode),beta*velocity*mode])

    def geometry(self,times):
        values=self.metric(times)
        derivative=self.metric(times,1)
        total,density,eta,hubble_direct=values.T
        total_prime,density_prime,eta_prime,hubble_prime_direct=derivative.T
        require(np.all(total>0),'positive Friedmann density')
        hubble=np.sqrt(total/3)
        hubble_prime=total_prime/(6*hubble)
        dilation=(density/2+eta)/hubble
        dilation_prime=(density_prime/2+self.eta_rhs(times))/hubble-dilation*hubble_prime/hubble
        interpolation_prime=(density_prime/2+eta_prime)/hubble-dilation*hubble_prime/hubble
        return hubble,hubble_prime,dilation,dilation_prime,dict(eta_equation=comparison(eta_prime,self.eta_rhs(times)),hubble_derivative=comparison(hubble_prime,hubble_prime_direct),z_derivative=comparison(dilation_prime,self.direct_z(times,1)),z_constraint=comparison(dilation,self.direct_z(times)),z_equation_vs_interpolation=comparison(dilation_prime,interpolation_prime))

    def evaluate(self,times):
        times=np.atleast_1d(times)
        hubble,hubble_prime,dilation,dilation_prime,metric_checks=self.geometry(times)
        scale=self.scale(times)
        rate=self.scale(times,1)/scale
        values=self.states(times)
        count=len(times)
        zeros=np.zeros(count)
        if self.case=='cold':
            density=self.cdm_factor*values[:,-1]
            base=-self.cdm_factor*dilation
            terms=dict(base_D=base,base_Q=zeros,pressure_D=zeros,kinetic_D=zeros,representation_D=zeros,pressure_Q=zeros,representation_Q=zeros,dynamic_D=base,dynamic_Q=zeros,kinetic_normalization=zeros,kinetic_metric=zeros,kinetic_expansion=zeros,kinetic_representation=zeros,pressure_history_D=zeros,pressure_history_Q=zeros,bound_D=zeros,bound_Q=zeros)
            rows=dict(density=density,current=zeros,J=zeros,S=zeros,E=zeros,J_bound=zeros,S_bound=zeros,z=dilation,H=hubble,z_prime=dilation_prime,H_prime=hubble_prime,pressure=zeros,averaged_pressure=zeros,smooth_density=density,smooth_current=zeros)
            return terms,rows,metric_checks,{}
        field=self.functions[0](np.log(scale))
        velocity=self.functions[1](np.log(scale))
        field_first=self.functions[0](np.log(scale),1)
        velocity_first=self.functions[1](np.log(scale),1)
        mass2=(scale*self.mass)**2
        mass=np.sqrt(mass2)
        beta=scale/self.density0
        mode,mode_velocity=values[:,2:4].T
        field_error=rate*field_first-velocity
        velocity_error=rate*velocity_first+2*hubble*velocity+mass2*field
        density=beta*(velocity*mode_velocity+mass2*field*mode)
        current=beta*velocity*mode
        pressure=beta*(velocity*mode_velocity-mass2*field*mode)
        sound2=(1/mass2)/(np.sqrt(1+1/mass2)+1)**2
        averaged=sound2*(density+3*hubble*current)
        residual=pressure-averaged
        virial=beta*field*velocity
        perturbation_virial=beta*(field*mode_velocity+velocity*mode)
        energy=beta*(velocity**2+mass2*field**2)/2
        perturbation_energy=beta*(mode_velocity**2+mass2*mode**2)/2
        defect=beta*(field_error*velocity+velocity_error*field)
        perturbation_defect=beta*(field_error*mode_velocity+velocity_error*mode)
        pressure_tail=((2*hubble-rate)*perturbation_virial+beta*field*mode+dilation*virial-perturbation_defect)/2-averaged
        representation_D=(rate-hubble)*density+beta*velocity_error*mode_velocity+beta*mass2*field_error*mode+2*beta*(rate-hubble)*mass2*field*mode
        representation_Q=(rate-hubble)*current+beta*velocity_error*mode
        mode_prime=mode_velocity
        mode_velocity_prime=-2*hubble*mode_velocity-(1+mass2)*mode-dilation*velocity
        dynamic_D=rate*density+beta*(rate*velocity_first*mode_velocity+velocity*mode_velocity_prime+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_prime)
        dynamic_Q=rate*current+beta*(rate*velocity_first*mode+velocity*mode_prime)
        virial_prime=rate*virial+beta*rate*(field_first*velocity+field*velocity_first)
        perturbation_virial_prime=rate*perturbation_virial+beta*(rate*field_first*mode_velocity+field*mode_velocity_prime+rate*velocity_first*mode+velocity*mode_prime)
        bound_J=energy/mass
        bound_S=2*np.sqrt(energy*perturbation_energy)/mass
        bound_tail=(abs(2*hubble-rate)*bound_S+beta*abs(field*mode)+abs(dilation)*bound_J+beta*(abs(field_error*mode_velocity)+abs(velocity_error*mode)))/2+abs(averaged)
        kinetic_parts=dict(kinetic_normalization=-dilation*(energy-1),kinetic_metric=dilation_prime*virial/2,kinetic_expansion=-(2*hubble-rate)*dilation*virial/2,kinetic_representation=dilation*defect/2)
        terms=dict(base_D=-3*hubble*averaged-current-dilation,base_Q=-hubble*current+averaged,pressure_D=-3*hubble*residual,kinetic_D=-dilation*(beta*velocity**2-1),representation_D=representation_D,pressure_Q=residual,representation_Q=representation_Q,dynamic_D=dynamic_D,dynamic_Q=dynamic_Q,**kinetic_parts,pressure_history_D=1.5*hubble_prime*perturbation_virial-3*hubble*pressure_tail,pressure_history_Q=pressure_tail,bound_D=1.5*abs(hubble_prime)*bound_S+3*abs(hubble)*bound_tail+abs(dilation)*abs(energy-1)+abs(dilation_prime)*bound_J/2+abs(2*hubble-rate)*abs(dilation)*bound_J/2+abs(dilation)*abs(defect)/2+abs(representation_D),bound_Q=bound_tail+abs(representation_Q))
        algebra=dict(pressure_virial=comparison(perturbation_virial_prime/2+pressure_tail,residual,ALGEBRA),kinetic_virial=comparison(energy-1+virial_prime/2+(2*hubble-rate)*virial/2-defect/2,beta*velocity**2-1,ALGEBRA),density_equation=comparison(terms['base_D']+terms['pressure_D']+terms['kinetic_D']+representation_D,dynamic_D,ALGEBRA),current_equation=comparison(terms['base_Q']+residual+representation_Q,dynamic_Q,ALGEBRA))
        require(np.all(abs(virial)<=bound_J*(1+ALGEBRA)) and np.all(abs(perturbation_virial)<=bound_S*(1+ALGEBRA)),'analytic energy amplitude bounds')
        rows=dict(density=density,current=current,J=virial,S=perturbation_virial,E=energy,J_bound=bound_J,S_bound=bound_S,z=dilation,H=hubble,z_prime=dilation_prime,H_prime=hubble_prime,pressure=pressure,averaged_pressure=averaged,smooth_density=density+(3*hubble*perturbation_virial+dilation*virial)/2,smooth_current=current-perturbation_virial/2)
        return terms,rows,metric_checks,algebra
