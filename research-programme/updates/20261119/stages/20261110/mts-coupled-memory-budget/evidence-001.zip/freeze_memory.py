from memory_support import *


with worker('freeze'):
    require(digest(PREVIOUS/'closeout.json')==EXPECTED,'previous live seal')
    seal=read(PREVIOUS/'closeout.json')
    check_hashes(seal['input_hashes'])
    check_hashes({str(PREVIOUS/name):value['sha256'] for name,value in seal['artifacts'].items()})
    cleanup=read(PREVIOUS/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and exited(cleanup['verifier_identity'])['exited'],'previous verifier exited')
    paths=[PREVIOUS/'closeout.json',PREVIOUS/'live_support.py',PROJECTION/'frozen-projection.npz',SOURCE/'quintic_model.py',SOURCE/'heavy-equation-quintic.npz',COUPLED/'native/fortran/equations.f90',COUPLED/'native/fortran/MTSTwoField.f90']
    for case in ('cold','heavy'):
        paths.extend([PREVIOUS/(case+'-live-reconstructed-step256.npz'),PREVIOUS/(case+'-live-capture.npz'),TRANSFER/(case+'-transfer-source-readout.npz'),TRANSFER/(case+'-transfer-capture.npz'),BACKGROUND/(case+'-candidate-background.npz')])
    paths.extend(sorted(ROOT.glob('*.py')))
    write('frozen-inputs.json',{str(path):digest(path) for path in paths})
    write('contract.json',dict(cases=['cold','heavy'],windows=['live','projection'],configs=[dict(name='fine4',stride=1,degree=5,order=4),dict(name='fine8',stride=1,degree=5,order=8),dict(name='degree7',stride=1,degree=7,order=8),dict(name='stride2',stride=2,degree=5,order=8)],gate=GATE,algebra=ALGEBRA,bank_and_physical_grid_unchanged=True,source_norm='original a225-w6-d8 rho0',metric_derivative='differentiate saved Hamiltonian and Friedmann constraints; native eta prime; independently check interpolation derivatives',negative_controls=['no_remainder','pressure_only'],pressure_fit=False,goal_complete=False))
    print(json.dumps(dict(frozen=True,inputs=len(paths),paired_windows=2,configs=4)),flush=True)
