import sys
from pathlib import Path
from time import monotonic
PREVIOUS=Path(__file__).resolve().parent.parent/'mts-reconstructed-live-continuation-20261110'
sys.path.insert(0,str(PREVIOUS))
import live_support as retained
retained.ROOT=Path(__file__).resolve().parent
retained.START=monotonic()
from live_support import *
PREVIOUS=POST/'mts-reconstructed-live-continuation-20261110'
EXPECTED='4d832bb8775acef51184e2990e969c5ce88838c86ce46fab9444e41e95338ebc'
original_guard=retained.guard


def guard():
    original_guard()
    require(not (PREVIOUS/'STOP-REQUESTED').exists(),'previous-stage owner hold')


retained.guard=guard
