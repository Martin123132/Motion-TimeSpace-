from memory_model import *
from numpy.polynomial.legendre import leggauss
import argparse


def evaluate(context,order):
    nodes,weights=leggauss(order)
    halfwidth=np.diff(context.times)/2
    midpoints=(context.times[:-1]+context.times[1:])/2
    times=(midpoints[:,None]+halfwidth[:,None]*nodes).ravel()
    terms,rows,metric,algebra=context.evaluate(times)
    _,endpoints,endpoint_metric,endpoint_algebra=context.evaluate(context.times)
    integrals={name:np.einsum('iq,q,i->i',value.reshape(-1,order),weights,halfwidth) for name,value in terms.items()}
    totals={name:float(context.weight@value) for name,value in integrals.items()}
    coefficient=context.boundary
    boundaries=dict(kinetic_D=float(-coefficient@(endpoints['z']*endpoints['J'])/2),pressure_D=float(-1.5*coefficient@(endpoints['H']*endpoints['S'])),pressure_Q=float(coefficient@endpoints['S']/2))
    direct=np.array([totals['pressure_D']+totals['kinetic_D']+totals['representation_D'],totals['pressure_Q']+totals['representation_Q']])
    kinetic_history=sum(totals[name] for name in ('kinetic_normalization','kinetic_metric','kinetic_expansion','kinetic_representation'))
    boundary_remainder=np.array([boundaries['pressure_D']+boundaries['kinetic_D']+totals['pressure_history_D']+kinetic_history+totals['representation_D'],boundaries['pressure_Q']+totals['pressure_history_Q']+totals['representation_Q']])
    base=np.array([totals['base_D'],totals['base_Q']])
    pressure=np.array([totals['pressure_D'],totals['pressure_Q']])
    source=context.original_sources
    initial=source[0] if context.window=='live' else context.frozen['weights']@source
    target=source[-1]
    predictions=dict(no_remainder=initial+base,pressure_only=initial+base+pressure,direct_remainder=initial+base+direct,boundary_remainder=initial+base+boundary_remainder)
    source_checks={name:columns(value[None,:],target[None,:],'source_') for name,value in predictions.items()}
    boundary_checks=dict(kinetic=comparison(boundaries['kinetic_D']+kinetic_history,totals['kinetic_D']),combined=columns(boundary_remainder[None,:],direct[None,:],'source_'))
    interval_checks=columns(np.column_stack([integrals['dynamic_D'],integrals['dynamic_Q']]),np.diff(source,axis=0),'source_')
    bounds=np.array([np.sum(abs(coefficient)*(1.5*abs(endpoints['H'])*endpoints['S_bound']+abs(endpoints['z'])*endpoints['J_bound']/2)),np.sum(abs(coefficient)*endpoints['S_bound']/2)])
    bounds+=np.array([abs(context.weight)@integrals['bound_D'],abs(context.weight)@integrals['bound_Q']])
    checks=dict(metric=metric,endpoint_metric=endpoint_metric,algebra=algebra,endpoint_algebra=endpoint_algebra,direct_transfer=source_checks['direct_remainder'],boundary_transfer=source_checks['boundary_remainder'],intervals=interval_checks,boundary_kinetic={'kinetic':boundary_checks['kinetic']},boundary_combined=boundary_checks['combined'])
    passed=all_pass(checks)
    bound_passed=bool(np.all(abs(direct)<=bounds+GATE*np.maximum(abs(direct),np.max(abs(source),axis=0))))
    output=dict(clock=context.times,interval_weights=context.weight,boundary_coefficients=coefficient,source=source,initial=initial,target=target,direct_remainder=direct,boundary_remainder=boundary_remainder,bounds=bounds,prediction_names=np.array(list(predictions)),predictions=np.array(list(predictions.values())),term_names=np.array(list(integrals)),integrals=np.column_stack(list(integrals.values())),**{'node_'+name:value for name,value in endpoints.items()})
    report=dict(passed=passed,bound_passed=bound_passed,checks=checks,controls=source_checks,boundaries=boundaries,totals=totals,direct_remainder=direct,boundary_remainder=boundary_remainder,bounds=bounds,bounds_over_endpoint=np.divide(bounds,abs(target),out=np.zeros_like(bounds),where=target!=0),metric_derivative_max=max(row['normalized'] or 0 for row in metric.values()),role='finite-support source transfer on saved history, not independently forecast cosmology',conditional_analytic_bound_numerically_integrated=True,certified_continuum_bound=False)
    return output,report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=('cold','heavy'))
    arguments=parser.parse_args()
    with worker(arguments.case+'-memory'):
        check_hashes(read(ROOT/'frozen-inputs.json'))
        contract=read(ROOT/'contract.json')
        reports={}
        for window in contract['windows']:
            for config in contract['configs']:
                context=History(arguments.case,window,config['stride'],config['degree'])
                data,result=evaluate(context,config['order'])
                name=arguments.case+'-'+window+'-'+config['name']
                path=ROOT/(name+'.npz')
                np.savez_compressed(path,**data)
                result['packet_sha256']=digest(path)
                reports[window+'/'+config['name']]=result
                print(json.dumps(dict(case=arguments.case,window=window,config=config['name'],passed=result['passed'],metric=result['metric_derivative_max'],direct=result['checks']['direct_transfer'],boundary=result['checks']['boundary_transfer'],bound=result['bound_passed']),default=convert),flush=True)
        check_hashes(read(ROOT/'frozen-inputs.json'))
        write(arguments.case+'-result.json',dict(completed=True,passed=all(value['passed'] and value['bound_passed'] for value in reports.values()),runs=reports))
