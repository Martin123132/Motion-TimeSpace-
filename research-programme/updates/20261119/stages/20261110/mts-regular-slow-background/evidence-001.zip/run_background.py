from stable_model import *
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('variant', choices=('fine1', 'fine2', 'coarse2'))
    args = parser.parse_args()
    label = args.case + '-' + args.variant
    with worker(label):
        source_hashes = {str(path): digest(path) for path in (Path(__file__), ROOT / 'stable_model.py', ROOT / 'background_support.py', ROOT / 'frozen-background.json')}
        model = Background(args.case, 'coarse' if args.variant == 'coarse2' else 'fine')
        state = integrate(model, int(args.variant[-1]))
        output = model.readout(model.efold, state)
        require(all(np.isfinite(value).all() for value in output.values()), 'finite readouts')
        field_rate = output['scale']**3 * output['j'] / output['H']
        momentum_rate = -5 * output['j'] - model.mass**2 * output['phi'] / (output['scale'] * output['H'])
        rho_rate = 3 * output['scale']**6 * output['j']**2 + output['scale']**6 * output['j'] * momentum_rate + (output['scale'] * model.mass)**2 * (output['phi']**2 + output['phi'] * field_rate)
        conservation_scale = np.max(abs(rho_rate) + abs(output['rho']) + 3 * abs(output['pressure']))
        conservation = float(np.max(abs(rho_rate + output['rho'] + 3 * output['pressure']))) / float(conservation_scale)
        friedmann = float(np.max(abs(3 * output['H']**2 - output['rest'] - output['rho']) / (3 * output['H']**2)))
        require(conservation < ALGEBRA and friedmann < ALGEBRA, 'background source algebra')
        np.savez_compressed(ROOT / (label + '.npz'), normalized_state=state, normalization=model.normalization, **output)
        matching = (output['scale'] >= model.configuration['matching_scale_range'][0]) & (output['scale'] <= model.configuration['matching_scale_range'][1])
        require(np.count_nonzero(matching) >= 3, 'matching source nodes retained')
        velocity_change = float(np.max(abs(output['v'][matching] - model.data['old_v'][matching])) / np.max(abs(model.data['old_v'][matching])))
        result = dict(completed=True, case=args.case, variant=args.variant, nodes=len(model.efold), initial_state_preserved=bool(state[0, 0] == 0 and output['j'][0] == model.j0), initial_field=model.field0, initial_j=model.j0, conservation_algebra=conservation, friedmann_algebra=friedmann, present_expansion2=float(output['expansion2'][-1]), present_flatness_difference=float(abs(output['expansion2'][-1] - 1)), matching_velocity_change_relative=velocity_change, maximum_H_change_relative=float(np.max(abs(output['H'] / model.data['old_H'] - 1))), final_field=float(output['phi'][-1]), final_j=float(output['j'][-1]), packet_sha256=digest(ROOT / (label + '.npz')), source_hashes=source_hashes, no_refit=True, full_native_hierarchy=False)
        check_hashes(source_hashes)
        write(label + '-result.json', result)
        print(json.dumps({key: result[key] for key in ('completed', 'case', 'variant', 'nodes', 'present_flatness_difference', 'matching_velocity_change_relative', 'maximum_H_change_relative', 'conservation_algebra', 'friedmann_algebra')}), flush=True)


if __name__ == '__main__':
    main()
