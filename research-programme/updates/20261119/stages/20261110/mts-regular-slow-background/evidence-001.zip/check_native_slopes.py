from check_native_replay import *


class SlopeReplay(NativeReplay):
    def __init__(self, case, representation):
        super().__init__(case, 'candidate', representation)
        with np.load(ROOT / ('native-' + case + '-candidate.npz'), allow_pickle=False) as saved:
            observer = {str(name): saved['observer'][:, index] for index, name in enumerate(saved['observer_names'])}
            all_clock = saved['clock'].copy()
        lower, upper = read(PREVIOUS / 'frozen-replay.json')['saved_indices']
        indices = np.arange(lower - 8, upper + 9)
        hubble = observer['H_native'][indices]
        alpha = observer['sigma'][indices]
        alpha_prime = observer['sigma_prime'][indices]
        hubble_prime = -(observer['R'][indices] + 3 * observer['Pbar'][indices]) / 6
        potential_prime = observer['eta_prime'][indices] - hubble_prime * alpha - hubble * alpha_prime
        lapse_prime = 2 * observer['Weyl_prime'][indices] - potential_prime
        alpha_check = retained.difference(alpha_prime, self.data['Psi'] - hubble * alpha)
        slip_check = retained.difference(potential_prime - lapse_prime, observer['Pi_prime'][indices])
        selected = np.arange(len(indices)) if representation == 'fine' else np.unique(np.r_[np.arange(0, len(indices), 2), len(indices) - 1, self.target[0], self.target[-1]])
        local_clock = all_clock[indices]
        self.potential = CubicHermiteSpline(local_clock[selected], self.data['Phi'][selected], potential_prime[selected])
        self.lapse = CubicHermiteSpline(local_clock[selected], self.data['Psi'][selected], lapse_prime[selected])
        omitted = np.setdiff1d(np.arange(len(indices)), selected)
        heldout = {} if not len(omitted) else {name: retained.difference(function(local_clock[omitted]), self.data[name][omitted]) for name, function in [('Phi', self.potential), ('Psi', self.lapse)]}
        self.slope_checks = dict(alpha_identity=alpha_check, slip_derivative_identity=slip_check, heldout=heldout)


def main():
    with worker('native-slope-check'):
        files = [Path(__file__), ROOT / 'METRIC-SLOPE-TEST.md', ROOT / 'check_native_replay.py', ROOT / 'native-residual-diagnosis-result.json']
        hashes = {str(path): digest(path) for path in files}
        write('native-slope-frozen.json', hashes)
        reports = {}
        for case in ('cold', 'heavy'):
            outputs, runs = {}, {}
            for variant in ('fine2', 'fine4', 'coarse4'):
                context = SlopeReplay(case, 'coarse' if variant == 'coarse4' else 'fine')
                state = retained.advance(context, int(variant[-1]))
                observed = context.observe(state)
                checks = {name: retained.difference(value, context.data[name][context.target]) for name, value in observed.items()}
                destination = ROOT / ('slope-replay-' + case + '-' + variant + '.npz')
                np.savez_compressed(destination, clock=context.clock, state=state, **observed)
                outputs[variant] = observed
                runs[variant] = dict(checks=checks, passed=all(row['passed'] for row in checks.values()), slope_checks=context.slope_checks, packet_sha256=digest(destination))
            refinement = {name: retained.difference(outputs['fine2'][name], value) for name, value in outputs['fine4'].items()}
            history = {name: retained.difference(outputs['coarse4'][name], value) for name, value in outputs['fine4'].items()}
            slope_ok = all(run['slope_checks']['alpha_identity']['normalized'] < ALGEBRA and run['slope_checks']['slip_derivative_identity']['normalized'] < ALGEBRA and all(row['passed'] for row in run['slope_checks']['heldout'].values()) for run in runs.values())
            passed = all(run['passed'] for run in runs.values()) and all(row['passed'] for row in list(refinement.values()) + list(history.values())) and slope_ok
            reports[case] = dict(passed=passed, runs=runs, refinement=refinement, history_sensitivity=history, native_slope_identities_passed=slope_ok)
            print(json.dumps(dict(case=case, passed=passed, slopes=context.slope_checks, worst=max(row['normalized'] for row in runs['fine4']['checks'].values()), failures={name: row['normalized'] for name, row in runs['fine4']['checks'].items() if not row['passed']})), flush=True)
        check_hashes(hashes)
        write('native-slope-result.json', dict(completed=True, candidate_pair_passed=all(row['passed'] for row in reports.values()), cases=reports, numerical_gate=GATE, algebra_gate=ALGEBRA, source_hashes=hashes, forced_replay_only=True, original_results_preserved=True))


if __name__ == '__main__':
    main()
