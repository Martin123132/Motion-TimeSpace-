from background_support import *
import argparse
import ast


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('boost', type=int, choices=(12, 24))
    args = parser.parse_args()
    source = ROOT / 'run_native_readout.py'
    contract = ROOT / 'NATIVE-ACCURACY-TEST.md'
    expected = read(ROOT / 'native-heavy-candidate-result.json')['source_hashes'][str(source)]
    require(digest(source) == expected, 'original runner preserved')
    tree = ast.parse(source.read_text(encoding='utf-8'))
    changed = dict(label=0, boost=0, provenance=0)

    class Specialize(ast.NodeTransformer):
        def visit_Assign(self, node):
            if any(isinstance(target, ast.Name) and target.id == 'label' for target in node.targets):
                changed['label'] += 1
                node.value = ast.BinOp(left=node.value, op=ast.Add(), right=ast.Constant('-tol' + str(args.boost)))
            if any(isinstance(target, ast.Attribute) and target.attr == 'IntTolBoost' for target in node.targets):
                require(isinstance(node.value, ast.Constant) and node.value.value == 6, 'original boost6')
                changed['boost'] += 1
                node.value = ast.Constant(args.boost)
            if any(isinstance(target, ast.Name) and target.id == 'files' for target in node.targets):
                require(isinstance(node.value, ast.List), 'explicit source list')
                changed['provenance'] += 1
                node.value.elts.extend(ast.parse('ROOT / "run_native_readout.py", ROOT / "NATIVE-ACCURACY-TEST.md"', mode='eval').body.elts)
            return self.generic_visit(node)

    tree = Specialize().visit(tree)
    require(changed == dict(label=1, boost=1, provenance=1), 'exact narrow specialization')
    ast.fix_missing_locations(tree)
    namespace = dict(__file__=__file__, __name__='frozen_accuracy_specialization')
    exec(compile(tree, str(source), 'exec'), namespace)
    sys.argv = [str(source), args.case, 'candidate']
    namespace['main']()


if __name__ == '__main__':
    main()
