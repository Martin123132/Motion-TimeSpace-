from background_support import *
import importlib.util
import numpy as np
from scipy.interpolate import CubicSpline, CubicHermiteSpline

sys.path.insert(0, str(PREVIOUS))
specification = importlib.util.spec_from_file_location('retained_replay_model', PREVIOUS / 'replay_model.py')
retained = importlib.util.module_from_spec(specification)
specification.loader.exec_module(retained)


class NativeReplay(retained.Context):
    def __init__(self, case, variant, representation):
        self.case = case
        self.representation = representation
        label = 'native-' + case + '-' + variant
        report = read(ROOT / (label + '-result.json'))
        require(report['completed'], 'completed coupled native case')
        check_hashes(report['source_hashes'])
        require(digest(ROOT / (label + '.npz')) == report['packet_sha256'], 'native packet integrity')
        with np.load(ROOT / (label + '.npz'), allow_pickle=False) as saved:
            columns = {str(name): saved['standard'][:, index] for index, name in enumerate(saved['names'])}
            observer = {str(name): saved['observer'][:, index] for index, name in enumerate(saved['observer_names'])}
            clock = saved['clock'].copy()
        frozen = read(PREVIOUS / 'frozen-replay.json')
        lower, upper = frozen['saved_indices']
        fine_indices = np.arange(lower - 8, upper + 9)
        target = np.arange(lower, upper + 1) - (lower - 8)
        coarse = np.unique(np.r_[np.arange(0, len(fine_indices), 2), len(fine_indices) - 1, target[0], target[-1]])
        scale, hubble, eta, alpha = [observer[name] for name in ('a_native', 'H_native', 'eta_sync', 'sigma')]
        potential = eta - hubble * alpha
        lapse = potential - observer['Pi']
        weyl_error = float(np.max(abs((potential + lapse) / 2 - observer['Weyl'])) / np.max(abs(observer['Weyl'])))
        require(weyl_error < ALGEBRA, 'double-precision metric convention')
        full_data = dict(clock=clock, a=scale, H=hubble, eta=eta, alpha=alpha, Phi=potential, Psi=lapse, dstar_cdm_over_rho=observer['delta_cdm64'] - 3 * eta, current_cdm_over_rho=alpha, delta_cdm_N=observer['delta_cdm64'] - 3 * hubble * alpha)
        self.fields = ['s'] if case == 'cold' else ['s', 'h']
        self.field_functions = {}
        masses = {}
        source_errors = {}
        with np.load(report['table'], allow_pickle=False) as table:
            for suffix in self.fields:
                efold = table['heavy_efold' if suffix == 'h' else 'efold']
                field_function = CubicSpline(efold, table['phi_' + suffix], bc_type='natural')
                velocity_function = CubicSpline(efold, table['phidot_' + suffix], bc_type='natural')
                self.field_functions[suffix] = (field_function, velocity_function)
                field, velocity = field_function(np.log(scale)), velocity_function(np.log(scale))
                mass = float(table['slow_mass_mpc' if suffix == 's' else 'heavy_mass_mpc'])
                masses[suffix] = mass
                mass2 = (scale * mass)**2
                sync_u, sync_w = columns['mts_dphi_' + suffix], columns['mts_dphidot_' + suffix]
                new_u = sync_u + velocity * alpha
                new_p = sync_w - mass2 * field * alpha - 3 * eta * velocity
                kinetic, mass_term = velocity * new_p, mass2 * field * new_u
                sources = dict(u=new_u, p=new_p, D=kinetic + mass_term + 3 * velocity**2 * potential, P=kinetic - mass_term + 3 * velocity**2 * potential, Q=velocity * new_u, Dstar=kinetic + mass_term, Pi=scale**2 * new_p)
                full_data.update({suffix + '_' + name: values for name, values in sources.items()})
                expected = dict(D=columns['mts_drho_' + suffix] - 3 * hubble * velocity**2 * alpha, P=columns['mts_dp_' + suffix] - (3 * hubble * velocity**2 + 2 * mass2 * field * velocity) * alpha, Q=columns['mts_q_' + suffix] + velocity**2 * alpha)
                for name, reference in expected.items():
                    error = retained.difference(sources[name][fine_indices], reference[fine_indices])
                    require(error['passed'], 'native source recovery ' + suffix + name)
                    source_errors[suffix + '_' + name] = error
        self.parameters = dict(masses=masses)
        self.data = {name: values[fine_indices] for name, values in full_data.items()}
        self.target = target
        self.clock = self.data['clock'][target]
        state_names = ['dstar_cdm_over_rho', 'current_cdm_over_rho'] + [suffix + '_' + component for suffix in self.fields for component in ('u', 'p')]
        self.data['reference_state'] = np.column_stack([self.data[name][target] for name in state_names])
        self.normalization = np.max(abs(self.data['reference_state']), axis=0)
        require(np.all(self.normalization > 0), 'nonzero physical state normalization')
        selected = np.arange(len(fine_indices)) if representation == 'fine' else coarse
        selected_clock = self.data['clock'][selected]
        selected_scale = self.data['a'][selected]
        self.scale = CubicHermiteSpline(selected_clock, selected_scale, selected_scale * self.data['H'][selected])
        self.scale_prime = self.scale.derivative()
        self.potential = CubicSpline(selected_clock, self.data['Phi'][selected])
        self.lapse = CubicSpline(selected_clock, self.data['Psi'][selected])
        self.provenance = dict(weyl_convention_error=weyl_error, source_recovery=source_errors, native_table=report['table'], native_packet_sha256=report['packet_sha256'], metric_precision='real*8 native observer', full_species_evolved=True, independent_replay_is_forced=True)


def main():
    with worker('native-replay-check'):
        reports = {}
        for case in ('cold', 'heavy'):
            for table in ('old', 'candidate'):
                label = case + '-' + table
                outputs = {}
                runs = {}
                for variant in ('fine2', 'fine4', 'coarse4'):
                    guard()
                    context = NativeReplay(case, table, 'coarse' if variant == 'coarse4' else 'fine')
                    state = retained.advance(context, int(variant[-1]))
                    observables = context.observe(state)
                    checks = {name: retained.difference(value, context.data[name][context.target]) for name, value in observables.items()}
                    outputs[variant] = observables
                    path = ROOT / ('replay-' + label + '-' + variant + '.npz')
                    np.savez_compressed(path, clock=context.clock, state=state, **observables)
                    runs[variant] = dict(passed=all(row['passed'] for row in checks.values()), checks=checks, packet_sha256=digest(path))
                refinement = {name: retained.difference(outputs['fine2'][name], value) for name, value in outputs['fine4'].items()}
                history = {name: retained.difference(outputs['coarse4'][name], value) for name, value in outputs['fine4'].items()}
                passed = runs['fine4']['passed'] and all(row['passed'] for row in refinement.values()) and all(row['passed'] for row in history.values())
                reports[label] = dict(passed=passed, runs=runs, step_refinement=refinement, history_sensitivity=history, provenance=context.provenance)
                worst = max(runs['fine4']['checks'], key=lambda name: runs['fine4']['checks'][name]['normalized'])
                print(json.dumps(dict(case=case, table=table, passed=passed, worst=worst, error=runs['fine4']['checks'][worst]['normalized'], failed=[name for name, row in runs['fine4']['checks'].items() if not row['passed']])), flush=True)
        candidates_passed = all(reports[case + '-candidate']['passed'] for case in ('cold', 'heavy'))
        write('native-replay-result.json', dict(completed=True, candidate_pair_passed=candidates_passed, old_failures_not_relabelled=True, cases=reports, source_hashes={str(path): digest(path) for path in (Path(__file__), PREVIOUS / 'replay_model.py', PREVIOUS / 'replay_support.py', ROOT / 'NATIVE-READOUT-CONTRACT.md')}, numerical_gate=GATE, full_state_restart_saved=False, independent_full_hierarchy_reintegration=False))
        print(json.dumps(dict(candidate_pair_passed=candidates_passed)), flush=True)


if __name__ == '__main__':
    main()
