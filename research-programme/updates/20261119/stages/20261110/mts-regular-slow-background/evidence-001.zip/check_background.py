from stable_model import *
import sympy as sym
from scipy.interpolate import CubicHermiteSpline
from numpy.polynomial.legendre import leggauss


def prove():
    scale, hubble, mass, field, momentum = sym.symbols('a H m b j', positive=True)
    field_rate = scale**3 * momentum / hubble
    momentum_rate = -5 * momentum - mass**2 * field / (scale * hubble)
    rho = (scale**6 * momentum**2 + scale**2 * mass**2 * field**2) / 2
    pressure = (scale**6 * momentum**2 - scale**2 * mass**2 * field**2) / 2
    rho_rate = sym.diff(rho, scale) * scale + sym.diff(rho, field) * field_rate + sym.diff(rho, momentum) * momentum_rate
    source, radiation = sym.symbols('b_infinity A', positive=True)
    series = source * (1 - mass**2 * scale**4 / (20 * radiation**2) + mass**4 * scale**8 / (1440 * radiation**4))
    equation = sym.expand(sym.diff(series, scale, 2) + 2 * sym.diff(series, scale) / scale + (mass / radiation)**2 * scale**2 * series)
    exact_j = radiation * sym.diff(series, scale) / scale**3
    finite_j = -mass**2 * series / (5 * radiation) - mass**4 * scale**4 * series / (225 * radiation**3)
    checks = dict(energy_identity=rho_rate + rho + 3 * pressure, integrating_factor=scale**5 * (5 * momentum + momentum_rate) + scale**4 * mass**2 * field / hubble, radiation_leading=equation.coeff(scale, 2), radiation_next=equation.coeff(scale, 6), finite_seed_leading=sym.expand(exact_j - finite_j).coeff(scale, 0), finite_seed_next=sym.expand(exact_j - finite_j).coeff(scale, 4))
    result = {name: str(sym.simplify(value)) for name, value in checks.items()}
    require(all(value == '0' for value in result.values()), 'derived background identities')
    return result


def load(case, variant):
    report = read(ROOT / (case + '-' + variant + '-result.json'))
    require(report['completed'], 'completed background evolution')
    check_hashes(report['source_hashes'])
    source = ROOT / (case + '-' + variant + '.npz')
    require(digest(source) == report['packet_sha256'], 'background result hash')
    with np.load(source, allow_pickle=False) as packet:
        return {key: packet[key].copy() for key in packet.files}, report


def compare(first, second, matching):
    checks = {}
    require(np.all(second['j'] != 0), 'no zero j reference')
    checks['j_uniform_relative'] = float(np.max(abs(first['j'] / second['j'] - 1)))
    checks['H_uniform_relative'] = float(np.max(abs(first['H'] / second['H'] - 1)))
    checks['offset_global'] = float(np.max(abs(first['offset'] - second['offset'])) / np.max(abs(second['offset'])))
    checks['offset_matching'] = float(np.max(abs(first['offset'][matching] - second['offset'][matching])) / np.max(abs(second['offset'][matching])))
    checks['v_matching'] = float(np.max(abs(first['v'][matching] - second['v'][matching])) / np.max(abs(second['v'][matching])))
    return dict(passed=all(value <= GATE for value in checks.values()), checks=checks, tolerance=GATE)


def integral_check(model, solution, order):
    nodes, weights = leggauss(order)
    efold = solution['efold']
    midpoint = (efold[1:] + efold[:-1]) / 2
    halfwidth = np.diff(efold) / 2
    query = midpoint[:, None] + halfwidth[:, None] * nodes
    field_rate = solution['scale']**3 * solution['j'] / solution['H'] / model.normalization[0]
    momentum_rate = (-5 * solution['j'] - model.mass**2 * solution['phi'] / (solution['scale'] * solution['H'])) / model.normalization[1]
    trajectory = CubicHermiteSpline(efold, solution['normalized_state'], np.column_stack([field_rate, momentum_rate]), axis=0)
    sampled = trajectory(query)
    scale = np.exp(query)
    offset = sampled[:, :, 0] * model.normalization[0]
    momentum = sampled[:, :, 1] * model.normalization[1]
    field = model.field0 + offset
    hubble = np.sqrt((np.exp(model.rest(query)) + (scale**6 * momentum**2 + (scale * model.mass * field)**2) / 2) / 3)
    impulse = (scale**4 * field / hubble) @ weights * halfwidth
    displacement = (scale**3 * momentum / hubble) @ weights * halfwidth
    initial_J = solution['scale'][0]**5 * model.j0
    reconstructed_j = (initial_J - model.mass**2 * np.r_[0., np.cumsum(impulse)]) / solution['scale']**5
    reconstructed_offset = np.r_[0., np.cumsum(displacement)]
    j_error = float(np.max(abs(reconstructed_j / solution['j'] - 1)))
    nonzero = solution['offset'] != 0
    offset_error = float(np.max(abs(reconstructed_offset[nonzero] / solution['offset'][nonzero] - 1)))
    return dict(order=order, j_error=j_error, offset_error=offset_error, passed=j_error <= GATE and offset_error <= GATE), reconstructed_j, reconstructed_offset


def main():
    with worker('background-check'):
        identities = prove()
        cases = {}
        for case in ('cold', 'heavy'):
            model = Background(case, 'fine')
            lower, lower_report = load(case, 'fine1')
            higher, higher_report = load(case, 'fine2')
            coarser, coarse_report = load(case, 'coarse2')
            lower_a, upper_a = model.configuration['matching_scale_range']
            matching = (higher['scale'] >= lower_a) & (higher['scale'] <= upper_a)
            refinement = compare(lower, higher, matching)
            interpolation = compare(coarser, higher, matching)
            coarse_model = Background(case, 'coarse')
            omitted = np.setdiff1d(np.arange(len(model.efold)), model.data['coarse_indices'])
            rest_error = float(np.max(abs(np.exp(coarse_model.rest(model.efold[omitted])) / model.data['rest'][omitted] - 1)))
            quadrature = []
            quadrature_arrays = {}
            for order in (4, 8):
                guard()
                report, momentum, offset = integral_check(model, higher, order)
                quadrature.append(report)
                quadrature_arrays['j' + str(order)] = momentum
                quadrature_arrays['offset' + str(order)] = offset
            np.savez_compressed(ROOT / (case + '-integral-check.npz'), efold=model.efold, **quadrature_arrays)
            accepted = refinement['passed'] and interpolation['passed'] and rest_error < GATE and all(row['passed'] for row in quadrature) and higher_report['present_flatness_difference'] < GATE
            cases[case] = dict(passed=accepted, step_refinement=refinement, rest_interpolation=interpolation, heldout_rest_relative_error=rest_error, quadrature=quadrature, original_result=higher_report, matching_samples=int(matching.sum()))
            require(accepted, 'stable background candidate gates ' + case)
            with np.load(model.configuration['source'], allow_pickle=False) as original:
                candidate = {key: original[key].copy() for key in original.files}
            candidate.update(phi_s=higher['phi'], phidot_s=higher['v'], expansion2=higher['expansion2'])
            destination = ROOT / (case + '-candidate-background.npz')
            require(not destination.exists(), 'new candidate only')
            np.savez_compressed(destination, **candidate)
            cases[case]['candidate_path'] = str(destination)
            cases[case]['candidate_sha256'] = digest(destination)
        write('background-check-result.json', dict(passed=all(row['passed'] for row in cases.values()), identities=identities, cases=cases, old_tables_modified=False, no_refit=True, native_validated=False, code_sha256=digest(__file__)))
        print(json.dumps({case: dict(passed=row['passed'], step_error=max(row['step_refinement']['checks'].values()), interpolation_error=max(row['rest_interpolation']['checks'].values()), heldout_rest_error=row['heldout_rest_relative_error'], quadrature=row['quadrature'], candidate_sha256=row['candidate_sha256']) for case, row in cases.items()}), flush=True)


if __name__ == '__main__':
    main()
