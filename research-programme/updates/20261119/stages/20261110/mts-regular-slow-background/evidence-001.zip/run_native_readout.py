from background_support import *
import argparse
import ast
import ctypes
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('variant', choices=('old', 'candidate'))
    args = parser.parse_args()
    label = 'native-' + args.case + '-' + args.variant
    with worker(label):
        accepted = read(ROOT / 'background-check-result.json')
        require(accepted['passed'], 'verified repaired background')
        owner = BRANCH / 'native-heavy-matching-20261007'
        observer_owner = POST / 'mts-metric-feedback-20261107'
        factory_source = owner / 'matching_common.py'
        observer_source = observer_owner / 'observe_native.py'
        names = ast.literal_eval(next(node.value for node in ast.parse(observer_source.read_text()).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'NAMES' for target in node.targets)))
        observer_receipt = read(observer_owner / 'compiler-shortpath-receipt.json')
        require(observer_receipt['exit_code'] == 0 and observer_receipt['temporary_mapping_removed'], 'retained observer build accepted')
        require(digest(observer_owner / 'observer.dll') == observer_receipt['dll_sha256'], 'observer binary hash')
        require(digest(observer_owner / 'observer.f90') == observer_receipt['source_sha256'], 'observer source hash')
        table = EARLY / ('runs/backgrounds/' + args.case + '.npz') if args.variant == 'old' else ROOT / (args.case + '-candidate-background.npz')
        expected = read(ROOT / 'frozen-background.json')['cases'][args.case]['source_sha256'] if args.variant == 'old' else accepted['cases'][args.case]['candidate_sha256']
        require(digest(table) == expected, 'correct source table')
        schedule = POST / 'mts-early-canonical-state-bridge-20261110/k1-early-source.npz'
        files = [table, schedule, factory_source, observer_source, observer_owner / 'observer.dll', observer_owner / 'observer.f90', observer_owner / 'compiler-shortpath-receipt.json', owner / 'native/camb/cambdll.dll', owner / 'native/camb/mts.py', owner / 'native/camb/model.py', owner / 'native/camb/results.py', owner / 'native/fortran/MTSTwoField.f90', owner / 'native/fortran/equations.f90', owner / 'native/fortran/camb_python.f90', BRANCH / 'radiation-and-slow-field-transfer-20261007/radiation_common.py', Path(__file__), ROOT / 'NATIVE-READOUT-CONTRACT.md']
        hashes = {str(path): digest(path) for path in files}
        retained = read(ROOT / 'frozen-inputs.json')
        for path in (owner / 'native/camb/cambdll.dll', owner / 'native/fortran/MTSTwoField.f90', owner / 'native/fortran/equations.f90'):
            require(str(path) in retained and hashes[str(path)] == retained[str(path)], 'retained native ownership ' + str(path))
        write(label + '-frozen.json', hashes)
        sys.path.insert(0, str(owner / 'native'))
        import camb
        from camb.mts import MTSTwoField
        sys.path.append(str(BRANCH / 'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        factory = next(node for node in ast.parse(factory_source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_source), 'exec'), namespace)
        observer_dll = ctypes.CDLL(str(observer_owner / 'observer.dll'))
        callback = ctypes.cast(observer_dll.source_func_, ctypes.c_void_p)
        with np.load(schedule, allow_pickle=False) as packet:
            scales = packet['requested_scale'].copy()
        params = namespace['params_for'](table)
        native = camb.get_background(params)
        try:
            clock = np.ascontiguousarray(native.conformal_time(1 / scales - 1, tol=1e-10))
            native.Params.Accuracy.IntTolBoost = 6
            native.Params.Accuracy.lAccuracyBoost = 4
            standard_names = list(camb.model.evolve_names)
            wave = np.array([1.], dtype=np.float64)
            count = len(standard_names) + len(names)
            output = np.zeros((1, len(clock), count))
            guard()
            code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(1)), wave, ctypes.byref(ctypes.c_int(len(clock))), clock, ctypes.byref(ctypes.c_int(count)), output, ctypes.byref(ctypes.c_int(len(names))), ctypes.byref(callback))
            require(code == 0 and np.isfinite(output).all(), 'native coupled early evolution')
            standard = output[0, :, :len(standard_names)]
            observer = output[0, :, len(standard_names):]
            require(np.all(standard[:, standard_names.index('mts_match_count')] == 0), 'no phase matching event')
            require(np.all(standard[:, standard_names.index('mts_averaged_chart')] == 0), 'exact coherent early branch')
            require(np.all(np.diff(observer[:, names.index('a_native')]) > 0), 'ordered actual native scales')
            destination = ROOT / (label + '.npz')
            np.savez_compressed(destination, requested_scale=scales, clock=clock, names=np.array(standard_names), observer_names=np.array(names), standard=standard, observer=observer, wave=1.)
        finally:
            del native
        check_hashes(hashes)
        write(label + '-result.json', dict(completed=True, case=args.case, variant=args.variant, table=str(table), table_sha256=expected, samples=len(clock), packet_sha256=digest(destination), native_error_code=int(code), full_native_species_evolved=True, full_state_restart_saved=False, precision='observer real*8 before transfer float32 cast', new_fit=False, source_hashes=hashes))
        print(json.dumps(dict(completed=True, case=args.case, variant=args.variant, samples=len(clock), native_error_code=int(code), packet_sha256=digest(destination))), flush=True)


if __name__ == '__main__':
    main()
