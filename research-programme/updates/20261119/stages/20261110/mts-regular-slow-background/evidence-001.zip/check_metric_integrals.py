from check_native_replay import *
from numpy.polynomial.legendre import leggauss


def main():
    with worker('metric-integral-check'):
        reports = {}
        for case in ('cold', 'heavy'):
            context = NativeReplay(case, 'candidate', 'fine')
            with np.load(ROOT / ('native-' + case + '-candidate.npz'), allow_pickle=False) as saved:
                observer = {str(name): saved['observer'][:, index] for index, name in enumerate(saved['observer_names'])}
                full_clock = saved['clock'].copy()
            lower, upper = read(PREVIOUS / 'frozen-replay.json')['saved_indices']
            guard_indices = np.arange(lower - 8, upper + 9)
            observer_clock_error = float(np.max(abs(observer['tau_native'] - full_clock)))
            hubble_source = -(observer['R'] + 3 * observer['Pbar']) / 6
            functions = {name: CubicSpline(full_clock[guard_indices], value[guard_indices]) for name, value in dict(H_source=hubble_source, H=observer['H_native'], alpha=observer['sigma']).items()}
            functions['Psi'] = context.lapse
            clock = context.clock
            halfwidth = np.diff(clock) / 2
            midpoint = (clock[:-1] + clock[1:]) / 2
            orders, arrays = {}, {}
            for order in (4, 8):
                nodes, weights = leggauss(order)
                query = midpoint[:, None] + halfwidth[:, None] * nodes
                sources = dict(H=functions['H_source'](query), alpha=functions['Psi'](query) - functions['H'](query) * functions['alpha'](query), dstar=-functions['alpha'](query))
                reference = dict(H=context.data['H'][context.target], alpha=context.data['alpha'][context.target], dstar=context.data['dstar_cdm_over_rho'][context.target])
                checks = {}
                for name, value in sources.items():
                    integrated = reference[name][0] + np.r_[0., np.cumsum((value @ weights) * halfwidth)]
                    checks[name] = retained.difference(integrated, reference[name])
                    arrays[name + str(order)] = integrated
                orders[str(order)] = checks
            quadrature = {name: retained.difference(arrays[name + '4'], arrays[name + '8']) for name in reference}
            destination = ROOT / (case + '-metric-integrals.npz')
            np.savez_compressed(destination, clock=clock, **arrays, **{name + '_reference': value for name, value in reference.items()})
            reports[case] = dict(orders=orders, quadrature=quadrature, observer_clock_error=observer_clock_error, packet_sha256=digest(destination))
            print(json.dumps(dict(case=case, observer_clock_error=observer_clock_error, normalized={name: row['normalized'] for name, row in orders['8'].items()}, absolute={name: row['absolute_max'] for name, row in orders['8'].items()}, quadrature={name: row['normalized'] for name, row in quadrature.items()})), flush=True)
        files = [Path(__file__), ROOT / 'check_native_replay.py', ROOT / 'native-tolerance-result.json']
        write('metric-integral-result.json', dict(completed=True, diagnostic_only=True, cases=reports, source_hashes={str(path): digest(path) for path in files}, requires_scaled_field_response_to_assess_significance=True))


if __name__ == '__main__':
    main()
