from background_support import *
import math
import numpy as np
from scipy.interpolate import CubicSpline


class Background:
    def __init__(self, case, representation):
        self.case = case
        self.configuration = read(ROOT / 'frozen-background.json')['cases'][case]
        source = ROOT / (case + '-frozen-source.npz')
        require(digest(source) == self.configuration['frozen_sha256'], 'frozen background source')
        with np.load(source, allow_pickle=False) as packet:
            self.data = {key: packet[key].copy() for key in packet.files}
        self.efold = self.data['efold']
        selected = np.arange(len(self.efold)) if representation == 'fine' else self.data['coarse_indices']
        self.rest = CubicSpline(self.efold[selected], np.log(self.data['rest'][selected]), bc_type='natural')
        self.field0 = self.configuration['initial_field']
        self.j0 = self.configuration['initial_j']
        self.mass = self.configuration['mass']
        self.normalization = np.array([self.field0, abs(self.j0)])

    def equation(self, efold, state):
        scale = math.exp(efold)
        offset = state[0] * self.normalization[0]
        momentum = state[1] * self.normalization[1]
        field = self.field0 + offset
        velocity = scale**3 * momentum
        rest = math.exp(float(self.rest(efold)))
        hubble = math.sqrt((rest + (velocity**2 + (scale * self.mass * field)**2) / 2) / 3)
        return np.array([scale**3 * momentum / hubble, -5 * momentum - self.mass**2 * field / (scale * hubble)]) / self.normalization

    def readout(self, efold, state):
        scale = np.exp(efold)
        offset = state[:, 0] * self.normalization[0]
        momentum = state[:, 1] * self.normalization[1]
        field = self.field0 + offset
        velocity = scale**3 * momentum
        rest = np.exp(self.rest(efold))
        kinetic = velocity**2 / 2
        potential = (scale * self.mass * field)**2 / 2
        rho, pressure = kinetic + potential, kinetic - potential
        hubble = np.sqrt((rest + rho) / 3)
        return dict(efold=efold, scale=scale, offset=offset, j=momentum, phi=field, v=velocity, H=hubble, rest=rest, rho=rho, pressure=pressure, expansion2=(hubble / (scale * UNIT))**2)


def integrate(model, substeps):
    state = np.array([0., np.sign(model.j0)])
    history = np.empty((len(model.efold), 2))
    history[0] = state
    for index in range(len(model.efold) - 1):
        if index % 256 == 0:
            guard()
        left, right = model.efold[index:index + 2]
        step = (right - left) / substeps
        for inner in range(substeps):
            efold = left + step * inner
            first = model.equation(efold, state)
            second = model.equation(efold + step / 2, state + step * first / 2)
            third = model.equation(efold + step / 2, state + step * second / 2)
            fourth = model.equation(efold + step, state + step * third)
            state += step * (first + 2 * second + 2 * third + fourth) / 6
        history[index + 1] = state
    require(np.isfinite(history).all(), 'finite full background')
    return history
