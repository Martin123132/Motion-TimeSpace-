from background_support import *
import numpy as np


def main():
    with worker('prepare'):
        inputs = preserved()
        fit_path = BRANCH / 'cosmology-reconnection-20261006/results/comparison/status.json'
        fit = next(row for row in read(fit_path)['fits'] if row['model'] == 'ParentScalar_Lambda_zero')
        omega_m = float(fit['parameters']['Omega_m'])
        old_status_path = EARLY / 'runs/backgrounds/status.json'
        old_status = read(old_status_path)
        require(old_status['state'] == 'complete', 'retained background completed')
        replay = read(PREVIOUS / 'frozen-replay.json')
        cases = {}
        for case in ('cold', 'heavy'):
            source = EARLY / ('runs/backgrounds/' + case + '.npz')
            require(digest(source) == old_status['input_hashes'][str(source)], 'original background hash')
            with np.load(source, allow_pickle=False) as table:
                efold, scale, field, velocity, expansion = [table[key].copy() for key in ('efold', 'scale', 'phi_s', 'phidot_s', 'expansion2')]
                mass = float(table['slow_mass_mpc'])
                old_hubble = scale * UNIT * np.sqrt(expansion)
                rho = (velocity**2 + (scale * mass * field)**2) / 2
                rest = 3 * old_hubble**2 - rho
                require(np.all(np.isfinite(rest)) and np.all(rest > 0), 'positive retained rest energy')
                require(abs(scale[0] / 1e-9 - 1) < ALGEBRA and abs(efold[-1]) < ALGEBRA, 'retained full range')
                initial_j = velocity[0] / scale[0]**3
                initial_a_h = scale[0] * old_hubble[0]
                seed = -mass**2 * field[0] / (5 * initial_a_h)
                seed_difference = abs(initial_j / seed - 1)
                require(seed_difference < ALGEBRA, 'retained leading regular seed')
                scalar_energy = float(rho[0])
                heavy_ratio = 0.
                if case == 'heavy':
                    heavy_mass = float(table['heavy_mass_mpc'])
                    scalar_energy += (float(table['phidot_h'][0])**2 + (scale[0] * heavy_mass * float(table['phi_h'][0]))**2) / 2
                    heavy_ratio = float(heavy_mass * scale[0] / old_hubble[0])
                eta = UNIT**2 * omega_m * scale[0] / initial_a_h**2 + 2 * scale[0]**2 * scalar_energy / (3 * initial_a_h**2)
                require(0 < eta < 1e-3 and heavy_ratio < 1e-3, 'regular radiation bootstrap regime')
                lower_a_h2 = initial_a_h**2 * (1 - eta)
                delta = mass**2 * scale[0]**4 / (20 * lower_a_h2)
                seed_relative_bound = float(np.expm1(-.5 * np.log1p(-eta) - np.log1p(-delta)))
                guards = []
                for edge in (.00028, .0003, .0004):
                    index = int(np.argmin(abs(scale - edge)))
                    guards.extend(range(max(0, index - 2), min(len(scale), index + 3)))
                coarse = np.unique(np.r_[np.arange(0, len(scale), 2), len(scale) - 1, guards])
                np.savez_compressed(ROOT / (case + '-frozen-source.npz'), efold=efold, scale=scale, rest=rest, old_phi=field, old_v=velocity, old_H=old_hubble, old_expansion2=expansion, coarse_indices=coarse)
                cases[case] = dict(source=str(source), source_sha256=digest(source), frozen_sha256=digest(ROOT / (case + '-frozen-source.npz')), nodes=len(scale), coarse_nodes=len(coarse), initial_scale=float(scale[0]), initial_field=float(field[0]), initial_velocity=float(velocity[0]), initial_j=float(initial_j), mass=mass, fraction=float(table['fraction']), matching_scale_range=replay['cases'][case]['scale_range'], seed_difference=float(seed_difference), radiation_remainder=dict(eta_nonradiation_allowance=float(eta), A_initial=float(initial_a_h), A_lower=float(np.sqrt(lower_a_h2)), scalar_bootstrap_delta=float(delta), relative_j_bound=seed_relative_bound, heavy_mass_over_physical_H=heavy_ratio, conditional=True))
                inputs[str(source)] = digest(source)
        extras = [fit_path, old_status_path, EARLY / 'prepare_backgrounds.py', BRANCH / 'radiation-and-slow-field-transfer-20261007/radiation_common.py', ROOT / 'PROTOCOL.md', ROOT / 'DERIVATION.md', ROOT / 'prepare_background.py', ROOT / 'background_support.py']
        inputs.update({str(path): digest(path) for path in extras})
        write('frozen-inputs.json', inputs)
        write('frozen-background.json', dict(passed=True, cases=cases, inherited_Omega_m=omega_m, unit=UNIT, H0_km_s_Mpc=70., variants=['fine1', 'fine2', 'coarse2'], gate=GATE, algebra=ALGEBRA, present_refit=False, source_hashes=inputs))
        print(json.dumps(dict(passed=True, cases=cases, sources=len(inputs))), flush=True)


if __name__ == '__main__':
    main()
