from background_support import *
import argparse
import numpy as np
import check_background as background
import check_native_replay as replay
import check_native_slopes as slopes


def owned_exits(except_name):
    rows = []
    for path in sorted(ROOT.glob('*-start.json')):
        name = path.name.removesuffix('-start.json')
        if name == except_name:
            continue
        identity = read(path)
        receipt = read(ROOT / (name + '-end.json'))
        expected_state = 'failed' if name == 'native-cold-candidate-tol12' else 'completed'
        require(receipt['state'] == expected_state, 'honest worker status ' + name)
        require(all(identity[key] == receipt[key] for key in ('pid', 'created', 'command')), 'worker identity ' + name)
        outcome = exited(identity)
        require(outcome['exited'], 'worker exit ' + name)
        rows.append(dict(name=name, identity=identity, state=receipt['state'], outcome=outcome))
    return rows


def merge(inputs, addition):
    for path, checksum in addition.items():
        require(path not in inputs or inputs[path] == checksum, 'consistent source ownership ' + path)
        inputs[path] = checksum


def validate():
    with worker('validate'):
        inputs = read(ROOT / 'frozen-inputs.json')
        for path in sorted(ROOT.glob('*-result.json')):
            report = read(path)
            merge(inputs, report.get('source_hashes', {}))
        for path in ROOT.glob('native-*-frozen.json'):
            merge(inputs, read(path))
        check_hashes(inputs)
        comparisons = 0
        accepted = read(ROOT / 'background-check-result.json')
        require(accepted['passed'] and not accepted['native_validated'] and not accepted['old_tables_modified'], 'background status distinct from native')
        require(background.prove() == accepted['identities'], 'six symbolic checks reproduced')
        for case in ('cold', 'heavy'):
            model = background.Background(case, 'fine')
            fine1, report1 = background.load(case, 'fine1')
            fine2, report2 = background.load(case, 'fine2')
            coarse, report3 = background.load(case, 'coarse2')
            lower, upper = model.configuration['matching_scale_range']
            matching = (fine2['scale'] >= lower) & (fine2['scale'] <= upper)
            require(background.compare(fine1, fine2, matching) == accepted['cases'][case]['step_refinement'], 'background step refinement reproduced')
            require(background.compare(coarse, fine2, matching) == accepted['cases'][case]['rest_interpolation'], 'background source refinement reproduced')
            comparisons += 10
            for order, recorded in zip((4, 8), accepted['cases'][case]['quadrature']):
                checked, momentum, offset = background.integral_check(model, fine2, order)
                require(checked == recorded, 'independent background integral reproduced')
                with np.load(ROOT / (case + '-integral-check.npz'), allow_pickle=False) as packet:
                    require(np.array_equal(momentum, packet['j' + str(order)]) and np.array_equal(offset, packet['offset' + str(order)]), 'background integral arrays')
                comparisons += 2
            require(digest(ROOT / (case + '-candidate-background.npz')) == accepted['cases'][case]['candidate_sha256'], 'candidate table hash')
            with np.load(ROOT / (case + '-candidate-background.npz'), allow_pickle=False) as candidate, np.load(model.configuration['source'], allow_pickle=False) as original:
                require(set(candidate.files) == set(original.files), 'original table schema')
                for name in original.files:
                    reference = {'phi_s': fine2['phi'], 'phidot_s': fine2['v'], 'expansion2': fine2['expansion2']}.get(name, original[name])
                    require(np.array_equal(candidate[name], reference), 'only the declared candidate columns changed ' + name)
        native = read(ROOT / 'native-replay-result.json')
        slope = read(ROOT / 'native-slope-result.json')
        tolerance = read(ROOT / 'native-tolerance-result.json')
        require(not native['candidate_pair_passed'] and not slope['candidate_pair_passed'] and not tolerance['any_paired_refinement_passed'], 'failed physical gates retained')
        groups = [('original', native), ('slope', slope), ('tolerance', tolerance)]
        for group, report in groups:
            for label, case_report in report['cases'].items():
                case = label.split('-')[0]
                outputs = {}
                for variant, run in case_report['runs'].items():
                    representation = 'coarse' if variant == 'coarse4' else 'fine'
                    context = slopes.SlopeReplay(case, representation) if group == 'slope' else replay.NativeReplay(case, label[len(case) + 1:], representation)
                    filename = ('slope-replay-' if group == 'slope' else 'replay-') + label + '-' + variant + '.npz'
                    path = ROOT / filename
                    require(digest(path) == run['packet_sha256'], 'canonical replay hash ' + filename)
                    with np.load(path, allow_pickle=False) as packet:
                        require(all(np.isfinite(packet[name]).all() for name in packet.files), 'finite canonical packet')
                        observed = context.observe(packet['state'])
                        for name, recorded in run['checks'].items():
                            require(np.array_equal(observed[name], packet[name]), 'state readout reproduced ' + filename + name)
                            require(replay.retained.difference(packet[name], context.data[name][context.target]) == recorded, 'replay comparison reproduced ' + filename + name)
                            comparisons += 1
                        outputs[variant] = {name: packet[name].copy() for name in observed}
                    require(run['passed'] == all(row['passed'] for row in run['checks'].values()), 'honest run pass')
                    if group == 'slope':
                        require(context.slope_checks == run['slope_checks'], 'native slope checks reproduced')
                refinement = case_report['step_refinement'] if group == 'original' else case_report['refinement']
                for name, recorded in refinement.items():
                    require(replay.retained.difference(outputs['fine2'][name], outputs['fine4'][name]) == recorded, 'refinement reproduced')
                    comparisons += 1
                for name, recorded in case_report['history_sensitivity'].items():
                    require(replay.retained.difference(outputs['coarse4'][name], outputs['fine4'][name]) == recorded, 'history sensitivity reproduced')
                    comparisons += 1
        metric = read(ROOT / 'metric-integral-result.json')
        for case, report in metric['cases'].items():
            path = ROOT / (case + '-metric-integrals.npz')
            require(digest(path) == report['packet_sha256'], 'metric diagnostic packet')
            with np.load(path, allow_pickle=False) as packet:
                for order, checks in report['orders'].items():
                    for name, recorded in checks.items():
                        require(replay.retained.difference(packet[name + order], packet[name + '_reference']) == recorded, 'metric integral comparison reproduced')
                        comparisons += 1
        require(not list(ROOT.rglob('__pycache__')), 'no generated bytecode')
        compiled = []
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
            compiled.append(path.name)
        require(not any(ROOT.glob('native-*-tol24*')), 'cancelled excessive boost24 not run')
        require(not (ROOT / 'native-cold-candidate-tol12.npz').exists(), 'no failed packet promoted')
        workers = owned_exits('validate')
        write('validation.json', dict(implementation_validated=True, regular_background_passed=True, candidate_canonical_replay_passed=False, original_failed_replays_preserved=True, independent_comparisons=comparisons, exact_background_identities=6, input_hashes=inputs, compiled_scripts=compiled, workers=workers, numerical_gate=GATE, algebra_gate=ALGEBRA, full_state_restart_saved=False, full_hierarchy_independently_recoupled=False, documented_failed_workers=['native-cold-candidate-tol12'], warnings_not_promoted_to_convergence=True))
        print(json.dumps(dict(validated=True, background_passed=True, canonical_replay_passed=False, comparisons=comparisons, sources=len(inputs), workers=len(workers))), flush=True)


def seal():
    with worker('seal'):
        report = read(ROOT / 'validation.json')
        require(report['implementation_validated'] and report['regular_background_passed'] and not report['candidate_canonical_replay_passed'], 'separate acceptance states')
        check_hashes(report['input_hashes'])
        workers = owned_exits('seal')
        artifacts = {path.name: dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file()}
        require('closeout.json' not in artifacts, 'new seal only')
        write('closeout.json', dict(implementation_validated=True, regular_background_passed=True, candidate_canonical_replay_passed=False, original_failures_preserved=True, state='regular slow background repaired; remaining native metric residual isolated', utc=datetime.now(timezone.utc).isoformat(), artifacts=artifacts, input_hashes=report['input_hashes'], prior_seal=EXPECTED, workers=workers, next_file='NEXT.md', full_state_restart_saved=False))
        print(json.dumps(dict(seal_sha256=digest(ROOT / 'closeout.json'), artifacts=len(artifacts), sources=len(report['input_hashes']))), flush=True)


def verify(expected):
    with worker('postseal') as identity:
        require(expected is not None and digest(ROOT / 'closeout.json') == expected, 'expected seal digest')
        report = read(ROOT / 'closeout.json')
        check_hashes(report['input_hashes'])
        for name, artifact in report['artifacts'].items():
            path = ROOT / name
            require(path.stat().st_size == artifact['bytes'] and digest(path) == artifact['sha256'], 'sealed artifact ' + name)
        workers = owned_exits('postseal')
        extras = {path.name for path in ROOT.iterdir()} - set(report['artifacts'])
        require(extras == {'closeout.json', 'seal-end.json', 'postseal-start.json'}, 'only expected postseal files')
        write('CLEANUP-VERIFIED.json', dict(passed=True, seal_sha256=expected, workers=workers, verifier_identity=identity, verifier_exit_requires_exec_completion=True, continuing_job_authorized=False, processes_killed=[], temporary_apps_started=[], note='Documented failed worker exited. No shared service or other chat touched. Final verifier exit follows command completion.'))
        print(json.dumps(dict(passed=True, regular_background_passed=True, canonical_replay_passed=False, sources=len(report['input_hashes']), artifacts=len(report['artifacts']), prior_workers_exited=len(workers), verifier_pid=identity['pid'])), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('validate', 'seal', 'verify'))
    parser.add_argument('--expected')
    args = parser.parse_args()
    if args.mode == 'validate':
        validate()
    elif args.mode == 'seal':
        seal()
    else:
        verify(args.expected)
