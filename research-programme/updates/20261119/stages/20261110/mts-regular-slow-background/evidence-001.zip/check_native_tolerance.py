from check_native_replay import *


def main():
    with worker('native-tolerance-check'):
        reports = {}
        for case in ('cold', 'heavy'):
            for factor in (2, 4):
                table = 'candidate-tight' + str(factor)
                label = case + '-' + table
                outputs, runs = {}, {}
                for variant in ('fine2', 'fine4', 'coarse4'):
                    context = NativeReplay(case, table, 'coarse' if variant == 'coarse4' else 'fine')
                    state = retained.advance(context, int(variant[-1]))
                    observables = context.observe(state)
                    checks = {name: retained.difference(value, context.data[name][context.target]) for name, value in observables.items()}
                    destination = ROOT / ('replay-' + label + '-' + variant + '.npz')
                    np.savez_compressed(destination, clock=context.clock, state=state, **observables)
                    outputs[variant] = observables
                    runs[variant] = dict(passed=all(row['passed'] for row in checks.values()), checks=checks, packet_sha256=digest(destination))
                step = {name: retained.difference(outputs['fine2'][name], value) for name, value in outputs['fine4'].items()}
                history = {name: retained.difference(outputs['coarse4'][name], value) for name, value in outputs['fine4'].items()}
                prior = NativeReplay(case, 'candidate' if factor == 2 else 'candidate-tight2', 'fine')
                require(np.array_equal(context.clock, prior.clock), 'identical requested conformal clock')
                change = {name: retained.difference(prior.data[name][prior.target], context.data[name][context.target]) for name in outputs['fine4']}
                passed = all(row['passed'] for row in runs.values()) and all(row['passed'] for row in list(step.values()) + list(history.values()))
                reports[label] = dict(passed=passed, runs=runs, refinement=step, history_sensitivity=history, native_reference_change=change)
                print(json.dumps(dict(case=case, factor=factor, passed=passed, worst=max(row['normalized'] for row in runs['fine4']['checks'].values()), slow_field_error=runs['fine4']['checks']['s_u']['normalized'], slow_field_reference_change=change['s_u']['normalized'])), flush=True)
        files = [Path(__file__), ROOT / 'check_native_replay.py', ROOT / 'ACCURACY-FAILURE-AND-REVISION.md', ROOT / 'run_native_half_tolerance.py']
        write('native-tolerance-result.json', dict(completed=True, cases=reports, any_paired_refinement_passed=any(all(reports[case + '-candidate-tight' + str(factor)]['passed'] for case in ('cold', 'heavy')) for factor in (2, 4)), numerical_gate=GATE, source_hashes={str(path): digest(path) for path in files}, failed_boost12_preserved=True, original_results_preserved=True))


if __name__ == '__main__':
    main()
