from check_native_replay import *

diagnostic_spec = importlib.util.spec_from_file_location('retained_defect', PREVIOUS / 'diagnose_defect.py')
diagnostic = importlib.util.module_from_spec(diagnostic_spec)
diagnostic_spec.loader.exec_module(diagnostic)


def main():
    with worker('native-residual-diagnosis'):
        proof = diagnostic.prove_ports()
        reports = {}
        for case in ('cold', 'heavy'):
            context = NativeReplay(case, 'candidate', 'fine')
            scale, hubble, potential, lapse = context.geometry(context.clock)
            field, velocity, mass2 = context.background(context.clock, 's')
            field_function, velocity_function = context.field_functions['s']
            defect = velocity_function(np.log(scale), 1) * hubble + 2 * hubble * velocity + mass2 * field
            with np.load(ROOT / (case + '-candidate-background.npz'), allow_pickle=False) as table:
                old_hubble = CubicSpline(table['efold'], np.log(np.exp(table['efold']) * UNIT * np.sqrt(table['expansion2'])), bc_type='natural')(np.log(scale))
            background_hubble = np.exp(old_hubble)
            expansion_difference = hubble / background_hubble - 1
            with np.load(ROOT / ('replay-' + case + '-candidate-fine4.npz'), allow_pickle=False) as saved:
                original = saved['state'].copy()
            prediction = diagnostic.response(context, 4)
            checks = {}
            for label, contribution in [('background', prediction[:, :, 0, :]), ('metric', prediction[:, :, 1, :]), ('sum', prediction.sum(axis=2))]:
                amended = original.copy()
                amended[:, 2:] += contribution.reshape(len(context.clock), -1)
                checks[label] = {name: retained.difference(values, context.data[name][context.target]) for name, values in context.observe(amended).items()}
            destination = ROOT / (case + '-native-residual-diagnosis.npz')
            np.savez_compressed(destination, clock=context.clock, background_defect=defect, expansion_difference=expansion_difference, response=prediction)
            reports[case] = dict(responses=checks, expansion_relative_max=float(np.max(abs(expansion_difference))), expansion_relative_start=float(expansion_difference[0]), expansion_relative_end=float(expansion_difference[-1]), slow_background_defect_relative=float(np.max(abs(defect)) / np.max(abs(mass2 * field))), packet_sha256=digest(destination))
            print(json.dumps(dict(case=case, expansion_max=reports[case]['expansion_relative_max'], slow_defect=reports[case]['slow_background_defect_relative'], responses={label: {name: row['normalized'] for name, row in values.items() if name in ('s_u', 's_p', 'h_u', 'h_p')} for label, values in checks.items()})), flush=True)
        files = [Path(__file__), ROOT / 'check_native_replay.py', ROOT / 'native-replay-result.json', PREVIOUS / 'diagnose_defect.py']
        write('native-residual-diagnosis-result.json', dict(completed=True, proof=proof, cases=reports, diagnostic_only=True, new_fit=False, accepted_replay_changed=False, source_hashes={str(path): digest(path) for path in files}))


if __name__ == '__main__':
    main()
