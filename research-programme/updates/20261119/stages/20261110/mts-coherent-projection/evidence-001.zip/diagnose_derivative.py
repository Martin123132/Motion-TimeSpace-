from projection_support import *
import numpy as np
from transport_phase import Transport, compare
from verify_projection import derivative_check


def consistent_derivative_check(context, index):
    clock = context.clock[index]
    scale = float(context.scale(clock))
    hubble = float(context.scale(clock, 1)) / scale
    dilation = float(context.dilation(clock))
    independent, physical = [], []
    for suffix, field in context.fields.items():
        field_fun, velocity_fun = context.functions[suffix]
        efold = np.log(scale)
        background_field, background_velocity = float(field_fun(efold)), float(velocity_fun(efold))
        mass2 = (scale * context.masses[suffix])**2
        omega = np.sqrt(1 + mass2)
        chi = hubble * mass2 / (1 + mass2)
        field_prime = hubble * float(field_fun(efold, 1))
        velocity_prime = hubble * float(velocity_fun(efold, 1))
        coordinate, momentum = field['u'][index], field['w'][index]
        background = np.array([background_field, background_velocity / omega])
        background_prime = np.array([field_prime, (velocity_prime - chi * background_velocity) / omega])
        perturbation = np.array([coordinate, momentum / omega])
        perturbation_prime = np.array([momentum, (-2 * hubble * momentum - (1 + mass2) * coordinate - dilation * background_velocity - chi * momentum) / omega])
        physical.append(np.outer(background, perturbation).ravel())
        independent.append((np.outer(background_prime, perturbation) + np.outer(background, perturbation_prime)).ravel())
    physical_state = np.concatenate(physical)
    predicted = context.rhs(clock, physical_state / context.normalization)
    expected = np.concatenate(independent) / context.normalization
    return compare(predicted, expected, ALGEBRA), compare(physical_state / context.normalization, context.reference[index] / context.normalization, ALGEBRA)


def main():
    with worker('derivative-diagnosis'):
        require(read(ROOT / 'validate-end.json')['state'] == 'failed', 'original validation failure preserved')
        hashes = {str(path): digest(path) for path in (Path(__file__), ROOT / 'verify_projection.py', ROOT / 'transport_phase.py', ROOT / 'PHASE-MEMORY-TRANSPORT.md')}
        reports = {}
        with np.load(ROOT / 'frozen-projection.npz', allow_pickle=False) as frozen:
            for case in ('cold', 'heavy'):
                for coarse in (False, True):
                    context = Transport(case, frozen, coarse)
                    label = case + ('-coarse' if coarse else '-fine')
                    reports[label] = []
                    for index in (0, len(context.clock) // 2, len(context.clock) - 1):
                        fixed, state_difference = consistent_derivative_check(context, index)
                        old = derivative_check(context, index)
                        reports[label].append(dict(index=index, original=old, consistent_state=fixed, input_state_mismatch=state_difference))
                    print(json.dumps(dict(label=label, old_max=max(row['original']['normalized'] for row in reports[label]), fixed_max=max(row['consistent_state']['normalized'] for row in reports[label]), state_max=max(row['input_state_mismatch']['normalized'] for row in reports[label]))), flush=True)
        require(all(row['consistent_state']['passed'] for group in reports.values() for row in group), 'same-background algebra identity')
        check_hashes(hashes)
        write('derivative-diagnosis-result.json', dict(passed=True, cases=reports, source_hashes=hashes, physical_evolution_changed=False, tolerances_changed=False, diagnosis='Original derivative verifier used a native-background moment on one side and a coarse-interpolated-background moment on the other. Test the algebra on the same physical background/state; retain the already separate measured history-sensitivity test.'))


if __name__ == '__main__':
    main()
