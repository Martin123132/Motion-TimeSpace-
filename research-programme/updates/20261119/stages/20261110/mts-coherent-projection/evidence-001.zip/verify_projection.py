from projection_support import *
import argparse
import numpy as np
from freeze_projection import basis
from project_sources import case_history, evaluate_gauge, virial_prediction, algebra
from transport_phase import Transport, compare
from prove_transport import prove


def owned_exits(except_name):
    rows = []
    for path in sorted(ROOT.glob('*-start.json')):
        name = path.name.removesuffix('-start.json')
        if name == except_name:
            continue
        identity = read(path)
        end = read(ROOT / (name + '-end.json'))
        require(end['state'] == 'completed', 'completed execution ' + name)
        require(all(end[key] == identity[key] for key in ('pid', 'created', 'command')), 'exact worker identity')
        outcome = exited(identity)
        require(outcome['exited'], 'worker exited ' + name)
        rows.append(dict(name=name, identity=identity, state=end['state'], outcome=outcome))
    return rows


def merge(inputs, addition):
    for path, checksum in addition.items():
        require(path not in inputs or inputs[path] == checksum, 'consistent provenance ' + path)
        inputs[path] = checksum


def derivative_check(context, index):
    clock = context.clock[index]
    scale = float(context.scale(clock))
    hubble = float(context.scale(clock, 1)) / scale
    dilation = float(context.dilation(clock))
    independent = []
    for suffix, field in context.fields.items():
        field_fun, velocity_fun = context.functions[suffix]
        efold = np.log(scale)
        background_field, background_velocity = float(field_fun(efold)), float(velocity_fun(efold))
        mass2 = (scale * context.masses[suffix])**2
        omega = np.sqrt(1 + mass2)
        chi = hubble * mass2 / (1 + mass2)
        field_prime, velocity_prime = hubble * float(field_fun(efold, 1)), hubble * float(velocity_fun(efold, 1))
        coordinate, momentum = field['u'][index], field['w'][index]
        background = np.array([background_field, background_velocity / omega])
        background_prime = np.array([field_prime, (velocity_prime - chi * background_velocity) / omega])
        perturbation = np.array([coordinate, momentum / omega])
        perturbation_prime = np.array([momentum, (-2 * hubble * momentum - (1 + mass2) * coordinate - dilation * background_velocity - chi * momentum) / omega])
        independent.append((np.outer(background_prime, perturbation) + np.outer(background, perturbation_prime)).ravel())
    predicted = context.rhs(clock, context.reference[index] / context.normalization)
    expected = np.concatenate(independent) / context.normalization
    return compare(predicted, expected, ALGEBRA)


def validate():
    with worker('validate'):
        inputs = read(ROOT / 'frozen-inputs.json')
        for path in ROOT.glob('*-result.json'):
            merge(inputs, read(path).get('source_hashes', {}))
        merge(inputs, read(ROOT / 'frozen-projection.json')['source_hashes'])
        check_hashes(inputs)
        proof = prove()
        require(proof == read(ROOT / 'symbolic-result.json')['checks'], 'independent symbolic rerun')
        frozen_report = read(ROOT / 'frozen-projection.json')
        source_report = read(ROOT / 'projection-result.json')
        transport_report = read(ROOT / 'phase-transport-result.json')
        require(digest(ROOT / 'frozen-projection.npz') == frozen_report['packet_sha256'], 'same frozen operator')
        comparisons, conditioning, transport_summary = 0, {}, {}
        with np.load(ROOT / 'frozen-projection.npz', allow_pickle=False) as frozen:
            selected, weights = frozen['selected'], frozen['weights']
            regenerated = basis(frozen['original_phase'][selected], float(frozen['phase_middle']))
            require(np.array_equal(regenerated, frozen['design']), 'same original basis')
            require(np.array_equal(np.linalg.pinv(regenerated)[0], weights), 'same original weights')
            require(np.count_nonzero(weights < 0) == 429, 'signed extraction not positive ensemble')
            negative_example = np.zeros(len(weights))
            negative_example[np.argmin(weights)] = 1
            require(weights @ negative_example < 0, 'nonnegative history need not have positive extraction')
            for case in ('cold', 'heavy'):
                result = source_report['cases'][case]
                data, fields, full_clock = case_history(case, frozen)
                path = ROOT / (case + '-projected-sources.npz')
                require(digest(path) == result['packet_sha256'], 'projection packet integrity')
                with np.load(path, allow_pickle=False) as packet:
                    for name, values in data.items():
                        require(np.array_equal(packet[name], values), 'source data regenerated ' + name)
                    for suffix, field in fields.items():
                        for name, values in field.items():
                            require(np.array_equal(packet[suffix + '_' + name], values), 'field source regenerated')
                        gauge = evaluate_gauge(data, field, weights, suffix == 'cdm')
                        require(gauge == result['gauge'][suffix], 'gauge product corrections independently recomputed')
                        require(all(row['passed'] for row in gauge['checks'].values()), 'corrected gauge conversion passes')
                        comparisons += len(gauge['checks'])
                        if suffix != 'cdm':
                            for stride in (1, 2):
                                recalculated, arrays = virial_prediction(data, field, full_clock, frozen, stride)
                                for key, value in recalculated.items():
                                    require(value == result['virial'][suffix][str(stride)][key], 'virial prediction reproduced ' + key)
                                for name, values in arrays.items():
                                    require(np.array_equal(values, packet[suffix + '_virial' + str(stride) + '_' + name]), 'virial derivative packet')
                                comparisons += 1
                    beta, hubble = data['beta'], data['H']
                    project = lambda value: float(weights @ value)
                    normalization = float(frozen['density0'] / frozen['center'])
                    raw = -normalization * (project(beta * data['Dtotal']) + 3 * project(hubble) * project(beta * data['Qtotal'])) / 2
                    actual = normalization * project(beta * data['Phi'])
                    correction = -1.5 * normalization * (project(beta * data['Qtotal'] * hubble) - project(beta * data['Qtotal']) * project(hubble))
                    require(actual == result['metric']['actual'] and raw == result['metric']['naive'] and correction == result['metric']['correction'], 'metric source projection')
                    require(algebra(actual, raw + correction, [actual, raw, correction]) == result['metric']['check'], 'metric commutator identity')
                    comparisons += 1
                    if case == 'heavy':
                        pressure = float(weights @ (beta * fields['h']['Ps']))
                        density = float(weights @ (beta * fields['h']['Ds']))
                        current = float(weights @ (beta * fields['h']['Qs']))
                        prediction = float(frozen['sound2']) * (density + 3 * project(hubble) * current)
                        normalized = abs(pressure - prediction) / float(frozen['original_norm'])
                        require(normalized == result['legacy_pressure']['error_over_original_norm'] and normalized <= PRESSURE_GATE, 'unchanged legacy pressure gate')
                        for name, values in [('density', beta * fields['h']['Ds']), ('current', beta * fields['h']['Qs']), ('pressure', beta * fields['h']['Ps'])]:
                            coefficients = frozen['inverse'] @ values
                            require(np.array_equal(coefficients, packet[name + '_coefficients']), 'unmodified harmonic decomposition')
                            require(abs(coefficients[0] - weights @ values) <= ALGEBRA * np.max(abs(values)), 'secular extraction')
                            comparisons += 1
                slow = result['virial']['s']['1']
                conditioning[case] = dict(slow_virial_pressure_gate_passed=slow['pressure_relative_error'] <= GATE, slow_virial_pressure_relative_error=slow['pressure_relative_error'], slow_virial_absolute_error=slow['absolute_error'], slow_virial_source_term_cancellation=sum(abs(value) for value in slow['contributions'].values()) / abs(slow['actual']))
                require(not conditioning[case]['slow_virial_pressure_gate_passed'], 'preserve actual slow-field virial failure')
                outputs, runs, component_constraints, derivative_checks = {}, {}, {}, {}
                for variant, run in transport_report['cases'][case]['runs'].items():
                    context = Transport(case, frozen, variant == 'coarse4')
                    path = ROOT / (case + '-phase-' + variant + '.npz')
                    require(digest(path) == run['packet_sha256'], 'phase packet integrity')
                    with np.load(path, allow_pickle=False) as packet:
                        require(np.array_equal(packet['clock'], context.clock) and np.array_equal(packet['reference'], context.reference), 'original source/physical epochs')
                        require(np.array_equal(packet['state'][0], context.reference[0]), 'physical phase seed, not fitted')
                        observed = context.observe(packet['state'])
                        for name, values in observed.items():
                            require(np.array_equal(values, packet[name]), 'phase readout regeneration')
                        projected, checks, physical = {}, {}, {}
                        entry_constraints = {}
                        for suffix, field in context.fields.items():
                            for label, source in [('D', 'Ds'), ('P', 'Ps'), ('Q', 'Qs'), ('u', 'u'), ('w', 'w')]:
                                calculated = compare(observed[suffix + '_' + label], field[source])
                                require(calculated == run['checks'][suffix + '_' + label], 'phase source comparison recomputed')
                                checks[suffix + '_' + label] = calculated
                                comparisons += 1
                            transverse = observed[suffix + '_transverse']
                            moment = context.references[suffix]['moment']
                            peak = float(np.max(abs(moment)))
                            absolute = float(np.max(abs(transverse)))
                            physical[suffix] = dict(passed=absolute / peak <= GATE, absolute_error=absolute, reference_peak=peak, normalized=absolute / peak, tolerance=GATE)
                            require(physical[suffix] == run['physicality'][suffix], 'physical-subspace check reproduced')
                            ratios = np.max(abs(transverse), axis=0) / np.max(abs(moment), axis=0)
                            require(np.isfinite(ratios).all() and np.max(ratios) <= GATE, 'stronger per-entry physical-subspace bound')
                            entry_constraints[suffix] = ratios.tolist()
                            expected = float(weights @ (context.data['beta'] * field['Ps']))
                            prediction = float(weights @ (context.data['beta'] * observed[suffix + '_P']))
                            require(expected == run['projected_pressure'][suffix]['actual'] and prediction == run['projected_pressure'][suffix]['prediction'], 'pressure prediction recomputed')
                            passed = abs(prediction - expected) <= (PRESSURE_GATE * float(frozen['original_norm']) if suffix == 'h' else GATE * abs(expected))
                            require(passed and passed == run['projected_pressure'][suffix]['passed'], 'unchanged pressure gate')
                            projected[suffix] = run['projected_pressure'][suffix]
                            comparisons += 2
                        require(all(row['passed'] for row in checks.values()) and all(row['passed'] for row in physical.values()) and run['passed'], 'paired phase transport accepted')
                        outputs[variant] = observed
                        runs[variant] = dict(worst_source=max(row['normalized'] for row in checks.values()), projected_pressure=projected)
                        component_constraints[variant] = entry_constraints
                    derivative_checks[variant] = [derivative_check(context, index) for index in (0, len(context.clock) // 2, len(context.clock) - 1)]
                    require(all(row['passed'] for row in derivative_checks[variant]), 'native-equation/outer-product derivative equality')
                    comparisons += 3
                for name, variant in [('step', 'fine2'), ('history', 'coarse4')]:
                    for key, row in transport_report['cases'][case]['refinement'][name].items():
                        require(compare(outputs[variant][key], outputs['fine4'][key]) == row and row['passed'], 'phase step/history refinement')
                        comparisons += 1
                transport_summary[case] = dict(passed=True, runs=runs, per_entry_physical_subspace=component_constraints, derivative_checks=derivative_checks)
        require(transport_report['passed'] and source_report['algebra_passed'], 'separate scientific outcomes')
        require(not list(ROOT.rglob('__pycache__')), 'no bytecode generated')
        compiled = []
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
            compiled.append(path.name)
        workers = owned_exits('validate')
        write('validation.json', dict(implementation_validated=True, fixed_projection_reproduced=True, gauge_metric_commutators_validated=True, legacy_heavy_pressure_gate_passed=True, heavy_virial_pressure_gate_passed=True, paired_virial_prediction_passed=False, paired_phase_transport_passed=True, forced_history=True, new_coupled_phase_transport=False, independently_recomputed_comparisons=comparisons, symbolic_identities=len(proof), conditioning=conditioning, transport=transport_summary, input_hashes=inputs, workers=workers, compiled_scripts=compiled, numerical_gate=GATE, algebra_gate=ALGEBRA, legacy_pressure_gate=PRESSURE_GATE))
        print(json.dumps(dict(validated=True, comparisons=comparisons, identities=len(proof), sources=len(inputs), workers=len(workers), paired_phase_transport_passed=True, paired_virial_prediction_passed=False)), flush=True)


def seal():
    with worker('seal'):
        validation = read(ROOT / 'validation.json')
        require(validation['implementation_validated'] and validation['paired_phase_transport_passed'] and not validation['paired_virial_prediction_passed'], 'distinct preserved outcomes')
        check_hashes(validation['input_hashes'])
        workers = owned_exits('seal')
        artifacts = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file()}
        require('closeout.json' not in artifacts, 'new stage only')
        write('closeout.json', dict(implementation_validated=True, paired_phase_transport_passed=True, paired_virial_prediction_passed=False, heavy_virial_pressure_gate_passed=True, fixed_projection_reproduced=True, gauge_metric_commutators_validated=True, forced_history=True, new_coupled_phase_transport=False, state='Derived phase-stress transport preserves pressure and coherent state on saved native histories', utc=datetime.now(timezone.utc).isoformat(), prior_seal=EXPECTED, artifacts=artifacts, input_hashes=validation['input_hashes'], workers=workers, next_file='NEXT.md'))
        print(json.dumps(dict(seal_sha256=digest(ROOT / 'closeout.json'), artifacts=len(artifacts), sources=len(validation['input_hashes']))), flush=True)


def verify(expected):
    with worker('postseal') as identity:
        require(expected and digest(ROOT / 'closeout.json') == expected, 'expected closeout')
        report = read(ROOT / 'closeout.json')
        check_hashes(report['input_hashes'])
        for name, row in report['artifacts'].items():
            path = ROOT / name
            require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'sealed artifact ' + name)
        workers = owned_exits('postseal')
        extras = {str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if path.is_file()} - set(report['artifacts'])
        require(extras == {'closeout.json', 'seal-end.json', 'postseal-start.json'}, 'expected postseal files')
        write('CLEANUP-VERIFIED.json', dict(passed=True, seal_sha256=expected, workers=workers, verifier_identity=identity, verifier_exit_requires_exec_completion=True, continuing_job_authorized=False, processes_killed=[], temporary_apps_started=[], no_native_build=True, no_drive_mapping=True, note='All task-owned numerical workers have exited; final verifier exit requires command completion. No shared services or other chats changed.'))
        print(json.dumps(dict(passed=True, sources=len(report['input_hashes']), artifacts=len(report['artifacts']), prior_workers_exited=len(workers), verifier_pid=identity['pid'])), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('validate', 'seal', 'verify'))
    parser.add_argument('--expected')
    args = parser.parse_args()
    if args.mode == 'validate':
        validate()
    elif args.mode == 'seal':
        seal()
    else:
        verify(args.expected)
