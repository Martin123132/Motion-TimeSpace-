from projection_support import *
import sympy as symbolic


def prove():
    scale, hubble, hubble_prime, field, velocity, perturbation, momentum, mass2, wave, dilation, omega, defect_f, defect_b, defect_prime = symbolic.symbols('scale hubble hubble_prime field velocity perturbation momentum mass2 wave dilation omega defect_f defect_b defect_prime', real=True)
    rules = {scale: scale * hubble, hubble: hubble_prime, field: velocity + defect_f, velocity: -2 * hubble * velocity - mass2 * field + defect_b, perturbation: momentum, momentum: -2 * hubble * momentum - (wave**2 + mass2) * perturbation - wave * dilation * velocity, mass2: 2 * hubble * mass2, omega: hubble * mass2 / omega, defect_f: defect_prime}
    def derivative(value):
        return sum(symbolic.diff(value, variable) * rate for variable, rate in rules.items())
    def zero(value):
        numerator = symbolic.together(value).as_numer_denom()[0]
        return symbolic.expand(numerator).subs(omega**2, wave**2 + mass2).expand() == 0 or symbolic.simplify(value.subs(omega, symbolic.sqrt(wave**2 + mass2))) == 0
    displacement = scale * field * perturbation
    pressure = velocity * momentum - mass2 * field * perturbation
    virial = derivative(derivative(displacement)) + (wave**2 - hubble**2 - hubble_prime) * displacement + scale * wave * dilation * field * velocity
    defect = scale * ((defect_b + defect_prime + 2 * hubble * defect_f) * perturbation + 2 * defect_f * momentum)
    checks = dict(virial_with_source_defects=zero(virial - defect - 2 * scale * pressure))
    background = symbolic.Matrix([field, velocity / omega])
    mode = symbolic.Matrix([perturbation, momentum / omega])
    moment = background * mode.T
    norm = (background.T * background)[0]
    chi = hubble * mass2 / omega**2
    background_matrix = symbolic.Matrix([[0, omega], [-mass2 / omega, -2 * hubble - chi]]) + symbolic.Matrix([defect_f, defect_b / omega]) * background.T / norm
    perturbation_matrix = symbolic.Matrix([[0, omega], [-omega, -2 * hubble - chi]])
    forcing = symbolic.Matrix([0, -wave * dilation * background[1]])
    equation = background_matrix * moment + moment * perturbation_matrix.T + background * forcing.T
    for row in range(2):
        checks['background_' + str(row)] = zero(derivative(background[row]) - (background_matrix * background)[row])
        checks['recovery_' + str(row)] = zero((moment.T * background / norm)[row] - mode[row])
        for column in range(2):
            checks['moment_' + str(row) + str(column)] = zero(derivative(moment[row, column]) - equation[row, column])
    checks['density_source'] = zero(omega**2 * moment[1, 1] + mass2 * moment[0, 0] - (velocity * momentum + mass2 * field * perturbation))
    checks['pressure_source'] = zero(omega**2 * moment[1, 1] - mass2 * moment[0, 0] - pressure)
    checks['current_source'] = zero(wave * omega * moment[1, 0] - wave * velocity * perturbation)
    mean_first, mean_second, mean_third, mean_pair, mean_pair_third, mean_triple = symbolic.symbols('mean_first mean_second mean_third mean_pair mean_pair_third mean_triple')
    direct = mean_triple - mean_first * mean_second * mean_third
    split = mean_triple - mean_pair * mean_third + mean_third * (mean_pair - mean_first * mean_second)
    checks['triple_product_commutator'] = symbolic.expand(direct - split) == 0
    require(all(checks.values()), 'all derived pressure/transport identities')
    return checks


def main():
    with worker('symbolic'):
        checks = prove()
        write('symbolic-result.json', dict(passed=True, checks=checks, identities=len(checks), source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'DERIVATION.md', ROOT / 'PHASE-MEMORY-TRANSPORT.md')}))
        print(json.dumps(dict(passed=True, identities=len(checks))), flush=True)


if __name__ == '__main__':
    main()
