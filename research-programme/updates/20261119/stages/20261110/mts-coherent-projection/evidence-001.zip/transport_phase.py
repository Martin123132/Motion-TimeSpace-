from projection_support import *
import numpy as np
from scipy.interpolate import CubicSpline, CubicHermiteSpline
from project_sources import case_history
sys.path.insert(0, str(SOURCE))
from quintic_model import functions as quintic_functions


def compare(actual, reference, tolerance=GATE):
    absolute = float(np.max(abs(actual - reference)))
    peak = float(np.max(abs(reference)))
    return dict(passed=absolute <= tolerance * peak, absolute_error=absolute, reference_peak=peak, normalized=absolute / peak if peak else (0. if absolute == 0 else None), tolerance=tolerance)


class Transport:
    def __init__(self, case, frozen, coarse=False):
        self.data, self.fields, full_clock = case_history(case, frozen)
        self.fields.pop('cdm')
        indices = frozen['selected']
        require(np.all(np.diff(indices) == 1), 'contiguous frozen window')
        guarded = np.arange(indices[0] - 8, indices[-1] + 9)
        with np.load(PREVIOUS / ('early-' + case + '-restart.npz'), allow_pickle=False) as packet:
            observers = dict(zip([str(name) for name in packet['observation_names'][:30]], packet['observer'][guarded].T))
        selected = np.arange(len(guarded))
        if coarse:
            selected = np.unique(np.r_[selected[::2], len(guarded) - 1, 8, len(guarded) - 9])
        self.scale = CubicHermiteSpline(full_clock[guarded][selected], observers['a_native'][selected], (observers['a_native'] * observers['H_native'])[selected])
        dilation = (observers['D_sync'] / 2 + observers['eta_sync']) / observers['H_native']
        self.dilation = CubicSpline(full_clock[guarded][selected], dilation[selected])
        self.clock = self.data['clock']
        self.functions, self.masses = {}, {}
        with np.load(BACKGROUND / (case + '-candidate-background.npz'), allow_pickle=False) as table:
            self.functions['s'] = [CubicSpline(table['efold'], table[name], bc_type='natural') for name in ('phi_s', 'phidot_s')]
            self.masses['s'] = float(table['slow_mass_mpc'])
            if case == 'heavy':
                with np.load(SOURCE / 'heavy-equation-quintic.npz', allow_pickle=False) as packet:
                    self.functions['h'], _ = quintic_functions(packet)
                self.masses['h'] = float(table['heavy_mass_mpc'])
        reference, self.references = [], {}
        self.minimum_background_norm = {}
        for suffix, field in self.fields.items():
            omega = np.sqrt(1 + (self.data['a'] * self.masses[suffix])**2)
            background = np.column_stack([field['b'], field['v'] / omega])
            perturbation = np.column_stack([field['u'], field['w'] / omega])
            moment = background[:, :, None] * perturbation[:, None, :]
            self.references[suffix] = dict(moment=moment, background=background, perturbation=perturbation)
            self.minimum_background_norm[suffix] = float(np.min(np.sum(background**2, axis=1)))
            require(self.minimum_background_norm[suffix] > 0, 'nonzero coherent source norm')
            reference.append(moment.reshape(len(self.clock), 4))
        self.reference = np.concatenate(reference, axis=1)
        self.normalization = np.max(abs(self.reference), axis=0)
        require(np.all(self.normalization > 0), 'componentwise phase normalization')

    def rhs(self, clock, normalized):
        scale = float(self.scale(clock))
        hubble = float(self.scale(clock, 1)) / scale
        dilation = float(self.dilation(clock))
        efold = np.log(scale)
        values = normalized * self.normalization
        derivatives = []
        for index, suffix in enumerate(self.fields):
            field_fun, velocity_fun = self.functions[suffix]
            field, velocity = float(field_fun(efold)), float(velocity_fun(efold))
            field_first, velocity_first = float(field_fun(efold, 1)), float(velocity_fun(efold, 1))
            mass2 = (scale * self.masses[suffix])**2
            omega = np.sqrt(1 + mass2)
            chi = hubble * mass2 / (1 + mass2)
            background = np.array([field, velocity / omega])
            defect = np.array([hubble * field_first - velocity, (hubble * velocity_first + 2 * hubble * velocity + mass2 * field) / omega])
            background_matrix = np.array([[0., omega], [-mass2 / omega, -2 * hubble - chi]]) + np.outer(defect, background) / (background @ background)
            perturbation_matrix = np.array([[0., omega], [-omega, -2 * hubble - chi]])
            force = np.array([0., -dilation * background[1]])
            moment = values[4 * index:4 * index + 4].reshape(2, 2)
            derivatives.append((background_matrix @ moment + moment @ perturbation_matrix.T + np.outer(background, force)).ravel())
        return np.concatenate(derivatives) / self.normalization

    def advance(self, substeps):
        state = np.empty_like(self.reference)
        state[0] = self.reference[0]
        normalized = state[0] / self.normalization
        for index in range(len(self.clock) - 1):
            guard()
            left, right = self.clock[index:index + 2]
            step = (right - left) / substeps
            for inner in range(substeps):
                clock = left + inner * step
                first = self.rhs(clock, normalized)
                second = self.rhs(clock + step / 2, normalized + step * first / 2)
                third = self.rhs(clock + step / 2, normalized + step * second / 2)
                fourth = self.rhs(clock + step, normalized + step * third)
                normalized += step * (first + 2 * second + 2 * third + fourth) / 6
            state[index + 1] = normalized * self.normalization
        require(np.isfinite(state).all(), 'finite phase transport')
        return state

    def observe(self, state):
        observed = {}
        for index, suffix in enumerate(self.fields):
            moment = state[:, 4 * index:4 * index + 4].reshape(-1, 2, 2)
            mass2 = (self.data['a'] * self.masses[suffix])**2
            omega = np.sqrt(1 + mass2)
            observed[suffix + '_D'] = omega**2 * moment[:, 1, 1] + mass2 * moment[:, 0, 0]
            observed[suffix + '_P'] = omega**2 * moment[:, 1, 1] - mass2 * moment[:, 0, 0]
            observed[suffix + '_Q'] = omega * moment[:, 1, 0]
            background = self.references[suffix]['background']
            recovered = np.einsum('tij,ti->tj', moment, background) / np.sum(background**2, axis=1)[:, None]
            observed[suffix + '_u'] = recovered[:, 0]
            observed[suffix + '_w'] = recovered[:, 1] * omega
            transverse = moment - background[:, :, None] * recovered[:, None, :]
            observed[suffix + '_transverse'] = transverse
        return observed


def main():
    with worker('phase-transport'):
        frozen_report = read(ROOT / 'frozen-projection.json')
        require(digest(ROOT / 'frozen-projection.npz') == frozen_report['packet_sha256'], 'original operator unchanged')
        hashes = {str(path): digest(path) for path in (Path(__file__), ROOT / 'projection_support.py', ROOT / 'project_sources.py', ROOT / 'frozen-projection.npz', ROOT / 'PHASE-MEMORY-TRANSPORT.md')}
        reports = {}
        with np.load(ROOT / 'frozen-projection.npz', allow_pickle=False) as frozen:
            for case in ('cold', 'heavy'):
                outputs, runs = {}, {}
                for variant in ('fine2', 'fine4', 'coarse4'):
                    context = Transport(case, frozen, variant == 'coarse4')
                    state = context.advance(int(variant[-1]))
                    observed = context.observe(state)
                    checks, projection, physicality = {}, {}, {}
                    for suffix in context.fields:
                        for output, source in [('D', 'Ds'), ('P', 'Ps'), ('Q', 'Qs'), ('u', 'u'), ('w', 'w')]:
                            checks[suffix + '_' + output] = compare(observed[suffix + '_' + output], context.fields[suffix][source])
                        physicality[suffix] = compare(observed[suffix + '_transverse'], context.references[suffix]['moment'])
                        physicality[suffix]['absolute_error'] = float(np.max(abs(observed[suffix + '_transverse'])))
                        physicality[suffix]['normalized'] = physicality[suffix]['absolute_error'] / physicality[suffix]['reference_peak']
                        physicality[suffix]['passed'] = physicality[suffix]['normalized'] <= GATE
                        actual = float(frozen['weights'] @ (context.data['beta'] * context.fields[suffix]['Ps']))
                        predicted = float(frozen['weights'] @ (context.data['beta'] * observed[suffix + '_P']))
                        projection[suffix] = dict(prediction=predicted, actual=actual, absolute_error=abs(predicted - actual), pressure_relative_error=abs((predicted - actual) / actual) if actual else None)
                        if suffix == 'h':
                            projection[suffix]['error_over_original_norm'] = abs(predicted - actual) / float(frozen['original_norm'])
                            projection[suffix]['passed'] = projection[suffix]['error_over_original_norm'] <= PRESSURE_GATE
                        else:
                            projection[suffix]['passed'] = abs(predicted - actual) <= GATE * abs(actual)
                    passed = all(row['passed'] for row in list(checks.values()) + list(physicality.values()) + list(projection.values()))
                    destination = ROOT / (case + '-phase-' + variant + '.npz')
                    np.savez_compressed(destination, clock=context.clock, state=state, reference=context.reference, **observed)
                    outputs[variant] = observed
                    runs[variant] = dict(passed=passed, checks=checks, physicality=physicality, projected_pressure=projection, minimum_background_norm=context.minimum_background_norm, packet_sha256=digest(destination), initial_state_exact=bool(np.array_equal(state[0], context.reference[0])))
                    print(json.dumps(dict(case=case, variant=variant, passed=passed, failed=[name for name, row in checks.items() if not row['passed']], projected_pressure=projection)), flush=True)
                refinements = {}
                for label, variant in [('step', 'fine2'), ('history', 'coarse4')]:
                    refinements[label] = {name: compare(values, outputs['fine4'][name]) for name, values in outputs[variant].items() if not name.endswith('_transverse')}
                reports[case] = dict(passed=all(row['passed'] for row in runs.values()) and all(row['passed'] for group in refinements.values() for row in group.values()), runs=runs, refinement=refinements)
        check_hashes(hashes)
        write('phase-transport-result.json', dict(completed=True, passed=all(row['passed'] for row in reports.values()), cases=reports, source_hashes=hashes, forced_history=True, new_coupled_native_run=False, fitted_pressure=False, new_physical_degrees_of_freedom=False, original_operator_unchanged=True))


if __name__ == '__main__':
    main()
