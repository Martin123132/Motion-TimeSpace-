from projection_support import *
import numpy as np
from scipy.interpolate import CubicSpline
sys.path.insert(0, str(SOURCE))
from quintic_model import functions as quintic_functions


def algebra(actual, predicted, terms):
    scale = float(sum(abs(term) for term in terms))
    error = float(abs(actual - predicted))
    return dict(passed=error <= ALGEBRA * scale, absolute_error=error, component_sum=scale, normalized=error / scale if scale else (0. if error == 0 else None), tolerance=ALGEBRA)


def case_history(case, frozen):
    path = PREVIOUS / ('early-' + case + '-restart.npz')
    require(digest(path) == read(PREVIOUS / ('early-' + case + '-result.json'))['packet_sha256'], 'verified native full history')
    selected = frozen['selected']
    with np.load(path, allow_pickle=False) as packet:
        require(np.array_equal(packet['requested_scale'], frozen['original_requested_scale']), 'same4253 requested samples')
        observer_names = [str(name) for name in packet['observation_names'][:30]]
        observer = dict(zip(observer_names, packet['observer'][selected].T))
        standard = dict(zip([str(name) for name in packet['standard_names']], packet['standard'][selected].T))
        full_clock = packet['full_clock'].copy()
    scale, hubble, alpha, eta = [observer[name] for name in ('a_native', 'H_native', 'sigma', 'eta_sync')]
    hubble_prime = -(observer['R'] + 3 * observer['Pbar']) / 6
    potential = eta - hubble * alpha
    dilation = (observer['D_sync'] / 2 + eta) / hubble
    functions, masses = {}, {}
    with np.load(BACKGROUND / (case + '-candidate-background.npz'), allow_pickle=False) as table:
        functions['s'] = [CubicSpline(table['efold'], table[name], bc_type='natural') for name in ('phi_s', 'phidot_s')]
        masses['s'] = float(table['slow_mass_mpc'])
        if case == 'heavy':
            with np.load(SOURCE / 'heavy-equation-quintic.npz', allow_pickle=False) as packet:
                functions['h'], _ = quintic_functions(packet)
            masses['h'] = float(table['heavy_mass_mpc'])
    data = dict(a=scale, H=hubble, Hprime=hubble_prime, alpha=alpha, eta=eta, Phi=potential, z=dilation, beta=scale / float(frozen['density0']), Dtotal=observer['D_sync'], Qtotal=observer['Q_sync'], clock=full_clock[selected])
    fields = {}
    for suffix in functions:
        field_fun, velocity_fun = functions[suffix]
        field, velocity = field_fun(np.log(scale)), velocity_fun(np.log(scale))
        field_first, field_second = field_fun(np.log(scale), 1), field_fun(np.log(scale), 2)
        velocity_first = velocity_fun(np.log(scale), 1)
        mass2 = (scale * masses[suffix])**2
        sync_u, sync_w = standard['mts_dphi_' + suffix], standard['mts_dphidot_' + suffix]
        coordinate, momentum = sync_u + velocity * alpha, sync_w - mass2 * field * alpha - 3 * eta * velocity
        kinetic, potential_energy, geometric = velocity * momentum, mass2 * field * coordinate, 3 * velocity**2 * potential
        defect_f = hubble * field_first - velocity
        defect_b = hubble * velocity_first + 2 * hubble * velocity + mass2 * field
        defect_prime = hubble_prime * field_first + hubble**2 * field_second - hubble * velocity_first
        fields[suffix] = dict(b=field, v=velocity, u=sync_u, w=sync_w, S=velocity**2, V=mass2 * field * velocity, Ds=standard['mts_drho_' + suffix], Ps=standard['mts_dp_' + suffix], Qs=standard['mts_q_' + suffix], DN=kinetic + potential_energy + geometric, PN=kinetic - potential_energy + geometric, QN=velocity * coordinate, Z=scale * field * sync_u, defect=scale * ((defect_b + defect_prime + 2 * hubble * defect_f) * sync_u + 2 * defect_f * sync_w), mass=np.full_like(scale, masses[suffix]))
    density_cdm = observer['R_cdm']
    fields['cdm'] = dict(S=density_cdm, V=np.zeros_like(scale), Ds=density_cdm * observer['delta_cdm64'], Ps=np.zeros_like(scale), Qs=np.zeros_like(scale), DN=density_cdm * (observer['delta_cdm64'] - 3 * hubble * alpha), PN=np.zeros_like(scale), QN=density_cdm * alpha)
    return data, fields, full_clock


def evaluate_gauge(data, field, weights, dust=False):
    project = lambda value: float(weights @ value)
    covariance = lambda first, second: project(first * second) - project(first) * project(second)
    beta, hubble, alpha = data['beta'], data['H'], data['alpha']
    hubble_bar, alpha_bar = project(hubble), project(alpha)
    enthalpy_bar, mixed_bar = project(beta * field['S']), project(beta * field['V'])
    density_correction = -3 * (covariance(beta * field['S'] * hubble, alpha) + alpha_bar * covariance(beta * field['S'], hubble))
    pressure_correction = 0. if dust else density_correction - 2 * covariance(beta * field['V'], alpha)
    current_correction = covariance(beta * field['S'], alpha)
    naive = dict(D=project(beta * field['Ds']) - 3 * hubble_bar * enthalpy_bar * alpha_bar, P=0. if dust else project(beta * field['Ps']) - (3 * hubble_bar * enthalpy_bar + 2 * mixed_bar) * alpha_bar, Q=project(beta * field['Qs']) + enthalpy_bar * alpha_bar)
    corrections = dict(D=density_correction, P=pressure_correction, Q=current_correction)
    actual = {name: project(beta * field[name + 'N']) for name in ('D', 'P', 'Q')}
    checks = {name: algebra(actual[name], naive[name] + corrections[name], [actual[name], naive[name], corrections[name]]) for name in actual}
    return dict(actual=actual, naive=naive, correction=corrections, corrected={name: naive[name] + corrections[name] for name in actual}, checks=checks, omission_relative_to_projected_source={name: abs(corrections[name] / actual[name]) if actual[name] else (0. if corrections[name] == 0 else None) for name in actual})


def virial_prediction(data, field, full_clock, frozen, stride):
    selected = frozen['selected']
    phase = frozen['original_phase']
    indices = np.unique(np.r_[np.arange(0, len(full_clock), stride), len(full_clock) - 1])
    phase_clock = CubicSpline(full_clock[indices], phase[indices])
    rate = phase_clock(full_clock[selected], 1)
    acceleration = phase_clock(full_clock[selected], 2)
    coefficients = frozen['inverse'] @ field['Z']
    reconstruction = frozen['design'] @ coefficients
    second = (frozen['design_phase_second'] @ coefficients) * rate**2 + (frozen['design_phase_first'] @ coefficients) * acceleration
    zeroth = (1 - data['H']**2 - data['Hprime']) * field['Z']
    force = data['a'] * data['z'] * field['b'] * field['v']
    pieces = dict(curvature=second, displacement=zeroth, metric_force=force, source_defect=-field['defect'])
    density0 = float(frozen['density0'])
    projections = {name: float(frozen['weights'] @ values / (2 * density0)) for name, values in pieces.items()}
    prediction = sum(projections.values())
    actual = float(frozen['weights'] @ (data['beta'] * field['Ps']))
    peak = float(np.max(abs(data['beta'] * field['Ds'])))
    residual = field['Z'] - reconstruction
    return dict(prediction=prediction, actual=actual, absolute_error=abs(prediction - actual), error_over_source_density_peak=abs(prediction - actual) / peak if peak else None, pressure_relative_error=abs((prediction - actual) / actual) if actual else None, contributions=projections, displacement_fit_relative_peak=float(np.max(abs(residual)) / np.max(abs(field['Z']))), stride=stride, phase_label_reconstruction_error=float(np.max(abs(phase_clock(full_clock[selected]) - phase[selected]))), pressure_used_to_fit_coefficients=False), dict(coefficients=coefficients, reconstruction=reconstruction, second=second, rate=rate, acceleration=acceleration, residual=residual, **pieces)


def main():
    with worker('project-sources'):
        frozen_report = read(ROOT / 'frozen-projection.json')
        require(frozen_report['passed'] and digest(ROOT / 'frozen-projection.npz') == frozen_report['packet_sha256'], 'operator frozen before source comparison')
        inputs = {str(path): digest(path) for path in (Path(__file__), ROOT / 'projection_support.py', ROOT / 'DERIVATION.md', ROOT / 'frozen-projection.npz', SOURCE / 'quintic_model.py')}
        reports = {}
        with np.load(ROOT / 'frozen-projection.npz', allow_pickle=False) as frozen:
            weights = frozen['weights']
            project = lambda value: float(weights @ value)
            norm, density0, center, sound2 = [float(frozen[name]) for name in ('original_norm', 'density0', 'center', 'sound2')]
            for case in ('cold', 'heavy'):
                guard()
                data, fields, full_clock = case_history(case, frozen)
                source_path = PREVIOUS / ('early-' + case + '-restart.npz')
                inputs[str(source_path)] = digest(source_path)
                gauge = {name: evaluate_gauge(data, field, weights, name == 'cdm') for name, field in fields.items()}
                beta, hubble = data['beta'], data['H']
                hubble_bar = project(hubble)
                source_metric = -(density0 / center) * (project(beta * data['Dtotal']) + 3 * hubble_bar * project(beta * data['Qtotal'])) / 2
                actual_metric = (density0 / center) * project(beta * data['Phi'])
                metric_correction = -1.5 * (density0 / center) * (project(beta * data['Qtotal'] * hubble) - project(beta * data['Qtotal']) * hubble_bar)
                metric = dict(actual=actual_metric, naive=source_metric, correction=metric_correction, corrected=source_metric + metric_correction, check=algebra(actual_metric, source_metric + metric_correction, [actual_metric, source_metric, metric_correction]), omission_relative_to_projected_metric=abs(metric_correction / actual_metric))
                diagnostics, virial, arrays = {}, {}, dict(data)
                for suffix, field in fields.items():
                    arrays.update({suffix + '_' + name: values for name, values in field.items()})
                    if suffix != 'cdm':
                        predictions = {}
                        for stride in (1, 2):
                            predictions[str(stride)], saved = virial_prediction(data, field, full_clock, frozen, stride)
                            arrays.update({suffix + '_virial' + str(stride) + '_' + name: values for name, values in saved.items()})
                        predictions['clock_sensitivity_absolute'] = abs(predictions['1']['prediction'] - predictions['2']['prediction'])
                        if suffix == 'h':
                            for stride in ('1', '2'):
                                predictions[stride]['error_over_original_norm'] = predictions[stride]['absolute_error'] / norm
                                predictions[stride]['historical_pressure_gate_passed'] = predictions[stride]['error_over_original_norm'] <= PRESSURE_GATE
                            predictions['clock_sensitivity_over_original_norm'] = predictions['clock_sensitivity_absolute'] / norm
                        virial[suffix] = predictions
                    if suffix == 'h':
                        scaled = {name: beta * field[key] for name, key in [('density', 'Ds'), ('current', 'Qs'), ('pressure', 'Ps')]}
                        projected = {name: project(value) for name, value in scaled.items()}
                        law = sound2 * (projected['density'] + 3 * hubble_bar * projected['current'])
                        error = abs(projected['pressure'] - law)
                        ratio = (1 / (data['a'] * field['mass']))**2
                        changing_sound = ratio / (np.sqrt(1 + ratio) + 1)**2
                        instant_law = beta * changing_sound * (field['Ds'] + 3 * hubble * field['Qs'])
                        genuine = project(scaled['pressure'] - instant_law)
                        drift = project(instant_law) - law
                        harmonic = {}
                        for name, value in scaled.items():
                            coefficients = frozen['inverse'] @ value
                            slow = frozen['design'][:, :9] @ coefficients[:9]
                            second = frozen['design'][:, 9:23] @ coefficients[9:23]
                            fourth = frozen['design'][:, 23:] @ coefficients[23:]
                            residual = value - slow - second - fourth
                            harmonic[name] = dict(secular=float(coefficients[0]), slow_variation_peak=float(np.max(abs(slow - coefficients[0]))), second_harmonic_peak=float(np.max(abs(second))), fourth_harmonic_peak=float(np.max(abs(fourth))), residual_peak=float(np.max(abs(residual))), actual_peak=float(np.max(abs(value))))
                            arrays.update({name + '_coefficients': coefficients, name + '_slow': slow, name + '_second_harmonic': second, name + '_fourth_harmonic': fourth, name + '_fit_residual': residual})
                        diagnostics = dict(projected=projected, averaged_pressure=law, absolute_error=error, pressure_relative_error=error / abs(projected['pressure']), error_over_original_norm=error / norm, pressure_gate=PRESSURE_GATE, passed=error / norm <= PRESSURE_GATE, diagnostic_decomposition=dict(projected_pointwise_remainder=genuine, coefficient_product_drift=drift, identity=algebra(projected['pressure'] - law, genuine + drift, [projected['pressure'], law, genuine, drift]), independent_prediction=False), harmonic_decomposition=harmonic)
                destination = ROOT / (case + '-projected-sources.npz')
                np.savez_compressed(destination, **arrays)
                passed = all(row['passed'] for result in gauge.values() for row in result['checks'].values()) and metric['check']['passed']
                reports[case] = dict(algebra_passed=passed, gauge=gauge, metric=metric, legacy_pressure=diagnostics, virial=virial, hubble_projected=hubble_bar, original_hubble_change=hubble_bar / frozen_report['original_hubble'] - 1, scale_index_relative_shift=float(np.max(abs(data['a'] / frozen['original_scale'][frozen['selected']] - 1))), packet_sha256=digest(destination), cold_heavy_channel='absent' if case == 'cold' else 'present', new_native_evolution=False)
                print(json.dumps(dict(case=case, algebra_passed=passed, metric_omission=metric['omission_relative_to_projected_metric'], legacy_pressure=diagnostics.get('error_over_original_norm'), virial_heavy=virial.get('h'))), flush=True)
        check_hashes(inputs)
        write('projection-result.json', dict(completed=True, algebra_passed=all(row['algebra_passed'] for row in reports.values()), cases=reports, source_hashes=inputs, original_operator_unchanged=True, original_pressure_gate=PRESSURE_GATE, positive_phase_ensemble_derived=False, galactic_occupation_derived=False))


if __name__ == '__main__':
    main()
