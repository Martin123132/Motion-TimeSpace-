from projection_support import *
import argparse
from diagnose_derivative import consistent_derivative_check


def owned_exits(except_name):
    if except_name == 'validate':
        except_name = 'validate-consistent-state'
    rows = []
    for path in sorted(ROOT.glob('*-start.json')):
        name = path.name.removesuffix('-start.json')
        if name == except_name:
            continue
        identity = read(path)
        end = read(ROOT / (name + '-end.json'))
        expected = 'failed' if name == 'validate' else 'completed'
        require(end['state'] == expected, 'honest worker outcome ' + name)
        require(all(end[key] == identity[key] for key in ('pid', 'created', 'command')), 'exact worker identity')
        outcome = exited(identity)
        require(outcome['exited'], 'worker exited ' + name)
        rows.append(dict(name=name, identity=identity, state=end['state'], outcome=outcome))
    return rows


def labelled_worker(name):
    return worker('validate-consistent-state' if name == 'validate' else name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('validate', 'seal', 'verify'))
    parser.add_argument('--expected')
    args = parser.parse_args()
    diagnosis = read(ROOT / 'derivative-diagnosis-result.json')
    require(diagnosis['passed'], 'diagnosed same-state algebra comparison')
    check_hashes(diagnosis['source_hashes'])
    source = ROOT / 'verify_projection.py'
    namespace = dict(__file__=str(source), __name__='preserved_verifier')
    exec(compile(source.read_text(encoding='utf-8'), str(source), 'exec'), namespace)
    namespace['derivative_check'] = lambda context, index: consistent_derivative_check(context, index)[0]
    namespace['owned_exits'] = owned_exits
    namespace['worker'] = labelled_worker
    if args.mode == 'validate':
        write('validator-repair-result.json', dict(passed=True, physical_evolution_changed=False, tolerance_changed=False, source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'VALIDATOR-REPAIR.md', ROOT / 'diagnose_derivative.py', source)}))
        namespace['validate']()
    elif args.mode == 'seal':
        namespace['seal']()
    else:
        namespace['verify'](args.expected)


if __name__ == '__main__':
    main()
