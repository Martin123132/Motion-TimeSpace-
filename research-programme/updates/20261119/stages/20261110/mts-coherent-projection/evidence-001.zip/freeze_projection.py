from projection_support import *
import numpy as np
from scipy.interpolate import CubicSpline


def basis(phase, middle, derivative=0):
    width = 6 * np.pi
    coordinate = (phase - middle) / width
    terms = [(power, 0, 'cos') for power in range(9)]
    terms += [(power, 2, kind) for power in range(7) for kind in ('cos', 'sin')]
    terms += [(power, 4, kind) for power in range(3) for kind in ('cos', 'sin')]
    result = []
    for power, harmonic, kind in terms:
        wave = np.cos(harmonic * phase) if kind == 'cos' else np.sin(harmonic * phase)
        wave_prime = -harmonic * np.sin(harmonic * phase) if kind == 'cos' else harmonic * np.cos(harmonic * phase)
        polynomial = coordinate**power
        first = power * coordinate**(power - 1) / width if power else np.zeros_like(phase)
        second = power * (power - 1) * coordinate**(power - 2) / width**2 if power > 1 else np.zeros_like(phase)
        if derivative == 0:
            result.append(polynomial * wave)
        elif derivative == 1:
            result.append(first * wave + polynomial * wave_prime)
        else:
            result.append(second * wave + 2 * first * wave_prime - harmonic**2 * polynomial * wave)
    return np.column_stack(result)


def main():
    with worker('freeze-projection'):
        inputs = preserved()
        legacy = SPECTRUM / 'runs/projection/a225-w6-d8.npz'
        old_path = BRIDGE / 'k1-early-source.npz'
        table_path = EARLY / 'runs/backgrounds/heavy.npz'
        old_result = read(BRIDGE / 'projection-reproduction.json')
        require(digest(legacy) == old_result['sha256'], 'original projection source')
        for path in (Path(__file__), ROOT / 'projection_support.py', ROOT / 'PROTOCOL.md', legacy, old_path, table_path, SPECTRUM / 'project_grid.py'):
            inputs[str(path)] = digest(path)
        with np.load(legacy, allow_pickle=False) as saved, np.load(old_path, allow_pickle=False) as packet, np.load(table_path, allow_pickle=False) as table:
            columns = dict(zip([str(name) for name in packet['names']], packet['values'].T))
            row = np.flatnonzero(saved['modes'] == 1.)
            require(len(row) == 1, 'one historical k1 row')
            index = int(row[0])
            center, density0 = float(saved['matching_scale']), float(saved['matching_density'])
            phase_fun = CubicSpline(table['heavy_efold'], table['phase_h'])
            phases = phase_fun(np.log(columns['a']))
            middle = float(phase_fun(np.log(center)))
            selected = np.flatnonzero(abs(phases - middle) < 6 * np.pi)
            design = basis(phases[selected], middle)
            inverse = np.linalg.pinv(design)
            weights = inverse[0]
            require(len(selected) == 902 and design.shape == (902, 29), 'original window and basis')
            rows = {}
            for label, key, target in [('density', 'mts_drho_h', 'matching_delta'), ('current', 'mts_q_h', 'matching_momentum'), ('pressure', 'mts_dp_h', 'projected_pressure')]:
                value = float((columns[key][selected] * columns['a'][selected]) @ weights / density0)
                reference = float(saved[target][index])
                error = abs(value - reference)
                require(error <= ALGEBRA * abs(reference), 'historical projection reproduction ' + label)
                rows[label] = dict(value=value, reference=reference, absolute_error=error)
            hubble = float(columns['H'][selected] @ weights)
            ratio = (1 / (center * float(table['heavy_mass_mpc'])))**2
            sound2 = ratio / (np.sqrt(1 + ratio) + 1)**2
            predicted = sound2 * (rows['density']['value'] + 3 * hubble * rows['current']['value'])
            norm = max(abs(rows['density']['value']), abs(rows['current']['value'] / hubble) / max(1., np.sqrt(sound2) / hubble), 1e-6)
            require(abs(norm / float(saved['projection_norm'][index]) - 1) < ALGEBRA, 'historical normalization')
            error = abs(rows['pressure']['value'] - predicted) / norm
            require(abs(error - float(saved['closure_error'][index])) < ALGEBRA * PRESSURE_GATE, 'historical pressure error')
            require(np.max(abs(weights @ design - np.eye(29)[0])) < ALGEBRA, 'fixed extraction identity')
            destination = ROOT / 'frozen-projection.npz'
            np.savez_compressed(destination, selected=selected, original_phase=phases, phase_middle=middle, design=design, design_phase_first=basis(phases[selected], middle, 1), design_phase_second=basis(phases[selected], middle, 2), inverse=inverse, weights=weights, center=center, density0=density0, original_norm=norm, original_requested_scale=packet['requested_scale'], original_scale=columns['a'], sound2=sound2, mass=float(table['heavy_mass_mpc']))
        check_hashes(inputs)
        write('frozen-inputs.json', inputs)
        write('frozen-projection.json', dict(passed=True, packet_sha256=digest(destination), prior_seal=EXPECTED, rows=rows, original_norm=norm, original_pressure_error=error, original_pressure_gate=PRESSURE_GATE, original_hubble=hubble, sound2=sound2, selected_nodes=len(selected), design_columns=29, condition=float(np.linalg.cond(design)), weight_sum=float(weights.sum()), weight_abs_sum=float(abs(weights).sum()), negative_weights=int(np.count_nonzero(weights < 0)), negative_weight_sum=float(weights[weights < 0].sum()), frozen_before_new_source_evaluation=True, source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'projection_support.py', ROOT / 'PROTOCOL.md', legacy, old_path, table_path)}))
        print(json.dumps(dict(frozen=True, nodes=len(selected), original_pressure_error=error, negative_weights=int(np.count_nonzero(weights < 0)), abs_weight_sum=float(abs(weights).sum()))), flush=True)


if __name__ == '__main__':
    main()
