from stage_support import *
import math
import numpy as np
import sympy as sym

NATIVE = POST / "condensate-origin-20261003/native-heavy-matching-20261007/native/fortran"
NORMALIZATION = 7 * math.pi**4 / 120


def thermal_integral(masses, steps):
    masses = np.atleast_1d(masses).astype(float)
    spacing = 30. / steps
    momentum = np.arange(1, steps + 1) * spacing
    energy = np.sqrt(masses[:, None]**2 + momentum[None, :]**2)
    factor = spacing * momentum**2 / (np.exp(momentum) + 1)
    density = factor[None, :] * energy
    pressure = factor[None, :] * momentum[None, :]**2 / energy
    outputs = []
    for values in (density, pressure):
        endpoint_derivative = (11 * values[:, -1] - 18 * values[:, -2] + 9 * values[:, -3] - 2 * values[:, -4]) / 6
        integral = np.sum(values[:, :-1], axis=1) + .5 * values[:, -1] - endpoint_derivative / 12
        integral += values[:, -1] / spacing
        outputs.append(integral / NORMALIZATION)
    return np.array([outputs[0], outputs[1] / 3]).T


def derivatives(values):
    count = len(values)
    recurrence = np.zeros(count)
    for index in range(1, count):
        recurrence[index] = 1 / (4 - recurrence[index - 1])
    forcing = np.empty_like(values)
    forcing[0] = (-10 * values[0] + 15 * values[1] - 6 * values[2] + values[3]) / 6
    forcing[-1] = (10 * values[-1] - 15 * values[-2] + 6 * values[-3] - values[-4]) / 6
    for index in range(1, count - 1):
        forcing[index] = recurrence[index] * (3 * (values[index + 1] - values[index - 1]) - forcing[index - 1])
    output = np.empty_like(values)
    output[-1] = forcing[-1]
    for index in range(count - 2, -1, -1):
        output[index] = forcing[index] - recurrence[index] * output[index + 1]
    return output


def interpolate(mass, values, slopes):
    step = (70. - .3) / (1400 - 1)
    coordinate = (mass - .3) / step
    index = int(coordinate)
    fraction = coordinate - index
    left, right, left_slope, right_slope = values[index], values[index + 1], slopes[index], slopes[index + 1]
    return left + fraction * (left_slope + fraction * (3 * (right - left) - 2 * left_slope - right_slope + fraction * (left_slope + right_slope + 2 * (left - right))))


def main():
    with worker("background-reference"):
        previous = read(ROOT / "continuum-reference.json")
        require(not previous["passed"], "retain rejected five-node-only explanation")
        frozen = digest(ROOT / "BACKGROUND-PREDICTION.md")
        momentum, mass_symbol = sym.symbols("momentum mass", positive=True)
        integrand = (momentum**2 * sym.sqrt(momentum**2 + mass_symbol**2) + momentum**4 / (3 * sym.sqrt(momentum**2 + mass_symbol**2))) / (sym.exp(momentum) + 1)
        series = sym.series(integrand, momentum, 0, 9).removeO().expand()
        coefficient_expressions = {order: sym.simplify(sym.bernoulli(order) * series.coeff(momentum, order - 1) / order) for order in (4, 6, 8)}
        require(sym.simplify(coefficient_expressions[4] - mass_symbol / 480) == 0, "derived h4 coefficient")
        require(sym.simplify(coefficient_expressions[6] - (5 * mass_symbol / 2 - 25 / mass_symbol) / 30240) == 0, "derived h6 coefficient")
        coefficient_functions = {order: sym.lambdify(mass_symbol, expression, "numpy") for order, expression in coefficient_expressions.items()}
        table_masses = .3 + np.arange(1400) * ((70. - .3) / 1399)
        table = thermal_integral(table_masses, 100)
        slopes = derivatives(table)
        reports = []
        for row in previous["reports"]:
            mass = row["am"]
            native_dimensionless = row["reference_background_enthalpy"] * (1 + row["native_background_relative_difference"])
            interpolated = float(np.sum(interpolate(mass, table, slopes)))
            refinements = []
            for steps in (100, 200, 400, 800):
                enthalpy = float(np.sum(thermal_integral([mass], steps)))
                refinements.append(dict(steps=steps, enthalpy=enthalpy, absolute_error=enthalpy - row["reference_background_enthalpy"]))
            correction, series_checks = 0., []
            discrepancy = row["reference_background_enthalpy"] - refinements[0]["enthalpy"]
            for order in (4, 6, 8):
                correction += float(coefficient_functions[order](mass)) * .3**order / NORMALIZATION
                series_checks.append(dict(order=order, predicted_correction=correction, relative_discrepancy=abs(correction - discrepancy) / abs(discrepancy)))
            predicted_mismatch = (interpolated - row["five_node_enthalpy"]) / interpolated
            prediction_error = abs(predicted_mismatch - row["native_fractional_mismatch"]) / abs(row["native_fractional_mismatch"])
            reports.append(dict(case=row["case"], fraction=row["fraction"], am=mass,
                                native_background_enthalpy=native_dimensionless, reproduced_background_enthalpy=interpolated,
                                reconstruction_error=abs(interpolated / native_dimensionless - 1),
                                source_mismatch_prediction_error=prediction_error, predicted_fractional_mismatch=predicted_mismatch,
                                refinements=refinements, endpoint_series=series_checks,
                                final_to_initial_integration_error=abs(refinements[-1]["absolute_error"] / refinements[0]["absolute_error"])))
        passed = all(row["reconstruction_error"] <= ALGEBRA and row["source_mismatch_prediction_error"] <= GATE and row["endpoint_series"][-1]["relative_discrepancy"] <= GATE and
                     all(abs(later["absolute_error"]) < abs(earlier["absolute_error"]) for earlier, later in zip(row["refinements"], row["refinements"][1:])) for row in reports)
        result = dict(passed=passed, reports=reports, endpoint_coefficients={str(order): str(expression) for order, expression in coefficient_expressions.items()},
                      source_hashes={str(NATIVE / name): digest(NATIVE / name) for name in ("massive_neutrinos.f90", "subroutines.f90")},
                      frozen_prediction_sha256=frozen, code_sha256=digest(__file__), continuum_input_sha256=digest(ROOT / "continuum-reference.json"),
                      production_background_changed=False, production_momentum_grid_changed=False,
                      qualification="Independent diagnostic replication and convergence, not a repaired production trajectory or rigorous error enclosure.")
        write("background-reference-result.json", result)
        print(json.dumps(dict(passed=passed, endpoint_coefficients=result["endpoint_coefficients"], first=reports[0],
                              maximum_reconstruction_error=max(row["reconstruction_error"] for row in reports),
                              maximum_source_prediction_error=max(row["source_mismatch_prediction_error"] for row in reports),
                              maximum_endpoint_series_error=max(row["endpoint_series"][-1]["relative_discrepancy"] for row in reports)), indent=2))
        require(passed, "thermal-background quadrature diagnosis")


if __name__ == "__main__":
    main()
