from stage_support import *
from summarize_stage import exited


def main():
    with worker("seal"):
        validation = read(ROOT / "validation.json")
        require(validation["passed"], "validated stage")
        require(not validation["five_node_only_explanation_passed"] and validation["full_native_background_and_perturbation_explanation_passed"], "retain actual hypothesis outcomes")
        inputs = preserved()
        require(inputs == read(ROOT / "frozen-inputs.json"), "frozen inherited inputs")
        for path, checksum in validation["source_hashes"].items():
            require(digest(path) == checksum, "reference source changed")
            if path in inputs:
                require(inputs[path] == checksum, "inherited source conflict")
            inputs[path] = checksum
        compiled = []
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            compiled.append(path.name)
        for name in ("RESULTS.md", "DERIVATION.md", "NEXT.md", "PROTOCOL.md"):
            require((ROOT / name).is_file(), "missing document " + name)
        workers = []
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name == "seal-start.json":
                continue
            identity = read(path)
            status = exited(identity)
            require(status["exited"], "worker still live: " + path.name)
            workers.append(dict(receipt=path.name, identity=identity, status=status))
        require(not list(ROOT.rglob("__pycache__")), "no bytecode")
    artifacts = {}
    for path in sorted(ROOT.iterdir()):
        require(path.is_file() and path.name != "closeout.json", "unexpected artifact or reseal")
        artifacts[path.name] = dict(sha256=digest(path), bytes=path.stat().st_size)
    write("closeout.json", dict(state="verified_progress_derived_neutrino_representation_defect", goal_complete=False,
          utc=datetime.now(timezone.utc).isoformat(), input_hashes=inputs, artifacts=artifacts, workers=workers, compiled_after_validation=compiled,
          verified=["seven-species intrinsic/gauge budget decomposition", "analytic neutrino quadrature defect prediction",
                    "continuous enthalpy identity", "independent native background replication", "derived endpoint integration-error series",
                    "source-to-metric error relation"],
          rejected=["five-node-only explanation of full mismatch", "decimal64 interpretation of unsuffixed native literals"],
          production_repair_applied=False, new_evolution=False, new_fitted_parameters=0,
          qualification="Derived numerical source-compatibility diagnosis for saved paired trajectories, not a new observational fit or universal error enclosure.",
          next="NEXT.md", cleanup="Verify seal process exit and hashes separately."))
    print(json.dumps(dict(seal_sha256=digest(ROOT / "closeout.json"), inputs=len(inputs), artifacts=len(artifacts), validation_checks=len(validation["checks"]))))


if __name__ == "__main__":
    main()
