from stage_support import *
import re
import math
import numpy as np
from scipy.integrate import quad


def main():
    with worker("continuum-literals"):
        source = POST / "condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/massive_neutrinos.f90"
        text = source.read_text(encoding="utf-8")
        section = text.split("else if (this%nqmax==5) then", 1)[1].split("else", 1)[0]
        nodes, weights = [] , []
        for variable, target in (("nu_q", nodes), ("nu_int_kernel", weights)):
            expression = re.search(r"this%" + variable + r"\(1:5\)\s*=\s*\(/(.*?)/\)", section).group(1)
            target.extend(float(np.float32(value.strip())) for value in expression.split(","))
        require(len(nodes) == len(weights) == 5, "native five-node rule")
        normalization = 7 * math.pi**4 / 120
        saved = read(ROOT / "neutrino-prediction-result.json")
        require(saved["passed"], "native equation prediction verified first")
        reports = []
        for case in ("cold", "heavy", "D0", "D01"):
            for fraction in (0., .5, 1.):
                sample = next(row for row in saved["reports"] if row["case"] == case and row["enabled"] and row["fraction"] == fraction)
                require(len(sample["node_checks"]) == 5 and all(row["eigen"] == 0 for row in sample["node_checks"]), "one retained five-node eigenstate")
                inferred_mass = [node * math.sqrt(1 / row["speed"]**2 - 1) for node, row in zip(nodes, sample["node_checks"])]
                mass = inferred_mass[0]
                mass_spread = max(abs(value / mass - 1) for value in inferred_mass)
                require(mass_spread <= ALGEBRA, "common retained am, not a fitted mass")

                def background_integrand(momentum):
                    energy = math.hypot(momentum, mass)
                    exponential = math.exp(-momentum)
                    occupation = exponential / (1 + exponential)
                    return momentum**2 * (energy + momentum**2 / (3 * energy)) * occupation / normalization

                def perturbation_integrand(momentum):
                    energy = math.hypot(momentum, mass)
                    exponential = math.exp(-momentum)
                    derivative = exponential / (1 + exponential)**2
                    return momentum**3 * energy * derivative / (3 * normalization)

                background, background_estimate = quad(background_integrand, 0, np.inf, epsabs=1e-11, epsrel=2e-13, limit=120)
                perturbation, perturbation_estimate = quad(perturbation_integrand, 0, np.inf, epsabs=1e-11, epsrel=2e-13, limit=120)
                five_node = sum(4 * weight * math.sqrt(1 + (mass / node)**2) / (3 * normalization) for node, weight in zip(nodes, weights))
                reference_mismatch = (background - five_node) / background
                native_scale = sample["quadrature_enthalpy"] / five_node
                native_dimensionless = sample["background_enthalpy"] / native_scale
                background_difference = (native_dimensionless - background) / background
                identity_error = abs(background - perturbation) / background
                reports.append(dict(case=case, fraction=fraction, am=mass, mass_from_node_spread=mass_spread,
                                    reference_background_enthalpy=background, reference_perturbation_enthalpy=perturbation,
                                    five_node_enthalpy=five_node, continuum_identity_error=identity_error,
                                    reference_fractional_mismatch=reference_mismatch,
                                    native_fractional_mismatch=sample["fractional_enthalpy_mismatch"],
                                    native_background_relative_difference=background_difference,
                                    estimated_absolute_integration_errors=[background_estimate, perturbation_estimate]))
        result = dict(passed=all(row["continuum_identity_error"] <= ALGEBRA and abs(row["reference_fractional_mismatch"] - row["native_fractional_mismatch"]) <= GATE * abs(row["native_fractional_mismatch"]) for row in reports),
                      reports=reports, nodes=nodes, unnormalized_weights=weights,
                      reference_source=str(source), reference_source_sha256=digest(source), code_sha256=digest(__file__),
                      saved_input_sha256=digest(ROOT / "neutrino-prediction-result.json"),
                      original_grids_changed=False, reference_only=True, native_literal_kind="default REAL32 literals promoted into real(dl) arrays",
                      qualification="Reference integrals diagnose the native quadrature; no saved source, action, background or evolution is replaced. Quadrature error estimates are not rigorous enclosures.")
        write("continuum-reference.json", result)
        print(json.dumps(dict(passed=result["passed"], reports=reports), indent=2))
        require(result["passed"], "independent continuum comparison")


if __name__ == "__main__":
    main()
