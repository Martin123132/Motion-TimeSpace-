from stage_support import *
from budget_model import SpeciesOperators, diagnose
import numpy as np


def main():
    with worker("budget"):
        write("frozen-inputs.json", preserved())
        reports, packets = [], {}
        for label, canonical, cases in (("cold", False, ("cold",)), ("heavy", False, ("heavy",)), ("heavy", True, ("D0", "D01"))):
            operator = SpeciesOperators(label, canonical)
            try:
                for enabled in (False, True):
                    operator.enabled = enabled
                    if operator.block is not None:
                        operator.block.enabled = enabled
                    operator.cache.clear()
                    operator.systems.clear()
                    for case in cases:
                        name = case + ("-corrected-" if enabled else "-original-") + ("256" if canonical else "128")
                        with np.load(SOURCE / (name + ".npz")) as packet:
                            history = packet["history"].copy()
                            saved_times = packet["times"].copy()
                        require(np.array_equal(saved_times, np.linspace(*operator.port.times, 9)), "saved probe times")
                        for index, state in enumerate(history):
                            for divisions in (16, 32):
                                jets = operator.jets_at(index / 8, divisions)
                                result = diagnose(operator, jets, state)
                                reports.append(dict(case=case, enabled=enabled, fraction=index / 8, divisions=divisions, **result))
                        selected = reports[-18:]
                        print(json.dumps(dict(case=case, enabled=enabled, largest_total=max(abs(row["metrics"]["total_budget"]) for row in selected),
                              species={species: max(abs(row["species"][species]["synchronous_budget"]) for row in selected) for species in selected[0]["species"]},
                              largest_baryon_pressure=max(abs(row["baryon_pressure_budget"]) for row in selected),
                              largest_baryon_prediction_error=max(row["baryon_analytic_prediction_error"] for row in selected))), flush=True)
                    for fraction, sample in operator.cache.items():
                        key = label + "_" + str(int(canonical)) + "_" + str(int(enabled)) + "_" + str(fraction)
                        for field in ("matrix", "phi", "psi", "clock_alpha", "sync_eta", "sync_z"):
                            packets[key + "_" + field] = sample[field]
            finally:
                operator.close()
        np.savez_compressed(ROOT / "budget-control-rows.npz", **packets)
        result = dict(reports=reports, code_sha256=digest(__file__), model_sha256=digest(ROOT / "budget_model.py"),
                      source_seal=EXPECTED, trajectories_reused=True, new_evolution=False, tolerances=dict(physics=GATE, algebra=ALGEBRA))
        write("species-budget.json", result)
        require(all(max(row["source_sum_errors"].values()) <= ALGEBRA and row["total_budget_identity_error"] <= ALGEBRA for row in reports), "source decomposition identities")


if __name__ == "__main__":
    main()
