from stage_support import *
import sympy as sym


def main():
    with worker("proof"):
        density, density_prime, current, current_prime, enthalpy, enthalpy_prime, hubble, hubble_prime, alpha, alpha_prime, eta, eta_prime, wave, zvalue, pi_total, pi_species = sym.symbols(
            "density density_prime current current_prime enthalpy enthalpy_prime hubble hubble_prime alpha alpha_prime eta eta_prime wave zvalue pi_total pi_species", real=True)
        newtonian_density = density - 3 * hubble * enthalpy * alpha
        newtonian_current = current + wave * enthalpy * alpha
        newtonian_density_prime = density_prime - 3 * (hubble_prime * enthalpy + hubble * enthalpy_prime) * alpha - 3 * hubble * enthalpy * alpha_prime
        newtonian_current_prime = current_prime + wave * enthalpy_prime * alpha + wave * enthalpy * alpha_prime
        phi_prime = eta_prime - hubble_prime * alpha - hubble * alpha_prime
        psi = eta - hubble * alpha - pi_total / wave**2
        newtonian = newtonian_density_prime + hubble * newtonian_density + wave * newtonian_current - 3 * enthalpy * phi_prime + 3 * hubble * newtonian_current_prime / wave + 6 * hubble**2 * newtonian_current / wave - 3 * hubble * enthalpy * psi + 2 * hubble * pi_species
        synchronous = density_prime + hubble * density + wave * current + wave * zvalue * enthalpy + 3 * hubble * current_prime / wave + 6 * hubble**2 * current / wave + 2 * hubble * pi_species
        clock_defect = alpha_prime + hubble * alpha - psi
        eta_defect = eta_prime - wave * (wave * alpha - zvalue) / 3
        require(sym.factor(newtonian - synchronous - 3 * hubble * enthalpy * clock_defect + 3 * enthalpy * eta_defect) == 0, "species gauge-budget identity")
        rho, pressure, exchange = sym.symbols("rho pressure exchange", real=True)
        baryon = synchronous.subs({density_prime: -hubble * density - wave * current - wave * zvalue * rho,
                                   current_prime: -2 * hubble * current + wave * pressure + exchange,
                                   enthalpy: rho, pi_species: 0})
        require(sym.factor(baryon - 3 * hubble * pressure - 3 * hubble * exchange / wave) == 0, "baryon pressure and exchange budget")
        cold = synchronous.subs({density_prime: -hubble * density - wave * zvalue * rho,
                                 current: 0, current_prime: 0, enthalpy: rho, pi_species: 0})
        require(sym.factor(cold) == 0, "CDM synchronous budget")
        total_enthalpy, sync_current = sym.symbols("total_enthalpy sync_current", real=True)
        background_defect = hubble_prime - hubble**2 + total_enthalpy / 2
        metric_defect = phi_prime + hubble * psi - (sync_current + wave * total_enthalpy * alpha) / (2 * wave)
        require(sym.factor(metric_defect + hubble * clock_defect - eta_prime + sync_current / (2 * wave) + background_defect * alpha) == 0, "metric and clock defect relation")
        result = dict(passed=True, identities=["species_gauge_budget", "baryon_pressure_exchange", "CDM_budget", "metric_clock_defect_relation"], code_sha256=digest(__file__))
        write("proof.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    main()
