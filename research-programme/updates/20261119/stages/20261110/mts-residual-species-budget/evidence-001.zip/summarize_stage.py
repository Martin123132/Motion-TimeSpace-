from stage_support import *
import csv
import numpy as np
import sympy as sym


def exited(identity):
    try:
        process = psutil.Process(identity["pid"])
        created, command = process.create_time(), process.cmdline()
    except psutil.NoSuchProcess:
        return dict(exited=True, reason="PID absent")
    same = abs(created - identity["created"]) < .01 and command == identity["command"]
    return dict(exited=not same, reason="original identity live" if same else "PID reused; not touched", observed_creation=created, observed_command=command)


def prove_constraint_bound():
    constraint, constraint_prime, hubble, enthalpy, wave, current, background, alpha, eta_error, metric, synchronous = sym.symbols(
        "constraint constraint_prime hubble enthalpy wave current background alpha eta_error metric synchronous", real=True)
    clock = (eta_error - constraint / (6 * hubble) - background * alpha - metric) / hubble
    budget = synchronous + 3 * hubble * enthalpy * clock - 3 * enthalpy * eta_error + 3 * background * (current + wave * enthalpy * alpha) / wave
    retained_identity = constraint_prime + hubble * constraint - budget - (2 * wave**2 + 3 * enthalpy) * metric
    reduced = constraint_prime + (hubble + enthalpy / (2 * hubble)) * constraint - synchronous - 3 * background * current / wave - 2 * wave**2 * metric
    require(sym.factor(retained_identity - reduced) == 0, "synchronous source-to-metric defect identity")
    return dict(passed=True, identity="2 k^2 Ephi = Ec' + (H+S/(2H)) Ec - sum Ki - 3 EH Qsync/k",
                assumptions="retained flat scalar conventions, H nonzero and k nonzero; source gauge/constraint definitions as in DERIVATION.md",
                bound="Triangle inequality bounds |Ephi| by the absolute terms on the right divided by 2 k^2. A uniform time bound additionally needs verified enclosures for those terms.")


def main():
    with worker("validation"):
        checks = []

        def check(name, condition, **details):
            checks.append(dict(name=name, passed=bool(condition), **details))

        inputs = preserved()
        check("inherited inputs unchanged", inputs == read(ROOT / "frozen-inputs.json"), count=len(inputs))
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            check("compile " + path.name, True)
        check("no bytecode cache", not list(ROOT.rglob("__pycache__")))
        proof = read(ROOT / "proof.json")
        budget = read(ROOT / "species-budget.json")
        neutrino = read(ROOT / "neutrino-prediction-result.json")
        continuum = read(ROOT / "continuum-reference.json")
        background = read(ROOT / "background-reference-result.json")
        check("four exact budget identities", proof["passed"] and len(proof["identities"]) == 4)
        check("two exact node identities", neutrino["passed"] and len(neutrino["identities"]) == 2)
        bound = prove_constraint_bound()
        write("constraint-bound.json", bound)
        check("source-to-metric defect identity", bound["passed"])
        for report, name in ((proof, "prove_budget.py"), (budget, "measure_budget.py"), (neutrino, "check_neutrino.py"), (continuum, "check_continuum_reference.py"), (background, "check_background_reference.py")):
            check("source hash " + name, report["code_sha256"] == digest(ROOT / name))
        for report in (budget, neutrino):
            check("budget model hash", report["model_sha256"] == digest(ROOT / "budget_model.py"))
        check("frozen neutrino prediction", neutrino["frozen_prediction_sha256"] == digest(ROOT / "NEUTRINO-PREDICTION.md"))
        check("frozen background prediction", background["frozen_prediction_sha256"] == digest(ROOT / "BACKGROUND-PREDICTION.md"))
        check("same gates and saved trajectories", budget["tolerances"] == dict(physics=GATE, algebra=ALGEBRA) and budget["trajectories_reused"] and not budget["new_evolution"])
        check("no source or production background change", not neutrino["source_rows_changed"] and not background["production_background_changed"] and not background["production_momentum_grid_changed"])
        check("failed five-node-only hypothesis retained", not continuum["passed"] and read(ROOT / "continuum-literals-end.json")["state"] == "failed")
        check("reader failure retained", read(ROOT / "continuum-end.json")["state"] == "failed")
        check("continuum integral identity itself passes", all(row["continuum_identity_error"] <= ALGEBRA and row["mass_from_node_spread"] <= ALGEBRA for row in continuum["reports"]))
        check("background replication and derived endpoint correction", background["passed"])
        for path, checksum in background["source_hashes"].items():
            check("native source hash " + Path(path).name, digest(path) == checksum)
        check("continuum source hash", digest(continuum["reference_source"]) == continuum["reference_source_sha256"])
        check("continuum input hash", continuum["saved_input_sha256"] == digest(ROOT / "neutrino-prediction-result.json"))
        check("background input hash", background["continuum_input_sha256"] == digest(ROOT / "continuum-reference.json"))
        check("budget case coverage", len(budget["reports"]) == 144 and {(row["case"], row["enabled"], row["fraction"], row["divisions"]) for row in budget["reports"]} == {(case, enabled, index / 8, divisions) for case in ("cold", "heavy", "D0", "D01") for enabled in (False, True) for index in range(9) for divisions in (16, 32)})
        check("neutrino case coverage", len(neutrino["reports"]) == 72 and {(row["case"], row["enabled"], row["fraction"]) for row in neutrino["reports"]} == {(case, enabled, index / 8) for case in ("cold", "heavy", "D0", "D01") for enabled in (False, True) for index in range(9)})
        check("species source identities", all(max(row["source_sum_errors"].values()) <= ALGEBRA and row["total_budget_identity_error"] <= ALGEBRA and max(data["gauge_identity_error"] for data in row["species"].values()) <= ALGEBRA for row in budget["reports"]))
        check("node prediction verified", all(row["prediction_error"] <= GATE and row["momentum_error"] <= ALGEBRA for row in neutrino["reports"]))
        check("zero-mismatch ablation fails", all(row["zero_mismatch_ablation_error"] > .99 for row in neutrino["reports"]))
        for row in background["reports"]:
            check("native background replication " + row["case"] + str(row["fraction"]), row["reconstruction_error"] <= ALGEBRA and row["source_mismatch_prediction_error"] <= GATE)
            check("endpoint-series prediction " + row["case"] + str(row["fraction"]), row["endpoint_series"][-1]["relative_discrepancy"] <= GATE)
            check("monotone diagnostic quadrature refinement " + row["case"] + str(row["fraction"]), all(abs(later["absolute_error"]) < abs(earlier["absolute_error"]) for earlier, later in zip(row["refinements"], row["refinements"][1:])))
        summaries, rows = [], []
        for case in ("cold", "heavy", "D0", "D01"):
            for enabled in (False, True):
                selected = [row for row in budget["reports"] if row["case"] == case and row["enabled"] == enabled]
                predicted = [row for row in neutrino["reports"] if row["case"] == case and row["enabled"] == enabled]
                fractions = []
                for row in selected:
                    partner = next(entry for entry in predicted if entry["fraction"] == row["fraction"])
                    predicted_metric = -partner["predicted_budget"] / (2 * 5.**2)
                    actual_metric = row["metrics"]["metric_residual"]
                    fraction = predicted_metric / actual_metric
                    fractions.append(fraction)
                    rows.append(dict(case=case, enabled=enabled, fraction=row["fraction"], divisions=row["divisions"], measured_metric=actual_metric,
                                     neutrino_metric_contribution=predicted_metric, signed_neutrino_fraction=fraction,
                                     other_metric_remainder=actual_metric - predicted_metric,
                                     total_budget=row["metrics"]["total_budget"], massive_synchronous_budget=row["species"]["massive"]["synchronous_budget"],
                                     neutrino_analytic_budget=partner["measured_analytic_budget"], neutrino_predicted_budget=partner["predicted_budget"]))
                summaries.append(dict(case=case, enabled=enabled, neutrino_signed_metric_fraction_range=[min(fractions), max(fractions)],
                                      maximum_source_prediction_error=max(row["prediction_error"] for row in predicted),
                                      maximum_stencil_minus_analytic=max(abs(value) for row in predicted for value in row["stencil_minus_analytic"].values()),
                                      maximum_baryon_tiny_budget_relative_error=max(row["baryon_analytic_prediction_error"] for row in selected)))
        with (ROOT / "metric-source-budget.csv").open("x", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
        with (ROOT / "metric-source-budget.csv").open(encoding="utf-8", newline="") as stream:
            parsed = list(csv.DictReader(stream))
        check("budget CSV complete", len(parsed) == 144 and all(None not in row for row in parsed))
        with np.load(ROOT / "budget-control-rows.npz") as packet:
            check("saved row packet finite", all(np.all(np.isfinite(packet[key])) for key in packet.files))
        processes = []
        expected_failures = {"continuum-start.json", "continuum-literals-start.json"}
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name == "validation-start.json":
                continue
            identity = read(path)
            status = exited(identity)
            ending = read(ROOT / path.name.replace("-start.json", "-end.json"))
            check("worker exited " + path.name, status["exited"])
            check("honest ending " + path.name, ending["state"] == ("failed" if path.name in expected_failures else "completed"))
            processes.append(dict(receipt=path.name, identity=identity, status=status, ending=ending["state"]))
        result = dict(passed=all(row["passed"] for row in checks), checks=checks, workers=processes, input_count=len(inputs),
                      summaries=summaries, equation_prediction_passed=True, continuum_identity_passed=True, five_node_only_explanation_passed=False,
                      full_native_background_and_perturbation_explanation_passed=background["passed"], production_repair_applied=False,
                      source_hashes=background["source_hashes"], scientific_outcome="The dominant remaining source defect is derived from unmatched native background and perturbation neutrino quadratures; its two components are independently reproduced and the background endpoint error is derived.",
                      qualification="Finite sampled diagnostics and reference convergence, not a universal error enclosure or observational preference.")
        write("validation.json", result)
        print(json.dumps(dict(passed=result["passed"], checks=len(checks), inputs=len(inputs), summaries=summaries, failed=[row for row in checks if not row["passed"]]), indent=2))
        require(result["passed"], "honest derivation, implementation and provenance checks")


if __name__ == "__main__":
    main()
