from stage_support import *
from budget_model import SpeciesOperators
from bridge_imports import relative
import numpy as np
import sympy as sym


def prove():
    hubble, wave, zvalue, density_weight, current_weight, pi_weight, speed, monopole, dipole, quadrupole, enthalpy = sym.symbols(
        "hubble wave zvalue density_weight current_weight pi_weight speed monopole dipole quadrupole enthalpy", real=True)
    density = density_weight * monopole
    pressure = density_weight * speed**2 * monopole / 3
    current = density_weight * speed * dipole
    anisotropy = density_weight * speed**2 * quadrupole
    density_prime = -hubble * (1 + speed**2) * density - density_weight * wave * (4 * zvalue / 3 + speed * dipole)
    current_prime = -2 * hubble * current + density_weight * speed**2 * wave * (monopole - 2 * quadrupole) / 3
    energy = density_prime + hubble * (density + 3 * pressure) + wave * current + wave * zvalue * enthalpy
    momentum = current_prime + 2 * hubble * current - wave * pressure + 2 * wave * anisotropy / 3
    require(sym.factor(energy - wave * zvalue * (enthalpy - 4 * density_weight / 3)) == 0, "node energy identity")
    require(sym.factor(momentum) == 0, "node current identity")
    return ["node_energy_quadrature_defect", "node_current_conservation"]


def evaluate(operator, fraction, state):
    sample = operator.sample(fraction)
    system = operator.systems[fraction]
    port = operator.port
    signature = port.reference["signature"]
    require(signature[18] == 0, "no unresolved relativistic momentum tail")
    require(signature[20] > 0, "massive eigenstates present")
    mapping = system["mapping"]
    native_map = port.reference["mapping"]
    state = state.astype(np.longdouble)
    matrix = sample["matrix"].astype(np.longdouble)
    derivative = matrix @ state
    density_row = sample["massive_sync_density"].copy()
    current_row = sample["massive_sync_current"].copy()
    pi_row = sample["massive_source_pi"].copy()
    pressure_row = np.zeros(len(state), dtype=np.longdouble)
    expected_density = np.zeros_like(pressure_row)
    expected_current = np.zeros_like(pressure_row)
    expected_pi = np.zeros_like(pressure_row)
    hubble, wave = sample["hubble"], port.wave
    zrow = sample["sync_z"]
    summed_weights = np.longdouble(0)
    node_reports = []
    for eigen in range(int(signature[20])):
        require(signature[70 + eigen] == 0, "full momentum hierarchy, not massive fluid approximation")
        count, lmax, begin = [int(signature[index + eigen]) for index in (30, 40, 50)]
        require(lmax >= 2 and count > 0, "resolved monopole dipole quadrupole")
        for node in range(count):
            indices = []
            for moment in range(3):
                native_index = int(np.flatnonzero(native_map == begin + node * (lmax + 1) + moment)[0])
                candidates = np.flatnonzero(mapping[native_index])
                require(len(candidates) == 1 and mapping[native_index, candidates[0]] == 1, "unchanged neutrino coordinates")
                indices.append(int(candidates[0]))
            monopole_index, dipole_index, quadrupole_index = indices
            density_weight, current_weight, pi_weight = density_row[monopole_index], current_row[dipole_index], pi_row[quadrupole_index]
            require(density_weight > 0 and current_weight > 0 and pi_weight > 0, "positive source weights")
            speed_squared = pi_weight / density_weight
            speed = np.sqrt(speed_squared)
            require(0 < speed_squared < 1, "massive-node speed")
            first_expected = -4 * wave * zrow / 3
            first_expected = first_expected.copy()
            first_expected[dipole_index] -= wave * speed
            second_expected = np.zeros_like(pressure_row)
            second_expected[monopole_index] = wave * speed / 3
            second_expected[quadrupole_index] = -2 * wave * speed / 3
            weight_error = relative(current_weight**2 - density_weight * pi_weight, [current_weight**2, density_weight * pi_weight])
            first_error = relative(matrix[monopole_index] - first_expected, [matrix[monopole_index], first_expected])
            second_error = relative(matrix[dipole_index] - second_expected, [matrix[dipole_index], second_expected])
            node_reports.append(dict(eigen=eigen, node=node, speed=float(speed), weight_identity_error=weight_error, monopole_rhs_error=first_error, dipole_rhs_error=second_error))
            expected_density[monopole_index] = density_weight
            expected_current[dipole_index] = current_weight
            expected_pi[quadrupole_index] = pi_weight
            pressure_row[monopole_index] = pi_weight / 3
            summed_weights += density_weight
    support = {name: relative(actual - expected, [actual, expected]) for name, actual, expected in
               (("density", density_row, expected_density), ("current", current_row, expected_current), ("pi", pi_row, expected_pi))}
    require(max(support.values()) <= ALGEBRA, "source support")
    require(all(max(row["weight_identity_error"], row["monopole_rhs_error"], row["dipole_rhs_error"]) <= ALGEBRA for row in node_reports), "native source coefficients and equations")
    density, current, pressure, anisotropy = [row @ state for row in (expected_density, expected_current, pressure_row, expected_pi)]
    enthalpy = sample["massive_source_enthalpy"]
    density_prime = -hubble * (density + 3 * pressure) + expected_density @ derivative
    current_prime = -2 * hubble * current + expected_current @ derivative
    energy_terms = [density_prime, hubble * (density + 3 * pressure), wave * current, wave * (zrow @ state) * enthalpy]
    momentum_terms = [current_prime, 2 * hubble * current, -wave * pressure, 2 * wave * anisotropy / 3]
    energy, momentum = np.sum(energy_terms), np.sum(momentum_terms)
    actual = energy + 3 * hubble * momentum / wave
    quadrature_enthalpy = 4 * summed_weights / 3
    mismatch = enthalpy - quadrature_enthalpy
    prediction = wave * (zrow @ state) * mismatch
    return dict(node_checks=node_reports, support_errors=support,
                background_enthalpy=float(enthalpy), quadrature_enthalpy=float(quadrature_enthalpy), enthalpy_mismatch=float(mismatch),
                fractional_enthalpy_mismatch=float(mismatch / enthalpy), predicted_budget=float(prediction),
                measured_analytic_budget=float(actual), energy_residual=float(energy), current_residual=float(momentum),
                prediction_error=relative(actual - prediction, [actual, prediction]),
                zero_mismatch_ablation_error=relative(actual, [actual, prediction]),
                momentum_error=relative(momentum, momentum_terms), prediction_term_scale=float(max(abs(term) for term in energy_terms)))


def main():
    with worker("neutrino"):
        require(read(ROOT / "budget-end.json")["state"] == "completed", "completed initial decomposition")
        inputs = preserved()
        require(inputs == read(ROOT / "frozen-inputs.json"), "same source inputs")
        prediction_hash = digest(ROOT / "NEUTRINO-PREDICTION.md")
        proofs = prove()
        reports = []
        measured = read(ROOT / "species-budget.json")["reports"]
        for label, canonical, cases in (("cold", False, ("cold",)), ("heavy", False, ("heavy",)), ("heavy", True, ("D0", "D01"))):
            operator = SpeciesOperators(label, canonical)
            try:
                for enabled in (False, True):
                    operator.enabled = enabled
                    if operator.block is not None:
                        operator.block.enabled = enabled
                    operator.cache.clear()
                    operator.systems.clear()
                    for case in cases:
                        name = case + ("-corrected-" if enabled else "-original-") + ("256" if canonical else "128")
                        with np.load(SOURCE / (name + ".npz")) as packet:
                            history = packet["history"].copy()
                        for index, state in enumerate(history):
                            result = evaluate(operator, index / 8, state)
                            previous = [row for row in measured if row["case"] == case and row["enabled"] == enabled and row["fraction"] == index / 8]
                            result["stencil_budgets"] = {str(row["divisions"]): row["species"]["massive"]["synchronous_budget"] for row in previous}
                            result["stencil_minus_analytic"] = {key: value - result["measured_analytic_budget"] for key, value in result["stencil_budgets"].items()}
                            reports.append(dict(case=case, enabled=enabled, fraction=index / 8, **result))
                        selected = reports[-9:]
                        print(json.dumps(dict(case=case, enabled=enabled, fractional_enthalpy_mismatch=selected[0]["fractional_enthalpy_mismatch"],
                              maximum_prediction_error=max(row["prediction_error"] for row in selected),
                              maximum_analytic_budget=max(abs(row["measured_analytic_budget"]) for row in selected),
                              maximum_stencil_difference=max(abs(value) for row in selected for value in row["stencil_minus_analytic"].values()))), flush=True)
            finally:
                operator.close()
        result = dict(passed=all(row["prediction_error"] <= GATE and row["momentum_error"] <= ALGEBRA for row in reports),
                      identities=proofs, reports=reports, frozen_prediction_sha256=prediction_hash,
                      source_rows_changed=False, new_evolution=False, code_sha256=digest(__file__), model_sha256=digest(ROOT / "budget_model.py"))
        write("neutrino-prediction-result.json", result)
        require(result["passed"], "derived quadrature prediction")


if __name__ == "__main__":
    main()
