from stage_support import *
from diagnostic_model import DiagnosticOperators
from radiation_model import scalar_indices
from bridge_imports import defects, relative
import numpy as np

SPECIES = ("cdm", "baryon", "gamma", "massless", "massive", "slow", "heavy")


class SpeciesOperators(DiagnosticOperators):
    def sample(self, fraction):
        guard()
        result = super().sample(fraction)
        if "cdm_sync_density" in result:
            return result
        system = self.systems[fraction]
        port = self.port
        original = system["observer"].astype(np.longdouble)
        observer = system["full_observer"].astype(np.longdouble)
        background = system["background"].astype(np.longdouble)
        mapping = system["mapping"].astype(np.longdouble)
        columns = port.columns
        wave = port.wave
        hubble = np.longdouble(system["hubble"])
        alpha = system["alpha"].astype(np.longdouble)
        width = len(result["matrix"])
        zero = np.zeros(width, dtype=np.longdouble)
        field_index, velocity_index = scalar_indices(port)
        velocity = original[columns["D_sync"], velocity_index]
        slow_density_native = np.zeros(port.dimension, dtype=np.longdouble)
        slow_density_native[[field_index, velocity_index]] = original[columns["D_sync"], [field_index, velocity_index]]
        slow_current_native = np.zeros(port.dimension, dtype=np.longdouble)
        slow_current_native[field_index] = wave * velocity
        native_heavy_rho = np.longdouble(port.matching_density) / system["scale_factor"] if port.label == "heavy" else np.longdouble(0)
        native_heavy_density = np.zeros(port.dimension, dtype=np.longdouble)
        native_heavy_current = np.zeros(port.dimension, dtype=np.longdouble)
        if port.label == "heavy":
            native_heavy_density[port.selected[0]] = native_heavy_rho
            native_heavy_current[port.selected[1]] = native_heavy_rho
        density = dict(slow=slow_density_native @ mapping, heavy=native_heavy_density @ mapping)
        current = dict(slow=slow_current_native @ mapping, heavy=native_heavy_current @ mapping, cdm=zero.copy())
        enthalpy = dict(slow=velocity**2, heavy=np.longdouble(system["enthalpy"]) if self.block is not None else native_heavy_rho)
        native_massive_current = original[columns["Q_sync"]] - slow_current_native - native_heavy_current
        for species in ("cdm", "baryon", "gamma", "massless", "massive"):
            rho = background[columns["R_" + species]]
            density[species] = rho * observer[columns["delta_" + species + "64"]]
            if species in ("cdm", "baryon"):
                enthalpy[species] = rho
            elif species in ("gamma", "massless"):
                enthalpy[species] = 4 * rho / 3
                current[species] = rho * observer[columns["q_" + species + "64"]]
                native_massive_current -= rho * original[columns["q_" + species + "64"]]
            if species == "baryon":
                current[species] = rho * observer[columns["v_baryon64"]]
                native_massive_current -= rho * original[columns["v_baryon64"]]
        current["massive"] = native_massive_current @ mapping
        enthalpy["massive"] = np.longdouble(result["enthalpy"]) - sum(enthalpy.values())
        require(enthalpy["massive"] > 0, "positive massive-neutrino enthalpy")
        for species in SPECIES:
            result[species + "_sync_density"] = density[species]
            result[species + "_sync_current"] = current[species]
            result[species + "_source_enthalpy"] = np.array(enthalpy[species])
            result[species + "_source_density"] = density[species] - 3 * hubble * enthalpy[species] * alpha
            result[species + "_source_current"] = current[species] + wave * enthalpy[species] * alpha
            result[species + "_source_pi"] = result["anisotropy"].astype(np.longdouble) if species == "massive" else zero.copy()
        result["clock_alpha"] = alpha
        result["sync_eta"] = system["eta"].astype(np.longdouble)
        result["sync_z"] = (observer[columns["D_sync"]] / (2 * wave) + wave * result["sync_eta"]) / hubble
        result["baryon_pressure_sync"] = background[columns["R_baryon"]] * observer[columns["delta_p_b"]]
        result["baryon_exchange"] = -result["gamma_drag"].astype(np.longdouble)
        result["baryon_rho"] = np.array(background[columns["R_baryon"]])
        result["cdm_rho"] = np.array(background[columns["R_cdm"]])
        result["baryon_delta"] = observer[columns["delta_baryon64"]]
        result["cdm_delta"] = observer[columns["delta_cdm64"]]
        result["baryon_velocity"] = observer[columns["v_baryon64"]]
        return result


def diagnose(operator, jets, state):
    state = state.astype(np.longdouble)
    derivative = jets["matrix"][0] @ state
    value = lambda name: jets[name][0] @ state
    rate = lambda name: jets[name][1] @ state + jets[name][0] @ derivative
    hubble, hubble_prime = jets["hubble"][:2]
    wave = operator.port.wave
    alpha, eta = value("clock_alpha"), value("sync_eta")
    alpha_prime, eta_prime = rate("clock_alpha"), rate("sync_eta")
    phi_prime, psi, zvalue = rate("phi"), value("psi"), value("sync_z")
    clock_defect = alpha_prime + hubble * alpha - psi
    eta_defect = eta_prime - wave * (wave * alpha - zvalue) / 3
    background_defect = hubble_prime - hubble**2 + jets["enthalpy"][0] / 2
    species_rows = {}
    totals = dict(density=np.longdouble(0), current=np.longdouble(0), pi=np.longdouble(0), enthalpy=np.longdouble(0), newtonian=np.longdouble(0), synchronous=np.longdouble(0), gauge=np.longdouble(0))
    for species in SPECIES:
        density, current, pi = [value(species + "_source_" + name) for name in ("density", "current", "pi")]
        enthalpy = jets[species + "_source_enthalpy"][0]
        density_prime, current_prime = [rate(species + "_source_" + name) for name in ("density", "current")]
        newtonian_terms = [density_prime, hubble * density, wave * current, -3 * enthalpy * phi_prime,
                          3 * hubble * current_prime / wave, 6 * hubble**2 * current / wave, -3 * hubble * enthalpy * psi, 2 * hubble * pi]
        sync_density, sync_current = [value(species + "_sync_" + name) for name in ("density", "current")]
        sync_density_prime, sync_current_prime = [rate(species + "_sync_" + name) for name in ("density", "current")]
        synchronous_terms = [sync_density_prime, hubble * sync_density, wave * sync_current, wave * zvalue * enthalpy,
                            3 * hubble * sync_current_prime / wave, 6 * hubble**2 * sync_current / wave, 2 * hubble * pi]
        newtonian, synchronous = np.sum(newtonian_terms), np.sum(synchronous_terms)
        gauge = 3 * hubble * enthalpy * clock_defect - 3 * enthalpy * eta_defect
        species_rows[species] = dict(newtonian_budget=float(newtonian), synchronous_budget=float(synchronous), gauge_transport=float(gauge),
                                     gauge_identity_error=relative(newtonian - synchronous - gauge, newtonian_terms + synchronous_terms),
                                     synchronous_term_scale=float(max(abs(term) for term in synchronous_terms)))
        for name, entry in (("density", density), ("current", current), ("pi", pi), ("enthalpy", enthalpy),
                            ("newtonian", newtonian), ("synchronous", synchronous), ("gauge", gauge)):
            totals[name] += entry
    metrics = defects(operator, jets, state)
    background_transport = 3 * background_defect * value("current") / wave
    total_prediction = totals["synchronous"] + totals["gauge"] + background_transport
    source_matches = {name: relative(totals[name] - value(name if name != "pi" else "anisotropy"), [totals[name], value(name if name != "pi" else "anisotropy")]) for name in ("density", "current", "pi")}
    source_matches["enthalpy"] = float(abs(totals["enthalpy"] - jets["enthalpy"][0]) / jets["enthalpy"][0])
    pressure_budget = 3 * hubble * value("baryon_pressure_sync")
    exchange_budget = 3 * hubble * value("baryon_exchange") / wave
    baryon_native_rate = -hubble * value("baryon_sync_density") + jets["baryon_rho"][0] * (jets["baryon_delta"][0] @ derivative)
    cdm_native_rate = -hubble * value("cdm_sync_density") + jets["cdm_rho"][0] * (jets["cdm_delta"][0] @ derivative)
    baryon_current_rate = -hubble * value("baryon_sync_current") + jets["baryon_rho"][0] * (jets["baryon_velocity"][0] @ derivative)
    baryon_exact = baryon_native_rate + hubble * value("baryon_sync_density") + wave * value("baryon_sync_current") + wave * zvalue * jets["baryon_rho"][0] + 3 * hubble * baryon_current_rate / wave + 6 * hubble**2 * value("baryon_sync_current") / wave
    cdm_exact = cdm_native_rate + hubble * value("cdm_sync_density") + wave * zvalue * jets["cdm_rho"][0]
    return dict(metrics=metrics, species=species_rows, source_sum_errors=source_matches,
                total_prediction=float(total_prediction), total_budget_identity_error=relative(total_prediction - metrics["total_budget"], [row["synchronous_term_scale"] for row in species_rows.values()]),
                background_transport=float(background_transport), clock_defect=float(clock_defect), eta_defect=float(eta_defect),
                baryon_pressure_budget=float(pressure_budget), baryon_exchange_budget=float(exchange_budget),
                baryon_analytic_budget=float(baryon_exact), baryon_analytic_prediction_error=relative(baryon_exact - pressure_budget - exchange_budget, [pressure_budget, exchange_budget, baryon_exact]),
                baryon_stencil_error=float(species_rows["baryon"]["synchronous_budget"] - baryon_exact),
                cdm_analytic_budget=float(cdm_exact), cdm_stencil_error=float(species_rows["cdm"]["synchronous_budget"] - cdm_exact))
