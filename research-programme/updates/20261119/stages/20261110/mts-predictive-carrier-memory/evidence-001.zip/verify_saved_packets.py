from memory_model import *


with worker('packet-audit'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks={}
    source_hashes={str(Path(__file__)):digest(Path(__file__))}
    weights=packet(PROJECTION/'frozen-projection.npz')['weights']
    for case in ('cold','heavy'):
        for window in ('live','extraction'):
            label=case+'-'+window
            projections={}
            for config in read(ROOT/'contract.json')['configs']:
                name=config['name']
                path=ROOT/(label+'-'+name+'.npz')
                data=packet(path)
                report_path=ROOT/(label+'-'+name+'-result.json')
                report=read(report_path)
                require(digest(path)==report['packet_sha256'],'packet checksum')
                require(all(np.all(np.isfinite(value)) for value in data.values()),'finite packet contents')
                evolution=MemoryEvolution(case,window,config['stride'])
                require(np.array_equal(data['clock'],evolution.history.times),'original clock')
                require(np.array_equal(data['solution'][0],data['initial']),'frozen exact initial sample')
                require(np.array_equal(data['initial'],np.array(read(ROOT/'initials.json')[label]['state'])),'pre-run initial freeze')
                if case=='heavy':
                    require(np.array_equal(data['initial'][2:],np.zeros(6)),'no fitted correction initial state')
                regenerated=readouts(evolution,data['solution'])
                for key in ('primitive','physical','uncorrected_primitive','uncorrected_physical'):
                    checks[label+'/'+name+'/'+key]=columns(regenerated[key],data[key],'component_',ALGEBRA)
                if window=='extraction':
                    projections[name]=weights@data['physical']
                    checks[label+'/'+name+'/projected-report']={'projection':comparison(projections[name],np.array(report['projection']['prediction']),ALGEBRA)}
                source_hashes[str(path)]=digest(path)
                source_hashes[str(report_path)]=digest(report_path)
            if window=='extraction':
                for name in ('dense-step1','sparse-step2'):
                    checks[label+'/'+name+'/projected-refinement']=columns(projections[name][None,:],projections['dense-step2'][None,:],'component_')
    check_hashes(source_hashes)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(all_pass(checks),'independent saved readout and signed projection audit')
    write('packet-audit.json',dict(passed=True,checks=checks,count=sum(len(rows) for rows in checks.values()),input_hashes=source_hashes))
    print(json.dumps(dict(passed=True,checks=sum(len(rows) for rows in checks.values()))),flush=True)
