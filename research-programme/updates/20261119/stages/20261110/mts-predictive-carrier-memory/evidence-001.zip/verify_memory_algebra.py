from memory_support import *
import sympy as symbolic


with worker('algebra'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    base=symbolic.Matrix(2,2,symbolic.symbols('base0:4'))
    remainder=symbolic.Matrix(2,2,symbolic.symbols('remainder0:4'))
    state=symbolic.Matrix(symbolic.symbols('state0:2'))
    correction=symbolic.Matrix(symbolic.symbols('correction0:2'))
    error=symbolic.Matrix(symbolic.symbols('error0:2'))
    force=symbolic.Matrix(symbolic.symbols('force0:2'))
    force_remainder=symbolic.Matrix(symbolic.symbols('force_remainder0:2'))
    state_rate=base*state+force
    correction_rate=base*correction+remainder*state+force_remainder
    predicted_rate=(base+remainder)*(state+correction)+force+force_remainder-remainder*correction
    error_rate=(base+remainder)*(state+correction+error)+force+force_remainder-predicted_rate
    identities={}
    for label,expression in (('corrected_equation',state_rate+correction_rate-predicted_rate),('error_equation',error_rate-(base+remainder)*error-remainder*correction)):
        for index,entry in enumerate(expression):
            identities[label+'_'+str(index)]=str(symbolic.expand(entry))
    require(all(value=='0' for value in identities.values()),'exact predictive-memory identities')
    write('algebra.json',dict(passed=True,identities=identities,count=len(identities),assumptions='linear affine conditional equation; matrices time dependent and not assumed commuting',script_sha256=digest(Path(__file__))))
    print(json.dumps(dict(passed=True,identities=len(identities))),flush=True)
