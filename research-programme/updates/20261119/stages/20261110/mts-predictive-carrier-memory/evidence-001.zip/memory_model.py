from memory_support import *


def coefficients(values):
    transform=values['transform'][:2,:2]
    transform_prime=values['transform_prime'][:2,:2]
    source_column=values['transform'][:2,2]
    source_column_prime=values['transform_prime'][:2,2]
    mapping=values['mapping']
    normal_operator=np.linalg.solve(mapping.T,(values['mapping_prime']+mapping@values['operator']).T).T
    exact_operator=np.linalg.solve(transform,normal_operator@transform-transform_prime)
    exact_force=np.linalg.solve(transform,(normal_operator@source_column-source_column_prime)*values['rest']+mapping@values['force']-source_column*values['rest_prime'])
    return exact_operator,exact_force,exact_operator-values['generator'],exact_force-values['forcing']


class MemoryEvolution:
    def __init__(self,case,window,stride):
        self.history=History(case,window,stride)
        self.case=case

    def initial(self):
        initial=self.history.initial()
        if self.case=='cold':
            return initial
        return np.r_[initial[2:4],np.zeros(6)]

    def rhs(self,time,state):
        values=self.history.evaluate(time)
        if self.case=='cold':
            return values['operator']@state+values['force']
        exact_operator,exact_force,remainder,forcing_remainder=coefficients(values)
        reduced=state[:2]
        correction=state[2:4]
        error_transport=state[4:6]
        envelope=state[6:8]
        reduced_rate=values['generator']@reduced+values['forcing']
        correction_rate=values['generator']@correction+remainder@reduced+forcing_remainder
        remaining_source=remainder@correction
        error_rate=exact_operator@error_transport+remaining_source
        majorant=abs(exact_operator)
        np.fill_diagonal(majorant,np.diag(exact_operator))
        envelope_rate=majorant@envelope+abs(remaining_source)
        return np.r_[reduced_rate,correction_rate,error_rate,envelope_rate]


def readouts(evolution,solution):
    history=evolution.history
    if evolution.case=='cold':
        physical=np.column_stack([solution[:,0],np.zeros((len(solution),2))])
        return dict(primitive=solution.copy(),physical=physical,uncorrected_primitive=solution.copy(),uncorrected_physical=physical.copy())
    output={key:[] for key in ('primitive','physical','uncorrected_primitive','uncorrected_physical','corrected_reduced','remaining_source','transport_reconstructed','physical_envelope')}
    for time,state in zip(history.times,solution):
        values=history.evaluate(float(time))
        corrected=state[:2]+state[2:4]
        for key,reduced in (('',corrected),('uncorrected_',state[:2])):
            primitive=np.linalg.solve(values['mapping'],(values['transform']@np.r_[reduced,values['rest']])[:2])
            output[key+'primitive'].append(primitive)
            output[key+'physical'].append(values['physical_readout']@primitive)
        remainder=coefficients(values)[2]
        conversion=np.linalg.solve(values['mapping'],values['transform'][:2,:2])
        output['corrected_reduced'].append(corrected)
        output['remaining_source'].append(remainder@state[2:4])
        output['transport_reconstructed'].append(corrected+state[4:6])
        output['physical_envelope'].append(abs(values['physical_readout']@conversion)@state[6:8])
    return {key:np.array(value) for key,value in output.items()}
