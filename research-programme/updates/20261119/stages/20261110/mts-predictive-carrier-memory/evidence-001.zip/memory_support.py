import sys
from pathlib import Path
from time import monotonic

CARRIER=Path(__file__).resolve().parent.parent/'mts-carrier-finite-time-propagation-20261110'
sys.path.insert(0,str(CARRIER))
import prop_model as retained_model
from prop_model import *

ROOT=Path(__file__).resolve().parent
CARRIER=ROOT.parent/'mts-carrier-finite-time-propagation-20261110'
EXPECTED_CARRIER='4324fac80043dd27766be769eb252248236aa4e09ee850df3d73c20f6d532f21'
retained_model.phase_module.retained.shared.ROOT=ROOT
retained_model.phase_module.retained.shared.START=monotonic()
base_guard=retained_model.guard
last_check=[-float('inf')]


def guard():
    current=monotonic()
    if current-last_check[0]>=1:
        base_guard()
        require(not (CARRIER/'STOP-REQUESTED').exists(),'owner hold '+str(CARRIER))
        last_check[0]=current


retained_model.guard=guard


def reference_path(case,window):
    suffix='dense-step2-segmented' if window=='extraction' else 'dense-step2'
    return CARRIER/(case+'-'+window+'-'+suffix+'.npz')
