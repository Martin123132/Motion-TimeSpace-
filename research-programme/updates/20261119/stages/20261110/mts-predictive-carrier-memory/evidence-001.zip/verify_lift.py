from memory_support import *
import sympy as symbolic


def matrix(prefix,rows,columns):
    return symbolic.Matrix(rows,columns,symbolic.symbols(prefix+'0:'+str(rows*columns)))


with worker('lift-algebra'):
    heavy=matrix('heavy',2,2)
    source=matrix('source',2,1)
    readout=matrix('readout',1,2)
    readout_prime=matrix('readout_prime',1,2)
    coupling=matrix('coupling',2,2)
    rest=matrix('rest',2,2)
    transform=matrix('transform',2,2)
    transform_prime=matrix('transform_prime',2,2)
    column=matrix('column',2,1)
    column_prime=matrix('column_prime',2,1)
    base=matrix('base',2,2)
    base_source=matrix('base_source',2,1)
    state=matrix('state',2,1)
    rest_state=matrix('rest_state',2,1)
    inverse=transform.inv()
    transformed_coupling=coupling*transform
    transformed_rest=rest+coupling*column*readout
    source_heavy=readout*transformed_coupling
    source_rest=readout_prime+readout*transformed_rest
    exact_heavy=inverse*(heavy*transform-transform_prime-column*source_heavy)
    exact_rest=inverse*((heavy*column+source-column_prime)*readout-column*source_rest)
    effective_heavy=base-inverse*column*source_heavy
    effective_rest=base_source*readout-inverse*column*source_rest
    coordinate_rate=exact_heavy*state+exact_rest*rest_state
    rest_rate=transformed_coupling*state+transformed_rest*rest_state
    source_rate=source_heavy*state+source_rest*rest_state
    physical=transform*state+column*readout*rest_state
    identities={}
    expressions={
        'heavy_chain':transform*coordinate_rate+transform_prime*state+column_prime*readout*rest_state+column*source_rate-heavy*physical-source*readout*rest_state,
        'rest_chain':rest_rate-coupling*physical-rest*rest_state,
        'source_chain':source_rate-readout_prime*rest_state-readout*rest_rate,
        'remainder_heavy':exact_heavy-effective_heavy-(inverse*(heavy*transform-transform_prime)-base),
        'remainder_rest':exact_rest-effective_rest-(inverse*(heavy*column+source-column_prime)-base_source)*readout,
    }
    for label,expression in expressions.items():
        for index,entry in enumerate(expression):
            guard()
            identities[label+'_'+str(index)]=str(symbolic.cancel(symbolic.expand(entry)))
    require(all(value=='0' for value in identities.values()),'exact block-lift identities')
    write('lift-algebra.json',dict(passed=True,count=len(identities),identities=identities,scope='generic 2-heavy/2-rest symbolic block control; does not verify native full-system closure',assumptions=['invertible T','fixed-background linear perturbation system','current source L*r'],script_sha256=digest(Path(__file__))))
    print(json.dumps(dict(passed=True,identities=len(identities),native_full_system_executed=False)),flush=True)
