import argparse
from memory_model import *
from scipy.integrate import solve_ivp


def freeze():
    require(digest(CARRIER/'closeout.json')==EXPECTED_CARRIER,'verified carrier checkpoint')
    previous=read(CARRIER/'closeout.json')
    check_hashes(previous['input_hashes'])
    check_hashes({str(CARRIER/name):row['sha256'] for name,row in previous['artifacts'].items()})
    cleanup=read(CARRIER/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and not cleanup['verifier_exit_requires_final_external_check'],'previous workers closed')
    require(exited(cleanup['verifier_identity'])['exited'],'previous verifier absent')
    checks={}
    initials={}
    for case in ('cold','heavy'):
        for window in ('live','extraction'):
            label=case+'-'+window
            evolution=MemoryEvolution(case,window,1)
            history=evolution.history
            initial=evolution.initial()
            initials[label]=dict(time=float(history.times[0]),state=initial)
            if case=='cold':
                checks[label]={'initial':comparison(initial,np.array(read(CARRIER/'initials.json')[label]['state']),ALGEBRA)}
                continue
            indices=np.unique(np.linspace(0,len(history.times)-2,5,dtype=int))
            times=np.r_[history.times[indices],(history.times[indices]+history.times[indices+1])/2,history.times[-1]]
            for index,time in enumerate(times):
                values=history.evaluate(float(time))
                require(np.array_equal(values['transform'][2],np.array([0.,0.,1.])),'triangular augmented map')
                exact_operator,exact_force,remainder,forcing_remainder=coefficients(values)
                for vector_index,primitive in enumerate((np.array([1.,0.]),np.array([0.,1.]),np.array([.037,-.21]),np.zeros(2))):
                    reduced=history.reduced_state(values,primitive)
                    primitive_rate=values['operator']@primitive+values['force']
                    chain=history.exact_reduced_rate(values,primitive,primitive_rate,reduced)
                    checks[label+'/'+str(index)+'/'+str(vector_index)]={'coefficient_chain':comparison(exact_operator@reduced+exact_force,chain,ALGEBRA)}
                state=initial.copy()
                state[2:4]=np.array([.002,-.003])
                original=evolution.rhs(float(time),state)
                changed=state.copy()
                changed[4:]+=np.array([.1,-.2,.3,-.4])
                mutated=evolution.rhs(float(time),changed)
                corrected=state[:2]+state[2:4]
                predicted_rate=exact_operator@corrected+exact_force-remainder@state[2:4]
                checks[label+'/'+str(index)+'/memory']={'equation':comparison(original[:2]+original[2:4],predicted_rate,ALGEBRA),'diagnostic_independence':comparison(original[:4],mutated[:4],ALGEBRA)}
            time=float(times[len(times)//2])
            before=evolution.rhs(time,initial)
            originals={name:history.saved[name].copy() for name in ('vector','derivative')}
            original_physical=history.normal['physical'].copy()
            for name in originals:
                history.saved[name]+=123.
            history.normal['physical']-=456.
            after=evolution.rhs(time,initial)
            checks[label+'/comparator-mutation']={'forward':comparison(after[:4],before[:4],ALGEBRA)}
            for name,value in originals.items():
                history.saved[name][...]=value
            history.normal['physical'][...]=original_physical
            require(np.array_equal(initial[2:],np.zeros(6)),'zero correction and diagnostic initial values')
    require(all_pass(checks),'preflight coefficient and independence identities')
    sources=dict(previous['input_hashes'])
    sources.update({str(CARRIER/name):row['sha256'] for name,row in previous['artifacts'].items()})
    for path in (CARRIER/'closeout.json',CARRIER/'CLEANUP-VERIFIED.json',ROOT/'PROTOCOL.md',*sorted(ROOT.glob('*.py'))):
        sources[str(path)]=digest(path)
    for module in tuple(sys.modules.values()):
        path=Path(getattr(module,'__file__','') or '')
        if path.is_file() and path.suffix=='.py' and POST in path.parents:
            sources[str(path)]=digest(path)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write('preflight.json',dict(passed=True,checks=checks,count=sum(len(group) for group in checks.values()),no_comparator_state_in_rhs=True))
    write('initials.json',initials)
    write('frozen-inputs.json',sources)
    write('contract.json',dict(previous_turn='progress',previous_seal=EXPECTED_CARRIER,configs=[dict(name='dense-step1',stride=1,step_divisor=1),dict(name='dense-step2',stride=1,step_divisor=2),dict(name='sparse-step2',stride=2,step_divisor=2)],integration=dict(method='DOP853',rtol=1e-10,atol=1e-12,history_knot_stops=True),gates=[GATE,ALGEBRA],physical_grid_or_parameters_changed=False,rest_history_prescribed=True,full_live_feedback=False,initials_sha256=digest(ROOT/'initials.json')))
    print(json.dumps(dict(frozen=True,preflight_checks=sum(len(group) for group in checks.values()),inputs=len(sources))),flush=True)


def selected_reference(case,window,config):
    if config=='dense-step2':
        return reference_path(case,window)
    return CARRIER/(case+'-'+window+'-'+config+'.npz')


def score(evolution,data,config):
    history=evolution.history
    case=evolution.case
    window=history.window
    reference=packet(selected_reference(case,window,config))
    require(np.array_equal(data['clock'],reference['clock']),'same saved reference grid')
    native=history.saved['vector'][:,history.first+2:history.first+4] if case=='heavy' else history.original_density[:,None]
    native_physical=history.normal['physical'] if case=='heavy' else np.column_stack([history.original_density,np.zeros((len(history.times),2))])
    candidate=dict(primitive=columns(data['primitive'],native,'component_'),physical=columns(data['physical'],native_physical,'component_'),conditional_primitive=columns(data['primitive'],reference['exact'],'component_'),conditional_physical=columns(data['physical'],reference['exact_physical'],'component_'))
    numerical=dict(uncorrected_replay=columns(data['uncorrected_primitive'],reference['predicted'],'component_'),uncorrected_stress_replay=columns(data['uncorrected_physical'],reference['predicted_physical'],'component_'))
    report=dict(candidate=candidate,numerical=numerical,final_physical=columns(data['physical'][-1:],native_physical[-1:],'component_'),reference_path=str(selected_reference(case,window,config)))
    if case=='heavy':
        numerical['error_transport']=columns(data['transport_reconstructed'],reference['exact_reduced'],'component_',ALGEBRA)
        observed_error=abs(reference['exact_reduced']-data['corrected_reduced'])
        allowance=ALGEBRA*np.maximum(np.max(abs(reference['exact_reduced']),axis=0),1e-300)
        bound=data['solution'][:,6:8]
        report['error_transport']=dict(encloses_sampled_error=bool(np.all(observed_error<=bound+allowance) and np.min(bound)>=-np.max(allowance)),final_measured=reference['exact_reduced'][-1]-data['corrected_reduced'][-1],final_transport=data['solution'][-1,4:6],final_envelope=bound[-1],certified_continuum_bound=False)
    if window=='extraction':
        weights=packet(PROJECTION/'frozen-projection.npz')['weights']
        target=weights@native_physical
        prediction=weights@data['physical']
        report['projection']=dict(reference=target,prediction=prediction,uncorrected=weights@data['uncorrected_physical'],checks=columns(prediction[None,:],target[None,:],'component_'),original_signed_weights=True)
    report['numerical_checks_passed']=all_pass(numerical)
    report['candidate_pointwise_passed']=all_pass(candidate)
    return report


def run(case,window,config_name):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'preflight.json')['passed'],'preflight passed')
    contract=read(ROOT/'contract.json')
    require(digest(ROOT/'initials.json')==contract['initials_sha256'],'frozen initial file')
    config=next(row for row in contract['configs'] if row['name']==config_name)
    evolution=MemoryEvolution(case,window,config['stride'])
    history=evolution.history
    initial=evolution.initial()
    require(comparison(initial,np.array(read(ROOT/'initials.json')[case+'-'+window]['state']),ALGEBRA)['passed'],'initial frozen before propagation')
    initial_rate=evolution.rhs(float(history.times[0]),initial)
    normalization=np.maximum(abs(initial),abs(initial_rate)*(history.times[-1]-history.times[0]))
    if case=='heavy':
        for offset in (2,4,6):
            normalization[offset:offset+2]=normalization[:2]
    normalization[normalization==0]=1.
    def rhs(time,normalized):
        return evolution.rhs(time,normalized*normalization)/normalization
    maximum_step=float(np.min(np.diff(history.times)))/config['step_divisor']
    state=initial/normalization
    saved=[initial.copy()]
    evaluations=0
    for left,right in zip(history.times[:-1],history.times[1:]):
        guard()
        solution=solve_ivp(rhs,(left,right),state,method='DOP853',rtol=1e-10,atol=1e-12,max_step=maximum_step,t_eval=[right])
        require(solution.success,'completed original interval')
        state=solution.y[:,-1]
        saved.append(state*normalization)
        evaluations+=solution.nfev
    states=np.array(saved)
    data=readouts(evolution,states)
    data.update(clock=history.times,solution=states,normalization=normalization,initial=initial,selected_history_nodes=history.selected)
    require(all(np.all(np.isfinite(value)) for value in data.values()),'finite packet')
    report=score(evolution,data,config_name)
    name=case+'-'+window+'-'+config_name
    path=ROOT/(name+'.npz')
    require(not path.exists(),'never overwrite a completed packet')
    np.savez_compressed(path,**data)
    report.update(completed=True,packet_sha256=digest(path),nfev=evaluations,maximum_step=maximum_step)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write(name+'-result.json',report)
    print(json.dumps(dict(name=name,numerical=report['numerical_checks_passed'],pointwise=report['candidate_pointwise_passed'],projection=report.get('projection'),error_transport=report.get('error_transport'),nfev=evaluations),default=convert),flush=True)


def verify():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks={}
    projection={}
    reports={}
    envelopes={}
    for case in ('cold','heavy'):
        for window in ('live','extraction'):
            label=case+'-'+window
            packets={}
            for config in read(ROOT/'contract.json')['configs']:
                name=config['name']
                path=ROOT/(label+'-'+name+'.npz')
                report=read(ROOT/(label+'-'+name+'-result.json'))
                require(report['completed'] and digest(path)==report['packet_sha256'],'complete unchanged packet')
                packets[name]=packet(path)
                for group,rows in report['numerical'].items():
                    checks[label+'/'+name+'/'+group]=rows
                reports[label+'/'+name]=report
                if window=='extraction':
                    projection[label+'/'+name]=report['projection']['checks']
            fine=packets['dense-step2']
            for name in ('dense-step1','sparse-step2'):
                require(np.array_equal(packets[name]['clock'],fine['clock']),'fixed output grid')
                for key in ('primitive','physical','uncorrected_primitive','uncorrected_physical'):
                    checks[label+'/'+name+'/'+key]=columns(packets[name][key],fine[key],'component_')
                if case=='heavy':
                    envelopes[label+'/'+name]=columns(packets[name]['solution'][:,6:8],fine['solution'][:,6:8],'component_')
            if case=='heavy':
                evolution=MemoryEvolution(case,window,1)
                for index in (0,len(fine['clock'])//2,len(fine['clock'])-1):
                    state=fine['solution'][index].copy()
                    original=evolution.rhs(float(fine['clock'][index]),state)
                    state[4:]+=np.array([.17,-.03,.41,.05])
                    changed=evolution.rhs(float(fine['clock'][index]),state)
                    checks[label+'/mutation/'+str(index)]={'independent_forward':comparison(changed[:4],original[:4],ALGEBRA)}
    numerical=all_pass(checks)
    pointwise=all(report['candidate_pointwise_passed'] for report in reports.values())
    projected=all_pass(projection)
    write('validation.json',dict(numerical_checks_passed=numerical,checks=checks,count=sum(len(rows) for rows in checks.values()),all_candidate_pointwise_passed=pointwise,all_candidate_projections_passed=projected,projections=projection,envelope_refinements=envelopes,envelope_values_converged=all_pass(envelopes),certified_continuum_bound=False,full_live_feedback=False,old_late_model_replaced=False))
    print(json.dumps(dict(numerical=numerical,pointwise=pointwise,projections=projected,checks=sum(len(rows) for rows in checks.values()),envelope_values_converged=all_pass(envelopes))),flush=True)


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['numerical_checks_passed'],'numerical checks')
    require((ROOT/'RESULTS.md').is_file() and (ROOT/'NEXT.md').is_file(),'saved result and next step')
    excluded={'closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json'}
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write('closeout.json',dict(conditional_predictive_memory_test_completed=True,no_comparator_state_in_forward_rhs=True,full_live_feedback=False,old_late_model_replaced=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='postseal-start.json':
            continue
        owner=read(path)
        ending=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(owner)
        require(outcome['exited'] and ending['state']=='completed','worker completed and exited')
        require(all(ending[key]==owner[key] for key in ('pid','created','command')),'matching worker identity')
        workers.append(dict(name=path.stem,identity=owner,outcome=outcome))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('freeze','run','verify','seal','postseal'))
    parser.add_argument('--case',choices=('cold','heavy'))
    parser.add_argument('--window',choices=('live','extraction'))
    parser.add_argument('--config',choices=('dense-step1','dense-step2','sparse-step2'))
    arguments=parser.parse_args()
    label='-'.join((arguments.case,arguments.window,arguments.config)) if arguments.operation=='run' else arguments.operation
    with worker(label) as identity:
        if arguments.operation=='run':
            run(arguments.case,arguments.window,arguments.config)
        elif arguments.operation=='postseal':
            postseal(identity)
        else:
            globals()[arguments.operation]()
