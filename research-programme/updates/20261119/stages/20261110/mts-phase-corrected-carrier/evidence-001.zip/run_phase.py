from phase_model import *
import argparse


def freeze():
    require(digest(NORMAL/'closeout.json')==EXPECTED_NORMAL,'verified normal-form predecessor')
    previous=read(NORMAL/'closeout.json')
    check_hashes(previous['input_hashes'])
    check_hashes({str(NORMAL/name):row['sha256'] for name,row in previous['artifacts'].items()})
    paths=[NORMAL/'closeout.json',NORMAL/'CLEANUP-VERIFIED.json',NORMAL/'normal_support.py',LIVE/'live_support.py',PROJECTION/'frozen-projection.npz',MEMORY/'closeout.json']
    for case in ('cold','heavy'):
        for window in ('extraction','live'):
            paths.extend([input_path(case,window),NORMAL/(case+'-'+window+'.npz')])
            if case=='heavy':
                paths.append(NORMAL/(case+'-'+window+'-operators.npz'))
                for variant in ('fine8','degree7'):
                    path=memory_path(case,window,variant)
                    require(digest(path)==read(MEMORY/'closeout.json')['artifacts'][path.name]['sha256'],'verified saved metric derivative packet')
                    paths.append(path)
    paths.extend(sorted(ROOT.glob('*.py')))
    paths.append(ROOT/'PROTOCOL.md')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write('frozen-inputs.json',{str(path):digest(path) for path in paths})
    write('contract.json',dict(previous_turn='progress',previous_seal=EXPECTED_NORMAL,wave=1.,gates=[GATE,ALGEBRA],complex_steps=[1e-20,1e-24],angular_orders=[32,64],phase_offset=.371,periodic_integration_steps=[128,256],periodic_rtol=1e-10,periodic_atol=1e-12,paired_saved_windows=['extraction','live'],heavy_metric_variants=['fine8','degree7','native_for_live_only'],no_physical_parameters_or_grids_changed=True,physical_live_reintegration=False,acceptance='exact identities, representation and refinements; averaged-approximation failures stay explicit',no_assumed_occupation=True))
    print(json.dumps(dict(frozen=True,inputs=len(paths))),flush=True)


def derive():
    import sympy as symbolic_math
    check_hashes(read(ROOT/'frozen-inputs.json'))
    field,velocity,mass,hubble,rate,beta,field_error,velocity_error=symbolic_math.symbols('b v mu H r beta Ef Eb',real=True)
    amplitude2=field**2+velocity**2/mass**2
    field_prime=velocity+field_error
    velocity_prime=-2*hubble*velocity-mass**2*field+velocity_error
    phase_direct=(field*(-velocity_prime/mass+rate*velocity/mass)+(velocity/mass)*field_prime)/amplitude2
    phase_expected=mass+(2*hubble+rate)*field*velocity/(mass*amplitude2)+(velocity*field_error-field*velocity_error)/(mass*amplitude2)
    energy=beta*(velocity**2+mass**2*field**2)/2
    energy_direct=rate*energy+beta*(velocity*velocity_prime+mass**2*field*field_prime+rate*mass**2*field**2)
    double_cosine=(field**2-velocity**2/mass**2)/amplitude2
    energy_expected=energy*(2*(rate-hubble)+(2*hubble+rate)*double_cosine)+beta*(velocity*velocity_error+mass**2*field*field_error)
    amplitude_prime=2*field*field_prime+2*velocity*velocity_prime/mass**2-2*rate*velocity**2/mass**2
    amplitude_expected=-(4*hubble+2*rate)*velocity**2/mass**2+2*field*field_error+2*velocity*velocity_error/mass**2
    checks=dict(phase_speed=symbolic_math.simplify(phase_direct-phase_expected)==0,energy_flow=symbolic_math.simplify(energy_direct-energy_expected)==0,amplitude_flow=symbolic_math.simplify(amplitude_prime-amplitude_expected)==0)
    angle=symbolic_math.symbols('theta',real=True)
    cosine2,sine2,cosine4,sine4,energy_symbol,sine_energy,sine_hubble=symbolic_math.symbols('C2 S2 C4 S4 E dS2dE dS2dH',real=True)
    primitive=(cosine2*symbolic_math.sin(2*angle)-sine2*symbolic_math.cos(2*angle))/(2*mass)+(cosine4*symbolic_math.sin(4*angle)-sine4*symbolic_math.cos(4*angle))/(4*mass)
    oscillation=cosine2*symbolic_math.cos(2*angle)+sine2*symbolic_math.sin(2*angle)+cosine4*symbolic_math.cos(4*angle)+sine4*symbolic_math.sin(4*angle)
    checks['homological_equation']=symbolic_math.simplify(mass*symbolic_math.diff(primitive,angle)-oscillation)==0
    checks['zero_mean_micromotion']=symbolic_math.integrate(primitive,(angle,0,2*symbolic_math.pi))==0
    drift=-3*hubble*symbolic_math.sin(2*angle)*symbolic_math.diff(primitive,angle)/2-3*hubble*energy_symbol*symbolic_math.cos(2*angle)*sine_energy*symbolic_math.cos(2*angle)/(2*mass)-energy_symbol*symbolic_math.cos(2*angle)*sine_hubble*symbolic_math.cos(2*angle)/(4*beta*mass)
    expected_drift=-3*hubble*(sine2+energy_symbol*sine_energy)/(4*mass)-energy_symbol*sine_hubble/(8*beta*mass)
    checks['averaged_phase_and_parameter_drift']=symbolic_math.simplify(symbolic_math.integrate(drift,(angle,0,2*symbolic_math.pi))/(2*symbolic_math.pi)-expected_drift)==0
    for first_harmonic in (2,4):
        for second_harmonic in (2,4):
            expected=symbolic_math.pi if first_harmonic==second_harmonic else 0
            checks['cosine_orthogonality_'+str(first_harmonic)+'_'+str(second_harmonic)]=symbolic_math.integrate(symbolic_math.cos(first_harmonic*angle)*symbolic_math.cos(second_harmonic*angle),(angle,0,2*symbolic_math.pi))==expected
            checks['sine_cosine_orthogonality_'+str(first_harmonic)+'_'+str(second_harmonic)]=symbolic_math.integrate(symbolic_math.sin(first_harmonic*angle)*symbolic_math.cos(second_harmonic*angle),(angle,0,2*symbolic_math.pi))==0
    require(all(checks.values()),'phase and averaging identities')
    write('symbolic.json',dict(passed=True,checks=checks,count=len(checks),commutator_convention='[S,C]=S*C-C*S; sum [S_n,C_n]/(2*n*mu)',drift_correction='-mean(DK)=3H(S2+E*dS2/dE)/(4mu)+E*dS2/dH/(8beta*mu)',scope='formal first near-identity correction; remainder tested rather than assumed negligible'))
    print(json.dumps(dict(derived=True,identities=len(checks))),flush=True)


def analyze():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'symbolic.json')['passed'],'derive before evaluating')
    reports={}
    for case in ('cold','heavy'):
        for window in ('extraction','live'):
            original=packet(input_path(case,window))
            normal=packet(NORMAL/(case+'-'+window+'.npz'))
            if case=='cold':
                checks=dict(dust=comparison(normal['predicted'],normal['direct'],ALGEBRA))
                reports[case+'-'+window]=dict(passed=all(row['passed'] for row in checks.values()),checks=checks,phase_map='identity; actual CDM control has no heavy phase')
                continue
            operators=packet(NORMAL/(case+'-'+window+'-operators.npz'))
            background=saved_background(original)
            scale,rate,hubble,dilation=original['extra'].T
            parameters=background['parameters']
            mass=parameters[:,0]
            beta=parameters[:,3]
            physical_density=normal['physical'][:,0]
            first=source_first(case,window)
            field,velocity,field_first,velocity_first,mass2,frequency=original['jets'][:,1].T
            mode,mode_velocity=original['vector'][:,first+2:first+4].T
            mode_prime,velocity_prime=original['derivative'][:,first+2:first+4].T
            physical_density_prime=rate*physical_density+beta*(rate*velocity_first*mode_velocity+velocity*velocity_prime+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_prime)
            variants=['fine8','degree7']+(['native'] if window=='live' else [])
            for variant in variants:
                if variant=='native':
                    hubble_prime,dilation_prime=original['metric_rates'].T
                else:
                    memory=packet(memory_path(case,window,variant))
                    require(np.array_equal(memory['clock'],original['clock']),'saved derivative epochs')
                    hubble_prime,dilation_prime=memory['node_H_prime'],memory['node_z_prime']
                rest=operators['rest_metric']
                rest_prime=dilation_prime-(physical_density_prime-(rate+hubble_prime/hubble)*physical_density)/(2*hubble*beta)
                original_state=np.column_stack([normal['slow'][:,:2],rest])
                original_rates=np.column_stack([normal['direct'],rest_prime])
                rows=[]
                for index in range(len(scale)):
                    guard()
                    parameter=parameters[index]
                    theta=background['theta'][index]
                    rates=np.array([rate[index]*mass[index],hubble_prime[index],background['energy_prime'][index],rate[index]*beta[index]])
                    micro=micromotion(theta,parameter)
                    transform=np.eye(3)+micro
                    micro_prime=micromotion_prime(theta,parameter,background['theta_prime'][index],rates)
                    alternate=micromotion_prime(theta,parameter,background['theta_prime'][index],rates,1e-24)
                    mean,commutator,drift=effective(parameter)
                    native=np.zeros((3,3))
                    native[:2,:2]=operators['opened'][index]+operators['self_gravity'][index]
                    native[:2,2]=operators['gravity'][index]
                    reduced=np.linalg.solve(transform,original_state[index])
                    derivative=np.linalg.solve(transform,original_rates[index]-micro_prime@reduced)
                    external=np.array([0.,0.,rest_prime[index]])
                    response=np.linalg.solve(transform,external)
                    exact=np.linalg.solve(transform,(native@transform-micro_prime)@reduced)+response
                    predictions={}
                    for title,generator in [('mean',mean),('commutator',mean+commutator),('phase_drift',mean+commutator+drift)]:
                        predicted=generator@reduced+response
                        predictions[title]=(transform@predicted+micro_prime@reduced)[:2]
                    bad_response=(mean+commutator+drift)@reduced+external
                    predictions['omit_rest_compensation']=(transform@bad_response+micro_prime@reduced)[:2]
                    local_remainder=np.linalg.solve(transform,native@transform-micro_prime)-(mean+commutator+drift)
                    harmonic=harmonics(parameter)
                    bound=(np.linalg.norm(harmonic[1],2)+np.linalg.norm(harmonic[2],2))/(2*mass[index])+(np.linalg.norm(harmonic[3],2)+np.linalg.norm(harmonic[4],2))/(4*mass[index])
                    rows.append(dict(state=reduced,derivative=derivative,exact=exact,transformed_back=transform@reduced,complex_difference=alternate-micro_prime,condition=np.linalg.cond(transform),bound=bound,micro_prime=micro_prime,micro=micro,remainder=local_remainder,rest_response=response,**predictions))
                output={name:np.array([row[name] for row in rows]) for name in rows[0]}
                output.update(clock=original['clock'],original_state=original_state,original_rates=original_rates,parameters=parameters,theta=background['theta'],theta_prime=background['theta_prime'],energy_prime=background['energy_prime'],hubble_prime=hubble_prime,rest_prime=rest_prime)
                checks=dict(background=background['checks'],exact_chain=columns(output['exact'],output['derivative'],'rate_',ALGEBRA),inverse=columns(output['transformed_back'],original_state,'state_',ALGEBRA),complex_step={'precision':comparison(output['complex_difference'],np.zeros_like(output['complex_difference'])+np.max(abs(output['micro_prime']))*0,ALGEBRA)})
                checks['complex_step']['precision']=dict(passed=bool(np.max(abs(output['complex_difference']))<=ALGEBRA*np.max(abs(output['micro_prime']))),absolute_error=float(np.max(abs(output['complex_difference']))),normalization=float(np.max(abs(output['micro_prime']))),tolerance=ALGEBRA)
                require(np.max(output['bound'])<1,'uniform frozen-phase invertibility bound')
                controls={title:columns(output[title],normal['direct'],'normal_rate_') for title in ('mean','commutator','phase_drift','omit_rest_compensation')}
                report=dict(passed=all_pass(checks),checks=checks,controls=controls,max_condition=float(np.max(output['condition'])),max_invertibility_bound=float(np.max(output['bound'])),phase_speed_relative_departure=float(np.max(abs(background['theta_prime']/mass-1))),remainder_matrix_peak=float(np.max(abs(output['remainder']))),source_response_peak=np.max(abs(output['rest_response'][:,:2]),axis=0))
                if window=='extraction':
                    weights=packet(PROJECTION/'frozen-projection.npz')['weights']
                    projected_target=weights@normal['direct']
                    report['projection']=dict(target=projected_target,controls={title:columns((weights@output[title])[None,:],projected_target[None,:],'rate_') for title in controls},values={title:weights@output[title] for title in controls},rule='original fixed signed extraction; not an evolved probability ensemble')
                    output['weights']=weights
                label=case+'-'+window+'-'+variant
                path=ROOT/(label+'.npz')
                require(not path.exists(),'no overwrite')
                np.savez_compressed(path,**output)
                report['packet_sha256']=digest(path)
                reports[label]=report
                print(json.dumps(dict(window=window,variant=variant,passed=report['passed'],condition=report['max_condition'],bound=report['max_invertibility_bound'],phase_drift_controls=controls['phase_drift'],projection=report.get('projection',{}).get('controls',{}).get('phase_drift')),default=convert),flush=True)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('analysis.json',dict(passed=all(row['passed'] for row in reports.values()),runs=reports,approximation_controls_not_forced_to_pass=True,full_goal_complete=False))
    require(all(row['passed'] for row in reports.values()),'paired exact transform verification')


def controls():
    from scipy.integrate import solve_ivp
    from scipy.linalg import expm
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks={}
    results=[]
    for window in ('extraction','live'):
        background=saved_background(packet(input_path('heavy',window)))
        for index in (0,len(background['theta'])//2,len(background['theta'])-1):
            parameter=background['parameters'][index]
            mass,hubble,energy,beta=parameter
            mean,commutator,drift=effective(parameter)
            for order in (32,64):
                angles=2*np.pi*(np.arange(order)+.371)/order
                actual=[]
                reconstructed=[]
                drift_terms=[]
                commutators=[]
                for theta in angles:
                    actual.append(independent_frozen(theta,parameter))
                    reconstructed.append(periodic(theta,parameter))
                    micro=micromotion(theta,parameter)
                    drift_rate=np.array([hubble*mass,energy*np.cos(2*theta)/(2*beta),3*hubble*energy*np.cos(2*theta),hubble*beta])
                    drift_terms.append(micromotion_prime(theta,parameter,-1.5*hubble*np.sin(2*theta),drift_rate))
                    commutators.append((periodic(theta,parameter)-mean)@micro)
                title=window+'-'+str(index)+'-'+str(order)
                checks[title]=dict(harmonics=comparison(np.array(reconstructed),np.array(actual),ALGEBRA),commutator=comparison(np.mean(commutators,axis=0),commutator,ALGEBRA),drift=comparison(-np.mean(drift_terms,axis=0),drift,ALGEBRA))
            initial_phase=background['theta'][index]
            period=np.pi/mass
            micro0=micromotion(initial_phase,parameter)
            transform=np.eye(3)+micro0
            predictions=dict(bare_mean=expm(mean*period),micromotion_mean=transform@expm(mean*period)@np.linalg.inv(transform),micromotion_commutator=transform@expm((mean+commutator)*period)@np.linalg.inv(transform))
            references={}
            for steps in (128,256):
                def rhs(time,values):
                    guard()
                    return (periodic(initial_phase+mass*time,parameter)@values.reshape(3,3)).ravel()
                solution=solve_ivp(rhs,(0,period),np.eye(3).ravel(),method='DOP853',rtol=1e-10,atol=1e-12,max_step=period/steps,t_eval=[period])
                require(solution.success,'frozen periodic control completes')
                references[str(steps)]=solution.y[:,-1].reshape(3,3)
            checks[window+'-'+str(index)+'-period_refinement']=dict(matrix=comparison(references['128'],references['256'],GATE))
            result=dict(window=window,index=index,period=period,checks={name:comparison(value,references['256']) for name,value in predictions.items()},scope='frozen periodic operator with constant rest-source component; no evolving-background or full-species propagation claim')
            results.append(result)
            np.savez_compressed(ROOT/(window+'-'+str(index)+'-periodic.npz'),parameters=parameter,phase=initial_phase,period=period,reference128=references['128'],reference256=references['256'],**predictions)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('controls.json',dict(passed=all_pass(checks),checks=checks,periodic_results=results,drift_test_separate_from_constant_parameter_periodic_control=True))
    print(json.dumps(dict(passed=all_pass(checks),periodic_results=results),default=convert),flush=True)
    require(all_pass(checks),'harmonic and drift controls')


def verify():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    analysis=read(ROOT/'analysis.json')
    require(analysis['passed'] and read(ROOT/'controls.json')['passed'] and read(ROOT/'symbolic.json')['passed'],'completed exact derivation and controls')
    checks={}
    for label,row in analysis['runs'].items():
        if label.startswith('cold'):
            continue
        path=ROOT/(label+'.npz')
        require(digest(path)==row['packet_sha256'],'unchanged derived packet')
        data=packet(path)
        transform=data['micro']+np.eye(3)[None,:,:]
        source=np.einsum('tij,tj->ti',transform,data['derivative'])+np.einsum('tij,tj->ti',data['micro_prime'],data['state'])
        checks[label]=columns(source,data['original_rates'],'source_',ALGEBRA)
    for window in ('extraction','live'):
        primary='native' if window=='live' else 'fine8'
        reference=packet(ROOT/('heavy-'+window+'-'+primary+'.npz'))
        for variant in ('fine8','degree7'):
            if variant==primary:
                continue
            compared=packet(ROOT/('heavy-'+window+'-'+variant+'.npz'))
            checks[window+'-'+variant+'-derivative_robustness']=columns(compared['phase_drift'],reference['phase_drift'],'source_',GATE)
    passed=all_pass(checks)
    write('validation.json',dict(passed=passed,checks=checks,count=sum(len(group) for group in checks.values()),approximation_promotion=False))
    print(json.dumps(dict(verified=passed,comparisons=sum(len(group) for group in checks.values()))),flush=True)
    require(passed,'saved derivative representation robustness')


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['passed'],'validated stage')
    require((ROOT/'RESULTS.md').is_file() and (ROOT/'DERIVATION.md').is_file(),'scientific results saved')
    excluded={'closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json'}
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write('closeout.json',dict(implementation_validated=True,actual_phase_flow_derived=True,first_phase_and_parameter_drift_correction_derived=True,rest_source_derivative_retained=True,physical_late_model_replaced=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='postseal-start.json':
            continue
        owner=read(path)
        ending=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(owner)
        require(outcome['exited'] and ending['state']=='completed','previous worker exited successfully')
        workers.append(dict(name=path.stem,identity=owner,outcome=outcome))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('freeze','derive','analyze','controls','verify','seal','postseal'))
    arguments=parser.parse_args()
    with worker(arguments.operation) as identity:
        if arguments.operation=='postseal':
            postseal(identity)
        else:
            globals()[arguments.operation]()
