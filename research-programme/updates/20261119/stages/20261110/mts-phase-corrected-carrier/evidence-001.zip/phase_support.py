import sys
from pathlib import Path
from time import monotonic

NORMAL=Path(__file__).resolve().parent.parent/'mts-derived-carrier-normal-form-20261110'
sys.path.insert(0,str(NORMAL))
import normal_support as retained
retained.ROOT=Path(__file__).resolve().parent
retained.shared.ROOT=retained.ROOT
retained.shared.START=monotonic()
from normal_support import *

NORMAL=POST/'mts-derived-carrier-normal-form-20261110'
MEMORY=POST/'mts-coupled-memory-budget-20261110'
EXPECTED_NORMAL='879347d36208fef8e70264599c9efbd8eb571f5acbd3d9fc0964fe0f38c53be6'
base_guard=retained.guard


def guard():
    base_guard()
    require(not (NORMAL/'STOP-REQUESTED').exists(),'owner hold '+str(NORMAL))


retained.shared.guard=guard


def memory_path(case,window,variant):
    label='projection' if window=='extraction' else 'live'
    return MEMORY/(case+'-'+label+'-'+variant+'.npz')
