from wide_support import *
from angular_boundary import BoundaryOperator
import argparse
import numpy as np
from scipy.linalg import expm


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('iteration', type=int, choices=(1, 2))
    parser.add_argument('steps', type=int, choices=(128, 256))
    parser.add_argument('--from-step', type=int, default=0)
    args = parser.parse_args()
    first = args.from_step
    require(0 <= first < args.steps and first % 8 == 0, 'checkpoint resume boundary')
    tag = f'closed-{args.case}-i{args.iteration}-s{args.steps}'
    name = tag + f'-from{first:03d}'
    with worker(name):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'same retained inputs')
        frozen = {path: digest(ROOT / path) for path in ('wide_support.py', 'wide_operator.py', 'angular_boundary.py',
                  'run_boundary_evolution.py', 'ANGULAR-REPAIR-CONTRACT.md', f'{args.case}-boundary{args.iteration}.npz',
                  f'{args.case}-boundary{args.iteration}-result.json', args.case + '64-initial.npz')}
        with np.load(ROOT / (args.case + '64-initial.npz'), allow_pickle=False) as packet:
            initial = np.r_[packet['initial'], 1.]
            scale = np.r_[packet['normalization'], 1.]
            times = packet['times'].copy()
        previous = frozen[args.case + '64-initial.npz']
        if first:
            receipt_name = tag + f'-chunk{first:03d}.json'
            receipt = read(ROOT / receipt_name)
            require(receipt['frozen'] == frozen and receipt['last'] == first, 'same angular resume inputs')
            origin = receipt['worker']
            require(exited(read(ROOT / (origin + '-start.json')))['exited'], 'prior worker exited')
            require(read(ROOT / (origin + '-end.json'))['state'] == 'completed', 'no automatic failed retry')
            require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'restart packet')
            with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
                initial = packet['states'][-1].copy()
            previous = digest(ROOT / receipt_name)
        operator = BoundaryOperator(args.case, args.iteration)
        try:
            require(np.array_equal(operator.port.times, times), 'same physical clock')
            boundaries = np.linspace(*times, args.steps + 1)
            lower, upper = (3 - 2 * np.sqrt(3.)) / 12, (3 + 2 * np.sqrt(3.)) / 12
            state, saved, begin_index = initial / scale, [initial.copy()], first
            for index in range(first, args.steps):
                guard()
                begin, end = boundaries[index:index + 2]
                interval = end - begin
                early = operator.matrix(begin + (.5 - np.sqrt(3.) / 6) * interval) * scale[None, :] / scale[:, None]
                late = operator.matrix(begin + (.5 + np.sqrt(3.) / 6) * interval) * scale[None, :] / scale[:, None]
                state = expm(interval * (lower * early + upper * late)) @ (expm(interval * (upper * early + lower * late)) @ state)
                require(np.all(np.isfinite(state)) and abs(state[-1] - 1) <= ALGEBRA, 'finite forced state and constant coordinate')
                saved.append(state * scale)
                if (index + 1) % 8 == 0:
                    packet_name = tag + f'-chunk{index + 1:03d}.npz'
                    require(not (ROOT / packet_name).exists(), 'no angular packet overwrite')
                    np.savez_compressed(ROOT / packet_name, states=np.array(saved), times=boundaries[begin_index:index + 2], normalization=scale)
                    receipt_name = tag + f'-chunk{index + 1:03d}.json'
                    write(receipt_name, dict(first=begin_index, last=index + 1, worker=name, previous_sha256=previous,
                          packet=packet_name, packet_sha256=digest(ROOT / packet_name), frozen=frozen))
                    previous = digest(ROOT / receipt_name)
                    begin_index, saved = index + 1, [state * scale]
                    print(json.dumps(dict(run=tag, completed=begin_index, target=args.steps, elapsed=time.monotonic() - START)), flush=True)
                    if time.monotonic() - START > 720:
                        break
            if begin_index == args.steps:
                all_states = []
                previous = frozen[args.case + '64-initial.npz']
                for last in range(8, args.steps + 1, 8):
                    receipt_name = tag + f'-chunk{last:03d}.json'
                    receipt = read(ROOT / receipt_name)
                    require(receipt['previous_sha256'] == previous and receipt['frozen'] == frozen, 'contiguous angular chain')
                    require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'angular packet hash')
                    with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
                        values = packet['states'].copy()
                    if all_states:
                        require(np.array_equal(all_states[-1][-1], values[0]), 'angular state continuity')
                    all_states.append(values if last == 8 else values[1:])
                    previous = digest(ROOT / receipt_name)
                require(not (ROOT / (tag + '.npz')).exists(), 'no full packet overwrite')
                np.savez_compressed(ROOT / (tag + '.npz'), states=np.concatenate(all_states), times=boundaries, normalization=scale)
                write(tag + '-result.json', dict(full_run=True, steps=args.steps, worker=name, frozen=frozen,
                      packet_sha256=digest(ROOT / (tag + '.npz')), terminal_receipt_sha256=previous))
            write(name + '-progress.json', dict(completed_through=begin_index, target=args.steps, full_run=begin_index == args.steps))
        finally:
            operator.close()


if __name__ == '__main__':
    main()
