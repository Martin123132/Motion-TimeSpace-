import os
import sys
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[name] = '1'
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-shared-moment-perturbation-20261110'
BACKGROUND = POST / 'mts-conservative-background-bridge-20261110'
RAD = POST / 'mts-source-complete-radiation-20261110'
PORT = POST / 'mts-late-hierarchy-port-20261110'
EXPECTED = '88d14aa97659d90b89dd43ae92db9d4bd67583225fb7fb74851d27ac34e60ba7'
GATE, ALGEBRA, SPAN = 2e-5, 1e-10, .01
START = time.monotonic()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    with (ROOT / name).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False))


def guard():
    require(time.monotonic() - START < 900, 'bounded worker deadline')
    for directory in (ROOT, POST, PREVIOUS, BACKGROUND, RAD, PORT):
        require(not (directory / 'STOP-REQUESTED').exists(), 'owner hold ' + str(directory))


@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())
    write(name + '-start.json', identity)
    try:
        guard()
        yield identity
    except BaseException as error:
        write(name + '-end.json', dict(**identity, state='failed', error=repr(error)))
        raise
    else:
        write(name + '-end.json', dict(**identity, state='completed', elapsed=time.monotonic() - START))


def preserved():
    require(digest(PREVIOUS / 'closeout.json') == EXPECTED, 'previous seal')
    seal = read(PREVIOUS / 'closeout.json')
    result = dict(seal['input_hashes'])
    result[str(PREVIOUS / 'closeout.json')] = EXPECTED
    result.update({str(PREVIOUS / name): row['sha256'] for name, row in seal['artifacts'].items()})
    result[str(PREVIOUS / 'CLEANUP-VERIFIED.json')] = digest(PREVIOUS / 'CLEANUP-VERIFIED.json')
    for path, checksum in result.items():
        guard()
        require(digest(path) == checksum, 'changed source ' + path)
    return result


def exited(identity):
    try:
        process = psutil.Process(identity['pid'])
        same = abs(process.create_time() - identity['created']) < .01 and process.cmdline() == identity['command']
    except psutil.NoSuchProcess:
        return dict(exited=True, reason='PID absent')
    return dict(exited=not same, reason='original identity live' if same else 'PID reused; untouched')
