from wide_support import *
from angular_boundary import BoundaryOperator, WideOperator, response17, reference, load_trajectory
from shared_operator import defects
import argparse
import numpy as np
from scipy.linalg import expm


class FineBoundaryOperator(BoundaryOperator):
    def __init__(self, case):
        super().__init__(case, 2)
        result = read(ROOT / (case + '-boundary512-result.json'))
        require(result['passed'] and result['code_sha256'] == digest(__file__), 'accepted same refinement bank')
        require(result['packet_sha256'] == digest(ROOT / (case + '-boundary512.npz')), 'refinement bank hash')
        with np.load(ROOT / (case + '-boundary512.npz'), allow_pickle=False) as packet:
            self.extra_times, self.extra_values = packet['times'].copy(), packet['values'].copy()
        self.extra_lookup = {float(stamp).hex(): index for index, stamp in enumerate(self.extra_times)}

    def boundary(self, stamp):
        index = self.extra_lookup.get(float(stamp).hex())
        if index is not None:
            return self.extra_values[index]
        near = int(np.argmin(abs(self.extra_times - stamp)))
        if abs(self.extra_times[near] - stamp) <= 4 * np.spacing(float(stamp)):
            return self.extra_values[near]
        return super().boundary(stamp)


def bank(case):
    with worker('bank512-' + case):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'same retained inputs')
        with np.load(ROOT / (case + '-boundary2.npz'), allow_pickle=False) as packet:
            clock, metric, old_times, old_values = [packet[name].copy() for name in ('source_clock', 'source_metric', 'times', 'values')]
        operator = WideOperator(case, 64)
        try:
            boundaries = np.linspace(*operator.port.times, 513)
            targets = list(boundaries)
            for begin, end in zip(boundaries[:-1], boundaries[1:]):
                targets.extend([begin + (.5 - np.sqrt(3.) / 6) * (end - begin), begin + (.5 + np.sqrt(3.) / 6) * (end - begin)])
            probes = operator.port.times[0] + operator.port.state_spline(np.linspace(0., SPAN, 9))[:, 3]
            targets.extend(probes)
            for target in probes:
                index = min(int(np.searchsorted(boundaries, target, side='right')) - 1, 512)
                begin = boundaries[index]
                if target > begin:
                    targets.extend([begin + (.5 - np.sqrt(3.) / 6) * (target - begin), begin + (.5 + np.sqrt(3.) / 6) * (target - begin)])
            targets = np.unique(targets)
            values = response17(operator, clock, metric, targets, 10)
            indices = np.unique(np.linspace(0, len(targets) - 1, 33).astype(int))
            coarse = response17(operator, clock, metric, targets[indices], 6)
            amplitude = float(np.max(abs(values)))
            quadrature = float(np.max(abs(values[indices] - coarse)) / amplitude)
            old_lookup = {float(stamp).hex(): index for index, stamp in enumerate(old_times)}
            overlap = [(index, old_lookup[float(stamp).hex()]) for index, stamp in enumerate(targets) if float(stamp).hex() in old_lookup]
            require(len(overlap) >= 257, 'overlap with old bank')
            overlap_error = max(float(np.max(abs(values[first] - old_values[second])) / amplitude) for first, second in overlap)
            np.savez_compressed(ROOT / (case + '-boundary512.npz'), times=targets, values=values,
                                source_clock=clock, source_metric=metric, control_indices=indices, coarse=coarse)
            result = dict(passed=max(quadrature, overlap_error) <= GATE, quadrature_difference=quadrature,
                          overlap_difference=overlap_error, overlap_count=len(overlap), count=len(targets),
                          source_bank_sha256=digest(ROOT / (case + '-boundary2.npz')), code_sha256=digest(__file__),
                          packet_sha256=digest(ROOT / (case + '-boundary512.npz')))
            write(case + '-boundary512-result.json', result)
            print(json.dumps(dict(case=case, **result)), flush=True)
            require(result['passed'], 'finer bank preserves fixed source history')
        finally:
            operator.close()


def run(case, first):
    require(0 <= first < 512 and first % 32 == 0, '32-step resume boundary')
    tag = 'closed512-' + case
    name = tag + f'-from{first:03d}'
    with worker(name):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'retained sources')
        frozen = {name: digest(ROOT / name) for name in ('time_refinement.py', 'TIME-REFINEMENT-CONTRACT.md',
                  case + '-boundary512.npz', case + '-boundary512-result.json', case + '64-initial.npz')}
        with np.load(ROOT / (case + '64-initial.npz'), allow_pickle=False) as packet:
            initial, scale = np.r_[packet['initial'], 1.], np.r_[packet['normalization'], 1.]
            times = packet['times'].copy()
        previous = frozen[case + '64-initial.npz']
        if first:
            receipt_path = ROOT / (tag + f'-chunk{first:03d}.json')
            receipt = read(receipt_path)
            require(receipt['frozen'] == frozen and receipt['last'] == first, 'same resume inputs')
            require(exited(read(ROOT / (receipt['worker'] + '-start.json')))['exited'], 'prior worker exited')
            require(read(ROOT / (receipt['worker'] + '-end.json'))['state'] == 'completed', 'no automatic failed retry')
            require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'restart hash')
            with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
                initial = packet['states'][-1].copy()
            previous = digest(receipt_path)
        operator = FineBoundaryOperator(case)
        try:
            boundaries = np.linspace(*times, 513)
            state, saved, begin_index = initial / scale, [initial.copy()], first
            lower, upper = (3 - 2 * np.sqrt(3.)) / 12, (3 + 2 * np.sqrt(3.)) / 12
            for index in range(first, 512):
                guard()
                begin, end = boundaries[index:index + 2]
                interval = end - begin
                early = operator.matrix(begin + (.5 - np.sqrt(3.) / 6) * interval) * scale[None, :] / scale[:, None]
                late = operator.matrix(begin + (.5 + np.sqrt(3.) / 6) * interval) * scale[None, :] / scale[:, None]
                state = expm(interval * (lower * early + upper * late)) @ (expm(interval * (upper * early + lower * late)) @ state)
                require(np.all(np.isfinite(state)) and abs(state[-1] - 1) <= ALGEBRA, 'finite state and constant coordinate')
                saved.append(state * scale)
                if (index + 1) % 32 == 0:
                    packet_name = tag + f'-chunk{index + 1:03d}.npz'
                    require(not (ROOT / packet_name).exists(), 'no overwrite')
                    np.savez_compressed(ROOT / packet_name, states=np.array(saved), times=boundaries[begin_index:index + 2], normalization=scale)
                    receipt_name = tag + f'-chunk{index + 1:03d}.json'
                    write(receipt_name, dict(first=begin_index, last=index + 1, worker=name, previous_sha256=previous,
                          packet=packet_name, packet_sha256=digest(ROOT / packet_name), frozen=frozen))
                    previous = digest(ROOT / receipt_name)
                    begin_index, saved = index + 1, [state * scale]
                    print(json.dumps(dict(case=case, completed=begin_index, target=512, elapsed=time.monotonic() - START)), flush=True)
                    if time.monotonic() - START > 720:
                        break
            if begin_index == 512:
                history = []
                previous = frozen[case + '64-initial.npz']
                for last in range(32, 513, 32):
                    receipt_path = ROOT / (tag + f'-chunk{last:03d}.json')
                    receipt = read(receipt_path)
                    require(receipt['previous_sha256'] == previous and receipt['frozen'] == frozen, 'hash-linked finer history')
                    require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'finer packet hash')
                    with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
                        values = packet['states'].copy()
                    if history:
                        require(np.array_equal(history[-1][-1], values[0]), 'finer state continuity')
                    history.append(values if last == 32 else values[1:])
                    previous = digest(receipt_path)
                np.savez_compressed(ROOT / (tag + '.npz'), states=np.concatenate(history), times=boundaries, normalization=scale)
                write(tag + '-result.json', dict(passed=True, full_run=True, worker=name, frozen=frozen,
                      packet_sha256=digest(ROOT / (tag + '.npz')), terminal_receipt_sha256=previous))
            write(name + '-progress.json', dict(completed_through=begin_index, full_run=begin_index == 512))
        finally:
            operator.close()


def analyse(case):
    with worker('analyse512-' + case):
        result = read(ROOT / ('closed512-' + case + '-result.json'))
        require(exited(read(ROOT / (result['worker'] + '-start.json')))['exited'], 'finer worker exited')
        require(digest(ROOT / ('closed512-' + case + '.npz')) == result['packet_sha256'], 'finer packet')
        with np.load(ROOT / ('closed512-' + case + '.npz'), allow_pickle=False) as packet:
            fine, clock, scale = [packet[key].copy() for key in ('states', 'times', 'normalization')]
        coarse, old_clock, unused_scale = load_trajectory(case, 2, 256)
        coarse = np.column_stack((coarse, np.ones(len(coarse))))
        state_error = float(np.max(abs(fine[::2] - coarse) / scale))
        operator = FineBoundaryOperator(case)
        old_operator = BoundaryOperator(case, 2)
        try:
            targets = operator.port.times[0] + operator.port.state_spline(np.linspace(0., SPAN, 9))[:, 3]
            fractions = (targets - operator.port.times[0]) / operator.span
            fractions[0], fractions[-1] = 0., 1.
            aligned = []
            for trajectory, times, owner in ((coarse, old_clock, old_operator), (fine, clock, operator)):
                values = []
                for target in targets:
                    index = min(int(np.searchsorted(times, target, side='right')) - 1, len(times) - 1)
                    values.append(reference.analysis_module.advance(owner, trajectory[index], times[index], target, scale))
                aligned.append(np.array(values))
            aligned_error = float(np.max(abs(aligned[0] - aligned[1]) / scale))
            fields = ['phi', 'psi', 'density', 'current', 'anisotropy'] + (['heavy_density', 'heavy_current', 'heavy_pressure'] if case == 'heavy' else [])
            readouts, earlier, diagnostics = [], [], []
            for index, fraction in enumerate(fractions):
                sample = operator.sample(float(fraction), keep_matrix=False)
                readouts.append({name: float(sample[name].astype(np.longdouble) @ aligned[1][index].astype(np.longdouble)) for name in fields})
                earlier.append({name: float(sample[name].astype(np.longdouble) @ aligned[0][index].astype(np.longdouble)) for name in fields})
                for divisions in (16, 32):
                    jets = reference.analysis_module.jets_inside(operator, float(fraction), divisions)
                    diagnostics.append(dict(fraction=float(fraction), divisions=divisions, metrics=defects(operator, jets, aligned[1][index])))
            source_steps = {name: reference.analysis_module.field_comparison(np.array([row[name] for row in earlier]), np.array([row[name] for row in readouts])) for name in fields}
            metric = reference.sample_metric(operator.core, fine[:, :-1], clock)
            exact, low = reference.respond(operator.core, clock, metric, targets, 64, 10, 1)
            quadrature, unused_low = reference.respond(operator.core, clock, metric, targets, 64, 6, 1)
            interpolation, unused_low = reference.respond(operator.core, clock, metric, targets, 64, 10, 2)
            momentum, unused_low = reference.respond(operator.core, clock, metric, targets, 128, 10, 1)
            actual = []
            nodes, weights = reference.rule(64)
            for stamp, state in zip(targets, aligned[1]):
                context = operator.port.context(float(stamp))
                speed = nodes / np.sqrt(nodes**2 + (context['scale'] * context['neutrino_mass'])**2)
                prefactor = context['neutrino_amplitude'] / context['scale']**2
                modes = state[6:6 + 64 * 17].reshape(64, 17)
                actual.append([np.sum(prefactor * weights * modes[:, 0] / speed), np.sum(prefactor * weights * modes[:, 1]), np.sum(prefactor * weights * speed * modes[:, 2])])
            checks = {}
            for name, value in (('characteristic', np.array(actual)), ('quadrature', quadrature), ('interpolation', interpolation), ('momentum', momentum)):
                checks[name] = {field: reference.analysis_module.field_comparison(value[:, index], exact[:, index]) for index, field in enumerate(('density', 'current', 'anisotropy'))}
            final_boundary = response17(operator.core, clock, metric, clock, 10)
            supplied = np.array([operator.boundary(float(stamp)) for stamp in clock])
            fixed_point = reference.analysis_module.field_comparison(supplied, final_boundary)
            phase_check = reference.phase_control(operator.core, clock, 64)
            numerical = max(state_error, aligned_error) <= GATE and all(row['passed'] for row in source_steps.values())
            passed = numerical and fixed_point['passed'] and phase_check['passed'] and all(row['passed'] for group in checks.values() for row in group.values())
            passed = passed and all(row['metrics']['metric_error'] <= GATE and row['metrics']['identity_error'] <= ALGEBRA for row in diagnostics)
            np.savez_compressed(ROOT / (case + '-refinement512-analysis.npz'), coarse=aligned[0], fine=aligned[1], target_times=targets,
                                metric=metric, times=clock, exact_moments=exact, actual_moments=np.array(actual), final_boundary=final_boundary, supplied_boundary=supplied)
            report = dict(case=case, passed=passed, numerical_passed=numerical, state_difference=state_error, aligned_difference=aligned_error,
                          source_step_checks=source_steps, readouts=readouts, diagnostics=diagnostics, checks=checks, fixed_point=fixed_point,
                          phase_check=phase_check, code_sha256=digest(__file__), packet_sha256=digest(ROOT / (case + '-refinement512-analysis.npz')))
            write(case + '-refinement512-result.json', report)
            print(json.dumps(dict(case=case, passed=passed, state_difference=state_error, aligned_difference=aligned_error,
                  source_step_maximum=max(row['relative_difference'] for row in source_steps.values()), fixed_point=fixed_point,
                  characteristic=checks['characteristic'], metric_error=max(row['metrics']['metric_error'] for row in diagnostics))), flush=True)
        finally:
            operator.close()
            old_operator.close()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('operation', choices=('bank', 'run', 'analyse'))
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('--from-step', type=int, default=0)
    options = parser.parse_args()
    if options.operation == 'bank':
        bank(options.case)
    elif options.operation == 'run':
        run(options.case, options.from_step)
    else:
        analyse(options.case)
