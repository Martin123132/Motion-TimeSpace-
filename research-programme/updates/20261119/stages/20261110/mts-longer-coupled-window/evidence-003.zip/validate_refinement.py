from wide_support import *
import numpy as np


def main():
    with worker('validation-refinement'):
        checks = []

        def check(name, value):
            checks.append(dict(name=name, passed=bool(value)))

        base = read(ROOT / 'validation.json')
        check('original validation retained', base['passed'] and base['code_sha256'] == digest(ROOT / 'validate_stage.py'))
        check('original coarse repair not promoted', base['coupled_repair_passed'] is False)
        check('same inherited inputs', preserved() == read(ROOT / 'frozen-inputs.json'))
        reports = []
        for case in ('cold', 'heavy'):
            bank = read(ROOT / (case + '-boundary512-result.json'))
            check(case + ' refined bank', bank['passed'] and bank['code_sha256'] == digest(ROOT / 'time_refinement.py'))
            check(case + ' exact same boundary source', bank['source_bank_sha256'] == digest(ROOT / (case + '-boundary2.npz')))
            check(case + ' refined boundary packet', bank['packet_sha256'] == digest(ROOT / (case + '-boundary512.npz')))
            trajectory = read(ROOT / ('closed512-' + case + '-result.json'))
            check(case + ' complete512trajectory', trajectory['passed'] and trajectory['full_run'])
            check(case + ' trajectory hash', trajectory['packet_sha256'] == digest(ROOT / ('closed512-' + case + '.npz')))
            with np.load(ROOT / ('closed512-' + case + '.npz'), allow_pickle=False) as packet:
                check(case + ' finite513states', len(packet['states']) == 513 and np.all(np.isfinite(packet['states'])))
                check(case + ' constant coordinate', np.max(abs(packet['states'][:, -1] - 1)) <= ALGEBRA)
            report = read(ROOT / (case + '-refinement512-result.json'))
            check(case + ' final analysis code', report['code_sha256'] == digest(ROOT / 'time_refinement.py'))
            check(case + ' final analysis packet', report['packet_sha256'] == digest(ROOT / (case + '-refinement512-analysis.npz')))
            reports.append(report)
        for path in sorted(ROOT.glob('*-chunk*.json')):
            receipt = read(path)
            extent = 32 if path.name.startswith('closed512-') else 8
            check(path.name + ' extent', receipt['last'] - receipt['first'] == extent)
            check(path.name + ' packet', digest(ROOT / receipt['packet']) == receipt['packet_sha256'])
            check(path.name + ' frozen inputs', all(digest(ROOT / name) == checksum for name, checksum in receipt['frozen'].items()))
        for path in sorted(ROOT.glob('*-start.json')):
            if path.name == 'validation-refinement-start.json':
                continue
            start = read(path)
            end = read(ROOT / path.name.replace('-start.json', '-end.json'))
            check('worker identity ' + path.name, all(start[key] == end[key] for key in ('pid', 'created', 'command')))
            check('worker exited ' + path.name, exited(start)['exited'])
            check('worker completed ' + path.name, end['state'] == 'completed')
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
        check('no bytecode', not list(ROOT.rglob('__pycache__')))
        result = dict(passed=all(row['passed'] for row in checks), checks=checks,
                      coupled_repair_passed=all(row['passed'] for row in reports), reports=reports,
                      code_sha256=digest(__file__), original_validation_sha256=digest(ROOT / 'validation.json'),
                      original_128_256_failure_preserved=True, gates=dict(numerical=GATE, algebra=ALGEBRA))
        write('validation-refinement.json', result)
        print(json.dumps(dict(passed=result['passed'], checks=len(checks), coupled_repair_passed=result['coupled_repair_passed'],
              reports=[dict(case=row['case'], passed=row['passed'], state_difference=row['state_difference'],
                            aligned_difference=row['aligned_difference']) for row in reports])), flush=True)
        require(result['passed'], 'final implementation/provenance checks')


if __name__ == '__main__':
    main()
