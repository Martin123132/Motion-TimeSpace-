from wide_support import *


def main():
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    seal = read(ROOT / 'closeout.json')
    require(seal['state'] == 'verified_progress_longer_coupled_window', 'expected seal')
    for path, checksum in seal['input_hashes'].items():
        guard()
        require(digest(path) == checksum, 'inherited source ' + path)
    for name, row in seal['artifacts'].items():
        require(digest(ROOT / name) == row['sha256'] and (ROOT / name).stat().st_size == row['bytes'], 'artifact ' + name)
    workers = []
    for path in sorted(ROOT.glob('*-start.json')):
        start = read(path)
        status = exited(start)
        end = read(ROOT / path.name.replace('-start.json', '-end.json'))
        require(status['exited'], 'worker live ' + path.name)
        require(all(start[key] == end[key] for key in ('pid', 'created', 'command')), 'receipt identity')
        workers.append(dict(receipt=path.name, identity=start, status=status, ending=end['state']))
    require(not list(ROOT.rglob('__pycache__')), 'no bytecode')
    write('CLEANUP-VERIFIED.json', dict(passed=True, seal_sha256=digest(ROOT / 'closeout.json'),
          utc=datetime.now(timezone.utc).isoformat(), input_count=len(seal['input_hashes']), artifacts=len(seal['artifacts']),
          workers=workers, verifier_identity=dict(pid=process.pid, created=process.create_time(), command=process.cmdline()),
          verifier_exit='Confirm this verifier exited from its launching tool result.', apps_started=[], servers_started=[],
          continuing_job=False, unrelated_processes_changed=False, cleanup_action='Verified exact task-owned identities exited; no process killed.'))
    print(json.dumps(dict(passed=True, seal_sha256=digest(ROOT / 'closeout.json'), exited_workers=len(workers), verifier_pid=process.pid)))


if __name__ == '__main__':
    main()
