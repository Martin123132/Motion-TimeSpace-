from wide_support import *


def main():
    with worker('seal'):
        validation = read(ROOT / 'validation.json')
        require(validation['passed'] and validation['code_sha256'] == digest(ROOT / 'validate_stage.py'), 'same validated evidence')
        refinement = read(ROOT / 'validation-refinement.json')
        require(refinement['passed'] and refinement['code_sha256'] == digest(ROOT / 'validate_refinement.py'), 'validated512refinement')
        require(refinement['original_validation_sha256'] == digest(ROOT / 'validation.json'), 'original failure preserved')
        inputs = preserved()
        require(inputs == read(ROOT / 'frozen-inputs.json'), 'unchanged inherited sources')
        for name in ('PROTOCOL.md', 'DERIVATION.md', 'CHARACTERISTIC-CONTRACT.md', 'ANGULAR-REPAIR-CONTRACT.md',
                     'ANGULAR-REPAIR-DERIVATION.md', 'RESULTS.md', 'NEXT.md'):
            require((ROOT / name).is_file(), 'required document ' + name)
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
        for path in sorted(ROOT.glob('*-start.json')):
            if path.name != 'seal-start.json':
                require(exited(read(path))['exited'], 'worker exited ' + path.name)
        require(not list(ROOT.rglob('__pycache__')), 'no bytecode')
    artifacts = {path.name: dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file()}
    require(len(artifacts) == len(list(ROOT.iterdir())), 'no unexpected directories')
    write('closeout.json', dict(state='verified_progress_longer_coupled_window', utc=datetime.now(timezone.utc).isoformat(),
          goal_complete=False, input_hashes=inputs, artifacts=artifacts, validation_checks=len(validation['checks']),
          coupled_angular_repair_passed=refinement['coupled_repair_passed'], production_changed=False,
          original_128_256_repair_passed=validation['coupled_repair_passed'], refinement_checks=len(refinement['checks']),
          original_failed_angular_controls_preserved=True, new_fitted_parameters=0, next='NEXT.md'))
    print(json.dumps(dict(seal_sha256=digest(ROOT / 'closeout.json'), inputs=len(inputs), artifacts=len(artifacts),
                          validation_checks=len(validation['checks']), refinement_checks=len(refinement['checks']),
                          coupled_angular_repair_passed=refinement['coupled_repair_passed'])))


if __name__ == '__main__':
    main()
