from wide_support import *
sys.path.insert(0, str(PREVIOUS))
from shared_operator import SharedPort, SharedOperator, SharedCanonical, clone, Series, action_model, Operators
import types
import numpy as np
from scipy.interpolate import CubicSpline


class WidePort(SharedPort):
    def __init__(self, label, count):
        super().__init__(label, count)
        require(read(ROOT / 'background-result.json')['passed'], 'extended background controls')
        require(read(ROOT / 'thermal-regime-result.json')['passed'], 'extended native regime/thermal controls')
        with np.load(ROOT / (label + '-background.npz'), allow_pickle=False) as packet:
            states = packet['states' if count == 64 else 'alternate_states'].copy()
            positions = packet['position'].copy()
        self.state_spline = CubicSpline(positions, states, axis=0)
        self.position_spline = CubicSpline(states[:, 3], positions)
        self.times = np.array([self.original_times[0], self.original_times[0] + states[-1, 3]])
        with np.load(ROOT / (label + '-thermal-regime.npz'), allow_pickle=False) as packet:
            self.thermal_spline = CubicSpline(packet['position'][::2], packet['values'][::2], axis=0)
        self.cache = None


class WideOperator(SharedOperator):
    def __init__(self, label, count):
        self.port = WidePort(label, count)
        self.facade = types.SimpleNamespace(Series=Series, background_series=self.port.background_series,
                                           RESIDUAL_FUNCTION=action_model.RESIDUAL_FUNCTION)
        self.block = SharedCanonical(self.port, self.facade) if label == 'heavy' else None
        self.scalar_jets = types.MethodType(clone(Operators.scalar_jets, action_model=self.facade), self)
        self.span = float(self.port.times[-1] - self.port.times[0])
        self.last_system = None

    def system(self, stamp):
        guard()
        if self.last_system is None or self.last_system[0] != stamp:
            self.last_system = stamp, super().system(stamp)
        return self.last_system[1]

    def sample(self, fraction, keep_matrix=True):
        result = super().sample(fraction, keep_matrix)
        system = self.system(float(self.port.times[0] + fraction * self.span))
        result.update(missing_density=system['missing_density'], missing_pressure=system['missing_pressure'])
        return result

    def close(self):
        self.last_system = None
        super().close()
