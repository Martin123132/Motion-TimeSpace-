from wide_support import *
from wide_operator import WideOperator
import argparse
import numpy as np
from scipy.linalg import expm


def fingerprint(case, count):
    names = ['wide_support.py', 'wide_operator.py', 'run_forward.py', 'PROTOCOL.md', 'interface-result.json',
             'background-result.json', 'thermal-regime-result.json', case + '-background.npz',
             case + '-thermal-regime.npz', case + str(count) + '-initial.npz']
    return {name: digest(ROOT / name) for name in names}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('count', type=int, choices=(32, 64))
    parser.add_argument('steps', type=int, choices=(128, 256))
    parser.add_argument('--from-step', type=int, default=0)
    args = parser.parse_args()
    first, last = args.from_step, args.steps
    require(0 <= first < last and first % 8 == 0, 'eight-step resume boundary')
    tag = f'{args.case}{args.count}-s{args.steps}'
    name = f'forward-{tag}-from{first:03d}'
    with worker(name):
        require(read(ROOT / 'interface-result.json')['passed'], 'interface gate')
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'inherited inputs unchanged')
        frozen = fingerprint(args.case, args.count)
        previous = frozen[args.case + str(args.count) + '-initial.npz']
        with np.load(ROOT / (args.case + str(args.count) + '-initial.npz'), allow_pickle=False) as packet:
            initial, scale, times = [packet[key].copy() for key in ('initial', 'normalization', 'times')]
        if first:
            receipt_name = f'{tag}-chunk{first:03d}.json'
            receipt = read(ROOT / receipt_name)
            require(receipt['last'] == first and receipt['frozen'] == frozen, 'resume fingerprint')
            origin = receipt['worker']
            require(exited(read(ROOT / (origin + '-start.json')))['exited'], 'previous worker exited')
            require(read(ROOT / (origin + '-end.json'))['state'] == 'completed', 'no automatic failed-run retry')
            require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'resume packet')
            with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
                initial = packet['states'][-1].copy()
            previous = digest(ROOT / receipt_name)
        operator = WideOperator(args.case, args.count)
        try:
            require(np.array_equal(times, operator.port.times), 'same clock')
            boundaries = np.linspace(*times, last + 1)
            state, saved, begin_index = initial / scale, [initial.copy()], first
            lower, upper = (3 - 2 * np.sqrt(3.)) / 12, (3 + 2 * np.sqrt(3.)) / 12
            for index in range(first, last):
                guard()
                begin, end = boundaries[index:index + 2]
                interval = end - begin
                early = operator.system(begin + (.5 - np.sqrt(3.) / 6) * interval)['matrix'] * scale[None, :] / scale[:, None]
                late = operator.system(begin + (.5 + np.sqrt(3.) / 6) * interval)['matrix'] * scale[None, :] / scale[:, None]
                state = expm(interval * (lower * early + upper * late)) @ (expm(interval * (upper * early + lower * late)) @ state)
                require(np.all(np.isfinite(state)), 'finite trajectory')
                saved.append(state * scale)
                if (index + 1) % 8 == 0:
                    packet_name = f'{tag}-chunk{index + 1:03d}.npz'
                    require(not (ROOT / packet_name).exists(), 'no overwrite')
                    np.savez_compressed(ROOT / packet_name, states=np.array(saved), times=boundaries[begin_index:index + 2], normalization=scale)
                    receipt_name = f'{tag}-chunk{index + 1:03d}.json'
                    write(receipt_name, dict(case=args.case, count=args.count, steps=last, first=begin_index, last=index + 1,
                          worker=name, previous_sha256=previous, packet=packet_name, packet_sha256=digest(ROOT / packet_name), frozen=frozen))
                    previous = digest(ROOT / receipt_name)
                    begin_index, saved = index + 1, [state * scale]
                    print(json.dumps(dict(run=tag, completed=begin_index, target=last, elapsed=time.monotonic() - START)), flush=True)
                    if time.monotonic() - START > 720:
                        break
            write(name + '-result.json', dict(completed_through=begin_index, target=last, full_run=begin_index == last,
                  terminal_chunk_sha256=previous, frozen=frozen))
        finally:
            operator.close()


if __name__ == '__main__':
    main()
