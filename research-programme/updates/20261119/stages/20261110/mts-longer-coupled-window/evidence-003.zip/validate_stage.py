from wide_support import *
import numpy as np


def comparison(first, second):
    absolute = float(np.max(abs(first - second)))
    amplitude = float(max(np.max(abs(first)), np.max(abs(second))))
    relative = absolute / amplitude if amplitude else (0. if not absolute else float('inf'))
    return dict(absolute_difference=absolute, maximum_amplitude=amplitude, relative_difference=relative, passed=relative <= GATE)


def main():
    with worker('validation'):
        checks = []

        def check(name, value):
            checks.append(dict(name=name, passed=bool(value)))

        inputs = preserved()
        check('retained sources unchanged', inputs == read(ROOT / 'frozen-inputs.json'))
        for name, code in (('background-result.json', 'prepare_background.py'),
                           ('thermal-regime-result.json', 'capture_regime_thermal.py'),
                           ('interface-result.json', 'check_interface.py'),
                           ('conservative-rows-result.json', 'check_conservative_rows.py')):
            result = read(ROOT / name)
            check('accepted preparation ' + name, result['passed'])
            check('preparation code ' + name, result['code_sha256'] == digest(ROOT / code))
        old_grid_comparisons, old_characteristics, repaired = [], [], []
        for case in ('cold', 'heavy'):
            old = {}
            for count in (32, 64):
                tag = case + str(count)
                result = read(ROOT / (tag + '-result.json'))
                old[count] = result
                check('wide diagnostic code ' + tag, result['code_sha256'] == digest(ROOT / 'analyse_evolution.py'))
                check('wide diagnostic packet ' + tag, result['packet_sha256'] == digest(ROOT / (tag + '-forward.npz')))
                check('wide time refinement ' + tag, result['numerical_passed'] and result['source_step_passed'])
                check('wide budget identity ' + tag, result['identities_passed'])
            fields = {}
            for name in old[64]['readouts'][0]:
                fields[name] = comparison(np.array([row[name] for row in old[32]['readouts']]), np.array([row[name] for row in old[64]['readouts']]))
            old_grid_comparisons.append(dict(case=case, fields=fields, passed=all(row['passed'] for row in fields.values())))
            characteristic = read(ROOT / (case + '-characteristic-result.json'))
            check('conditional reference code ' + case, characteristic['code_sha256'] == digest(ROOT / 'characteristic_reference.py'))
            check('conditional reference packet ' + case, characteristic['packet_sha256'] == digest(ROOT / (case + '-characteristic.npz')))
            check('conditional reference numerical controls ' + case, characteristic['numerical_control_passed'])
            check('independent kernel controls ' + case, all(row['passed'] for row in characteristic['kernel_controls']))
            old_characteristics.append(dict(case=case, comparisons=characteristic['comparisons']))
            for iteration in (1, 2):
                tag = f'{case}-boundary{iteration}'
                bank = read(ROOT / (tag + '-result.json'))
                check('boundary precision ' + tag, bank['passed'])
                check('boundary code ' + tag, bank['code_sha256'] == digest(ROOT / 'build_boundary.py'))
                check('boundary model ' + tag, bank['model_sha256'] == digest(ROOT / 'angular_boundary.py'))
                check('boundary contract ' + tag, bank['contract_sha256'] == digest(ROOT / 'ANGULAR-REPAIR-CONTRACT.md'))
                check('boundary packet ' + tag, bank['packet_sha256'] == digest(ROOT / (tag + '.npz')))
                for name, checksum in bank['source_hashes'].items():
                    check('boundary source ' + tag + ' ' + name, digest(ROOT / name) == checksum)
            repair = read(ROOT / (case + '-boundary-analysis-result.json'))
            check('repair diagnostic code ' + case, repair['code_sha256'] == digest(ROOT / 'analyse_boundary.py'))
            check('repair model ' + case, repair['model_sha256'] == digest(ROOT / 'angular_boundary.py'))
            check('repair diagnostic packet ' + case, repair['packet_sha256'] == digest(ROOT / (case + '-boundary-analysis.npz')))
            repaired.append(repair)
        for path in sorted(ROOT.glob('*-chunk*.json')):
            receipt = read(path)
            check('chunk packet ' + path.name, digest(ROOT / receipt['packet']) == receipt['packet_sha256'])
            check('chunk frozen inputs ' + path.name, all(digest(ROOT / name) == checksum for name, checksum in receipt['frozen'].items()))
            check('chunk extent ' + path.name, receipt['last'] - receipt['first'] == 8)
        for case in ('cold', 'heavy'):
            for iteration, steps in ((1, 256), (2, 128), (2, 256)):
                tag = f'closed-{case}-i{iteration}-s{steps}'
                result = read(ROOT / (tag + '-result.json'))
                check('complete coupled iteration ' + tag, result['full_run'] and result['steps'] == steps)
                check('coupled trajectory packet ' + tag, result['packet_sha256'] == digest(ROOT / (tag + '.npz')))
                with np.load(ROOT / (tag + '.npz'), allow_pickle=False) as packet:
                    check('finite coupled states ' + tag, np.all(np.isfinite(packet['states'])))
                    check('constant affine coordinate ' + tag, np.max(abs(packet['states'][:, -1] - 1)) <= ALGEBRA)
        for path in sorted(ROOT.glob('*-start.json')):
            if path.name == 'validation-start.json':
                continue
            start = read(path)
            end = read(ROOT / path.name.replace('-start.json', '-end.json'))
            check('worker identity ' + path.name, all(start[key] == end[key] for key in ('pid', 'created', 'command')))
            check('worker exited ' + path.name, exited(start)['exited'])
            check('worker completed ' + path.name, end['state'] == 'completed')
        compiled = []
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
            compiled.append(path.name)
        check('no bytecode', not list(ROOT.rglob('__pycache__')))
        repair_passed = all(row[field] for row in repaired for field in ('numerical_passed', 'characteristic_passed', 'fixed_point_passed', 'metric_passed', 'identities_passed'))
        summaries = [dict(case=row['case'], numerical_passed=row['numerical_passed'], characteristic_passed=row['characteristic_passed'],
                         fixed_point_passed=row['fixed_point_passed'], metric_passed=row['metric_passed'],
                         state_step_difference=row['state_step_difference'], boundary_step_difference=row['boundary_step_difference'],
                         source_step_maximum=max(value['relative_difference'] for value in row['source_step_checks'].values()),
                         metric_error=max(value['metrics']['metric_error'] for value in row['diagnostics']),
                         boundary_fixed_point=row['boundary_fixed_point'], comparisons=row['comparisons']) for row in repaired]
        result = dict(passed=all(row['passed'] for row in checks), checks=checks, code_sha256=digest(__file__),
                      input_count=len(inputs), original_l16_grid_comparisons=old_grid_comparisons,
                      original_characteristic_comparisons=old_characteristics, coupled_repair_passed=repair_passed,
                      coupled_repair=summaries, compiled=compiled, production_changed=False, new_fitted_parameters=0,
                      scope='finite sampled coupled reference and numerical controls; not a uniform or observational certificate')
        write('validation.json', result)
        print(json.dumps(dict(passed=result['passed'], checks=len(checks), coupled_repair_passed=repair_passed,
                              old_grid=old_grid_comparisons, repaired=summaries)), flush=True)
        require(result['passed'], 'implementation/provenance validation')


if __name__ == '__main__':
    main()
