from wide_support import *
sys.path.insert(0, str(PREVIOUS))
from shared_operator import ReferenceBackground, clone
import numpy as np
from scipy.interpolate import CubicSpline


def main():
    with worker('background'):
        write('frozen-inputs.json', preserved())
        solve = clone(ReferenceBackground.solve, SPAN=SPAN, guard=guard)
        reports = []
        positions = np.linspace(0., SPAN, 321)
        for case in ('cold', 'heavy'):
            owner = ReferenceBackground(case, 64)
            alternate = ReferenceBackground(case, 32)
            coarse, scale = solve(owner, 2e-11)
            fine, fine_scale = solve(owner, 2e-12)
            alternate_solution, alternate_scale = solve(alternate, 2e-12)
            require(np.array_equal(scale, fine_scale), 'same normalization')
            states = fine.sol(positions).T * scale
            coarse_states = coarse.sol(positions).T * scale
            alternate_states = alternate_solution.sol(positions).T * alternate_scale
            constraint, clocks = [], []
            for position, state in zip(positions[::8], states[::8]):
                values = owner.parts(position, *state[:2])
                constraint.append(abs(values['density'] / (3 * state[2]**2) - 1))
                clocks.append(owner.pressure_clock_error(position, state))
            with np.load(BACKGROUND / (case + '-background.npz'), allow_pickle=False) as old:
                overlap = fine.sol(old['position']).T * scale
                overlap_scale = old['normalization']
                overlap_error = float(np.max(abs(overlap - old['states']) / overlap_scale))
            spline = CubicSpline(positions, states, axis=0)
            held = (positions[:-1] + positions[1:]) / 2
            interpolation = float(np.max(abs(spline(held) - fine.sol(held).T * scale) / scale))
            refinement = float(np.max(abs(states - coarse_states) / scale))
            grid = float(np.max(abs(states - alternate_states) / scale))
            packet = case + '-background.npz'
            np.savez_compressed(ROOT / packet, position=positions, states=states, coarse_states=coarse_states,
                                alternate_states=alternate_states, normalization=scale)
            report = dict(case=case, refinement=refinement, grid_difference=grid,
                          friedmann_error=float(max(constraint)), pressure_clock_error=float(max(clocks)),
                          independent_midpoint_interpolation=interpolation, old_overlap_error=overlap_error,
                          evaluations=[coarse.nfev, fine.nfev, alternate_solution.nfev], packet_sha256=digest(ROOT / packet),
                          passed=bool(max(refinement, grid, interpolation, overlap_error) <= GATE and max(*constraint, *clocks) <= ALGEBRA))
            reports.append(report)
            print(json.dumps(report), flush=True)
        write('background-result.json', dict(passed=all(row['passed'] for row in reports), reports=reports,
              code_sha256=digest(__file__), span=SPAN, solver_source=str(BACKGROUND / 'background_bridge.py'),
              solver_source_sha256=digest(BACKGROUND / 'background_bridge.py')))
        require(all(row['passed'] for row in reports), 'extended backgrounds')


if __name__ == '__main__':
    main()
