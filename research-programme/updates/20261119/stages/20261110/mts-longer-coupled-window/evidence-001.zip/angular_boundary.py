from wide_support import *
from wide_operator import WideOperator
import importlib.util
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn
from numpy.polynomial.legendre import leggauss, Legendre

reference_spec = importlib.util.spec_from_file_location('wide_characteristic_reference', ROOT / 'characteristic_reference.py')
reference = importlib.util.module_from_spec(reference_spec)
reference_spec.loader.exec_module(reference)


def kernel17_controls():
    cosine, weights = leggauss(128)
    ell = 17
    upper = 3 * (ell + 1) * (ell + 2) / (2 * (2 * ell + 1) * (2 * ell + 3))
    middle = ell * (ell + 1) / ((2 * ell - 1) * (2 * ell + 3))
    lower = 3 * ell * (ell - 1) / (2 * (2 * ell + 1) * (2 * ell - 1))
    errors = []
    for phase in (0., .1, 1., 10., 20., 40.):
        direct = .5 * 1j**ell * np.sum(weights * Legendre.basis(ell)(cosine) * Legendre.basis(2)(cosine) * np.exp(-1j * phase * cosine))
        analytic = middle * spherical_jn(ell, phase) - upper * spherical_jn(ell + 2, phase) - lower * spherical_jn(ell - 2, phase)
        errors.append(float(abs(direct - analytic)))
    require(max(errors) <= ALGEBRA, 'l17 characteristic kernel')
    return errors


def response17(operator, clock, metric, targets, order):
    nodes, unused_weights = reference.rule(64)
    local = clock - clock[0]
    source = CubicSpline(local, metric, axis=0)
    scale = np.exp(-np.log(11.) + operator.port.position_spline(local))
    speed = nodes[None, :] / np.sqrt(nodes[None, :]**2 + (scale[:, None] * operator.port.owner.neutrino_mass)**2)
    primitive = CubicSpline(local, speed, axis=0).antiderivative()
    zero = primitive(0.)
    points, weights = leggauss(order)
    ell = 17
    upper = 3 * (ell + 1) * (ell + 2) / (2 * (2 * ell + 1) * (2 * ell + 3))
    middle = ell * (ell + 1) / ((2 * ell - 1) * (2 * ell + 3))
    lower = 3 * ell * (ell - 1) / (2 * (2 * ell + 1) * (2 * ell - 1))
    outputs = []
    for target in targets:
        guard()
        endpoint = float(target - clock[0])
        phase = np.maximum(operator.port.wave * (primitive(endpoint) - zero), 0.)
        value = 4e-6 * spherical_jn(ell, phase)
        edges = np.r_[local[local < endpoint], endpoint]
        if len(edges) > 1:
            half = np.diff(edges) / 2
            times = ((edges[:-1] + half)[:, None] + half[:, None] * points).reshape(-1)
            quadrature_weights = (half[:, None] * weights).reshape(-1)
            delayed = operator.port.wave * (primitive(endpoint)[None, :] - primitive(times))
            require(np.min(delayed) >= -1e-10, 'causal streaming phase')
            delayed = np.maximum(delayed, 0.)
            bessel = spherical_jn(ell, delayed)
            coupling = middle * bessel - upper * spherical_jn(ell + 2, delayed) - lower * spherical_jn(ell - 2, delayed)
            fields = source(times)
            value += np.sum(quadrature_weights[:, None] * (-4 * operator.port.wave * fields[:, 0, None] * bessel / 3
                            - 8 * operator.port.wave * fields[:, 1, None] * coupling / 3), axis=0)
        outputs.append(value)
    return np.array(outputs)


def load_trajectory(case, iteration, steps=256):
    if iteration == 0:
        return reference.analysis_module.history(case, 64, steps)[:3]
    tag = f'closed-{case}-i{iteration}-s{steps}'
    receipt = read(ROOT / (tag + '-result.json'))
    require(receipt['full_run'], 'completed coupled angular trajectory')
    require(exited(read(ROOT / (receipt['worker'] + '-start.json')))['exited'], 'trajectory worker exited')
    require(read(ROOT / (receipt['worker'] + '-end.json'))['state'] == 'completed', 'successful terminal trajectory')
    require(digest(ROOT / (tag + '.npz')) == receipt['packet_sha256'], 'coupled trajectory hash')
    with np.load(ROOT / (tag + '.npz'), allow_pickle=False) as packet:
        require(np.max(abs(packet['states'][:, -1] - 1)) <= ALGEBRA, 'constant forcing coordinate')
        return packet['states'][:, :-1].copy(), packet['times'].copy(), packet['normalization'][:-1].copy()


def requested_times(operator):
    points = []
    for steps in (128, 256):
        boundaries = np.linspace(*operator.port.times, steps + 1)
        points.extend(boundaries)
        for begin, end in zip(boundaries[:-1], boundaries[1:]):
            points.extend([begin + (.5 - np.sqrt(3.) / 6) * (end - begin), begin + (.5 + np.sqrt(3.) / 6) * (end - begin)])
    probes = operator.port.times[0] + operator.port.state_spline(np.linspace(0., SPAN, 9))[:, 3]
    points.extend(probes)
    for steps in (128, 256):
        boundaries = np.linspace(*operator.port.times, steps + 1)
        for target in probes:
            index = min(int(np.searchsorted(boundaries, target, side='right')) - 1, steps)
            begin = boundaries[index]
            if target > begin:
                points.extend([begin + (.5 - np.sqrt(3.) / 6) * (target - begin), begin + (.5 + np.sqrt(3.) / 6) * (target - begin)])
    return np.unique(np.array(points))


class BoundaryOperator:
    def __init__(self, case, iteration):
        self.core = WideOperator(case, 64)
        self.port, self.block, self.span = self.core.port, self.core.block, self.core.span
        self.case, self.iteration = case, iteration
        name = f'{case}-boundary{iteration}'
        result = read(ROOT / (name + '-result.json'))
        require(result['passed'] and result['model_sha256'] == digest(__file__), 'same accepted angular bank model')
        require(digest(ROOT / (name + '.npz')) == result['packet_sha256'], 'boundary packet')
        with np.load(ROOT / (name + '.npz'), allow_pickle=False) as packet:
            self.times, self.values = packet['times'].copy(), packet['values'].copy()
        self.lookup = {float(stamp).hex(): index for index, stamp in enumerate(self.times)}

    def boundary(self, stamp):
        index = self.lookup.get(float(stamp).hex())
        if index is None:
            near = int(np.argmin(abs(self.times - stamp)))
            require(abs(self.times[near] - stamp) <= 4 * np.spacing(float(stamp)), 'no unbanked boundary extrapolation')
            index = near
        return self.values[index]

    def matrix(self, stamp):
        base = self.core.system(stamp)['matrix']
        matrix = np.zeros((len(base) + 1, len(base) + 1))
        matrix[:-1, :-1] = base
        context = self.port.context(stamp)
        speed = self.port.nodes / np.sqrt(self.port.nodes**2 + (context['scale'] * context['neutrino_mass'])**2)
        upper = self.boundary(stamp)
        for node in range(64):
            row = 6 + node * 17 + 16
            matrix[row] = 0.
            matrix[row, row - 1] = self.port.wave * speed[node] * 16 / 33
            matrix[row, -1] = -self.port.wave * speed[node] * 17 * upper[node] / 33
        return matrix

    def sample(self, fraction, keep_matrix=True):
        result = self.core.sample(fraction, keep_matrix=False)
        for name in list(result):
            if np.ndim(result[name]) == 1:
                result[name] = np.r_[result[name], 0.]
        if keep_matrix:
            result['matrix'] = self.matrix(float(self.port.times[0] + fraction * self.span))
        return result

    def system(self, stamp):
        return dict(matrix=self.matrix(stamp))

    def close(self):
        self.core.close()
