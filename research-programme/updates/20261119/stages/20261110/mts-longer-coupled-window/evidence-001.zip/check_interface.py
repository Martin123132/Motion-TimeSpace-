from wide_support import *
from wide_operator import WideOperator, SharedOperator
import numpy as np


def main():
    with worker('interface'):
        reports = []
        for case in ('cold', 'heavy'):
            for count in (32, 64):
                longer = WideOperator(case, count)
                shorter = SharedOperator(case, count)
                try:
                    tag = case + str(count)
                    with np.load(PREVIOUS / (tag + '-initial.npz'), allow_pickle=False) as packet:
                        initial, normalization = packet['initial'].copy(), packet['normalization'].copy()
                    differences = []
                    for fraction in (0., .5, 1.):
                        stamp = shorter.port.times[0] + fraction * shorter.span
                        old = shorter.system(stamp)
                        new = longer.system(stamp)
                        matrix_scale = np.maximum(np.max(abs(old['matrix']), axis=1), 1e-100)
                        matrix_error = float(np.max(np.max(abs(old['matrix'] - new['matrix']), axis=1) / matrix_scale))
                        source_errors = {}
                        for name in ('potential', 'lapse', 'alpha'):
                            amplitude = max(float(np.max(abs(old[name]))), 1e-100)
                            source_errors[name] = float(np.max(abs(old[name] - new[name])) / amplitude)
                        differences.append(dict(fraction=fraction, matrix_error=matrix_error, source_errors=source_errors))
                    first, coarse = longer.prepare(16)
                    second, fine = longer.prepare(32)
                    stencil = float(np.max(abs(first - second) / normalization))
                    retained_seed_difference = float(np.max(abs(initial - second) / normalization))
                    passed = bool(coarse['passed'] and fine['passed'] and max(stencil, retained_seed_difference,
                            *(row['matrix_error'] for row in differences),
                            *(value for row in differences for value in row['source_errors'].values())) <= GATE)
                    np.savez_compressed(ROOT / (tag + '-initial.npz'), initial=initial, normalization=normalization,
                                        times=longer.port.times, freshly_prepared=second)
                    reports.append(dict(case=case, count=count, differences=differences, coarse=coarse, fine=fine,
                                        stencil_difference=stencil, saved_seed_difference=retained_seed_difference, passed=passed,
                                        exact_saved_seed_reused=True, packet_sha256=digest(ROOT / (tag + '-initial.npz'))))
                    print(json.dumps(dict(case=case, count=count, passed=passed, saved_seed_difference=retained_seed_difference,
                                          max_overlap_matrix_error=max(row['matrix_error'] for row in differences))), flush=True)
                finally:
                    longer.close()
                    shorter.close()
        write('interface-result.json', dict(passed=all(row['passed'] for row in reports), reports=reports,
              code_sha256=digest(__file__), model_sha256=digest(ROOT / 'wide_operator.py')))
        require(all(row['passed'] for row in reports), 'extended interface and reused preparation')


if __name__ == '__main__':
    main()
