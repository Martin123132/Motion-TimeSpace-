from wide_support import *
from angular_boundary import BoundaryOperator, load_trajectory, response17, reference
import argparse
import numpy as np
from shared_operator import defects


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    args = parser.parse_args()
    with worker('analyse-boundary-' + args.case):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'frozen parent sources')
        operator = BoundaryOperator(args.case, 2)
        try:
            positions = np.linspace(0., SPAN, 9)
            targets = operator.port.times[0] + operator.port.state_spline(positions)[:, 3]
            fractions = (targets - operator.port.times[0]) / operator.span
            fractions[0], fractions[-1] = 0., 1.
            aligned, raw, clocks = {}, {}, {}
            for steps in (128, 256):
                states, clock, normalization = load_trajectory(args.case, 2, steps)
                raw[steps], clocks[steps] = states, clock
                full = np.column_stack((states, np.ones(len(states))))
                scale = np.r_[normalization, 1.]
                values = []
                for target in targets:
                    index = min(int(np.searchsorted(clock, target, side='right')) - 1, len(clock) - 1)
                    require(index >= 0, 'readout target covered')
                    values.append(reference.analysis_module.advance(operator, full[index], clock[index], target, scale))
                aligned[steps] = np.array(values)
            step_difference = float(np.max(abs(aligned[256] - aligned[128]) / scale))
            boundary_difference = float(np.max(abs(raw[256][::2] - raw[128]) / normalization))
            fields = ['phi', 'psi', 'density', 'current', 'anisotropy']
            if args.case == 'heavy':
                fields += ['heavy_density', 'heavy_current', 'heavy_pressure']
            readouts, coarse_readouts, diagnostics = [], [], []
            for index, fraction in enumerate(fractions):
                guard()
                sample = operator.sample(float(fraction), keep_matrix=False)
                readouts.append({name: float(sample[name].astype(np.longdouble) @ aligned[256][index].astype(np.longdouble)) for name in fields})
                coarse_readouts.append({name: float(sample[name].astype(np.longdouble) @ aligned[128][index].astype(np.longdouble)) for name in fields})
                for divisions in (16, 32):
                    jets = reference.analysis_module.jets_inside(operator, float(fraction), divisions)
                    diagnostics.append(dict(fraction=float(fraction), divisions=divisions,
                                            metrics=defects(operator, jets, aligned[256][index])))
            source_step_checks = {name: reference.analysis_module.field_comparison(
                                 np.array([row[name] for row in coarse_readouts]), np.array([row[name] for row in readouts])) for name in fields}
            metric = reference.sample_metric(operator.core, raw[256], clocks[256])
            phase_control = reference.phase_control(operator.core, clocks[256], 64)
            require(phase_control['passed'], 'final streaming phase accuracy')
            exact, low = reference.respond(operator.core, clocks[256], metric, targets, 64, 10, 1)
            time_control, unused_low = reference.respond(operator.core, clocks[256], metric, targets, 64, 6, 1)
            source_control, unused_low = reference.respond(operator.core, clocks[256], metric, targets, 64, 10, 2)
            momentum_control, unused_low = reference.respond(operator.core, clocks[256], metric, targets, 128, 10, 1)
            actual = []
            nodes, weights = reference.rule(64)
            for stamp, state in zip(targets, aligned[256]):
                context = operator.port.context(float(stamp))
                speed = nodes / np.sqrt(nodes**2 + (context['scale'] * context['neutrino_mass'])**2)
                prefactor = context['neutrino_amplitude'] / context['scale']**2
                modes = state[6:6 + 64 * 17].reshape(64, 17)
                actual.append([np.sum(prefactor * weights * modes[:, 0] / speed),
                               np.sum(prefactor * weights * modes[:, 1]), np.sum(prefactor * weights * speed * modes[:, 2])])
            actual = np.array(actual)
            comparisons = {}
            for name, first in (('characteristic_agreement', actual), ('time_quadrature', time_control),
                                ('metric_interpolation', source_control), ('momentum64_128', momentum_control)):
                comparisons[name] = {field: reference.analysis_module.field_comparison(first[:, index], exact[:, index])
                                     for index, field in enumerate(('density', 'current', 'anisotropy'))}
            final_boundary = response17(operator.core, clocks[256], metric, clocks[256], 10)
            supplied_boundary = np.array([operator.boundary(float(stamp)) for stamp in clocks[256]])
            fixed_point = reference.analysis_module.field_comparison(supplied_boundary, final_boundary)
            first_iteration, first_clock, unused_normalization = load_trajectory(args.case, 1, 256)
            require(np.array_equal(first_clock, clocks[256]), 'same iterated clock')
            iteration_state_difference = float(np.max(abs(first_iteration - raw[256]) / normalization))
            original = read(ROOT / (args.case + '64-result.json'))
            changes = {name: reference.analysis_module.field_comparison(np.array([row[name] for row in original['readouts']]),
                                                                       np.array([row[name] for row in readouts])) for name in fields}
            packet = args.case + '-boundary-analysis.npz'
            np.savez_compressed(ROOT / packet, position=positions, times=targets, coarse=aligned[128], fine=aligned[256],
                                source_clock=clocks[256], metric=metric, exact_moments=exact, actual_moments=actual,
                                final_boundary=final_boundary, supplied_boundary=supplied_boundary, low64=low)
            result = dict(case=args.case, state_step_difference=step_difference, boundary_step_difference=boundary_difference,
                iteration_state_difference=iteration_state_difference, source_step_checks=source_step_checks,
                readouts=readouts, diagnostics=diagnostics, comparisons=comparisons, boundary_fixed_point=fixed_point,
                phase_control=phase_control, change_from_l16=changes, packet_sha256=digest(ROOT / packet),
                code_sha256=digest(__file__), model_sha256=digest(ROOT / 'angular_boundary.py'),
                numerical_passed=max(step_difference, boundary_difference) <= GATE and all(row['passed'] for row in source_step_checks.values()),
                characteristic_passed=all(row['passed'] for group in comparisons.values() for row in group.values()),
                fixed_point_passed=fixed_point['passed'], metric_passed=all(row['metrics']['metric_error'] <= GATE for row in diagnostics),
                identities_passed=all(row['metrics']['identity_error'] <= ALGEBRA for row in diagnostics),
                self_consistency_scope='sampled low moments and every saved boundary; no computed uniform contraction bound')
            write(args.case + '-boundary-analysis-result.json', result)
            print(json.dumps(dict(case=args.case, numerical_passed=result['numerical_passed'],
                characteristic_passed=result['characteristic_passed'], fixed_point_passed=result['fixed_point_passed'],
                metric_error=max(row['metrics']['metric_error'] for row in diagnostics), boundary_fixed_point=fixed_point,
                characteristic_agreement=comparisons['characteristic_agreement'],
                source_step_maximum=max(row['relative_difference'] for row in source_step_checks.values()))), flush=True)
        finally:
            operator.close()


if __name__ == '__main__':
    main()
