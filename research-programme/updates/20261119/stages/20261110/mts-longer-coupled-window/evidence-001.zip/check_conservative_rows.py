from wide_support import *
from wide_operator import WideOperator
import ast
import numpy as np

SharedOperator = WideOperator
source = PREVIOUS / 'check_conservative_rows.py'
definition = next(node for node in ast.parse(source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'main')
exec(compile(ast.Module(body=[definition], type_ignores=[]), str(source), 'exec'), globals())


if __name__ == '__main__':
    main()
