from wide_support import *
from wide_operator import WideOperator
import argparse
import importlib.util
import numpy as np
from numpy.polynomial.legendre import leggauss, Legendre
from scipy.interpolate import CubicSpline
from scipy.special import spherical_jn

analysis_spec = importlib.util.spec_from_file_location('wide_analysis', ROOT / 'analyse_evolution.py')
analysis_module = importlib.util.module_from_spec(analysis_spec)
analysis_spec.loader.exec_module(analysis_module)


def rule(count):
    if count == 64:
        with np.load(POST / 'mts-conservative-neutrino-reference-20261110/shell-rules.npz', allow_pickle=False) as packet:
            return packet['gauss64_nodes'].astype(float), packet['gauss64_weights'].astype(float)
    points, weights = leggauss(count)
    nodes = 30 * (points + 1)
    exponential = np.exp(-nodes)
    weights = 30 * weights * nodes**4 * exponential / ((1 + exponential)**2 * 4 * (7 * np.pi**4 / 120))
    require(np.all(weights > 0), 'positive passive momentum rule')
    return nodes, weights


def kernels(phase):
    bessel = [spherical_jn(ell, phase) for ell in range(5)]
    return bessel[:3], [-bessel[2], 2 * bessel[1] / 5 - 3 * bessel[3] / 5,
                       2 * bessel[2] / 7 - 18 * bessel[4] / 35 - bessel[0] / 5]


def kernel_controls():
    cosine, weights = leggauss(128)
    reports = []
    for phase in (0., .1, 1., 10., 40.):
        bessel, coupling = kernels(phase)
        for ell in range(3):
            basis = Legendre.basis(ell)(cosine)
            wave = np.exp(-1j * phase * cosine)
            isotropic = .5 * 1j**ell * np.sum(weights * basis * wave)
            quadrupole = .5 * 1j**ell * np.sum(weights * basis * Legendre.basis(2)(cosine) * wave)
            error = float(max(abs(isotropic - bessel[ell]), abs(quadrupole - coupling[ell])))
            reports.append(dict(phase=phase, ell=ell, absolute_error=error, passed=error <= ALGEBRA))
    require(all(row['passed'] for row in reports), 'independent angular projection')
    return reports


def sample_metric(operator, states, clock):
    values = []
    for state, stamp in zip(states, clock):
        guard()
        system = operator.system(float(stamp))
        zed = -float(system['matrix'][1].astype(np.longdouble) @ state.astype(np.longdouble)) / operator.port.wave
        sigma = float(system['full_observer'][operator.port.columns['sigma']].astype(np.longdouble) @ state.astype(np.longdouble))
        values.append([zed, sigma])
    return np.array(values)


def phase_control(operator, clock, count):
    nodes, unused_weights = rule(count)
    local = clock - clock[0]
    scale = np.exp(-np.log(11.) + operator.port.position_spline(local))
    speed = nodes[None, :] / np.sqrt(nodes[None, :]**2 + (scale[:, None] * operator.port.owner.neutrino_mass)**2)
    primitive = CubicSpline(local, speed, axis=0).antiderivative()
    quadrature, weights = leggauss(8)
    half = np.diff(local) / 2
    times = ((local[:-1] + half)[:, None] + half[:, None] * quadrature).reshape(-1)
    direct_scale = np.exp(-np.log(11.) + operator.port.position_spline(times))
    direct_speed = nodes[None, :] / np.sqrt(nodes[None, :]**2 + (direct_scale[:, None] * operator.port.owner.neutrino_mass)**2)
    pieces = direct_speed.reshape(len(half), 8, count)
    integrated = np.cumsum(np.sum(pieces * (half[:, None] * weights)[..., None], axis=1), axis=0)
    predicted = primitive(local[1:]) - primitive(0.)
    error = float(operator.port.wave * np.max(abs(predicted - integrated)))
    return dict(count=count, maximum_absolute_phase_difference=error, passed=error <= ALGEBRA)


def respond(operator, clock, metric, target_clock, momentum_count, time_order, stride):
    nodes, weights = rule(momentum_count)
    local = clock - clock[0]
    source = CubicSpline(local[::stride], metric[::stride], axis=0)
    position = operator.port.position_spline(local)
    scale = np.exp(-np.log(11.) + position)
    speed = nodes[None, :] / np.sqrt(nodes[None, :]**2 + (scale[:, None] * operator.port.owner.neutrino_mass)**2)
    primitive = CubicSpline(local, speed, axis=0).antiderivative()
    zero = primitive(0.)
    quadrature, quadrature_weight = leggauss(time_order)
    outputs, mode_values = [], []
    for stamp in target_clock:
        guard()
        endpoint = float(stamp - clock[0])
        edges = np.r_[local[local < endpoint], endpoint]
        if len(edges) > 1:
            half = np.diff(edges) / 2
            times = ((edges[:-1] + half)[:, None] + half[:, None] * quadrature).reshape(-1)
            time_weights = (half[:, None] * quadrature_weight).reshape(-1)
            delayed = operator.port.wave * (primitive(endpoint)[None, :] - primitive(times))
            require(np.min(delayed) >= -1e-10, 'causal nonnegative streaming phase')
            delayed = np.maximum(delayed, 0.)
            bessel, coupling = kernels(delayed)
            sources = source(times)
            driven = np.array([np.sum(time_weights[:, None] * (-4 * operator.port.wave * sources[:, 0, None] * bessel[ell] / 3
                                - 8 * operator.port.wave * sources[:, 1, None] * coupling[ell] / 3), axis=0) for ell in range(3)])
        else:
            driven = np.zeros((3, momentum_count))
        phase = operator.port.wave * (primitive(endpoint) - zero)
        low = np.array([4e-6 * spherical_jn(ell, np.maximum(phase, 0.)) for ell in range(3)]) + driven
        context = operator.port.context(float(stamp))
        speed_now = nodes / np.sqrt(nodes**2 + (context['scale'] * context['neutrino_mass'])**2)
        prefactor = context['neutrino_amplitude'] / context['scale']**2
        outputs.append([np.sum(prefactor * weights * low[0] / speed_now),
                        np.sum(prefactor * weights * low[1]), np.sum(prefactor * weights * speed_now * low[2])])
        mode_values.append(low)
    return np.array(outputs), np.array(mode_values)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    args = parser.parse_args()
    with worker('characteristic-' + args.case):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'same retained sources')
        controls = kernel_controls()
        operator = WideOperator(args.case, 64)
        try:
            states, clock, normalization, receipts = analysis_module.history(args.case, 64, 256)
            metric = sample_metric(operator, states, clock)
            phase_checks = [phase_control(operator, clock, count) for count in (64, 128, 256)]
            require(all(row['passed'] for row in phase_checks), 'independent streaming-phase integration')
            with np.load(ROOT / (args.case + '64-forward.npz'), allow_pickle=False) as packet:
                targets, aligned = packet['times'].copy(), packet['fine'].copy()
            values = {}
            low64 = None
            for count, order, stride in ((64, 6, 1), (64, 10, 1), (64, 10, 2), (128, 10, 1), (256, 10, 1)):
                response, low = respond(operator, clock, metric, targets, count, order, stride)
                values[f'n{count}-o{order}-s{stride}'] = response
                if (count, order, stride) == (64, 10, 1):
                    low64 = low
            native = []
            for stamp, state in zip(targets, aligned):
                context = operator.port.context(float(stamp))
                nodes, weights = rule(64)
                speed = nodes / np.sqrt(nodes**2 + (context['scale'] * context['neutrino_mass'])**2)
                prefactor = context['neutrino_amplitude'] / context['scale']**2
                modes = state[6:6 + 64 * 17].reshape(64, 17)
                native.append([np.sum(prefactor * weights * modes[:, 0] / speed),
                               np.sum(prefactor * weights * modes[:, 1]), np.sum(prefactor * weights * speed * modes[:, 2])])
            values['retained-l16'] = np.array(native)
            comparisons = {}
            pairs = [('time_quadrature', 'n64-o6-s1', 'n64-o10-s1'),
                     ('source_interpolation', 'n64-o10-s2', 'n64-o10-s1'),
                     ('angular_closure', 'retained-l16', 'n64-o10-s1'),
                     ('momentum64_128', 'n64-o10-s1', 'n128-o10-s1'),
                     ('momentum128_256', 'n128-o10-s1', 'n256-o10-s1')]
            for name, first, second in pairs:
                comparisons[name] = {field: analysis_module.field_comparison(values[first][:, index], values[second][:, index])
                                     for index, field in enumerate(('density', 'current', 'anisotropy'))}
            packet = args.case + '-characteristic.npz'
            np.savez_compressed(ROOT / packet, times=clock, metric=metric, target_times=targets,
                                low64=low64, **values)
            result = dict(case=args.case, kernel_controls=controls, phase_checks=phase_checks, comparisons=comparisons,
                source_receipts=receipts, packet_sha256=digest(ROOT / packet), code_sha256=digest(__file__),
                contract_sha256=digest(ROOT / 'CHARACTERISTIC-CONTRACT.md'),
                conditional_on_saved_metric=True, self_consistent_new_prediction=False,
                numerical_control_passed=all(row['passed'] for name in ('time_quadrature', 'source_interpolation') for row in comparisons[name].values()))
            write(args.case + '-characteristic-result.json', result)
            print(json.dumps(dict(case=args.case, numerical_control_passed=result['numerical_control_passed'], comparisons=comparisons)), flush=True)
        finally:
            operator.close()


if __name__ == '__main__':
    main()
