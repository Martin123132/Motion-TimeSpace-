from wide_support import *
import ast
import ctypes
import numpy as np
from scipy.interpolate import CubicSpline


def main():
    with worker('regime-thermal'):
        require(read(ROOT / 'background-result.json')['passed'], 'extended background')
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'same sources')
        build = RAD / 'build'
        require(digest(build / 'native/camb/cambdll.dll') == read(RAD / 'build-result.json')['dll_sha256'], 'retained isolated DLL')
        sys.path.insert(0, str(build / 'native'))
        import camb
        from camb.mts import MTSTwoField
        branch = POST / 'condensate-origin-20261003'
        sys.path.append(str(branch / 'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        source = branch / 'native-heavy-matching-20261007/matching_common.py'
        factory = next(node for node in ast.parse(source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(source), 'exec'), namespace)
        library = camb.baseconfig.camblib
        library.mts_capture_reset.argtypes = []
        library.mts_capture_reset.restype = None
        observer_dll = ctypes.CDLL(str(POST / 'mts-metric-feedback-20261107/observer.dll'))
        observer_function = ctypes.cast(observer_dll.source_func_, ctypes.c_void_p)
        reports = []
        for case in ('cold', 'heavy'):
            config = read(PORT / 'runs' / (case + '-v4') / 'config.json')
            with np.load(PORT / 'runs' / (case + '-v4') / 'capture.npz', allow_pickle=False) as reference:
                names = reference['observer_names'].tolist()
                signature = reference['signature'].copy()
            native = camb.get_background(namespace['params_for'](Path(config['table'])))
            try:
                positions = np.linspace(0., SPAN, 641)
                redshifts = 11 * np.exp(-positions) - 1
                thermal = native.get_background_redshift_evolution(redshifts, vars=['opacity', 'cs2b'])
                values = np.column_stack([thermal[name] for name in ('opacity', 'cs2b')])
                spline = CubicSpline(positions[::2], values[::2], axis=0)
                errors = np.max(abs(spline(positions[1::2]) - values[1::2]) / np.maximum(abs(values[1::2]), 1e-100), axis=0)
                with np.load(PREVIOUS / (case + '-thermal.npz'), allow_pickle=False) as old:
                    overlap = np.max(abs(spline(old['positions']) - old['values']) / np.maximum(abs(old['values']), 1e-100))
                probes = np.linspace(0., SPAN, 17)
                times = np.ascontiguousarray(native.conformal_time(11 * np.exp(-probes) - 1, tol=1e-10))
                native.Params.Accuracy.IntTolBoost = 6
                native.Params.Accuracy.lAccuracyBoost = 4
                library.mts_capture_reset()
                for name in ('step', 'kind', 'count', 'tangent'):
                    ctypes.c_int.in_dll(library, 'mts_probe_' + name).value = 0
                for name, value in (('begin', 1), ('end', len(times)), ('q_index', 1)):
                    ctypes.c_int.in_dll(library, 'mts_capture_' + name).value = value
                modes = np.array([5.])
                columns = len(camb.model.evolve_names) + len(names)
                output = np.zeros((1, len(times), columns))
                code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(1)), modes,
                       ctypes.byref(ctypes.c_int(len(times))), times, ctypes.byref(ctypes.c_int(columns)), output,
                       ctypes.byref(ctypes.c_int(len(names))), ctypes.byref(observer_function))
                require(code == 0, 'extended native regime capture')
                captured = np.array(list((ctypes.c_int * 96).in_dll(library, 'mts_capture_signature')))
                snapshots = ctypes.c_int.in_dll(library, 'mts_capture_count').value
                require(snapshots == len(times), 'all extended regime probes captured')
                same = bool(np.array_equal(captured, signature))
                packet = case + '-thermal-regime.npz'
                np.savez_compressed(ROOT / packet, position=positions, values=values, probe_position=probes,
                                    probe_times=times, signature=captured, observed=output)
                report = dict(case=case, snapshots=snapshots, signature_same_as_saved=same,
                              interpolation_errors=errors.tolist(), old_overlap_error=float(overlap),
                              sampled_z_range=[float(redshifts[0]), float(redshifts[-1])],
                              packet_sha256=digest(ROOT / packet), source_table=config['table'],
                              passed=bool(same and max(*errors, overlap) <= GATE))
                reports.append(report)
                print(json.dumps(report), flush=True)
            finally:
                library.mts_capture_reset()
                del native
        write('thermal-regime-result.json', dict(passed=all(row['passed'] for row in reports), reports=reports,
              code_sha256=digest(__file__), scope='17 native regime probes; retained opacity/cs2b as functions of a; no primordial reference prediction'))
        require(all(row['passed'] for row in reports), 'thermal and regime controls')


if __name__ == '__main__':
    main()
