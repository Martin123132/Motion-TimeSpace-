from wide_support import *
from wide_operator import WideOperator
import ast
import argparse
import importlib.util
import numpy as np
from scipy.linalg import expm
from shared_operator import defects

runner_spec = importlib.util.spec_from_file_location('wide_forward_runner', ROOT / 'run_forward.py')
runner_module = importlib.util.module_from_spec(runner_spec)
runner_spec.loader.exec_module(runner_module)
fingerprint = runner_module.fingerprint
helper_path = PREVIOUS / 'evaluate_forward.py'
helpers = [node for node in ast.parse(helper_path.read_text()).body if isinstance(node, ast.FunctionDef)
           and node.name in ('history', 'advance', 'jets_inside')]
require(len(helpers) == 3, 'three retained pure evolution/diagnostic functions')
exec(compile(ast.Module(body=helpers, type_ignores=[]), str(helper_path), 'exec'), globals())


def field_comparison(coarse, fine):
    absolute = float(np.max(abs(coarse - fine)))
    amplitude = float(max(np.max(abs(coarse)), np.max(abs(fine))))
    relative = absolute / amplitude if amplitude else (0. if not absolute else float('inf'))
    return dict(absolute_difference=absolute, maximum_amplitude=amplitude,
                relative_difference=relative, passed=relative <= GATE)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('count', type=int, choices=(32, 64))
    args = parser.parse_args()
    tag = args.case + str(args.count)
    with worker('analyse-' + tag):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'frozen inherited inputs')
        operator = WideOperator(args.case, args.count)
        try:
            positions = np.linspace(0., SPAN, 9)
            targets = operator.port.times[0] + operator.port.state_spline(positions)[:, 3]
            fractions = (targets - operator.port.times[0]) / operator.span
            fractions[0], fractions[-1] = 0., 1.
            aligned, raw, receipts = {}, {}, {}
            for steps in (128, 256):
                states, clock, normalization, hashes = history(args.case, args.count, steps)
                raw[steps] = states
                receipts.update(hashes)
                values = []
                for target in targets:
                    guard()
                    index = min(int(np.searchsorted(clock, target, side='right')) - 1, len(clock) - 1)
                    require(index >= 0, 'covered common-scale-factor target')
                    values.append(advance(operator, states[index], clock[index], target, normalization))
                aligned[steps] = np.array(values)
            refinement = float(np.max(abs(aligned[256] - aligned[128]) / normalization))
            boundary_refinement = float(np.max(abs(raw[256][::2] - raw[128]) / normalization))
            readouts, coarse_readouts, diagnostics, source_order, angular = [], [], [], [], []
            fields = ['phi', 'psi', 'density', 'current', 'anisotropy']
            if args.case == 'heavy':
                fields += ['heavy_density', 'heavy_current', 'heavy_pressure']
            for index, fraction in enumerate(fractions):
                guard()
                sample = operator.sample(float(fraction))
                fine, coarse = aligned[256][index].astype(np.longdouble), aligned[128][index].astype(np.longdouble)
                readouts.append({name: float(sample[name].astype(np.longdouble) @ fine) for name in fields})
                coarse_readouts.append({name: float(sample[name].astype(np.longdouble) @ coarse) for name in fields})
                for divisions in (16, 32):
                    jets = jets_inside(operator, float(fraction), divisions)
                    metrics = defects(operator, jets, fine)
                    diagnostics.append(dict(position=float(positions[index]), fraction=float(fraction), divisions=divisions, metrics=metrics))
                    if divisions == 32:
                        state_rate = jets['matrix'][0].astype(np.longdouble) @ fine
                        source_order.append(dict(position=float(positions[index]),
                            density=float(jets['missing_density'][0] @ fine),
                            pressure=float(jets['missing_pressure'][0] @ fine),
                            density_rate=float(jets['missing_density'][1] @ fine + jets['missing_density'][0] @ state_rate),
                            pressure_rate=float(jets['missing_pressure'][1] @ fine + jets['missing_pressure'][0] @ state_rate)))
                multipoles = aligned[256][index, 6:6 + args.count * 17].reshape(args.count, 17)
                stamp = float(targets[index])
                context = operator.port.context(stamp)
                speed = operator.port.nodes / np.sqrt(operator.port.nodes**2 + (context['scale'] * context['neutrino_mass'])**2)
                weights = context['neutrino_amplitude'] * operator.port.weights / (context['scale']**2 * speed)
                seed_scale = float(np.sum(weights) * 4e-6)
                angular.append(dict(position=float(positions[index]),
                    weighted_l15_relative_seed=float(np.sum(weights * abs(multipoles[:, 15])) / seed_scale),
                    weighted_l16_relative_seed=float(np.sum(weights * abs(multipoles[:, 16])) / seed_scale),
                    maximum_l16_relative_seed=float(np.max(abs(multipoles[:, 16])) / 4e-6),
                    maximum_streaming_phase_estimate=float(np.max(operator.port.nodes / np.sqrt(operator.port.nodes**2 +
                        (np.exp(-np.log(11.)) * context['neutrino_mass'])**2)) * operator.port.wave * (stamp - operator.port.times[0]))))
            source_checks = {name: field_comparison(np.array([row[name] for row in coarse_readouts]),
                                                   np.array([row[name] for row in readouts])) for name in fields}
            amplitude = max(abs(row['density']) for row in source_order)
            ordering = dict(source_peak_density=amplitude,
                maximum_density_rate_over_k_peak_density=max(abs(row['density_rate']) for row in source_order) / (operator.port.wave * amplitude) if amplitude else None,
                maximum_pressure_over_peak_density=max(abs(row['pressure']) for row in source_order) / amplitude if amplitude else None,
                maximum_pressure_rate_over_k_peak_density=max(abs(row['pressure_rate']) for row in source_order) / (operator.port.wave * amplitude) if amplitude else None)
            packet = tag + '-forward.npz'
            require(not (ROOT / packet).exists(), 'no diagnostic overwrite')
            np.savez_compressed(ROOT / packet, position=positions, times=targets, fractions=fractions,
                                coarse=aligned[128], fine=aligned[256], normalization=normalization)
            result = dict(case=args.case, count=args.count, numerical_passed=max(refinement, boundary_refinement) <= GATE,
                source_step_passed=all(row['passed'] for row in source_checks.values()), source_step_checks=source_checks,
                aligned_step_difference=refinement, shared_boundary_step_difference=boundary_refinement,
                diagnostics=diagnostics, readouts=readouts, coarse_readouts=coarse_readouts, source_order=source_order,
                source_order_summary=ordering, angular_tail=angular, angular_accuracy_tested=False,
                metric_passed=all(row['metrics']['metric_error'] <= GATE for row in diagnostics),
                identities_passed=all(row['metrics']['identity_error'] <= ALGEBRA for row in diagnostics),
                source_receipts=receipts, packet_sha256=digest(ROOT / packet), code_sha256=digest(__file__),
                retained_helpers_sha256=digest(helper_path), grid=positions.tolist(),
                scope='controlled late IVP at retained angular cutoff; sampled tests, not uniform certification')
            write(tag + '-result.json', result)
            print(json.dumps(dict(case=args.case, count=args.count, numerical_passed=result['numerical_passed'],
                source_step_passed=result['source_step_passed'], refinement=refinement,
                metric_error=max(row['metrics']['metric_error'] for row in diagnostics),
                source_step_error=max(row['relative_difference'] for row in source_checks.values()),
                largest_weighted_l16=max(row['weighted_l16_relative_seed'] for row in angular),
                ordering=ordering)), flush=True)
        finally:
            operator.close()


if __name__ == '__main__':
    main()
