from wide_support import *
from angular_boundary import *
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('iteration', type=int, choices=(1, 2))
    args = parser.parse_args()
    tag = f'{args.case}-boundary{args.iteration}'
    with worker(tag):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'retained sources')
        controls = kernel17_controls()
        operator = WideOperator(args.case, 64)
        try:
            states, clock, normalization = load_trajectory(args.case, args.iteration - 1)
            metric = reference.sample_metric(operator, states, clock)
            phases = reference.phase_control(operator, clock, 64)
            require(phases['passed'], 'phase accuracy')
            targets = requested_times(operator)
            fine = response17(operator, clock, metric, targets, 10)
            control_indices = np.unique(np.linspace(0, len(targets) - 1, 33).astype(int))
            coarse = response17(operator, clock, metric, targets[control_indices], 6)
            absolute = float(np.max(abs(coarse - fine[control_indices])))
            amplitude = float(np.max(abs(fine)))
            error = absolute / amplitude if amplitude else 0.
            np.savez_compressed(ROOT / (tag + '.npz'), times=targets, values=fine, source_clock=clock, source_metric=metric,
                                control_indices=control_indices, coarse=coarse)
            if args.iteration == 1:
                source_hashes = reference.analysis_module.history(args.case, 64, 256)[3]
            else:
                path = f'closed-{args.case}-i{args.iteration - 1}-s256.npz'
                source_hashes = {path: digest(ROOT / path)}
            result = dict(case=args.case, iteration=args.iteration, passed=error <= GATE,
                          sample_count=len(targets), kernel_errors=controls, phase_control=phases,
                          quadrature_difference=error, quadrature_absolute_difference=absolute,
                          source_hashes=source_hashes, packet_sha256=digest(ROOT / (tag + '.npz')),
                          code_sha256=digest(__file__), model_sha256=digest(ROOT / 'angular_boundary.py'),
                          contract_sha256=digest(ROOT / 'ANGULAR-REPAIR-CONTRACT.md'),
                          conditional_on_input_metric=True, no_temporal_interpolation_in_evolution=True)
            write(tag + '-result.json', result)
            print(json.dumps(dict(case=args.case, iteration=args.iteration, passed=result['passed'],
                                  bank_points=len(targets), quadrature_difference=error)), flush=True)
            require(result['passed'], 'angular boundary bank accuracy')
        finally:
            operator.close()


if __name__ == '__main__':
    main()
