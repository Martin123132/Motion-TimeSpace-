from common import *
import sympy as sym


def main():
    with worker("proof-fixed"):
        inputs = sources()
        half = sym.Rational(1, 2)
        scale, hubble, mass, wave, field, speed, fluctuation, fluctuation_speed, lapse, potential, shift, gradient = sym.symbols("scale hubble mass wave field speed fluctuation fluctuation_speed lapse potential shift gradient", real=True)
        parameter = sym.Symbol("parameter", real=True)
        kinetic_prefactor = (1 - 2 * parameter * potential)**sym.Rational(3, 2) / sym.sqrt(1 + 2 * parameter * lapse)
        mass_prefactor = sym.sqrt(1 + 2 * parameter * lapse) * (1 - 2 * parameter * potential)**sym.Rational(3, 2)
        kinetic_expansion = sum(sym.diff(kinetic_prefactor, parameter, order).subs(parameter, 0) * parameter**order / sym.factorial(order) for order in range(3))
        mass_expansion = sum(sym.diff(mass_prefactor, parameter, order).subs(parameter, 0) * parameter**order / sym.factorial(order) for order in range(3))
        exact_second = sym.expand(scale**2 * half * (kinetic_expansion * (speed + parameter * fluctuation_speed - parameter**2 * shift * gradient)**2 - mass_expansion * mass**2 * (field + parameter * fluctuation)**2 - parameter**2 * wave**2 * fluctuation**2)).coeff(parameter, 2)
        combined, difference = lapse + 3 * potential, 3 * potential - lapse
        metric_mass = sym.Rational(3, 2) * potential**2 - 3 * lapse * potential - lapse**2 / 2
        expected = scale**2 * half * (fluctuation_speed**2 - (wave**2 + mass**2) * fluctuation**2) - scale**2 * combined * speed * fluctuation_speed + scale**2 * mass**2 * difference * field * fluctuation + scale**2 * half * (sym.Rational(3, 2) * (lapse + potential)**2 * speed**2 - mass**2 * metric_mass * field**2) - scale**2 * speed * shift * gradient
        background = (speed**2 + mass**2 * field**2) / 2
        background_pressure = (speed**2 - mass**2 * field**2) / 2
        density_source = speed * fluctuation_speed - speed**2 * lapse + mass**2 * field * fluctuation
        pressure_source = speed * fluctuation_speed - speed**2 * lapse - mass**2 * field * fluctuation
        expressions = {
            "full_parent_quadratic_expansion": exact_second - expected,
            "lapse_energy_source_and_measure": sym.diff(expected, lapse) + scale**2 * (density_source - combined * background),
            "spatial_pressure_source_and_measure": sym.diff(expected, potential) + 3 * scale**2 * (pressure_source + (lapse - potential) * background_pressure),
            "shift_momentum_source": sym.diff(expected, shift) + scale**2 * speed * gradient,
        }
        realpart, imagpart, realprime, imagprime, carrier, sideband, slope0, slopek, hubble_prime, residual0, residualk = sym.symbols("realpart imagpart realprime imagprime carrier sideband slope0 slopek hubble_prime residual0 residualk", real=True)
        dress_real, dress_imag, dress_real_prime, dress_imag_prime, combined_prime = sym.symbols("dress_real dress_imag dress_real_prime dress_imag_prime combined_prime", real=True)
        combined_symbol = sym.Symbol("combined", real=True)
        omega0 = mass**2 - hubble_prime - hubble**2
        omegak = omega0 + wave**2
        slope0_prime = residual0 - slope0**2 + carrier**2 - omega0
        slopek_prime = residualk - slopek**2 + sideband**2 - omegak
        affine_real = dress_real - combined_symbol * (slope0 - hubble)
        affine_imag = dress_imag + combined_symbol * carrier
        affine_real_prime = dress_real_prime - combined_prime * (slope0 - hubble) - combined_symbol * (slope0_prime - hubble_prime)
        affine_imag_prime = dress_imag_prime + combined_prime * carrier - 2 * combined_symbol * slope0 * carrier
        momentum = sym.Matrix([slopek * realpart + sideband * imagpart + affine_real, slopek * imagpart - sideband * realpart + affine_imag])
        path_velocity = sym.Matrix([realprime + slope0 * realpart + carrier * imagpart, imagprime + slope0 * imagpart - carrier * realpart])
        embedded_velocity = sym.Matrix([slopek * realpart + sideband * imagpart + dress_real, slopek * imagpart - sideband * realpart + dress_imag])
        force_real = hubble * combined_symbol * (slope0 - hubble) + mass**2 * (combined_symbol - 2 * lapse)
        force_imag = -hubble * combined_symbol * carrier
        pulled = (momentum.dot(path_velocity) - (embedded_velocity.dot(embedded_velocity) + omegak * (realpart**2 + imagpart**2)) / 2 + force_real * realpart + force_imag * imagpart) / carrier
        boundary_prime = (slopek_prime + 2 * slope0 * slopek) * (realpart**2 + imagpart**2) / (2 * carrier) + slopek * (realpart * realprime + imagpart * imagprime) / carrier
        boundary_prime += 2 * (slopek - slope0) * sideband * realpart * imagpart / carrier - sideband * (realprime * imagpart + realpart * imagprime) / carrier
        boundary_prime += ((affine_real_prime + 2 * slope0 * affine_real) * realpart + (affine_imag_prime + 2 * slope0 * affine_imag) * imagpart + affine_real * realprime + affine_imag * imagprime) / carrier
        source_real = combined_prime * (slope0 - hubble) - 2 * mass**2 * lapse
        source_imag = -combined_prime * carrier
        defect_real = dress_real_prime + (slope0 + slopek) * dress_real + (carrier + sideband) * dress_imag - source_real
        defect_imag = dress_imag_prime + (slope0 + slopek) * dress_imag - (carrier + sideband) * dress_real - source_imag
        weight = 2 * sideband / carrier
        gamma, beat = slopek - slope0, sideband - carrier
        hamiltonian = beat * (realpart**2 + imagpart**2) / 2 + gamma * realpart * imagpart + dress_real * imagpart - dress_imag * realpart
        hamiltonian += residualk * (realpart**2 + imagpart**2) / (4 * sideband) + ((defect_real - combined_symbol * residual0) * realpart + defect_imag * imagpart) / (2 * sideband) + (dress_real**2 + dress_imag**2) / (4 * sideband)
        expressions["actual_action_pullback_and_boundary"] = pulled - boundary_prime - weight * (imagpart * realprime - hamiltonian)
        expected_real = gamma * realpart + (beat + residualk / (2 * sideband)) * imagpart + dress_real + defect_imag / (2 * sideband)
        expected_imag = -(beat + residualk / (2 * sideband)) * realpart + gamma * imagpart + dress_imag - (defect_real - combined_symbol * residual0) / (2 * sideband)
        expressions["weighted_real_hamilton_equation"] = sym.diff(hamiltonian, imagpart) - expected_real
        expressions["weighted_imag_hamilton_equation"] = -sym.diff(hamiltonian, realpart) + 2 * gamma * imagpart - expected_imag
        expressions["symplectic_weight_connection"] = (-2 * slopek * sideband / carrier + 2 * slope0 * sideband / carrier) / (sideband / carrier) + 2 * gamma
        physical0, physicalk = slope0 - hubble, slopek - hubble
        denominator = carrier**2 + mass**2 + physical0**2
        mapping = 2 / denominator * sym.Matrix([[physical0 * physicalk + carrier * sideband + mass**2, physical0 * sideband - carrier * physicalk], [-mass * physical0, mass * carrier]])
        determinant = 4 * mass * (sideband * (carrier**2 + physical0**2) + carrier * mass**2) / denominator**2
        expressions["source_map_determinant"] = mapping.det() - determinant
        expressions["flat_parent_weight"] = (weight / determinant).subs({slope0: 0, slopek: 0, hubble: 0, carrier: mass}) - 2 * sideband / (sideband + mass)
        time_symbol = sym.Symbol("time", real=True)
        response_rate, response_source = sym.Function("response_rate")(time_symbol), sym.Function("response_source")(time_symbol)
        leading = response_source / response_rate
        correction = -sym.diff(leading, time_symbol) / response_rate
        expressions["derived_first_response_correction"] = sym.diff(leading, time_symbol) + response_rate * correction
        expressions["next_response_defect"] = sym.diff(leading + correction, time_symbol) + response_rate * (leading + correction) - response_source - sym.diff(correction, time_symbol)
        entries = sym.symbols("map00 map01 map10 map11 dot00 dot01 dot10 dot11", real=True)
        transform = sym.Matrix(2, 2, entries[:4])
        transform_prime = sym.Matrix(2, 2, entries[4:])
        original_flow = sym.Matrix([[gamma, beat], [-beat, gamma]])
        transformed_flow = (transform_prime + transform * original_flow) * transform.inv()
        determinant_prime = entries[4] * entries[3] + entries[0] * entries[7] - entries[5] * entries[2] - entries[1] * entries[6]
        expressions["affine_source_weight_trace"] = sym.trace(transformed_flow) - 2 * gamma - determinant_prime / transform.det()
        identities = {}
        for name, expression in expressions.items():
            guard()
            reduced = sym.factor(expression)
            identities[name] = str(reduced)
            if reduced != 0:
                raise ValueError(name + ":" + str(reduced))
        result = dict(passed=True, identities=identities, exact_identity_count=len(identities),
                      full_metric_terms_retained=True, eliminated_response_not_held_fixed_for_gravity=True,
                      population_selected=False, coupled_einstein_solution=False,
                      sources=inputs, code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"),
                      derivation_sha256=digest(ROOT / "DERIVATION.md"), protocol_sha256=digest(ROOT / "PROTOCOL.md"))
        write("proof.json", result)
        print(json.dumps(dict(passed=True, exact_identities=len(identities), sources=len(inputs))), flush=True)


if __name__ == "__main__":
    main()
