from common import *
import importlib
import importlib.util

current_common = sys.modules["common"]
specification = importlib.util.spec_from_file_location("retained_transport_common", PREVIOUS / "common.py")
retained_common = importlib.util.module_from_spec(specification)
specification.loader.exec_module(retained_common)
sys.modules["common"] = retained_common
sys.path.insert(0, str(PREVIOUS))
try:
    model = importlib.import_module("model")
    phase = importlib.import_module("phase_repair")
    dressing = importlib.import_module("dressing_diagnostic")
finally:
    sys.path.remove(str(PREVIOUS))
    sys.modules["common"] = current_common

StableCase = phase.StableCase
