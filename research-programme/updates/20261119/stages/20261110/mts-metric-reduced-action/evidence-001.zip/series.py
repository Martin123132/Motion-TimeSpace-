import numpy as np

ORDER = 6


class Series:
    __array_priority__ = 1000

    def __init__(self, value=0, coefficients=None):
        if coefficients is not None:
            self.coefficients = np.asarray(coefficients).copy()
        else:
            values = np.asarray(value).reshape(-1)
            self.coefficients = np.zeros((ORDER + 1, len(values)), dtype=np.result_type(values, float))
            self.coefficients[0] = values

    def __add__(self, other):
        other = as_series(other)
        return Series(coefficients=self.coefficients + other.coefficients)

    __radd__ = __add__

    def __neg__(self):
        return Series(coefficients=-self.coefficients)

    def __sub__(self, other):
        return self + (-as_series(other))

    def __rsub__(self, other):
        return as_series(other) - self

    def __mul__(self, other):
        other = as_series(other)
        columns = max(self.coefficients.shape[1], other.coefficients.shape[1])
        result = np.zeros((ORDER + 1, columns), dtype=np.result_type(self.coefficients, other.coefficients))
        for degree in range(ORDER + 1):
            for left in range(degree + 1):
                result[degree] += self.coefficients[left] * other.coefficients[degree - left]
        return Series(coefficients=result)

    __rmul__ = __mul__

    def reciprocal(self):
        if np.any(self.coefficients[0] == 0):
            raise ValueError("zero series divisor")
        result = np.zeros_like(self.coefficients)
        result[0] = 1 / self.coefficients[0]
        for degree in range(1, ORDER + 1):
            for left in range(1, degree + 1):
                result[degree] -= self.coefficients[left] * result[degree - left]
            result[degree] /= self.coefficients[0]
        return Series(coefficients=result)

    def __truediv__(self, other):
        return self * as_series(other).reciprocal()

    def __rtruediv__(self, other):
        return as_series(other) / self

    def __pow__(self, exponent):
        if not isinstance(exponent, int):
            raise ValueError("integer series power required")
        if exponent < 0:
            return self.reciprocal()**(-exponent)
        result = Series(1)
        for _ in range(exponent):
            result = result * self
        return result

    def derivative(self):
        result = np.zeros_like(self.coefficients)
        for degree in range(ORDER):
            result[degree] = (degree + 1) * self.coefficients[degree + 1]
        return Series(coefficients=result)

    def exp(self):
        result = np.zeros_like(self.coefficients)
        result[0] = np.exp(self.coefficients[0])
        for degree in range(1, ORDER + 1):
            for left in range(1, degree + 1):
                result[degree] += left * self.coefficients[left] * result[degree - left]
            result[degree] /= degree
        return Series(coefficients=result)

    def sqrt(self):
        result = np.zeros_like(self.coefficients)
        if np.any(self.coefficients[0] <= 0):
            raise ValueError("positive series square root required")
        result[0] = np.sqrt(self.coefficients[0])
        for degree in range(1, ORDER + 1):
            result[degree] = self.coefficients[degree]
            for left in range(1, degree):
                result[degree] -= result[left] * result[degree - left]
            result[degree] /= 2 * result[0]
        return Series(coefficients=result)

    def real(self):
        return Series(coefficients=self.coefficients.real)

    def imag(self):
        return Series(coefficients=self.coefficients.imag)

    @property
    def value(self):
        return self.coefficients[0]


def as_series(value):
    return value if isinstance(value, Series) else Series(value)
