from common import *
import ast


if __name__ == "__main__":
    with worker("seal") as identity:
        validation = read(ROOT / "validation.json")
        if not validation["passed"] or not all(row["passed"] for row in validation["checks"]):
            raise ValueError("validation not passed")
        if validation["code_sha256"] != digest(ROOT / "validate_action.py") or validation["boundary_addendum_sha256"] != digest(ROOT / "BOUNDARY-ADDENDUM.md"):
            raise ValueError("validation owner changed")
        for filename, checksum in validation["reports"].items():
            if digest(ROOT / filename) != checksum:
                raise ValueError("validated report changed " + filename)
        inputs = sources()
        if read(ROOT / "proof.json")["sources"] != inputs:
            raise ValueError("preserved inputs changed")
        for path, checksum in validation["context_only_sources"].items():
            if digest(path) != checksum:
                raise ValueError("next-step source changed " + path)
        cleanup = []
        for prefix in ("proof", "proof-fixed", "coefficients", "evolution", "conservation", "validation"):
            start, end = read(ROOT / (prefix + "-start.json")), read(ROOT / (prefix + "-end.json"))
            expected = "failed" if prefix == "proof" else "completed"
            if end["state"] != expected or any(start[key] != end[key] for key in ("pid", "created", "command")):
                raise ValueError("unexpected worker terminal record " + prefix)
            try:
                live = abs(psutil.Process(start["pid"]).create_time() - start["created"]) < .001
            except psutil.NoSuchProcess:
                live = False
            if live:
                raise ValueError("owned worker still live " + prefix)
            cleanup.append(dict(stage=prefix, **start, state=expected, exited=True))
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        if list(ROOT.rglob("__pycache__")):
            raise ValueError("bytecode residue")
        for filename in ("RESULTS.md", "NEXT.md", "DERIVATION.md", "BOUNDARY-ADDENDUM.md", "FREE-RESPONSE-BOUND.md"):
            if not (ROOT / filename).is_file() or (ROOT / filename).stat().st_size < 100:
                raise ValueError("missing stage document")
        action = read(ROOT / "action-result.json")
        manifest = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size) for path in ROOT.rglob("*") if path.is_file()}
        result = dict(state="verified", time=datetime.now(timezone.utc).isoformat(), artifacts=manifest,
                      input_hashes=inputs, context_only_sources=validation["context_only_sources"], cleanup=cleanup, sealer=identity,
                      exact_identities=15, coefficient_checks=len(read(ROOT / "coefficients-result.json")["checks"]),
                      evolution_checks=len(action["checks"]), validation_checks=len(validation["checks"]),
                      microscopic_comparisons=action["comparisons"], cold_native_passed=action["cold_native_passed"],
                      pure_metric_and_shift_sources_derived=True, conditional_fast_component=True,
                      full_late_metric_evolution_completed=False, uniform_reduction_certificate=False,
                      no_original_changes=True, no_galaxy_edits=True, no_github=True, no_relay_or_timer=True,
                      broad_goal_complete=False)
        write("closeout.json", result)
        print(json.dumps(dict(closeout_sha256=digest(ROOT / "closeout.json"), artifacts=len(manifest), sources=len(inputs), cleanup=cleanup, sealer=identity)), flush=True)
