from common import *
from retained import model, StableCase
from series import Series, ORDER
import numpy as np
import sympy as sym

FORMULA = model.FORMULA
SYMBOLS = model.SYMBOLS
RESIDUAL_FUNCTION = sym.lambdify(SYMBOLS, sym.sympify(FORMULA["residual_numerator"], locals=dict(zip(FORMULA["variables"], SYMBOLS))) / sym.sympify(FORMULA["residual_denominator"], locals=dict(zip(FORMULA["variables"], SYMBOLS))), "numpy", cse=True)


def background_series(case, position):
    efold = Series(model.CENTER + position)
    efold.coefficients[1] = 1
    scale = efold.exp()
    field, speed, hubble = [Series(value) for value in case.state_spline(position)]
    unit = float(case.background["unit"])
    scalar_mass = scale * float(case.background["slow_mass"])
    dust = (3 * unit**2 * float(case.background["standard_matter"]) + float(case.background["matching_density"])) / scale
    radiation = 3 * unit**2 * float(case.background["standard_radiation"]) / scale**2
    segment = int(np.searchsorted(case.background["nu_knots"], model.CENTER + position, side="right") - 1)
    offset = efold - case.background["nu_knots"][segment]
    cubic, quadratic, linear, constant = case.background["nu_coefficients"][:, segment]
    logarithm = ((cubic * offset + quadratic) * offset + linear) * offset + constant
    neutrino = 3 * unit**2 * (logarithm - 2 * efold).exp()
    nu_w = (1 - logarithm.derivative()) / 3
    for degree in range(ORDER):
        density = dust + radiation + neutrino + (speed**2 + scalar_mass**2 * field**2) / 2
        pressure = radiation / 3 + neutrino * nu_w + (speed**2 - scalar_mass**2 * field**2) / 2
        rates = [speed / hubble, -2 * speed - scalar_mass**2 * field / hubble, -(density + 3 * pressure) / (6 * hubble)]
        for state, rate in zip((field, speed, hubble), rates):
            state.coefficients[degree + 1] = rate.coefficients[degree] / (degree + 1)
    return scale * case.mass, hubble


def metric_series(case, position):
    argument = Series(position)
    argument.coefficients[1] = 1
    coefficients = case.metrics["full"].c[:, 3]
    result = []
    for field in range(2):
        result.append(((Series(coefficients[0, :, field]) * argument + coefficients[1, :, field]) * argument + coefficients[2, :, field]) * argument + coefficients[3, :, field])
    return result


def local(case, position):
    guard()
    mass, hubble = background_series(case, position)
    first = hubble * hubble.derivative()
    second = hubble * first.derivative()
    third = hubble * second.derivative()
    pressure = -2 * first - hubble**2
    gradient = Series(case.wave**2) / mass**2
    ratio = (1 + gradient).sqrt()
    carrier = mass + 3 * pressure / (8 * mass)
    beat = mass * gradient / (ratio + 1) * (1 - pressure / mass**2 * (3 * ratio**2 + ratio + 1) / (8 * ratio**3) - hubble**2 / mass**2 * (ratio + 1) * (2 * ratio**2 + 5) / (8 * ratio**5))
    sideband = carrier + beat
    slope0 = -hubble * carrier.derivative() / (2 * carrier)
    slopek = -hubble * sideband.derivative() / (2 * sideband)
    rate0, ratek = slope0 - 1j * carrier, slopek - 1j * sideband
    rate_sum = rate0 + ratek
    potential, lapse = metric_series(case, position)
    combined = lapse + 3 * potential
    source = hubble * combined.derivative() * (rate0 - hubble) - 2 * mass**2 * lapse
    leading = source / rate_sum
    leading_prime = hubble * leading.derivative()
    correction = -leading_prime / rate_sum
    correction_prime = hubble * correction.derivative()
    reduced_jets = [hubble.value / mass.value, first.value / mass.value**2, second.value / mass.value**3, third.value / mass.value**4]
    residual0 = mass.value**2 * RESIDUAL_FUNCTION(np.ones(1), *reduced_jets)
    residualk = mass.value**2 * RESIDUAL_FUNCTION(ratio.value, *reduced_jets)
    gamma = slopek - slope0
    physical0, physicalk = slope0 - hubble, slopek - hubble
    denominator = carrier**2 + mass**2 + physical0**2
    mapping = [[2 * (physical0 * physicalk + carrier * sideband + mass**2) / denominator, 2 * (physical0 * sideband - carrier * physicalk) / denominator],
               [-2 * mass * physical0 / denominator, 2 * mass * carrier / denominator]]
    transform = np.stack([np.stack([np.broadcast_to(entry.value, (len(case.wave),)) for entry in row], axis=-1) for row in mapping], axis=1)
    transform_prime = np.stack([np.stack([np.broadcast_to((hubble * entry.derivative()).value, (len(case.wave),)) for entry in row], axis=-1) for row in mapping], axis=1)
    determinant = mapping[0][0] * mapping[1][1] - mapping[0][1] * mapping[1][0]
    weight = 2 * sideband / carrier / determinant
    weight_log_prime = (hubble * weight.derivative() / weight).value
    eigenbeat = beat.value + residualk / (2 * sideband.value)
    matrix = np.zeros((len(case.wave), 2, 2))
    matrix[:, 0, 0], matrix[:, 1, 1] = gamma.value, gamma.value
    matrix[:, 0, 1], matrix[:, 1, 0] = eigenbeat, -eigenbeat
    transform_inverse = np.linalg.inv(transform)
    source_matrix = (transform_prime + transform @ matrix) @ transform_inverse
    pressure_row = np.column_stack((transform[:, 0, 0] - (4 * mass**2 / denominator).value, transform[:, 0, 1]))
    eos = (carrier**2 + physical0**2 - mass**2) / denominator
    choices = {}
    for name, response, defect in (("D0", leading, leading_prime), ("D01", leading + correction, correction_prime)):
        force = np.column_stack((response.value.real + defect.value.imag / (2 * sideband.value), response.value.imag - (defect.value.real - combined.value * residual0) / (2 * sideband.value)))
        offset = 2 * (physical0 * response.real() - carrier * response.imag()) / denominator - (1 + eos) * lapse
        offset_vector = np.column_stack((offset.value, np.zeros(len(case.wave))))
        offset_prime = np.column_stack(((hubble * offset.derivative()).value, np.zeros(len(case.wave))))
        source_force = np.einsum("nij,nj->ni", transform, force) + offset_prime - np.einsum("nij,nj->ni", source_matrix, offset_vector)
        choices[name] = dict(response=response.value, defect=defect.value, force=force, offset=offset.value,
                             source_force=source_force, source_offset_prime=offset_prime)
    return dict(mass=float(mass.value[0]), hubble=float(hubble.value[0]), carrier=float(carrier.value[0]), sideband=sideband.value,
                slope0=float(slope0.value[0]), slopek=slopek.value, leading=leading.value, leading_prime=leading_prime.value,
                correction=correction.value, correction_prime=correction_prime.value, rate_sum=rate_sum.value,
                jets=np.array([hubble.value[0], first.value[0], second.value[0], third.value[0]]),
                transform=transform, transform_inverse=transform_inverse, transform_prime=transform_prime,
                source_matrix=source_matrix, matrix=matrix, weight=weight.value, weight_log_prime=weight_log_prime,
                pressure_row=pressure_row, choices=choices, potential=potential.value, lapse=lapse.value,
                residual0=float(residual0[0]), residualk=residualk)


def prepare(case, coefficients, choice):
    mass = coefficients["mass"]
    target = np.column_stack((case.history["density"][:, 3], -mass * case.history["current"][:, 3] / case.wave))
    shifted = target.copy()
    shifted[:, 0] -= coefficients["choices"][choice]["offset"]
    relative = np.einsum("nij,nj->ni", coefficients["transform_inverse"], shifted)
    states = model.prepare(case)[0]
    amplitude = 1 / np.sqrt(coefficients["carrier"])
    response = coefficients["choices"][choice]["response"]
    states[:, 2, :] = amplitude * relative
    physical_prime = amplitude * np.column_stack((coefficients["slopek"] * relative[:, 0] + coefficients["sideband"] * relative[:, 1] + response.real,
                                                coefficients["slopek"] * relative[:, 1] - coefficients["sideband"] * relative[:, 0] + response.imag))
    combined = coefficients["lapse"] + 3 * coefficients["potential"]
    states[:, 3, :] = physical_prime - combined[:, None] * (states[:, 1, :] - coefficients["hubble"] * states[:, 0, :])
    return relative, states, target


def sources_at(coefficients, choice, relative):
    density_current = np.einsum("nij,nj->ni", coefficients["transform"], relative)
    density_current[:, 0] += coefficients["choices"][choice]["offset"]
    pressure = np.einsum("ni,ni->n", coefficients["pressure_row"], relative) + coefficients["choices"][choice]["offset"]
    return np.column_stack((density_current, pressure))
