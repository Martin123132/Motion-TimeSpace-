from common import *
import numpy as np
import sympy as sym
import ast


def main():
    with worker("validation"):
        inputs = sources()
        proof = read(ROOT / "proof.json")
        coefficients = read(ROOT / "coefficients-result.json")
        action = read(ROOT / "action-result.json")
        conservation = read(ROOT / "conservation-result.json")
        checks = []

        def check(name, passed):
            checks.append(dict(name=name, passed=bool(passed)))

        shared = {"common_sha256": "common.py"}
        binding_sets = [
            ("proof", proof, dict(shared, code_sha256="derive_action.py", derivation_sha256="DERIVATION.md", protocol_sha256="PROTOCOL.md")),
            ("coefficients", coefficients, dict(shared, code_sha256="validate_coefficients.py", action_model_sha256="action_model.py", series_sha256="series.py", adapter_sha256="retained.py", output_sha256="coefficients.npz")),
            ("action", action, dict(shared, code_sha256="test_action.py", action_model_sha256="action_model.py", series_sha256="series.py", adapter_sha256="retained.py", proof_sha256="proof.json", coefficients_sha256="coefficients-result.json", output_sha256="action-evolution.npz")),
            ("conservation", conservation, dict(shared, code_sha256="check_conservation.py", action_model_sha256="action_model.py", series_sha256="series.py", adapter_sha256="retained.py", action_sha256="action-result.json", bound_document_sha256="FREE-RESPONSE-BOUND.md", output_sha256="conservation.npz")),
        ]
        for name, report, bindings in binding_sets:
            check(name + " bindings", all(report[key] == digest(ROOT / filename) for key, filename in bindings.items()))
        check("prior source manifest unchanged", inputs == proof["sources"] == coefficients["sources"])
        check("13exact canonical/metric identities", proof["passed"] and len(proof["identities"]) == 13 and all(value == "0" for value in proof["identities"].values()))
        check("coefficient checks", coefficients["passed"] and all(row["passed"] and row["error"] <= row["gate"] for row in coefficients["checks"]))
        check("action checks", action["implementation_checks_passed"] and all(row["passed"] and row["error"] <= row["gate"] for row in action["checks"]))
        check("sampled conservation checks", conservation["passed"] and all(row["sampled_rates_passed"] and row["endpoint_passed"] for row in conservation["reports"]))
        check("correct repaired forcing packet", action["source_packet_sha256"] == digest(PREVIOUS / "phase-full.npz"))
        check("conditional state and scope retained", action["source_histories_supplied"] and action["fast_mode_selection_conditional"] and not action["uniform_reduction_bound_proved"])
        with np.load(ROOT / "action-evolution.npz") as archive, np.load(PREVIOUS / "transport.npz") as prior:
            check("all399original modes retained", np.array_equal(archive["wave"], prior["wave"]) and len(archive["wave"]) == 399)
            check("original source scales unchanged", np.array_equal(archive["source_scale"], prior["normalizer"][:, [0, 1, 0]]))
            for report in action["comparisons"]:
                choice = report["preparation"]
                errors = abs((archive[choice + "_reduced_source"] - archive[choice + "_reference_source"]) / archive["source_scale"])
                native_errors = abs((archive[choice + "_reduced_source"] - prior["native"]) / archive["source_scale"])
                check(choice + " full-field comparison accurately reported", np.array_equal(errors, archive[choice + "_errors"]) and report["microscopic_passed"] == bool(np.max(errors) <= GATE) and report["failing_modes"] == int(np.sum(np.max(errors, axis=1) > GATE)))
                check(choice + " native comparison accurately reported", np.array_equal(native_errors, archive[choice + "_native_errors"]) and report["native_density_current_passed"] == bool(np.max(native_errors[:, :2]) <= GATE))
            cold_error = float(np.max(abs((archive["cold_action_final"] - prior["cold_native"]) / prior["cold_scale"])))
            check("cold comparison accurately reported", cold_error == action["cold_native_max"] and action["cold_native_passed"] == bool(cold_error <= GATE))
        coordinate, velocity, hubble, hubble_prime, mass, wave = sym.symbols("coordinate velocity hubble hubble_prime mass wave", real=True)
        original = ((velocity - hubble * coordinate)**2 - (wave**2 + mass**2) * coordinate**2) / 2
        canonical = (velocity**2 - (wave**2 + mass**2 - hubble_prime - hubble**2) * coordinate**2) / 2
        boundary_prime = hubble_prime * coordinate**2 / 2 + hubble * coordinate * velocity
        rescaling_identity = sym.factor(original - canonical + boundary_prime)
        check("original scalar rescaling boundary", rescaling_identity == 0)
        time_symbol = sym.Symbol("time", real=True)
        rate = sym.Function("rate")(time_symbol)
        source = sym.Function("source")(time_symbol)
        correction = -sym.diff(source / rate, time_symbol) / rate
        expanded_correction_prime = -sym.diff(source, time_symbol, 2) / rate**2 + 3 * sym.diff(source, time_symbol) * sym.diff(rate, time_symbol) / rate**3 + source * sym.diff(rate, time_symbol, 2) / rate**3 - 3 * source * sym.diff(rate, time_symbol)**2 / rate**4
        correction_identity = sym.factor(sym.diff(correction, time_symbol) - expanded_correction_prime)
        check("explicit next response derivative", correction_identity == 0)
        for path in ROOT.glob("*.npz"):
            with np.load(path) as archive:
                check(path.name + " finite numeric entries", all(np.all(np.isfinite(archive[key])) for key in archive.files if np.issubdtype(archive[key].dtype, np.number)))
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        context = {}
        for relative in ("MTS-CLOSED-LINEAR-METRIC-RESPONSE.md", "MTS-RETAINED-HIERARCHY-AND-RETARDED-COUPLING.md", "MTS-JOINT-GRAVITY-HAMILTONIAN-AND-CANONICAL-MEAN.md", "mts-formation-state-bundle-20261110/SCHEMA.md"):
            path = POST / relative
            check("existing next-step owner " + relative, path.is_file())
            context[str(path)] = digest(path)
        check("no bytecode residue", not list(ROOT.rglob("__pycache__")))
        result = dict(passed=all(row["passed"] for row in checks), checks=checks,
                      supplementary_identities={"rescaling_boundary": str(rescaling_identity), "D1_prime": str(correction_identity)},
                      context_only_sources=context, code_sha256=digest(__file__),
                      reports={filename: digest(ROOT / filename) for filename in ("proof.json", "coefficients-result.json", "action-result.json", "conservation-result.json")},
                      boundary_addendum_sha256=digest(ROOT / "BOUNDARY-ADDENDUM.md"))
        write("validation.json", result)
        print(json.dumps(dict(passed=result["passed"], checks=len(checks), failed=[row for row in checks if not row["passed"]])), flush=True)
        if not result["passed"]:
            raise ValueError("validation failed")


if __name__ == "__main__":
    main()
