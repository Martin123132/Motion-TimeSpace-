from common import *
from action_model import local, prepare, sources_at, StableCase
from retained import model
import numpy as np
from scipy.integrate import solve_ivp
from functools import lru_cache


def main():
    with worker("evolution"):
        if not read(ROOT / "proof.json")["passed"] or not read(ROOT / "coefficients-result.json")["passed"]:
            raise ValueError("unpassed derivation/derivative gate")
        with np.load(PREVIOUS / "transport.npz") as archive:
            saved = {name: archive[name].copy() for name in archive.files}
        with np.load(PREVIOUS / "phase-full.npz") as archive:
            integral = archive["integral8192"].copy()
        case = StableCase("heavy")

        @lru_cache(maxsize=256)
        def coefficients(position):
            return local(case, float(position))

        initial_coefficients, final_coefficients = coefficients(0.), coefficients(SPAN)
        arrays, checks, comparisons, solver_rows = {}, [], [], []

        def check(name, error, gate=GATE):
            checks.append(dict(name=name, error=float(error), gate=gate, passed=bool(np.isfinite(error) and abs(error) <= gate)))

        source_scale = saved["normalizer"][:, [0, 1, 0]]
        for choice in ("D0", "D01"):
            relative_initial, initial, target = prepare(case, initial_coefficients, choice)
            reference_final = model.propagate(case, initial, integral)
            reference_source = model.stress(case, reference_final, SPAN)
            relative_scale = np.column_stack((np.maximum.reduce((abs(relative_initial[:, 0]), saved["normalizer"][:, 0] / abs(initial_coefficients["transform"][:, 0, 0]), np.full(399, 1e-100))),
                                               np.maximum.reduce((abs(relative_initial[:, 1]), saved["normalizer"][:, 1] / abs(initial_coefficients["transform"][:, 1, 1]), np.full(399, 1e-100)))))
            solved_sources = []
            relative_final = None
            for tolerance in (2e-11, 2e-12):
                def rhs(position, flattened):
                    values = coefficients(position)
                    relative = flattened.reshape(399, 2) * relative_scale
                    velocity = np.einsum("nij,nj->ni", values["matrix"], relative) + values["choices"][choice]["force"]
                    return (velocity / values["hubble"] / relative_scale).ravel()
                solution = solve_ivp(rhs, (0, SPAN), (relative_initial / relative_scale).ravel(), method="DOP853", rtol=tolerance, atol=tolerance / 100, max_step=SPAN / 8, t_eval=[SPAN])
                if not solution.success:
                    raise ValueError(solution.message)
                relative_final = solution.y[:, -1].reshape(399, 2) * relative_scale
                solved_sources.append(sources_at(final_coefficients, choice, relative_final))
                solver_rows.append(dict(model="heavy", preparation=choice, coordinates="relative", tolerance=tolerance, evaluations=solution.nfev))
            check(choice + " reduced solver refinement", np.max(abs((solved_sources[1] - solved_sources[0]) / source_scale)))
            def source_rhs(position, flattened):
                values = coefficients(position)
                source = flattened.reshape(399, 2) * saved["normalizer"]
                velocity = np.einsum("nij,nj->ni", values["source_matrix"], source) + values["choices"][choice]["source_force"]
                return (velocity / values["hubble"] / saved["normalizer"]).ravel()
            source_solution = solve_ivp(source_rhs, (0, SPAN), (target / saved["normalizer"]).ravel(), method="DOP853", rtol=2e-12, atol=2e-14, max_step=SPAN / 8, t_eval=[SPAN])
            if not source_solution.success:
                raise ValueError(source_solution.message)
            source_coordinate_final = source_solution.y[:, -1].reshape(399, 2) * saved["normalizer"]
            solver_rows.append(dict(model="heavy", preparation=choice, coordinates="density-current", tolerance=2e-12, evaluations=source_solution.nfev))
            check(choice + " affine action-coordinate equivalence", np.max(abs((source_coordinate_final - solved_sources[1][:, :2]) / saved["normalizer"])))
            errors = abs((solved_sources[1] - reference_source) / source_scale)
            native_errors = abs((solved_sources[1] - saved["native"]) / source_scale)
            comparisons.append(dict(preparation=choice, microscopic_density=float(np.max(errors[:, 0])), microscopic_current=float(np.max(errors[:, 1])), microscopic_pressure=float(np.max(errors[:, 2])),
                                    microscopic_passed=bool(np.max(errors) <= GATE), failing_modes=int(np.sum(np.max(errors, axis=1) > GATE)),
                                    native_density=float(np.max(native_errors[:, 0])), native_current=float(np.max(native_errors[:, 1])), native_pressure=float(np.max(native_errors[:, 2])),
                                    native_density_current_passed=bool(np.max(native_errors[:, :2]) <= GATE)))
            arrays.update({choice + "_" + name: value for name, value in dict(initial=initial, relative_initial=relative_initial, relative_final=relative_final, reduced_source=solved_sources[1], reference_final=reference_final, reference_source=reference_source, source_coordinate_final=source_coordinate_final, errors=errors, native_errors=native_errors).items()})
            print(json.dumps(comparisons[-1]), flush=True)
        cold = model.Case("cold")
        cold_outputs = []
        for convention, tolerance in ((1., 2e-11), (1., 2e-12), (7., 2e-12)):
            initial_mass = cold.mass * np.exp(model.CENTER) * convention
            final_mass = initial_mass * np.exp(SPAN)
            initial = np.column_stack((cold.history["density"][:, 3] - 3 * cold.metrics["full"](0)[:, 0], -initial_mass * cold.history["current"][:, 3] / cold.wave))
            scale = np.column_stack((saved["cold_scale"][:, 0], final_mass * saved["cold_scale"][:, 1] / cold.wave))
            def cold_rhs(position, flattened):
                guard()
                density, phase_value = (flattened.reshape(399, 2) * scale).T
                mass = initial_mass * np.exp(position)
                hubble = cold.jets(position)[1]
                lapse = cold.metrics["full"](position)[:, 1]
                return (np.column_stack((cold.wave**2 * phase_value / mass, -mass * lapse)) / hubble / scale).ravel()
            solution = solve_ivp(cold_rhs, (0, SPAN), (initial / scale).ravel(), method="DOP853", rtol=tolerance, atol=tolerance / 100, max_step=SPAN / 8, t_eval=[SPAN])
            if not solution.success:
                raise ValueError(solution.message)
            final = solution.y[:, -1].reshape(399, 2) * scale
            final[:, 0] += 3 * cold.metrics["full"](SPAN)[:, 0]
            final[:, 1] *= -cold.wave / final_mass
            cold_outputs.append(final)
            solver_rows.append(dict(model="cold", reference_mass_convention=convention, tolerance=tolerance, evaluations=solution.nfev))
        check("cold independent action versus saved Euler", np.max(abs((cold_outputs[1] - saved["cold_final"]) / saved["cold_scale"])))
        check("cold action solver refinement", np.max(abs((cold_outputs[1] - cold_outputs[0]) / saved["cold_scale"])))
        check("cold reference-mass convention independence", np.max(abs((cold_outputs[2] - cold_outputs[1]) / saved["cold_scale"])))
        cold_native = float(np.max(abs((cold_outputs[1] - saved["cold_native"]) / saved["cold_scale"])))
        arrays["cold_action_final"] = cold_outputs[1]
        arrays["wave"], arrays["source_scale"] = case.wave, source_scale
        np.savez_compressed(ROOT / "action-evolution.npz", **arrays)
        result = dict(implementation_checks_passed=all(row["passed"] for row in checks), checks=checks, comparisons=comparisons,
                      cold_native_max=cold_native, cold_native_passed=cold_native <= GATE, solver_rows=solver_rows,
                      source_histories_supplied=True, fast_mode_selection_conditional=True, uniform_reduction_bound_proved=False,
                      code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"), action_model_sha256=digest(ROOT / "action_model.py"),
                      series_sha256=digest(ROOT / "series.py"), adapter_sha256=digest(ROOT / "retained.py"),
                      proof_sha256=digest(ROOT / "proof.json"), coefficients_sha256=digest(ROOT / "coefficients-result.json"),
                      source_packet_sha256=digest(PREVIOUS / "phase-full.npz"), output_sha256=digest(ROOT / "action-evolution.npz"))
        write("action-result.json", result)
        print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
