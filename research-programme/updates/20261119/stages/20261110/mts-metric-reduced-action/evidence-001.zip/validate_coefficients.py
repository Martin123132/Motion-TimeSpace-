from common import *
from action_model import local, prepare, sources_at, StableCase
from retained import model, dressing
from series import Series, ORDER
import numpy as np
import sympy as sym


def main():
    with worker("coefficients"):
        inputs = sources()
        checks = []

        def check(name, error, gate=ALGEBRA):
            checks.append(dict(name=name, error=float(error), gate=gate, passed=bool(np.isfinite(error) and abs(error) <= gate)))

        argument = sym.Symbol("argument")
        polynomial = 2 + argument + argument**2 / 3
        coefficients = np.zeros((ORDER + 1, 1))
        coefficients[:3, 0] = [2, 1, 1 / 3]
        test = Series(coefficients=coefficients)
        for name, series_value, exact in (("inverse", test.reciprocal(), 1 / polynomial), ("square root", test.sqrt(), sym.sqrt(polynomial)), ("exponential", test.exp(), sym.exp(polynomial))):
            reference = sym.series(exact, argument, 0, ORDER + 1).removeO().expand()
            expected = np.array([float(reference.coeff(argument, degree).evalf(60)) for degree in range(ORDER + 1)])
            check("Taylor " + name + " through order6", np.max(abs(series_value.coefficients[:, 0] - expected) / np.maximum(1, abs(expected))))
        case = StableCase("heavy")
        positions = np.linspace(0, SPAN, 17)
        rows, collected = [], []
        for position in positions:
            guard()
            values = local(case, position)
            reference_jets = np.array(case.jets(position))[1:]
            check("equation-derived jets " + str(position), np.max(abs((values["jets"] - reference_jets) / np.maximum(abs(reference_jets), 1e-100))))
            previous = dressing.rates(case, [position])
            check("D0 formula " + str(position), np.max(abs(values["leading"] - previous[0][0]) / np.maximum(abs(previous[0][0]), 1e-100)))
            check("D0 derivative " + str(position), np.max(abs(values["leading_prime"] - previous[1][0]) / np.maximum(abs(previous[1][0]), 1e-100)))
            check("source symplectic connection " + str(position), np.max(abs(np.trace(values["source_matrix"], axis1=1, axis2=2) + values["weight_log_prime"])) / values["hubble"])
            check("positive source map/weight " + str(position), 0 if np.all(np.linalg.det(values["transform"]) > 0) and np.all(values["weight"] > 0) else 1)
            collected.append(values)
            rows.append(dict(position=float(position), D1_over_D0=float(np.max(abs(values["correction"]) / np.maximum(abs(values["leading"]), 1e-100))),
                             next_over_previous_defect=float(np.max(abs(values["correction_prime"]) / np.maximum(abs(values["leading_prime"]), 1e-100)))))
        with np.load(PREVIOUS / "transport.npz") as archive:
            scales = archive["normalizer"].copy()
            microscopic_scale = archive["microscopic_scale"].copy()
        with np.load(PREVIOUS / "dressing.npz") as archive:
            previous_initial = archive["initial"].copy()
        for choice in ("D0", "D01"):
            relative, state, target = prepare(case, collected[0], choice)
            mapped = sources_at(collected[0], choice, relative)
            actual = model.stress(case, state, 0)
            check(choice + " physical initial density/current", np.max(abs((actual[:, :2] - target) / scales)))
            check(choice + " source map versus original stress", np.max(abs((mapped - actual) / scales[:, [0, 1, 0]])))
            if choice == "D0":
                check("D0 retained microscopic preparation", np.max(abs(model.normalized(case, state - previous_initial, microscopic_scale, 0))))
        np.savez_compressed(ROOT / "coefficients.npz", positions=positions, wave=case.wave,
                            leading=np.array([value["leading"] for value in collected]), leading_prime=np.array([value["leading_prime"] for value in collected]),
                            correction=np.array([value["correction"] for value in collected]), correction_prime=np.array([value["correction_prime"] for value in collected]),
                            weight=np.array([value["weight"] for value in collected]))
        report = dict(passed=all(row["passed"] for row in checks), checks=checks, samples=rows,
                      derivative_method="order6 local Taylor recurrence from retained background ODE; central metric cubic including one-sided endpoint third derivative",
                      indicators_not_uniform_bounds=True, sources=inputs, code_sha256=digest(__file__),
                      action_model_sha256=digest(ROOT / "action_model.py"), series_sha256=digest(ROOT / "series.py"),
                      adapter_sha256=digest(ROOT / "retained.py"), common_sha256=digest(ROOT / "common.py"), output_sha256=digest(ROOT / "coefficients.npz"))
        write("coefficients-result.json", report)
        print(json.dumps(dict(passed=report["passed"], checks=len(checks), failed=[row for row in checks if not row["passed"]],
                              max_correction=max(row["D1_over_D0"] for row in rows), max_defect_ratio=max(row["next_over_previous_defect"] for row in rows))), flush=True)
        if not report["passed"]:
            raise ValueError("coefficient gate failed; no propagation authorized")


if __name__ == "__main__":
    main()
