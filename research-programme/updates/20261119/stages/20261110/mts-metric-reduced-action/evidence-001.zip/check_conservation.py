from common import *
from action_model import local, prepare, sources_at, StableCase
from retained import model
import numpy as np
from scipy.integrate import solve_ivp
from functools import lru_cache


def main():
    with worker("conservation"):
        case = StableCase("heavy")
        with np.load(PREVIOUS / "transport.npz") as archive:
            scales = archive["normalizer"].copy()
        with np.load(ROOT / "action-evolution.npz") as archive:
            completed = {name: archive[name].copy() for name in archive.files}

        @lru_cache(maxsize=256)
        def coefficients(position):
            return local(case, float(position))

        positions = np.linspace(0, SPAN, 9)
        initial_values = coefficients(0.)
        reports, arrays = [], {"positions": positions, "wave": case.wave}
        for choice in ("D0", "D01"):
            initial_relative, _, _ = prepare(case, initial_values, choice)
            relative_scale = np.column_stack((np.maximum.reduce((abs(initial_relative[:, 0]), scales[:, 0] / abs(initial_values["transform"][:, 0, 0]), np.full(399, 1e-100))),
                                               np.maximum.reduce((abs(initial_relative[:, 1]), scales[:, 1] / abs(initial_values["transform"][:, 1, 1]), np.full(399, 1e-100)))))
            def rhs(position, flattened):
                values = coefficients(position)
                relative = flattened.reshape(399, 2) * relative_scale
                return ((np.einsum("nij,nj->ni", values["matrix"], relative) + values["choices"][choice]["force"]) / values["hubble"] / relative_scale).ravel()
            solution = solve_ivp(rhs, (0, SPAN), (initial_relative / relative_scale).ravel(), method="DOP853", rtol=2e-12, atol=2e-14, max_step=SPAN / 8, t_eval=positions)
            if not solution.success:
                raise ValueError(solution.message)
            history = solution.y.T.reshape(9, 399, 2) * relative_scale[None, :, :]
            residual_rows, source_history, offplane = [], [], []
            for position, relative in zip(positions, history):
                values = coefficients(position)
                source = sources_at(values, choice, relative)
                density, phase_value, pressure = source.T
                velocity = np.einsum("nij,nj->ni", values["source_matrix"], source[:, :2]) + values["choices"][choice]["source_force"]
                background_slope = values["slope0"] - values["hubble"]
                background_eos = (values["carrier"]**2 + background_slope**2 - values["mass"]**2) / (values["carrier"]**2 + background_slope**2 + values["mass"]**2)
                potential_prime = values["hubble"] * case.metrics["full"](position, 1)[:, 0]
                density_residual = velocity[:, 0] - case.wave**2 * phase_value / values["mass"] - 3 * (1 + background_eos) * potential_prime + 3 * values["hubble"] * (pressure - background_eos * density)
                current_residual = velocity[:, 1] - 3 * values["hubble"] * background_eos * phase_value + values["mass"] * (pressure + (1 + background_eos) * values["lapse"])
                residual_rows.append(np.column_stack((density_residual, current_residual)) / values["hubble"] / scales)
                source_history.append(source)
                offplane.append(values["choices"][choice]["defect"] + values["residualk"] * (relative[:, 0] + 1j * relative[:, 1]))
            residual_rows = np.array(residual_rows)
            endpoint_error = float(np.max(abs((np.array(source_history)[-1] - completed[choice + "_reduced_source"]) / scales[:, [0, 1, 0]])))
            reports.append(dict(preparation=choice, density_rate_residual=float(np.max(abs(residual_rows[..., 0]))),
                                current_rate_residual=float(np.max(abs(residual_rows[..., 1]))),
                                sampled_rate_gate=GATE, sampled_rates_passed=bool(np.max(abs(residual_rows)) <= GATE),
                                endpoint_replay_error=endpoint_error, endpoint_passed=endpoint_error <= GATE,
                                interpretation="rates divided by H and fixed source scales at9samples; not a uniform bound or accumulated error certificate"))
            arrays[choice + "_relative_history"] = history
            arrays[choice + "_source_history"] = np.array(source_history)
            arrays[choice + "_rate_residual"] = residual_rows
            arrays[choice + "_offplane_defect"] = np.array(offplane)
        np.savez_compressed(ROOT / "conservation.npz", **arrays)
        report = dict(passed=all(row["endpoint_passed"] and row["sampled_rates_passed"] for row in reports), reports=reports,
                      code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"), action_model_sha256=digest(ROOT / "action_model.py"),
                      series_sha256=digest(ROOT / "series.py"), adapter_sha256=digest(ROOT / "retained.py"),
                      action_sha256=digest(ROOT / "action-result.json"), bound_document_sha256=digest(ROOT / "FREE-RESPONSE-BOUND.md"),
                      output_sha256=digest(ROOT / "conservation.npz"))
        write("conservation-result.json", report)
        print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
