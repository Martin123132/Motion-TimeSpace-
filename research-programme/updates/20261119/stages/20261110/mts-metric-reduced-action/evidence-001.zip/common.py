import os
import sys
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / "mts-changing-metric-transport-20261110"
BACKGROUND = POST / "mts-background-derivatives-20261110"
SPAN, ALGEBRA, GATE = .001, 1e-10, 2e-5
START = time.monotonic()


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(name, value):
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def guard():
    if time.monotonic() - START > 900:
        raise RuntimeError("bounded worker deadline")
    if any((directory / "STOP-REQUESTED").exists() for directory in (ROOT, POST, PREVIOUS)):
        raise RuntimeError("owner hold")


@contextmanager
def worker(prefix):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    guard()
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), started=datetime.now(timezone.utc).isoformat())
    write(prefix + "-start.json", identity)
    try:
        yield identity
    except Exception as error:
        write(prefix + "-end.json", dict(**identity, state="failed", error=repr(error)))
        raise
    else:
        write(prefix + "-end.json", dict(**identity, state="completed", elapsed=time.monotonic() - START))


def sources():
    if digest(PREVIOUS / "closeout.json") != "7297b4b4eff7d3531aaa2fdccb888c9ed0031df614cbf90054dd8856258ccf8b":
        raise ValueError("changed previous seal")
    seal = read(PREVIOUS / "closeout.json")
    result = dict(seal["input_hashes"])
    result[str(PREVIOUS / "closeout.json")] = digest(PREVIOUS / "closeout.json")
    for name, entry in seal["artifacts"].items():
        result[str(PREVIOUS / name)] = entry["sha256"]
    for path, checksum in result.items():
        guard()
        if digest(path) != checksum:
            raise ValueError("changed source " + path)
    return result
