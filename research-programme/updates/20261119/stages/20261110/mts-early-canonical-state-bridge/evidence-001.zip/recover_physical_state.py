from bridge_support import *
import numpy as np
import scipy
from scipy.interpolate import CubicSpline


def metric_coordinates(columns, wave):
    hubble = columns['H']
    eta = columns['etak'] / wave
    alpha = -hubble * columns['v_newtonian_cdm'] / wave**2
    potential = eta - hubble * alpha
    lapse = 2 * columns['Weyl'] / wave**2 - potential
    return hubble, eta, alpha, potential, lapse


def background_values(table, scales, suffix):
    logscale = np.log(scales)
    efold = table['heavy_efold' if suffix == 'h' else 'efold']
    field_nodes, velocity_nodes = table['phi_' + suffix], table['phidot_' + suffix]
    field_spline = CubicSpline(efold, field_nodes, bc_type='natural')
    velocity_spline = CubicSpline(efold, velocity_nodes, bc_type='natural')
    query = np.maximum(logscale, efold[0])
    if suffix == 's':
        query = np.minimum(query, 0.)
    require(np.all(query <= efold[-1]), 'no background upper extrapolation')
    field, velocity = field_spline(query), velocity_spline(query)
    early = logscale < efold[0]
    field[early] = field_nodes[0]
    velocity[early] = velocity_nodes[0] * np.exp(3 * (logscale[early] - efold[0]))
    return field, velocity


def main():
    with worker('recover'):
        inspection = read(ROOT / 'inspection-result.json')
        require(inspection['passed'], 'passed inspection')
        require(digest(ROOT / 'k1-early-source.npz') == inspection['packet_sha256'], 'saved extracted packet')
        cold_source = EARLY / 'runs/final-bg8-start/cold.npz'
        cold_status_path = cold_source.with_name('status.json')
        cold_status = read(cold_status_path)
        require(cold_status['state'] == 'complete', 'original cold run complete')
        extra_paths = [cold_source, cold_status_path, EARLY / 'runs/backgrounds/cold.npz',
                       EARLY / 'run_native_early.py', EARLY / 'native/fortran/MTSTwoField.f90',
                       MATCHING / 'native/forutils/Interpolation.f90',
                       ROOT / 'DERIVATION.md', ROOT / 'recover_physical_state.py', ROOT / 'bridge_support.py']
        for source in (cold_source, EARLY / 'runs/backgrounds/cold.npz', EARLY / 'native/fortran/MTSTwoField.f90'):
            require(digest(source) == cold_status['input_hashes'][str(source)], 'original cold source hash ' + str(source))
        extra_hashes = {str(path): digest(path) for path in extra_paths}
        write('recovery-frozen-inputs.json', extra_hashes)
        checks = {}

        def compare(name, actual, reference, terms, gate):
            actual, reference = np.asarray(actual), np.asarray(reference)
            require(actual.shape == reference.shape, name + ' shape')
            require(np.isfinite(actual).all() and np.isfinite(reference).all(), name + ' finite')
            denominator = float(np.max(sum(np.abs(np.asarray(term)) for term in terms)))
            absolute = float(np.max(np.abs(actual - reference)))
            normalized = absolute / denominator if denominator > 0 else (0. if absolute == 0 else float('inf'))
            checks[name] = dict(passed=bool(normalized <= gate), absolute_max=absolute, component_sum_peak=denominator, normalized=normalized, tolerance=gate, samples=int(actual.size))
            require(checks[name]['passed'], name + ' failed: ' + str(checks[name]))

        case_results = {}
        for case in ('cold', 'heavy'):
            guard()
            if case == 'heavy':
                with np.load(ROOT / 'k1-early-source.npz', allow_pickle=False) as packet:
                    names, values, clock, requested = [packet[key].copy() for key in ('names', 'values', 'clock', 'requested_scale')]
                require(np.all(values[:, names.tolist().index('mts_match_count')] == 0), 'early heavy unswitched')
                require(np.all(values[:, names.tolist().index('mts_averaged_chart')] == 0), 'early exact heavy chart')
            else:
                with np.load(cold_source, allow_pickle=False) as packet:
                    selected = np.flatnonzero(packet['modes'] == 1.)
                    require(len(selected) == 1, 'unique actual cold k1')
                    names = packet['names'].copy()
                    values = packet['values'][selected[0]].copy()
                    clock, requested = [packet[key].copy() for key in ('conformal_time', 'requested_scale')]
            columns = {str(name): values[:, index] for index, name in enumerate(names)}
            scales = columns['a']
            require(np.all(scales > 0) and np.all(np.diff(scales) > 0), case + ' ordered physical scale')
            require(np.all(np.diff(clock) > 0), case + ' ordered clock')
            hubble, eta, alpha, potential, lapse = metric_coordinates(columns, 1.)
            output = dict(a=scales, clock=clock, requested_scale=requested, H=hubble, eta=eta, alpha=alpha, Phi=potential, Psi=lapse, wave=np.array(1.))
            delta_cdm = columns['delta_cdm'] - 3 * hubble * alpha
            current_cdm = alpha
            compensated_cdm = delta_cdm - 3 * potential
            compare(case + '_cdm_compensated', compensated_cdm, columns['delta_cdm'] - 3 * eta, [columns['delta_cdm'], 3 * eta, 3 * hubble * alpha, 3 * potential], ALGEBRA)
            compare(case + '_cdm_current', current_cdm, -hubble * columns['v_newtonian_cdm'], [alpha], ALGEBRA)
            output.update(delta_cdm_N=delta_cdm, current_cdm_over_rho=current_cdm, dstar_cdm_over_rho=compensated_cdm)
            field_rows = {}
            with np.load(EARLY / ('runs/backgrounds/' + case + '.npz'), allow_pickle=False) as table:
                for suffix in (('s', 'h') if case == 'heavy' else ('s',)):
                    field, velocity = background_values(table, scales, suffix)
                    mass = float(table['heavy_mass_mpc' if suffix == 'h' else 'slow_mass_mpc'])
                    mass2 = (scales * mass)**2
                    sync_field, sync_velocity = columns['mts_dphi_' + suffix], columns['mts_dphidot_' + suffix]
                    kinetic = velocity * sync_velocity
                    potential_sync = mass2 * field * sync_field
                    density_sync, pressure_sync = kinetic + potential_sync, kinetic - potential_sync
                    current_sync = velocity * sync_field
                    native_density, native_pressure, native_current = [columns['mts_' + name + '_' + suffix] for name in ('drho', 'dp', 'q')]
                    prefix = case + '_' + suffix
                    compare(prefix + '_native_density', density_sync, native_density, [kinetic, potential_sync], GATE)
                    compare(prefix + '_native_pressure', pressure_sync, native_pressure, [kinetic, potential_sync], GATE)
                    compare(prefix + '_native_current', current_sync, native_current, [velocity * sync_field], GATE)
                    field_new = sync_field + velocity * alpha
                    canonical_p = sync_velocity - mass2 * field * alpha - 3 * eta * velocity
                    field_prime = sync_velocity + (-2 * hubble * velocity - mass2 * field) * alpha + velocity * (lapse - hubble * alpha)
                    compare(prefix + '_canonical_gauge', canonical_p, field_prime - (lapse + 3 * potential) * velocity, [sync_velocity, mass2 * field * alpha, 3 * eta * velocity, (lapse + 3 * potential) * velocity], ALGEBRA)
                    compare(prefix + '_inverse_field', field_new - velocity * alpha, sync_field, [sync_field, velocity * alpha], ALGEBRA)
                    compare(prefix + '_inverse_momentum', canonical_p + mass2 * field * alpha + 3 * eta * velocity, sync_velocity, [sync_velocity, mass2 * field * alpha, 3 * eta * velocity], ALGEBRA)
                    enthalpy = velocity**2
                    field_term = mass2 * field * field_new
                    canonical_term = velocity * canonical_p
                    metric_term = 3 * enthalpy * potential
                    density_new = canonical_term + field_term + metric_term
                    pressure_new = canonical_term - field_term + metric_term
                    current_new = velocity * field_new
                    density_shift = -3 * hubble * enthalpy * alpha
                    pressure_shift = -(3 * hubble * enthalpy + 2 * mass2 * field * velocity) * alpha
                    current_shift = enthalpy * alpha
                    for label, actual, sync, native, shift, terms in (
                        ('density', density_new, density_sync, native_density, density_shift, [canonical_term, field_term, metric_term, density_sync, density_shift]),
                        ('pressure', pressure_new, pressure_sync, native_pressure, pressure_shift, [canonical_term, field_term, metric_term, pressure_sync, pressure_shift]),
                        ('current', current_new, current_sync, native_current, current_shift, [current_new, current_sync, current_shift])):
                        compare(prefix + '_' + label + '_gauge_algebra', actual, sync + shift, terms, ALGEBRA)
                        compare(prefix + '_' + label + '_saved_source', actual, native + shift, terms, GATE)
                    compare(prefix + '_compensated_density', canonical_term + field_term, density_sync - 3 * eta * enthalpy, [canonical_term, field_term, density_sync, 3 * eta * enthalpy], ALGEBRA)
                    output.update({suffix + '_' + key: value for key, value in dict(phi=field, v=velocity, u=field_new, p=canonical_p, Pi=scales**2 * canonical_p, D=density_new, P=pressure_new, Q=current_new, Dstar=canonical_term + field_term).items()})
                    field_rows[suffix] = dict(mass_mpc_inverse=mass, u_peak=float(np.max(abs(field_new))), p_peak=float(np.max(abs(canonical_p))), source_density_peak=float(np.max(abs(density_new))), source_pressure_peak=float(np.max(abs(pressure_new))), source_current_peak=float(np.max(abs(current_new))), field_zero_crossings=int(np.count_nonzero(np.diff(np.signbit(field)))), velocity_zero_crossings=int(np.count_nonzero(np.diff(np.signbit(velocity)))))
                if case == 'cold':
                    for key in ('mts_dphi_h', 'mts_dphidot_h', 'mts_drho_h', 'mts_dp_h', 'mts_q_h'):
                        require(np.all(columns[key] == 0), 'cold heavy channel absent ' + key)
                else:
                    projection_report = reproduce_projection(columns, table, checks, compare)
                    write('projection-reproduction.json', projection_report)
            np.savez_compressed(ROOT / (case + '-canonical-early-state.npz'), **output)
            anchors = []
            for center in (.0002, .000225, .00025):
                index = int(np.argmin(abs(scales - center)))
                anchors.append(dict(requested_center=center, actual_saved_scale=float(scales[index]), saved_index=index, clock=float(clock[index]), fields={suffix: {key: float(output[suffix + '_' + key][index]) for key in ('phi', 'v', 'u', 'p', 'Pi', 'D', 'P', 'Q', 'Dstar')} for suffix in field_rows}))
            case_results[case] = dict(samples=len(scales), actual_scale_range=[float(scales[0]), float(scales[-1])], maximum_requested_actual_relative_difference=float(np.max(abs(scales / requested - 1))), fields=field_rows, anchors=anchors, packet_sha256=digest(ROOT / (case + '-canonical-early-state.npz')))
        for source, expected in extra_hashes.items():
            require(digest(source) == expected, 'frozen recovery source unchanged')
        require(all(row['passed'] for row in checks.values()), 'all reconstruction checks')
        write('recovery-result.json', dict(passed=True, checks=checks, cases=case_results, count=len(checks), scipy_version=scipy.__version__, numpy_version=np.__version__, normalization='maximum absolute error divided by peak sum of absolute algebraic components; no unit floor', native_metric_accuracy_independently_checked=False, integrated_forward=False, ensemble_preparation_derived=False, new_galaxy_population=False, extra_source_hashes=extra_hashes))
        print(json.dumps(dict(passed=True, checks=len(checks), maximum_native_reconstruction=max(row['normalized'] for name, row in checks.items() if '_native_' in name), maximum_algebra=max(row['normalized'] for row in checks.values() if row['tolerance'] == ALGEBRA), cases=case_results)), flush=True)


def reproduce_projection(columns, table, checks, compare):
    source = SPECTRUM / 'runs/projection/a225-w6-d8.npz'
    with np.load(source, allow_pickle=False) as saved:
        selected = np.flatnonzero(saved['modes'] == 1.)
        require(len(selected) == 1, 'one saved k1 matching row')
        index = selected[0]
        center, density0 = float(saved['matching_scale']), float(saved['matching_density'])
        phase_spline = CubicSpline(table['heavy_efold'], table['phase_h'])
        phase = phase_spline(np.log(columns['a']))
        middle = float(phase_spline(np.log(center)))
        chosen = abs(phase - middle) < 6 * np.pi
        coordinate = (phase[chosen] - middle) / (6 * np.pi)
        basis = np.column_stack([coordinate**power for power in range(9)] + [coordinate**power * trig(2 * phase[chosen]) for power in range(7) for trig in (np.cos, np.sin)] + [coordinate**power * trig(4 * phase[chosen]) for power in range(3) for trig in (np.cos, np.sin)])
        weights = np.linalg.pinv(basis)[0]
        norm = float(saved['projection_norm'][index])
        rows = {}
        for label, key, saved_key in (('density', 'mts_drho_h', 'matching_delta'), ('current', 'mts_q_h', 'matching_momentum'), ('pressure', 'mts_dp_h', 'projected_pressure')):
            value = float((columns[key][chosen] * columns['a'][chosen]) @ weights / density0)
            reference = float(saved[saved_key][index])
            compare('projection_' + label, value, reference, [abs(reference)], ALGEBRA)
            rows[label] = dict(reconstructed=value, saved=reference, absolute_difference=abs(value - reference), difference_over_original_mode_norm=abs(value - reference) / norm)
        return dict(passed=True, source=str(source), sha256=digest(source), center=center, density0=density0, samples=int(chosen.sum()), condition=float(np.linalg.cond(basis)), original_norm=norm, rows=rows, original_closure_error=float(saved['closure_error'][index]), original_pressure_gate=2e-6, new_prediction=False, inverse_of_projection=False, projection_convention='original default CubicSpline phase plus width6 degree8 2theta/4theta basis; unchanged')


if __name__ == '__main__':
    main()
