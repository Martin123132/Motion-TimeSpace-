from bridge_support import *
import numpy as np


def main():
    with worker('inspect'):
        inputs = preserved()
        cleanup = read(PREVIOUS / 'CLEANUP-VERIFIED.json')
        require(cleanup['passed'] and cleanup['seal_sha256'] == EXPECTED, 'previous cleanup')
        for row in cleanup['workers']:
            require(exited(row['identity'])['exited'], 'previous worker exited')
        require(exited(cleanup['verifier_identity'])['exited'], 'previous verifier exited')
        require(read(PREVIOUS / 'validation-i1.json')['paired_physics_passed'], 'preceding physical pass')
        folder = SPECTRUM / 'runs/exact-grid'
        status = read(folder / 'status.json')
        require(status['state'] == 'complete', 'completed original early grid')
        selected = []
        for path in sorted(folder.glob('chunk-*.npz')):
            with np.load(path, allow_pickle=False) as packet:
                matches = np.flatnonzero(packet['modes'] == 1.)
                if len(matches):
                    selected.append((path, int(matches[0])))
        require(len(selected) == 1, 'unique saved k1 packet')
        path, index = selected[0]
        recorded = status['input_hashes'].get(str(path))
        require(recorded is not None and digest(path) == recorded, 'original early packet fingerprint')
        with np.load(path, allow_pickle=False) as packet:
            names = packet['names'].tolist()
            values = packet['values'][index].copy()
            clock, scales, phase = [packet[key].copy() for key in ('conformal_time', 'requested_scale', 'background_phase')]
        require(np.all(np.isfinite(values)) and np.all(np.diff(clock) > 0), 'finite ordered early history')
        require(all(name in names for name in ('mts_dphi_h', 'mts_dphidot_h', 'mts_drho_h', 'mts_dp_h', 'mts_q_h')), 'saved primitive field and stress')
        np.savez_compressed(ROOT / 'k1-early-source.npz', names=names, values=values, clock=clock, requested_scale=scales, phase=phase, wave=1.)
        extras = [path, folder / 'status.json', EARLY / 'runs/backgrounds/heavy.npz',
                  SPECTRUM / 'runs/projection/a225-w6-d8.npz', SPECTRUM / 'run_early_grid.py', SPECTRUM / 'project_grid.py',
                  MATCHING / 'prepare_matching.py', MATCHING / 'matching_common.py',
                  MATCHING / 'native/fortran/MTSTwoField.f90', MATCHING / 'native/fortran/equations.f90',
                  MATCHING / 'native/camb/model.py', POST / 'mts-canonical-metric-closure-20261110/DERIVATION.md',
                  POST / 'mts-gauge-source-bridge-20261110/canonical_block.py',
                  POST / 'mts-metric-reduced-action-20261110/DERIVATION.md']
        source_hashes = {str(source): digest(source) for source in extras}
        inputs.update(source_hashes)
        write('frozen-inputs.json', inputs)
        with np.load(EARLY / 'runs/backgrounds/heavy.npz', allow_pickle=False) as table:
            table_info = {key: dict(shape=list(table[key].shape), dtype=str(table[key].dtype)) for key in table.files}
            fields = {key: float(table[key]) for key in ('heavy_mass_mpc', 'slow_mass_mpc', 'fraction')}
        report = dict(passed=True, selected_source=str(path), selected_index=index, source_sha256=recorded,
                      names=names, shape=list(values.shape), scale_range=[float(scales.min()), float(scales.max())],
                      phase_range=[float(phase.min()), float(phase.max())], background_fields=fields, background_arrays=table_info,
                      code_sha256=digest(__file__), packet_sha256=digest(ROOT / 'k1-early-source.npz'), source_hashes=source_hashes)
        write('inspection-result.json', report)
        print(json.dumps(dict(passed=True, source=str(path), shape=list(values.shape), names=names,
              scale_range=report['scale_range'], background_fields=fields, input_count=len(inputs))), flush=True)


if __name__ == '__main__':
    main()
