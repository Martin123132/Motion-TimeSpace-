from bridge_support import *
import sympy as sym


def main():
    with worker('symbolic'):
        hubble, mass2, field, velocity, alpha, eta, lapse, wave = sym.symbols(
            'H mu2 phi v alpha eta Psi k', real=True)
        sync_field, sync_velocity = sym.symbols('u_s w_s', real=True)
        potential = eta - hubble * alpha
        field_new = sync_field + velocity * alpha
        field_prime = sync_velocity + (-2 * hubble * velocity - mass2 * field) * alpha + velocity * (lapse - hubble * alpha)
        momentum = sync_velocity - mass2 * field * alpha - 3 * eta * velocity
        checks = {}

        def exact(name, value):
            reduced = sym.simplify(value)
            checks[name] = dict(passed=bool(reduced == 0), remainder=str(reduced))
            require(reduced == 0, name)

        exact('canonical_gauge_map', field_prime - (lapse + 3 * potential) * velocity - momentum)
        density_sync = velocity * sync_velocity + mass2 * field * sync_field
        pressure_sync = velocity * sync_velocity - mass2 * field * sync_field
        current_sync = wave * velocity * sync_field
        density = velocity * momentum + mass2 * field * field_new + 3 * velocity**2 * potential
        pressure = velocity * momentum - mass2 * field * field_new + 3 * velocity**2 * potential
        current = wave * velocity * field_new
        exact('density_gauge_map', density - density_sync + 3 * hubble * velocity**2 * alpha)
        exact('pressure_gauge_map', pressure - pressure_sync + (3 * hubble * velocity**2 + 2 * mass2 * field * velocity) * alpha)
        exact('current_gauge_map', current - current_sync - wave * velocity**2 * alpha)
        exact('compensated_density', density - 3 * velocity**2 * potential - density_sync + 3 * eta * velocity**2)
        gauge_jacobian = sym.Matrix([field_new, momentum]).jacobian([sync_field, sync_velocity])
        exact('gauge_affine_determinant', gauge_jacobian.det() - 1)
        exact('gauge_inverse_field', field_new - velocity * alpha - sync_field)
        exact('gauge_inverse_momentum', momentum + mass2 * field * alpha + 3 * eta * velocity - sync_velocity)
        scale, real_b, imag_b, real_l, frequency = sym.symbols('a Br Bi Lk Wk', real=True, nonzero=True)
        real_z, imag_z, real_v, imag_v = sym.symbols('x y r s', real=True)
        carrier = real_b + sym.I * imag_b
        envelope = real_z + sym.I * imag_z
        auxiliary = real_v + sym.I * imag_v
        lambda_k = real_l - sym.I * frequency
        physical_field = carrier * envelope / scale
        physical_momentum = carrier * (auxiliary + (lambda_k - hubble) * envelope) / scale
        coordinates = sym.Matrix([sym.re(physical_field), sym.im(physical_field), sym.re(physical_momentum), sym.im(physical_momentum)])
        transform = coordinates.jacobian([real_z, imag_z, real_v, imag_v])
        exact('full_map_determinant', transform.det() - (real_b**2 + imag_b**2)**2 / scale**4)
        canonical = sym.zeros(4)
        canonical[0, 2] = canonical[1, 3] = scale**2
        canonical[2, 0] = canonical[3, 1] = -scale**2
        expected = sym.Matrix([[0, 2 * frequency, 1, 0], [-2 * frequency, 0, 0, 1], [-1, 0, 0, 0], [0, -1, 0, 0]])
        defect = transform.T * canonical * transform - (real_b**2 + imag_b**2) * expected
        for row in range(4):
            for column in range(4):
                exact(f'symplectic_{row}_{column}', defect[row, column])
        exact('full_map_inverse_field', scale * physical_field / carrier - envelope)
        exact('full_map_inverse_momentum', (scale * physical_momentum + (hubble - lambda_k) * scale * physical_field) / carrier - auxiliary)
        real_a, real_ak = sym.symbols('aR ak', real=True)
        freq0, freqk, mass, positive_wave = sym.symbols('W0 Wk mu k_positive', positive=True)
        squared = real_a**2 + freq0**2
        denominator = squared + mass**2
        matrix = 2 / denominator * sym.Matrix([[real_a * real_ak + freq0 * freqk + mass**2, real_a * freqk - freq0 * real_ak, real_a, -freq0], [positive_wave * real_a, -positive_wave * freq0, 0, 0]])
        factor = freqk * squared + mass**2 * freq0
        first = sym.Matrix([freq0, real_a, -real_a * factor / squared, freq0 * factor / squared])
        second = sym.Matrix([0, 0, freq0, real_a])
        for label, direction in [('first', first), ('second', second)]:
            for row in range(2):
                exact(f'{label}_null_{row}', (matrix * direction)[row])
        exact('rank_two_minor', matrix[:, [1, 3]].det() + 4 * positive_wave * freq0**2 / denominator**2)
        pressure_row = matrix[0, :] - sym.Matrix([[4 * mass**2 / denominator, 0, 0, 0]])
        exact('first_null_changes_pressure', (pressure_row * first)[0] + 4 * mass**2 * freq0 / denominator)
        exact('second_null_instant_pressure', (pressure_row * second)[0])
        require(all(row['passed'] for row in checks.values()), 'all symbolic identities')
        write('symbolic-result.json', dict(passed=True, checks=checks, count=len(checks), sympy_version=sym.__version__, script_sha256=digest(__file__), derivation_sha256=digest(ROOT / 'DERIVATION.md')))
        print(json.dumps(dict(passed=True, identities=len(checks))), flush=True)


if __name__ == '__main__':
    main()
