import os
import sys
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[name] = '1'
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-independent-wavelength-20261110'
BRANCH = POST / 'condensate-origin-20261003'
SPECTRUM = BRANCH / 'resolved-matter-spectrum-20261007'
MATCHING = BRANCH / 'native-heavy-matching-20261007'
EARLY = BRANCH / 'native-two-field-transfer-20261007'
EXPECTED = '15c90a84a35a44e793bf32e9138e69968a504bd52c318421e4e3061022efa2d8'
GATE, ALGEBRA = 2e-5, 1e-10
START = time.monotonic()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    with (ROOT / name).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False))


def guard():
    require(time.monotonic() - START < 900, 'bounded worker deadline')
    for directory in (ROOT, POST, PREVIOUS, BRANCH):
        require(not (directory / 'STOP-REQUESTED').exists(), 'owner hold ' + str(directory))


def exited(identity):
    try:
        process = psutil.Process(identity['pid'])
        same = abs(process.create_time() - identity['created']) < .01 and process.cmdline() == identity['command']
    except psutil.NoSuchProcess:
        return dict(exited=True, reason='PID absent')
    return dict(exited=not same, reason='original identity live' if same else 'PID reused; untouched')


@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())
    write(name + '-start.json', identity)
    try:
        guard()
        yield identity
    except BaseException as error:
        write(name + '-end.json', dict(**identity, state='failed', error=repr(error)))
        raise
    else:
        write(name + '-end.json', dict(**identity, state='completed', elapsed=time.monotonic() - START))


def preserved():
    require(digest(PREVIOUS / 'closeout.json') == EXPECTED, 'previous seal')
    seal = read(PREVIOUS / 'closeout.json')
    result = dict(seal['input_hashes'])
    result[str(PREVIOUS / 'closeout.json')] = EXPECTED
    result.update({str(PREVIOUS / name): row['sha256'] for name, row in seal['artifacts'].items()})
    result[str(PREVIOUS / 'CLEANUP-VERIFIED.json')] = digest(PREVIOUS / 'CLEANUP-VERIFIED.json')
    for path, checksum in result.items():
        guard()
        require(digest(path) == checksum, 'changed inherited source ' + path)
    return result
