from bridge_support import *
import numpy as np
import sympy as sym
from scipy.interpolate import CubicSpline


def main():
    with worker('state-covariance'):
        require(read(ROOT / 'recovery-result.json')['passed'], 'physical recovery passed')
        hubble, mass2, wave, potential, lapse, potential_prime = sym.symbols('H mu2 k Phi Psi Phi_prime', real=True)
        field = sym.Matrix(sym.symbols('b1 b2', real=True))
        velocity = sym.Matrix(sym.symbols('v1 v2', real=True))
        perturbation = sym.Matrix(sym.symbols('u1 u2', real=True))
        momentum = sym.Matrix(sym.symbols('p1 p2', real=True))
        first, cross, second = sym.symbols('Sigma11 Sigma12 Sigma22', real=True)
        covariance = sym.Matrix([[first, cross], [cross, second]])
        dot = lambda left, right: (left.T * covariance * right)[0]
        enthalpy = dot(velocity, velocity)
        rho = (enthalpy + mass2 * dot(field, field)) / 2
        background_pressure = (enthalpy - mass2 * dot(field, field)) / 2
        density = dot(velocity, momentum) + mass2 * dot(field, perturbation) + 3 * enthalpy * potential
        pressure = dot(velocity, momentum) - mass2 * dot(field, perturbation) + 3 * enthalpy * potential
        current = wave * dot(velocity, perturbation)
        variables = list(field) + list(velocity) + list(perturbation) + list(momentum) + [mass2, potential]
        rates = list(velocity) + list(-2 * hubble * velocity - mass2 * field) + list(momentum + (lapse + 3 * potential) * velocity) + list(-2 * hubble * momentum - (wave**2 + mass2) * perturbation + mass2 * (3 * potential - lapse) * field) + [2 * hubble * mass2, potential_prime]
        derivative = lambda expression: sum(sym.diff(expression, variable) * rate for variable, rate in zip(variables, rates))
        checks = {}

        def exact(name, expression):
            value = sym.simplify(expression)
            checks[name] = dict(passed=bool(value == 0), remainder=str(value))
            require(value == 0, name)

        exact('background_energy', derivative(rho) + hubble * (rho + 3 * background_pressure))
        exact('perturbation_energy', derivative(density) + hubble * (density + 3 * pressure) + wave * current - 3 * enthalpy * potential_prime)
        exact('perturbation_current', derivative(current) + 2 * hubble * current - wave * (pressure + enthalpy * lapse))
        coherent = {first: 1, cross: 0, second: 0}
        exact('coherent_density', density.subs(coherent) - velocity[0] * momentum[0] - mass2 * field[0] * perturbation[0] - 3 * velocity[0]**2 * potential)
        exact('coherent_pressure', pressure.subs(coherent) - velocity[0] * momentum[0] + mass2 * field[0] * perturbation[0] - 3 * velocity[0]**2 * potential)
        exact('coherent_current', current.subs(coherent) - wave * velocity[0] * perturbation[0])
        for label, expression in [('rho', rho), ('density', density), ('pressure', pressure), ('current', current)]:
            for auxiliary in (field[1], velocity[1], perturbation[1], momentum[1]):
                exact(label + '_unoccupied_' + str(auxiliary), sym.diff(expression.subs(coherent), auxiliary))
        uniform = {first: sym.Rational(1, 2), cross: 0, second: sym.Rational(1, 2)}
        complex_field = field[0] + sym.I * field[1]
        complex_velocity = velocity[0] + sym.I * velocity[1]
        complex_u = perturbation[0] + sym.I * perturbation[1]
        complex_p = momentum[0] + sym.I * momentum[1]
        exact('uniform_complex_density', (density - 3 * enthalpy * potential).subs(uniform) - sym.re(sym.conjugate(complex_velocity) * complex_p + mass2 * sym.conjugate(complex_field) * complex_u) / 2)
        exact('uniform_complex_pressure', (pressure - 3 * enthalpy * potential).subs(uniform) - sym.re(sym.conjugate(complex_velocity) * complex_p - mass2 * sym.conjugate(complex_field) * complex_u) / 2)
        exact('uniform_complex_current', current.subs(uniform) - wave * sym.re(sym.conjugate(complex_velocity) * complex_u) / 2)
        coherent_matrix = sym.Matrix([[mass2 * field[0], velocity[0]], [wave * velocity[0], 0]])
        exact('real_source_determinant', coherent_matrix.det() + wave * velocity[0]**2)
        basis = sym.Matrix([[2, 1], [-1, 3]])
        transformed = basis.inv().T * covariance * basis.inv()
        for label, left, right in [('density_kinetic', velocity, momentum), ('density_potential', field, perturbation), ('current', velocity, perturbation), ('enthalpy', velocity, velocity)]:
            exact('basis_invariance_' + label, ((basis * left).T * transformed * (basis * right))[0] - dot(left, right))
        require(transformed.subs(coherent).rank() == 1 and transformed.subs(uniform).rank() == 2, 'rank is not a population convention')
        projection = projection_weight_diagnostic()
        numeric = numeric_null_control()
        write('state-covariance-result.json', dict(passed=True, exact_identities=len(checks), checks=checks, coherent_rank=1, uniform_rank=2, projection=projection, null_control=numeric, coupled_forward_test=False, source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'STATE-COVARIANCE-BRIDGE.md', ROOT / 'recovery-result.json', ROOT / 'projection-reproduction.json')}))
        print(json.dumps(dict(passed=True, identities=len(checks), projection=projection, null_control=numeric)), flush=True)


def projection_weight_diagnostic():
    with np.load(ROOT / 'heavy-canonical-early-state.npz', allow_pickle=False) as packet:
        scales = packet['a'].copy()
    with np.load(EARLY / 'runs/backgrounds/heavy.npz', allow_pickle=False) as background:
        phase_spline = CubicSpline(background['heavy_efold'], background['phase_h'])
    center = read(ROOT / 'projection-reproduction.json')['center']
    phase, middle = phase_spline(np.log(scales)), float(phase_spline(np.log(center)))
    chosen = abs(phase - middle) < 6 * np.pi
    coordinate = (phase[chosen] - middle) / (6 * np.pi)
    basis = np.column_stack([coordinate**power for power in range(9)] + [coordinate**power * trig(2 * phase[chosen]) for power in range(7) for trig in (np.cos, np.sin)] + [coordinate**power * trig(4 * phase[chosen]) for power in range(3) for trig in (np.cos, np.sin)])
    weights = np.linalg.pinv(basis)[0]
    require(abs(weights.sum() - 1) < ALGEBRA, 'constant projection reproduction')
    minimum = float(weights.min())
    return dict(samples=len(weights), sum=float(weights.sum()), minimum=minimum, maximum=float(weights.max()), negative_weights=int(np.count_nonzero(weights < 0)), negative_weight_sum=float(weights[weights < 0].sum()), can_interpret_as_positive_average=bool(minimum >= 0), note='Signed secular-coefficient extraction remains valid as regression; it is not automatically an ensemble probability measure.')


def numeric_null_control():
    real_a, real_ak, freq0, freqk, mass, wave = .2, -.1, 2., 2.5, 1.7, .9
    squared = real_a**2 + freq0**2
    denominator = squared + mass**2
    matrix = 2 / denominator * np.array([[real_a * real_ak + freq0 * freqk + mass**2, real_a * freqk - freq0 * real_ak, real_a, -freq0], [wave * real_a, -wave * freq0, 0, 0]])
    factor = freqk * squared + mass**2 * freq0
    direction = np.array([freq0, real_a, -real_a * factor / squared, freq0 * factor / squared])
    pressure = matrix[0].copy()
    pressure[0] -= 4 * mass**2 / denominator
    defect = float(np.max(abs(matrix @ direction)))
    pressure_change = float(pressure @ direction)
    require(defect < ALGEBRA, 'null direction numerical control')
    require(abs(pressure_change + 4 * mass**2 * freq0 / denominator) < ALGEBRA, 'pressure-changing null numerical control')
    require(abs(pressure_change) > 1, 'two-moment pressure uniqueness rejected')
    return dict(synthetic=True, moment_difference_max=defect, pressure_difference=pressure_change, unique_pressure_from_two_moments=False)


if __name__ == '__main__':
    main()
