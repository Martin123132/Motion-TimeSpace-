import os
import sys
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
import json
import hashlib
import time
from pathlib import Path
from datetime import datetime, timezone
import psutil
import numpy as np
import sympy as sym
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
SAVED = POST / "mts-formation-state-bundle-20261110"
NATIVE = POST / "condensate-origin-20261003/native-heavy-matching-20261007/native/fortran/MTSTwoField.f90"
ALGEBRA, NUMERICAL, SPAN = 1e-10, 2e-5, .001
START = time.monotonic()
INPUTS, CHECKS = {}, []


def guard():
    if time.monotonic() - START > 900:
        raise RuntimeError("bounded action probe expired")
    for path in (ROOT / "STOP-REQUESTED", POST / "STOP-REQUESTED"):
        if path.exists():
            raise RuntimeError("owner hold " + str(path))


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(name, data):
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        json.dump(data, stream, indent=2, allow_nan=False)


def protect(path, expected=None):
    path = Path(path)
    checksum = digest(path)
    if expected is not None and checksum != expected:
        raise ValueError("changed source " + str(path))
    INPUTS[str(path)] = checksum
    return path


def check(name, error, gate=ALGEBRA):
    error = float(error)
    if not np.isfinite(error) or abs(error) > gate:
        raise ValueError(name + ": " + str(error))
    CHECKS.append(dict(name=name, error=error, gate=gate, passed=True))


def symbolic():
    density, phase, hubble, mass, wave, sound, potential, lapse = sym.symbols(
        "density phase hubble mass wave sound potential lapse", real=True)
    rest = density + 3 * potential - 3 * hubble * phase / mass
    energy = mass * sound * rest**2 / 2 + wave**2 * phase**2 / (2 * mass) + mass * lapse * density
    expected = sym.Matrix([wave**2 * phase / mass - 3 * hubble * sound * rest,
                           -mass * (lapse + sound * rest)])
    derived = sym.Matrix([sym.diff(energy, phase), -sym.diff(energy, density)])
    hessian = sym.hessian(energy, (density, phase))
    generator = derived.jacobian((density, phase))
    residuals = list(derived - expected) + [hessian.det() - wave**2 * sound, sym.trace(generator)]
    alpha, alpha_prime, hubble_prime, potential_prime, syn_density, syn_velocity = sym.symbols(
        "alpha alpha_prime hubble_prime potential_prime syn_density syn_velocity")
    pressure = sound * (syn_density + 3 * hubble * syn_velocity / wave)
    shear = wave**2 * alpha - 3 * potential_prime - 3 * hubble_prime * alpha - 3 * hubble * alpha_prime
    native_delta_prime = -wave * syn_velocity - shear - 3 * hubble * pressure
    native_velocity_prime = -hubble * syn_velocity + wave * pressure
    delta_newton = syn_density - 3 * hubble * alpha
    velocity_newton = syn_velocity + wave * alpha
    residuals += [
        native_delta_prime - 3 * hubble_prime * alpha - 3 * hubble * alpha_prime -
        (-wave * velocity_newton + 3 * potential_prime - 3 * hubble * pressure),
        (native_velocity_prime + wave * alpha_prime + hubble * velocity_newton - wave * (lapse + pressure)).subs(
            alpha_prime, lapse - hubble * alpha),
        sound * (delta_newton + 3 * hubble * velocity_newton / wave) - pressure]
    frequency, carrier, real_part, imag_part, amplitude, angle = sym.symbols(
        "frequency carrier real_part imag_part amplitude angle", positive=True)
    field = amplitude * (real_part * sym.cos(angle) + imag_part * sym.sin(angle))
    momentum = amplitude * frequency * (imag_part * sym.cos(angle) - real_part * sym.sin(angle))
    jacobian = sym.Matrix([field, momentum]).jacobian((real_part, imag_part))
    residuals.append(jacobian.det() - amplitude**2 * frequency)
    relative_density = (frequency + carrier) / carrier * real_part
    relative_pressure = (frequency - carrier) / carrier * real_part
    coefficient = (frequency - carrier) / (frequency + carrier)
    weight = 2 * frequency / (frequency + carrier)
    background_number = carrier * amplitude**2 / 2
    residuals += [relative_pressure - coefficient * relative_density,
                  weight - 1 - coefficient,
                  background_number * weight * sym.diff(relative_density, real_part) - amplitude**2 * frequency]
    flat_energy = carrier * coefficient * relative_density**2 / 2 + (frequency**2 - carrier**2) * imag_part**2 / (2 * carrier)
    parent_energy = (frequency - carrier) * frequency / carrier * (real_part**2 + imag_part**2)
    residuals += [weight * flat_energy - parent_energy,
                  (frequency**2 - carrier**2) * coefficient - (frequency - carrier)**2,
                  1 - coefficient**2 - 4 * frequency * carrier / (frequency + carrier)**2]
    ratio = sym.symbols("ratio", positive=True)
    dispersion = ratio**2 / (sym.sqrt(1 + ratio**2) + 1)**2
    residuals.append(-ratio * sym.diff(dispersion, ratio) + 2 * dispersion / sym.sqrt(1 + ratio**2))
    weight_symbol, weight_prime = sym.symbols("weight_symbol weight_prime")
    symplectic = sym.Matrix([[0, 1], [-1, 0]])
    compatibility = weight_prime * symplectic + weight_symbol * (generator.T * symplectic + symplectic * generator)
    residuals += list(compatibility - weight_prime * symplectic)
    answers = [str(sym.simplify(value)) for value in residuals]
    if not all(value == "0" for value in answers):
        raise ValueError("symbolic action identity " + str(answers))
    return answers


def load_case(model):
    path = protect(SAVED / ("late-" + model + ".npz"))
    with np.load(path) as packet:
        names = packet["columns"].tolist()
        values = packet["values"]
    values = values[values[:, names.index("nominal_a")] == .01]
    if len(values) != 399:
        raise ValueError("fixed initial slice coverage")
    get = lambda key: values[:, names.index(key)].copy()
    case = dict(model=model, wave=get("k_Mpc_inverse"), scale=get("a"),
                hubble=get("H_conformal_Mpc_inverse"), mass=get("test_mass_Mpc_inverse"),
                potential=get("Phi"), lapse=get("Psi"))
    case["density"] = get("heavy_delta_N" if model == "heavy" else "delta_cdm_N")
    case["velocity"] = get("heavy_u_N") if model == "heavy" else get("theta_cdm_N") / case["wave"]
    case["mass_scale"] = case["scale"] * case["mass"]
    case["initial"] = np.column_stack((case["density"] - 3 * case["potential"],
                                      -case["mass_scale"] * case["velocity"] / case["wave"]))
    case["normalizer"] = np.column_stack((
        np.maximum.reduce([abs(case["initial"][:, 0]), abs(case["density"]), 3 * abs(case["potential"]), np.full(399, 1e-100)]),
        np.maximum.reduce([abs(case["initial"][:, 1]), abs(case["mass_scale"] * case["lapse"] / case["hubble"]) * SPAN, np.full(399, 1e-100)])))
    return case


def coefficients(case, position):
    mass = case["mass_scale"] * np.exp(position)
    ratio = case["wave"] / mass
    sound = ratio**2 / (np.sqrt(1 + ratio**2) + 1)**2 if case["model"] == "heavy" else np.zeros_like(ratio)
    sound_derivative = -2 * sound / np.sqrt(1 + ratio**2)
    return mass, sound, sound_derivative


def generator(case, position):
    mass, sound, _ = coefficients(case, position)
    hubble, wave = case["hubble"], case["wave"]
    matrix = np.empty((399, 2, 2))
    matrix[:, 0, 0] = -3 * hubble * sound
    matrix[:, 0, 1] = (wave**2 + 9 * hubble**2 * sound) / mass
    matrix[:, 1, 0] = -mass * sound
    matrix[:, 1, 1] = 3 * hubble * sound
    forcing = np.column_stack((-9 * hubble * sound * case["potential"],
                                -mass * (case["lapse"] + 3 * sound * case["potential"])))
    normalizer = case["normalizer"]
    return (matrix * normalizer[:, None, :] / normalizer[:, :, None] / hubble[:, None, None],
            forcing / normalizer / hubble[:, None])


def energy(case, position, state):
    mass, sound, _ = coefficients(case, position)
    density, phase = state.T
    rest = density + 3 * case["potential"] - 3 * case["hubble"] * phase / mass
    pieces = np.column_stack((mass * sound * rest**2 / 2,
                              case["wave"]**2 * phase**2 / (2 * mass), mass * case["lapse"] * density))
    return pieces.sum(axis=1), np.sum(abs(pieces), axis=1)


def work_derivative(case, position, state):
    mass, sound, sound_prime = coefficients(case, position)
    density, phase = state.T
    rest = density + 3 * case["potential"] - 3 * case["hubble"] * phase / mass
    return (mass * (sound + sound_prime) * rest**2 / 2 + 3 * case["hubble"] * sound * rest * phase
            - case["wave"]**2 * phase**2 / (2 * mass) + mass * case["lapse"] * density)


def integrate_hamilton(case, tight=False):
    initial_energy, scale_energy = energy(case, 0, case["initial"])
    scale_energy = np.maximum(scale_energy, 1e-100)
    initial = np.column_stack((case["initial"] / case["normalizer"], np.zeros(399)))
    def rhs(position, flattened):
        guard()
        state = flattened.reshape(399, 3)
        matrix, force = generator(case, position)
        velocity = np.einsum("nij,nj->ni", matrix, state[:, :2]) + force
        work = work_derivative(case, position, state[:, :2] * case["normalizer"]) / scale_energy
        return np.column_stack((velocity, work)).ravel()
    solution = solve_ivp(rhs, (0, SPAN), initial.ravel(), method="DOP853",
                         rtol=3e-13 if tight else 2e-12, atol=3e-15 if tight else 2e-14)
    if not solution.success:
        raise ValueError(solution.message)
    final = solution.y[:, -1].reshape(399, 3)
    state = final[:, :2] * case["normalizer"]
    final_energy, _ = energy(case, SPAN, state)
    error = np.max(abs((final_energy - initial_energy) / scale_energy - final[:, 2]))
    check(case["model"] + " Hamilton work balance" + (" tight" if tight else ""), error)
    return state, dict(work_balance=float(error), evaluations=solution.nfev), final[:, 2]


def integrate_fluid(case):
    initial = np.column_stack((case["density"], case["velocity"]))
    normalizer = np.column_stack((case["normalizer"][:, 0],
        np.maximum.reduce([abs(case["velocity"]), abs(case["wave"] * case["lapse"] / case["hubble"]) * SPAN, np.full(399, 1e-100)])))
    def rhs(position, flattened):
        guard()
        density, velocity = (flattened.reshape(399, 2) * normalizer).T
        mass, sound, _ = coefficients(case, position)
        pressure = sound * (density + 3 * case["hubble"] * velocity / case["wave"])
        derivatives = np.column_stack((-case["wave"] * velocity / case["hubble"] - 3 * pressure,
            -velocity + case["wave"] / case["hubble"] * (case["lapse"] + pressure)))
        return (derivatives / normalizer).ravel()
    solution = solve_ivp(rhs, (0, SPAN), (initial / normalizer).ravel(), method="DOP853", rtol=2e-12, atol=2e-14)
    if not solution.success:
        raise ValueError(solution.message)
    density, velocity = (solution.y[:, -1].reshape(399, 2) * normalizer).T
    mass, _, _ = coefficients(case, SPAN)
    return np.column_stack((density - 3 * case["potential"], -mass * velocity / case["wave"]))


def midpoint(case, count):
    initial = case["initial"] / case["normalizer"]
    state = initial.copy()
    identity = np.broadcast_to(np.eye(2), (399, 2, 2)).copy()
    transport = identity.copy()
    step = SPAN / count
    maximum_det, maximum_local_energy = 0.0, 0.0
    for index in range(count):
        guard()
        position = (index + .5) * step
        matrix, force = generator(case, position)
        left, right = identity - step * matrix / 2, identity + step * matrix / 2
        before = state * case["normalizer"]
        state = np.linalg.solve(left, (np.einsum("nij,nj->ni", right, state) + step * force)[:, :, None])[:, :, 0]
        advance = np.linalg.solve(left, right)
        transport = advance @ transport
        maximum_det = max(maximum_det, float(np.max(abs(np.linalg.det(transport) - 1))))
        energy_before, norm_before = energy(case, position, before)
        energy_after, norm_after = energy(case, position, state * case["normalizer"])
        maximum_local_energy = max(maximum_local_energy, float(np.max(abs(energy_after - energy_before) /
            np.maximum.reduce([norm_before, norm_after, np.full(399, 1e-100)]))))
    check(case["model"] + " midpoint symplectic " + str(count), maximum_det)
    check(case["model"] + " midpoint frozen-energy " + str(count), maximum_local_energy)
    return state * case["normalizer"], transport, dict(steps=count, symplectic_error=maximum_det,
                                                      frozen_energy_error=maximum_local_energy)


def parent_normalization(case):
    mass, sound, _ = coefficients(case, 0)
    final_mass, final_sound, _ = coefficients(case, SPAN)
    frequency_ratio = np.sqrt(1 + (case["wave"] / mass)**2)
    if case["model"] == "cold":
        return dict(applicable=False, reason="classical control; no scalar parent normalization assigned"), None
    values = np.column_stack((case["wave"], sound, 1 + sound,
        -2 * sound / (frequency_ratio * (1 + sound)), (final_sound - sound) / (1 + sound),
        np.sqrt(1 - sound**2), np.sqrt(frequency_ratio)))
    report = dict(applicable=True, max_weight_minus_one=float(sound.max()),
        max_absolute_log_weight_rate_per_efold=float(abs(values[:, 3]).max()),
        max_absolute_naive_weight_drift=float(abs(values[:, 4]).max()),
        max_canonical_phase_multiplier_minus_one=float((np.sqrt(frequency_ratio) - 1).max()),
        positive_frequency_only=True, exact_FLRW_pullback_claimed=False)
    return report, values


def main():
    worker = psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    guard()
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(),
                    started=datetime.now(timezone.utc).isoformat(), affinity=worker.cpu_affinity())
    write("worker-start.json", identity)
    try:
        protect(SAVED / "closeout.json", "18d0046bd803891009fc5256d583470c1fd16fa4f678389eca2b762c3f93e7d5")
        seal = read(SAVED / "closeout.json")
        for relative, metadata in seal["artifacts"].items():
            protect(SAVED / relative, metadata["sha256"])
        for path, checksum in seal["input_hashes"].items():
            protect(path, checksum)
        native_expected = [checksum for path, checksum in seal["input_hashes"].items()
                           if Path(path) == NATIVE]
        if len(native_expected) != 1:
            raise ValueError("native action owner not uniquely pinned")
        protect(NATIVE, native_expected[0])
        for path in ROOT.iterdir():
            if path.suffix in (".md", ".py"):
                protect(path)
        identities = symbolic()
        write("symbolic.json", dict(passed=True, identities=identities, input_hashes=INPUTS))
        reports, outputs = [], []
        cases = {}
        for model in ("heavy", "cold"):
            case = load_case(model)
            cases[model] = case
            reference, integration, work = integrate_hamilton(case)
            tight, tight_report, tight_work = integrate_hamilton(case, tight=True)
            fluid = integrate_fluid(case)
            solver_error = float(np.max(abs((tight - reference) / case["normalizer"])))
            fluid_error = float(np.max(abs((fluid - reference) / case["normalizer"])))
            check(model + " solver refinement", solver_error, NUMERICAL)
            check(model + " independent fluid equivalence", fluid_error, NUMERICAL)
            refinements, states, transports = [], [], []
            for count in (8, 16, 32, 64):
                state, transport, report = midpoint(case, count)
                report["reference_error"] = float(np.max(abs((state - tight) / case["normalizer"])))
                refinements.append(report)
                states.append(state)
                transports.append(transport)
            check(model + " final midpoint refinement", refinements[-1]["reference_error"], NUMERICAL)
            normalization, data = parent_normalization(case)
            target = ROOT / (model + "-probe.npz")
            if target.exists():
                raise ValueError("do not overwrite probe")
            np.savez_compressed(target, wave=case["wave"], initial=case["initial"], hamilton=reference,
                tight=tight, fluid=fluid, midpoint=np.array(states), transport=np.array(transports),
                work=work, tight_work=tight_work, normalizer=case["normalizer"],
                parent_normalization=np.empty((0, 0)) if data is None else data,
                parent_columns=np.array(["k", "r", "W", "dlnW_dloga", "relative_weight_drift", "real_density_multiplier", "phase_multiplier"]))
            outputs.append(dict(path=str(target), sha256=digest(target)))
            reports.append(dict(model=model, rows=399, integration=integration, tight=tight_report,
                solver_refinement=solver_error, fluid_equivalence=fluid_error, refinements=refinements,
                parent_normalization=normalization))
        check("same mode set", np.max(abs(cases["heavy"]["wave"] - cases["cold"]["wave"])))
        for path, checksum in INPUTS.items():
            if digest(path) != checksum:
                raise ValueError("changed input at completion")
        result = dict(passed=True, reports=reports, symbolic_identities=len(identities), checks=CHECKS,
            inputs=INPUTS, outputs=outputs, span_log_a=SPAN, physical_source_held_probe=True,
            native_saved_cosmology_replay=False, nonlinear_realization=False, new_halo_prediction=False,
            exact_full_parent_action_claimed=False, exact_flat_parent_normalization_derived=True,
            naive_instantaneous_extension_has_symplectic_defect=True, gates=[ALGEBRA, NUMERICAL])
        write("result.json", result)
        write("worker-end.json", dict(**identity, state="completed", result_sha256=digest(ROOT / "result.json"),
              finished=datetime.now(timezone.utc).isoformat()))
        print(json.dumps(dict(symbolic_identities=len(identities), reports=reports)))
    except Exception as error:
        write("worker-end.json", dict(**identity, state="failed", error=repr(error),
                                    inputs=INPUTS, checks=CHECKS))
        raise


if __name__ == "__main__":
    main()
