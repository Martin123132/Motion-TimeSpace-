import json
from datetime import datetime, timezone
import run_action_probe as base

np, sym = base.np, base.sym


def symbolic_connection():
    hubble, mass, ratio = sym.symbols("hubble mass ratio", positive=True)
    real, imag = sym.symbols("real imag", real=True)
    rate = hubble * (1 - 1 / ratio**2) / 2
    beat = mass * (ratio - 1)
    background_slope = -3 * hubble / 2
    slope = -hubble - hubble / (2 * ratio**2)
    mixing = hubble / mass * (-3 * ratio / 2 + 1 + 1 / (2 * ratio**2))
    density = (ratio + 1) * real + mixing * imag
    pressure = (ratio - 1) * real + mixing * imag
    phase = imag - background_slope / mass * real
    sound = (ratio - 1) / (ratio + 1)
    weight = 2 * ratio / (ratio + 1)
    connection = hubble * (ratio - 1) / ratio**2
    differentiate = lambda expression: (sym.diff(expression, real) * (rate * real + beat * imag) +
        sym.diff(expression, imag) * (rate * imag - beat * real) +
        sym.diff(expression, ratio) * hubble * (1 / ratio - ratio) + sym.diff(expression, mass) * hubble * mass)
    residuals = [
        mixing - (background_slope * mass * ratio - mass * slope) / mass**2,
        sym.series(pressure - sound * density + (3 * hubble * sound + connection) * phase / mass, hubble, 0, 2).removeO(),
        sym.series(differentiate(density) - mass * (ratio**2 - 1) * phase + 3 * hubble * pressure, hubble, 0, 2).removeO(),
        sym.series(differentiate(phase) + mass * pressure, hubble, 0, 2).removeO(),
        connection + sym.diff(weight, ratio) * hubble * (1 / ratio - ratio) / weight]
    coordinate, momentum = sym.symbols("coordinate momentum", real=True)
    wave_squared = mass**2 * (ratio**2 - 1)
    hamilton = mass * sound * (coordinate - 3 * hubble * momentum / mass)**2 / 2 + wave_squared * momentum**2 / (2 * mass) + 3 * hubble * connection * momentum**2 / (2 * mass)
    physical = sym.Matrix([-3 * hubble * sound * coordinate +
                           (wave_squared + 9 * hubble**2 * sound + 3 * hubble * connection) / mass * momentum,
                           -mass * sound * coordinate + (3 * hubble * sound + connection) * momentum])
    generated = sym.Matrix([sym.diff(hamilton, momentum), -sym.diff(hamilton, coordinate) + connection * momentum])
    residuals += list(physical - generated)
    residuals += [sym.trace(physical.jacobian((coordinate, momentum))) - connection,
                  sym.hessian(hamilton, (coordinate, momentum)).det() - sound * (wave_squared + 3 * hubble * connection)]
    frequency_log_derivative = hubble / ratio**2
    frequency_second_over_frequency = hubble**2 * (2 / ratio**2 - 1 / ratio**4)
    residuals += [sym.Rational(3, 4) * frequency_log_derivative**2 -
                  frequency_second_over_frequency / 2 - hubble**2 -
                  hubble**2 * (sym.Rational(5, 4) / ratio**4 - 1 / ratio**2 - 1)]
    answers = [str(sym.simplify(value)) for value in residuals]
    if not all(value == "0" for value in answers):
        raise ValueError("connection identities " + str(answers))
    return answers


def parameters(case, position):
    mass, sound, _ = base.coefficients(case, position)
    squared_ratio = (case["wave"] / mass)**2
    frequency_ratio = np.sqrt(1 + squared_ratio)
    connection = case["hubble"] * squared_ratio / (frequency_ratio**2 * (frequency_ratio + 1)) if case["model"] == "heavy" else np.zeros(399)
    return mass, sound, frequency_ratio, connection


def template_map(case, position):
    mass, _, ratio, _ = parameters(case, position)
    hubble = case["hubble"]
    frequency = mass * ratio
    background_slope = -1.5 * hubble
    slope = -hubble - hubble / (2 * ratio**2)
    denominator = 2 * mass**2 + background_slope**2
    matrix = np.empty((399, 2, 2))
    matrix[:, 0, 0] = 2 * (background_slope * slope + mass * frequency + mass**2) / denominator
    matrix[:, 0, 1] = 2 * (background_slope * frequency - mass * slope) / denominator
    matrix[:, 1, 0] = -2 * mass * background_slope / denominator
    matrix[:, 1, 1] = 2 * mass**2 / denominator
    return matrix


def integrate_model(case, corrected):
    _, sound_initial, _, _ = parameters(case, 0)
    initial_weight = 1 + sound_initial if corrected else np.ones(399)
    initial = case["initial"].copy()
    initial[:, 1] *= initial_weight
    normalizer = case["normalizer"].copy()
    normalizer[:, 1] *= initial_weight
    def rhs(position, flattened):
        base.guard()
        state = flattened.reshape(399, 2) * normalizer
        mass, sound, _, connection = parameters(case, position)
        if not corrected:
            connection = np.zeros(399)
        weight = 1 + sound if corrected else np.ones(399)
        density, phase = state[:, 0], state[:, 1] / weight
        derivative_density = -3 * case["hubble"] * sound * density + (
            case["wave"]**2 + 9 * case["hubble"]**2 * sound + 3 * case["hubble"] * connection) * phase / mass
        derivative_momentum = weight * (-mass * sound * density + 3 * case["hubble"] * sound * phase)
        derivatives = np.column_stack((derivative_density, derivative_momentum)) / case["hubble"][:, None]
        return (derivatives / normalizer).ravel()
    answer = base.solve_ivp(rhs, (0, base.SPAN), (initial / normalizer).ravel(), method="DOP853",
        rtol=3e-13, atol=3e-15, max_step=base.SPAN / 4)
    if not answer.success:
        raise ValueError(answer.message)
    result = answer.y[:, -1].reshape(399, 2) * normalizer
    if corrected:
        _, sound_final, _, _ = parameters(case, base.SPAN)
        result[:, 1] /= 1 + sound_final
    return result


def integrate_template(case):
    initial = np.linalg.solve(template_map(case, 0), case["initial"][:, :, None])[:, :, 0]
    normalizer = np.maximum(abs(initial), case["normalizer"] / 4)
    def rhs(position, flattened):
        base.guard()
        state = flattened.reshape(399, 2) * normalizer
        mass, _, ratio, _ = parameters(case, position)
        squared = (case["wave"] / mass)**2
        rate = case["hubble"] * squared / (2 * ratio**2)
        beat = mass * squared / (ratio + 1)
        derivatives = np.column_stack((rate * state[:, 0] + beat * state[:, 1],
                                       rate * state[:, 1] - beat * state[:, 0])) / case["hubble"][:, None]
        return (derivatives / normalizer).ravel()
    answer = base.solve_ivp(rhs, (0, base.SPAN), (initial / normalizer).ravel(), method="DOP853",
        rtol=3e-13, atol=3e-15, max_step=base.SPAN / 4)
    if not answer.success:
        raise ValueError(answer.message)
    state = answer.y[:, -1].reshape(399, 2) * normalizer
    return np.einsum("nij,nj->ni", template_map(case, base.SPAN), state)


def canonical_midpoint(case):
    identity = np.broadcast_to(np.eye(2), (399, 2, 2)).copy()
    transport = identity.copy()
    count, step = 64, base.SPAN / 64
    for index in range(count):
        position = (index + .5) * step
        mass, sound, _, connection = parameters(case, position)
        weight = 1 + sound
        matrix = np.empty((399, 2, 2))
        matrix[:, 0, 0] = -3 * case["hubble"] * sound
        matrix[:, 0, 1] = (case["wave"]**2 + 9 * case["hubble"]**2 * sound + 3 * case["hubble"] * connection) / (mass * weight)
        matrix[:, 1, 0] = -weight * mass * sound
        matrix[:, 1, 1] = 3 * case["hubble"] * sound
        matrix = matrix / case["hubble"][:, None, None]
        transport = np.linalg.solve(identity - step * matrix / 2, identity + step * matrix / 2) @ transport
    error = float(np.max(abs(np.linalg.det(transport) - 1)))
    base.check(case["model"] + " corrected canonical transport", error)
    return transport, error


def main():
    worker = base.psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(),
                    started=datetime.now(timezone.utc).isoformat())
    base.write("connection-start.json", identity)
    try:
        previous = base.read(base.ROOT / "result.json")
        for path, checksum in previous["inputs"].items():
            base.protect(path, checksum)
        base.protect(base.ROOT / "FIRST-ADIABATIC-CONNECTION.md")
        base.protect(__file__)
        identities = symbolic_connection()
        reports, outputs = [], []
        for model in ("heavy", "cold"):
            case = base.load_case(model)
            case["potential"] = np.zeros(399)
            case["lapse"] = np.zeros(399)
            case["initial"][:, 0] = case["density"]
            original = integrate_model(case, False)
            corrected = integrate_model(case, True)
            transport, symplectic_error = canonical_midpoint(case)
            report = dict(model=model, rows=399, canonical_symplectic_error=symplectic_error,
                          original_to_corrected=float(np.max(abs((corrected - original) / case["normalizer"]))))
            template = np.empty((0, 0))
            residual = np.empty(0)
            if model == "heavy":
                template = integrate_template(case)
                original_error = float(np.max(abs((original - template) / case["normalizer"])))
                corrected_error = float(np.max(abs((corrected - template) / case["normalizer"])))
                mass, sound, ratio, connection = parameters(case, 0)
                residual = case["hubble"]**2 * (1.25 / ratio**4 - 1 / ratio**2 - 1) / (mass * ratio)**2
                report.update(original_to_WKB_template=original_error, corrected_to_WKB_template=corrected_error,
                    max_template_KG_residual=float(abs(residual).max()),
                    max_background_KG_residual=float((.75 * (case["hubble"] / mass)**2).max()),
                    max_connection_per_H=float((connection / case["hubble"]).max()),
                    pressure_second_order_not_fully_derived=True, metric_forcing_not_derived=True)
                base.check("first-order completion versus full projected WKB template", corrected_error, base.NUMERICAL)
            else:
                base.check("unchanged cold completion", report["original_to_corrected"])
            path = base.ROOT / (model + "-connection.npz")
            if path.exists():
                raise ValueError("preserve existing connection probe")
            np.savez_compressed(path, wave=case["wave"], initial=case["initial"], original=original,
                                corrected=corrected, template=template, canonical_transport=transport,
                                normalizer=case["normalizer"], template_residual=residual)
            outputs.append(dict(path=str(path), sha256=base.digest(path)))
            reports.append(report)
        for path, checksum in base.INPUTS.items():
            if base.digest(path) != checksum:
                raise ValueError("changed connection input")
        result = dict(passed=True, identities=identities, reports=reports, outputs=outputs,
            inputs=base.INPUTS, checks=base.CHECKS, full_metric_perturbation_reduction=False,
            higher_order_remainder_bound=False, first_adiabatic_connection_derived=True,
            original_native_averaged_closure_unchanged=True)
        base.write("connection-result.json", result)
        base.write("connection-end.json", dict(**identity, state="completed",
                   result_sha256=base.digest(base.ROOT / "connection-result.json")))
        print(json.dumps(dict(symbolic_identities=len(identities), reports=reports)))
    except Exception as error:
        base.write("connection-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
