import json
from datetime import datetime, timezone
from decimal import Decimal, localcontext
import derive_connection as connection

base, sym, np = connection.base, connection.sym, connection.np


def template_generator_proof():
    mass, ratio, hubble = sym.symbols("mass ratio hubble", positive=True)
    background_slope = -sym.Rational(3, 2) * hubble
    slope = -hubble - hubble / (2 * ratio**2)
    denominator = 2 * mass**2 + background_slope**2
    transform = sym.Matrix([
        [2 * (background_slope * slope + mass**2 * ratio + mass**2) / denominator,
         2 * (background_slope * mass * ratio - mass * slope) / denominator],
        [-2 * mass * background_slope / denominator, 2 * mass**2 / denominator]])
    rate = hubble * (1 - 1 / ratio**2) / 2
    microscopic = sym.Matrix([[rate, mass * (ratio - 1)], [-mass * (ratio - 1), rate]])
    derivative = transform.diff(mass) * hubble * mass + transform.diff(ratio) * hubble * (1 / ratio - ratio)
    exact = (derivative + transform * microscopic) * transform.inv()
    sound = (ratio - 1) / (ratio + 1)
    correction = hubble * (ratio - 1) / ratio**2
    expected = sym.Matrix([[-3 * hubble * sound, mass * (ratio**2 - 1) +
                           (9 * hubble**2 * sound + 3 * hubble * correction) / mass],
                          [-mass * sound, 3 * hubble * sound + correction]])
    residuals = [sym.simplify(sym.series(element, hubble, 0, 2).removeO()) for element in exact - expected]
    parent_weight = 2 * ratio / transform.det()
    residuals += [sym.simplify(parent_weight.subs(hubble, 0) - 2 * ratio / (ratio + 1)),
                  sym.simplify(sym.diff(parent_weight, hubble).subs(hubble, 0))]
    residuals = [str(value) for value in residuals]
    if any(value != "0" for value in residuals):
        raise ValueError(residuals)
    return residuals


def cold_control(factor):
    case = base.load_case("cold")
    case["hubble"] *= factor
    case["potential"][:] = 0
    case["lapse"][:] = 0
    case["initial"][:, 0] = case["density"]
    evolved = connection.integrate_model(case, True)
    with localcontext() as context:
        context.prec = 60
        number = lambda value: Decimal.from_float(float(value))
        span = number(base.SPAN)
        decay = (-span).exp()
        error = 0.0
        for index in range(399):
            wave, hubble = number(case["wave"][index]), number(case["hubble"][index])
            velocity = number(case["velocity"][index])
            final_density = number(case["density"][index]) - wave / hubble * velocity * (1 - decay)
            phase = -number(case["mass_scale"][index]) * velocity / wave
            for component, expected in enumerate((final_density, phase)):
                error = max(error, abs(float(number(evolved[index, component]) - expected)) / case["normalizer"][index, component])
    base.check("cold analytic H factor " + str(factor), error)
    return dict(H_factor=factor, maximum_error=error)


def main():
    worker = base.psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
    base.write("connection-validation-start.json", identity)
    try:
        result = base.read(base.ROOT / "connection-result.json")
        for path, checksum in result["inputs"].items():
            base.protect(path, checksum)
        for output in result["outputs"]:
            base.protect(output["path"], output["sha256"])
        identities = template_generator_proof()
        cold = [cold_control(factor) for factor in (1.0, .5, .25, .125, .0625)]
        scaling = base.read(base.ROOT / "adiabatic-scaling-diagnosis.json")
        ratios = [new["corrected"] / old["corrected"] for old, new in zip(scaling, scaling[1:])]
        if not all(.45 < value < .55 for value in ratios):
            raise ValueError("unresolved expected fixed-efold first-order remainder scaling")
        output = dict(passed=True, identities=identities, cold_controls=cold,
            scaling_ratios=ratios, acceptance_gate_unchanged=True,
            no_numerical_improvement_at_retained_H=True, retained_H_comparison=scaling[0],
            result_sha256=base.digest(base.ROOT / "connection-result.json"),
            scaling_sha256=base.digest(base.ROOT / "adiabatic-scaling-diagnosis.json"),
            validator_sha256=base.digest(__file__), identity=identity)
        base.write("connection-validation.json", output)
        base.write("connection-validation-end.json", dict(**identity, state="completed"))
        print(json.dumps(dict(symbolic_identities=len(identities), cold_controls=cold, scaling_ratios=ratios)))
    except Exception as error:
        base.write("connection-validation-end.json", dict(**identity, state="failed", error=repr(error)))
        raise


if __name__ == "__main__":
    main()
