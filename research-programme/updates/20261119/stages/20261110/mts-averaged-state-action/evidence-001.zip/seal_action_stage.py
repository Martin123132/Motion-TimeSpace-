import ast
import json
import hashlib
from pathlib import Path
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
worker = psutil.Process()
worker.cpu_affinity([4])
worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(),
                started=datetime.now(timezone.utc).isoformat())


def read(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


with (ROOT / "seal-start.json").open("x") as stream:
    json.dump(identity, stream)
try:
    result, connection = read("result.json"), read("connection-result.json")
    validation, connection_validation = read("validation.json"), read("connection-validation.json")
    assert all(item["passed"] for item in (result, connection, validation, connection_validation))
    assert validation["result_sha256"] == digest(ROOT / "result.json")
    assert validation["validator_sha256"] == digest(ROOT / "validate_parent_action.py")
    assert connection_validation["result_sha256"] == digest(ROOT / "connection-result.json")
    assert connection_validation["validator_sha256"] == digest(ROOT / "validate_connection.py")
    assert connection_validation["scaling_sha256"] == digest(ROOT / "adiabatic-scaling-diagnosis.json")
    inputs = {**result["inputs"], **connection["inputs"]}
    for path, checksum in inputs.items():
        assert Path(path).is_file() and digest(path) == checksum, path
    for output in result["outputs"] + connection["outputs"]:
        assert digest(output["path"]) == output["sha256"]
    symbolic = read("symbolic.json")["identities"] + connection["identities"] + connection_validation["identities"]
    assert len(symbolic) == 35 and all(value == "0" for value in symbolic)
    cleanup = []
    for prefix in ("worker", "validation", "connection", "connection-validation"):
        start, end = read(prefix + "-start.json"), read(prefix + "-end.json")
        assert end["state"] == "completed" and start["pid"] == end["pid"] and start["created"] == end["created"]
        same_live = psutil.pid_exists(start["pid"]) and abs(psutil.Process(start["pid"]).create_time() - start["created"]) < .001
        assert not same_live, "task-owned worker live"
        cleanup.append(dict(prefix=prefix, pid=start["pid"], created=start["created"], command=start["command"], exited=True))
    assert not list(ROOT.rglob("__pycache__"))
    for path in ROOT.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    manifest = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size)
                for path in ROOT.rglob("*") if path.is_file()}
    closeout = dict(state="verified", time=datetime.now(timezone.utc).isoformat(), artifacts=manifest,
        input_hashes=inputs, source_count=len(inputs), symbolic_identities=35,
        parent_validation_scalar_checks=sum(validation["checks"].values()),
        cleanup=cleanup, sealer=identity, standalone_diagnostic="diagnose_adiabatic_scaling.py returned exit0 synchronously",
        physical_result="retained action plus first-adiabatic real-field connection; see RESULTS.md",
        next_target="second-adiabatic action/source correction, then metric-perturbation forcing",
        retained_H_numerical_improvement=False, original_native_closure_unchanged=True,
        no_new_halo_prediction=True, no_github=True, no_galaxy_file_changes=True,
        broad_goal_complete=False)
    with (ROOT / "closeout.json").open("x") as stream:
        json.dump(closeout, stream, indent=2, allow_nan=False)
    checksum = digest(ROOT / "closeout.json")
    with (ROOT / "seal-end.json").open("x") as stream:
        json.dump(dict(**identity, state="completed", closeout_sha256=checksum), stream)
    print(json.dumps(dict(closeout_sha256=checksum, artifacts=len(manifest), source_count=len(inputs),
                         cleanup=cleanup, sealer_pid=worker.pid)))
except Exception as error:
    with (ROOT / "seal-end.json").open("x") as stream:
        json.dump(dict(**identity, state="failed", error=repr(error)), stream)
    raise
