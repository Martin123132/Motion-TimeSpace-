import os
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[key] = "1"
import json
import hashlib
from pathlib import Path
from decimal import Decimal, localcontext
from datetime import datetime, timezone
import numpy as np
import psutil
from scipy.linalg import expm

ROOT = Path(__file__).resolve().parent
SAVED = ROOT.parent / "mts-formation-state-bundle-20261110"
ERRORS, COUNTS = {}, {}


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def check(name, left, right, scale=1.0, gate=1e-10):
    error = abs(float(left - right)) / max(abs(float(scale)), 1e-100)
    ERRORS[name] = max(ERRORS.get(name, 0.0), error)
    COUNTS[name] = COUNTS.get(name, 0) + 1
    if not np.isfinite(error) or error > gate:
        raise ValueError(name + ": " + str(error))


def table(name):
    with np.load(SAVED / (name + ".npz")) as packet:
        columns = packet["columns"].tolist()
        return [dict(zip(columns, row)) for row in packet["values"]]


def flat_parent():
    with localcontext() as context:
        context.prec = 60
        number = lambda value: Decimal.from_float(float(value))
        for row in table("late-heavy"):
            mass = number(row["a"]) * number(row["test_mass_Mpc_inverse"])
            wave = number(row["k_Mpc_inverse"])
            frequency = (mass**2 + wave**2).sqrt()
            beat = frequency - mass
            sound = (wave / mass)**2 / ((1 + (wave / mass)**2).sqrt() + 1)**2
            weight = 2 * frequency / (frequency + mass)
            amplitude = Decimal("1.3")
            background_number = mass * amplitude**2 / 2
            for real, imag in ((Decimal(".07"), Decimal("-.11")), (Decimal("-.19"), Decimal(".23"))):
                density = (frequency + mass) / mass * real
                projected_density = amplitude**2 * (mass * frequency + mass**2) * real / 2
                projected_pressure = amplitude**2 * (mass * frequency - mass**2) * real / 2
                mean_density = mass**2 * amplitude**2 / 2
                check("flat density coefficient", projected_density / mean_density, density, density)
                check("flat pressure coefficient", projected_pressure / mean_density, sound * density, sound * density)
                check("flat symplectic weight", background_number * weight * (frequency + mass) / mass,
                      amplitude**2 * frequency, amplitude**2 * frequency)
                hamilton = mass * sound * density**2 / 2 + wave**2 * imag**2 / (2 * mass)
                parent = beat * frequency / mass * (real**2 + imag**2)
                check("flat excitation normalization", weight * hamilton, parent, parent)
                check("flat canonical real map", (1 - sound**2).sqrt() * density / 2,
                      (frequency / mass).sqrt() * real, (frequency / mass).sqrt() * real)
            angle = 1.123
            coefficient = float((frequency + mass) / mass)
            transport = expm(angle * np.array([[0, coefficient], [-1 / coefficient, 0]]))
            initial = np.array([coefficient * .07, -.11])
            exact = np.array([coefficient * (.07 * np.cos(angle) - .11 * np.sin(angle)),
                              -.11 * np.cos(angle) - .07 * np.sin(angle)])
            check("finite beat phase propagation", np.max(abs(transport @ initial - exact)), 0, np.max(abs(exact)))
            check("flat transport symplectic", np.linalg.det(transport), 1)


def cold_exact():
    rows = [row for row in table("late-cold") if row["nominal_a"] == .01]
    with np.load(ROOT / "cold-probe.npz") as packet:
        comparison, normalizer = packet["hamilton"], packet["normalizer"]
    with localcontext() as context:
        context.prec = 60
        number = lambda value: Decimal.from_float(float(value))
        span = number(.001)
        decay = (-span).exp()
        for index, row in enumerate(rows):
            wave, hubble = number(row["k_Mpc_inverse"]), number(row["H_conformal_Mpc_inverse"])
            lapse, potential = number(row["Psi"]), number(row["Phi"])
            mass = number(row["a"]) * number(row["test_mass_Mpc_inverse"])
            velocity = number(row["theta_cdm_N"]) / wave
            density = number(row["delta_cdm_N"])
            final_velocity = velocity * decay + wave * lapse / hubble * (1 - decay)
            final_density = density - wave / hubble * (velocity * (1 - decay) +
                            wave * lapse / hubble * (span - 1 + decay))
            expected = [final_density - 3 * potential, -mass * span.exp() * final_velocity / wave]
            for component in range(2):
                check("analytic cold propagation", number(comparison[index, component]), expected[component],
                      normalizer[index, component])


def saved_flow():
    for model in ("heavy", "cold"):
        with np.load(ROOT / (model + "-probe.npz")) as packet:
            for index, count in enumerate((8, 16, 32, 64)):
                determinant = np.linalg.det(packet["transport"][index])
                check(model + " complete symplectic map", np.max(abs(determinant - 1)), 0)
            differences = np.max(abs((packet["midpoint"] - packet["tight"]) / packet["normalizer"]), axis=(1, 2))
            for older, newer in zip(differences[:-1], differences[1:]):
                if not newer < older:
                    raise ValueError("nondecreasing midpoint discrepancy")
            if model == "heavy":
                normalization = packet["parent_normalization"]
                naive_drift = normalization[:, 4]
                weighted_drift = (normalization[:, 2] * (1 + naive_drift) *
                                  np.linalg.det(packet["transport"][-1]) - normalization[:, 2]) / normalization[:, 2]
                check("predicted weighted symplectic defect", np.max(abs(weighted_drift - naive_drift)), 0)
                if not abs(naive_drift).max() > 1e-10:
                    raise ValueError("negative control does not resolve missing weight")


def main():
    worker = psutil.Process()
    worker.cpu_affinity([4])
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=worker.pid, created=worker.create_time(), command=worker.cmdline(), started=datetime.now(timezone.utc).isoformat())
    with (ROOT / "validation-start.json").open("x") as stream:
        json.dump(identity, stream)
    try:
        result = json.loads((ROOT / "result.json").read_text())
        for path, checksum in result["inputs"].items():
            if digest(path) != checksum:
                raise ValueError("changed source " + path)
        for output in result["outputs"]:
            if digest(output["path"]) != output["sha256"]:
                raise ValueError("changed probe")
        flat_parent()
        cold_exact()
        saved_flow()
        output = dict(passed=True, checks=COUNTS, maxima=ERRORS, identity=identity,
            result_sha256=digest(ROOT / "result.json"), validator_sha256=digest(__file__),
            weighted_defect_is_detected_not_repaired=True, standalone_cold_exact_solution=True)
        with (ROOT / "validation.json").open("x") as stream:
            json.dump(output, stream, indent=2, allow_nan=False)
        with (ROOT / "validation-end.json").open("x") as stream:
            json.dump(dict(**identity, state="completed"), stream)
        print(json.dumps(dict(checks=sum(COUNTS.values()), maxima=ERRORS)))
    except Exception as error:
        with (ROOT / "validation-end.json").open("x") as stream:
            json.dump(dict(**identity, state="failed", error=repr(error)), stream)
        raise


if __name__ == "__main__":
    main()
