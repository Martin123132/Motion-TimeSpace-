import json
import derive_connection as connection

base, np = connection.base, connection.np
reports = []
for factor in (1.0, .5, .25, .125, .0625):
    case = base.load_case("heavy")
    case["hubble"] *= factor
    case["potential"][:] = 0
    case["lapse"][:] = 0
    case["initial"][:, 0] = case["density"]
    original = connection.integrate_model(case, False)
    corrected = connection.integrate_model(case, True)
    template = connection.integrate_template(case)
    error = abs((corrected - template) / case["normalizer"])
    location = np.unravel_index(np.argmax(error), error.shape)
    reports.append(dict(H_factor=factor, corrected=float(error.max()),
        original=float(np.max(abs((original - template) / case["normalizer"]))),
        k=float(case["wave"][location[0]]), component=int(location[1]),
        corrected_value=float(corrected[location]), template_value=float(template[location]),
        original_value=float(original[location]), norm=float(case["normalizer"][location])))
base.write("adiabatic-scaling-diagnosis.json", reports)
print(json.dumps(reports))
