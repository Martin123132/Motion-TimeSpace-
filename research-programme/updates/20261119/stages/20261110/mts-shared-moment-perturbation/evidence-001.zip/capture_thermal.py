from stage_support import *
import numpy as np
from scipy.interpolate import CubicSpline


def main():
    with worker("thermal"):
        require(read(ROOT / "parity-result.json")["passed"], "direct native operator parity")
        sys.path.insert(0, str(POST / "condensate-origin-20261003/native-heavy-matching-20261007"))
        import matching_common as retained
        captures = read(ROOT / "native-control.json")
        backgrounds = read(POST / "mts-background-derivatives-20261110/background-result.json")
        reports = []
        for case in ("cold", "heavy"):
            entry = next(row for row in backgrounds["models"] if row["model"] == case)
            native = retained.camb.get_background(retained.params_for(Path(entry["background_source"])))
            positions = np.linspace(0, .001, 65)
            scale = np.exp(-np.log(11.) + positions)
            values = native.get_background_redshift_evolution(1 / scale - 1, vars=["opacity", "cs2b"])
            arrays = np.column_stack((values["opacity"], values["cs2b"]))
            spline = CubicSpline(positions[::2], arrays[::2], axis=0)
            errors = np.max(abs(spline(positions[1::2]) - arrays[1::2]) / np.maximum(abs(arrays[1::2]), 1e-100), axis=0)
            captured = next(row for row in captures["reports"] if row["case"] == case)
            replay_errors = []
            for context in captured["contexts"]:
                offset = np.log(context["scale"]) + np.log(11.)
                predicted = spline(offset)
                actual = np.array([context["opacity"], context["cs2b"]])
                replay_errors.append(float(np.max(abs(predicted - actual) / np.maximum(abs(actual), 1e-100))))
            np.savez_compressed(ROOT / (case + "-thermal.npz"), positions=positions, values=arrays)
            reports.append(dict(case=case, interpolation_errors=errors.tolist(), original_context_errors=replay_errors,
                                passed=bool(max(*errors, *replay_errors) <= GATE), output_sha256=digest(ROOT / (case + "-thermal.npz"))))
        result = dict(passed=all(row["passed"] for row in reports), reports=reports, code_sha256=digest(__file__),
                      convention="Retained opacity/cs2b as functions of scale factor, not refitted or recomputed under the tiny reference-background change.",
                      new_perturbation_evolution=False)
        write("thermal-result.json", result)
        print(json.dumps(result, indent=2))
        require(result["passed"], "retained thermal input interpolation")


if __name__ == "__main__":
    main()
