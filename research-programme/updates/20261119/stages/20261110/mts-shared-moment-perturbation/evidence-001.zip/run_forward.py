from stage_support import *
import argparse
import numpy as np
from scipy.linalg import expm
from shared_operator import SharedOperator


def fingerprint(case, count):
    names = ['direct_hierarchy.py', 'shared_operator.py', 'run_forward.py', 'stage_support.py',
             'EVOLUTION-CONTRACT.md', 'PREPARATION-CONTRACT.md', 'shared-result.json',
             case + str(count) + '-initial.npz']
    return {name: digest(ROOT / name) for name in names}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('count', type=int, choices=(32, 64))
    parser.add_argument('steps', type=int, choices=(64, 128))
    parser.add_argument('--from-step', type=int, default=0)
    parser.add_argument('--through-step', type=int)
    args = parser.parse_args()
    first, last = args.from_step, args.through_step or args.steps
    require(0 <= first < last <= args.steps and first % 8 == last % 8 == 0, 'eight-step batch endpoints')
    tag = f'{args.case}{args.count}-s{args.steps}'
    name = f'forward-{tag}-from{first:03d}'
    with worker(name):
        require(read(ROOT / 'shared-result.json')['passed'], 'shared operator/preparation checks')
        frozen = fingerprint(args.case, args.count)
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'inherited sources unchanged')
        previous_hash = frozen[args.case + str(args.count) + '-initial.npz']
        with np.load(ROOT / (args.case + str(args.count) + '-initial.npz'), allow_pickle=False) as packet:
            initial, scale, times = [packet[key].copy() for key in ('initial', 'normalization', 'times')]
        if first:
            receipt_path = ROOT / f'{tag}-chunk{first:03d}.json'
            receipt = read(receipt_path)
            require(receipt['last'] == first and receipt['frozen'] == frozen, 'resume fingerprint')
            origin = receipt['worker']
            require(exited(read(ROOT / (origin + '-start.json')))['exited'], 'previous worker exited')
            require(read(ROOT / (origin + '-end.json'))['state'] == 'completed', 'no failed-run automatic resume')
            packet_path = ROOT / receipt['packet']
            require(digest(packet_path) == receipt['packet_sha256'], 'resume packet hash')
            with np.load(packet_path, allow_pickle=False) as packet:
                initial = packet['states'][-1].copy()
            previous_hash = digest(receipt_path)
        operator = SharedOperator(args.case, args.count)
        try:
            require(np.array_equal(times, operator.port.times), 'same physical clock')
            boundaries = np.linspace(*times, args.steps + 1)
            state = initial / scale
            chunk_states = [initial.copy()]
            chunk_first = first
            weight_low = (3 - 2 * np.sqrt(3.)) / 12
            weight_high = (3 + 2 * np.sqrt(3.)) / 12
            node_low, node_high = .5 - np.sqrt(3.) / 6, .5 + np.sqrt(3.) / 6
            for index in range(first, last):
                guard()
                begin, end = boundaries[index:index + 2]
                interval = end - begin
                early = operator.system(begin + node_low * interval)['matrix'] * scale[None, :] / scale[:, None]
                late = operator.system(begin + node_high * interval)['matrix'] * scale[None, :] / scale[:, None]
                left = interval * (weight_high * early + weight_low * late)
                right = interval * (weight_low * early + weight_high * late)
                state = expm(right) @ (expm(left) @ state)
                require(np.all(np.isfinite(state)), 'finite evolved state')
                chunk_states.append(state * scale)
                if (index + 1) % 8 == 0:
                    packet_name = f'{tag}-chunk{index + 1:03d}.npz'
                    require(not (ROOT / packet_name).exists(), 'no packet overwrite')
                    np.savez_compressed(ROOT / packet_name, states=np.array(chunk_states),
                                        times=boundaries[chunk_first:index + 2], normalization=scale)
                    receipt_name = f'{tag}-chunk{index + 1:03d}.json'
                    write(receipt_name, dict(case=args.case, count=args.count, steps=args.steps,
                          first=chunk_first, last=index + 1, worker=name, previous_sha256=previous_hash,
                          packet=packet_name, packet_sha256=digest(ROOT / packet_name), frozen=frozen,
                          elapsed=time.monotonic() - START))
                    previous_hash = digest(ROOT / receipt_name)
                    chunk_first = index + 1
                    chunk_states = [state * scale]
                    print(json.dumps(dict(run=tag, completed=chunk_first, requested=last,
                                          elapsed=time.monotonic() - START)), flush=True)
                    if time.monotonic() - START > 720:
                        break
            require(chunk_first > first, 'saved forward progress')
            write(name + '-result.json', dict(completed_through=chunk_first, target=args.steps,
                  full_run=chunk_first == args.steps, terminal_chunk_sha256=previous_hash,
                  elapsed=time.monotonic() - START, frozen=frozen))
        finally:
            operator.close()


if __name__ == '__main__':
    main()
