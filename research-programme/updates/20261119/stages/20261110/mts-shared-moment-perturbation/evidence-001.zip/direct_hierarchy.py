from stage_support import *
import numpy as np


def build(context, nodes, weights, heavy, increments=None):
    count, lmax = len(nodes), 16
    first = 8 if heavy else 6
    width = first + count * (lmax + 1)
    identity = np.eye(width)
    eta_k, cold, baryon, baryon_velocity, slow_field, slow_velocity = identity[:6]
    matrix = np.zeros((width, width))
    rows = np.arange(first, width).reshape(count, lmax + 1)
    wave, hubble, scale, stamp = [context[name] for name in ("wave", "hubble", "scale", "stamp")]
    require(wave > 0 and hubble > 0 and scale > 0 and stamp > 0, "retained expanding flat regime")
    speed = nodes / np.sqrt(nodes**2 + (scale * context["neutrino_mass"])**2)
    density_weights = context["neutrino_amplitude"] * weights / (scale**2 * speed)
    current_weights = context["neutrino_amplitude"] * weights / scale**2
    stress_weights = context["neutrino_amplitude"] * weights * speed / scale**2
    nu_density, nu_current, nu_pi = np.zeros((3, width))
    nu_density[rows[:, 0]] = density_weights
    nu_current[rows[:, 1]] = current_weights
    nu_pi[rows[:, 2]] = stress_weights
    slow_density = context["slow_velocity"] * slow_velocity + context["slow_mass_squared"] * context["slow_field"] * slow_field
    slow_pressure = context["slow_velocity"] * slow_velocity - context["slow_mass_squared"] * context["slow_field"] * slow_field
    slow_current = wave * context["slow_velocity"] * slow_field
    matter_density = context["baryon"] * baryon + context["cdm"] * cold + nu_density
    matter_current = context["baryon"] * baryon_velocity + nu_current
    provisional_z = (matter_density / (2 * wave) + eta_k) / hubble
    provisional_z_prime = -hubble * provisional_z - matter_density / (2 * wave)
    delta_massless = -4 * provisional_z_prime / wave
    current_massless = -4 * provisional_z / 3
    delta_gamma = delta_massless - 4 * context["opacity"] * (baryon_velocity + provisional_z) / wave
    current_gamma = current_massless.copy()
    if increments is not None:
        require(increments.shape == (4, width), "radiation increment rows")
        delta_gamma = delta_gamma + increments[0]
        current_gamma = current_gamma + increments[1]
        delta_massless = delta_massless + increments[2]
        current_massless = current_massless + increments[3]
    density = matter_density + slow_density + context["gamma"] * delta_gamma + context["massless"] * delta_massless
    current = matter_current + slow_current + context["gamma"] * current_gamma + context["massless"] * current_massless
    heavy_density, heavy_pressure = np.zeros((2, width))
    if heavy:
        heavy_density = context["heavy_density"] * identity[6]
        ratio = (wave / context["heavy_mass"])**2
        sound = ratio / (np.sqrt(1 + ratio) + 1)**2
        heavy_pressure = context["heavy_density"] * sound * (identity[6] + 3 * hubble * identity[7] / wave)
        density += heavy_density
        current += context["heavy_density"] * identity[7]
    zrow = (density / (2 * wave) + eta_k) / hubble
    sigma = zrow + 3 * current / (2 * wave**2)
    potential = -(density + 3 * hubble * current / wave) / (2 * wave**2)
    lapse = potential - nu_pi / wave**2
    matrix[0] = current / 2
    matrix[1] = -wave * zrow
    matrix[2] = -wave * (zrow + baryon_velocity)
    matrix[3] = -hubble * baryon_velocity + wave * context["cs2b"] * baryon
    matrix[3] -= context["gamma"] / context["baryon"] * context["opacity"] * (4 * baryon_velocity / 3 - current_gamma)
    matrix[4] = slow_velocity
    matrix[5] = -2 * hubble * slow_velocity - (wave**2 + context["slow_mass_squared"]) * slow_field
    matrix[5] -= wave * context["slow_velocity"] * zrow
    if heavy:
        pressure = heavy_pressure / context["heavy_density"]
        matrix[6] = -3 * hubble * pressure - wave * identity[7] - wave * zrow
        matrix[7] = -hubble * identity[7] + wave * pressure
    for node in range(count):
        offsets = rows[node]
        matrix[offsets[0]] = -4 * wave * zrow / 3
        matrix[offsets[0], offsets[1]] -= wave * speed[node]
        matrix[offsets[1], offsets[0]] = wave * speed[node] / 3
        matrix[offsets[1], offsets[2]] = -2 * wave * speed[node] / 3
        matrix[offsets[2]] = 8 * wave * sigma / 15
        matrix[offsets[2], offsets[1]] += 2 * wave * speed[node] / 5
        matrix[offsets[2], offsets[3]] -= 3 * wave * speed[node] / 5
        for moment in range(3, lmax):
            matrix[offsets[moment], offsets[moment - 1]] = wave * speed[node] * moment / (2 * moment + 1)
            matrix[offsets[moment], offsets[moment + 1]] = -wave * speed[node] * (moment + 1) / (2 * moment + 1)
        matrix[offsets[lmax], offsets[lmax - 1]] = wave * speed[node]
        matrix[offsets[lmax], offsets[lmax]] = -(lmax + 1) / stamp
    return dict(matrix=matrix, density=density, current=current, anisotropy=nu_pi,
                eta=eta_k / wave, sigma=sigma, z=zrow, potential=potential, lapse=lapse,
                slow_density=slow_density, slow_pressure=slow_pressure,
                heavy_density=heavy_density, heavy_pressure=heavy_pressure,
                gamma_density=context["gamma"] * delta_gamma, gamma_current=context["gamma"] * current_gamma,
                massless_density=context["massless"] * delta_massless, massless_current=context["massless"] * current_massless,
                nu_density=nu_density, nu_current=nu_current, nu_pressure=nu_density * np.r_[np.zeros(first), np.repeat(speed**2, lmax + 1)] / 3,
                nu_enthalpy=4 * np.sum(density_weights) / 3, nodes=rows)


def radiation_gains(context, nodes, weights, heavy):
    base = build(context, nodes, weights, heavy)
    width = len(base["matrix"])
    wave, hubble = context["wave"], context["hubble"]
    density = np.array([context["gamma"], 0., context["massless"], 0.])
    current = np.array([0., context["gamma"], 0., context["massless"]])
    zrow = density / (2 * wave * hubble)
    sigma = zrow + 3 * current / (2 * wave**2)
    gains = np.zeros((width, 4))
    gains[0] = current / 2
    gains[1] = gains[2] = -wave * zrow
    gains[3, 1] = context["gamma"] / context["baryon"] * context["opacity"]
    gains[5] = -wave * context["slow_velocity"] * zrow
    if heavy:
        gains[6] = -wave * zrow
    gains[base["nodes"][:, 0]] = -4 * wave * zrow / 3
    gains[base["nodes"][:, 2]] = 8 * wave * sigma / 15
    return gains, dict(density=density, current=current, sigma=sigma)
