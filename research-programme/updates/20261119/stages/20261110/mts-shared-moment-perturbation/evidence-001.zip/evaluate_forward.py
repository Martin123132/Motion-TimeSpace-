from stage_support import *
import argparse
import numpy as np
from scipy.linalg import expm
from shared_operator import SharedOperator, defects
from run_forward import fingerprint


def history(case, count, steps):
    tag = f'{case}{count}-s{steps}'
    frozen = fingerprint(case, count)
    previous = frozen[case + str(count) + '-initial.npz']
    states, times, receipts = [], [], {}
    for last in range(8, steps + 1, 8):
        name = f'{tag}-chunk{last:03d}.json'
        receipt = read(ROOT / name)
        require(receipt['frozen'] == frozen, 'run fingerprints match')
        require(receipt['first'] == last - 8 and receipt['last'] == last, 'contiguous chunk')
        require(receipt['previous_sha256'] == previous, 'hash-linked restart chain')
        require(digest(ROOT / receipt['packet']) == receipt['packet_sha256'], 'saved states hash')
        origin = receipt['worker']
        require(exited(read(ROOT / (origin + '-start.json')))['exited'], 'forward worker exited')
        require(read(ROOT / (origin + '-end.json'))['state'] == 'completed', 'successful terminal receipt')
        with np.load(ROOT / receipt['packet'], allow_pickle=False) as packet:
            current = packet['states'].copy()
            clock = packet['times'].copy()
            scale = packet['normalization'].copy()
        if states:
            require(np.array_equal(states[-1][-1], current[0]), 'restart state continuity')
            require(times[-1][-1] == clock[0], 'restart clock continuity')
        states.append(current if last == 8 else current[1:])
        times.append(clock if last == 8 else clock[1:])
        previous = digest(ROOT / name)
        receipts[name] = previous
    with np.load(ROOT / (case + str(count) + '-initial.npz'), allow_pickle=False) as packet:
        require(np.array_equal(packet['initial'], states[0][0]), 'frozen starting state')
        require(np.array_equal(packet['normalization'], scale), 'frozen state scales')
    return np.concatenate(states), np.concatenate(times), scale, receipts


def advance(operator, state, start, end, scale):
    require(end >= start, 'forward alignment only')
    if end == start:
        return state.copy()
    interval = end - start
    lower, upper = (3 - 2 * np.sqrt(3.)) / 12, (3 + 2 * np.sqrt(3.)) / 12
    early = operator.system(start + (.5 - np.sqrt(3.) / 6) * interval)['matrix'] * scale[None, :] / scale[:, None]
    late = operator.system(start + (.5 + np.sqrt(3.) / 6) * interval)['matrix'] * scale[None, :] / scale[:, None]
    first = interval * (upper * early + lower * late)
    second = interval * (lower * early + upper * late)
    return (expm(second) @ (expm(first) @ (state / scale))) * scale


def jets_inside(operator, fraction, divisions):
    if fraction < 2 / divisions:
        offsets, weights = np.arange(5), np.array([-25, 48, -36, 16, -3]) / 12
    elif fraction > 1 - 2 / divisions:
        offsets, weights = -np.arange(5), -np.array([-25, 48, -36, 16, -3]) / 12
    else:
        offsets, weights = np.arange(-2, 3), np.array([1, -8, 0, 8, -1]) / 12
    center = operator.sample(fraction)
    samples = [operator.sample(fraction + offset / divisions, keep_matrix=False) for offset in offsets]
    result = {'matrix': (center['matrix'], None, None)}
    for name in samples[0]:
        base = np.asarray(center[name], dtype=np.longdouble)
        values = np.stack([sample[name] for sample in samples]).astype(np.longdouble)
        derivative = np.tensordot(weights.astype(np.longdouble), values - base, axes=(0, 0)) / (operator.span / divisions)
        result[name] = (base, derivative, None)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('count', type=int, choices=(32, 64))
    args = parser.parse_args()
    tag = args.case + str(args.count)
    with worker('evaluate-' + tag):
        require(preserved() == read(ROOT / 'frozen-inputs.json'), 'same inherited sources')
        operator = SharedOperator(args.case, args.count)
        try:
            positions = np.linspace(0., .001, 9)
            targets = operator.port.times[0] + operator.port.state_spline(positions)[:, 3]
            fractions = (targets - operator.port.times[0]) / operator.span
            fractions[0], fractions[-1] = 0., 1.
            aligned, receipt_hashes = {}, {}
            for steps in (64, 128):
                states, clock, scale, receipts = history(args.case, args.count, steps)
                receipt_hashes.update(receipts)
                values = []
                for target in targets:
                    guard()
                    index = min(int(np.searchsorted(clock, target, side='right')) - 1, len(clock) - 1)
                    require(index >= 0, 'target covered')
                    values.append(advance(operator, states[index], clock[index], target, scale))
                aligned[steps] = np.array(values)
            refinement = float(np.max(abs(aligned[128] - aligned[64]) / scale))
            raw_coarse, _, _, _ = history(args.case, args.count, 64)
            raw_fine, _, _, _ = history(args.case, args.count, 128)
            shared_boundary_refinement = float(np.max(abs(raw_fine[::2] - raw_coarse) / scale))
            diagnostics, readouts = [], []
            for index, fraction in enumerate(fractions):
                guard()
                sample = operator.sample(float(fraction))
                state = aligned[128][index]
                names = ['phi', 'psi', 'density', 'current', 'anisotropy']
                if args.case == 'heavy':
                    names += ['heavy_density', 'heavy_current', 'heavy_pressure']
                readouts.append({name: float(np.asarray(sample[name], dtype=np.longdouble) @ state.astype(np.longdouble)) for name in names})
                for divisions in (16, 32):
                    jets = jets_inside(operator, float(fraction), divisions)
                    diagnostics.append(dict(position=float(positions[index]), fraction=float(fraction), divisions=divisions,
                                            metrics=defects(operator, jets, state)))
            packet_name = tag + '-forward.npz'
            require(not (ROOT / packet_name).exists(), 'no diagnostic packet overwrite')
            np.savez_compressed(ROOT / packet_name, position=positions, times=targets, fractions=fractions,
                                coarse=aligned[64], fine=aligned[128], normalization=scale)
            result = dict(case=args.case, count=args.count, numerical_passed=refinement <= GATE and shared_boundary_refinement <= GATE,
                          aligned_step_difference=refinement, shared_boundary_step_difference=shared_boundary_refinement,
                          diagnostics=diagnostics, readouts=readouts,
                          metric_passed=all(row['metrics']['metric_error'] <= GATE for row in diagnostics),
                          identities_passed=all(row['metrics']['identity_error'] <= ALGEBRA for row in diagnostics),
                          source_receipts=receipt_hashes, code_sha256=digest(__file__), packet_sha256=digest(ROOT / packet_name),
                          grid=positions.tolist(), scope='controlled late IVP; sampled diagnostics, not a uniform enclosure')
            write(tag + '-forward-result.json', result)
            print(json.dumps(dict(case=args.case, count=args.count, numerical_passed=result['numerical_passed'],
                  refinement=refinement, boundary_refinement=shared_boundary_refinement,
                  metric_error=max(row['metrics']['metric_error'] for row in diagnostics),
                  identity_error=max(row['metrics']['identity_error'] for row in diagnostics))), flush=True)
        finally:
            operator.close()


if __name__ == '__main__':
    main()
