from stage_support import *
from direct_hierarchy import build, radiation_gains
import numpy as np


def row_errors(actual, expected):
    denominator = np.maximum(np.maximum(np.max(abs(actual), axis=-1), np.max(abs(expected), axis=-1)), 1e-100)
    return np.max(abs(actual - expected), axis=-1) / denominator


def main():
    with worker("parity"):
        require(read(ROOT / "native-control.json")["passed"], "native capture complete")
        require(preserved() == read(ROOT / "frozen-inputs.json"), "same source set")
        with np.load(SHELL / "shell-rules.npz", allow_pickle=False) as packet:
            nodes, weights = packet["native5_nodes"].astype(float), packet["native5_weights"].astype(float)
        reports = []
        for capture in read(ROOT / "native-control.json")["reports"]:
            case = capture["case"]
            with np.load(ROOT / (case + "-native-control.npz"), allow_pickle=False) as packet:
                require(digest(ROOT / (case + "-native-control.npz")) == capture["output_sha256"], "same captured controls")
                count = capture["source_dimension"]
                mapping = np.r_[np.arange(1, 9), np.arange(10, 95)] if case == "heavy" else np.arange(1, 92)
                require(np.array_equal(packet["mapping"], mapping), "explicit retained ordering")
                for index, context in enumerate(capture["contexts"]):
                    raw = build(context, nodes, weights, case == "heavy")
                    require(raw["matrix"].shape == (count, count), "derived state dimension")
                    scalar_density = raw["slow_density"] + raw["heavy_density"]
                    scalar_pressure = raw["slow_pressure"] + raw["heavy_pressure"]
                    wave, hubble = context["wave"], context["hubble"]
                    delta_massless = (4 * scalar_density + 6 * scalar_pressure) / wave**2
                    delta_gamma = delta_massless - 2 * context["opacity"] * scalar_density / (wave**2 * hubble)
                    delta_current = -2 * scalar_density / (3 * wave * hubble)
                    increments = np.array([delta_gamma, delta_current, delta_massless, delta_current])
                    corrected = build(context, nodes, weights, case == "heavy", increments)
                    gains, output_gains = radiation_gains(context, nodes, weights, case == "heavy")
                    gain_error = float(np.max(row_errors(corrected["matrix"], raw["matrix"] + gains @ increments)))
                    matrices, sources = {}, {}
                    for label, model in (("raw", raw), ("corrected", corrected)):
                        reference = packet[label + "_matrix" + str(index)]
                        errors = row_errors(model["matrix"], reference)
                        matrices[label] = dict(maximum_error=float(np.max(errors)),
                                               failing_rows=np.flatnonzero(errors > ALGEBRA).tolist())
                        for name in ("density", "current", "anisotropy", "eta", "sigma"):
                            key = ("" if label == "raw" else "corrected_") + name + str(index)
                            sources[label + "_" + name] = float(row_errors(model[name][None, :], packet[key][None, :])[0])
                    sources["corrected_potential"] = float(row_errors(corrected["potential"][None, :], packet["corrected_potential" + str(index)][None, :])[0])
                    passed = all(row["maximum_error"] <= ALGEBRA for row in matrices.values()) and max(sources.values()) <= ALGEBRA and gain_error <= ALGEBRA
                    reports.append(dict(case=case, fraction=index / 2, matrices=matrices, sources=sources,
                                        radiation_gain_error=gain_error, passed=bool(passed)))
        result = dict(passed=all(row["passed"] for row in reports), reports=reports,
                      code_sha256=digest(__file__), model_sha256=digest(ROOT / "direct_hierarchy.py"),
                      capture_sha256=digest(ROOT / "native-control.json"))
        write("parity-result.json", result)
        print(json.dumps(result, indent=2))
        require(result["passed"], "full derived late operator matches retained native rows")


if __name__ == "__main__":
    main()
