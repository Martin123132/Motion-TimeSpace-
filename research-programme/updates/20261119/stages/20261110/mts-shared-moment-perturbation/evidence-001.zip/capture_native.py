from stage_support import *
import numpy as np


def main():
    with worker("capture"):
        write("frozen-inputs.json", preserved())
        sys.path.insert(0, str(RAD))
        from radiation_model import RadiationOperators, corrected_system
        reports = []
        for case in ("cold", "heavy"):
            operator = RadiationOperators(case, canonical=False)
            try:
                port = operator.port
                signature = port.reference["signature"]
                require(np.array_equal(signature[[11, 13, 14, 16, 17, 18, 20, 30, 40, 70]], [0, 1, 1, 0, 0, 0, 1, 5, 16, 0]), "full five-node late regime")
                require(np.all(signature[23:26] == 0), "no hidden thermal perturbation coordinates")
                values, contexts = {}, []
                for index, fraction in enumerate((0., .5, 1.)):
                    stamp = float(port.times[0] + fraction * (port.times[-1] - port.times[0]))
                    background, observer = port.observer_matrix(stamp)
                    raw = port.matrix(stamp)
                    corrected = corrected_system(port, stamp, enabled=True)
                    thermo = port.native.get_background_time_evolution(np.array([stamp]), vars=["opacity", "cs2b"])
                    columns = port.columns
                    field_index = int(np.flatnonzero(port.reference["mapping"] == signature[2])[0])
                    velocity_index = field_index + 1
                    scale = float(background[columns["a_native"]])
                    slow_mass_squared = float((scale * port.native.Params.DarkEnergy.slow_mass_mpc)**2)
                    context = dict(wave=port.wave, stamp=stamp, scale=scale, hubble=float(background[columns["H_native"]]),
                                   total_density=float(background[columns["R"]]), total_pressure=float(background[columns["Pbar"]]),
                                   baryon=float(background[columns["R_baryon"]]), cdm=float(background[columns["R_cdm"]]),
                                   gamma=float(background[columns["R_gamma"]]), massless=float(background[columns["R_massless"]]),
                                   neutrino_mass=float(port.native.nu_masses[0]), neutrino_amplitude=float(port.native.grhormass[0]),
                                   slow_mass_squared=slow_mass_squared,
                                   slow_field=float(observer[columns["D_sync"], field_index] / slow_mass_squared),
                                   slow_velocity=float(observer[columns["D_sync"], velocity_index]),
                                   opacity=float(thermo["opacity"][0]), cs2b=float(thermo["cs2b"][0]),
                                   heavy_density=float(port.matching_density / scale) if case == "heavy" else 0.,
                                   heavy_mass=float(port.mass * scale))
                    contexts.append(context)
                    values["raw_matrix" + str(index)] = raw
                    values["corrected_matrix" + str(index)] = corrected["matrix"]
                    for name, column in (("density", "D_sync"), ("current", "Q_sync"), ("anisotropy", "Pi"), ("eta", "eta_sync"), ("sigma", "sigma")):
                        values[name + str(index)] = observer[columns[column]]
                        values["corrected_" + name + str(index)] = corrected["full_observer"][columns[column]]
                    values["corrected_potential" + str(index)] = corrected["potential"]
                values.update(initial=port.initial, normalization=port.scale, mapping=port.reference["mapping"], signature=signature, times=port.times)
                np.savez_compressed(ROOT / (case + "-native-control.npz"), **values)
                reports.append(dict(case=case, contexts=contexts, source_dimension=port.dimension,
                                    input_clock=port.times.tolist(), output_sha256=digest(ROOT / (case + "-native-control.npz"))))
            finally:
                operator.close()
        result = dict(passed=True, reports=reports, code_sha256=digest(__file__),
                      qualification="Fresh read-only operator capture on the retained original grid; not a new fit or a 64-node evolution.")
        write("native-control.json", result)
        print(json.dumps(dict(passed=True, cases=[dict(case=row["case"], dimension=row["source_dimension"]) for row in reports])))


if __name__ == "__main__":
    main()
