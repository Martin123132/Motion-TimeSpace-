from stage_support import *
from shared_operator import SharedOperator, retained_radiation
from check_parity import row_errors
import numpy as np


def main():
    with worker("shared"):
        require(read(ROOT / "parity-result.json")["passed"] and read(ROOT / "thermal-result.json")["passed"], "native and thermal gates")
        require(preserved() == read(ROOT / "frozen-inputs.json"), "same inputs")
        actual = retained_radiation.RadiationOperators("heavy", canonical=True, enabled=True)
        legacy = SharedOperator("heavy", count=5, legacy=True)
        parity = []
        try:
            for fraction in (0., .5, 1.):
                stamp = float(actual.port.times[0] + fraction * actual.span)
                original = actual.system(stamp)
                derived = legacy.system(stamp)
                matrices = row_errors(derived["matrix"], original["matrix"])
                sources = {name: float(row_errors(derived[name][None, :], original[name][None, :])[0])
                           for name in ("potential", "lapse", "alpha", "density", "current", "pressure")}
                parity.append(dict(fraction=fraction, matrix_error=float(np.max(matrices)), sources=sources,
                                   passed=bool(np.max(matrices) <= ALGEBRA and max(sources.values()) <= ALGEBRA)))
        finally:
            actual.close()
            legacy.close()
        write("canonical-parity.json", dict(passed=all(row["passed"] for row in parity), reports=parity,
                                           model_sha256=digest(ROOT / "shared_operator.py")))
        require(all(row["passed"] for row in parity), "canonical source and pressure-clock reuse parity")
        preparations = []
        for case in ("cold", "heavy"):
            for count in (32, 64):
                operator = SharedOperator(case, count)
                try:
                    coarse, coarse_report = operator.prepare(16)
                    fine, fine_report = operator.prepare(32)
                    require(coarse_report["passed"] and fine_report["passed"], "conditional preparation solve")
                    scale = np.maximum(abs(fine), 1e-6)
                    if case == "heavy":
                        coefficients = operator.block.coefficients(operator.port.context(operator.port.times[0])["scale"])
                        scale[-2:] = max(coefficients["mass"], 1.) * max(np.max(abs(fine[-4:-2])), 1e-6)
                    difference = float(np.max(abs(coarse - fine) / scale))
                    sample = operator.sample(0.)
                    dimension = len(fine)
                    nu_first = 6
                    require(np.array_equal(fine[nu_first:nu_first + count * 17:17], np.full(count, 4e-6)), "frozen grid-independent monopole seed")
                    require(np.count_nonzero(fine[nu_first:nu_first + count * 17].reshape(count, 17)[:, 1:]) == 0, "zero higher initial multipoles")
                    np.savez_compressed(ROOT / (case + str(count) + "-initial.npz"), initial=fine, coarse_initial=coarse,
                                        normalization=scale, times=operator.port.times)
                    preparations.append(dict(case=case, count=count, dimension=dimension, coarse=coarse_report,
                                             fine=fine_report, stencil_difference=difference,
                                             zero_rhs=float(np.max(abs(sample["matrix"] @ np.zeros(dimension)))),
                                             passed=bool(difference <= GATE),
                                             packet_sha256=digest(ROOT / (case + str(count) + "-initial.npz"))))
                    print(json.dumps(preparations[-1]), flush=True)
                finally:
                    operator.close()
        result = dict(passed=all(row["passed"] for row in preparations), canonical_parity=parity, preparations=preparations,
                      code_sha256=digest(__file__), direct_model_sha256=digest(ROOT / "direct_hierarchy.py"),
                      shared_model_sha256=digest(ROOT / "shared_operator.py"),
                      contract_sha256=digest(ROOT / "PREPARATION-CONTRACT.md"),
                      actual_primordial_replay=False, new_physical_parameters=0)
        write("shared-result.json", result)
        print(json.dumps(dict(passed=result["passed"], canonical_parity=parity)))
        require(result["passed"], "paired matched-grid preparations")


if __name__ == "__main__":
    main()
