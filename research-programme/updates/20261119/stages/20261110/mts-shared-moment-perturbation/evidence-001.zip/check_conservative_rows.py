from stage_support import *
from shared_operator import SharedOperator
import numpy as np


def main():
    with worker('conservative-rows'):
        reports = []
        for case in ('cold', 'heavy'):
            for count in (32, 64):
                operator = SharedOperator(case, count)
                try:
                    for fraction in (0., .5, 1.):
                        guard()
                        stamp = operator.port.times[0] + fraction * operator.span
                        context = operator.port.context(stamp)
                        system = operator.system(stamp)
                        matrix = system['matrix'].astype(np.longdouble)
                        nodes = operator.port.nodes.astype(np.longdouble)
                        weights = operator.port.weights.astype(np.longdouble)
                        scale, hubble, wave = [np.longdouble(context[key]) for key in ('scale', 'hubble', 'wave')]
                        speed = nodes / np.sqrt(nodes**2 + (scale * context['neutrino_mass'])**2)
                        density_weights = context['neutrino_amplitude'] * weights / (scale**2 * speed)
                        current_weights = context['neutrino_amplitude'] * weights / scale**2
                        stress_weights = context['neutrino_amplitude'] * weights * speed / scale**2
                        density, current, pressure, anisotropy, density_prime = np.zeros((5, len(matrix)), dtype=np.longdouble)
                        for node in range(count):
                            offset = 6 + node * 17
                            density[offset] = density_weights[node]
                            current[offset + 1] = current_weights[node]
                            pressure[offset] = stress_weights[node] / 3
                            anisotropy[offset + 2] = stress_weights[node]
                            density_prime[offset] = -hubble * (density_weights[node] + stress_weights[node])
                        position = float(operator.port.position_spline(stamp - operator.port.times[0]))
                        values = operator.port.owner.parts(position, *operator.port.state_spline(position)[:2])
                        terms = [density_prime, density @ matrix, hubble * (density + 3 * pressure), wave * current]
                        shared_enthalpy = 4 * np.sum(density_weights) / 3
                        background_enthalpy = np.longdouble(values['neutrino']) + np.longdouble(values['neutrino_pressure'])
                        enthalpy_error = float(abs(background_enthalpy - shared_enthalpy) / abs(shared_enthalpy))
                        terms.append(-background_enthalpy * matrix[1])
                        energy = np.sum(terms, axis=0)
                        current_terms = [-2 * hubble * current, current @ matrix, 2 * hubble * current,
                                         -wave * pressure, 2 * wave * anisotropy / 3]
                        momentum = np.sum(current_terms, axis=0)
                        energy_scale = np.sum(abs(np.array(terms)), axis=0)
                        current_scale = np.sum(abs(np.array(current_terms)), axis=0)
                        energy_error = float(np.max(abs(energy) / np.maximum(energy_scale, np.longdouble('1e-100'))))
                        current_error = float(np.max(abs(momentum) / np.maximum(current_scale, np.longdouble('1e-100'))))
                        report = dict(case=case, count=count, fraction=fraction, energy_error=energy_error,
                                      current_error=current_error, shared_enthalpy=float(shared_enthalpy),
                                      background_enthalpy=float(background_enthalpy), enthalpy_error=enthalpy_error,
                                      absolute_energy_row=float(np.max(abs(energy))),
                                      absolute_current_row=float(np.max(abs(momentum))),
                                      passed=energy_error <= ALGEBRA and current_error <= ALGEBRA and enthalpy_error <= ALGEBRA)
                        reports.append(report)
                finally:
                    operator.close()
        write('conservative-rows-result.json', dict(passed=all(row['passed'] for row in reports), reports=reports,
              code_sha256=digest(__file__), property='operator identities for arbitrary state at sampled background points'))
        print(json.dumps(dict(passed=all(row['passed'] for row in reports),
              maximum_energy_error=max(row['energy_error'] for row in reports),
              maximum_current_error=max(row['current_error'] for row in reports))), flush=True)


if __name__ == '__main__':
    main()
