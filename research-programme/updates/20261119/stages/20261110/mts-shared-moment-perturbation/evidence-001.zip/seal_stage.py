from stage_support import *


def main():
    with worker('seal'):
        validation = read(ROOT / 'validation.json')
        require(validation['passed'] and validation['code_sha256'] == digest(ROOT / 'validate_stage.py'), 'same validated stage')
        stability = read(ROOT / 'source-stability-result.json')
        require(stability['passed'] and stability['code_sha256'] == digest(ROOT / 'check_source_stability.py'), 'physical source refinement')
        for row in stability['reports']:
            require(row['packet_sha256'] == digest(ROOT / (row['case'] + str(row['count']) + '-forward.npz')), 'same physical source states')
        inputs = preserved()
        require(inputs == read(ROOT / 'frozen-inputs.json'), 'unchanged source set')
        for name in ('PROTOCOL.md', 'PREPARATION-CONTRACT.md', 'EVOLUTION-CONTRACT.md', 'DERIVATION.md', 'RESULTS.md', 'NEXT.md'):
            require((ROOT / name).is_file(), 'required document ' + name)
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
        for path in sorted(ROOT.glob('*-start.json')):
            if path.name != 'seal-start.json':
                require(exited(read(path))['exited'], 'worker exited ' + path.name)
        require(not list(ROOT.rglob('__pycache__')), 'no bytecode')
    artifacts = {path.name: dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file()}
    require(len(artifacts) == len(list(ROOT.iterdir())), 'no unexpected directories')
    write('closeout.json', dict(state='verified_progress_shared_moment_perturbation',
          utc=datetime.now(timezone.utc).isoformat(), goal_complete=False, input_hashes=inputs, artifacts=artifacts,
          validation_checks=len(validation['checks']), sampled_metric_passed=validation['sampled_metric_passed'],
          physical_source_step_refinement_passed=stability['passed'], physical_source_refinement_checks=sum(len(row['fields']) for row in stability['reports']),
          controlled_paired_perturbation_evolution=True, actual_primordial_replay=False,
          production_changed=False, new_fitted_parameters=0, next='NEXT.md'))
    print(json.dumps(dict(seal_sha256=digest(ROOT / 'closeout.json'), inputs=len(inputs), artifacts=len(artifacts),
                          validation_checks=len(validation['checks']))))


if __name__ == '__main__':
    main()
