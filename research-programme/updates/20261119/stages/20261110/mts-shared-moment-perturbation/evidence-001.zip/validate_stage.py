from stage_support import *
import numpy as np


def main():
    with worker('validation'):
        checks = []

        def check(name, value):
            checks.append(dict(name=name, passed=bool(value)))

        inputs = preserved()
        check('original-source hashes unchanged', inputs == read(ROOT / 'frozen-inputs.json'))
        for name in ('parity-result.json', 'thermal-result.json', 'shared-result.json',
                     'canonical-parity.json', 'conservative-rows-result.json'):
            check(name, read(ROOT / name)['passed'])
        shared = read(ROOT / 'shared-result.json')
        for name, key in (('check_shared.py', 'code_sha256'), ('direct_hierarchy.py', 'direct_model_sha256'),
                          ('shared_operator.py', 'shared_model_sha256'), ('PREPARATION-CONTRACT.md', 'contract_sha256')):
            check('shared fingerprint ' + name, shared[key] == digest(ROOT / name))
        check('conservative rows code', read(ROOT / 'conservative-rows-result.json')['code_sha256'] == digest(ROOT / 'check_conservative_rows.py'))
        comparison = []
        maxima = dict(step_refinement=0., metric_error=0., constraint_error=0., identity_error=0.,
                      heavy_energy_error=0., heavy_current_error=0., background_error=0.)
        for case in ('cold', 'heavy'):
            results = {}
            for count in (32, 64):
                tag = case + str(count)
                result = read(ROOT / (tag + '-forward-result.json'))
                results[count] = result
                check(tag + ' forward code', result['code_sha256'] == digest(ROOT / 'evaluate_forward.py'))
                check(tag + ' packet', result['packet_sha256'] == digest(ROOT / (tag + '-forward.npz')))
                check(tag + ' step refinement', result['numerical_passed'])
                check(tag + ' budget identity', result['identities_passed'])
                check(tag + ' finite diagnostics', all(np.isfinite(value) for row in result['diagnostics']
                                                      for value in row['metrics'].values()))
                for name, checksum in result['source_receipts'].items():
                    check(tag + ' source ' + name, digest(ROOT / name) == checksum)
                    receipt = read(ROOT / name)
                    check(tag + ' packet ' + name, digest(ROOT / receipt['packet']) == receipt['packet_sha256'])
                    check(tag + ' frozen model ' + name,
                          all(digest(ROOT / path) == value for path, value in receipt['frozen'].items()))
                maxima['step_refinement'] = max(maxima['step_refinement'], result['aligned_step_difference'], result['shared_boundary_step_difference'])
                for name in maxima:
                    if name != 'step_refinement':
                        maxima[name] = max(maxima[name], *(row['metrics'].get(name, 0.) for row in result['diagnostics']))
            check(case + ' common scale-factor probes', results[32]['grid'] == results[64]['grid'])
            fields = {}
            for name in results[64]['readouts'][0]:
                coarse = np.array([row[name] for row in results[32]['readouts']])
                fine = np.array([row[name] for row in results[64]['readouts']])
                absolute = float(np.max(abs(coarse - fine)))
                amplitude = float(max(np.max(abs(coarse)), np.max(abs(fine))))
                relative = absolute / amplitude if amplitude else (0. if absolute == 0 else float('inf'))
                fields[name] = dict(maximum_absolute_difference=absolute, maximum_amplitude=amplitude,
                                    relative_difference=relative, passed=relative <= GATE,
                                    units='dimensionless' if name in ('phi', 'psi') else 'Mpc^-2')
                check(case + ' momentum reference ' + name, relative <= GATE)
            comparison.append(dict(case=case, fields=fields))
        for path in sorted(ROOT.glob('*-start.json')):
            if path.name != 'validation-start.json':
                terminal = read(ROOT / path.name.replace('-start.json', '-end.json'))
                start = read(path)
                check('receipt identity ' + path.name, all(terminal[key] == start[key] for key in ('pid', 'created', 'command')))
                check('worker exited ' + path.name, exited(start)['exited'])
                check('worker completed ' + path.name, terminal['state'] == 'completed')
        compiled = []
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
            compiled.append(path.name)
        check('no bytecode', not list(ROOT.rglob('__pycache__')))
        result = dict(passed=all(row['passed'] for row in checks), checks=checks,
                      code_sha256=digest(__file__), input_count=len(inputs), comparisons=comparison,
                      maxima=maxima, sampled_metric_passed=maxima['metric_error'] <= GATE,
                      compiled=compiled, gates=dict(numerical=GATE, algebra=ALGEBRA),
                      actual_primordial_replay=False, new_observational_fit=False,
                      production_changed=False, new_fitted_parameters=0)
        write('validation.json', result)
        print(json.dumps(dict(passed=result['passed'], checks=len(checks), maxima=maxima,
                              comparisons=comparison)), flush=True)
        require(result['passed'], 'implementation/refinement validation')


if __name__ == '__main__':
    main()
