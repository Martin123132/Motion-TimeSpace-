from stage_support import *
from direct_hierarchy import build, radiation_gains
import types
import numpy as np
from scipy.interpolate import CubicSpline
from scipy.sparse import csr_matrix

sys.path.insert(0, str(SOURCE))
from background_bridge import ReferenceBackground, CENTER, Series
sys.path.insert(0, str(RAD))
import radiation_model as retained_radiation
from bridge_imports import CanonicalBlock, action_model, Operators, defects

NAMES = ["a_native", "H_native", "R", "Pbar", "R_baryon", "R_cdm", "R_gamma", "R_massless",
         "D_sync", "Q_sync", "Pi", "eta_sync", "sigma"]


def clone(function, **changes):
    namespace = dict(function.__globals__, **changes)
    return types.FunctionType(function.__code__, namespace, function.__name__,
                              function.__defaults__, function.__closure__)


class SharedPort:
    def __init__(self, label, count=64, legacy=False):
        self.label, self.count, self.legacy = label, count, legacy
        self.wave = 5.
        self.owner = ReferenceBackground(label, 64 if legacy else count)
        self.mass = self.owner.heavy_mass
        self.matching_density = float(self.owner.saved["matching_density"])
        capture = next(row for row in read(ROOT / "native-control.json")["reports"] if row["case"] == label)
        self.contexts = capture["contexts"]
        with np.load(ROOT / (label + "-native-control.npz"), allow_pickle=False) as packet:
            self.original_times = packet["times"].copy()
            self.reference = dict(signature=packet["signature"].copy())
            original_initial = packet["initial"].copy()
        with np.load(SHELL / "shell-rules.npz", allow_pickle=False) as packet:
            prefix = "native5" if legacy else "gauss" + str(count)
            self.nodes = packet[prefix + "_nodes"].astype(float)
            self.weights = packet[prefix + "_weights"].astype(float)
        self.first = 8 if label == "heavy" else 6
        self.dimension = self.first + len(self.nodes) * 17
        self.reference["mapping"] = np.r_[np.arange(1, 9), np.arange(10, self.dimension + 2)] if label == "heavy" else np.arange(1, self.dimension + 1)
        self.reference["signature"][30] = len(self.nodes)
        self.selected = np.array([6, 7]) if label == "heavy" else np.array([], dtype=int)
        self.remaining = np.array([index for index in range(self.dimension) if index not in self.selected])
        self.columns = {name: index for index, name in enumerate(NAMES)}
        self.cache = None
        if legacy:
            self.times = self.original_times.copy()
            self.context_spline = {name: CubicSpline((0., .5, 1.), [row[name] for row in self.contexts])
                                   for name in self.contexts[0]}
            self.initial = original_initial
        else:
            with np.load(SOURCE / (label + "-background.npz"), allow_pickle=False) as packet:
                states = packet["states" if count == 64 else "alternate_states"].copy()
                positions = packet["position"].copy()
            self.state_spline = CubicSpline(positions, states, axis=0)
            self.position_spline = CubicSpline(states[:, 3], positions)
            self.times = np.array([self.original_times[0], self.original_times[0] + states[-1, 3]])
            with np.load(ROOT / (label + "-thermal.npz"), allow_pickle=False) as packet:
                self.thermal_spline = CubicSpline(packet["positions"][::2], packet["values"][::2], axis=0)
            self.initial = np.zeros(self.dimension)
            self.initial[1:3] = 3e-6
            if label == "heavy":
                self.initial[6] = 3e-6
            self.initial[self.first::17] = 4e-6
        self.native = types.SimpleNamespace(get_background_time_evolution=self.thermal_values)

    def context(self, stamp):
        guard()
        require(self.times[0] - 1e-9 <= stamp <= self.times[-1] + 1e-9, "inside late reference interval")
        if self.legacy:
            fraction = (stamp - self.times[0]) / (self.times[-1] - self.times[0])
            return {name: float(function(fraction)) for name, function in self.context_spline.items()}
        position = float(self.position_spline(stamp - self.times[0]))
        field, velocity, hubble, clock = self.state_spline(position)
        parts = self.owner.parts(position, field, velocity)
        scale = parts["scale"]
        source = next(row for row in read(SOURCE / "normalization-result.json")["reports"] if row["case"] == self.label)
        opacity, cs2b = self.thermal_spline(position)
        return dict(wave=self.wave, stamp=float(stamp), scale=scale, hubble=float(hubble),
                    total_density=parts["density"], total_pressure=parts["pressure"],
                    baryon=source["grhob"] / scale, cdm=source["grhoc"] / scale,
                    gamma=source["grhog"] / scale**2, massless=source["grhornomass"] / scale**2,
                    neutrino_mass=self.owner.neutrino_mass, neutrino_amplitude=self.owner.neutrino_amplitude,
                    slow_mass_squared=parts["scalar_mass"]**2, slow_field=float(field), slow_velocity=float(velocity),
                    opacity=float(opacity), cs2b=float(cs2b), heavy_density=self.matching_density / scale,
                    heavy_mass=self.mass * scale)

    def thermal_values(self, stamps, vars):
        return {name: np.array([self.context(float(stamp))[name] for stamp in stamps]) for name in vars}

    def raw(self, stamp):
        if self.cache is None or self.cache[0] != stamp:
            context = self.context(stamp)
            model = build(context, self.nodes, self.weights, self.label == "heavy")
            self.cache = (stamp, context, model)
        return self.cache[1], self.cache[2]

    def matrix(self, stamp):
        matrix = self.raw(stamp)[1]["matrix"]
        return csr_matrix(matrix) if self.label == "heavy" else matrix

    def rhs(self, stamp, state):
        return self.raw(stamp)[1]["matrix"] @ state

    def observer_matrix(self, stamp):
        context, model = self.raw(stamp)
        background = np.zeros(len(NAMES))
        for name, field in (("a_native", "scale"), ("H_native", "hubble"), ("R", "total_density"),
                            ("Pbar", "total_pressure"), ("R_baryon", "baryon"), ("R_cdm", "cdm"),
                            ("R_gamma", "gamma"), ("R_massless", "massless")):
            background[self.columns[name]] = context[field]
        observer = np.zeros((len(NAMES), self.dimension))
        for name, field in (("D_sync", "density"), ("Q_sync", "current"), ("Pi", "anisotropy"),
                            ("eta_sync", "eta"), ("sigma", "sigma")):
            observer[self.columns[name]] = model[field]
        return background, observer

    def observe(self, stamp, state):
        background, observer = self.observer_matrix(stamp)
        return background + observer @ state

    def radiation_columns(self, stamp):
        context = self.raw(stamp)[0]
        gains, sources = radiation_gains(context, self.nodes, self.weights, self.label == "heavy")
        output_gains = np.zeros((len(NAMES), 4))
        for name, field in (("D_sync", "density"), ("Q_sync", "current"), ("sigma", "sigma")):
            output_gains[self.columns[name]] = sources[field]
        return gains, output_gains

    def background_series(self, case, position):
        state = self.state_spline(position)
        values = self.owner.series(position, state)
        return values["scale"] * self.mass, values["hubble"]

    def close(self):
        self.cache = None


class SharedCanonical(CanonicalBlock):
    def __init__(self, port, facade):
        self.port = port
        self.case = types.SimpleNamespace(wave=np.array([port.wave]), mass=port.mass)
        if port.legacy:
            original_index = int(np.flatnonzero(action_model.StableCase("heavy").wave == port.wave)[0])
            self.case = action_model.StableCase("heavy", indices=[original_index])
        self.coefficients = types.MethodType(clone(CanonicalBlock.coefficients, action_model=facade), self)
        self.initial_scale = port.context(port.times[0])["scale"]
        self.initial_rho = port.matching_density / self.initial_scale
        values = self.coefficients(self.initial_scale)
        self.initial_weight = values["denominator"] / (self.initial_scale**2 * values["carrier"])
        self.diagnostics = []
        pressure_clock = clone(retained_radiation.pressure_clock, action_model=facade)
        self.corrected = clone(retained_radiation.corrected_system, pressure_clock=pressure_clock)

    def system(self, stamp):
        base = CanonicalBlock.system(self, stamp)
        return self.corrected(self.port, stamp, block=self, base=base, enabled=True)


class SharedOperator:
    def __init__(self, label, count=64, legacy=False):
        self.port = SharedPort(label, count, legacy)
        self.facade = action_model if legacy else types.SimpleNamespace(
            Series=Series, background_series=self.port.background_series,
            RESIDUAL_FUNCTION=action_model.RESIDUAL_FUNCTION)
        self.block = SharedCanonical(self.port, self.facade) if label == "heavy" else None
        self.scalar_jets = types.MethodType(clone(Operators.scalar_jets, action_model=self.facade), self)
        self.span = float(self.port.times[-1] - self.port.times[0])

    def system(self, stamp):
        return self.block.system(stamp) if self.block is not None else retained_radiation.corrected_system(self.port, stamp, enabled=True)

    def sample(self, fraction, keep_matrix=True):
        stamp = float(self.port.times[0] + fraction * self.span)
        system = self.system(stamp)
        background, observer = system["background"], system["full_observer"]
        columns = self.port.columns
        hubble = system["hubble"]
        enthalpy = background[columns["R"]] + background[columns["Pbar"]]
        if self.block is not None:
            enthalpy += system["enthalpy"] - system["native_rho"]
        alpha = system["alpha"]
        result = dict(phi=system["potential"], psi=system["lapse"],
                      combined=3 * system["potential"] + system["lapse"],
                      density=observer[columns["D_sync"]] - 3 * hubble * enthalpy * alpha,
                      current=observer[columns["Q_sync"]] + self.port.wave * enthalpy * alpha,
                      anisotropy=observer[columns["Pi"]], hubble=np.array(hubble), enthalpy=np.array(enthalpy),
                      scale_factor=np.array(system["scale_factor"]))
        if keep_matrix:
            result["matrix"] = np.asarray(system["matrix"])
        if self.block is not None:
            result.update(heavy_density=system["rho"] * system["density"],
                          heavy_current=system["rho"] * system["current"],
                          heavy_pressure=system["rho"] * system["pressure"],
                          heavy_enthalpy=np.array(system["enthalpy"]))
        return result

    def jets(self, fraction, divisions=32):
        if fraction == 0:
            offsets, first = np.arange(5), np.array([-25, 48, -36, 16, -3]) / 12
        elif fraction == 1:
            offsets, first = -np.arange(5), -np.array([-25, 48, -36, 16, -3]) / 12
        else:
            offsets, first = np.arange(-2, 3), np.array([1, -8, 0, 8, -1]) / 12
        require(all(0 <= fraction + offset / divisions <= 1 for offset in offsets), "stencil inside interval")
        center = self.sample(fraction)
        samples = [self.sample(fraction + offset / divisions, keep_matrix=False) for offset in offsets]
        result = {"matrix": (center["matrix"], None, None)}
        for name in samples[0]:
            values = np.stack([sample[name] for sample in samples]).astype(np.longdouble)
            base = np.asarray(center[name], dtype=np.longdouble)
            derivative = np.tensordot(first.astype(np.longdouble), values - base, axes=(0, 0)) / (self.span / divisions)
            result[name] = (base, derivative, None)
        return result

    def prepare(self, divisions=32):
        if self.block is None:
            return self.port.initial.copy(), dict(passed=True, controlled_thermal_seed=True)
        jets = self.jets(0., divisions)
        scalar = self.scalar_jets()
        combined, partial = jets["combined"][:2]
        matrix = jets["matrix"][0]
        first = partial + combined @ matrix
        leading = (scalar["physical"] * first - 2 * scalar["mass2"] * jets["psi"][0]) / scalar["rate"]
        condition = (scalar["physical"] * combined - leading).astype(np.clongdouble)
        condition[-2] += 1
        condition[-1] += 1j
        bridge = self.block.system(self.port.times[0])
        observed = self.port.observe(self.port.times[0], self.port.initial)
        alpha = observed[self.port.columns["sigma"]] / self.port.wave
        hubble = observed[self.port.columns["H_native"]]
        target = np.array([self.port.initial[6] - 3 * hubble * alpha,
                           self.port.initial[7] + self.port.wave * alpha, 0., 0.], dtype=np.longdouble)
        constraints = np.array([bridge["density"], bridge["current"], condition.real, condition.imag], dtype=np.longdouble)
        initial = np.r_[self.port.initial[self.port.remaining], np.zeros(4)]
        row_scale = np.max(abs(constraints[:, -4:]), axis=1)
        linear = np.asarray(constraints[:, -4:] / row_scale[:, None], dtype=float)
        initial[-4:] = np.linalg.solve(linear, np.asarray((target - constraints @ initial) / row_scale, dtype=float))
        residual = constraints @ initial - target
        denominator = np.maximum(np.sum(abs(constraints * initial), axis=1), abs(target))
        error = float(np.max(abs(residual) / np.maximum(denominator, 1e-100)))
        return initial, dict(passed=error <= ALGEBRA, residual_error=error,
                             condition_number=float(np.linalg.cond(linear)), controlled_thermal_seed=True,
                             conditional_preparation="Retained live D0; full fast coordinates evolve afterwards.",
                             physical_targets=target.astype(float).tolist())

    def close(self):
        self.port.close()
