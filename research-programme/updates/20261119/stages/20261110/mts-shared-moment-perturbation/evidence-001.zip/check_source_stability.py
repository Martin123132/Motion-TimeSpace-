from stage_support import *
from shared_operator import SharedOperator
import numpy as np


def main():
    with worker('source-stability'):
        reports = []
        for case in ('cold', 'heavy'):
            for count in (32, 64):
                tag = case + str(count)
                with np.load(ROOT / (tag + '-forward.npz'), allow_pickle=False) as packet:
                    coarse, fine, fractions = [packet[name].copy() for name in ('coarse', 'fine', 'fractions')]
                operator = SharedOperator(case, count)
                try:
                    fields = ['phi', 'psi', 'density', 'current', 'anisotropy']
                    if case == 'heavy':
                        fields += ['heavy_density', 'heavy_current', 'heavy_pressure']
                    values = {name: [] for name in fields}
                    changes = {name: [] for name in fields}
                    for index, fraction in enumerate(fractions):
                        sample = operator.sample(float(fraction), keep_matrix=False)
                        first, second = coarse[index].astype(np.longdouble), fine[index].astype(np.longdouble)
                        for name in fields:
                            row = sample[name].astype(np.longdouble)
                            values[name].append([float(row @ first), float(row @ second)])
                            changes[name].append(float(row @ (second - first)))
                    checks = {}
                    for name in fields:
                        amplitude = float(np.max(abs(np.array(values[name]))))
                        absolute = float(np.max(abs(np.array(changes[name]))))
                        error = absolute / amplitude if amplitude else (0. if not absolute else float('inf'))
                        checks[name] = dict(absolute_difference=absolute, maximum_amplitude=amplitude,
                                            relative_difference=error, passed=error <= GATE)
                    reports.append(dict(case=case, count=count, fields=checks,
                                        passed=all(row['passed'] for row in checks.values()),
                                        packet_sha256=digest(ROOT / (tag + '-forward.npz'))))
                finally:
                    operator.close()
        result = dict(passed=all(row['passed'] for row in reports), reports=reports,
                      code_sha256=digest(__file__), gate=GATE,
                      comparison='64/128 time steps; physical readouts on the same common-scale-factor states')
        write('source-stability-result.json', result)
        print(json.dumps(result), flush=True)


if __name__ == '__main__':
    main()
