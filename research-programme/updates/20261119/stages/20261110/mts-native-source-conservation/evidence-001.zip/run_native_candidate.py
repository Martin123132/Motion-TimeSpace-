from source_support import *
import argparse
import ast
import ctypes
import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    parser.add_argument('representation', choices=('cubic', 'quintic'))
    args = parser.parse_args()
    label = 'native-' + args.case + '-' + args.representation
    with worker(label):
        build = read(ROOT / 'native-build-result.json')
        local = ROOT / 'native'
        require(build['state'] == 'completed' and build['temporary_mapping_removed'], 'completed isolated build')
        require(digest(local / 'camb/cambdll.dll') == build['dll_sha256'], 'candidate binary hash')
        for row in build['children']:
            require(exited(row['identity'])['exited'], 'compiler process exited')
        table_path = PREVIOUS / (args.case + '-candidate-background.npz')
        expected = read(PREVIOUS / 'background-check-result.json')['cases'][args.case]['candidate_sha256']
        require(digest(table_path) == expected, 'retained candidate source table')
        clock_path = ROOT / 'heavy-equation-quintic.npz'
        require(digest(clock_path) == read(ROOT / 'quintic-preparation-result.json')['packet_sha256'], 'equation-derived clock input')
        observer_owner = POST / 'mts-metric-feedback-20261107'
        observer_source = observer_owner / 'observe_native.py'
        names = ast.literal_eval(next(node.value for node in ast.parse(observer_source.read_text()).body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'NAMES' for target in node.targets)))
        observer_receipt = read(observer_owner / 'compiler-shortpath-receipt.json')
        require(digest(observer_owner / 'observer.dll') == observer_receipt['dll_sha256'], 'unchanged double observer')
        factory_source = NATIVE.parent / 'matching_common.py'
        schedule = POST / 'mts-early-canonical-state-bridge-20261110/k1-early-source.npz'
        hashes = dict(build['source_hashes'])
        for path in (Path(__file__), ROOT / 'QUINTIC-REPAIR-CONTRACT.md', table_path, clock_path, local / 'camb/cambdll.dll', factory_source, observer_source, observer_owner / 'observer.dll', observer_owner / 'observer.f90', schedule):
            hashes[str(path)] = digest(path)
        write(label + '-frozen.json', hashes)
        sys.path.insert(0, str(local))
        import camb
        from camb.mts import MTSTwoField
        require(Path(camb.__file__).resolve().parent == (local / 'camb').resolve(), 'isolated native import')
        sys.path.append(str(BRANCH / 'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        factory = next(node for node in ast.parse(factory_source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_source), 'exec'), namespace)
        params = namespace['params_for'](table_path)
        enabled = args.case == 'heavy' and args.representation == 'quintic'
        if enabled:
            with np.load(clock_path, allow_pickle=False) as packet:
                model = params.DarkEnergy
                model.set_table('SetHeavyClock', packet['efold'], packet['H'], packet['H_N'])
                params.DarkEnergy = model
        observer_dll = ctypes.CDLL(str(observer_owner / 'observer.dll'))
        callback = ctypes.cast(observer_dll.source_func_, ctypes.c_void_p)
        with np.load(schedule, allow_pickle=False) as saved:
            scales = saved['requested_scale'].copy()
        native = camb.get_background(params)
        try:
            clock = np.ascontiguousarray(native.conformal_time(1 / scales - 1, tol=1e-10))
            native.Params.Accuracy.IntTolBoost = 6
            native.Params.Accuracy.lAccuracyBoost = 4
            standard_names = list(camb.model.evolve_names)
            count = len(standard_names) + len(names)
            output = np.zeros((1, len(clock), count))
            wave = np.array([1.], dtype=np.float64)
            code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(1)), wave, ctypes.byref(ctypes.c_int(len(clock))), clock, ctypes.byref(ctypes.c_int(count)), output, ctypes.byref(ctypes.c_int(len(names))), ctypes.byref(callback))
            require(code == 0 and np.isfinite(output).all(), 'coupled candidate evolution')
            standard = output[0, :, :len(standard_names)]
            observer = output[0, :, len(standard_names):]
            require(np.all(standard[:, standard_names.index('mts_match_count')] == 0), 'no new matching event')
            require(np.all(standard[:, standard_names.index('mts_averaged_chart')] == 0), 'exact early branch')
            require(np.all(np.diff(observer[:, names.index('a_native')]) > 0), 'monotonic native clock')
            destination = ROOT / (label + '.npz')
            np.savez_compressed(destination, requested_scale=scales, clock=clock, names=np.array(standard_names), observer_names=np.array(names), standard=standard, observer=observer, wave=1.)
        finally:
            del native
        check_hashes(hashes)
        write(label + '-result.json', dict(completed=True, case=args.case, representation=args.representation, heavy_quintic_enabled=enabled, table=str(table_path), table_sha256=expected, clock_packet=str(clock_path), samples=len(clock), packet_sha256=digest(destination), native_error_code=int(code), full_native_species_evolved=True, full_state_restart_saved=False, new_fit=False, source_hashes=hashes))
        print(json.dumps(dict(case=args.case, representation=args.representation, completed=True, enabled=enabled, packet_sha256=digest(destination))), flush=True)


if __name__ == '__main__':
    main()
