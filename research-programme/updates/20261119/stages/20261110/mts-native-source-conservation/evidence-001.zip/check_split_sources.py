from source_model import *
from numpy.polynomial.legendre import leggauss
from scipy.optimize import brentq


def edges_for(model):
    context = model.context
    clock = model.clock
    left_scale, right_scale = context.scale(clock[[0, -1]])
    knot_arrays = [function.x for pair in context.field_functions.values() for function in pair]
    knot_arrays.extend([model.nu_density.x, model.nu_pressure.x])
    knots = np.unique(np.concatenate(knot_arrays))
    knots = knots[(knots > np.log(left_scale)) & (knots < np.log(right_scale))]
    native_scale = context.scale(clock)
    crossings = []
    errors = []
    for knot in knots:
        scale = np.exp(knot)
        upper = np.searchsorted(native_scale, scale)
        require(0 < upper < len(clock), 'interior source knot bracket')
        root = brentq(lambda value: float(context.scale(value) / scale - 1), clock[upper - 1], clock[upper], xtol=1e-13, rtol=4 * np.finfo(float).eps)
        crossings.append(root)
        errors.append(float(abs(context.scale(root) / scale - 1)))
    return np.unique(np.r_[clock, crossings]), dict(source_knots=len(knots), maximum_scale_error=max(errors, default=0.))


def integrate_split(model, edges, order):
    nodes, weights = leggauss(order)
    halfwidth = np.diff(edges) / 2
    query = (edges[:-1] + edges[1:])[:, None] / 2 + halfwidth[:, None] * nodes
    sampled = model.evaluate(query)
    output = np.searchsorted(edges, model.clock)
    require(np.array_equal(edges[output], model.clock), 'original evaluation times')

    def cumulative(values):
        return np.r_[0., np.cumsum((values @ weights) * halfwidth)][output]

    arrays = {}
    for name, defects in sampled['defects'].items():
        arrays['EH_' + name] = cumulative(defects['EH'])
        arrays['Ea_' + name] = cumulative(defects['Ea'])
    hubble = model.context.data['H'][model.target]
    alpha = model.context.data['alpha'][model.target]
    arrays['H_target_components'] = hubble - hubble[0] + cumulative((sampled['R'] + 3 * sampled['P']) / 6)
    arrays['H_target_native_spline'] = hubble - hubble[0] + cumulative((sampled['native_R'] + 3 * sampled['native_P']) / 6)
    arrays['alpha_target'] = alpha - alpha[0] - cumulative(sampled['Psi'] - sampled['H'] * sampled['alpha'])
    arrays['H_prediction'] = sum(values for name, values in arrays.items() if name.startswith('EH_'))
    arrays['alpha_prediction'] = sum(values for name, values in arrays.items() if name.startswith('Ea_'))
    physical_hubble = np.sqrt(sampled['R'] / 3)
    scale_defect = sampled['H'] / physical_hubble - 1
    arrays['scale_consistency_response'] = cumulative(scale_defect * (sum(value['EH'] for value in sampled['defects'].values()) - (sampled['R'] + 3 * sampled['P']) / 6))
    arrays['H_prediction_with_scale'] = arrays['H_prediction'] + arrays['scale_consistency_response']
    checks = {name: native_replay.retained.difference(arrays[prediction], arrays[target]) for name, prediction, target in [('H', 'H_prediction', 'H_target_components'), ('H_with_scale', 'H_prediction_with_scale', 'H_target_components'), ('alpha', 'alpha_prediction', 'alpha_target')]}
    return arrays, dict(comparisons=checks, absolute_peaks={name: float(np.max(abs(value))) for name, value in arrays.items()}, scale_hubble_relative_peak=float(np.max(abs(scale_defect))))


def main():
    with worker('split-source-check'):
        hashes = {str(path): digest(path) for path in (Path(__file__), ROOT / 'KNOT-SPLIT-TEST.md', ROOT / 'source_model.py', ROOT / 'attribution-result.json')}
        write('split-source-frozen.json', hashes)
        reports = {}
        for case in ('cold', 'heavy'):
            reports[case] = {}
            for representation in ('fine', 'coarse'):
                model = SourceModel(case, representation)
                edges, edge_report = edges_for(model)
                outputs, runs = {}, {}
                for order in (4, 8):
                    guard()
                    arrays, report = integrate_split(model, edges, order)
                    destination = ROOT / (case + '-split-' + representation + str(order) + '.npz')
                    np.savez_compressed(destination, clock=model.clock, edges=edges, **arrays)
                    runs[str(order)] = dict(**report, packet_sha256=digest(destination))
                    outputs[order] = arrays
                refinement = {name: native_replay.retained.difference(outputs[4][name], values) for name, values in outputs[8].items()}
                reports[case][representation] = dict(edges=edge_report, runs=runs, quadrature_refinement=refinement)
                print(json.dumps(dict(case=case, representation=representation, edges=edge_report, comparisons=runs['8']['comparisons'], peaks=runs['8']['absolute_peaks'], refinement={name: row['normalized'] for name, row in refinement.items() if name in ('H_prediction', 'alpha_prediction')}, scale_defect=runs['8']['scale_hubble_relative_peak'])), flush=True)
        check_hashes(hashes)
        write('split-source-result.json', dict(completed=True, cases=reports, source_hashes=hashes, original_results_preserved=True, diagnostic_only=True))


if __name__ == '__main__':
    main()
