from source_model import *
import ast
import check_native_candidate as first_check


def owned_context_class():
    source = ROOT / 'check_native_candidate.py'
    definition = next(node for node in ast.parse(source.read_text(encoding='utf-8')).body if isinstance(node, ast.FunctionDef) and node.name == 'candidate_context_class')
    replacements = []

    class Label(ast.NodeTransformer):
        def visit_Constant(self, node):
            if node.value == 'quintic':
                replacements.append(node.value)
                return ast.Constant('quintic-owned')
            return node

    definition = Label().visit(definition)
    require(replacements == ['quintic'], 'only successful packet label changed')
    namespace = dict(vars(first_check))
    exec(compile(ast.fix_missing_locations(ast.Module(body=[definition], type_ignores=[])), str(source), 'exec'), namespace)
    return namespace['candidate_context_class']()


OwnedReplay = owned_context_class()


def main():
    with worker('owned-candidate-check'):
        reports, legacy = {}, {}
        for case in ('cold', 'heavy'):
            with np.load(PREVIOUS / ('native-' + case + '-candidate.npz'), allow_pickle=False) as old, np.load(ROOT / ('native-' + case + '-cubic.npz'), allow_pickle=False) as rebuilt:
                legacy[case] = {name: bool(np.array_equal(rebuilt[name], old[name])) for name in old.files}
                require(all(legacy[case].values()), 'byte-equivalent disabled legacy arrays')
            variants = ('cubic', 'quintic') if case == 'cold' else ('cubic', 'quintic-owned')
            for representation in variants:
                label = case + '-' + representation
                outputs, runs = {}, {}
                for variant in ('fine2', 'fine4', 'coarse4'):
                    context = OwnedReplay(case, representation, 'coarse' if variant == 'coarse4' else 'fine')
                    destination = ROOT / ('replay-' + label + '-' + variant + '.npz')
                    reused = destination.exists()
                    if reused:
                        require(representation != 'quintic-owned', 'new candidate not silently rerun')
                        with np.load(destination, allow_pickle=False) as saved:
                            state = saved['state'].copy()
                    else:
                        state = native_replay.retained.advance(context, int(variant[-1]))
                    observed = context.observe(state)
                    checks = {name: native_replay.retained.difference(value, context.data[name][context.target]) for name, value in observed.items()}
                    if reused:
                        with np.load(destination, allow_pickle=False) as saved:
                            require(all(np.array_equal(observed[name], saved[name]) for name in observed), 'saved control readouts reproduced')
                    else:
                        np.savez_compressed(destination, clock=context.clock, state=state, **observed)
                    outputs[variant] = observed
                    runs[variant] = dict(passed=all(row['passed'] for row in checks.values()), reused_saved_control=reused, checks=checks, source_recovery=context.provenance['source_recovery'], packet_sha256=digest(destination))
                refinement = {name: native_replay.retained.difference(outputs['fine2'][name], value) for name, value in outputs['fine4'].items()}
                history = {name: native_replay.retained.difference(outputs['coarse4'][name], value) for name, value in outputs['fine4'].items()}
                source_recovered = all(row['normalized'] < ALGEBRA for run in runs.values() for row in run['source_recovery'].values())
                passed = all(run['passed'] for run in runs.values()) and all(row['passed'] for row in list(refinement.values()) + list(history.values())) and source_recovered
                reports[label] = dict(passed=passed, runs=runs, refinement=refinement, history_sensitivity=history, source_recovery_algebra_passed=source_recovered)
                print(json.dumps(dict(case=case, representation=representation, passed=passed, worst=max(row['normalized'] for row in runs['fine4']['checks'].values()), slow_u=runs['fine4']['checks']['s_u']['normalized'], failed=[name for name, row in runs['fine4']['checks'].items() if not row['passed']], source_recovery_algebra_passed=source_recovered)), flush=True)
        files = [Path(__file__), ROOT / 'check_native_candidate.py', ROOT / 'quintic_model.py', ROOT / 'heavy-equation-quintic.npz', PREVIOUS / 'check_native_replay.py', ROOT / 'QUINTIC-REPAIR-CONTRACT.md', ROOT / 'NATIVE-OWNERSHIP-REPAIR.md']
        write('owned-candidate-result.json', dict(completed=True, paired_candidate_passed=reports['cold-quintic']['passed'] and reports['heavy-quintic-owned']['passed'], old_mts_failure_preserved=not reports['heavy-cubic']['passed'], cases=reports, disabled_legacy_arrays_identical=legacy, source_hashes={str(path): digest(path) for path in files}, numerical_gate=GATE, algebra_gate=ALGEBRA, full_state_restart_saved=False, independent_full_hierarchy_reintegration=False, diagnostic_defect_forces_added=False))


if __name__ == '__main__':
    main()
