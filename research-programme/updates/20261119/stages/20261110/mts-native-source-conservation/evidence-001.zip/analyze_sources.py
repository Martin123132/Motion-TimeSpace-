from source_model import *
import sympy as sym
from numpy.polynomial.legendre import leggauss


def prove():
    hubble, pressure, delta_pressure, shear, wave, eta, dilation, density_delta, current = sym.symbols('H P dP Pi k eta z D Q', nonzero=True)
    defect_h, defect_d, defect_q = sym.symbols('EH ED EQ')
    density = 3 * hubble**2
    hubble_rate = -(density + 3 * pressure) / 6 + defect_h
    density_delta_rate = -hubble * (density_delta + 3 * delta_pressure) - wave * current - wave * dilation * (density + pressure) + defect_d
    current_rate = -2 * hubble * current + wave * delta_pressure - 2 * wave * shear / 3 + defect_q
    eta_rate = current / (2 * wave)
    dilation_rate = (density_delta_rate / (2 * wave) + wave * eta_rate) / hubble - dilation * hubble_rate / hubble
    alpha = dilation / wave + 3 * current / (2 * wave**3)
    lapse = -(density_delta + 3 * hubble * current / wave) / (2 * wave**2) - shear / wave**2
    predicted = defect_d / (2 * wave**2 * hubble) + 3 * defect_q / (2 * wave**3) - dilation * defect_h / (wave * hubble)
    proof = dict(shear_constraint=dilation_rate / wave + 3 * current_rate / (2 * wave**3) + hubble * alpha - lapse - predicted)
    field, velocity, mass2, sync_u, sync_w, defect_b, defect_f = sym.symbols('b v mu2 u w Eb Ef')
    field_rate = velocity + defect_f
    velocity_rate = -2 * hubble * velocity - mass2 * field + defect_b
    sync_w_rate = -2 * hubble * sync_w - (wave**2 + mass2) * sync_u - wave * dilation * velocity
    rho = (velocity**2 + mass2 * field**2) / 2
    pres = (velocity**2 - mass2 * field**2) / 2
    drho = velocity * sync_w + mass2 * field * sync_u
    dpres = velocity * sync_w - mass2 * field * sync_u
    momentum = wave * velocity * sync_u
    rho_rate = velocity * velocity_rate + mass2 * field * field_rate + hubble * mass2 * field**2
    drho_rate = velocity_rate * sync_w + velocity * sync_w_rate + 2 * hubble * mass2 * field * sync_u + mass2 * field_rate * sync_u + mass2 * field * sync_w
    momentum_rate = wave * (velocity_rate * sync_u + velocity * sync_w)
    proof.update(scalar_background=rho_rate + hubble * (rho + 3 * pres) - velocity * defect_b - mass2 * field * defect_f, scalar_density=drho_rate + hubble * (drho + 3 * dpres) + wave * momentum + wave * dilation * (rho + pres) - sync_w * defect_b - mass2 * sync_u * defect_f, scalar_current=momentum_rate + 2 * hubble * momentum - wave * dpres - wave * sync_u * defect_b)
    result = {name: str(sym.simplify(value)) for name, value in proof.items()}
    require(all(value == '0' for value in result.values()), 'source defect derivation')
    return result


def integrate(model, order):
    clock = model.clock
    nodes, weights = leggauss(order)
    halfwidth = np.diff(clock) / 2
    query = (clock[:-1] + clock[1:])[:, None] / 2 + halfwidth[:, None] * nodes
    sampled = model.evaluate(query)
    at_nodes = model.evaluate(clock)

    def cumulative(values):
        return np.r_[0., np.cumsum((values @ weights) * halfwidth)]

    arrays = {}
    for name, defects in sampled['defects'].items():
        arrays['EH_' + name] = cumulative(defects['EH'])
        arrays['Ea_' + name] = cumulative(defects['Ea'])
    hubble = model.context.data['H'][model.target]
    alpha = model.context.data['alpha'][model.target]
    arrays['H_target_components'] = hubble - hubble[0] + cumulative((sampled['R'] + 3 * sampled['P']) / 6)
    arrays['H_target_native_spline'] = hubble - hubble[0] + cumulative((sampled['native_R'] + 3 * sampled['native_P']) / 6)
    arrays['alpha_target'] = alpha - alpha[0] - cumulative(sampled['Psi'] - sampled['H'] * sampled['alpha'])
    arrays['H_prediction'] = sum(values for name, values in arrays.items() if name.startswith('EH_'))
    arrays['alpha_prediction'] = sum(values for name, values in arrays.items() if name.startswith('Ea_'))
    comparisons = {name: native_replay.retained.difference(arrays[name + '_prediction'], arrays[target]) for name, target in [('H', 'H_target_components'), ('alpha', 'alpha_target')]}
    peaks = {name: float(np.max(abs(values))) for name, values in arrays.items()}
    scales = dict(H=float(np.max(abs(hubble))), alpha=float(np.max(abs(alpha))))
    floor = {name: 64 * np.finfo(float).eps * value for name, value in scales.items()}
    return arrays, dict(comparisons=comparisons, absolute_peaks=peaks, estimated_roundoff=floor, component_recovery=model.recovery, constants=model.constant_checks, native_scalar_nodes=max(model.recovery['scalar_density'], model.recovery['friedmann']))


def main():
    with worker('source-attribution'):
        inputs = previous_inputs()
        for path in [Path(__file__), ROOT / 'source_model.py', ROOT / 'source_support.py', ROOT / 'PROTOCOL.md', ROOT / 'DERIVATION.md', NATIVE / 'fortran/MTSTwoField.f90', NATIVE / 'fortran/equations.f90']:
            inputs[str(path)] = digest(path)
        write('frozen-inputs.json', inputs)
        proof = prove()
        reports = {}
        for case in ('cold', 'heavy'):
            runs = {}
            for representation in ('fine', 'coarse'):
                model = SourceModel(case, representation)
                for order in (4, 8):
                    guard()
                    arrays, report = integrate(model, order)
                    label = case + '-' + representation + str(order)
                    destination = ROOT / (label + '.npz')
                    np.savez_compressed(destination, clock=model.clock, **arrays)
                    runs[representation + str(order)] = dict(**report, packet_sha256=digest(destination))
                    if representation == 'fine' and order == 8:
                        print(json.dumps(dict(case=case, comparisons=report['comparisons'], peaks=report['absolute_peaks'], estimated_roundoff=report['estimated_roundoff'])), flush=True)
            reports[case] = runs
        check_hashes(inputs)
        write('attribution-result.json', dict(completed=True, proof=proof, cases=reports, source_hashes={str(path): digest(path) for path in (Path(__file__), ROOT / 'source_model.py', ROOT / 'DERIVATION.md')}, no_fit=True, no_action_modification=True, massive_neutrino_perturbation_remainder_not_assumed_zero=True))


if __name__ == '__main__':
    main()
