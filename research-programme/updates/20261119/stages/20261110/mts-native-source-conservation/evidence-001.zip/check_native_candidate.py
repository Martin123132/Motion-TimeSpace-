from source_model import *
from quintic_model import functions
import ast


def candidate_context_class():
    source = PREVIOUS / 'check_native_replay.py'
    seal = read(PREVIOUS / 'closeout.json')
    require(digest(source) == seal['artifacts']['check_native_replay.py']['sha256'], 'unchanged retained canonical checker')
    definition = next(node for node in ast.parse(source.read_text(encoding='utf-8')).body if isinstance(node, ast.ClassDef) and node.name == 'NativeReplay')
    modifications = []

    class FieldRepresentation(ast.NodeTransformer):
        def visit_Assign(self, node):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in ('field_function', 'velocity_function'):
                    component = 0 if target.id == 'field_function' else 1
                    node.value = ast.Call(func=ast.Name(id='candidate_interpolator', ctx=ast.Load()), args=[ast.Name(id='suffix', ctx=ast.Load()), ast.Name(id='variant', ctx=ast.Load()), ast.Constant(component), node.value], keywords=[])
                    modifications.append(target.id)
            return node

    definition = FieldRepresentation().visit(definition)
    require(modifications == ['field_function', 'velocity_function'], 'only source interpolation changed in checker')
    with np.load(ROOT / 'heavy-equation-quintic.npz', allow_pickle=False) as packet:
        quintic, derivatives = functions(packet)

    def select(suffix, variant, component, fallback):
        return quintic[component] if suffix == 'h' and variant == 'quintic' else fallback

    namespace = dict(vars(native_replay))
    namespace.update(ROOT=ROOT, candidate_interpolator=select)
    tree = ast.fix_missing_locations(ast.Module(body=[definition], type_ignores=[]))
    exec(compile(tree, str(source), 'exec'), namespace)
    return namespace['NativeReplay']


CandidateReplay = candidate_context_class()


def main():
    with worker('native-candidate-check'):
        reports, legacy = {}, {}
        for case in ('cold', 'heavy'):
            with np.load(PREVIOUS / ('native-' + case + '-candidate.npz'), allow_pickle=False) as old, np.load(ROOT / ('native-' + case + '-cubic.npz'), allow_pickle=False) as rebuilt:
                legacy[case] = {name: native_replay.retained.difference(rebuilt[name], old[name]) for name in ('standard', 'observer', 'clock')}
                require(all(row['normalized'] < ALGEBRA for row in legacy[case].values()), 'legacy-disabled behaviour unchanged')
            for representation in ('cubic', 'quintic'):
                label = case + '-' + representation
                outputs, runs = {}, {}
                for variant in ('fine2', 'fine4', 'coarse4'):
                    context = CandidateReplay(case, representation, 'coarse' if variant == 'coarse4' else 'fine')
                    state = native_replay.retained.advance(context, int(variant[-1]))
                    observed = context.observe(state)
                    checks = {name: native_replay.retained.difference(value, context.data[name][context.target]) for name, value in observed.items()}
                    destination = ROOT / ('replay-' + label + '-' + variant + '.npz')
                    np.savez_compressed(destination, clock=context.clock, state=state, **observed)
                    outputs[variant] = observed
                    runs[variant] = dict(passed=all(row['passed'] for row in checks.values()), checks=checks, source_recovery=context.provenance['source_recovery'], packet_sha256=digest(destination))
                refinement = {name: native_replay.retained.difference(outputs['fine2'][name], value) for name, value in outputs['fine4'].items()}
                history = {name: native_replay.retained.difference(outputs['coarse4'][name], value) for name, value in outputs['fine4'].items()}
                source_recovered = all(row['normalized'] < ALGEBRA for run in runs.values() for row in run['source_recovery'].values())
                passed = all(run['passed'] for run in runs.values()) and all(row['passed'] for row in list(refinement.values()) + list(history.values())) and source_recovered
                reports[label] = dict(passed=passed, runs=runs, refinement=refinement, history_sensitivity=history, source_recovery_algebra_passed=source_recovered)
                print(json.dumps(dict(case=case, representation=representation, passed=passed, worst=max(row['normalized'] for row in runs['fine4']['checks'].values()), slow_u=runs['fine4']['checks']['s_u']['normalized'], failed=[name for name, row in runs['fine4']['checks'].items() if not row['passed']], source_recovery_algebra_passed=source_recovered)), flush=True)
        files = [Path(__file__), ROOT / 'quintic_model.py', ROOT / 'heavy-equation-quintic.npz', PREVIOUS / 'check_native_replay.py', ROOT / 'QUINTIC-REPAIR-CONTRACT.md']
        write('native-candidate-result.json', dict(completed=True, paired_candidate_passed=all(reports[case + '-quintic']['passed'] for case in ('cold', 'heavy')), old_mts_failure_preserved=not reports['heavy-cubic']['passed'], cases=reports, legacy_library_comparison=legacy, source_hashes={str(path): digest(path) for path in files}, numerical_gate=GATE, algebra_gate=ALGEBRA, full_state_restart_saved=False, independent_full_hierarchy_reintegration=False, diagnostic_defect_forces_added=False))


if __name__ == '__main__':
    main()
