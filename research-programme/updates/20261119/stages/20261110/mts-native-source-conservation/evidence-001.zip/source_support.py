import os
import sys
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[name] = '1'
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-regular-slow-background-20261110'
BRANCH = POST / 'condensate-origin-20261003'
NATIVE = BRANCH / 'native-heavy-matching-20261007/native'
EXPECTED = '63979a6df20d6d15ed21d8aa1feff207b597c61a73541fc9390d3c239b76603b'
GATE, ALGEBRA = 2e-5, 1e-10
START = time.monotonic()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(name, value):
    with (ROOT / name).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False))


def guard():
    require(time.monotonic() - START < 900, 'worker deadline')
    for directory in (ROOT, POST, PREVIOUS, BRANCH):
        require(not (directory / 'STOP-REQUESTED').exists(), 'owner hold ' + str(directory))


def exited(identity):
    try:
        process = psutil.Process(identity['pid'])
        same = abs(process.create_time() - identity['created']) < .01 and process.cmdline() == identity['command']
    except psutil.NoSuchProcess:
        return dict(exited=True, reason='PID absent')
    return dict(exited=not same, reason='original identity live' if same else 'PID reused; untouched')


@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())
    write(name + '-start.json', identity)
    try:
        guard()
        yield identity
    except BaseException as error:
        write(name + '-end.json', dict(**identity, state='failed', error=repr(error)))
        raise
    else:
        write(name + '-end.json', dict(**identity, state='completed', elapsed=time.monotonic() - START))


def check_hashes(mapping):
    for path, expected in mapping.items():
        guard()
        require(Path(path).is_file() and digest(path) == expected, 'source unchanged ' + path)


def previous_inputs():
    require(digest(PREVIOUS / 'closeout.json') == EXPECTED, 'previous seal')
    seal = read(PREVIOUS / 'closeout.json')
    require(seal['implementation_validated'] and seal['regular_background_passed'] and not seal['candidate_canonical_replay_passed'], 'previous statuses')
    mapping = dict(seal['input_hashes'])
    mapping.update({str(PREVIOUS / name): entry['sha256'] for name, entry in seal['artifacts'].items()})
    mapping[str(PREVIOUS / 'closeout.json')] = EXPECTED
    for name in ('seal-end.json', 'postseal-start.json', 'postseal-end.json', 'CLEANUP-VERIFIED.json'):
        mapping[str(PREVIOUS / name)] = digest(PREVIOUS / name)
    check_hashes(mapping)
    cleanup = read(PREVIOUS / 'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['seal_sha256'] == EXPECTED, 'previous cleanup')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'], 'previous worker exited')
    require(exited(cleanup['verifier_identity'])['exited'], 'previous verifier exited')
    return mapping
