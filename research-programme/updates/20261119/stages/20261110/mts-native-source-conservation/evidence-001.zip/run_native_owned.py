from source_support import *
import ast


def main():
    require(sys.argv[1:] == ['heavy', 'quintic'], 'only previously failed enabled candidate')
    source = ROOT / 'run_native_candidate.py'
    frozen = read(ROOT / 'native-heavy-quintic-frozen.json')
    require(digest(source) == frozen[str(source)], 'failed adapter source preserved')
    tree = ast.parse(source.read_text(encoding='utf-8'))
    counts = dict(copy=0, label=0, provenance=0)

    class OwnModel(ast.NodeTransformer):
        def visit_Assign(self, node):
            if any(isinstance(target, ast.Name) and target.id == 'model' for target in node.targets):
                require(ast.unparse(node.value) == 'params.DarkEnergy', 'identified allocatable alias')
                node.value = ast.Call(func=ast.Attribute(value=node.value, attr='copy', ctx=ast.Load()), args=[], keywords=[])
                counts['copy'] += 1
            if any(isinstance(target, ast.Name) and target.id == 'label' for target in node.targets):
                node.value = ast.BinOp(left=node.value, op=ast.Add(), right=ast.Constant('-owned'))
                counts['label'] += 1
            return self.generic_visit(node)

        def visit_For(self, node):
            if isinstance(node.target, ast.Name) and node.target.id == 'path' and isinstance(node.iter, ast.Tuple):
                node.iter.elts.extend(ast.parse('ROOT / "run_native_candidate.py", ROOT / "NATIVE-OWNERSHIP-REPAIR.md"', mode='eval').body.elts)
                counts['provenance'] += 1
            return self.generic_visit(node)

    tree = OwnModel().visit(tree)
    require(counts == dict(copy=1, label=1, provenance=1), 'only owned-object adapter changes')
    namespace = dict(__file__=__file__, __name__='owned_native_adapter')
    exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'), namespace)
    namespace['main']()


if __name__ == '__main__':
    main()
