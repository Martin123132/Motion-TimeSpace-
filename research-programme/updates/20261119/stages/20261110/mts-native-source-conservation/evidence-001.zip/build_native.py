from source_support import *
import ctypes
import importlib.util
import subprocess


def drive_target(drive):
    buffer = ctypes.create_unicode_buffer(32768)
    size = ctypes.windll.kernel32.QueryDosDeviceW(drive, buffer, len(buffer))
    return buffer.value if size else None


def main():
    with worker('build-native'):
        bootstrap = read(ROOT / 'native-bootstrap-result.json')
        local = ROOT / 'native'
        changed = []
        for relative, checksum in bootstrap['copied_source_hashes'].items():
            require(digest(NATIVE / relative) == checksum, 'original native source intact')
            if digest(local / relative) != checksum:
                changed.append(relative.replace('\\', '/'))
        require(set(changed) == {'fortran/MTSTwoField.f90', 'camb/mts.py'}, 'only declared native changes')
        candidate_sources = {str(local / relative): digest(local / relative) for relative in bootstrap['copied_source_hashes']}
        write('native-build-frozen.json', candidate_sources)
        command_rows, identities = [], {}
        mapped = False
        selected_drive = next((letter + ':' for letter in ('Z', 'Y', 'X', 'W', 'V') if drive_target(letter + ':') is None and not Path(letter + ':/').exists()), None)
        require(selected_drive is not None, 'unused temporary short-path drive')
        expected_target = '\\??\\' + str(POST)
        result = dict(state='started', commands=command_rows, children=[])

        def capture(process):
            identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline())
            identities[(identity['pid'], identity['created'])] = identity
            return identity

        def run(command, log, cwd=None, environment=None, cleanup=False):
            if not cleanup:
                guard()
            process = subprocess.Popen(command, cwd=cwd, env=environment, stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
            row = dict(command=command, pid=process.pid)
            try:
                row['identity'] = capture(psutil.Process(process.pid))
            except psutil.NoSuchProcess:
                row['exited_before_identity_read'] = True
            command_rows.append(row)
            try:
                while process.poll() is None:
                    if not cleanup:
                        guard()
                    try:
                        parent = psutil.Process(process.pid)
                        if 'identity' in row and abs(parent.create_time() - row['identity']['created']) < .01:
                            for child in parent.children(recursive=True):
                                try:
                                    capture(child)
                                except psutil.NoSuchProcess:
                                    pass
                    except psutil.NoSuchProcess:
                        pass
                    time.sleep(.1)
                row['exit_code'] = process.wait()
                require(row['exit_code'] == 0, 'compiler/subst command failed; inspect log')
            except BaseException:
                for identity in reversed(list(identities.values())):
                    if not exited(identity)['exited']:
                        try:
                            psutil.Process(identity['pid']).terminate()
                        except psutil.NoSuchProcess:
                            pass
                process.wait(timeout=15)
                raise

        try:
            with (ROOT / 'native-build.log').open('x', encoding='utf-8') as log:
                run(['subst', selected_drive, str(POST)], log)
                require(drive_target(selected_drive).casefold() == expected_target.casefold(), 'owned drive mapping')
                mapped = True
                alias = Path(selected_drive + '/')
                native = alias / ROOT.name / 'native'
                chain = alias / 'condensate-origin-20261003/native-two-field-transfer-20261007/toolchain/mingw64'
                compiler = str(chain / 'bin/gfortran.exe')
                environment = dict(os.environ, PATH=str(chain / 'bin') + ';' + os.environ['PATH'])
                spec = importlib.util.spec_from_file_location('isolated_compilers', local / 'camb/_compilers.py')
                helper = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(helper)
                sources = ['../forutils/' + name.removesuffix('.f90') for name in helper.makefile_dict(native / 'forutils/Makefile')['SRCS'].replace('MatrixUtils.f90', '').split()]
                sources += helper.makefile_dict(native / 'fortran/Makefile_main')['SOURCEFILES'].split()
                (local / 'fortran/WinMTS').mkdir(exist_ok=False)
                flags = ['-B' + (chain / suffix).as_posix() + '/' for suffix in ('libexec/gcc/x86_64-w64-mingw32/14.2.0', 'lib', 'bin', 'lib/gcc/x86_64-w64-mingw32/14.2.0', 'x86_64-w64-mingw32/lib')]
                flags += ['-L' + (chain / suffix).as_posix() + '/' for suffix in ('lib', 'lib/gcc/x86_64-w64-mingw32/14.2.0', 'x86_64-w64-mingw32/lib')]
                flags += ['-shared', '-static', '-cpp', '-fopenmp', '-O2', '-fcheck=bounds', '-fmax-errors=4', '-ffree-line-length-none']
                objects = []
                for index, source in enumerate(sources):
                    target = 'WinMTS/' + Path(source).name + '.o'
                    objects.append(target)
                    run([compiler, *flags, source + '.f90', '-c', '-o', target, '-JWinMTS'], log, native / 'fortran', environment)
                    if index % 10 == 0:
                        print(json.dumps(dict(compiled=index + 1, total=len(sources))), flush=True)
                run([compiler, *flags, *objects, '-o', '../camb/cambdll.dll', '-JWinMTS'], log, native / 'fortran', environment)
                result.update(state='completed', dll_sha256=digest(local / 'camb/cambdll.dll'), source_hashes=candidate_sources, compiler_sha256=digest(BRANCH / 'native-two-field-transfer-20261007/toolchain/mingw64/bin/gfortran.exe'), source_count=len(sources), bounds_checking=True, worker_threads=1)
        except BaseException as error:
            result.update(state='failed', error=repr(error))
            raise
        finally:
            if mapped:
                current_target = drive_target(selected_drive)
                if current_target is not None and current_target.casefold() == expected_target.casefold():
                    with (ROOT / 'native-unmap.log').open('x', encoding='utf-8') as log:
                        run(['subst', selected_drive, '/D'], log, cleanup=True)
                elif current_target is not None:
                    result['mapping_reassigned_by_other_owner_preserved'] = True
            result['temporary_mapping_removed'] = drive_target(selected_drive) is None
            result['temporary_drive'] = selected_drive
            result['children'] = [dict(identity=identity, outcome=exited(identity)) for identity in identities.values()]
            write('native-build-result.json', result)
        require(all(row['outcome']['exited'] for row in result['children']), 'compiler children exited')
        require(result['temporary_mapping_removed'], 'temporary mapping removed')
        check_hashes(candidate_sources)
        print(json.dumps(dict(state=result['state'], dll_sha256=result['dll_sha256'], compiled=result['source_count'], children_exited=len(result['children']), mapping_removed=True)), flush=True)


if __name__ == '__main__':
    main()
