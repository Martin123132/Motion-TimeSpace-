from source_model import *
from check_owned_candidate import OwnedReplay
from check_split_sources import edges_for, integrate_split
import ast
import sympy as sym


def repaired_source_class():
    definition = next(node for node in ast.parse((ROOT / 'source_model.py').read_text()).body if isinstance(node, ast.ClassDef) and node.name == 'SourceModel')
    changes = dict(context=0, packet=0)

    class ReadCandidate(ast.NodeTransformer):
        def visit_Call(self, node):
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'native_replay' and node.func.attr == 'NativeReplay':
                changes['context'] += 1
                node.func = ast.Name(id='OwnedReplay', ctx=ast.Load())
                node.args[1] = ast.Call(func=ast.Name(id='candidate_label', ctx=ast.Load()), args=[ast.Name(id='case', ctx=ast.Load())], keywords=[])
            if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'np' and node.func.attr == 'load':
                changes['packet'] += 1
                node.args[0] = ast.Call(func=ast.Name(id='candidate_packet', ctx=ast.Load()), args=[ast.Name(id='case', ctx=ast.Load())], keywords=[])
            return self.generic_visit(node)

    definition = ReadCandidate().visit(definition)
    require(changes == dict(context=1, packet=1), 'same component equations on new native history')
    namespace = dict(globals(), OwnedReplay=OwnedReplay, candidate_label=lambda case: 'quintic' if case == 'cold' else 'quintic-owned', candidate_packet=lambda case: ROOT / ('native-' + case + ('-quintic.npz' if case == 'cold' else '-quintic-owned.npz')))
    exec(compile(ast.fix_missing_locations(ast.Module(body=[definition], type_ignores=[])), str(ROOT / 'source_model.py'), 'exec'), namespace)
    return namespace['SourceModel']


def extra_identities():
    hubble, hubble_prime, pressure = sym.symbols('H Hp P', nonzero=True)
    energy_residual = 6 * hubble * hubble_prime + hubble * (3 * hubble**2 + 3 * pressure)
    rho_b, rho_g, vel_b, vel_b_prime, qg, dg, pig, dpb, wave = sym.symbols('Rb Rg vb vbp qg dg pig dpb k', nonzero=True)
    ratio = 4 * rho_g / (3 * rho_b)
    qg_prime = 4 * (-vel_b_prime - hubble * vel_b + wave * dpb) / (3 * ratio) + wave * (dg - 2 * pig) / 3
    total_current_rate = rho_b * (vel_b_prime - hubble * vel_b) + rho_g * (qg_prime - 2 * hubble * qg)
    current_expected = -2 * hubble * (rho_b * vel_b + rho_g * qg) + wave * (rho_b * dpb + rho_g * dg / 3) - 2 * wave * rho_g * pig / 3
    values = dict(friedmann_source=energy_residual / (6 * hubble) - hubble_prime - (3 * hubble**2 + 3 * pressure) / 6, baryon_photon_drag=total_current_rate - current_expected)
    result = {name: str(sym.simplify(value)) for name, value in values.items()}
    require(all(value == '0' for value in result.values()), 'remaining source identities')
    return result


RepairedSources = repaired_source_class()


def main():
    with worker('repaired-conservation-check'):
        require(read(ROOT / 'owned-candidate-result.json')['paired_candidate_passed'], 'paired native candidate acceptance')
        proof = extra_identities()
        reports = {}
        for case in ('cold', 'heavy'):
            model = RepairedSources(case)
            edges, edge_report = edges_for(model)
            arrays, report = integrate_split(model, edges, 8)
            destination = ROOT / (case + '-repaired-conservation.npz')
            np.savez_compressed(destination, clock=model.clock, edges=edges, **arrays)
            hubble = model.context.data['H'][model.target]
            alpha = model.context.data['alpha'][model.target]
            relative_history = dict(H=float(np.max(abs(arrays['H_target_components'])) / np.max(abs(hubble))), alpha=float(np.max(abs(arrays['alpha_target'])) / np.max(abs(alpha))))
            reports[case] = dict(**report, relative_history=relative_history, edges=edge_report, packet_sha256=digest(destination))
            print(json.dumps(dict(case=case, history_residuals=relative_history, source_residuals=report['comparisons'])), flush=True)
        files = [Path(__file__), ROOT / 'source_model.py', ROOT / 'check_split_sources.py', ROOT / 'check_owned_candidate.py', ROOT / 'owned-candidate-result.json']
        write('repaired-conservation-result.json', dict(completed=True, proof=proof, cases=reports, source_hashes={str(path): digest(path) for path in files}, exact_total_conservation_claimed=False, numerical_canonical_gate_separate=True))


if __name__ == '__main__':
    main()
