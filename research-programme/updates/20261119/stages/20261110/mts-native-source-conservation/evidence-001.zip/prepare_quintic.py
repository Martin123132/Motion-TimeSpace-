from quintic_model import *
from scipy.interpolate import CubicSpline
import ast


def main():
    with worker('prepare-quintic'):
        sys.path.insert(0, str(NATIVE))
        import camb
        from camb.mts import MTSTwoField
        radiation = BRANCH / 'radiation-and-slow-field-transfer-20261007'
        sys.path.append(str(radiation))
        import radiation_common
        factory_source = NATIVE.parent / 'matching_common.py'
        factory = next(node for node in ast.parse(factory_source.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_source), 'exec'), namespace)
        source = PREVIOUS / 'heavy-candidate-background.npz'
        require(digest(source) == read(PREVIOUS / 'background-check-result.json')['cases']['heavy']['candidate_sha256'], 'retained heavy candidate')
        native = camb.get_background(namespace['params_for'](source), no_thermo=True)
        try:
            with np.load(source, allow_pickle=False) as table:
                nodes = table['heavy_efold'].copy()
                scale = np.exp(nodes)
                raw = native.get_background_densities(scale, vars=['cdm', 'baryon', 'photon', 'neutrino', 'nu'])
                densities = {name: values / scale**2 for name, values in raw.items()}
                neutrino = CubicSpline(nodes, np.log(densities['nu']), bc_type='natural')
                pressure_nu = -(neutrino(nodes, 1) + 1) * densities['nu'] / 3
                standard = sum(densities.values())
                standard_pressure = (densities['photon'] + densities['neutrino']) / 3 + pressure_nu
                slow_field = CubicSpline(table['efold'], table['phi_s'], bc_type='natural')(nodes)
                slow_velocity = CubicSpline(table['efold'], table['phidot_s'], bc_type='natural')(nodes)
                heavy_field, heavy_velocity = table['phi_h'].copy(), table['phidot_h'].copy()
                slow_mass2, heavy_mass2 = (scale * table['slow_mass_mpc'])**2, (scale * table['heavy_mass_mpc'])**2
                total = standard + (slow_velocity**2 + slow_mass2 * slow_field**2 + heavy_velocity**2 + heavy_mass2 * heavy_field**2) / 2
                pressure = standard_pressure + (slow_velocity**2 - slow_mass2 * slow_field**2 + heavy_velocity**2 - heavy_mass2 * heavy_field**2) / 2
                hubble = np.sqrt(total / 3)
                hubble_rate = -(total + 3 * pressure) / (6 * hubble)
                packet = dict(efold=nodes, field=heavy_field, velocity=heavy_velocity, H=hubble, H_N=hubble_rate, mass=table['heavy_mass_mpc'].copy(), standard_R=standard, standard_P=standard_pressure, **{'R_' + name: values for name, values in densities.items()})
                evaluator, derivatives = functions(packet)
                checks = {}
                for name, function, values in [('field', evaluator[0], heavy_field), ('velocity', evaluator[1], heavy_velocity)]:
                    checks[name] = float(np.max(abs(function(nodes) - values)) / np.max(abs(values)))
                    checks[name + '_first'] = float(np.max(abs(function(nodes, 1) - derivatives[name + '_first'])) / np.max(abs(derivatives[name + '_first'])))
                    checks[name + '_second'] = float(np.max(abs(function(nodes, 2) - derivatives[name + '_second'])) / np.max(abs(derivatives[name + '_second'])))
                require(max(checks.values()) < ALGEBRA, 'quintic endpoint identities')
                destination = ROOT / 'heavy-equation-quintic.npz'
                np.savez_compressed(destination, **packet)
                np.savez_compressed(ROOT / 'heavy-quintic-coefficients.npz', efold=nodes, field=evaluator[0].c, velocity=evaluator[1].c)
        finally:
            del native
        files = [Path(__file__), ROOT / 'quintic_model.py', ROOT / 'QUINTIC-REPAIR-CONTRACT.md', source, factory_source, radiation / 'radiation_common.py', NATIVE / 'camb/cambdll.dll', NATIVE / 'camb/mts.py', NATIVE / 'fortran/MTSTwoField.f90']
        write('quintic-preparation-result.json', dict(completed=True, node_count=len(nodes), unchanged_nodes_and_values=True, endpoint_checks=checks, packet_sha256=digest(destination), source_hashes={str(path): digest(path) for path in files}, native_integration_not_yet_tested=True, massive_neutrino_pressure_method='derivative of log native density on retained heavy nodes'))
        print(json.dumps(dict(completed=True, nodes=len(nodes), endpoint_checks=checks, packet_sha256=digest(destination))), flush=True)


if __name__ == '__main__':
    main()
