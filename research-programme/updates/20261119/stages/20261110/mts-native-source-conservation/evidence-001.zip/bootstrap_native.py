from source_support import *
import shutil


def main():
    with worker('bootstrap-native'):
        target = ROOT / 'native'
        require(not target.exists(), 'new isolated native tree')
        copied = {}
        for folder in ('camb', 'fortran', 'forutils'):
            shutil.copytree(NATIVE / folder, target / folder, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.dll', '*.o', '*.mod', 'WinMTS', '.git'))
            for path in sorted((target / folder).rglob('*')):
                if path.is_file():
                    relative = path.relative_to(target)
                    expected = digest(NATIVE / relative)
                    require(digest(path) == expected, 'unchanged native copy')
                    copied[str(relative)] = expected
        write('native-bootstrap-result.json', dict(completed=True, copied_source_hashes=copied, original=str(NATIVE), candidate=str(target), original_modified=False))
        print(json.dumps(dict(copied=len(copied), candidate=str(target))), flush=True)


if __name__ == '__main__':
    main()
