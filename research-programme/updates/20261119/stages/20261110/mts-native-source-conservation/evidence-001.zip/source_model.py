from source_support import *
import numpy as np
from scipy.interpolate import CubicSpline
sys.path.insert(0, str(PREVIOUS))
import check_native_replay as native_replay


class SourceModel:
    def __init__(self, case, representation='fine'):
        self.case = case
        self.context = native_replay.NativeReplay(case, 'candidate', representation)
        lower, upper = read(POST / 'mts-coherent-matching-replay-20261110/frozen-replay.json')['saved_indices']
        indices = np.arange(lower - 8, upper + 9)
        with np.load(PREVIOUS / ('native-' + case + '-candidate.npz'), allow_pickle=False) as saved:
            self.raw = {str(name): saved['observer'][indices, index] for index, name in enumerate(saved['observer_names'])}
            self.standard = {str(name): saved['standard'][indices, index] for index, name in enumerate(saved['names'])}
            full_clock = saved['clock'][indices].copy()
        self.clock = self.context.clock
        self.target = self.context.target
        self.fields = self.context.fields
        selected = np.arange(len(indices)) if representation == 'fine' else np.unique(np.r_[np.arange(0, len(indices), 2), len(indices) - 1, self.target[0], self.target[-1]])
        scale = self.raw['a_native']
        efold = np.log(scale)
        self.scalar_pressure = {}
        self.scalar_density = {}
        for suffix in self.fields:
            field_fun, velocity_fun = self.context.field_functions[suffix]
            field, velocity = field_fun(efold), velocity_fun(efold)
            mass2 = (scale * self.context.parameters['masses'][suffix])**2
            self.scalar_density[suffix] = (velocity**2 + mass2 * field**2) / 2
            self.scalar_pressure[suffix] = (velocity**2 - mass2 * field**2) / 2
        massive_pressure = self.raw['Pbar'] - (self.raw['R_gamma'] + self.raw['R_massless']) / 3 - sum(self.scalar_pressure.values())
        self.nu_density = CubicSpline(efold[selected], self.raw['R_massive'][selected])
        self.nu_pressure = CubicSpline(efold[selected], massive_pressure[selected])
        self.functions = {name: CubicSpline(full_clock[selected], values[selected]) for name, values in self.raw.items()}
        for suffix in self.fields:
            for name in ('dphi', 'dphidot'):
                key = 'mts_' + name + '_' + suffix
                self.functions[key] = CubicSpline(full_clock[selected], self.standard[key][selected])
        self.constants = {name: self.raw[name][0] * scale[0]**power for name, power in [('R_cdm', 1), ('R_baryon', 1), ('R_gamma', 2), ('R_massless', 2)]}
        self.constant_checks = {name: float(np.max(abs(self.raw[name] * scale**power / self.constants[name] - 1))) for name, power in [('R_cdm', 1), ('R_baryon', 1), ('R_gamma', 2), ('R_massless', 2)]}
        native_scalar = self.raw['R_scalar']
        self.recovery = dict(scalar_density=float(np.max(abs(sum(self.scalar_density.values()) - native_scalar)) / np.max(abs(native_scalar))), friedmann=float(np.max(abs(3 * self.raw['H_native']**2 / self.raw['R'] - 1))), scalar_pressure_subtraction_only=True)
        require(max(self.constant_checks.values()) < ALGEBRA and self.recovery['scalar_density'] < ALGEBRA and self.recovery['friedmann'] < ALGEBRA, 'native component recovery')

    def evaluate(self, clock):
        scale, hubble, potential, lapse = self.context.geometry(clock)
        efold = np.log(scale)
        alpha = self.functions['sigma'](clock)
        eta = self.functions['eta_sync'](clock)
        density_delta = self.functions['D_sync'](clock)
        current = self.functions['Q_sync'](clock)
        dilation = (density_delta / 2 + eta) / hubble
        density = sum(self.constants[name] / scale**power for name, power in [('R_cdm', 1), ('R_baryon', 1), ('R_gamma', 2), ('R_massless', 2)])
        pressure = (self.constants['R_gamma'] + self.constants['R_massless']) / (3 * scale**2)
        pressure_b = self.constants['R_baryon'] / scale * self.functions['delta_p_b'](clock)
        defects = {}
        fields = {}
        for suffix in self.fields:
            field, velocity, mass2 = self.context.background(clock, suffix)
            field_fun, velocity_fun = self.context.field_functions[suffix]
            defect_f = hubble * field_fun(efold, 1) - velocity
            defect_b = hubble * velocity_fun(efold, 1) + 2 * hubble * velocity + mass2 * field
            sync_u = self.functions['mts_dphi_' + suffix](clock)
            sync_w = self.functions['mts_dphidot_' + suffix](clock)
            energy_defect = velocity * defect_b + mass2 * field * defect_f
            density_defect = sync_w * defect_b + mass2 * sync_u * defect_f
            current_defect = sync_u * defect_b
            expansion_defect = energy_defect / (6 * hubble)
            shear_defect = density_defect / (2 * hubble) + 1.5 * current_defect - dilation * expansion_defect / hubble
            defects[suffix] = dict(EH=expansion_defect, Ea=shear_defect, ER=energy_defect, ED=density_defect, EQ=current_defect)
            fields[suffix] = dict(field=field, velocity=velocity, mass2=mass2, Eb=defect_b, Ef=defect_f)
            density = density + (velocity**2 + mass2 * field**2) / 2
            pressure = pressure + (velocity**2 - mass2 * field**2) / 2
        density_nu, pressure_nu = self.nu_density(efold), self.nu_pressure(efold)
        expansion_nu = (self.nu_density(efold, 1) + density_nu + 3 * pressure_nu) / 6
        defects['nu_background_only'] = dict(EH=expansion_nu, Ea=-dilation * expansion_nu / hubble)
        defects['baryon_pressure'] = dict(EH=np.zeros_like(scale), Ea=1.5 * pressure_b)
        return dict(a=scale, H=hubble, Phi=potential, Psi=lapse, alpha=alpha, eta=eta, z=dilation, R=density + density_nu, P=pressure + pressure_nu, defects=defects, fields=fields, native_R=self.functions['R'](clock), native_P=self.functions['Pbar'](clock), native_alpha_derivative_defect=self.functions['sigma'](clock, 1) + hubble * alpha - lapse, constraint_alpha=alpha - dilation - 1.5 * current)
