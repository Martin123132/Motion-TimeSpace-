from source_support import *
import argparse
import numpy as np
from check_owned_candidate import OwnedReplay
from source_model import native_replay
from analyze_sources import prove
from check_repaired_conservation import extra_identities

FAILED = {'native-heavy-quintic', 'native-candidate-check'}


def owned_exits(except_name):
    rows = []
    for path in sorted(ROOT.glob('*-start.json')):
        name = path.name.removesuffix('-start.json')
        if name == except_name:
            continue
        identity = read(path)
        end = read(ROOT / (name + '-end.json'))
        expected_state = 'failed' if name in FAILED else 'completed'
        require(end['state'] == expected_state, 'honest execution state ' + name)
        require(all(end[key] == identity[key] for key in ('pid', 'created', 'command')), 'exact worker identity')
        outcome = exited(identity)
        require(outcome['exited'], 'worker exited ' + name)
        rows.append(dict(name=name, identity=identity, state=end['state'], outcome=outcome))
    return rows


def merge(inputs, addition):
    for path, checksum in addition.items():
        require(path not in inputs or inputs[path] == checksum, 'consistent source hash ' + path)
        inputs[path] = checksum


def validate():
    with worker('validate'):
        inputs = read(ROOT / 'frozen-inputs.json')
        for path in ROOT.glob('*-result.json'):
            merge(inputs, read(path).get('source_hashes', {}))
        for path in ROOT.glob('native-*-frozen.json'):
            merge(inputs, read(path))
        check_hashes(inputs)
        require(prove() == read(ROOT / 'attribution-result.json')['proof'], 'four source identities reproduced')
        require(extra_identities() == read(ROOT / 'repaired-conservation-result.json')['proof'], 'two additional identities reproduced')
        report = read(ROOT / 'owned-candidate-result.json')
        require(report['paired_candidate_passed'] and report['old_mts_failure_preserved'], 'candidate success and old failure remain separate')
        require(report['numerical_gate'] == GATE and report['algebra_gate'] == ALGEBRA and not report['diagnostic_defect_forces_added'], 'unchanged gates and physical source equations')
        comparisons = 0
        for label, case_report in report['cases'].items():
            case, representation = label.split('-', 1)
            outputs = {}
            for variant, run in case_report['runs'].items():
                context = OwnedReplay(case, representation, 'coarse' if variant == 'coarse4' else 'fine')
                path = ROOT / ('replay-' + label + '-' + variant + '.npz')
                require(digest(path) == run['packet_sha256'], 'replay packet integrity')
                with np.load(path, allow_pickle=False) as packet:
                    require(all(np.isfinite(packet[name]).all() for name in packet.files), 'finite replay')
                    observed = context.observe(packet['state'])
                    for name, values in observed.items():
                        require(np.array_equal(values, packet[name]), 'independent state readout reproduction')
                        require(native_replay.retained.difference(values, context.data[name][context.target]) == run['checks'][name], 'canonical comparison reproduced')
                        comparisons += 1
                    outputs[variant] = {name: values.copy() for name, values in observed.items()}
                require(context.provenance['source_recovery'] == run['source_recovery'], 'native/Python source recovery reproduced')
                require(all(row['normalized'] < ALGEBRA for row in run['source_recovery'].values()), 'source recovery gate')
                require(run['passed'] == all(row['passed'] for row in run['checks'].values()), 'honest variant pass')
            for name, recorded in case_report['refinement'].items():
                require(native_replay.retained.difference(outputs['fine2'][name], outputs['fine4'][name]) == recorded, 'step refinement reproduced')
                comparisons += 1
            for name, recorded in case_report['history_sensitivity'].items():
                require(native_replay.retained.difference(outputs['coarse4'][name], outputs['fine4'][name]) == recorded, 'history refinement reproduced')
                comparisons += 1
            computed_pass = all(run['passed'] for run in case_report['runs'].values()) and all(row['passed'] for row in list(case_report['refinement'].values()) + list(case_report['history_sensitivity'].values())) and case_report['source_recovery_algebra_passed']
            require(computed_pass == case_report['passed'], 'overall case status')
        for case in ('cold', 'heavy'):
            with np.load(PREVIOUS / ('native-' + case + '-candidate.npz'), allow_pickle=False) as old, np.load(ROOT / ('native-' + case + '-cubic.npz'), allow_pickle=False) as rebuilt:
                require(all(np.array_equal(old[name], rebuilt[name]) for name in old.files), 'disabled library reproduces every saved array')
        clock = ROOT / 'heavy-equation-quintic.npz'
        preparation = read(ROOT / 'quintic-preparation-result.json')
        require(digest(clock) == preparation['packet_sha256'], 'derived coefficient packet')
        with np.load(clock, allow_pickle=False) as packet, np.load(PREVIOUS / 'heavy-candidate-background.npz', allow_pickle=False) as table:
            for candidate, original in [('efold', 'heavy_efold'), ('field', 'phi_h'), ('velocity', 'phidot_h'), ('mass', 'heavy_mass_mpc')]:
                require(np.array_equal(packet[candidate], table[original]), 'original primitive nodes and parameters retained')
            require(all(np.isfinite(packet[name]).all() for name in packet.files), 'finite clock packet')
            require(np.all(packet['H'] > 0), 'physical positive clock')
        for name, row in read(ROOT / 'split-source-result.json')['cases'].items():
            for representation, case_report in row.items():
                arrays = {}
                for order, run in case_report['runs'].items():
                    path = ROOT / (name + '-split-' + representation + order + '.npz')
                    require(digest(path) == run['packet_sha256'], 'split diagnostic packet hash')
                    with np.load(path, allow_pickle=False) as packet:
                        arrays[order] = {key: packet[key].copy() for key in packet.files}
                        for check, prediction, target in [('H', 'H_prediction', 'H_target_components'), ('H_with_scale', 'H_prediction_with_scale', 'H_target_components'), ('alpha', 'alpha_prediction', 'alpha_target')]:
                            require(native_replay.retained.difference(packet[prediction], packet[target]) == run['comparisons'][check], 'source attribution comparison reproduced')
                            comparisons += 1
                for observable, recorded in case_report['quadrature_refinement'].items():
                    require(native_replay.retained.difference(arrays['4'][observable], arrays['8'][observable]) == recorded, 'source quadrature refinement reproduced')
                    comparisons += 1
        build = read(ROOT / 'native-build-result.json')
        require(build['state'] == 'completed' and build['temporary_mapping_removed'], 'isolated native build cleanup')
        require(digest(ROOT / 'native/camb/cambdll.dll') == build['dll_sha256'], 'tested binary intact')
        for row in build['children']:
            require(exited(row['identity'])['exited'], 'compiler/helper exited')
        bootstrap = read(ROOT / 'native-bootstrap-result.json')
        changed = []
        for relative, checksum in bootstrap['copied_source_hashes'].items():
            require(digest(NATIVE / relative) == checksum, 'original native files intact')
            if digest(ROOT / 'native' / relative) != checksum:
                changed.append(relative.replace('\\', '/'))
        require(set(changed) == {'fortran/MTSTwoField.f90', 'camb/mts.py'}, 'only declared native source changes')
        require(not list(ROOT.rglob('__pycache__')), 'no generated bytecode')
        compiled = []
        for path in sorted(ROOT.glob('*.py')):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
            compiled.append(path.name)
        workers = owned_exits('validate')
        write('validation.json', dict(implementation_validated=True, paired_candidate_canonical_replay_passed=True, old_cubic_mts_replay_passed=False, exact_total_conservation_claimed=False, independently_recomputed_comparisons=comparisons, exact_identities=6, input_hashes=inputs, workers=workers, compiler_children_exited=len(build['children']), compiled_scripts=compiled, numerical_gate=GATE, algebra_gate=ALGEBRA, full_state_restart_saved=False, independent_full_hierarchy_reintegration=False, no_new_fits=True))
        print(json.dumps(dict(validated=True, paired_candidate_passed=True, comparisons=comparisons, sources=len(inputs), workers=len(workers), compiler_children=len(build['children']))), flush=True)


def seal():
    with worker('seal'):
        validation = read(ROOT / 'validation.json')
        require(validation['implementation_validated'] and validation['paired_candidate_canonical_replay_passed'] and not validation['old_cubic_mts_replay_passed'], 'separate verified outcomes')
        check_hashes(validation['input_hashes'])
        workers = owned_exits('seal')
        artifacts = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file()}
        require('closeout.json' not in artifacts, 'new checkpoint only')
        write('closeout.json', dict(implementation_validated=True, paired_candidate_canonical_replay_passed=True, old_cubic_mts_replay_passed=False, full_state_restart_saved=False, state='derived heavy-source interpolation passes paired native canonical replay', utc=datetime.now(timezone.utc).isoformat(), artifacts=artifacts, input_hashes=validation['input_hashes'], prior_seal=EXPECTED, workers=workers, next_file='NEXT.md'))
        print(json.dumps(dict(seal_sha256=digest(ROOT / 'closeout.json'), artifacts=len(artifacts), sources=len(validation['input_hashes']))), flush=True)


def verify(expected):
    with worker('postseal') as identity:
        require(expected is not None and digest(ROOT / 'closeout.json') == expected, 'expected seal')
        report = read(ROOT / 'closeout.json')
        check_hashes(report['input_hashes'])
        for name, row in report['artifacts'].items():
            path = ROOT / name
            require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'sealed artifact ' + name)
        workers = owned_exits('postseal')
        extras = {str(path.relative_to(ROOT)) for path in ROOT.rglob('*') if path.is_file()} - set(report['artifacts'])
        require(extras == {'closeout.json', 'seal-end.json', 'postseal-start.json'}, 'expected postseal files only')
        build = read(ROOT / 'native-build-result.json')
        for row in build['children']:
            require(exited(row['identity'])['exited'], 'final compiler child exit')
        write('CLEANUP-VERIFIED.json', dict(passed=True, seal_sha256=expected, workers=workers, compiler_children=build['children'], temporary_mapping_removed=build['temporary_mapping_removed'], verifier_identity=identity, verifier_exit_requires_exec_completion=True, continuing_job_authorized=False, processes_killed=[], temporary_apps_started=[], note='Both failed attempt identities exited. Final verifier exit is observed by command completion. No shared services changed.'))
        print(json.dumps(dict(passed=True, paired_candidate_passed=True, sources=len(report['input_hashes']), artifacts=len(report['artifacts']), prior_workers_exited=len(workers), compiler_children_exited=len(build['children']), verifier_pid=identity['pid'])), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('validate', 'seal', 'verify'))
    parser.add_argument('--expected')
    args = parser.parse_args()
    if args.mode == 'validate':
        validate()
    elif args.mode == 'seal':
        seal()
    else:
        verify(args.expected)
