from source_model import *
from quintic_model import functions
from check_split_sources import edges_for
from numpy.polynomial.legendre import leggauss


def main():
    with worker('quintic-source-check'):
        report = read(ROOT / 'quintic-preparation-result.json')
        require(digest(ROOT / 'heavy-equation-quintic.npz') == report['packet_sha256'], 'quintic source packet')
        with np.load(ROOT / 'heavy-equation-quintic.npz', allow_pickle=False) as packet:
            quintic, derivatives = functions(packet)
        model = SourceModel('heavy')
        edges, edge_report = edges_for(model)
        nodes, weights = leggauss(8)
        query = ((edges[:-1] + edges[1:])[:, None] / 2 + np.diff(edges)[:, None] * nodes / 2).ravel()
        scale = model.context.scale(query)
        efold = np.log(scale)
        standard = model.nu_density(efold) + sum(model.constants[name] / scale**power for name, power in [('R_cdm', 1), ('R_baryon', 1), ('R_gamma', 2), ('R_massless', 2)])
        slow_field, slow_velocity, slow_mass2 = model.context.background(query, 's')
        rest = standard + (slow_velocity**2 + slow_mass2 * slow_field**2) / 2
        mass2 = (scale * model.context.parameters['masses']['h'])**2
        outputs, checks = {}, {}
        for label, evaluators in [('cubic', model.context.field_functions['h']), ('quintic', quintic)]:
            field, velocity = [function(efold) for function in evaluators]
            hubble = np.sqrt((rest + (velocity**2 + mass2 * field**2) / 2) / 3)
            defect_f = hubble * evaluators[0](efold, 1) - velocity
            defect_b = hubble * evaluators[1](efold, 1) + 2 * hubble * velocity + mass2 * field
            defect_r = velocity * defect_b + mass2 * field * defect_f
            checks[label] = dict(field_equation=float(np.max(abs(defect_f)) / np.max(abs(velocity))), velocity_equation=float(np.max(abs(defect_b)) / np.max(abs(2 * hubble * velocity) + abs(mass2 * field))), energy_equation=float(np.max(abs(defect_r)) / np.max(hubble * (2 * velocity**2 + mass2 * field**2))))
            outputs.update({label + '_' + name: value for name, value in dict(field=field, velocity=velocity, H=hubble, Ef=defect_f, Eb=defect_b, ER=defect_r).items()})
        change = {name: native_replay.retained.difference(outputs['quintic_' + name], outputs['cubic_' + name]) for name in ('field', 'velocity', 'H')}
        destination = ROOT / 'quintic-source-check.npz'
        np.savez_compressed(destination, clock=query, **outputs)
        files = [Path(__file__), ROOT / 'quintic_model.py', ROOT / 'heavy-equation-quintic.npz', ROOT / 'source_model.py']
        write('quintic-source-result.json', dict(completed=True, original_grid_unchanged=True, checks=checks, source_change=change, all_defects_reduced=all(checks['quintic'][name] < checks['cubic'][name] for name in checks['cubic']), packet_sha256=digest(destination), source_hashes={str(path): digest(path) for path in files}, native_canonical_gate_not_yet_tested=True))
        print(json.dumps(dict(checks=checks, change=change)), flush=True)


if __name__ == '__main__':
    main()
