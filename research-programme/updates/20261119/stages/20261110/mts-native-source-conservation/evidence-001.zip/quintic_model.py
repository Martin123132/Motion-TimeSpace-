from source_support import *
import numpy as np
from scipy.interpolate import PPoly


def make_quintic(nodes, values, first, second):
    width = np.diff(nodes)
    initial = values[:-1]
    linear = width * first[:-1]
    quadratic = width**2 * second[:-1] / 2
    remaining_value = values[1:] - initial - linear - quadratic
    remaining_first = width * first[1:] - linear - 2 * quadratic
    remaining_second = width**2 * second[1:] - 2 * quadratic
    cubic = 10 * remaining_value - 4 * remaining_first + remaining_second / 2
    quartic = -15 * remaining_value + 7 * remaining_first - remaining_second
    quintic = 6 * remaining_value - 3 * remaining_first + remaining_second / 2
    coefficients = np.array([quintic / width**5, quartic / width**4, cubic / width**3, quadratic / width**2, linear / width, initial])
    return PPoly(coefficients, nodes, extrapolate=False)


def functions(packet):
    nodes = packet['efold']
    field, velocity, hubble, hubble_rate = [packet[name] for name in ('field', 'velocity', 'H', 'H_N')]
    mass2 = (np.exp(nodes) * float(packet['mass']))**2
    field_rate = velocity / hubble
    velocity_rate = -2 * velocity - mass2 * field / hubble
    field_second = velocity_rate / hubble - velocity * hubble_rate / hubble**2
    velocity_second = -2 * velocity_rate - (2 * mass2 * field + mass2 * field_rate) / hubble + mass2 * field * hubble_rate / hubble**2
    return (make_quintic(nodes, field, field_rate, field_second), make_quintic(nodes, velocity, velocity_rate, velocity_second)), dict(field_first=field_rate, velocity_first=velocity_rate, field_second=field_second, velocity_second=velocity_second)
