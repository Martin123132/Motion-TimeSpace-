from prop_model import *
import argparse
from scipy.integrate import solve_ivp


def freeze():
    require(digest(PHASE/'closeout.json')==EXPECTED_PHASE,'verified phase correction')
    previous=read(PHASE/'closeout.json')
    check_hashes(previous['input_hashes'])
    check_hashes({str(PHASE/name):row['sha256'] for name,row in previous['artifacts'].items()})
    paths=[PHASE/'closeout.json',PHASE/'CLEANUP-VERIFIED.json',PHASE/'phase_support.py',PHASE/'phase_model.py',NORMAL/'normal_support.py',LIVE/'live_support.py',PROJECTION/'frozen-projection.npz',MEMORY/'closeout.json']
    initials={}
    for case in ('cold','heavy'):
        for window in ('live','extraction'):
            paths.extend([input_path(case,window),NORMAL/(case+'-'+window+'.npz')])
            if not (case=='heavy' and window=='live'):
                path=memory_path(case,window,'fine8')
                require(digest(path)==read(MEMORY/'closeout.json')['artifacts'][path.name]['sha256'],'verified metric history')
                paths.append(path)
            history=History(case,window,1)
            initials[case+'-'+window]=dict(time=float(history.times[0]),state=history.initial(),count=len(history.times),source='retained original initial primitive; derived coordinate inverse, not endpoint fit')
    paths.extend(sorted(ROOT.glob('*.py')))
    paths.append(ROOT/'PROTOCOL.md')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write('frozen-inputs.json',{str(path):digest(path) for path in paths})
    write('initials.json',initials)
    write('contract.json',dict(previous_turn='progress',previous_seal=EXPECTED_PHASE,configs=[dict(name='dense-step1',stride=1,step_divisor=1),dict(name='dense-step2',stride=1,step_divisor=2),dict(name='sparse-step2',stride=2,step_divisor=2)],integration=dict(method='DOP853',rtol=1e-10,atol=1e-12,normalization='initial state and initial RHS only; error/bound use initial reduced-state scales'),gates=[GATE,ALGEBRA],physical_grid_and_parameters_changed=False,rest_source_prescribed=True,full_live_feedback=False,initials_sha256=digest(ROOT/'initials.json'),acceptance='native conditional reference, error-channel identity and numerical refinements; reduced physical predictions reported whether passing or failing'))
    print(json.dumps(dict(frozen=True,inputs=len(paths),initial_cases=len(initials))),flush=True)


def score(history,solution):
    case=history.case
    exact=[]
    predicted=[]
    exact_physical=[]
    predicted_physical=[]
    exact_reduced=[]
    bounds_physical=[]
    coordinate_conditions=[]
    for time,state in zip(history.times,solution):
        values=history.evaluate(float(time))
        if case=='cold':
            exact.append(state.copy())
            predicted.append(state.copy())
            exact_physical.append([state[0],0.,0.])
            predicted_physical.append([state[0],0.,0.])
            continue
        primitive=state[:2]
        reduced=state[2:4]
        reconstructed=(values['transform']@np.r_[reduced,values['rest']])[:2]
        reduced_primitive=np.linalg.solve(values['mapping'],reconstructed)
        exact.append(primitive)
        predicted.append(reduced_primitive)
        exact_physical.append(values['physical_readout']@primitive)
        predicted_physical.append(values['physical_readout']@reduced_primitive)
        exact_reduced.append(history.reduced_state(values,primitive))
        conversion=np.linalg.solve(values['mapping'],values['transform'][:2,:2])
        bounds_physical.append(abs(values['physical_readout']@conversion)@state[6:8])
        coordinate_conditions.append(np.linalg.cond(values['transform']))
    data=dict(clock=history.times,solution=solution,exact=np.array(exact),predicted=np.array(predicted),exact_physical=np.array(exact_physical),predicted_physical=np.array(predicted_physical))
    if case=='cold':
        reference=history.original_density[:,None]
        reference_physical=np.column_stack([history.original_density,np.zeros(len(history.times)),np.zeros(len(history.times))])
    else:
        reference=history.saved['vector'][:,history.first+2:history.first+4]
        reference_physical=history.normal['physical']
        data.update(exact_reduced=np.array(exact_reduced),physical_error_bound=np.array(bounds_physical),condition=np.array(coordinate_conditions))
    checks=dict(reference_state=columns(data['exact'],reference,'primitive_'),reference_stress=columns(data['exact_physical'],reference_physical,'stress_'))
    reduced=dict(state=columns(data['predicted'],reference,'primitive_'),stress=columns(data['predicted_physical'],reference_physical,'stress_'),versus_conditional_exact=columns(data['predicted'],data['exact'],'primitive_'))
    report=dict(reference_passed=all_pass(checks),checks=checks,reduced_controls=reduced,final_state=comparison(data['predicted'][-1],reference[-1]),final_stress=columns(data['predicted_physical'][-1:],reference_physical[-1:],'stress_'),kind='independent conditional evolution with prescribed native rest history')
    if case=='heavy':
        checks['defect_response']=columns(solution[:,2:4]+solution[:,4:6],data['exact_reduced'],'reduced_',ALGEBRA)
        allowances=ALGEBRA*np.maximum(np.max(abs(data['exact_reduced']),axis=0),1e-300)
        error=abs(data['exact_reduced']-solution[:,2:4])
        bound=solution[:,6:8]
        bound_passed=bool(np.all(error<=bound+allowances[None,:]) and np.min(bound)>=-np.max(allowances))
        report['error_budget']=dict(defect_response_passed=all(row['passed'] for row in checks['defect_response'].values()),sampled_majorant_encloses_error=bound_passed,error_final=data['exact_reduced'][-1]-solution[-1,2:4],bound_final=bound[-1],physical_bound_final=data['physical_error_bound'][-1],certified_continuum_bound=False,interpretation='a posteriori defect and numerical componentwise envelope; not an independent forward physical correction')
        report['reference_passed']=all_pass(checks) and bound_passed
    if history.window=='extraction':
        weights=packet(PROJECTION/'frozen-projection.npz')['weights']
        projected_reference=weights@reference_physical
        report['projection']=dict(reference=projected_reference,exact=weights@data['exact_physical'],reduced=weights@data['predicted_physical'],checks=columns((weights@data['predicted_physical'])[None,:],projected_reference[None,:],'stress_'),fixed_original_signed_weights=True)
    return data,report


def run(case,window):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    contract=read(ROOT/'contract.json')
    require(digest(ROOT/'initials.json')==contract['initials_sha256'],'initials unchanged')
    frozen_initial=np.array(read(ROOT/'initials.json')[case+'-'+window]['state'])
    reports={}
    for config in contract['configs']:
        history=History(case,window,config['stride'])
        initial=history.initial()
        require(comparison(initial,frozen_initial,ALGEBRA)['passed'],'frozen initial state')
        initial_rhs=history.rhs(float(history.times[0]),initial)
        normalization=np.maximum(abs(initial),abs(initial_rhs)*(history.times[-1]-history.times[0]))
        if case=='heavy':
            normalization[4:6]=normalization[2:4]
            normalization[6:8]=normalization[2:4]
        normalization[normalization==0]=1.
        def rhs(time,normalized):
            return history.rhs(time,normalized*normalization)/normalization
        maximum_step=float(np.min(np.diff(history.times)))/config['step_divisor']
        result=solve_ivp(rhs,(history.times[0],history.times[-1]),initial/normalization,method='DOP853',rtol=contract['integration']['rtol'],atol=contract['integration']['atol'],max_step=maximum_step,t_eval=history.times)
        require(result.success and result.y.shape[1]==len(history.times),'complete conditional integration')
        data,report=score(history,result.y.T*normalization)
        data.update(normalization=normalization,initial=initial,selected_history_nodes=history.selected)
        name=case+'-'+window+'-'+config['name']
        path=ROOT/(name+'.npz')
        require(not path.exists(),'no output overwrite')
        np.savez_compressed(path,**data)
        report.update(packet_sha256=digest(path),nfev=result.nfev,maximum_step=maximum_step)
        reports[config['name']]=report
        print(json.dumps(dict(case=case,window=window,config=config['name'],reference_passed=report['reference_passed'],reduced_state=report['reduced_controls']['state'],projection=report.get('projection'),error_budget=report.get('error_budget'),nfev=result.nfev),default=convert),flush=True)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write(case+'-'+window+'-result.json',dict(completed=True,reference_passed=all(value['reference_passed'] for value in reports.values()),runs=reports,reduced_model_promoted=False))


def verify():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks={}
    reference_passed=True
    reduced_passed=True
    for case in ('cold','heavy'):
        for window in ('live','extraction'):
            label=case+'-'+window
            report=read(ROOT/(label+'-result.json'))
            require(report['completed'],'completed paired windows')
            reference_passed=reference_passed and report['reference_passed']
            reduced_passed=reduced_passed and all_pass(report['runs']['dense-step2']['reduced_controls'])
            packets={}
            for name,row in report['runs'].items():
                path=ROOT/(label+'-'+name+'.npz')
                require(digest(path)==row['packet_sha256'],'unchanged run packet')
                packets[name]=packet(path)
                require(comparison(packets[name]['solution'][0],packets[name]['initial'],ALGEBRA)['passed'],'saved initial state at unchanged algebra gate')
                if case=='heavy':
                    data=packets[name]
                    checks[label+'/'+name+'/defect']=columns(data['solution'][:,2:4]+data['solution'][:,4:6],data['exact_reduced'],'state_',ALGEBRA)
            fine=packets['dense-step2']
            for name in ('dense-step1','sparse-step2'):
                compared=packets[name]
                for key in ('exact','predicted','exact_physical','predicted_physical'):
                    checks[label+'/'+name+'/'+key]=columns(compared[key],fine[key],'component_')
    write('validation.json',dict(passed=reference_passed and all_pass(checks),reference_passed=reference_passed,refinements_passed=all_pass(checks),checks=checks,count=sum(len(group) for group in checks.values()),reduced_all_pointwise_gates_passed=reduced_passed,full_live_feedback=False))
    print(json.dumps(dict(verified=reference_passed and all_pass(checks),reference=reference_passed,refinements=all_pass(checks),reduced_all_pointwise_gates_passed=reduced_passed,comparisons=sum(len(group) for group in checks.values()))),flush=True)


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'validation.json')['passed'],'validated reference/refinement gates')
    require((ROOT/'RESULTS.md').is_file() and (ROOT/'DERIVATION.md').is_file(),'saved scientific outcome')
    excluded={'closeout.json','seal-end.json','postseal-start.json','postseal-end.json','CLEANUP-VERIFIED.json'}
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write('closeout.json',dict(implementation_validated=True,conditional_finite_time_test_completed=True,defect_response_evaluated=True,rest_history_prescribed=True,full_live_feedback=False,old_late_model_replaced=False,goal_complete=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='postseal-start.json':
            continue
        owner=read(path)
        ending=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(owner)
        require(outcome['exited'] and ending['state']=='completed','prior task worker completed and exited')
        workers.append(dict(name=path.stem,identity=owner,outcome=outcome))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('freeze','run','verify','seal','postseal'))
    parser.add_argument('--case',choices=('cold','heavy'))
    parser.add_argument('--window',choices=('live','extraction'))
    arguments=parser.parse_args()
    label=arguments.operation if arguments.operation!='run' else arguments.case+'-'+arguments.window
    with worker(label) as identity:
        if arguments.operation=='run':
            run(arguments.case,arguments.window)
        elif arguments.operation=='postseal':
            postseal(identity)
        else:
            globals()[arguments.operation]()
