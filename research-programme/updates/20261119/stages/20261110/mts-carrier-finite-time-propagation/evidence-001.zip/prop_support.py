import sys
from pathlib import Path
from time import monotonic

PHASE=Path(__file__).resolve().parent.parent/'mts-phase-corrected-carrier-20261110'
sys.path.insert(0,str(PHASE))
import phase_support as phase_module
phase_module.ROOT=Path(__file__).resolve().parent
phase_module.retained.ROOT=phase_module.ROOT
phase_module.retained.shared.ROOT=phase_module.ROOT
phase_module.retained.shared.START=monotonic()
from phase_support import *
from phase_model import effective,micromotion,micromotion_prime

PHASE=POST/'mts-phase-corrected-carrier-20261110'
EXPECTED_PHASE='22760b701ea5207c8331673150878f0ffc0a337e52034a6cad9f6c359f168b11'
original_guard=phase_module.guard


def guard():
    original_guard()
    require(not (PHASE/'STOP-REQUESTED').exists(),'owner hold '+str(PHASE))


phase_module.retained.shared.guard=guard
