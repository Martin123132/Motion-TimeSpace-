import argparse
from prop_model import *
from run_propagation import score


def validate():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks={}
    selected={}
    source_hashes={str(Path(__file__)):digest(Path(__file__))}
    original=read(ROOT/'validation.json')
    failures={group+'/'+name for group,rows in original['checks'].items() for name,row in rows.items() if not row['passed']}
    expected={'heavy-extraction/'+name+'/defect/state_0' for name in ('dense-step1','dense-step2','sparse-step2')}
    require(failures==expected and not original['passed'],'preserve exactly the three original diagnostic failures')
    contract=read(ROOT/'contract.json')
    require(contract['gates']==[GATE,ALGEBRA] and not contract['physical_grid_and_parameters_changed'],'unchanged gates and physical settings')
    require(digest(ROOT/'initials.json')==contract['initials_sha256'],'unchanged frozen initials')
    for case in ('cold','heavy'):
        for window in ('live','extraction'):
            label=case+'-'+window
            original_report=read(ROOT/(label+'-result.json'))
            packets={}
            for name,report in original_report['runs'].items():
                path=ROOT/(label+'-'+name+'.npz')
                require(digest(path)==report['packet_sha256'],'original packet hash')
                packets[name]=packet(path)
                require(all(np.all(np.isfinite(value)) for value in packets[name].values()),'finite original arrays')
                source_hashes[str(path)]=digest(path)
            fine=packets['dense-step2']
            for name in ('dense-step1','sparse-step2'):
                require(np.array_equal(packets[name]['clock'],fine['clock']),'original grids unchanged')
                for key in ('exact','predicted','exact_physical','predicted_physical'):
                    checks[label+'/'+name+'/'+key]=columns(packets[name][key],fine[key],'component_')
            selected_name='dense-step2-segmented' if window=='extraction' else 'dense-step2'
            path=ROOT/(label+'-'+selected_name+'.npz')
            data=packet(path)
            report_path=ROOT/(label+'-'+selected_name+'-result.json') if window=='extraction' else ROOT/(label+'-result.json')
            saved_report=read(report_path)['runs'][selected_name]
            require(digest(path)==saved_report['packet_sha256'],'selected packet hash')
            require(np.array_equal(data['clock'],fine['clock']),'selected grid unchanged')
            require(np.array_equal(data['initial'],fine['initial']),'selected initial unchanged')
            require(np.array_equal(data['selected_history_nodes'],fine['selected_history_nodes']),'selected history nodes unchanged')
            require(np.array_equal(data['normalization'],fine['normalization']),'initial-only scaling unchanged')
            require(all(np.all(np.isfinite(value)) for value in data.values()),'finite selected arrays')
            checks[label+'/initial']={'state':comparison(data['solution'][0],data['initial'],ALGEBRA)}
            history=History(case,window,1)
            regenerated,report=score(history,data['solution'])
            for key in ('exact','predicted','exact_physical','predicted_physical'):
                checks[label+'/readout/'+key]=columns(regenerated[key],data[key],'component_',ALGEBRA)
                if window=='extraction':
                    checks[label+'/segmented-versus-global/'+key]=columns(data[key],fine[key],'component_')
            for group,rows in report['checks'].items():
                checks[label+'/selected/'+group]=rows
            require(report['reference_passed'],'selected conditional reference and defect identity')
            if case=='heavy':
                require(report['error_budget']['sampled_majorant_encloses_error'],'sampled enclosure only')
            selected[label]=dict(packet=path.name,report=report)
            source_hashes[str(path)]=digest(path)
            source_hashes[str(report_path)]=digest(report_path)
    independence=read(ROOT/'independence.json')
    check_hashes(independence['input_hashes'])
    require(independence['passed'] and all_pass(independence['checks']),'independence controls')
    require(all_pass(checks),'selected reference, readout and physical refinement checks')
    pointwise=all(all_pass(row['report']['reduced_controls']) for row in selected.values())
    projections={label:row['report']['projection']['checks'] for label,row in selected.items() if 'projection' in row['report']}
    projection_pass=all_pass(projections)
    source_hashes[str(ROOT/'validation.json')]=digest(ROOT/'validation.json')
    source_hashes[str(ROOT/'independence.json')]=digest(ROOT/'independence.json')
    check_hashes(source_hashes)
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('selected-route-validation.json',dict(numerical_checks_passed=True,checks=checks,count=sum(len(group) for group in checks.values()),selected=selected,original_validation_passed=False,original_failure_keys=sorted(failures),repair='force integration stops at existing Hermite knots; no grid or tolerance change',all_pointwise_prediction_gates_passed=pointwise,all_projected_prediction_gates_passed=projection_pass,model_promoted=False,bound_values_claimed_converged=False,certified_continuum_bound=False,rest_history_prescribed=True,full_live_feedback=False,input_hashes=source_hashes))
    print(json.dumps(dict(numerical_checks_passed=True,checks=sum(len(group) for group in checks.values()),pointwise_passed=pointwise,projections_passed=projection_pass,original_failures_preserved=sorted(failures))),flush=True)


def seal():
    check_hashes(read(ROOT/'frozen-inputs.json'))
    selected=read(ROOT/'selected-route-validation.json')
    require(selected['numerical_checks_passed'],'selected numerical validation')
    check_hashes(selected['input_hashes'])
    for filename in ('RESULTS.md','DERIVATION.md','NEXT.md','PREDICTIVE-MEMORY-CORRECTION.md','ADMINISTRATIVE-PAUSE.md'):
        require((ROOT/filename).is_file(),'saved result and caveats '+filename)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    excluded={'closeout.json','selected-seal-end.json','selected-postseal-start.json','selected-postseal-end.json','CLEANUP-VERIFIED.json'}
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in excluded}
    write('closeout.json',dict(selected_numerical_route_validated=True,original_validation_passed=False,conditional_finite_time_test_completed=True,all_pointwise_prediction_gates_passed=selected['all_pointwise_prediction_gates_passed'],all_projected_prediction_gates_passed=selected['all_projected_prediction_gates_passed'],rest_history_prescribed=True,full_live_feedback=False,old_late_model_replaced=False,goal_complete=False,bound_values_claimed_converged=False,input_hashes=read(ROOT/'frozen-inputs.json'),artifacts=artifacts))
    print(json.dumps(dict(sealed=True,sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts))),flush=True)


def postseal(identity):
    sealed=read(ROOT/'closeout.json')
    check_hashes(sealed['input_hashes'])
    check_hashes({str(ROOT/name):row['sha256'] for name,row in sealed['artifacts'].items()})
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='selected-postseal-start.json':
            continue
        owner=read(path)
        ending=read(path.with_name(path.name.replace('-start.json','-end.json')))
        outcome=exited(owner)
        require(outcome['exited'],'prior task-owned process exited')
        require(all(ending[key]==owner[key] for key in ('pid','created','command')),'matching start/end identity')
        administrative=False
        if ending['state']!='completed':
            require(path.name=='cold-extraction-start.json','no undisclosed failed workers')
            require(owner['pid']==1836 and owner['created']==1794344336.8781765,'exact administrative stop owner')
            require(owner['command'][2:]==[str(ROOT/'run_propagation.py'),'run','--case','cold','--window','extraction'],'exact administrative stop command')
            require(ending['state']=='failed' and 'owner hold' in ending.get('error',''),'documented cooperative interruption')
            require(digest(ROOT/'cold-extraction-dense-step1.npz')=='b48dad8675498ac6ebc6b4f0ffd649bf22b4f86c9123610e642e79dfd61cec01','original completed packet preserved')
            administrative=True
        workers.append(dict(name=path.stem,identity=owner,outcome=outcome,recorded_state=ending['state'],documented_administrative_stop=administrative))
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    write('CLEANUP-VERIFIED.json',dict(passed=True,seal_sha256=digest(ROOT/'closeout.json'),workers=workers,verifier_identity=identity,verifier_exit_requires_final_external_check=True,no_continuing_worker_authorized=True,no_processes_killed=True))
    print(json.dumps(dict(passed=True,workers_exited=len(workers),verifier_pid=identity['pid'])),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('operation',choices=('validate','seal','postseal'))
    arguments=parser.parse_args()
    with worker('selected-'+arguments.operation) as identity:
        if arguments.operation=='postseal':
            postseal(identity)
        else:
            globals()[arguments.operation]()
