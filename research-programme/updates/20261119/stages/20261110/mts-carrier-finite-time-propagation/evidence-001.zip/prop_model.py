from prop_support import *
from scipy.interpolate import CubicHermiteSpline


class History:
    def __init__(self,case,window,stride):
        self.case=case
        self.window=window
        self.saved=packet(input_path(case,window))
        self.normal=packet(NORMAL/(case+'-'+window+'.npz'))
        self.times=self.saved['clock']
        self.first=source_first(case,window)
        self.density0=float(packet(PROJECTION/'frozen-projection.npz')['density0'])
        scale,rate,hubble,dilation=self.saved['extra'].T
        beta=scale/self.density0
        if case=='heavy' and window=='live':
            hubble_prime,dilation_prime=self.saved['metric_rates'].T
        else:
            derivative=packet(memory_path(case,window,'fine8'))
            require(np.array_equal(derivative['clock'],self.times),'saved derivative clocks')
            hubble_prime,dilation_prime=derivative['node_H_prime'],derivative['node_z_prime']
        if case=='heavy':
            field,velocity,field_first,velocity_first,mass2,frequency=self.saved['jets'][:,1].T
            self.mass=float(np.sqrt(mass2[0])/scale[0])
            require(comparison(np.sqrt(mass2)/scale,np.full(len(scale),self.mass),ALGEBRA)['passed'],'constant retained parent mass')
            mode,mode_velocity=self.saved['vector'][:,self.first+2:self.first+4].T
            mode_prime,mode_velocity_prime=self.saved['derivative'][:,self.first+2:self.first+4].T
            density=beta*(velocity*mode_velocity+mass2*field*mode)
            density_prime=rate*density+beta*(rate*velocity_first*mode_velocity+velocity*mode_velocity_prime+2*rate*mass2*field*mode+mass2*rate*field_first*mode+mass2*field*mode_prime)
            self.initial_primitive=np.array([mode[0],mode_velocity[0]])
        else:
            factor=beta*self.saved['observation'][:,12]
            self.factor=float(factor[0])
            require(comparison(factor,np.full(len(factor),self.factor),ALGEBRA)['passed'],'constant actual dust normalization')
            density=self.factor*self.saved['vector'][:,1]
            density_prime=self.factor*self.saved['derivative'][:,1]
            self.initial_primitive=np.array([density[0]])
        rest=dilation-density/(2*hubble*beta)
        rest_prime=dilation_prime-(density_prime-(rate+hubble_prime/hubble)*density)/(2*hubble*beta)
        selected=np.unique(np.r_[np.arange(0,len(scale),stride),len(scale)-1])
        epochs=self.times[selected]
        def spline(values,derivatives):
            return CubicHermiteSpline(epochs,values[selected],derivatives[selected],extrapolate=False)
        self.scale=spline(scale,scale*rate)
        self.hubble=spline(hubble,hubble_prime)
        self.rest=spline(rest,rest_prime)
        if case=='heavy':
            self.field=spline(field,rate*field_first)
            self.velocity=spline(velocity,rate*velocity_first)
        self.selected=selected
        self.original_density=density
        self.original_rest=rest
        self.original_rest_prime=rest_prime

    def evaluate(self,time):
        guard()
        require(self.times[0]-1e-12<=time<=self.times[-1]+1e-12,'conditional history interval')
        scale=float(self.scale(time))
        rate=float(self.scale(time,1))/scale
        beta=scale/self.density0
        hubble=float(self.hubble(time))
        hubble_prime=float(self.hubble(time,1))
        rest=float(self.rest(time))
        rest_prime=float(self.rest(time,1))
        require(np.isfinite(scale+hubble+rest+rest_prime) and scale>0 and hubble>0,'finite expanding history')
        if self.case=='cold':
            return dict(operator=np.array([[-self.factor/(2*hubble*beta)]]),force=np.array([-self.factor*rest]),beta=beta,hubble=hubble,rest=rest,rest_prime=rest_prime)
        field=float(self.field(time))
        velocity=float(self.velocity(time))
        field_prime=float(self.field(time,1))
        velocity_prime=float(self.velocity(time,1))
        mass=scale*self.mass
        frequency=np.sqrt(mass**2+1)
        summed=frequency+mass
        energy=beta*(velocity**2+mass**2*field**2)/2
        amplitude2=field**2+velocity**2/mass**2
        require(energy>0 and amplitude2>0,'nonzero parent field')
        theta=np.arctan2(-velocity/mass,field)
        theta_prime=(field*(-velocity_prime/mass+rate*velocity/mass)+(velocity/mass)*field_prime)/amplitude2
        energy_prime=rate*energy+beta*(velocity*velocity_prime+mass**2*field*field_prime+rate*mass**2*field**2)
        parameters=np.array([mass,hubble,energy,beta])
        parameter_rates=np.array([rate*mass,hubble_prime,energy_prime,rate*beta])
        transform=np.eye(3)+micromotion(theta,parameters)
        transform_prime=micromotion_prime(theta,parameters,theta_prime,parameter_rates)
        mean,commutator,drift=effective(parameters)
        generator=mean+commutator+drift
        response=np.linalg.solve(transform,np.array([0.,0.,rest_prime]))[:2]
        exact_operator=np.array([[0.,1.],[-frequency**2-mass**2*field*velocity/(2*hubble),-2*hubble-velocity**2/(2*hubble)]])
        exact_force=np.array([0.,-velocity*rest])
        density_factor=beta*mass*summed/2
        current_factor=beta*mass/2
        density_rate=rate*(2+mass/frequency)
        denominator_rate=rate*(1+mass**2/frequency**2)
        mapping=np.array([[density_factor*field,density_factor*velocity/(mass*frequency)],[current_factor*velocity/mass,-current_factor*field/frequency]])
        mapping_prime=np.array([[density_factor*(field_prime+density_rate*field),density_factor*(velocity_prime+(density_rate-denominator_rate)*velocity)/(mass*frequency)],[current_factor*(velocity_prime+rate*velocity)/mass,-current_factor*(field_prime+rate*(2-mass**2/frequency**2)*field)/frequency]])
        physical_readout=beta*np.array([[mass**2*field,velocity],[velocity,0.],[-mass**2*field,velocity]])
        return dict(operator=exact_operator,force=exact_force,mapping=mapping,mapping_prime=mapping_prime,transform=transform,transform_prime=transform_prime,generator=generator[:2,:2],forcing=generator[:2,2]*rest+response,rest=rest,rest_prime=rest_prime,physical_readout=physical_readout,parameters=parameters,theta=theta)

    def reduced_state(self,values,primitive):
        return np.linalg.solve(values['transform'],np.r_[values['mapping']@primitive,values['rest']])[:2]

    def exact_reduced_rate(self,values,primitive,primitive_rate,reduced):
        physical_rate=values['mapping_prime']@primitive+values['mapping']@primitive_rate
        return np.linalg.solve(values['transform'],np.r_[physical_rate,values['rest_prime']]-values['transform_prime']@np.r_[reduced,values['rest']])[:2]

    def initial(self):
        values=self.evaluate(float(self.times[0]))
        if self.case=='cold':
            return self.initial_primitive.copy()
        reduced=self.reduced_state(values,self.initial_primitive)
        return np.r_[self.initial_primitive,reduced,np.zeros(4)]

    def rhs(self,time,state):
        values=self.evaluate(time)
        if self.case=='cold':
            return values['operator']@state+values['force']
        primitive=state[:2]
        reduced=state[2:4]
        defect_response=state[4:6]
        bound=state[6:8]
        primitive_rate=values['operator']@primitive+values['force']
        reduced_rate=values['generator']@reduced+values['forcing']
        exact_reduced=self.reduced_state(values,primitive)
        exact_reduced_rate=self.exact_reduced_rate(values,primitive,primitive_rate,exact_reduced)
        defect=exact_reduced_rate-values['generator']@exact_reduced-values['forcing']
        defect_rate=values['generator']@defect_response+defect
        majorant=abs(values['generator'])
        np.fill_diagonal(majorant,np.diag(values['generator']))
        bound_rate=majorant@bound+abs(defect)
        return np.r_[primitive_rate,reduced_rate,defect_rate,bound_rate]
