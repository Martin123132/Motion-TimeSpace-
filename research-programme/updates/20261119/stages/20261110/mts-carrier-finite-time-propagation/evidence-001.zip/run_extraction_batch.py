import argparse
from prop_support import *
import run_propagation as driver


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('config',choices=('dense-step1','dense-step2','sparse-step2','collect'))
    arguments=parser.parse_args()
    with worker('heavy-extraction-'+arguments.config):
        check_hashes(read(ROOT/'frozen-inputs.json'))
        config_names=[row['name'] for row in read(ROOT/'contract.json')['configs']]
        if arguments.config=='collect':
            reports={}
            for config in config_names:
                child=read(ROOT/('heavy-extraction-'+config+'-result.json'))
                require(child['completed'] and list(child['runs'])==[config],'completed exact batch')
                reports[config]=child['runs'][config]
            write('heavy-extraction-result.json',dict(completed=True,reference_passed=all(row['reference_passed'] for row in reports.values()),runs=reports,reduced_model_promoted=False,batching_only=True))
            print(json.dumps(dict(collected=True,configs=config_names)),flush=True)
        else:
            receipt=dict(script_sha256=digest(Path(__file__)),original_driver_sha256=digest(ROOT/'run_propagation.py'),config=arguments.config,physics_and_gates_changed=False,reason='one unchanged configuration per 900-second worker; long-window computation is larger than short live test')
            write('heavy-extraction-'+arguments.config+'-dispatch.json',receipt)
            retained_read=driver.read
            retained_write=driver.write
            def selected_read(path):
                value=retained_read(path)
                if Path(path)==ROOT/'contract.json':
                    value=dict(value,configs=[row for row in value['configs'] if row['name']==arguments.config])
                return value
            def selected_write(name,value):
                if name=='heavy-extraction-result.json':
                    name='heavy-extraction-'+arguments.config+'-result.json'
                retained_write(name,value)
            driver.read=selected_read
            driver.write=selected_write
            driver.run('heavy','extraction')
