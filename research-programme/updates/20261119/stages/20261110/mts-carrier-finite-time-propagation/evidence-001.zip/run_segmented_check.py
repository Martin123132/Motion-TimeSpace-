import argparse
from types import SimpleNamespace
from prop_support import *
import guarded_batch
import run_propagation as driver
from scipy.integrate import solve_ivp as integrate_interval


def segmented_solve(function,span,initial,**options):
    times=np.asarray(options.pop('t_eval'))
    require(times[0]==span[0] and times[-1]==span[1],'same original output interval')
    state=np.asarray(initial).copy()
    history=[state.copy()]
    evaluations=0
    for left,right in zip(times[:-1],times[1:]):
        guarded_batch.paced_guard()
        solved=integrate_interval(function,(left,right),state,t_eval=[right],**options)
        require(solved.success,'segmented interval completes')
        state=solved.y[:,-1]
        history.append(state.copy())
        evaluations+=solved.nfev
    return SimpleNamespace(success=True,y=np.array(history).T,nfev=evaluations)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=('cold','heavy'))
    parser.add_argument('--step-divisor',type=int,choices=(1,2),default=2)
    arguments=parser.parse_args()
    name='dense-step'+str(arguments.step_divisor)+'-segmented'
    with worker(arguments.case+'-extraction-'+name):
        check_hashes(read(ROOT/'frozen-inputs.json'))
        write(arguments.case+'-extraction-'+name+'-contract.json',dict(adapter_sha256=digest(Path(__file__)),guard_adapter_sha256=digest(ROOT/'guarded_batch.py'),hypothesis='global adaptive steps across cubic-Hermite source knots limit the strict accumulated chain identity; test exact interval endpoints without changing tolerances',original_max_step_divisor=arguments.step_divisor,history_stride=1,output_grid_parameters_and_gates_changed=False,original_failed_diagnostic_preserved=True))
        original_read=driver.read
        original_write=driver.write
        def selected_read(path):
            value=original_read(path)
            if Path(path)==ROOT/'contract.json':
                value=dict(value,configs=[dict(name=name,stride=1,step_divisor=arguments.step_divisor)])
            return value
        def selected_write(filename,value):
            if filename==arguments.case+'-extraction-result.json':
                filename=arguments.case+'-extraction-'+name+'-result.json'
            original_write(filename,value)
        driver.read=selected_read
        driver.write=selected_write
        driver.solve_ivp=segmented_solve
        driver.run(arguments.case,'extraction')
