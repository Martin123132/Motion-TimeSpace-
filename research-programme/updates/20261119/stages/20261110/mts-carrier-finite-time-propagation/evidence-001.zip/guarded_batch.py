import argparse
from prop_support import *
import prop_model as model
import run_propagation as driver


retained_guard=model.guard
last_check=[-float('inf')]


def paced_guard():
    current=monotonic()
    if current-last_check[0]>=1:
        retained_guard()
        last_check[0]=current


model.guard=paced_guard


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=('cold','heavy'))
    parser.add_argument('config',choices=('dense-step1','dense-step2','sparse-step2','recover','collect'))
    arguments=parser.parse_args()
    with worker(arguments.case+'-extraction-'+arguments.config+'-guarded'):
        check_hashes(read(ROOT/'frozen-inputs.json'))
        configs=read(ROOT/'contract.json')['configs']
        if arguments.config=='recover':
            require(arguments.case=='cold','only documented completed cold packet can be recovered')
            ending=read(ROOT/'cold-extraction-end.json')
            require(ending['state']=='failed' and 'owner hold' in ending['error'] and str(ROOT).replace('\\','\\\\') in ending['error'],'documented cooperative interruption')
            require(exited(ending)['exited'],'interrupted worker exited')
            path=ROOT/'cold-extraction-dense-step1.npz'
            require(digest(path)=='b48dad8675498ac6ebc6b4f0ffd649bf22b4f86c9123610e642e79dfd61cec01','completed packet preserved')
            data=packet(path)
            history=driver.History('cold','extraction',1)
            require(np.array_equal(data['clock'],history.times),'complete original output grid')
            ignored,report=driver.score(history,data['solution'])
            require(report['reference_passed'],'recovered conditional reference verifies')
            report.update(packet_sha256=digest(path),nfev=94304,maximum_step=float(np.min(np.diff(history.times))),recovered_completed_packet=True,nfev_source='captured original completed-config stdout before cooperative stop')
            write('cold-extraction-dense-step1-result.json',dict(completed=True,reference_passed=report['reference_passed'],runs={'dense-step1':report},reduced_model_promoted=False))
            print(json.dumps(dict(recovered=True,rerun=False,sha256=digest(path))),flush=True)
        elif arguments.config=='collect':
            reports={}
            for config in configs:
                name=config['name']
                child=read(ROOT/(arguments.case+'-extraction-'+name+'-result.json'))
                require(child['completed'] and list(child['runs'])==[name],'completed configuration')
                reports[name]=child['runs'][name]
            write(arguments.case+'-extraction-result.json',dict(completed=True,reference_passed=all(row['reference_passed'] for row in reports.values()),runs=reports,reduced_model_promoted=False,batched=True))
            print(json.dumps(dict(collected=True,case=arguments.case)),flush=True)
        else:
            require(not (ROOT/(arguments.case+'-extraction-'+arguments.config+'.npz')).exists(),'never overwrite completed calculation')
            write(arguments.case+'-extraction-'+arguments.config+'-guard-contract.json',dict(adapter_sha256=digest(Path(__file__)),driver_sha256=digest(ROOT/'run_propagation.py'),config=arguments.config,filesystem_guard_cadence_seconds=1,worker_deadline_seconds=900,physical_rhs_steps_grids_parameters_and_tolerances_changed=False))
            retained_read=driver.read
            retained_write=driver.write
            def selected_read(path):
                value=retained_read(path)
                if Path(path)==ROOT/'contract.json':
                    value=dict(value,configs=[row for row in value['configs'] if row['name']==arguments.config])
                return value
            def selected_write(name,value):
                if name==arguments.case+'-extraction-result.json':
                    name=arguments.case+'-extraction-'+arguments.config+'-result.json'
                retained_write(name,value)
            driver.read=selected_read
            driver.write=selected_write
            driver.run(arguments.case,'extraction')
