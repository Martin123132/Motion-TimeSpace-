from prop_model import *


with worker('independence'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks={}
    bound_diagnostics={}
    historical_pressure={}
    source_hashes={str(Path(__file__)):digest(Path(__file__))}
    for window in ('live','extraction'):
        history=History('heavy',window,1)
        paths={name:ROOT/('heavy-'+window+'-'+name+'.npz') for name in ('dense-step1','dense-step2','sparse-step2')}
        packets={name:packet(path) for name,path in paths.items()}
        source_hashes.update({str(path):digest(path) for path in paths.values()})
        fine=packets['dense-step2']
        for index in (0,len(history.times)//2,len(history.times)-1):
            time=float(history.times[index])
            state=fine['solution'][index].copy()
            reference=history.rhs(time,state)
            changed=state.copy()
            changed[:2]*=1.2
            changed[4:]+=np.array([.1,-.2,.3,.4])
            mutated=history.rhs(time,changed)
            changed_reduced=state.copy()
            changed_reduced[2:4]+=np.array([.07,-.03])
            mutated_reduced=history.rhs(time,changed_reduced)
            checks[window+'/'+str(index)]=dict(no_reference_or_defect_leak=comparison(mutated[2:4],reference[2:4],ALGEBRA),no_reduction_feedback_into_reference=comparison(mutated_reduced[:2],reference[:2],ALGEBRA))
        bound_diagnostics[window]={name:columns(data['solution'][:,6:8],fine['solution'][:,6:8],'envelope_',GATE) for name,data in packets.items() if name!='dense-step2'}
        if window=='extraction':
            frozen=packet(PROJECTION/'frozen-projection.npz')
            projected=frozen['weights']@fine['predicted_physical']
            target=frozen['weights']@history.normal['physical']
            error=abs(float(projected[2]-target[2]))
            historical_pressure=dict(error=error,original_mode_norm=float(frozen['original_norm']),mode_normalized_error=error/float(frozen['original_norm']),historical_gate=2e-6,historical_gate_passed=bool(error/float(frozen['original_norm'])<=2e-6),role='context only; does not replace this stage frozen relative-stress and projection diagnostics')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(source_hashes)
    require(all_pass(checks),'no diagnostic-channel leakage into forward prediction')
    write('independence.json',dict(passed=True,checks=checks,count=sum(len(group) for group in checks.values()),bound_refinements=bound_diagnostics,bound_values_claimed_converged=all(all_pass(groups) for groups in bound_diagnostics.values()),historical_pressure_context=historical_pressure,input_hashes=source_hashes))
    print(json.dumps(dict(passed=True,checks=sum(len(group) for group in checks.values()),bound_values_claimed_converged=all(all_pass(groups) for groups in bound_diagnostics.values()),historical_pressure_context=historical_pressure),default=convert),flush=True)
