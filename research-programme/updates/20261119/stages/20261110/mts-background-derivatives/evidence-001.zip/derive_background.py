from common import *
import sympy as sym


def derive():
    hubble, hubble_prime, mass, field, speed = sym.symbols("hubble hubble_prime mass field speed")
    rates = {hubble: hubble_prime, mass: hubble * mass, field: speed, speed: -2 * hubble * speed - mass**2 * field}
    derivative = lambda value: sum(sym.diff(value, variable) * rate for variable, rate in rates.items())
    density = (speed**2 + mass**2 * field**2) / 2
    pressure = (speed**2 - mass**2 * field**2) / 2
    pressure_prime = -2 * hubble * speed**2 - hubble * mass**2 * field**2 - 2 * mass**2 * field * speed
    pressure_second = (-2 * hubble_prime + 8 * hubble**2 - 2 * mass**2) * speed**2 + (-hubble_prime * mass**2 - 2 * hubble**2 * mass**2 + 2 * mass**4) * field**2 + 2 * hubble * mass**2 * field * speed
    identities = {}

    def exact(name, expression):
        guard()
        result = str(sym.factor(expression))
        if result != "0":
            raise ValueError(name + ": " + result)
        identities[name] = result

    exact("scalar energy conservation", derivative(density) + hubble * (density + 3 * pressure))
    exact("scalar pressure derivative", derivative(pressure) - pressure_prime)
    exact("scalar second pressure derivative", derivative(pressure_prime) - pressure_second)
    total_density, total_pressure = sym.symbols("total_density total_pressure")
    density_prime = -hubble * (total_density + 3 * total_pressure)
    exact("Friedmann constraint propagated", density_prime - 6 * hubble * (-(total_density + 3 * total_pressure) / 6))

    ratio, expansion, acceleration, jerk, snap = sym.symbols("ratio expansion acceleration jerk snap", real=True)
    rate_map = {ratio: -expansion * (ratio**2 - 1) / ratio, expansion: acceleration - expansion**2,
                acceleration: jerk - 2 * expansion * acceleration, jerk: snap - 3 * expansion * jerk}
    operator = lambda value: sum(sym.diff(value, variable) * rate for variable, rate in rate_map.items())
    frequency = ratio - acceleration * (2 * ratio**2 + 1) / (4 * ratio**3) - expansion**2 * (4 * ratio**4 + 4 * ratio**2 - 5) / (8 * ratio**5)
    first = sym.factor(expansion * frequency + operator(frequency))
    second = sym.factor(2 * expansion * first + operator(first))
    original_omega_prime = expansion / ratio
    original_omega_second = sym.factor(2 * expansion * original_omega_prime + operator(original_omega_prime))
    construction = ratio + (-acceleration - expansion**2 - original_omega_second / (2 * ratio) + sym.Rational(3, 4) * (original_omega_prime / ratio)**2) / (2 * ratio)
    exact("second-adiabatic construction", frequency - construction)
    residual = sym.factor(sym.cancel(ratio**2 - acceleration - expansion**2 - frequency**2 - second / (2 * frequency) + sym.Rational(3, 4) * (first / frequency)**2))
    numerator, denominator = sym.fraction(residual)
    dust = {ratio: 1, acceleration: -expansion**2 / 2, jerk: expansion**3 / 2, snap: -3 * expansion**4 / 4}
    exact("dust homogeneous frequency", frequency.subs(dust, simultaneous=True) - 1)
    exact("dust homogeneous exact residual", residual.subs(dust, simultaneous=True))
    exact("radiation homogeneous correction", frequency.subs({ratio: 1, acceleration: -expansion**2}, simultaneous=True) - 1 - 3 * expansion**2 / 8)
    constant_h = frequency.subs(acceleration, 0)
    exact("constant-H reduction", constant_h - ratio + expansion**2 * (4 * ratio**4 + 4 * ratio**2 - 5) / (8 * ratio**5))
    exact("zero expansion flat limit", frequency.subs({expansion: 0, acceleration: 0}, simultaneous=True) - ratio)
    return dict(identities=identities, variables=[str(value) for value in (ratio, expansion, acceleration, jerk, snap)],
                frequency=str(frequency), first_derivative=str(first), second_derivative=str(second),
                residual_numerator=str(numerator), residual_denominator=str(denominator),
                residual_terms=len(sym.Poly(numerator, ratio, expansion, acceleration, jerk, snap).terms()),
                derivative_scope="mu'=Hmu; full H',H'',H''' retained; piecewise background functions")


if __name__ == "__main__":
    with worker("proof"):
        sources = preserved_sources()
        formulas = derive()
        result = dict(passed=True, formula=formulas, sources=sources, code_sha256=digest(__file__),
                      common_sha256=digest(ROOT / "common.py"), protocol_sha256=digest(ROOT / "PROTOCOL.md"),
                      derivation_sha256=digest(ROOT / "DERIVATION.md"))
        write("proof.json", result)
        print(json.dumps(dict(identities=len(formulas["identities"]), residual_terms=formulas["residual_terms"], sources=len(sources))))
