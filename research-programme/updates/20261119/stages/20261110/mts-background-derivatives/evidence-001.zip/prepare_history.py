from common import *
import numpy as np
import sympy as sym
import mpmath as mp
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp

CHECKS = []
CENTER = -np.log(11.)
OFFSETS = np.array([-.004, -.002, -.001, 0., .001, .002, .004])


def check(name, error, gate=ALGEBRA):
    error = float(error)
    if not np.isfinite(error) or abs(error) > gate:
        raise ValueError(name + ": " + str(error))
    CHECKS.append(dict(name=name, error=error, gate=gate, passed=True))


def half_ulp(values):
    single = np.asarray(values, dtype=np.float32)
    return .5 * np.maximum(abs(np.nextafter(single, np.float32(np.inf)).astype(float) - single.astype(float)),
                           abs(single.astype(float) - np.nextafter(single, np.float32(-np.inf)).astype(float)))


def load_history(model, background):
    chunks, modes, paths = [], [], []
    selected_times, selected_requested, names = None, None, None
    for path in sorted((SPECTRUM / "runs" / model).glob("chunk-*.npz")):
        guard()
        with np.load(path) as packet:
            packet_names = packet["names"].tolist()
            if names is not None and names != packet_names:
                raise ValueError("column contract changed")
            names = packet_names
            indices = [int(np.argmin(abs(np.log(packet["requested_scale"]) - CENTER - offset))) for offset in OFFSETS]
            check(model + " original requested offsets " + path.name, np.max(abs(np.log(packet["requested_scale"][indices]) - CENTER - OFFSETS)))
            if selected_times is None:
                selected_times = packet["conformal_time"][indices].copy()
                selected_requested = packet["requested_scale"][indices].copy()
            else:
                check(model + " identical packet clock " + path.name, np.max(abs(packet["conformal_time"][indices] - selected_times)))
            valid = packet["modes"] <= 5
            chunks.append(packet["values"][valid][:, indices, :].copy())
            modes.append(packet["modes"][valid].copy())
            paths.append(str(path))
    raw, wave = np.concatenate(chunks), np.concatenate(modes)
    if len(wave) != 399 or raw.shape[:2] != (399, 7):
        raise ValueError("fixed history coverage")
    get = lambda name: raw[:, :, names.index(name)]
    scale, hubble, velocity, weyl = (get(name) for name in ("a", "H", "v_newtonian_cdm", "Weyl"))
    alpha = -hubble * velocity / wave[:, None]**2
    potential = get("etak") / wave[:, None] - hubble * alpha
    lapse = 2 * weyl / wave[:, None]**2 - potential
    alpha_radius = abs(hubble) * half_ulp(velocity) / wave[:, None]**2
    potential_radius = abs(hubble) * alpha_radius
    lapse_radius = 2 * half_ulp(weyl) / wave[:, None]**2 + potential_radius
    if model == "heavy":
        if not np.all(get("mts_averaged_chart") == 1):
            raise ValueError("late chart changed")
        source_scale = float(background["matching_density"]) / scale
        density = get("mts_drho_h") / source_scale - 3 * hubble * alpha
        current = get("mts_q_h") / source_scale + wave[:, None] * alpha
        pressure = get("mts_dp_h") / source_scale
    else:
        density = get("delta_cdm") - 3 * hubble * alpha
        current = wave[:, None] * alpha
        pressure = np.zeros_like(density)
    result = dict(wave=wave, raw_names=np.array(names), raw_values=raw, requested_scale=selected_requested,
                  conformal_time=selected_times, actual_scale=scale, native_hubble=hubble, alpha=alpha,
                  potential=potential, lapse=lapse, alpha_rounding=alpha_radius,
                  potential_rounding=potential_radius, lapse_rounding=lapse_radius,
                  density=density, current=current, pressure=pressure,
                  physical_field_phase_supplied=np.array(False), original_offsets=OFFSETS)
    return result, paths


class Background:
    def __init__(self, table, species, unit):
        self.table, self.species, self.unit = table, species, unit
        self.mass = float(table["slow_mass_mpc"])
        self.heavy_mass = float(table["heavy_mass_mpc"])
        self.dust = float(table["matching_density"]) if "matching_density" in table else 0.
        self.field = CubicSpline(table["efold"], table["phi_s"])
        self.speed = CubicSpline(table["efold"], table["phidot_s"])

    def parts(self, efold, field, speed):
        scale = np.exp(efold)
        unit_squared = 3 * self.unit**2
        dust = unit_squared * self.species.matter / scale + self.dust / scale
        radiation = unit_squared * self.species.radiation / scale**2
        nu_log = self.species.nu_log
        logarithm, slope, curvature, third = (nu_log(efold, order) for order in range(4))
        neutrino = unit_squared * np.exp(logarithm - 2 * efold)
        nu_slope = slope - 2
        nu_w = (1 - slope) / 3
        nu_pressure_n = neutrino * (nu_slope * nu_w - curvature / 3)
        nu_pressure_nn = neutrino * ((nu_slope**2 + curvature) * nu_w - 2 * nu_slope * curvature / 3 - third / 3)
        mass = scale * self.mass
        scalar_density = (speed**2 + mass**2 * field**2) / 2
        scalar_pressure = (speed**2 - mass**2 * field**2) / 2
        density = dust + radiation + neutrino + scalar_density
        pressure = radiation / 3 + neutrino * nu_w + scalar_pressure
        return density, pressure, radiation, nu_pressure_n, nu_pressure_nn, mass

    def jets(self, efold, field, speed, hubble):
        density, pressure, radiation, nu_pressure_n, nu_pressure_nn, mass = self.parts(efold, field, speed)
        first = -(density + 3 * pressure) / 6
        scalar_first = -2 * hubble * speed**2 - hubble * mass**2 * field**2 - 2 * mass**2 * field * speed
        pressure_first = -2 * hubble * radiation / 3 + hubble * nu_pressure_n + scalar_first
        density_first = -hubble * (density + 3 * pressure)
        second = -(density_first + 3 * pressure_first) / 6
        scalar_second = (-2 * first + 8 * hubble**2 - 2 * mass**2) * speed**2 + (-first * mass**2 - 2 * hubble**2 * mass**2 + 2 * mass**4) * field**2 + 2 * hubble * mass**2 * field * speed
        pressure_second = (-2 * first + 4 * hubble**2) * radiation / 3 + hubble**2 * nu_pressure_nn + first * nu_pressure_n + scalar_second
        density_second = -first * (density + 3 * pressure) - hubble * (density_first + 3 * pressure_first)
        third = -(density_second + 3 * pressure_second) / 6
        return np.asarray([hubble, first, second, third, density, pressure, pressure_first, pressure_second])

    def solve(self, tolerance):
        field, speed = float(self.field(CENTER)), float(self.speed(CENTER))
        hubble = float(np.sqrt(self.parts(CENTER, field, speed)[0] / 3))
        initial = np.array([field, speed, hubble, 0.])
        normalization = np.array([max(abs(field), 1e-100), max(abs(speed), 1e-100), hubble, SPAN / hubble])

        def rhs(offset, normalized):
            guard()
            field, speed, hubble, _ = normalized * normalization
            scale = np.exp(CENTER + offset)
            first = self.jets(CENTER + offset, field, speed, hubble)[1]
            return np.array([speed / hubble, -2 * speed - (scale * self.mass)**2 * field / hubble,
                             first / hubble, 1 / hubble]) / normalization

        solved = solve_ivp(rhs, (0, SPAN), initial / normalization, method="DOP853", rtol=tolerance,
                           atol=tolerance / 100, dense_output=True)
        if not solved.success:
            raise ValueError(solved.message)
        return solved, normalization


def background_checks(model, owner, history):
    coarse, normalization = owner.solve(2e-11)
    fine, fine_normalization = owner.solve(2e-12)
    positions = np.linspace(0, SPAN, 33)
    states = fine.sol(positions).T * normalization
    coarse_states = coarse.sol(positions).T * normalization
    refinement = float(np.max(abs((states - coarse_states) / normalization)))
    check(model + " background tolerance comparison", refinement, GATE)
    efolds = CENTER + positions
    jets = owner.jets(efolds, states[:, 0], states[:, 1], states[:, 2]).T
    constraint = float(np.max(abs(jets[:, 4] / (3 * states[:, 2]**2) - 1)))
    check(model + " propagated Friedmann constraint", constraint, ALGEBRA)
    table_field, table_speed = owner.field(efolds), owner.speed(efolds)
    table_error = float(np.max(abs((states[:, :2] - np.column_stack((table_field, table_speed))) / normalization[:2])))
    check(model + " saved slow background", table_error, GATE)
    actual_efolds = np.log(history["actual_scale"])
    field, speed = owner.field(actual_efolds), owner.speed(actual_efolds)
    reconstructed_hubble = np.sqrt(owner.parts(actual_efolds, field, speed)[0] / 3)
    native_error = float(np.max(abs(reconstructed_hubble / history["native_hubble"] - 1)))
    check(model + " all399x7native background values", native_error, GATE)
    interval = float(history["conformal_time"][4] - history["conformal_time"][3])
    clock_error = abs(float(states[-1, 3] / interval - 1))
    check(model + " saved conformal interval", clock_error, GATE)
    derivative_controls = []
    for location in (.00025, .0005, .00075):
        for step in (1e-5, 5e-6):
            sample = np.array([location - step, location, location + step])
            probe = fine.sol(sample).T * normalization
            test_jets = owner.jets(CENTER + sample, probe[:, 0], probe[:, 1], probe[:, 2]).T
            inferred = (test_jets[2, :3] - test_jets[0, :3]) / (2 * step) * test_jets[1, 0]
            scales = abs(test_jets[1, 0])**np.array([2, 3, 4])
            errors = abs(inferred - test_jets[1, 1:4]) / scales
            check(model + " independent jet difference " + str((location, step)), np.max(errors), GATE)
            derivative_controls.append(dict(position=location, step=step, errors=errors.tolist()))
    return dict(position=positions, states=states, jets=jets, normalization=normalization,
                coarse_states=coarse_states), dict(model=model, refinement=refinement, friedmann=constraint,
                saved_slow_error=table_error, native_hubble_error=native_error, clock_error=clock_error,
                evaluations=[coarse.nfev, fine.nfev], derivative_controls=derivative_controls,
                Hprime_over_H2_range=[float(np.min(jets[:, 1] / jets[:, 0]**2)), float(np.max(jets[:, 1] / jets[:, 0]**2))])


def residual_diagnostics(proof, background, wave, mass):
    formula = proof["formula"]
    symbols = sym.symbols(" ".join(formula["variables"]), real=True)
    local = dict(zip(formula["variables"], symbols))
    numerator = sym.sympify(formula["residual_numerator"], locals=local)
    denominator = sym.sympify(formula["residual_denominator"], locals=local)
    residual_function = sym.lambdify(symbols, numerator / denominator, "numpy", cse=True)
    high_function = sym.lambdify(symbols, numerator / denominator, "mpmath", cse=True)
    positions, jets = background["position"], background["jets"]
    mu = np.exp(CENTER + positions) * mass
    reduced = np.column_stack([jets[:, order] / mu**(order + 1) for order in range(4)])
    ratio = np.sqrt(1 + (wave[None, :] / mu[:, None])**2)
    residual = residual_function(ratio, *[reduced[:, index, None] for index in range(4)])
    frequency = ratio - reduced[:, 1, None] * (2 * ratio**2 + 1) / (4 * ratio**3) - reduced[:, 0, None]**2 * (4 * ratio**4 + 4 * ratio**2 - 5) / (8 * ratio**5)
    if not np.isfinite(residual).all() or not np.all(frequency > 0):
        raise ValueError("sampled W2 invalid")
    homogeneous_correction = -3 * (2 * jets[:, 1] + jets[:, 0]**2) / (8 * mu**2)
    frozen_correction = -3 * jets[:, 0]**2 / (8 * mu**2)
    high_checks = []
    with mp.workdps(60):
        for epoch in (0, 16, 32):
            for target in (1e-5, .1, 5):
                index = int(np.argmin(abs(wave - target)))
                true_ratio = mp.sqrt(1 + (mp.mpf(float(wave[index])) / mp.mpf(float(mu[epoch])))**2)
                values = [mp.mpf(float(value)) for value in reduced[epoch]]
                exact = high_function(true_ratio, *values)
                scale = abs(values[0])**4 + values[1]**2 + abs(values[0] * values[2]) + abs(values[3])
                error = float(abs(mp.mpf(float(residual[epoch, index])) - exact) / scale)
                check("60digit stable residual " + str((epoch, target)), error, ALGEBRA)
                high_checks.append(dict(epoch=epoch, wave=float(wave[index]), absolute_scaled_error=error))
    return dict(mu=mu, reduced_jets=reduced, residual_over_mu2=residual, frequency_over_mu=frequency,
                homogeneous_correction=homogeneous_correction, frozen_correction=frozen_correction), dict(
                maximum_sampled_residual_over_mu2=float(np.max(abs(residual))),
                maximum_sampled_residual_rate=float(np.max(abs(residual) * mu[:, None] / frequency)),
                correction_to_frozen_range=[float(np.min(homogeneous_correction / frozen_correction)),
                                            float(np.max(homogeneous_correction / frozen_correction))],
                high_precision_controls=high_checks, interval_certificate=False)


def main():
    with worker("background"):
        proof = read(ROOT / "proof.json")
        for path, expected in proof["sources"].items():
            guard()
            if digest(path) != expected:
                raise ValueError("source changed " + path)
        sys.path.insert(0, str(MATCHING))
        import matching_common as retained
        if not Path(retained.camb.__file__).resolve().is_relative_to(MATCHING / "native"):
            raise ValueError("wrong native library")
        omega_m, _ = retained.previous.inherited_parameters()
        unit = retained.previous.H0 / retained.previous.C_LIGHT
        reports, outputs = [], []
        for model in ("heavy", "cold"):
            path = SPECTRUM / "runs/projection/a225-w6-d8.npz" if model == "heavy" else EARLY / "runs/backgrounds/cold.npz"
            with np.load(path) as packet:
                table = {name: packet[name].copy() for name in packet.files}
            species = retained.previous.StandardSpecies(omega_m, float(table["fraction"]))
            owner = Background(table, species, unit)
            history, paths = load_history(model, table)
            background, report = background_checks(model, owner, history)
            diagnostics, diagnostic_report = residual_diagnostics(proof, background, history["wave"], owner.heavy_mass)
            np.savez_compressed(ROOT / (model + "-history.npz"), **history)
            np.savez_compressed(ROOT / (model + "-background.npz"), **background, **diagnostics,
                                standard_matter=species.matter, standard_radiation=species.radiation,
                                nu_knots=species.nu_log.x, nu_coefficients=species.nu_log.c,
                                slow_mass=owner.mass, heavy_mass=owner.heavy_mass, matching_density=owner.dust, unit=unit)
            report.update(diagnostics=diagnostic_report, background_source=str(path), background_source_sha256=digest(path),
                          source_packets=paths, source_count=len(paths), standard_species_coefficients=species.coefficients)
            reports.append(report)
            outputs.extend([model + "-history.npz", model + "-background.npz"])
            print(json.dumps(report), flush=True)
        result = dict(passed=True, models=reports, checks=CHECKS, source_count=len(proof["sources"]),
                      outputs={name: digest(ROOT / name) for name in outputs},
                      code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"),
                      protocol_sha256=digest(ROOT / "PROTOCOL.md"), proof_sha256=digest(ROOT / "proof.json"),
                      native_module_path=retained.camb.__file__, full_perturbation_run=False,
                      sampled_residual_not_interval_certificate=True, changing_metric_prepared_not_yet_propagated=True)
        write("background-result.json", result)


if __name__ == "__main__":
    main()
