import os
import sys
for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[key] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PRIOR = POST / "mts-metric-forcing-calibration-20261110"
BRANCH = POST / "condensate-origin-20261003"
MATCHING = BRANCH / "native-heavy-matching-20261007"
SPECTRUM = BRANCH / "resolved-matter-spectrum-20261007"
EARLY = BRANCH / "native-two-field-transfer-20261007"
ALGEBRA, GATE, SPAN = 1e-10, 2e-5, .001
START = time.monotonic()


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(name, value):
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


def guard():
    if time.monotonic() - START > 900:
        raise RuntimeError("bounded worker deadline")
    for parent in (ROOT, POST):
        if (parent / "STOP-REQUESTED").exists():
            raise RuntimeError("owner hold")


@contextmanager
def worker(prefix):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    guard()
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(),
                    started=datetime.now(timezone.utc).isoformat())
    write(prefix + "-start.json", identity)
    try:
        yield identity
    except Exception as error:
        write(prefix + "-end.json", dict(**identity, state="failed", error=repr(error)))
        raise
    else:
        write(prefix + "-end.json", dict(**identity, state="completed", elapsed=time.monotonic() - START))


def preserved_sources():
    if digest(PRIOR / "closeout.json") != "d556304bd696093ea4154796bf19259da5bc026ce195b78f6efc63119c422aae":
        raise ValueError("prior seal changed")
    closeout = read(PRIOR / "closeout.json")
    sources = dict(closeout["input_hashes"])
    sources[str(PRIOR / "closeout.json")] = digest(PRIOR / "closeout.json")
    for name, entry in closeout["artifacts"].items():
        sources[str(PRIOR / name)] = entry["sha256"]
    for model in ("heavy", "cold"):
        status_path = SPECTRUM / "runs" / model / "status.json"
        status = read(status_path)
        if status["state"] != "complete" or status["completed"] != 412:
            raise ValueError("original history incomplete")
        sources[str(status_path)] = digest(status_path)
        sources.update(status["input_hashes"])
    for path, expected in sources.items():
        guard()
        if digest(path) != expected:
            raise ValueError("changed input " + path)
    return sources
