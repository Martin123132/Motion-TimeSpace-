from common import *
import ast
import numpy as np
import sympy as sym


def pressure_identities():
    hubble, pressure, mass, wave, ratio = sym.symbols("hubble pressure mass wave ratio", nonzero=True)
    omega = sym.sqrt(mass**2 + wave**2)
    hubble_prime = -(hubble**2 + pressure) / 2
    general = omega - hubble_prime * (2 * wave**2 + 3 * mass**2) / (4 * omega**3) - hubble**2 * (4 * wave**4 + 12 * wave**2 * mass**2 + 3 * mass**4) / (8 * omega**5)
    physical = omega + (pressure * (2 * wave**2 + 3 * mass**2) * omega**2 - hubble**2 * wave**2 * (2 * wave**2 + 7 * mass**2)) / (8 * omega**5)
    physical_ratio = mass * ratio + (pressure * (2 * ratio**2 + 1) * ratio**2 - hubble**2 * (ratio**2 - 1) * (2 * ratio**2 + 5)) / (8 * mass * ratio**5)
    stable = mass * (ratio**2 - 1) / (ratio + 1) * (1 - pressure / mass**2 * (3 * ratio**2 + ratio + 1) / (8 * ratio**3) - hubble**2 / mass**2 * (ratio + 1) * (2 * ratio**2 + 5) / (8 * ratio**5))
    old = mass * (ratio**2 - 1) / (ratio + 1) * (1 + hubble**2 / mass**2 * (3 * ratio**4 - ratio**3 - ratio**2 - 5 * ratio - 5) / (8 * ratio**5))
    results = dict(carrier_pressure=str(sym.factor(-3 * (2 * hubble_prime + hubble**2) / (8 * mass) - 3 * pressure / (8 * mass))),
                   finite_k_pressure=str(sym.factor(general - physical)),
                   stable_beat=str(sym.factor(physical_ratio - mass - 3 * pressure / (8 * mass) - stable)),
                   constant_H_beat=str(sym.factor(stable.subs(pressure, -hubble**2) - old)))
    if any(value != "0" for value in results.values()):
        raise ValueError("pressure simplification failed")
    return results


def main():
    with worker("validation"):
        proof, report = read(ROOT / "proof.json"), read(ROOT / "background-result.json")
        if not proof["passed"] or not report["passed"]:
            raise ValueError("earlier gate failed")
        for name, checksum in report["outputs"].items():
            if digest(ROOT / name) != checksum:
                raise ValueError("changed packet " + name)
        for path, checksum in proof["sources"].items():
            guard()
            if digest(path) != checksum:
                raise ValueError("changed source " + path)
        output = []
        for model in ("heavy", "cold"):
            with np.load(ROOT / (model + "-history.npz")) as archive:
                history = {name: archive[name].copy() for name in archive.files}
            with np.load(ROOT / (model + "-background.npz")) as archive:
                background = {name: archive[name].copy() for name in archive.files}
            for collection in (history, background):
                for name, value in collection.items():
                    if value.dtype.kind in "fci" and not np.isfinite(value).all():
                        raise ValueError("nonfinite packet " + model + ":" + name)
            if len(history["wave"]) != 399 or history["raw_values"].shape[:2] != (399, 7):
                raise ValueError("history coverage")
            if not np.all(np.diff(history["conformal_time"]) > 0) or not np.all(np.diff(history["actual_scale"], axis=1) > 0):
                raise ValueError("nonmonotone history")
            offset = 0
            for path in sorted((SPECTRUM / "runs" / model).glob("chunk-*.npz")):
                with np.load(path) as original:
                    valid = original["modes"] <= 5
                    indices = [int(np.argmin(abs(np.log(original["requested_scale"]) + np.log(11.) - delta))) for delta in history["original_offsets"]]
                    values = original["values"][valid][:, indices, :]
                    count = len(values)
                    if not np.array_equal(values, history["raw_values"][offset:offset + count]):
                        raise ValueError("lossless original source copy")
                    offset += count
            if offset != 399:
                raise ValueError("copy coverage")
            jets, mu = background["jets"], background["mu"]
            pressure_correction = 3 * jets[:, 5] / (8 * mu**2)
            scale = (jets[:, 0] / mu)**2
            pressure_error = float(np.max(abs(pressure_correction - background["homogeneous_correction"]) / scale))
            if pressure_error > ALGEBRA:
                raise ValueError("physical pressure identity")
            variations = {}
            for name in ("potential", "lapse", "density", "current"):
                values = history[name]
                norm = np.maximum(np.max(abs(values), axis=1), 1e-100)
                variations[name] = float(np.max(abs(values[:, 4] - values[:, 3]) / norm))
            knot_count = int(np.count_nonzero((background["nu_knots"] > -np.log(11.)) & (background["nu_knots"] < -np.log(11.) + SPAN)))
            output.append(dict(model=model, raw_rows_verified=399 * 7, pressure_identity_error=pressure_error,
                               real_interval_changes=variations, neutrino_spline_knots_inside=knot_count,
                               cold_WKB_diagnostic_only=model == "cold"))
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(), filename=str(path))
        if list(ROOT.rglob("__pycache__")):
            raise ValueError("bytecode residue")
        result = dict(passed=True, pressure_identities=pressure_identities(), models=output,
                      code_sha256=digest(__file__), common_sha256=digest(ROOT / "common.py"),
                      proof_sha256=digest(ROOT / "proof.json"), background_sha256=digest(ROOT / "background-result.json"),
                      pressure_document_sha256=digest(ROOT / "PRESSURE-BRIDGE.md"))
        write("validation.json", result)
        print(json.dumps(result))


if __name__ == "__main__":
    main()
