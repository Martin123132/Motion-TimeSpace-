from common import *
import ast


def binding(report, key, filename):
    if report[key] != digest(ROOT / filename):
        raise ValueError("changed report binding " + filename)


if __name__ == "__main__":
    with worker("seal") as identity:
        proof, background, validation = (read(ROOT / name) for name in ("proof.json", "background-result.json", "validation.json"))
        if not all(report["passed"] for report in (proof, background, validation)):
            raise ValueError("unpassed stage")
        if any(value != "0" for value in proof["formula"]["identities"].values()) or any(value != "0" for value in validation["pressure_identities"].values()):
            raise ValueError("symbolic mismatch")
        for key, filename in (("code_sha256", "derive_background.py"), ("common_sha256", "common.py"),
                              ("protocol_sha256", "PROTOCOL.md"), ("derivation_sha256", "DERIVATION.md")):
            binding(proof, key, filename)
        for key, filename in (("code_sha256", "prepare_history.py"), ("common_sha256", "common.py"),
                              ("protocol_sha256", "PROTOCOL.md"), ("proof_sha256", "proof.json")):
            binding(background, key, filename)
        for key, filename in (("code_sha256", "validate_background.py"), ("common_sha256", "common.py"),
                              ("pressure_document_sha256", "PRESSURE-BRIDGE.md"), ("proof_sha256", "proof.json"),
                              ("background_sha256", "background-result.json")):
            binding(validation, key, filename)
        for name, checksum in background["outputs"].items():
            if digest(ROOT / name) != checksum:
                raise ValueError("changed output " + name)
        if not all(row["passed"] and abs(row["error"]) <= row["gate"] for row in background["checks"]):
            raise ValueError("numeric check failed")
        for path, expected in proof["sources"].items():
            guard()
            if digest(path) != expected:
                raise ValueError("changed original " + path)
        cleanup = []
        for prefix in ("proof", "background", "validation"):
            start, end = read(ROOT / (prefix + "-start.json")), read(ROOT / (prefix + "-end.json"))
            if end["state"] != "completed" or start["pid"] != end["pid"] or start["created"] != end["created"]:
                raise ValueError("worker terminal receipt")
            try:
                live = abs(psutil.Process(start["pid"]).create_time() - start["created"]) < .001
            except psutil.NoSuchProcess:
                live = False
            if live:
                raise ValueError("owned process still live")
            cleanup.append(dict(**start, exited=True))
        for path in ROOT.glob("*.py"):
            ast.parse(path.read_text(), filename=str(path))
        if list(ROOT.rglob("__pycache__")):
            raise ValueError("bytecode residue")
        for name in ("RESULTS.md", "NEXT.md"):
            if not (ROOT / name).is_file() or (ROOT / name).stat().st_size < 100:
                raise ValueError("missing handoff")
        manifest = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size)
                    for path in ROOT.rglob("*") if path.is_file()}
        result = dict(state="verified", time=datetime.now(timezone.utc).isoformat(), artifacts=manifest,
                      input_hashes=proof["sources"], cleanup=cleanup, sealer=identity,
                      exact_identities=14, preparation_checks=len(background["checks"]),
                      source_rows_per_model=2793, modes_per_model=399, background_points_per_model=33,
                      scope="real background derivatives and evolution; pressure bridge; original moving-metric packet",
                      residual_diagnostics_not_interval_certificate=True, forced_perturbations_pending=True,
                      no_original_native_changes=True, no_galaxy_edits=True, no_github=True, no_relay_or_timer=True,
                      broad_goal_complete=False)
        write("closeout.json", result)
        print(json.dumps(dict(closeout_sha256=digest(ROOT / "closeout.json"), artifacts=len(manifest),
                              sources=len(proof["sources"]), cleanup=cleanup, sealer=identity)))
