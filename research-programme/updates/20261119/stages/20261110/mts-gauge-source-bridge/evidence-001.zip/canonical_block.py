from common import *
from source_bridge import port_map
import importlib.util
import numpy as np

current_common = sys.modules["common"]
specification = importlib.util.spec_from_file_location("saved_action_common", ACTION / "common.py")
saved_common = importlib.util.module_from_spec(specification)
specification.loader.exec_module(saved_common)
sys.modules["common"] = saved_common
sys.path.insert(0, str(ACTION))
try:
    import action_model
finally:
    sys.path.remove(str(ACTION))
    sys.modules["common"] = current_common


def complex_matrix(value):
    return np.array([[value.real, -value.imag], [value.imag, value.real]])


class CanonicalBlock:
    def __init__(self, port):
        self.port = port
        with np.load(action_model.BACKGROUND / "heavy-history.npz") as packet:
            index = int(np.flatnonzero(packet["wave"] == port.wave)[0])
        self.case = action_model.StableCase("heavy", indices=[index])
        self.case.history = {}
        self.case.metrics = {}
        require(self.case.mass == port.mass, "same retained heavy mass")
        initial_background = port.observe(port.times[0], np.zeros(port.dimension))
        self.initial_scale = initial_background[port.columns["a_native"]]
        self.initial_rho = port.matching_density / self.initial_scale
        initial_values = self.coefficients(self.initial_scale)
        self.initial_weight = initial_values["denominator"] / (self.initial_scale**2 * initial_values["carrier"])
        self.diagnostics = []

    def coefficients(self, scale_factor):
        position = np.log(scale_factor) + np.log(11.)
        mass, hubble = action_model.background_series(self.case, float(position))
        first = hubble * hubble.derivative()
        second = hubble * first.derivative()
        third = hubble * second.derivative()
        pressure = -2 * first - hubble**2
        gradient = action_model.Series(self.case.wave**2) / mass**2
        ratio = (1 + gradient).sqrt()
        carrier = mass + 3 * pressure / (8 * mass)
        beat = mass * gradient / (ratio + 1) * (1 - pressure / mass**2 * (3 * ratio**2 + ratio + 1) / (8 * ratio**3) - hubble**2 / mass**2 * (ratio + 1) * (2 * ratio**2 + 5) / (8 * ratio**5))
        sideband = carrier + beat
        slope0 = -hubble * carrier.derivative() / (2 * carrier)
        slopek = -hubble * sideband.derivative() / (2 * sideband)
        to_float = lambda entry: float(entry.value[0])
        mass_value, hubble_value, carrier_value, sideband_value = [to_float(entry) for entry in (mass, hubble, carrier, sideband)]
        physical0 = to_float(slope0) - hubble_value - 1j * carrier_value
        lambda0 = to_float(slope0) - 1j * carrier_value
        lambdak = to_float(slopek) - 1j * sideband_value
        difference = to_float(slopek - slope0) - 1j * to_float(beat)
        reduced_jets = [hubble_value / mass_value, to_float(first) / mass_value**2, to_float(second) / mass_value**3, to_float(third) / mass_value**4]
        residual = float(mass_value**2 * action_model.RESIDUAL_FUNCTION(np.array([to_float(ratio)]), *reduced_jets)[0])
        residual0 = float(mass_value**2 * action_model.RESIDUAL_FUNCTION(np.ones(1), *reduced_jets)[0])
        denominator = abs(physical0)**2 + mass_value**2
        source_rows = np.array([
            [physical0.real * (lambdak.real - hubble_value) + carrier_value * sideband_value + mass_value**2,
             physical0.real * sideband_value - carrier_value * (lambdak.real - hubble_value), physical0.real, -carrier_value],
            [self.port.wave * physical0.real, -self.port.wave * carrier_value, 0., 0.]]) * (2 / denominator)
        return dict(mass=mass_value, hubble=hubble_value, carrier=carrier_value, sideband=sideband_value,
                    lambda0=lambda0, lambdak=lambdak, difference=difference, physical0=physical0,
                    residual=residual, residual0=residual0, denominator=denominator, source_rows=source_rows,
                    enthalpy_ratio=2 * abs(physical0)**2 / denominator)

    def system(self, stamp):
        port = self.port
        native_background = port.observe(stamp, np.zeros(port.dimension))
        scale_factor = native_background[port.columns["a_native"]]
        values = self.coefficients(scale_factor)
        rho = self.initial_rho * values["denominator"] / (scale_factor**2 * values["carrier"]) / self.initial_weight
        enthalpy = rho * values["enthalpy_ratio"]
        bridge = port_map(port, stamp, values["source_rows"], rho, enthalpy)
        native = port.matrix(stamp)
        width = len(port.remaining) + 4
        matrix = np.zeros((width, width))
        matrix[:len(port.remaining)] = native[port.remaining] @ bridge["mapping"]
        matrix[-4:-2, -4:-2] = complex_matrix(values["difference"])
        matrix[-4:-2, -2:] = np.eye(2)
        matrix[-2:, -4:-2] = -values["residual"] * np.eye(2)
        matrix[-2:, -2:] = complex_matrix(-(values["lambda0"] + values["lambdak"]))
        combined = 3 * bridge["potential"] + bridge["lapse"]
        difference = 3 * bridge["potential"] - bridge["lapse"]
        source_first = values["physical0"] * combined
        source_second = (values["hubble"] - values["lambdak"]) * values["physical0"] * combined + values["mass"]**2 * difference
        matrix[-4] += source_first.real
        matrix[-3] += source_first.imag
        matrix[-2] += source_second.real
        matrix[-1] += source_second.imag
        pressure = bridge["density_star"].copy()
        pressure[-4] -= 4 * values["mass"]**2 / values["denominator"]
        pressure += 3 * values["enthalpy_ratio"] * bridge["potential"]
        density = bridge["density_star"] + 3 * values["enthalpy_ratio"] * bridge["potential"]
        self.diagnostics.append(dict(stamp=float(stamp), background_hubble_relative=abs(values["hubble"] / bridge["hubble"] - 1),
                                     carried_energy_relative=rho / bridge["native_rho"] - 1,
                                     carried_enthalpy_relative=enthalpy / bridge["native_rho"] - 1,
                                     carrier_residual=values["residual0"], sideband_residual=values["residual"]))
        bridge.update(matrix=matrix, coefficients=values, pressure=pressure, density=density)
        return bridge

    def prepare(self):
        port = self.port
        bridge = self.system(port.times[0])
        values = bridge["coefficients"]
        native = port.observe(port.times[0], port.initial)
        native_hubble = native[port.columns["H_native"]]
        alpha = native[port.columns["sigma"]] / port.wave
        density_target = port.initial[port.selected[0]] - 3 * native_hubble * alpha
        current_target = port.initial[port.selected[1]] + port.wave * alpha
        combined_prime = 4 * native[port.columns["Weyl_prime"]] + native[port.columns["Pi_prime"]] / port.wave**2
        rate_sum = values["lambda0"] + values["lambdak"]
        combined = 3 * bridge["potential"] + bridge["lapse"]
        momentum_condition = values["physical0"] * combined + 2 * values["mass"]**2 * bridge["lapse"] / rate_sum
        momentum_condition[-2] += 1
        momentum_condition[-1] += 1j
        constraints = np.vstack((bridge["density"], bridge["current"], momentum_condition.real, momentum_condition.imag))
        response_constant = combined_prime * values["physical0"] / rate_sum
        target = np.array([density_target, current_target, response_constant.real, response_constant.imag])
        initial = np.r_[port.initial[port.remaining], np.zeros(4)]
        right = target - constraints @ initial
        rowscale = np.maximum(np.max(abs(constraints[:, -4:]), axis=1), 1e-100)
        initial[-4:] = np.linalg.solve(constraints[:, -4:] / rowscale[:, None], right / rowscale)
        residual = constraints @ initial - target
        return initial, bridge, dict(target=target.tolist(), residual=residual.tolist(),
            conditional_preparation="D0 using initial native metric derivative, not a derived formation state; subsequent metric is live",
            initial_same_physical_density_current=True, initial_fast_component_retained=True, future_metric_history_used=False)
