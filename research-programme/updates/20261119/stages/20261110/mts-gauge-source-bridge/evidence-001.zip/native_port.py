from common import *
import ast
import ctypes
import numpy as np

POINTER = ctypes.POINTER(ctypes.c_double)


def pointer(array):
    return array.ctypes.data_as(POINTER)


class NativePort:
    def __init__(self, label):
        self.label = label
        self.wave = 5.
        self.owner = PORT / "runs" / (label + "-v4")
        self.config = read(self.owner / "config.json")
        build = PORT / "build-v3"
        require(digest(build / "native/camb/cambdll.dll") == self.config["adapter_sha256"], "retained DLL")
        sys.path.insert(0, str(build / "native"))
        import camb
        from camb.mts import MTSTwoField
        self.camb = camb
        sys.path.append(str(BRANCH / "radiation-and-slow-field-transfer-20261007"))
        import radiation_common
        factory_owner = NATIVE.parent / "matching_common.py"
        factory = next(node for node in ast.parse(factory_owner.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == "params_for")
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_owner), "exec"), namespace)
        with np.load(self.config["packet"]) as packet:
            full_times = np.ascontiguousarray(packet["conformal_time"])
            requested = packet["requested_scale"].copy()
            modes = packet["modes"].copy()
        target = int(np.flatnonzero(modes == self.wave)[0])
        with np.load(self.config["table"]) as table:
            self.mass = float(table["heavy_mass_mpc"])
            self.matching_density = float(table["matching_density"]) if label == "heavy" else 0.
        with np.load(self.owner / "capture.npz") as packet:
            self.reference = {name: packet[name].copy() for name in packet.files}
        self.observer_names = self.reference["observer_names"].tolist()
        self.columns = {name: index for index, name in enumerate(self.observer_names)}
        self.dimension = len(self.reference["mapping"])
        self.times = self.reference["times"].copy()
        self.initial = self.reference["state"][0].copy()
        with np.load(self.owner / "scale.npz") as packet:
            self.scale = packet["normalization"].copy()
        self.lib = camb.baseconfig.camblib
        self.observer_dll = ctypes.CDLL(str(POST / "mts-metric-feedback-20261107/observer.dll"))
        self.observer_function = ctypes.cast(self.observer_dll.source_func_, ctypes.c_void_p)
        self.lib.mts_capture_reset.argtypes = []
        self.lib.mts_capture_reset.restype = None
        self.lib.mts_capture_copy.argtypes = [ctypes.c_int, ctypes.c_int, POINTER, POINTER, POINTER]
        self.lib.mts_capture_copy.restype = None
        self.lib.mts_operator_rhs.argtypes = [ctypes.c_double, ctypes.c_int, POINTER, POINTER]
        self.lib.mts_operator_rhs.restype = None
        self.lib.mts_operator_observe.argtypes = [ctypes.c_double, ctypes.c_int, POINTER, ctypes.c_int, POINTER]
        self.lib.mts_operator_observe.restype = None
        self.native = camb.get_background(namespace["params_for"](Path(self.config["table"])))
        clock = self.native.conformal_time(1 / requested - 1, tol=1e-10)
        require(np.max(abs(clock - full_times) / full_times) < 1e-12, "original clock")
        self.native.Params.Accuracy.IntTolBoost = 6
        self.native.Params.Accuracy.lAccuracyBoost = 4
        self.lib.mts_capture_reset()
        for name in ("step", "kind", "count", "tangent"):
            ctypes.c_int.in_dll(self.lib, "mts_probe_" + name).value = 0
        for name, value in (("begin", self.config["first"] + 1), ("end", self.config["last"] + 1), ("q_index", target + 1)):
            ctypes.c_int.in_dll(self.lib, "mts_capture_" + name).value = value
        count = len(camb.model.evolve_names) + len(self.observer_names)
        output = np.zeros((len(modes), len(full_times), count))
        code = camb.results.CAMB_TimeEvolution(ctypes.byref(self.native), ctypes.byref(ctypes.c_int(len(modes))), modes, ctypes.byref(ctypes.c_int(len(full_times))), full_times, ctypes.byref(ctypes.c_int(count)), output, ctypes.byref(ctypes.c_int(len(self.observer_names))), ctypes.byref(self.observer_function))
        require(code == 0, "fresh live capture")
        dimension = ctypes.c_int.in_dll(self.lib, "mts_capture_dimension").value
        snapshots = ctypes.c_int.in_dll(self.lib, "mts_capture_count").value
        require(dimension == self.dimension and snapshots == 2, "late regime dimension")
        captured = np.zeros((dimension, snapshots), order="F")
        derivative = np.zeros_like(captured, order="F")
        times = np.zeros(snapshots)
        self.lib.mts_capture_copy(dimension, snapshots, pointer(captured), pointer(derivative), pointer(times))
        require(np.array_equal(times, self.times) and np.array_equal(captured.T, self.reference["state"]), "live initial state/clock identical to retained port")
        require(np.array_equal(derivative.T, self.reference["derivative"]), "live derivative identical to retained port")
        state_map = self.reference["mapping"]
        self.eta_index = int(np.flatnonzero(state_map == 1)[0])
        if label == "heavy":
            field_index = int(self.reference["signature"][2])
            self.selected = np.array([int(np.flatnonzero(state_map == field_index + offset)[0]) for offset in (2, 3)])
        else:
            self.selected = np.array([], dtype=int)
        self.remaining = np.array([index for index in range(dimension) if index not in self.selected])

    def rhs(self, stamp, state):
        guard()
        state = np.ascontiguousarray(state, dtype=np.float64)
        result = np.empty(self.dimension)
        self.lib.mts_operator_rhs(float(stamp), self.dimension, pointer(state), pointer(result))
        return result

    def observe(self, stamp, state):
        state = np.ascontiguousarray(state, dtype=np.float64)
        result = np.empty(len(self.observer_names))
        self.lib.mts_operator_observe(float(stamp), self.dimension, pointer(state), len(result), pointer(result))
        return result

    def matrix(self, stamp):
        return np.column_stack([self.rhs(stamp, basis) for basis in np.eye(self.dimension)])

    def observer_matrix(self, stamp):
        zero = self.observe(stamp, np.zeros(self.dimension))
        return zero, np.column_stack([self.observe(stamp, basis) - zero for basis in np.eye(self.dimension)])

    def close(self):
        self.lib.mts_capture_reset()
        del self.native
