from common import *
import sympy as sym


def main():
    with worker("proof"):
        wave, hubble, eta, density_rest, current_rest, rho, enthalpy, dstar, current, anisotropy = sym.symbols(
            "wave hubble eta density_rest current_rest rho enthalpy dstar current anisotropy", real=True)
        potential = -(density_rest + rho * dstar + 3 * hubble * (current_rest + rho * current) / wave) / (2 * wave**2 + 3 * enthalpy)
        alpha = (eta - potential) / hubble
        density_sync = density_rest + rho * dstar + 3 * enthalpy * eta
        current_sync = current_rest + rho * current - enthalpy * wave * alpha
        curvature_rate = current_sync / (2 * wave)
        zmetric = (density_sync / (2 * wave) + wave * eta) / hubble
        sigma = zmetric + 3 * current_sync / (2 * wave**2)
        checks = {"mixed_gauge_clock": sigma - wave * alpha,
                  "density_gauge_transform": rho * dstar + 3 * enthalpy * potential - (density_sync - density_rest - 3 * hubble * enthalpy * alpha),
                  "current_gauge_transform": rho * current - (current_sync - current_rest + enthalpy * wave * alpha)}
        rest_enthalpy = sym.symbols("rest_enthalpy", real=True)
        full_dstar = rho * dstar + density_rest - 3 * rest_enthalpy * eta
        full_current = rho * current + current_rest + rest_enthalpy * wave * alpha
        checks["all_Newtonian_formula_equivalence"] = potential + (full_dstar + 3 * hubble * full_current / wave) / (2 * wave**2 + 3 * (enthalpy + rest_enthalpy))
        pressure = sym.symbols("pressure", real=True)
        lapse = potential - anisotropy / wave**2
        slot_current = current - wave * alpha
        density_slot_rate = -3 * hubble * pressure - wave * slot_current - wave * zmetric
        current_slot_rate = -hubble * slot_current + wave * pressure
        checks["native_compensated_density_evolution"] = density_slot_rate - 3 * curvature_rate + wave * current + 3 * hubble * pressure
        checks["native_Newtonian_current_evolution"] = current_slot_rate + wave * (lapse - hubble * alpha) + hubble * current - wave * (pressure + lapse)
        slope0, slopek, slopek_prime, relative, fast, combined, mass2, hubble_prime = sym.symbols("slope0 slopek slopek_prime relative fast combined mass2 hubble_prime")
        canonical = slopek * relative + fast
        physical0 = slope0 - hubble
        relative_rate = canonical - slope0 * relative + combined * physical0
        canonical_rate = -slope0 * canonical - (wave**2 + mass2 - hubble_prime - hubble**2) * relative + hubble * combined * physical0 + mass2 * (combined - 2 * lapse)
        residual = slopek_prime + slopek**2 + wave**2 + mass2 - hubble_prime - hubble**2
        fast_rate = canonical_rate - slopek_prime * relative - slopek * relative_rate
        checks["stable_fast_coordinate_equation"] = fast_rate + (slope0 + slopek) * fast + residual * relative - combined * (hubble - slopek) * physical0 - mass2 * (combined - 2 * lapse)
        for name, expression in checks.items():
            guard()
            require(sym.factor(expression) == 0, name)
        write("proof.json", dict(passed=True, identities=list(checks), code_sha256=digest(__file__)))
        print("PASS", len(checks), "gauge/source identities", flush=True)


if __name__ == "__main__":
    main()
