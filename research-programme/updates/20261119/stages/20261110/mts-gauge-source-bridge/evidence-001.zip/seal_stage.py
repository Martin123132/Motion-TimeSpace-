from common import *
from validate_stage import identity_status


def main():
    with worker("seal"):
        require(read(ROOT / "validation.json")["passed"], "validation passed")
        require(read(ROOT / "canonical-result.json")["passed"], "canonical refinement passed")
        inputs = preserved()
        require(inputs == read(ROOT / "frozen-inputs.json"), "unchanged frozen inputs")
        identities = []
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name == "seal-start.json":
                continue
            identity = read(path)
            status = identity_status(identity)
            require(status["exited"], "worker still running: " + path.name)
            identities.append(dict(receipt=path.name, identity=identity, status=status))
        require(not list(ROOT.rglob("__pycache__")), "no bytecode cache")
    artifacts = {}
    for path in sorted(ROOT.iterdir()):
        require(path.is_file(), "unexpected nested artifact: " + str(path))
        require(path.name != "closeout.json", "already sealed")
        artifacts[path.name] = dict(sha256=digest(path), bytes=path.stat().st_size)
    write("closeout.json", dict(state="verified_progress", utc=datetime.now(timezone.utc).isoformat(), goal_complete=False,
          input_hashes=inputs, artifacts=artifacts, worker_checks=identities,
          accepted=dict(proof="proof.json", controls="bridge-result.json", canonical="canonical-result.json", validation="validation.json"),
          scope="conditional 95-state live canonical short-window evolution with paired retained controls; no formation or observational claim",
          failed_attempts_preserved=["bridge-end.json", "INTEGRATOR-REFINEMENT.md"],
          final_cleanup="check seal identity after this process exits; save CLEANUP-VERIFIED.json separately"))
    print(json.dumps(dict(seal_sha256=digest(ROOT / "closeout.json"), inputs=len(inputs), artifacts=len(artifacts))))


if __name__ == "__main__":
    main()
