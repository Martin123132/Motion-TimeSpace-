from common import *
from native_port import NativePort
from canonical_block import CanonicalBlock
from source_bridge import evolve_exponential
import numpy as np
from scipy.linalg import expm


def main():
    with worker("canonical"):
        require(read(ROOT / "bridge-result.json")["passed"], "paired equivalent bridge gate")
        port = NativePort("heavy")
        try:
            block = CanonicalBlock(port)
            initial, initial_system, preparation = block.prepare()
            width = len(initial)
            require(width == 95, "unrestricted scalar plus unchanged91rest states")
            scale = np.maximum(abs(initial), max(float(np.max(abs(initial))) * 1e-20, 1e-30))
            scale[:len(port.remaining)] = np.maximum(scale[:len(port.remaining)], port.scale[port.remaining])
            for offset in np.linspace(0, port.times[-1] - port.times[0], 17):
                scale = np.maximum(scale, abs(expm(initial_system["matrix"] * offset) @ initial))
            write("canonical-preparation.json", dict(**preparation, dimension=width, code_sha256=digest(__file__), block_sha256=digest(ROOT / "canonical_block.py")))
            np.savez_compressed(ROOT / "canonical-initial.npz", initial=initial, normalization=scale, initial_matrix=initial_system["matrix"], initial_mapping=initial_system["mapping"], initial_native=port.initial, times=port.times)
            final_system = block.system(port.times[-1])
            with np.load(port.owner / "precision.npz") as packet:
                native_reference = packet["state"][-1].copy()
            reports, finals = [], []
            for steps in (64, 128, 256):
                final = evolve_exponential(lambda stamp: block.system(stamp)["matrix"], initial, port.times, steps, scale)
                native_image = final_system["mapping"] @ final
                source = np.array([final_system["density"] @ final, final_system["current"] @ final, final_system["pressure"] @ final,
                                   final_system["potential"] @ final, final_system["lapse"] @ final])
                previous_error = None if not finals else float(np.max(abs(final - finals[-1]) / scale))
                native_difference = float(np.max(abs(native_image - native_reference) / port.scale))
                report = dict(steps=steps, difference_from_previous=previous_error, difference_from_retained_fluid=native_difference,
                              meaning="new canonical parent versus old fluid; its difference is not an integration-error estimate or observational preference")
                reports.append(report)
                finals.append(final)
                np.savez_compressed(ROOT / ("canonical-" + str(steps) + ".npz"), final=final, native_image=native_image, final_sources=source, normalization=scale)
                write("canonical-" + str(steps) + ".json", report)
                print(json.dumps(report), flush=True)
            final_difference = reports[-1]["difference_from_previous"]
            report = dict(passed=bool(np.isfinite(final_difference) and final_difference <= GATE), gate=GATE, reports=reports,
                          diagnostics=block.diagnostics, original_future_perturbation_histories_disabled=True,
                          background_and_fast_preparation_conditional=True, independent_full_GR_claim=False,
                          code_sha256=digest(__file__), block_sha256=digest(ROOT / "canonical_block.py"))
            write("canonical-result.json", report)
            require(report["passed"], "unrestricted parent internal-step refinement")
        finally:
            port.close()


if __name__ == "__main__":
    main()
