from common import *
import numpy as np
from scipy.linalg import expm


def port_map(port, stamp, source_rows, rho=None, enthalpy=None):
    background, observer = port.observer_matrix(stamp)
    columns = port.columns
    scale_factor = background[columns["a_native"]]
    hubble = background[columns["H_native"]]
    native_rho = port.matching_density / scale_factor
    rho = native_rho if rho is None else rho
    enthalpy = rho if enthalpy is None else enthalpy
    remaining_count = len(port.remaining)
    width = remaining_count + source_rows.shape[1]
    density_star, current = np.zeros((2, width))
    density_star[remaining_count:] = source_rows[0]
    current[remaining_count:] = source_rows[1]
    density_rest, current_rest, eta = np.zeros((3, width))
    density_rest[:remaining_count] = observer[columns["D_sync"], port.remaining]
    current_rest[:remaining_count] = observer[columns["Q_sync"], port.remaining]
    eta[:remaining_count] = observer[columns["eta_sync"], port.remaining]
    denominator = 2 * port.wave**2 + 3 * enthalpy
    potential = -(density_rest + rho * density_star + 3 * hubble * (current_rest + rho * current) / port.wave) / denominator
    alpha = (eta - potential) / hubble
    mapping = np.zeros((port.dimension, width))
    mapping[port.remaining, np.arange(remaining_count)] = 1
    mapping[port.selected[0]] = (rho * density_star + 3 * enthalpy * eta) / native_rho
    mapping[port.selected[1]] = (rho * current - enthalpy * port.wave * alpha) / native_rho
    anisotropy = observer[columns["Pi"]] @ mapping
    lapse = potential - anisotropy / port.wave**2
    return dict(mapping=mapping, potential=potential, lapse=lapse, anisotropy=anisotropy, density_star=density_star, current=current,
                alpha=alpha, eta=eta, hubble=hubble, scale_factor=scale_factor, rho=rho, enthalpy=enthalpy,
                native_rho=native_rho, observer=observer, background=background)


def equivalent_matrix(port, stamp):
    bridge = port_map(port, stamp, np.eye(2))
    native = port.matrix(stamp)
    result = np.zeros((port.dimension, port.dimension))
    result[:len(port.remaining)] = native[port.remaining] @ bridge["mapping"]
    mass = port.mass * bridge["scale_factor"]
    ratio = (port.wave / mass)**2
    sound = ratio / (np.sqrt(1 + ratio) + 1)**2
    pressure = sound * (bridge["density_star"] + 3 * bridge["potential"] + 3 * bridge["hubble"] * bridge["current"] / port.wave)
    result[-2] = -port.wave * bridge["current"] - 3 * bridge["hubble"] * pressure
    result[-1] = -bridge["hubble"] * bridge["current"] + port.wave * (pressure + bridge["lapse"])
    bridge["matrix"], bridge["native_matrix"], bridge["pressure"] = result, native, pressure
    return bridge


def equivalent_initial(port):
    observer = port.observe(port.times[0], port.initial)
    eta = observer[port.columns["eta_sync"]]
    sigma = observer[port.columns["sigma"]]
    return np.r_[port.initial[port.remaining], port.initial[port.selected[0]] - 3 * eta, port.initial[port.selected[1]] + sigma]


def evolve_exponential(factory, initial, times, steps, normalization):
    first_weight = (3 - 2 * np.sqrt(3.)) / 12
    second_weight = (3 + 2 * np.sqrt(3.)) / 12
    first_node, second_node = .5 - np.sqrt(3.) / 6, .5 + np.sqrt(3.) / 6
    boundaries = np.linspace(times[0], times[-1], steps + 1)
    state = initial / normalization
    for begin, end in zip(boundaries[:-1], boundaries[1:]):
        guard()
        interval = end - begin
        matrix_first = factory(begin + first_node * interval) * normalization[None, :] / normalization[:, None]
        matrix_second = factory(begin + second_node * interval) * normalization[None, :] / normalization[:, None]
        early = interval * (second_weight * matrix_first + first_weight * matrix_second)
        late = interval * (first_weight * matrix_first + second_weight * matrix_second)
        state = expm(late) @ (expm(early) @ state)
    return state * normalization
