from common import *
from native_port import NativePort
from source_bridge import equivalent_matrix, equivalent_initial, evolve_exponential
import numpy as np
from scipy.linalg import expm


def main():
    with worker("bridge-refined"):
        require(read(ROOT / "proof.json")["passed"], "source derivation")
        require(read(ROOT / "frozen-inputs.json") == preserved(), "unchanged frozen inputs")
        checks, reports, arrays = [], [], {}
        def check(name, error, gate=ALGEBRA):
            checks.append(dict(name=name, error=float(error), gate=gate, passed=bool(np.isfinite(error) and error <= gate)))
        for label in ("heavy", "cold"):
            port = NativePort(label)
            try:
                if label == "heavy":
                    initial = equivalent_initial(port)
                    first = equivalent_matrix(port, port.times[0])
                    scale = np.maximum(abs(initial), np.r_[port.scale[port.remaining], port.scale[port.selected]])
                    for offset in np.linspace(0, port.times[-1] - port.times[0], 17):
                        scale = np.maximum(scale, abs(expm(first["matrix"] * offset) @ initial))
                    for point, stamp in enumerate(np.linspace(port.times[0], port.times[-1], 5)):
                        bridge = equivalent_matrix(port, stamp)
                        observer, native = bridge["observer"], bridge["native_matrix"]
                        transform = np.zeros((port.dimension, port.dimension))
                        transform[:len(port.remaining), port.remaining] = np.eye(len(port.remaining))
                        transform[-2, port.selected[0]] = 1
                        transform[-2] -= 3 * observer[port.columns["eta_sync"]]
                        transform[-1, port.selected[1]] = 1
                        transform[-1] += observer[port.columns["sigma"]]
                        inverse_error = float(np.max(abs(transform @ bridge["mapping"] - np.eye(port.dimension))))
                        check("gauge inverse " + str(point), inverse_error)
                        chain = np.zeros_like(native)
                        chain[:len(port.remaining)] = native[port.remaining]
                        chain[-2] = native[port.selected[0]] - 3 * observer[port.columns["eta_prime"]]
                        chain[-1] = native[port.selected[1]] + observer[port.columns["sigma_prime"]]
                        expected = chain @ bridge["mapping"]
                        check("all-state transformed RHS " + str(point), np.max(abs(bridge["matrix"] - expected)) / max(np.max(abs(expected)), 1e-100))
                        check("metric source potential " + str(point), np.max(abs((observer[port.columns["eta_sync"]] - bridge["hubble"] * observer[port.columns["sigma"]] / port.wave) @ bridge["mapping"] - bridge["potential"])))
                    check("same physical initial state", np.max(abs(first["mapping"] @ initial - port.initial) / port.scale), GATE)
                    factory = lambda stamp: equivalent_matrix(port, stamp)["matrix"]
                else:
                    initial, scale = port.initial.copy(), port.scale.copy()
                    factory = port.matrix
                with np.load(port.owner / "precision.npz") as packet:
                    reference = packet["state"][-1].copy()
                outputs = []
                for steps in (32, 64):
                    final = evolve_exponential(factory, initial, port.times, steps, scale)
                    native_final = equivalent_matrix(port, port.times[-1])["mapping"] @ final if label == "heavy" else final
                    error = float(np.max(abs(native_final - reference) / port.scale))
                    reports.append(dict(model=label, steps=steps, error_against_saved_DOP853=error, passed=error <= GATE))
                    arrays[label + "_" + str(steps)] = native_final
                    outputs.append(native_final)
                    print(label, steps, error, flush=True)
                check(label + " step refinement", np.max(abs(outputs[-1] - outputs[-2]) / port.scale), GATE)
                np.savez_compressed(ROOT / (label + "-bridge-progress.npz"), **arrays)
                write(label + "-bridge-progress.json", dict(checks=checks, reports=reports))
                require(all(row["passed"] for row in checks) and all(row["passed"] for row in reports), "bridge/control acceptance")
            finally:
                port.close()
        np.savez_compressed(ROOT / "bridge-control.npz", **arrays)
        write("bridge-result.json", dict(passed=True, checks=checks, reports=reports, native_equations_unchanged=True,
              future_species_forcing=False, unrestricted_new_scalar_evolved=False, code_sha256=digest(__file__),
              bridge_sha256=digest(ROOT / "source_bridge.py"), native_port_sha256=digest(ROOT / "native_port.py"), output_sha256=digest(ROOT / "bridge-control.npz")))


if __name__ == "__main__":
    main()
