import os
import sys
for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[name] = "1"
sys.dont_write_bytecode = True
import hashlib
import json
import time
from pathlib import Path
from contextlib import contextmanager
from datetime import datetime, timezone
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PORT = POST / "mts-late-hierarchy-port-20261110"
ACTION = POST / "mts-metric-reduced-action-20261110"
CLOSURE = POST / "mts-canonical-metric-closure-20261110"
BRANCH = POST / "condensate-origin-20261003"
NATIVE = BRANCH / "native-heavy-matching-20261007/native"
START = time.monotonic()
ALGEBRA, GATE = 1e-10, 2e-5


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            hasher.update(block)
    return hasher.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(name, value):
    encoded = json.dumps(value, indent=2, allow_nan=False)
    with (ROOT / name).open("x", encoding="utf-8") as stream:
        stream.write(encoded)


def guard():
    require(time.monotonic() - START < 900, "bounded worker deadline")
    for directory in (ROOT, POST, PORT):
        require(not (directory / "STOP-REQUESTED").exists(), "owner hold: " + str(directory))


@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())
    write(name + "-start.json", identity)
    try:
        guard()
        yield
    except BaseException as error:
        write(name + "-end.json", dict(**identity, state="failed", error=repr(error)))
        raise
    else:
        write(name + "-end.json", dict(**identity, state="completed", elapsed=time.monotonic() - START))


def preserved():
    require(digest(PORT / "closeout.json") == "e863d5b1068e2f008035a9133a98b9671dbf6e22eed4cc861b9b2da52c2ecd60", "retained port seal")
    seal = read(PORT / "closeout.json")
    result = dict(seal["input_hashes"])
    result[str(PORT / "closeout.json")] = digest(PORT / "closeout.json")
    result.update({str(PORT / name): row["sha256"] for name, row in seal["artifacts"].items()})
    for path, checksum in result.items():
        guard()
        require(digest(path) == checksum, "changed retained input: " + path)
    return result
