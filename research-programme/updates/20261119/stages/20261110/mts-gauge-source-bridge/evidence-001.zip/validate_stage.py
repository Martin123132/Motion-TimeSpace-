from common import *
import ast
import numpy as np


def identity_status(identity):
    try:
        process = psutil.Process(identity["pid"])
        created = process.create_time()
        command = process.cmdline()
    except psutil.NoSuchProcess:
        return dict(exited=True, reason="PID absent")
    matching = abs(created - identity["created"]) < .01 and command == identity["command"]
    return dict(exited=not matching, reason="original identity live" if matching else "PID reused; not touched",
                observed_creation=created, observed_command=command)


def main():
    with worker("validation"):
        checks = []

        def check(name, passed, **details):
            checks.append(dict(name=name, passed=bool(passed), **details))

        inputs = preserved()
        check("all inherited hashes unchanged", inputs == read(ROOT / "frozen-inputs.json"), count=len(inputs))
        for path in sorted(ROOT.glob("*.py")):
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
            check("compile " + path.name, True)
        check("no bytecode cache", not list(ROOT.rglob("__pycache__")))
        proof = read(ROOT / "proof.json")
        bridge = read(ROOT / "bridge-result.json")
        canonical = read(ROOT / "canonical-result.json")
        preparation = read(ROOT / "canonical-preparation.json")
        check("seven symbolic identities", proof["passed"] and len(proof["identities"]) == 7)
        check("paired bridge acceptance", bridge["passed"] and all(row["passed"] for row in bridge["checks"] + bridge["reports"]))
        for report, fields in ((proof, {"code_sha256": "prove_map.py"}),
                               (bridge, {"code_sha256": "check_bridge.py", "bridge_sha256": "source_bridge.py", "native_port_sha256": "native_port.py", "output_sha256": "bridge-control.npz"}),
                               (canonical, {"code_sha256": "run_canonical.py", "block_sha256": "canonical_block.py"}),
                               (preparation, {"code_sha256": "run_canonical.py", "block_sha256": "canonical_block.py"})):
            for field, name in fields.items():
                check("recorded hash " + name, digest(ROOT / name) == report[field])
        with np.load(ROOT / "canonical-initial.npz") as packet:
            initial, scale = packet["initial"].copy(), packet["normalization"].copy()
            mapped = packet["initial_mapping"] @ initial
            native_initial = packet["initial_native"].copy()
            check("95 real states and full matrix", initial.shape == (95,) and packet["initial_matrix"].shape == (95, 95))
            check("93-state native source mapping", packet["initial_mapping"].shape == (93, 95))
            check("positive finite frozen normalization", np.all(np.isfinite(scale)) and np.all(scale > 0))
        with np.load(PORT / "runs/heavy-v4/scale.npz") as packet:
            native_scale = packet["normalization"].copy()
        with np.load(PORT / "runs/heavy-v4/precision.npz") as packet:
            reference = packet["state"][-1].copy()
        initial_error = float(np.max(abs(mapped - native_initial) / native_scale))
        check("same initial rest and physical sources", initial_error <= ALGEBRA, error=initial_error, gate=ALGEBRA)
        finals, numerical_rows = [], []
        for row in canonical["reports"]:
            steps = row["steps"]
            with np.load(ROOT / ("canonical-" + str(steps) + ".npz")) as packet:
                final = packet["final"].copy()
                check("finite canonical packet " + str(steps), all(np.all(np.isfinite(packet[name])) for name in packet.files))
                check("fixed normalization " + str(steps), np.array_equal(packet["normalization"], scale))
                check("saved shape " + str(steps), final.shape == (95,) and packet["native_image"].shape == (93,) and packet["final_sources"].shape == (5,))
                difference = float(np.max(abs(packet["native_image"] - reference) / native_scale))
            check("recomputed native difference " + str(steps), difference == row["difference_from_retained_fluid"])
            refinement = None if not finals else float(np.max(abs(final - finals[-1]) / scale))
            check("recomputed refinement " + str(steps), refinement == row["difference_from_previous"])
            numerical_rows.append(dict(steps=steps, difference_from_previous=refinement, retained_fluid_difference=difference))
            finals.append(final)
        check("unchanged final refinement gate", canonical["passed"] and canonical["gate"] == GATE and numerical_rows[-1]["difference_from_previous"] <= GATE)
        check("conditional preparation explicit", preparation["conditional_preparation"].startswith("D0 using initial native metric derivative") and not preparation["future_metric_history_used"])
        tree = ast.parse((ROOT / "canonical_block.py").read_text(encoding="utf-8"))
        rhs = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == "system")
        forbidden = {"history", "metrics", "local", "reference", "precision"}
        check("RHS excludes supplied perturbation history access", not any(isinstance(node, ast.Attribute) and node.attr in forbidden for node in ast.walk(rhs)))
        check("no broad physical claim", canonical["background_and_fast_preparation_conditional"] and not canonical["independent_full_GR_claim"])
        checksums = {}
        for path in sorted(ROOT.glob("*.npz")):
            with np.load(path) as packet:
                check("readable packet " + path.name, all(np.all(np.isfinite(packet[name])) for name in packet.files))
            checksums[path.name] = digest(path)
        workers = []
        for path in sorted(ROOT.glob("*-start.json")):
            if path.name == "validation-start.json":
                continue
            identity = read(path)
            status = identity_status(identity)
            ending = ROOT / path.name.replace("-start.json", "-end.json")
            check("worker exited " + path.name, status["exited"] and ending.exists())
            workers.append(dict(receipt=path.name, identity=identity, status=status, end_state=read(ending)["state"]))
        report = dict(passed=all(row["passed"] for row in checks), checks=checks, numerical_rows=numerical_rows,
                      input_count=len(inputs), packet_hashes=checksums, workers=workers,
                      qualification="Compilation, hashes, schema and finite-sample controls are not independent physical predictions.")
        write("validation.json", report)
        require(report["passed"], "stage validation")
        print(json.dumps(dict(passed=report["passed"], checks=len(checks), inputs=len(inputs), workers=len(workers))))


if __name__ == "__main__":
    main()
