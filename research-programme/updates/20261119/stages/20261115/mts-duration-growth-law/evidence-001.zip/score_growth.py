from growth_math import *
from numpy.polynomial.legendre import leggauss

def check(actual, expected, tolerance=GATE, scale=None):
    actual, expected = np.asarray(actual), np.asarray(expected)
    error = float(np.max(abs(actual-expected)))
    size = float(np.max(abs(expected))) if scale is None else float(scale)
    return dict(error=error,scale=size,relative=error/size if size else None,passed=bool(error <= tolerance*size),tolerance=tolerance)

def by_parts_moment(history, elapsed, degree, node):
    gauss_nodes, gauss_weights = leggauss(8)
    smooth, jumps, direct = np.zeros(2),np.zeros(2),np.zeros(2)
    previous_right = None
    for segment in range(history.lengths[node]):
        left = history.left[node,segment]
        if left >= elapsed:
            break
        width = history.width[node,segment]
        upper = min(width,elapsed-left)
        fraction = upper/width
        points = fraction*(gauss_nodes+1)/2
        distance = elapsed-left-width*points
        coefficients = history.coefficients[node,segment]
        curvature = sum(value[None,:]*points[:,None]**exponent for exponent,value in enumerate(coefficients))
        slope = sum(exponent*coefficients[exponent][None,:]*points[:,None]**(exponent-1)/width for exponent in range(1,len(coefficients)))
        direct += upper/2*np.sum(gauss_weights[:,None]*distance[:,None]**degree/math.factorial(degree)*curvature,axis=0)
        smooth += upper/2*np.sum(gauss_weights[:,None]*distance[:,None]**(degree+1)/math.factorial(degree+1)*slope,axis=0)
        if previous_right is not None:
            jumps += (coefficients[0]-previous_right)*(elapsed-left)**(degree+1)/math.factorial(degree+1)
        previous_right = np.sum(coefficients,axis=0)
    initial = history.coefficients[node,0,0]*elapsed**(degree+1)/math.factorial(degree+1)
    return direct,smooth+jumps+initial,jumps

with worker('score-growth'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    reports, algebra = {}, {}
    for case in ('cold','heavy'):
        require(exited(read(ROOT/(case+'-growth-start.json')))['exited'],'numerical worker exited')
        check_hashes(read(ROOT/(case+'-growth-freeze.json'))['hashes'])
        prepared,history,background,old = problem(case)
        jets = load(ROOT/(case+'-growth-coefficients.npz'))
        fine = load(ROOT/(case+'-growth-64.npz'))
        coarse = load(ROOT/(case+'-growth-32.npz'))
        reference = load(LAST/(case+'-extended-64.npz'))
        comparison = load(LAST/(case+'-comparison.npz'))
        target = reference['delta_prediction']
        source_first = jets['curvature_first']
        source_second = jets['curvature_second']
        matrix,derivative,forcing,forcing_prime = metric.geometry(case,0.,prepared,background)
        fourth_rhs = np.einsum('nij,nj->ni',forcing,source_first)/6
        fifth_rhs = np.einsum('nij,nj->ni',matrix,jets['state_four'])+np.einsum('nij,nj->ni',forcing_prime,source_first)/6+np.einsum('nij,nj->ni',forcing,source_second)/24
        algebra[case+'_coefficient_four'] = check(4*jets['state_four'],fourth_rhs,ALGEBRA)
        algebra[case+'_coefficient_five'] = check(5*jets['state_five'],fifth_rhs,ALGEBRA)
        if case == 'heavy':
            algebra[case+'_density_pressure_leading'] = check(jets['output_four'][:,0],jets['output_four'][:,2],ALGEBRA)
            algebra[case+'_current_extra_integration'] = check(jets['output_five'][:,1],prepared['wave']*jets['output_four'][:,0]/5,ALGEBRA)
            algebra[case+'_zero_fourth_current'] = check(jets['output_four'][:,1],np.zeros(len(prepared['times'])),ALGEBRA)
        else:
            algebra[case+'_dust_zeros'] = check(fine['terms'][:,:,1:],0,ALGEBRA)
        for endpoint in (8,16):
            duration = float(prepared['elapsed'][endpoint])
            for degree in (2,3):
                moments = source_moment(history,duration,degree)
                for node in (0,451,901):
                    direct,parts,jump = by_parts_moment(history,duration,degree,node)
                    algebra[case+'_'+str(endpoint)+'_'+str(degree)+'_'+str(node)+'_moment'] = check(moments[node],direct,ALGEBRA)
                    algebra[case+'_'+str(endpoint)+'_'+str(degree)+'_'+str(node)+'_corners'] = check(parts,direct,ALGEBRA)
        partial = fine['partial_sums']
        partial_coarse = coarse['partial_sums']
        node_refinement = np.abs(fine['nodes']-coarse['nodes'])
        uncertainty = np.array([[weighted(abs(prepared['weights']),np.sum(row[:order+1],axis=0)) for order in range(9)] for row in node_refinement])
        methods = dict(local_fourth=jets['taylor_four'],local_fourth_fifth=jets['taylor_five'],corner_moment_leading=jets['moment_leading'],corner_moment_first=jets['moment_first'])
        methods.update({'volterra_'+str(order):partial[:,order] for order in (0,1,2,4,6,8)})
        windows = {}
        for label,indices in (('original',np.arange(1,9)),('extension',np.arange(9,17))):
            window = {}
            for method,values in methods.items():
                channels = {}
                for channel,name in enumerate(('D','Q','P')):
                    scale = np.max(abs(target[indices,channel]))
                    numerical = comparison['difference_refinement'][indices,channel]
                    if method.startswith('volterra_'):
                        numerical = numerical+uncertainty[indices,int(method.split('_')[-1]),channel]
                    channels[name] = dict(raw=check(values[indices,channel],target[indices,channel],scale=scale),with_working_uncertainty=check(abs(values[indices,channel]-target[indices,channel])+numerical,0,scale=scale),original_observable_gate=check(abs(values[indices,channel]-target[indices,channel])+numerical,0,scale=comparison['reference_scale'][channel]))
                window[method] = channels
            windows[label] = window
        resolved = all(channel['with_working_uncertainty']['passed'] for window in windows.values() for channel in window['volterra_8'].values())
        node_checks = {}
        for endpoint in (8,16):
            summed = np.sum(fine['states'][endpoint],axis=0)
            normalized_target = reference['delta_state'][endpoint]/prepared['norm']
            node_checks[str(endpoint)] = check(summed/prepared['norm'],normalized_target)
        for endpoint in (8,16):
            old = load(OLDER/(case+'-source-history-64.npz')) if endpoint == 8 else reference
            require(np.array_equal(old['delta_prediction'][endpoint if endpoint == 8 else -1],target[endpoint]),'same saved window')
        report = dict(case=case,windows=windows,resolved_eight_interactions=resolved,node_state_checks=node_checks,weighted_four=jets['weighted_four'].tolist(),weighted_five=jets['weighted_five'].tolist(),first_cell_common_validity=float(np.min(jets['first_cell_width'])),elapsed_windows=prepared['elapsed'][[8,16]].tolist(),local_series_not_valid_across_all_corners=True,terms_at_endpoints=fine['terms'][[8,16]].tolist(),target_endpoints=target[[8,16]].tolist(),no_exponent_fitted=True)
        write(case+'-growth-result.json',report)
        reports[case] = report
        np.savez_compressed(ROOT/(case+'-growth-comparison.npz'),target=target,partial_sums=partial,working_refinement=uncertainty,reference_refinement=comparison['difference_refinement'],elapsed=prepared['elapsed'])
        print(json.dumps(dict(case=case,resolved=resolved,coefficients4=report['weighted_four'],coefficients5=report['weighted_five'],windows={label:{method:{name:row['raw']['relative'] for name,row in channels.items()} for method,channels in window.items()} for label,window in windows.items()})),flush=True)
    write('algebra-validation.json',dict(passed=all(row['passed'] for row in algebra.values()),checks=algebra,count=len(algebra)))
    passed = all(report['resolved_eight_interactions'] and all(row['passed'] for row in report['node_state_checks'].values()) for report in reports.values()) and all(row['passed'] for row in algebra.values())
    write('result.json',dict(completed=True,passed=passed,baseline_mts_checked=True,both_saved_windows_checked=True,gate=GATE,algebra_gate=ALGEBRA,no_fitting=True,no_new_source_extrapolation=True,physical_bank_grids_unchanged=True,goal_left_paused=True))
    check_hashes(read(ROOT/'frozen-inputs.json'))
    print(json.dumps(dict(all_checks_passed=passed,algebra_checks=len(algebra))),flush=True)
