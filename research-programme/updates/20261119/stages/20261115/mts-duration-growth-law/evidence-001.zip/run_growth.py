from growth_math import *
from scipy.integrate import solve_ivp
import argparse

parser = argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case = parser.parse_args().case

with worker(case+'-growth'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'protocol-freeze.json'))
    prepared, history, background, old = problem(case)
    jets = coefficients(case,prepared,history,background)
    moment_leading, moment_first = moments_prediction(case,prepared,history,background,jets)
    elapsed = prepared['elapsed']
    taylor_four = elapsed[:,None]**4*jets['weighted_four']
    taylor_five = taylor_four+elapsed[:,None]**5*jets['weighted_five']
    np.savez_compressed(ROOT/(case+'-growth-coefficients.npz'),**jets,moment_leading=moment_leading,moment_first=moment_first,taylor_four=taylor_four,taylor_five=taylor_five,elapsed=elapsed)
    dimension = prepared['state'].shape[1]
    shape = (9,len(prepared['times']),dimension)
    scaling = prepared['norm']*old['diagnostic_amplitude'][:,None]
    for steps in (32,64):
        def derivative(offset,flat):
            guard()
            matrix,forcing = metric.normalized_geometry(case,offset,prepared,background)
            states = flat.reshape(shape)
            result = np.zeros_like(states)
            result[0] = np.einsum('nij,nj->ni',forcing,history.remainder(offset)/old['diagnostic_amplitude'][:,None])
            result[1:] = np.einsum('nij,knj->kni',matrix,states[:-1])
            return result.ravel()
        solution = solve_ivp(derivative,(0,float(elapsed[-1])),np.zeros(np.prod(shape)),method='DOP853',t_eval=elapsed,rtol=1e-10,atol=1e-12,max_step=float(elapsed[8])/steps)
        require(solution.success and solution.y.shape == (np.prod(shape),17),'completed hierarchy')
        states = solution.y.T.reshape(17,*shape)*scaling[None,None,:,:]
        nodes = np.array([[metric.readout(case,float(offset),state,prepared,background) for state in terms] for offset,terms in zip(elapsed,states)])
        predictions = np.array([[weighted(prepared['weights'],term) for term in terms] for terms in nodes])
        require(np.isfinite(predictions).all(),'finite response series')
        np.savez_compressed(ROOT/(case+'-growth-'+str(steps)+'.npz'),states=states,nodes=nodes,terms=predictions,partial_sums=np.cumsum(predictions,axis=1),elapsed=elapsed,max_physical_step=float(elapsed[8])/steps)
        print(json.dumps(dict(case=case,steps=steps,evaluations=solution.nfev)),flush=True)
    write(case+'-growth-freeze.json',dict(passed=True,hashes={str(path):digest(path) for path in ROOT.glob(case+'-growth-*.npz')},scoring_started=False))
    check_hashes(read(ROOT/'frozen-inputs.json'))
