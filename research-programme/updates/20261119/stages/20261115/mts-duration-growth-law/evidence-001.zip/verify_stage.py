from growth_math import *

with worker('verify-stage-v2'):
    checks = {}
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['python_compiles'] = True
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'protocol-freeze.json'))
    checks['all_frozen_inputs_unchanged'] = True
    checks['no_pycache'] = not list(ROOT.rglob('__pycache__'))
    checks['algebra'] = read(ROOT/'algebra-validation.json')['passed']
    checks['result'] = read(ROOT/'result.json')['passed']
    contract = read(ROOT/'next-window-contract.json')
    checks['next_endpoint'] = contract['selected_endpoint_index'] == 2924 and contract['new_intervals'] == 16
    checks['future_not_claimed'] = not contract['job_launched'] and all(not row['usable_as_future_prediction'] for row in contract['forecast_not_promoted'].values())
    checks['same_gates'] = contract['future_gate'] == GATE and contract['future_algebra_gate'] == ALGEBRA
    for directory in (LAST,OLDER):
        seal = read(directory/'closeout.json')
        checks[directory.name+'_artifacts'] = all(digest(directory/name)==row['sha256'] and (directory/name).stat().st_size==row['bytes'] for name,row in seal['artifacts'].items())
    for case in ('cold','heavy'):
        report = read(ROOT/(case+'-growth-result.json'))
        prepared,history,background,old = problem(case)
        for steps in (32,64):
            run = load(ROOT/(case+'-growth-'+str(steps)+'.npz'))
            checks[case+'_'+str(steps)+'_original_clock'] = np.array_equal(run['elapsed'],prepared['elapsed'])
            checks[case+'_'+str(steps)+'_max_step'] = run['max_physical_step'] == prepared['elapsed'][8]/steps
            checks[case+'_'+str(steps)+'_finite'] = all(np.isfinite(values).all() for values in run.values())
        checks[case+'_initial_curvature_match'] = np.array_equal(load(ROOT/(case+'-growth-coefficients.npz'))['initial_error'],np.zeros((902,2)))
        for window,values in report['windows'].items():
            checks[case+'_'+window+'_correction_gate'] = all(row['with_working_uncertainty']['passed'] for row in values['volterra_8'].values())
            checks[case+'_'+window+'_observable_gate'] = all(row['original_observable_gate']['passed'] for row in values['volterra_8'].values())
        checks[case+'_node_states'] = all(row['passed'] for row in report['node_state_checks'].values())
        checks[case+'_no_fitted_exponent'] = report['no_exponent_fitted']
    checks['failed_local_approximation_retained'] = not read(ROOT/'heavy-growth-result.json')['windows']['extension']['local_fourth_fifth']['P']['raw']['passed']
    checks = {name:bool(value) for name,value in checks.items()}
    write('validation-v2.json',dict(passed=all(checks.values()),checks=checks,count=len(checks),goal_left_paused=True))
    require(all(checks.values()),'final validation '+str({name:passed for name,passed in checks.items() if not passed}))
    print(json.dumps(dict(passed=True,checks=len(checks))))
