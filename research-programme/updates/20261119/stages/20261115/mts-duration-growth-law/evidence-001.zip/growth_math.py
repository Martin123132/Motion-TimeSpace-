from support import *
import math
import numpy as np

metric = sealed_module('growth_metric', PREVIOUS, 'metric_math.py')
SourceHistory = sealed_module('growth_history', OLDER, 'source_history.py').SourceHistory
weighted = metric.weighted

def problem(case):
    prepared = load(PREVIOUS/(case+'-initial-state.npz'))
    prepared['elapsed'] = load(LAST/(case+'-extension-plan.npz'))['elapsed']
    old = load(OLDER/(case+'-history-preparation.npz'))
    control = load(LAST/(case+'-source-frozen.npz'))
    history = SourceHistory(control['cells'], control['power'], prepared['times'], float(prepared['elapsed'][-1]), prepared['other0'], prepared['other1'], old['curvature'])
    background = metric.Background(load(SOURCE/(case+'-native-clock.npz')), load(EARLY/'runs/backgrounds'/(case+'.npz')))
    return prepared, history, background, old

def output_jet(case, prepared, background):
    mapping = metric.terminal_map(case, 0., prepared, background)/prepared['norm'][:,None,:]
    derivative = np.zeros_like(mapping)
    if case == 'heavy':
        values = background.evaluate(prepared['times'])
        field, velocity, field_prime, velocity_prime, field_second, velocity_second, mass2 = values['jets'][1]
        beta = values['scale']/prepared['density0']
        potential_prime = beta*mass2*(3*values['rate']*field+field_prime)
        kinetic_prime = beta*(values['rate']*velocity+velocity_prime)
        derivative[:,0,0], derivative[:,0,1] = potential_prime, kinetic_prime
        derivative[:,1,0] = prepared['wave']*kinetic_prime
        derivative[:,2,0], derivative[:,2,1] = -potential_prime, kinetic_prime
    return mapping, derivative

def coefficients(case, prepared, history, background):
    matrix, matrix_prime, forcing, forcing_prime = metric.geometry(case, 0., prepared, background)
    mapping, mapping_prime = output_jet(case, prepared, background)
    initial_error = history.coefficients[:,0,0]
    first = history.coefficients[:,0,1]/history.width[:,0,None]
    second = 2*history.coefficients[:,0,2]/history.width[:,0,None]**2
    require(np.array_equal(initial_error, np.zeros_like(initial_error)), 'zero initial represented curvature mismatch')
    forcing_first = np.einsum('nij,nj->ni',forcing,first)
    state_four = forcing_first/24
    state_five = (np.einsum('nij,nj->ni',matrix,forcing_first)/120
                  +np.einsum('nij,nj->ni',forcing_prime,first)/30
                  +np.einsum('nij,nj->ni',forcing,second)/120)
    output_four = np.einsum('nci,ni->nc',mapping,state_four)
    output_five = np.einsum('nci,ni->nc',mapping,state_five)+np.einsum('nci,ni->nc',mapping_prime,state_four)
    return dict(state_four=state_four,state_five=state_five,output_four=output_four,output_five=output_five,weighted_four=weighted(prepared['weights'],output_four),weighted_five=weighted(prepared['weights'],output_five),curvature_first=first,curvature_second=second,initial_error=initial_error,first_cell_width=history.width[:,0],matrix=matrix,forcing=forcing,forcing_prime=forcing_prime)

def source_moment(history, elapsed, degree):
    total = np.zeros((history.count,2), dtype=np.longdouble)
    if elapsed == 0:
        return np.asarray(total,dtype=float)
    for segment in range(history.left.shape[1]):
        active = np.flatnonzero((segment < history.lengths)&(history.left[:,segment] < elapsed))
        if not len(active):
            continue
        width = history.width[active,segment].astype(np.longdouble)
        distance = np.longdouble(elapsed)-history.left[active,segment].astype(np.longdouble)
        fraction = np.minimum(distance/width,1)
        power = history.coefficients[active,segment].astype(np.longdouble)
        local = np.zeros((len(active),2),dtype=np.longdouble)
        for exponent in range(power.shape[1]):
            integral = np.zeros(len(active),dtype=np.longdouble)
            for term in range(degree+1):
                integral += math.comb(degree,term)*distance**(degree-term)*(-width)**term*fraction**(exponent+term+1)/(exponent+term+1)
            local += power[:,exponent]*integral[:,None]*width[:,None]/math.factorial(degree)
        total[active] += local
    return np.asarray(total,dtype=float)

def moments_prediction(case, prepared, history, background, jets):
    predictions, leading = [], []
    for elapsed in prepared['elapsed']:
        integral = source_moment(history,float(elapsed),2)
        lag = source_moment(history,float(elapsed),3)
        timed = elapsed*integral-lag
        state_zero = np.einsum('nij,nj->ni',jets['forcing'],integral)
        state_one = (np.einsum('nij,nj->ni',jets['matrix'],np.einsum('nij,nj->ni',jets['forcing'],lag))
                     +np.einsum('nij,nj->ni',jets['forcing_prime'],timed))
        leading.append(weighted(prepared['weights'],metric.readout(case,float(elapsed),state_zero,prepared,background)))
        predictions.append(weighted(prepared['weights'],metric.readout(case,float(elapsed),state_zero+state_one,prepared,background)))
    return np.asarray(leading),np.asarray(predictions)
