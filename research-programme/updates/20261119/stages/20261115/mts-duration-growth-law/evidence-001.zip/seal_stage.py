from support import *

with worker('seal-stage'):
    require(read(ROOT/'validation-v2.json')['passed'],'validated stage')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    outcomes = []
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name == 'seal-stage-start.json':
            continue
        identity = read(path)
        outcome = exited(identity)
        require(outcome['exited'],'worker exited '+path.name)
        completion = read(path.with_name(path.name.replace('-start.json','-end.json')))
        if path.name == 'verify-stage-start.json':
            require(completion['state']=='failed' and 'not JSON serializable' in completion.get('error',''),'recorded validation-only serialization failure')
        else:
            require(completion['state']=='completed','worker completion')
        outcomes.append(dict(receipt=path.name,identity=identity,outcome=outcome,completion=completion['state']))
    write('preseal-validation.json',dict(passed=True,workers=outcomes,no_native_workers_or_compilers_started=True,continuing_jobs=[]))

artifacts = {path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(stage='duration-growth-law',date='2026-11-15',completed=True,previous=str(LAST),previous_closeout_sha256=PIN,artifacts=artifacts,frozen_inputs=read(ROOT/'frozen-inputs.json'),validation_passed=True,result=read(ROOT/'result.json'),next='Acquire first missing block2909..2916 toward selected endpoint2924 with frozen source/reference and response gates',goal_left_paused=True,github_action=False,continuing_jobs=[],cleanup_receipt='CLEANUP-VERIFIED.json'))
print(json.dumps(dict(completed=True,artifacts=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'))))
