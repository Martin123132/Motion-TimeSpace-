from growth_math import *

with worker('select-window'):
    require(read(ROOT/'result.json')['passed'], 'completed-window checks')
    choices, examples = {}, {}
    for case in ('cold','heavy'):
        prepared, history, background, old = problem(case)
        saved_path = SPECTRUM/'runs/exact-grid/chunk-0384.npz' if case == 'heavy' else EARLY/'runs/final-bg8-start/cold.npz'
        clock = load(saved_path)['conformal_time']
        current_duration = float(prepared['elapsed'][-1])
        rows = []
        for additional in (8,16,32):
            endpoint = 2908+additional
            duration = float(clock[endpoint]-clock[2892])
            require(duration > current_duration, 'later native clock')
            ratios = []
            for offset in np.linspace(0.,duration,17):
                matrix,forcing = metric.normalized_geometry(case,float(offset),prepared,background)
                require(np.isfinite(matrix).all() and np.isfinite(forcing).all(), 'background supports candidate')
                ratios.append(float(np.max(np.sum(abs(matrix),axis=2))))
            rows.append(dict(additional_original_intervals=additional,endpoint_index=endpoint,elapsed=duration,duration_ratio=duration/current_duration,within_doubling=bool(duration <= 2*current_duration),sampled_normalized_matrix_norm=max(ratios),sampled_norm_times_duration=duration*max(ratios),matrix_sampling_is_not_a_certified_bound=True))
        choices[case] = rows
        jets = load(ROOT/(case+'-growth-coefficients.npz'))
        duration = rows[1]['elapsed']
        examples[case] = dict(pure_local_fourth=(duration**4*jets['weighted_four']).tolist(),pure_local_fourth_plus_fifth=(duration**4*jets['weighted_four']+duration**5*jets['weighted_five']).tolist(),usable_as_future_prediction=False,reason='MTS local truncation fails existing-window correction gate; these are explicit counterexamples to substituting a power law for full history.')
    eligible = [row['endpoint_index'] for row in choices['heavy'] if row['within_doubling'] and next(other for other in choices['cold'] if other['endpoint_index']==row['endpoint_index'])['within_doubling']]
    selected = max(eligible)
    require(selected == 2924, 'largest frozen candidate within doubling')
    write('next-window-contract.json',dict(selected_endpoint_index=selected,new_intervals=16,acquisition_batches=[[2909,2916],[2917,2924]],retained_control_indices=[2892,2908],target_report_indices=[2892,2924],choices=choices,growth_law='Corner-aware time-dependent Volterra response, not fitted T power',local_density_pressure_order=4,local_current_order=5,retained_interaction_orders=list(range(9)),candidate_evaluations='Saved clock and background only; no missing source/performance inspected',future_gate=GATE,future_algebra_gate=ALGEBRA,future_solver=dict(method='DOP853',rtol=1e-10,normalized_atol=1e-12,max_physical_step='original short duration/32 and /64'),required_before_future_pass=['Obtain missing native source cells without extrapolation','Freeze reconstructed-source predictions before sixth/five-sixths tests','Direct native 902-shifted-time reference for new reports','Compare resolved direct difference evolution with the eight-interaction expansion','Extend terminal gains and uncertainty budget to new endpoint','Preserve all17 old reports and carry original quadratic origin and difference state'],forecast_not_promoted=examples,goal_left_paused=True,job_launched=False))
    print(json.dumps(dict(endpoint=selected,new_intervals=16,choices=choices)),flush=True)
