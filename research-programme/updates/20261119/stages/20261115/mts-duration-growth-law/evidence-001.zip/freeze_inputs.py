from support import *

with worker('freeze-inputs'):
    cleanup = read(LAST/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['external_checker_exit_verified'], 'previous cleanup')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'], 'old worker not active')
    frozen = read(LAST/'frozen-inputs.json')
    for directory in (LAST, OLDER):
        seal = read(directory/'closeout.json')
        frozen[str(directory/'closeout.json')] = digest(directory/'closeout.json')
        for name, record in seal['artifacts'].items():
            path = directory/name
            require(path.stat().st_size == record['bytes'] and digest(path) == record['sha256'], 'sealed artifact '+name)
            frozen[str(path)] = record['sha256']
    check_hashes(frozen)
    write('frozen-inputs.json', frozen)
    write('protocol-freeze.json', {str(path):digest(path) for path in ROOT.iterdir() if path.suffix in ('.py','.md')})
    print(json.dumps(dict(inputs=len(frozen), previous_sealed_artifacts=90, older_sealed_artifacts=49)))
