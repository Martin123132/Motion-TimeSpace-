from extension_math import *
import argparse
from scipy.integrate import solve_ivp

parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case

with worker(case+'-extend'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'source-validation.json')['passed'],'source checks passed')
    prepared,history,background,old_preparation,control=problem(case)
    frozen={str(ROOT/name):digest(ROOT/name) for name in ('run_extension.py','extension_math.py','support.py','PROTOCOL.md',case+'-source-frozen.npz',case+'-extended-preparation.npz')}
    write(case+'-evolution-code.json',frozen)
    norm=prepared['norm']
    amplitude=old_preparation['diagnostic_amplitude']
    elapsed=prepared['elapsed']
    begin,end=float(elapsed[8]),float(elapsed[-1])
    shape=prepared['state'].shape
    def derivative(offset,flat,mode):
        guard()
        matrix,forcing=metric.normalized_geometry(case,offset,prepared,background)
        source=history.remainder(offset)/amplitude[:,None] if mode=='difference' else history.evaluate(offset) if mode=='history' else history.quadratic(offset)
        return (np.einsum('nij,nj->ni',matrix,flat.reshape(shape))+np.einsum('nij,nj->ni',forcing,source)).ravel()
    hashes={}
    for steps in (32,64):
        old=load(LAST/(case+'-source-history-'+str(steps)+'.npz'))
        old_quad=load(QUADRATIC/(case+'-both-quadratic-'+str(steps)+'.npz'))
        states={}
        counts={}
        for mode,initial,normalization,prefix in (
            ('history',old['state'][-1],norm,old['state']),
            ('quadratic',old_quad['state'][-1],norm,old_quad['state']),
            ('difference',old['delta_state'][-1],norm*amplitude[:,None],old['delta_state'])):
            solution=solve_ivp(lambda offset,flat:derivative(offset,flat,mode),(begin,end),(initial/normalization).ravel(),method='DOP853',t_eval=elapsed[8:],rtol=1e-10,atol=1e-12,max_step=begin/steps)
            require(solution.success and solution.y.shape==(initial.size,9),'eight-epoch restart completed '+mode)
            tail=solution.y.T.reshape(9,*shape)*normalization[None,:,:]
            states[mode]=np.concatenate((prefix,tail[1:]))
            require(np.array_equal(states[mode][:9],prefix),'old state rows byte-identical')
            counts[mode]=solution.nfev
        outputs={}
        for mode,prefix in (('history',old),('quadratic',old_quad),('difference',old)):
            key='delta_node_source' if mode=='difference' else 'node_source'
            tail=np.array([metric.readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed[9:],states[mode][9:])])
            nodes=np.concatenate((prefix[key],tail))
            if mode=='difference':
                predicted=np.concatenate((old['delta_prediction'],np.array([weighted(prepared['weights'],row) for row in tail])))
                arithmetic=np.zeros_like(predicted)
            else:
                predicted_tail=prepared['initial_weighted_source']+np.array([weighted(prepared['weights'],row-prepared['node_initial_sources']) for row in tail])
                predicted=np.concatenate((prefix['prediction'],predicted_tail))
                direct=np.array([weighted(prepared['weights'],row) for row in nodes])
                arithmetic=abs(predicted-(prepared['initial_weighted_source']+direct-direct[0]))
                arithmetic[:9]=prefix['arithmetic_difference']
            outputs[mode]=dict(nodes=nodes,prediction=predicted,arithmetic=arithmetic)
        force=np.array([metric.metric_force(case,float(offset),state,prepared,background,'density-quadratic')+history.remainder(float(offset))[:,0]/(2*prepared['wave']*background.evaluate(prepared['times']+offset)['hubble']) for offset,state in zip(elapsed[9:],states['history'][9:])])
        force=np.concatenate((old['metric_force'],force))
        sources=load(ROOT/(case+'-extended-preparation.npz'))['source']
        sources[:9]=old['source']
        filename=case+'-extended-'+str(steps)+'.npz'
        np.savez_compressed(ROOT/filename,state=states['history'],quad_state=states['quadratic'],delta_state=states['difference'],node_source=outputs['history']['nodes'],quad_node_source=outputs['quadratic']['nodes'],delta_node_source=outputs['difference']['nodes'],prediction=outputs['history']['prediction'],quad_prediction=outputs['quadratic']['prediction'],delta_prediction=outputs['difference']['prediction'],arithmetic_difference=outputs['history']['arithmetic'],quad_arithmetic_difference=outputs['quadratic']['arithmetic'],metric_force=force,source=sources,elapsed=elapsed,weights=prepared['weights'],max_physical_step=begin/steps)
        hashes[str(ROOT/filename)]=digest(ROOT/filename)
        print(json.dumps(dict(case=case,steps=steps,evaluations=counts)),flush=True)
    write(case+'-run-freeze.json',dict(passed=True,hashes=hashes,old_window_rows_preserved=True,target_comparison_started=False,rtol=1e-10,normalized_atol=1e-12,physical_scaling_unchanged=True))
    check_hashes(frozen)
    check_hashes(read(ROOT/'frozen-inputs.json'))
