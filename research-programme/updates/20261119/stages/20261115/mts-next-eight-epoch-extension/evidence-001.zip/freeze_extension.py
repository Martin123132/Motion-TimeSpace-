from support import *
import numpy as np

metric=sealed_module('extension_metric',PREVIOUS,'metric_math.py')
with worker('freeze-extension'):
    cleanup=read(LAST/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['external_checker_exit_verified'],'previous cleanup')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'],'previous worker exited')
    frozen=read(LAST/'frozen-inputs.json')
    for directory,names in (
        (LAST,['closeout.json','source_history.py','support.py','cold-source-history-32.npz','cold-source-history-64.npz','heavy-source-history-32.npz','heavy-source-history-64.npz','cold-history-preparation.npz','heavy-history-preparation.npz','cold-comparison.npz','heavy-comparison.npz']),
        (PREVIOUS,['response.py']),
        (CONTROL,['native/camb/cambdll.dll','native-build-frozen.json','native-build-result.json','cell_math.py','variation_math.py'])):
        seal=read(directory/'closeout.json')
        for name in names:
            path=directory/name
            if name!='closeout.json':
                require(digest(path)==seal['artifacts'][name]['sha256'],'sealed input '+name)
            frozen[str(path)]=digest(path)
    frozen.update(read(CONTROL/'native-build-frozen.json'))
    for case in ('cold','heavy'):
        saved=load(SPECTRUM/'runs/exact-grid/chunk-0384.npz' if case=='heavy' else EARLY/'runs/final-bg8-start/cold.npz')
        clock=saved['conformal_time']
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        reports=clock[2892:2909]
        elapsed=reports-reports[0]
        require(np.array_equal(elapsed[:9],prepared['elapsed']),'old report times unchanged')
        require(np.array_equal(prepared['times'],clock[1991:2893]),'same902 initial times')
        background=metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        boundaries=np.asarray(background.boundaries(float(clock[2900]),float(clock[2908])))
        boundaries=boundaries[(boundaries>clock[2900])&(boundaries<clock[2908])]
        cells,source_requests=[],[]
        for gap in range(2900,2908):
            left,right=clock[gap:gap+2]
            splits=np.concatenate(([left],boundaries[(boundaries>left)&(boundaries<right)],[right]))
            for part,(begin,end) in enumerate(zip(splits[:-1],splits[1:])):
                index=len(cells)
                cells.append((begin,end,gap,part))
                for fraction in (.25,.5,.75):
                    source_requests.append((begin+fraction*(end-begin),index,fraction,0))
                if begin!=left:
                    offset=min(1e-10,.01*(end-begin))
                    require(offset>=128*np.spacing(begin),'resolvable right-side offset')
                    source_requests.append((begin+offset,index,0.,1))
                if end!=right:
                    offset=min(1e-10,.01*(end-begin))
                    require(offset>=128*np.spacing(end),'resolvable left-side offset')
                    source_requests.append((end-offset,index,1.,-1))
        source_requests=np.array(sorted(source_requests))
        query_times=prepared['times'][None,:]+elapsed[9:,None]
        times=np.unique(np.concatenate((source_requests[:,0],query_times.ravel(),clock[1992:2909])))
        require(times[0]>clock[1991] and times[-1]<=clock[2908],'native query coverage')
        np.savez_compressed(ROOT/(case+'-extension-plan.npz'),cells=np.array(cells),source_requests=source_requests,query_times=query_times,requests=times,elapsed=elapsed,report_times=reports,clock=clock[1991:2909],boundaries=boundaries)
        write(case+'-plan-freeze.json',dict(passed=True,sha256=digest(ROOT/(case+'-extension-plan.npz')),new_intervals=8,new_cells=len(cells),native_queries=len(times),same_physical_grids=True,target_performance_inspected=False))
        print(json.dumps(dict(case=case,new_cells=len(cells),queries=len(times),duration=float(elapsed[-1]))),flush=True)
    check_hashes(frozen)
    write('frozen-inputs.json',frozen)
    write('protocol-freeze.json',{str(ROOT/name):digest(ROOT/name) for name in ('support.py','PROTOCOL.md','freeze_extension.py')})
