from extension_math import *

with worker('check-source'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    results={}
    for case in ('cold','heavy'):
        require(read(ROOT/(case+'-validation-validation.json'))['passed'],'native validation passed')
        require(exited(read(ROOT/(case+'-validation-capture-start.json')))['exited'],'native worker exited')
        freeze=read(ROOT/(case+'-source-freeze.json'))
        require(digest(ROOT/(case+'-source-frozen.npz'))==freeze['sha256'],'source freeze unchanged')
        prepared,history,background,old_preparation,control=problem(case)
        fresh=load(ROOT/(case+'-validation-capture.npz'))
        positions=np.searchsorted(fresh['query_times'],control['validation_requests'][:,0])
        require(np.array_equal(fresh['query_times'][positions],control['validation_requests'][:,0]),'fresh source queries present')
        actual=source_jet(fresh['probes'][positions],case)[:,2]
        error=control['validation_prediction']-actual
        scale=np.max(abs(np.vstack((actual,old_preparation['curvature']))),axis=0)
        checks={name+'_fresh_curvature':comparison(error[:,channel],0,scale=scale[channel]) for channel,name in enumerate(('D','Q'))}
        sources=np.array([history.evaluate(float(offset)) for offset in prepared['elapsed']])
        old_run=load(LAST/(case+'-source-history-64.npz'))
        checks['old_source_history']=comparison(sources[:9],old_run['source'],ALGEBRA)
        boundary=source_jet(fresh['packet'],case)[901:,0]
        for channel,name in enumerate(('D','Q')):
            checks[name+'_extended_boundary_source']=comparison(sources[:,-1,channel],boundary[:,channel])
        variation=np.array([cells_math.cell_variation(control['cells'],control['power'],float(begin),float(begin+prepared['elapsed'][-1]),initial) for begin,initial in zip(prepared['times'],old_preparation['curvature'])])
        checks['nonnegative_extended_variation']=dict(passed=bool(np.all(variation>=0)))
        checks['old_diagnostic_scaling']=dict(passed=bool(np.all(old_preparation['diagnostic_amplitude']>0)))
        np.savez_compressed(ROOT/(case+'-extended-preparation.npz'),source=sources,curvature=old_preparation['curvature'],node_variation_bound=variation,diagnostic_amplitude=old_preparation['diagnostic_amplitude'],elapsed=prepared['elapsed'],fresh_curvature_error=error)
        report=dict(passed=all(row['passed'] for row in checks.values()),checks=checks,source_error=np.max(abs(error),axis=0).tolist(),same_tolerances=True,source_fitted=False)
        write(case+'-source-validation.json',report)
        results[case]=report['passed']
        print(json.dumps(dict(case=case,checks=checks)),flush=True)
    write('source-validation.json',dict(passed=all(results.values()),cases=results))
    require(all(results.values()),'paired source checks')
