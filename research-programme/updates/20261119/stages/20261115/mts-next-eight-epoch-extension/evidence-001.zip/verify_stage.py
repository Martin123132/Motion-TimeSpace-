from extension_math import *

with worker('verify-stage'):
    checks={}
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['python_compiles']=True
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'protocol-freeze.json'))
    checks['frozen_inputs_unchanged']=True
    for relative,entry in read(LAST/'closeout.json')['artifacts'].items():
        require(digest(LAST/relative)==entry['sha256'],'previous49 artifacts unchanged '+relative)
    checks['previous49_artifacts_unchanged']=True
    checks['no_pycache']=not any(ROOT.rglob('__pycache__'))
    checks['source_checks']=read(ROOT/'source-validation.json')['passed']
    checks['gain_checks']=read(ROOT/'response-validation.json')['passed']
    result=read(ROOT/'result.json')
    checks['all_requested_checks']=result['all_requested_checks_passed']
    checks['no_continuum_overclaim']=not result['uniform_continuum_bound_claimed']
    checks['same_gates']=GATE==2e-5 and ALGEBRA==1e-10
    for case in ('cold','heavy'):
        for phase in ('construction','validation'):
            checks[case+'_'+phase+'_capture']=read(ROOT/(case+'-'+phase+'-validation.json'))['passed']
            release=read(ROOT/(case+'-'+phase+'-owner-release.json'))
            checks[case+'_'+phase+'_released']=release['cleared'] and release['native_reference_released']
            check_hashes(read(ROOT/(case+'-'+phase+'-code-freeze.json')))
        freeze=read(ROOT/(case+'-source-freeze.json'))
        checks[case+'_source_freeze']=digest(ROOT/(case+'-source-frozen.npz'))==freeze['sha256'] and not freeze['new_probe_values_loaded']
        checks[case+'_one_sided_checks']=all(row['passed'] for row in freeze['one_sided_checks'].values())
        runfreeze=read(ROOT/(case+'-run-freeze.json'))
        check_hashes(runfreeze['hashes'])
        check_hashes(read(ROOT/(case+'-evolution-code.json')))
        checks[case+'_same_solver_accuracy']=runfreeze['rtol']==1e-10 and runfreeze['normalized_atol']==1e-12
        report=read(ROOT/(case+'-result.json'))
        checks[case+'_old_window_bit_identical']=report['prefix_passed']
        checks[case+'_all17_reports']=len(report['epoch_pass'])==17 and all(report['epoch_pass'])
        checks[case+'_new_reference']=report['old_uncertainties_not_extrapolated'] and report['original_reference_scales_retained']
        for name in ('boundary_passed','external_passed','superposition_passed','node_state_superposition_passed','difference_refinement_passed','response_passed'):
            checks[case+'_'+name]=report[name]
        prepared,history,background,old_preparation,control=problem(case)
        gain=load(ROOT/(case+'-extended-response.npz'))
        checks[case+'_longer_endpoint_gain']=float(gain['duration'])==prepared['elapsed'][-1] and gain['duration']>prepared['elapsed'][8]
        checks[case+'_gain_step_not_enlarged']=float(gain['duration'])/int(gain['fine_steps'])<=prepared['elapsed'][8]/64 and float(gain['duration'])/int(gain['coarse_steps'])<=prepared['elapsed'][8]/32
        for steps in (32,64):
            run=load(ROOT/(case+'-extended-'+str(steps)+'.npz'))
            checks[case+'_'+str(steps)+'_finite']=all(np.isfinite(value).all() for value in run.values())
            checks[case+'_'+str(steps)+'_physical_step']=float(run['max_physical_step'])==prepared['elapsed'][8]/steps
            if case=='cold':
                checks['cold_'+str(steps)+'_dust_zeros']=not np.count_nonzero(run['node_source'][:,:,1:]) and not np.count_nonzero(run['delta_node_source'][:,:,1:])
    require(all(checks.values()),'final validation '+str({name:value for name,value in checks.items() if not value}))
    write('validation.json',dict(passed=True,checks={name:bool(value) for name,value in checks.items()},check_count=len(checks),goal_left_paused=True))
    print(json.dumps(dict(passed=True,checks=len(checks))),flush=True)
