import hashlib
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
LAST=POST/'mts-corner-safe-source-evolution-20261115'
assert hashlib.sha256((LAST/'closeout.json').read_bytes()).hexdigest()=='c0f9098a00d2568278f9e434793ada7463c2e20a7928019ad27e949c9472b35c'
assert hashlib.sha256((LAST/'support.py').read_bytes()).hexdigest()==json.loads((LAST/'closeout.json').read_text())['artifacts']['support.py']['sha256']
spec=importlib.util.spec_from_file_location('retained_extension_support',LAST/'support.py')
retained=importlib.util.module_from_spec(spec)
spec.loader.exec_module(retained)
retained.retained.retained.base.ROOT=ROOT
CONTROL,PREVIOUS,QUADRATIC=retained.CONTROL,retained.PREVIOUS,retained.QUADRATIC
SOURCE,ORIGIN,MIDPOINT=retained.SOURCE,retained.ORIGIN,retained.MIDPOINT
EARLY,BRANCH,SPECTRUM,MATCHING=retained.EARLY,retained.BRANCH,retained.SPECTRUM,retained.MATCHING
require,read,write,guard=retained.require,retained.read,retained.write,retained.guard
worker,exited,check_hashes=retained.worker,retained.exited,retained.check_hashes
digest,load=retained.digest,retained.load
sealed_module,retained_module=retained.sealed_module,retained.retained_module
GATE,ALGEBRA=retained.GATE,retained.ALGEBRA
os,sys,time,psutil=retained.os,retained.sys,retained.time,retained.psutil
