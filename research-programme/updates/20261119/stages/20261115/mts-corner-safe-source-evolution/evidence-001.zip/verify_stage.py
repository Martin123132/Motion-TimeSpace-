from support import *
import numpy as np

with worker('verify-stage'):
    checks={}
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['all_python_compiles']=True
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'protocol-freeze.json')['hashes'])
    checks['inputs_protocol_unchanged']=True
    for relative,entry in read(CONTROL/'closeout.json')['artifacts'].items():
        require(digest(CONTROL/relative)==entry['sha256'],'previous artifact unchanged '+relative)
    checks['previous_325_artifacts_unchanged']=True
    checks['no_pycache']=not any(ROOT.rglob('__pycache__'))
    checks['source_integral_checks']=read(ROOT/'history-validation.json')['passed']
    result=read(ROOT/'result.json')
    checks['all_requested_checks']=result['all_requested_checks_passed']
    checks['no_continuum_overclaim']=not result['uniform_continuum_bound_claimed']
    for case in ('cold','heavy'):
        freeze=read(ROOT/(case+'-run-freeze.json'))
        check_hashes(freeze['hashes'])
        check_hashes(read(ROOT/(case+'-evolution-code.json')))
        checks[case+'_run_frozen']=freeze['passed'] and not freeze['parameters_fitted'] and not freeze['final_target_values_loaded']
        checks[case+'_same_solver_tolerances']=freeze['rtol']==1e-10 and freeze['normalized_atol']==1e-12
        report=read(ROOT/(case+'-result.json'))
        checks[case+'_all_eight_intervals']=len(report['epoch_pass'])==9 and all(report['epoch_pass'])
        for label in ('boundary_passed','external_passed','difference_refinement_passed','superposition_passed','response_envelope_passed','final_total_passed'):
            checks[case+'_'+label]=report[label]
        checks[case+'_node_state_superposition']=report['node_state_superposition']['passed']
        packets=[load(ROOT/(case+'-source-history-'+str(steps)+'.npz')) for steps in (32,64)]
        checks[case+'_same_reports']=np.array_equal(packets[0]['elapsed'],packets[1]['elapsed'])
        checks[case+'_same_sources']=np.array_equal(packets[0]['source'],packets[1]['source'])
        checks[case+'_finite_packets']=all(np.isfinite(value).all() for packet in packets for value in packet.values())
        if case=='cold':
            checks['baseline_zero_current_pressure']=all(np.count_nonzero(packet['node_source'][:,:,1:])==0 and np.count_nonzero(packet['delta_node_source'][:,:,1:])==0 for packet in packets)
    checks['unchanged_gate']=GATE==2e-5 and ALGEBRA==1e-10
    check_hashes(read(ROOT/'scoring-code-freeze.json'))
    require(all(checks.values()),'stage checks '+str({name:value for name,value in checks.items() if not value}))
    write('validation.json',dict(passed=True,checks={name:bool(value) for name,value in checks.items()},check_count=len(checks),goal_left_paused=True))
    print(json.dumps(dict(passed=True,checks=len(checks))),flush=True)
