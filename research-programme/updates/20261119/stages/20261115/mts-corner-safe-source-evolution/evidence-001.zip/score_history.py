from support import *
import numpy as np

metric=sealed_module('score_metric',PREVIOUS,'metric_math.py')
weighted=metric.weighted

def comparison(actual,expected,tolerance=GATE,scale=None):
    return metric.comparison(np.asarray(actual),np.asarray(expected),tolerance,scale=scale)

def weighted_absolute(weights,values):
    return np.array([weighted(abs(weights),abs(row)) for row in values])

def readout_rounding(case,elapsed,states,prepared,background):
    totals=[]
    for offset,state in zip(elapsed,states):
        mapping=metric.terminal_map(case,float(offset),prepared,background)
        absolute_node=np.einsum('nci,ni->nc',abs(mapping),abs(state/prepared['norm']))
        totals.append(64*np.finfo(float).eps*weighted(abs(prepared['weights']),absolute_node))
    return np.array(totals)

with worker('score-history'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('scoring-code-freeze.json',{str(ROOT/name):digest(ROOT/name) for name in ('score_history.py','source_history.py','support.py','PROTOCOL.md')})
    reports={}
    for case in ('cold','heavy'):
        freeze=read(ROOT/(case+'-run-freeze.json'))
        require(freeze['passed'] and not freeze['final_target_values_loaded'] and not freeze['parameters_fitted'],'predictions frozen before scoring')
        require(exited(read(ROOT/(case+'-evolve-start.json')))['exited'],'evolution worker exited')
        check_hashes(freeze['hashes'])
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        fine=load(ROOT/(case+'-source-history-64.npz'))
        coarse=load(ROOT/(case+'-source-history-32.npz'))
        old=load(QUADRATIC/(case+'-both-quadratic-64.npz'))
        old_coarse=load(QUADRATIC/(case+'-both-quadratic-32.npz'))
        prior_budget=load(CONTROL/(case+'-corner-safe-budget.npz'))
        target=load(MIDPOINT/(case+'-tested-readout.npz'))
        expected=target['corrected_readout']
        scale=np.max(abs(expected),axis=0)
        elapsed=fine['elapsed']
        require(np.array_equal(elapsed,old['elapsed']) and np.array_equal(elapsed,target['current_time']-target['current_time'][0]),'original nine reporting epochs')
        require(np.array_equal(fine['weights'],prepared['weights']) and np.array_equal(coarse['weights'],prepared['weights']),'same signed preparation weights')
        weights=prepared['weights']
        numerical=weighted_absolute(weights,fine['node_source']-coarse['node_source'])
        old_numerical=weighted_absolute(weights,old['node_source']-old_coarse['node_source'])
        difference_numeric=weighted_absolute(weights,fine['delta_node_source']-coarse['delta_node_source'])
        target_allowance=target['updated_working_budget']
        recapture_allowance=np.broadcast_to(abs(prepared['initial_recapture_difference']),target_allowance.shape)
        budget=target_allowance+recapture_allowance+numerical+fine['arithmetic_difference']
        residual=fine['prediction']-expected
        background=metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        rounding=readout_rounding(case,elapsed,fine['state'],prepared,background)
        old_rounding=readout_rounding(case,elapsed,old['state'],prepared,background)
        difference_rounding=readout_rounding(case,elapsed,fine['delta_state'],prepared,background)
        subtracted=fine['prediction']-old['prediction']
        resolved=fine['delta_prediction']
        subtraction_allowance=numerical+old_numerical+difference_numeric+fine['arithmetic_difference']+old['arithmetic_difference']+rounding+old_rounding+difference_rounding
        superposition_error=subtracted-resolved
        envelope=prior_budget['variation_envelope']
        final_source_uncertainty=prior_budget['observed_error_envelope']
        final_total=abs(residual[-1])+budget[-1]+final_source_uncertainty
        names=('density','current','pressure')
        raw,numeric,response,refinement,superposition={},{},{},{},{}
        for column,name in enumerate(names):
            raw[name]=comparison(fine['prediction'][:,column],expected[:,column])
            numeric[name]=comparison(abs(residual[:,column])+budget[:,column],0,scale=scale[column])
            error=float(np.max(abs(superposition_error[:,column])-subtraction_allowance[:,column]))
            superposition[name]=dict(passed=bool(error<=0),maximum_excess_over_allowance=error,maximum_absolute_discrepancy=float(np.max(abs(superposition_error[:,column]))),maximum_allowance=float(np.max(subtraction_allowance[:,column])))
            delta_scale=float(np.max(abs(resolved[:,column])))
            refinement[name]=comparison(difference_numeric[:,column],0,scale=delta_scale)
            response[name]=dict(passed=bool(abs(resolved[-1,column])<=envelope[column]+difference_numeric[-1,column]+difference_rounding[-1,column]),actual_final_delta=float(resolved[-1,column]),previous_envelope=float(envelope[column]),refinement_allowance=float(difference_numeric[-1,column]),rounding_allowance=float(difference_rounding[-1,column]),fraction_of_envelope=float(abs(resolved[-1,column])/envelope[column]) if envelope[column]>0 else None,full_subtraction_resolves_sign=bool(abs(subtracted[-1,column])>subtraction_allowance[-1,column]),final_including_source_allowance_passed=bool(final_total[column]<=GATE*scale[column]))
        packet=load(QUADRATIC/(case+'-current-readout.npz'))['packet']
        boundary_packet=packet[901:]
        native_state=np.column_stack((boundary_packet[:,39:41] if case=='heavy' else boundary_packet[:,63:64],boundary_packet[:,10]))
        boundary={str(column):comparison(fine['state'][:,-1,column],native_state[:,column]) for column in range(native_state.shape[1])}
        boundary['metric_force']=comparison(fine['metric_force'][:,-1],boundary_packet[:,6])
        reference_sources=load(CONTROL/(case+'-corner-safe-budget.npz'))['boundary_reference']
        external={name:comparison(fine['source'][:,-1,column],reference_sources[:,column]) for column,name in enumerate(('D','Q'))}
        epoch_pass=np.all(abs(residual)+budget<=GATE*scale[None,:],axis=1)
        node_state_error=fine['state']-old['state']-fine['delta_state']
        normalized_state_error=node_state_error/prepared['norm'][None,:,:]
        normalized_state_allowance=(abs(fine['state']-coarse['state'])+abs(old['state']-old_coarse['state'])+abs(fine['delta_state']-coarse['delta_state']))/prepared['norm'][None,:,:]+64*np.finfo(float).eps*(abs(fine['state'])+abs(old['state'])+abs(fine['delta_state']))/prepared['norm'][None,:,:]
        state_superposition=dict(passed=bool(np.all(abs(normalized_state_error)<=normalized_state_allowance)),maximum_normalized_excess=float(np.max(abs(normalized_state_error)-normalized_state_allowance)))
        np.savez_compressed(ROOT/(case+'-comparison.npz'),residual=residual,numerical_budget=budget,numerical_refinement=numerical,target_allowance=target_allowance,initial_recapture_allowance=recapture_allowance,reference_scale=scale,subtracted_change=subtracted,resolved_change=resolved,difference_refinement=difference_numeric,subtraction_allowance=subtraction_allowance,superposition_error=superposition_error,final_envelope=envelope,final_source_uncertainty=final_source_uncertainty,final_total_allowance=final_total,epoch_pass=epoch_pass,boundary_state_reference=native_state,boundary_source_reference=reference_sources,normalized_state_superposition_error=normalized_state_error,normalized_state_superposition_allowance=normalized_state_allowance)
        report=dict(completed=True,raw=raw,residual_plus_numerical_allowance=numeric,raw_passed=all(row['passed'] for row in raw.values()),numerical_passed=all(row['passed'] for row in numeric.values()),boundary=boundary,boundary_passed=all(row['passed'] for row in boundary.values()),external_sources=external,external_passed=all(row['passed'] for row in external.values()),difference_refinement=refinement,difference_refinement_passed=all(row['passed'] for row in refinement.values()),superposition=superposition,superposition_passed=all(row['passed'] for row in superposition.values()),node_state_superposition=state_superposition,response=response,response_envelope_passed=all(row['passed'] for row in response.values()),final_total_passed=all(row['final_including_source_allowance_passed'] for row in response.values()),epoch_pass=epoch_pass.tolist(),final_prediction=fine['prediction'][-1].tolist(),final_resolved_change=resolved[-1].tolist(),final_subtracted_change=subtracted[-1].tolist(),physical_normalization_unchanged=True,original_bank_grids_tolerances_unchanged=True,uniform_continuum_bound_claimed=False,goal_left_paused=True)
        write(case+'-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,numeric={name:row['relative'] for name,row in numeric.items()},boundary=report['boundary_passed'],external=report['external_passed'],response=response,refinement=refinement,superposition=superposition,state_superposition=state_superposition)),flush=True)
    flags=('numerical_passed','boundary_passed','external_passed','difference_refinement_passed','superposition_passed','response_envelope_passed','final_total_passed')
    paired={flag:all(report[flag] for report in reports.values()) for flag in flags}
    write('result.json',dict(completed=True,paired=paired,all_requested_checks_passed=all(paired.values()) and all(report['node_state_superposition']['passed'] for report in reports.values()),uniform_continuum_bound_claimed=False,goal_left_paused=True))
    check_hashes(read(ROOT/'scoring-code-freeze.json'))
    check_hashes(read(ROOT/'frozen-inputs.json'))
