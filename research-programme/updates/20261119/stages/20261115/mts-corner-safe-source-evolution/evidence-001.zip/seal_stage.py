from support import *

with worker('seal-stage'):
    require(read(ROOT/'validation.json')['passed'],'final validation passed')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    outcomes=[]
    for path in ROOT.glob('*-start.json'):
        if path.name=='seal-stage-start.json':
            continue
        identity=read(path)
        outcome=exited(identity)
        require(outcome['exited'],'worker exit '+path.name)
        end=read(path.with_name(path.name.replace('-start.json','-end.json')))
        require(end['state']=='completed','worker completed '+path.name)
        outcomes.append(dict(receipt=path.name,identity=identity,outcome=outcome))
    write('preseal-validation.json',dict(passed=True,workers=outcomes,no_native_compilers_started=True,no_continuing_jobs=True))

artifacts={path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(stage='corner-safe-source-evolution',date='2026-11-15',completed=True,previous=str(CONTROL),previous_closeout_sha256=digest(CONTROL/'closeout.json'),artifacts=artifacts,frozen_inputs=read(ROOT/'frozen-inputs.json'),validation_passed=True,result=read(ROOT/'result.json'),next='Extend by the next small block of saved epochs, preserving the current reports as controls and extending gains before using a later endpoint',goal_left_paused=True,github_action=False,continuing_jobs=[],cleanup_receipt='CLEANUP-VERIFIED.json'))
print(json.dumps(dict(completed=True,artifacts=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'))),flush=True)
