from support import *
import argparse
import numpy as np
from scipy.integrate import solve_ivp
from source_history import SourceHistory

metric = sealed_module('evolution_metric', PREVIOUS, 'metric_math.py')
parser = argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case = parser.parse_args().case

with worker(case+'-evolve'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'history-validation.json')['passed'],'source integral checks passed')
    require(exited(read(ROOT/'prepare-history-start.json'))['exited'],'preparation worker exited')
    freeze = read(ROOT/(case+'-history-freeze.json'))
    require(freeze['passed'] and digest(ROOT/(case+'-history-preparation.npz'))==freeze['sha256'],'frozen source preparation')
    require(digest(CONTROL/(case+'-corner-safe-control-frozen.npz'))==freeze['polynomial_sha256'],'frozen source polynomial')
    code = {str(ROOT/name):digest(ROOT/name) for name in ('run_history.py','source_history.py','support.py','PROTOCOL.md')}
    write(case+'-evolution-code.json',code)
    prepared = load(PREVIOUS/(case+'-initial-state.npz'))
    frozen = load(ROOT/(case+'-history-preparation.npz'))
    control = load(CONTROL/(case+'-corner-safe-control-frozen.npz'))
    elapsed = prepared['elapsed']
    duration = float(elapsed[-1])
    history = SourceHistory(control['cells'],control['power'],prepared['times'],duration,prepared['other0'],prepared['other1'],frozen['curvature'])
    background = metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
    norm, amplitude = prepared['norm'],frozen['diagnostic_amplitude']
    initial = prepared['state']/norm
    def derivative(offset,flat):
        guard()
        matrix, forcing = metric.normalized_geometry(case,offset,prepared,background)
        state = flat.reshape(initial.shape)
        return (np.einsum('nij,nj->ni',matrix,state)+np.einsum('nij,nj->ni',forcing,history.evaluate(offset))).ravel()
    def difference_rhs(offset,flat):
        guard()
        matrix, forcing = metric.normalized_geometry(case,offset,prepared,background)
        state = flat.reshape(initial.shape)
        return (np.einsum('nij,nj->ni',matrix,state)+np.einsum('nij,nj->ni',forcing,history.remainder(offset))/amplitude[:,None]).ravel()
    runs = {}
    for steps in (32,64):
        options = dict(method='DOP853',t_eval=elapsed,rtol=1e-10,atol=1e-12,max_step=duration/steps)
        solution = solve_ivp(derivative,(0.,duration),initial.ravel(),**options)
        require(solution.success and solution.y.shape==(initial.size,len(elapsed)),'full evolution completed')
        states = solution.y.T.reshape(len(elapsed),*initial.shape)*norm[None,:,:]
        sources = np.array([metric.readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed,states)])
        prediction = prepared['initial_weighted_source']+np.array([metric.weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
        direct = np.array([metric.weighted(prepared['weights'],row) for row in sources])
        arithmetic = abs(prediction-(prepared['initial_weighted_source']+direct-direct[0]))
        force = np.array([metric.metric_force(case,float(offset),state,prepared,background,'density-quadratic') for offset,state in zip(elapsed,states)])
        for index, offset in enumerate(elapsed):
            values = background.evaluate(prepared['times']+offset)
            force[index] += history.remainder(float(offset))[:,0]/(2*prepared['wave']*values['hubble'])
        difference = solve_ivp(difference_rhs,(0.,duration),np.zeros(initial.size),**options)
        require(difference.success and difference.y.shape==(initial.size,len(elapsed)),'difference evolution completed')
        differences = difference.y.T.reshape(len(elapsed),*initial.shape)*(norm*amplitude[:,None])[None,:,:]
        difference_sources = np.array([metric.readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed,differences)])
        difference_prediction = np.array([metric.weighted(prepared['weights'],row) for row in difference_sources])
        require(np.isfinite(states).all() and np.isfinite(differences).all() and np.isfinite(prediction).all(),'finite coupled response')
        filename=case+'-source-history-'+str(steps)+'.npz'
        np.savez_compressed(ROOT/filename,state=states,node_source=sources,prediction=prediction,metric_force=force,arithmetic_difference=arithmetic,delta_state=differences,delta_node_source=difference_sources,delta_prediction=difference_prediction,elapsed=elapsed,weights=prepared['weights'],source=frozen['report_source'],source_remainder=frozen['report_remainder'],steps=steps,full_nfev=solution.nfev,difference_nfev=difference.nfev)
        runs[str(ROOT/filename)]=digest(ROOT/filename)
        print(json.dumps(dict(case=case,steps=steps,full_evaluations=solution.nfev,difference_evaluations=difference.nfev)),flush=True)
    write(case+'-run-freeze.json',dict(passed=True,hashes=runs,rtol=1e-10,normalized_atol=1e-12,physical_normalization_unchanged=True,final_target_values_loaded=False,parameters_fitted=False))
    check_hashes(code)
    check_hashes(read(ROOT/'frozen-inputs.json'))
