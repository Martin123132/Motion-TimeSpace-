from support import *
import numpy as np
from source_history import SourceHistory

metric = sealed_module('history_metric', PREVIOUS, 'metric_math.py')
cell_math = sealed_module('history_cell_math', CONTROL, 'cell_math.py')

def comparison(actual, expected, tolerance=ALGEBRA, scale=None):
    return metric.comparison(np.asarray(actual), np.asarray(expected), tolerance, scale=scale)

with worker('prepare-history'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'protocol-freeze.json')['hashes'])
    checks = {}
    cells = np.array([[0., .5], [.5, 1.]])
    power = np.zeros((2, 5, 2))
    power[0, 0], power[0, 1] = [2., 7.], [1.5, -1.]
    power[1, 0], power[1, 1] = [3.5, 6.], [1.5, -1.]
    starts = np.array([0., .1])
    initial_curvature = np.column_stack((2+3*starts, 7-2*starts))
    example = SourceHistory(cells, power, starts, .7, np.zeros((2,2)), np.zeros((2,2)), initial_curvature)
    for offset in (0., .125, .3, .5, .7):
        expected = np.tile(np.array([3.,-2.])*offset**3/6, (2,1))
        checks['affine_curvature_'+str(offset)] = comparison(example.remainder(offset), expected)
    constant = SourceHistory(cells, power*0+np.array([[[4.,4.],[0.,0.],[0.,0.],[0.,0.],[0.,0.]]]), starts, .7, np.ones((2,2)), np.zeros((2,2)), np.full((2,2),4.))
    checks['constant_curvature_zero_remainder'] = comparison(constant.remainder(.7), np.zeros((2,2)))
    checks['constant_curvature_source'] = comparison(constant.evaluate(.7), np.full((2,2),1+.5*.7**2*4))
    for case in ('cold','heavy'):
        prepared = load(PREVIOUS/(case+'-initial-state.npz'))
        control = load(CONTROL/(case+'-corner-safe-control-frozen.npz'))
        curvature = np.column_stack((prepared['other_density_second'],load(QUADRATIC/(case+'-frozen-current.npz'))['other_current_second']))
        duration = float(prepared['elapsed'][-1])
        history = SourceHistory(control['cells'], control['power'], prepared['times'], duration, prepared['other0'], prepared['other1'], curvature)
        offsets = prepared['elapsed']
        remainder = np.array([history.remainder(float(offset)) for offset in offsets])
        sources = np.array([history.evaluate(float(offset)) for offset in offsets])
        selected = np.unique(np.linspace(0,len(prepared['times'])-1,19).astype(int))
        reference = np.array([[cell_math.cell_integral(control['cells'],control['power'],float(prepared['times'][node]),float(prepared['times'][node]+offset),curvature[node]) for node in selected] for offset in offsets])
        for channel, name in enumerate(('D','Q')):
            checks[case+'_'+name+'_independent_local_integral'] = comparison(remainder[:,selected,channel],reference[:,:,channel])
            prior = load(CONTROL/(case+'-corner-safe-budget.npz'))['boundary_prediction']
            checks[case+'_'+name+'_saved_boundary_source'] = comparison(sources[:,-1,channel],prior[:,channel])
        checks[case+'_initial_source'] = comparison(sources[0],prepared['other0'])
        checks[case+'_zero_initial_remainder'] = comparison(remainder[0],np.zeros_like(remainder[0]))
        background = metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        matrix, forcing = metric.normalized_geometry(case,0.,prepared,background)
        variation = load(CONTROL/(case+'-corner-safe-budget.npz'))['node_variation_bound']
        diagnostic_amplitude = .5*duration**3*np.max(np.einsum('nij,nj->ni',abs(forcing),variation),axis=1)
        require(np.all(diagnostic_amplitude>0) and np.isfinite(diagnostic_amplitude).all(),'positive difference-state numerical scale')
        full_initial = prepared['state']/prepared['norm']
        direct_rhs = np.einsum('nij,nj->ni',matrix,full_initial)+np.einsum('nij,nj->ni',forcing,history.evaluate(0.))
        retained_rhs = metric.rhs(case,0.,prepared['state'],prepared,background,'density-quadratic')/prepared['norm']
        checks[case+'_same_initial_equations'] = comparison(direct_rhs,retained_rhs)
        np.savez_compressed(ROOT/(case+'-history-preparation.npz'),curvature=curvature,diagnostic_amplitude=diagnostic_amplitude,report_source=sources,report_remainder=remainder,elapsed=offsets,weights=prepared['weights'],times=prepared['times'])
        write(case+'-history-freeze.json',dict(passed=all(row['passed'] for name,row in checks.items() if name.startswith(case)),sha256=digest(ROOT/(case+'-history-preparation.npz')),target_fit_performed=False,physical_normalization_unchanged=True,diagnostic_scale_rule='0.5 T^3 max_component(sum_channel abs(B_normalized(0))*saved_node_curvature_variation)',polynomial_sha256=digest(CONTROL/(case+'-corner-safe-control-frozen.npz'))))
        print(json.dumps(dict(case=case,segments_per_node=[int(history.lengths.min()),int(history.lengths.max())],diagnostic_scale_range=[float(diagnostic_amplitude.min()),float(diagnostic_amplitude.max())])),flush=True)
    passed = all(row['passed'] for row in checks.values())
    write('history-validation.json',dict(passed=passed,checks=checks,check_count=len(checks)))
    require(passed,'history validation '+str({name:row for name,row in checks.items() if not row['passed']}))
    print(json.dumps(dict(passed=passed,checks=len(checks))),flush=True)
