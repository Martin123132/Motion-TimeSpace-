import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
CONTROL = POST / 'mts-between-epoch-source-control-20261112'
assert hashlib.sha256((CONTROL / 'closeout.json').read_bytes()).hexdigest() == '5af74dffa40842d2909898fe68aa519d2c0cf9c541c7af1317dade0e936dbe60'
assert hashlib.sha256((CONTROL / 'support.py').read_bytes()).hexdigest() == json.loads((CONTROL / 'closeout.json').read_text())['artifacts']['support.py']['sha256']
spec = importlib.util.spec_from_file_location('sealed_control_support', CONTROL / 'support.py')
retained = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retained)
retained.retained.base.ROOT = ROOT
PREVIOUS, REST, ORIGIN, SOURCE = retained.PREVIOUS, retained.REST, retained.ORIGIN, retained.SOURCE
QUADRATIC, MIDPOINT = retained.LATEST, retained.MIDPOINT
EARLY, BRANCH, SPECTRUM, MATCHING = retained.EARLY, retained.BRANCH, retained.SPECTRUM, retained.MATCHING
require, read, write, guard = retained.require, retained.read, retained.write, retained.guard
worker, exited, check_hashes = retained.worker, retained.exited, retained.check_hashes
digest, load = retained.digest, retained.load
sealed_module, retained_module = retained.sealed_module, retained.retained_module
GATE, ALGEBRA = retained.GATE, retained.ALGEBRA
os, sys, time, psutil = retained.os, retained.sys, retained.time, retained.psutil
