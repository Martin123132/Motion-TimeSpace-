import math
import numpy as np


def restrict_power(power, lower, upper):
    result = np.zeros_like(power)
    for index in range(len(power)):
        for exponent in range(index, len(power)):
            result[index] += power[exponent] * math.comb(exponent, index) * lower**(exponent-index) * (upper-lower)**index
    return result


class SourceHistory:
    def __init__(self, cells, power, starts, duration, initial, first, curvature):
        self.starts = np.asarray(starts)
        self.duration = float(duration)
        self.initial = np.asarray(initial)
        self.first = np.asarray(first)
        self.curvature = np.asarray(curvature)
        self.count = len(starts)
        plans = []
        for begin, initial_curvature in zip(starts, curvature):
            end = begin + duration
            selected = np.flatnonzero((cells[:, 0] < end) & (cells[:, 1] > begin))
            if not len(selected) or begin < cells[0, 0] or end > cells[-1, 1]:
                raise ValueError('Source window outside frozen cells')
            row = []
            for index in selected:
                left, right = cells[index, :2]
                clipped_left, clipped_right = max(begin, left), min(end, right)
                coefficients = restrict_power(power[index], (clipped_left-left)/(right-left), (clipped_right-left)/(right-left))
                coefficients[0] -= initial_curvature
                row.append((clipped_left-begin, clipped_right-begin, coefficients))
            plans.append(row)
        capacity = max(map(len, plans))
        self.left = np.full((self.count, capacity), np.inf)
        self.width = np.ones((self.count, capacity))
        self.coefficients = np.zeros((self.count, capacity, power.shape[1], 2))
        self.first_prefix = np.zeros((self.count, capacity, 2))
        self.second_prefix = np.zeros((self.count, capacity, 2))
        self.lengths = np.array([len(row) for row in plans])
        for node, plan in enumerate(plans):
            first_prefix, second_prefix = np.zeros(2), np.zeros(2)
            for segment, (left, right, coefficients) in enumerate(plan):
                width = right-left
                self.left[node, segment], self.width[node, segment] = left, width
                self.coefficients[node, segment] = coefficients
                self.first_prefix[node, segment], self.second_prefix[node, segment] = first_prefix, second_prefix
                first_cell = width * sum(coefficients[degree]/(degree+1) for degree in range(len(coefficients)))
                second_cell = width**2 * sum(coefficients[degree]/((degree+1)*(degree+2)) for degree in range(len(coefficients)))
                second_prefix = second_prefix + width*first_prefix + second_cell
                first_prefix = first_prefix + first_cell

    def remainder(self, elapsed):
        elapsed = float(elapsed)
        if elapsed < 0 or elapsed > self.duration:
            raise ValueError('Elapsed time outside frozen window')
        selected = np.minimum(np.sum(self.left <= elapsed, axis=1)-1, self.lengths-1)
        nodes = np.arange(self.count)
        width = self.width[nodes, selected]
        partial = elapsed-self.left[nodes, selected]
        fraction = partial/width
        coefficients = self.coefficients[nodes, selected]
        integral = np.zeros((self.count, 2))
        for degree in range(coefficients.shape[1]):
            integral += coefficients[:, degree] * (width**2*fraction**(degree+2)/((degree+1)*(degree+2)))[:, None]
        return self.second_prefix[nodes, selected] + partial[:, None]*self.first_prefix[nodes, selected] + integral

    def quadratic(self, elapsed):
        return self.initial + elapsed*self.first + .5*elapsed**2*self.curvature

    def evaluate(self, elapsed):
        return self.quadratic(elapsed) + self.remainder(elapsed)
