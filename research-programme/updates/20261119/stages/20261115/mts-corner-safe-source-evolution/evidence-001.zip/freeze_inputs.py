from support import *

with worker('freeze-inputs'):
    cleanup = read(CONTROL/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['external_checker_exit_verified'], 'previous cleanup passed')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'], 'previous worker exited')
    frozen = read(CONTROL/'frozen-inputs.json')
    for directory, names in (
        (CONTROL, ['closeout.json','cell_math.py','variation_math.py','cold-corner-safe-control-frozen.npz','heavy-corner-safe-control-frozen.npz','cold-corner-safe-budget.npz','heavy-corner-safe-budget.npz','cold-corner-safe-result.json','heavy-corner-safe-result.json','corner-safe-result.json']),
        (QUADRATIC, ['cold-run-freeze.json','heavy-run-freeze.json','cold-frozen-current.npz','heavy-frozen-current.npz','cold-both-quadratic-32.npz','cold-both-quadratic-64.npz','heavy-both-quadratic-32.npz','heavy-both-quadratic-64.npz','cold-comparison.npz','heavy-comparison.npz']),
        (PREVIOUS, ['metric_math.py','cold-initial-state.npz','heavy-initial-state.npz'])):
        seal = read(directory/'closeout.json')
        for name in names:
            path = directory/name
            if name != 'closeout.json':
                require(digest(path) == seal['artifacts'][name]['sha256'], 'sealed input '+name)
            frozen[str(path)] = digest(path)
    check_hashes(frozen)
    write('frozen-inputs.json', frozen)
    write('protocol-freeze.json', dict(hashes={str(ROOT/name):digest(ROOT/name) for name in ('support.py','PROTOCOL.md','source_history.py','freeze_inputs.py')}, physical_grids_unchanged=True, target_scoring_started=False))
    print(json.dumps(dict(passed=True,inputs=len(frozen))), flush=True)
