from extension_math import *
import ast
import math
from scipy.integrate import solve_ivp

path=PREVIOUS/'response.py'
require(digest(path)==read(PREVIOUS/'closeout.json')['artifacts']['response.py']['sha256'],'sealed response algorithm')
function=next(node for node in ast.parse(path.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='response_gains')
namespace={name:getattr(metric,name) for name in dir(metric) if not name.startswith('__')}
namespace.update(guard=guard,require=require,solve_ivp=solve_ivp,np=np)
exec(compile(ast.Module(body=[function],type_ignores=[]),str(path),'exec'),namespace)

with worker('extend-response'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks={}
    for case in ('cold','heavy'):
        prepared,history,background,old_preparation,control=problem(case)
        variation=load(ROOT/(case+'-extended-preparation.npz'))['node_variation_bound']
        runs={}
        ratio=float(prepared['elapsed'][-1]/prepared['elapsed'][8])
        for label in (32,64):
            steps=math.ceil(ratio*label)
            absolute,signed,direct,evaluations=namespace['response_gains'](case,prepared,background,steps)
            require(np.isfinite(absolute).all() and np.min(absolute)>=0,'positive finite new gain')
            runs[label]=dict(absolute=absolute,signed=signed,direct=direct,steps=steps)
            for output,name in enumerate(('D','Q','P')):
                for channel in (0,1):
                    checks[case+'_'+str(label)+'_'+name+'_'+str(channel)+'_duality']=comparison(signed[:,output,channel],direct[:,output,channel])
                    checks[case+'_'+str(label)+'_'+name+'_'+str(channel)+'_envelope']=dict(passed=bool(np.all(abs(signed[:,output,channel])<=absolute[:,output,channel]+GATE*np.max(absolute[:,output,channel]))))
            print(json.dumps(dict(case=case,label=label,full_horizon_steps=steps,evaluations=evaluations)),flush=True)
        gain=np.array([weighted(abs(prepared['weights']),runs[64]['absolute'][:,:,channel]) for channel in (0,1)]).T
        difference=abs(runs[64]['absolute']-runs[32]['absolute'])
        refinement=np.array([weighted(abs(prepared['weights']),difference[:,:,channel]) for channel in (0,1)]).T
        envelope=weighted(abs(prepared['weights']),np.sum((runs[64]['absolute']+difference)*variation[:,None,:],axis=2))
        for output,name in enumerate(('D','Q','P')):
            for channel in (0,1):
                checks[case+'_'+name+'_'+str(channel)+'_refinement']=comparison(refinement[output,channel],0,scale=gain[output,channel])
        np.savez_compressed(ROOT/(case+'-extended-response.npz'),node_absolute_gain=runs[64]['absolute'],node_signed_gain=runs[64]['signed'],node_gain_refinement=difference,gain=gain,gain_refinement=refinement,variation_envelope=envelope,duration=prepared['elapsed'][-1],coarse_steps=runs[32]['steps'],fine_steps=runs[64]['steps'])
    write('response-validation.json',dict(passed=all(row['passed'] for row in checks.values()),checks=checks,old_endpoint_gain_not_reused=True,maximum_physical_step_preserved=True))
    require(all(row['passed'] for row in checks.values()),'extended response checks '+str({name:row for name,row in checks.items() if not row['passed']}))
