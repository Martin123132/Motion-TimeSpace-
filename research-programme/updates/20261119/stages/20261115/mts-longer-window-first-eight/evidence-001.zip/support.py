import os
import sys
for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[name] = '1'
sys.dont_write_bytecode = True
import hashlib
import importlib.util
import json
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import psutil

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREFIX = POST/'mts-next-eight-epoch-extension-20261115'
LAST = POST/'mts-duration-growth-law-20261115'
OLDER = POST/'mts-corner-safe-source-evolution-20261115'
PIN = '2ab6881473be01faa163fd4e2455fb96c6b8521f83f2488f075cffd42e467ba2'
assert hashlib.sha256((LAST/'closeout.json').read_bytes()).hexdigest() == PIN
assert hashlib.sha256((LAST/'support.py').read_bytes()).hexdigest() == json.loads((LAST/'closeout.json').read_text())['artifacts']['support.py']['sha256']
spec = importlib.util.spec_from_file_location('growth_retained_support', LAST/'support.py')
retained = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retained)
CONTROL, PREVIOUS, QUADRATIC = retained.CONTROL, retained.PREVIOUS, retained.QUADRATIC
SOURCE, ORIGIN, MIDPOINT = retained.SOURCE, retained.ORIGIN, retained.MIDPOINT
EARLY, BRANCH, SPECTRUM, MATCHING = retained.EARLY, retained.BRANCH, retained.SPECTRUM, retained.MATCHING
load, sealed_module, retained_module = retained.load, retained.sealed_module, retained.retained_module
GATE, ALGEBRA = retained.GATE, retained.ALGEBRA
START = time.monotonic()
BEGIN_INDEX, END_INDEX = 2908, 2916
ORIGIN_INDEX, NODE_FIRST = 2892, 1991
PREFIX_COUNT = BEGIN_INDEX-ORIGIN_INDEX+1
REPORT_COUNT = END_INDEX-ORIGIN_INDEX+1
OLD_PACKETS = BEGIN_INDEX-NODE_FIRST+1
NEW_PACKETS = END_INDEX-NODE_FIRST+1

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def write(name, value):
    with (ROOT/name).open('x', encoding='utf-8') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False))

def guard():
    require(time.monotonic()-START < 900, 'worker deadline')
    for directory in (ROOT, POST, LAST, PREFIX, OLDER, BRANCH):
        require(not (directory/'STOP-REQUESTED').exists(), 'owner hold '+str(directory))

def check_hashes(mapping):
    for path, expected in mapping.items():
        guard()
        require(Path(path).is_file() and digest(path) == expected, 'unchanged '+path)

def exited(identity):
    try:
        process = psutil.Process(identity['pid'])
        same = abs(process.create_time()-identity['created']) < .01 and process.cmdline() == identity['command']
    except psutil.NoSuchProcess:
        return dict(exited=True, reason='PID absent')
    return dict(exited=not same, reason='original identity live' if same else 'PID reused; untouched')

@contextmanager
def worker(name):
    process = psutil.Process()
    process.cpu_affinity([4])
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    identity = dict(pid=process.pid, created=process.create_time(), command=process.cmdline(), utc=datetime.now(timezone.utc).isoformat())
    write(name+'-start.json', identity)
    try:
        guard()
        yield identity
    except BaseException as error:
        write(name+'-end.json', dict(**identity, state='failed', error=repr(error)))
        raise
    else:
        write(name+'-end.json', dict(**identity, state='completed', elapsed=time.monotonic()-START))
