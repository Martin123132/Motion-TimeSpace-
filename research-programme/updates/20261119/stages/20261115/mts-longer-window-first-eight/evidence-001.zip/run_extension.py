from extension_math import *
import argparse
from scipy.integrate import solve_ivp

parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case

with worker(case+'-extend'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'source-validation.json')['passed'],'source gates passed')
    prepared,history,background,old_preparation,control=problem(case)
    frozen={str(ROOT/name):digest(ROOT/name) for name in ('run_extension.py','extension_math.py','support.py','PROTOCOL.md',case+'-source-frozen.npz',case+'-extended-preparation.npz')}
    write(case+'-evolution-code.json',frozen)
    norm=prepared['norm']
    amplitude=old_preparation['diagnostic_amplitude']
    elapsed=prepared['elapsed']
    begin,end=float(elapsed[PREFIX_COUNT-1]),float(elapsed[-1])
    shape=prepared['state'].shape
    def derivative(offset,flat,mode):
        guard()
        matrix,forcing=metric.normalized_geometry(case,offset,prepared,background)
        source=history.remainder(offset)/amplitude[:,None] if mode=='difference' else history.evaluate(offset) if mode=='history' else history.quadratic(offset)
        return (np.einsum('nij,nj->ni',matrix,flat.reshape(shape))+np.einsum('nij,nj->ni',forcing,source)).ravel()
    hashes={}
    for steps in (32,64):
        old=load(PREFIX/(case+'-extended-'+str(steps)+'.npz'))
        states,counts,outputs={},{},{}
        for mode,state_key,node_key,prediction_key,arithmetic_key,normalization in (
            ('history','state','node_source','prediction','arithmetic_difference',norm),
            ('quadratic','quad_state','quad_node_source','quad_prediction','quad_arithmetic_difference',norm),
            ('difference','delta_state','delta_node_source','delta_prediction',None,norm*amplitude[:,None])):
            initial=old[state_key][-1]
            solution=solve_ivp(lambda offset,flat:derivative(offset,flat,mode),(begin,end),(initial/normalization).ravel(),method='DOP853',t_eval=elapsed[PREFIX_COUNT-1:],rtol=1e-10,atol=1e-12,max_step=float(elapsed[8])/steps)
            require(solution.success and solution.y.shape==(initial.size,9),'eight-epoch restart '+mode)
            tail=solution.y.T.reshape(9,*shape)*normalization[None,:,:]
            states[mode]=np.concatenate((old[state_key],tail[1:]))
            require(np.array_equal(states[mode][:PREFIX_COUNT],old[state_key]),'old state rows unchanged')
            node_tail=np.array([metric.readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed[PREFIX_COUNT:],states[mode][PREFIX_COUNT:])])
            nodes=np.concatenate((old[node_key],node_tail))
            if mode=='difference':
                predicted_tail=np.array([weighted(prepared['weights'],row) for row in node_tail])
                predicted=np.concatenate((old[prediction_key],predicted_tail))
                arithmetic=np.zeros_like(predicted)
            else:
                predicted_tail=prepared['initial_weighted_source']+np.array([weighted(prepared['weights'],row-prepared['node_initial_sources']) for row in node_tail])
                predicted=np.concatenate((old[prediction_key],predicted_tail))
                direct=np.array([weighted(prepared['weights'],row) for row in nodes])
                arithmetic=abs(predicted-(prepared['initial_weighted_source']+direct-direct[0]))
                arithmetic[:PREFIX_COUNT]=old[arithmetic_key]
            outputs[mode]=dict(nodes=nodes,prediction=predicted,arithmetic=arithmetic)
            counts[mode]=solution.nfev
        force=np.array([metric.metric_force(case,float(offset),state,prepared,background,'density-quadratic')+history.remainder(float(offset))[:,0]/(2*prepared['wave']*background.evaluate(prepared['times']+offset)['hubble']) for offset,state in zip(elapsed[PREFIX_COUNT:],states['history'][PREFIX_COUNT:])])
        force=np.concatenate((old['metric_force'],force))
        sources=load(ROOT/(case+'-extended-preparation.npz'))['source']
        sources[:PREFIX_COUNT]=old['source']
        filename=case+'-extended-'+str(steps)+'.npz'
        np.savez_compressed(ROOT/filename,state=states['history'],quad_state=states['quadratic'],delta_state=states['difference'],node_source=outputs['history']['nodes'],quad_node_source=outputs['quadratic']['nodes'],delta_node_source=outputs['difference']['nodes'],prediction=outputs['history']['prediction'],quad_prediction=outputs['quadratic']['prediction'],delta_prediction=outputs['difference']['prediction'],arithmetic_difference=outputs['history']['arithmetic'],quad_arithmetic_difference=outputs['quadratic']['arithmetic'],metric_force=force,source=sources,elapsed=elapsed,weights=prepared['weights'],max_physical_step=float(elapsed[8])/steps)
        hashes[str(ROOT/filename)]=digest(ROOT/filename)
        print(json.dumps(dict(case=case,steps=steps,evaluations=counts)),flush=True)
    write(case+'-run-freeze.json',dict(passed=True,hashes=hashes,old_window_rows_preserved=True,target_comparison_started=False,rtol=1e-10,normalized_atol=1e-12,physical_scaling_unchanged=True))
    check_hashes(frozen)
    check_hashes(read(ROOT/'frozen-inputs.json'))
