from support import *
import numpy as np

metric=sealed_module('extended_metric',PREVIOUS,'metric_math.py')
SourceHistory=sealed_module('extended_source_history',OLDER,'source_history.py').SourceHistory
cells_math=sealed_module('extended_cell_math',CONTROL,'cell_math.py')
source_jet=sealed_module('extended_source_jet',CONTROL,'variation_math.py').source_jet
weighted=metric.weighted

def comparison(actual,expected,tolerance=GATE,scale=None):
    return metric.comparison(np.asarray(actual),np.asarray(expected),tolerance,scale=scale)

def problem(case):
    prepared=load(PREVIOUS/(case+'-initial-state.npz'))
    plan=load(ROOT/(case+'-extension-plan.npz'))
    prepared['elapsed']=plan['elapsed']
    old_preparation=load(OLDER/(case+'-history-preparation.npz'))
    control=load(ROOT/(case+'-source-frozen.npz'))
    history=SourceHistory(control['cells'],control['power'],prepared['times'],float(prepared['elapsed'][-1]),prepared['other0'],prepared['other1'],old_preparation['curvature'])
    background=metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
    return prepared,history,background,old_preparation,control

def native_source(packet,case,prepared):
    if case=='cold':
        return np.column_stack((prepared['cold_normalization']*packet[:,63],np.zeros((len(packet),2))))
    return metric.primitive.field_sources(packet,float(prepared['density0']))['source']

def absolute_weighted(weights,values):
    return np.array([weighted(abs(weights),abs(row)) for row in values])

def rounding(case,elapsed,states,prepared,background):
    result=[]
    for offset,state in zip(elapsed,states):
        mapping=metric.terminal_map(case,float(offset),prepared,background)
        magnitude=np.einsum('nci,ni->nc',abs(mapping),abs(state/prepared['norm']))
        result.append(64*np.finfo(float).eps*weighted(abs(prepared['weights']),magnitude))
    return np.array(result)
