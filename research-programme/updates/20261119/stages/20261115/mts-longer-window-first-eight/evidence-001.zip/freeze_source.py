from support import *
import numpy as np

jet=sealed_module('extension_source_jet',CONTROL,'variation_math.py').source_jet
with worker('freeze-source'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    for case in ('cold','heavy'):
        require(read(ROOT/(case+'-construction-validation.json'))['passed'],'construction capture passed')
        require(exited(read(ROOT/(case+'-construction-capture-start.json')))['exited'],'capture exited')
        capture=load(ROOT/(case+'-construction-capture.npz'))
        plan=load(ROOT/(case+'-extension-plan.npz'))
        requests=plan['source_requests']
        positions=np.searchsorted(capture['query_times'],requests[:,0])
        require(np.array_equal(capture['query_times'][positions],requests[:,0]),'all source nodes present')
        values=capture['probes'][positions]
        probe_jet=jet(values,case)
        original_jet=jet(capture['packet'],case)
        clock_packet=load(SOURCE/(case+'-native-clock.npz'))
        minimum,spacing=clock_packet['metadata']
        side_checks={}
        powers,validation_requests=[],[]
        for index,(begin,end,gap,part) in enumerate(plan['cells']):
            gap=int(gap)
            subset=requests[:,1]==index
            node_times=[begin,end]
            endpoints=[original_jet[gap-1991,2],original_jet[gap+1-1991,2]]
            for side,slot,boundary in ((1,0,begin),(-1,1,end)):
                selected=np.flatnonzero(subset&(requests[:,3]==side))
                if len(selected):
                    row=selected[0]
                    node_times[slot]=requests[row,0]
                    endpoints[slot]=probe_jet[row,2]
                    position=np.log(boundary/minimum)/spacing+1
                    nearest=int(round(position))
                    if abs(position-nearest)<1e-7:
                        expected=nearest if side==1 else nearest-1
                        side_checks[str(index)+'_'+str(side)]=dict(passed=bool(int(values[row,18])==expected),expected=expected,observed=int(values[row,18]))
            interior=subset&(requests[:,3]==0)
            abscissa=(np.concatenate(([node_times[0]],requests[interior,0],[node_times[1]]))-begin)/(end-begin)
            samples=np.vstack((endpoints[0],probe_jet[interior,2],endpoints[1]))
            powers.append(np.linalg.solve(np.polynomial.polynomial.polyvander(abscissa,4),samples))
            for fraction in (1/6,5/6):
                validation_requests.append((begin+fraction*(end-begin),index,fraction))
        require(all(row['passed'] for row in side_checks.values()),'native one-sided cells correct')
        powers,validation_requests=np.array(powers),np.array(validation_requests)
        prediction=np.array([np.polynomial.polynomial.polyval(row[2],powers[int(row[1])]) for row in validation_requests])
        old=load(PREFIX/(case+'-source-frozen.npz'))
        cells=np.concatenate((old['cells'],plan['cells']))
        power=np.concatenate((old['power'],powers))
        require(old['cells'][-1,1]==plan['cells'][0,0] and np.all(cells[:-1,1]==cells[1:,0]),'contiguous cells without extrapolation')
        require(np.array_equal(cells[:len(old['cells'])],old['cells']) and np.array_equal(power[:len(old['power'])],old['power']),'old cells byte-identical')
        np.savez_compressed(ROOT/(case+'-source-frozen.npz'),cells=cells,power=power,tail_cells=plan['cells'],tail_power=powers,validation_requests=validation_requests,validation_prediction=prediction,elapsed=plan['elapsed'])
        write(case+'-source-freeze.json',dict(passed=True,sha256=digest(ROOT/(case+'-source-frozen.npz')),new_probe_values_loaded=False,one_sided_checks=side_checks,old_cells_unchanged=True,tail_cells=len(powers),fresh_validation_probes=len(validation_requests)))
        print(json.dumps(dict(case=case,tail_cells=len(powers),fresh_probes=len(validation_requests))),flush=True)
