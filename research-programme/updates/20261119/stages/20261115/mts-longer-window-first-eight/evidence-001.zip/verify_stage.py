from extension_math import *

with worker('verify-stage'):
    checks={}
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['python_compiles']=True
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'protocol-freeze.json'))
    checks['frozen_inputs_and_protocol_unchanged']=True
    checks['no_pycache']=not list(ROOT.rglob('__pycache__'))
    for directory,label in ((LAST,'growth'),(PREFIX,'prior17')):
        seal=read(directory/'closeout.json')
        checks[label+'_sealed_artifacts']=all(digest(directory/name)==record['sha256'] and (directory/name).stat().st_size==record['bytes'] for name,record in seal['artifacts'].items())
    checks['source_checks']=read(ROOT/'source-validation.json')['passed']
    checks['endpoint_gains']=read(ROOT/'response-validation.json')['passed']
    checks['direct_reference']=all(passed for name,passed in read(ROOT/'result.json')['paired'].items() if name!='node_state_superposition_passed')
    checks['derived_restart_identity']=read(ROOT/'restart-defect-validation.json')['passed']
    checks['raw_node_failure_preserved']=not read(ROOT/'result.json')['paired']['node_state_superposition_passed']
    check_hashes(read(ROOT/'restart-transport-freeze.json')['hashes'])
    checks['response_expansion']=read(ROOT/'series-validation.json')['passed']
    checks['batch']=read(ROOT/'batch-result.json')['passed']
    checks['unchanged_gain_algorithm']=digest(ROOT/'extend_response.py')==digest(PREFIX/'extend_response.py')
    for case in ('cold','heavy'):
        for phase in ('construction','validation'):
            checks[case+'_'+phase+'_capture']=read(ROOT/(case+'-'+phase+'-validation.json'))['passed']
            release=read(ROOT/(case+'-'+phase+'-owner-release.json'))
            checks[case+'_'+phase+'_owner_release']=release['cleared'] and release['native_reference_released']
            check_hashes(read(ROOT/(case+'-'+phase+'-code-freeze.json')))
        freeze=read(ROOT/(case+'-source-freeze.json'))
        checks[case+'_source_freeze']=freeze['passed'] and digest(ROOT/(case+'-source-frozen.npz'))==freeze['sha256']
        validation_start=read(ROOT/(case+'-validation-capture-start.json'))
        checks[case+'_predictions_precede_probes']=(ROOT/(case+'-source-freeze.json')).stat().st_mtime < validation_start['created'] and not freeze['new_probe_values_loaded']
        checks[case+'_correct_sides']=all(row['passed'] for row in freeze['one_sided_checks'].values())
        for filename in (case+'-evolution-code.json',case+'-series-code.json'):
            check_hashes(read(ROOT/filename))
        for filename in (case+'-run-freeze.json',case+'-series-freeze.json'):
            check_hashes(read(ROOT/filename)['hashes'])
            checks[filename+'_precedes_score']=(ROOT/filename).stat().st_mtime < read(ROOT/'score-extension-start.json')['created']
        prepared,history,background,old_preparation,control=problem(case)
        old_control=load(PREFIX/(case+'-source-frozen.npz'))
        checks[case+'_old_polynomials_unchanged']=np.array_equal(control['cells'][:len(old_control['cells'])],old_control['cells']) and np.array_equal(control['power'][:len(old_control['power'])],old_control['power'])
        checks[case+'_25_reports']=len(prepared['elapsed'])==25
        checks[case+'_only_first_batch']=load(ROOT/(case+'-extension-plan.npz'))['cells'][-1,2]==2915
        gains=load(ROOT/(case+'-extended-response.npz'))
        checks[case+'_new_endpoint_gain']=gains['duration']==prepared['elapsed'][-1]
        checks[case+'_gain_physical_step']=gains['duration']/gains['fine_steps']<=prepared['elapsed'][8]/64
        for steps in (32,64):
            run=load(ROOT/(case+'-extended-'+str(steps)+'.npz'))
            series=load(ROOT/(case+'-growth-'+str(steps)+'.npz'))
            checks[case+'_'+str(steps)+'_finite']=all(np.isfinite(values).all() for values in run.values()) and all(np.isfinite(values).all() for values in series.values())
            checks[case+'_'+str(steps)+'_original_steps']=run['max_physical_step']==prepared['elapsed'][8]/steps and series['max_physical_step']==prepared['elapsed'][8]/steps
        checks[case+'_direct_prefix']=read(ROOT/(case+'-result.json'))['prefix_passed']
        checks[case+'_series_prefix']=read(ROOT/(case+'-series-result.json'))['old17_rows_preserved']
        checks[case+'_same_node_allowance']=read(ROOT/(case+'-restart-defect-result.json'))['same_raw_allowance']
        if case=='cold':
            checks['cold_dust_zeros']=bool(np.all(run['prediction'][:,1:]==0) and np.all(series['terms'][:,:,1:]==0))
    checks={name:bool(value) for name,value in checks.items()}
    write('validation.json',dict(passed=all(checks.values()),checks=checks,count=len(checks),goal_left_paused=True))
    require(all(checks.values()),'validation '+str({name:passed for name,passed in checks.items() if not passed}))
    print(json.dumps(dict(passed=True,checks=len(checks))),flush=True)
