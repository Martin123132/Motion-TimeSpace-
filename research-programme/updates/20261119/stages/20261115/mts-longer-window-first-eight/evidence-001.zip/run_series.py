from extension_math import *
from scipy.integrate import solve_ivp
import argparse

parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case
with worker(case+'-series'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'source-validation.json')['passed'],'source passed')
    prepared,history,background,old_preparation,control=problem(case)
    elapsed=prepared['elapsed']
    shape=(9,*prepared['state'].shape)
    amplitude=old_preparation['diagnostic_amplitude']
    scaling=prepared['norm']*amplitude[:,None]
    write(case+'-series-code.json',{str(ROOT/name):digest(ROOT/name) for name in ('run_series.py','extension_math.py','support.py','PROTOCOL.md',case+'-source-frozen.npz')})
    for steps in (32,64):
        old=load(LAST/(case+'-growth-'+str(steps)+'.npz'))
        require(np.array_equal(elapsed[:PREFIX_COUNT],old['elapsed']),'old series times')
        def derivative(offset,flat):
            guard()
            matrix,forcing=metric.normalized_geometry(case,offset,prepared,background)
            states=flat.reshape(shape)
            result=np.zeros_like(states)
            result[0]=np.einsum('nij,nj->ni',forcing,history.remainder(offset)/amplitude[:,None])
            result[1:]=np.einsum('nij,knj->kni',matrix,states[:-1])
            return result.ravel()
        solution=solve_ivp(derivative,(float(elapsed[PREFIX_COUNT-1]),float(elapsed[-1])),(old['states'][-1]/scaling[None,:,:]).ravel(),method='DOP853',t_eval=elapsed[PREFIX_COUNT-1:],rtol=1e-10,atol=1e-12,max_step=float(elapsed[8])/steps)
        require(solution.success and solution.y.shape==(np.prod(shape),9),'series continuation')
        tail=solution.y.T.reshape(9,*shape)*scaling[None,None,:,:]
        states=np.concatenate((old['states'],tail[1:]))
        nodes_tail=np.array([[metric.readout(case,float(offset),state,prepared,background) for state in terms] for offset,terms in zip(elapsed[PREFIX_COUNT:],tail[1:])])
        nodes=np.concatenate((old['nodes'],nodes_tail))
        terms_tail=np.array([[weighted(prepared['weights'],term) for term in row] for row in nodes_tail])
        terms=np.concatenate((old['terms'],terms_tail))
        sums=np.concatenate((old['partial_sums'],np.cumsum(terms_tail,axis=1)))
        np.savez_compressed(ROOT/(case+'-growth-'+str(steps)+'.npz'),states=states,nodes=nodes,terms=terms,partial_sums=sums,elapsed=elapsed,max_physical_step=float(elapsed[8])/steps)
        print(json.dumps(dict(case=case,steps=steps,series_evaluations=solution.nfev)),flush=True)
    write(case+'-series-freeze.json',dict(passed=True,hashes={str(path):digest(path) for path in ROOT.glob(case+'-growth-*.npz')},target_comparison_started=False,interaction_orders=list(range(9)),old17_rows_preserved=True))
    check_hashes(read(ROOT/(case+'-series-code.json')))
    check_hashes(read(ROOT/'frozen-inputs.json'))
