import os

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
import importlib.util
import json
import math
from pathlib import Path

import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
REPAIR = ROOT / "paired-work-repair"
spec = importlib.util.spec_from_file_location("bridge_validation", ROOT / "run_bridge.py")
BRIDGE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BRIDGE)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def complex_value(value):
    return complex(value[0], value[1])


def summed(values):
    values = list(values)
    return complex(math.fsum(value.real for value in values), math.fsum(value.imag for value in values))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    name = "validation-replay" if args.replay else "validation"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(), "utc": BRIDGE.utc()}
    if (ROOT / (name + "-start.json")).exists():
        raise FileExistsError("Do not overwrite validator receipt")
    BRIDGE.save(ROOT / (name + "-start.json"), identity)
    try:
        checks = {}
        original_result = read(ROOT / "result.json")
        repair_result = read(REPAIR / "result.json")
        checks["failed_root_retained"] = not original_result["passed"]
        checks["repair_cached_replay_exact"] = repair_result == read(REPAIR / "replay-result.json")
        checks["repair_original_reports_reproduced"] = repair_result["original_results_reproduced"]
        checks["repair_source_arrays_unchanged"] = repair_result["original_source_arrays_unchanged"]
        failures = {key for key, value in repair_result["repair_checks"].items() if not value}
        checks["only_reference_alignment_receipt_failed"] = failures == {"raw_force_step_6_reproduced", "raw_force_step_7_reproduced"}
        checks["all_other_repair_checks_pass"] = all(value for key, value in repair_result["repair_checks"].items() if key not in failures)
        expected_hashes = {
            ROOT / "run_bridge.py": repair_result["bridge_code_sha256"],
            ROOT / "protocol.json": repair_result["protocol_sha256"],
            REPAIR / "run_precision.py": repair_result["code_sha256"],
        }
        checks["tested_codes_and_protocol_unchanged"] = all(BRIDGE.sha(path) == value for path, value in expected_hashes.items())
        verified_inputs = BRIDGE.verify_inputs()
        for entry in read(REPAIR / "inputs.json"):
            path = ROOT / entry["path"]
            verified_inputs[str(path)] = path.is_file() and path.stat().st_size == entry["bytes"] and BRIDGE.sha(path) == entry["sha256"]
        checks["all_inputs_unchanged"] = all(verified_inputs.values())
        panels = []
        alignment = []
        packets = read(REPAIR / "paired-work-packets.json")
        for seed in BRIDGE.CONFIG["seeds"]:
            original = read(ROOT / f"panel-{seed}.json")
            report = read(REPAIR / f"panel-{seed}.json")
            if seed == BRIDGE.CONFIG["finite_difference_fixture"]:
                with np.load(ROOT / f"sources-{seed}.npz", allow_pickle=False) as source:
                    strength = source["curvature"]
                    current = source["checked_current"]
                    stored_force = source["force"]
                vector = np.array([[np.cos((site + 1) * (axis + 1)) / 2 for axis in range(4)] for site in range(BRIDGE.SITES)])
                exact_target = np.einsum("xn,xn->", vector, np.einsum("xnma,xma->xn", strength, current))
                stored_target = np.einsum("xn,xn->", vector, stored_force)
                checks["equivalent_saved_currents_within_original_gate"] = BRIDGE.BASE.error(exact_target, stored_target) <= BRIDGE.CONFIG["identity_tolerance"]
                for index, step in enumerate(BRIDGE.CONFIG["finite_difference_steps"], start=6):
                    item = report["finite_tests"][index]
                    frozen = original["finite_tests"][index]
                    checks[f"step_{index}_same_steps"] = item["step"] == frozen["step"] == step
                    checks[f"step_{index}_reference_cause_exact"] = complex_value(item["predicted"]) == stored_target
                    selected = [packet for packet in packets if packet["step"] == step]
                    checks[f"step_{index}_all_four_packets"] = [packet["offset"] for packet in selected] == [1, 2, 3, 4]
                    reconstructed = summed(
                        weight * complex_value(packet["paired_difference"]) / step
                        for weight, packet in zip(BRIDGE.FD_WEIGHTS, selected)
                    )
                    checks[f"step_{index}_paired_derivative_exact"] = reconstructed == complex_value(item["derivative"])
                    raw = sum(
                        weight * np.array([complex_value(value) for value in packet["raw_difference"]]) / step
                        for weight, packet in zip(BRIDGE.FD_WEIGHTS, selected)
                    )
                    raw_errors = [BRIDGE.BASE.error(value, exact_target) for value in raw]
                    checks[f"step_{index}_raw_original_errors_exact"] = raw_errors == frozen["force_work_errors"]
                    checks[f"step_{index}_raw_derivatives_exact"] = list(raw) == [complex_value(value) for value in item["raw_derivative"]]
                    checks[f"step_{index}_old_target_error_exact"] = item["force_work_errors"] == [BRIDGE.BASE.error(reconstructed, stored_target)] * 2
                    error = BRIDGE.BASE.error(reconstructed, exact_target)
                    item["predicted"] = [float(exact_target.real), float(exact_target.imag)]
                    item["force_work_errors"] = [error] * 2
                    item["raw_errors"] = raw_errors
                    for case in range(2):
                        key = f"finite_{index}_force_work_errors_{case}"
                        report["metrics"][key] = error
                        report["checks"][key] = bool(np.isfinite(error) and error <= BRIDGE.CONFIG["identity_tolerance"])
                    alignment.append({"step": step, "reference_difference": float(abs(exact_target - stored_target)),
                                      "raw_original_errors": raw_errors, "paired_work_error": error})
                unchanged_keys = [key for key in original["metrics"] if "force_work_errors" not in key]
                checks["all_nonwork_metrics_exact"] = all(report["metrics"][key] == original["metrics"][key] for key in unchanged_keys)
                checks["all_nonwork_finite_tests_exact"] = report["finite_tests"][:6] == original["finite_tests"][:6]
            else:
                checks[f"seed_{seed}_all_metrics_exact"] = report["metrics"] == original["metrics"]
            report["passed"] = all(report["checks"].values())
            panels.append(report)
        checks["all_106_panel_checks_pass"] = sum(len(report["checks"]) for report in panels) == 106 and all(report["passed"] for report in panels)
        checks["quantum_measure_separate"] = not repair_result["quantum_measure_included"]
        checks["no_physical_history_change"] = not repair_result["physical_history_changed"]
        result = {
            "passed": all(checks.values()), "checks": checks,
            "scientific_panel_checks": 106, "checks_count": len(checks),
            "reference_alignment": alignment, "retained_files_verified": len(verified_inputs),
            "code_sha256": BRIDGE.sha(Path(__file__)),
            "original_failure_retained": True, "repair_receipt_failure_retained": True,
            "tolerance": BRIDGE.CONFIG["identity_tolerance"],
            "quantum_measure_included": False, "constant_metric_only": True,
            "local_lattice_stress_divergence_proved": False, "physical_history_changed": False,
        }
        if args.replay:
            checks_equal = read(ROOT / "validation.json") == result
            panels_equal = read(ROOT / "accepted-panels.json") == panels
            if not checks_equal or not panels_equal:
                raise RuntimeError("Acceptance replay differs")
            BRIDGE.save(ROOT / "validation-replay.json", result)
        else:
            if (ROOT / "validation.json").exists() or (ROOT / "accepted-panels.json").exists():
                raise FileExistsError("Do not overwrite acceptance")
            BRIDGE.save(ROOT / "accepted-panels.json", panels)
            BRIDGE.save(ROOT / "validation.json", result)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        BRIDGE.save(ROOT / (name + "-end.json"), {"completed": True, "passed": result["passed"], "pid": process.pid,
                    "created": process.create_time(), "utc": BRIDGE.utc(), "pycache_absent": not any(ROOT.rglob("__pycache__"))})
        print(json.dumps(result), flush=True)
        return 0 if result["passed"] else 1
    except BaseException as failure:
        BRIDGE.save(ROOT / (name + "-failure.json"), {"completed": False, "pid": process.pid, "created": process.create_time(),
                    "utc": BRIDGE.utc(), "error": repr(failure)})
        raise


if __name__ == "__main__":
    raise SystemExit(main())

