import os

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
import importlib.util
import json
import math
from pathlib import Path
import time

import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent
spec = importlib.util.spec_from_file_location("metric_bridge", PARENT / "run_bridge.py")
BRIDGE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BRIDGE)
WARD = BRIDGE.WARD
BASE = BRIDGE.BASE
STARTED = time.monotonic()


def complex_sum(values):
    values = list(values)
    return complex(math.fsum(value.real for value in values), math.fsum(value.imag for value in values))


def encoded(value):
    return [float(value.real), float(value.imag)]


def paired_work(arrays, positive_arrays, negative_arrays, positive, negative):
    mean_fields = {}
    delta_fields = {}
    kinetic = []
    invariant_bars = True
    for label in BASE.FIELDS:
        pos_operator = positive["operators"][label]
        neg_operator = negative["operators"][label]
        mean_projector = (pos_operator["projector"] + neg_operator["projector"]) / 2
        delta_projector = pos_operator["projector"] - neg_operator["projector"]
        mean_field = mean_projector @ arrays["eta_" + label]
        delta_field = delta_projector @ arrays["eta_" + label]
        mean_fields[label] = mean_field.reshape(BRIDGE.SITES, -1)
        delta_fields[label] = delta_field.reshape(BRIDGE.SITES, -1)
        mean_overlap = (pos_operator["overlap"] + neg_operator["overlap"]) / 2
        delta_overlap = pos_operator["overlap"] - neg_operator["overlap"]
        invariant_bars &= np.array_equal(positive["bars"][label], negative["bars"][label])
        kinetic.append(positive["bars"][label] @ (mean_overlap @ delta_field + delta_overlap @ mean_field))
    yukawa = []
    for name, left, right, conjugate_higgs, coefficient, tensors in WARD.PAIRS:
        for site in range(BRIDGE.SITES):
            scalar = arrays["higgs"][site].conj() if conjugate_higgs else arrays["higgs"][site]
            matrix = sum(scalar[component] * tensors[component] for component in range(2))
            yukawa.append(coefficient * (
                delta_fields[left][site] @ matrix @ mean_fields[right][site]
                + mean_fields[left][site] @ matrix @ delta_fields[right][site]
            ))
    higgs = []
    for site in range(BRIDGE.SITES):
        for direction in range(4):
            other, _ = BASE.shift(site, direction)
            positive_link = positive_arrays["phase"][site, direction] ** 3 * positive_arrays["weak"][site, direction]
            negative_link = negative_arrays["phase"][site, direction] ** 3 * negative_arrays["weak"][site, direction]
            mean_gradient = ((positive_link + negative_link) / 2) @ arrays["higgs"][other] - arrays["higgs"][site]
            delta_gradient = (positive_link - negative_link) @ arrays["higgs"][other]
            higgs.append(complex(2 * np.vdot(mean_gradient, delta_gradient).real))
    components = {"fermion": complex_sum(kinetic), "yukawa": complex_sum(yukawa), "higgs": complex_sum(higgs)}
    same_neutral = positive["scalar"]["neutral"] == negative["scalar"]["neutral"]
    same_barred = positive["interaction"]["barred_terms"] == negative["interaction"]["barred_terms"]
    same_fields = all(np.array_equal(positive_arrays[key], negative_arrays[key]) for key in ("neutral", "higgs"))
    same_metric = np.array_equal(positive["geometry"]["inverse"], np.eye(4)) and np.array_equal(negative["geometry"]["inverse"], np.eye(4))
    checks = {"bars_fixed": bool(invariant_bars), "barred_yukawa_fixed": bool(same_barred),
              "neutral_fixed": bool(same_neutral), "scalar_fields_fixed": bool(same_fields), "metric_fixed": bool(same_metric)}
    return complex_sum(components.values()), components, checks


def repaired_force(arrays, source):
    vector = np.array([[np.cos((site + 1) * (axis + 1)) / 2 for axis in range(4)] for site in range(BRIDGE.SITES)])
    predicted = np.einsum("xn,xn->", vector, source["force"])
    records = []
    packets = []
    for step in BRIDGE.CONFIG["finite_difference_steps"]:
        terms = []
        raw_terms = []
        for offset, weight in enumerate(BRIDGE.FD_WEIGHTS, start=1):
            positive_arrays = BRIDGE.force_shift(arrays, source["curvature"], vector, offset * step)
            negative_arrays = BRIDGE.force_shift(arrays, source["curvature"], vector, -offset * step)
            positive = BRIDGE.build_model(positive_arrays, np.eye(4), responses=False)
            negative = BRIDGE.build_model(negative_arrays, np.eye(4), responses=False)
            difference, components, invariants = paired_work(arrays, positive_arrays, negative_arrays, positive, negative)
            raw = BRIDGE.action_pair(positive) - BRIDGE.action_pair(negative)
            agreement = [BASE.error(difference, value) for value in raw]
            terms.append(weight * difference / step)
            raw_terms.append(weight * raw / step)
            packets.append({
                "step": step, "offset": offset, "paired_difference": encoded(difference),
                "components": {key: encoded(value) for key, value in components.items()},
                "raw_difference": [encoded(value) for value in raw],
                "algebraic_agreement_errors": agreement, "invariant_checks": invariants,
            })
        stable = complex_sum(terms)
        raw_derivative = sum(raw_terms)
        records.append({
            "direction": "force_work", "step": step,
            "force_work_errors": [BASE.error(stable, predicted)] * 2,
            "derivative": encoded(stable), "predicted": encoded(predicted),
            "raw_derivative": [encoded(value) for value in raw_derivative],
            "raw_errors": [BASE.error(value, predicted) for value in raw_derivative],
        })
    return records, packets


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    name = "replay" if args.replay else "run"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(),
                "utc": BRIDGE.utc(), "affinity": process.cpu_affinity(), "priority": "below-normal"}
    if (ROOT / (name + "-start.json")).exists():
        raise FileExistsError("Do not overwrite a worker receipt")
    BRIDGE.save(ROOT / (name + "-start.json"), identity)
    try:
        frozen = json.loads((ROOT / "inputs.json").read_text(encoding="utf-8"))
        before = BRIDGE.verify_inputs()
        for entry in frozen:
            path = PARENT / entry["path"]
            before[str(path)] = path.is_file() and path.stat().st_size == entry["bytes"] and BRIDGE.sha(path) == entry["sha256"]
        if not all(before.values()):
            raise RuntimeError("Input hash mismatch")
        aggregate = []
        repair_checks = {}
        for seed in BRIDGE.CONFIG["seeds"]:
            with np.load(WARD.PREVIOUS / f"fixture-{seed}.npz", allow_pickle=False) as fixture:
                arrays = {key: fixture[key] for key in fixture.files}
            original, values = BRIDGE.panel(arrays, seed)
            saved_original = json.loads((PARENT / f"panel-{seed}.json").read_text(encoding="utf-8"))
            if original != saved_original:
                raise RuntimeError("Original failed/passing results did not reproduce")
            with np.load(PARENT / f"sources-{seed}.npz", allow_pickle=False) as cached:
                if set(cached.files) != set(values) or not all(np.array_equal(cached[key], values[key]) for key in values):
                    raise RuntimeError("Original source arrays changed")
            report = json.loads(json.dumps(original))
            if seed == BRIDGE.CONFIG["finite_difference_fixture"]:
                repaired, packets = repaired_force(arrays, values)
                for index, corrected in enumerate(repaired, start=6):
                    item = report["finite_tests"][index]
                    if item["step"] != corrected["step"] or item["direction"] != "force_work":
                        raise RuntimeError("Unexpected frozen test ordering")
                    for case, value in enumerate(corrected["force_work_errors"]):
                        key = f"finite_{index}_force_work_errors_{case}"
                        report["metrics"][key] = value
                        report["checks"][key] = bool(np.isfinite(value) and value <= BRIDGE.CONFIG["identity_tolerance"])
                    report["finite_tests"][index] = corrected
                    repair_checks[f"raw_force_step_{index}_reproduced"] = corrected["raw_errors"] == item["force_work_errors"]
                for index, packet in enumerate(packets):
                    repair_checks[f"paired_packet_{index}_fixed_terms"] = all(packet["invariant_checks"].values())
                    repair_checks[f"paired_packet_{index}_algebra"] = max(packet["algebraic_agreement_errors"]) <= BRIDGE.CONFIG["identity_tolerance"]
                if args.replay:
                    if packets != json.loads((ROOT / "paired-work-packets.json").read_text(encoding="utf-8")):
                        raise RuntimeError("Paired work replay differs")
                else:
                    BRIDGE.save(ROOT / "paired-work-packets.json", packets)
            report["passed"] = all(report["checks"].values())
            report["original_report_reproduced"] = True
            report["original_source_arrays_unchanged"] = True
            if args.replay:
                if report != json.loads((ROOT / f"panel-{seed}.json").read_text(encoding="utf-8")):
                    raise RuntimeError("Repaired panel replay differs")
            else:
                BRIDGE.save(ROOT / f"panel-{seed}.json", report)
            aggregate.append(report)
            print(json.dumps({"seed": seed, "passed": report["passed"], "checks": len(report["checks"])}), flush=True)
        after = BRIDGE.verify_inputs()
        for entry in frozen:
            path = PARENT / entry["path"]
            after[str(path)] = path.is_file() and path.stat().st_size == entry["bytes"] and BRIDGE.sha(path) == entry["sha256"]
        result = {
            "passed": all(report["passed"] for report in aggregate) and all(repair_checks.values()) and all(after.values()),
            "panels": [{"seed": value["seed"], "passed": value["passed"], "checks": len(value["checks"])} for value in aggregate],
            "repair_checks": repair_checks, "retained_files_verified": len(after),
            "inputs_unchanged": all(before.values()) and all(after.values()),
            "original_failed_result_retained": True, "original_results_reproduced": True,
            "original_source_arrays_unchanged": True,
            "code_sha256": BRIDGE.sha(Path(__file__)), "bridge_code_sha256": BRIDGE.sha(PARENT / "run_bridge.py"),
            "protocol_sha256": BRIDGE.sha(PARENT / "protocol.json"), "tolerance": BRIDGE.CONFIG["identity_tolerance"],
            "quantum_measure_included": False, "physical_history_changed": False,
            "local_lattice_stress_divergence_proved": False, "constant_metric_only": True,
        }
        if args.replay and result != json.loads((ROOT / "result.json").read_text(encoding="utf-8")):
            raise RuntimeError("Aggregate replay differs")
        BRIDGE.save(ROOT / ("replay-result.json" if args.replay else "result.json"), result)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        BRIDGE.save(ROOT / (name + "-end.json"), {
            "completed": True, "passed": result["passed"], "pid": process.pid, "created": process.create_time(),
            "utc": BRIDGE.utc(), "elapsed_seconds": time.monotonic() - STARTED, "pycache_absent": not any(PARENT.rglob("__pycache__")),
        })
        return 0 if result["passed"] else 1
    except BaseException as failure:
        BRIDGE.save(ROOT / (name + "-failure.json"), {"completed": False, "pid": process.pid, "created": process.create_time(), "utc": BRIDGE.utc(), "error": repr(failure)})
        raise


if __name__ == "__main__":
    raise SystemExit(main())

