import os

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import time

import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
PREVIOUS = Path(CONFIG["previous_directory"])
spec = importlib.util.spec_from_file_location("checked_ward", PREVIOUS / "dirac-adjoint/run_ward.py")
WARD = importlib.util.module_from_spec(spec)
spec.loader.exec_module(WARD)
BASE = WARD.BASE
STARTED = time.monotonic()
SITES = WARD.SITES
METRICS = [np.eye(4), np.diag([1., -1., 0., 0.]), np.zeros((4, 4))]
METRICS[2][0, 1] = METRICS[2][1, 0] = 1
FD_WEIGHTS = [4 / 5, -1 / 5, 4 / 105, -1 / 280]


def utc():
    return datetime.now(timezone.utc).isoformat()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def guard():
    if time.monotonic() - STARTED > CONFIG["maximum_worker_seconds"]:
        raise TimeoutError("Bounded worker deadline reached")


def matrix_trace_product(left, right):
    return np.einsum("ij,ji->", left, right)


def geometry(inverse_metric):
    eigenvalues, eigenvectors = np.linalg.eigh(inverse_metric)
    if eigenvalues.min() <= 0:
        raise ValueError("Nonpositive diagnostic metric")
    coframe = (eigenvectors * np.sqrt(eigenvalues)) @ eigenvectors.T
    return {
        "inverse": inverse_metric, "covariant": np.linalg.inv(inverse_metric),
        "coframe": coframe, "volume": float(np.linalg.det(inverse_metric) ** -0.5),
        "values": np.sqrt(eigenvalues), "vectors": eigenvectors,
    }


def coframe_derivative(geom, tangent):
    vectors = geom["vectors"]
    coefficients = vectors.T @ tangent @ vectors
    return vectors @ (coefficients / (geom["values"][:, None] + geom["values"][None, :])) @ vectors.T


def sign_derivative(operator, argument):
    vectors = operator["vectors"]
    return vectors @ (operator["divided"] * (vectors.conj().T @ argument @ vectors)) @ vectors.conj().T


def build_operator(arrays, label, geom, responses=True):
    guard()
    internal = abs(BASE.FIELDS[label][0]) * BASE.FIELDS[label][1]
    width = 4 * internal
    dimension = SITES * width
    unit = np.eye(dimension, dtype=complex)
    gamma5 = np.kron(np.eye(SITES), np.kron(BASE.GAMMA5, np.eye(internal)))
    spin = [np.kron(np.eye(SITES), np.kron(value, np.eye(internal))) for value in BASE.GAMMA]
    transports = [np.zeros_like(unit) for _ in range(4)]
    for site in range(SITES):
        source = slice(site * width, (site + 1) * width)
        for direction in range(4):
            other, crossed = BASE.shift(site, direction)
            target = slice(other * width, (other + 1) * width)
            boundary = BASE.CONFIG["fermion_boundary_signs"][direction] if crossed else 1
            link = BASE.representation(arrays["color"][site, direction], arrays["weak"][site, direction], arrays["phase"][site, direction], label)
            transports[direction][source, target] = boundary * np.kron(np.eye(4), link)
    differences = [value - unit for value in transports]
    skew = [(value - value.conj().T) / 2 for value in transports]
    gamma = [sum(geom["coframe"][axis, direction] * spin[axis] for axis in range(4)) for direction in range(4)]
    laplacian = {}
    wilson = sum(gamma[direction] @ skew[direction] for direction in range(4))
    for first in range(4):
        for second in range(4):
            if responses or geom["inverse"][first, second] != 0:
                laplacian[first, second] = differences[first].conj().T @ differences[second]
            if geom["inverse"][first, second] != 0:
                wilson += geom["inverse"][first, second] * laplacian[first, second] / 2
    kernel = gamma5 @ (wilson - unit)
    values, vectors = np.linalg.eigh(kernel)
    signs = np.sign(values)
    spectral_sign = (vectors * signs) @ vectors.conj().T
    divided = np.zeros((dimension, dimension))
    separated = signs[:, None] != signs[None, :]
    denominators = values[:, None] - values[None, :]
    divided[separated] = (signs[:, None] - signs[None, :])[separated] / denominators[separated]
    gap = float(np.min(np.abs(values)))
    if gap < BASE.CONFIG["kernel_gap_floor"]:
        raise ValueError("Frozen Wilson-kernel gap guard failed")
    return {
        "wilson": wilson, "kernel": kernel, "overlap": unit + gamma5 @ spectral_sign,
        "projector": (unit + spectral_sign) / 2, "plus": (unit + gamma5) / 2,
        "gamma5": gamma5, "gamma": gamma, "spin": spin, "skew": skew,
        "differences": differences, "laplacian": laplacian,
        "vectors": vectors, "divided": divided, "gap": gap, "internal": internal,
    }


def scalar_data(arrays, geom):
    higgs_gradient = np.zeros((SITES, 4, 2), complex)
    neutral_gradient = np.zeros((SITES, 4, 3))
    for site in range(SITES):
        for direction in range(4):
            other, _ = BASE.shift(site, direction)
            link = arrays["phase"][site, direction] ** 3 * arrays["weak"][site, direction]
            higgs_gradient[site, direction] = link @ arrays["higgs"][other] - arrays["higgs"][site]
            neutral_gradient[site, direction] = arrays["neutral"][other] - arrays["neutral"][site]
    higgs_norm = np.sum(np.abs(arrays["higgs"]) ** 2, axis=1)
    higgs_potential = BASE.CONFIG["higgs_mass_squared"] * np.sum(higgs_norm) + BASE.CONFIG["higgs_quartic"] * np.sum(higgs_norm ** 2)
    mass = np.diag(np.array([BASE.CONFIG["bath_mass_squared"]] + BASE.CONFIG["bath_frequency_squared"], float))
    mass[0, 1:] = -np.array(BASE.CONFIG["bath_couplings"])
    mass[1:, 0] = mass[0, 1:]
    neutral_potential = 0.5 * np.einsum("xi,ij,xj->", arrays["neutral"], mass, arrays["neutral"])
    higgs_kinetic = np.einsum("mn,xmi,xni->", geom["inverse"], higgs_gradient.conj(), higgs_gradient).real
    neutral_kinetic = 0.5 * np.einsum("mn,xmi,xni->", geom["inverse"], neutral_gradient, neutral_gradient)
    return {
        "higgs_gradient": higgs_gradient, "neutral_gradient": neutral_gradient,
        "higgs": float(higgs_potential + higgs_kinetic), "neutral": float(neutral_potential + neutral_kinetic),
    }


def build_model(arrays, inverse_metric, responses=True, split=False):
    geom = geometry(inverse_metric)
    operators = {label: build_operator(arrays, label, geom, responses) for label in BASE.FIELDS}
    fields = {label: value["projector"] @ arrays["eta_" + label] for label, value in operators.items()}
    bars = {label: arrays["bar_" + label].conj() @ value["plus"] for label, value in operators.items()}
    interaction = WARD.interaction(fields, bars, arrays["higgs"])
    kinetic = sum(bars[label] @ operators[label]["overlap"] @ fields[label] for label in BASE.FIELDS)
    scalar = scalar_data(arrays, geom)
    bare_matter = kinetic + interaction["action"] + scalar["higgs"]
    model = {
        "geometry": geom, "operators": operators, "fields": fields, "bars": bars,
        "interaction": interaction, "scalar": scalar, "bare_matter": bare_matter,
        "matter": geom["volume"] * bare_matter,
        "with_bath": geom["volume"] * (bare_matter + scalar["neutral"]),
    }
    if responses:
        for label, operator in operators.items():
            direct = np.outer(fields[label], bars[label] @ operator["gamma5"])
            chain = np.outer(arrays["eta_" + label], (bars[label] @ operator["overlap"] + interaction["field_gradient"][label]) / 2)
            operator["sensitivity"] = sign_derivative(operator, direct + chain) @ operator["gamma5"]
            if split:
                operator["direct_sensitivity"] = sign_derivative(operator, direct) @ operator["gamma5"]
    return model


def wilson_metric_derivative(operator, geom, tangent):
    delta_coframe = coframe_derivative(geom, tangent)
    response = np.zeros_like(operator["wilson"])
    for direction in range(4):
        gamma = sum(delta_coframe[axis, direction] * operator["spin"][axis] for axis in range(4))
        response += gamma @ operator["skew"][direction]
    for first in range(4):
        for second in range(4):
            if tangent[first, second] != 0:
                response += tangent[first, second] * operator["laplacian"][first, second] / 2
    return response


def metric_response(model, tangent, direct=False):
    geom = model["geometry"]
    density_factor = -np.trace(geom["covariant"] @ tangent) / 2
    sensitivity = "direct_sensitivity" if direct else "sensitivity"
    fermion = sum(
        matrix_trace_product(operator[sensitivity], wilson_metric_derivative(operator, geom, tangent))
        for operator in model["operators"].values()
    )
    higgs = np.einsum("mn,xmi,xni->", tangent, model["scalar"]["higgs_gradient"].conj(), model["scalar"]["higgs_gradient"]).real
    neutral = 0.5 * np.einsum("mn,xmi,xni->", tangent, model["scalar"]["neutral_gradient"], model["scalar"]["neutral_gradient"])
    matter = geom["volume"] * (fermion + higgs + density_factor * model["bare_matter"])
    bath = geom["volume"] * (neutral + density_factor * model["scalar"]["neutral"])
    return np.array([matter, matter + bath], complex)


def link_current(arrays, model, site, direction, generator):
    geom = model["geometry"]
    other, crossed = BASE.shift(site, direction)
    boundary = BASE.CONFIG["fermion_boundary_signs"][direction] if crossed else 1
    result = 0j
    for label, operator in model["operators"].items():
        internal = operator["internal"]
        width = 4 * internal
        source = slice(site * width, (site + 1) * width)
        target = slice(other * width, (other + 1) * width)
        link = boundary * BASE.representation(arrays["color"][site, direction], arrays["weak"][site, direction], arrays["phase"][site, direction], label)
        tangent = np.kron(np.eye(4), WARD.represented_generator(label, generator) @ link)
        key = "link_sensitivity_" + str(direction)
        if key not in operator:
            sensitivity = operator["sensitivity"]
            weighted_difference = sum(geom["inverse"][direction, other_axis] * operator["differences"][other_axis] for other_axis in range(4))
            forward = (sensitivity @ operator["gamma"][direction] + sensitivity @ weighted_difference.conj().T) / 2
            reverse = (-sensitivity @ operator["gamma"][direction] + weighted_difference @ sensitivity) / 2
            operator[key] = (forward, reverse)
        forward, reverse = operator[key]
        result += matrix_trace_product(forward[target, source], tangent)
        result += matrix_trace_product(reverse[source, target], tangent.conj().T)
    higgs_link = arrays["phase"][site, direction] ** 3 * arrays["weak"][site, direction]
    transported = higgs_link @ arrays["higgs"][other]
    variation = WARD.HIGGS_GENERATORS[generator] @ transported
    weighted_gradient = sum(geom["inverse"][direction, axis] * model["scalar"]["higgs_gradient"][site, axis] for axis in range(4))
    result += 2 * np.vdot(weighted_gradient, variation).real
    return geom["volume"] * result


def all_currents(arrays, model):
    return np.array([
        [[link_current(arrays, model, site, direction, generator) for generator in range(12)] for direction in range(4)]
        for site in range(SITES)
    ])


def response_tensor(model):
    values = np.zeros((2, 4, 4), complex)
    for first in range(4):
        for second in range(first, 4):
            tangent = np.zeros((4, 4))
            tangent[first, second] = tangent[second, first] = 1
            response = metric_response(model, tangent)
            if first != second:
                response /= 2
            values[:, first, second] = values[:, second, first] = response
    return values


def principal_log(unitary):
    values, vectors = np.linalg.eig(unitary)
    angles = np.angle(values)
    if np.max(np.abs(angles)) >= np.pi / 2:
        raise ValueError("Curvature probe approaches a branch cut")
    result = vectors @ np.diag(1j * angles) @ np.linalg.inv(vectors)
    return (result - result.conj().T) / 2


def curvature(arrays):
    result = np.zeros((SITES, 4, 4, 12))
    for site in range(SITES):
        for first in range(4):
            for second in range(first + 1, 4):
                next_first, _ = BASE.shift(site, first)
                next_second, _ = BASE.shift(site, second)
                for key, basis, offset in (("color", WARD.COLOR_BASIS, 0), ("weak", WARD.WEAK_BASIS, 8)):
                    links = arrays[key]
                    loop = links[site, first] @ links[next_first, second] @ links[next_second, first].conj().T @ links[site, second].conj().T
                    logarithm = principal_log(loop)
                    for generator, matrix in enumerate(basis):
                        result[site, first, second, offset + generator] = -2 * np.trace(matrix @ logarithm).real
                phase = arrays["phase"]
                loop = phase[site, first] * phase[next_first, second] * phase[next_second, first].conjugate() * phase[site, second].conjugate()
                result[site, first, second, 11] = np.angle(loop)
                result[site, second, first] = -result[site, first, second]
    return result


def force_shift(arrays, field_strength, vector, amount):
    result = {name: value.copy() for name, value in arrays.items()}
    tangent = np.einsum("xn,xnma->xma", vector, field_strength)
    for site in range(SITES):
        for direction in range(4):
            color = sum(tangent[site, direction, generator] * WARD.COLOR_BASIS[generator] for generator in range(8))
            weak = sum(tangent[site, direction, 8 + generator] * WARD.WEAK_BASIS[generator] for generator in range(3))
            result["color"][site, direction] = WARD.matrix_exp_antihermitian(color, amount) @ arrays["color"][site, direction]
            result["weak"][site, direction] = WARD.matrix_exp_antihermitian(weak, amount) @ arrays["weak"][site, direction]
            result["phase"][site, direction] *= np.exp(1j * amount * tangent[site, direction, 11])
    return result


def action_pair(model):
    return np.array([model["matter"], model["with_bath"]])


def finite_tests(arrays, flat, currents, field_strength, vector):
    records = []
    for index, tangent in enumerate(METRICS):
        selected = CONFIG["paired_links"][index]
        expected_metric = metric_response(flat, tangent)
        h_tangent = tangent - np.eye(4) * np.trace(tangent) / 2
        expected_density = metric_response(flat, h_tangent)
        for step in CONFIG["finite_difference_steps"]:
            metric_action = np.zeros(2, complex)
            metric_current = 0j
            link_stress = np.zeros(2, complex)
            density_action = np.zeros(2, complex)
            link_action = np.zeros(2, complex)
            for offset, weight in enumerate(FD_WEIGHTS, start=1):
                for sign in (1, -1):
                    amount = sign * offset * step
                    coefficient = sign * weight / step
                    changed_metric = build_model(arrays, np.eye(4) + amount * tangent)
                    metric_action += coefficient * action_pair(changed_metric)
                    metric_current += coefficient * link_current(arrays, changed_metric, **selected)
                    changed_links = WARD.link_shift(arrays, **selected, amount=amount)
                    changed_source = build_model(changed_links, np.eye(4))
                    link_stress += coefficient * metric_response(changed_source, tangent)
                    link_action += coefficient * action_pair(changed_source)
                    densitized = np.eye(4) + amount * tangent
                    inverse = densitized / np.sqrt(np.linalg.det(densitized))
                    changed_density = build_model(arrays, inverse, responses=False)
                    density_action += coefficient * action_pair(changed_density)
            expected_link = currents[selected["site"], selected["direction"], selected["generator"]]
            records.append({
                "direction": CONFIG["metric_directions"][index], "step": step,
                "metric_action_errors": [BASE.error(metric_action[case], expected_metric[case]) for case in range(2)],
                "densitized_chain_errors": [BASE.error(density_action[case], expected_density[case]) for case in range(2)],
                "mixed_errors": [BASE.error(link_stress[case], metric_current) for case in range(2)],
                "link_action_errors": [BASE.error(link_action[case], expected_link) for case in range(2)],
                "mixed_current": [float(metric_current.real), float(metric_current.imag)],
            })
    force = np.einsum("xnma,xma->xn", field_strength, currents)
    predicted = np.einsum("xn,xn->", vector, force)
    for step in CONFIG["finite_difference_steps"]:
        derivative = np.zeros(2, complex)
        for offset, weight in enumerate(FD_WEIGHTS, start=1):
            plus = build_model(force_shift(arrays, field_strength, vector, offset * step), np.eye(4), responses=False)
            minus = build_model(force_shift(arrays, field_strength, vector, -offset * step), np.eye(4), responses=False)
            derivative += weight * (action_pair(plus) - action_pair(minus)) / step
        records.append({"direction": "force_work", "step": step, "force_work_errors": [BASE.error(value, predicted) for value in derivative]})
    return records


def neutral_exchange(arrays):
    coupling = np.array(BASE.CONFIG["bath_couplings"])
    residual = []
    omitted = []
    for site in range(SITES):
        for direction in range(4):
            other, _ = BASE.shift(site, direction)
            first, last = arrays["neutral"][site], arrays["neutral"][other]
            mean = (first + last) / 2
            difference = last - first
            motion_transfer = -np.dot(coupling, mean[1:]) * difference[0]
            bath_transfer = -mean[0] * np.dot(coupling, difference[1:])
            stress_transfer = last[0] * np.dot(coupling, last[1:]) - first[0] * np.dot(coupling, first[1:])
            residual.append(motion_transfer + bath_transfer + stress_transfer)
            omitted.append(motion_transfer + bath_transfer)
    return np.array(residual), np.array(omitted)


def panel(arrays, seed):
    flat = build_model(arrays, np.eye(4), split=True)
    old = WARD.model(arrays)
    with np.load(PREVIOUS / "dirac-adjoint" / f"currents-{seed}.npz", allow_pickle=False) as saved:
        saved_current = saved["current"]
        saved_transformed = saved["transformed_current"]
    currents = all_currents(arrays, flat)
    tensor_response = response_tensor(flat)
    stress = -2 * tensor_response
    h_source = tensor_response - np.eye(4)[None, :, :] * np.trace(tensor_response, axis1=1, axis2=2)[:, None, None] / 2
    expected_h = -(stress - np.eye(4)[None, :, :] * np.trace(stress, axis1=1, axis2=2)[:, None, None] / 2) / 2
    neutral_gradient = flat["scalar"]["neutral_gradient"]
    neutral_stress = np.eye(4) * flat["scalar"]["neutral"] - np.einsum("xmi,xni->mn", neutral_gradient, neutral_gradient)
    field_strength = curvature(arrays)
    force = np.einsum("xnma,xma->xn", field_strength, saved_current)
    transformed = WARD.transform_all(arrays)
    changed_strength = curvature(transformed)
    changed_force = np.einsum("xnma,xma->xn", changed_strength, saved_transformed)
    vector = np.array([[np.cos((site + 1) * (axis + 1)) / 2 for axis in range(4)] for site in range(SITES)])
    exchange, omitted_exchange = neutral_exchange(arrays)
    metrics, checks = {}, {}

    def check(name, value, minimum=False):
        metrics[name] = float(value)
        checks[name] = bool(np.isfinite(value) and (
            value >= CONFIG["negative_control_floor"] if minimum else value <= CONFIG["identity_tolerance"]
        ))

    check("flat_action_matter", BASE.error(flat["matter"], old["matter"]))
    check("flat_action_with_bath", BASE.error(flat["with_bath"], old["with_bath"]))
    check("checked_current_recovered", BASE.error(currents, saved_current))
    for label in BASE.FIELDS:
        check("flat_operator_" + label, BASE.error(flat["operators"][label]["overlap"], old["operators"][label]["overlap"]))
    check("densitized_source_algebra", BASE.error(h_source, expected_h))
    reversed_stress = stress - np.eye(4)[None, :, :] * np.trace(stress, axis1=1, axis2=2)[:, None, None] / 2
    reversed_twice = reversed_stress - np.eye(4)[None, :, :] * np.trace(reversed_stress, axis1=1, axis2=2)[:, None, None] / 2
    check("trace_reversal_involution", BASE.error(reversed_twice, stress))
    check("explicit_bath_stress_addition", BASE.error(stress[1] - stress[0], neutral_stress))
    check("neutral_stress_is_not_zero", float(np.linalg.norm(neutral_stress)), True)
    check("force_gauge_invariance", BASE.error(force, changed_force))
    check("neutral_internal_exchange", float(np.max(np.abs(exchange))))
    check("negative_omit_interaction_stress", float(np.max(np.abs(omitted_exchange))), True)
    missing_projector = max(BASE.error(metric_response(flat, tangent), metric_response(flat, tangent, direct=True)) for tangent in METRICS)
    check("negative_omit_metric_projector", missing_projector, True)

    operator = flat["operators"]["Q"]
    tangent = METRICS[1]
    derivative = wilson_metric_derivative(operator, flat["geometry"], tangent)
    delta_projector = sign_derivative(operator, operator["gamma5"] @ derivative) / 2
    column = flat["fields"]["Q"]
    off_diagonal = delta_projector @ column
    row = off_diagonal.conj() @ (np.eye(len(column)) - operator["projector"])
    check("projected_Euler_zero_witness", float(np.linalg.norm(row @ operator["projector"])))
    check("negative_invertible_map_assumption", float(abs(row @ delta_projector @ column)), True)

    finite = finite_tests(arrays, flat, currents, field_strength, vector) if seed == CONFIG["finite_difference_fixture"] else []
    for index, item in enumerate(finite):
        for key, errors in item.items():
            if key.endswith("_errors"):
                for case, value in enumerate(errors):
                    check(f"finite_{index}_{key}_{case}", value)
    report = {
        "seed": seed, "passed": all(checks.values()), "checks": checks, "metrics": metrics,
        "finite_tests": finite, "constant_metric_only": True,
        "measure_included": False, "physical_history_modified": False,
        "force_max": float(np.max(np.abs(force))),
        "neutral_stress_norm": float(np.linalg.norm(neutral_stress)),
        "fixture_sha256": sha(WARD.PREVIOUS / f"fixture-{seed}.npz"),
    }
    output = {
        "metric_response": tensor_response, "integrated_stress": stress,
        "densitized_source": h_source, "explicit_neutral_stress": neutral_stress,
        "checked_current": currents, "curvature": field_strength, "force": force,
        "transformed_force": changed_force, "neutral_exchange_residual": exchange,
        "omitted_interaction_exchange": omitted_exchange,
    }
    return report, output


def verify_inputs():
    checks = {}
    for entry in CONFIG["local_inputs"]:
        path = Path(entry["path"])
        checks[str(path)] = path.is_file() and path.stat().st_size == entry["bytes"] and sha(path) == entry["sha256"]
    seal = json.loads((PREVIOUS / "closeout.json").read_text(encoding="utf-8"))
    for entry in seal["artifacts"]:
        path = PREVIOUS / entry["path"]
        checks[str(path)] = path.is_file() and path.stat().st_size == entry["bytes"] and sha(path) == entry["sha256"]
    checks.update(WARD.verify_inputs())
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    name = "replay" if args.replay else "run"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(), "utc": utc(), "affinity": process.cpu_affinity(), "priority": "below-normal"}
    save(ROOT / (name + "-start.json"), identity)
    try:
        before = verify_inputs()
        if not all(before.values()):
            raise RuntimeError("Frozen input integrity failed")
        reports = []
        for seed in CONFIG["seeds"]:
            with np.load(WARD.PREVIOUS / f"fixture-{seed}.npz", allow_pickle=False) as saved:
                arrays = {key: saved[key] for key in saved.files}
            report, values = panel(arrays, seed)
            if args.replay:
                original = json.loads((ROOT / f"panel-{seed}.json").read_text(encoding="utf-8"))
                if report != original:
                    raise RuntimeError("Panel replay mismatch")
                with np.load(ROOT / f"sources-{seed}.npz", allow_pickle=False) as original_values:
                    if set(original_values.files) != set(values) or not all(np.array_equal(original_values[key], values[key]) for key in values):
                        raise RuntimeError("Source replay mismatch")
            else:
                if (ROOT / f"panel-{seed}.json").exists():
                    raise FileExistsError("Never overwrite an earlier result")
                save(ROOT / f"panel-{seed}.json", report)
                np.savez_compressed(ROOT / f"sources-{seed}.npz", **values)
            reports.append(report)
            print(json.dumps({"seed": seed, "passed": report["passed"], "checks": len(report["checks"])}), flush=True)
        after = verify_inputs()
        result = {
            "passed": all(report["passed"] for report in reports) and all(after.values()),
            "panels": [{"seed": value["seed"], "passed": value["passed"], "checks": len(value["checks"])} for value in reports],
            "retained_files_verified": len(after),
            "inputs_unchanged": all(before.values()) and all(after.values()),
            "code_sha256": sha(Path(__file__)), "protocol_sha256": sha(ROOT / "protocol.json"),
            "quantum_measure_included": False, "curved_lattice_constructed": False,
            "local_lattice_stress_divergence_proved": False, "physical_history_changed": False,
        }
        if args.replay and result != json.loads((ROOT / "result.json").read_text(encoding="utf-8")):
            raise RuntimeError("Aggregate replay mismatch")
        save(ROOT / ("replay-result.json" if args.replay else "result.json"), result)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        save(ROOT / (name + "-end.json"), {"completed": True, "passed": result["passed"], "pid": process.pid, "created": process.create_time(), "utc": utc(), "elapsed_seconds": time.monotonic() - STARTED, "pycache_absent": not any(ROOT.rglob("__pycache__"))})
        return 0 if result["passed"] else 1
    except BaseException as failure:
        save(ROOT / (name + "-failure.json"), {"completed": False, "pid": process.pid, "created": process.create_time(), "utc": utc(), "error": repr(failure)})
        raise


if __name__ == "__main__":
    raise SystemExit(main())
