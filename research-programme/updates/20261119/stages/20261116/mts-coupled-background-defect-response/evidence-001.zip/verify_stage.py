import os
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
import json
from pathlib import Path

import numpy as np
import psutil

import run_response as RESPONSE

ROOT = Path(__file__).resolve().parent
REPAIR = ROOT / "segmented-response"


def archive(path):
    with np.load(path, allow_pickle=False) as saved:
        return {name: saved[name] for name in saved.files}


def verify():
    checks, science, inputs = {}, {}, {}
    for label, directory in (("original", ROOT), ("partitioned", REPAIR)):
        for name in ("inputs.json", "interface-inputs.json"):
            mapping = RESPONSE.read(directory / name)
            RESPONSE.check_inputs(mapping)
            inputs.update(mapping)
        interface = RESPONSE.read(directory / "interface-result.json")
        replay = RESPONSE.read(directory / "interface-replay.json")
        checks[label + "_interface_exact_replay"] = replay["report_exact"] and replay["arrays_exact"]
        checks[label + "_no_source_promotion"] = interface["corrected_prediction_promoted"] is False
        checks[label + "_no_quantum_measure"] = interface["quantum_measure_included"] is False
        checks[label + "_interface_status_consistent"] = interface["interface_checks_passed"] == all(
            all(value["passed"] for value in item["checks"].values()) for item in interface["cases"].values())
        science[label] = {"interface_checks_passed": interface["interface_checks_passed"], "cases": {}}
        for case in RESPONSE.CONFIG["cases"]:
            report = RESPONSE.read(directory / (case + "-result.json"))
            arrays = archive(directory / (case + "-response.npz"))
            prefix = label + "_" + case
            checks[prefix + "_completion"] = RESPONSE.read(directory / (case + "-run-end.json"))["completed"]
            checks[prefix + "_finite"] = all(np.all(np.isfinite(value)) for value in arrays.values())
            checks[prefix + "_grid_shape"] = arrays["queries"].shape == (33, 902)
            checks[prefix + "_own_status_consistent"] = report["background_checks_passed"] == all(
                value["passed"] for value in report["checks"].values())
            checks[prefix + "_single_anchor"] = all(np.array_equal(arrays[f"correction_{steps}"][0], np.zeros_like(arrays[f"correction_{steps}"][0])) for steps in RESPONSE.CONFIG["steps"])
            checks[prefix + "_environment_not_zeroed"] = report["surrounding_response_assumed_zero"] is False
            checks[prefix + "_source_not_promoted"] = report["corrected_prediction_promoted"] is False
            checks[prefix + "_physical_max_steps_preserved"] = all(
                report["integrations"][str(steps)]["maximum_physical_step"] ==
                RESPONSE.read(ROOT / (case + "-result.json"))["integrations"][str(steps)]["maximum_physical_step"]
                for steps in RESPONSE.CONFIG["steps"])
            science[label]["cases"][case] = {
                "background_checks_passed": report["background_checks_passed"],
                "check_count": len(report["checks"]),
                "failed_checks": {name: value for name, value in report["checks"].items() if not value["passed"]},
                "maximum_absolute_control_relative": max(value["relative"] for name, value in report["checks"].items() if "_absolute_" in name),
                "source_interface_checks_passed": interface["cases"][case]["interface_checks_passed"],
                "source_interface_check_count": len(interface["cases"][case]["checks"]),
                "fixed_state_diagnostics": interface["cases"][case]["diagnostics"],
                "final_fixed_state_increment": interface["cases"][case]["final_fixed_state_increment"],
            }
    old_config, new_config = RESPONSE.read(ROOT / "protocol.json"), RESPONSE.read(REPAIR / "protocol.json")
    for name in old_config:
        checks["retained_protocol_" + name] = old_config[name] == new_config[name]
    for case in RESPONSE.CONFIG["cases"]:
        original = archive(ROOT / (case + "-response.npz"))
        corrected = archive(REPAIR / (case + "-response.npz"))
        for name in ("queries", "unique_times", "query_index", "normalization", "represented", "hubble", "rate"):
            checks[case + "_retained_" + name] = np.array_equal(original[name], corrected[name])
        checks[case + "_conditioning_units"] = np.array_equal(corrected["correction_normalization"],
                                                            original["correction_normalization"] * new_config["response_unit_factor"])
        bounds = corrected["integration_boundaries"]
        checks[case + "_ordered_internal_partition"] = bool(np.all(np.diff(bounds) > 0) and bounds[0] > corrected["unique_times"][0] and bounds[-1] < corrected["unique_times"][-1])
        checks[case + "_same_partition_count"] = all(
            RESPONSE.read(REPAIR / (case + "-result.json"))["integrations"][str(steps)]["segments"] == len(bounds) + 1
            for steps in RESPONSE.CONFIG["steps"])
    for path in ROOT.rglob("*.py"):
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    checks["no_bytecode_cache"] = not list(ROOT.rglob("__pycache__"))
    checks["prior_pressure_failure_retained"] = RESPONSE.read(RESPONSE.PREVIOUS / "verification.json")["hilbert_pressure_budget_passed"] is False
    checks["derivation_and_next_exist"] = all((ROOT / name).is_file() for name in ("DERIVATION.md", "SOURCE-INTERFACE.md", "RESULTS.md", "NEXT.md"))
    return {"verification_checks_passed": all(bool(value) for value in checks.values()),
            "checks": {name: bool(value) for name, value in checks.items()}, "science": science,
            "frozen_input_count": len(inputs), "all_background_checks_passed": all(
                item["background_checks_passed"] for item in science["partitioned"]["cases"].values()),
            "quantum_measure_included": False, "corrected_prediction_promoted": False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    label = "verify-replay" if args.replay else "verify-run"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(),
                "utc": RESPONSE.utc(), "affinity": process.cpu_affinity(), "priority": "below-normal"}
    RESPONSE.write(ROOT / (label + "-start.json"), identity)
    report = verify()
    if args.replay:
        if report != RESPONSE.read(ROOT / "verification.json"):
            raise RuntimeError("Verification replay differs")
        RESPONSE.write(ROOT / "verification-replay.json", {"report_exact": True, "verification_checks_passed": report["verification_checks_passed"]})
    else:
        RESPONSE.write(ROOT / "verification.json", report)
    RESPONSE.write(ROOT / (label + "-end.json"), {**identity, "completed": True, "verification_checks_passed": report["verification_checks_passed"]})
    print(json.dumps({"verification_checks_passed": report["verification_checks_passed"],
                      "checks": len(report["checks"]), "frozen_inputs": report["frozen_input_count"],
                      "failed": [name for name, passed in report["checks"].items() if not passed],
                      "all_background_checks_passed": report["all_background_checks_passed"]}), flush=True)
    return 0 if report["verification_checks_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())

