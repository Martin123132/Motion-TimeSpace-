import os

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys
import time

import numpy as np
import psutil
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
HISTORY = Path(CONFIG["history_directory"])
PREVIOUS = Path(CONFIG["previous_directory"])
POST = Path(CONFIG["post_directory"])
PILOT = Path(CONFIG["pilot_directory"])
sys.dont_write_bytecode = True
sys.path.insert(0, str(HISTORY))
import extension_math as EX

START = time.monotonic()
ALGEBRA = CONFIG["algebra_tolerance"]
GATE = CONFIG["numerical_tolerance"]
FD_WEIGHTS = [4 / 5, -1 / 5, 4 / 105, -1 / 280]


def utc():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def guard():
    if time.monotonic() - START > CONFIG["maximum_worker_seconds"]:
        raise TimeoutError("Bounded worker deadline")
    for directory in (ROOT, POST, HISTORY, PREVIOUS, EX.BRANCH):
        if (directory / "STOP-REQUESTED").exists():
            raise RuntimeError("Owner hold: " + str(directory))


def check_inputs(mapping):
    for path, expected in mapping.items():
        guard()
        if not Path(path).is_file() or digest(path) != expected:
            raise RuntimeError("Input changed: " + path)


def freeze_inputs():
    if digest(PREVIOUS / "closeout.json") != CONFIG["previous_closeout_sha256"]:
        raise RuntimeError("Unexpected previous seal")
    inputs = read(PILOT / "inputs.json")
    for name in ("cold-result.json", "heavy-result.json", "cold-response.npz", "heavy-response.npz"):
        inputs[str(PILOT / name)] = digest(PILOT / name)
    for name in ("protocol.json", "DERIVATION.md", "run_response.py"):
        inputs[str(ROOT / name)] = digest(ROOT / name)
    for name in ("closeout.json", "verification.json", "NEXT.md", "hilbert-result.json", "hilbert-readout.npz"):
        inputs[str(PREVIOUS / name)] = digest(PREVIOUS / name)
    if (ROOT / "inputs.json").exists():
        if read(ROOT / "inputs.json") != inputs:
            raise RuntimeError("Input map differs")
    else:
        write(ROOT / "inputs.json", inputs)
    check_inputs(inputs)
    return inputs


def ratio(error, scale, tolerance=GATE):
    error, scale = float(error), float(scale)
    return {"error": error, "scale": scale, "relative": error / scale if scale else None,
            "tolerance": tolerance, "passed": bool(np.isfinite(error) and error <= tolerance * scale)}


def maxabs(value):
    return float(np.max(abs(np.asarray(value))))


def neutrino(argument):
    if not 0 < argument <= 0.3 + 70 / 1399 * 1.01:
        raise ValueError("Unsupported retained neutrino branch")
    coefficient = 5 / (7 * np.pi ** 2)
    if argument < 0.01:
        return 1 + coefficient * argument ** 2, 2 * coefficient * argument ** 2
    higher = argument ** 4
    logarithm = math.log(argument)
    density = 1 + coefficient * argument ** 2 + higher * (0.01099926669 * logarithm - 0.003492416767 - 0.005866275571 * argument)
    derivative = 2 * coefficient * argument ** 2 + higher * (0.01099926669 * (4 * logarithm + 1) - 4 * 0.003492416767 - 5 * 0.005866275571 * argument)
    return density, derivative


class Model:
    def __init__(self, background, anchor):
        self.background = background
        self.constants = background.constants
        self.count = len(background.fields)
        self.initial = self.represented(anchor)
        amplitudes = []
        for field, velocity, mass in zip(self.initial["field"], self.initial["velocity"], self.initial["mass"]):
            frequency = max(self.initial["hubble"], math.sqrt(mass))
            amplitude = math.hypot(field, velocity / frequency)
            if amplitude <= 0:
                raise ValueError("Zero background phase normalization")
            amplitudes.extend([amplitude, frequency * amplitude])
        self.norm = np.array([self.initial["scale"]] + amplitudes)
        self.correction_norm = self.norm.copy()
        self.correction_norm[0] = 1
        self.correction_norm *= CONFIG["response_unit_factor"]

    def represented(self, clock):
        value = self.background.evaluate(np.array([clock]))
        jets = value["jets"]
        return {
            "scale": float(value["scale"][0]), "rate": float(value["rate"][0]), "hubble": float(value["hubble"][0]),
            "field": np.array([entry[0][0] for entry in jets]),
            "velocity": np.array([entry[1][0] for entry in jets]),
            "field_first": np.array([entry[2][0] for entry in jets]),
            "velocity_first": np.array([entry[3][0] for entry in jets]),
            "mass": np.array([entry[6][0] for entry in jets]),
        }

    def external(self, scale):
        constants = self.constants
        matter = (constants[0] + constants[1]) / scale
        radiation = (constants[2] + constants[3]) / scale ** 2
        density, derivative = [matter, radiation], [-matter, -2 * radiation]
        for index in range(int(constants[4])):
            rho, rho_first = neutrino(scale * constants[8 + index])
            factor = constants[14 + index] / scale ** 2
            density.append(factor * rho)
            derivative.append(factor * (rho_first - 2 * rho))
        return math.fsum(density), math.fsum(derivative)

    def external_difference(self, scale, alpha):
        factor = 1 + alpha
        if factor <= 0:
            raise ValueError("Nonpositive corrected scale")
        square_difference = alpha * (2 + alpha)
        values = [
            -(self.constants[0] + self.constants[1]) / scale * alpha / factor,
            -(self.constants[2] + self.constants[3]) / scale ** 2 * square_difference / factor ** 2,
        ]
        for index in range(int(self.constants[4])):
            argument = scale * self.constants[8 + index]
            changed = argument * factor
            neutrino(argument)
            neutrino(changed)
            if (argument < 0.01) != (changed < 0.01):
                raise ValueError("Correction crosses a retained neutrino branch")
            difference = -square_difference / factor ** 2
            if argument >= 0.01:
                cubic_difference = alpha * (3 + 3 * alpha + alpha ** 2)
                difference += argument ** 4 * (
                    square_difference * (0.01099926669 * math.log(argument) - 0.003492416767)
                    + factor ** 2 * 0.01099926669 * math.log1p(alpha)
                    - 0.005866275571 * argument * cubic_difference
                )
            values.append(self.constants[14 + index] / scale ** 2 * difference)
        return math.fsum(values)

    def unpack(self, vector):
        return vector[0], vector[1::2], vector[2::2]

    def pack(self, scale, field, velocity):
        result = np.empty(1 + 2 * self.count)
        result[0], result[1::2], result[2::2] = scale, field, velocity
        return result

    def absolute_hubble(self, state):
        scale, field, velocity = self.unpack(state)
        if scale <= 0:
            raise ValueError("Nonpositive scale")
        masses = (scale * self.constants[6:6 + self.count]) ** 2
        density = self.external(scale)[0] + math.fsum(((velocity ** 2 + masses * field ** 2) / 2).tolist())
        if density <= 0:
            raise ValueError("Nonpositive total density")
        return math.sqrt(density / 3), masses

    def absolute_rhs(self, clock, normalized):
        guard()
        state = normalized * self.norm
        scale, field, velocity = self.unpack(state)
        hubble, masses = self.absolute_hubble(state)
        return self.pack(scale * hubble, velocity, -2 * hubble * velocity - masses * field) / self.norm

    def correction_geometry(self, base, physical, linear):
        alpha, field_delta, velocity_delta = self.unpack(physical)
        field, velocity, masses = base["field"], base["velocity"], base["mass"]
        if linear:
            density_delta = math.fsum((
                self.external(base["scale"])[1] * alpha,
                *list(velocity * velocity_delta + masses * field * field_delta + masses * field ** 2 * alpha),
            ))
            hubble_delta = density_delta / (6 * base["hubble"])
        else:
            density_delta = math.fsum((
                self.external_difference(base["scale"], alpha),
                *list(velocity * velocity_delta + velocity_delta ** 2 / 2
                      + masses * (field * field_delta + field_delta ** 2 / 2)
                      + masses * alpha * (2 + alpha) * (field + field_delta) ** 2 / 2),
            ))
            new_square = base["hubble"] ** 2 + density_delta / 3
            if new_square <= 0:
                raise ValueError("Nonpositive corrected Friedmann density")
            hubble_delta = density_delta / (3 * (math.sqrt(new_square) + base["hubble"]))
        return hubble_delta, density_delta

    def difference_flow(self, base, physical, linear):
        alpha, field_delta, velocity_delta = self.unpack(physical)
        field, velocity, masses, hubble = base["field"], base["velocity"], base["mass"], base["hubble"]
        hubble_delta, _ = self.correction_geometry(base, physical, linear)
        if linear:
            scale_difference = base["scale"] * (hubble * alpha + hubble_delta)
            acceleration_difference = -2 * hubble * velocity_delta - masses * field_delta - 2 * velocity * hubble_delta - 2 * masses * field * alpha
        else:
            scale_difference = base["scale"] * (hubble * alpha + (1 + alpha) * hubble_delta)
            acceleration_difference = (-2 * hubble * velocity_delta - 2 * hubble_delta * (velocity + velocity_delta)
                                       - masses * field_delta - masses * alpha * (2 + alpha) * (field + field_delta))
        return self.pack(scale_difference, velocity_delta, acceleration_difference)

    def correction_rhs(self, clock, normalized):
        guard()
        base = self.represented(clock)
        width = len(self.norm)
        output = []
        field_defect = base["field_first"] - base["velocity"]
        velocity_defect = base["velocity_first"] + 2 * base["hubble"] * base["velocity"] + base["mass"] * base["field"]
        for vector, linear in ((normalized[:width], True), (normalized[width:], False)):
            physical = vector * self.correction_norm
            alpha = physical[0]
            difference = self.difference_flow(base, physical, linear)
            scale_rate = (difference[0] / base["scale"] - base["rate"] * alpha + base["hubble"] - base["rate"])
            result = self.pack(scale_rate, difference[1::2] - field_defect, difference[2::2] - velocity_defect)
            output.append(result / self.correction_norm)
        return np.concatenate(output)

    def reconstructed(self, clock, correction):
        base = self.represented(clock)
        alpha, field_delta, velocity_delta = self.unpack(correction)
        return self.pack(base["scale"] * (1 + alpha), base["field"] + field_delta, base["velocity"] + velocity_delta)


def jacobian_checks(model, clocks):
    checks = {}
    directions = list(np.eye(len(model.norm)))
    generator = np.random.default_rng(CONFIG["jacobian_seed"])
    direction = generator.normal(size=len(model.norm))
    directions.append(direction / np.linalg.norm(direction))
    for time_index, clock in enumerate(clocks):
        base = model.represented(clock)
        physical_state = model.pack(base["scale"], base["field"], base["velocity"])
        hubble, _ = model.absolute_hubble(physical_state)
        checks[f"background_{time_index}_friedmann"] = ratio(abs(hubble - base["hubble"]), abs(base["hubble"]), ALGEBRA)
        for direction_index, direction in enumerate(directions):
            physical_direction = direction * model.norm
            physical_direction[0] /= base["scale"]
            expected = model.difference_flow(base, physical_direction, True) / model.norm
            for step in CONFIG["jacobian_steps"]:
                difference = np.zeros_like(direction)
                for offset, weight in enumerate(FD_WEIGHTS, start=1):
                    plus = model.difference_flow(base, offset * step * physical_direction, False)
                    minus = model.difference_flow(base, -offset * step * physical_direction, False)
                    difference += weight * (plus - minus) / (step * model.norm)
                checks[f"jacobian_{time_index}_{direction_index}_{step}"] = ratio(maxabs(difference - expected), maxabs(expected), ALGEBRA)
    return checks


def solve_segments(function, initial, anchor, end, unique_times, boundaries, shared):
    divisions = np.unique(np.concatenate(([anchor], boundaries, [end])))
    state = initial.copy()
    output = np.empty((len(initial), len(unique_times)))
    output[:, 0] = state
    evaluations = 0
    for begin, finish in zip(divisions[:-1], divisions[1:]):
        guard()
        selected = np.flatnonzero((unique_times > begin) & (unique_times <= finish))
        samples = np.unique(np.concatenate((unique_times[selected], [finish])))
        solution = solve_ivp(function, (float(begin), float(finish)), state, t_eval=samples, **shared)
        if not solution.success:
            raise RuntimeError("Segment integration failed")
        if len(selected):
            output[:, selected] = solution.y[:, np.searchsorted(samples, unique_times[selected])]
        state = solution.y[:, -1]
        evaluations += solution.nfev
    return output, evaluations, len(divisions) - 1


def run_case(case):
    prepared, history, background, _, _ = EX.problem(case)
    anchor = float(prepared["times"][0])
    end = float(prepared["times"][-1] + prepared["elapsed"][-1])
    queries = prepared["times"][None, :] + prepared["elapsed"][:, None]
    unique_times, inverse = np.unique(queries.ravel(), return_inverse=True)
    model = Model(background, anchor)
    worst_time = float(prepared["times"][-1] + prepared["elapsed"][12])
    checks = jacobian_checks(model, [anchor, worst_time, end])
    if not all(value["passed"] for value in checks.values()):
        write(ROOT / (case + "-jacobian-failure.json"), checks)
        raise RuntimeError("Analytic background Jacobian check failed")
    initial = model.pack(model.initial["scale"], model.initial["field"], model.initial["velocity"])
    original_values = background.evaluate(unique_times)
    represented = np.empty((len(unique_times), len(model.norm)))
    represented[:, 0] = original_values["scale"]
    for index, jet in enumerate(original_values["jets"]):
        represented[:, 1 + 2 * index], represented[:, 2 + 2 * index] = jet[0], jet[1]
    outputs = {"queries": queries, "unique_times": unique_times, "query_index": inverse.reshape(queries.shape),
               "normalization": model.norm, "correction_normalization": model.correction_norm,
               "represented": represented, "hubble": original_values["hubble"], "rate": original_values["rate"]}
    boundaries = background.boundaries(anchor, end)
    outputs["integration_boundaries"] = boundaries
    integrations = {}
    for steps in CONFIG["steps"]:
        maximum_step = float(prepared["elapsed"][8]) / steps
        shared = dict(method="DOP853", rtol=CONFIG["rtol"], atol=CONFIG["normalized_atol"],
                      max_step=maximum_step)
        response, response_evaluations, segments = solve_segments(model.correction_rhs,
            np.zeros(2 * len(model.norm)), anchor, end, unique_times, boundaries, shared)
        correction = response.T.reshape(len(unique_times), 2, len(model.norm)) * model.correction_norm
        direct, direct_evaluations, direct_segments = solve_segments(model.absolute_rhs,
            initial / model.norm, anchor, end, unique_times, boundaries, shared)
        if direct_segments != segments:
            raise RuntimeError("Integration partitions differ")
        absolute = direct.T * model.norm
        reconstructed = represented.copy()
        reconstructed[:, 0] *= 1 + correction[:, 1, 0]
        reconstructed[:, 1:] += correction[:, 1, 1:]
        width = len(model.norm)
        for column in range(width):
            checks[f"{steps}_absolute_{column}"] = ratio(maxabs(absolute[:, column] - reconstructed[:, column]), model.norm[column], ALGEBRA)
        checks[f"{steps}_matched_anchor"] = ratio(maxabs(reconstructed[0] - initial), maxabs(initial), ALGEBRA)
        checks[f"{steps}_zero_correction_anchor"] = ratio(maxabs(correction[0]), 1, ALGEBRA)
        corrected_hubble = np.array([model.absolute_hubble(state)[0] for state in reconstructed])
        outputs[f"correction_{steps}"] = correction
        outputs[f"absolute_{steps}"] = absolute
        outputs[f"reconstructed_{steps}"] = reconstructed
        outputs[f"corrected_hubble_{steps}"] = corrected_hubble
        integrations[str(steps)] = {"response_evaluations": response_evaluations, "direct_evaluations": direct_evaluations, "segments": segments,
                                     "maximum_physical_step": maximum_step}
        print(json.dumps({"case": case, "steps": steps, **integrations[str(steps)]}), flush=True)
    fine, coarse = outputs["correction_64"], outputs["correction_32"]
    for column in range(len(model.norm)):
        for mode, label in enumerate(("linear", "nonlinear")):
            checks[f"refinement_{label}_{column}"] = ratio(maxabs(fine[:, mode, column] - coarse[:, mode, column]), maxabs(fine[:, mode, column]), GATE)
        checks[f"linear_vs_nonlinear_{column}"] = ratio(maxabs(fine[:, 0, column] - fine[:, 1, column]), maxabs(fine[:, 1, column]), GATE)
    held = held_state_readout(case, prepared, background, outputs, model)
    outputs.update(held.pop("arrays"))
    report = {
        "case": case, "background_checks_passed": all(value["passed"] for value in checks.values()),
        "checks": checks, "integrations": integrations, "anchor": anchor, "end": end,
        "queries": int(queries.size), "unique_times": len(unique_times),
        "maximum_relative_scale_correction": maxabs(fine[:, 1, 0]),
        "maximum_normalized_field_corrections": np.max(abs(fine[:, 1, 1:] / model.norm[None, 1:]), axis=0).tolist(),
        "held_state_readout": held, "quantum_measure_included": False,
        "surrounding_response_assumed_zero": False, "corrected_prediction_promoted": False,
        "scope": "Coherent local background repair; perturbations, environment and preparation have not yet been re-evolved.",
    }
    return report, outputs


def held_state_readout(case, prepared, background, outputs, model):
    saved = EX.load(HISTORY / (case + "-extended-64.npz"))
    comparison = EX.load(HISTORY / (case + "-comparison.npz"))
    indices = outputs["query_index"]
    corrected = outputs["reconstructed_64"][indices]
    original = outputs["represented"][indices]
    corrected_hubble = outputs["corrected_hubble_64"][indices]
    original_hubble = outputs["hubble"][indices]
    state = saved["state"]
    wave = prepared["wave"][None, :]
    if case == "heavy":
        old_scale, new_scale = original[:, :, 0], corrected[:, :, 0]
        old_field, old_velocity = original[:, :, 3], original[:, :, 4]
        new_field, new_velocity = corrected[:, :, 3], corrected[:, :, 4]
        mass = (old_scale * model.constants[7]) ** 2
        new_mass = (new_scale * model.constants[7]) ** 2
        displacement, speed = state[:, :, 0], state[:, :, 1]
        old_density = old_velocity * speed + mass * old_field * displacement
        new_density = new_velocity * speed + new_mass * new_field * displacement
        new_current = wave * new_velocity * displacement
        new_source = (new_scale / float(prepared["density0"]))[:, :, None] * np.stack(
            (new_density, new_current, new_velocity * speed - new_mass * new_field * displacement), axis=-1)
        delta = new_source - saved["node_source"]
        delta_density = new_density - old_density
        delta_current = wave * (new_velocity - old_velocity) * displacement
    else:
        new_source = saved["node_source"].copy()
        delta = np.zeros_like(new_source)
        old_density = model.constants[0] / original[:, :, 0] * state[:, :, 0]
        new_density = model.constants[0] / corrected[:, :, 0] * state[:, :, 0]
        delta_density = new_density - old_density
        delta_current = np.zeros_like(delta_density)
    increments = np.array([EX.weighted(prepared["weights"], row - delta[0]) for row in delta])
    hubble_delta = corrected_hubble - original_hubble
    force_change = (delta_density / (2 * wave) - saved["metric_force"] * hubble_delta) / corrected_hubble
    current_change = delta_current / 2
    channels = {}
    for column, label in enumerate(("density", "current", "pressure")):
        channels[label] = ratio(maxabs(increments[:, column]), float(comparison["reference_scale"][column]), GATE)
    return {
        "classification": "Background-only frozen-perturbation sensitivity, not a corrected prediction.",
        "channels": channels, "final_increment": increments[-1].tolist(),
        "maximum_partial_constraint_change": maxabs(force_change),
        "maximum_partial_eta_rate_change": maxabs(current_change),
        "environment_and_state_response_required": True,
        "arrays": {"held_source_increment": increments, "held_partial_force_change": force_change,
                   "held_partial_eta_rate_change": current_change},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=CONFIG["cases"])
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    label = args.case + ("-replay" if args.replay else "-run")
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(),
                "utc": utc(), "affinity": process.cpu_affinity(), "priority": "below-normal"}
    write(ROOT / (label + "-start.json"), identity)
    try:
        inputs = freeze_inputs()
        report, arrays = run_case(args.case)
        check_inputs(inputs)
        if args.replay:
            if report != read(ROOT / (args.case + "-result.json")):
                raise RuntimeError("Result replay differs")
            with np.load(ROOT / (args.case + "-response.npz"), allow_pickle=False) as saved:
                if set(saved.files) != set(arrays) or not all(np.array_equal(saved[key], value) for key, value in arrays.items()):
                    raise RuntimeError("Array replay differs")
            write(ROOT / (args.case + "-replay.json"), {"passed": report["background_checks_passed"], "report_exact": True, "arrays_exact": True})
        else:
            write(ROOT / (args.case + "-result.json"), report)
            if (ROOT / (args.case + "-response.npz")).exists():
                raise FileExistsError("Output exists")
            np.savez_compressed(ROOT / (args.case + "-response.npz"), **arrays)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        write(ROOT / (label + "-end.json"), {**identity, "completed": True, "background_checks_passed": report["background_checks_passed"], "elapsed_seconds": time.monotonic() - START})
        print(json.dumps({"case": args.case, "passed": report["background_checks_passed"], "failed": [key for key, value in report["checks"].items() if not value["passed"]], "held_state": report["held_state_readout"]}), flush=True)
        return 0 if report["background_checks_passed"] else 1
    except BaseException as failure:
        write(ROOT / (label + "-failure.json"), {**identity, "completed": False, "error": repr(failure), "utc_end": utc()})
        raise


if __name__ == "__main__":
    raise SystemExit(main())

