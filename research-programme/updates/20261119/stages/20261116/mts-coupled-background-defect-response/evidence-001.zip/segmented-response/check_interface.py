import os
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
import json
from pathlib import Path
import time

import mpmath as mp
import numpy as np
import psutil

import run_response as RESPONSE

ROOT = Path(__file__).resolve().parent
mp.mp.dps = 80


def load_arrays(path):
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}


def stable_readout(case, saved, prepared, arrays, model, steps, mode):
    indices = arrays["query_index"]
    original = arrays["represented"][indices]
    correction = arrays[f"correction_{steps}"][indices, mode, :]
    alpha = correction[:, :, 0]
    state = saved["state"]
    wave = prepared["wave"][None, :]
    if case == "cold":
        source = np.zeros_like(saved["node_source"])
        bare_density = -model.constants[0] / original[:, :, 0] * state[:, :, 0] * alpha / (1 + alpha)
        return source, bare_density, np.zeros_like(bare_density)
    scale, field, velocity = original[:, :, 0], original[:, :, 3], original[:, :, 4]
    field_delta, velocity_delta = correction[:, :, 3], correction[:, :, 4]
    displacement, speed = state[:, :, 0], state[:, :, 1]
    mass = (scale * model.constants[7]) ** 2
    mass_delta = mass * alpha * (2 + alpha)
    kinetic = velocity * speed
    potential = mass * field * displacement
    kinetic_delta = velocity_delta * speed
    potential_delta = (mass_delta * field + mass * field_delta + mass_delta * field_delta) * displacement
    old = np.stack((kinetic + potential, wave * velocity * displacement, kinetic - potential), axis=-1)
    bare = np.stack((kinetic_delta + potential_delta, wave * velocity_delta * displacement,
                     kinetic_delta - potential_delta), axis=-1)
    source = (scale / float(prepared["density0"]))[:, :, None] * (bare + alpha[:, :, None] * (old + bare))
    return source, bare[:, :, 0], bare[:, :, 1]


def weighted_increment(values, weights):
    return np.array([RESPONSE.EX.weighted(weights, row - values[0]) for row in values])


def reference_readout(case, original, correction, state, wave, density0, constants):
    alpha = mp.mpf(float(correction[0]))
    scale = mp.mpf(float(original[0]))
    displacement = mp.mpf(float(state[0]))
    if case == "cold":
        change = -mp.mpf(float(constants[0])) / scale * displacement * alpha / (1 + alpha)
        return np.zeros(3), float(change), 0.0
    field, velocity = mp.mpf(float(original[3])), mp.mpf(float(original[4]))
    field_delta, velocity_delta = mp.mpf(float(correction[3])), mp.mpf(float(correction[4]))
    speed, wave = mp.mpf(float(state[1])), mp.mpf(float(wave))
    mass_parameter, density0 = mp.mpf(float(constants[7])), mp.mpf(float(density0))
    def evaluate(current_scale, current_field, current_velocity):
        mass = (current_scale * mass_parameter) ** 2
        density = current_velocity * speed + mass * current_field * displacement
        current = wave * current_velocity * displacement
        pressure = current_velocity * speed - mass * current_field * displacement
        return [current_scale / density0 * value for value in (density, current, pressure)], density, current
    old, old_density, old_current = evaluate(scale, field, velocity)
    new, new_density, new_current = evaluate(scale * (1 + alpha), field + field_delta, velocity + velocity_delta)
    return np.array([float(new_value - old_value) for new_value, old_value in zip(new, old)]), float(new_density - old_density), float(new_current - old_current)


def analyse_case(case):
    prepared, _, background, _, _ = RESPONSE.EX.problem(case)
    arrays = load_arrays(ROOT / (case + "-response.npz"))
    saved = RESPONSE.EX.load(RESPONSE.HISTORY / (case + "-extended-64.npz"))
    comparison = RESPONSE.EX.load(RESPONSE.HISTORY / (case + "-comparison.npz"))
    result = RESPONSE.read(ROOT / (case + "-result.json"))
    model = RESPONSE.Model(background, float(prepared["times"][0]))
    checks, outputs, diagnostics = {}, {}, {}
    indices = arrays["query_index"]
    original = arrays["represented"][indices]
    fine = arrays["correction_64"][indices, 1, :]
    weights = prepared["weights"]
    stable, bare_density, bare_current = stable_readout(case, saved, prepared, arrays, model, 64, 1)
    coarse, _, _ = stable_readout(case, saved, prepared, arrays, model, 32, 1)
    linear, _, _ = stable_readout(case, saved, prepared, arrays, model, 64, 0)
    increments = weighted_increment(stable, weights)
    coarse_increments = weighted_increment(coarse, weights)
    linear_increments = weighted_increment(linear, weights)
    old_source = np.array([RESPONSE.EX.metric.readout(case, float(offset), saved["state"][index], prepared, background)
                           for index, offset in enumerate(prepared["elapsed"])])
    for column, label in enumerate(("density", "current", "pressure")):
        scale = float(comparison["reference_scale"][column])
        checks[label + "_original_readout"] = RESPONSE.ratio(RESPONSE.maxabs(old_source[:, :, column] - saved["node_source"][:, :, column]), scale, RESPONSE.ALGEBRA)
        checks[label + "_stable_vs_original_subtraction"] = RESPONSE.ratio(RESPONSE.maxabs(increments[:, column] - arrays["held_source_increment"][:, column]), scale, RESPONSE.ALGEBRA)
        checks[label + "_source_step_error"] = RESPONSE.ratio(RESPONSE.maxabs(increments[:, column] - coarse_increments[:, column]), scale)
        checks[label + "_source_linearization_error"] = RESPONSE.ratio(RESPONSE.maxabs(increments[:, column] - linear_increments[:, column]), scale)
        diagnostics[label + "_fixed_state_increment"] = RESPONSE.ratio(RESPONSE.maxabs(increments[:, column]), scale)
        diagnostics[label + "_correction_relative_step_error"] = RESPONSE.ratio(
            RESPONSE.maxabs(increments[:, column] - coarse_increments[:, column]), RESPONSE.maxabs(increments[:, column]))
    selected = [(0, 0), (12, 901), (32, 901), (16, 451)]
    for column in range(3):
        selected.append(tuple(int(item) for item in np.unravel_index(np.argmax(abs(stable[:, :, column])), stable.shape[:2])))
    for sample, (epoch, node) in enumerate(dict.fromkeys(selected)):
        RESPONSE.guard()
        reference, reference_density, reference_current = reference_readout(
            case, original[epoch, node], fine[epoch, node], saved["state"][epoch, node],
            prepared["wave"][node], prepared["density0"], model.constants)
        for column, label in enumerate(("density", "current", "pressure")):
            checks[f"high_precision_{sample}_{label}"] = RESPONSE.ratio(
                abs(float(stable[epoch, node, column]) - reference[column]),
                RESPONSE.maxabs(stable[:, :, column]), RESPONSE.ALGEBRA)
        checks[f"high_precision_{sample}_bare_density"] = RESPONSE.ratio(
            abs(float(bare_density[epoch, node]) - reference_density), RESPONSE.maxabs(bare_density), RESPONSE.ALGEBRA)
        checks[f"high_precision_{sample}_bare_current"] = RESPONSE.ratio(
            abs(float(bare_current[epoch, node]) - reference_current), RESPONSE.maxabs(bare_current), RESPONSE.ALGEBRA)
    for column in range(len(model.norm)):
        checks[f"absolute_state_refinement_{column}"] = RESPONSE.ratio(
            RESPONSE.maxabs(arrays["absolute_64"][:, column] - arrays["absolute_32"][:, column]),
            model.norm[column], RESPONSE.ALGEBRA)
        checks[f"background_correction_step_on_state_scale_{column}"] = RESPONSE.ratio(
            RESPONSE.maxabs(arrays["correction_64"][:, 1, column] - arrays["correction_32"][:, 1, column]),
            (1.0 if column == 0 else model.norm[column]), RESPONSE.ALGEBRA)
    outputs.update(stable_increment=increments, coarse_increment=coarse_increments, linear_increment=linear_increments,
                   stable_node_change=stable, bare_density_change=bare_density, bare_current_change=bare_current)
    failed_original = {name: value for name, value in result["checks"].items() if not value["passed"]}
    report = {
        "case": case, "interface_checks_passed": all(value["passed"] for value in checks.values()), "checks": checks,
        "original_background_checks_passed": result["background_checks_passed"], "original_failed_checks": failed_original,
        "diagnostics": diagnostics, "final_fixed_state_increment": increments[-1].tolist(),
        "sampled_high_precision_locations": [list(pair) for pair in dict.fromkeys(selected)],
        "maximum_partial_bare_density_change": RESPONSE.maxabs(bare_density),
        "maximum_partial_bare_current_change": RESPONSE.maxabs(bare_current),
        "classification": "Same background response, stable readout arithmetic; perturbations and environment not re-evolved.",
        "source_replacement_authorized": False, "quantum_measure_included": False,
    }
    return report, outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    arguments = parser.parse_args()
    label = "interface-replay" if arguments.replay else "interface-run"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(),
                "utc": RESPONSE.utc(), "affinity": process.cpu_affinity(), "priority": "below-normal"}
    RESPONSE.write(ROOT / (label + "-start.json"), identity)
    try:
        inputs = RESPONSE.read(ROOT / "inputs.json").copy()
        for name in ("check_interface.py", "SOURCE-INTERFACE.md", "cold-result.json", "cold-response.npz",
                     "heavy-result.json", "heavy-response.npz"):
            inputs[str(ROOT / name)] = RESPONSE.digest(ROOT / name)
        target = ROOT / "interface-inputs.json"
        if target.exists():
            if RESPONSE.read(target) != inputs:
                raise RuntimeError("Interface inputs differ")
        else:
            RESPONSE.write(target, inputs)
        RESPONSE.check_inputs(inputs)
        reports, outputs = {}, {}
        for case in RESPONSE.CONFIG["cases"]:
            reports[case], arrays = analyse_case(case)
            outputs.update({case + "_" + name: value for name, value in arrays.items()})
        report = {"interface_checks_passed": all(value["interface_checks_passed"] for value in reports.values()),
                  "all_original_background_checks_passed": all(value["original_background_checks_passed"] for value in reports.values()),
                  "cases": reports, "frozen_input_count": len(inputs), "quantum_measure_included": False,
                  "corrected_prediction_promoted": False}
        RESPONSE.check_inputs(inputs)
        if arguments.replay:
            if report != RESPONSE.read(ROOT / "interface-result.json"):
                raise RuntimeError("Interface report replay differs")
            previous = load_arrays(ROOT / "interface-arrays.npz")
            if previous.keys() != outputs.keys() or not all(np.array_equal(previous[name], value) for name, value in outputs.items()):
                raise RuntimeError("Interface array replay differs")
            RESPONSE.write(ROOT / "interface-replay.json", {"report_exact": True, "arrays_exact": True,
                "interface_checks_passed": report["interface_checks_passed"]})
        else:
            RESPONSE.write(ROOT / "interface-result.json", report)
            target = ROOT / "interface-arrays.npz"
            if target.exists():
                raise FileExistsError(target)
            np.savez_compressed(target, **outputs)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        RESPONSE.write(ROOT / (label + "-end.json"), {**identity, "completed": True,
            "elapsed_seconds": time.monotonic() - RESPONSE.START, "interface_checks_passed": report["interface_checks_passed"]})
        print(json.dumps({"interface_checks_passed": report["interface_checks_passed"],
                         "failed": {case: [name for name, value in item["checks"].items() if not value["passed"]]
                                    for case, item in reports.items()},
                         "original_background_checks_passed": report["all_original_background_checks_passed"]}), flush=True)
        return 0 if report["interface_checks_passed"] else 1
    except BaseException as error:
        RESPONSE.write(ROOT / (label + "-failure.json"), {**identity, "error": repr(error), "utc_end": RESPONSE.utc()})
        raise


if __name__ == "__main__":
    raise SystemExit(main())

