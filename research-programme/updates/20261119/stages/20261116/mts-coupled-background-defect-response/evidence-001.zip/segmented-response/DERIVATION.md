# Segmented defect-response repair, frozen before testing

The root run is preserved, including its failed cold correction-relative and
heavy absolute/correction-relative checks. The heavy field/velocity disagreement
falls from about1.8e-9 to1.93e-10 under step halving, but both exceed1e-10.
This is not accepted merely because its fixed-state source remains small.

The retained background is piecewise polynomial in the saved clock/efold
coordinates. Its defect forcing changes derivative formula at those exact
saved knots. Split integration there; no old bank entry, spline coefficient,
reported epoch, wave number, node, weight, or physical parameter changes.

Both cases use the same correction-coordinate conversion:
integration coordinate = physical correction/(original phase unit times1e-7).
The original solver rtol1e-10 and normalized atol1e-12 remain fixed. This
tightens the physical absolute error request by1e7; it is numerical
conditioning, not a fitted coefficient or weakened acceptance criterion.
The original absolute-state normalization is unchanged. Both integrations
use the same original32/64 maximum physical steps and the same partitions.

The factor is frozen now, before these repaired results. It resolves the
pilot's small heavy response and scale correction without demanding changes
to the actual background state. A correction at binary64 evaluation noise,
particularly the cold baseline, may still fail a correction-relative gate:
keep that failure rather than creating a tolerance floor.

The partitioned absolute evolution is independent of defect subtraction and
provides the control. Compare with original results as well. Do not promote
a physical source change until perturbations, environment and preparation
responses have all been carried consistently. Quantum measure remains separate.

