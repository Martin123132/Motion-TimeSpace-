# Source validation of the partitioned background response

Use the exact stable source-difference equations in the parent stage's
SOURCE-INTERFACE.md, on the original33x902 query grid and saved perturbations.
The code independently reconstructs the old readout, checks80-digit direct
differences at fixed locations and maximum-change nodes, and carries the
32/64 background step difference through the signed source integral.

Numerical integration coordinates are not physical state units. The
background-error check therefore retains1 for relative scale and the
original phase amplitudes for field/velocity, NOT the tightened solver
coordinate units. This keeps the physical1e-10 gate identical to the first
attempt. The original correction-relative2e-5 checks are kept unchanged
and separate. A source-scale pass never erases a failed correction check.

All original inputs, first-attempt failures and partitioned results remain
unchanged. This adds no environment response, initial preparation change,
new coupling, fit or quantum-measure calculation.
