from run_coupled import *

parser = argparse.ArgumentParser()
parser.add_argument("case", choices=CONFIG["cases"])
parser.add_argument("steps", type=int, choices=CONFIG["steps"])
arguments = parser.parse_args()
case, steps = arguments.case, arguments.steps
label = case + "-step" + str(steps)
with worker(label):
    require(not (ROOT / (case + "-coupled-" + str(steps) + ".npz")).exists(), "do not redo saved integration")
    inputs = read(ROOT / "inputs.json").copy()
    for name in ("support.py", "native_context.py", "run_coupled.py", "run_sized.py", "protocol.json", "DERIVATION.md",
                 "native/camb/cambdll.dll", "native-build-full-result.json", case + "-preflight-result.json"):
        inputs[str(ROOT / name)] = digest(ROOT / name)
    check_inputs(inputs)
    write(ROOT / (label + "-inputs.json"), inputs)
    require(read(ROOT / (case + "-preflight-result.json"))["passed"], "preflight passed")
    prepared, _, background, _, _ = EX.problem(case)
    with native_context(case, label) as (captured, metadata, sample):
        reference = load(ROOT / (case + "-preflight-capture.npz"))
        require(all(np.array_equal(value, reference[name]) for name, value in captured.items()), "identical saved full preparation")
        system = Coupled(case, prepared, background, captured, metadata, sample)
        checks = {}
        random = np.random.default_rng(20261116)
        for location in (0, len(captured["clock"]) // 2, len(captured["clock"]) - 1):
            tau = float(captured["clock"][location])
            base = system.model.represented(tau)
            background_packet = np.zeros(5)
            background_packet[:system.width] = system.model.pack(base["scale"], base["field"], base["velocity"])
            trial = np.zeros(system.allocated)
            trial[:system.active] = random.normal(size=system.active) * system.state_units * .001
            if case == "heavy":
                trial[system.first + 4] = 0
            state = captured["reference"][location]
            first = sample(tau, state, background_packet, True)[0]
            trial_rhs = sample(tau, trial, background_packet, True)[0]
            combined = sample(tau, state + trial, background_packet, True)[0]
            checks[str(location)] = ratio(maximum((combined-first-trial_rhs)[:system.active]/system.state_units), 1, CONFIG["algebra_tolerance"])
        require(all(value["passed"] for value in checks.values()), "native linear response contract")
        write(ROOT / (label + "-linearity.json"), {"passed": True, "checks": checks})
        values, integration = system.solve(steps)
        np.savez_compressed(ROOT / (case + "-coupled-" + str(steps) + ".npz"), **values)
        write(ROOT / (label + "-result.json"), {"completed": True, "integration": integration,
              "output": case + "-coupled-" + str(steps) + ".npz"})
        check_inputs(inputs)
        print(json.dumps({"case": case, "steps": steps, **integration}), flush=True)

