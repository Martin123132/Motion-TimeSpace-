import os
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "1"
import json
import hashlib
from pathlib import Path
import sys
import time
from datetime import datetime, timezone
from contextlib import contextmanager
import psutil
import numpy as np

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "protocol.json").read_text())
POST = Path(CONFIG["post_directory"])
PREVIOUS = POST / CONFIG["previous"]
NATIVE = POST / CONFIG["native_owner"] / "native"
HISTORY = POST / CONFIG["history"]
START = time.monotonic()

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")

def load(path):
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}

def require(condition, description):
    if not condition:
        raise RuntimeError(description)

def guard():
    require(time.monotonic() - START < CONFIG["maximum_worker_seconds"], "worker time bound")
    require(datetime.now(timezone.utc) < datetime.fromisoformat(CONFIG["turn_stop_utc"]), "four-hour stopping point")
    for directory in (ROOT, POST, PREVIOUS, HISTORY, POST / "condensate-origin-20261003"):
        require(not (directory / "STOP-REQUESTED").exists(), "owner hold: " + str(directory))

def check_inputs(mapping):
    for path, expected in mapping.items():
        guard()
        require(Path(path).is_file() and digest(path) == expected, "unchanged input: " + path)

def identity(process):
    return {"pid": process.pid, "created": process.create_time(), "command": process.cmdline()}

def exited(saved):
    try:
        process = psutil.Process(saved["pid"])
        same = abs(process.create_time() - saved["created"]) < .01 and process.cmdline() == saved["command"]
    except psutil.NoSuchProcess:
        return {"exited": True, "reason": "PID absent"}
    return {"exited": not same, "reason": "original active" if same else "PID reused, untouched"}

@contextmanager
def worker(label):
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    saved = identity(process)
    saved.update(utc=datetime.now(timezone.utc).isoformat(), affinity=process.cpu_affinity(), priority="below-normal")
    write(ROOT / (label + "-start.json"), saved)
    try:
        guard()
        yield
    except BaseException as error:
        write(ROOT / (label + "-failure.json"), {**saved, "error": repr(error), "elapsed": time.monotonic() - START})
        raise
    else:
        write(ROOT / (label + "-end.json"), {**saved, "completed": True, "elapsed": time.monotonic() - START})

def ratio(error, scale, tolerance=None):
    tolerance = CONFIG["numerical_tolerance"] if tolerance is None else tolerance
    error, scale = float(error), float(scale)
    return {"error": error, "scale": scale, "relative": error / scale if scale else None,
            "tolerance": tolerance, "passed": bool(np.isfinite(error) and error <= tolerance * scale)}

