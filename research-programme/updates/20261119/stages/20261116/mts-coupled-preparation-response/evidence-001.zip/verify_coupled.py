from support import *
import ast
from native_context import EX

with worker("verify-coupled-v2"):
    report = read(ROOT / "result.json")
    replay = read(ROOT / "score-replay.json")
    checks = {
        "score_reproduced_exactly": replay["exact"],
        "reproduction_checks_passed": report["reproduction_passed"],
        "previous_seal_unchanged": digest(PREVIOUS / "closeout.json") == CONFIG["previous_seal"],
        "algebra_tolerance_unchanged": CONFIG["algebra_tolerance"] == 1e-10,
        "numerical_tolerance_unchanged": CONFIG["numerical_tolerance"] == 2e-5,
        "step_choices_unchanged": CONFIG["steps"] == [32, 64],
        "clock_range_unchanged": CONFIG["first_index"] == 1991 and CONFIG["last_index"] == 2924,
        "quantum_measure_separate": not report["quantum_measure_included"],
        "no_new_fit": not report["new_data_fit"],
    }
    frozen = {}
    declarations = {}
    input_receipts = [ROOT / "inputs.json", ROOT / "native-build-frozen.json", ROOT / "native-build-full-frozen.json"]
    input_receipts.extend(sorted(ROOT.glob("*-inputs.json")))
    for receipt in input_receipts:
        mapping = read(receipt)
        check_inputs(mapping)
        for path, expected in mapping.items():
            require(path not in frozen or frozen[path] == expected, "consistent declared hash: " + path)
            frozen[path] = expected
            declarations.setdefault(path, []).append(receipt.name)
    checks["all_frozen_declarations_unchanged"] = True
    additional = [
        POST / "mts-metric-feedback-20261107/observer.dll",
        EX.BRANCH / "radiation-and-slow-field-transfer-20261007/radiation_common.py",
        EX.MATCHING / "matching_common.py",
        EX.EARLY / "runs/backgrounds/cold.npz",
        EX.EARLY / "runs/backgrounds/heavy.npz",
        EX.EARLY / "runs/final-bg8-start/cold.npz",
        EX.SPECTRUM / "runs/exact-grid/chunk-0384.npz",
    ]
    provenance = []
    for path in additional:
        require(path.is_file(), "explicit native dependency: " + str(path))
        expected = digest(path)
        inherited = [name for name, value in frozen.items()
                     if Path(name).resolve() == path.resolve() and value == expected]
        provenance.append({
            "path": str(path), "sha256": expected,
            "in_existing_input_receipts": bool(inherited),
            "status": "existing hash verified" if inherited else "supplementary closeout hash; not claimed frozen before run",
        })
    checks["explicit_dependencies_exist"] = True
    for case in CONFIG["cases"]:
        preflight = read(ROOT / (case + "-preflight-result.json"))
        checks[case + "_preflight_passed"] = preflight["passed"]
        for steps in CONFIG["steps"]:
            archive = ROOT / (case + "-coupled-" + str(steps) + ".npz")
            values = load(archive)
            checks[case + "_" + str(steps) + "_all_finite"] = all(np.all(np.isfinite(value)) for value in values.values())
            checks[case + "_" + str(steps) + "_shape"] = values["source"].shape == (33, 902, 3)
            checks[case + "_" + str(steps) + "_common_anchor"] = bool(
                np.all(values["own_state_change"][0, 0] == 0) and
                np.all(values["background_change"][0, 0] == 0))
            if case == "cold" and steps == 32:
                handover = read(ROOT / "coarse-handover.json")
                checks["cold32_intentional_checkpoint"] = handover["completed"] and handover["task_hold_removed"]
                checks["cold32_checkpoint_hash"] = digest(archive) == handover["coarse_sha256"]
                label = "cold-coupled"
            else:
                label = case + "-step" + str(steps)
                checks[label + "_completed"] = read(ROOT / (label + "-result.json"))["completed"]
                checks[label + "_end"] = read(ROOT / (label + "-end.json"))["completed"]
            release = read(ROOT / (label + "-owner-release.json"))
            checks[label + "_released"] = release["cleared"] and release["native_reference_released"]
            capture = read(ROOT / (label + "-capture.json"))
            checks[label + "_934_exact"] = capture["count"] == 934 and capture["original934_packets_exact"]
    for path in ROOT.glob("*.py"):
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    checks["local_python_syntax"] = True
    checks["no_bytecode"] = not list(ROOT.rglob("__pycache__"))
    checks["native_mapping_removed"] = read(ROOT / "native-build-full-result.json")["mapping_removed"]
    scientific = {
        case: {
            "passed": sum(item["passed"] for item in result["checks"].values()),
            "total": len(result["checks"]),
            "failed": {name: item for name, item in result["checks"].items() if not item["passed"]},
        }
        for case, result in report["cases"].items()
    }
    output = {
        "verified": all(checks.values()), "checks": checks,
        "frozen_paths": len(frozen), "input_receipts": [path.name for path in input_receipts],
        "supplementary_provenance": provenance, "scientific": scientific,
        "inherited_baseline_background_relative_failures": 4,
        "refinement_allowance_is_rigorous_bound": False,
    }
    write(ROOT / "verification-v2.json", output)
    require(output["verified"], "coupled validation")
    print(json.dumps({"verified": output["verified"], "checks": len(checks), "scientific": scientific}))

