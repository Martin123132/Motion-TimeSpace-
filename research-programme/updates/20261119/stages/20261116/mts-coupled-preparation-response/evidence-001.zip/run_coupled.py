from native_context import *
import argparse
from scipy.integrate import solve_ivp

def weighted(weights, values):
    return np.array([EX.weighted(weights, row - values[0]) for row in values])

def maximum(value):
    return float(np.max(abs(value)))

class Coupled:
    def __init__(self, case, prepared, background, captured, metadata, sample):
        self.case, self.prepared, self.background = case, prepared, background
        self.captured, self.metadata, self.sample = captured, metadata, sample
        self.active, self.allocated = metadata["active"], metadata["allocated"]
        self.model = BG.Model(background, float(prepared["times"][0]))
        self.width = len(self.model.norm)
        self.state_units = np.max(abs(captured["reference"][:, :self.active]), axis=0)
        self.state_units[self.state_units == 0] = 1
        self.background_units = self.model.correction_norm * 1e-7
        self.delta_units = self.state_units * 1e-5
        comparison = load(HISTORY / (case + "-comparison.npz"))
        self.reference_scale = comparison["reference_scale"]
        self.work_units = np.array([max(float(self.reference_scale[0]), 1e-30)] * 6 +
                                   [max(float(self.reference_scale[1]), 1e-30)] * 3)
        if case == "cold":
            self.work_units[6:] = 1
        self.delta_work_units = self.work_units * 1e-5
        self.initial = np.concatenate((captured["reference"][0, :self.active] / self.state_units,
                                       np.zeros(self.active + self.width + 18)))
        self.first = int(captured["signature"][0, 2]) - 1
        self.calls = 0

    def unpack(self, normalized):
        active, width = self.active, self.width
        old = self.captured["reference"][0].copy()
        old[:active] = normalized[:active] * self.state_units
        change = np.zeros(self.allocated)
        change[:active] = normalized[active:2*active] * self.delta_units
        background_change = normalized[2*active:2*active+width] * self.background_units
        cursor = 2*active + width
        work = normalized[cursor:cursor+9] * self.work_units
        work_change = normalized[cursor+9:cursor+18] * self.delta_work_units
        return old, change, background_change, work, work_change

    def evaluate(self, tau, normalized):
        old, change, physical, work, work_change = self.unpack(normalized)
        base = self.model.represented(tau)
        alpha, field_delta, velocity_delta = self.model.unpack(physical)
        full_background = np.zeros(5)
        full_background[:self.width] = self.model.pack(
            base["scale"] * (1 + alpha), base["field"] + field_delta, base["velocity"] + velocity_delta)
        old_rhs, old_observed, extra = self.sample(tau, old, full_background, False)
        new_at_old_rhs, new_at_old_observed, _ = self.sample(tau, old, full_background, True)
        propagated_rhs, propagated_observed, _ = self.sample(tau, change, full_background, True)
        delta_rhs = (new_at_old_rhs - old_rhs) + propagated_rhs
        new_observed = new_at_old_observed.copy()
        for index in (2, 3, 4, 5, 6, 7, 8, 9, 10, 11, *range(18, 27), *range(30, 40)):
            new_observed[index] += propagated_observed[index]
        total_delta = (new_at_old_observed[2:4] - old_observed[2:4]) + propagated_observed[2:4]
        hubble_delta, _ = self.model.correction_geometry(base, physical, False)
        hubble, scale = base["hubble"], base["scale"]
        changed_hubble = hubble + hubble_delta
        wave = float(self.prepared["wave"][0])
        old_eta, delta_eta = old[0], change[0]
        if self.case == "heavy":
            original = self.first + 2
            field, velocity, mass = base["field"][1], base["velocity"][1], base["mass"][1]
            field_change, velocity_change = field_delta[1], velocity_delta[1]
            displacement, speed = old[original:original+2]
            displacement_change, speed_change = change[original:original+2]
            mass_change = mass * alpha * (2 + alpha)
            kinetic, potential = velocity * speed, mass * field * displacement
            kinetic_change = velocity_change * speed + velocity * speed_change + velocity_change * speed_change
            potential_change = mass * (field * displacement_change + field_change * displacement + field_change * displacement_change)
            potential_change += mass_change * (field + field_change) * (displacement + displacement_change)
            bare = np.array([kinetic + potential, wave * velocity * displacement, kinetic - potential])
            bare_change = np.array([kinetic_change + potential_change,
                wave * (velocity * displacement_change + velocity_change * displacement + velocity_change * displacement_change),
                kinetic_change - potential_change])
            beta = scale / float(self.prepared["density0"])
            source = beta * bare
            source_change = beta * (bare_change + alpha * (bare + bare_change))
            field_defect = base["field_first"][1] - velocity
            velocity_defect = base["velocity_first"][1] + 2 * hubble * velocity + mass * field
            contact_density = (base["rate"] - hubble) * (2 * source[0] - source[2]) + beta * (velocity_defect * speed + mass * field_defect * displacement)
            contact_current = (base["rate"] - hubble) * source[1] + beta * wave * velocity_defect * displacement
            coefficient = beta * velocity ** 2 / (2 * hubble)
            velocity_square_change = velocity_change * (2 * velocity + velocity_change)
            numerator_change = beta * (velocity_square_change + alpha * (velocity ** 2 + velocity_square_change))
            coefficient_change = (numerator_change - 2 * coefficient * hubble_delta) / (2 * changed_hubble)
        else:
            density_factor = self.model.constants[0] / scale
            normalization = float(self.prepared["cold_normalization"])
            bare = np.array([density_factor * old[1], 0.0, 0.0])
            bare_change = np.array([density_factor * (change[1] - alpha * (old[1] + change[1]) / (1 + alpha)), 0.0, 0.0])
            source = np.array([normalization * old[1], 0.0, 0.0])
            source_change = np.array([normalization * change[1], 0.0, 0.0])
            contact_density = contact_current = 0.0
            coefficient = normalization / (2 * hubble)
            coefficient_change = -coefficient * hubble_delta / changed_hubble
        other = old_observed[2:4] - bare[:2]
        other_change = total_delta - bare_change[:2]
        flow = np.zeros(9)
        delta_flow = np.zeros(9)
        if self.case == "heavy":
            flow[0:2] = [-3 * hubble * source[2], -wave * source[1]]
            delta_flow[0:2] = [-3 * (hubble_delta * source[2] + changed_hubble * source_change[2]), -wave * source_change[1]]
            flow[6:9] = [-hubble * source[1], wave * source[2], contact_current]
            delta_flow[6:9] = [-(hubble_delta * source[1] + changed_hubble * source_change[1]), wave * source_change[2], -contact_current]
        flow[2:6] = [-coefficient * bare[0], -coefficient * other[0], -2 * wave * coefficient * old_eta, contact_density]
        changed_coefficient = coefficient + coefficient_change
        delta_flow[2:6] = [
            -coefficient_change * bare[0] - changed_coefficient * bare_change[0],
            -coefficient_change * other[0] - changed_coefficient * other_change[0],
            -2 * wave * (coefficient_change * old_eta + changed_coefficient * delta_eta),
            -contact_density]
        difference = self.model.difference_flow(base, physical, False)
        field_defect = base["field_first"] - base["velocity"]
        velocity_defect = base["velocity_first"] + 2 * hubble * base["velocity"] + base["mass"] * base["field"]
        background_rhs = self.model.pack(
            difference[0] / scale - base["rate"] * alpha + hubble - base["rate"],
            difference[1::2] - field_defect, difference[2::2] - velocity_defect)
        rhs = np.concatenate((old_rhs[:self.active] / self.state_units, delta_rhs[:self.active] / self.delta_units,
                              background_rhs / self.background_units, flow / self.work_units, delta_flow / self.delta_work_units))
        old_force = (old_observed[2] / (2 * wave) + old_eta) / hubble
        delta_force = (total_delta[0] / (2 * wave) + delta_eta - old_force * hubble_delta) / changed_hubble
        selected = [1, 0] if self.case == "cold" else [self.first + 2, self.first + 3, 0]
        return rhs, {
            "source": source, "source_change": source_change, "work": work, "work_change": work_change,
            "other": other, "other_change": other_change, "background_change": physical,
            "own_state": old[selected], "own_state_change": change[selected],
            "metric_force": np.array([old_force, delta_force]), "background": full_background[:self.width],
            "live_balance_rhs": np.array([sum(flow[:6]), sum(flow[6:]), sum(delta_flow[:6]), sum(delta_flow[6:])]),
            "thermo_response": np.array([alpha, (1 + alpha) ** -1 - 1, (1 + alpha) ** -2 - 1]),
        }

    def rhs(self, tau, normalized):
        self.calls += 1
        if self.calls % 128 == 0:
            guard()
        return self.evaluate(tau, normalized)[0]

    def solve(self, steps):
        prepared = self.prepared
        queries = prepared["times"][None, :] + prepared["elapsed"][:, None]
        unique, inverse = np.unique(queries.ravel(), return_inverse=True)
        anchor, end = float(unique[0]), float(unique[-1])
        boundaries = self.background.boundaries(anchor, end)
        divisions = np.concatenate(([anchor], boundaries, [end]))
        current = self.initial.copy()
        items = {}
        initial_values = self.evaluate(anchor, current)[1]
        for name, value in initial_values.items():
            items[name] = np.empty((len(unique), *np.asarray(value).shape))
            items[name][0] = value
        evaluations = 0
        maximum_step = float(prepared["elapsed"][8]) / steps
        for segment, (begin, finish) in enumerate(zip(divisions[:-1], divisions[1:])):
            guard()
            selected = np.flatnonzero((unique > begin) & (unique <= finish))
            samples = np.unique(np.concatenate((unique[selected], [finish])))
            solution = solve_ivp(self.rhs, (float(begin), float(finish)), current, method="DOP853",
                                 rtol=CONFIG["rtol"], atol=CONFIG["normalized_atol"], max_step=maximum_step, t_eval=samples)
            require(solution.success, "coupled evolution segment")
            evaluations += solution.nfev
            for index, position in zip(selected, np.searchsorted(samples, unique[selected])):
                values = self.evaluate(float(unique[index]), solution.y[:, position])[1]
                for name, value in values.items():
                    items[name][index] = value
            current = solution.y[:, -1]
            if segment % 150 == 0:
                print(json.dumps({"case": self.case, "steps": steps, "segment": segment, "total": len(divisions)-1}), flush=True)
        shape = queries.shape
        items = {name: values[inverse].reshape((*shape, *values.shape[1:])) for name, values in items.items()}
        items["queries"] = queries
        items["state_units"] = self.state_units
        items["background_units"] = self.background_units
        for name in ("source", "source_change", "work", "work_change"):
            items[name + "_increment"] = weighted(prepared["weights"], items[name])
        own_change = items["source_change_increment"]
        change_work = items["work_change_increment"]
        own = items["source_increment"]
        own_work = items["work_increment"]
        items["balance"] = np.column_stack((own[:, 0] - np.sum(own_work[:, :6], axis=1),
                                           own[:, 1] - np.sum(own_work[:, 6:], axis=1)))
        items["change_balance"] = np.column_stack((own_change[:, 0] - np.sum(change_work[:, :6], axis=1),
                                                  own_change[:, 1] - np.sum(change_work[:, 6:], axis=1)))
        return items, {"evaluations": evaluations, "segments": len(divisions)-1, "maximum_physical_step": maximum_step}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=CONFIG["cases"])
    args = parser.parse_args()
    case, label = args.case, args.case + "-coupled"
    with worker(label):
        inputs = read(ROOT / "inputs.json").copy()
        for name in ("support.py", "native_context.py", "run_coupled.py", "protocol.json", "DERIVATION.md",
                     "native/camb/cambdll.dll", "native-build-full-result.json", case + "-preflight-result.json"):
            inputs[str(ROOT / name)] = digest(ROOT / name)
        check_inputs(inputs)
        write(ROOT / (label + "-inputs.json"), inputs)
        require(read(ROOT / (case + "-preflight-result.json"))["passed"], "same-background and thermo preflight")
        prepared, _, background, _, _ = EX.problem(case)
        require(np.all(prepared["wave"] == CONFIG["retained_comoving_wave"]), "one retained physical mode")
        saved = load(HISTORY / (case + "-extended-64.npz"))
        with native_context(case, label) as (captured, metadata, sample):
            reference = load(ROOT / (case + "-preflight-capture.npz"))
            require(all(np.array_equal(value, reference[name]) for name, value in captured.items()), "cached full initial-state parity")
            system = Coupled(case, prepared, background, captured, metadata, sample)
            checks, runs, integration = {}, {}, {}
            random = np.random.default_rng(20261116)
            for location in (0, len(captured["clock"]) // 2, len(captured["clock"]) - 1):
                tau = float(captured["clock"][location])
                base = system.model.represented(tau)
                background_packet = np.zeros(5)
                background_packet[:system.width] = system.model.pack(base["scale"], base["field"], base["velocity"])
                trial = np.zeros(system.allocated)
                trial[:system.active] = random.normal(size=system.active) * system.state_units * .001
                if case == "heavy":
                    trial[system.first + 4] = 0
                state = captured["reference"][location]
                original_rhs = sample(tau, state, background_packet, True)[0]
                trial_rhs = sample(tau, trial, background_packet, True)[0]
                combined_rhs = sample(tau, state + trial, background_packet, True)[0]
                checks["native_linearity_" + str(location)] = ratio(
                    maximum((combined_rhs - original_rhs - trial_rhs)[:system.active] / system.state_units), 1, CONFIG["algebra_tolerance"])
            require(all(value["passed"] for value in checks.values()), "native linear response contract")
            for steps in CONFIG["steps"]:
                runs[steps], integration[str(steps)] = system.solve(steps)
                np.savez_compressed(ROOT / (label + "-" + str(steps) + ".npz"), **runs[steps])
                print(json.dumps({"case": case, "steps": steps, **integration[str(steps)]}), flush=True)
            fine, coarse = runs[64], runs[32]
            saved_increment = weighted(prepared["weights"], saved["node_source"])
            for column, name in enumerate(("density", "current", "pressure")):
                scale = float(system.reference_scale[column])
                checks[name + "_control"] = ratio(maximum(fine["source_increment"][:, column] - saved_increment[:, column]), scale)
                checks[name + "_coarse_fine"] = ratio(maximum(fine["source_increment"][:, column] - coarse["source_increment"][:, column]), scale)
                checks[name + "_response_step_on_source_scale"] = ratio(maximum(fine["source_change_increment"][:, column] - coarse["source_change_increment"][:, column]), scale)
                checks[name + "_response_relative_step"] = ratio(maximum(fine["source_change_increment"][:, column] - coarse["source_change_increment"][:, column]),
                                                               maximum(fine["source_change_increment"][:, column]))
                checks[name + "_changed_source_budget"] = ratio(maximum(fine["source_increment"][:, column] + fine["source_change_increment"][:, column] - saved_increment[:, column]), scale)
            for column, name in enumerate(("density", "current")):
                scale = float(system.reference_scale[column])
                checks[name + "_old_exchange_balance"] = ratio(maximum(fine["balance"][:, column]), scale)
                checks[name + "_new_exchange_balance"] = ratio(maximum(fine["balance"][:, column] + fine["change_balance"][:, column]), scale)
                checks[name + "_response_exchange_on_source_scale"] = ratio(maximum(fine["change_balance"][:, column]), scale)
                checks[name + "_response_exchange_relative"] = ratio(maximum(fine["change_balance"][:, column]), maximum(fine["source_change_increment"][:, column]))
            prior = load(PREVIOUS / "segmented-response" / (case + "-response.npz"))
            for column in range(system.width):
                expected = prior["correction_64"][prior["query_index"], 1, column]
                checks["background_" + str(column)] = ratio(maximum(fine["background_change"][:, :, column] - expected),
                                                           1 if column == 0 else system.model.norm[column], CONFIG["algebra_tolerance"])
            checks["initial_matched_once"] = ratio(maximum(fine["own_state_change"][0, 0]), 1, CONFIG["algebra_tolerance"])
            checks["initial_preparation_source"] = ratio(maximum(fine["source"][0] - saved["node_source"][0]), max(float(max(system.reference_scale)), 1e-30))
            result = {"case": case, "checks_passed": all(value["passed"] for value in checks.values()), "checks": checks,
                      "integrations": integration, "final_source_change": fine["source_change_increment"][-1].tolist(),
                      "maximum_source_change": np.max(abs(fine["source_change_increment"]), axis=0).tolist(),
                      "maximum_surrounding_density_current_change": np.max(abs(fine["other_change"]), axis=(0, 1)).tolist(),
                      "matched_node_source_change_maximum": np.max(abs(fine["source_change"][0]), axis=0).tolist(),
                      "final_change_work_terms": fine["work_change_increment"][-1].tolist(),
                      "quantum_measure_included": False, "all_species_live": True, "nodewise_initial_resets": False,
                      "background_baseline_relative_limitations_inherited": True}
            write(ROOT / (label + "-result.json"), result)
            check_inputs(inputs)
            print(json.dumps({"case": case, "checks_passed": result["checks_passed"], "failed": {name: value for name, value in checks.items() if not value["passed"]},
                              "final_source_change": result["final_source_change"]}), flush=True)

if __name__ == "__main__":
    main()

