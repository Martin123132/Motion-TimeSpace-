from native_context import *
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("case", choices=CONFIG["cases"])
args = parser.parse_args()
with worker(args.case + "-preflight"):
    prepared, _, background, _, _ = EX.problem(args.case)
    model = BG.Model(background, float(prepared["times"][0]))
    with native_context(args.case, args.case + "-preflight") as (captured, metadata, sample):
        norms = np.max(abs(captured["reference"]), axis=0)
        norms[norms == 0] = 1
        checks, thermo = {}, []
        for number in (0, len(captured["clock"]) // 2, len(captured["clock"]) - 1):
            tau = float(captured["clock"][number])
            base = model.represented(tau)
            packet = np.zeros(5)
            packet[:len(model.norm)] = model.pack(base["scale"], base["field"], base["velocity"])
            state = captured["reference"][number]
            first, observed, extra = sample(tau, state, packet, False)
            same, same_observed, same_extra = sample(tau, state, packet, True)
            checks[str(number) + "_recovered_rhs"] = ratio(np.max(abs(first - captured["derivative_reference"][number]) / norms), 1, CONFIG["algebra_tolerance"])
            checks[str(number) + "_zero_response_rhs"] = ratio(np.max(abs(same - first) / norms), 1, CONFIG["algebra_tolerance"])
            scale = np.max(abs(captured["observation_reference"]), axis=0)
            scale[scale == 0] = 1
            checks[str(number) + "_recovered_readout"] = ratio(np.max(abs(observed - captured["observation_reference"][number]) / scale), 1, CONFIG["algebra_tolerance"])
            checks[str(number) + "_zero_response_readout"] = ratio(np.max(abs(same_observed - observed) / scale), 1, CONFIG["algebra_tolerance"])
            checks[str(number) + "_ionization_plateau"] = ratio(abs(extra[3] - (1 + extra[6])), 1 + extra[6], CONFIG["algebra_tolerance"])
            checks[str(number) + "_temperature_plateau"] = ratio(abs(extra[4] * extra[0] / extra[5] - 1), 1, CONFIG["algebra_tolerance"])
            thermo.append(extra.tolist())
        result = {"case": args.case, "passed": all(item["passed"] for item in checks.values()), "checks": checks, "thermo": thermo}
        write(ROOT / (args.case + "-preflight-result.json"), result)
        print(json.dumps({"case": args.case, "preflight_passed": result["passed"], "failed": {name: item for name, item in checks.items() if not item["passed"]}}), flush=True)
        require(result["passed"], "preflight checks")

