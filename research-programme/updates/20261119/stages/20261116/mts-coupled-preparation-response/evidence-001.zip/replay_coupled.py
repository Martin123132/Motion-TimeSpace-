from run_coupled import *

parser = argparse.ArgumentParser()
parser.add_argument("--replay", action="store_true")
arguments = parser.parse_args()
with worker("score-cached-replay"):
    require(arguments.replay, "cached replay only; no new integrations")
    inputs = read(ROOT / "score-inputs.json")
    check_inputs(inputs)
    cases, reproduction = {}, {}
    for case in CONFIG["cases"]:
        prepared, _, background, _, _ = EX.problem(case)
        model = BG.Model(background, float(prepared["times"][0]))
        scale = load(HISTORY / (case + "-comparison.npz"))["reference_scale"]
        saved = load(HISTORY / (case + "-extended-64.npz"))
        prior = load(PREVIOUS / "segmented-response" / (case + "-response.npz"))
        fine, coarse = [load(ROOT / (case + "-coupled-" + str(steps) + ".npz")) for steps in (64, 32)]
        saved_increment = weighted(prepared["weights"], saved["node_source"])
        checks, diagnostics = {}, {}
        for column, name in enumerate(("density", "current", "pressure")):
            reference = float(scale[column])
            checks[name + "_unrepaired_control"] = ratio(maximum(fine["source_increment"][:, column] - saved_increment[:, column]), reference)
            checks[name + "_control_step"] = ratio(maximum(fine["source_increment"][:, column] - coarse["source_increment"][:, column]), reference)
            response_error = maximum(fine["source_change_increment"][:, column] - coarse["source_change_increment"][:, column])
            response_scale = maximum(fine["source_change_increment"][:, column])
            checks[name + "_response_step_on_source_scale"] = ratio(response_error, reference)
            checks[name + "_response_relative_step"] = ratio(response_error, response_scale)
            difference = fine["source_increment"][:, column] + fine["source_change_increment"][:, column] - saved_increment[:, column]
            numerical = maximum(fine["source_increment"][:, column] - coarse["source_increment"][:, column]) + response_error
            checks[name + "_corrected_source_budget"] = ratio(maximum(difference) + numerical, reference)
            diagnostics[name] = {"maximum_response": response_scale, "final_response": float(fine["source_change_increment"][-1, column]),
                "maximum_changed_prediction": maximum(difference), "measured_step_allowance": numerical,
                "final_changed_prediction": float(difference[-1]), "unchanged_allowance": CONFIG["numerical_tolerance"] * reference}
        for column, name in enumerate(("density", "current")):
            reference = float(scale[column])
            response_scale = maximum(fine["source_change_increment"][:, column])
            checks[name + "_old_exchange"] = ratio(maximum(fine["balance"][:, column]), reference)
            checks[name + "_new_exchange"] = ratio(maximum(fine["balance"][:, column] + fine["change_balance"][:, column]), reference)
            checks[name + "_response_exchange_on_source_scale"] = ratio(maximum(fine["change_balance"][:, column]), reference)
            checks[name + "_response_exchange_relative"] = ratio(maximum(fine["change_balance"][:, column]), response_scale)
        for column in range(len(model.norm)):
            expected = prior["correction_64"][prior["query_index"], 1, column]
            checks["retained_background_" + str(column)] = ratio(maximum(fine["background_change"][:, :, column] - expected),
                                                              1 if column == 0 else model.norm[column], CONFIG["algebra_tolerance"])
        checks["single_initial_match"] = ratio(maximum(fine["own_state_change"][0, 0]), 1, CONFIG["algebra_tolerance"])
        weights = prepared["weights"]
        controls = {
            "frozen_surroundings_not_used": bool(maximum(fine["other_change"]) > 0),
            "prepared_nodes_not_reset": bool(maximum(fine["own_state_change"][0, 1:]) > 0),
            "new_density_without_surrounding_work": ratio(maximum(
                fine["balance"][:, 0] + fine["change_balance"][:, 0] +
                fine["work_increment"][:, 3] + fine["work_change_increment"][:, 3]), float(scale[0])),
            "response_without_surrounding_work": ratio(maximum(fine["change_balance"][:, 0] + fine["work_change_increment"][:, 3]),
                                                       maximum(fine["source_change_increment"][:, 0])),
        }
        cases[case] = {
            "checks_passed": all(item["passed"] for item in checks.values()), "checks": checks, "source_budget": diagnostics,
            "live_environment_controls": controls, "all_species_live": True, "quantum_measure_included": False,
            "maximum_surrounding_change": np.max(abs(fine["other_change"]), axis=(0, 1)).tolist(),
            "maximum_matched_node_change": np.max(abs(fine["source_change"][0]), axis=0).tolist(),
            "final_exchange_work_change": fine["work_change_increment"][-1].tolist(),
        }
        reproduction[case + "_finite"] = all(np.all(np.isfinite(value)) for values in (fine, coarse) for value in values.values())
        reproduction[case + "_original_grid"] = np.array_equal(fine["queries"], prepared["times"][None, :] + prepared["elapsed"][:, None])
        reproduction[case + "_same_grid"] = np.array_equal(fine["queries"], coarse["queries"])
        reproduction[case + "_preflight"] = read(ROOT / (case + "-preflight-result.json"))["passed"]
        reproduction[case + "_same_capture"] = read(ROOT / (case + "-preflight-capture.json"))["original934_packets_exact"]
        for name in ("source", "source_change", "work", "work_change"):
            reproduction[case + "_weighted_" + name] = np.array_equal(fine[name + "_increment"], weighted(weights, fine[name]))
        reproduction[case + "_linearity"] = read(ROOT / (case + "-step64-linearity.json"))["passed"]
    reproduction["symbolic"] = read(ROOT / "symbolic-result.json")["passed"]
    reproduction["no_pycache"] = not list(ROOT.rglob("__pycache__"))
    check_inputs(inputs)
    report = {"reproduction_passed": all(reproduction.values()), "reproduction_checks": reproduction,
              "cases": cases, "all_scientific_checks_passed": all(item["checks_passed"] for item in cases.values()),
              "frozen_inputs": len(inputs), "quantum_measure_included": False, "new_data_fit": False}
    if arguments.replay:
        require(report == read(ROOT / "result.json"), "exact cached score replay")
        write(ROOT / "score-cached-replay.json", {"exact": True, "reproduction_passed": report["reproduction_passed"]})
    else:
        write(ROOT / "result.json", report)
    print(json.dumps({"reproduction_passed": report["reproduction_passed"],
                     "failed": {case: {name: value for name, value in item["checks"].items() if not value["passed"]}
                                for case, item in cases.items()},
                     "source_budget": {case: item["source_budget"] for case, item in cases.items()}}))
    require(report["reproduction_passed"], "reproduction checks")

