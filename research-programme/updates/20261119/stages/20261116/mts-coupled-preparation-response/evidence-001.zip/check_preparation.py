from run_coupled import *

parser = argparse.ArgumentParser()
parser.add_argument("--replay", action="store_true")
arguments = parser.parse_args()
with worker("preparation-replay" if arguments.replay else "preparation-run"):
    inputs = read(ROOT / "score-inputs.json").copy()
    inputs[str(ROOT / "check_preparation.py")] = digest(ROOT / "check_preparation.py")
    for case in CONFIG["cases"]:
        for suffix in ("-extended-32.npz", "-comparison.npz"):
            path = HISTORY / (case + suffix)
            inputs[str(path)] = digest(path)
    if arguments.replay:
        require(inputs == read(ROOT / "preparation-inputs.json"), "same preparation audit inputs")
    else:
        write(ROOT / "preparation-inputs.json", inputs)
    check_inputs(inputs)
    cases = {}
    for case in CONFIG["cases"]:
        prepared, _, _, _, _ = EX.problem(case)
        weights = prepared["weights"]
        reference = load(HISTORY / (case + "-comparison.npz"))
        saved = load(HISTORY / (case + "-extended-64.npz"))
        old_coarse = load(HISTORY / (case + "-extended-32.npz"))
        fine = load(ROOT / (case + "-coupled-64.npz"))
        coarse = load(ROOT / (case + "-coupled-32.npz"))
        def project(values):
            return np.array([EX.weighted(weights, row) for row in values])
        response = project(fine["source_change"])
        response_step = response - project(coarse["source_change"])
        control_error = project(fine["source"] - saved["node_source"])
        control_step = project(fine["source"] - coarse["source"])
        retained_step = project(saved["node_source"] - old_coarse["node_source"])
        total_change = control_error + response
        step_allowance = abs(response_step) + abs(control_step) + abs(retained_step)
        reported_allowance = abs(reference["numerical_budget"])
        combined_allowance = step_allowance + reported_allowance
        checks, components = {}, {}
        for column, name in enumerate(("density", "current", "pressure")):
            scale = float(reference["reference_scale"][column])
            response_scale = maximum(response[:, column])
            checks[name + "_full_preparation_budget"] = ratio(
                maximum(abs(total_change[:, column]) + combined_allowance[:, column]), scale)
            checks[name + "_initial_preparation_budget"] = ratio(
                abs(total_change[0, column]) + combined_allowance[0, column], scale)
            checks[name + "_full_response_refinement"] = ratio(maximum(response_step[:, column]), response_scale)
            checks[name + "_initial_plus_increment_identity"] = ratio(
                maximum(response[:, column] - response[0, column] - fine["source_change_increment"][:, column]),
                scale, CONFIG["algebra_tolerance"])
            components[name] = {
                "initial_response": float(response[0, column]),
                "final_response": float(response[-1, column]),
                "maximum_response": response_scale,
                "maximum_corrected_total_change": maximum(total_change[:, column]),
                "maximum_combined_allowance": maximum(combined_allowance[:, column]),
                "maximum_response_step": maximum(response_step[:, column]),
                "gate_consumption_fraction": checks[name + "_full_preparation_budget"]["error"] / (CONFIG["numerical_tolerance"] * scale) if scale else None,
                "unchanged_allowance": CONFIG["numerical_tolerance"] * scale,
            }
        cases[case] = {"checks": checks, "checks_passed": all(item["passed"] for item in checks.values()),
                       "components": components}
        if not arguments.replay:
            np.savez_compressed(ROOT / (case + "-preparation-budget.npz"), response=response,
                total_change=total_change, response_step=response_step, control_error=control_error,
                control_step=control_step, retained_step=retained_step,
                reported_allowance=reported_allowance, combined_allowance=combined_allowance)
        else:
            archived = load(ROOT / (case + "-preparation-budget.npz"))
            local = dict(response=response, total_change=total_change, response_step=response_step,
                         control_error=control_error, control_step=control_step, retained_step=retained_step,
                         reported_allowance=reported_allowance, combined_allowance=combined_allowance)
            require(all(np.array_equal(value, archived[name]) for name, value in local.items()), "exact preparation arrays")
    result = {
        "cases": cases,
        "scope": "Full signed source including changed matched preparation, not only post-preparation increments.",
        "measured_allowances_not_rigorous_error_bounds": True,
        "all_scientific_checks_passed": all(item["checks_passed"] for item in cases.values()),
    }
    check_inputs(inputs)
    if arguments.replay:
        require(result == read(ROOT / "preparation-result.json"), "exact preparation report")
        write(ROOT / "preparation-replay.json", {"exact": True})
    else:
        write(ROOT / "preparation-result.json", result)
    print(json.dumps(result))

