from support import *
import sympy as symbolic

with worker("prove-response"):
    scale, expansion, rate, normalization, mass, wave = symbolic.symbols("a H r R0 m k", nonzero=True, real=True)
    field, velocity, perturbation, speed, force = symbolic.symbols("b v u w z", real=True)
    field_defect, velocity_defect = symbolic.symbols("fb fv", real=True)
    mass_squared = (scale * mass) ** 2
    density = velocity * speed + mass_squared * field * perturbation
    current = wave * velocity * perturbation
    pressure = velocity * speed - mass_squared * field * perturbation
    source = [scale * value / normalization for value in (density, current, pressure)]
    coordinates = [scale, field, velocity, perturbation, speed]
    flow = [rate * scale, velocity + field_defect,
            -2 * expansion * velocity - mass_squared * field + velocity_defect,
            speed, -2 * expansion * speed - (mass_squared + wave ** 2) * perturbation - wave * velocity * force]
    derivatives = [sum(symbolic.diff(value, coordinate) * derivative for coordinate, derivative in zip(coordinates, flow)) for value in source]
    density_contact = (rate - expansion) * (2 * source[0] - source[2]) + scale / normalization * (
        velocity_defect * speed + mass_squared * field_defect * perturbation)
    current_contact = (rate - expansion) * source[1] + scale / normalization * wave * velocity_defect * perturbation
    expected_density = -3 * expansion * source[2] - wave * source[1] - wave * scale / normalization * velocity ** 2 * force + density_contact
    expected_current = -expansion * source[1] + wave * source[2] + current_contact
    checks = {
        "represented_density_contact": symbolic.expand(derivatives[0] - expected_density) == 0,
        "represented_current_contact": symbolic.expand(derivatives[1] - expected_current) == 0,
        "coherent_contacts_zero": symbolic.expand(density_contact.subs({rate: expansion, field_defect: 0, velocity_defect: 0})) == 0
            and symbolic.expand(current_contact.subs({rate: expansion, field_defect: 0, velocity_defect: 0})) == 0,
        "dropping_contacts_not_an_identity": symbolic.expand(derivatives[0] - expected_density + density_contact) != 0,
    }
    alpha, field_change, velocity_change, perturbation_change, speed_change = symbolic.symbols("alpha B V du dw", real=True)
    substitutions = {scale: scale * (1 + alpha), field: field + field_change, velocity: velocity + velocity_change,
                     perturbation: perturbation + perturbation_change, speed: speed + speed_change}
    kinetic_change = velocity_change * speed + velocity * speed_change + velocity_change * speed_change
    mass_change = mass_squared * alpha * (2 + alpha)
    potential_change = mass_squared * (field * perturbation_change + field_change * perturbation + field_change * perturbation_change)
    potential_change += mass_change * (field + field_change) * (perturbation + perturbation_change)
    bare_change = [kinetic_change + potential_change,
        wave * (velocity * perturbation_change + velocity_change * perturbation + velocity_change * perturbation_change),
        kinetic_change - potential_change]
    for label, original, bare, changed in zip(("density", "current", "pressure"), source, (density, current, pressure), bare_change):
        stable = scale / normalization * (changed + alpha * (bare + changed))
        checks["exact_bilinear_" + label] = symbolic.expand(original.subs(substitutions, simultaneous=True) - original - stable) == 0
    write(ROOT / "symbolic-result.json", {"passed": all(checks.values()), "checks": checks,
                                         "scope": "Exact retained subsystem/source identities, not a new theory."})
    require(all(checks.values()), "symbolic identities")
    print(json.dumps(checks))

