from support import *
import subprocess
import ast

guard()
process = psutil.Process()
process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
allowed = process.cpu_affinity()
process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
checker = identity(process)
require(ROOT.resolve().is_relative_to(POST.resolve()), "private stage scope")
report = read(ROOT / "result.json")
preparation = read(ROOT / "preparation-result.json")
verification = read(ROOT / "verification-v2.json")
checks = {
    "consolidated_verification": verification["verified"],
    "cached_scoring_exact": read(ROOT / "score-cached-replay.json")["exact"],
    "cached_preparation_exact": read(ROOT / "preparation-replay.json")["exact"],
    "symbolic": read(ROOT / "symbolic-result.json")["passed"],
    "previous_seal": digest(PREVIOUS / "closeout.json") == CONFIG["previous_seal"],
}
original = (ROOT / "score_coupled.py").read_text()
cached = (ROOT / "replay_coupled.py").read_text()
begin = "    cases, reproduction = {}, {}"
end = "    if arguments.replay:\n        require(report == "
checks["same_scientific_scoring_code"] = original.split(begin, 1)[1].split(end, 1)[0] == cached.split(begin, 1)[1].split(end, 1)[0]
frozen = {}
for name in ("inputs.json", "native-build-frozen.json", "native-build-full-frozen.json",
             "cold-coupled-inputs.json", "cold-step64-inputs.json", "heavy-step32-inputs.json",
             "heavy-step64-inputs.json", "score-inputs.json", "preparation-inputs.json"):
    mapping = read(ROOT / name)
    check_inputs(mapping)
    for path, expected in mapping.items():
        require(path not in frozen or frozen[path] == expected, "consistent input declarations")
        frozen[path] = expected
checks["all_frozen_inputs_unchanged"] = True
for source in verification["supplementary_provenance"]:
    require(digest(source["path"]) == source["sha256"], "supplementary provenance stable")
checks["supplementary_provenance_unchanged"] = True
for path in ROOT.glob("*.py"):
    ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
checks["python_syntax"] = True
checks["no_bytecode"] = not list(ROOT.rglob("__pycache__"))
checks["no_task_hold"] = not (ROOT / "STOP-REQUESTED").exists()
checks["cold32_saved_hash"] = digest(ROOT / "cold-coupled-32.npz") == read(ROOT / "coarse-handover.json")["coarse_sha256"]
scientific = {}
for case in CONFIG["cases"]:
    combined = {**report["cases"][case]["checks"],
                **{"preparation_" + name: item for name, item in preparation["cases"][case]["checks"].items()}}
    scientific[case] = {
        "passed": sum(item["passed"] for item in combined.values()), "total": len(combined),
        "failures": {name: item for name, item in combined.items() if not item["passed"]},
        "all_source_scale_and_exchange_checks_pass": all(
            item["passed"] for name, item in combined.items()
            if name.endswith(("_corrected_source_budget", "_new_exchange", "_full_preparation_budget", "_initial_preparation_budget"))),
    }
checks["retained_inherited_failures"] = verification["inherited_baseline_background_relative_failures"] == 4
checks["scientific_failures_reported"] = not report["all_scientific_checks_passed"] and not preparation["all_scientific_checks_passed"]
identities = {}
def remember(value):
    if isinstance(value, dict):
        if all(name in value for name in ("pid", "created", "command")):
            identities[(value["pid"], value["created"])] = {name: value[name] for name in ("pid", "created", "command")}
        for item in value.values():
            remember(item)
    elif isinstance(value, list):
        for item in value:
            remember(item)
for path in ROOT.glob("*-start.json"):
    remember(read(path))
for name in ("native-build-result.json", "native-build-full-result.json"):
    remember(read(ROOT / name))
cleanup = [{"identity": saved, "outcome": exited(saved)} for saved in identities.values()]
checks["recorded_workers_and_build_children_exited"] = all(item["outcome"]["exited"] for item in cleanup)
mapping = subprocess.run(["subst"], capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW, check=True).stdout
checks["no_owned_drive_mapping"] = str(POST).replace("/", "\\").lower() not in mapping.lower()
checks["all_native_owners_released"] = all(
    read(path)["cleared"] and read(path)["native_reference_released"]
    for path in ROOT.glob("*-owner-release.json"))
require(all(checks.values()), "closeout validation: " + repr([name for name, passed in checks.items() if not passed]))
write(ROOT / "CLEANUP-VERIFIED.json", {
    "completed": True, "verified_exited_identities": len(cleanup), "processes": cleanup,
    "executing_foreground_checker": checker,
    "foreground_checker_exit_confirmed_by": "terminal command completion, outside this file",
    "drive_mappings": mapping, "no_task_hold": True, "no_bytecode": True,
    "temporary_coarse_handover": read(ROOT / "coarse-handover.json"),
    "other_chats_processes_changed": False, "services_started": False,
    "no_browsers_or_servers_started": True, "no_continuing_jobs": True,
})
artifacts = {}
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name != "closeout.json":
        guard()
        artifacts[path.relative_to(ROOT).as_posix()] = {"sha256": digest(path), "bytes": path.stat().st_size}
output = {
    "stage": "Coupled background, perturbations, live surroundings and matched preparation",
    "utc": datetime.now(timezone.utc).isoformat(),
    "completed": True, "verification_passed": True, "checks": checks,
    "scientific": scientific, "inherited_baseline_background_relative_failures": 4,
    "all_scientific_checks_passed": False,
    "full_mts_pressure_gate_fraction": preparation["cases"]["heavy"]["components"]["pressure"]["gate_consumption_fraction"],
    "source_bank_grids_tolerances_unchanged": True,
    "frozen_paths": len(frozen), "supplementary_provenance_count": len(verification["supplementary_provenance"]),
    "quantum_measure_included": False, "goal_resumed": False, "github_actions": False,
    "authoritative_results": ["result.json", "preparation-result.json", "verification-v2.json"],
    "cleanup_receipt": "CLEANUP-VERIFIED.json",
    "artifact_count": len(artifacts), "artifacts": artifacts,
}
write(ROOT / "closeout.json", output)
print(json.dumps({"completed": True, "sha256": digest(ROOT / "closeout.json"),
                  "artifacts": len(artifacts), "frozen_paths": len(frozen),
                  "cleaned_identities": len(cleanup), "scientific": scientific,
                  "full_pressure_gate_fraction": output["full_mts_pressure_gate_fraction"]}))

