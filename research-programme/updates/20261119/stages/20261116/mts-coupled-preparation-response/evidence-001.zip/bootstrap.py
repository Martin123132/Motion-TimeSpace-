from support import *
import shutil

with worker("bootstrap"):
    require(digest(PREVIOUS / "closeout.json") == CONFIG["previous_seal"], "previous sealed checkpoint")
    previous = read(PREVIOUS / "segmented-response/interface-inputs.json")
    check_inputs(previous)
    build = read(NATIVE.parent / "native-build-result.json")
    require(digest(NATIVE / "camb/cambdll.dll") == build["dll_sha256"], "authoritative retained binary")
    target = ROOT / "native"
    require(not target.exists(), "fresh private native copy")
    shutil.copytree(NATIVE, target, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    copied = {str(path.relative_to(NATIVE)).replace("\\", "/"): digest(path)
              for path in NATIVE.rglob("*") if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
    for relative, expected in copied.items():
        require(digest(target / relative) == expected, "copied native " + relative)
    inputs = previous.copy()
    for name in ("closeout.json", "verification.json", "NEXT.md"):
        inputs[str(PREVIOUS / name)] = digest(PREVIOUS / name)
    for relative, expected in copied.items():
        inputs[str(NATIVE / relative)] = expected
    write(ROOT / "bootstrap.json", {"completed": True, "original": str(NATIVE), "copied": copied,
                                   "bytes": sum((target / path).stat().st_size for path in copied)})
    write(ROOT / "inputs.json", inputs)
    print(json.dumps({"copied_files": len(copied), "bytes": sum((target / path).stat().st_size for path in copied)}))

