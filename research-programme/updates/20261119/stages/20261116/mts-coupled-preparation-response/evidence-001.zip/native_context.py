from support import *
import ast
import ctypes
import importlib.util
from contextlib import contextmanager

def load_background_owner():
    current_support = sys.modules.pop("support", None)
    try:
        specification = importlib.util.spec_from_file_location("background_response_owner", PREVIOUS / "run_response.py")
        module = importlib.util.module_from_spec(specification)
        specification.loader.exec_module(module)
    finally:
        if current_support is not None:
            sys.modules["support"] = current_support
    module.guard = guard
    return module

BG = load_background_owner()
EX = BG.EX

def pointers(*arrays):
    return [ctypes.c_void_p(value.ctypes.data) for value in arrays]

@contextmanager
def native_context(case, label):
    build = read(ROOT / "native-build-full-result.json")
    local = ROOT / "native"
    require(build["state"] == "completed" and build["mapping_removed"], "private native build ready")
    require(digest(local / "camb/cambdll.dll") == build["dll_sha256"], "frozen native binary")
    sys.path.insert(0, str(local))
    import camb
    from camb.mts import MTSTwoField
    require(Path(camb.__file__).resolve().parent == (local / "camb").resolve(), "private native import")
    sys.path.append(str(EX.BRANCH / "radiation-and-slow-field-transfer-20261007"))
    import radiation_common
    factory_path = EX.MATCHING / "matching_common.py"
    factory = next(node for node in ast.parse(factory_path.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == "params_for")
    namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
    exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_path), "exec"), namespace)
    parameters = namespace["params_for"](EX.EARLY / "runs/backgrounds" / (case + ".npz"))
    reference = load(EX.SPECTRUM / "runs/exact-grid/chunk-0384.npz" if case == "heavy" else EX.EARLY / "runs/final-bg8-start/cold.npz")
    observer = ctypes.CDLL(str(POST / "mts-metric-feedback-20261107/observer.dll"))
    callback = ctypes.cast(observer.source_func_, ctypes.c_void_p)
    library = ctypes.CDLL(str(local / "camb/cambdll.dll"))
    reset, reset_curve = library.mts_early_reset, library.mts_curv_reset
    for function in (reset, reset_curve):
        function.argtypes, function.restype = [], None
    copy = library.mts_early_copy
    copy.argtypes, copy.restype = [ctypes.c_int, ctypes.c_int] + [ctypes.c_void_p] * 11, None
    copy_curve = library.mts_current_copy
    copy_curve.argtypes, copy_curve.restype = [ctypes.c_int, ctypes.c_void_p], None
    evaluate = library.mts_response_evaluate
    evaluate.argtypes = [ctypes.c_double, ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int] + [ctypes.c_void_p] * 3
    evaluate.restype = None
    def scalar(name):
        return ctypes.c_int.in_dll(library, "mts_" + name)
    native = camb.get_background(parameters)
    try:
        clock = np.ascontiguousarray(native.conformal_time(1 / reference["requested_scale"] - 1, tol=1e-10))
        require(np.array_equal(clock, reference["conformal_time"]), "unchanged original clock")
        modes = np.ascontiguousarray(reference["modes"])
        selected = int(np.flatnonzero(modes == CONFIG["retained_comoving_wave"])[0])
        native.Params.Accuracy.IntTolBoost = 6
        native.Params.Accuracy.lAccuracyBoost = 4
        names = list(camb.model.evolve_names)
        output = np.zeros((len(modes), len(clock), len(names) + 30))
        reset()
        reset_curve()
        for family in ("early", "curv"):
            scalar(family + "_begin").value = CONFIG["first_index"] + 1
            scalar(family + "_end").value = CONFIG["last_index"] + 1
        scalar("early_target_index").value = scalar("curv_target").value = selected + 1
        result = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(len(modes))), modes,
                 ctypes.byref(ctypes.c_int(len(clock))), clock, ctypes.byref(ctypes.c_int(output.shape[-1])),
                 output, ctypes.byref(ctypes.c_int(30)), ctypes.byref(callback))
        require(result == 0 and scalar("early_status").value == 2 and scalar("curv_status").value == 2, "native state capture")
        count, allocated, active = [scalar("early_" + name).value for name in ("count", "nvar", "active")]
        captured = {name: np.zeros((count, allocated)) for name in ("reference", "restarted", "derivative_reference", "derivative_restarted")}
        captured.update({name: np.zeros((count, 40)) for name in ("observation_reference", "observation_restarted")})
        captured.update({name: np.zeros((count, 23)) for name in ("cache_reference", "cache_restarted")})
        captured["cache_mask"] = np.zeros((count, 23), dtype=np.int32)
        captured["signature"] = np.zeros((count, 96), dtype=np.int32)
        captured["clock"] = np.zeros(count)
        copy(allocated, count, *pointers(*captured.values()))
        require(scalar("early_status").value == 2, "captured state copy")
        packet = np.zeros((count, 224))
        copy_curve(count, pointers(packet)[0])
        old_packet = load(HISTORY / (case + "-construction-capture.npz"))["packet"]
        require(np.array_equal(packet, old_packet), "disabled hook leaves934 saved packets byte-identical")
        require(np.all(captured["signature"] == captured["signature"][0]), "unchanged active regime")
        capture_path = ROOT / (label + "-capture.npz")
        require(not capture_path.exists(), "new capture receipt")
        np.savez_compressed(capture_path, **captured, packet=packet)
        metadata = {"allocated": allocated, "active": active, "count": count, "original934_packets_exact": True,
                    "signature": captured["signature"][0].tolist(), "native_dll_sha256": build["dll_sha256"]}
        write(ROOT / (label + "-capture.json"), metadata)
        print(json.dumps({"case": case, "capture": metadata}), flush=True)
        calls = 0
        def sample(tau, vector, background, corrected):
            nonlocal calls
            calls += 1
            if calls % 128 == 0:
                guard()
            vector = np.ascontiguousarray(vector, dtype=np.float64)
            background = np.ascontiguousarray(background, dtype=np.float64)
            derivative, observed, extra = np.zeros(allocated), np.zeros(40), np.zeros(12)
            evaluate(float(tau), allocated, *pointers(vector, background), int(corrected), *pointers(derivative, observed, extra))
            require(scalar("response_status").value == 1, "coupled native response status at " + str(tau))
            require(np.all(np.isfinite(derivative)) and np.all(np.isfinite(observed)), "finite native response")
            return derivative, observed, extra
        yield captured, metadata, sample
    finally:
        reset()
        reset_curve()
        cleared = scalar("early_count").value == 0 and scalar("curv_count").value == 0
        del native
        write(ROOT / (label + "-owner-release.json"), {"cleared": cleared, "native_reference_released": True})
        require(cleared, "native owner released")

