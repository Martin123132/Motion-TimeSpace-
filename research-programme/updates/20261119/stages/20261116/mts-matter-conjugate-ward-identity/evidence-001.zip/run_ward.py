import os

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import time

import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
PREVIOUS = Path(CONFIG["previous_directory"])
spec = importlib.util.spec_from_file_location("retained_matter", PREVIOUS / "float-bath-repair/run_interface.py")
BASE = importlib.util.module_from_spec(spec)
spec.loader.exec_module(BASE)
STARTED = time.monotonic()
SITES = len(BASE.COORDS)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def utc():
    return datetime.now(timezone.utc).isoformat()


def guard():
    if time.monotonic() - STARTED > CONFIG["maximum_worker_seconds"]:
        raise TimeoutError("Bounded manual worker deadline reached")


def algebra_basis(dimension):
    matrices = []
    for first in range(dimension):
        for second in range(first + 1, dimension):
            symmetric = np.zeros((dimension, dimension), complex)
            symmetric[first, second] = symmetric[second, first] = 0.5j
            antisymmetric = np.zeros_like(symmetric)
            antisymmetric[first, second] = 0.5
            antisymmetric[second, first] = -0.5
            matrices.extend([symmetric, antisymmetric])
    for width in range(1, dimension):
        diagonal = np.zeros(dimension)
        diagonal[:width] = 1
        diagonal[width] = -width
        matrices.append(1j * np.diag(diagonal) / np.sqrt(2 * width * (width + 1)))
    return matrices


COLOR_BASIS = algebra_basis(3)
WEAK_BASIS = algebra_basis(2)


def represented_generator(label, generator):
    color_dim, weak_dim, charge = BASE.FIELDS[label] if isinstance(label, str) else label
    color_size = abs(color_dim)
    if generator < 8:
        color = COLOR_BASIS[generator]
        if color_dim == -3:
            color = color.conj()
        if color_size == 1:
            color = np.zeros((1, 1))
        return np.kron(color, np.eye(weak_dim))
    if generator < 11:
        weak = WEAK_BASIS[generator - 8] if weak_dim == 2 else np.zeros((1, 1))
        return np.kron(np.eye(color_size), weak)
    return 1j * charge * np.eye(color_size * weak_dim)


REP_GENERATORS = {
    label: [np.kron(np.eye(4), represented_generator(label, generator)) for generator in range(12)]
    for label in BASE.FIELDS
}
HIGGS_GENERATORS = [represented_generator((1, 2, 3), generator) for generator in range(12)]


def adjoint(color, weak):
    result = np.zeros((12, 12))
    for offset, basis, group in ((0, COLOR_BASIS, color), (8, WEAK_BASIS, weak)):
        for column, generator in enumerate(basis):
            changed = group @ generator @ group.conj().T
            for row, test in enumerate(basis):
                result[offset + row, offset + column] = -2 * np.trace(test @ changed).real
    result[11, 11] = 1
    return result


def pair_definitions():
    epsilon = np.array([[0, 1], [-1, 0]])
    pairs = []
    coefficients = [complex(*value) for value in BASE.CONFIG["yukawa_coefficients"]]
    for name, left, right, conjugate_higgs, coefficient in (
        ("up", "Q", "uc", False, coefficients[0]),
        ("down", "Q", "dc", True, coefficients[1]),
        ("lepton", "L", "ec", True, coefficients[2]),
    ):
        tensors = []
        for component in range(2):
            weak = epsilon[:, component] if name == "up" else np.eye(2)[:, component]
            if name == "lepton":
                tensor = np.einsum("ab,i->aib", BASE.CHARGE_C, weak).reshape(8, 4)
            else:
                tensor = np.einsum("ab,cd,i->acibd", BASE.CHARGE_C, np.eye(3), weak).reshape(24, 12)
            tensors.append(tensor)
        pairs.append((name, left, right, conjugate_higgs, coefficient, tensors))
    return pairs


PAIRS = pair_definitions()


def interaction(fields, bars, higgs):
    fields = {label: value.reshape(SITES, -1) for label, value in fields.items()}
    bars = {label: value.reshape(SITES, -1) for label, value in bars.items()}
    field_gradient = {label: np.zeros_like(value) for label, value in fields.items()}
    bar_gradient = {label: np.zeros_like(value) for label, value in bars.items()}
    higgs_gradient = np.zeros_like(higgs)
    higgs_conjugate_gradient = np.zeros_like(higgs)
    terms = {name: 0j for name, *_ in PAIRS}
    barred_terms = {name: 0j for name, *_ in PAIRS}
    action = 0j
    for name, left, right, conjugate_higgs, coefficient, tensors in PAIRS:
        for site in range(SITES):
            scalar = higgs[site].conj() if conjugate_higgs else higgs[site]
            matrix = sum(scalar[component] * tensors[component] for component in range(2))
            column_left, column_right = fields[left][site], fields[right][site]
            row_left, row_right = bars[left][site], bars[right][site]
            holomorphic = column_left @ matrix @ column_right
            partner = row_right @ matrix.conj().T @ row_left
            terms[name] += holomorphic
            barred_terms[name] += partner
            action += coefficient * holomorphic + coefficient.conjugate() * partner
            field_gradient[left][site] += coefficient * (matrix @ column_right)
            field_gradient[right][site] += coefficient * (matrix.T @ column_left)
            bar_gradient[right][site] += coefficient.conjugate() * (matrix.conj().T @ row_left)
            bar_gradient[left][site] += coefficient.conjugate() * (matrix.conj() @ row_right)
            for component, tensor in enumerate(tensors):
                direct = coefficient * (column_left @ tensor @ column_right)
                reverse = coefficient.conjugate() * (row_right @ tensor.conj().T @ row_left)
                if conjugate_higgs:
                    higgs_conjugate_gradient[site, component] += direct
                    higgs_gradient[site, component] += reverse
                else:
                    higgs_gradient[site, component] += direct
                    higgs_conjugate_gradient[site, component] += reverse
    return {
        "action": action, "terms": terms, "barred_terms": barred_terms,
        "field_gradient": {label: value.ravel() for label, value in field_gradient.items()},
        "bar_gradient": {label: value.ravel() for label, value in bar_gradient.items()},
        "higgs_gradient": higgs_gradient, "higgs_conjugate_gradient": higgs_conjugate_gradient,
    }


def model(arrays):
    guard()
    operators = {label: BASE.operator(arrays, label) for label in BASE.FIELDS}
    fields = {label: value["projector"] @ arrays["eta_" + label] for label, value in operators.items()}
    bars = {label: arrays["bar_" + label].conj() @ value["plus"] for label, value in operators.items()}
    interactions = interaction(fields, bars, arrays["higgs"])
    kinetic = sum(bars[label] @ operators[label]["overlap"] @ fields[label] for label in BASE.FIELDS)
    matter = kinetic + interactions["action"] + BASE.higgs_action(arrays)
    neutral = BASE.neutral_action(arrays["neutral"])["action"]
    return {
        "operators": operators, "fields": fields, "bars": bars, "interaction": interactions,
        "kinetic": kinetic, "matter": matter, "with_bath": matter + neutral, "neutral": neutral,
    }


def frechet_matrix(operator, weight):
    eigenvalues, eigenvectors = np.linalg.eigh(operator["kernel"])
    signs = np.sign(eigenvalues)
    split = signs[:, None] != signs[None, :]
    divided = np.zeros((len(signs), len(signs)))
    differences = eigenvalues[:, None] - eigenvalues[None, :]
    divided[split] = (signs[:, None] - signs[None, :])[split] / differences[split]
    return eigenvectors @ (divided * (eigenvectors.conj().T @ weight @ eigenvectors)) @ eigenvectors.conj().T


def sensitivities(arrays, state):
    exact, omitted = {}, {}
    for label, operator in state["operators"].items():
        column = state["fields"][label]
        row = state["bars"][label]
        weight = np.outer(column, row @ operator["gamma5"])
        missing = np.outer(
            arrays["eta_" + label],
            (row @ operator["overlap"] + state["interaction"]["field_gradient"][label]) / 2,
        )
        exact[label] = frechet_matrix(operator, weight + missing) @ operator["gamma5"]
        omitted[label] = frechet_matrix(operator, weight) @ operator["gamma5"]
    return exact, omitted


def current(arrays, response):
    values = np.zeros((SITES, 4, 12), complex)
    for site in range(SITES):
        for direction in range(4):
            other, crossed = BASE.shift(site, direction)
            boundary = BASE.CONFIG["fermion_boundary_signs"][direction] if crossed else 1
            for label, matrix in response.items():
                internal = abs(BASE.FIELDS[label][0]) * BASE.FIELDS[label][1]
                width = 4 * internal
                source = slice(site * width, (site + 1) * width)
                target = slice(other * width, (other + 1) * width)
                link = boundary * BASE.representation(arrays["color"][site, direction], arrays["weak"][site, direction], arrays["phase"][site, direction], label)
                for generator in range(12):
                    tangent = represented_generator(label, generator) @ link
                    forward = np.kron((BASE.GAMMA[direction] - np.eye(4)) / 2, tangent)
                    reverse = np.kron((-BASE.GAMMA[direction] - np.eye(4)) / 2, tangent.conj().T)
                    values[site, direction, generator] += (
                        np.einsum("ij,ji->", matrix[target, source], forward)
                        + np.einsum("ij,ji->", matrix[source, target], reverse)
                    )
            higgs_link = arrays["phase"][site, direction] ** 3 * arrays["weak"][site, direction]
            transported = higgs_link @ arrays["higgs"][other]
            difference = transported - arrays["higgs"][site]
            for generator in range(12):
                values[site, direction, generator] += 2 * np.vdot(difference, HIGGS_GENERATORS[generator] @ transported).real
    return values


def divergence(arrays, current_values):
    result = np.zeros((SITES, 12), complex)
    for site in range(SITES):
        for direction in range(4):
            other, _ = BASE.shift(site, direction)
            result[site] += current_values[site, direction]
            rotation = adjoint(arrays["color"][site, direction], arrays["weak"][site, direction])
            result[other] -= rotation.T @ current_values[site, direction]
    return result


def higgs_euler(arrays):
    higgs = arrays["higgs"]
    norm = np.sum(np.abs(higgs) ** 2, axis=1)
    gradient = (BASE.CONFIG["higgs_mass_squared"] + 2 * BASE.CONFIG["higgs_quartic"] * norm)[:, None] * higgs
    for site in range(SITES):
        for direction in range(4):
            other, _ = BASE.shift(site, direction)
            link = arrays["phase"][site, direction] ** 3 * arrays["weak"][site, direction]
            difference = link @ higgs[other] - higgs[site]
            gradient[site] -= difference
            gradient[other] += link.conj().T @ difference
    return gradient


def contacts(arrays, state):
    result = np.zeros((SITES, 12), complex)
    barred_contribution = np.zeros_like(result)
    for label, operator in state["operators"].items():
        eta_euler = (
            state["bars"][label] @ operator["overlap"] + state["interaction"]["field_gradient"][label]
        ) @ operator["projector"]
        bar_euler = operator["plus"] @ (
            operator["overlap"] @ state["fields"][label] + state["interaction"]["bar_gradient"][label]
        )
        eta_euler = eta_euler.reshape(SITES, -1)
        bar_euler = bar_euler.reshape(SITES, -1)
        eta = arrays["eta_" + label].reshape(SITES, -1)
        zeta = arrays["bar_" + label].conj().reshape(SITES, -1)
        for site in range(SITES):
            for generator, matrix in enumerate(REP_GENERATORS[label]):
                left = eta_euler[site] @ matrix @ eta[site]
                right = -zeta[site] @ matrix @ bar_euler[site]
                result[site, generator] += left + right
                barred_contribution[site, generator] += right
    higgs_star = higgs_euler(arrays)
    higgs_direct = higgs_star.conj() + state["interaction"]["higgs_gradient"]
    higgs_star = higgs_star + state["interaction"]["higgs_conjugate_gradient"]
    for site in range(SITES):
        for generator, matrix in enumerate(HIGGS_GENERATORS):
            tangent = matrix @ arrays["higgs"][site]
            result[site, generator] += higgs_direct[site] @ tangent + higgs_star[site] @ tangent.conj()
    return result, result - 2 * barred_contribution


def transform_all(arrays):
    result = BASE.transformed(arrays)
    for label in BASE.FIELDS:
        gauge = BASE.gauge_matrix(arrays, label)
        result["eta_" + label] = gauge @ arrays["eta_" + label]
        result["bar_" + label] = (arrays["bar_" + label].conj() @ gauge.conj().T).conj()
    return result


def matrix_exp_antihermitian(matrix, amount):
    eigenvalues, eigenvectors = np.linalg.eigh(-1j * matrix)
    return (eigenvectors * np.exp(1j * amount * eigenvalues)) @ eigenvectors.conj().T


def link_shift(arrays, site, direction, generator, amount):
    result = {name: value.copy() for name, value in arrays.items()}
    if generator < 8:
        result["color"][site, direction] = matrix_exp_antihermitian(COLOR_BASIS[generator], amount) @ arrays["color"][site, direction]
    elif generator < 11:
        result["weak"][site, direction] = matrix_exp_antihermitian(WEAK_BASIS[generator - 8], amount) @ arrays["weak"][site, direction]
    else:
        result["phase"][site, direction] *= np.exp(1j * amount)
    return result


def finite_differences(arrays, current_values):
    outcomes = []
    weights = [4 / 5, -1 / 5, 4 / 105, -1 / 280]
    for selected in CONFIG["finite_difference_links"]:
        for step in CONFIG["finite_difference_steps"]:
            differences = {"matter": [], "with_bath": []}
            for offset, weight in enumerate(weights, start=1):
                plus = model(link_shift(arrays, **selected, amount=offset * step))
                minus = model(link_shift(arrays, **selected, amount=-offset * step))
                for key in differences:
                    differences[key].append(weight * (plus[key] - minus[key]) / step)
            expected = current_values[selected["site"], selected["direction"], selected["generator"]]
            derivatives = {key: sum(terms) for key, terms in differences.items()}
            outcomes.append({
                **selected, "step": step,
                "matter_error": BASE.error(derivatives["matter"], expected),
                "bath_error": BASE.error(derivatives["with_bath"], expected),
                "bath_difference": BASE.error(derivatives["matter"], derivatives["with_bath"]),
                "derivative": [float(expected.real), float(expected.imag)],
            })
    return outcomes


def ward_error(divergence_values, contact_values):
    scale = np.maximum(1, np.abs(divergence_values) + np.abs(contact_values))
    return float(np.max(np.abs(divergence_values + contact_values) / scale))


def panel(arrays, seed):
    original = model(arrays)
    changed_arrays = transform_all(arrays)
    changed = model(changed_arrays)
    response, broken_response = sensitivities(arrays, original)
    currents = current(arrays, response)
    broken_currents = current(arrays, broken_response)
    current_divergence = divergence(arrays, currents)
    field_contacts, wrong_contacts = contacts(arrays, original)
    changed_response, _ = sensitivities(changed_arrays, changed)
    changed_currents = current(changed_arrays, changed_response)
    changed_divergence = divergence(changed_arrays, changed_currents)
    changed_contacts, _ = contacts(changed_arrays, changed)
    predicted_currents = np.zeros_like(currents)
    predicted_contacts = np.zeros_like(field_contacts)
    for site in range(SITES):
        rotation = adjoint(arrays["gcolor"][site], arrays["gweak"][site])
        predicted_currents[site] = (rotation @ currents[site].T).T
        predicted_contacts[site] = rotation @ field_contacts[site]
    metrics = {}
    checks = {}

    def check(name, value, minimum=False):
        metrics[name] = float(value)
        checks[name] = bool(np.isfinite(value) and (
            value >= CONFIG["negative_control_floor"] if minimum else value <= CONFIG["identity_tolerance"]
        ))

    old_terms = BASE.yukawa(original["fields"], arrays["higgs"])
    for name in original["interaction"]["terms"]:
        check("holomorphic_retained_" + name, BASE.error(original["interaction"]["terms"][name], old_terms[name]))
        check("conjugate_gauge_" + name, BASE.error(original["interaction"]["barred_terms"][name], changed["interaction"]["barred_terms"][name]))
    check("matter_action_covariance", BASE.error(original["matter"], changed["matter"]))
    check("bath_action_covariance", BASE.error(original["with_bath"], changed["with_bath"]))
    check("current_covariance", BASE.error(changed_currents, predicted_currents))
    check("contact_covariance", BASE.error(changed_contacts, predicted_contacts))
    check("ward_matter", ward_error(current_divergence, field_contacts))
    check("ward_matter_plus_bath", ward_error(current_divergence, field_contacts))
    check("ward_transformed_matter", ward_error(changed_divergence, changed_contacts))
    check("ward_transformed_bath", ward_error(changed_divergence, changed_contacts))
    check("negative_omit_projector_motion", ward_error(divergence(arrays, broken_currents), field_contacts), True)
    check("negative_wrong_barred_sign", ward_error(current_divergence, wrong_contacts), True)

    raw_columns = {label: arrays["eta_" + label] for label in BASE.FIELDS}
    conjugate_rows = {label: value.conj() for label, value in raw_columns.items()}
    partners = interaction(raw_columns, conjugate_rows, arrays["higgs"])
    for name in partners["terms"]:
        check("coefficient_partner_" + name, BASE.error(partners["barred_terms"][name], partners["terms"][name].conjugate()))
    wrong_coefficients = sum(
        coefficient * partners["barred_terms"][name]
        for (name, _, _, _, coefficient, _) in PAIRS
    )
    correct_coefficients = sum(
        coefficient.conjugate() * partners["barred_terms"][name]
        for (name, _, _, _, coefficient, _) in PAIRS
    )
    check("negative_unconjugated_coefficients", BASE.error(wrong_coefficients, correct_coefficients), True)
    check("neutral_state_preserved", BASE.error(changed_arrays["neutral"], arrays["neutral"]))

    empty = {name: value.copy() for name, value in arrays.items()}
    for label in BASE.FIELDS:
        empty["eta_" + label][:] = 0
        empty["bar_" + label][:] = 0
    empty["higgs"][:] = 0
    vacuum = model(empty)
    vacuum_response, _ = sensitivities(empty, vacuum)
    vacuum_current = current(empty, vacuum_response)
    check("trivial_charged_vacuum_current", float(np.linalg.norm(vacuum_current)))
    check("trivial_vacuum_retains_neutral_action", BASE.error(vacuum["with_bath"], original["neutral"]))
    finite = finite_differences(arrays, currents) if seed == CONFIG["finite_difference_fixture"] else []
    for index, row in enumerate(finite):
        check(f"finite_difference_matter_{index}", row["matter_error"])
        check(f"finite_difference_bath_{index}", row["bath_error"])
        check(f"finite_difference_bath_equality_{index}", row["bath_difference"])
    checks["kernel_gap_guard"] = min(
        value["gap"] for state in (original, changed) for value in state["operators"].values()
    ) >= BASE.CONFIG["kernel_gap_floor"]
    checks["faithful_plaquette_guard"] = all(
        BASE.plaquettes(value)[0][0] <= BASE.CONFIG["engineering_plaquette_threshold"]
        for value in (arrays, changed_arrays)
    )
    report = {
        "seed": seed, "passed": all(checks.values()), "checks": checks, "metrics": metrics,
        "finite_differences": finite,
        "local_identity_entries": SITES * 12,
        "off_shell_max_divergence": float(np.max(np.abs(current_divergence))),
        "off_shell_max_contact": float(np.max(np.abs(field_contacts))),
        "neutral_action": float(original["neutral"]),
        "action_matter": [float(original["matter"].real), float(original["matter"].imag)],
        "action_with_bath": [float(original["with_bath"].real), float(original["with_bath"].imag)],
        "quantum_measure_included": False,
    }
    saved = {
        "current": currents, "divergence": current_divergence, "contacts": field_contacts,
        "broken_current": broken_currents, "wrong_barred_contacts": wrong_contacts,
        "transformed_current": changed_currents, "transformed_divergence": changed_divergence,
        "transformed_contacts": changed_contacts,
    }
    return report, saved


def verify_inputs():
    checks = {}
    for entry in CONFIG["local_inputs"]:
        path = Path(entry["path"])
        checks[str(path)] = path.is_file() and path.stat().st_size == entry["bytes"] and sha(path) == entry["sha256"]
    sealed = json.loads((PREVIOUS / "closeout.json").read_text(encoding="utf-8"))
    for entry in sealed["artifacts"]:
        path = PREVIOUS / entry["path"]
        checks[str(path)] = path.is_file() and path.stat().st_size == entry["bytes"] and sha(path) == entry["sha256"]
    return checks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    name = "replay" if args.replay else "run"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(), "utc": utc(), "affinity": process.cpu_affinity(), "priority": "below-normal"}
    save(ROOT / (name + "-start.json"), identity)
    try:
        before = verify_inputs()
        if not all(before.values()):
            raise RuntimeError("Retained source/fixture integrity failed before execution")
        reports = []
        for seed in CONFIG["seeds"]:
            path = PREVIOUS / f"fixture-{seed}.npz"
            with np.load(path, allow_pickle=False) as archive:
                arrays = {key: archive[key] for key in archive.files}
            report, values = panel(arrays, seed)
            report["fixture_sha256"] = sha(path)
            if args.replay:
                original = json.loads((ROOT / f"panel-{seed}.json").read_text(encoding="utf-8"))
                if report != original:
                    raise RuntimeError(f"Panel {seed} replay mismatch")
                with np.load(ROOT / f"currents-{seed}.npz", allow_pickle=False) as saved:
                    if set(saved.files) != set(values) or not all(np.array_equal(saved[key], values[key]) for key in values):
                        raise RuntimeError(f"Panel {seed} current replay mismatch")
            else:
                if (ROOT / f"panel-{seed}.json").exists():
                    raise FileExistsError("Never overwrite a saved panel")
                save(ROOT / f"panel-{seed}.json", report)
                np.savez_compressed(ROOT / f"currents-{seed}.npz", **values)
            reports.append(report)
            print(json.dumps({"seed": seed, "passed": report["passed"], "checks": len(report["checks"])}), flush=True)
        after = verify_inputs()
        result = {
            "passed": all(report["passed"] for report in reports) and all(after.values()),
            "panels": [{"seed": report["seed"], "passed": report["passed"], "checks": len(report["checks"])} for report in reports],
            "retained_files_verified": len(after),
            "all_frozen_inputs_unchanged": all(before.values()) and all(after.values()),
            "protocol_sha256": sha(ROOT / "protocol.json"), "code_sha256": sha(Path(__file__)),
            "quantum_measure_included": False, "physical_history_changed": False,
            "identity": "D^- J_act + E_gauge = 0 off shell; covariant conservation conditional on charged-field equations",
        }
        if args.replay and result != json.loads((ROOT / "result.json").read_text(encoding="utf-8")):
            raise RuntimeError("Aggregate replay mismatch")
        save(ROOT / ("replay-result.json" if args.replay else "result.json"), result)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        save(ROOT / (name + "-end.json"), {"completed": True, "passed": result["passed"], "utc": utc(), "elapsed_seconds": time.monotonic() - STARTED, "pid": process.pid, "created": process.create_time(), "pycache_absent": not any(ROOT.rglob("__pycache__"))})
        return 0 if result["passed"] else 1
    except BaseException as failure:
        save(ROOT / (name + "-failure.json"), {"completed": False, "utc": utc(), "pid": process.pid, "created": process.create_time(), "error": repr(failure)})
        raise


if __name__ == "__main__":
    raise SystemExit(main())
