import os

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
HISTORY = Path(CONFIG["history_directory"])
POST = Path(CONFIG["post_directory"])
sys.dont_write_bytecode = True
sys.path.insert(0, str(HISTORY))
import extension_math as EX

START = time.monotonic()
ALGEBRA = CONFIG["algebra_tolerance"]
GATE = CONFIG["observable_tolerance"]
TERMS = ["flux", "self_metric_work", "surrounding_density_work", "eta_metric_work",
         "clock_contact", "background_field_contact", "reconstruction_euler"]
MODE_KEYS = {
    "history": ("state", "node_source"),
    "quadratic": ("quad_state", "quad_node_source"),
    "difference": ("delta_state", "delta_node_source"),
}


def utc():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def write(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + "\n")


def guard():
    if time.monotonic() - START > CONFIG["maximum_worker_seconds"]:
        raise TimeoutError("Bounded diagnostic deadline reached")
    for directory in (ROOT, POST, HISTORY, EX.OLDER, EX.BRANCH):
        if (directory / "STOP-REQUESTED").exists():
            raise RuntimeError("Owner hold: " + str(directory))


def freeze_inputs():
    if digest(HISTORY / "closeout.json") != CONFIG["history_closeout_sha256"]:
        raise RuntimeError("Unexpected history seal")
    bridge = Path(CONFIG["bridge_directory"])
    if digest(bridge / "closeout.json") != CONFIG["bridge_closeout_sha256"]:
        raise RuntimeError("Unexpected current/stress seal")
    expected = {
        path: value for path, value in read(HISTORY / "frozen-inputs.json").items()
        if Path(path).suffix in (".py", ".md", ".json")
    }
    paths = [ROOT / "protocol.json", ROOT / "run_balance.py", ROOT / "DERIVATION.md",
             HISTORY / "closeout.json", bridge / "closeout.json",
             POST / "mts-action-source-pullback-20261107/DERIVATION.md",
             POST / "MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md",
             POST / "condensate-origin-20261003/motion-bath-matching-20261006/49-real-motion-envelope-and-existing-bath-matching.md"]
    for name in ("support.py", "extension_math.py", "PROTOCOL.md", "METHOD.md", "RESULTS.md"):
        paths.append(HISTORY / name)
    for case in CONFIG["cases"]:
        paths.extend([EX.PREVIOUS / (case + "-initial-state.npz"),
                      EX.OLDER / (case + "-history-preparation.npz"),
                      EX.SOURCE / (case + "-native-clock.npz"),
                      EX.EARLY / "runs/backgrounds" / (case + ".npz")])
        for suffix in ("-extension-plan.npz", "-source-frozen.npz", "-extended-preparation.npz",
                       "-extended-32.npz", "-extended-64.npz", "-comparison.npz",
                       "-validation-capture.npz"):
            paths.append(HISTORY / (case + suffix))
    for path in paths:
        expected[str(path)] = digest(path)
    if (ROOT / "inputs.json").exists():
        if read(ROOT / "inputs.json") != expected:
            raise RuntimeError("Frozen input map changed")
    else:
        write(ROOT / "inputs.json", expected)
    verify_inputs(expected)
    return expected


def verify_inputs(expected):
    for path, wanted in expected.items():
        guard()
        if not Path(path).is_file() or digest(path) != wanted:
            raise RuntimeError("Input changed: " + path)


def source_first(history, offset):
    selected = np.minimum(np.sum(history.left <= offset, axis=1) - 1, history.lengths - 1)
    nodes = np.arange(history.count)
    width = history.width[nodes, selected]
    fraction = (offset - history.left[nodes, selected]) / width
    coefficients = history.coefficients[nodes, selected]
    integral = np.zeros((history.count, 2))
    for degree in range(coefficients.shape[1]):
        integral += coefficients[:, degree] * (width * fraction ** (degree + 1) / (degree + 1))[:, None]
    remainder_first = history.first_prefix[nodes, selected] + integral
    return history.first + offset * history.curvature + remainder_first, remainder_first


def sources(history, offset):
    remainder = history.remainder(offset)
    full_first, remainder_first = source_first(history, offset)
    return {
        "history": (history.evaluate(offset), full_first),
        "quadratic": (history.quadratic(offset), history.first + offset * history.curvature),
        "difference": (remainder, remainder_first),
    }


def rhs(matrix, forcing, state, source):
    return np.einsum("nij,nj->ni", matrix, state) + np.einsum("nij,nj->ni", forcing, source)


def observed(case, state, derivative, values, source, prepared):
    wave, rate, hubble = prepared["wave"], values["rate"], values["hubble"]
    eta = state[:, -1]
    zeros = np.zeros(len(wave))
    if case == "heavy":
        field, velocity, field_prime, velocity_prime, _, _, mass = values["jets"][1]
        displacement, speed = state[:, 0], state[:, 1]
        displacement_prime, speed_prime = derivative[:, 0], derivative[:, 1]
        beta = values["scale"] / float(prepared["density0"])
        density = velocity * speed + mass * field * displacement
        current = wave * velocity * displacement
        pressure = velocity * speed - mass * field * displacement
        field_defect = field_prime - velocity
        velocity_defect = velocity_prime + 2 * hubble * velocity + mass * field
        force = ((density + source[:, 0]) / (2 * wave) + eta) / hubble
        euler_displacement = displacement_prime - speed
        euler_speed = speed_prime + (mass + wave ** 2) * displacement + 2 * hubble * speed + wave * velocity * force
        euler_eta = derivative[:, -1] - (current + source[:, 1]) / 2
        density_prime = (velocity_prime * speed + velocity * speed_prime
                         + 2 * rate * mass * field * displacement
                         + mass * field_prime * displacement + mass * field * displacement_prime)
        current_prime = wave * (velocity_prime * displacement + velocity * displacement_prime)
        source_values = beta[:, None] * np.column_stack((density, current, pressure))
        direct = beta[:, None] * np.column_stack((density_prime + rate * density, current_prime + rate * current))
        work_factor = beta * velocity ** 2
        flux = np.column_stack((-3 * rate * source_values[:, 2] - wave * source_values[:, 1],
                                -rate * source_values[:, 1] + wave * source_values[:, 2]))
        clock = beta[:, None] * np.column_stack((4 * (rate - hubble) * velocity * speed, 2 * (rate - hubble) * current))
        background = beta[:, None] * np.column_stack((velocity_defect * speed + mass * field_defect * displacement,
                                                      wave * velocity_defect * displacement))
        euler = beta[:, None] * np.column_stack((velocity * euler_speed + mass * field * euler_displacement,
                                                 wave * velocity * euler_displacement))
    else:
        density_factor = float(values["cold_constant"]) / values["scale"]
        density = density_factor * state[:, 0]
        force = ((density + source[:, 0]) / (2 * wave) + eta) / hubble
        normalization = float(prepared["cold_normalization"])
        source_values = np.column_stack((normalization * state[:, 0], zeros, zeros))
        direct = np.column_stack((normalization * derivative[:, 0], zeros))
        work_factor = np.full(len(wave), normalization)
        flux = np.zeros((len(wave), 2))
        clock = np.zeros_like(flux)
        background = np.zeros_like(flux)
        euler = np.column_stack((normalization * (derivative[:, 0] + wave * force), zeros))
        euler_eta = derivative[:, -1] - source[:, 1] / 2
    work_self = np.column_stack((-work_factor * density / (2 * hubble), zeros))
    work_other = np.column_stack((-work_factor * source[:, 0] / (2 * hubble), zeros))
    work_eta = np.column_stack((-work_factor * wave * eta / hubble, zeros))
    contributions = np.stack((flux, work_self, work_other, work_eta, clock, background, euler), axis=1)
    return {"source": source_values, "direct": direct, "terms": contributions,
            "euler_eta": euler_eta, "force": force}


def hermite_coefficients(first, last, first_rhs, last_rhs, first_second, last_second, duration, norm):
    coefficients = np.zeros((6, *first.shape))
    coefficients[0] = first / norm
    coefficients[1] = duration * first_rhs / norm
    coefficients[2] = 0.5 * duration ** 2 * first_second / norm
    endpoint = last / norm - coefficients[0] - coefficients[1] - coefficients[2]
    slope = duration * last_rhs / norm - coefficients[1] - 2 * coefficients[2]
    curvature = duration ** 2 * last_second / norm - 2 * coefficients[2]
    coefficients[3] = 10 * endpoint - 4 * slope + curvature / 2
    coefficients[4] = -15 * endpoint + 7 * slope - curvature
    coefficients[5] = 6 * endpoint - 3 * slope + curvature / 2
    return coefficients


def polynomial(coefficients, fraction, duration, norm):
    state = sum(coefficients[degree] * fraction ** degree for degree in range(6)) * norm
    derivative = sum(degree * coefficients[degree] * fraction ** (degree - 1) for degree in range(1, 6)) * norm / duration
    return state, derivative


def check_ratio(error, scale, tolerance):
    error, scale = float(error), float(scale)
    return {"error": error, "scale": scale, "relative": error / scale if scale else None,
            "tolerance": tolerance, "passed": bool(np.isfinite(error) and error <= tolerance * scale)}


def maxabs(value):
    return float(np.max(np.abs(value)))


def solve_case(case):
    prepared, history, background, _, _ = EX.problem(case)
    elapsed = prepared["elapsed"]
    weights = prepared["weights"]
    if len(elapsed) != CONFIG["report_count"] or len(weights) != CONFIG["preparation_nodes"]:
        raise RuntimeError("Unexpected saved shape")
    saved_comparison = EX.load(HISTORY / (case + "-comparison.npz"))
    scale = saved_comparison["reference_scale"][:2]
    samples = {}
    def sample(offset):
        key = float(offset)
        if key not in samples:
            guard()
            values = background.evaluate(prepared["times"] + key)
            values["cold_constant"] = background.constants[0]
            geometry = EX.metric.geometry(case, key, prepared, background)
            samples[key] = (values, geometry, sources(history, key))
        return samples[key]

    report = {"case": case, "checks": {}, "modes": {}, "quantum_measure_included": False,
              "all_species_stress_closed": False, "new_evolution": False}
    arrays_out = {"elapsed": elapsed, "weights": weights, "reference_scale": scale}
    for steps in CONFIG["saved_steps"]:
        saved = EX.load(HISTORY / (case + f"-extended-{steps}.npz"))
        if not np.array_equal(saved["elapsed"], elapsed) or not np.array_equal(saved["weights"], weights):
            raise RuntimeError("Saved grid/weight mismatch")
        endpoints = {mode: [] for mode in CONFIG["modes"]}
        rate_checks = {mode: {"error": np.zeros(2), "scale": np.zeros(2)} for mode in CONFIG["modes"]}
        direct_derivatives, second_derivatives = {}, {}
        for mode, (state_key, node_key) in MODE_KEYS.items():
            first_rates, seconds = [], []
            for index, offset in enumerate(elapsed):
                values, (matrix, matrix_prime, forcing, forcing_prime), source_map = sample(offset)
                source, source_prime = source_map[mode]
                state = saved[state_key][index]
                derivative = rhs(matrix, forcing, state, source)
                second = (np.einsum("nij,nj->ni", matrix_prime, state)
                          + np.einsum("nij,nj->ni", matrix, derivative)
                          + np.einsum("nij,nj->ni", forcing_prime, source)
                          + np.einsum("nij,nj->ni", forcing, source_prime))
                item = observed(case, state, derivative, values, source, prepared)
                first_rates.append(derivative)
                seconds.append(second)
                endpoints[mode].append(item)
                defect = item["direct"] - np.sum(item["terms"], axis=1)
                rate_checks[mode]["error"] = np.maximum(rate_checks[mode]["error"], np.max(abs(defect), axis=0))
                magnitude = abs(item["direct"]) + np.sum(abs(item["terms"]), axis=1)
                rate_checks[mode]["scale"] = np.maximum(rate_checks[mode]["scale"], np.max(magnitude, axis=0))
            direct_derivatives[mode] = np.array(first_rates)
            second_derivatives[mode] = np.array(seconds)
            rebuilt = np.array([item["source"] for item in endpoints[mode]])
            reference = saved[node_key]
            report["checks"][f"{steps}_{mode}_source_reconstruction"] = check_ratio(maxabs(rebuilt - reference), maxabs(reference), ALGEBRA)
            arrays_out[f"{steps}_{mode}_endpoint_source"] = np.array([EX.weighted(weights, item["source"][:, :2] - endpoints[mode][0]["source"][:, :2]) for item in endpoints[mode]])
            for channel, name in enumerate(("density", "current")):
                report["checks"][f"{steps}_{mode}_{name}_rate_identity"] = check_ratio(rate_checks[mode]["error"][channel], rate_checks[mode]["scale"][channel], ALGEBRA)

        approximation_terms = []
        approximation_errors = []
        approximation_scales = []
        eta_contacts = []
        for index, offset in enumerate(elapsed):
            values, (matrix, _, forcing, _), source_map = sample(offset)
            state = saved["quad_state"][index]
            own_derivative = direct_derivatives["quadratic"][index]
            against_full = observed(case, state, own_derivative, values, source_map["history"][0], prepared)
            own = endpoints["quadratic"][index]
            remainder = source_map["difference"][0]
            exact_euler = -np.einsum("nij,nj->ni", forcing, remainder)
            factor = values["scale"] / float(prepared["density0"]) * values["jets"][1][1] if case == "heavy" else np.full(len(weights), float(prepared["cold_normalization"]))
            exact_energy = factor * exact_euler[:, 1 if case == "heavy" else 0]
            exact_eta = exact_euler[:, -1]
            actual = against_full["terms"][:, -1, 0] - own["terms"][:, -1, 0]
            approximation_errors.append(maxabs(actual - exact_energy))
            approximation_scales.append(maxabs(against_full["direct"]) + maxabs(against_full["terms"]))
            eta_contacts.append([maxabs(against_full["euler_eta"] - exact_eta), maxabs(own_derivative[:, -1]) + maxabs(source_map["history"][0][:, 1])])
            approximation_terms.append(EX.weighted(weights, np.column_stack((exact_energy, exact_eta))))
        report["checks"][f"{steps}_quadratic_as_full_energy_contact"] = check_ratio(max(approximation_errors), max(approximation_scales), ALGEBRA)
        report["checks"][f"{steps}_quadratic_as_full_eta_contact"] = check_ratio(max(item[0] for item in eta_contacts), max(item[1] for item in eta_contacts), ALGEBRA)
        arrays_out[f"{steps}_approximation_contacts"] = np.array(approximation_terms)
        for order in CONFIG["quadrature_orders"]:
            nodes, quadrature_weights = np.polynomial.legendre.leggauss(order)
            cumulative = {mode: np.zeros((len(elapsed), len(TERMS), 2)) for mode in CONFIG["modes"]}
            integrated_direct = {mode: np.zeros((len(elapsed), 2)) for mode in CONFIG["modes"]}
            for interval in range(len(elapsed) - 1):
                guard()
                left, right = float(elapsed[interval]), float(elapsed[interval + 1])
                duration = right - left
                coefficients = {}
                for mode, (state_key, _) in MODE_KEYS.items():
                    coefficients[mode] = hermite_coefficients(
                        saved[state_key][interval], saved[state_key][interval + 1],
                        direct_derivatives[mode][interval], direct_derivatives[mode][interval + 1],
                        second_derivatives[mode][interval], second_derivatives[mode][interval + 1],
                        duration, prepared["norm"])
                totals = {mode: np.zeros((len(TERMS), 2)) for mode in CONFIG["modes"]}
                directs = {mode: np.zeros(2) for mode in CONFIG["modes"]}
                for node, quadrature_weight in zip(nodes, quadrature_weights):
                    fraction = (node + 1) / 2
                    offset = left + duration * fraction
                    values, _, source_map = sample(offset)
                    for mode in CONFIG["modes"]:
                        state, derivative = polynomial(coefficients[mode], fraction, duration, prepared["norm"])
                        item = observed(case, state, derivative, values, source_map[mode][0], prepared)
                        weighted_terms = EX.weighted(weights, item["terms"].reshape(len(weights), -1)).reshape(len(TERMS), 2)
                        totals[mode] += duration * quadrature_weight / 2 * weighted_terms
                        directs[mode] += duration * quadrature_weight / 2 * EX.weighted(weights, item["direct"])
                for mode in CONFIG["modes"]:
                    cumulative[mode][interval + 1] = cumulative[mode][interval] + totals[mode]
                    integrated_direct[mode][interval + 1] = integrated_direct[mode][interval] + directs[mode]
                if interval % 8 == 7:
                    print(json.dumps({"case": case, "steps": steps, "quadrature": order, "intervals_complete": interval + 1}), flush=True)
            for mode in CONFIG["modes"]:
                arrays_out[f"{steps}_{mode}_budget_{order}"] = cumulative[mode]
                arrays_out[f"{steps}_{mode}_direct_integral_{order}"] = integrated_direct[mode]
        for mode in CONFIG["modes"]:
            fine = arrays_out[f"{steps}_{mode}_budget_16"]
            coarse = arrays_out[f"{steps}_{mode}_budget_8"]
            target = arrays_out[f"{steps}_{mode}_endpoint_source"]
            budget = np.sum(fine, axis=1)
            no_euler = np.sum(fine[:, :-1], axis=1)
            allowance = np.sum(abs(fine - coarse), axis=1)
            direct_integral = arrays_out[f"{steps}_{mode}_direct_integral_16"]
            checks = {}
            for channel, name in enumerate(("density", "current")):
                checks[name + "_with_contacts"] = check_ratio(maxabs(target[:, channel] - budget[:, channel]) + maxabs(allowance[:, channel]), scale[channel], GATE)
                checks[name + "_without_reconstruction_contact"] = check_ratio(maxabs(target[:, channel] - no_euler[:, channel]) + maxabs(allowance[:, channel]), scale[channel], GATE)
                checks[name + "_independent_endpoint_integral"] = check_ratio(maxabs(target[:, channel] - direct_integral[:, channel]) + maxabs(allowance[:, channel]), scale[channel], GATE)
            report["modes"][f"{steps}_{mode}"] = {
                "checks": checks, "final_endpoint_change": target[-1].tolist(),
                "final_budget": {name: fine[-1, index].tolist() for index, name in enumerate(TERMS)},
                "maximum_quadrature_allowance": np.max(allowance, axis=0).tolist(),
                "maximum_reconstruction_contact": np.max(abs(fine[:, -1]), axis=0).tolist(),
            }

    native = EX.load(HISTORY / (case + "-validation-capture.npz"))["packet"][901:]
    if len(native) != len(elapsed):
        raise RuntimeError("Unexpected independent boundary coverage")
    native_balance = []
    native_scale = []
    for index, packet in enumerate(native):
        wave = packet[14:15]
        dummy = {"wave": wave, "density0": prepared["density0"], "cold_normalization": prepared["cold_normalization"]}
        values = {"scale": packet[1:2], "rate": packet[2:3], "hubble": packet[4:5], "cold_constant": background.constants[0]}
        if case == "heavy":
            field, velocity, field_n, velocity_n, _, _, mass = packet[32:39]
            values["jets"] = [None, (np.array([field]), np.array([velocity]), packet[2] * np.array([field_n]), packet[2] * np.array([velocity_n]), None, None, np.array([mass]))]
            state = np.array([[packet[39], packet[40], packet[10]]])
            derivative = np.array([[packet[41], packet[42], packet[9] / 2]])
            independent = EX.metric.primitive.field_sources(packet[None, :], float(prepared["density0"]))["first"][:, :2]
        else:
            state = np.array([[packet[63], packet[10]]])
            derivative = np.array([[-packet[14] * packet[6], packet[9] / 2]])
            independent = np.array([[float(prepared["cold_normalization"]) * derivative[0, 0], 0]])
        external = EX.source_jet(packet[None, :], case)[:, 0]
        item = observed(case, state, derivative, values, external, dummy)
        native_balance.append((independent - np.sum(item["terms"], axis=1))[0])
        native_scale.append((abs(independent) + np.sum(abs(item["terms"]), axis=1))[0])
    for channel, name in enumerate(("density", "current")):
        report["checks"]["native_boundary_" + name] = check_ratio(maxabs(np.array(native_balance)[:, channel]), maxabs(np.array(native_scale)[:, channel]), ALGEBRA)
    arrays_out["native_boundary_balance"] = np.array(native_balance)
    report["checks"]["saved_step_budget_refinement"] = check_ratio(
        max(maxabs(arrays_out[f"64_{mode}_budget_16"] - arrays_out[f"32_{mode}_budget_16"]) for mode in CONFIG["modes"]),
        maxabs(scale), GATE)
    report["passed"] = all(value["passed"] for value in report["checks"].values()) and all(
        value["passed"] for mode in report["modes"].values() for value in mode["checks"].values())
    report["algebra_tolerance"] = ALGEBRA
    report["observable_tolerance"] = GATE
    report["report_count"] = len(elapsed)
    report["preparation_nodes"] = len(weights)
    report["scope"] = "Own subsystem exchange with environment; actual background and interpolation Euler contacts retained; no all-species closure."
    report["input_files"] = len(read(ROOT / "inputs.json"))
    return report, arrays_out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=CONFIG["cases"])
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    label = args.case + ("-replay" if args.replay else "-run")
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(), "utc": utc(), "affinity": process.cpu_affinity(), "priority": "below-normal"}
    write(ROOT / (label + "-start.json"), identity)
    try:
        expected = freeze_inputs()
        report, arrays = solve_case(args.case)
        verify_inputs(expected)
        if args.replay:
            if read(ROOT / (args.case + "-result.json")) != report:
                raise RuntimeError("Report replay differs")
            with np.load(ROOT / (args.case + "-balance.npz"), allow_pickle=False) as saved:
                if set(saved.files) != set(arrays) or not all(np.array_equal(saved[key], value) for key, value in arrays.items()):
                    raise RuntimeError("Budget replay differs")
            write(ROOT / (args.case + "-replay.json"), {"passed": report["passed"], "report_exact": True, "arrays_exact": True})
        else:
            write(ROOT / (args.case + "-result.json"), report)
            if (ROOT / (args.case + "-balance.npz")).exists():
                raise FileExistsError("Never overwrite a budget")
            np.savez_compressed(ROOT / (args.case + "-balance.npz"), **arrays)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        write(ROOT / (label + "-end.json"), {**identity, "completed": True, "passed": report["passed"], "elapsed_seconds": time.monotonic() - START, "inputs_unchanged": True})
        print(json.dumps({"case": args.case, "passed": report["passed"], "checks": len(report["checks"])}), flush=True)
        return 0 if report["passed"] else 1
    except BaseException as failure:
        write(ROOT / (label + "-failure.json"), {**identity, "completed": False, "error": repr(failure), "utc_end": utc()})
        raise


if __name__ == "__main__":
    raise SystemExit(main())

