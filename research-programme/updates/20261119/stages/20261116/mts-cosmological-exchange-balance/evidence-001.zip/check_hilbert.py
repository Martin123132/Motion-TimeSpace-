import argparse
from pathlib import Path
import sys

import numpy as np
import psutil

import run_balance as BAL

ROOT = Path(__file__).resolve().parent


def run():
    checks, diagnostics, outputs = {}, {}, {}
    for case in BAL.CONFIG["cases"]:
        prepared, history, background, _, _ = BAL.EX.problem(case)
        reference = BAL.EX.load(BAL.HISTORY / (case + "-comparison.npz"))
        scale = reference["reference_scale"]
        for steps in BAL.CONFIG["saved_steps"]:
            saved = BAL.EX.load(BAL.HISTORY / (case + f"-extended-{steps}.npz"))
            for mode, (state_key, _) in BAL.MODE_KEYS.items():
                corrections, increments, force_shifts, current_shifts = [], [], [], []
                initial_correction = None
                errors, magnitudes = [], []
                for index, offset in enumerate(prepared["elapsed"]):
                    BAL.guard()
                    state = saved[state_key][index]
                    values = background.evaluate(prepared["times"] + offset)
                    values["cold_constant"] = background.constants[0]
                    matrix, _, forcing, _ = BAL.EX.metric.geometry(case, offset, prepared, background)
                    source = BAL.sources(history, offset)[mode][0]
                    derivative = BAL.rhs(matrix, forcing, state, source)
                    original = BAL.observed(case, state, derivative, values, source, prepared)
                    if case == "cold":
                        correction = np.zeros((len(state), 3))
                        force_shift = np.zeros(len(state))
                        current_shift = np.zeros(len(state))
                        error = np.zeros(2)
                        magnitude = np.zeros(2)
                    else:
                        field, velocity, actual_velocity, velocity_prime, field_second, _, mass = values["jets"][1]
                        displacement, speed = state[:, 0], state[:, 1]
                        actual_speed, acceleration = derivative[:, 0], derivative[:, 1]
                        beta = values["scale"] / float(prepared["density0"])
                        rate, wave, force = values["rate"], prepared["wave"], original["force"]
                        kinetic = actual_velocity * actual_speed
                        potential = mass * field * displacement
                        bare = np.column_stack((kinetic + potential, wave * actual_velocity * displacement, kinetic - potential))
                        covariant = beta[:, None] * bare
                        kinetic_prime = field_second * actual_speed + actual_velocity * acceleration
                        potential_prime = 2 * rate * potential + mass * (actual_velocity * displacement + field * actual_speed)
                        bare_prime = np.column_stack((kinetic_prime + potential_prime,
                            wave * (field_second * displacement + actual_velocity * actual_speed),
                            kinetic_prime - potential_prime))
                        derivative_source = beta[:, None] * (bare_prime + rate[:, None] * bare)
                        background_euler = field_second + 2 * rate * actual_velocity + mass * field
                        field_euler = acceleration + 2 * rate * actual_speed + (mass + wave ** 2) * displacement + wave * actual_velocity * force
                        left = np.column_stack((
                            derivative_source[:, 0] + 3 * rate * covariant[:, 2] + wave * covariant[:, 1] + beta * wave * actual_velocity ** 2 * force,
                            derivative_source[:, 1] + rate * covariant[:, 1] - wave * covariant[:, 2]))
                        right = beta[:, None] * np.column_stack((background_euler * actual_speed + actual_velocity * field_euler,
                                                                 wave * background_euler * displacement))
                        field_defect = actual_velocity - velocity
                        correction = beta[:, None] * np.column_stack((field_defect * speed, wave * field_defect * displacement, field_defect * speed))
                        reconstructed_correction = covariant - original["source"]
                        reconstruction_error = BAL.maxabs(reconstructed_correction - correction)
                        reconstruction_scale = BAL.maxabs(covariant) + BAL.maxabs(original["source"])
                        key = f"{case}_{steps}_{mode}_source_chain"
                        previous = checks.get(key, {"error": 0, "scale": 0})
                        checks[key] = BAL.check_ratio(max(previous["error"], reconstruction_error), max(previous["scale"], reconstruction_scale), BAL.ALGEBRA)
                        force_shift = field_defect * speed / (2 * wave * values["hubble"])
                        current_shift = wave * field_defect * displacement / 2
                        error = np.max(abs(left - right), axis=0)
                        magnitude = np.max(abs(left) + abs(right) + abs(derivative_source[:, :2]), axis=0)
                    corrections.append(BAL.EX.weighted(prepared["weights"], correction))
                    if initial_correction is None:
                        initial_correction = correction.copy()
                    increments.append(BAL.EX.weighted(prepared["weights"], correction - initial_correction))
                    force_shifts.append(BAL.maxabs(force_shift))
                    current_shifts.append(BAL.maxabs(current_shift))
                    errors.append(error)
                    magnitudes.append(magnitude)
                key = f"{case}_{steps}_{mode}"
                corrections = np.array(corrections)
                increments = np.array(increments)
                outputs[key + "_correction"] = corrections
                outputs[key + "_increment"] = increments
                for channel, name in enumerate(("density", "current")):
                    checks[key + "_" + name + "_hilbert_identity"] = BAL.check_ratio(
                        float(np.max(np.array(errors)[:, channel])), float(np.max(np.array(magnitudes)[:, channel])), BAL.ALGEBRA)
                channel_diagnostics = {}
                for channel, name in enumerate(("density", "current", "pressure")):
                    diagnostic = BAL.check_ratio(BAL.maxabs(increments[:, channel]), float(scale[channel]), BAL.GATE)
                    if mode == "history":
                        consumed = abs(reference["residual"][:, channel]) + reference["numerical_budget"][:, channel]
                        diagnostic["remaining_margin_passed"] = bool(np.all(abs(increments[:, channel]) + consumed <= BAL.GATE * scale[channel]))
                        diagnostic["maximum_fraction_of_remaining_margin"] = float(np.max(np.divide(
                            abs(increments[:, channel]), np.maximum(BAL.GATE * scale[channel] - consumed, np.finfo(float).tiny)
                        ))) if scale[channel] else None
                    channel_diagnostics[name] = diagnostic
                diagnostics[key] = {
                    "channels": channel_diagnostics,
                    "final_increment": increments[-1].tolist(),
                    "maximum_force_constraint_shift": max(force_shifts),
                    "maximum_eta_rate_shift": max(current_shifts),
                    "applied_to_history": False,
                }
    result = {
        "identities_passed": all(item["passed"] for item in checks.values()), "checks": checks,
        "diagnostics": diagnostics, "quantum_measure_included": False,
        "corrected_evolution_run": False, "source_change_promoted": False,
        "note": "A finite Hilbert-source correction is measured, not inserted. Budget failure is retained separately from identity acceptance.",
    }
    return result, outputs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    name = "hilbert-replay" if args.replay else "hilbert"
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(), "utc": BAL.utc()}
    BAL.write(ROOT / (name + "-start.json"), identity)
    try:
        inputs = BAL.read(ROOT / "inputs.json")
        BAL.verify_inputs(inputs)
        frozen = {str(ROOT / file): BAL.digest(ROOT / file) for file in ("check_hilbert.py", "HILBERT-READOUT.md")}
        if args.replay:
            if frozen != BAL.read(ROOT / "hilbert-inputs.json"):
                raise RuntimeError("Hilbert code changed")
        else:
            BAL.write(ROOT / "hilbert-inputs.json", frozen)
        result, arrays = run()
        BAL.verify_inputs(inputs)
        if args.replay:
            if result != BAL.read(ROOT / "hilbert-result.json"):
                raise RuntimeError("Hilbert report replay differs")
            with np.load(ROOT / "hilbert-readout.npz", allow_pickle=False) as saved:
                if set(saved.files) != set(arrays) or not all(np.array_equal(saved[key], value) for key, value in arrays.items()):
                    raise RuntimeError("Hilbert array replay differs")
            BAL.write(ROOT / "hilbert-replay.json", {"passed": result["identities_passed"], "report_exact": True, "arrays_exact": True})
        else:
            BAL.write(ROOT / "hilbert-result.json", result)
            np.savez_compressed(ROOT / "hilbert-readout.npz", **arrays)
        BAL.write(ROOT / (name + "-end.json"), {**identity, "completed": True, "passed": result["identities_passed"]})
        print(__import__("json").dumps({"identities_passed": result["identities_passed"],
             "heavy_history": result["diagnostics"]["heavy_64_history"]}), flush=True)
        return 0 if result["identities_passed"] else 1
    except BaseException as failure:
        BAL.write(ROOT / (name + "-failure.json"), {**identity, "completed": False, "error": repr(failure)})
        raise


if __name__ == "__main__":
    raise SystemExit(main())

