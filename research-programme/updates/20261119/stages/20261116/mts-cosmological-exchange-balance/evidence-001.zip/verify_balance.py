import argparse
import csv
from pathlib import Path

import numpy as np
import psutil

import run_balance as BAL

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    name = "verification-replay" if args.replay else "verification"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    identity = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(), "utc": BAL.utc()}
    BAL.write(ROOT / (name + "-start.json"), identity)
    try:
        inputs = BAL.read(ROOT / "inputs.json")
        BAL.verify_inputs(inputs)
        for path, expected in BAL.read(ROOT / "hilbert-inputs.json").items():
            if BAL.digest(path) != expected:
                raise RuntimeError("Hilbert source changed")
        checks, report_rows, counts = {}, [], {}
        for case in BAL.CONFIG["cases"]:
            report = BAL.read(ROOT / (case + "-result.json"))
            replay = BAL.read(ROOT / (case + "-replay.json"))
            checks[case + "_exchange_checks"] = report["passed"]
            checks[case + "_cached_replay"] = replay["passed"] and replay["report_exact"] and replay["arrays_exact"]
            counts[case] = len(report["checks"]) + sum(len(value["checks"]) for value in report["modes"].values())
            with np.load(ROOT / (case + "-balance.npz"), allow_pickle=False) as saved:
                checks[case + "_finite_saved_arrays"] = all(np.isfinite(saved[key]).all() for key in saved.files)
                scales = saved["reference_scale"]
                for mode in BAL.CONFIG["modes"]:
                    fine, coarse = saved[f"64_{mode}_budget_16"], saved[f"32_{mode}_budget_16"]
                    for channel, label in enumerate(("density", "current")):
                        error = BAL.maxabs(fine[:, :, channel] - coarse[:, :, channel])
                        value = BAL.check_ratio(error, scales[channel], BAL.GATE)
                        checks[f"{case}_{mode}_{label}_step_refinement"] = value["passed"]
                        report_rows.append({"category": "step_refinement", "case": case, "mode": mode,
                                            "channel": label, **value})
                for channel, label in enumerate(("density", "current")):
                    source_scale = BAL.maxabs(saved["64_difference_endpoint_source"][:, channel])
                    metric = report["modes"]["64_difference"]["checks"][label + "_with_contacts"]
                    value = BAL.check_ratio(metric["error"], source_scale, BAL.GATE)
                    checks[case + "_" + label + "_correction_relative_balance"] = value["passed"]
                    report_rows.append({"category": "correction_relative_balance", "case": case,
                                        "mode": "difference", "channel": label, **value})
                history = report["modes"]["64_history"]
                for label in ("density", "current"):
                    report_rows.append({"category": "integrated_exchange", "case": case,
                                        "mode": "history", "channel": label, **history["checks"][label + "_with_contacts"]})
        hilbert = BAL.read(ROOT / "hilbert-result.json")
        hilbert_replay = BAL.read(ROOT / "hilbert-replay.json")
        checks["hilbert_identities"] = hilbert["identities_passed"]
        checks["hilbert_cached_replay"] = hilbert_replay["passed"] and hilbert_replay["report_exact"] and hilbert_replay["arrays_exact"]
        hilbert_budget = {}
        with np.load(ROOT / "hilbert-readout.npz", allow_pickle=False) as saved:
            for case in BAL.CONFIG["cases"]:
                increments = saved[case + "_64_history_increment"]
                comparison = BAL.EX.load(BAL.HISTORY / (case + "-comparison.npz"))
                scope = hilbert["diagnostics"][case + "_64_history"]["channels"]
                for channel, label in enumerate(("density", "current", "pressure")):
                    diagnostic = scope[label]
                    target_index = int(np.argmax(abs(increments[:, channel])))
                    initial_limit = BAL.GATE * float(comparison["reference_scale"][channel])
                    remaining = initial_limit - abs(comparison["residual"][:, channel]) - comparison["numerical_budget"][:, channel]
                    endpoint_source_allowance = float(comparison["final_source_allowance"][channel])
                    final_limit = float(remaining[-1]) - endpoint_source_allowance
                    record = {
                        **diagnostic, "maximum_report_epoch": BAL.CONFIG["epoch_range"][0] + target_index,
                        "absolute_source_gate": initial_limit,
                        "maximum_increment": float(increments[target_index, channel]),
                        "final_remaining_after_source_allowance": final_limit,
                        "final_with_source_allowance_passed": bool(abs(increments[-1, channel]) <= final_limit),
                        "promoted": False,
                    }
                    hilbert_budget[case + "_" + label] = record
                    report_rows.append({"category": "hilbert_increment_diagnostic", "case": case,
                                        "mode": "history", "channel": label,
                                        **{key: diagnostic[key] for key in ("error", "scale", "relative", "tolerance", "passed")}})
        checks["no_quantum_measure"] = not hilbert["quantum_measure_included"]
        checks["no_corrected_evolution"] = not hilbert["corrected_evolution_run"] and not hilbert["source_change_promoted"]
        for file in ROOT.rglob("*.py"):
            compile(file.read_text(encoding="utf-8"), str(file), "exec")
        checks["no_pycache"] = not any(ROOT.rglob("__pycache__"))
        checks = {key: bool(value) for key, value in checks.items()}
        result = {
            "completed": True, "verification_checks_passed": all(checks.values()),
            "exchange_checks_passed": all(BAL.read(ROOT / (case + "-result.json"))["passed"] for case in BAL.CONFIG["cases"]),
            "hilbert_pressure_budget_passed": hilbert_budget["heavy_pressure"]["passed"],
            "status": "exchange-verified; canonical-to-Hilbert pressure increment exceeds saved budget",
            "checks": checks, "exchange_check_counts": counts, "hilbert_identity_checks": len(hilbert["checks"]),
            "hilbert_budget": hilbert_budget,
            "frozen_input_count": len(inputs), "code_sha256": BAL.digest(Path(__file__)),
            "physical_history_modified": False, "quantum_measure_included": False,
            "all_species_conservation_claimed": False, "corrected_source_promoted": False,
        }
        if args.replay:
            if result != BAL.read(ROOT / "verification.json"):
                raise RuntimeError("Verification replay differs")
            with (ROOT / "summary.csv").open(newline="", encoding="utf-8") as stream:
                if len(list(csv.DictReader(stream))) != len(report_rows):
                    raise RuntimeError("Summary row count differs")
            BAL.write(ROOT / "verification-replay.json", result)
        else:
            BAL.write(ROOT / "verification.json", result)
            with (ROOT / "summary.csv").open("x", newline="", encoding="utf-8") as stream:
                writer = csv.DictWriter(stream, fieldnames=["category", "case", "mode", "channel", "error", "scale", "relative", "tolerance", "passed"])
                writer.writeheader()
                writer.writerows(report_rows)
        BAL.verify_inputs(inputs)
        BAL.write(ROOT / (name + "-end.json"), {**identity, "completed": True, "verification_checks_passed": result["verification_checks_passed"]})
        print(__import__("json").dumps({
            "verification_checks_passed": result["verification_checks_passed"],
            "counts": counts, "hilbert_checks": len(hilbert["checks"]),
            "failed_checks": [key for key, value in checks.items() if not value],
            "heavy_pressure": hilbert_budget["heavy_pressure"],
            "frozen_input_count": len(inputs),
        }), flush=True)
        return 0 if result["verification_checks_passed"] else 1
    except BaseException as failure:
        BAL.write(ROOT / (name + "-failure.json"), {**identity, "completed": False, "error": repr(failure)})
        raise


if __name__ == "__main__":
    raise SystemExit(main())

