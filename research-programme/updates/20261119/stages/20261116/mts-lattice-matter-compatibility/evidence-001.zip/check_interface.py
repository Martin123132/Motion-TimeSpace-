from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
from itertools import combinations
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    sources = json.loads((ROOT / "sources.json").read_text(encoding="utf-8"))
    checks = {}
    for entry in sources["local_inputs"]:
        path = Path(entry["path"])
        checks["input_unchanged:" + path.name] = (
            path.is_file()
            and path.stat().st_size == entry["bytes"]
            and digest(path) == entry["sha256"]
        )

    fields = [
        ("Q", 3, 2, 1, 1, 1),
        ("uc", 3, 1, -1, 0, -4),
        ("dc", 3, 1, -1, 0, 2),
        ("L", 1, 2, 0, 1, -3),
        ("ec", 1, 1, 0, 0, 6),
        ("Higgs", 1, 2, 0, 1, 3),
    ]
    center_exponents = {}
    for name, color_dim, weak_dim, triality, parity, charge in fields:
        exponent = Fraction(triality, 3) + Fraction(parity, 2) + Fraction(charge, 6)
        center_exponents[name] = str(exponent)
        for quotient in (1, 2, 3, 6):
            checks[f"center:{name}:Z{quotient}"] = (
                exponent * (6 // quotient)
            ).denominator == 1
    fermions = fields[:-1]
    charges = {row[0]: Fraction(row[5], 6) for row in fields}
    anomaly = {
        "color_cubic": Fraction(2 - 1 - 1),
        "color_squared_Y": 2 * charges["Q"] + charges["uc"] + charges["dc"],
        "weak_squared_Y": 3 * charges["Q"] + charges["L"],
        "Y_cubic": sum(
            color_dim * weak_dim * Fraction(charge, 6) ** 3
            for _, color_dim, weak_dim, _, _, charge in fermions
        ),
        "gravity_squared_Y": sum(
            color_dim * weak_dim * Fraction(charge, 6)
            for _, color_dim, weak_dim, _, _, charge in fermions
        ),
    }
    for name, value in anomaly.items():
        checks["anomaly:" + name] = value == 0
    weak_doublets = sum(row[1] for row in fermions if row[2] == 2)
    checks["ordinary_SU2_even_doublets"] = weak_doublets == 4
    checks["up_yukawa"] = charges["Q"] + charges["uc"] + charges["Higgs"] == 0
    checks["down_yukawa"] = charges["Q"] + charges["dc"] - charges["Higgs"] == 0
    checks["lepton_yukawa"] = charges["L"] + charges["ec"] - charges["Higgs"] == 0
    checks["fifteen_Weyl_components"] = sum(row[1] * row[2] for row in fermions) == 15
    checks["three_generations_fortyfive"] = 3 * sum(
        row[1] * row[2] for row in fermions
    ) == 45

    cubic_fundamental = [1, 1, -2, 0, 0]
    cubic_weights = [
        left + right for left, right in combinations(cubic_fundamental, 2)
    ] + [-value for value in cubic_fundamental]
    checks["SU5_10_plus_bar5_cubic"] = sum(value ** 3 for value in cubic_weights) == 0
    subgroup_fundamental = [1, -1, 0, 0, 0]
    subgroup_weights = [
        left + right for left, right in combinations(subgroup_fundamental, 2)
    ] + [-value for value in subgroup_fundamental]
    multiplicities = Counter(subgroup_weights)
    checks["SU5_subgroup_four_doublets"] = (
        multiplicities[1] == multiplicities[-1] == 4
        and multiplicities[0] == 7
        and set(multiplicities) == {-1, 0, 1}
    )

    numerical = POST / "mts-longer-window-second-eight-20261116"
    batch = json.loads((numerical / "batch-result.json").read_text(encoding="utf-8"))
    validation = json.loads((numerical / "validation.json").read_text(encoding="utf-8"))
    cleanup = json.loads((numerical / "CLEANUP-VERIFIED.json").read_text(encoding="utf-8"))
    checks["numerical_selected_window_complete"] = (
        batch["passed"] and batch["completed"]
        and batch["selected_longer_window_complete"]
        and batch["first_batch"] == [2917, 2924] and batch["reports"] == 33
        and batch["remaining_batch"] == [] and not batch["next_batch_started"]
    )
    checks["numerical_validation"] = (
        validation["passed"] and len(validation["checks"]) == 56
        and all(value is True for value in validation["checks"].values())
    )
    checks["old_diagnostics_retained"] = (
        batch["raw_failure_receipts_preserved"]
        and batch["raw_node_superposition_passed"] is False
        and batch["saved25_reports_preserved"]
    )
    checks["numerical_cleanup"] = (
        cleanup["passed"] and cleanup["artifacts_verified"] == 121
        and cleanup["inputs_verified"] == 518
        and all(worker["outcome"]["exited"] for worker in cleanup["workers"])
    )
    checks["script_syntax"] = bool(compile(
        Path(__file__).read_text(encoding="utf-8"), str(__file__), "exec"
    ))
    checks["no_pycache"] = not any(ROOT.rglob("__pycache__"))
    outcome = {
        "passed": all(checks.values()),
        "utc": datetime.now(timezone.utc).isoformat(),
        "pid": os.getpid(),
        "command": [sys.executable, "-B", str(Path(__file__).resolve())],
        "scope": "Exact representation arithmetic and source integrity only; not external theorem verification",
        "checks": checks,
        "check_count": len(checks),
        "center_exponents": center_exponents,
        "anomaly_sums": {name: str(value) for name, value in anomaly.items()},
        "SU5_subgroup_weights": dict(sorted(multiplicities.items())),
        "source_document_sha256": digest(ROOT / "sources.json"),
    }
    (ROOT / "checks.json").write_text(
        json.dumps(outcome, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "passed": outcome["passed"], "checks": len(checks), "pid": os.getpid()
    }))
    return 0 if outcome["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
