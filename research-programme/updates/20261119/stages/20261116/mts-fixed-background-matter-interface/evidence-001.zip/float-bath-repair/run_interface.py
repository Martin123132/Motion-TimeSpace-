import os

for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"

import argparse
from datetime import datetime, timezone
import hashlib
from itertools import product
import json
from pathlib import Path
import sys
import time

import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
FIELDS = {"Q": (3, 2, 1), "uc": (-3, 1, -4), "dc": (-3, 1, 2), "L": (1, 2, -3), "ec": (1, 1, 6)}
CONFIG = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
COORDS = list(product(*(range(size) for size in CONFIG["lattice_shape"])))
INDEX = {coord: index for index, coord in enumerate(COORDS)}
STARTED = time.monotonic()


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def error(actual, expected):
    return float(np.linalg.norm(actual - expected) / max(1.0, np.linalg.norm(actual), np.linalg.norm(expected)))


def guard():
    if time.monotonic() - STARTED > CONFIG["worker_timeout_seconds"]:
        raise TimeoutError("Frozen bounded worker deadline reached")


def shift(site, direction):
    coord = list(COORDS[site])
    crossed = coord[direction] == CONFIG["lattice_shape"][direction] - 1
    coord[direction] = (coord[direction] + 1) % CONFIG["lattice_shape"][direction]
    return INDEX[tuple(coord)], crossed


def special_unitary(rng, dimension, scale):
    raw = rng.normal(size=(dimension, dimension)) + 1j * rng.normal(size=(dimension, dimension))
    hermitian = (raw + raw.conj().T) / 2
    hermitian -= np.trace(hermitian) * np.eye(dimension) / dimension
    values, vectors = np.linalg.eigh(hermitian)
    return (vectors * np.exp(1j * scale * values)) @ vectors.conj().T


def representation(color, weak, phase, label):
    color_dim, weak_dim, charge = FIELDS[label] if isinstance(label, str) else label
    color_rep = color if color_dim == 3 else color.conj() if color_dim == -3 else np.ones((1, 1))
    weak_rep = weak if weak_dim == 2 else np.ones((1, 1))
    return np.kron(color_rep, weak_rep) * phase ** charge


def generators():
    pauli = [
        np.array([[0, 1], [1, 0]], complex),
        np.array([[0, -1j], [1j, 0]], complex),
        np.diag([1, -1]).astype(complex),
    ]
    zero = np.zeros((2, 2), complex)
    unit = np.eye(2, dtype=complex)
    gamma = [np.block([[zero, -1j * sigma], [1j * sigma, zero]]) for sigma in pauli]
    gamma.append(np.block([[zero, unit], [unit, zero]]))
    chirality = gamma[0] @ gamma[1] @ gamma[2] @ gamma[3]
    conjugation = gamma[1] @ gamma[3]
    return gamma, chirality, conjugation


GAMMA, GAMMA5, CHARGE_C = generators()


def fixture(seed):
    rng = np.random.default_rng(seed)
    count = len(COORDS)
    arrays = {
        "color": np.array([[special_unitary(rng, 3, CONFIG["link_amplitude"]) for _ in range(4)] for _ in COORDS]),
        "weak": np.array([[special_unitary(rng, 2, CONFIG["link_amplitude"]) for _ in range(4)] for _ in COORDS]),
        "phase": np.exp(1j * CONFIG["link_amplitude"] * rng.uniform(-1, 1, (count, 4))),
        "gcolor": np.array([special_unitary(rng, 3, CONFIG["gauge_amplitude"]) for _ in COORDS]),
        "gweak": np.array([special_unitary(rng, 2, CONFIG["gauge_amplitude"]) for _ in COORDS]),
        "gphase": np.exp(1j * rng.uniform(-np.pi, np.pi, count)),
        "higgs": rng.normal(size=(count, 2)) + 1j * rng.normal(size=(count, 2)),
        "neutral": rng.normal(size=(count, 3)),
    }
    for label, (color_dim, weak_dim, _) in FIELDS.items():
        dimension = count * 4 * abs(color_dim) * weak_dim
        arrays["eta_" + label] = (rng.normal(size=dimension) + 1j * rng.normal(size=dimension)) / np.sqrt(dimension)
        arrays["bar_" + label] = (rng.normal(size=dimension) + 1j * rng.normal(size=dimension)) / np.sqrt(dimension)
    return arrays


def transformed(arrays):
    result = {name: value.copy() for name, value in arrays.items()}
    for site in range(len(COORDS)):
        for direction in range(4):
            other, _ = shift(site, direction)
            result["color"][site, direction] = arrays["gcolor"][site] @ arrays["color"][site, direction] @ arrays["gcolor"][other].conj().T
            result["weak"][site, direction] = arrays["gweak"][site] @ arrays["weak"][site, direction] @ arrays["gweak"][other].conj().T
            result["phase"][site, direction] = arrays["gphase"][site] * arrays["phase"][site, direction] * arrays["gphase"][other].conjugate()
        result["higgs"][site] = arrays["gphase"][site] ** 3 * arrays["gweak"][site] @ arrays["higgs"][site]
    return result


def block_diagonal(blocks):
    size = blocks[0].shape[0]
    result = np.zeros((len(blocks) * size, len(blocks) * size), complex)
    for index, block in enumerate(blocks):
        result[index * size:(index + 1) * size, index * size:(index + 1) * size] = block
    return result


def gauge_matrix(arrays, label):
    return block_diagonal([
        np.kron(np.eye(4), representation(arrays["gcolor"][site], arrays["gweak"][site], arrays["gphase"][site], label))
        for site in range(len(COORDS))
    ])


def operator(arrays, label):
    guard()
    color_dim, weak_dim, _ = FIELDS[label]
    internal = abs(color_dim) * weak_dim
    size = len(COORDS) * 4 * internal
    unit = np.eye(size, dtype=complex)
    wilson = 4 * unit
    spin_gamma5 = np.kron(np.eye(len(COORDS)), np.kron(GAMMA5, np.eye(internal)))
    for site in range(len(COORDS)):
        source = slice(site * 4 * internal, (site + 1) * 4 * internal)
        for direction in range(4):
            other, crossed = shift(site, direction)
            target = slice(other * 4 * internal, (other + 1) * 4 * internal)
            boundary = CONFIG["fermion_boundary_signs"][direction] if crossed else 1
            link = boundary * representation(arrays["color"][site, direction], arrays["weak"][site, direction], arrays["phase"][site, direction], label)
            wilson[source, target] += 0.5 * np.kron(GAMMA[direction] - np.eye(4), link)
            wilson[target, source] += 0.5 * np.kron(-GAMMA[direction] - np.eye(4), link.conj().T)
    kernel = spin_gamma5 @ (wilson - unit)
    values, vectors = np.linalg.eigh(kernel)
    spectral_sign = (vectors * np.sign(values)) @ vectors.conj().T
    overlap = unit + spin_gamma5 @ spectral_sign
    return {
        "wilson": wilson, "kernel": kernel, "eigenvalues": values,
        "basis": vectors[:, values > 0], "overlap": overlap,
        "projector": (unit + spectral_sign) / 2,
        "plus": (unit + spin_gamma5) / 2, "gamma5": spin_gamma5,
        "gap": float(np.min(np.abs(values))),
    }


def faithful(color, weak, phase, include_kernel=True):
    size = 6 if include_kernel else 5
    result = np.zeros((size, size), complex)
    result[:3, :3] = phase ** -2 * color
    result[3:5, 3:5] = phase ** 3 * weak
    if include_kernel:
        result[5, 5] = phase
    return result


def plaquettes(arrays):
    maxima = [0.0, 0.0]
    action = 0.0
    for site in range(len(COORDS)):
        for first in range(4):
            for second in range(first + 1, 4):
                next_first, _ = shift(site, first)
                next_second, _ = shift(site, second)
                for variant in range(2):
                    links = [
                        faithful(arrays["color"][where, direction], arrays["weak"][where, direction], arrays["phase"][where, direction], variant == 0)
                        for where, direction in ((site, first), (next_first, second), (next_second, first), (site, second))
                    ]
                    loop = links[0] @ links[1] @ links[2].conj().T @ links[3].conj().T
                    maxima[variant] = max(maxima[variant], float(np.linalg.norm(np.eye(loop.shape[0]) - loop, 2)))
                    if variant == 0:
                        action += float(loop.shape[0] - np.trace(loop).real)
    return maxima, action


def higgs_action(arrays):
    result = 0.0
    for site in range(len(COORDS)):
        for direction in range(4):
            other, _ = shift(site, direction)
            transported = arrays["phase"][site, direction] ** 3 * arrays["weak"][site, direction] @ arrays["higgs"][other]
            result += float(np.vdot(transported - arrays["higgs"][site], transported - arrays["higgs"][site]).real)
    norm = np.sum(np.abs(arrays["higgs"]) ** 2, axis=1)
    return float(result + CONFIG["higgs_mass_squared"] * np.sum(norm) + CONFIG["higgs_quartic"] * np.sum(norm ** 2))


def yukawa(fields, higgs):
    quark = fields["Q"].reshape(len(COORDS), 4, 3, 2)
    up = fields["uc"].reshape(len(COORDS), 4, 3)
    down = fields["dc"].reshape(len(COORDS), 4, 3)
    lepton = fields["L"].reshape(len(COORDS), 4, 2)
    electron = fields["ec"].reshape(len(COORDS), 4)
    epsilon = np.array([[0, 1], [-1, 0]])
    return {
        "up": np.einsum("xaci,ab,xbc,ij,xj->", quark, CHARGE_C, up, epsilon, higgs),
        "down": np.einsum("xaci,ab,xbc,xi->", quark, CHARGE_C, down, higgs.conj()),
        "lepton": np.einsum("xai,ab,xb,xi->", lepton, CHARGE_C, electron, higgs.conj()),
    }


def neutral_action(states):
    mass = np.diag(np.array([CONFIG["bath_mass_squared"]] + CONFIG["bath_frequency_squared"], dtype=float))
    mass[0, 1:] = -np.array(CONFIG["bath_couplings"])
    mass[1:, 0] = mass[0, 1:]
    laplacian = np.zeros((len(COORDS), len(COORDS)))
    action = 0.5 * float(np.einsum("xi,ij,xj->", states, mass, states))
    for site in range(len(COORDS)):
        for direction in range(4):
            other, _ = shift(site, direction)
            difference = states[other] - states[site]
            action += 0.5 * float(difference @ difference)
            laplacian[site, site] += 1
            laplacian[other, other] += 1
            laplacian[site, other] -= 1
            laplacian[other, site] -= 1
    kernel = np.kron(laplacian, np.eye(3)) + np.kron(np.eye(len(COORDS)), mass)
    schur = CONFIG["bath_mass_squared"] - sum(
        coupling ** 2 / frequency
        for coupling, frequency in zip(CONFIG["bath_couplings"], CONFIG["bath_frequency_squared"])
    )
    unstable = mass.copy()
    unstable[0, 0] = sum(
        coupling ** 2 / frequency
        for coupling, frequency in zip(CONFIG["bath_couplings"], CONFIG["bath_frequency_squared"])
    ) - 0.1
    return {
        "action": action,
        "kernel_action": float(0.5 * states.ravel() @ kernel @ states.ravel()),
        "schur": schur,
        "mass_min": float(np.linalg.eigvalsh(mass).min()),
        "kernel_min": float(np.linalg.eigvalsh(kernel).min()),
        "logdet": float(np.linalg.slogdet(kernel)[1]),
        "unstable_min": float(np.linalg.eigvalsh(unstable).min()),
        "actual_couplings": (-mass[0, 1:]).tolist(),
        "mass_determinant": float(np.linalg.det(mass)),
        "schur_determinant": float(np.prod(CONFIG["bath_frequency_squared"]) * schur),
    }


def run_panel(arrays):
    changed = transformed(arrays)
    metrics = {}
    passed = {}

    def check(name, value, limit=None):
        metrics[name] = float(value)
        passed[name] = bool(np.isfinite(value) and value <= (CONFIG["identity_tolerance"] if limit is None else limit))

    def assert_control(name, value, minimum=None):
        metrics[name] = float(value)
        passed[name] = bool(np.isfinite(value) and value >= (CONFIG["negative_control_floor"] if minimum is None else minimum))

    for first in range(4):
        check(f"clifford_{first}", error(GAMMA[first] @ GAMMA[first], np.eye(4)))
        check(f"charge_conjugation_{first}", error(CHARGE_C @ GAMMA[first] @ np.linalg.inv(CHARGE_C), -GAMMA[first].T))
        for second in range(first + 1, 4):
            check(f"clifford_{first}_{second}", np.linalg.norm(GAMMA[first] @ GAMMA[second] + GAMMA[second] @ GAMMA[first]))
    check("charge_antisymmetry", error(CHARGE_C.T, -CHARGE_C))

    original_fields = {}
    changed_fields = {}
    kinetic_original = 0j
    kinetic_changed = 0j
    for label in FIELDS:
        original = operator(arrays, label)
        updated = operator(changed, label)
        gauge = gauge_matrix(arrays, label)
        unit = np.eye(gauge.shape[0])
        for suffix, values in (("before", original), ("after", updated)):
            overlap = values["overlap"]
            projector = values["projector"]
            chirality = values["gamma5"]
            check(label + "_kernel_hermitian_" + suffix, error(values["kernel"], values["kernel"].conj().T))
            check(label + "_GW_" + suffix, error(chirality @ overlap + overlap @ chirality, overlap @ chirality @ overlap))
            check(label + "_projector_" + suffix, error(projector @ projector, projector))
            check(label + "_intertwining_" + suffix, error(overlap @ projector, values["plus"] @ overlap))
            assert_control(label + "_kernel_gap_" + suffix, values["gap"], CONFIG["kernel_gap_floor"])
        check(label + "_gauge_unitary", error(gauge.conj().T @ gauge, unit))
        check(label + "_overlap_covariance", error(updated["overlap"], gauge @ original["overlap"] @ gauge.conj().T))
        check(label + "_projector_covariance", error(updated["projector"], gauge @ original["projector"] @ gauge.conj().T))
        field = original["projector"] @ arrays["eta_" + label]
        field_changed = updated["projector"] @ (gauge @ arrays["eta_" + label])
        check(label + "_projected_field", error(field_changed, gauge @ field))
        original_fields[label] = field
        changed_fields[label] = field_changed
        row = arrays["bar_" + label].conj() @ original["plus"]
        row_changed = (arrays["bar_" + label].conj() @ gauge.conj().T) @ updated["plus"]
        kinetic = row @ original["overlap"] @ field
        kinetic_new = row_changed @ updated["overlap"] @ field_changed
        kinetic_original += kinetic
        kinetic_changed += kinetic_new
        check(label + "_kinetic", error(kinetic, kinetic_new))
        if label == "Q":
            stale = original["projector"] @ (gauge @ arrays["eta_" + label])
            assert_control("negative_stale_projector", error(stale, gauge @ field))
        if label == "L":
            positive_values, positive_vectors = np.linalg.eigh(original["gamma5"])
            row_basis = positive_vectors[:, positive_values > 0].conj().T
            matrix = row_basis @ original["overlap"] @ original["basis"]
            phase, logabs = np.linalg.slogdet(matrix)
            shifted = matrix.copy()
            shifted[:, 0] *= np.exp(0.37j)
            phase_new, logabs_new = np.linalg.slogdet(shifted)
            check("basis_rotation_expected_phase", error(phase_new / phase, np.exp(0.37j)))
            check("basis_rotation_same_log_magnitude", abs(logabs_new - logabs))
            assert_control("basis_rotation_phase_visible", abs(phase_new / phase - 1))
        del original, updated, gauge, unit

    terms = yukawa(original_fields, arrays["higgs"])
    terms_new = yukawa(changed_fields, changed["higgs"])
    for name in terms:
        check("yukawa_" + name, error(terms[name], terms_new[name]))
    incorrect_charge = dict(changed_fields)
    incorrect_charge["uc"] = gauge_matrix(arrays, (-3, 1, -3)) @ original_fields["uc"]
    assert_control("negative_wrong_hypercharge", error(yukawa(incorrect_charge, changed["higgs"])["up"], terms["up"]))
    incorrect_conjugation = dict(changed_fields)
    incorrect_conjugation["uc"] = gauge_matrix(arrays, (3, 1, -4)) @ original_fields["uc"]
    assert_control("negative_wrong_color_conjugation", error(yukawa(incorrect_conjugation, changed["higgs"])["up"], terms["up"]))
    norms, gauge_action = plaquettes(arrays)
    norms_new, gauge_action_new = plaquettes(changed)
    check("faithful_plaquette_guard_before", norms[0], CONFIG["engineering_plaquette_threshold"])
    check("faithful_plaquette_guard_after", norms_new[0], CONFIG["engineering_plaquette_threshold"])
    check("plaquette_gauge_invariance", error(np.array(norms), np.array(norms_new)))
    check("gauge_action", error(gauge_action, gauge_action_new))
    higgs_before, higgs_after = higgs_action(arrays), higgs_action(changed)
    check("higgs_action", error(higgs_before, higgs_after))
    coefficients = [complex(*pair) for pair in CONFIG["yukawa_coefficients"]]
    yukawa_before = sum(value * terms[name] for value, name in zip(coefficients, terms))
    yukawa_after = sum(value * terms_new[name] for value, name in zip(coefficients, terms_new))
    visible_before = gauge_action + higgs_before + kinetic_original + yukawa_before
    visible_after = gauge_action_new + higgs_after + kinetic_changed + yukawa_after
    neutral_before, neutral_after = neutral_action(arrays["neutral"]), neutral_action(changed["neutral"])
    check("baseline_action_sum", error(visible_before, visible_after))
    check("neutral_kernel_matches_edges", error(neutral_before["action"], neutral_before["kernel_action"]))
    check("neutral_fractional_couplings_preserved", error(np.array(neutral_before["actual_couplings"]), np.array(CONFIG["bath_couplings"])))
    check("neutral_schur_determinant", error(neutral_before["mass_determinant"], neutral_before["schur_determinant"]))
    check("neutral_gauge_independence", error(neutral_before["action"], neutral_after["action"]))
    check("MTS_action_sum", error(visible_before + neutral_before["action"], visible_after + neutral_after["action"]))
    assert_control("neutral_positive_schur", neutral_before["schur"], 0.01)
    assert_control("neutral_positive_mass", neutral_before["mass_min"], 0.01)
    assert_control("neutral_positive_kernel", neutral_before["kernel_min"], 0.01)
    assert_control("negative_unstable_bath", -neutral_before["unstable_min"])
    check("scalar_logdet_gauge_independence", abs(neutral_before["logdet"] - neutral_after["logdet"]))
    return {"passed": all(passed.values()), "checks": passed, "metrics": metrics, "neutral": neutral_before}


def independent_controls():
    empty = fixture(0)
    empty["color"][:] = np.eye(3)
    empty["weak"][:] = np.eye(2)
    empty["phase"][:] = 1
    free = operator(empty, "Q")
    predicted = []
    for labels in COORDS:
        momenta = [
            2 * np.pi * (label + (0.5 if boundary == -1 else 0)) / size
            for label, boundary, size in zip(labels, CONFIG["fermion_boundary_signs"], CONFIG["lattice_shape"])
        ]
        energy = np.sqrt(sum(np.sin(momentum) ** 2 for momentum in momenta) + (sum(1 - np.cos(momentum) for momentum in momenta) - 1) ** 2)
        predicted.extend([-energy] * 12 + [energy] * 12)
    spectrum_error = error(np.sort(free["eigenvalues"]), np.sort(predicted))
    empty["color"][0, 0] = np.exp(2j * np.pi / 3) * np.eye(3)
    empty["weak"][0, 0] = -np.eye(2)
    empty["phase"][0, 0] = np.exp(1j * np.pi / 3)
    norms, _ = plaquettes(empty)
    return {
        "passed": bool(spectrum_error < CONFIG["identity_tolerance"] and norms[1] < CONFIG["identity_tolerance"] and norms[0] > CONFIG["engineering_plaquette_threshold"]),
        "free_fourier_spectrum_error": spectrum_error,
        "center_defect_faithful_norm": norms[0],
        "center_defect_image_only_norm": norms[1],
    }


def verify_inputs():
    entries = list(CONFIG["local_inputs"])
    inherited = ROOT.parents[1] / "mts-lattice-matter-compatibility-20261116/sources.json"
    entries.extend(json.loads(inherited.read_text(encoding="utf-8"))["local_inputs"])
    return {
        entry["path"]: Path(entry["path"]).is_file()
        and Path(entry["path"]).stat().st_size == entry["bytes"]
        and sha(Path(entry["path"])) == entry["sha256"]
        for entry in entries
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    name = "replay" if args.replay else "run"
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([allowed[4] if len(allowed) > 4 else allowed[-1]])
    receipt = {"pid": process.pid, "created": process.create_time(), "command": process.cmdline(), "utc": stamp(), "affinity": process.cpu_affinity(), "priority": "below-normal", "threads_requested": 1}
    save(ROOT / (name + "-start.json"), receipt)
    try:
        before = verify_inputs()
        if not all(before.values()):
            raise RuntimeError("A frozen source input changed")
        protocol_hash = sha(ROOT / "protocol.json")
        code_hash = sha(Path(__file__))
        controls = independent_controls()
        reports = []
        for seed in CONFIG["seeds"]:
            guard()
            path = ROOT.parent / f"fixture-{seed}.npz"
            if args.replay:
                with np.load(path, allow_pickle=False) as saved:
                    arrays = {key: saved[key] for key in saved.files}
            else:
                with np.load(path, allow_pickle=False) as saved:
                    arrays = {key: saved[key] for key in saved.files}
            report = run_panel(arrays)
            report["seed"] = seed
            report["fixture_sha256"] = sha(path)
            if args.replay:
                original = json.loads((ROOT / f"panel-{seed}.json").read_text(encoding="utf-8"))
                if report != original:
                    raise RuntimeError("Cached replay differs from saved panel")
            else:
                save(ROOT / f"panel-{seed}.json", report)
            reports.append(report)
            print(json.dumps({"seed": seed, "passed": report["passed"], "checks": len(report["checks"])}), flush=True)
        after = verify_inputs()
        checks_pass = all(report["passed"] for report in reports)
        result = {
            "passed": bool(controls["passed"] and checks_pass and all(after.values())),
            "controls": controls,
            "panels": [{"seed": report["seed"], "passed": report["passed"], "checks": len(report["checks"])} for report in reports],
            "panel_check_count": sum(len(report["checks"]) for report in reports),
            "all_frozen_inputs_unchanged": all(before.values()) and all(after.values()),
            "input_count": len(after),
            "protocol_sha256": protocol_hash,
            "code_sha256": code_hash,
            "external_measure_current_implemented": False,
            "cosmology_changed": False,
            "operator_and_action_covariance_only": True,
        }
        if args.replay:
            original = json.loads((ROOT / "result.json").read_text(encoding="utf-8"))
            if result != original:
                raise RuntimeError("Cached replay differs from overall result")
        save(ROOT / ("replay-result.json" if args.replay else "result.json"), result)
        compile(Path(__file__).read_text(encoding="utf-8"), str(Path(__file__)), "exec")
        save(ROOT / (name + "-end.json"), {"completed": True, "passed": result["passed"], "utc": stamp(), "elapsed_seconds": time.monotonic() - STARTED, "pid": process.pid, "created": process.create_time(), "pycache_absent": not any(ROOT.rglob("__pycache__"))})
        return 0 if result["passed"] else 1
    except BaseException as failure:
        save(ROOT / (name + "-failure.json"), {"completed": False, "utc": stamp(), "error": repr(failure), "pid": process.pid, "created": process.create_time()})
        raise


if __name__ == "__main__":
    raise SystemExit(main())
