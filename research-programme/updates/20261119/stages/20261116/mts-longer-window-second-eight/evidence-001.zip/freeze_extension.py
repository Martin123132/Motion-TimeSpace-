from support import *
import numpy as np

metric=sealed_module('batch_metric',PREVIOUS,'metric_math.py')
with worker('freeze-extension'):
    cleanup=read(LAST/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['external_checker_exit_verified'],'previous cleanup')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'],'previous worker exited')
    require(read(GROWTH/'next-window-contract.json')['acquisition_batches'][1]==[BEGIN_INDEX+1,END_INDEX],'authorized second batch')
    frozen=read(LAST/'frozen-inputs.json')
    for directory in (LAST,):
        seal=read(directory/'closeout.json')
        frozen[str(directory/'closeout.json')]=digest(directory/'closeout.json')
        for name,record in seal['artifacts'].items():
            path=directory/name
            require(path.stat().st_size==record['bytes'] and digest(path)==record['sha256'],'sealed input '+name)
            frozen[str(path)]=record['sha256']
    for case in ('cold','heavy'):
        saved=load(SPECTRUM/'runs/exact-grid/chunk-0384.npz' if case=='heavy' else EARLY/'runs/final-bg8-start/cold.npz')
        clock=saved['conformal_time']
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        reports=clock[ORIGIN_INDEX:END_INDEX+1]
        elapsed=reports-reports[0]
        old_run=load(PREFIX/(case+'-extended-64.npz'))
        require(np.array_equal(elapsed[:PREFIX_COUNT],old_run['elapsed']),'old25 report times unchanged')
        require(np.array_equal(prepared['times'],clock[NODE_FIRST:ORIGIN_INDEX+1]),'same902 initial nodes')
        background=metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        boundaries=np.asarray(background.boundaries(float(clock[BEGIN_INDEX]),float(clock[END_INDEX])))
        boundaries=boundaries[(boundaries>clock[BEGIN_INDEX])&(boundaries<clock[END_INDEX])]
        cells,source_requests=[],[]
        for gap in range(BEGIN_INDEX,END_INDEX):
            left,right=clock[gap:gap+2]
            splits=np.concatenate(([left],boundaries[(boundaries>left)&(boundaries<right)],[right]))
            for part,(begin,end) in enumerate(zip(splits[:-1],splits[1:])):
                index=len(cells)
                cells.append((begin,end,gap,part))
                for fraction in (.25,.5,.75):
                    source_requests.append((begin+fraction*(end-begin),index,fraction,0))
                if begin!=left:
                    offset=min(1e-10,.01*(end-begin))
                    require(offset>=128*np.spacing(begin),'resolvable right offset')
                    source_requests.append((begin+offset,index,0.,1))
                if end!=right:
                    offset=min(1e-10,.01*(end-begin))
                    require(offset>=128*np.spacing(end),'resolvable left offset')
                    source_requests.append((end-offset,index,1.,-1))
        source_requests=np.array(sorted(source_requests))
        query_times=prepared['times'][None,:]+elapsed[PREFIX_COUNT:,None]
        requests=np.unique(np.concatenate((source_requests[:,0],query_times.ravel(),clock[NODE_FIRST+1:END_INDEX+1])))
        require(requests[0]>clock[NODE_FIRST] and requests[-1]<=clock[END_INDEX],'native coverage')
        np.savez_compressed(ROOT/(case+'-extension-plan.npz'),cells=np.array(cells),source_requests=source_requests,query_times=query_times,requests=requests,elapsed=elapsed,report_times=reports,clock=clock[NODE_FIRST:END_INDEX+1],boundaries=boundaries)
        write(case+'-plan-freeze.json',dict(passed=True,sha256=digest(ROOT/(case+'-extension-plan.npz')),new_intervals=8,new_cells=len(cells),native_queries=len(requests),same_physical_grids=True,target_performance_inspected=False))
        print(json.dumps(dict(case=case,new_cells=len(cells),queries=len(requests),duration=float(elapsed[-1]))),flush=True)
    check_hashes(frozen)
    write('frozen-inputs.json',frozen)
    write('protocol-freeze.json',{str(path):digest(path) for path in ROOT.iterdir() if path.suffix in ('.py','.md')})
