from support import *
import argparse
import ast
import ctypes
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
parser.add_argument('phase',choices=('construction','validation'))
args=parser.parse_args()
case,phase=args.case,args.phase
label=case+'-'+phase
comparison=retained_module('extension_capture_comparison','curvature_math.py').comparison

with worker(label+'-capture'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    plan=load(ROOT/(case+'-extension-plan.npz'))
    require(digest(ROOT/(case+'-extension-plan.npz'))==read(ROOT/(case+'-plan-freeze.json'))['sha256'],'frozen query plan')
    probe_times=plan['requests']
    if phase=='validation':
        freeze=read(ROOT/(case+'-source-freeze.json'))
        require(freeze['passed'] and not freeze['new_probe_values_loaded'],'predictions frozen before fresh probes')
        require(digest(ROOT/(case+'-source-frozen.npz'))==freeze['sha256'],'source polynomial frozen')
        prediction=load(ROOT/(case+'-source-frozen.npz'))
        midpoint=(plan['clock'][1:]+plan['clock'][:-1])/2
        probe_times=np.unique(np.concatenate((probe_times,prediction['validation_requests'][:,0],midpoint)))
    probe_times=np.ascontiguousarray(probe_times)
    write(label+'-code-freeze.json',{str(ROOT/name):digest(ROOT/name) for name in ('capture_extension.py','support.py','PROTOCOL.md')})
    build=read(CONTROL/'native-build-result.json')
    local=CONTROL/'native'
    require(build['state']=='completed' and digest(local/'camb/cambdll.dll')==build['dll_sha256'],'retained native DLL')
    sys.path.insert(0,str(local))
    import camb
    from camb.mts import MTSTwoField
    sys.path.append(str(BRANCH/'radiation-and-slow-field-transfer-20261007'))
    import radiation_common
    factory_path=MATCHING/'matching_common.py'
    factory=next(node for node in ast.parse(factory_path.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='params_for')
    namespace=dict(np=np,previous=radiation_common,MTSTwoField=MTSTwoField)
    exec(compile(ast.Module(body=[factory],type_ignores=[]),str(factory_path),'exec'),namespace)
    params=namespace['params_for'](EARLY/'runs/backgrounds'/(case+'.npz'))
    saved=load(SPECTRUM/'runs/exact-grid/chunk-0384.npz' if case=='heavy' else EARLY/'runs/final-bg8-start/cold.npz')
    observer=ctypes.CDLL(str(POST/'mts-metric-feedback-20261107/observer.dll'))
    callback=ctypes.cast(observer.source_func_,ctypes.c_void_p)
    library=ctypes.CDLL(str(local/'camb/cambdll.dll'))
    reset,copy,setup,probe_copy=library.mts_curv_reset,library.mts_current_copy,library.mts_probe_setup,library.mts_probe_copy
    for routine in (reset,copy,setup,probe_copy):
        routine.restype=None
    reset.argtypes=[]
    copy.argtypes=setup.argtypes=probe_copy.argtypes=[ctypes.c_int,ctypes.c_void_p]
    scalar=lambda name:ctypes.c_int.in_dll(library,'mts_curv_'+name)
    native=camb.get_background(params)
    try:
        clock=np.ascontiguousarray(native.conformal_time(1/saved['requested_scale']-1,tol=1e-10))
        require(np.array_equal(clock,saved['conformal_time']),'unchanged original native clock')
        modes=np.ascontiguousarray(saved['modes'])
        selected=int(np.flatnonzero(modes==5.)[0])
        names=list(camb.model.evolve_names)
        native.Params.Accuracy.IntTolBoost=6
        native.Params.Accuracy.lAccuracyBoost=4
        output=np.zeros((len(modes),len(clock),len(names)+30))
        reset()
        scalar('begin').value=1992
        scalar('end').value=END_INDEX+1
        scalar('target').value=selected+1
        setup(len(probe_times),ctypes.c_void_p(probe_times.ctypes.data))
        code=camb.results.CAMB_TimeEvolution(ctypes.byref(native),ctypes.byref(ctypes.c_int(len(modes))),modes,ctypes.byref(ctypes.c_int(len(clock))),clock,ctypes.byref(ctypes.c_int(output.shape[-1])),output,ctypes.byref(ctypes.c_int(30)),ctypes.byref(callback))
        require(code==0 and scalar('status').value==2 and scalar('count').value==NEW_PACKETS,'extended native capture complete')
        require(ctypes.c_int.in_dll(library,'mts_probe_status').value==2 and ctypes.c_int.in_dll(library,'mts_probe_count').value==len(probe_times),'state-copy queries complete')
        packet=np.zeros((NEW_PACKETS,224))
        copy(NEW_PACKETS,ctypes.c_void_p(packet.ctypes.data))
        require(np.array_equal(packet[:OLD_PACKETS],load(PREFIX/(case+'-validation-capture.npz'))['packet']),'old926 packets byte-identical')
        probes=np.zeros((len(probe_times),224))
        probe_copy(len(probe_times),ctypes.c_void_p(probes.ctypes.data))
        require(np.array_equal(probes[:,0],probe_times) and np.isfinite(probes).all(),'finite queries at frozen times')
        checks={}
        for mode in range(len(saved['modes'])):
            for column,name in enumerate(saved['names']):
                checks['original_'+str(mode)+'_'+str(name)]=comparison(output[mode,:,names.index(str(name))],saved['values'][mode,:,column])
        checks['same_regime']=dict(passed=bool(np.all(probes[:,199]==1) and np.all(probes[:,170:172]==0)))
        checks['collision_cancellation']=comparison(probes[:,167],probes[:,161]+probes[:,162],ALGEBRA)
        endpoint=probes[np.searchsorted(probe_times,clock[1992:END_INDEX+1])]
        require(np.array_equal(endpoint[:,0],clock[1992:END_INDEX+1]),'right endpoints present')
        for column in (8,9,47,152,153,168):
            checks['restart_'+str(column)]=comparison(endpoint[:,column],packet[1:,column])
        np.savez_compressed(ROOT/(label+'-capture.npz'),packet=packet,probes=probes,query_times=probe_times)
        write(label+'-validation.json',dict(passed=all(row['passed'] for row in checks.values()),checks=checks,original926_packets_byte_identical=True,probes=len(probes),native_build_reused=True))
        require(all(row['passed'] for row in checks.values()),'native validation')
        check_hashes(read(ROOT/(label+'-code-freeze.json')))
        check_hashes(read(ROOT/'frozen-inputs.json'))
        print(json.dumps(dict(case=case,phase=phase,probes=len(probes),passed=True)),flush=True)
    finally:
        reset()
        cleared=scalar('count').value==0 and ctypes.c_int.in_dll(library,'mts_probe_count').value==0
        del native
        write(label+'-owner-release.json',dict(cleared=cleared,native_reference_released=True))
        require(cleared,'native owner released')
