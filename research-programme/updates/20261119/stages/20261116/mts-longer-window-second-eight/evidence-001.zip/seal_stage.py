from support import *

with worker('seal-stage'):
    require(read(ROOT/'validation.json')['passed'],'final checks passed')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    workers=[]
    for path in sorted(ROOT.glob('*-start.json')):
        if path.name=='seal-stage-start.json':
            continue
        identity=read(path)
        outcome=exited(identity)
        require(outcome['exited'],'worker exited '+path.name)
        completion=read(path.with_name(path.name.replace('-start.json','-end.json')))
        require(completion['state']=='completed','worker completed')
        workers.append(dict(receipt=path.name,identity=identity,outcome=outcome,completion=completion['state']))
    write('preseal-validation.json',dict(passed=True,workers=workers,no_native_compiler_started=True,continuing_jobs=[]))

artifacts={path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(stage='longer-window-second-eight',date='2026-11-16',completed=True,previous=str(LAST),previous_closeout_sha256=PIN,previous_evolution=str(PREFIX),artifacts=artifacts,frozen_inputs=read(ROOT/'frozen-inputs.json'),validation_passed=True,result=read(ROOT/'batch-result.json'),next='Selected horizon complete; matter-sector compatibility review remains separate; no further evolution authorized',goal_left_paused=True,github_action=False,continuing_jobs=[],cleanup_receipt='CLEANUP-VERIFIED.json'))
print(json.dumps(dict(completed=True,artifacts=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'))),flush=True)
