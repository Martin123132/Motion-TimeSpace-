from extension_math import *

def reference_magnitude(packet,case,prepared):
    if case=='cold':
        return abs(native_source(packet,case,prepared))
    beta=packet[:,1]/prepared['density0']
    kinetic=beta*packet[:,33]*packet[:,40]
    potential=beta*packet[:,38]*packet[:,32]*packet[:,39]
    current=beta*packet[:,14]*packet[:,33]*packet[:,39]
    return np.column_stack((abs(kinetic)+abs(potential),abs(current),abs(kinetic)+abs(potential)))

with worker('score-extension'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(read(ROOT/'response-validation.json')['passed'],'new endpoint gain verified')
    reports={}
    for case in ('cold','heavy'):
        series_freeze=read(ROOT/(case+'-series-freeze.json'))
        require(series_freeze['passed'] and not series_freeze['target_comparison_started'],'response expansion frozen before scoring')
        check_hashes(series_freeze['hashes'])
        freeze=read(ROOT/(case+'-run-freeze.json'))
        require(freeze['passed'] and not freeze['target_comparison_started'],'runs frozen before comparison')
        require(exited(read(ROOT/(case+'-extend-start.json')))['exited'],'evolution worker exited')
        check_hashes(freeze['hashes'])
        prepared,history,background,old_preparation,control=problem(case)
        fine=load(ROOT/(case+'-extended-64.npz'))
        coarse=load(ROOT/(case+'-extended-32.npz'))
        plan=load(ROOT/(case+'-extension-plan.npz'))
        old_comparison=load(PREFIX/(case+'-comparison.npz'))
        old_target=load(MIDPOINT/(case+'-tested-readout.npz'))
        captures={phase:load(ROOT/(case+'-'+phase+'-capture.npz')) for phase in ('construction','validation')}
        require(np.array_equal(captures['construction']['packet'],captures['validation']['packet']),'all934 original main samples unchanged by probe schedules')
        target_nodes={}
        target_magnitude=None
        for phase,capture in captures.items():
            positions=np.searchsorted(capture['query_times'],plan['query_times'].ravel())
            require(np.array_equal(capture['query_times'][positions],plan['query_times'].ravel()),'all shifted target times present')
            rows=capture['probes'][positions]
            target_nodes[phase]=native_source(rows,case,prepared).reshape(8,902,3)
            if phase=='validation':
                target_magnitude=reference_magnitude(rows,case,prepared).reshape(8,902,3)
        initial_nodes=native_source(captures['validation']['packet'][:902],case,prepared)
        initial_check=comparison(initial_nodes,prepared['node_initial_sources'],ALGEBRA)
        require(initial_check['passed'],'same native initial source representation')
        weights=prepared['weights']
        reference_tail=old_target['corrected_readout'][0]+np.array([weighted(weights,row-initial_nodes) for row in target_nodes['validation']])
        expected=np.concatenate((old_comparison['reference'],reference_tail))
        reference_path=absolute_weighted(weights,target_nodes['validation']-target_nodes['construction'])
        initial_magnitude=reference_magnitude(captures['validation']['packet'][:902],case,prepared)
        reference_rounding=64*np.finfo(float).eps*np.array([weighted(abs(weights),row+initial_magnitude) for row in target_magnitude])
        reference_working=reference_path+reference_rounding
        numerical=absolute_weighted(weights,fine['node_source']-coarse['node_source'])
        quad_numerical=absolute_weighted(weights,fine['quad_node_source']-coarse['quad_node_source'])
        difference_numeric=absolute_weighted(weights,fine['delta_node_source']-coarse['delta_node_source'])
        scale=old_comparison['reference_scale']
        budget=np.concatenate((old_comparison['numerical_budget'],reference_working+abs(prepared['initial_recapture_difference'])[None,:]+numerical[PREFIX_COUNT:]+fine['arithmetic_difference'][PREFIX_COUNT:]))
        residual=fine['prediction']-expected
        direct=fine['prediction']-fine['quad_prediction']
        resolved=fine['delta_prediction']
        numeric_round=rounding(case,fine['elapsed'],fine['state'],prepared,background)
        quad_round=rounding(case,fine['elapsed'],fine['quad_state'],prepared,background)
        delta_round=rounding(case,fine['elapsed'],fine['delta_state'],prepared,background)
        subtraction=numerical+quad_numerical+difference_numeric+fine['arithmetic_difference']+fine['quad_arithmetic_difference']+numeric_round+quad_round+delta_round
        gains=load(ROOT/(case+'-extended-response.npz'))
        envelope=gains['variation_envelope']
        old_source_error=np.maximum.reduce([np.array(read(CONTROL/(case+'-corner-safe-result.json'))['new_prediction_errors'])]+[np.array(read(directory/(case+'-source-validation.json'))['source_error']) for directory in (FIRST_EXTENSION,PREFIX)])
        new_source_error=np.array(read(ROOT/(case+'-source-validation.json'))['source_error'])
        source_allowance=(gains['gain']+gains['gain_refinement'])@np.maximum(old_source_error,new_source_error)
        raw,numeric,paired,response,delta_refinement={},{},{},{},{}
        for channel,name in enumerate(('density','current','pressure')):
            raw[name]=comparison(fine['prediction'][PREFIX_COUNT:,channel],expected[PREFIX_COUNT:,channel],scale=scale[channel])
            numeric[name]=comparison(abs(residual[:,channel])+budget[:,channel],0,scale=scale[channel])
            paired[name]=dict(passed=bool(np.all(abs(direct[:,channel]-resolved[:,channel])<=subtraction[:,channel])),maximum_discrepancy=float(np.max(abs(direct[:,channel]-resolved[:,channel]))),maximum_allowance=float(np.max(subtraction[:,channel])))
            delta_refinement[name]=comparison(difference_numeric[:,channel],0,scale=np.max(abs(resolved[:,channel])))
            response[name]=dict(passed=bool(abs(resolved[-1,channel])<=envelope[channel]+difference_numeric[-1,channel]+delta_round[-1,channel]),actual_final_delta=float(resolved[-1,channel]),extended_envelope=float(envelope[channel]),fraction_of_envelope=float(abs(resolved[-1,channel])/envelope[channel]) if envelope[channel]>0 else None,final_total_passed=bool(abs(residual[-1,channel])+budget[-1,channel]+source_allowance[channel]<=GATE*scale[channel]))
        packet=captures['validation']['packet'][901:]
        native_state=np.column_stack((packet[:,39:41] if case=='heavy' else packet[:,63:64],packet[:,10]))
        boundary={str(column):comparison(fine['state'][:,-1,column],native_state[:,column]) for column in range(native_state.shape[1])}
        boundary['metric_force']=comparison(fine['metric_force'][:,-1],packet[:,6])
        external_reference=source_jet(packet,case)[:,0]
        external={name:comparison(fine['source'][:,-1,channel],external_reference[:,channel]) for channel,name in enumerate(('D','Q'))}
        prefix_checks={}
        for steps in (32,64):
            run=load(ROOT/(case+'-extended-'+str(steps)+'.npz'))
            old=load(PREFIX/(case+'-extended-'+str(steps)+'.npz'))
            for field in ('state','quad_state','delta_state','node_source','quad_node_source','delta_node_source','prediction','quad_prediction','delta_prediction','metric_force','arithmetic_difference','quad_arithmetic_difference','source','elapsed'):
                prefix_checks[str(steps)+'_'+field]=bool(np.array_equal(run[field][:PREFIX_COUNT],old[field]))
        state_error=fine['state']-fine['quad_state']-fine['delta_state']
        state_allowance=abs(fine['state']-coarse['state'])+abs(fine['quad_state']-coarse['quad_state'])+abs(fine['delta_state']-coarse['delta_state'])+64*np.finfo(float).eps*(abs(fine['state'])+abs(fine['quad_state'])+abs(fine['delta_state']))
        state_pass=bool(np.all(abs(state_error)<=state_allowance))
        epoch_pass=np.all(abs(residual)+budget<=GATE*scale[None,:],axis=1)
        np.savez_compressed(ROOT/(case+'-comparison.npz'),reference=expected,native_reference_tail=reference_tail,reference_path_sensitivity=reference_path,reference_rounding=reference_rounding,reference_working_allowance=reference_working,residual=residual,numerical_budget=budget,numerical_refinement=numerical,reference_scale=scale,subtracted_change=direct,resolved_change=resolved,difference_refinement=difference_numeric,subtraction_allowance=subtraction,final_envelope=envelope,final_source_allowance=source_allowance,epoch_pass=epoch_pass,boundary_state_reference=native_state)
        report=dict(completed=True,raw_new_block=raw,residual_plus_numerical_allowance=numeric,numerical_passed=all(row['passed'] for row in numeric.values()),boundary=boundary,boundary_passed=all(row['passed'] for row in boundary.values()),external_sources=external,external_passed=all(row['passed'] for row in external.values()),superposition=paired,superposition_passed=all(row['passed'] for row in paired.values()),node_state_superposition_passed=state_pass,difference_refinement=delta_refinement,difference_refinement_passed=all(row['passed'] for row in delta_refinement.values()),response=response,response_passed=all(row['passed'] and row['final_total_passed'] for row in response.values()),prefix_bit_identical=prefix_checks,prefix_passed=all(prefix_checks.values()),epoch_pass=epoch_pass.tolist(),new_reference_method='Direct native full-state probes at902 shifted times per new epoch; same saved initial matching anchor, no fitted offset; old twenty-five reference rows and allowances retained',initial_source_agreement=initial_check,old_uncertainties_not_extrapolated=True,original_reference_scales_retained=True,uniform_continuum_bound_claimed=False,goal_left_paused=True)
        write(case+'-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,numeric={name:row['relative'] for name,row in numeric.items()},new_raw={name:row['relative'] for name,row in raw.items()},boundary=report['boundary_passed'],external=report['external_passed'],prefix=report['prefix_passed'],superposition=report['superposition_passed'],node_superposition=state_pass,response=response,refinement=delta_refinement)),flush=True)
    flags=('numerical_passed','boundary_passed','external_passed','superposition_passed','node_state_superposition_passed','difference_refinement_passed','response_passed','prefix_passed')
    paired={name:all(row[name] for row in reports.values()) for name in flags}
    write('result.json',dict(completed=True,paired=paired,all_requested_checks_passed=all(paired.values()),new_epochs=8,total_report_rows=REPORT_COUNT,goal_left_paused=True,uniform_continuum_bound_claimed=False))
    check_hashes(read(ROOT/'frozen-inputs.json'))
