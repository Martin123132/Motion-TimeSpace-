from extension_math import *
import math
from scipy.integrate import solve_ivp

with worker('transport-restart-defect'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('restart-transport-freeze.json',dict(method='Eprime=A E with E0=fsum(saved full,-saved quadratic,-saved difference)',seed_origin='saved64 endpoint before new batch; no fitted value',rtol=1e-10,normalized_atol=1e-12,max_physical_step='original duration/32 and /64',unchanged_allowance=True,hashes={str(ROOT/name):digest(ROOT/name) for name in ('transport_restart_defect.py','extension_math.py','support.py')}))
    reports={}
    for case in ('cold','heavy'):
        prepared,history,background,old_preparation,control=problem(case)
        fine=load(ROOT/(case+'-extended-64.npz'))
        coarse=load(ROOT/(case+'-extended-32.npz'))
        old=load(PREFIX/(case+'-extended-64.npz'))
        seed=np.array([[math.fsum((float(full),-float(quadratic),-float(difference))) for full,quadratic,difference in zip(fullrow,quadrow,deltarow)] for fullrow,quadrow,deltarow in zip(old['state'][-1],old['quad_state'][-1],old['delta_state'][-1])])
        amplitude=np.max(abs(seed/prepared['norm']),axis=1)
        scaling=prepared['norm']*np.where(amplitude>0,amplitude,1.)[:,None]
        elapsed=prepared['elapsed']
        shape=seed.shape
        solutions={}
        for steps in (32,64):
            def derivative(offset,flat):
                guard()
                matrix,forcing=metric.normalized_geometry(case,offset,prepared,background)
                return np.einsum('nij,nj->ni',matrix,flat.reshape(shape)).ravel()
            solve=solve_ivp(derivative,(float(elapsed[PREFIX_COUNT-1]),float(elapsed[-1])),(seed/scaling).ravel(),method='DOP853',t_eval=elapsed[PREFIX_COUNT-1:],rtol=1e-10,atol=1e-12,max_step=float(elapsed[8])/steps)
            require(solve.success and solve.y.shape==(seed.size,9),'known seed transport')
            solutions[steps]=solve.y.T.reshape(9,*shape)*scaling[None,:,:]
        error=fine['state']-fine['quad_state']-fine['delta_state']
        allowance=abs(fine['state']-coarse['state'])+abs(fine['quad_state']-coarse['quad_state'])+abs(fine['delta_state']-coarse['delta_state'])+64*np.finfo(float).eps*(abs(fine['state'])+abs(fine['quad_state'])+abs(fine['delta_state']))
        tail_error=error[PREFIX_COUNT-1:]
        transported=solutions[64]
        residual=tail_error-transported
        transport_uncertainty=abs(solutions[64]-solutions[32])+64*np.finfo(float).eps*(abs(tail_error)+abs(transported))
        raw_failed=np.argwhere(abs(error)>allowance)
        corrected_pass=np.all(abs(residual)+transport_uncertainty<=allowance[PREFIX_COUNT-1:])
        examples=[]
        for epoch,node,component in raw_failed[:20]:
            local=int(epoch)-(PREFIX_COUNT-1)
            examples.append(dict(report_row=int(epoch),original_epoch=ORIGIN_INDEX+int(epoch),node=int(node),component=int(component),raw_error=float(error[epoch,node,component]),unchanged_allowance=float(allowance[epoch,node,component]),seed=float(seed[node,component]),transported_seed=float(transported[local,node,component]) if local>=0 else None,residual_after_transport=float(residual[local,node,component]) if local>=0 else None))
        normalized_transport=transported/prepared['norm']
        refinement=comparison((solutions[64]-solutions[32])/prepared['norm'],0,scale=np.max(abs(normalized_transport)))
        prefix_pass=bool(read(PREFIX/'restart-defect-validation.json')['passed'] and read(PREFIX/'batch-result.json')['passed'] and all(np.array_equal(fine[name][:PREFIX_COUNT],old[name]) for name in ('state','quad_state','delta_state')))
        report=dict(passed=bool(corrected_pass and prefix_pass and refinement['passed']),raw_failed_count=len(raw_failed),new_raw_failed_count=int(np.count_nonzero(raw_failed[:,0]>=PREFIX_COUNT)) if len(raw_failed) else 0,raw_failures=examples,correct_identity='full - quadratic - difference = propagator times saved restart defect',same_raw_allowance=True,no_physical_histories_changed=True,no_free_coefficient=True,initial_prefix_passed=prefix_pass,transport_refinement=refinement,maximum_remaining_fraction=float(np.max(np.divide(abs(residual)+transport_uncertainty,allowance[PREFIX_COUNT-1:],out=np.zeros_like(residual),where=allowance[PREFIX_COUNT-1:]>0))))
        np.savez_compressed(ROOT/(case+'-restart-defect.npz'),seed=seed,transport32=solutions[32],transport64=solutions[64],remaining_error=residual,transport_uncertainty=transport_uncertainty,unchanged_allowance=allowance,elapsed=elapsed[PREFIX_COUNT-1:])
        write(case+'-restart-defect-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,**report)),flush=True)
    check_hashes(read(ROOT/'restart-transport-freeze.json')['hashes'])
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('restart-defect-validation.json',dict(passed=all(row['passed'] for row in reports.values()),cases={case:row['passed'] for case,row in reports.items()},raw_failure_retained=True,tolerances_unchanged=True))
