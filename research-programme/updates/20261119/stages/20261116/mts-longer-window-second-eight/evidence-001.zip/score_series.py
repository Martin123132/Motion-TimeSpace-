from extension_math import *

with worker('score-series'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    raw_result=read(ROOT/'result.json')
    require(all(passed for name,passed in raw_result['paired'].items() if name!='node_state_superposition_passed'),'native reference and endpoint checks')
    require(read(ROOT/'restart-defect-validation.json')['passed'],'derived restart identity with unchanged allowance')
    reports={}
    for case in ('cold','heavy'):
        for suffix in ('extend','series'):
            require(exited(read(ROOT/(case+'-'+suffix+'-start.json')))['exited'],'calculation worker exited')
        check_hashes(read(ROOT/(case+'-run-freeze.json'))['hashes'])
        check_hashes(read(ROOT/(case+'-series-freeze.json'))['hashes'])
        prepared,history,background,old_preparation,control=problem(case)
        fine=load(ROOT/(case+'-growth-64.npz'))
        coarse=load(ROOT/(case+'-growth-32.npz'))
        direct=load(ROOT/(case+'-extended-64.npz'))
        saved_comparison=load(ROOT/(case+'-comparison.npz'))
        expected=direct['delta_prediction']
        node_refinement=abs(fine['nodes']-coarse['nodes'])
        uncertainty=np.array([[weighted(abs(prepared['weights']),np.sum(row[:order+1],axis=0)) for order in range(9)] for row in node_refinement])
        channels={}
        for channel,name in enumerate(('D','Q','P')):
            scale=float(np.max(abs(expected[PREFIX_COUNT:,channel])))
            observed=fine['partial_sums'][PREFIX_COUNT:,8,channel]
            errors=abs(observed-expected[PREFIX_COUNT:,channel])
            numerical=uncertainty[PREFIX_COUNT:,8,channel]+saved_comparison['difference_refinement'][PREFIX_COUNT:,channel]
            channels[name]=dict(raw=comparison(observed,expected[PREFIX_COUNT:,channel],scale=scale),with_working_uncertainty=comparison(errors+numerical,0,scale=scale),original_observable_gate=comparison(errors+numerical,0,scale=saved_comparison['reference_scale'][channel]),actual_endpoint=float(expected[-1,channel]),series_endpoint=float(fine['partial_sums'][-1,8,channel]))
        nodes={}
        for endpoint in (PREFIX_COUNT-1,REPORT_COUNT-1):
            predicted=np.sum(fine['states'][endpoint],axis=0)/prepared['norm']
            reference=direct['delta_state'][endpoint]/prepared['norm']
            nodes[str(endpoint)]=comparison(predicted,reference)
        prefixes={}
        for steps in (32,64):
            saved=load(LAST/(case+'-growth-'+str(steps)+'.npz'))
            new=load(ROOT/(case+'-growth-'+str(steps)+'.npz'))
            for name in ('states','nodes','terms','partial_sums','elapsed'):
                prefixes[str(steps)+'_'+name]=bool(np.array_equal(new[name][:PREFIX_COUNT],saved[name]))
        partials={}
        for order in (0,1,2,4,6,8):
            partials[str(order)]={name:comparison(fine['partial_sums'][PREFIX_COUNT:,order,channel],expected[PREFIX_COUNT:,channel],scale=np.max(abs(expected[PREFIX_COUNT:,channel]))) for channel,name in enumerate(('D','Q','P'))}
        passed=all(row['with_working_uncertainty']['passed'] and row['original_observable_gate']['passed'] for row in channels.values()) and all(row['passed'] for row in nodes.values()) and all(prefixes.values())
        np.savez_compressed(ROOT/(case+'-series-comparison.npz'),direct=expected,series=fine['partial_sums'][:,8],refinement=uncertainty[:,8],elapsed=prepared['elapsed'])
        report=dict(passed=passed,channels=channels,node_checks=nodes,prefix_bit_identical=prefixes,partial_sums=partials,old25_rows_preserved=all(prefixes.values()),physical_grids_unchanged=True,interactions=8,no_fitted_exponent=True)
        write(case+'-series-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,passed=passed,relative={name:row['with_working_uncertainty']['relative'] for name,row in channels.items()},endpoint={name:row['actual_endpoint'] for name,row in channels.items()})),flush=True)
    passed=all(row['passed'] for row in reports.values())
    write('series-validation.json',dict(passed=passed,cases={case:row['passed'] for case,row in reports.items()},same_gate=GATE))
    write('batch-result.json',dict(completed=True,passed=passed and read(ROOT/'restart-defect-validation.json')['passed'],reports=REPORT_COUNT,new_epochs=8,first_batch=[BEGIN_INDEX+1,END_INDEX],remaining_batch=[],selected_longer_window_complete=True,source_predictions_frozen_before_tests=True,saved25_reports_preserved=True,raw_node_superposition_passed=raw_result['paired']['node_state_superposition_passed'],restart_identity_repair='Known saved finite-precision initial mismatch transported by Eprime=A E; old raw allowance retained',raw_failure_receipts_preserved=True,goal_left_paused=True,next_batch_started=False))
    check_hashes(read(ROOT/'frozen-inputs.json'))
    require(passed,'paired expansion checks')
