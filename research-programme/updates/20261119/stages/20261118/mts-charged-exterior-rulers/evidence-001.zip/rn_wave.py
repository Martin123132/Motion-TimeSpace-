from reference import *
from scipy.special import betainc
import json

RADII=(12.75,14.,18.,20.)
def wave(count,inner=5.1,flat=False):
    guard()
    mass=0. if flat else core_adm(1.,.8*BARYON)
    charge=0. if flat else .8*BARYON
    hi=44.;end=6.52
    def f(r):return 1-2*mass/r+charge**2/r**2
    def tort(r):
        if flat:return r-inner
        sq=math.sqrt(mass**2-charge**2);outer=mass+sq;inside=mass-sq
        return r-inner+(outer**2*np.log1p((r-inner)/(inner-outer))-inside**2*np.log1p((r-inner)/(inner-inside)))/(2*sq)
    axis=np.linspace(0,tort(hi),count+1);step=axis[1]
    rad=axis+inner
    for iteration in range(5):rad-=f(rad)*(tort(rad)-axis)
    assert peak(tort(rad)-axis)<2e-12
    potential=f(rad)*(1+2*mass/rad**3-2*charge**2/rad**4)
    constant=BARYON*25/17
    corr=(-BARYON*(rad-12)+constant*(1/12-1/rad))*(1-betainc(6,6,np.clip((rad-10)/5,0,1)))
    original=rad*.0008*(1+corr)*(1-betainc(6,6,np.clip((rad-16)/10,0,1)))
    original[0]=0.
    def operator(field):
        d=np.zeros_like(field)
        d[2:-2]=(-field[4:]+16*field[3:-1]-30*field[2:-2]+16*field[1:-3]-field[:-4])/(12*step**2)
        d[1]=(field[2]-2*field[1]+field[0])/step**2
        d[-2]=(field[-3]-2*field[-2]+field[-1])/step**2
        return d-potential*field
    nsteps=int(np.ceil(end/(.42*step)));dt=end/nsteps
    def increment(field):
        accel=operator(field)
        return dt**2*accel+dt**4/12*operator(accel)
    centers=np.rint(tort(np.array(RADII))/step).astype(int)
    ix=centers[:,None]+np.arange(-6,7)
    current=original.copy();last=current+.5*increment(current)
    hist=[]
    for n in range(nsteps+1):
        hist.append(current[ix])
        if n<nsteps:
            last,current=current,2*current-last+increment(current)
    hist=np.array(hist);times=np.linspace(0,end,nsteps+1);waves=[]
    for slot,r0 in enumerate(RADII):
        energy=math.sqrt(f(r0))
        def geodesic(t,z):
            r,v,clock=z
            return [v,-mass/r**2+charge**2/r**3,energy/f(r)]
        geo=solve_ivp(geodesic,(0,6.4),[r0,0.,0.],t_eval=TARGET,rtol=1e-13,atol=1e-17,max_step=.12,method="DOP853")
        assert geo.success and inner+end<min(geo.y[0])
        r,vel,clock=geo.y
        fixed=CubicSpline(times,hist[:,slot,:],axis=0)
        field=fixed(clock);partial=fixed(clock,1);partial[0]=0.
        vals=[];dvals=[]
        for i,coord in enumerate(tort(r)):
            fun=CubicSpline(axis[ix[slot]],field[i])
            val=fun(coord);ut=CubicSpline(axis[ix[slot]],partial[i])(coord)
            vals.append(val/r[i]);dvals.append((ut*energy/f(r[i])+fun(coord,1)*vel[i]/f(r[i]))/r[i]-val*vel[i]/r[i]**2)
        h=np.array(vals);dh=np.array(dvals)
        waves.append([h,dh,2*dh*dh-h*h])
    return np.array(waves)
def freeze():
    guard()
    files={}
    for n,inner,flat in ((960,5.1,False),(1920,5.1,False),(3840,5.1,False),(1920,5.7,False),(3840,5.1,True)):
        name=f"rn-wave-{n}-left{inner:g}-flat{int(flat)}.npz"
        values=wave(n,inner,flat)
        with (HERE/name).open("xb") as stream:np.savez_compressed(stream,radii=RADII,time=TARGET,curves=values)
        files[name]=sha(HERE/name)
    record=dict(predictor=sha(HERE/"rn_wave.py"),protocol=sha(HERE/"RN-WAVE-PREDICTION.md"),files=files,
        new_radii=[12.75,20.],exposed=[14.,18.],amp=[.00625,1.],gate=2e-5)
    with (HERE/"frozen-wave.json").open("x",encoding="utf8") as stream:json.dump(record,stream,sort_keys=True,indent=2)
    print("frozen",sha(HERE/"frozen-wave.json"))
if __name__=="__main__":freeze()

