from charged import *
import math
from scipy.special import betainc
from scipy.optimize import brentq

BARYON=.002
DMAX=.000703828125
def core_adm(scale,charge):
    def gradient(rad,values):
        if rad==0:return [0.]
        rho=DMAX*scale*max(0.,1-(rad/5)**2)**6
        q=charge*betainc(1.5,7.,min(1.,(rad/5)**2))
        root=math.sqrt(1-2*values[0]/rad+(q/rad)**2)
        return [rho*(rad**2*root+(charge/(BARYON*scale))*rad*q)]
    sol=solve_ivp(gradient,(0.,5.),[0.],method="DOP853",rtol=2e-13,atol=2e-17,max_step=.046)
    assert sol.success
    return sol.y[0,-1]
def matching():
    guard();rows=[]
    for amp in (0.,1/160,1.):
        packet=read(1920,.8,amp)
        aim=packet["stats"][0,0];charge=.8*BARYON
        scale=brentq(lambda val:core_adm(val,charge)-aim,.97,2.,xtol=4e-15)
        rows.append(dict(amplitude=amp,target_ADM=aim,charge=charge,reference_baryon_scale=scale,reference_eta=.8/scale,
            original_baryon_mass=BARYON,reference_baryon_mass=scale*BARYON,
            matched_ADM=core_adm(scale,charge),original_continuum_ADM=core_adm(1.,charge)))
    return rows
def common(src,slot):
    data=src["events"][:,:,5*slot+2];clock=data[:,0]
    assert clock[0]==0 and clock[-1]>TARGET[-1] and min(np.diff(clock))>0
    return CubicSpline(clock,data,axis=0)(TARGET)
def rn(mass,charge,radius):
    def rhs(time,state):
        rad,vel,jr,rate,ja,angular_rate=state
        force=-mass/rad**2+charge**2/rad**3
        curvature=2*mass/rad**3-3*charge**2/rad**4
        return [vel,force,rate,curvature*(1+jr),angular_rate,force/rad*(1+ja)]
    sol=solve_ivp(rhs,(0.,6.4),[radius,0,0,0,0,0],method="DOP853",t_eval=TARGET,rtol=1e-13,atol=1e-16,max_step=.12)
    assert sol.success
    rad,vel,jr,rate,ja,angular_rate=sol.y
    angular_acc=-mass/rad**3+charge**2/rad**4
    return dict(radius=rad,Jr_offset=jr,Jt_offset=ja,tidal_r=-2*mass/rad**3+3*charge**2/rad**4,
        tidal_t=-angular_acc,velocity=vel)
def rn_checks():
    guard();rows=[];source_rows=[]
    for count in (960,1920):
        for eta in (0.,.8,1.):
            src=read(count,eta,0)
            mass=src["stats"][0,0];q=src["stats"][0,1]
            for slot,radius in enumerate(CENTERS[1:],start=1):
                obs=common(src,slot)
                ref=rn(mass,q,radius);sch=rn(mass,0.,radius)
                for key in ("Jr_offset","Jt_offset","tidal_r","tidal_t"):
                    left=obs[:,KEYS.index(key)]
                    error=peak(left-ref[key]);signal=peak(ref[key])
                    coulomb=peak(ref[key]-sch[key])
                    rows.append(dict(mesh=count,eta=eta,r0=radius,readout=key,absolute=error,
                        relative_to_total=error/signal,charge_signal=coulomb,relative_to_charge=error/coulomb if coulomb else None,
                        passes_charge=error<2e-5*coulomb if coulomb else None))
            qwork=src["stats"]
            source_rows.append(dict(mesh=count,eta=eta,adm=mass,continuum_adm=core_adm(1.,q),charge=q,
                adm_drift=peak(qwork[:,0]-mass),charge_drift=peak(qwork[:,1]-q),baryon_drift=peak(qwork[:,2]-BARYON),
                independent_mass_quadrature=peak(qwork[:,3]),max_rho_exterior=peak(qwork[:,5]),
                central_region_max_speed=peak(qwork[:,9]),peak_force_at_rest=peak(qwork[:,11]),
                state_change=peak(src["final"]-src["initial"])))
    return rows,source_rows


if __name__=="__main__":
    table("same-adm-regular-cores.csv",matching());data,source=rn_checks()
    table("charged-GR-controls.csv",data);table("source-calibration.csv",source)

