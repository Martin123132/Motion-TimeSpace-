from scipy.integrate import quad
from numpy.polynomial import Polynomial
from selfgravity import CHARGE, RADII, adm_variation, preparation
from reference import HERE, TARGET, guard, np, peak, table
from sg_test import forecast


def checks():
    guard()
    bank=forecast()[3840]
    mass,variation=adm_variation()
    def base(rad):
        return 1-2*mass/rad+(CHARGE/rad)**2
    def energy_integrand(rad):
        field,slope=preparation(rad)
        return .5*rad**2*(field**2+base(rad)*slope**2)
    def second_taper(rad,start,width):
        frac=np.clip((rad-start)/width,0.,1.)
        return -13860*frac**4*(1-frac)**4*(1-2*frac)/width**2
    rows=[]
    for slot,radius in enumerate(RADII):
        field,slope=preparation(radius)
        if radius<15:
            from scipy.special import betainc
            scaled=(radius-10)/5
            chi=-.002*(radius-12)+(.002*25/17)*(1/12-1/radius)
            dchi=-.002+(.002*25/17)/radius**2
            ddchi=-2*(.002*25/17)/radius**3
            curvature=.0008*(ddchi*(1-betainc(6,6,scaled))+2*dchi*(-2772*scaled**5*(1-scaled)**5/5)+chi*second_taper(radius,10,5))
        else:
            curvature=.0008*second_taper(radius,16,10)
        deriv=2*mass/radius**2-2*CHARGE**2/radius**3
        second=base(radius)*curvature+(2*base(radius)/radius+deriv/2)*slope-field
        mu=variation-quad(energy_integrand,radius,26.,points=[p for p in (15.,16.) if p>radius],
                          epsabs=2e-17,epsrel=2e-13)[0]
        delta=-2*mu/radius
        ddelta=-2*energy_integrand(radius)/radius+2*mu/radius**2
        third=delta*curvature+(2*delta/radius+ddelta/2)*slope
        target=(8*second-2*field)*third
        parts=bank[slot,1:]
        def differentiate(samples):
            span=TARGET[8]
            return Polynomial.fit(TARGET[:9]/span,samples[:9]-samples[0],deg=8).deriv(2)(0)/span**2
        measured=differentiate(parts.sum(axis=0))
        bare=differentiate(parts[:2].sum(axis=0))
        rows.append(dict(r0=radius,initial_h=field,initial_second_clock=second,delta_initial_second_clock=third,
                    I4_second_from_constraint=target,I4_second_from_forecast=measured,
                    absolute=abs(measured-target),relative=abs(measured/target-1),
                    error_omitting_clock=abs(bare/target-1),numerical_time_floor=abs(differentiate(bank[slot,0])-(4*second**2-2*field*second))))
    return rows

if __name__=="__main__":
    table("initial-clock-cancellation.csv",checks())

