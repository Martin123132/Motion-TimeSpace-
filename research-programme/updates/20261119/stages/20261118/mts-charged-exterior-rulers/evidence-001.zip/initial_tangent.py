from scipy.integrate import cumulative_simpson
from reference import HERE, Charged, guard, np, table
from selfgravity import RADII
from turning_clock import checks


def measure():
    guard()
    expected=checks()
    rows=[]
    for mesh in (960,1920,3840,7680):
        grid=Charged(mesh,.8)
        state,_=grid.initial("both","prepared",1.,1.)
        bare,_=grid.initial("dust","bare",1.,0.)
        aa=grid.metric(bare)[0]
        charge,mu,em,weight=grid.extra
        radius=grid.r
        field=state[0]
        gradient=grid.first(field,1)
        curvature=grid.second(field)
        factor=1/aa**2
        energy=(factor*gradient**2+field**2)/2
        integrating=np.exp(cumulative_simpson(radius*bare[2]*aa,x=radius,initial=0))
        varied=cumulative_simpson(integrating*radius**2*energy,x=radius,initial=0)/integrating
        inv=grid.inv
        delta=-2*varied*inv
        ddelta=-2*radius*(energy-bare[2]*aa*varied*inv)+2*varied*inv**2
        exterior_deriv=2*mu*inv**2-2*charge**2*inv**3
        accel=factor*curvature+(2*factor*inv+exterior_deriv/2)*gradient-field
        third=delta*curvature+(2*delta*inv+ddelta/2)*gradient
        evaluated=grid.at((8*accel-2*field)*third,RADII)
        for ref,rad,value in zip(expected,RADII,evaluated):
            target=ref["I4_second_from_constraint"]
            relative=abs(value/target-1)
            rows.append(dict(mesh=mesh,r0=rad,continuum=target,discrete_tangent=value,relative=relative,passes=relative<2e-5))
    return rows

if __name__=="__main__":
    table("initial-clock-tangent.csv",measure())

