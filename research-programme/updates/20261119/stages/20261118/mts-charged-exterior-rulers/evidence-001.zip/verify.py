import csv
import json
import math
import sys
from pathlib import Path

import exterior_bound
import heldout
import initial_clock_direct
import initial_tangent
import reference
import sg_test
import source_test
import turning_clock
from charged import BOOT, HERE, SPHERE, LOCK, guard, np, peak, sha
from selfgravity import adm_variation


def read_rows(name):
    with (HERE/name).open(encoding="utf8",newline="") as stream:
        reader=csv.DictReader(stream,strict=True)
        assert reader.fieldnames and len(set(reader.fieldnames))==len(reader.fieldnames)
        content=list(reader)
    assert content and all(None not in row and None not in row.values() for row in content)
    return content


def audit():
    guard()
    checks={}
    def check(name,condition):
        if not condition:
            raise ArithmeticError(name)
        checks[name]=True
    def compare(name,computed):
        actual=read_rows(name)
        check("rows "+name,len(computed)==len(actual))
        for saved,new in zip(actual,computed,strict=True):
            assert set(saved)==set(new)
            for key,value in new.items():
                field=saved[key]
                if value is None:
                    assert field=="",(name,key,field)
                elif isinstance(value,(bool,np.bool_,str)):
                    assert field==str(value),(name,key,field,value)
                else:
                    assert math.isclose(float(field),value,rel_tol=2e-10,abs_tol=2e-26),(name,key,field,value)
        check("recalculate "+name,True)
    inputs={}
    def pin(path,digest=None):
        actual=sha(path)
        if digest is not None:
            check("source "+path.relative_to(HERE.parent).as_posix(),actual==digest)
        inputs[path.relative_to(HERE.parent).as_posix()]=actual
    for source,digest,names in ((BOOT,LOCK,["initial-polynomial-integrals.csv","MASSIVE-CANCELLATION.md","initial_polynomial.py","RESULTS.md"]),
                               (SPHERE,"2ec01956932aed50c5e46b069f8362e18b899542d391019258f87a245ab47762",
                               ["evolve.py","compare.py","relational.py","account-1920-dust-bare.npz","account-1920-both-prepared-h0.00625.npz"])):
        pin(source/"closeout.json",digest)
        receipt=json.loads((source/"closeout.json").read_text(encoding="utf8"))
        for name in names:
            pin(source/name,receipt["files"][name])
    pin(SPHERE.parent/"mts-forest-first-tail-20261118"/"closeout.json","57abc992b64fe5769dff2848359bcd41884e114c4fae4f3e1918baf72906c4e9")
    for name in ("MTS-CHARGED-THRESHOLD-AND-GR-TRACE.md","MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md",
                 "4934-Y5-R2FR-portal-a6-completion-and-direct-C3-photon-Hessian-gate.md"):
        pin(HERE.parent/name)
    files={}
    for path in sorted(HERE.iterdir()):
        if path.name=="closeout.json":
            continue
        check("physical file "+path.name,path.is_file() and path.suffix in {".md",".py",".npz",".json",".csv"})
        files[path.name]=sha(path)
        if path.suffix==".npz":
            with np.load(path,allow_pickle=False) as data:
                for key in data.files:
                    values=data[key]
                    if values.dtype.kind in "ifc":
                        assert np.isfinite(values).all(),(path.name,key)
                if "time" in data:
                    assert np.all(np.diff(data["time"])>0)
            check("finite archive "+path.name,True)
        if path.suffix==".csv":
            check("parse "+path.name,len(read_rows(path.name))>0)
    rn,source=reference.rn_checks()
    compare("charged-GR-controls.csv",rn)
    compare("source-calibration.csv",source)
    compare("same-adm-regular-cores.csv",reference.matching())
    check("charge effect resolved on own scale, not all coarse cases pass",
          sum(row["passes_charge"] is not None and bool(row["passes_charge"]) for row in rn if row["mesh"]==1920)==32
          and sum(row["passes_charge"] is not None and not bool(row["passes_charge"]) for row in rn if row["mesh"]==960)==5)
    repaired,retained=source_test.source_checks()
    compare("repaired-shell-energy.csv",repaired)
    compare("retained-controls.csv",retained)
    check("signed controls and repaired work",len(retained)==15 and all(row["passes"] for row in retained)
          and all(row["passes"] for row in repaired if row["mesh"]==1920) and not all(row["passes"] for row in repaired))
    bounds=exterior_bound.certs()
    compare("exterior-initial-data.csv",bounds)
    check("sufficient bound's domain and limits",
          all(not row["initial_only_certificate"] for row in bounds if row["r0"]==6)
          and all(row["below_original_target"]==(row["amp"]<1) for row in bounds if row["r0"] in (14,18))
          and all(row["radial_ceiling"]==0 and row["angular_ceiling"]==0 for row in bounds if row["r0"]==36))
    refinements=read_rows("response-refinement.csv")
    check("response convergence except exact null",sum(row["passes"]=="True" for row in refinements)==56
          and sum(row["passes"]=="" for row in refinements)==8)
    responses=read_rows("resolved-scalar-response.csv")
    small={(r["matching"],r["quantity"]):float(r["signed_final"]) for r in responses
           if r["mesh"]=="1920" and float(r["r0"])==6 and float(r["amplitude"])==1/160}
    check("matching matters even to angular sign",small["same-core","Jt_offset"]<0<small["same-ADM","Jt_offset"])
    original,tests,ratios=heldout.evaluate()
    for name,rows in zip(("frozen-wave-tests.csv","wave-resolution.csv","nonlinear-remainder.csv"),(original,tests,ratios)):
        compare(name,rows)
    check("fixed-metric miss retained",all(not row["passes"] for row in original if row["amp"]==1 and row["r0"] in (18.,20.)))
    rows,orders,res=sg_test.evaluate()
    compare("selfgravity-wave-test.csv",rows)
    compare("selfgravity-coefficient-test.csv",orders)
    compare("selfgravity-components.csv",res)
    fine=[row for row in rows if row["mesh"]==1920]
    fine_orders=[row for row in orders if row["mesh"]==1920]
    check("fine 75 waveforms and 25 quartic coefficients on own scale",
          len(fine)==75 and len(fine_orders)==25 and all(row["passes"] for row in fine+fine_orders))
    check("new radius and omitted-clock control",all(row["prior_error"]>2e-5 and row["no_clock"]>2e-5 and row["no_field"]>2e-5
                                                   for row in fine if row["amp"]==1 and row["r0"]==19.25))
    check("two independent leading wave solvers and quartic mesh refinement",
          all(row["I4_1920_3840"]<row["I4_960_1920"]<2e-5 for row in res)
          and all(row["I2_other_integrator"]<2e-5 for row in res if row["I2_other_integrator"] is not None))
    mass,variation=adm_variation()
    check("initial constrained mass variation",all(abs(float(row["total_mass_increment"])/(1/160)**2/variation-1)<2e-5
            for row in read_rows("initial-source-split.csv") if float(row["amp"])==1/160))
    indirect=turning_clock.checks()
    compare("initial-clock-cancellation.csv",indirect)
    direct=initial_clock_direct.compare()
    compare("initial-clock-direct.csv",direct)
    tangent=initial_tangent.measure()
    compare("initial-clock-tangent.csv",tangent)
    check("initial-clock successes and limitations",
          sum(row["relative"]<2e-5 for row in indirect)==2 and sum(row["passes"] for row in direct if row["mesh"]==1920)==3
          and all(row["relative"]<2e-8 for row in tangent if row["mesh"]==3840))
    return dict(files=files,inputs=inputs,checks=checks,first_forecast=heldout.FROZEN,second_forecast=sg_test.SEAL)

if __name__=="__main__":
    result=audit()
    close=HERE/"closeout.json"
    if sys.argv[1:]==["--seal"]:
        with close.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(result,stream,sort_keys=True,indent=2)
            stream.write("\n")
    elif sys.argv[1:] or json.loads(close.read_text(encoding="utf8"))!=result:
        raise ValueError("changed closeout or unexpected arguments")
    print(len(result["checks"]),"checks;",len(result["files"]),"files;",len(result["inputs"]),"parent inputs;",sha(close))

