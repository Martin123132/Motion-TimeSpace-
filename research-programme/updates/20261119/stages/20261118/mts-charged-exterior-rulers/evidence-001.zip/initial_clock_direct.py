from turning_clock import checks
from sg_test import AMPLITUDES, MESHES, RADII
from reference import HERE, guard, np, table

def compare():
    guard()
    refs=checks()
    rows=[]
    for mesh in MESHES:
        samples={}
        for amp in AMPLITUDES[1:]:
            with np.load(HERE/f"sg-held-{mesh}-eta0.8-h{amp:g}.npz",allow_pickle=False) as src:
                samples[amp]=src["taylor"][3]/amp**2
        low=(samples[.75]-samples[.5])/(.75**2-.5**2)
        high=(samples[1.]-samples[.75])/(1-.75**2)
        result=((1+.75**2)*low-(.75**2+.5**2)*high)/(1-.5**2)
        for slot,radius in enumerate(RADII):
            target=refs[slot]["I4_second_from_constraint"]
            deviation=abs(result[slot]/target-1)
            rows.append(dict(mesh=mesh,r0=radius,initial_equation=target,recovered_from_nonlinear_slice=result[slot],
                             relative=deviation,passes=deviation<2e-5))
    return rows

if __name__=="__main__":
    table("initial-clock-direct.csv",compare())

