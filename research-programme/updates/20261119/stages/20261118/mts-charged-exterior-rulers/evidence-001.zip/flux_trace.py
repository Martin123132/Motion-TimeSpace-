from reference import *
from scipy.integrate import cumulative_simpson

def acquire(count,eta,amp,held=False,*,extension=None):
    guard()
    if held:
        assert sha(HERE/"frozen-wave.json")=="1bebe93fabaf04de123f32cb0c701df744764f0c228d0d3498a1de38855c94a6"
    grid=Charged(count,eta);grid.probes=np.array((12.75,14.,18.,20.) if held else CENTERS)
    if extension is not None:
        assert not held and extension=="selfgravity"
        assert sha(HERE/"frozen-selfgravity.json")=="85a51c9cd60e054870ac36b36516dce2221beb7db1bd95a3899361582a03990e"
        grid.probes=np.array([12.75,14.,18.,19.25,20.])
    state,probe=grid.initial("both" if amp else "dust","prepared" if amp else "bare",1.,amp)
    probe[[3,5]]-=1
    steps=int(np.ceil(6.5/(.26*grid.step)/512))*512;dt=6.5/steps
    times=[];material=[];samples=[];initial_taylor=None
    for step in range(steps+1):
        if step%(steps//512)==0:
            h,mom,cons,flow=state
            aa,alpha,bb,ls,lp,mass,en,sr,st,current,eh,ed,vd,grad=grid.metric(state)
            q,mu,em,weight=grid.extra
            r,p,clock,jr,vr,ja,vt=probe;get=lambda val:grid.at(val,r)
            a=get(aa);al=get(alpha);W=np.hypot(1,p/a);v=p/a/W
            static=alpha*aa*(mass*grid.inv**2+grid.r*sr)
            dynamic=-grid.r*aa**2*current
            spatial=grid.first(static,-1)
            drdyn=grid.first(dynamic,-1)
            angular=W**2*(get(lp)/(a*a)+2*v*get(dynamic)/a**2+v*v*get(ls)/a**2)/r
            charge=get(q);rho=get(ed*(1-vd**2));lorD=get(weight)
            udot=W*lorD*(1-v*get(vd))
            sR=grid.at(en-sr+2*st-2*mass*grid.inv**3,r)
            sT=get(mass*grid.inv**3)+W**2*(get(sr)-2*v*get(current)+v*v*get(en))
            samples.append(np.stack([clock,r,jr,vr,ja,vt,get(h),W*(get(mom)+v*get(grad))/a,charge,al,a,W,v,
                get(spatial),get(dynamic),get(drdyn),angular,rho*(2*udot**2-1),sR,sT]))
            if initial_taylor is None:
                ddh=grid.second(h)+(2*grid.inv-ls)*grad
                h2=get(ddh/aa**2-h);h0=get(h)
                initial_taylor=np.stack([h0,h2,-h0*h0,4*h2*h2-2*h0*h2])
            baryon=grid.integral(grid.r**2*cons)
            labels=[brentq(lambda x:grid.at(baryon,np.array([x]))[0]-frac*BARYON,.25,4.95) for frac in (.1,.5,.9)]
            shell=np.asarray(labels);at=lambda value:grid.at(value,shell)
            a=at(aa);W=at(weight);v=at(vd);charge=at(q);mu0=at(mu)
            e=at(eh);j=at(-mom*grad/aa**2);s=at(eh-h*h)
            projected=W**2*((1+v*v)*j-v*(e+s))
            energypart=(at(flow)/a)**2-2*at(mass)/shell
            wminus=energypart/(1+W/a)+eta*charge/shell
            material.append(np.stack([shell,mu0,charge,at(alpha)/W,W*v/a,wminus,shell**2*W/a*(v*e-j),shell*projected]))
            times.append(step*dt)
        if step==steps:break
        k1,p1=grid.push(state,probe);k2,p2=grid.push(state+.5*dt*k1,probe+.5*dt*p1)
        k3,p3=grid.push(state+.5*dt*k2,probe+.5*dt*p2);k4,p4=grid.push(state+dt*k3,probe+dt*p3)
        state+=dt/6*(k1+2*k2+2*k3+k4);probe+=dt/6*(p1+2*p2+2*p3+p4)
    prefix="held-trace" if held else "trace"
    if extension is not None:
        prefix="sg-held"
    with (HERE/f"{prefix}-{count}-eta{eta:g}-h{amp:g}.npz").open("xb") as stream:
        np.savez_compressed(stream,time=times,samples=samples,material=material,taylor=initial_taylor)
    print("trace",count,eta,amp,flush=True)

if __name__=="__main__":acquire(int(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]),sys.argv[4:]==["held"])

