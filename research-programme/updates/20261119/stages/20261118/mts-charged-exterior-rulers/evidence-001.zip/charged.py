from pathlib import Path
import sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
SPHERE=HERE.parent/"mts-coupled-spherical-tides-20261118"
BOOT=HERE.parent/"mts-initial-geometry-bootstrap-20261118"
sys.path.insert(0,str(SPHERE))
from evolve import Grid, sha, np, guard as upstream_guard
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
import csv

LOCK="a4b597215705cfe2789627010a8694c41f6940a8dc621d4191e494edae9008e4"
CENTERS=(2.5,6.,14.,18.,36.)
TARGET=np.linspace(0,6.4,129)
KEYS=("clock","radius","Jr_offset","Jt_offset","radial_rate","angular_rate","tidal_r","tidal_t",
      "mass","charge","exterior_scalar","scalar_pressure_boost","scalar_kinetic","scalar_energy","mass_rate_exterior",
      "rho_d","v_d","v_probe","a","alpha","j_scalar","radial_ray_minus","radial_ray_plus","p_d","mass_plus_coulomb")
def guard():
    upstream_guard()
    assert sha(BOOT/"closeout.json")==LOCK and not (HERE/"STOP-REQUESTED").exists()
def table(name,rows):
    with (HERE/name).open("x",encoding="utf8",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def filename(count,eta,amp,scale=1.):
    return f"charged-{count}-eta{eta:g}-h{amp:g}-b{scale:g}.npz"
def read(count,eta,amp,scale=1.):
    with np.load(HERE/filename(count,eta,amp,scale),allow_pickle=False) as src:return dict(src)
def peak(values):return float(np.max(abs(values)))

class Charged(Grid):
    def __init__(self,count,eta):
        super().__init__(count)
        self.eta=eta
        self.probes=np.array([rad+offset for rad in CENTERS for offset in (-.05,-.025,0.,.025,.05)])
    def metric(self,state):
        r=self.r;inv=self.inv
        h,mom,dens,flow=state
        q=self.eta*self.integral(r*r*dens)
        grad=self.first(h,1);kin=.5*(grad**2+mom**2);pot=.5*h**2
        voltage=q*inv;electric=q*inv*inv;em=.5*electric**2
        factor=np.ones_like(r)
        for trial in range(10):
            weight=np.sqrt(1+flow**2*factor)
            dust=dens*np.sqrt(factor)*weight
            se=kin*factor+pot
            mu=self.integral(r*r*(dust+se)+self.eta*r*dens*q)
            mass=mu-.5*q*voltage
            updated=1-2*mass*inv
            assert min(updated)>.95
            if np.max(abs(updated-factor))<3e-15:break
            factor=updated
        else:raise ArithmeticError("charged Hamiltonian constraint")
        aa=1/np.sqrt(factor);v=flow/aa/weight
        energy=dust+se+em;sr=dust*v*v+se-2*pot-em
        st=.5*(mom**2-grad**2)*factor-pot+em
        current=dust*v-mom*grad*factor
        slope=(mass*inv**2+r*sr)/factor;logs=(r*energy-mass*inv**2)/factor
        integ=self.integral(r*(dust*(1+v*v)+2*kin*factor)/factor)
        alpha=np.exp(integ-integ[-1])/aa
        self.extra=(q,mu,em,weight)
        self.forcefactor=aa*alpha
        return aa,alpha,alpha/aa,logs,slope,mass,energy,sr,st,current,se,dust,v,grad
    def push(self,state,probe):
        actual=probe.copy();actual[[3,5]]+=1
        vals,steps=super().rhs(state,actual)
        q,mu,em,weight=self.extra
        forcefactor=self.forcefactor
        vals[3]+=self.eta*forcefactor*q*self.inv**2
        return vals,steps
    def observe(self,state,probe):
        aa,al,bb,ls,lp,mass,en,sr,st,jt,eh,ed,vd,grad=self.metric(state)
        q,mu,em,weight=self.extra
        rad,p,tau,jr,vr,ja,va=probe;get=lambda var:self.at(var,rad)
        a=get(aa);W=np.hypot(1,p/a);v=p/a/W
        scalarj=-state[1]*grad/aa**2;sp=eh-state[0]**2
        pressure=W**2*(get(sp)-2*v*get(scalarj)+v*v*get(eh))
        kin=(state[1]**2-grad**2)/aa**2
        movrate=rad**2*W/a*(v*get(eh)-get(scalarj))
        mean=mass*self.inv**3;mean[0]=en[0]/3
        tidr=get(en-sr+2*st-2*mean)
        tidt=get(mean)+W**2*(get(sr)-2*v*get(jt)+v*v*get(en))
        out=self.integral((self.r**2*eh)[::-1])[::-1]
        dens=state[2];rest=self.integral(self.r**2*dens)[-1]
        independent=self.integral(self.r**2*en)+.5*q*q*self.inv
        euler=ed*(1-vd**2)
        outside=mu[-1]-mu-out
        stats=np.array([mu[-1],q[-1],rest,peak(independent-mu),peak(2*mass*self.inv),
            peak(euler[self.r>=5.9]),peak(outside[self.r>=5.9]),min(1+jr),min(1+ja),max(abs(vd[self.r<=5.])),
            max(abs(state[:2,-5:]).ravel()),peak(self.eta*al*aa*q*self.inv**2-al*lp)])
        data=np.stack([tau,rad,jr,ja,vr,va,tidr,tidt,get(mass),get(q),get(out),pressure,get(kin),get(eh),movrate,
            get(euler),get(vd),v,a,get(al),get(scalarj),get((state[1]-grad)**2/aa**2),get((state[1]+grad)**2/aa**2),
            get(state[3]),get(mu)])
        return stats,data

def run(count,eta,amp,scale=1.):
    guard();grid=Charged(count,eta)
    state,probe=grid.initial("both" if amp else "dust","prepared" if amp else "bare",scale,amp)
    probe[[3,5]]-=1.
    initial=state.copy()
    steps=int(np.ceil(6.5/(.26*grid.step)/256))*256
    dt=6.5/steps;clocks=[];stats=[];values=[]
    for step in range(steps+1):
        if step%(steps//256)==0:
            budget,sample=grid.observe(state,probe);stats.append(budget);values.append(sample);clocks.append(step*dt)
        if step==steps:break
        k1,p1=grid.push(state,probe);k2,p2=grid.push(state+.5*dt*k1,probe+.5*dt*p1)
        k3,p3=grid.push(state+.5*dt*k2,probe+.5*dt*p2);k4,p4=grid.push(state+dt*k3,probe+dt*p3)
        state+=dt/6*(k1+2*k2+2*k3+k4);probe+=dt/6*(p1+2*p2+2*p3+p4)
    assert np.all(np.isfinite(values)) and np.all(np.isfinite(stats))
    with (HERE/filename(count,eta,amp,scale)).open("xb") as stream:
        np.savez_compressed(stream,eta=eta,amp=amp,scale=scale,time=clocks,stats=stats,events=values,keys=KEYS,
            grid=grid.r,initial=initial,final=state,labels=grid.probes)
    print(filename(count,eta,amp,scale),flush=True)


if __name__=="__main__":
    run(int(sys.argv[1]),*map(float,sys.argv[2:]))

