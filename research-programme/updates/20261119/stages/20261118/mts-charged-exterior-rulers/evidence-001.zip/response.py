from reference import *
from scipy.integrate import cumulative_simpson

READOUT=("Jr_offset","Jt_offset","tidal_r","tidal_t")


def initial_adm_excess(count,eta,amp):
    grid=Charged(count,eta)
    state,_=grid.initial("both","prepared",1.,amp)
    full=grid.metric(state)
    core,_=grid.initial("dust","bare",1.,0)
    ref=grid.metric(core)
    factor=np.exp(grid.integral(2*grid.r*state[2]/(1/full[0]+1/ref[0])))
    return (grid.integral(factor*grid.r**2*full[10])/factor)[-1]


def defect(source,slot,mass,q,shift):
    radius=CENTERS[slot]
    obs=source["events"][:,:,5*slot+2]
    time=obs[:,0]
    scales=source["amp"]**2*.0008**2
    terms=obs[:,[KEYS.index(k) for k in ("exterior_scalar","scalar_pressure_boost","scalar_kinetic")]]
    forc=CubicSpline(time,terms/scales,axis=0)
    def ode(t,state):
        ref,ur,refj,rate,dx,vel,dj,speed=state
        r=ref+scales*dx
        out,stress,kin=forc(t);delta=shift/scales-out
        fb=-mass/ref**2+q*q/ref**3;kb=2*mass/ref**3-3*q*q/ref**4
        k=2*mass/r**3-3*q*q/r**4
        fquot=mass*(r+ref)/(r**2*ref**2)-q*q*(r*r+r*ref+ref**2)/(r**3*ref**3)
        kquot=-2*mass*(r*r+r*ref+ref**2)/(r**3*ref**3)+3*q*q*(r+ref)*(r*r+ref*ref)/(r**4*ref**4)
        correction=2*delta/r**3-kin
        return [ur,fb,rate,kb*(1+refj),vel,fquot*dx-delta/r**2-r*stress,
            speed,(k+scales*correction)*dj+(kquot*dx+correction)*(1+refj)]
    sol=solve_ivp(ode,(0,6.4),[radius,0,0,0,0,0,0,0],t_eval=TARGET,method="DOP853",rtol=2e-12,atol=1e-17,max_step=.1)
    assert sol.success
    ref,ur,refj,rate,dx,vr,dj,vj=sol.y;r=ref+scales*dx
    out,stress,kin=forc(TARGET).T;delta=shift/scales-out
    kquot=-2*mass*(r*r+r*ref+ref**2)/(r**3*ref**3)+3*q*q*(r+ref)*(r*r+ref*ref)/(r**4*ref**4)
    tangquot=-mass*(r*r+r*ref+ref**2)/(r**3*ref**3)+q*q*(r+ref)*(r*r+ref*ref)/(r**4*ref**4)
    return scales*np.stack([dj,dx/radius,-kquot*dx-2*delta/r**3+kin,tangquot*dx+delta/r**3+stress],axis=1)

def compute():
    guard();rows=[];points=[];scaling=[];waves={}
    for n in (960,1920):
        core=read(n,.8,0)
        q=core["stats"][0,1];mass0=core["stats"][0,0]
        for amp in (1/160,1.):
            src=read(n,.8,amp)
            extra=initial_adm_excess(n,.8,amp)
            assert abs(extra-(src["stats"][0,0]-mass0))<5e-16
            for slot,radius in enumerate(CENTERS[1:],start=1):
                base=common(core,slot);actual=common(src,slot)
                ref0=rn(mass0,q,radius)
                eout,press,kin=actual[0,[KEYS.index(k) for k in ("exterior_scalar","scalar_pressure_boost","scalar_kinetic")]]
                co=2*eout/radius**3+kin;ct=-eout/radius**3+press
                points.append(dict(mesh=n,amp=amp,r0=radius,total_mass_increment=extra,initial_exterior_scalar=eout,
                    initial_inside_corrected_mass_increment=extra-eout,initial_same_ADM_radial_curvature_shift=co,
                    initial_same_ADM_neutral_acceleration_shift=-radius*ct,pressure_initial=press,kinetic_initial=kin))
                for convention in ("same-core","same-ADM"):
                    mass=mass0 if convention=="same-core" else mass0+extra
                    wave=defect(src,slot,mass,q,extra if convention=="same-core" else 0.)
                    waves[n,amp,radius,convention]=wave
                    ref=rn(mass,q,radius)
                    for k,key in enumerate(READOUT):
                        actual_curve=actual[:,KEYS.index(key)]
                        baseline=base[:,KEYS.index(key)]
                        raw=actual_curve-(baseline if convention=="same-core" else ref[key])
                        corrected=(actual_curve-baseline)-(ref[key]-ref0[key])
                        mag=peak(wave[:,k])
                        eigensilent=radius==36 and convention=="same-ADM"
                        rows.append(dict(mesh=n,amplitude=amp,r0=radius,matching=convention,quantity=key,peak=mag,
                            signed_final=wave[-1,k],raw_error=peak(raw-wave[:,k]),paired_error=peak(corrected-wave[:,k]),
                            raw_relative=peak(raw-wave[:,k])/mag if not eigensilent else None,
                            paired_relative=peak(corrected-wave[:,k])/mag if not eigensilent else None,
                            exterior_null=eigensilent))
    for amp in (1/160,1.):
        for rad in CENTERS[1:]:
            for match in ("same-core","same-ADM"):
                fine=waves[1920,amp,rad,match];coarse=waves[960,amp,rad,match]
                for k,key in enumerate(READOUT):
                    mag=peak(fine[:,k]);isnull=match=="same-ADM" and rad==36
                    err=peak(fine[:,k]-coarse[:,k])
                    scaling.append(dict(amplitude=amp,r0=rad,matching=match,quantity=key,mesh_difference=err,
                        own_scale=err/mag if not isnull else None,passes=err<2e-5*mag if not isnull else None))
    return rows,points,scaling


if __name__=="__main__":
    rows,initial,mesh=compute();table("resolved-scalar-response.csv",rows);table("initial-source-split.csv",initial);table("response-refinement.csv",mesh)

