from trace_test import *
from scipy.special import beta
from relational import interp as old_interp

def corrected_energy(packet,eta,slot):
    vals=packet["material"][:,:,slot]
    r,mu,q,clock,velocity,legacy,rate,flux=vals.T
    delta=velocity**2-2*mu/r+(q/r)**2
    root=np.sqrt(1+delta)
    return delta/(1+root)+eta*q/r

def source_checks():
    guard();works=[];controls=[]
    for n in (960,1920):
        core=loadtrace(n,.8,0)
        for amp in (1/160,1.):
            src=loadtrace(n,.8,amp)
            for slot,frac in enumerate((.1,.5,.9)):
                vals=src["material"][:,:,slot];base=core["material"][:,:,slot]
                active=corrected_energy(src,.8,slot);bare=corrected_energy(core,.8,slot)
                prediction=cumulative_simpson(vals[:,7]*vals[:,3],x=src["time"],initial=0)
                old=(vals[:,5]-base[:,5])-(vals[0,5]-base[0,5])
                measured=(active-bare)-(active[0]-bare[0])
                denom=peak(prediction)
                works.append(dict(mesh=n,amp=amp,shell=frac,work_peak=denom,old_relative_error=peak(old-prediction)/denom,
                    repaired_raw=peak(active-active[0]-prediction)/denom,repaired_paired=peak(measured-prediction)/denom,
                    passes=peak(measured-prediction)<2e-5*denom))
    plus=read(960,.8,1/160);minus=read(960,-.8,1/160)
    for name in ("time","initial","final"):
        assert np.array_equal(plus[name],minus[name])
    sign=np.ones(len(KEYS));sign[KEYS.index("charge")]=-1
    parity=peak(plus["events"]*sign[None,:,None]-minus["events"])
    controls.append(dict(control="signed charge reversal, physical histories",radius="",absolute=parity,scale=1.,tolerance=0.,passes=parity==0.))
    for n in (960,1920):
        packet=read(n,1,0);r=packet["grid"];inv=np.zeros_like(r);inv[1:]=1/r[1:]
        grid=Charged(n,1.);metric=grid.metric(packet["initial"]);q,mu,_,_=grid.extra
        for key,error,scale in (("balanced static metric",peak(1/metric[0]-(1-q*inv)),peak(q*inv)),("balanced mass",peak(mu-q),peak(q)),
                ("charged dust equilibrium",peak(packet["final"]-packet["initial"]),peak(packet["initial"]))):
            controls.append(dict(control=f"{key} {n}",radius="",absolute=error,scale=scale,tolerance=2e-5,passes=error<2e-5*scale))
    for amp,previous in ((0.,"account-1920-dust-bare.npz"),(1/160,"account-1920-both-prepared-h0.00625.npz")):
        active=read(1920,0,amp)
        with np.load(SPHERE/previous) as held:
            for slot,(r,idx) in enumerate(((2.5,1),(6.,4))):
                old=held["events"][:,:,idx]
                current=common(active,slot)
                for col,field in ((2,"Jr_offset"),(3,"Jt_offset")):
                    expect=old_interp(old[:,0],old[:,col,None],TARGET)[:,0]
                    err=peak(current[:,KEYS.index(field)]-expect)
                    controls.append(dict(control=f"zero charge {field} h={amp}",radius=r,absolute=err,scale=peak(expect),
                        tolerance=2e-5,passes=err<2e-5*peak(expect)))
    return works,controls

if __name__=="__main__":
    w,c=source_checks();table("repaired-shell-energy.csv",w);table("retained-controls.csv",c)

