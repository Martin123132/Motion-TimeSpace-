from math import comb
import json

from reference import BARYON, DMAX, HERE, TARGET, core_adm, guard, peak, sha
import numpy as np
from numpy.polynomial import Polynomial
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline, RectBivariateSpline
from scipy.special import betainc

RADII = np.array([12.75, 14., 18., 19.25, 20.])
CHARGE = .8 * BARYON
END = 6.52
INNER = 5.1


def preparation(radius):
    constant = BARYON * 25 / 17
    safe = np.maximum(radius, 5.)
    chi = -BARYON * (safe-12) + constant * (1/12-1/safe)
    slope = -BARYON + constant / safe**2
    inner = np.minimum(radius, 5.)
    power = np.zeros(15)
    for index in range(7):
        degree = 2*index + 2
        power[degree] = DMAX * comb(6, index) * (-1/25)**index / (degree*(degree+1))
    potential = Polynomial(power)
    power[0] = -BARYON/5 - potential(5.)
    radial = Polynomial([0., 0., *[2*value/((deg+2)*(deg+3)) for deg,value in enumerate(power)]])
    chi = np.where(radius<5, radial(inner)-radial(5.)+7*BARYON+constant*(1/12-1/5), chi)
    slope = np.where(radius<5, radial.deriv()(inner), slope)
    def taper(start, width):
        scaled = np.clip((radius-start)/width, 0., 1.)
        return 1-betainc(6,6,scaled), -2772*scaled**5*(1-scaled)**5/width
    flatten, dflatten = taper(10.,5.)
    envelope, denvelope = taper(16.,10.)
    return (.0008*(1+chi*flatten)*envelope,
            .0008*((slope*flatten+chi*dflatten)*envelope+(1+chi*flatten)*denvelope))


def adm_variation():
    def rhs(radius, state):
        if radius==0:
            return [0.,0.]
        enclosed, second = state
        density = DMAX * max(0., 1-(radius/5)**2)**6
        charge = CHARGE*betainc(1.5,7,min(1.,(radius/5)**2))
        factor = 1 - 2*enclosed/radius + (charge/radius)**2
        value, derivative = preparation(radius)
        return [density*(radius**2*np.sqrt(factor)+.8*charge*radius),
                .5*radius**2*(factor*derivative**2+value**2)-radius*density*second/np.sqrt(factor)]
    state = [0.,0.]
    for left,right in [(0.,5.),(5.,10.),(10.,15.),(15.,16.),(16.,26.)]:
        sol = solve_ivp(rhs,(left,right),state,method="DOP853",rtol=2e-13,atol=2e-17,max_step=.18)
        assert sol.success
        state = sol.y[:,-1]
    assert abs(state[0]-core_adm(1.,CHARGE))<1e-15
    return state


def calculate(count):
    guard()
    mass, second_mass = adm_variation()
    root = np.sqrt(mass**2-CHARGE**2)
    outer, inside = mass+root, mass-root
    def factor(radius):
        return 1-2*mass/radius+(CHARGE/radius)**2
    def optical(radius):
        return radius-INNER+(outer**2*np.log1p((radius-INNER)/(INNER-outer))
                  -inside**2*np.log1p((radius-INNER)/(INNER-inside)))/(2*root)
    axis = np.linspace(0,optical(44.),count+1)
    spacing = axis[1]
    radius = axis+INNER
    for iteration in range(5):
        radius -= factor(radius)*(optical(radius)-axis)
    metric = factor(radius)
    potential = 1+2*mass/radius**3-2*CHARGE**2/radius**4
    def first(values):
        out = np.empty_like(values)
        out[2:-2]=(values[:-4]-8*values[1:-3]+8*values[3:-1]-values[4:])/(12*spacing)
        out[0:2] = [(values[1]-values[0])/spacing,(values[2]-values[0])/(2*spacing)]
        out[-2:] = [(values[-1]-values[-3])/(2*spacing),(values[-1]-values[-2])/spacing]
        return out
    def lap(values):
        out=np.zeros_like(values)
        out[2:-2]=(-values[4:]+16*values[3:-1]-30*values[2:-2]+16*values[1:-3]-values[:-4])/(12*spacing**2)
        out[1]=(values[2]-2*values[1]+values[0])/spacing**2
        out[-2]=(values[-3]-2*values[-2]+values[-1])/spacing**2
        return out
    def tail(values):
        rev=(metric*values)[::-1]
        out=np.empty_like(rev)
        out[0]=0.
        left,mid,right=rev[:-2:2],rev[1::2],rev[2::2]
        out[2::2]=np.cumsum(spacing/3*(left+4*mid+right))
        out[1::2]=out[:-2:2]+spacing/12*(5*left+8*mid-right)
        return out[::-1]
    def coefficients(linear, speed):
        gradient=first(linear)
        field=linear/radius
        pi=speed/(metric*radius)
        radial=gradient/(metric*radius)-field/radius
        energy=.5*(metric*(pi**2+radial**2)+field**2)
        mu=second_mass-tail(radius**2*energy)
        lapse=-tail(radius*(pi**2+radial**2))
        return gradient, field, pi, radial, energy, mu, lapse
    def rate(state):
        linear,speed,cubic,third_speed=state
        gradient,field,pi,radial,energy,mu,lapse=coefficients(linear,speed)
        ratio=lapse-2*mu/(radius*metric)
        vsecond=lapse*potential+2*mu/radius**3-field**2
        out=np.stack([speed,lap(linear)-metric*potential*linear,third_speed+ratio*speed,
                      lap(cubic)-metric*potential*cubic+first(ratio*gradient)-metric*vsecond*linear])
        out[:,[0,-1]]=0.
        return out
    state=np.zeros((4,count+1))
    state[0]=radius*preparation(radius)[0]
    slots=np.rint(optical(RADII)/spacing).astype(int)[:,None]+np.arange(-6,7)
    steps=int(np.ceil(END/(.45*spacing)/512))*512
    step=END/steps
    history=[]
    for index in range(steps+1):
        if index%(steps//512)==0:
            gradient,field,pi,radial,energy,mu,lapse=coefficients(*state[:2])
            history.append(np.stack([field,state[1]/radius,radial,state[2]/radius,energy,pi,mu,lapse])[:,slots])
        if index==steps:
            break
        first_rate=rate(state)
        second_rate=rate(state+.5*step*first_rate)
        third_rate=rate(state+.5*step*second_rate)
        fourth_rate=rate(state+step*third_rate)
        state+=step/6*(first_rate+2*second_rate+2*third_rate+fourth_rate)
    times=np.linspace(0,END,513)
    history=np.array(history)
    dense=np.linspace(0,TARGET[-1],1025)
    curves=[]
    for slot,start in enumerate(RADII):
        splines=[RectBivariateSpline(times,axis[slots[slot]],piece) for piece in history[:,:,slot,:].transpose(1,0,2)]
        conserved=np.sqrt(factor(start))
        def trajectory(proper,state):
            position,momentum,time,shift,rate_shift,clock_shift=state
            base=factor(position)
            coord=optical(position)
            field,dt_field,spatial,cubic,energy,pi,mu,lapse=[s.ev(time,coord).item() for s in splines]
            velocity=momentum/conserved
            pressure=conserved**2/base*(energy-field**2+2*velocity*base*pi*spatial+velocity**2*energy)
            delta=(2*mass/position**2-2*CHARGE**2/position**3)*shift-2*mu/position
            return [momentum,-mass/position**2+CHARGE**2/position**3,conserved/base,rate_shift,
                    (2*mass/position**3-3*CHARGE**2/position**4)*shift-mu/position**2-position*pressure,
                    conserved/base*((delta+2*momentum*rate_shift)/(2*conserved**2)-lapse-delta/base)]
        sol=solve_ivp(trajectory,(0,TARGET[-1]),[start,0.,0.,0.,0.,0.],method="DOP853",rtol=1e-13,
                      atol=1e-17,t_eval=dense,max_step=.08)
        assert sol.success
        position,momentum,time,shift,rate_shift,clock_shift=sol.y
        coord=optical(position)
        assert min(coord)>END and max(time)<END and min(coord)>axis[slots[slot,0]] and max(coord)<axis[slots[slot,-1]]
        field,dt_field,spatial,cubic=[s.ev(time,coord) for s in splines[:4]]
        derivative=dt_field*conserved/factor(position)+spatial*momentum
        pieces=[cubic,shift*spatial,clock_shift*dt_field]
        def contribution(piece):
            drate=CubicSpline(dense,piece,bc_type=((1,0.),'not-a-knot'))(dense,1)
            return (4*derivative*drate-2*field*piece)[::8]
        curves.append([(2*derivative**2-field**2)[::8],*[contribution(piece) for piece in pieces]])
    path=HERE/f"sg-forecast-{count}.npz"
    with path.open("xb") as stream:
        np.savez_compressed(stream,time=TARGET,radii=RADII,orders=curves,adm_variation=second_mass)


def freeze():
    files={}
    for count in (960,1920,3840):
        path=HERE/f"sg-forecast-{count}.npz"
        calculate(count)
        files[path.name]=sha(path)
    receipt=dict(files=files,predictor=sha(HERE/"selfgravity.py"),protocol=sha(HERE/"SELF-GRAVITY-PREDICTION.md"),
                 new_radius=19.25,new_amplitude=.75,orders=["I2","I4 field","I4 displacement","I4 clock"],
                 relative_gate=2e-5,reference_sha=sha(HERE/"frozen-wave.json"))
    with (HERE/"frozen-selfgravity.json").open("x",encoding="utf8") as stream:
        json.dump(receipt,stream,indent=2,sort_keys=True)
    print(sha(HERE/"frozen-selfgravity.json"))

if __name__=="__main__":
    freeze()

