import csv
import math
from fractions import Fraction
from charged import BOOT, guard, table
from reference import DMAX,BARYON

def initial_integrals():
    with (BOOT/"initial-polynomial-integrals.csv").open(encoding="utf8") as stream:rows=list(csv.DictReader(stream))
    return [float(sum(Fraction(r["exact_square_integral"]) for r in rows if int(r["derivative"])==order)) for order in range(3)]

def bounds(amplitude,charge=.0016):
    terms=initial_integrals();s=6.;end=6.5;outer=33.;epsilon=.00012*amplitude**2
    y0=abs(amplitude)*math.sqrt(terms[0]+terms[1]);y1=abs(amplitude)*math.sqrt(terms[1]+terms[2])
    exterior=.5*y0**2
    adm=BARYON+exterior+abs(charge/BARYON)*abs(charge)*25*DMAX/14
    max_electric=abs(charge/BARYON)*(DMAX/3)**(2/3)*BARYON**(1/3)
    initial_e=DMAX+1.125*(.022055*amplitude)**2+.5*max_electric**2
    compact=2*(adm**2*initial_e/3)**(1/3)
    adm_low=BARYON*math.sqrt(1-compact)
    assert adm_low-exterior-charge**2/(2*s)>0
    a=1/math.sqrt(1-2*adm/s);flower=math.exp(-2*a*a*exterior/s)
    h2=min(2*epsilon,2*a*a*exterior/s)
    k=2*adm/s**3+2*charge**2/s**4+h2
    br=2*adm/s**2+2*charge**2/s**3+min(outer*2*epsilon,2*a*a*exterior)
    kr=2*epsilon/s+6*adm/s**4+8*charge**2/s**5+2*a*epsilon
    rkr=2*epsilon+6*adm/s**3+8*charge**2/s**4+2*outer*a*epsilon
    fr=2*a*a*outer*epsilon
    brr=fr*br/flower+k+rkr
    vr=fr*(1+k)+kr
    drift=k+2*adm/s
    x0=y0*math.exp(.5*(br+drift)*end)
    x1=math.exp(.5*(3*br+drift+brr)*end)*(y1+(brr+vr+br)*x0*end)
    def local(r):
        return (2*x0*x1+2*x1*x1+(1+2/r**2)*x0*x0)/(2*r*r)
    return locals_ledger(s,end,outer,epsilon,exterior,adm,compact,adm_low,a,flower,br,brr,vr,drift,x0,x1,local)

def locals_ledger(s,end,outer,trial,exterior,adm,compact,adm_low,a,flower,br,brr,vr,drift,x0,x1,local):
    return dict(cut=s,end=end,support=outer,trial=trial,exterior_mass_cap=exterior,adm_upper=adm,
        initial_compactness_upper=compact,adm_lower=adm_low,radial_metric_upper=a,F_lower=flower,
        B_r_upper=br,B_rr_upper=brr,V_r_upper=vr,B_minus_V_upper=drift,Y0=x0,Y1=x1,
        improved_stress=local(s),closes=local(s)<trial,local=local)

def certs():
    rows=[]
    for amp in (1/160,1.):
        b=bounds(amp);q=.0016
        for rad in (6.,14.,18.,36.):
            low=.95*rad;hi=1.05*rad;T=6.4;vel=.02
            causal=low>b["cut"]+b["end"];silent=low>26+b["end"]
            eps=b["local"](low) if not silent else 0
            dm=b["exterior_mass_cap"] if not silent else 0
            mass=b["adm_upper"];boost=(1+vel)/(1-vel)
            acc=mass/low**2+q*q/low**3+hi*boost*eps
            speed=b["radial_metric_upper"]*b["end"]*acc
            excursion=.5*b["end"]**2*acc
            proper=b["end"]*b["F_lower"]*math.sqrt(1-vel**2)/b["radial_metric_upper"]
            isvalid=causal and (b["closes"] or silent) and speed<vel and excursion<.05*rad and proper>T
            kernel=lambda k:2*math.sinh(.5*T*math.sqrt(k))**2/k
            kr=2*mass/low**3+3*q*q/low**4
            dr=(dm/low**2+hi*boost*eps)*kernel(kr)
            residual=2*dm/low**3+2*eps
            dj=math.cosh(math.sqrt(kr)*T)*(residual+(6*mass/low**4+12*q*q/low**5)*dr)*kernel(kr+residual)
            rows.append(dict(amp=amp,r0=rad,causal_domain=causal,stress_box_closed=b["closes"],beyond_all_scalar=silent,
                candidate_stress_at_cut=b["improved_stress"],trial=b["trial"],exterior_energy_upper=b["exterior_mass_cap"],
                clock_reached=proper,velocity_ceiling=speed,radius_excursion=excursion,initial_only_certificate=isvalid,
                angular_ceiling=dr/rad if isvalid else None,radial_ceiling=dj if isvalid else None,
                below_original_target=max(dr/rad,dj)<2e-5 if isvalid else None))
    return rows


if __name__=="__main__":
    guard();table("exterior-initial-data.csv",certs())

