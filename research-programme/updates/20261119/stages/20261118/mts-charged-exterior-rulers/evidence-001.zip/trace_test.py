from flux_trace import *

def loadtrace(count,eta,amp):
    with np.load(HERE/f"trace-{count}-eta{eta:g}-h{amp:g}.npz") as src:return dict(src)

def traces(src,slot):
    yy=src["samples"][:,:,slot];t=src["time"]
    (tau,r,jr,vr,ja,vt,h,dh,q,al,a,W,v,ds,dy,drdy,angular,dust,sr,st)=yy.T
    field=CubicSpline(tau,h)
    div=CubicSpline(t,dy)(t,1)-al/a*v*drdy
    geom=(ds-div)/(al*a)+2*angular
    rulers= -CubicSpline(tau,vr)(tau,1)/(1+jr)-2*CubicSpline(tau,vt)(tau,1)/(1+ja)
    subtract=q*q/r**4+dust
    curves=[2*field(tau,1)**2-h*h,sr+2*st-subtract,geom-subtract,rulers-subtract,
        2*dh*dh-h*h,dh,field(tau,1)]
    return np.array([CubicSpline(tau,curve)(TARGET) for curve in curves]),(tau,sr+2*st-subtract),src["taylor"][:,slot]

def taylor2(time,trace):
    from numpy.polynomial import Polynomial
    scale=time[8]
    fit=Polynomial.fit(time[:9]/scale,trace[:9]-trace[0],deg=8)
    return float(fit.deriv(2)(0)/scale**2)

def identities():
    guard();rows=[];zeros=[];works=[];nulls=[];curves={}
    for n,eta,amps in ((960,.8,(0.,1/160,1.)),(1920,.8,(0.,1/160,1.)),(1920,0.,(0.,)),(1920,1.,(0.,))):
        background=loadtrace(n,eta,0.)
        for amp in amps:
            src=loadtrace(n,eta,amp)
            for slot,radius in enumerate(CENTERS):
                current,(time,trace),initial=traces(src,slot);ref=traces(background,slot)[0]
                cur=current[0];curves[n,eta,amp,radius]=current
                if amp==0 or radius==36:
                    if slot:
                        nulls.append(dict(mesh=n,eta=eta,amp=amp,r0=radius,stress_abs=peak(current[1]),
                            connection_abs=peak(current[2]),ruler_abs=peak(current[3]),measured_scalar_abs=peak(cur),
                            electric_curvature=(eta*BARYON/radius**2)**2))
                    continue
                denom=peak(cur)
                for index,kind in ((1,"direct-curvature"),(2,"differentiated-connection"),(3,"differentiated-rulers"),(4,"independent-field-clock")):
                    for paired in (False,True):
                        test=current[index]-(ref[index] if paired else 0.)
                        err=peak(test-cur)
                        rows.append(dict(mesh=n,amp=amp,r0=radius,method=kind,ordinary_error_subtraction=paired,
                            peak_trace=denom,absolute_error=err,relative=err/denom,passes=err/denom<2e-5))
                h0,h2,initial_trace,curvature=initial
                plane=h0*h0*(.5-1.5*np.cos(2*TARGET))
                zeros_at=np.where(cur[:-1]*cur[1:]<0)[0]
                root=brentq(CubicSpline(TARGET,cur),TARGET[zeros_at[0]],TARGET[zeros_at[0]+1]) if len(zeros_at) else None
                est=taylor2(time,trace)
                zeros.append(dict(mesh=n,amp=amp,r0=radius,initial_trace=trace[0],predicted_initial=initial_trace,
                    second_derivative_prediction=curvature,second_derivative_direct=est,
                    own_second_derivative_error=abs(est/curvature-1),flat_template_error=peak(plane-cur)/denom,
                    first_zero=root,flat_template_zero=math.atan(1/math.sqrt(2)),geometry_peak=max(abs(current[1]))))
            if amp:
                for slot,frac in enumerate((.1,.5,.9)):
                    data=src["material"][:,:,slot];bare=background["material"][:,:,slot]
                    for k,rate,name in ((1,6,"Coulomb-corrected mass"),(5,7,"shell energy")):
                        pred=cumulative_simpson(data[:,rate]*data[:,3],x=src["time"],initial=0.)
                        measured=data[:,k]-data[0,k]
                        correction=bare[:,k]-bare[0,k]
                        signal=peak(pred)
                        works.append(dict(mesh=n,amp=amp,baryon_fraction=frac,identity=name,predicted_peak=signal,
                            raw_error_fraction=peak(measured-pred)/signal,matched_error_fraction=peak(measured-correction-pred)/signal,
                            gauss_charge_error=peak(data[:,2]-eta*BARYON*frac)))
    return rows,zeros,works,nulls


if __name__=="__main__":
    rows,zeros,works,nulls=identities()
    table("local-trace-controls.csv",rows);table("local-phase-predictions.csv",zeros)
    table("comoving-charge-shell-work.csv",works);table("absolute-trace-nulls.csv",nulls)

