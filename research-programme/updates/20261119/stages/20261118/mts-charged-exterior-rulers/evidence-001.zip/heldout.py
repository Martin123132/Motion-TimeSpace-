from trace_test import *
from rn_wave import RADII
import json

FROZEN="1bebe93fabaf04de123f32cb0c701df744764f0c228d0d3498a1de38855c94a6"
def held(mesh,amp):
    with np.load(HERE/f"held-trace-{mesh}-eta0.8-h{amp:g}.npz") as src:return dict(src)
def location(series):
    points=np.flatnonzero(series[:-1]*series[1:]<0)
    return brentq(CubicSpline(TARGET,series),TARGET[points[0]],TARGET[points[0]+1]) if points.size else None
def evaluate():
    guard()
    path=HERE/"frozen-wave.json"
    assert sha(path)==FROZEN
    receipt=json.loads(path.read_text(encoding="utf8"))
    assert sha(HERE/"rn_wave.py")==receipt["predictor"] and sha(HERE/"RN-WAVE-PREDICTION.md")==receipt["protocol"]
    banks={}
    for file,digest in receipt["files"].items():
        assert sha(HERE/file)==digest
        with np.load(HERE/file) as src:banks[file]=src["curves"]
    fetch=lambda n,left,flat:banks[f"rn-wave-{n}-left{left:g}-flat{int(flat)}.npz"]
    base=held(1920,0);rows=[];tests=[];ratios=[];errors={}
    for amp in (1/160,.5,1.):
        actual=held(1920,amp);coarse=held(960,amp) if amp==1/160 else None
        for slot,radius in enumerate(RADII):
            got=traces(actual,slot)[0];background=traces(base,slot)[0]
            predicted=fetch(3840,5.1,False)[slot,2]*amp**2
            oldgrid=fetch(1920,5.1,False)[slot,2]*amp**2
            low=fetch(960,5.1,False)[slot,2]*amp**2
            shifted=fetch(1920,5.7,False)[slot,2]*amp**2
            flat=fetch(3840,5.1,True)[slot,2]*amp**2
            mag=peak(got[0]);plane=predicted[0]*(1.5*np.cos(2*TARGET)-.5)
            err=predicted-got[0];errors[amp,slot]=err
            coarseerr=peak(traces(coarse,slot)[0][0]-got[0])/mag if coarse else None
            for name,target in (("clock field",got[0]),("electric-subtracted curvature",got[1]),("paired metric connection",got[2]-background[2]),
                                ("neutral rulers",got[3])):
                relative=peak(predicted-target)/mag
                rows.append(dict(amp=amp,r0=radius,held_out_radius=radius in (12.75,20),readout=name,peak=mag,
                    prediction_error=relative,passes=relative<2e-5,predicted_zero=location(predicted),actual_zero=location(target)))
            tests.append(dict(amp=amp,r0=radius,predictor_960_1920=peak(low-oldgrid)/mag,predictor_1920_3840=peak(predicted-oldgrid)/mag,
                changed_inner_boundary_and_grid=peak(oldgrid-shifted)/mag,nonlinear_mesh=coarseerr,uniform_cosine_error=peak(plane-got[0])/mag,
                free_radial_KG_error=peak(flat-got[0])/mag,charged_background_KG_error=peak(err)/mag))
    for slot,rad in enumerate(RADII):
        full=errors[1.,slot];half=errors[.5,slot]
        ratios.append(dict(r0=rad,full_remainder=peak(full),half_remainder=peak(half),half_over_full=peak(half)/peak(full),
            predicted_asymptotic_ratio=1/16,scaled_waveform_mismatch=peak(16*half-full)/peak(full)))
    return rows,tests,ratios

if __name__=="__main__":
    rows,tests,ratios=evaluate()
    table("frozen-wave-tests.csv",rows);table("wave-resolution.csv",tests);table("nonlinear-remainder.csv",ratios)

