import json
from flux_trace import acquire
from trace_test import traces
from selfgravity import RADII
from reference import HERE, TARGET, guard, np, peak, sha, table
import sys

SEAL="85a51c9cd60e054870ac36b36516dce2221beb7db1bd95a3899361582a03990e"
AMPLITUDES=(0.,.5,.75,1.)
MESHES=(960,1920)
NAMES=("clock derivative","curvature","paired connection","rulers","transported field")


def forecast():
    path=HERE/"frozen-selfgravity.json"
    assert sha(path)==SEAL
    receipt=json.loads(path.read_text(encoding="utf8"))
    assert sha(HERE/"selfgravity.py")==receipt["predictor"]
    assert sha(HERE/"SELF-GRAVITY-PREDICTION.md")==receipt["protocol"]
    assert sha(HERE/"frozen-wave.json")==receipt["reference_sha"]
    bank={}
    for count in (960,1920,3840):
        name=f"sg-forecast-{count}.npz"
        assert sha(HERE/name)==receipt["files"][name]
        with np.load(HERE/name,allow_pickle=False) as src:
            assert np.array_equal(src["time"],TARGET) and np.array_equal(src["radii"],RADII)
            bank[count]=src["orders"]
    return bank


def run():
    guard()
    forecast()
    for count in MESHES:
        for amp in AMPLITUDES:
            path=HERE/f"sg-held-{count}-eta0.8-h{amp:g}.npz"
            if path.exists():
                raise FileExistsError(path)
            acquire(count,.8,amp,extension="selfgravity")


def evaluate():
    guard()
    pred=forecast()
    latest=pred[3840]
    fine4=latest[:,1:].sum(axis=1)
    rows=[];orders=[];resolution=[]
    for count in MESHES:
        measured={}
        for amp in AMPLITUDES:
            with np.load(HERE/f"sg-held-{count}-eta0.8-h{amp:g}.npz",allow_pickle=False) as src:
                measured[amp]=np.array([traces(src,slot)[0][:5] for slot in range(len(RADII))])
            measured[amp][:,2]-=measured[0.][:,2] if amp else 0.
        for slot,radius in enumerate(RADII):
            quadratic=latest[slot,0]
            quartic=fine4[slot]
            for amp in AMPLITUDES[1:]:
                fixed=amp**2*quadratic
                correction=amp**4*quartic
                for index,name in enumerate(NAMES):
                    data=measured[amp][slot,index]
                    scale=peak(measured[amp][slot,0])
                    before=peak(data-fixed)/scale
                    after=peak(data-fixed-correction)/scale
                    rows.append(dict(mesh=count,r0=radius,amp=amp,method=name,prior_error=before,
                        corrected_error=after,passes=after<2e-5,new_radius=radius==19.25,
                        no_field=peak(data-fixed-amp**4*latest[slot,2:].sum(axis=0))/scale,
                        no_clock=peak(data-fixed-amp**4*latest[slot,1:3].sum(axis=0))/scale))
            for index,name in enumerate(NAMES):
                field=lambda amp:measured[amp][slot,index]/amp**2
                def slope(left,right):
                    return (field(right)-field(left))/(right**2-left**2)
                low=slope(.5,.75);high=slope(.75,1.)
                low_x=.5**2+.75**2;high_x=.75**2+1.
                recovered=(high_x*low-low_x*high)/(high_x-low_x)
                mag=peak(quartic)
                error=peak(recovered-quartic)/mag
                orders.append(dict(mesh=count,r0=radius,method=name,quartic_peak=mag,low_secant_error=peak(low-quartic)/mag,
                    high_secant_error=peak(high-quartic)/mag,extrapolated_error=error,passes=error<2e-5,
                    missing_clock=peak(recovered-latest[slot,1:3].sum(axis=0))/mag,
                    missing_field=peak(recovered-latest[slot,2:].sum(axis=0))/mag))
            if count==1920:
                with np.load(HERE/"rn-wave-3840-left5.1-flat0.npz") as prior:
                    hits=np.flatnonzero(prior["radii"]==radius)
                    cross=peak(prior["curves"][hits[0],2]-quadratic)/peak(quadratic) if len(hits) else None
                resolution.append(dict(r0=radius,I2_1920_3840=peak(quadratic-pred[1920][slot,0])/peak(quadratic),
                    I4_960_1920=peak(pred[960][slot,1:].sum(axis=0)-pred[1920][slot,1:].sum(axis=0))/peak(quartic),
                    I4_1920_3840=peak(pred[1920][slot,1:].sum(axis=0)-quartic)/peak(quartic),
                    I2_other_integrator=cross,field_peak=peak(latest[slot,1]),displacement_peak=peak(latest[slot,2]),
                    observer_clock_peak=peak(latest[slot,3]),sum_peak=peak(quartic)))
    return rows,orders,resolution

if __name__=="__main__":
    if sys.argv[1:] == ["acquire"]:
        run()
    elif sys.argv[1:] == ["score"]:
        rows,orders,resolution=evaluate()
        table("selfgravity-wave-test.csv",rows)
        table("selfgravity-coefficient-test.csv",orders)
        table("selfgravity-components.csv",resolution)
    else:
        raise ValueError("choose acquire or score")

