from compare import *
import ast
import math


def rows(name):
    with (ROOT/name).open(encoding='utf8',newline='') as handle:return list(csv.DictReader(handle))


def verify():
    verify_inputs()
    for name,field in [('prediction-lock.json','hashes'),('map-lock.json','sources')]:
        for path,expected in read(ROOT/name)[field].items():
            assert digest(ROOT/Path(path))==expected
    independent=[]
    for cap in CAPS:
        checked_k,checked_power=measured(cap)
        path=ROOT/'inputs'/filenames(cap)['power']
        data=path.read_text().rsplit('### header ###',1)[-1].splitlines()
        matrix=[list(map(float,line.split())) for line in data if line.strip()]
        direct=[]
        for col in [1,2,4,6,8,10]:
            combined=[]
            for first in range(0,400,10):
                batch=matrix[first:first+10]
                combined.append(math.fsum(row[col]*row[12] for row in batch)/math.fsum(row[12] for row in batch))
            direct.append(combined)
        np.testing.assert_allclose(checked_k,direct[0],atol=2e-15,rtol=0)
        np.testing.assert_allclose(checked_power,np.ravel(direct[1:]),rtol=2e-13,atol=1e-10)
        _,_,cov=matrices(cap)
        for branch in ('heavy','cold','lcdm'):
            bands=[row for row in rows('primary-bands.csv') if row['cap']==cap and row['branch']==branch]
            residual=np.array([float(row['observed'])-float(row['predicted']) for row in bands])
            sample=select(.10,(0,2));assert len(sample)==len(residual)==16
            sub=cov[np.ix_(sample,sample)]
            eig,axes=np.linalg.eigh(sub);assert eig.min()>0
            value=sum((axes.T@residual)**2/eig)*(2048-16-2)/2047
            match=next(row for row in rows('profiled-scores.csv') if row['cap']==cap and row['branch']==branch and row['test']=='primary')
            assert abs(value-float(match['chi2']))<1e-10
            independent.append(float(value))
    assert all(row['at_boundary']=='False' for row in rows('profiled-scores.csv')+rows('velocity-mapping-scores.csv'))
    assert all(row['quadrature_signal_pass']=='True' for row in rows('velocity-mapping-scores.csv'))
    cases=read(ROOT/'finite-box.json')['fixtures'];assert len(cases)==12 and all(row['truncation_ratio']<.16 for row in cases)
    for path in ROOT.glob('*.py'):ast.parse(path.read_text(encoding='utf8'))
    assert not list(ROOT.rglob('__pycache__')) and not list(ROOT.rglob('*.partial'))
    seal=ROOT/'closeout.json'
    assert (ROOT/'RESULTS.md').exists()
    manifest={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(ROOT.rglob('*')) if p.is_file() and p!=seal}
    if seal.exists():assert read(seal)['files']==manifest
    else:save('closeout.json',dict(previous=SEAL,utc=datetime.now(timezone.utc).isoformat(),files=manifest,
                 covariance_eigenbasis_checks=independent,observed_source_files=8,total_bytes=sum((ROOT/p).stat().st_size for p in manifest)))
    print('Verified',len(manifest),'files',digest(seal))


if __name__=='__main__':verify()
