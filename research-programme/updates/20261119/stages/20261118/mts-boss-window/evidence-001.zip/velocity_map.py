from compare import *
from scipy.integrate import simpson
from scipy.interpolate import CubicSpline
import time


def matter(branch):
    _,spline,_,_,_=curves(branch)
    def fields(wave):
        coord=np.log(wave)
        root=np.sqrt(2*np.pi**2*2.1e-9*(wave/.05)**(-.0347)/wave**3)
        return [root*np.exp(spline[key](coord)) for key in ('delta_cb','velocity_cb')]
    return fields


def angles(moment,angular):
    angle=np.asarray(angular)
    rem=1-angle
    aa,bb,ac,bd,cc,cd,dd=moment
    return np.stack([aa*angle**2+bb*angle*rem,
                     ac*angle**3+bd*angle**2*rem,
                     cc*angle**4+cd*angle**3*rem+dd*angle**2*rem**2],axis=-1)


def moments(fields,wave,upper,res,independent=False,soft=None):
    rorder,torder,spacing=res
    lower=1e-5
    end=upper if soft is None else soft
    divisions=np.unique(np.clip(np.r_[np.geomspace(lower,end,int(np.ceil(np.log(end/lower)/spacing))+1),
                                      wave/2,wave,upper-wave],lower,end))
    lo,hi=np.log(divisions[:-1,None]),np.log(divisions[1:,None])
    nodes,weights=roots_legendre(rorder)
    p=np.exp((lo+hi+(hi-lo)*nodes)/2).ravel()[:,None]
    pweights=((hi-lo)*weights/2).ravel()[:,None]*p**3/np.pi**2
    tnodes,tweights=roots_legendre(torder)
    left=np.maximum(-1.,(p**2+wave**2-upper**2)/(2*p*wave))
    right=np.minimum(1.,wave/(2*p))
    assert np.all(right>=left)
    theta=(left+right+(right-left)*tnodes)/2
    fullweight=pweights*(right-left)*tweights/2
    q=np.sqrt((wave-p)**2+2*wave*p*(1-theta))
    assert np.min(q)>=lower and np.max(q)<=upper*(1+1e-12)
    dp,up=fields(p);dq,uq=fields(q)
    along=p*theta;across=p*np.sqrt((1-theta)*(1+theta));other=wave-along
    a0=wave*.5*(dp*uq*other/q**2+dq*up*along/p**2)
    a1=wave*.5*across*(dq*up/p**2-dp*uq/q**2)
    factor=.5*wave**2*up*uq/(p*q)**2
    f0=factor*along*other;f1=factor*across*(other-along);f2=-factor*across**2
    coeffs=(a0**2,.5*a1**2,2*a0*f0,a0*f2+a1*f1,f0**2,f0*f2+.5*f1**2,.375*f2**2)
    result=np.array([np.sum(fullweight*entry) for entry in coeffs])
    if independent:
        for mu in (.21,.72,1.):
            los=np.sqrt(1-mu**2)
            for bias in (.75,1.83):
                sums=[]
                for phi in np.arange(8)*np.pi/4:
                    pz=along*mu+across*los*np.cos(phi)
                    lp=pz*up/p**2;lq=(wave*mu-pz)*uq/q**2
                    kernel=(bias*wave*mu*(dp*lq+dq*lp)+(wave*mu)**2*lp*lq)/2
                    sums.append(np.sum(fullweight*kernel**2))
                direct=np.mean(sums);reduced=angles(result,mu**2)@np.array([bias**2,bias,1])
                assert direct>=0 and abs(direct-reduced)<max(1e-12,abs(direct)*1e-11)
    return result


def variance(fields,cut):
    coord=np.linspace(np.log(1e-5),np.log(cut),8193)
    wave=np.exp(coord)
    return float(simpson(wave*fields(wave)[1]**2,x=coord)/(6*np.pi**2))


def assemble(branch,cut,res,count):
    fields=matter(branch)
    _,_,h,perp,para=curves(branch)
    variance1=variance(fields,cut)
    grid=np.unique(np.r_[np.geomspace(.00032,.012,40),np.linspace(.012,.303,count)])
    result=np.stack([moments(fields,wave,cut,res) for wave in grid])
    interpolation=CubicSpline(grid,result,axis=0,extrapolate=False)
    nodes,weights=roots_legendre(48);mu=nodes[None,:]
    stretch=np.sqrt((1-mu**2)/perp**2+mu**2/para**2)
    physical=h*KTHEORY[:,None]*stretch
    angular=(mu/(para*stretch))**2
    assert physical.min()>grid[0] and physical.max()<grid[-1] and grid[-1]<cut
    dc,uc=fields(physical)
    lin=np.stack([dc**2,2*dc*uc*angular,uc**2*angular**2],axis=-1)
    p22=angles(interpolation(physical).transpose(2,0,1),angular)
    p13=-variance1*(physical**2*angular)[:,:,None]*lin
    biasvec=np.array([1.83**2,1.83,1.])
    power=lin@biasvec
    assert np.min((p22@biasvec)/power)>-1e-10
    sig=p22+p13
    poles=np.concatenate([np.einsum('kas,a->ks',sig,(2*ell+1)/2*weights*eval_legendre(ell,nodes)) for ell in (0,2,4)])*h**3/(perp**2*para)
    basis=input_basis(branch,'primary',64)
    basis[:,:3]+=poles
    observed=KTHEORY<=.10
    diag=dict(variance_Mpc2=variance1,rms_hinv_Mpc=np.sqrt(variance1)*h,
              peak_abs_mapping_primary=float(abs((sig@biasvec)/power)[observed].max()),
              peak_abs_mapping_full_window_support=float(abs((sig@biasvec)/power).max()),
              min_total_to_linear=float(np.min(1+(sig@biasvec)/power)),
              peak_one_point_term_primary=float(abs((p13@biasvec)/power)[observed].max()))
    return basis,diag


def produce():
    verify_inputs()
    stats=[];checks=[];start=time.monotonic()
    for branch in ('heavy','cold','lcdm'):
        guard();fields=matter(branch)
        for wave in (.03,.075,.21):
            moments(fields,wave,5,(8,28,.12),True)
            cutoff=wave*.002
            sig=variance(fields,cutoff)
            val=moments(fields,wave,5,(8,24,.12),True,soft=cutoff)
            density,speed=fields(wave)
            for mu in (.4,.9):
                effect=angles(val,mu**2)@np.array([1.83**2,1.83,1.])
                predicted=(wave*mu)**2*sig*(1.83*density+mu**2*speed)**2
                checks.append(float(effect/predicted-1))
        assert max(abs(val) for val in checks)<TOL
        for cut in (.35,1.,5.):
            primary,diag=assemble(branch,cut,(6,20,.17),230)
            refined,other=assemble(branch,cut,(9,36,.10),451)
            branch_stats=dict(branch=branch,cut=cut,**other)
            for cap in CAPS:
                wide,window,cov=matrices(cap)
                operator=window@wide
                coarse=operator@primary;fine=operator@refined
                ids=select(.10,(0,2))
                pred=lambda shape:predict(shape[ids],1.83,137.)
                ratio=np.max(abs(pred(fine)-pred(coarse)))/np.max(abs(pred(fine)))
                with (ROOT/f'map-{branch}-{cut:g}-{cap}.npz').open('xb') as out:
                    np.savez_compressed(out,fine=fine,coarse=coarse,version='Eulerian Gaussian mapping contribution only')
                branch_stats[cap+'_quadrature_peak_relative']=ratio
            stats.append(branch_stats)
            print(branch,cut,'refined',branch_stats[CAPS[0]+'_quadrature_peak_relative'],round(time.monotonic()-start,1),flush=True)
    save('map-lock.json',dict(stats=stats,max_soft_fractional_residual=max(abs(val) for val in checks),
             soft_checks=len(checks),sources={path.name:digest(path) for path in [ROOT/'VELOCITY-MAP.md',ROOT/'velocity_map.py',
                       ROOT/'prediction-lock.json',*sorted(ROOT.glob('map-*.npz'))]}))


if __name__=='__main__':produce()
