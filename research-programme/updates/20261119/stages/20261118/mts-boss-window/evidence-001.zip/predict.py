from sources import *
import sys
from functools import lru_cache
from scipy.integrate import quad
from scipy.interpolate import CubicSpline
from scipy.special import roots_legendre,eval_legendre
sys.path.insert(0,str(PREV))
import observable as earlier

REDSHIFT=.38
KTHEORY=(np.arange(400)+.5)*.001
KOBS=(np.arange(40)+.5)*.01
BRANCHES=('heavy','cold','lcdm','heavy_live','cold_live','heavy_old')
MODELS=('primary','total','dispersion','no_ap','tail')


def verify_inputs():
    guard()
    receipt=read(ROOT/'source-receipt.json')
    assert receipt['protocol']==digest(ROOT/'PROTOCOL.md')
    for name,item in receipt['files'].items():assert digest(ROOT/'inputs'/name)==item['sha256']
    previous=read(PREV/'closeout.json')
    for name,item in previous['files'].items():
        if name.startswith('full-grid/') or name in ('observable.py','native_test.py','full_grid.py','score.py','input-lock.json','integral-lock.json'):
            assert digest(PREV/name)==item['sha256']


@lru_cache(None)
def curves(branch):
    case=branch.split('_')[0]
    modes,epochs,fields=earlier.original_spectrum(case)
    if branch not in ('lcdm','heavy_old'):
        fields,_=earlier.evolved('fixed' if branch=='heavy' else 'stock',case,'live' if '_live' in branch else 'rsa')
    pos=np.flatnonzero(abs(epochs-1/(1+REDSHIFT))<1e-12).item()
    with np.load(SPEC/'runs'/case/'background.npz') as pack:
        slot=np.flatnonzero(abs(pack['redshifts']-REDSHIFT)<1e-12).item()
        distance=pack['DM'][slot];hubble=pack['H_km_s_Mpc'][slot]
        h=pack['H_km_s_Mpc'][np.flatnonzero(pack['redshifts']==0).item()]/100
    efid=lambda z:np.sqrt(.31*(1+z)**3+.69)
    fid_distance=2997.92458*quad(lambda z:1/efid(z),0.,REDSHIFT,epsabs=1e-13)[0]
    parallel=h*100*efid(REDSHIFT)/hubble
    transverse=h*distance/fid_distance
    return modes,{name:CubicSpline(np.log(modes),np.log(values[:,pos]),extrapolate=False) for name,values in fields.items()},h,transverse,parallel


def input_basis(branch,variant,order):
    grid,curve,h,perp,para=curves(branch)
    if variant=='no_ap':perp=para=1.
    nodes,weights=roots_legendre(order)
    mu=nodes[None,:]
    stretch=np.sqrt((1-mu**2)/perp**2+mu**2/para**2)
    physical=h*KTHEORY[:,None]*stretch
    true_mu=mu/(para*stretch)
    assert physical.min()>grid[0] and physical.max()<grid[-1] and np.max(abs(true_mu))<=1
    dens=np.exp(curve['delta_m' if variant=='total' else 'delta_cb'](np.log(physical)))
    speed=np.exp(curve['velocity_cdm' if variant=='total' else 'velocity_cb'](np.log(physical)))
    prefactor=2*np.pi**2/physical**3*2.1e-9*(physical/.05)**(-.0347)*h**3/(perp**2*para)
    if variant=='dispersion':prefactor*=np.exp(-(physical/h*true_mu*3.)**2)
    if variant=='tail':prefactor*=np.where(KTHEORY[:,None]>.15,1.10,1.)
    coeff=np.stack(np.broadcast_arrays(prefactor*dens**2,2*prefactor*dens*speed*true_mu**2,
                                      prefactor*speed**2*true_mu**4),axis=-1)
    poles=np.concatenate([np.einsum('kas,a->ks',coeff,(2*ell+1)/2*weights*eval_legendre(ell,nodes)) for ell in (0,2,4)])
    shot=np.r_[np.ones(400),np.zeros(800)]
    ans=np.column_stack([poles,shot])
    if variant=='no_ap':
        flat=physical[:,0];ps=2*np.pi**2/flat**3*2.1e-9*(flat/.05)**(-.0347)*h**3
        signal=ps*dens[:,0]**2;cross=ps*dens[:,0]*speed[:,0];flow=ps*speed[:,0]**2
        exact=np.vstack([np.column_stack([signal,2/3*cross,flow/5]),
                         np.column_stack([0*signal,4/3*cross,4/7*flow]),np.column_stack([0*signal,0*cross,8/35*flow])])
        assert abs(ans[:,:3]-exact).max()/abs(exact).max()<1e-12
    return ans


def run():
    verify_inputs();errors=[];geometry={}
    for cap in CAPS:
        wide,window,cov=matrices(cap)
        response=window@wide
        even=np.concatenate([np.arange(400)+ell*400 for ell in (0,2,4)])
        np.testing.assert_array_equal(wide[even],np.eye(1200))
        vectors={}
        for branch in BRANCHES:
            _,_,h,perp,para=curves(branch)
            geometry[branch]=dict(h=h,transverse=perp,parallel=para)
            for variant in MODELS if branch in ('heavy','cold','lcdm') else ('primary',):
                low=input_basis(branch,variant,32)
                high=input_basis(branch,variant,64)
                vec=response@high
                estimate=np.max(abs(response@low-vec),axis=0)/np.max(abs(vec),axis=0)
                errors.append(max(estimate))
                np.testing.assert_allclose(vec,window@(wide@high),rtol=1e-11,atol=2e-8)
                vectors[branch+'__'+variant]=vec
        with (ROOT/f'{cap}-frozen.npz').open('xb') as handle:np.savez_compressed(handle,**vectors)
    assert max(errors)<2e-5
    hashes={str(path):digest(path) for path in [ROOT/'PROTOCOL.md',ROOT/'PREDICTION-ADDENDUM.md',ROOT/'predict.py',ROOT/'sources.py',
            ROOT/'source-receipt.json',*[ROOT/f'{cap}-frozen.npz' for cap in CAPS],
            *[SPEC/'runs'/case/'background.npz' for case in ('heavy','cold','lcdm')],
            *[SPEC/'results/spectrum'/(case+'.npz') for case in ('heavy','cold','lcdm')],SPEC/'runs/projection/a225-w6-d8.npz']}
    save('prediction-lock.json',dict(utc=datetime.now(timezone.utc).isoformat(),previous=SEAL,hashes=hashes,
                   angular_max_relative_to_peak=max(errors),geometry=geometry,
                   controls='native active and shortcut; previous biased heavy retained as a diagnostic only'))
    print(geometry,'32/64',float(max(errors)),flush=True)


if __name__=='__main__':run()
