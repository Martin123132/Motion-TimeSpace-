from compare import *


def run_mapping():
    verify_inputs()
    lock=read(ROOT/'map-lock.json')
    assert all(digest(ROOT/name)==value for name,value in lock['sources'].items())
    ids=select(.10,(0,2));rows=[];seps=[];held=[]
    for cap in CAPS:
        _,data=measured(cap);_,_,cov=matrices(cap)
        block=cov[np.ix_(ids,ids)]
        for cut in (.35,1.,5.):
            with np.load(ROOT/f'map-heavy-{cut:g}-{cap}.npz') as pack:
                synthetic=predict(pack['fine'][ids],1.83,137.)
            for branch in BRANCHES[:3]:
                with np.load(ROOT/f'map-{branch}-{cut:g}-{cap}.npz') as pack:
                    fine,coarse=pack['fine'],pack['coarse']
                res,pred=fit(data[ids],fine[ids],block,True)
                alt,other=fit(data[ids],coarse[ids],block,True)
                checks=next(row for row in lock['stats'] if row['branch']==branch and row['cut']==cut)
                rows.append(dict(cap=cap,branch=branch,cut=cut,**res,quadrature_signal_pass=checks[cap+'_quadrature_peak_relative']<TOL,
                            chi2_quadrature_change=res['chi2']-alt['chi2'],
                            fitted_peak_prediction_change=float(max(abs(other-pred))/max(abs(pred)))))
                distance,_=fit(synthetic,fine[ids],block,True)
                seps.append(dict(cap=cap,branch=branch,cut=cut,profiled_heavy_signal_distance=np.sqrt(distance['raw_chi2'])))
                held.append(dict(cap=cap,branch=branch,cut=cut,**conditional(data,fine,cov)))
    table('velocity-mapping-scores.csv',rows);table('velocity-mapping-distances.csv',seps);table('velocity-mapping-quadrupole.csv',held)
    print('both caps',[(cut,name,sum(row['chi2'] for row in rows if row['branch']==name and row['cut']==cut)) for cut in (.35,1.,5.) for name in BRANCHES[:3]])
    print('all refinements pass',all(row['quadrature_signal_pass'] for row in rows),max(abs(row['chi2_quadrature_change']) for row in rows))


if __name__=='__main__':run_mapping()
