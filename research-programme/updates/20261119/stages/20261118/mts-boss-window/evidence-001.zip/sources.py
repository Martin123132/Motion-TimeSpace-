from datetime import datetime,timezone
from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import urllib.request

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PREV=POST/'mts-growth-mode-native-20261118'
SPEC=POST/'condensate-origin-20261003/resolved-matter-spectrum-20261007'
SITE='https://fbeutler.github.io/hub/'
SEAL='67149e1c23899d3e441e44b289a67901857d54bb911729213206d19a0751ce60'
CAPS=('NGC','SGC')
for setting in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[setting]='1'
import numpy as np


def digest(path):
    with Path(path).open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def save(name,value):
    with (ROOT/name).open('x',encoding='utf8') as handle:json.dump(value,handle,indent=2,allow_nan=False)


def guard():
    assert digest(PREV/'closeout.json')==SEAL
    assert not any((base/'STOP-REQUESTED').exists() for base in (POST,ROOT,PREV,POST/'condensate-origin-20261003'))


def filenames(cap):
    return dict(wide=f'M_BOSS_DR12_{cap}_z1_V6C_1_1_1_1_1_1200_2000.matrix.gz',
                window=f'W_BOSS_DR12_{cap}_z1_V6C_1_1_1_1_1_10_200_2000_averaged_v1.matrix.gz',
                cov=f'C_2048_BOSS_DR12_{cap}_z1_V6C_1_1_1_1_1_10_200_200_prerecon.matrix.gz',
                power=f'ps1D_BOSS_DR12_{cap}_z1_COMPnbar_TSC_700_700_700_400_renorm.dat')


def acquire():
    guard();cache=ROOT/'inputs';cache.mkdir(exist_ok=True)
    inventory=urllib.request.urlopen(SITE+'deconv_paper.html',timeout=20).read().decode()
    rows={}
    for cap in CAPS:
        for role,name in filenames(cap).items():
            assert name in inventory
            url=SITE+name;path=cache/name
            if not path.exists():
                with urllib.request.urlopen(url,timeout=40) as response:
                    body=response.read(16_000_001);assert 100<len(body)<=16_000_000
                if role!='power':assert body[:2]==bytes.fromhex('1f8b')
                else:assert b'### header ###' in body[:8192]
                with path.open('xb') as handle:handle.write(body)
            rows[name]=dict(cap=cap,role=role,bytes=path.stat().st_size,sha256=digest(path),url=url)
    save('source-receipt.json',dict(files=rows,release=SITE+'deconv_paper.html',paper='https://arxiv.org/abs/2106.06324',
         wide_angle='https://arxiv.org/abs/1810.05051',reader='https://github.com/fbeutler/pk_tools/blob/master/pk_tools.py',
         previous_seal=SEAL,protocol=digest(ROOT/'PROTOCOL.md'),utc=datetime.now(timezone.utc).isoformat()))
    print('Saved',len(rows),'published inputs:',sum(row['bytes'] for row in rows.values()),'bytes')


def matrices(cap):
    files=filenames(cap)
    block=[np.loadtxt(ROOT/'inputs'/files[role]) for role in ('wide','window','cov')]
    assert [entry.shape for entry in block]==[(2000,1200),(200,2000),(200,200)]
    wide,window,cov=block
    assert all(np.isfinite(item).all() for item in block)
    np.testing.assert_allclose(cov,cov.T,rtol=1e-8,atol=1e-6)
    return wide,window,cov


def measured(cap):
    source=ROOT/'inputs'/filenames(cap)['power']
    header,data=source.read_text().rsplit('### header ###',1)
    raw=np.loadtxt(io.StringIO(data))
    assert raw.shape[0]==400 and raw.shape[1]>=13
    weights=raw[:,12].reshape(40,10)
    assert np.all(weights>=0) and np.all(weights.sum(axis=1)>0)
    bins=lambda col:(raw[:,col].reshape(40,10)*weights).sum(axis=1)/weights.sum(axis=1)
    result=np.concatenate([bins(2+2*degree) for degree in range(5)])
    assert np.isfinite(result).all()
    return bins(1),result


if __name__=='__main__':acquire()
