import sys
import json
import csv
from pathlib import Path
from types import FunctionType

HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-burst-scalar-susceptibility-20261118"
OLDER=HERE.parent/"mts-coherent-current-ruler-20261118"
LOCK="4c8b85f75fdb408e42772fe5a34cdf78423bc7d23db1807ee1b75ef5b9ff64da"
OLDLOCK="916c0276878ada9f754900be0fdf6480407ee11b4f92d6dd0c5fce91a6ac9e7c"
sys.path.insert(0,str(OLDER))
import mixed_current as original
from mixed_current import np, digest, COEFFICIENT, inherited, name

TOL=2e-5
ARMS=(0,1)
GRIDS=(.025,.0125)
PICKS=[150,200,250]
CLOCKS=[3.,4.,5.,6.,6.4]
SHAPES={"third":(0.,0.,1.),"firstthird":(1.,0.,1.),"secondthird":(0.,1.,1.),"validation":(.45,-.7,.85)}
VREF=np.array((1.,-COEFFICIENT,0.))


def hold():
    original.hold()
    if any((work/"STOP-REQUESTED").exists() for work in (HERE,PRE,HERE.parent)):raise SystemExit("owner hold")


def ensure():
    hold()
    if digest(PRE/"closeout.json")!=LOCK or digest(OLDER/"closeout.json")!=OLDLOCK:raise ValueError("upstream changed")
    manifest=json.loads((OLDER/"closeout.json").read_text())["files"]
    for member in ("mixed_current.py","magnetically-matched-scalar.json"):assert digest(OLDER/member)==manifest[member]


def read(path):
    with np.load(path,allow_pickle=False) as packet:return {key:packet[key] for key in packet.files}


def old(member):
    path=OLDER/member
    assert digest(path)==json.loads((OLDER/"closeout.json").read_text())["files"][member]
    return read(path)


def own(dx,amp,tag):
    data=read(HERE/name(dx,.8,amp,tag))
    assert data["rows"].shape==(321,16) and data["integrated"].shape==(321,6)
    assert np.array_equal(data["rows"][:,0],np.arange(321)*.02)
    assert str(data["protocol"])==digest(HERE/"PROTOCOL.md") and str(data["parent"])==LOCK
    assert all(np.isfinite(data[key]).all() for key in ("rows","integrated","mass","quality","weights"))
    return data


def compact(dx,amp,tag):
    if amp==1 and tag=="first":
        block=read(inherited(f"budget-d{dx:g}-q0.8-h1-s0-p0-c12-r15-t0.3-ko0.5-seed1-mass.npz"))
        rows=block["rows"];field=2*rows[:,12]/rows[:,20]**2
        return field,np.column_stack((rows[:,1:3],block["integrated"][:,:6]))
    if tag in ("first","second","minus","calibrated"):
        block=old(name(dx,.8,amp,tag))
    else:block=own(dx,amp,tag)
    return block["rows"][:,3],np.column_stack((block["rows"][:,1:3],block["integrated"]))


def solve(dx,amp,tag,weights):
    ensure()
    out=HERE/name(dx,.8,amp,tag)
    if out.exists() or out.with_suffix(".partial").exists():raise FileExistsError(out)
    ctx=dict(original.run.__globals__,LOCAL=HERE,WEIGHTS={tag:tuple(weights)},hold=hold,LOCK=LOCK)
    FunctionType(original.run.__code__,ctx)(dx,.8,amp,tag)
    packet=own(dx,amp,tag)
    assert np.array_equal(packet["weights"],weights)


def build(dx,phase):
    ensure();assert dx in GRIDS
    if phase=="basis":
        for amp in ARMS:
            for tag in ("third","firstthird","secondthird"):
                path=HERE/name(dx,.8,amp,tag)
                if path.exists():
                    assert np.array_equal(own(dx,amp,tag)["weights"],SHAPES[tag]);continue
                solve(dx,amp,tag,SHAPES[tag])
    elif phase=="test":
        pred=read(HERE/"three-clock-forecasts.npz")
        assert str(pred["protocol"])==digest(HERE/"PROTOCOL.md") and str(pred["all_source_protocol"])==digest(HERE/"SOURCE-INDEPENDENT-TEST.md")
        jobs=[(0,"validation"),(1,"validation"),(1,"matched3")]
        if str(pred["stress_kind"])!="unresolved":jobs.extend([(0,"nullpair"),(1,"nullpair")])
        counter=json.loads((HERE/"counterfeit-forecast.json").read_text())
        assert counter["forecast"]==digest(HERE/"three-clock-forecasts.npz")
        if counter["ordinary_candidate"] is not None:jobs.append((0,"adversary"))
        for amp,tag in jobs:
            key=f"g{GRIDS.index(dx)}a{amp}"
            if tag=="matched3":weights=pred[key+"_v"]
            elif tag=="nullpair":weights=pred[key+"_nullv"]
            elif tag=="adversary":weights=counter["ordinary_candidate"]["weights"]
            else:weights=SHAPES[tag]
            path=HERE/name(dx,.8,amp,tag)
            if path.exists():
                assert np.array_equal(own(dx,amp,tag)["weights"],weights);continue
            solve(dx,amp,tag,weights)
    else:raise ValueError(phase)


def table(filename,rows):
    with (HERE/filename).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


if __name__=="__main__":build(float(sys.argv[1]),sys.argv[2])
