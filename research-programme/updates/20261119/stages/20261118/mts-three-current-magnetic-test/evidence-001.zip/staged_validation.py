from three_response_map import HERE,GRIDS,ARMS,SHAPES,basis,quadratic,ensure,np,read,own,name,digest,json
from stage import solve
import sys


def prepare():
    ensure();target=HERE/"prospective-mixture.npz"
    if target.exists() or any(HERE.glob("source-validation-*.npz")):raise RuntimeError("validation already started")
    weights=np.array(SHAPES["validation"]);bank={}
    for arm in ARMS:
        fields,matrix=basis(.025,arm);bank[f"a{arm}B"]=fields@weights;bank[f"a{arm}L"]=quadratic(matrix,weights)
    inputs={p.name:digest(p) for p in HERE.glob("source-*-dx0.025-*.npz") if p.name.split("-")[1] in ("third","firstthird","secondthird")}
    assert len(inputs)==6
    with target.open("xb") as stream:np.savez_compressed(stream,**bank,dx=.025,weights=weights,
          coarse_inputs=json.dumps(inputs,sort_keys=True),protocol=digest(HERE/"PROTOCOL.md"),design=digest(HERE/"coarse-detector-design.json"))


def run(dx):
    ensure();target=HERE/"prospective-mixture.npz";predict=read(target);weights=predict["weights"]
    assert dx in GRIDS and np.array_equal(weights,SHAPES["validation"]) and str(predict["protocol"])==digest(HERE/"PROTOCOL.md")
    for arm in ARMS:
        path=HERE/name(dx,.8,arm,"validation")
        receipt=HERE/f"validation-before-g{GRIDS.index(dx)}a{arm}.json"
        if receipt.exists():
            assert json.loads(receipt.read_text())["prediction"]==digest(target)
            if path.exists() and np.array_equal(own(dx,arm,"validation")["weights"],weights):continue
            raise RuntimeError("an unclosed validation receipt requires inspection")
        if path.exists():raise RuntimeError("validation without prior receipt")
        with receipt.open("x") as stream:json.dump(dict(prediction=digest(target),arm=arm,grid=dx,
            weights=weights.tolist()),stream,allow_nan=False)
        solve(dx,arm,"validation",weights)


if __name__=="__main__":
    if sys.argv[1]=="freeze":prepare()
    else:run(float(sys.argv[1]))
