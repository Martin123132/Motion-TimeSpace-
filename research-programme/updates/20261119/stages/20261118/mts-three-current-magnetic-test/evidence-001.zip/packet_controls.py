from stage import HERE,GRIDS,ARMS,SHAPES,PICKS,TOL,own,read,json,np,table,name
from three_response_map import relative,peak
from scipy.integrate import simpson


def audit():
    result=[];packed=read(HERE/"three-clock-forecasts.npz");counter=json.loads((HERE/"counterfeit-forecast.json").read_text())
    expected=set()
    for idx,dx in enumerate(GRIDS):
        for arm in ARMS:
            shapes=dict(SHAPES)
            if arm==1:shapes["matched3"]=packed[f"g{idx}a1_v"]
            if str(packed["stress_kind"])!="unresolved":shapes["nullpair"]=packed[f"g{idx}a{arm}_nullv"]
            if arm==0 and counter["ordinary_candidate"] is not None:shapes["adversary"]=counter["ordinary_candidate"]["weights"]
            for tag,weights in shapes.items():
                member=name(dx,.8,arm,tag);expected.add(member);block=own(dx,arm,tag)
                assert np.array_equal(block["weights"],weights),member
                rows=block["rows"];mass=block["mass"];quality=block["quality"];ts=rows[:,0]
                assert mass.shape==(33,20) and quality.shape==(33,17) and np.array_equal(mass[:,0],ts[::10]) and np.array_equal(quality[:,0],ts[::10])
                def score(check,value,category):
                    result.append(dict(packet=member,category=category,check=check,value=value,passes=bool(value<=TOL)))
                score("independent initial constraint",json.loads(str(block["initial_info"]))["green_relative"],"physical")
                score("metric determinant vs ruler",relative(rows[:,2],rows[:,1]),"physical")
                score("focusing budget vs ruler",relative(block["integrated"].sum(axis=1),rows[:,1]),"physical")
                integrand=rows[:,8:14].sum(axis=1);times=[150,200,250,300,320]
                other=[simpson((ts[at]-ts[:at+1])*integrand[:at+1],x=ts[:at+1]) for at in times]
                score("independent focusing convolution",relative(np.array(other),rows[times,1]),"physical")
                score("radial mass constraint",peak(mass[:,1])/peak(mass[:,2]),"physical")
                score("mass vs geometric reconstruction",peak(mass[:,3])/peak(mass[:,4]),"physical")
                for region,start in (("core",1),("domain",9)):
                    for col,label in enumerate(("radial momentum","angular momentum","radial connection","angular connection")):
                        off=start+2*col
                        score(region+" "+label,peak(quality[:,off])/peak(quality[:,off+1]),"auxiliary")
    actual={p.name for p in HERE.glob("source-*.npz")}
    assert expected==actual,(expected-actual,actual-expected)
    return result


if __name__=="__main__":table("packet-controls.csv",audit())
