from three_response_map import basis,geometry,kinetic,extremes,GRIDS,ARMS,PICKS,VREF,HERE,np,read,digest,json,table,peak
from scipy.optimize import minimize_scalar
from itertools import product
import sys

LATE=[275,300,320]
SIGNS=np.array(list(product((-1.,1.),repeat=3)))


def whitening(energy):
    spectrum,columns=np.linalg.eigh(energy)
    return (columns/np.sqrt(spectrum))@columns.T


def optimize(contrast,energy):
    whitening_matrix=whitening(energy)
    matrices=whitening_matrix@contrast[[300,320],0]@whitening_matrix
    choices=[]
    for first,last in product((-1.,1.),repeat=2):
        def lower(mix):
            return np.linalg.eigvalsh(first*(1-mix)*matrices[0]+last*mix*matrices[1])[0]
        best=minimize_scalar(lambda mix:-lower(mix),bounds=(0.,1.),method="bounded",options={"xatol":1e-13})
        assert best.success
        for mix in (0.,best.x,1.):
            choices.append((float(lower(mix)),[first*(1-mix),last*mix]))
    return max(choices,key=lambda choice:choice[0])


def design():
    path=HERE/"coarse-detector-design.json"
    if path.exists() or (HERE/"three-clock-forecasts.npz").exists():raise RuntimeError("coarse design must precede main freeze")
    matrices=[basis(.025,arm) for arm in ARMS]
    ignored,contrast=geometry(matrices)
    gain,weights=optimize(contrast,kinetic())
    with path.open("x") as stream:json.dump(dict(clocks=[6.,6.4],weights=weights,coarse_margin=gain,
        protocol=digest(HERE/"LATE-READOUT-PROTOCOL.md"),basis_grid=.025),stream,indent=2,allow_nan=False)
    print("coarse-only detector weights",weights,"margin per cost",gain)


def compute():
    frozen=json.loads((HERE/"coarse-detector-design.json").read_text());weights=np.array(frozen["weights"])
    assert frozen["protocol"]==digest(HERE/"LATE-READOUT-PROTOCOL.md") and abs(sum(abs(weights))-1)<1e-12
    pack=read(HERE/"three-clock-forecasts.npz");energy=pack["reference_gram"];cost=VREF@energy@VREF
    white=whitening(energy);results=[];work=[]
    for index,dx in enumerate(GRIDS):
        first=pack[f"g{index}a0_basisB"];second=pack[f"g{index}a1_basisB"]
        fieldscale=np.linalg.norm(pack["g1a0_basisB"][LATE],axis=1)
        earlyscale=np.linalg.norm(pack["g1a0_basisB"][PICKS],axis=1)
        shift=np.linalg.solve(second[PICKS],first[PICKS]-second[PICKS]);transfer=np.eye(3)+shift
        H=((second[LATE]-first[LATE])+second[LATE]@shift)/fieldscale[:,None]
        singular=np.linalg.svd(H@white,compute_uv=False)
        aggregate=sum(float(w)*pack[f"g{index}_contrast"][pos,0] for w,pos in zip(weights,(300,320)))
        eigene,axes=extremes(aggregate,energy)
        linear=quadratic=field_noise_gain=0.
        for arm,source,mapping in ((0,first,np.eye(3)),(1,second,transfer)):
            transform=np.linalg.solve(source[PICKS],np.diag(earlyscale))
            obs=sum(float(w)*pack[f"g{index}a{arm}_basisK"][pos,0] for w,pos in zip(weights,(300,320)))
            linear+=2*np.sqrt(cost)*np.max(np.linalg.norm(SIGNS@(transform.T@obs@mapping@white),axis=1))
            quadratic+=np.sum(abs(transform.T@obs@transform))
            propagated=source[LATE]@transform/fieldscale[:,None]
            field_noise_gain+=np.max(np.linalg.norm(SIGNS@propagated.T,axis=1))
        margin=eigene[0]*cost
        eps=2*margin/(np.sqrt(linear**2+4*quadratic*margin)+linear) if margin>0 else None
        work.append((H@white,white@aggregate@white))
        results.append(dict(dx=dx,weights=json.dumps(weights.tolist()),ruler_min_at_reference_cost=margin,
                           ruler_max_at_reference_cost=eigene[-1]*cost,ruler_uniform_independent_early_epsilon=eps,
                           late_field_min_at_reference_cost=singular[-1]*np.sqrt(cost),field_largest_singular=singular[0],
                           field_smallest_singular=singular[-1],early_field_propagation_gain=field_noise_gain,
                           field_uniform_early_epsilon=singular[-1]*np.sqrt(cost)/field_noise_gain,
                           ruler_normalized_min=eigene[0],ruler_normalized_max=eigene[-1]))
    changeH=np.linalg.norm(work[0][0]-work[1][0],ord=2);changeR=np.linalg.norm(work[0][1]-work[1][1],ord=2)
    for row in results:
        row["field_discretization_spread"]=changeH;row["ruler_discretization_spread"]=changeR
        row["field_margin_over_spread"]=row["field_smallest_singular"]/max(changeH,1e-300)
        row["ruler_margin_over_spread"]=row["ruler_normalized_min"]/max(changeR,1e-300)
    return results


if __name__=="__main__":
    if sys.argv[1]=="design":design()
    elif sys.argv[1]=="test":table("late-source-discrimination.csv",compute())
    else:raise ValueError(sys.argv[1])
