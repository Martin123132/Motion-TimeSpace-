from three_response_map import HERE,GRIDS,TOL,np,read,table
from late_readouts import whitening


def history():
    data=read(HERE/"three-clock-forecasts.npz");white=whitening(data["reference_gram"]);runs=[];rows=[]
    for idx,clock in enumerate(data["clock"]):
        pair=[white@data[f"g{index}_contrast"][idx,0]@white for index in range(2)]
        coarse,fine=map(np.linalg.eigvalsh,pair)
        allowance=np.linalg.norm(pair[0]-pair[1],ord=2)+TOL*np.max(np.abs(fine))
        if min(coarse[0],fine[0])>allowance:kind="positive for every nonzero source"
        elif max(coarse[-1],fine[-1])< -allowance:kind="negative for every nonzero source"
        elif min(coarse[-1],fine[-1])>allowance and max(coarse[0],fine[0])< -allowance:kind="both signs possible"
        else:kind="at zero or unresolved"
        rows.append(dict(tau=clock,classification=kind,min_per_unit_cost=fine[0],max_per_unit_cost=fine[-1],sign_screen=allowance))
        if not runs or runs[-1]["classification"]!=kind:
            runs.append(dict(first_tau=clock,last_tau=clock,saved_clocks=1,classification=kind))
        else:runs[-1]["last_tau"]=clock;runs[-1]["saved_clocks"]+=1
    return rows,runs


if __name__=="__main__":
    rows,runs=history();table("whole-history-source-signs.csv",rows);table("source-sign-windows.csv",runs)
