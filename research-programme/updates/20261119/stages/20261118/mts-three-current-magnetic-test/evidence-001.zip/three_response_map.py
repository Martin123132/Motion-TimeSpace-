from stage import (HERE,PRE,OLDER,LOCK,OLDLOCK,TOL,GRIDS,ARMS,PICKS,CLOCKS,SHAPES,VREF,COEFFICIENT,ensure,
                   compact,own,name,old,table,digest,np,json,read)
from mixed_current import inherited
from scipy.linalg import eigh
from itertools import product
import sys


def peak(value):return float(np.max(np.abs(value)))


def relative(predicted,actual):
    scale=peak(actual)
    return peak(predicted-actual)/scale if scale else (0. if not np.any(predicted) else float("inf"))


def quadratic(matrix,weights):return np.einsum("i,...ij,j->...",weights,matrix,weights)


def basis(dx,amp):
    uno,due,third,minus,both13,both23=[compact(dx,amp,tag) for tag in ("first","second","third","minus","firstthird","secondthird")]
    first,second,last=uno[1],due[1],third[1]
    matrix=np.zeros((*first.shape,3,3))
    matrix[:,:,0,0]=first;matrix[:,:,1,1]=second;matrix[:,:,2,2]=last
    for (aa,bb),val in (((0,1),(first+COEFFICIENT**2*second-minus[1])/(2*COEFFICIENT)),
                        ((0,2),both13[1]-first-last),((1,2),both23[1]-second-last)):
        cross=val if aa==0 and bb==1 else .5*val
        matrix[:,:,aa,bb]=matrix[:,:,bb,aa]=cross
    fields=np.column_stack((uno[0],due[0],third[0]))
    return fields,matrix


def kinetic():
    frozen=old_json("frozen-midpoint.json");energy=np.array(frozen["gram"])
    assert np.linalg.eigvalsh(energy)[0]>0
    return energy


def old_json(filename):
    path=OLDER/filename;assert digest(path)==json.loads((OLDER/"closeout.json").read_text())["files"][filename]
    return json.loads(path.read_text())


def unit_sign(vector):
    pivot=np.argmax(abs(vector))
    return vector*np.sign(vector[pivot])


def geometry(bases):
    field0,mat0=bases[0];field1,mat1=bases[1];D0=field0[PICKS];D1=field1[PICKS]
    delta=np.linalg.solve(D1,D0-D1);Tmat=np.eye(3)+delta
    cross=mat1@delta
    contrast=(mat1-mat0)+np.swapaxes(cross,-1,-2)+cross+delta.T@cross
    assert peak(D1@Tmat-D0)/peak(D0)<1e-12
    return Tmat,contrast


def extremes(matrix,energy):
    values,axes=eigh(matrix,energy)
    axes=np.column_stack([unit_sign(axes[:,idx]) for idx in range(3)])
    return values,axes


def null_choice(eigen,axes,energy):
    if not eigen[0]<0<eigen[-1]:return None
    cost=VREF@energy@VREF
    return np.sqrt(cost)*(np.sqrt(eigen[-1]/(eigen[-1]-eigen[0]))*axes[:,0]
                         +np.sqrt(-eigen[0]/(eigen[-1]-eigen[0]))*axes[:,-1])


def solve():
    ensure();energy=kinetic()
    banks={(dx,amp):basis(dx,amp) for dx in GRIDS for amp in ARMS}
    geos={dx:geometry([banks[(dx,arm)] for arm in ARMS]) for dx in GRIDS}
    observed=compact(GRIDS[1],0,"minus")[0][PICKS]
    field0=banks[(GRIDS[1],0)][0];assert relative(field0[PICKS]@VREF,observed)<TOL
    eigengrid=[extremes(geos[dx][1][-1,0],energy) for dx in GRIDS]
    spread=peak(eigh(geos[GRIDS[0]][1][-1,0]-geos[GRIDS[1]][1][-1,0],energy,eigvals_only=True))
    eigen,axes=eigengrid[1]
    null=None
    if all(vals[0]<-spread and vals[-1]>spread for vals,_ in eigengrid):
        null=null_choice(eigen,axes,energy)
        assert abs(null@energy@null/(VREF@energy@VREF)-1)<1e-12
        assert abs(null@geos[GRIDS[1]][1][-1,0]@null) < 1e-10*(VREF@energy@VREF)*peak(eigen)
    extremal=None
    if null is None and (all(vals[0]>spread for vals,_ in eigengrid) or all(vals[-1]<-spread for vals,_ in eigengrid)):
        extremal=axes[:,np.argmin(abs(eigen))]*np.sqrt(VREF@energy@VREF)
    stress_test=null if null is not None else extremal
    raw={};rank=[];bounds=[]
    comparison=np.linalg.solve(banks[(GRIDS[1],1)][0][PICKS],observed)
    for idx,dx in enumerate(GRIDS):
        Tmat,contrast=geos[dx];raw[f"g{idx}_contrast"]=contrast;raw[f"g{idx}_transfer"]=Tmat
        for tau in CLOCKS:
            row=round(tau/.02);val,axes_at=extremes(contrast[row,0],energy)
            spread_at=peak(eigh(geos[GRIDS[0]][1][row,0]-geos[GRIDS[1]][1][row,0],energy,eigvals_only=True))
            bounds.append(dict(dx=dx,tau=tau,smallest=val[0],middle=val[1],largest=val[2],grid_change_norm=spread_at,
                               min_at_reference_cost=val[0]*(VREF@energy@VREF),max_at_reference_cost=val[-1]*(VREF@energy@VREF),
                               opposing=VREF@contrast[row,0]@VREF,minimum_vector=json.dumps(axes_at[:,0].tolist()),
                               maximum_vector=json.dumps(axes_at[:,-1].tolist())))
        for amp in ARMS:
            key=f"g{idx}a{amp}";fields,matrix=banks[(dx,amp)];design=fields[PICKS];sizes=np.linalg.norm(design,axis=1)
            singular=np.linalg.svd(design/sizes[:,None],compute_uv=False)
            assert singular[-1]>1e-12*singular[0],("unresolved magnetic rank",dx,amp,singular)
            fitted=np.linalg.solve(design,observed);v=VREF if amp==0 else comparison
            local_target=compact(dx,0,"minus")[0][PICKS]
            rank.append(dict(dx=dx,A=amp,det=np.linalg.det(design),absolute_condition=np.linalg.cond(design),
                             row_scaled_condition=singular[0]/singular[-1],singular_min=singular[-1],
                             third_independent_fraction=abs((design[2]/sizes[2])@np.linalg.svd((design/sizes[:,None])[:2])[2][-1]),
                             inverse_for_common_fine_target=json.dumps(fitted.tolist()),
                             inverse_for_local_target=json.dumps(np.linalg.solve(design,local_target).tolist()),
                             direct_run_weights=json.dumps(v.tolist()),reference_kinetic_ratio=(v@energy@v)/(VREF@energy@VREF)))
            raw[key+"_v"]=v;raw[key+"_basisB"]=fields;raw[key+"_basisK"]=matrix
            for label,weights in (("validation",np.array(SHAPES["validation"])),("match",v)):
                raw[key+"_"+label+"B"]=fields@weights;raw[key+"_"+label+"L"]=quadratic(matrix,weights)
            if stress_test is not None:
                weights=stress_test if amp==0 else geos[GRIDS[1]][0]@stress_test
                raw[key+"_nullv"]=weights;raw[key+"_nullB"]=fields@weights;raw[key+"_nullL"]=quadratic(matrix,weights)
    raw.update(null_available=(null is not None),stress_kind=("cancellation" if null is not None else "closest extremum" if extremal is not None else "unresolved"),reference_gram=energy,target=observed,
               clock=np.arange(321)*.02,protocol=digest(HERE/"PROTOCOL.md"),all_source_protocol=digest(HERE/"SOURCE-INDEPENDENT-TEST.md"),
               parent=LOCK,inputs=json.dumps({p.name:digest(p) for p in sorted(HERE.glob("source-*.npz"))
                                              if p.name.split("-")[1] in ("third","firstthird","secondthird")},sort_keys=True))
    return raw,rank,bounds


def freeze():
    target=HERE/"three-clock-forecasts.npz"
    if target.exists() or any(any(HERE.glob(f"source-{tag}-*")) for tag in ("matched3","nullpair","adversary")):
        raise RuntimeError("freeze out of order")
    blind=HERE/"prospective-mixture.npz"
    assert blind.exists()
    for idx,dx in enumerate(GRIDS):
        for arm in ARMS:
            if (HERE/name(dx,.8,arm,"validation")).exists():
                assert json.loads((HERE/f"validation-before-g{idx}a{arm}.json").read_text())["prediction"]==digest(blind)
    raw,rank,bounds=solve();assert len(json.loads(raw["inputs"]))==12
    raw["independent_mixture_forecast"]=digest(blind)
    table("magnetic-rank.csv",rank);table("source-independent-extrema.csv",bounds)
    with target.open("xb") as stream:np.savez_compressed(stream,**raw)
    print("forecast frozen",digest(target),"mixed signs",raw["null_available"],"scalar weights",raw["g1a1_v"])


if __name__=="__main__":freeze()
