from three_response_map import HERE,np,GRIDS,ARMS,PICKS,VREF,read,digest,table,quadratic,unit_sign


def alternatives(pred,idx,amp):
    key=f"g{idx}a{amp}";other=f"g{idx}a{1-amp}"
    design=pred[key+"_basisB"][PICKS];origin=pred[key+"_v"];energy=pred["reference_gram"]
    left=design[:2]/np.linalg.norm(design[:2],axis=1)[:,None]
    direction=unit_sign(np.linalg.svd(left)[2][-1]);assert np.linalg.norm(left@direction)<3e-14
    curve=pred[key+"_basisK"][-1,0];target=pred[other+"_matchL"][-1,0]
    curvature=direction@curve@direction;linear=2*(direction@curve@origin)
    intercept=origin@curve@origin-target
    disc=linear**2-4*curvature*intercept
    if curvature==0:
        roots=[-intercept/linear] if linear!=0 else []
    elif disc>=0:
        stable=-.5*(linear+np.copysign(np.sqrt(disc),linear))
        roots=sorted(set([stable/curvature,intercept/stable])) if stable!=0 else [0.]
    else:roots=[]
    rows=[]
    for shift in sorted(roots,key=abs):
        weights=origin+shift*direction;delta=weights-origin
        rows.append(dict(dx=GRIDS[idx],impersonating_arm=amp,root=shift,third_change=design[2]@delta,
                         third_change_in_reference_channels=(design[2]@delta)/np.linalg.norm(pred[f"g{idx}a0_basisB"][250]),
                         first_two_leak=float(np.max(abs(left@delta))),final_error_on_gap=abs(weights@curve@weights-target)/abs(intercept),
                         kinetic_fraction_of_nominal=(weights@energy@weights)/(origin@energy@origin),
                         weights=weights.tolist()))
    return rows


def freeze():
    import json
    fp=HERE/"three-clock-forecasts.npz";pred=read(fp)
    if any(HERE.glob("source-adversary-*")):raise RuntimeError("adversarial direct run already started")
    rows=[row for idx in (0,1) for amp in ARMS for row in alternatives(pred,idx,amp)]
    for row in rows:assert row["first_two_leak"]<1e-12 and row["final_error_on_gap"]<2e-5
    selected=[r for r in rows if r["impersonating_arm"]==0 and r["dx"]==.0125]
    candidate=min(selected,key=lambda item:abs(item["third_change"])) if selected else None
    with (HERE/"counterfeit-forecast.json").open("x") as stream:json.dump(dict(forecast=digest(fp),roots=rows,
                    ordinary_candidate=candidate),stream,indent=2,allow_nan=False)


if __name__=="__main__":freeze()
