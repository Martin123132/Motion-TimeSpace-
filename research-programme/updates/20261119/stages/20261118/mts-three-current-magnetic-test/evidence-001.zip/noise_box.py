from itertools import product
from three_response_map import HERE,PICKS,CLOCKS,GRIDS,np,read,table,quadratic
from scipy.optimize import brentq


def extrema(linear,matrix,eps):
    dim=len(linear);minimum=maximum=0.
    for labels in product((-1,0,1),repeat=dim):
        signs=np.array(labels);values=eps*signs.astype(float);free=signs==0;fixed=~free
        if free.any():
            block=matrix[np.ix_(free,free)]
            rhs=-.5*linear[free]-matrix[np.ix_(free,fixed)]@values[fixed]
            try:opt=np.linalg.solve(block,rhs)
            except np.linalg.LinAlgError:continue
            if np.any(abs(opt)>eps*(1+2e-12)):continue
            values[free]=np.clip(opt,-eps,eps)
        val=linear@values+values@matrix@values
        minimum=min(minimum,val);maximum=max(maximum,val)
    return minimum,maximum


def control():
    tests=0
    for shift in ((.4,-.3,.7),(-2.,.1,3.)):
        point=np.array(shift);lower,upper=extrema(-2*point,np.eye(3),1.)
        assert abs(lower-(sum((np.clip(point,-1,1)-point)**2)-point@point))<1e-12
        assert abs(upper-(sum((abs(point)+1)**2)-point@point))<1e-12
        tests+=2
    for eps in (.05,.5):
        vec=np.array((1.,-2.,3.))
        for diag in (np.diag([1.,-1.,0.]),np.array([[0,2.,0],[2.,0,1.],[0,1.,0]])):
            low,high=extrema(vec,diag,eps)
            pts=eps*np.array(list(product(np.linspace(-1,1,13),repeat=3)))
            scores=pts@vec+np.einsum("ni,ij,nj->n",pts,diag,pts)
            assert scores.max()<=high+1e-13 and scores.min()>=low-1e-13
            tests+=2
    return tests


def limits(options,weights,scales):
    values=[];linears=[];quads=[]
    for (design,matrix),coeff in zip(options,weights):
        transform=np.linalg.solve(design,np.diag(scales))
        values.append(coeff@matrix@coeff)
        linears.append(2*coeff@matrix@transform);quads.append(transform.T@matrix@transform)
    sign=np.sign(values[1]-values[0]);gap=abs(values[1]-values[0]);assert gap>0
    linear=sum(np.sum(abs(val)) for val in linears);square=sum(np.sum(abs(val)) for val in quads)
    sufficient=2*gap/(linear+np.sqrt(linear**2+4*gap*square))
    def margin(eps):
        o_lo,o_hi=extrema(sign*linears[0],sign*quads[0],eps)
        s_lo,s_hi=extrema(sign*linears[1],sign*quads[1],eps)
        return gap+s_lo-o_hi
    high=sufficient*1.01
    for _ in range(48):
        if margin(high)<=0:break
        high*=2
    else:raise ValueError("no touching boxes found")
    boundary=brentq(lambda eps:margin(eps)/gap,0,high,xtol=max(1e-19,high*1e-13))
    assert sufficient<=boundary*(1+1e-10) and abs(margin(boundary))<gap*1e-8
    return gap,sufficient,boundary


def compute():
    pred=read(HERE/"three-clock-forecasts.npz");results=[]
    for index,dx in enumerate(GRIDS):
        for dimension in (2,3):
            positions=PICKS[:dimension];fine=pred["g1a0_basisB"]
            for tau in CLOCKS:
                at=round(tau/.02)
                opts=[(pred[f"g{index}a{arm}_basisB"][positions,:dimension],
                       pred[f"g{index}a{arm}_basisK"][at,0,:dimension,:dimension]) for arm in (0,1)]
                weights=[np.linalg.solve(D,pred["target"][:dimension]) for D,K in opts]
                for label,scales in (("common first-two-unit scales",np.linalg.norm(fine[positions,:2],axis=1)),
                                      ("native unit scales",np.linalg.norm(fine[positions,:dimension],axis=1))):
                    gap,suff,root=limits(opts,weights,scales)
                    results.append(dict(dx=dx,dimension=dimension,tau=tau,scaling=label,
                            gap=gap,triangle_sufficient=suff,touching_epsilon=root,
                            B3_halfwidth=root*scales[0],B4_halfwidth=root*scales[1],
                            B5_halfwidth=root*scales[2] if dimension==3 else None))
    return results


if __name__=="__main__":
    print("extremum controls",control());table("magnetic-precision.csv",compute())
