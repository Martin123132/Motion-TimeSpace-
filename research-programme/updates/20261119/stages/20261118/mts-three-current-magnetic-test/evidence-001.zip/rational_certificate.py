from fractions import Fraction as Fr
from itertools import permutations
from three_response_map import HERE,GRIDS,ARMS,COEFFICIENT,PICKS,CLOCKS,compact,table,json

LOW=Fr(-4102,1000000)
HIGH=Fr(-2669,1000000)


def rational(val):return Fr.from_float(float(val))


def transpose(mat):return list(map(list,zip(*mat)))


def product(left,right):return [[sum(a*b for a,b in zip(row,col)) for col in zip(*right)] for row in left]


def plus(left,right,scale=1):return [[a+scale*b for a,b in zip(row,col)] for row,col in zip(left,right)]


def det(matrix):
    size=len(matrix);total=Fr(0)
    for order in permutations(range(size)):
        sign=(-1)**sum(order[a]>order[b] for a in range(size) for b in range(a+1,size))
        value=Fr(sign)
        for a,b in enumerate(order):value*=matrix[a][b]
        total+=value
    return total


def minors(matrix):return [det([row[:size] for row in matrix[:size]]) for size in (1,2,3)]


def invert(matrix):
    size=len(matrix);work=[list(row)+[Fr(i==j) for j in range(size)] for i,row in enumerate(matrix)]
    for ix in range(size):
        found=next(j for j in range(ix,size) if work[j][ix])
        work[ix],work[found]=work[found],work[ix]
        pivot=work[ix][ix];work[ix]=[v/pivot for v in work[ix]]
        for j in range(size):
            if ix!=j:
                scale=work[j][ix];work[j]=[a-scale*b for a,b in zip(work[j],work[ix])]
    return [row[size:] for row in work]


def matrix(arms,clock):
    d0,d1,d2,m12,p13,p23=[rational(data[1][clock,0]) for data in arms]
    coeff=rational(COEFFICIENT);x12=(d0+coeff**2*d1-m12)/(2*coeff)
    x13=(p13-d0-d2)/2;x23=(p23-d1-d2)/2
    return [[d0,x12,x13],[x12,d1,x23],[x13,x23,d2]]


def verify_signs():
    rows=[];proof={}
    for dx in GRIDS:
        catalogs=[[compact(dx,arm,tag) for tag in ("first","second","third","minus","firstthird","secondthird")] for arm in ARMS]
        designs=[[[rational(entry[0][idx]) for entry in bank[:3]] for idx in PICKS] for bank in catalogs]
        transform=product(invert(designs[1]),designs[0])
        assert product(designs[1],transform)==designs[0]
        for time in CLOCKS:
            idx=round(time/.02)
            ordinary,scalar=[matrix(data,idx) for data in catalogs]
            contrast=plus(product(transpose(transform),product(scalar,transform)),ordinary,-1)
            assert contrast==transpose(contrast)
            negative=[[-v for v in row] for row in contrast]
            for label,mat in (("ordinary",ordinary),("scalar minus ordinary",contrast),("ordinary minus scalar",negative)):
                computed=minors(mat);rows.append(dict(dx=dx,tau=time,matrix=label,positive_definite=all(v>0 for v in computed),
                  signs=json.dumps([int(v>0)-int(v<0) for v in computed]),leading_minors=json.dumps([float(v) for v in computed])))
            if time==6.4:
                upper=[[-v for v in row] for row in plus(contrast,ordinary,-HIGH)]
                lower=plus(contrast,ordinary,-LOW)
                for label,mat in (("ordinary metric ruler",ordinary),("C - lower*K0",lower),("upper*K0 - C",upper)):
                    exact=minors(mat)
                    assert all(v>0 for v in exact),(dx,label)
                    proof[f"dx{dx:g} {label}"]=[str(v) for v in exact]
    return rows,dict(lower=str(LOW),upper=str(HIGH),proof="strictly positive leading principal minors of rational symmetric matrices",certificates=proof)


if __name__=="__main__":
    rows,proof=verify_signs();table("exact-signs-at-five-clocks.csv",rows)
    with (HERE/"exact-final-fraction-certificate.json").open("x") as stream:json.dump(proof,stream,indent=2)
    print("outward bracket certified for the represented solution data",proof["lower"],proof["upper"])
