from three_response_map import (HERE,PRE,OLDER,LOCK,CLOCKS,PICKS,GRIDS,ARMS,VREF,SHAPES,np,json,compact,quadratic,
                      read,own,digest,relative,peak,TOL,table,old_json)
from mimic import alternatives


def gather():
    pkg=read(HERE/"three-clock-forecasts.npz");ad=json.loads((HERE/"counterfeit-forecast.json").read_text())
    precision=[];nominal=[];outofbasis=[];paired=[];extra=[];energy=pkg["reference_gram"]
    def compare(tag,test,reference):
        score=relative(np.asarray(test),np.asarray(reference))
        precision.append(dict(check=tag,relative_error=score,target=TOL,passes=bool(score<=TOL)))
    gaps=[];field_gaps=[];others=[]
    prospect=read(HERE/"prospective-mixture.npz")
    for index,dx in enumerate(GRIDS):
        fkey=f"g{index}";first,second=[pkg[fkey+f"a{arm}_basisB"] for arm in ARMS]
        scales=np.linalg.norm(first[PICKS],axis=1)
        for arm in ARMS:
            key=fkey+f"a{arm}";ptr=pkg[key+"_basisB"]
            for tag,weights in (("minus",VREF),("firstthird",[1,0,1]),("secondthird",[0,1,1]),("validation",SHAPES["validation"])):
                fields,ruler=compact(dx,arm,tag)
                compare(f"{dx}/{arm}/{tag} linear Maxwell",ptr@weights,fields)
                if tag!="validation":continue
                if tag=="validation":
                    compare(f"{dx}/{arm}/prospectively frozen field",prospect[f"a{arm}B"],fields)
                    compare(f"{dx}/{arm}/prospectively frozen ruler",prospect[f"a{arm}L"][:,0],ruler[:,0])
                    forecast=pkg[key+"_validationL"]
                    for column,label in enumerate(("ruler","determinant","shear","twist","scalar","polar_E","dipole","material")):
                        compare(f"{dx}/{arm}/held-out {label}",forecast[:,column],ruler[:,column])
                    compare(f"{dx}/{arm}/held-out determinant versus ray",ruler[:,1],ruler[:,0])
                    compare(f"{dx}/{arm}/held-out focusing versus ray",ruler[:,2:].sum(axis=1),ruler[:,0])
                    empirical=np.linalg.solve(ptr[PICKS],fields[PICKS])
                    compare(f"{dx}/{arm}/held-out weights inferred from magnetic data",empirical,weights)
                    compare(f"{dx}/{arm}/held-out gravity inferred from magnetic data",quadratic(pkg[key+"_basisK"],empirical)[:,0],ruler[:,0])
        field0,data0=compact(dx,0,"minus");field1,data1=compact(dx,1,"matched3")
        oldfield,oldcal=compact(dx,1,"calibrated")
        gap=data1-data0;fields=field1-field0;gaps.append(gap[:,0]);field_gaps.append(fields)
        for arm,(ff,dd) in enumerate(((field0,data0),(field1,data1))):
            ref=fkey+f"a{arm}_match"
            compare(f"{dx}/{arm}/matched full ruler",pkg[ref+"L"][:,0],dd[:,0])
            compare(f"{dx}/{arm}/matched full polar B",pkg[ref+"B"],ff)
        calc=pkg[fkey+"a1_matchL"]-pkg[fkey+"a0_matchL"]
        bcalc=pkg[fkey+"a1_matchB"]-pkg[fkey+"a0_matchB"]
        compare(f"{dx}/matched gravity difference",calc[:,0],gap[:,0])
        compare(f"{dx}/matched gravity difference determinant",gap[:,1],gap[:,0])
        compare(f"{dx}/matched gravity difference focusing",gap[:,2:].sum(axis=1),gap[:,0])
        compare(f"{dx}/withheld magnetic difference",bcalc[275:],fields[275:])
        precision.append(dict(check=f"{dx}/three early magnetic readings on row scales",relative_error=peak(fields[PICKS]/scales),
                              target=TOL,passes=bool(peak(fields[PICKS]/scales)<=TOL)))
        for tau in CLOCKS+[5.5]:
            at=round(tau/.02)
            nominal.append(dict(dx=dx,tau=tau,ordinary_ruler=data0[at,0],scalar_ruler=data1[at,0],
                 actual_difference=gap[at,0],predicted_difference=calc[at,0],
                 scalar_fraction_of_ordinary=gap[at,0]/data0[at,0],
                 two_source_old_difference=oldcal[at,0]-data0[at,0],scalar_direct=gap[at,4],shear=gap[at,2],
                 ordinary_field=field0[at],scalar_field=field1[at],withheld_or_calibration_B_difference=fields[at],
                 predicted_B_difference=bcalc[at],field_difference_on_row=fields[at]/np.linalg.norm(first[at])))
        if str(pkg["stress_kind"])!="unresolved":
            pair=[compact(dx,arm,"nullpair") for arm in ARMS];gap_other=pair[1][1]-pair[0][1]
            others.append(gap_other[:,0]);fgap=pair[1][0]-pair[0][0]
            cgap=pkg[fkey+"a1_nullL"]-pkg[fkey+"a0_nullL"]
            precision.append(dict(check=f"{dx}/extremal three matched fields",relative_error=peak(fgap[PICKS]/scales),
                        target=TOL,passes=bool(peak(fgap[PICKS]/scales)<=TOL)))
            for arm in ARMS:
                compare(f"{dx}/{arm}/extremal known source ruler",pkg[fkey+f"a{arm}_nullL"][:,0],pair[arm][1][:,0])
            for score,desc in ((peak(cgap[:,0]-gap_other[:,0])/peak(gaps[-1]),"history"),
                               (abs(cgap[-1,0]-gap_other[-1,0])/abs(gaps[-1][-1]),"last clock")):
                precision.append(dict(check=f"{dx}/extremal {desc} on nominal scalar scale",relative_error=score,target=TOL,passes=bool(score<TOL)))
            for tau in CLOCKS+[5.5]:
                at=round(tau/.02);eo=pkg[fkey+"a0_nullv"];es=pkg[fkey+"a1_nullv"]
                paired.append(dict(dx=dx,tau=tau,kind=str(pkg["stress_kind"]),actual_gap=gap_other[at,0],
                         actual_gap_over_final_nominal=gap_other[at,0]/gap[-1,0],predicted_gap=cgap[at,0],
                         determinant_gap=gap_other[at,1],focus_gap=gap_other[at,2:].sum(),field_gap=fgap[at],
                         field_gap_on_row=fgap[at]/np.linalg.norm(first[at]),ordinary_energy=float(eo@energy@eo),
                         scalar_energy=float(es@energy@es)))
        if ad["ordinary_candidate"] is not None:
            ff,dd=compact(dx,0,"adversary");ww=np.array(ad["ordinary_candidate"]["weights"])
            compare(f"{dx}/two-clock impostor independently evolved gravity",quadratic(pkg[fkey+"a0_basisK"],ww)[:,0],dd[:,0])
            compare(f"{dx}/two-clock impostor independently evolved B",first@ww,ff)
            early_error=peak((ff[PICKS[:2]]-field1[PICKS[:2]])/scales[:2])
            late_error=abs(dd[-1,0]-data1[-1,0])/abs(gap[-1,0])
            for score,tag in ((early_error,"two early fields"),(late_error,"counterfeit ruler on scalar gap scale")):
                precision.append(dict(check=f"{dx}/impostor {tag}",relative_error=score,target=TOL,passes=bool(score<TOL)))
            extra.append(dict(dx=dx,two_early_field_max=early_error,third_actual=(ff[250]-field1[250]),
                        third_channel_fraction=(ff[250]-field1[250])/scales[-1],
                        ruler_difference_at_6=dd[300,0]-data1[300,0],final_ruler_difference=dd[-1,0]-data1[-1,0],
                        final_difference_over_nominal=late_error,
                        energy_relative_to_reference=(ww@energy@ww)/(VREF@energy@VREF)))
        if dx==.0125:
            ctl=old_json("two-clock-alias.json")
            tag1=old_eta1("outside");tag2=old_eta1("alias")
            outofbasis.append(dict(eta=1.,k1=ctl["weights"][0],k2=ctl["weights"][1],
                          relative_early=peak(tag1[PICKS[:2],3]-tag2[PICKS[:2],3])/peak(tag1[PICKS[:2],3]),
                          final_ruler_ratio=tag2[-1,1]/tag1[-1,1]))
    compare("spatial refinement on matched gravity difference",gaps[0],gaps[1])
    compare("spatial refinement on withheld magnetic difference",field_gaps[0][275:],field_gaps[1][275:])
    if others:
        err=peak(others[0]-others[1])/peak(gaps[1])
        precision.append(dict(check="extremal spatial refinement on nominal scalar scale",relative_error=err,target=TOL,passes=bool(err<TOL)))
    return {"accuracy.csv":precision,"nominal-three-clock.csv":nominal,"direct-extremal-pair.csv":paired,
            "direct-two-clock-impostor.csv":extra,"old-ordinary-alias-control.csv":outofbasis}


def old_eta1(tag):
    from stage import old,name
    return old(name(.0125,1.,0.,tag))["rows"]


if __name__=="__main__":
    for file,rows in gather().items():
        if rows:table(file,rows)
