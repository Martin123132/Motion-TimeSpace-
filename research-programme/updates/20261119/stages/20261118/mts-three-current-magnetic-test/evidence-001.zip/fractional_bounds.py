from three_response_map import HERE,GRIDS,CLOCKS,VREF,np,read,table
from late_readouts import whitening
from scipy.linalg import eigh


def compute():
    frozen=read(HERE/"three-clock-forecasts.npz")
    energy=frozen["reference_gram"];white=whitening(energy);results=[]
    for clock in CLOCKS:
        row=round(clock/.02)
        denominators=[white@frozen[f"g{idx}a0_basisK"][row,0]@white for idx in range(2)]
        numerators=[white@frozen[f"g{idx}_contrast"][row,0]@white for idx in range(2)]
        dspread=np.linalg.norm(denominators[1]-denominators[0],ord=2)
        nspread=np.linalg.norm(numerators[1]-numerators[0],ord=2)
        floors=[eigh(mat,eigvals_only=True)[0] for mat in denominators]
        for idx,dx in enumerate(GRIDS):
            low=high=margin=None;flag="ordinary ruler not robustly positive definite"
            if min(floors)>dspread:
                coeff=eigh(numerators[idx],denominators[idx],eigvals_only=True)
                low,high=coeff[[0,-1]]
                margin=(nspread+max(abs(low),abs(high))*dspread)/min(floors)
                flag="positive ordinary ruler on tested subspace"
            results.append(dict(dx=dx,tau=clock,status=flag,min_fraction=low,max_fraction=high,
                                conservative_two_grid_fraction_spread=margin,ordinary_min_per_cost=floors[idx],
                                ordinary_grid_spread=dspread,contrast_grid_spread=nspread))
    return results


if __name__=="__main__":table("fractional-all-current-bounds.csv",compute())
