from three_response_map import (HERE,PRE,OLDER,LOCK,OLDLOCK,ensure,solve,digest,np,json,read,GRIDS,ARMS,
                      name,SHAPES,own,compact,PICKS,TOL,CLOCKS,relative,quadratic,peak)
from comparison import gather
from packet_controls import audit
from noise_box import compute as boxes,control
from late_readouts import compute as later,optimize
from mimic import alternatives
from fractional_bounds import compute as fractions
from sign_history import history
from rational_certificate import verify_signs
from mixed_current import inherited
from source_energy import numerical
import csv
import sys


def report():
    ensure();fp=HERE/"three-clock-forecasts.npz";pack=read(fp);raw,rank,bounds=solve()
    assert set(pack)==set(raw)|{"independent_mixture_forecast"}
    for key,val in raw.items():assert np.array_equal(val,pack[key]),key
    forecast=read(HERE/"prospective-mixture.npz")
    assert str(pack["independent_mixture_forecast"])==digest(HERE/"prospective-mixture.npz")
    assert np.array_equal(forecast["weights"],SHAPES["validation"])
    for filename,expected in json.loads(str(forecast["coarse_inputs"])).items():assert digest(HERE/filename)==expected
    assert digest(HERE/"coarse-detector-design.json")==str(forecast["design"])
    design=json.loads((HERE/"coarse-detector-design.json").read_text())
    opt=optimize(pack["g0_contrast"],pack["reference_gram"])
    assert opt[0]==design["coarse_margin"] and opt[1]==design["weights"]
    for key,expected in json.loads(str(pack["inputs"])).items():assert digest(HERE/key)==expected
    for index,dx in enumerate(GRIDS):
        for arm in ARMS:
            ticket=json.loads((HERE/f"validation-before-g{index}a{arm}.json").read_text())
            assert ticket==dict(grid=dx,arm=arm,weights=list(SHAPES["validation"]),prediction=digest(HERE/"prospective-mixture.npz"))
            label=f"g{index}a{arm}"
            for other in ("B","L"):
                if index==0:assert np.array_equal(forecast[f"a{arm}"+other],pack[label+"_validation"+other])
            assert np.array_equal(own(dx,arm,"validation")["weights"],forecast["weights"])
    adversary=json.loads((HERE/"counterfeit-forecast.json").read_text())
    assert adversary["forecast"]==digest(fp)
    roots=[row for i in range(2) for arm in ARMS for row in alternatives(pack,i,arm)]
    assert roots==adversary["roots"]
    eligible=[r for r in roots if r["dx"]==.0125 and r["impersonating_arm"]==0]
    assert (min(eligible,key=lambda r:abs(r["third_change"])) if eligible else None)==adversary["ordinary_candidate"]
    data=gather();physical=audit();response=data["accuracy.csv"]
    data.update({"packet-controls.csv":physical,"magnetic-rank.csv":rank,"source-independent-extrema.csv":bounds,
                 "magnetic-precision.csv":boxes(),"late-source-discrimination.csv":later(),"fractional-all-current-bounds.csv":fractions()})
    data["whole-history-source-signs.csv"],data["source-sign-windows.csv"]=history()
    data["exact-signs-at-five-clocks.csv"],proof=verify_signs()
    assert proof==json.loads((HERE/"exact-final-fraction-certificate.json").read_text())
    checked=0
    for path,values in data.items():
        if not values:assert not (HERE/path).exists();continue
        with (HERE/path).open(encoding="utf8",newline="") as stream:stored=list(csv.DictReader(stream))
        assert len(stored)==len(values),(path,len(stored),len(values))
        for left,right in zip(stored,values):
            assert set(left)==set(right)
            for key,val in right.items():
                assert left[key]==("" if val is None else str(val)),(path,key,left[key],val)
            checked+=1
    gram=pack["reference_gram"];assert relative(numerical(128),gram)<1e-12
    for row in bounds:
        k=pack[f"g{GRIDS.index(row['dx'])}_contrast"][round(row["tau"]/.02),0]
        for direction_key,lambda_key in (("minimum_vector","smallest"),("maximum_vector","largest")):
            axis=np.array(json.loads(row[direction_key]));assert abs(axis@gram@axis-1)<4e-12
            assert peak(k@axis-row[lambda_key]*gram@axis)<1e-10*max(abs(row["smallest"]),abs(row["largest"]))*peak(gram)*peak(axis)
    upstream={}
    def keep(path):upstream[str(path.relative_to(HERE.parent))]=digest(path)
    for folder in (PRE,OLDER):keep(folder/"closeout.json")
    for file in ("mixed_current.py","source_energy.py","frozen-midpoint.json","magnetically-matched-scalar.json","two-clock-alias.json","validate_mixed.py"):keep(OLDER/file)
    for dx in GRIDS:
        for amp in ARMS:
            for tag in ("first","second","minus"):
                if amp==1 and tag=="first":
                    keep(inherited(f"budget-d{dx:g}-q0.8-h1-s0-p0-c12-r15-t0.3-ko0.5-seed1-mass.npz"))
                else:keep(OLDER/name(dx,.8,amp,tag))
        keep(OLDER/name(dx,.8,1,"calibrated"))
    for tag in ("outside","alias"):keep(OLDER/name(.0125,1.,0.,tag))
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ("closeout.json","STOP-REQUESTED")}
    counts={}
    for group,rows in (("source_predictions",response),("physical_packet_checks",[r for r in physical if r["category"]=="physical"]),
                       ("auxiliary_packet_checks",[r for r in physical if r["category"]=="auxiliary"])):
        counts[group]=dict(passed=sum(bool(r["passes"]) for r in rows),total=len(rows))
    return dict(files=files,upstream=upstream,parent=LOCK,forecast=digest(fp),score_counts=counts,
                packets=len(list(HERE.glob("source-*.npz"))),recomputed_csv_rows=checked,box_controls=control(),
                comparison_target=TOL,stress_kind=str(pack["stress_kind"]),scope="three retained current profiles, synthetic charged burst")


if __name__=="__main__":
    receipt=report();path=HERE/"closeout.json"
    if sys.argv[1:]==["seal"]:
        with path.open("x") as stream:json.dump(receipt,stream,indent=2,sort_keys=True,allow_nan=False)
    else:assert receipt==json.loads(path.read_text())
    print("verified",len(receipt["files"]),"files",receipt["packets"],"coupled runs",receipt["score_counts"],digest(path))
