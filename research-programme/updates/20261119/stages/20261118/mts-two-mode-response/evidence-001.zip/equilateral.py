import csv
from scipy.integrate import solve_ivp
from threepoint import cyclic
from triangles import ROOT,np,Bank,CASES,guard,save,packet


def observable(case,idx,coarse=False):
    bank=Bank(case,[idx,idx],2 if coarse else 1,'early-')
    heavy=case=='heavy';wave=bank.wave[0]
    fh=bank.frac[-1] if heavy else 0.;fd=1-fh
    times=np.linspace(-np.log(9.),-np.log(4.),13)
    dim=4 if heavy else 2
    init=np.column_stack((np.eye(dim),np.zeros(dim)))
    def rhs(time,vec):
        state=vec.reshape(dim,-1)
        drag,omega,pr=bank.background(time);total=omega.sum()
        w=pr[-1]*wave**4
        out=np.zeros_like(state);den,vel=state[:2]
        hd=den+(fd*state[2] if heavy else 0)
        out[0]=vel
        out[1]=total*den-drag*vel-fh*w*hd
        if heavy:
            out[2]=state[3];out[3]=-drag*state[3]-w*hd
        dens,flow=bank.src(time)[:,0]
        adv=.5*flow*dens
        euler=-.25*flow**2+.75*pr*wave**4*dens**2
        out[0,-1]+=bank.frac@adv
        out[1,-1]+=bank.frac@euler
        if heavy:
            out[2,-1]+=adv[-1]-(bank.frac[:2]@adv[:2])/fd
            out[3,-1]+=euler[-1]-(bank.frac[:2]@euler[:2])/fd
        return out.ravel()
    fit=solve_ivp(rhs,(times[0],times[-1]),init.ravel(),t_eval=times,method='DOP853',rtol=2e-11,atol=2e-14,max_step=.02)
    assert fit.success
    first=bank.src(times)[:,0,0]@bank.frac
    response=2*fit.y.T.reshape(-1,dim,dim+1)[:,0]/first[:,None]**2
    return times,response[:,:-1],response[:,-1]


def build():
    guard();table=[];bankrows={};diag={}
    with np.load(ROOT/'early-cold.npz') as data:
        ks=data['k'];norm=data['rho0']@data['D'][:,:,-1]/data['rho0'].sum()
    for idx in (6,7,3,4):
        k=ks[idx]
        for case in CASES:
            bank=Bank(case,[idx,idx],prefix='early-')
            for end in (3,5,8):
                dd=bank.src(-np.log1p(end))[0,0]@bank.frac
                dimless=2.1e-9*(k/.05)**(-.0347)*(norm[idx]*dd)**2
                power=2*np.pi**2*dimless/k**3
                for start in (19,49,99):
                    row=cyclic(case,[idx,idx],k,start,end)
                    zero=2*row['total']/dd**2;grow=zero+2*row['eds_seed_contribution']/dd**2
                    table.append(dict(model=case,k=k,z=end,initial_z=start,delta2=dimless,P_Mpc3=power,Q_zero=zero,Q_EdS=grow,
                                      B_EdS_Mpc6=3*power**2*grow,Q_conservative_shift=2*row['conservative_shift']/dd**2))
        def combine(coarse):
            times,h,forcing=observable('heavy',idx,coarse)
            _,c,cold=observable('cold',idx,coarse)
            raw=np.column_stack((h,c))
            design=raw/np.linalg.norm(raw,axis=0)
            basis,sv,_=np.linalg.svd(design,full_matrices=False)
            diff=forcing-cold
            residual=diff-basis@(basis.T@diff)
            return times,design,sv,raw,diff,residual,basis
        times,design,sv,raw,diff,res,basis=combine(False)
        _,alt,sv2,_,diff2,res2,basis2=combine(True)
        weight=res/np.linalg.norm(res)
        leak=np.max(abs(weight@design))
        assert leak<2e-5
        coarse_leak=np.max(abs(weight@alt))
        projected_again=diff2-basis2@(basis2.T@diff2)
        check=cyclic('heavy',[idx,idx],k,8,3)
        checkcold=cyclic('cold',[idx,idx],k,8,3)
        def normal(case):return (Bank(case,[idx,idx],prefix='early-').src(-np.log(4))[0,0]@Bank(case,[idx,idx],prefix='early-').frac)**2
        expected=2*check['total']/normal('heavy')-2*checkcold['total']/normal('cold')
        assert abs(diff[-1]-expected)<2e-5
        bankrows[str(k)]=dict(k=k,smallest_scaled_singular=sv[-1],spectrum=sv.tolist(),norm_raw=float(np.linalg.norm(diff)),
            norm_seed_independent=float(np.linalg.norm(res)),largest_original_change=float(np.max(abs(diff))),coordinate_norm_leak=float(leak),
            half_grid_leak=coarse_leak,half_grid_projected_difference=float(np.linalg.norm(res-projected_again)),
            coarse_raw_contrast_change=float(np.linalg.norm(diff-diff2)),weight=weight.tolist(),
            independently_propagated_difference=expected,retained_fraction=np.linalg.norm(res)/np.linalg.norm(diff))
        diag[str(k)+'_design']=raw;diag[str(k)+'_difference']=diff;diag[str(k)+'_times']=times
    with (ROOT/'equilateral.csv').open('x',encoding='utf8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=table[0]);writer.writeheader();writer.writerows(table)
    save('seed-independent.json',bankrows);packet('initial-subspaces.npz',**diag)


if __name__=='__main__':build()
