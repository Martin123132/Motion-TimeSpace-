from triangles import Bank,ROOT,CASES,np,guard,save
from scipy.fft import fft2,ifft2
import psutil


def replay(case,side,steps,eps,outref,ids=(2,3),mu=.6,start=2,end=0,seed=False,prefix=''):
    bank=Bank(case,list(ids),prefix=prefix);left=-np.log1p(start);dt=(-np.log1p(end)-left)/steps
    wp,wq=bank.wave
    basis=np.fft.fftfreq(side)*side
    ix,iy=np.meshgrid(basis,basis,indexing='ij')
    kx=wp*ix+wq*mu*iy;ky=wq*np.sqrt(1-mu**2)*iy;ksq=kx**2+ky**2
    mask=(abs(ix)<side/3)&(abs(iy)<side/3)
    coords=np.arange(side)*2*np.pi/side
    harmonics=np.array(np.broadcast_arrays(np.cos(coords[:,None]),np.cos(coords[None,:])))
    ds,us=bank.src(left)
    dens=eps*np.einsum('ps,pxy->sxy',ds,harmonics)
    velocity=eps*np.einsum('ps,pxy->sxy',us/bank.wave[:,None]**2,harmonics)
    if seed:
        square=wp**2+wq**2+2*mu*wp*wq;alpha=1+.5*mu*(wp/wq+wq/wp);beta=square*mu/(2*wp*wq)
        cross=np.cos(coords[:,None]+coords[None,:])
        dens+=eps**2*((5*alpha+2*beta)/7*ds[0]*ds[1])[:,None,None]*cross
        velocity+=eps**2*((3*alpha+4*beta)/14*(us[0]*ds[1]+us[1]*ds[0])/square)[:,None,None]*cross
    has_wave=case=='heavy'
    fields=np.concatenate([dens[:2],velocity[:2]]).astype(complex)
    if has_wave:
        coupling=bank.mass*np.exp(2*left+bank.logH(left))
        wavefn=np.sqrt(1+dens[-1])*np.exp(1j*coupling*velocity[-1])
        fields=np.concatenate([fields,wavefn[None]])
    inv=np.divide(-1,ksq,out=np.zeros_like(ksq),where=ksq!=0)
    def rhs(t,fields):
        drag,omega,_=bank.background(t)
        dust=fields[:2].real
        source=omega[:2]@dust.reshape(2,-1)
        if has_wave:source+=omega[-1]*(abs(fields[-1])**2-1).ravel()
        potk=fft2(source.reshape(side,side))*inv*mask
        potential=ifft2(potk).real
        sk=fft2(fields[2:4].real)*mask
        gx=ifft2(sk*(1j*kx)).real;gy=ifft2(sk*(1j*ky)).real
        dust_rhs=ifft2(-(1j*kx*fft2((1+dust)*gx)+1j*ky*fft2((1+dust)*gy))*mask).real
        vel_rhs=-drag*fields[2:4].real-.5*(gx**2+gy**2)-potential
        out=np.concatenate([dust_rhs,ifft2(fft2(vel_rhs)*mask).real]).astype(complex)
        if has_wave:
            coupling=bank.mass*np.exp(2*t+bank.logH(t))
            psi=fields[-1]
            deriv=ifft2(-1j*mask*(ksq*fft2(psi)/(2*coupling)+coupling*fft2(potential*psi)))
            out=np.concatenate([out,deriv[None]])
        return out
    picks=[];phase=[];mass_error=0.
    for step in range(steps+1):
        if step%(steps//4)==0:
            actual=fields[:2].real
            if has_wave:actual=np.concatenate([actual,(abs(fields[-1])**2-1)[None]])
            mode=2*fft2(actual)[:,1,1]/side**2/eps**2
            picks.append(mode.real);phase.append(np.max(abs(mode.imag)))
            mass_error=max(mass_error,float(np.max(abs(np.mean(actual,axis=(1,2))))))
        if step==steps:break
        time=left+dt*step
        first=rhs(time,fields);second=rhs(time+dt/2,fields+.5*dt*first)
        third=rhs(time+dt/2,fields+.5*dt*second);fourth=rhs(time+dt,fields+dt*third)
        fields+=dt*(first+2*second+2*third+fourth)/6
    picks=np.array(picks);ref=outref[::12]
    assert ref.shape==picks.shape and np.max(phase)<1e-6 and mass_error<1e-9
    return dict(trajectory=picks.tolist(),max_relative=float(np.max(abs(picks-ref))/np.max(abs(ref))),
                total_today=float(picks[-1]@bank.frac),sine_leak=max(phase),mass_error=mass_error)


def main():
    guard()
    proc=psutil.Process();proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([proc.cpu_affinity()[0]])
    results={}
    with np.load(ROOT/'histories.npz') as hist:
        for case in CASES:
            ref=hist['main_'+case+'_coupled_density']
            tests=[(24,96,.002),(24,96,.001),(24,96,.0005),(32,192,.0005)]
            rows=[replay(case,*params,ref) for params in tests]
            fine=np.array(rows[-1]['trajectory']);coarse=np.array(rows[-2]['trajectory'])
            err=np.max(abs(fine-coarse))/np.max(abs(ref))
            assert rows[-1]['max_relative']<2e-5 and err<2e-5
            results[case]=dict(settings=tests,rows=rows,refinement=float(err))
            print(case,'direct field error',rows[-1]['max_relative'],flush=True)
    save('direct-field.json',results)


if __name__=='__main__':main()
