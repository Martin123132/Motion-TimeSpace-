import csv
from scipy.integrate import cumulative_simpson,solve_ivp
from triangles import ROOT,np,Bank,CASES,guard,load,save,geometry,response
from threepoint import adjoint,cyclic,TRIANGLES,ENDS,STARTS


class EinsteinDust:
    def __init__(self,wave):
        self.wave=np.array(wave);self.rho=np.array([3.]);self.frac=np.ones(1)
    def src(self,t,order=0):
        return np.exp(t)[...,None,None,None]*np.ones((2,2,1))
    def background(self,t,pressure=True):
        return .5,np.array([1.5]),np.zeros(1)


def eds_real_pipeline():
    checks=[]
    for wave,mu in (([.25,1.],.6),([.075,.1],0.),([1.,1.],-.5)):
        _,ap,aq,beta,_=geometry(np.array(wave),mu);alpha=(ap+aq)/2
        f2=(5*alpha+2*beta)/7
        res=response(EinsteinDust(wave),mu,4,'autonomous');t=res['N'];ai=np.exp(t[0])
        dec=(f2-alpha)/2.5;grow=-f2-dec
        analytic=f2*np.exp(2*t)+grow*ai*np.exp(t)+dec*ai**3.5*np.exp(-1.5*t)
        checks.append(float(max(np.max(abs(res[key][:,0]-analytic)) for key in ('density','conservative'))))
    assert max(checks)<2e-8
    return checks


def integrated(bank,start):
    times=np.linspace(-np.log1p(start),0.,2049)
    (dp,up)=bank.src(times).transpose(1,0,2,3)
    potentials=bank.metric(times)
    gain=np.exp(2*times+bank.logH(times))
    grav=-bank.wave**2*potentials[:,1]/np.exp(2*(times+bank.logH(times)))[:,None]
    press=bank.quant/(4*gain[:,None]**2)
    def integral(y):return cumulative_simpson(y,x=times,axis=0,initial=0.)
    cd=dp-dp[0]-3*(potentials[:,0]-potentials[0,0])[:,:,None]-integral(up)
    eu=(up*gain[:,None,None]-up[0]*gain[0]-integral(gain[:,None,None]*(grav[:,:,None]-bank.wave[None,:,None]**4*press[:,None,:]*dp)))/gain[:,None,None]
    return dict(continuity=np.max(abs(cd),axis=0).tolist(),euler=np.max(abs(eu),axis=0).tolist(),
                continuity_fraction=(np.max(abs(cd),axis=0)/np.max(abs(dp),axis=0)).tolist(),
                euler_fraction=(np.max(abs(eu),axis=0)/np.max(abs(up),axis=0)).tolist())


def validate():
    guard();eds=eds_real_pipeline();checks={};diff={}
    for case in CASES:
        bank=Bank(case,[2,3],prefix='early-')
        diff[case]={str(z):integrated(bank,z) for z in (2,99)}
        fine=response(bank,.6,2);half=response(Bank(case,[2,3],2,'early-'),.6,2)
        maxerr=float(np.max(abs(fine['density']-half['density']))/np.max(abs(fine['density'])))
        k=float(np.sqrt(geometry(bank.wave,.6)[0]))
        green=cyclic(case,[2,3],k,2,0)
        pred=green['total'];err=abs(pred-bank.frac@fine['density'][-1])/abs(pred)
        ns=len(bank.frac);initial=np.arange(1.,2*ns+1)/(ns*13.)
        def homogeneous(t,y):
            drag,om,pr=bank.background(t)
            return np.r_[y[ns:],(om@y[:ns])-drag*y[ns:]-pr*k**4*y[:ns]]
        left=-np.log(3.)
        f=solve_ivp(homogeneous,(left,0.),initial,rtol=1e-11,atol=1e-13,method='DOP853')
        assert f.success
        eprop=float(abs(bank.frac@f.y[:ns,-1]-adjoint(case,k,0)(left)@initial))
        assert max(err,maxerr,eprop)<2e-5
        checks[case]=dict(doubled_history_interval=maxerr,independent_green_vs_forward=err,arbitrary_seed_duality=eprop)
    save('validation.json',dict(eds_production_paths=eds,native_checks=checks,integrated_first_order=diff))


def attribute():
    rows=[];g=load(ROOT/'green-response.json')['retarded']
    with np.load(ROOT/'early-cold.npz') as src:
        ks=src['k'];norm=src['rho0']@src['D'][:,:,-1]/sum(src['rho0'])
    for end in ENDS:
        d={}
        for case in CASES:
            with np.load(ROOT/('early-'+case+'.npz')) as src:
                pos=int(np.argmin(abs(src['N']+np.log1p(end))));assert abs(src['N'][pos]+np.log1p(end))<1e-12
                d[case]=src['rho0']@src['D'][:,:,pos]/sum(src['rho0'])
        for name,indices in TRIANGLES.items():
            for start in STARTS:
                for seeded in (False,True):
                    models={}
                    for case in CASES:
                        kval=ks[indices];amp=d[case][indices]
                        power=2*np.pi**2/kval**3*2.1e-9*(kval/.05)**(-.0347)*amp**2
                        weight=power*np.roll(power,-1);weight/=weight.sum()
                        kernels=[];gap=[]
                        for perm in range(3):
                            p,q,last=np.roll(indices,-perm);r=g[f'{case}:{end}:{start}:{min(p,q)}:{max(p,q)}:{last}']
                            multiplier=norm[p]*norm[q]/(d[case][p]*d[case][q])
                            kernels.append((r['total']+(r['eds_seed_contribution'] if seeded else 0))*multiplier)
                            gap.append(r['conservative_shift']*multiplier)
                        models[case]=(weight,np.array(kernels),np.array(gap))
                    wh,fh,gh=models['heavy'];wc,fc,gc=models['cold']
                    qh=2*wh@fh;qc=2*wc@fc;reweight=(wh-wc)@(fh+fc);kernel=(wh+wc)@(fh-fc)
                    assert abs(reweight+kernel-(qh-qc))<1e-12
                    rows.append(dict(triangle=name,z=end,start=start,seed='EdS' if seeded else 'zero',Q_heavy=qh,Q_cold=qc,
                        relative_Q_change=(qh-qc)/qc,relative_power_reweight=reweight/qc,relative_kernel_change=kernel/qc,
                        heavy_residual_if_cold_F2=float(2*wh@(fh-fc)/qc),relative_pair_form_shift=float(2*(wh@gh-wc@gc)/qc)))
    with (ROOT/'attribution.csv').open('x',encoding='utf8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)


if __name__=='__main__':validate();attribute()
