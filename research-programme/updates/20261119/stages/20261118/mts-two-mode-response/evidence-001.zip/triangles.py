from setup_local import ROOT,np,CASES,guard,load,save,packet,digest
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp


class Bank:
    def __init__(self,case,ids,step=1,prefix=''):
        with np.load(ROOT/(prefix+'cold.npz')) as cold:
            norm=(cold['rho0']@cold['D'][:,:,-1])/cold['rho0'].sum()
        with np.load(ROOT/(prefix+case+'.npz')) as data:
            self.N=data['N'][::step]
            if self.N[-1]!=0:self.N=np.r_[self.N,0.]
            take=np.searchsorted(data['N'],self.N)
            self.wave=data['k'][ids];self.mass=float(data['mass'])
            self.rho=data['rho0'];self.frac=self.rho/self.rho.sum()
            self.quant=np.zeros(len(self.rho))
            if case=='heavy':self.quant[-1]=1/self.mass**2
            fields=[]
            for key in ('D','U'):
                fields.append((data[key][:,ids,:]/norm[ids][None,:,None])[:,:,take].transpose(2,1,0))
            self.src=CubicSpline(self.N,np.stack(fields,axis=1))
            self.logH=CubicSpline(self.N,np.log(data['H'][take]))
            self.metric=CubicSpline(self.N,np.stack([data[key][ids,:][:,take].T/norm[ids] for key in ('Phi','Psi')],axis=1))
            self.nu=CubicSpline(self.N,data['rhonu'][take])

    def background(self,time,pressure=True):
        hubble=np.exp(self.logH(time));a=np.exp(time)
        return (2+self.logH(time,1),self.rho/(2*a**3*hubble**2),
                self.quant*(1 if pressure else 0)/(4*a**4*hubble**2))


def solve(rhs,initial,left,epochs,precision=2e-10):
    fit=solve_ivp(rhs,(left,epochs[-1]),np.asarray(initial).ravel(),method='DOP853',atol=precision*.01,rtol=precision,t_eval=epochs,max_step=.045)
    assert fit.success and np.isfinite(fit.y).all() and fit.t[-1]==epochs[-1]
    return fit.y.T


def geometry(wave,mu):
    left,right=wave;dot=mu*left*right
    kap=left**2+right**2+2*dot
    ap,aq=1+dot/left**2,1+dot/right**2
    beta=kap*dot/(2*left**2*right**2)
    return kap,ap,aq,beta,dot


def sources(fields,gravity,wave,mu,pressure):
    dp,dq=fields[0];up,uq=fields[1]
    kap,ap,aq,beta,dot=geometry(wave,mu)
    adv=.5*(ap*up*dq+aq*uq*dp)
    euler=beta*up*uq
    eq=.5*pressure*kap*(sum(wave**2)+dot)*dp*dq
    tidal=.5*(ap*gravity[0]*dq+aq*gravity[1]*dp)
    flux=ap*aq*up*uq
    cq=pressure*ap*aq*np.prod(wave**2)*dp*dq
    return adv,euler,eq,tidal,flux,cq


def response(bank,mu,start=2,drive='native',pressure=True,points=49,precision=2e-10,end=0,seed=False):
    left=-np.log1p(start);times=np.linspace(left,-np.log1p(end),points);ns=len(bank.rho)
    shape=(2,2,ns);wave=bank.wave;kap=geometry(wave,mu)[0]
    linear0=bank.src(left);zero=np.zeros(ns)
    adv0=sources(linear0,[0,0],wave,mu,zero)[0]
    _,ap,aq,beta,_=geometry(wave,mu);alpha=.5*(ap+aq)
    (dp,dq),(up,uq)=linear0
    initd=(5*alpha+2*beta)/7*dp*dq if seed else zero
    initu=(3*alpha+4*beta)/14*(up*dq+uq*dp) if seed else zero
    initial=np.r_[linear0.ravel(),initd,initu,initd,initu+adv0,zero,zero]
    def rhs(time,state):
        drag,omega,press=bank.background(time,pressure)
        linear=state[:4*ns].reshape(shape)
        grav=linear[0]@omega
        linear_rhs=np.stack([linear[1],grav[:,None]-drag*linear[1]-wave[:,None]**4*press*linear[0]])
        fields=bank.src(time) if drive=='native' else linear
        if drive=='native':
            phi,psi=bank.metric(time)
            gravity=-wave**2*psi/np.exp(2*(time+bank.logH(time)))
        else:gravity=grav
        adv,euler,eq,tidal,flux,cq=sources(fields,gravity,wave,mu,press)
        dens,vel,cons,rate,gap,dgap=state[4*ns:].reshape(6,ns)
        feedback=lambda d:omega@d-press*kap**2*d
        correction=zero
        if drive=='native':
            dp,dq=fields[0];up,uq=fields[1];dprime,uprime=bank.src(time,1)
            missing_d=dprime-fields[1]
            missing_u=uprime+drag*fields[1]-gravity[:,None]+wave[:,None]**4*press*fields[0]
            _,ap,aq,_,_=geometry(wave,mu)
            correction=-.5*(ap*(missing_u[0]*dq+up*missing_d[1])+aq*(missing_u[1]*dp+uq*missing_d[0]))
        return np.r_[linear_rhs.ravel(),vel+adv,feedback(dens)-drag*vel+euler+eq,rate,
                     feedback(cons)-drag*rate+tidal+flux+cq,dgap,feedback(gap)-drag*dgap+correction]
    sol=solve(rhs,initial,left,times,precision)
    linear=sol[:,:4*ns].reshape(-1,*shape)
    dens,vel,cons,rate,gap,_=sol[:,4*ns:].reshape(-1,6,ns).transpose(1,0,2)
    retained=bank.src(times)
    err=np.max(abs(linear-retained),axis=0)/np.maximum(1e-12,np.max(abs(retained),axis=0))
    scale=max(np.max(abs(cons)),np.max(abs(dens)),1e-12)
    identity=np.max(abs(cons-dens-gap))/scale
    assert identity<2e-5
    return dict(N=times,density=dens,velocity=vel,conservative=cons,rate=rate,projection_gap=gap,
                linear=linear,native=retained,linear_fraction=err,identity=np.array(identity))


def diagnostics(bank,mu,start):
    times=np.linspace(-np.log1p(start),0,301)
    fields=bank.src(times);deriv=bank.src(times,1);phi=bank.metric(times)
    uc=fields[:,1,:,0]
    fac=np.exp(2*(times+bank.logH(times)))[:,None]
    gravity=-bank.wave**2*phi[:,1]/fac
    drag=2+bank.logH(times,1)
    cdmeuler=deriv[:,1,:,0]+drag[:,None]*uc
    cont=deriv[:,0]-fields[:,1]-3*bank.metric(times,1)[:,0,:,None]
    poisson=np.array([bank.background(t)[1]@state.T for t,state in zip(times,fields[:,0])])
    return dict(euler_cdm=float(np.max(abs(gravity-cdmeuler)/np.max(abs(gravity),axis=0))),
                continuity_species=(np.max(abs(cont),axis=0)/np.max(abs(fields[:,1]),axis=0)).tolist(),
                omission_first_order=(np.max(abs(poisson-gravity),axis=0)/np.max(abs(gravity),axis=0)).tolist(),
                horizon=float(np.max(np.sqrt(fac)/bank.wave)),weyl_slip_fraction=float(np.max(abs(phi[:,0]-phi[:,1])/np.max(abs(phi[:,1]),axis=0))))


def run():
    guard();entries={};summary={}
    tests=[('main',[2,3],.6,2),('right',[2,3],0.,2),('fold',[2,3],-.6,2),('large',[0,1],.6,2),
           ('small',[3,4],.6,2),('early',[2,3],.6,4),('late',[2,3],.6,1)]
    for key,ids,mu,start in tests:
        summary[key]={}
        for case in CASES:
            bank=Bank(case,ids);cell={}
            for kind,drive,pr in [('native','native',True),('coupled','autonomous',True)]+([('remove_late_pressure','autonomous',False)] if case=='heavy' else []):
                res=response(bank,mu,start,drive,pr)
                entries.update({key+'_'+case+'_'+kind+'_'+k:v for k,v in res.items()})
                cell[kind]=dict(total=float(res['density'][-1]@bank.frac),cons_total=float(res['conservative'][-1]@bank.frac),
                    species=res['density'][-1].tolist(),linear_mismatch=res['linear_fraction'].tolist(),two_form_gap=float(res['identity']))
            cell['weak_field']=diagnostics(bank,mu,start)
            summary[key][case]=cell
    packet('histories.npz',**entries)
    save('triangles.json',dict(cases=summary,protocol=digest(ROOT/'PROTOCOL.md'),banks={case:digest(ROOT/(case+'.npz')) for case in CASES}))


if __name__=='__main__':run()
