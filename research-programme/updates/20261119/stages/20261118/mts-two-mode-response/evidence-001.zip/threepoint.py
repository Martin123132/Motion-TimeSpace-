import csv
from functools import lru_cache
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from numpy.polynomial.legendre import leggauss
from triangles import ROOT,np,CASES,Bank,geometry,save,packet,guard,load

TRIANGLES={'345':[0,1,5],'middle':[6,2,7],'elongated':[2,3,3],'equilateral':[3,3,3]}
ENDS=(0,1,2)
STARTS=(4,9,19,49,99)


@lru_cache(None)
def adjoint(case,kout,end):
    sample=Bank(case,[0,1],prefix='early-')
    ns=len(sample.frac)
    def rhs(time,vec):
        drag,omega,press=sample.background(time)
        d,u=vec[:ns],vec[ns:]
        return np.r_[-omega*u.sum()+press*kout**4*u, -d+drag*u]
    res=solve_ivp(rhs,(-np.log1p(end),-np.log(100.)),np.r_[sample.frac,np.zeros(ns)],
                  dense_output=True,rtol=1e-10,atol=1e-12,method='DOP853',max_step=.05)
    assert res.success
    return res.sol


def quadrature(start,end,num,degree):
    nodes,weights=leggauss(degree)
    edges=np.linspace(-np.log1p(start),-np.log1p(end),num+1)
    middle=(edges[:-1]+edges[1:])*.5;width=np.diff(edges)*.5
    return (middle[:,None]+width[:,None]*nodes).ravel(),(width[:,None]*weights).ravel()


def cyclic(case,indices,kout,start,end,coarse=False):
    bank=Bank(case,indices,prefix='early-')
    p,q=bank.wave;ns=len(bank.frac)
    mu=(kout**2-p**2-q**2)/(2*p*q)
    assert abs(mu)<=1+1e-10
    cap,ap,aq,beta,dot=geometry(bank.wave,mu)
    assert abs(cap-kout**2)<1e-12
    t,w=quadrature(start,end,60 if coarse else 144,5 if coarse else 8)
    df,uf=bank.src(t).transpose(1,2,0,3);dp,dq=df;up,uq=uf
    lam=adjoint(case,float(kout),end)
    ld,lu=np.split(lam(t).T,2,axis=1)
    hub=bank.logH(t);press=bank.quant[None,:]*np.exp(-4*t-2*hub)[:,None]*.25
    cont=.5*(ap*up*dq+aq*uq*dp)
    adv=beta*up*uq
    wave=.5*press*cap*(p*p+q*q+dot)*dp*dq
    def integral(src,weights):return float(np.einsum('ts,ts,t->',src,weights,w))
    sources=[integral(cont,ld),integral(adv,lu),integral(wave,lu)]
    nd,nu=bank.src(t,1).transpose(1,2,0,3)
    grav=-bank.metric(t)[:,1].T*bank.wave[:,None]**2/np.exp(2*(t+hub))
    diff_d=nd-uf
    diff_u=nu+(2+bank.logH(t,1))[None,:,None]*uf-grav[:,:,None]+bank.wave[:,None,None]**4*press*df
    con_minus_bulk=integral(-.5*(ap*(diff_u[0]*dq+up*diff_d[1])+aq*(diff_u[1]*dp+uq*diff_d[0])),lu)
    alpha=(ap+aq)*.5;f2=(5*alpha+2*beta)/7;g2=(3*alpha+4*beta)/7
    t0=-np.log1p(start)
    (d0,d1),(u0,u1)=bank.src(t0)
    seed=np.r_[f2*d0*d1,.5*g2*(u0*d1+u1*d0)]
    row=lam(t0)
    return dict(sources=sources,total=sum(sources),conservative_shift=con_minus_bulk,
                eds_seed_contribution=float(row@seed),initial_row=row.tolist(),mu=float(mu),
                forcing_consistency=np.max(abs(diff_u),axis=1).tolist())


def eds_test():
    results=[]
    for p,q,mu in ((.25,1.,.6),(.075,.1,0.),(1.,1.,-.5)):
        _,ap,aq,beta,_=geometry(np.array([p,q]),mu)
        alpha=(ap+aq)*.5
        f2=(5*alpha+2*beta)/7;g2=(3*alpha+4*beta)/7
        left=-np.log(5)
        def rhs(t,y):return [y[1]+alpha*np.exp(2*t),1.5*y[0]-.5*y[1]+beta*np.exp(2*t)]
        fit=solve_ivp(rhs,(left,0.),np.exp(2*left)*np.array([f2,g2]),rtol=1e-11,atol=1e-13,method='DOP853')
        assert fit.success
        error=float(np.max(abs(fit.y[:,-1]-[f2,g2])))
        assert error<1e-9
        results.append(error)
    return results


def main():
    guard();eds=eds_test()
    with np.load(ROOT/'early-cold.npz') as inp:
        ks=inp['k']
        norm=inp['rho0']@inp['D'][:,:,-1]/sum(inp['rho0'])
    ledger={};table=[];maxerr=0.
    for case in CASES:
        with np.load(ROOT/('early-'+case+'.npz')) as inp:
            frac=inp['rho0']/inp['rho0'].sum()
            linear=CubicSpline(inp['N'],np.einsum('s,skt->tk',frac,inp['D']),axis=0)
        for end in ENDS:
            field=linear(-np.log1p(end))
            power=2*np.pi**2/ks**3*2.1e-9*(ks/.05)**(-.0347)*field**2
            delta2=ks**3*power/(2*np.pi**2)
            for name,triangle in TRIANGLES.items():
                for start in STARTS:
                    group=[];pre=[];shift=[];denom=0
                    for perm in range(3):
                        first,second,last=np.roll(triangle,-perm)
                        idx=[first,second];kout=ks[last]
                        label=f'{case}:{end}:{start}:{min(idx)}:{max(idx)}:{last}'
                        if label not in ledger:
                            row=cyclic(case,sorted(idx),kout,start,end)
                            if start in (4,99):
                                alt=cyclic(case,sorted(idx),kout,start,end,True)
                                numerr=abs(alt['total']-row['total'])/max(1e-10,abs(row['total']),sum(abs(v) for v in row['sources']))
                                maxerr=max(maxerr,numerr)
                                assert numerr<2e-5
                            ledger[label]=row
                        row=ledger[label]
                        pref=2*norm[first]*norm[second]/(field[first]*field[second])*power[first]*power[second]
                        group.append(pref*row['total']);pre.append(pref*row['eds_seed_contribution']);shift.append(pref*row['conservative_shift'])
                        denom+=power[first]*power[second]
                    bzero=sum(group);bgrow=bzero+sum(pre)
                    table.append(dict(model=case,triangle=name,start_z=start,end_z=end,k1=ks[triangle[0]],k2=ks[triangle[1]],k3=ks[triangle[2]],
                        max_delta2=max(delta2[triangle]),B_retarded=bzero,B_with_EdS_seed=bgrow,Q_retarded=bzero/denom,
                        Q_with_EdS_seed=bgrow/denom,Q_conservative_shift=sum(shift)/denom))
    assert len(table)==len(CASES)*len(ENDS)*len(STARTS)*len(TRIANGLES)
    with (ROOT/'tree-bispectrum.csv').open('x',encoding='utf8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=table[0]);writer.writeheader();writer.writerows(table)
    save('green-response.json',dict(retarded=ledger,finite_start_eds_fixture=eds,max_quadrature_fraction=maxerr))


if __name__=='__main__':main()
