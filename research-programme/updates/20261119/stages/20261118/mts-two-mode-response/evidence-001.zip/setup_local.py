from pathlib import Path
import os,sys,json,hashlib
for setting in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[setting]='1'
import numpy as np

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PRIOR=POST/'mts-kids-band-response-20261118'
BASE=POST/'condensate-origin-20261003'
MATCH=BASE/'native-heavy-matching-20261007'
SPEC=BASE/'resolved-matter-spectrum-20261007'
GROW=POST/'mts-growth-mode-native-20261118'
CASES=('cold','heavy','lcdm')


def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def load(path):return json.loads(path.read_text(encoding='utf8'))


def guard():
    assert digest(PRIOR/'closeout.json')=='cb07b47dea67db69f5bc600259a7099bbdffd9e1777302d9fd8c69fd5eade460'
    assert not any((path/'STOP-REQUESTED').exists() for path in (ROOT,POST,PRIOR))


def save(name,obj):
    with (ROOT/name).open('x',encoding='utf8') as stream:json.dump(obj,stream,indent=2,allow_nan=False)


def packet(name,**kwargs):
    with (ROOT/name).open('xb') as stream:np.savez_compressed(stream,**kwargs)


def native(case,extend=False):
    import psutil
    proc=psutil.Process();proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([proc.cpu_affinity()[0]])
    guard();sys.path.insert(0,str(MATCH))
    import matching_common as source
    library=MATCH/'native/camb/cambdll.dll'
    assert digest(library)==load(GROW/'input-lock.json')['inputs'][str(library)]
    origin=SPEC/'runs/projection/a225-w6-d8.npz'
    init=origin if case=='heavy' else BASE/'native-two-field-transfer-20261007/runs/backgrounds/cold.npz'
    with np.load(origin) as table:
        available=table['modes'];mass=float(table['heavy_mass_mpc']);rhoh=float(table['matching_density']) if case=='heavy' else 0.
    target=[.075,.1,.25,1.,2.]+([.125,.2,.3] if extend else [])
    ks=available[[np.argmin(abs(available-k)) for k in target]]
    assert all(abs(k-t)<1e-12 for k,t in zip(ks,target) if t!=2.)
    select=np.argsort(ks);unsort=np.argsort(select)
    params=source.params_for(init)
    if case=='lcdm':params.DarkEnergy=source.camb.dark_energy.DarkEnergyFluid()
    params.DoLateRadTruncation=False
    engine=source.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6
    efolds=np.unique(np.r_[np.linspace(-np.log(5.),0,513),-np.log(3.),-np.log(2.)])
    if extend:efolds=np.unique(np.r_[np.linspace(-np.log(100.),-np.log(5.),769),efolds,-np.log([10.,20.,50.])])
    scales=np.exp(efolds);red=1/scales-1
    times=engine.conformal_time(red,tol=1e-10)
    names=['a','H','etak','delta_cdm','delta_baryon','mts_drho_h','v_newtonian_cdm','v_newtonian_baryon','mts_q_h','Weyl','mts_match_count','mts_nonheavy_change']
    vals=engine.get_time_evolution(ks[select],times,vars=names,lAccuracyBoost=4)[unsort]
    get=lambda name:vals[:,:,names.index(name)]
    assert np.isfinite(vals).all() and np.all(get('mts_match_count')==(case=='heavy')) and np.all(get('mts_nonheavy_change')==0)
    hubble=engine.hubble_parameter(red)/299792.458
    assert np.max(abs(get('H')/(scales*hubble)-1))<2e-5
    Hc=get('H'); wave=ks[:,None];uc=get('v_newtonian_cdm');sigma=-Hc*uc/wave
    gauge=-3*Hc*sigma/wave
    dc=get('delta_cdm')+gauge;db=get('delta_baryon')+gauge
    densities=[dc,db];flows=[uc,get('v_newtonian_baryon')]
    if case=='heavy':
        densities.append(get('mts_drho_h')*get('a')/rhoh+gauge)
        flows.append(uc-wave*get('mts_q_h')*get('a')/(Hc*rhoh))
    curvature=get('etak')/wave-Hc*sigma/wave
    accel=2*get('Weyl')/wave**2-curvature
    native_bg=engine.get_background_densities(scales,vars=['cdm','baryon','nu'])
    clustered=[native_bg[k]/scales for k in ('cdm','baryon')]
    if case=='heavy':clustered.append(np.full(len(scales),rhoh))
    density0=np.array(clustered)[:,-1]
    assert np.max(abs(np.array(clustered)/density0[:,None]-1))<2e-5
    with np.load(PRIOR/(case+'.npz')) as old:
        assert digest(PRIOR/(case+'.npz'))==load(PRIOR/'closeout.json')['files'][case+'.npz']
        knots=np.array([np.argmin(abs(old['k']-k)) for k in ks]);assert np.all(old['k'][knots]==ks)
        anchor=[(np.argmin(abs(red-z)),np.argmin(abs(old['z']-z))) for z in (0.,1.,2.,4.)]
        mismatch=max(float(np.max(abs(get('Weyl')[:,i]/old['weyl'][knots,j]-1))) for i,j in anchor)
        assert mismatch<2e-5
    packet(('early-' if extend else '')+case+'.npz',N=efolds,k=ks,H=hubble,D=np.array(densities),U=np.array(flows),Phi=curvature,Psi=accel,
           rho0=density0,mass=mass,gauge=gauge,rhonu=native_bg['nu'],origin=digest(init),native=digest(library),
           weyl_anchor_fraction=mismatch,raw_names=names,raw=vals)
    print(case,'native consistency',mismatch,flush=True)


if __name__=='__main__':
    for case in CASES:native(case,'early' in sys.argv[1:])
