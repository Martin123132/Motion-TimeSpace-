import ast,csv
from setup_local import ROOT,PRIOR,CASES,np,guard,digest,load,save


def run():
    guard()
    for path in ROOT.glob('*.py'):ast.parse(path.read_text(encoding='utf8'))
    r=load(ROOT/'triangles.json')
    assert r['protocol']==digest(ROOT/'PROTOCOL.md') and all(r['banks'][c]==digest(ROOT/(c+'.npz')) for c in CASES)
    assert len(r['cases'])==7
    for model in CASES:
        with np.load(ROOT/(model+'.npz')) as base,np.load(ROOT/('early-'+model+'.npz')) as ext:
            mask=np.searchsorted(ext['N'],base['N'])
            assert np.array_equal(ext['N'][mask],base['N'])
            assert np.array_equal(ext['k'][:5],base['k'])
            for key in ('D','U'):
                new=ext[key][:,:5,:][:,:,mask];old=base[key]
                assert np.max(abs(new-old)/np.max(abs(old),axis=2,keepdims=True))<2e-5
            assert max(float(f['weyl_anchor_fraction']) for f in (base,ext))<2e-5
        for name in ('direct-field.json','high-redshift-check.json'):
            raw=load(ROOT/name)
            item=raw[model]['rows'][-1] if name=='direct-field.json' else raw['field'][model]['direct_field'][-1]
            assert item['max_relative']<2e-5
    arb=load(ROOT/'initial-state-requirement.json')
    assert abs(np.array(arb['response_row'])@arb['example_not_physical_prior']+arb['contrast'])<1e-12
    for name,count in [('tree-bispectrum.csv',180),('attribution.csv',120),('equilateral.csv',108)]:
        with (ROOT/name).open(encoding='utf8') as stream:rows=list(csv.DictReader(stream))
        assert len(rows)==count and all(all(v not in ('','nan','inf','-inf') for v in row.values()) for row in rows)
    eq=load(ROOT/'high-redshift-check.json')
    parts=eq['pressure_attribution']
    for model in CASES:
        row=parts[model+':4:99']
        assert abs(sum(v for key,v in row.items() if key!='total')-row['total'])<1e-12
        assert abs(row['total']-eq['field'][model]['Q_native'])<2e-7
    assert (ROOT/'RESULTS.md').exists() and all(p.is_file() and '.partial' not in p.name for p in ROOT.iterdir())
    files={p.name:digest(p) for p in sorted(ROOT.iterdir())}
    save('closeout.json',dict(previous_seal=digest(PRIOR/'closeout.json'),files=files))
    assert all(digest(ROOT/name)==sig for name,sig in load(ROOT/'closeout.json')['files'].items())
    print(len(files),digest(ROOT/'closeout.json'))


if __name__=='__main__':run()
