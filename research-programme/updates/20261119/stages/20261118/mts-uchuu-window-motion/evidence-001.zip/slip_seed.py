from population import ROOT,PREV,np,cKDTree,gauss
from fourier import guard,read,write,digest
from tracers import fields
import h5py


def projected_environment(directions,vel,dist,target):
    w=1/dist**2
    w/=np.sum(w,axis=1)[:,None]
    design=np.sqrt(w)[:,:,None]*directions
    left,sig,right=np.linalg.svd(design,full_matrices=False)
    assert np.all(sig[:,-1]>1e-10*sig[:,0])
    pinv=(np.swapaxes(right,1,2)/sig[:,None,:])@np.swapaxes(left,1,2)
    coef=np.einsum('ni,nij->nj',target,pinv)*np.sqrt(w)
    assert np.max(abs(np.einsum('ni,nij->nj',coef,directions)-target))<2e-9
    reconstructed=np.einsum('nij,nj->ni',pinv,vel*np.sqrt(w))
    scatter=np.sum(w*(vel-np.einsum('nij,nj->ni',directions,reconstructed))**2,axis=1)
    return np.sum(coef*vel,axis=1),scatter,np.linalg.norm(coef,axis=1),coef


def prepare(cap,cone,reader=fields,window=(.2,.5)):
    raw,_,_=reader(cap,cone)
    with h5py.File(PREV/'inputs'/f'COMB_{cap}_Uchuu_{cone}.dat.h5') as ff:
        def column(key):
            arr=np.empty(ff[key].shape);ff[key].read_direct(arr);return arr
        zobs=column('z_obs');wt=column('w_cp')*column('w_fkp')*column('w_npcf')
        chosen=np.flatnonzero((zobs>=window[0])&(zobs<window[1])&(wt>0))
        assert np.array_equal(raw['ids'],ff['id'][:][chosen])
        physical=column('vlos')[chosen]
        zcos=column('z_cos')[chosen]
        cart=np.column_stack([column(key)[chosen] for key in ('x','y','z')])
        velocity=np.column_stack([column(key) for key in ('vx','vy','vz')])
    sky=raw['sky']/raw['radius'][:,None]
    center=np.flatnonzero(~raw['sat'])
    sat=np.flatnonzero(raw['sat'])
    tree=cKDTree(raw['sky'][center])
    kind=np.where(raw['matched'][sat],1,2)
    boost=np.array([271.,-192.,83.])
    receipts=[];parts=[];maxerr=0
    for pos in range(0,len(sat),4000):
        source=sat[pos:pos+4000]
        dist,neighbors=tree.query(raw['sky'][source],k=64,workers=1)
        used=np.full((len(source),32),-1,dtype=np.int64);rows=used.copy();radii=used.astype(float)
        tally=np.zeros(len(source),int)
        for col in range(64):
            loc=center[neighbors[:,col]]
            ids=raw['family'][loc]
            take=np.flatnonzero((tally<32)&(dist[:,col]>0)&(ids!=raw['family'][source])&~np.any(used==ids[:,None],axis=1))
            used[take,tally[take]]=ids[take];rows[take,tally[take]]=loc[take];radii[take,tally[take]]=dist[take,col]
            tally[take]+=1
        assert (tally==32).all()
        target=sky[source];envs=[]
        for size in (8,32):
            ids=rows[:,:size]
            design=sky[ids];values=physical[ids]
            env,scatter,noise,coef=projected_environment(design,values,radii[:,:size],target)
            maxerr=max(maxerr,float(np.max(abs(np.sum(coef*(design@boost),axis=1)-target@boost))))
            envs.append(env)
            receipts.append((size,noise))
        host=envs[0].copy()
        matched=raw['matched'][source]
        rr=source[matched]
        host[matched]=np.einsum('ij,ij->i',velocity[raw['host'][rr]],cart[rr]/np.linalg.norm(cart[rr],axis=1)[:,None])
        parts.append(np.column_stack([host,host-envs[1],scatter]))
    host,slip,scatter=np.concatenate(parts).T
    assert maxerr<2e-7
    info=dict(boost_error_kms=maxerr,noise_amplification={str(size):np.quantile(np.concatenate([value for level,value in receipts if level==size]),[.5,.95,.99,1]).tolist() for size in (8,32)})
    return dict(indices=sat,kind=kind,zcos=zcos[sat],host=host,slip=slip,scatter=scatter,velocity=physical[sat],weight=raw['weight'][sat]),info


def calibrate(cap):
    data,info=prepare(cap,0)
    output={}
    for kind in (1,2):
        keep=data['kind']==kind
        wt,slip,scatter=(data[key][keep] for key in ('weight','slip','scatter'))
        residual=(data['velocity']-data['host'])[keep]
        gamma=float(np.sum(wt*slip*residual)/np.sum(wt*slip**2))
        remainder=residual-gamma*slip
        order=np.argsort(scatter);cdf=np.cumsum(wt[order])/wt.sum()
        edges=scatter[order][np.searchsorted(cdf,[.25,.5,.75])]
        groups=np.searchsorted(edges,scatter)
        rules=[]
        for group in range(4):
            pick=groups==group
            sym=np.r_[remainder[pick],-remainder[pick]];weight=np.tile(wt[pick],2)
            rule=gauss(sym,weight,12)
            rule.update(count=int(sum(pick)),rms_kms=float(np.sqrt(np.average(sym**2,weights=weight))))
            rules.append(rule)
        sym=np.r_[remainder,-remainder]
        output[str(kind)]=dict(gamma=gamma,edges_kms2=edges.tolist(),laws=rules,pooled=gauss(sym,np.tile(wt,2),12),
            before_rms=float(np.sqrt(np.average(residual**2,weights=wt))),after_mean_rms=float(np.sqrt(np.average(remainder**2,weights=wt))))
    return dict(classes=output,checks=info)


if __name__=='__main__':
    guard()
    write('boost-safe-seed.json',dict(caps={cap:calibrate(cap) for cap in ('S','N')},
        sources={name:digest(ROOT/name) for name in ('SLIP-CONTRACT.md','slip_seed.py','population.py','forecast-lock.json')},
        type='Training coefficients only; higher-redshift multipoles have not been evaluated'))
