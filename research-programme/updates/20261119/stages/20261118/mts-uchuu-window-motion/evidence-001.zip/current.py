from run import ROOT,np,guard,read,write,catalogue,meanband,fields_at,estimator,locks
from fourier import SIZE,BOX,TAKE,K,NHAT,PROBES,nufft
from math import factorial


def moments(cat,index,model):
    sight=cat['sight'][index]
    radius=cat['radius'][index]+cat['host'][index]
    coords=np.ascontiguousarray(radius[:,None]*sight)
    weight=cat['weight'][index]
    residual=cat['residual'][index]
    plan=nufft.plan(nu2u=True,coord=coords,grid_shape=(SIZE,)*3,epsilon=3e-10,nthreads=1,periodicity=BOX)
    grid=np.empty((SIZE,)*3,dtype=complex)
    out=[];errs=[]
    for order in (1,2):
        expected=np.zeros(len(index))
        for kind in (1,2):
            rule=model[str(kind)]['independent']
            expected[cat['kind'][index]==kind]=np.dot(rule['probs'],np.array(rule['nodes'])**order)
        amplitude=weight*(residual**order-expected)
        contracted=[]
        for rank in (order,order+2):
            total=np.zeros(len(K),complex)
            for aa in range(rank+1):
                for bb in range(rank+1-aa):
                    cc=rank-aa-bb
                    values=amplitude*sight[:,0]**aa*sight[:,1]**bb*sight[:,2]**cc
                    plan.nu2u(forward=True,points=values.astype(complex),out=grid)
                    count=factorial(rank)/(factorial(aa)*factorial(bb)*factorial(cc))
                    total+=grid.ravel()[TAKE]*count*NHAT[:,0]**aa*NHAT[:,1]**bb*NHAT[:,2]**cc
            contracted.append(total)
        total=np.stack([contracted[0],1.5*contracted[1]-.5*contracted[0]])
        for idx in PROBES:
            mu=sight@NHAT[idx]
            sample=amplitude*mu**order*np.exp(-1j*K[idx]*(coords@NHAT[idx]))
            direct=np.array([sum(sample),sum(sample*(1.5*mu**2-.5))])
            errs.append(float(max(abs(direct-total[:,idx]))/np.sqrt(amplitude@amplitude)))
        out.append(total*(-1j*K)**order/factorial(order))
    assert max(errs)<2e-5
    return out,errs


def case(cap):
    guard()
    fixed=read(ROOT/'forecast-lock.json')
    assert locks()==fixed['locks']
    model=fixed['caps'][cap]['model']
    result=read(ROOT/(cap+'1-result.json'))
    cat,_=catalogue(cap,1)
    branches={key:[] for key in ('base','true','current','second','both')}
    errs=[]
    for half in (0,1):
        mask=cat['half']==half
        central,_=fields_at(cat,np.flatnonzero(mask&(cat['kind']==0)),model,'obs')
        index=np.flatnonzero(mask&(cat['kind']!=0))
        convolved,_=fields_at(cat,index,model,'independent')
        truth,_=fields_at(cat,index,model,'obs')
        (current,second),direct=moments(cat,index,model)
        errs.extend(direct)
        for key,sat in [('base',convolved),('true',truth),('current',convolved+current),('second',convolved+second),('both',convolved+current+second)]:
            branches[key].append(central+sat)
    with np.load(ROOT/f'random-{cap}.npz') as ran:
        powers={key:estimator(np.stack(val),ran['amplitude'],np.array(result['alphas']),result['normalization'])[0] for key,val in branches.items()}
    with np.load(ROOT/(cap+'1-independent-error.npz')) as saved:
        replay=float(np.max(abs(saved['cross']-(powers['true']-powers['base']))))
    assert replay<2e-5
    errors={key:meanband(powers['true']-powers[key],True).tolist() for key in ('base','current','second','both')}
    return dict(errors=errors,mean_abs_primary={key:float(np.mean(abs(np.array(val)[:,:2]))) for key,val in errors.items()},
                worst_direct=max(errs),exact_mode_replay_max=replay)


if __name__=='__main__':write('current-vs-width.json',{cap:case(cap) for cap in ('S','N')})
