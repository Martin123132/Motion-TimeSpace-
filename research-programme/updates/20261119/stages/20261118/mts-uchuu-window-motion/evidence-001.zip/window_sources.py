import os
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen


ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/'mts-uchuu-tracer-20261118'
CACHE=ROOT/'inputs'
BASE='https://skun.iaa.es/SUsimulations/UchuuDR2/Uchuu_GLAM_BOSS-eBOSS/Uchuu/'


def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def guard():
    assert digest(PREV/'closeout.json')=='4711deb6996202e4d1c3a3a760cb52cbcc75f4190984c2d217c72777d3ceb0ea'
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (ROOT,ROOT.parent,PREV))


def write(name,obj):
    with (ROOT/name).open('x',encoding='utf8') as handle:json.dump(obj,handle,indent=2,allow_nan=False)


def read(path):
    return json.loads(path.read_text(encoding='utf8'))


def acquire(cap):
    guard()
    name=f'COMB_{cap}_Uchuu.ran.h5'
    url=BASE+name
    path=CACHE/name
    receipt=ROOT/(name+'.json')
    if receipt.exists():
        assert digest(path)==read(receipt)['sha256'];return
    partial=CACHE/(name+'.partial')
    assert not path.exists() and not partial.exists()
    with urlopen(Request(url,method='HEAD'),timeout=45) as response:
        total=int(response.headers['Content-Length']);etag=response.headers['ETag']
    assert 0<total<=1_600_000_000
    with urlopen(url,timeout=90) as response, partial.open('xb') as stream:
        assert int(response.headers['Content-Length'])==total and etag==response.headers['ETag']
        while chunk:=response.read(1<<20):
            stream.write(chunk)
            if stream.tell()%(64<<20)==0:guard()
        assert stream.tell()==total
    with partial.open('rb') as stream:assert stream.read(8)==bytes.fromhex('894844460d0a1a0a')
    partial.rename(path)
    write(receipt.name,dict(url=url,bytes=total,sha256=digest(path),etag=etag,utc=datetime.now(timezone.utc).isoformat()))
    print(name,total,flush=True)


if __name__=='__main__':
    CACHE.mkdir(exist_ok=True)
    for cap in ('S','N'):acquire(cap)
