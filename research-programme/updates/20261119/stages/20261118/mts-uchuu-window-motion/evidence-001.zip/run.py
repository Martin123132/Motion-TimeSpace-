from population import catalogue,fit
from close_pairs import measure,predict
from fourier import ROOT,PREV,np,guard,read,write,digest,CUB,K,LABEL,BANDS,sums,meanband,output
from scipy.spatial import cKDTree
import sys


LOCK=('PROTOCOL.md','window_sources.py','fourier.py','population.py','close_pairs.py','run.py')


def locks():
    return {name:digest(ROOT/name) for name in LOCK}


def train():
    guard()
    out={}
    for cap in ('S','N'):
        cat,meta=catalogue(cap,0)
        model=fit(cat)
        out[cap]=dict(model=model,short=measure(cat,model,False),catalogue=meta)
        print('trained',cap,flush=True)
    write('forecast-lock.json',dict(caps=out,locks=locks(),source=digest(PREV/'closeout.json')))


def counts(cat):
    left,right=cKDTree(cat['sky']).query_pairs(10,output_type='ndarray').T
    keep=cat['half'][left]!=cat['half'][right]
    left,right=left[keep],right[keep]
    shell=np.searchsorted([2.,5.,10.],np.linalg.norm(cat['sky'][left]-cat['sky'][right],axis=1))
    types=np.minimum(cat['kind'][left],cat['kind'][right])*3+np.maximum(cat['kind'][left],cat['kind'][right])
    cell=shell*18+types*2+(cat['family'][left]==cat['family'][right])
    return {str(key):[int(sum(cell==key)),float(np.sum((cat['weight'][left]*cat['weight'][right])[cell==key]))] for key in np.unique(cell)}


def angular_geometry():
    return dict(counts=np.bincount(LABEL).tolist(),balance_range=[float(CUB.min()),float(CUB.max())],
                k2=meanband(K**2,True).tolist(),k4=meanband(K**4,True).tolist())


def fields_at(cat,idx,model,mode):
    sight,radius,weight=(cat[key][idx] for key in ('sight','radius','weight'))
    if mode in ('real','obs','host'):
        shift=0 if mode=='real' else cat['total' if mode=='obs' else 'host'][idx]
        return sums(sight,radius+shift,weight)
    position=[];direction=[];mass=[]
    for kind in (1,2):
        here=cat['kind'][idx]==kind
        obj=model[str(kind)]
        center=radius[here]+cat['host'][idx[here]]
        if mode=='linear':center+=obj['mean']+obj['slope']*(cat['host'][idx[here]]-obj['host_mean'])
        for node,prob in zip(obj[mode]['nodes'],obj[mode]['probs']):
            position.append(center+node);direction.append(sight[here]);mass.append(weight[here]*prob)
    return sums(np.concatenate(direction),np.concatenate(position),np.concatenate(mass))


def estimator(field,random,alphas,norm):
    residual=field-alphas[:,None,None]*random
    aa,bb=residual
    cross=2*np.real(aa[0]*bb.conj()+bb[0]*aa.conj())*np.array([1,5])[:,None]/norm
    merged=aa+bb
    auto=np.real(merged[0]*merged.conj())*np.array([1,5])[:,None]/norm
    return cross,auto


def case(cap,cone):
    guard()
    fixed=read(ROOT/'forecast-lock.json')
    assert fixed['locks']==locks()
    source=fixed['caps'][cap];model=source['model']
    cat,meta=catalogue(cap,cone)
    geom=angular_geometry();geomcount=counts(cat)
    norm=cat['weight']@cat['weight']
    correction,uncovered=predict(source['short'],geomcount,norm,meanband(K**2,True),meanband(K**4,True))
    name=cap+str(cone)
    write(name+'-pair-forecast.json',dict(training=digest(ROOT/'forecast-lock.json'),composition=geomcount,
            correction=correction.tolist(),uncovered_weight=uncovered))
    branches=('real','obs','host','independent','linear','missing_fixed')
    amps={branch:[] for branch in branches}
    checks=[]
    def calculate(idx,mode):
        value,err=fields_at(cat,idx,model,mode)
        checks.append(err.tolist())
        return value
    for half in range(2):
        mask=cat['half']==half
        central=calculate(np.flatnonzero(mask&(cat['kind']==0)),'obs')
        sats=np.flatnonzero(mask&(cat['kind']!=0))
        amps['real'].append(calculate(np.flatnonzero(mask),'real'))
        for mode in ('obs','host','independent','linear'):
            amps[mode].append(central+calculate(sats,mode))
        miss=np.flatnonzero(mask&(cat['kind']==2))
        amps['missing_fixed'].append(amps['obs'][-1]+calculate(miss,'real')-calculate(miss,'obs'))
    with np.load(ROOT/f'random-{cap}.npz') as ran:
        alphas=np.bincount(cat['half'],weights=cat['weight'])/ran['sumw']
        random=ran['amplitude']
        estimates={mode:estimator(np.stack(amplitude),random,alphas,norm) for mode,amplitude in amps.items()}
        random_rows=int(ran['count']);random_direct=float(ran['checks'].max())
    balanced={};plain={};auto={};directional={}
    for mode in branches:
        crossdiff=estimates[mode][0]-estimates['real'][0]
        autodiff=estimates[mode][1]-estimates['real'][1]
        balanced[mode]=meanband(crossdiff,True).tolist();plain[mode]=meanband(crossdiff,False).tolist()
        if mode in ('real','obs','host','missing_fixed'):auto[mode]=meanband(autodiff,True).tolist()
    balanced['independent_plus_short']=(balanced['independent']+correction).tolist()
    actual_short=measure(cat,model,True)
    assert set(geomcount)==set(actual_short)
    for key,row in geomcount.items():assert np.allclose(row,actual_short[key][:2],atol=1e-9,rtol=1e-12)
    own,_=predict(actual_short,geomcount,norm,meanband(K**2,True),meanband(K**4,True))
    rigorous=np.array([1,5])[:,None]*4*sum(row[6] for row in actual_short.values())/norm*meanband(K**6,True)
    exact=4*sum(np.array(row[7:15]) for row in actual_short.values()).reshape(2,4)/norm
    center_poly,_=predict(actual_short,geomcount,norm,BANDS**2,BANDS**4)
    center_bound=np.array([1,5])[:,None]*4*sum(row[6] for row in actual_short.values())/norm*BANDS**6
    assert np.all(abs(exact-center_poly)<=center_bound+2e-10)
    for mode in ('host','independent','linear'):
        output(name+'-'+mode+'-error.npz',cross=estimates['obs'][0]-estimates[mode][0])
    write(name+'-result.json',dict(cap=cap,cone=cone,catalogue=meta,random_rows=random_rows,random_direct=random_direct,
        direct_check_max=float(np.max(checks)),alphas=alphas.tolist(),normalization=float(norm),modes=geom,auto=auto,
        cross=balanced,ordinary_cross=plain,own_close_polynomial=own.tolist(),own_close_remainder_bound=rigorous.tolist(),
        continuous_center_4node_control=exact.tolist(),center_bound=center_bound.tolist(),forecast_uncovered_weight=uncovered))
    print('finished',name,'check',np.max(checks),flush=True)


if __name__=='__main__':
    if sys.argv[1]=='train':train()
    else:
        for arg in sys.argv[1:]:case(arg[0],int(arg[1:]))
