from fourier import ROOT, PREV, np, guard, digest, read
from tracers import fields
from scipy.spatial import cKDTree


def catalogue(cap,cone):
    raw,meta,_=fields(cap,cone)
    kind=np.where(~raw['sat'],0,np.where(raw['matched'],1,2))
    host=raw['total'].copy()
    known=kind==1
    host[known]-=raw['internal'][known]
    missing=np.flatnonzero(kind==2)
    centers=np.flatnonzero(kind==0)
    dist,near=cKDTree(raw['sky'][centers]).query(raw['sky'][missing],k=24,workers=1)
    counts=np.zeros(len(missing),int);weights=np.zeros(len(missing))
    used=np.full((len(missing),8),-1,dtype=np.int64)
    numer=np.zeros(len(missing));outer=np.zeros(len(missing))
    exact_count=np.zeros(len(missing),int);exact_sum=np.zeros(len(missing))
    for col in range(24):
        rows=centers[near[:,col]]
        ids=raw['family'][rows]
        eligible=(counts<8)&(ids!=raw['family'][missing])&~np.any(used==ids[:,None],axis=1)
        take=np.flatnonzero(eligible)
        if not len(take):continue
        distance=dist[take,col]
        coincident=distance==0
        exact_count[take[coincident]]+=1
        exact_sum[take[coincident]]+=raw['total'][rows[take[coincident]]]
        weight=np.divide(1.,distance**2,out=np.zeros_like(distance),where=~coincident)
        numer[take]+=weight*raw['total'][rows[take]];weights[take]+=weight
        used[take,counts[take]]=ids[take];counts[take]+=1;outer[take]=distance
    assert (counts==8).all()
    host[missing]=np.divide(numer,weights,out=np.zeros_like(weights),where=weights>0)
    exactly=exact_count>0
    host[missing[exactly]]=exact_sum[exactly]/exact_count[exactly]
    residual=raw['total']-host
    meta.update(proxy_colocated_other_family=int(sum(exactly)),proxy_outer_distance_quantiles=np.quantile(outer,[0,.5,.95,1]).tolist(),
                proxy_residual_rms=float(np.sqrt(np.average(residual[missing]**2,weights=raw['weight'][missing]))))
    return dict(sky=raw['sky'],sight=raw['sky']/raw['radius'][:,None],radius=raw['radius'],weight=raw['weight'],
                ids=raw['ids'],family=raw['family'],kind=kind,host=host,total=raw['total'],residual=residual,
                half=np.random.default_rng(240511+10*cone+int(cap=='N')).integers(0,2,len(kind))),meta


def gauss(values,weights,order):
    measure=weights/weights.sum()
    previous=np.zeros(len(values));now=np.ones(len(values));off=0.
    diag=[];sub=[]
    for level in range(order):
        moment=np.sum(measure*values*now**2)
        diag.append(moment)
        step=(values-moment)*now-off*previous
        off=np.sqrt(np.sum(measure*step**2))
        if level<order-1:
            assert off>0
            sub.append(off);previous,now=now,step/off
    nodes,eigen=np.linalg.eigh(np.diag(diag)+np.diag(sub,1)+np.diag(sub,-1))
    probs=eigen[0]**2
    assert min(probs)>0 and abs(sum(probs)-1)<2e-12
    return dict(nodes=nodes.tolist(),probs=probs.tolist())


def fit(data):
    result={}
    for kind in (1,2):
        keep=data['kind']==kind
        h,delta,wt=(data[key][keep] for key in ('host','residual','weight'))
        center,mean=(np.average(values,weights=wt) for values in (h,delta))
        slope=np.sum(wt*(h-center)*(delta-mean))/np.sum(wt*(h-center)**2)
        out=dict(mean=float(mean),host_mean=float(center),slope=float(slope),count=int(len(h)))
        for mode,values in [('independent',delta),('linear',delta-mean-slope*(h-center))]:
            rule=gauss(values,wt,12)
            nodes,probs=(np.array(rule[key]) for key in ('nodes','probs'))
            error=max(abs(np.average(np.exp(1j*wave*values),weights=wt)-np.dot(np.exp(1j*wave*nodes),probs))
                      for wave in np.linspace(0,.1025,81))
            assert error<2e-7
            out[mode]=dict(**rule,max_characteristic_error=float(error))
        out['pair_rule']=gauss(delta,wt,4)
        result[str(kind)]=out
    return result
