from window_sources import ROOT, digest, guard, write
import json
import zipfile
from urllib.request import urlopen


if __name__=='__main__':
    guard()
    version='0.42.0'
    name=f'ducc0-{version}-cp313-cp313-win_amd64.whl'
    with urlopen(f'https://pypi.org/pypi/ducc0/{version}/json',timeout=25) as handle:release=json.load(handle)
    item=next(item for item in release['urls'] if item['filename']==name)
    local=ROOT/'dependency'
    local.mkdir(exist_ok=True)
    wheel=local/name
    with urlopen(item['url'],timeout=45) as handle,wheel.open('xb') as file:file.write(handle.read(3_000_000))
    assert wheel.stat().st_size==item['size'] and digest(wheel)==item['digests']['sha256']
    with zipfile.ZipFile(wheel) as zipped:
        for member in zipped.namelist():
            assert not member.startswith(('/','\\')) and '..' not in member.split('/')
        zipped.extractall(local)
    write('dependency.json',dict(name=name,url=item['url'],sha256=digest(wheel),version=version))
