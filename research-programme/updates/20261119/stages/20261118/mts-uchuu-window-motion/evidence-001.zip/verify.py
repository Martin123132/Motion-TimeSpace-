from run import ROOT,PREV,np,guard,read,write,digest,catalogue,estimator,meanband,locks
from fourier import NHAT,K,BANDS,CACHE,sums
from close_pairs import response
from math import factorial
import csv


def toy():
    rng=np.random.default_rng(35091)
    points=rng.normal(size=(17,3));sights=points/np.linalg.norm(points,axis=1)[:,None]
    radii=rng.uniform(600,1300,len(points));weights=rng.uniform(.1,1,len(points))
    ranges=(np.arange(0,5),np.arange(5,12),np.arange(12,17))
    amps=[sums(sights[idx],radii[idx],weights[idx])[0] for idx in ranges]
    alphas=np.array([weights[idx].sum()/weights[ranges[-1]].sum() for idx in ranges[:2]])
    predicted=estimator(np.stack(amps[:2]),amps[2],alphas,1.)[0]
    worst=0.
    for cell in (0,1731,7000,25000,50000):
        mu=sights@NHAT[cell]
        phase=K[cell]*radii*mu
        leg=1.5*mu**2-.5
        first=np.r_[ranges[0],ranges[2]];second=np.r_[ranges[1],ranges[2]]
        weighta=weights[first]*np.r_[np.ones(5),np.full(5,-alphas[0])]
        weightb=weights[second]*np.r_[np.ones(7),np.full(5,-alphas[1])]
        cosine=np.cos(phase[first,None]-phase[second][None,:])*weighta[:,None]*weightb[None,:]
        exact=np.array([4*cosine.sum(),10*np.sum(cosine*(leg[first,None]+leg[second][None,:]))])
        worst=max(worst,max(abs(exact-predicted[:,cell])))
    assert worst<2e-5
    angular_error=0.
    for aa,bb in zip(ranges[0],ranges[1]):
        disp=(points[aa]-points[bb])*3.
        coef=response(disp[None,:],sights[aa:aa+1],sights[bb:bb+1])[0]
        argument=(NHAT@disp)*K
        quad_poly=-argument**2/2+argument**4/24
        leg=.75*((NHAT@sights[aa])**2+(NHAT@sights[bb])**2)-.5
        sampled=meanband(np.stack([quad_poly,5*leg*quad_poly]),True)
        expect=coef[[0,2],None]*meanband(K**2,True)+coef[[1,3],None]*meanband(K**4,True)
        angular_error=max(angular_error,float(np.max(abs(sampled-expect))))
    assert angular_error<2e-12
    return dict(direct_signed_pair_error=worst,discrete_lattice_angular_identity=angular_error)


def quadrature_bounds():
    fixed=read(ROOT/'forecast-lock.json')
    result={}
    for cap in ('S','N'):
        data,_=catalogue(cap,0)
        for kind in (1,2):
            mask=data['kind']==kind
            weights=data['weight'][mask];delta=data['residual'][mask];h=data['host'][mask]
            spec=fixed['caps'][cap]['model'][str(kind)]
            for mode in ('independent','linear'):
                vals=.1025*(delta if mode=='independent' else delta-spec['mean']-spec['slope']*(h-spec['host_mean']))
                nodes=.1025*np.array(spec[mode]['nodes'])
                probs=np.array(spec[mode]['probs'])
                mismatch=sum(abs(np.average(vals**deg,weights=weights)-probs@(nodes**deg))/factorial(deg) for deg in range(24))
                tail=(np.average(vals**24,weights=weights)+probs@(nodes**24))/factorial(24)
                result[f'{cap}-{kind}-{mode}']=dict(polynomial_roundoff=float(mismatch),taylor_bound=float(tail),sum=float(mismatch+tail))
                assert mismatch+tail<2e-5
    return result


def main():
    guard()
    fixed=read(ROOT/'forecast-lock.json');assert fixed['locks']==locks()
    checks=toy();checks['continuous_characteristic_bounds']=quadrature_bounds()
    loc=read(ROOT/'residual-locations.json')
    curr=read(ROOT/'current-vs-width.json')
    ledger=[]
    for cap in ('S','N'):
        source=CACHE/f'COMB_{cap}_Uchuu.ran.h5'
        assert digest(source)==read(ROOT/(source.name+'.json'))['sha256']
        for cone in (0,1):
            key=cap+str(cone)
            data=read(ROOT/(key+'-result.json'))
            assert data['direct_check_max']<2e-5 and data['random_direct']<2e-5
            assert np.all(np.array(data['cross']['real'])==0)
            truth=np.array(data['cross']['obs'])
            if cone==1:
                diag=loc[cap]
                assert np.allclose(diag['total'],np.array(diag['data_random'])+diag['data_data'],atol=1e-10,rtol=0)
                assert np.allclose(diag['total'],np.array(diag['data_random'])+diag['close_data_data']+diag['outside_10_up_to_taylor_remainder'],atol=1e-10,rtol=0)
                assert np.max(abs(np.subtract(curr[cap]['errors']['base'],diag['total'])))<2e-5
            for branch,pred in data['cross'].items():
                for idx,wave in enumerate(BANDS):
                    for ell in (0,2):
                        ledger.append([cap,cone,branch,ell,wave,truth[ell//2,idx],pred[ell//2][idx],truth[ell//2,idx]-pred[ell//2][idx]])
    with (ROOT/'paired-multipoles.csv').open('x',encoding='utf8',newline='') as handle:
        writer=csv.writer(handle);writer.writerow(['cap','cone','branch','ell','k_center_h_Mpc','observed_shift','predicted_shift','error']);writer.writerows(ledger)
    assert len(ledger)==224 and len(list(csv.reader((ROOT/'paired-multipoles.csv').read_text().splitlines())))==225
    checks.update(rows=len(ledger),retained_seal=digest(PREV/'closeout.json'),third_cone_used=False)
    write('verification.json',checks)


if __name__=='__main__':main()
