from window_sources import ROOT,guard,digest,read,write
import csv
from pathlib import Path


if __name__=='__main__':
    guard()
    assert read(ROOT/'verification.json')['rows']==224
    forecast=read(ROOT/'forecast-lock.json')
    for key,value in forecast['locks'].items():assert digest(ROOT/key)==value
    seed=read(ROOT/'boost-safe-seed.json')
    for key,value in seed['sources'].items():assert digest(ROOT/key)==value
    records=list(csv.DictReader((ROOT/'paired-multipoles.csv').read_text().splitlines()))
    assert len(records)==224
    for cap in ('S','N'):
        assert seed['caps'][cap]['checks']['boost_error_kms']<2e-7
        for cone in (0,1):
            name=cap+str(cone)
            assert read(ROOT/(name+'-pair-forecast.json'))['training']==digest(ROOT/'forecast-lock.json')
        assert (ROOT/f'random-{cap}.npz').exists() and (ROOT/(cap+'1-result.json')).exists()
    assert not any(path.suffix=='.partial' or path.name=='__pycache__' for path in ROOT.rglob('*'))
    files={path.relative_to(ROOT).as_posix():digest(path) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    assert 'RESULTS.md' in files and 'residual-locations.json' in files and 'current-vs-width.json' in files
    write('closeout.json',dict(files=files,scope='local mock tracer survey window, no physical parent refit; upper-z multipoles unscored',bytes=sum((ROOT/key).stat().st_size for key in files)))
