from run import ROOT,np,catalogue,meanband,fields_at,read,write,guard,locks


def case(cap):
    guard()
    result=read(ROOT/(cap+'1-result.json'))
    frozen=read(ROOT/'forecast-lock.json')
    assert locks()==frozen['locks']
    cat,_=catalogue(cap,1)
    model=frozen['caps'][cap]['model']
    with np.load(ROOT/f'random-{cap}.npz') as ran:random=ran['amplitude']
    alphas=result['alphas']
    dr=np.zeros_like(random,dtype=float)
    for half in (0,1):
        idx=np.flatnonzero((cat['kind']!=0)&(cat['half']==half))
        actual,_=fields_at(cat,idx,model,'obs')
        estimated,_=fields_at(cat,idx,model,'independent')
        delta=actual-estimated
        dr-=2*alphas[1-half]*np.array([1,5])[:,None]*np.real(delta[0]*random.conj()+random[0]*delta.conj())/result['normalization']
    with np.load(ROOT/(cap+'1-independent-error.npz')) as archive:residual=archive['cross']
    checked=meanband(residual,True)
    assert np.max(abs(checked-np.subtract(result['cross']['obs'],result['cross']['independent'])))<2e-10
    window=meanband(dr,True)
    close=np.array(result['own_close_polynomial'])
    tail=checked-window-close
    return dict(total=checked.tolist(),data_random=window.tolist(),data_data=meanband(residual-dr,True).tolist(),
                close_data_data=close.tolist(),outside_10_up_to_taylor_remainder=tail.tolist(),
                close_absolute_remainder_bound=result['own_close_remainder_bound'])


if __name__=='__main__':write('residual-locations.json',{cap:case(cap) for cap in ('S','N')})
