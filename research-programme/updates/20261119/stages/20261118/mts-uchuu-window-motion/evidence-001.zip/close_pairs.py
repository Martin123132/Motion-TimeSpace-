from population import np,cKDTree
from fourier import BANDS
from scipy.special import spherical_jn


def response(displacement,left,right):
    square=np.einsum('ij,ij->i',displacement,displacement)
    axial=(np.einsum('ij,ij->i',displacement,left)**2+np.einsum('ij,ij->i',displacement,right)**2)/2
    anis=3*axial-square
    return np.column_stack([-square/6,square**2/120,-anis/6,anis*square/84,square**3/720])


def exact_center(displacement,left,right):
    norm=np.linalg.norm(displacement,axis=1)
    unit=displacement/np.where(norm>0,norm,1)[:,None]
    leg=.75*(np.einsum('ij,ij->i',unit,left)**2+np.einsum('ij,ij->i',unit,right)**2)-.5
    kr=norm[:,None]*BANDS
    return np.column_stack([spherical_jn(0,kr),-5*leg[:,None]*spherical_jn(2,kr)])


def measure(cat,model,cross):
    pairs=cKDTree(cat['sky']).query_pairs(10,output_type='ndarray')
    if cross:pairs=pairs[cat['half'][pairs[:,0]]!=cat['half'][pairs[:,1]]]
    stats={}
    for start in range(0,len(pairs),40000):
        left,right=pairs[start:start+40000].T
        distance=np.linalg.norm(cat['sky'][left]-cat['sky'][right],axis=1)
        shell=np.searchsorted([2.,5.,10.],distance)
        types=np.minimum(cat['kind'][left],cat['kind'][right])*3+np.maximum(cat['kind'][left],cat['kind'][right])
        cell=shell*18+types*2+(cat['family'][left]==cat['family'][right])
        for label in np.unique(cell):
            take=cell==label
            aa,bb=left[take],right[take]
            lo=np.minimum(cat['kind'][aa],cat['kind'][bb])
            swap=lo!=cat['kind'][aa]
            aa,bb=np.where(swap,bb,aa),np.where(swap,aa,bb)
            ni,nj=cat['sight'][aa],cat['sight'][bb]
            base=(cat['sky'][aa]-cat['sky'][bb])+cat['host'][aa,None]*ni-cat['host'][bb,None]*nj
            truth=base+cat['residual'][aa,None]*ni-cat['residual'][bb,None]*nj
            wt=cat['weight'][aa]*cat['weight'][bb]
            actual=response(truth,ni,nj);control=np.zeros_like(actual)
            center=exact_center(truth,ni,nj);ind=np.zeros_like(center)
            rules=[]
            for kind in (cat['kind'][aa[0]],cat['kind'][bb[0]]):
                obj=model[str(kind)]['pair_rule'] if kind else dict(nodes=[0.],probs=[1.])
                rules.append(list(zip(obj['nodes'],obj['probs'])))
            for da,wa in rules[0]:
                for db,wb in rules[1]:
                    offset=base+da*ni-db*nj
                    control+=wa*wb*response(offset,ni,nj)
                    ind+=wa*wb*exact_center(offset,ni,nj)
            diff=actual-control
            diff[:,-1]=actual[:,-1]+control[:,-1]
            values=np.r_[len(wt),wt.sum(),wt@diff,wt@(center-ind),int(np.sum(cat['ids'][aa]==cat['ids'][bb]))]
            key=str(int(label))
            stats[key]=stats.get(key,0)+values
    return {key:values.tolist() for key,values in stats.items()}


def predict(train,target,norm,k2,k4):
    m2=np.zeros(2);m4=np.zeros(2);absent=0.;supported=0.
    for key,row in target.items():
        if key not in train:
            absent+=row[1];continue
        coef=np.array(train[key][2:6])/train[key][1]
        m2+=row[1]*coef[[0,2]]
        m4+=row[1]*coef[[1,3]]
        supported+=row[1]
    return 4*(m2[:,None]*k2+m4[:,None]*k4)/norm,absent/(supported+absent)
