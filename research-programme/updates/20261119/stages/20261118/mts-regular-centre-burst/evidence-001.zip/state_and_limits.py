from exposure import run_budget
from exact_dust import exact
from resolved_flux import main as flux

if __name__=="__main__":
    exact();flux()
    for dx in (.025,.0125):
        for amplitude in (1.,1/160):
            run_budget(dx,.8,amplitude,homogeneous=True)
