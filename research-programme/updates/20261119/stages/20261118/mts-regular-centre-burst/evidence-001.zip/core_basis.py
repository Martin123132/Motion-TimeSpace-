from centre_base import EPS, POL, SIN, ANG, coeff, np

class CoreBasis:
    def __init__(self,radius,count=12,degree=3,skip=1):
        self.count=count
        self.rad=radius[:count];s=self.rad[:,0]/self.rad[-1,0]
        self.mat={};self.at0={}
        weight=np.clip((1-s)/.32,0,1);weight=weight**3*(10-15*weight+6*weight**2)
        for power in range(6):
            basis=s[:,None]**(power+2*np.arange(degree+1)[None,:])
            proj=np.linalg.pinv(basis[skip:]);pad=np.pad(proj,((0,0),(skip,0)))
            self.mat[power]=(1-weight[:,None])*np.eye(count)+weight[:,None]*(basis@pad)
            self.at0[power]=pad[0]/self.rad[-1,0]**power
    def project(self,state):
        val=state[:,:self.count];rad=self.rad
        apply=lambda arr,p:self.mat[p]@arr
        def combine(slot,background,perturbation,basis=POL):
            val[slot]=background+1j*perturbation*basis
        for start in (0,4):
            hx,cross,ht,hf=val[start:start+4]
            angular=apply(ht.real[:,:1],0)
            base=angular+apply(hx.real[:,:1]-ht.real[:,:1],2)
            hh=coeff(hx.imag);jj=cross.imag[:,:1]/(rad*ANG[0])
            kk=coeff((ht.imag+hf.imag)/2);gg=(ht.imag[:,:1]-hf.imag[:,:1])/(3*SIN[0]**2)
            alpha=apply(2*gg,0);beta=apply(2*jj-2*gg,2);gamma=apply(kk+gg,2)
            delta=apply(hh-4*jj-kk+gg,4)
            trace=gamma-alpha/2;tf=.75*alpha*SIN**2
            combine(start,base,alpha+2*beta+gamma+delta)
            combine(start+1,0.,rad*(alpha+beta)/2,ANG)
            val[start+2]=angular+1j*(trace*POL+tf)
            val[start+3]=angular+1j*(trace*POL-tf)
        for slot,bpow,apow in ((8,0,2),(9,2,4),(13,2,4),(16,0,2),(17,0,2)):
            combine(slot,apply(val[slot].real[:,:1],bpow),apply(coeff(val[slot].imag),apow))
        et=val[11].imag[:,:1]/ANG[0];er=coeff(val[10].imag)
        pc=apply(et,2)
        combine(10,apply(val[10].real[:,:1],3),rad*(2*pc+apply(er/rad-2*et,4)))
        combine(11,0.,pc,ANG)
        combine(12,0.,apply(val[12].imag[:,:1]/ANG[0],3),ANG)
        pt=val[15].imag[:,:1]/ANG[0];px=coeff(val[14].imag)
        tc=apply(pt,2)
        combine(14,apply(val[14].real[:,:1],1),2*tc/rad+apply(px-2*pt/rad,3))
        combine(15,0.,tc,ANG)
        for slot,powr in ((18,3),(19,2),(20,2)):
            val[slot]=apply(val[slot].real[:,:1],powr)
        if len(state)>=23:
            vt=val[22].imag[:,:1]/ANG[0];vx=coeff(val[21].imag)
            tc=apply(vt,2)
            combine(21,apply(val[21].real[:,:1],1),2*tc/rad+apply(vx-2*vt/rad,3))
            combine(22,0.,tc,ANG)
            if len(state)==24:val[23]=apply(val[23].real[:,:1],0)
        return state

PARITY=np.array([1,-1,1,1,1,-1,1,1,1,1,-1,1,-1,1,-1,1,1,1,-1,1,1,1])[:,None,None]
VPARITY=np.concatenate((PARITY[:21],np.array([-1,1])[:,None,None]))
MPARITY=np.concatenate((VPARITY,np.ones((1,1,1),int)))
