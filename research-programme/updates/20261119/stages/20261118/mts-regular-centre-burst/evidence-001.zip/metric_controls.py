from regular import *
from connection import flat_vector
import csv

def core_constraints(model,y):
    rad=model.rad;rr=rad**2
    ax,bz,ct,cf,kx,kxt,ktt,kff,scalar,dp,exd,etd,mag,dens,px,pt=y[:16]
    aa=1+ax;cc=rr*(1+ct);kt=rr*ktt;det=aa*cc-bz**2
    ia=cc/det;ib=-bz/det;ic=aa/det
    jac=rad*np.sqrt((1+cf)*det);dr=model.dr
    ku=ia*kx+ib*kxt;kv=ib*kx+ic*kxt;mu=ia*kxt+ib*kt;mv=ib*kxt+ic*kt;ko=kff/(1+cf)
    tr=ku+mv+ko;kxx=ku*ia+mu*ib;kxtc=ku*ib+mu*ic;kttc=kv*ib+mv*ic
    ext=model.extend(y)
    g=model.ghost
    def radial(arr,parity):
        return dr(np.concatenate((parity*arr[:g][::-1],arr)))[g:]
    cr=2*rad*(1+ct)+rr*radial(ct,1)
    linkr,linkt=flat_vector(model,*ext[:4]);linkr=linkr[g:];linkt=linkt[g:]
    poy=-y[20].real[:,:1]/(np.sqrt(aa.real[:,:1])*cc.real[:,:1]);wave=y[19].real[:,:1]
    radterms=[radial(jac*ku,1)/jac,divang(jac*kv)/jac,-radial(tr,1),
              -.5*(radial(ax,1)*kxx+2*radial(bz,-1)*kxtc+cr*kttc),
              -ko*(1/rad+radial(cf,1)/(2*(1+cf))),2*dp*radial(scalar,1)/jac,-2*dens*px/jac,
              -2*(mag*etd/jac+DUAL*poy*radial(wave,1)*SIN**2)]
    tangterms=[radial(jac*mu,-1)/jac,(angle(jac*mv)+COS/SIN*jac*mv)/jac,-angle(tr),
               -.5*(angle(ax)*kxx+2*mixed(bz)*kxtc+rr*angle(ct)*kttc),-ko*(COS/SIN+angle(cf)/(2*(1+cf))),
               2*dp*angle(scalar)/jac,-2*dens*pt/jac,-2*(-mag*exd/jac+DUAL*poy*2*wave*SIN*COS)]
    output=[]
    for mask in (rad[:,0]<=.5,rad[:,0]<=6.5):
        def maxcoef(value):return float(np.max(abs(value[mask].imag/EPS)))
        for terms in (radterms,tangterms):
            output.extend((maxcoef(sum(terms)),sum(maxcoef(v) for v in terms)))
        for data,ref in ((y[21],linkr),(y[22],linkt)):
            output.extend((maxcoef(data-ref),maxcoef(ref)))
    return output

def manufactured(dx,cap):
    model=Centre(dx,0.,0.,cap=cap,damping=0.,reduced=True)
    rad=model.rad
    y=np.zeros_like(model.y0)
    base=rad**2-.04*rad**4+.001*rad**6
    dr=2*rad-.16*rad**3+.006*rad**5
    drr=2-.48*rad**2+.03*rad**4
    y[0]=DUAL*2*drr*POL;y[1]=DUAL*2*(dr-base/rad)*ANG
    y[2]=DUAL*2*(dr/rad*POL+base/rad**2*ANG2)
    y[3]=DUAL*2*(dr/rad*POL+base/rad**2*COS/SIN*ANG)
    y[4:8]=.37*y[:4]
    canon=model.cap.project(y.copy());rr=model.rad[:,0]
    test=model.rhs(canon);ham=model.rhs(canon,True)[2]
    mask=rr<=5
    high=lambda val:float(np.max(abs(val.imag/EPS)))
    return [dx,cap,high((y-canon)[:,mask]),high((test[:4]+2*canon[4:8])[:,mask]),
            high(test[4:8,mask]),high(test[21:,mask]),high(ham[mask])]

if __name__=="__main__":
    rows=[manufactured(dx,cap) for dx in (.05,.025,.0125) for cap in (12,16)]
    with (LOCAL/"stationary-flat-gauge.csv").open("x",newline="") as out:
        writer=csv.writer(out);writer.writerow("dx cap polynomial_reproduction metric_rate curvature_rate vector_rate Hamiltonian".split());writer.writerows(rows)
    print(rows,flush=True)
