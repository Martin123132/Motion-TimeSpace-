from exposure import run_budget

if __name__=="__main__":
    for profile in (0,1):
        run_budget(.025,1.,0.,profile=profile,smooth=True)
        run_budget(.0125,1.,0.,profile=profile,smooth=True)
    run_budget(.025,.8,1.,smooth=True)
    run_budget(.0125,.8,1.,smooth=True)
    run_budget(.0125,.8,0.,smooth=True)
    run_budget(.0125,.8,1.,True,smooth=True)
    run_budget(.0125,1.,0.,cap=16,outer=17,step=.15,diss=1.,smooth=True)
