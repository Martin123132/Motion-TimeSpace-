from score import bud, err, np, raw, table
from scipy.interpolate import make_interp_spline


def responses():
    reference=bud(.0125,.8,0.)
    baseline=reference["rows"]
    clock=baseline[:,0]; weak_amp=1/160
    output=[]
    for shell in (False,True):
        stage=bud(.0125,.8,1.,shell)
        strong=stage["rows"]; assert np.array_equal(clock,strong[:,0])
        acceleration=strong[:,3:9]-baseline[:,3:9]
        local=make_interp_spline(clock,acceleration,k=5,axis=0).antiderivative(2)
        differential=local(clock)-local(0)-clock[:,None]*local.derivative()(0)
        original=raw(.0125,.8,1.,shell)-raw(.0125,.8,0.)
        coarse=raw(.025,.8,1.,shell)-raw(.025,.8,0.)
        weak=raw(.0125,.8,weak_amp,shell)-raw(.0125,.8,0.)
        weak_coarse=raw(.025,.8,weak_amp,shell)-raw(.025,.8,0.)
        ray=strong[:,1]-baseline[:,1]
        geometry=strong[:,2]-baseline[:,2]
        for time in (3.,4.,5.,6.,6.4):
            tick=round(time/.02);half=tick//2
            shear, twist, scalar, electric, dipole, dust = differential[tick]
            output.append(dict(preparation="shell" if shell else "label",tau=time,
                    volume_change=ray[tick],fraction_of_ordinary=ray[tick]/baseline[tick,1],explicit_scalar=scalar,
                    induced_shear=shear,induced_twist=twist,induced_polar_E=electric,induced_dipole=dipole,induced_dust=dust,
                    all_other_terms=sum((shear,twist,electric,dipole,dust)),weak_observed=weak[half,1],weak_leading_estimate=weak_amp**2*original[half,1],
                    difference_budget_error=err(differential.sum(axis=1),ray),difference_determinant_error=err(geometry,ray),
                    difference_radial_error=err(coarse[:,1],original[:,1]),difference_seed_error=err(original[:,1],ray[::2]),
                    weak_difference_radial_error=err(weak_coarse[:,1],weak[:,1]),weak_difference_metric_error=err(weak[:,2],weak[:,1]),
                    finite_amplitude_scaling_difference=err(weak_amp**2*original[:,1],weak[:,1])))
    return output


if __name__=="__main__":
    table("scalar-versus-ordinary.csv",responses())
