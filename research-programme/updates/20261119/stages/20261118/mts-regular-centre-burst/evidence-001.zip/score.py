from regular import *
from retained_runs import cases
from pathlib import Path
import json
import csv
import xml.etree.ElementTree as ET

TOL=2e-5
def pack(name):
    with np.load(LOCAL/name,allow_pickle=False) as src:return {k:src[k] for k in src.files}
def raw(dx,eta,amp,shell=False,profile=0):
    return pack(f"burst-d{dx:g}-q{eta:g}-h{amp:g}-s{int(shell)}-p{profile}-c12-k3-r15-t0.3-end6.4-ko0.5-connection.npz")["rows"]
def bud(dx,eta,amp,shell=False,profile=0,hom=False,variant=False):
    setup="c16-r17-t0.15-ko1" if variant else "c12-r15-t0.3-ko0.5"
    return pack(f"budget-d{dx:g}-q{eta:g}-h{amp:g}-s{int(shell)}-p{profile}-{setup}-seed{int(not hom)}{('-hom' if hom else '')}.npz")
def peak(x):return float(np.max(abs(x)))
def err(x,y):return peak(x-y)/peak(y) if peak(y)>0 else (0. if not np.any(x) else float("inf"))
def records(path):
    with path.open() as stream:return list(csv.DictReader(stream))
def table(name,rows):
    with (LOCAL/name).open("x",newline="",encoding="utf8") as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def factor():
    row=records(source(PARENT,"magnetic-normalization.csv"))[-1]
    return float(row["spin_ratio_from_bank"]),float(row["late_volume_ratio"])

def main():
    stats=[];curves=[];budget_rows=[];regularity=[]
    cal,old=factor()
    for eta,amp,shell,prof in cases:
        data=raw(.0125,eta,amp,shell,prof);other=raw(.025,eta,amp,shell,prof)
        tag=f"eta{eta:g}-h{amp:g}";cut=4 if eta==1 else 3
        if eta==1:
            path=source(PARENT,f"front-0.00625-eta1-h0-label-wide-direct{('-spin1' if prof else '')}-to4.npz")
        else:
            dx=.0125 if eta==0 else .00625
            path=source(PARENT,f"front-{dx:g}-{tag}-{'shell' if shell else 'label'}-direct.npz")
        with np.load(path) as archive:original=archive["rows"][::2]
        frame=data[:len(original)]
        scores=dict(preceding_window=err(frame[:,1],original[:,1]),radial=err(other[:,1],data[:,1]),
                    independent_metric=err(data[:,2],data[:,1]),emitted_field=err(data[:,5],data[:,6]),
                    central_field=err(data[:,9],data[:,10]),central_density=err(data[:,11],data[:,12]),
                    central_scalar_squared=err(data[:,13],data[:,14]),falling_radius=err(data[:,7]-6,data[:,8]-6) if eta else None)
        stats.append(dict(eta=eta,amp=amp,shell=shell,profile=prof,signal=data[-1,1],**scores,
                          passed=all(v<TOL for v in scores.values() if v is not None)))
    table("absolute-comparisons.csv",stats)
    for dx in (.025,.0125):
        a=raw(dx,1,0);b=raw(dx,1,0,False,1)
        for target in (3.,4.,5.,6.,6.4):
            tick=round(target/.04)
            vol=cal**2*b[tick,1]/a[tick,1];geom=cal**2*b[tick,2]/a[tick,2]
            curves.append(dict(dx=dx,tau=target,frozen_spin_ratio=cal,B_ratio=cal*b[tick,5]/a[tick,5],
                               B_ratio_bank=cal*b[tick,6]/a[tick,6],volume_ratio=vol,metric_ratio=geom,
                               old_result_at_4=old if target==4 else None,first=a[tick,1],second=b[tick,1]))
    table("frozen-magnetic-burst.csv",curves)
    resolved=records(LOCAL/"resolved-flux-bound.csv")
    for case in ((1,0,False,0),(1,0,False,1),(.8,0,False,0),(.8,1,False,0),(.8,1,True,0)):
        eta,amp,shell,prof=case
        saved=bud(.0125,*case);data=saved["rows"];integ=saved["integrated"];coarse=saved["coarse"];quality=saved["quality"]
        quality_rows=[]
        for k in (1,9):
            fractions=[peak(quality[:,j])/peak(quality[:,j+1]) for j in range(k,k+8,2)]
            quality_rows+=fractions
        regularity.append(dict(eta=eta,amp=amp,shell=shell,profile=prof,core_Mr=quality_rows[0],core_Mtheta=quality_rows[1],
                               core_Vr=quality_rows[2],core_Vtheta=quality_rows[3],domain_Mr=quality_rows[4],domain_Mtheta=quality_rows[5],
                               domain_Vr=quality_rows[6],domain_Vtheta=quality_rows[7],max_core_H0=peak(data[:,18]),max_core_H2=peak(data[:,19]),
                               original_seed_H0=peak(raw(.0125,*case)[:,16]),original_seed_H2=peak(raw(.0125,*case)[:,17]),
                               seed_volume_error=err(data[::2,1],raw(.0125,*case)[:,1]),seed_changes=str(saved["changes"].item())))
        for target in (3.,4.,5.,6.,6.4):
            tick=round(target/.02);s=integ[tick];vol=data[tick,1]
            ref=next(r for r in resolved if [float(r[k]) for k in ("eta","amp","profile","tau")]==[eta,amp,prof,target])
            budget_rows.append(dict(eta=eta,amp=amp,shell=shell,profile=prof,tau=target,volume=vol,
                geometric_shear=s[0],twist=s[1],scalar=s[2],polar_E=s[3],em_dipole=s[4],dust=s[5],
                flux_floor=float(ref["flux_floor"]),slack=float(ref["positive_slack"]),direct_fraction=s[4]/vol,
                flux_fraction_of_direct=float(ref["floor_fraction"]),sum_error=(sum(s[:6])-vol)/vol,
                full_interval_budget_error=err(np.sum(integ[:,:6],axis=1),data[:,1]),
                independent_dipole=err(integ[:,4],integ[:,6]),positive_quadrature_crosscheck=s[6]/float(ref["direct"])-1,
                smooth_quadrature=err(coarse[:,4],integ[::2,4])))
    table("focusing-ledger.csv",budget_rows);table("regularity-audit.csv",regularity)
    pairs=[]
    for amp in (1.,1/160):
        a=raw(.0125,.8,amp,False);b=raw(.0125,.8,amp,True);base=raw(.0125,.8,0.)
        hom=bud(.0125,.8,amp,hom=True);h=hom["rows"][::2];hcoarse=bud(.025,.8,amp,hom=True)["rows"][::2]
        for target in (3.,4.,5.,6.,6.4):
            tick=round(target/.04)
            pairs.append(dict(amp=amp,tau=target,label_minus_ordinary=a[tick,1]-base[tick,1],shell_minus_ordinary=b[tick,1]-base[tick,1],
                shell_minus_label=b[tick,1]-a[tick,1],homogeneous=h[tick,1],signal_fraction=h[tick,1]/base[tick,1],
                same_wave=bool(np.array_equal(a[:,5],b[:,5])),direct_vs_subtracted=err(b[:,1]-a[:,1],h[:,1]),
                refinement=err(hcoarse[:,1],h[:,1]),metric=err(h[:,2],h[:,1])))
    table("state-difference.csv",pairs)
    variant=bud(.0125,1,0,variant=True)["rows"];native=bud(.0125,1,0)["rows"]
    print("combined independent variation",err(variant[:,1],native[:,1]),"emission",err(variant[:,12],native[:,12]))
    table("numerical-variation.csv",[dict(variation="cap + outer boundary + time step + high-frequency damping",
                  volumes=err(variant[:,1],native[:,1]),wave=err(variant[:,12],native[:,12]),centre_B=err(variant[:,14],native[:,14]))])
if __name__=="__main__":main()
