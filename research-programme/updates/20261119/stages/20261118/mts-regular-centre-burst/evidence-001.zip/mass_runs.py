from exposure import run_budget

if __name__=="__main__":
    for dx in (.025,.0125):
        for eta,amp in ((0.,0.),(1.,0.),(.8,1.)):
            run_budget(dx,eta,amp,smooth=True,mass_form=True)
