from regular import *
from scipy.optimize import brentq
import csv

class Measured:
    def __init__(self,eta,amp,profile):
        tag=f"1920-eta{eta:g}-h{amp:g}"
        with np.load(source(CLOUD,f"path-{tag}.npz")) as saved:
            self.path=CubicSpline(saved["tau"],saved["state"][1,:,:3],axis=0)
        with np.load(source(CLOUD,f"strip-{tag}.npz")) as saved:
            self.mass=RectBivariateSpline(saved["time"],saved["radius"],saved["values"][:,0,:],kx=5,ky=5,s=0)
        with np.load(source(SRC,f"driven-{tag}-spin{profile}.npz")) as saved:
            self.bank=[RectBivariateSpline(saved["time"],saved["radius"],saved["fields"][:,k,:],kx=5,ky=5,s=0) for k in range(3)]
    def get(self,tau):
        local=self.path(tau);time,radius,p=[local[...,k] for k in range(3)]
        f=1-2*self.mass.ev(time,radius)/radius;boost=np.sqrt(f)*p;lor=np.hypot(1,boost)
        a,pm,dr=[fn.ev(time,radius) for fn in self.bank]
        return (-np.sqrt(f)*(lor*pm+boost*dr)/radius,-np.sqrt(f)*(lor*dr+boost*pm)/radius,2*a/radius**2)
    def integrate(self,divisions,order):
        sample=np.linspace(0,6.4,divisions+1);components=self.get(sample)
        edges=list(np.linspace(0,6.4,513))
        for idx,curve in enumerate(components[:2]):
            for left in np.flatnonzero(np.signbit(curve[1:])!=np.signbit(curve[:-1])):
                lo,hi=sample[left:left+2]
                if max(abs(curve[left:left+2]))<1e-28:continue
                root=brentq(lambda t:float(self.get(t)[idx]),lo,hi,xtol=1e-14)
                edges.append(root)
        edges=np.unique(edges+[3.,4.,5.,6.,6.4])
        mid=(edges[:-1]+edges[1:])/2;half=np.diff(edges)/2
        nodes,weights=np.polynomial.legendre.leggauss(order)
        t=mid[:,None]+half[:,None]*nodes
        w=half[:,None]*weights
        e,b,z=self.get(t.ravel())
        e,b,z=[x.reshape(t.shape) for x in (e,b,z)]
        signed=-2*e*b;absolute=abs(signed)
        outputs=np.stack([e**2+b**2-z**2,absolute-z**2,(abs(e)-abs(b))**2,np.maximum(0,-signed),z**2])
        rows=[]
        for target in (3.,4.,5.,6.,6.4):
            values=np.sum(outputs*(w*np.maximum(target-t,0))[None,:,:],axis=(1,2))
            assert abs(values[0]-values[1]-values[2])<1e-14*max(abs(values))
            rows.append(values)
        return np.array(rows),len(edges)

def main():
    rows=[]
    for eta,amp,profile in ((1.,0.,0),(1.,0.,1),(.8,0.,0),(.8,1.,0),(.8,1/160,0)):
        model=Measured(eta,amp,profile);a,na=model.integrate(2560,6);b,nb=model.integrate(5120,10)
        for tick,target in enumerate((3.,4.,5.,6.,6.4)):
            vals=b[tick];delta=abs(a[tick]-vals)
            rows.append(dict(eta=eta,amp=amp,profile=profile,tau=target,direct=vals[0],flux_floor=vals[1],
                             positive_slack=vals[2],twice_inward_flux=vals[3],polar_magnetic=vals[4],
                             floor_fraction=vals[1]/vals[0],direct_refine=delta[0]/abs(vals[0]),
                             floor_refine=delta[1]/abs(vals[1]),slack_refine=delta[2]/abs(vals[2]),
                             inward_refine_absolute=delta[3],edges=nb,coarse_edges=na))
    with (LOCAL/"resolved-flux-bound.csv").open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print("max fractional slack refinement",max(r["slack_refine"] for r in rows),flush=True)
if __name__=="__main__":main()
