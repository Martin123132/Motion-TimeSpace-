from score import err, factor, np, raw, table
from resolved_flux import Measured
from scipy.interpolate import make_interp_spline


class Difference(Measured):
    def __init__(self, coefficient):
        self.first=Measured(1.,0.,0)
        self.second=Measured(1.,0.,1)
        self.coefficient=coefficient

    def get(self, times):
        first=self.first.get(times)
        second=self.second.get(times)
        return tuple(left-self.coefficient*right for left,right in zip(first,second))


def predictions():
    coefficient,_=factor()
    assert abs(coefficient-1.1666214009559583)<1e-15
    source=Difference(coefficient)
    coarse,_=source.integrate(2560,6)
    fine,_=source.integrate(5120,10)
    first=raw(.0125,1.,0.,False,0)
    second=raw(.0125,1.,0.,False,1)
    clock=first[:,0]
    assert np.array_equal(clock,second[:,0]) and np.array_equal(first[:,7],second[:,7])
    radius=first[:,7]
    potential=first[:,5]-coefficient*second[:,5]
    local_b=2*potential/radius**2
    local_e=-make_interp_spline(clock,potential,k=5).derivative()(clock)/radius
    electric,_,polar=source.get(clock)
    base=source.first.get(clock)[2]
    output=[]
    for index,time in enumerate((3.,4.,5.,6.,6.4)):
        tick=round(time/.04)
        output.append(dict(tau=time,c=coefficient,polar_B=polar[tick],opposite_source_B_over_first=polar[tick]/base[tick],
                           combined_direct=fine[index,0],combined_floor=fine[index,1],positive_slack=fine[index,2],
                           full_ruler="not calculated",polar_history_error=err(local_b,polar),electric_history_error=err(local_e,electric),
                           direct_refinement=abs(1-coarse[index,0]/fine[index,0]),floor_refinement=abs(1-coarse[index,1]/fine[index,1]),
                           slack_refinement=abs(1-coarse[index,2]/fine[index,2])))
    return output


if __name__=="__main__":
    table("magnetic-null-predictions.csv",predictions())
