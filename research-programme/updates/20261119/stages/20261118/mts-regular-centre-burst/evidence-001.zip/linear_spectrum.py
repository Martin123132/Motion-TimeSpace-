from regular import Centre, np, EPS, POL, ANG, SIN, coeff, LOCAL
from core_basis import CoreBasis
from scipy.linalg import eigvals
import csv

def matrix(model,block,count=28):
    degree=4 if block=="quad" else 2
    r=model.rad[:count]
    taper=np.clip((count-np.arange(count)-1)/4,0,1)[:,None]
    taper=taper**3*(10-15*taper+6*taper**2)
    def unpack(data):
        y=np.zeros_like(model.y0);slots=data.reshape(degree,count)[:,:,None]*taper
        if degree==2:
            y[0,:count]=slots[0]
            y[2,:count]=y[3,:count]=slots[1]
        else:
            hh,jj,kk,gg=slots
            y[0,:count]=1j*EPS*hh*POL;y[1,:count]=1j*EPS*r*jj*ANG
            y[2,:count]=1j*EPS*(kk*POL+1.5*gg*SIN**2)
            y[3,:count]=1j*EPS*(kk*POL-1.5*gg*SIN**2)
        return y
    def read(y):
        if degree==2:return np.array([y[4,:count,0].real,y[6,:count,0].real]).ravel()
        return np.array([coeff(y[4,:count].imag)[:,0],y[5,:count,0].imag/(r[:,0]*ANG[0]),
                         coeff((y[6,:count].imag+y[7,:count].imag)/2)[:,0],(y[6,:count,0].imag-y[7,:count,0].imag)/(3*SIN[0]**2)]).ravel()/EPS
    shape=degree*count
    lam=[]
    for slot in np.eye(shape):
        if degree==4:
            val=read(model.rhs(unpack(slot)))
        else:
            val=(read(model.rhs(unpack(1e-6*slot)))-read(model.rhs(unpack(-1e-6*slot))))/2e-6
        lam.append(-2*val*model.dx**2)
    return np.array(lam).T

if __name__=="__main__":
    model=Centre(.05,0,0)
    rows=[]
    for cap,degree,skip in ((12,3,1),(12,3,0),(12,2,0),(16,3,0),(8,2,0),(12,2,1),(16,2,0),(10,1,0)):
        model.cap=CoreBasis(model.rad,cap,degree,skip)
        for block in ("sphere","quad"):
            spectrum=eigvals(matrix(model,block))
            grow=np.sqrt(spectrum+0j).real.max()
            rows.append([cap,degree,skip,block,grow]);print(rows[-1],flush=True)
    with (LOCAL/"flat-discrete-spectrum.csv").open("x",newline="") as out:
        writer=csv.writer(out);writer.writerow("cap degree skip sector max_dimensionless_growth".split());writer.writerows(rows)
