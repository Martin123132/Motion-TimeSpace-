from score import *
from initial import CH
import ast
import sys

def verify():
    ensure();checks={};accuracy={};inputs={}
    def require(key,value):
        assert key not in checks and bool(value),key
        checks[key]=True
    def score(key,value):
        assert key not in accuracy
        value=float(value);assert np.isfinite(value) and value>=0,key
        accuracy[key]={"relative_error":value,"pass":value<TOL}
    def link(folder,member):inputs[f"{folder.name}/{member}"]=sha(source(folder,member))
    for file in LOCAL.glob("*.py"):ast.parse(file.read_text(encoding="utf8"))
    for file in sorted(LOCAL.glob("*.npz")):
        data=pack(file.name);rows=data["rows"]
        require(file.name+" finite time series",np.isfinite(rows).all() and rows[0,0]==0 and np.all(np.diff(rows[:,0])>0))
        if file.name.startswith(("budget-","burst-","tt-")):require(file.name+" full saved window",rows[-1,0]==6.4)
        if "integrated" in data:require(file.name+" finite exposures",np.isfinite(data["integrated"]).all() and np.isfinite(data["quality"]).all())
    for name in ("front_equations.py","CENTRE-MATCH.md","magnetic-normalization.csv","preparation_difference.py","RESULTS.md"):link(PARENT,name)
    for name in ("initial.py","on_shell.py"):link(PRE,name)
    link(SRC,"current_source.py");link(SRC,"radiate.py");link(CH,"charged.py")
    for eta,amp,shell,profile in cases:
        tag=f"1920-eta{eta:g}-h{amp:g}"
        link(SRC,"core-"+tag+".npz");link(SRC,f"driven-{tag}-spin{profile}.npz");link(CH,"charged-"+tag+"-b1.npz")
        if eta:link(CLOUD,"path-"+tag+".npz");link(CLOUD,"strip-"+tag+".npz")
        old=(f"front-0.00625-eta1-h0-label-wide-direct{('-spin1' if profile else '')}-to4.npz" if eta==1 else
             f"front-{(.0125 if eta==0 else .00625):g}-eta{eta:g}-h{amp:g}-{'shell' if shell else 'label'}-direct.npz")
        link(PARENT,old)
    for file in LOCAL.glob("*.csv"):
        require(file.name+" parses",all(None not in row and None not in row.values() for row in records(file)))
    absolute=records(LOCAL/"absolute-comparisons.csv");require("complete matched cases",len(absolute)==8)
    for i,row in enumerate(absolute):
        for k in ("preceding_window","radial","independent_metric","emitted_field","central_field","central_density","central_scalar_squared","falling_radius"):
            if row[k]:score(f"arm {i} {k}",row[k])
    require("neutral radiative null",not np.any(raw(.0125,0,0)[:,[5,6,9,10]]))
    c,old=factor();a=raw(.0125,1,0);b=raw(.0125,1,0,False,1);first=raw(.025,1,0);second=raw(.025,1,0,False,1)
    for tau in (3.,4.,5.,6.,6.4):
        i=round(tau/.04);reference=c*c*b[i,1]/a[i,1]
        score(f"calibrated {tau} determinant",abs((b[i,2]/a[i,2])/(b[i,1]/a[i,1])-1))
        score(f"calibrated {tau} refinement",abs((second[i,1]/first[i,1])/(b[i,1]/a[i,1])-1))
        if tau==4:score("recovered frozen time 4",abs(reference/old-1))
        if tau==3:score("magnetic match without recalibrating",abs(c*b[i,5]/a[i,5]-1))
    require("late magnetic sign reverses between sources",c*b[-1,5]/a[-1,5]<0)
    mixed=records(LOCAL/"magnetic-null-predictions.csv")
    require("opposed current sampled on frozen clocks",[float(row["tau"]) for row in mixed]==[3.,4.,5.,6.,6.4])
    for row in mixed:
        time=float(row["tau"]);tick=round(time/.04);tag="mixed "+row["tau"]
        require(tag+" coefficient from preceding stage",float(row["c"])==c and row["full_ruler"]=="not calculated")
        require(tag+" direct EM accounting",float(row["positive_slack"])>0 and
                abs(float(row["combined_direct"])-float(row["combined_floor"])-float(row["positive_slack"]))<1e-14*abs(float(row["combined_direct"])))
        independent=1-c*b[tick,5]/a[tick,5]
        score(tag+" field ratio absolute discrepancy on first field",abs(independent-float(row["opposite_source_B_over_first"])))
        for key in ("direct_refinement","floor_refinement","slack_refinement"):score(tag+" "+key,row[key])
    score("suppressed signed field at frozen calibration",abs(float(mixed[0]["opposite_source_B_over_first"])))
    for key in ("polar_history_error","electric_history_error"):score("mixed whole-history "+key,mixed[-1][key])
    for row in records(LOCAL/"state-difference.csv"):
        if row["tau"]=="6.4":
            for k in ("direct_vs_subtracted","refinement","metric"):score("state "+row["amp"]+" "+k,row[k])
            require("same emitted wave "+row["amp"],row["same_wave"]=="True")
    for row in records(LOCAL/"focusing-ledger.csv"):
        if row["tau"]=="6.4":
            case=row["eta"]+" "+row["amp"]+" "+row["shell"]+" "+row["profile"]
            for k in ("full_interval_budget_error","independent_dipole","positive_quadrature_crosscheck","smooth_quadrature"):score("ledger "+case+" "+k,abs(float(row[k])))
            require("positive flux slack "+case,0<float(row["flux_fraction_of_direct"])<=1 and float(row["slack"])>0)
    for row in records(LOCAL/"regularity-audit.csv"):
        case=row["eta"]+" "+row["amp"]+" "+row["shell"]+" "+row["profile"]
        for k in ("core_Mr","core_Mtheta","core_Vr","core_Vtheta","domain_Mr","domain_Mtheta","domain_Vr","domain_Vtheta","seed_volume_error"):
            score(case+" "+k,row[k])
    signature=records(LOCAL/"scalar-versus-ordinary.csv")
    require("ordinary minus scalar cases frozen",len(signature)==10 and {row["preparation"] for row in signature}=={"label","shell"})
    for row in signature:
        if float(row["tau"])!=6.4:continue
        for key in ("difference_budget_error","difference_determinant_error","difference_radial_error","difference_seed_error",
                    "weak_difference_radial_error","weak_difference_metric_error"):
            score("scalar minus ordinary "+row["preparation"]+" "+key,row[key])
        require("scalar and induced terms reported "+row["preparation"],float(row["explicit_scalar"])!=0 and float(row["all_other_terms"])!=0)
    for row in records(LOCAL/"resolved-flux-bound.csv"):
        if row["tau"]=="6.4":
            for k in ("direct_refine","floor_refine","slack_refine"):score("flux "+row["eta"]+" "+row["amp"]+" "+row["profile"]+" "+k,row[k])
    for row in records(LOCAL/"exact-dust-controls.csv"):
        for k in ("radius_change_error","centre_scale_change_error","centre_density_error","centre_density_change_error","inner_shell_change_error"):
            if row[k]:score("dust "+row["dx"]+" "+row["eta"]+" "+k,row[k])
    for p in sorted(LOCAL.glob("crossing-*.npz")):
        z=pack(p.name)["rows"];score(p.name+" central field",err(z[:,1],z[:,2]));score(p.name+" radial field",peak(z[:,3])/peak(z[:,4]))
    for p in sorted(LOCAL.glob("tt-*.npz")):
        z=pack(p.name)["rows"];score(p.name+" central shear",err(z[:,1],z[:,2]));score(p.name+" tensor components",peak(z[:,3])/.4)
    for r in records(LOCAL/"stationary-flat-gauge.csv"):require("flat gauge "+r["dx"]+" "+r["cap"],max(abs(float(r[k])) for k in ("curvature_rate","vector_rate","Hamiltonian"))<1e-8)
    for row in records(LOCAL/"numerical-variation.csv"):
        for k in ("volumes","wave","centre_B"):score("combined method change "+k,row[k])
    from mass_score import diagnostics
    mass_rows=records(LOCAL/"mass-force-ledger.csv")
    require("two independent resolutions in all three mass arms",
            {(float(row["dx"]),float(row["eta"]),float(row["amp"])) for row in mass_rows}==
            {(spacing,eta,amp) for spacing in (.0125,.025) for eta,amp in ((0,0),(1,0),(.8,1))} and len(mass_rows)==6)
    for row in mass_rows:
        dx,eta,amp=(float(row[key]) for key in ("dx","eta","amp"))
        label=f"mass dx={dx} eta={eta}"
        reread=diagnostics(dx,eta,amp)
        require(label+" ledger from packet",all((not row[key]) if value is None else float(row[key])==value for key,value in reread.items()))
        for key in ("accumulated_velocity_error","pressure_split_error","radial_mass_error","geometric_mass_error",
                    "centre_acceleration_error","old_equation_volume","determinant_error","exact_acceleration_error",
                    "exact_exterior_mass_error","exact_centre_change_error","exact_density_error","mass_balance_on_change",
                    "mass_balance_on_mass","em_subtracted_mass_change_error"):
            if row[key]:score(label+" "+key,row[key])
        if eta:
            require(label+" no appreciable charge or material crossing",
                    float(row["electric_charge_drift"])<1e-14 and float(row["local_material_density"])<1e-16)
        if amp:
            require(label+" scalar transports energy",float(row["scalar_transport"])!=0)
    fail=pack("burst-d0.05-q1-h0-s0-p0-c12-k3-r15-t0.3-end6.4.npz")["rows"]
    require("rejected unadjusted centre is a material failure",err(fail[:,9],fail[:,10])>.01 and err(fail[:,2],fail[:,1])>.1 and peak(fail[:,17])>1)
    require("local cache clean",not (LOCAL/"__pycache__").exists())
    return dict(checks=checks,accuracy=accuracy,inputs=inputs)
def main():
    report=verify()
    report["files"]={p.name:sha(p) for p in sorted(LOCAL.iterdir()) if p.is_file() and p.name!="closeout.json"}
    path=LOCAL/"closeout.json"
    if "--seal" in sys.argv:
        with path.open("x",encoding="utf8") as stream:json.dump(report,stream,indent=2,sort_keys=True)
    else:assert json.loads(path.read_text())==report
    print(len(report["files"]),"files",len(report["inputs"]),"linked sources",len(report["checks"]),"checks",sum(v["pass"] for v in report["accuracy"].values()),"of",len(report["accuracy"]),"accuracy comparisons",sha(path))
if __name__=="__main__":main()
