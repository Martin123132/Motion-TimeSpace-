from regular import run
cases=((1.,0.,False,0),(1.,0.,False,1),(.8,0.,False,0),(.8,1.,False,0),(.8,1.,True,0),(.8,1/160,False,0),(.8,1/160,True,0),(0.,0.,False,0))

if __name__=="__main__":
    for spacing in (.025,.0125):
        for eta,amp,shell,profile in cases:
            if (spacing,eta,amp,shell,profile)==(.025,1.,0.,False,0):continue
            run(spacing,eta,amp,shell,profile,damping=.5,reduced=True)
