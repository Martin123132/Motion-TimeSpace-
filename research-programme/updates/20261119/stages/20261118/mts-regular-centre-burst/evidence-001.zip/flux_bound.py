from regular import *
from scipy.interpolate import make_interp_spline
import csv

def integrate(time,values):
    p=make_interp_spline(time,values,k=5,axis=0).antiderivative(2)
    return p(time)-p(time[0])-(time-time[0])[:,None]*p.derivative()(time[0])

def solve_bound(eta,amp,profile):
    tag=f"1920-eta{eta:g}-h{amp:g}"
    with np.load(source(CLOUD,f"path-{tag}.npz")) as saved:
        path=CubicSpline(saved["tau"],saved["state"][1,:,:3],axis=0)
    with np.load(source(CLOUD,f"strip-{tag}.npz")) as saved:
        mass=RectBivariateSpline(saved["time"],saved["radius"],saved["values"][:,0,:],kx=5,ky=5,s=0)
    with np.load(source(SRC,f"driven-{tag}-spin{profile}.npz")) as saved:
        time,rad,fields=saved["time"],saved["radius"],saved["fields"]
        bank=[RectBivariateSpline(time,rad,fields[:,k,:],kx=5,ky=5,s=0) for k in range(3)]
    tau=np.linspace(0,6.4,2561);clock,radius,imp=path(tau).T
    a,p,ar=[fn.ev(clock,radius) for fn in bank]
    fac=1-2*mass.ev(clock,radius)/radius
    vel=np.sqrt(fac)*imp;lor=np.hypot(1,vel)
    electric=-np.sqrt(fac)*(lor*p+vel*ar)/radius
    magnetic=-np.sqrt(fac)*(lor*ar+vel*p)/radius
    zed=2*a/radius**2
    flux=-electric*magnetic;force=electric**2+magnetic**2-zed**2
    lower=2*abs(flux)-zed**2;excess=(abs(electric)-abs(magnetic))**2
    instantaneous=np.column_stack([force,lower,excess,2*abs(flux),zed**2,2*flux])
    memory=integrate(tau,instantaneous);half=integrate(tau[::2],instantaneous[::2])
    err=np.max(abs(memory[::2]-half),axis=0)/(np.max(abs(memory),axis=0)+1e-300)
    assert np.max(abs(force-lower-excess))<2e-14*np.max(abs(force))
    assert np.max(abs(memory[:,0]-memory[:,1]-memory[:,2]))<1e-10*np.max(abs(memory[:,0]))
    rows=[]
    for target in (3.,4.,5.,6.,6.4):
        idx=round(target/.0025);vals=memory[idx]
        rows.append(dict(eta=eta,amp=amp,profile=profile,tau=target,direct=vals[0],flux_floor=vals[1],
                         positive_slack=vals[2],floor_fraction=vals[1]/vals[0],abs_flux_exposure=vals[3],
                         polar_magnetic_exposure=vals[4],signed_flux_exposure=vals[5],
                         conditional_no_incoming_error=(vals[3]-vals[5]+vals[2])/vals[0],
                         numerical_error=err.max()))
    return rows

if __name__=="__main__":
    out=[]
    for eta,amp,profile in ((1.,0.,0),(1.,0.,1),(.8,0.,0),(.8,1.,0),(.8,1/160,0)):
        out+=solve_bound(eta,amp,profile)
    with (LOCAL/"poynting-predictions.csv").open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(out[0]));writer.writeheader();writer.writerows(out)
    print([r for r in out if r["tau"]==6.4],flush=True)
