from centre_base import np

def quantities(model,y):
    radius=model.x
    ax,ct,kx,kt,h,dp,ex,dens,px=[y[k].real[:,:1] for k in (0,2,4,6,8,9,10,13,14)]
    aa=1+ax;cc=1+ct;a=np.sqrt(aa);b=np.sqrt(cc);areal=radius*b;jac=a*areal**2
    pi=dp/jac;grad=model.dr(h)/a;em=(ex/areal**2)**2
    lor=np.hypot(1,px/a);rho=dens/(jac*lor);ko=kt/cc
    pr=rho*(px/a)**2+.5*(pi**2+grad**2-h**2-em)
    energy=rho*lor**2+.5*(pi**2+grad**2+h**2+em)
    current=rho*lor*px/a-pi*grad
    nn=2*pi**2-h**2+em+rho*(2*lor**2-1)
    mass_density=y[23].real[:,:1]
    md=mass_density/b**3
    rdot=-areal*ko;rp=b+radius*model.dr(ct)/(2*b)
    return aa,cc,kx,ko,a,b,areal,md,rdot,rp,pr,current,nn,energy

def impose(model,y,dy):
    aa,cc,kx,ko,a,b,rad,md,rdot,rp,pr,current,nn,en=quantities(model,y)
    krate=aa*(nn-2*md-2*pr)-(kx/a)**2
    arate=cc*(md+pr-ko**2)
    dy[4].real=krate
    dy[6].real=arate;dy[7].real=arate
    dy[23]=-(b**2)*(pr*rdot+current*rp/a)/model.x

def diagnostics(model,y):
    ext=model.extend(y)
    aa,cc,kx,ko,a,b,rad,md,rdot,rp,pr,current,nn,en=quantities(model,ext)
    radx=model.x
    mass=ext[23].real[:,:1]*radx**3
    cp=model.dr(ext[2].real[:,:1])
    difference=ext[0].real[:,:1]-ext[2].real[:,:1]-radx*cp-(radx*cp/(2*b))**2
    reconstruct=rad*(rdot**2+difference/aa)/2
    density=rad**2*(en*rp+a*current*rdot)
    mask=(radx[:,0]>0)&(radx[:,0]<=6.5)
    peak=lambda val:float(np.max(abs(val[mask])))
    local=lambda val:float(model.atsite(val[model.ghost:,0]))
    center=lambda val:float(model.central(val[model.ghost:,0],0))
    jac=a*rad**2
    scalar=ext[8].real[:,:1];pi=ext[9].real[:,:1]/jac;grad=model.dr(scalar)/a
    scalar_pressure=.5*(pi**2+grad**2-scalar**2)
    em_pressure=-.5*(ext[10].real[:,:1]/rad**2)**2
    return [peak(model.dr(mass)-density),peak(density),peak(reconstruct-mass),peak(mass),
            local(-rad*md),local(-rad*pr),local(rdot),local(mass),center(-nn/3),center(nn),local(rad),
            local(-rad**2*pr*rdot),local(-rad**2*current*rp/a),local(-rad*scalar_pressure),
            local(-rad*em_pressure),local(-rad*(pr-scalar_pressure-em_pressure)),
            local(ext[10].real[:,:1]),local(ext[13].real[:,:1]/jac),local(rad**2*pi*grad*rp/a)]
