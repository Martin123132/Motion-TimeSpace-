from regular import *
from connection import flat_vector, replacement
import csv
from scipy.integrate import simpson

def capwave(dx,cap,spread=.55,centre=2.):
    radius=(np.arange(round(10/dx))+.5)*dx
    basis=CoreBasis(radius[:,None],cap)
    def gaussian(value,n):
        xx=(value-centre)/spread;gf=np.exp(-xx**2/2)
        return [gf,-xx*gf/spread,(xx**2-1)*gf/spread**2,(3*xx-xx**3)*gf/spread**3][n]
    def exact(time,order):
        lo=time-radius;hi=time+radius
        return -gaussian(lo,order+1)-gaussian(hi,order+1)-(gaussian(lo,order)-gaussian(hi,order))/radius
    sample=np.stack([exact(0,0),exact(0,1)])
    def rhs(data):
        pack=np.r_[data[0,3::-1],data[0]]
        lap=correlate1d(pack,AXIAL_SECOND,mode="nearest")[4:]/dx**2-2*data[0]/radius**2
        rate=np.stack((data[1],lap));rate[:,:cap]=rate[:,:cap]@basis.mat[2].T;rate[:,-4:]=0.
        return rate
    rows=[]
    for tick in range(101):
        time=tick*.04
        wave,mom=sample;central=2*basis.at0[2]@wave[:cap]
        direct=exact(time,0);mask=radius<6.
        slope=correlate1d(np.r_[wave[2::-1],wave],FIRST,mode="nearest")[3:]/dx
        energy=simpson((mom**2+slope**2+2*(wave/radius)**2)/2,x=radius)
        rows.append([time,central,-4*gaussian(time,3)/3,np.max(abs(wave[mask]-direct[mask])),np.max(abs(direct[mask])),energy])
        if tick==100:break
        count=int(np.ceil(.04/(dx*.24)));dt=.04/count
        for _ in range(count):
            one=rhs(sample);two=rhs(sample+dt/2*one);three=rhs(sample+dt/2*two);sample+=dt/6*(one+2*two+2*three+rhs(sample+dt*three))
    with (LOCAL/f"crossing-d{dx:g}-c{cap}.npz").open("xb") as out:np.savez_compressed(out,rows=rows)
    return np.asarray(rows)

def seed_tt(model,frequency=.8):
    mu,weights=np.polynomial.legendre.leggauss(24)
    phi=np.arange(48)*2*np.pi/48
    kx=np.sqrt(1-mu[:,None]**2)*np.cos(phi);ky=np.sqrt(1-mu[:,None]**2)*np.sin(phi);kz=mu[:,None]+np.zeros_like(kx)
    vec=np.stack((kx.ravel(),ky.ravel(),kz.ravel()),axis=1)
    weights=np.repeat(weights/96,48)
    proj=np.eye(3)[None,:,:]-vec[:,:,None]*vec[:,None,:]
    seed=np.diag([-.5,-.5,1.])
    tt=proj@seed@proj-.5*proj*np.trace(proj@seed,axis1=1,axis2=2)[:,None,None]
    slots=np.zeros((4,len(model.rad),2))
    for idx,(co,si) in enumerate(zip(COS,SIN)):
        normal=np.array([si,0.,co]);tang=np.array([co,0.,-si]);az=np.array([0.,1.,0.])
        factors=np.stack((normal@tt@normal,normal@tt@tang,tang@tt@tang,az@tt@az),axis=1)
        slots[:,:,idx]=(np.cos(frequency*model.rad*(vec@normal))@(weights[:,None]*factors)).T
    slots[1]*=model.rad
    return slots

def ttcheck(dx,cap,frequency=.8):
    model=Centre(dx,0.,0.,cap=cap,reduced=True,damping=.5)
    y=np.zeros_like(model.y0);ref=seed_tt(model,frequency)
    y[:4]=1j*EPS*ref
    y=model.cap.project(y)
    rows=[];mask=model.rad[:,0]<model.rad[-1,0]-7
    for tick in range(81):
        time=tick*.08;expect=ref*np.cos(frequency*time)
        centre_h=model.central(coeff(y[0].imag)[:,0]/EPS,0)
        centre_ref=.4*np.cos(frequency*time)
        error=(y[:4].imag/EPS-expect);error[1]/=model.rad
        ham=model.rhs(y,True)[2]
        rows.append([time,centre_h,centre_ref,np.max(abs(error[:,mask])),
                     np.max(abs(ham[mask].imag/EPS)),np.max(abs(y[17,mask].imag/EPS))])
        if tick==80:break
        steps=int(np.ceil(.08/(.30*dx)));dt=.08/steps
        for _ in range(steps):
            one=model.rhs(y);two=model.rhs(y+dt/2*one);three=model.rhs(y+dt/2*two);y+=dt/6*(one+2*two+2*three+model.rhs(y+dt*three))
    with (LOCAL/f"tt-d{dx:g}-c{cap}.npz").open("xb") as out:np.savez_compressed(out,rows=rows)
    return np.array(rows)

if __name__=="__main__":
    for dx in (.05,.025,.0125):
        for cap in (12,16):
            a=capwave(dx,cap)
            print("regular dipole",dx,cap,np.max(abs(a[:,1]-a[:,2]))/np.max(abs(a[:,2])),np.max(a[:,3])/np.max(a[:,4]),flush=True)
    for dx,cap in ((.05,12),(.025,12),(.0125,12),(.025,16)):
        data=ttcheck(dx,cap)
        print("TT",dx,cap,np.max(abs(data[:,1]-data[:,2]))/.4,np.max(data[:,3]),flush=True)
