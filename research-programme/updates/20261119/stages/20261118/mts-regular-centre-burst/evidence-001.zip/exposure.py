from regular import *
from smooth_launch import refresh
from metric_controls import core_constraints
import json
from scipy.integrate import cumulative_simpson
from scipy.interpolate import make_interp_spline

def terms(model,y):
    radius=model.rad;ax,bz,ct,cf,kx,kxt,ktt,kff,h,dp,er,et,mag,dens,px,pt=y[:16]
    aa=1+ax;cc=radius**2*(1+ct);det=aa*cc-bz*bz;ia=cc/det;ib=-bz/det;ic=aa/det
    jac=radius*np.sqrt(1+cf)*np.sqrt(det)
    ex=(aa*er+bz*et)/jac;ez=(bz*er+cc*et)/jac
    electric=(er*ex+et*ez)/jac
    area=radius*np.sqrt(1+ct.real[:,:1]);a=np.sqrt(aa.real[:,:1])
    charge=model.eta*y[18].real[:,:1]
    avec=y[19].real[:,:1];pm=y[20].real[:,:1]
    ag=model.dr(avec)
    ell,internal=spin(y[18].real[:,:1],model.profile)
    if model.homogeneous:ell,internal=0.,0.
    twist=2*(charge*avec-internal)/area**3
    gamma=np.sqrt(1+ia*px**2+2*ib*pt*px+ic*pt**2+DUAL*((ell-model.eta*avec)*SIN/area)**2)
    dust=dens/(jac*gamma)*(2*gamma**2-1)
    kt=radius**2*ktt
    kr=ia*kx+ib*kxt;km=ia*kxt+ib*kt;kn=ib*kx+ic*kxt;ktheta=ib*kxt+ic*kt;ko=kff/(1+cf)
    shear=kr**2+2*km*kn+ktheta**2+ko**2
    direct=(2*avec/area**2)**2-((pm/a)**2+(ag/a)**2)/area**2
    return [-model.contrast(shear),2*float(model.atsite(twist[:,0]**2)),-model.contrast(2*(dp/jac)**2-h**2),
            -model.contrast(electric),-float(model.atsite(direct[:,0])),-model.contrast(dust)]

def run_budget(dx,eta,amp,shell=False,profile=0,cap=12,outer=15,step=.30,diss=.5,smooth=False,homogeneous=False,mass_form=False):
    ensure()
    model=Centre(dx,eta,amp,shell,profile,cap,outer,3,diss,True,mass_form)
    changes=refresh(model,eta,amp,shell,profile) if smooth else {}
    if homogeneous:
        assert not (shell or smooth or profile) and amp>0
        from types import SimpleNamespace
        from preparation_difference import prepare
        from connection import flat_vector
        stub=SimpleNamespace(model=model.model,x=np.maximum(model.rad,.0078125),initial=model.y0)
        model.y0=prepare(stub)
        model.shift=stub.shift*(model.rad/stub.x)**3
        model.homogeneous=True
        model.y0=model.cap.project(model.y0)
        vx,vt=flat_vector(model,*model.extend(model.y0)[:4])
        model.y0[21]=vx[model.ghost:];model.y0[22]=vt[model.ghost:]
    ref=Reference(eta,amp,profile);y=model.y0.copy();start=model.logmetric(y)
    name=f"budget-d{dx:g}-q{eta:g}-h{amp:g}-s{int(shell)}-p{profile}-c{cap}-r{outer:g}-t{step:g}-ko{diss:g}-seed{int(smooth)}.npz"
    if homogeneous:name=name.replace(".npz","-hom.npz")
    if mass_form:name=name.replace(".npz","-mass.npz")
    if (LOCAL/name).exists():raise FileExistsError(name)
    with np.load(source(SRC,f"driven-1920-eta{eta:g}-h{amp:g}-spin{profile}.npz")) as old:
        mt,rd=old["time"],old["radius"];storage=old["fields"]
        banks=[RectBivariateSpline(mt,rd,storage[:,k],kx=5,ky=5,s=0) for k in (1,2)]
    if eta:
        key=f"1920-eta{eta:g}-h{amp:g}"
        with np.load(source(CLOUD,f"path-{key}.npz")) as old:path=CubicSpline(old["tau"],old["state"][1,:,:3],axis=0)
        with np.load(source(CLOUD,f"strip-{key}.npz")) as old:
            metric=RectBivariateSpline(old["time"],old["radius"],old["values"][:,0,:],kx=5,ky=5,s=0)
    rows=[];quality=[];mass_checks=[]
    for tick in range(321):
        if (LOCAL/"STOP-REQUESTED").exists():raise SystemExit("owner hold")
        time=tick*.02
        vals=terms(model,y);jac,tr,ham,gauss,nn,ksq,rot=model.rhs(y,True)
        rb=float(model.atsite((model.rad*np.sqrt(1+y[2].real[:,:1]))[:,0]))
        if eta and not homogeneous:
            tc,rc,imp=path(time);val=float(ref.wave.ev(tc,rc))
            pm,xr=[float(bank.ev(tc,rc)) for bank in banks];fac=1-2*float(metric.ev(tc,rc))/rc
            lor=np.sqrt(1+fac*imp**2);vs=np.sqrt(fac)*imp
            em=(2*val/rc**2)**2-fac*((lor*pm+vs*xr)**2+(lor*xr+vs*pm)**2)/rc**2
        else:val=0.;em=0.;rc=rb
        cb,rho,h2=ref.get(time)
        if homogeneous:cb=0.
        cm=2*model.central(y[19,:,0].real,2)/(1+model.central(y[2,:,0].real,0))
        cd=model.central(y[13,:,0].real/jac[:,0].real,0)
        rows.append([time,model.contrast(y[17]),model.contrast(model.logmetric(y)-start),*vals,-em,
                     model.contrast(ham),model.contrast(gauss),float(model.atsite(y[19,:,0].real)),val,cm,cb,cd,rho,
                     np.max(abs(ham[:cap].real)),np.max(abs(ham[:cap].imag/EPS)),rb,rc])
        if not np.isfinite(y).all():raise ArithmeticError(f"{name} nonfinite at {time}")
        if tick%10==0:quality.append([time,*core_constraints(model,y)])
        if mass_form and tick%2==0:
            from mass_flux import diagnostics
            mass_checks.append([time,*diagnostics(model,y)])
        if tick==320:break
        steps=int(np.ceil(.02/(step*dx)-1e-12));dt=.02/steps
        for _ in range(steps):
            one=model.rhs(y);two=model.rhs(y+dt/2*one);three=model.rhs(y+dt/2*two);four=model.rhs(y+dt*three);y+=dt/6*(one+2*two+2*three+four)
    data=np.array(rows);tau=data[:,0]
    def integrate(grid,values):
        pp=make_interp_spline(grid,values,k=5,axis=0).antiderivative(2)
        return pp(grid)-pp(0)-grid[:,None]*pp.derivative()(0)
    integrated=integrate(tau,data[:,3:10]);coarse=integrate(tau[::2],data[::2,3:10])
    with (LOCAL/name).open("xb") as out:
        np.savez_compressed(out,rows=data,integrated=integrated,coarse=coarse,quality=quality,changes=json.dumps(changes),mass_checks=mass_checks,
                inner_metric=y[:,:cap],core_radius=model.rad[:cap],
                columns="tau ray metric shear twist scalar polar_E dipole dust bank_dipole ham gauss A bank B_c B_c_bank rho_c rho_c_bank max_core_H0 max_core_H2 R Rbank".split())
    print(name, data[-1,1],integrated[-1].tolist(),flush=True)

if __name__=="__main__":
    import argparse
    arg=argparse.ArgumentParser()
    for key in ("dx","eta","amp"):arg.add_argument(key,type=float)
    for key,default in (("profile",0),("cap",12),("outer",15.),("step",.30),("diss",.5)):
        arg.add_argument("--"+key,type=type(default),default=default)
    arg.add_argument("--shell",action="store_true");arg.add_argument("--smooth",action="store_true");arg.add_argument("--homogeneous",action="store_true")
    arg.add_argument("--mass-form",action="store_true")
    run_budget(**vars(arg.parse_args()))
