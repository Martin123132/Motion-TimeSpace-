from regular import *
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
import csv

def neutral_mass(rad):
    d0=.000703828125
    def rhs(x,y):
        fac=1-2*y[0]/x if x>0 else 1.
        return [x*x*d0*max(1-(x/5)**2,0.)**6*np.sqrt(fac)]
    ivp=solve_ivp(rhs,(0,8),[0.],method="DOP853",rtol=4e-14,atol=3e-22,max_step=.05,dense_output=True)
    assert ivp.success
    return ivp.sol(rad)[0]

def factor(time,concentration):
    value=time*np.sqrt(8*concentration)
    if value==0:return 1.,0.
    angle=brentq(lambda v:v+np.sin(v)-value,0.,value,xtol=1e-16)
    return 1-np.sin(angle/2)**2,angle

def exact():
    rows=[]
    for dx in (.025,.0125):
        for eta in (0.,1.):
            path=LOCAL/f"burst-d{dx:g}-q{eta:g}-h0-s0-p0-c12-k3-r15-t0.3-end6.4-ko0.5-connection.npz"
            with np.load(path) as saved:
                data=saved["rows"];rad=saved["core_radius"][:,0];last=saved["last"]
            tau=data[:,0];d0=.000703828125;cap=CoreBasis(rad[:,None],len(rad))
            actual_c=np.sqrt(1+cap.at0[0]@last[2,:,0].real)
            if eta==0:
                mass=neutral_mass(np.r_[rad,6.])
                radius=np.array([6*factor(t,mass[-1]/216)[0] for t in tau])
                ac=np.array([factor(t,d0/3)[0] for t in tau])
                dc=d0/ac**3
                inner=np.array([r*factor(6.4,m/r**3)[0] for r,m in zip(rad,mass[:-1])])
                ifit=np.max(abs(inner-rad*np.sqrt(1+last[2,:,0].real)))/np.max(abs(inner-rad))
            else:
                ode=solve_ivp(lambda t,y:[y[1],-.002/y[0]**2+.002**2/y[0]**3],(0.,6.4),[6.,0.],method="DOP853",rtol=3e-14,atol=1e-16,t_eval=tau)
                assert ode.success
                radius=ode.y[0];ac=np.cos(np.sqrt(d0/3)*tau);dc=np.full_like(tau,d0)
                ifit=None
            rows.append(dict(dx=dx,eta=eta,R_final=radius[-1],radius_change_error=np.max(abs(data[:,7]-radius))/abs(radius[-1]-6.),
                centre_scale=ac[-1],centre_scale_change_error=abs(actual_c-ac[-1])/abs(1-ac[-1]),
                centre_density=dc[-1],centre_density_error=np.max(abs(dc-data[:,11]))/max(dc),
                centre_density_change_error=np.max(abs(dc-data[:,11]))/abs(dc[-1]-d0) if eta==0 else None,
                inner_shell_change_error=ifit))
    with (LOCAL/"exact-dust-controls.csv").open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print(rows,flush=True)
if __name__=="__main__":exact()
