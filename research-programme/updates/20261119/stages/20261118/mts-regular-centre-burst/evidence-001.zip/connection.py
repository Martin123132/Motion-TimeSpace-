from centre_base import np, ANG, ANG2, POL, SIN, COS, coeff, angle, mixed, divang, DUAL

def flat_vector(model,aa,bb,cc,ff):
    radius=model.x
    norm=bb/radius
    return ((2*aa-cc-ff+divang(norm))/radius-model.dr(cc+ff),
            model.dr(bb)+2*norm-angle(aa+ff)+COS/SIN*(cc-ff))

def cart_lap(model,aa,bphys,cc,ff):
    rad=model.x;rr=rad**2;nr=rad[:,0]
    def op(val):
        return model.drr(val)+2*model.dr(val)/rad
    tang=cc.real[:,:1];delta=aa.real[:,:1]-tang
    ua=op(tang)+2*delta/rr;ub=op(delta)-6*delta/rr
    hh=coeff(aa.imag);jj=bphys.imag[:,:1]/(rad*ANG[0])
    kk=coeff((cc.imag+ff.imag)/2);gg=(cc.imag[:,:1]-ff.imag[:,:1])/(3*SIN[0]**2)
    al=2*gg;bt=2*jj-2*gg;gm=kk+gg;de=hh-4*jj-kk+gg
    ap=op(al)+4*bt/rr;bp=op(bt)+(4*de-6*bt)/rr;gp=op(gm)+(2*de-6*gm)/rr;dp=op(de)-20*de/rr
    return (ua+ub+1j*(ap+2*bp+gp+dp)*POL,1j*(ap+bp)/2*ANG,
            ua+1j*((gp-ap/2)*POL+.75*ap*SIN**2),ua+1j*((gp-ap/2)*POL-.75*ap*SIN**2))

def replacement(model,y):
    aa,bb,cc,ff=y[:4];radius=model.x;rr=radius**2
    dr=model.dr;drr=model.drr
    vx,vt=y[21:23]
    lp=cart_lap(model,aa,bb,cc,ff)
    trace=aa+cc+ff
    tr=dr(trace);ta=angle(trace)
    wanted=(dr(vx)+.5*drr(trace)-.5*lp[0],
            (dr(vt)-2*vt/radius+angle(vx))/(2*radius)+.5*(dr(ta)-ta/radius)/radius-.5*lp[1],
            vx/radius+mixed(vt)/rr+.5*(tr/radius+coeff(trace)*ANG2/rr)-.5*lp[2],
            vx/radius+COS/SIN*vt/rr+.5*(tr/radius+COS/SIN*ta/rr)-.5*lp[3])
    ar=dr(aa);cr=dr(cc);fr=dr(ff);at=angle(aa);ct=angle(cc);ft=angle(ff)
    bt=mixed(bb)
    gauss=(dr(bt)-radius*cr-.5*rr*drr(cc)-.5*coeff(aa)*ANG2+.5*radius*ar)/rr
    hx=SIN*(fr+radius*drr(ff)/2-ar/2)-(dr(bb)-at/2)*COS/radius
    ht=.5*radius*(COS*(fr-cr)+SIN*dr(ft))-.5*SIN*at+SIN*bb/radius
    hz=radius*COS*ft+radius*SIN*coeff(ff)*ANG2/2-SIN*bt+radius*SIN*(cc-aa)+.5*rr*SIN*(cr+fr)-.5*radius*COS*ct-bb*COS
    raw=(gauss-hx/(radius*SIN),-ht/(rr*SIN),gauss-hz/(radius**3*SIN),-(hx+hz/rr)/(radius*SIN))
    return [new-old for new,old in zip(wanted,raw)]

def vector_rate(model,y):
    ax,bz,ct,cf,kx,kxt,ktt,kff,scalar,dp,exd,etd,mag,dens,px,pt=y[:16];wave,mom=y[19:21]
    radius=model.x
    aa=1+ax;cc=radius**2*(1+ct);kt=radius**2*ktt
    det=aa*cc-bz**2;ia=cc/det;ib=-bz/det;ic=aa/det
    jac=abs(radius)*np.sqrt(1+cf)*np.sqrt(det)
    ku=ia*kx+ib*kxt;kv=ib*kx+ic*kxt;mu=ia*kxt+ib*kt;mv=ib*kxt+ic*kt
    ko=kff/(1+cf);tr=ku+mv+ko
    kxx=ku*ia+mu*ib;kxtup=ku*ib+mu*ic;ktup=kv*ib+mv*ic
    dr=model.dr
    ar=dr(ax);at=angle(ax);br=dr(bz);bt=mixed(bz)
    cr=2*radius*(1+ct)+radius**2*dr(ct);ca=radius**2*angle(ct)
    logjr=1/radius+dr(cf)/(2*(1+cf))+(ar*cc+aa*cr-2*bz*br)/(2*det)
    logja=angle(cf)/(2*(1+cf))+(at*cc+aa*ca-2*bz*bt)/(2*det)
    mx=dr(ku-tr)+divang(kv)+logjr*ku+logja*kv-(ar*kxx+2*br*kxtup+cr*ktup)/2-ko*(1/radius+dr(cf)/(2*(1+cf)))
    mt=dr(mu)+angle(mv-tr)+logjr*mu+logja*mv+(COS/SIN)*(mv-ko)-(at*kxx+2*bt*kxtup+ca*ktup)/2-ko*angle(cf)/(2*(1+cf))
    ec=-mom.real[:,:1]/(np.sqrt(aa.real[:,:1])*cc.real[:,:1])
    emx=mag*etd/jac+DUAL*ec*dr(wave.real[:,:1])*SIN**2
    emt=-mag*exd/jac+DUAL*ec*2*wave.real[:,:1]*SIN*COS
    mx+=2*(dp*dr(scalar)/jac-dens*px/jac-emx);mt+=2*(dp*angle(scalar)/jac-dens*pt/jac-emt)
    fx,ft=flat_vector(model,kx,kxt,ktt,kff)
    return 2*(mx-fx),2*(mt-ft)
