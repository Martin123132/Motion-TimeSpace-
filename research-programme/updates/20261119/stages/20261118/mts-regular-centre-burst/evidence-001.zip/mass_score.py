from score import LOCAL, TOL, bud, err, np, pack, peak, raw, table
from exact_dust import CoreBasis, factor, neutral_mass
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline


def primitive(clock, values):
    fit = make_interp_spline(clock, values, k=5).antiderivative()
    return fit(clock) - fit(clock[0])


def diagnostics(spacing, charge, amplitude):
    saved = pack(f"budget-d{spacing:g}-q{charge:g}-h{amplitude:g}-s0-p0-c12-r15-t0.3-ko0.5-seed1-mass.npz")
    timeseries = saved["rows"][::2]
    mass = saved["mass_checks"]
    assert mass.shape == (161, 20) and np.array_equal(mass[:, 0], timeseries[:, 0])
    assert np.isfinite(mass).all()
    clock, gravity, pressure, velocity, enclosed, radius = mass[:, [0, 5, 6, 7, 8, 11]].T
    pressure_work, transported, scalar_term, maxwell_term, dust_term = mass[:, 12:17].T
    delta_mass = enclosed - enclosed[0]
    electric_charge, local_matter, scalar_inflow = mass[:,17:20].T
    material_energy = enclosed + electric_charge**2/(2*radius)
    corrected_change = material_energy-material_energy[0]
    scalar_work = primitive(clock,radius*scalar_term*velocity)
    scalar_transport = primitive(clock,scalar_inflow)
    normal_volume = raw(spacing, charge, amplitude)
    centre_grid = saved["core_radius"]
    origin = CoreBasis(centre_grid, len(centre_grid)).at0[0]
    final_scale = np.sqrt(1 + origin @ saved["inner_metric"][2, :, 0].real)
    acceleration = make_interp_spline(clock, mass[:, 9], k=5)
    central = solve_ivp(lambda time, state: [state[1], acceleration(time)*state[0]], (0., 6.4), [1., 0.],
                        method="DOP853", rtol=3e-14, atol=1e-16)
    assert central.success
    row = dict(dx=spacing, eta=charge, amp=amplitude, final_R=radius[-1], final_centre_scale=final_scale,
               final_centre_density=timeseries[-1, 16], gravity_initial=gravity[0], gravity_final=gravity[-1],
               pressure_final=pressure[-1], scalar_pressure_final=scalar_term[-1], electric_pressure_final=maxwell_term[-1],
               dust_pressure_final=dust_term[-1], enclosed_initial=enclosed[0], enclosed_change=delta_mass[-1],
               pressure_work=primitive(clock,pressure_work)[-1], net_inward_energy=primitive(clock,transported)[-1],
               scalar_compression_work=scalar_work[-1], scalar_transport=scalar_transport[-1],
               electric_charge_drift=peak(electric_charge-electric_charge[0]), local_material_density=peak(local_matter),
               em_subtracted_mass_change=corrected_change[-1], em_subtracted_mass_change_error=None,
               accumulated_velocity_error=err(primitive(clock,gravity+pressure), velocity-velocity[0]),
               pressure_split_error=err(scalar_term+maxwell_term+dust_term, pressure),
               radial_mass_error=peak(mass[:,1])/peak(mass[:,2]), geometric_mass_error=peak(mass[:,3])/peak(mass[:,4]),
               centre_acceleration_error=abs(final_scale-central.y[0,-1])/abs(1-final_scale),
               old_equation_volume=err(timeseries[:,1],normal_volume[:,1]), determinant_error=err(timeseries[:,2],timeseries[:,1]),
               exact_acceleration_error=None, exact_exterior_mass_error=None, exact_centre_change_error=None, exact_density_error=None,
               mass_balance_on_change=None, mass_balance_on_mass=peak(primitive(clock,pressure_work+transported)-delta_mass)/peak(enclosed))
    if charge != 0:
        row["mass_balance_on_change"]=err(primitive(clock,pressure_work+transported),delta_mass)
    if amplitude:
        row["em_subtracted_mass_change_error"]=err(scalar_work+scalar_transport,corrected_change)
    if charge in (0., 1.):
        neutral=charge==0
        material_mass = float(neutral_mass(np.array([6.]))[0]) if neutral else .002
        electric_charge = 0. if neutral else .002
        row["exact_acceleration_error"]=err(gravity+pressure,-material_mass/radius**2+electric_charge**2/radius**3)
        row["exact_exterior_mass_error"]=err(enclosed,material_mass-electric_charge**2/(2*radius))
        central_density=.000703828125
        exact_scale=factor(6.4,central_density/3)[0] if neutral else np.cos(np.sqrt(central_density/3)*6.4)
        row["exact_centre_change_error"]=abs(final_scale-exact_scale)/abs(1-exact_scale)
        expected_density=central_density/exact_scale**3 if neutral else central_density
        row["exact_density_error"]=abs(row["final_centre_density"]-expected_density)/expected_density
    return row


def main():
    results=[diagnostics(dx, charge, amplitude) for dx in (.025,.0125) for charge, amplitude in ((0.,0.),(1.,0.),(.8,1.))]
    table("mass-force-ledger.csv",results)
    print("mass evolution checked on six independent runs",flush=True)


if __name__=="__main__":
    main()
