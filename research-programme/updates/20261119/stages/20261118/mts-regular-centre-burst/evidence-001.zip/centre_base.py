from pathlib import Path
import sys
LOCAL=Path(__file__).resolve().parent
PARENT=LOCAL.parent/"mts-driven-even-front-20261118"
sys.path.insert(0,str(PARENT))
from front_equations import np, SIN, COS, POL, ANG, ANG2, DUAL, EPS, angle, mixed, divang, coeff, cov_project, spin, correlate1d, AXIAL_SECOND, FIRST, SECOND, Model, ShellModel, source, solve, spline, sha, CLOUD, SRC, PRE, guard
LOCK="671b8ffbbec40d0544dda80b8f160ba2134e0d12ef8cf7dcfd967e1a3fa56cb7"

def ensure():
    guard()
    assert sha(PARENT/"closeout.json")==LOCK
    if (LOCAL/"STOP-REQUESTED").exists() or (PARENT/"STOP-REQUESTED").exists():raise SystemExit("owner hold")
