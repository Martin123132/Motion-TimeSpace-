import sys
from common import ROOT,PRIOR,np,guard,packet,digest,json
import psutil

BASE=ROOT.parent/'condensate-origin-20261003'
MATCH=BASE/'native-heavy-matching-20261007'
SPEC=BASE/'resolved-matter-spectrum-20261007'
GROW=ROOT.parent/'mts-growth-mode-native-20261118'


def main(case):
    guard()
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([process.cpu_affinity()[0]])
    sys.path.insert(0,str(MATCH))
    import matching_common as source
    assert digest(MATCH/'native/camb/cambdll.dll')==json.loads((GROW/'input-lock.json').read_text())['inputs'][str(MATCH/'native/camb/cambdll.dll')]
    init=SPEC/'runs/projection/a225-w6-d8.npz' if case=='heavy' else BASE/'native-two-field-transfer-20261007/runs/backgrounds/cold.npz'
    params=source.params_for(init)
    if case=='lcdm':params.DarkEnergy=source.camb.dark_energy.DarkEnergyFluid()
    params.DoLateRadTruncation=False
    engine=source.camb.get_background(params)
    engine.Params.Accuracy.IntTolBoost=6
    red=np.r_[np.linspace(0,2,81),np.linspace(2.05,4,40)]
    eta=engine.conformal_time(red,tol=1e-10);chi=eta[0]-eta
    assert np.max(abs(chi-engine.comoving_radial_distance(red)))<.001
    with np.load(SPEC/'results/spectrum'/(case+'.npz')) as inp:
        modes=inp['modes'];modes=modes[modes<=5]
    bank=PRIOR/('dense-'+case+'.npz')
    assert digest(bank)==json.loads((PRIOR/'closeout.json').read_text())['files'][bank.name]
    table=np.empty((len(modes),len(red)))
    with np.load(bank) as old:
        low=len(old['modes']);assert np.array_equal(modes[:low],old['modes'])
        ref=1/old['scales']-1;ind=np.argmin(abs(ref[:,None]-red[:81]),axis=0)
        assert np.max(abs(ref[ind]-red[:81]))<1e-12
        table[:low,:81]=old['weyl'][:,ind]
    mismatch=0.
    for left,right,first in ((0,low,80),(low,len(modes),0)):
        for start in range(left,right,16):
            guard()
            part=slice(start,min(right,start+16))
            values=engine.get_time_evolution(modes[part],eta[first:][::-1],vars=['Weyl','a','mts_match_count','mts_nonheavy_change'],lAccuracyBoost=4)[:,::-1]
            assert np.isfinite(values).all() and np.all(values[:,:,2]==(case=='heavy')) and np.all(values[:,:,3]==0)
            assert np.max(abs(values[:,:,1]*(1+red[first:])-1))<2e-5
            if first:
                mismatch=max(mismatch,np.max(abs(values[:,0,0]/table[part,first]-1)))
                table[part,first+1:]=values[:,1:,0]
            else:table[part]=values[:,:,0]
    assert mismatch<2e-5 and np.all(table<0) and len(modes)==399
    packet(case+'.npz',k=modes,z=red,chi=chi,weyl=table,overlap=mismatch,initial=digest(init),retained=digest(bank))
    print(case,len(modes),len(red),mismatch,flush=True)


if __name__=='__main__':
    for name in sys.argv[1:]:main(name)
