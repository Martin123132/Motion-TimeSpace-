import csv
import sys
from common import ROOT,PRIOR,np,digest,json,guard,save
from project import design,sensitivity
from windows import EDGES


def main():
    guard()
    data=np.load(ROOT/'public-response.npz')
    fit=np.load(ROOT/'contractions.npz')
    result=json.loads((ROOT/'response.json').read_text())
    assert digest(ROOT/'public-response.npz')==json.loads((ROOT/'public-response.json').read_text())['output_sha256']
    for model in ('heavy','cold','lcdm'):
        assert digest(ROOT/(model+'.npz'))==result['histories'][model]['native_hash']
    heavy,cold,lcdm=(fit['signed_'+key] for key in ('heavy','cold','lcdm'))
    absolute=fit['absolute_cold']
    np.testing.assert_array_less(abs(cold),absolute*(1+1e-12)+1e-25)
    keep=fit['minimum_fraction'][-1,:,0]>=.9
    cov=fit['null_cov'][np.ix_(keep,keep)]
    ij=np.column_stack((data['row_BIN1'],data['row_BIN2']))-1
    weights=fit['weights']
    coeff=np.array([(1 if a==b else 2)*weights[a]*weights[b] for a,b in fit['pairs']])
    transform=np.kron(coeff[None,:],np.eye(8))
    assert np.max(abs(transform@data['cov']@transform.T-fit['null_cov']))<1e-20
    scores={}
    for model,control in (('cold',cold),('lcdm',lcdm)):
        nuisance=transform@design(control[:15,:,-1].ravel(),ij)
        scores[model]=sensitivity(heavy[-1,keep,-1],control[-1,keep,-1],nuisance[keep],cov)
    with (ROOT/'scale-coverage.csv').open('x',encoding='utf8',newline='') as out:
        writer=csv.writer(out)
        writer.writerow('pair_or_map band ell_min ell_max minimum_abs_share_k_le_0p1 minimum_abs_share_k_le_0p2 heavy_over_cold_minus_one heavy_over_lcdm_minus_one low_k_heavy_minus_cold_per_cold_full allowed_residual_fraction_of_cold_tail_at_break_even'.split())
        for idx,key in enumerate([str(a+1)+'x'+str(b+1) for a,b in fit['pairs']]+['weighted-high-three']):
            for band in range(8):
                tail=absolute[idx,band,-1]-absolute[idx,band,0]
                delta=heavy[idx,band,0]-cold[idx,band,0]
                assert tail>0
                writer.writerow((key,band+1,*EDGES[band:band+2],*fit['minimum_fraction'][idx,band,:2],heavy[idx,band,-1]/cold[idx,band,-1]-1,
                    heavy[idx,band,-1]/lcdm[idx,band,-1]-1,delta/cold[idx,band,-1],abs(delta)/tail))
    for name in ('NONLINEAR-SOURCE.md','stress-checks.json','harmonic-check.json','finite-contrast.json'):assert (ROOT/name).is_file()
    save('selected-bands.json',dict(eligible_before_unknown_tail=(np.flatnonzero(keep)+1).tolist(),distances=scores,cov=cov.tolist(),
        tail_fraction_needed_to_mask_lowk_signal=(abs((heavy-cold)[-1,keep,0])/(absolute[-1,keep,-1]-absolute[-1,keep,0])).tolist(),
        max_ordinary_fraction=float(np.max(fit['minimum_fraction'][:15,:,0])),measured_values_used=False))


def seal():
    guard()
    required=['PROTOCOL.md','SURVEY-NULL.md','RESULTS.md','selected-bands.json','scale-coverage.csv','finite-contrast.json']
    assert all((ROOT/key).is_file() for key in required)
    assert all(p.is_file() and '.partial' not in p.name for p in ROOT.iterdir())
    files={p.name:digest(p) for p in sorted(ROOT.iterdir())}
    save('closeout.json',dict(previous_seal=digest(PRIOR/'closeout.json'),files=files))
    assert all(digest(ROOT/key)==sig for key,sig in json.loads((ROOT/'closeout.json').read_text())['files'].items())
    print(len(files),digest(ROOT/'closeout.json'))


if __name__=='__main__':
    (seal if sys.argv[1:] == ['seal'] else main)()
