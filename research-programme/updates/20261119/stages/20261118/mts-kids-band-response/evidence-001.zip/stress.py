from common import ROOT,np,guard,digest,save


def exercise(count):
    coord=np.arange(count)*2*np.pi/count
    xx,yy=np.meshgrid(coord,coord,indexing='ij')
    modes=np.fft.fftfreq(count)*count
    wave=np.array(np.meshgrid(modes,modes,indexing='ij'))
    lap=-(wave**2).sum(axis=0)
    def derivative(field,mult):
        return np.fft.ifft2(mult*np.fft.fft2(field))
    def grad(field,axis):
        return derivative(field,1j*wave[axis])
    scale=.8;lam=.63
    def moments(fields,phi):
        phi=np.broadcast_to(phi,xx.shape)
        gradpsi=np.stack([grad(fields,axis) for axis in range(2)])
        density=(abs(fields)**2).sum(axis=0)
        current=lam*np.sum(fields.conj()*gradpsi,axis=1).imag
        dpsi=1j*(.5*lam*derivative(fields,lap)/scale**2-phi*fields/lam)
        dn=2*np.real(np.sum(fields.conj()*dpsi,axis=0))
        dj=lam*np.stack([(dpsi.conj()*gradpsi[axis]+fields.conj()*grad(dpsi,axis)).sum(axis=0).imag for axis in range(2)])
        flux=lam**2*np.array([[(gradpsi[i].conj()*gradpsi[j]).sum(axis=0).real-.25*derivative(density,-wave[i]*wave[j]).real for j in range(2)] for i in range(2)])
        dn_model=-sum(grad(current[i],i).real for i in range(2))/scale**2
        dj_model=np.array([-density*grad(phi,i).real-sum(grad(flux[i,j],j).real for j in range(2))/scale**2 for i in range(2)])
        assert np.max(abs(dn-dn_model))<1e-9 and np.max(abs(dj-dj_model))<1e-8
        return density,current,flux,-sum(grad(dj[i],i).real for i in range(2))/scale**2
    source=np.cos(2*xx+yy)+.6*np.cos(xx-2*yy)
    phi=.14*np.cos(xx)*np.sin(yy)
    amps=np.stack((np.sqrt(1+.06*source)*np.exp(.12j*np.sin(xx)),np.sqrt(.3+.04*np.cos(yy))*np.exp(-.13j*np.sin(xx+yy))))
    dens,cur,flux,acc=moments(amps,phi)
    rotated=np.einsum('ab,bij->aij',np.array([[1,1j],[1j,1]])/np.sqrt(2),amps)
    for original,other in zip((dens,cur,flux,acc),moments(rotated,phi)):assert np.max(abs(original-other))<1e-8
    dn=np.stack([grad(dens,i).real for i in range(2)])
    extra=flux-np.einsum('ixy,jxy->ijxy',cur,cur)/dens
    for i in range(2):
        for j in range(2):
            extra[i,j]-=.25*lam**2*(dn[i]*dn[j]/dens-derivative(dens,-wave[i]*wave[j]).real)
    assert np.min(np.linalg.eigvalsh(extra.transpose(2,3,0,1)))>-1e-11
    def force(eps):
        fields=np.sqrt(1+eps*source)[None,:,:].astype(complex)
        return moments(fields,0.)[3]
    linear=-.25*lam**2/scale**4*derivative(source,lap**2).real
    target=.25*lam**2/scale**4*sum(derivative(grad(source,i).real*grad(source,j).real,-wave[i]*wave[j]).real for i in range(2) for j in range(2))
    errors=[];linerr=[]
    for eps in (.02,.01,.005,.0025,.00125):
        plus,minus=force(eps),force(-eps)
        errors.append(float(np.max(abs((plus+minus)/(2*eps**2)-target))/np.max(abs(target))))
        linerr.append(float(np.max(abs((plus-minus)/(2*eps)-linear))/np.max(abs(linear))))
    assert errors[-1]<2e-5 and linerr[-1]<2e-5 and all(.18<b/a<.32 for a,b in zip(errors[:3],errors[1:4]))
    strength=.32
    pair=np.exp(1j*np.array([-1.,1.])[:,None,None]*strength*np.sin(xx)/lam)/np.sqrt(2)
    dens,cur,flux,acc=moments(pair,0.)
    expected=-2*strength**2*np.cos(2*xx)/scale**4
    assert np.max(abs(dens-1))<1e-14 and np.max(abs(cur))<1e-13 and np.max(abs(acc-expected))<1e-8
    assert np.max(abs(moments(np.ones_like(pair[:1]),0.)[3]))<1e-14
    def evolve(dt):
        wavefn=pair.copy()
        def potential(fields):
            contrast=(abs(fields)**2).sum(axis=0)-1
            return derivative(contrast,np.divide(.7,lap,out=np.zeros_like(lap),where=lap!=0)).real
        wavefn*=np.exp(-.5j*dt*potential(wavefn)/lam)
        wavefn=derivative(wavefn,np.exp(.5j*dt*lam*lap/scale**2))
        wavefn*=np.exp(-.5j*dt*potential(wavefn)/lam)
        return (abs(wavefn)**2).sum(axis=0)
    temporal=[float(np.max(abs((evolve(dt)+evolve(-dt)-2*dens)/dt**2-expected))/np.max(abs(expected))) for dt in (.02,.01,.005,.0025)]
    assert temporal[-1]<2e-5 and max(temporal[i+1]/temporal[i] for i in range(3))<.28
    return dict(quadratic_relative_error=errors,linear_relative_error=linerr,mixed_evolution_relative_error=temporal,extra_stress_peak=float(np.max(extra)))


def run():
    guard()
    base=ROOT.parent/'condensate-origin-20261003/resolved-matter-spectrum-20261007/runs'
    init=base/'projection/a225-w6-d8.npz';back=base/'heavy/background.npz'
    with np.load(init) as data:mass=float(data['heavy_mass_mpc']);abundance=float(data['matching_density'])
    with np.load(back) as data:
        scale=data['requested_scale'];scaled=data['cdm']+data['baryon']+abundance*scale
    assert np.ptp(scaled/scale)/scaled[-1]<2e-12
    budget={}
    for red in (0.,.51,1.,2.):
        index=np.argmin(abs(1/scale-1-red));assert abs(1/scale[index]-1-red)<1e-8
        kj=(2*scaled[index]*mass**2)**.25
        budget[str(red)]=dict(jeans_per_Mpc=kj,ratio_quadratic={str(k):2*(k/kj)**4 for k in (.1,.2,.5,1.,5.)})
    save('stress-checks.json',dict(background_hash=digest(back),initial_hash=digest(init),mass_per_Mpc=mass,
         jeans_probe=budget,witness={str(n):exercise(n) for n in (48,64)}))


if __name__=='__main__':run()
