from common import ROOT,PRIOR,np,guard,packet,save,digest
from windows import quadgrid,EDGES,leggauss,fourier_window
from scipy.interpolate import PchipInterpolator,RectBivariateSpline,CubicSpline
from scipy.linalg import solve_triangular

MODELS=('heavy','cold','lcdm')
CEIL=np.array([.1,.2,1.,5.])
AS=2.1e-9
NSM1=-.0347


class Sources:
    def __init__(self,data,z,chi,fine):
        self.distance=PchipInterpolator(z,chi,extrapolate=False)
        mids=data['Z_MID']
        knots=np.r_[0,mids[mids<4],4.]
        values=np.array([np.r_[0,data['BIN'+str(i)][mids<4],0] for i in range(1,6)])
        assert not any(np.any(data['BIN'+str(i)][mids>=4]) for i in range(1,6))
        self.raw_area=np.trapezoid(values,knots,axis=1)
        values=values/self.raw_area[:,None]
        edges=np.unique(np.r_[knots,np.linspace(0,4,fine+1)])
        edges=edges[np.r_[True,np.diff(edges)>1e-12]]
        loc,wt=quadgrid(edges,6)
        den=np.array([np.interp(loc,knots,row) for row in values])
        def above(integrand):
            cells=(integrand*wt).reshape(5,-1,6).sum(axis=2)
            return np.column_stack((np.cumsum(cells[:,::-1],axis=1)[:,::-1],np.zeros(5)))
        aa,bb=above(den),above(den/self.distance(loc))
        assert np.max(abs(aa[:,0]-1))<1e-12
        self.inv=bb[:,0].copy()
        eff=aa-bb*self.distance(edges)
        assert eff.min()>-1e-13
        self.chi=chi
        self.eff=PchipInterpolator(self.distance(edges),eff.T,extrapolate=False)
        self.knots=self.distance(knots)
        self.high_source=aa[:,np.argmin(abs(edges-2))]


def compressed_weights(inv):
    short=np.linalg.solve(np.array([[1.,1.],inv[2:4]]),[-1.,-inv[4]])
    weights=np.r_[0.,0.,short,1.]
    assert abs(weights.sum())<1e-12 and abs(weights@inv)<1e-14
    return weights


def spectra(item,source,weights,pairs,ells,order):
    modes,chi=item['k'],item['chi']
    spline=RectBivariateSpline(np.log(modes),chi,np.log(-item['weyl']))
    limits=np.unique(np.r_[0.,source.knots,chi,np.geomspace(1.,chi[-1],60)])
    nodes,wt=leggauss(order)
    outputs=[]
    for first in range(0,len(ells),24):
        degree=ells[first:first+24];nu=degree+.5
        split=np.minimum(chi[-1],nu[:,None]/CEIL)
        edges=np.sort(np.column_stack((np.broadcast_to(limits,(len(degree),len(limits))),split)),axis=1)
        lw=edges[:,:-1];half=np.diff(edges)*.5
        dist=lw[:,:,None]+half[:,:,None]*(1+nodes)
        width=half[:,:,None]*wt
        dist=dist.reshape(len(nu),-1);width=width.reshape(dist.shape)
        kk=nu[:,None]/np.maximum(dist,1e-12)
        ok=(kk<=5)&(width>0)
        assert np.min(kk)>modes[0] and modes[-1]>=5-1e-10
        weyl=np.zeros_like(dist)
        weyl[ok]=np.exp(spline.ev(np.log(kk[ok]),dist[ok]))
        scale=width*weyl**2*(2*np.pi**2*AS)*(kk/.05)**NSM1/kk**3
        eff=source.eff(dist)
        radial=np.stack([eff[:,:,a]*eff[:,:,b] for a,b in pairs]+[(eff@weights)**2],axis=2)
        out=np.stack([np.einsum('ij,ijp->ip',scale*(kk<=cut),radial) for cut in CEIL],axis=-1)
        outputs.append(out)
    return np.concatenate(outputs)


def design(raw,rows):
    return np.column_stack([raw*((rows[:,0]==ind).astype(int)+(rows[:,1]==ind)) for ind in range(5)])


def sensitivity(heavy,control,cal,cov):
    chol=np.linalg.cholesky(cov)
    residual=solve_triangular(chol,heavy-control,lower=True)
    white=solve_triangular(chol,cal,lower=True)
    basis,sv,_=np.linalg.svd(white,full_matrices=False)
    keep=sv>sv[0]*1e-10
    projected=residual-basis[:,keep]@(basis[:,keep].T@residual)
    return dict(fixed=float(np.linalg.norm(residual)),free_source_calibration=float(np.linalg.norm(projected)),rank=int(keep.sum()))


def contract(ell,wt,window,curves):
    norm=np.log(EDGES[1:]/EDGES[:-1])
    kern=(wt*ell)[:,None]*window/norm
    return np.einsum('lb,lpc->pbc',kern,curves),np.einsum('lb,lpc->pbc',abs(kern),curves)


def main():
    guard()
    data=np.load(ROOT/'public-response.npz');windows=np.load(ROOT/'windows.npz')
    ell,wt,we=(windows[k] for k in ('ell','weight','ee'))
    ij=np.column_stack([data['row_BIN1'],data['row_BIN2']]).astype(int)-1
    pairs=np.unique(ij,axis=0)
    assert len(pairs)==15 and len(ij)==120 and np.all(ij==np.repeat(pairs,8,axis=0))
    assert np.array_equal(data['row_ANGBIN'],np.tile(np.arange(1,9),15))
    assert np.max(abs(data['row_ANG']/np.tile(np.sqrt(EDGES[1:]*EDGES[:-1]),15)-1))<1e-8
    cov=data['cov'];sky=np.geomspace(2.,1e4,801)
    altell,altwt=quadgrid(np.unique(np.r_[2.,np.arange(10.,1e4,20.),EDGES,1e4]),3)
    altwindow=fourier_window(altell,12,80)[0]
    winerr={};powers={};absolutes={};whole={};native={};floors={};rec={}
    for model in MODELS:
        with np.load(ROOT/(model+'.npz')) as file:item={k:file[k] for k in ('k','z','chi','weyl')}
        assert np.isfinite(item['weyl']).all() and np.all(item['weyl']<0)
        src=Sources(data,item['z'],item['chi'],1600)
        if model=='heavy':
            weights=compressed_weights(src.inv)
            pair_factor=np.array([(1 if a==b else 2)*weights[a]*weights[b] for a,b in pairs])
            transform=np.kron(pair_factor[None,:],np.eye(8))
            nullcov=transform@cov@transform.T
            np.linalg.cholesky(nullcov)
        fine=spectra(item,src,weights,pairs,sky,9)
        coarse=spectra(item,Sources(data,item['z'],item['chi'],800),weights,pairs,sky[::8],5)
        control=np.max(abs(coarse-fine[::8]),axis=0)/np.maximum(np.max(fine[::8],axis=0),1e-30)
        assert np.all(fine>=0) and np.all(np.diff(fine,axis=-1)>=-1e-23)
        assert np.max(abs(np.einsum('p,lpc->lc',pair_factor,fine[:,:15])-fine[:,15]))<1e-20
        def interp(knots,at):
            return CubicSpline(np.log(sky[::knots]),fine[::knots],axis=0)(np.log(at))
        curves=interp(1,ell)
        power,absolute=contract(ell,wt,we,curves)
        alt=contract(altell,altwt,altwindow,interp(1,altell))[0]
        half=contract(ell,wt,we,interp(2,ell))[0]
        angular=abs((alt-power)/absolute[:,:,-1,None]).max()
        knot=abs((half-power)/absolute[:,:,-1,None]).max()
        protect=abs((np.einsum('p,pbc->bc',pair_factor,power[:15])-power[15])/absolute[15,:,-1,None]).max()
        print(model,'quadrature / multipole sampling / map linearity / radial',angular,knot,protect,np.max(control),flush=True)
        assert max(angular,knot,protect,np.max(control))<2e-5
        spin=(ell+2)*(ell+1)*ell*(ell-1)/(ell+.5)**4
        spinshift=contract(ell,wt,we,curves*spin[:,None,None])[0]-power
        lows=contract(ell,wt,we,curves*(ell<30)[:,None,None])[1]
        winerr[model]=dict(alt_ell_quadrature=float(angular),coarse_ell_interpolant=float(knot),direct_vs_pair_null=float(protect),
               radial_refinement_peak_units=float(np.max(control)),spin_factor_max_fraction=float(np.max(abs(spinshift[:,:,-1])/absolute[:,:,-1])),
               ell_lt30_absolute_max_fraction=float(np.max(lows[:,:,-1]/absolute[:,:,-1])))
        powers[model]=power
        absolutes[model]=absolute
        whole[model]=power[:15,:,-1].ravel()
        rec[model]=dict(source_fraction_z_gt2=src.high_source.tolist(),inv_source_distance=src.inv.tolist(),raw_source_area=src.raw_area.tolist(),native_hash=digest(ROOT/(model+'.npz')))
        native[model]=fine
    distances={}
    for model in ('cold','lcdm'):
        nuisance=design(whole[model],ij)
        distances[model]=dict(raw=sensitivity(whole['heavy'],whole[model],nuisance,cov),
                              null=sensitivity(transform@whole['heavy'],transform@whole[model],transform@nuisance,nullcov))
    coverage=np.min(np.stack([absolutes[model][:,:,:-1]/absolutes[model][:,:,-1,None] for model in MODELS]),axis=0)
    packet('contractions.npz',**{'signed_'+key:val for key,val in powers.items()},**{'absolute_'+key:val for key,val in absolutes.items()},
           **{'spectrum_'+key:val for key,val in native.items()},ell=sky,ceilings=CEIL,pairs=pairs,weights=weights,minimum_fraction=coverage,null_cov=nullcov)
    save('response.json',dict(foreground_weights=weights.tolist(),checks=winerr,histories=rec,
        native_cov_distances=distances,raw_eligible=int((coverage[:15,:,0]>=.9).sum()),null_eligible=int((coverage[15,:,0]>=.9).sum()),
        domain='Linear metric and gravitational shear only; normalized over k<=5/Mpc, ell=2..10000, true source redshift<=4. Uncomputed UV not bounded.'))
    print('necessary 90% coverage count raw, null:',(coverage[:15,:,0]>=.9).sum(),(coverage[15,:,0]>=.9).sum(), 'best',coverage[:15,:,0].max(),coverage[15,:,0].max())


if __name__=='__main__':main()
