from common import ROOT,guard,save,json
import mpmath as mp


def response(jeans,k,eps):
    lam=2*(k/jeans)**2
    def field(x):return mp.sqrt(1+eps*mp.cos(x))
    def ham(fun,x):return -lam**2/2*mp.diff(fun,x,2)-eps*mp.cos(x)*fun(x)
    def first(x):return ham(field,x)
    acc=[]
    for index in range(40):
        x=2*mp.pi*index/40
        heavy=2*(first(x)**2-field(x)*ham(first,x))/lam**2
        cold=eps*mp.cos(x)+eps**2*mp.cos(2*x)
        acc.append((heavy-cold)*mp.cos(2*x)/20)
    expected=2*(k/jeans)**4
    return float(mp.fsum(acc)/eps**2/expected-1)


def main():
    guard()
    mp.mp.dps=50
    stored=json.loads((ROOT/'stress-checks.json').read_text())['jeans_probe']
    table={}
    for z in ('0.0','1.0'):
        kj=mp.mpf(str(stored[z]['jeans_per_Mpc']))
        for kval in ('.1','.5','1','5'):
            err=[response(kj,mp.mpf(kval),mp.mpf(eps)) for eps in ('.02','.01','.005')]
            assert abs(err[-1])<2e-5
            predicted=[-eps**4/16 for eps in (.02,.01,.005)]
            assert all(abs(value/lead-1)<2*eps**2 for value,lead,eps in zip(err,predicted,(.02,.01,.005)))
            table[z+':'+kval]=err
    save('harmonic-check.json',dict(method='50-digit direct n double time derivative from the wave Hamiltonian, common self-gravity force, cosine projection minus cold dust.',relative_to_leading_coefficient=table))


if __name__=='__main__':main()
