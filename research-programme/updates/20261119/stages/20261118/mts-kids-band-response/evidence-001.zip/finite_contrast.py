from common import ROOT,guard,save,json
import mpmath as mp


def main():
    guard();mp.mp.dps=50
    jeans=mp.mpf(str(json.loads((ROOT/'stress-checks.json').read_text())['jeans_probe']['0.0']['jeans_per_Mpc']))
    lam=2*(mp.mpf('.5')/jeans)**2
    audit={}
    for contrast in ('.05','.3','.6','.9'):
        eps=mp.mpf(contrast);root=mp.sqrt(1-eps**2);ratio=-eps/(1+root)
        def field(x):return mp.sqrt(1+eps*mp.cos(x))
        def ham(fun,x):return -lam**2/2*mp.diff(fun,x,2)-eps*mp.cos(x)*fun(x)
        def hpsi(x):return ham(field,x)
        xx=[2*mp.pi*i/160 for i in range(160)];vals=[]
        for x in xx:
            total=2*(hpsi(x)**2-field(x)*ham(hpsi,x))/lam**2
            dust=eps*mp.cos(x)+eps**2*mp.cos(2*x)
            vals.append(total-dust)
        measured=[2*mp.fsum(v*mp.cos(n*x) for v,x in zip(vals,xx))/len(xx) for n in range(1,7)]
        law=[lam**2*n**2*root*ratio**n/2 for n in range(1,7)]
        errors=[float(abs(val/ref-1)) for val,ref in zip(measured,law)]
        assert max(errors)<2e-5 and abs(mp.fsum(vals)/len(vals))<mp.mpf('1e-22')
        audit[contrast]=dict(second_harmonic_over_small_contrast=float(4*root/(1+root)**2),mode_1_to_6_relative_errors=errors)
    save('finite-contrast.json',dict(k_per_Mpc=.5,preparation='single initially stationary comoving cosine, shared gravity subtracted',cases=audit))


if __name__=='__main__':main()
