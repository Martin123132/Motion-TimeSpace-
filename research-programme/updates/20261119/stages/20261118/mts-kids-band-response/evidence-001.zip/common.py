from pathlib import Path
import hashlib
import json
import os

for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[key]='1'
import numpy as np

ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-uchuu-slip-transfer-20261118'


def digest(path):
    with path.open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()


def guard():
    assert digest(PRIOR/'closeout.json')=='901073016cee1b54b9660d66d73678d6765975f0b8693389e9b26b05c38f2f2f'
    assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT,ROOT.parent,PRIOR))


def packet(name,**values):
    with (ROOT/name).open('xb') as stream:
        np.savez(stream,**values)


def save(name,values):
    with (ROOT/name).open('x',encoding='utf8') as stream:
        json.dump(values,stream,indent=2,allow_nan=False)
