from common import ROOT,np,guard,packet,save
from numpy.polynomial.legendre import leggauss
from scipy.special import jv

EDGES=np.geomspace(100,1500,9)
ARCMIN=np.pi/(180*60)
LOW,HIGH=.5*ARCMIN,300*ARCMIN
TAPER=.5


def quadgrid(edges,order):
    nodes,weights=leggauss(order)
    mid=(edges[1:]+edges[:-1])*.5
    width=np.diff(edges)*.5
    return (mid[:,None]+width[:,None]*nodes).ravel(),(width[:,None]*weights).ravel()


def fourier_window(ell,order,panels,bands=range(8)):
    corners=np.array([LOW*np.exp(-TAPER/2),LOW*np.exp(TAPER/2),HIGH*np.exp(-TAPER/2),HIGH*np.exp(TAPER/2)])
    theta,weight=quadgrid(np.unique(np.r_[corners,np.linspace(corners[0],corners[-1],panels+1)]),order)
    tap=np.ones(len(theta))
    for outer,inner,mask in ((corners[0],corners[1],theta<corners[1]),(corners[3],corners[2],theta>corners[2])):
        tap[mask]=np.sin(.5*np.pi*np.log(theta[mask]/outer)/np.log(inner/outer))**2
    out=[]
    for beta in (0,4):
        kernels=[]
        for band in bands:
            ref,refwt=quadgrid(EDGES[band:band+2],48)
            kernels.append((jv(beta,theta[:,None]*ref)@(refwt*ref))*weight*theta*tap)
        kernels=np.array(kernels).T
        chunks=[jv(beta,ell[start:start+160,None]*theta)@kernels for start in range(0,len(ell),160)]
        out.append(np.vstack(chunks))
    return .5*(out[0]+out[1]),.5*(out[0]-out[1])


def run():
    guard()
    with np.load(ROOT/'public-response.npz') as data:fixture=data['fixture']
    use=fixture[::4]
    ee,eb=fourier_window(use[:,0],12,80,[0])
    errors=[float(np.max(abs(out.ravel()-use[:,col]))) for col,out in ((2,ee),(3,eb))]
    print('public filter residuals (absolute, peak ~1):',errors,flush=True)
    check=np.geomspace(2,9999,90)
    coarse=fourier_window(check,12,80);fine=fourier_window(check,16,120)
    internal=max(np.max(abs(a-b)) for a,b in zip(coarse,fine))
    assert internal<2e-5 and max(errors)<.002
    boundaries=np.unique(np.r_[2.,np.arange(10.,10000.,20.),EDGES,10000.])
    ell,weight=quadgrid(boundaries,5)
    ee,eb=fourier_window(ell,12,80)
    packet('windows.npz',ell=ell,weight=weight,ee=ee,eb=eb,edges=EDGES)
    save('filter-check.json',dict(public_reference_ee_eb_max_abs=errors,max_internal_abs=float(internal),source_samples=len(use),
        interpretation='Signed E/B estimator windows reconstructed from KCAP settings; reference independently tabulated only in first band at ell<=1000.'))


if __name__=='__main__':run()
