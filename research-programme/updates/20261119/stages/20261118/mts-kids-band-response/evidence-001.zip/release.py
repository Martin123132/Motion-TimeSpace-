from common import ROOT, np, guard, packet, save, digest
import configparser
import hashlib
import io
import math
import re
import tarfile
import requests

ARCHIVE='https://kids.strw.leidenuniv.nl/DR4/data_files/KiDS1000_cosmic_shear_data_release.tgz'
KCAP='https://raw.githubusercontent.com/KiDS-WL/kcap/36b40c55394caf26021408e71ff74538bfa3d51e/cosebis/'
REFERENCE='Benjamins_Bandpower/bandpower_filter_output_0_100.0_140.29.dat'


def headers(blob):
    start=0
    while start<len(blob):
        header={}; pos=start
        while True:
            card=blob[pos:pos+80].decode('ascii');pos+=80
            if card.startswith('END     '):break
            if card[8:10]=='= ':
                key=card[:8].strip()
                raw=card[10:].strip()
                header[key]=raw.split("'")[1].strip() if raw.startswith("'") else raw.split('/')[0].strip()
        pos=start+2880*math.ceil((pos-start)/2880)
        dims=[int(header['NAXIS'+str(i+1)]) for i in range(int(header['NAXIS']))]
        size=(math.prod(dims) if dims else 0)*abs(int(header['BITPIX']))//8
        size+=int(header.get('PCOUNT',0))
        assert int(header.get('GCOUNT',1))==1 and size>=0
        yield header,pos
        start=pos+2880*math.ceil(size/2880)
    assert start==len(blob)


def column(blob,entry,name):
    header,base=entry
    ext=header['EXTNAME'].upper()
    assert (ext.startswith('NZ_') and re.fullmatch(r'Z_LOW|Z_MID|Z_HIGH|BIN[1-5]',name)) or (ext=='PEEE' and name in ('BIN1','BIN2','ANGBIN','ANG'))
    offset=0
    for idx in range(1,int(header['TFIELDS'])+1):
        form=header[f'TFORM{idx}']
        repeat,code=re.fullmatch(r'(\d*)([DEJKI])',form).groups()
        assert not repeat or repeat=='1'
        dtype=np.dtype({'D':'>f8','E':'>f4','J':'>i4','K':'>i8','I':'>i2'}[code])
        if name==header[f'TTYPE{idx}']:
            return np.ndarray((int(header['NAXIS2']),),dtype,buffer=blob,offset=base+offset,strides=(int(header['NAXIS1']),)).astype(dtype.newbyteorder('='))
        offset+=dtype.itemsize
    raise KeyError(name)


def run():
    guard()
    def get(url):
        resp=requests.get(url,timeout=60);resp.raise_for_status();assert len(resp.content)<25_000_000
        return resp.content
    archive=get(ARCHIVE)
    with tarfile.open(fileobj=io.BytesIO(archive)) as handle:
        name=next(n for n in handle.getnames() if '/data_fits/bp_' in n and n.endswith('.fits'))
        data=handle.extractfile(name).read()
        config=next(n for n in handle.getnames() if '/bp/config/pipeline.ini' in n)
        raw=handle.extractfile(config).read()
    parts={h.get('EXTNAME','PRIMARY').upper():(h,pos) for h,pos in headers(data)}
    print({ext:(h.get('NAXIS1'),h.get('NAXIS2'),[h[k] for k in h if k.startswith('TTYPE')]) for ext,(h,pos) in parts.items()})
    cfg=configparser.ConfigParser(interpolation=None,strict=False)
    cfg.read_string(raw.decode())
    section=dict(cfg['bandpower_shear_e'])
    assert tuple(float(section[k]) for k in ('l_min','l_max','nbands','delta_x','theta_min','theta_max','apodise'))==(100.,1500.,8.,.5,.5,300.,1.)
    assert section['type']=='cosmic_shear_e' and section['response_function_type']=='tophat'
    nz=next(entry for key,entry in parts.items() if key.startswith('NZ_') and 'SOURCE' in key)
    arrays={key:column(data,nz,key) for key in ('Z_LOW','Z_MID','Z_HIGH',*[f'BIN{i}' for i in range(1,6)])}
    meta={key:column(data,parts['PEEE'],key) for key in ('BIN1','BIN2','ANGBIN','ANG')}
    cov,base=parts['COVMAT']
    assert cov['BITPIX']=='-64' and cov['NAXIS1']==cov['NAXIS2']
    total=int(cov['NAXIS1'])
    start=next(int(cov[k.replace('NAME','STRT')]) for k in cov if k.startswith('NAME') and cov[k].upper()=='PEEE')
    matrix=np.ndarray((total,total),dtype='>f8',buffer=data,offset=base)[start:start+120,start:start+120].astype(float)
    assert len(meta['ANG'])==120 and np.allclose(matrix,matrix.T,rtol=1e-10,atol=0)
    np.linalg.cholesky(matrix)
    try:column(data,parts['PEEE'],'VALUE')
    except AssertionError:pass
    else:raise AssertionError('science value readable')
    assert all(np.isfinite(a).all() for a in [*arrays.values(),*meta.values(),matrix])
    fixture=get(KCAP+REFERENCE)
    packet('public-response.npz',cov=matrix,fixture=np.loadtxt(io.BytesIO(fixture)),**arrays,**{'row_'+k:v for k,v in meta.items()})
    save('public-response.json',dict(url=ARCHIVE,archive_sha256=hashlib.sha256(archive).hexdigest(),bytes=len(archive),
        member=name,member_sha256=hashlib.sha256(data).hexdigest(),pipeline=config,settings=section,
        reference=KCAP+REFERENCE,reference_sha256=hashlib.sha256(fixture).hexdigest(),
        ext=list(parts),covariance_header=cov,allowed_columns=list(arrays),row_coordinates=list(meta),
        output_sha256=digest(ROOT/'public-response.npz'),measured_value_decoded=False,chains_read=False))


if __name__=='__main__':run()
