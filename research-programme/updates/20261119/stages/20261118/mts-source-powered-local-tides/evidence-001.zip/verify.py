from common import *
from rulers import ARMS, read, measurement
from exterior import initial_mass
import ast


def rows(file):
    with (HOME/file).open(encoding="utf8",newline="") as stream:return list(csv.DictReader(stream))


def main():
    guard()
    checks={}
    def test(name,passed):
        checks[name]=bool(passed)
        if not checks[name]:raise AssertionError(name)
    parent_files={}
    def link(folder,name):
        path=source(folder,name)
        parent_files[folder.name+"/"+name]=sha(path)
    for name in ("fine.npz","checkgrid.npz","outgoing.py","GRAVITY-AT-INFINITY.md","bondi_loss.csv"):link(ESC,name)
    for name in ("current_source.py","static_modes.py","stationary_moments.csv","EQUATIONS.md"):link(SRC,name)
    link(CH,"charged.py")
    for mesh in (960,1920):
        for eta,amp in ARMS+(((0.,0.),) if mesh==1920 else ()):
            link(CH,f"charged-{mesh}-eta{eta:g}-h{amp:g}-b1.npz")
            for spin in ((0,1) if eta==1 else (0,)):
                link(SRC,f"driven-{mesh}-eta{eta:g}-h{amp:g}-spin{spin}.npz")
    test("all stage modules compile",all(compile(path.read_text(encoding="utf8"),str(path),"exec") for path in HOME.glob("*.py")))
    exact=json.loads((HOME/"exact.json").read_text())
    test("algebra: 12 checked identities",len(exact)==12 and all(exact.values()))
    for rec in rows("kerr_newman.csv"):
        test(f"exact exterior {rec['charge']} {rec['BL_radius']} {rec['channel']}",
             max(float(rec["relative_miss"]),float(rec["extraction_change"]))<TOL)
    shell=rows("static_checks.csv")
    for rec in shell:
        test(f"static mass and genuine angular curvature {rec['mesh']} {rec['spin']} {rec['radius']}",
             max(float(rec[key]) for key in ("mass_flux_error","angular_curvature_error","trace_error"))<TOL)
    test("raw metric differentiation misses recorded",any(float(rec["radial_curvature_error"])>TOL for rec in shell))
    for rec in rows("local_curvature.csv"):
        if rec["mesh"]=="1920":test("local metric radial "+rec["spin"]+" "+rec["radius"],float(rec["error"])<TOL)
    for rec in rows("source_controls.csv"):test(rec["test"],float(rec["error"])<TOL)
    sizes=rows("higher_ruler_mesh.csv")
    test("entire comparison matrix present",len(sizes)==72 and len({tuple(rec[key] for key in ("eta","amp","comparison","radius","channel")) for rec in sizes})==72)
    for rec in sizes:
        test("clock mesh "+" ".join(rec[key] for key in ("eta","amp","comparison","channel","radius")),float(rec["mesh_error"])<TOL)
    test("coarse derivative misses retained",sum(float(rec["mesh_error"])>=TOL for rec in rows("ruler_mesh.csv"))==13)
    test("raw interior mass drift retained",max(float(rec["inner_error"]) for rec in rows("mass_audit.csv") if rec["scheme"]=="coupled")>1)
    test("inner finite residual remains identified",max(float(rec["inner_error"]) for rec in rows("higher_mass_audit.csv") if rec["mesh"]=="1920")>TOL)
    for rec in rows("higher_paired_controls.csv"):
        test("physical trace and mass continuity "+" ".join(rec[key] for key in ("eta","amp","comparison","site")),
             max(float(rec[key]) for key in ("trace_error","paired_flux_error"))<TOL)
    for rec in rows("proper_scalar.csv"):
        test("proper scalar waveform "+" ".join(rec[key] for key in ("mesh","amp","site")),
             max(float(rec[key]) for key in ("independent_error","scalar_only_error","mesh_change"))<TOL)
    test("mixed interpolant false residual retained",max(float(rec["mixed_interpolant_error"]) for rec in rows("proper_scalar.csv"))>TOL)
    test("Ricci channels independently reproduce curvature",max(float(rec["independent_error"]) for rec in rows("ricci_components.csv"))<TOL)
    for spin in ("0","1"):
        far=[rec for rec in rows("near_far.csv") if rec["grid"]=="fine" and rec["spin"]==spin]
        sealed=list(csv.DictReader((ESC/"bondi_loss.csv").read_text().splitlines()))[int(spin)]
        energy=float(sealed["reduced_mass_loss"])
        test("source has available energy and loses mass "+spin,energy<0 and initial_mass(int(spin))>abs(energy))
        test("near-far sign and cutoff "+spin,all(float(rec["signed_measured_at_peak"])<0 and float(rec["mesh_error"])<TOL and abs(float(rec["end_ratio"])-1)<TOL for rec in far))
        test("induction correction required and passes "+spin,all(float(rec["corrected_error"])<TOL<float(rec["raw_error"]) for rec in far if int(rec["radius"])>=112))
    compare={}
    for eta,amp in ARMS:
        for mesh in (960,1920):
            data=read("higher",mesh,eta,amp);out=measurement(data)
            test(f"no baryons lost {mesh} {eta} {amp}",np.max(abs(data["budget"][:,1]))<1e-20)
            test(f"no scalar null invented {mesh} {eta} {amp}",(peak(data["delta_final"][0])>0)==(amp>0))
            test(f"physical clock and shapes {mesh} {eta} {amp}",np.all(np.diff(out["tau"],axis=0)>0) and data["delta_final"].shape==(4,mesh+1) and np.isfinite(data["delta"]).all())
            compare[mesh,eta,amp]=out
    for rec in sizes:
        eta=float(rec["eta"]);amp=float(rec["amp"]);site=(5.5,6.,7.).index(float(rec["radius"]));name=rec["channel"]
        reference=compare[1920,eta,amp][name][:,site]
        if rec["comparison"]=="difference":reference=reference-compare[1920,.8,0.][name][:,site]
        assert abs(peak(reference)-float(rec["peak"]))<1.e-12*max(peak(reference),1.e-27)
    test("published peaks recomputed on original clocks",True)
    test("no bytecode directory",not (HOME/"__pycache__").exists())
    files={path.name:sha(path) for path in sorted(HOME.iterdir()) if path.is_file() and path.name!="closeout.json"}
    receipt=dict(checks=checks,files=files,inputs=parent_files,predecessor=LOCK)
    target=HOME/"closeout.json"
    if "--seal" in sys.argv:
        with target.open("x",encoding="utf8") as stream:json.dump(receipt,stream,sort_keys=True,indent=2)
    if target.exists():assert json.loads(target.read_text())==receipt
    print(len(checks),"checks;",len(files),"files;",len(parent_files),"parent inputs")
    if target.exists():print(sha(target))


if __name__=="__main__":main()

