from common import *
sys.path.insert(0,str(CH))
from charged import Charged, filename
from scipy.interpolate import CubicSpline
from conserved import Primitive, conservative_mass
import higher

EPS=1.e-24
SITES=np.array([5.5,6.,7.])


class Averaged:
    def __init__(self,mesh,eta,amp,variant=0,conserved=False):
        self.grid=Charged(mesh,eta)
        self.mesh=mesh
        self.eta=eta
        self.amp=amp
        self.variant=variant
        self.conserved=conserved
        self.high=conserved=="higher"
        self.primitive=Primitive(self.grid) if conserved else self.grid.integral
        self.path=source(CH,filename(mesh,eta,amp))
        self.r=self.grid.r
        self.inv=self.grid.inv
        self.sel=[np.flatnonzero(self.r==site).item() for site in SITES]
        with np.load(source(SRC,f"driven-{mesh}-eta{eta:g}-h{amp:g}-spin{variant}.npz")) as wave:
            self.times=wave["time"]
            fields=wave["fields"]
            self.length=len(wave["radius"])
            assert np.array_equal(self.r[:self.length],wave["radius"])
            self.wave=CubicSpline(self.times,fields,axis=0)
        self.pad=np.zeros((3,len(self.r)))
    def field(self,time):
        self.pad[:,:self.length]=self.wave(time)
        return self.pad.copy()
    def first(self,field,parity):
        if not self.high:return self.grid.first(field,parity)
        return self.grid.first(field.real,parity)+1j*higher.first(self.grid,field.imag,parity)
    def second(self,field):
        if not self.high:return self.grid.second(field)
        return self.grid.second(field.real)+1j*higher.second(self.grid,field.imag)
    def rhs(self,state,wave,order,observe=False):
        grid=self.grid
        rad,inv=self.r,self.inv
        scalar,mom,density,flow=state
        grad=self.first(scalar,1)
        if self.conserved:
            enclosed_density=density.imag
            density=density.real+1j*(3*enclosed_density+rad*(higher.first(grid,enclosed_density,1) if self.high else grid.first(enclosed_density,1)))
            label=grid.integral(rad**2*density.real)+1j*rad**3*enclosed_density
        else:
            label=grid.integral(rad**2*density)
        charge=self.eta*label
        law,enclosed=spin(label.real,self.variant)
        self.law,self.inside=law,enclosed
        val,pm,xr=wave
        mech=law-self.eta*val
        twist=charge.real*val-enclosed
        coeff=NORM*order
        cyl=2*twist**2*inv**4
        ang_sq=mech**2*inv**2
        kinetic=(pm**2+xr**2)/2
        potential=val**2*inv**2+cyl
        scalar_kin=(mom**2+grad**2)/2
        scalar_pot=scalar**2/2
        factor=np.ones_like(scalar)
        for loop in range(7):
            lor=np.sqrt(1+factor*flow**2+coeff*ang_sq)
            dust=density*np.sqrt(factor)*lor
            scalar_en=scalar_kin*factor+scalar_pot
            mass=grid.integral(rad**2*(dust+scalar_en)+self.eta*rad*density*charge+coeff*(factor*kinetic+potential))-charge**2*inv/2
            factor=1-2*mass*inv
        if self.conserved:
            mass=mass.real+1j*conservative_mass(self,state,label,mass.real,wave,order)
            factor=1-2*mass*inv
            lor=np.sqrt(1+factor*flow**2+coeff*ang_sq)
            dust=density*np.sqrt(factor)*lor
            scalar_en=scalar_kin*factor+scalar_pot
        root=np.sqrt(factor)
        speed=flow*root/lor
        electric=charge**2*inv**4/2
        energy=dust+scalar_en+electric+coeff*inv**2*(factor*kinetic+potential)
        pressure=dust*speed**2+scalar_en-2*scalar_pot-electric+coeff*inv**2*(factor*kinetic-potential)
        tangential=(mom**2-grad**2)*factor/2-scalar_pot+electric+coeff*(density*root*ang_sq/(2*lor)+val**2*inv**4+4*twist**2*inv**6)
        current=density*flow*factor-mom*grad*factor-coeff*factor*pm*xr*inv**2
        slope=(mass*inv**2+rad*pressure)/factor
        logs=(rad*energy-mass*inv**2)/factor
        integ=grid.integral(rad*(density*lor/root*(1+speed**2)+2*scalar_kin)+2*coeff*kinetic*inv)
        exponent=integ-integ[-1]
        if self.conserved:
            integrand=rad*(density*lor/root*(1+speed**2)+2*scalar_kin)+2*coeff*kinetic*inv
            exponent=exponent.real-1j*self.primitive(integrand.imag[::-1])[::-1]
        lapse=np.exp(exponent)
        alpha=lapse*root
        bridge=lapse*factor
        drift=bridge*speed
        angular_force=alpha*(mech**2*inv**3+self.eta*mech*xr*inv**2)/lor-4*lapse*mech*twist*inv**4
        dflow=-alpha*lor*(slope-speed**2*logs)+self.eta*lapse*charge*inv**2-drift*self.first(flow,-1)+coeff*angular_force
        curvature=self.second(scalar)
        lap=curvature+2*inv*grad
        lap[0]=3*curvature[0]
        flux=density*drift
        div=grid.first(flux,-1)+2*inv*flux
        div[0]=3*grid.first(flux,-1)[0]
        if self.conserved:
            dnum=flux.imag*inv
            dnum[0]=(higher.first(grid,flux.imag,-1) if self.high else grid.first(flux.imag,-1))[0]
            div=div.real+1j*dnum
        rhs=np.stack([bridge*mom,bridge*(lap+(slope-logs)*grad)-lapse*scalar,-div,dflow])
        if not observe:return rhs
        twist_norm=16*coeff*twist**2*inv**6
        radial=energy-pressure+2*tangential-2*mass*inv**3-.75*twist_norm
        angular=mass*inv**3+pressure+twist_norm/8
        trace=density*root*(2*lor-1/lor)+2*factor*mom**2-scalar**2+2*electric+coeff*(2*factor*kinetic*inv**2+2*val**2*inv**4)
        scalartrace=2*factor*mom**2-scalar**2
        scalar_k=factor*(mom**2-grad**2)
        local_r=scalar_k+4*coeff*val**2*inv**4
        local_t=pressure-coeff*(-2*twist**2*inv**6)
        rate=-rad**2*bridge*current
        projection=np.stack([mass,rate,lapse,radial,angular,trace,scalartrace,local_r,local_t,charge,scalar,mom,factor,density])
        return rhs,projection[:,self.sel],np.array([mass[-1],label[-1]]),rad**2*energy


def run(mesh,eta,amp,variant=0,conserved=False):
    guard()
    model=Averaged(mesh,eta,amp,variant,conserved)
    with np.load(model.path) as old:
        initial=old["initial"];final=old["final"]
    state=initial.astype(complex)
    steps=int(np.ceil(6.5/(.26*model.grid.step)/256))*256
    dt=6.5/steps
    saved=[];background=[];budgets=[];from_outside=[]
    moment=1j*EPS
    for tick in range(steps+1):
        if tick%256==0:guard()
        now=tick*dt
        first_wave=model.field(now)
        if tick%(steps//256)==0:
            first,read,budget,energy=model.rhs(state,first_wave,moment,True)
            saved.append(read.imag/EPS);background.append(read.real);budgets.append(budget.imag/EPS)
            if not from_outside:
                adm=budget.imag[0]/EPS
                initial_tail=energy.imag/EPS
            difference=(energy.imag/EPS-initial_tail)
            primitive=model.primitive(difference[::-1])[::-1]
            from_outside.append(-primitive[model.sel])
        else:first=model.rhs(state,first_wave,moment)
        if tick==steps:break
        midwave=model.field(now+dt/2)
        second=model.rhs(state+dt/2*first,midwave,moment)
        third=model.rhs(state+dt/2*second,midwave,moment)
        fourth=model.rhs(state+dt*third,model.field(now+dt),moment)
        state+=dt/6*(first+2*second+2*third+fourth)
    end_checks=np.max(abs(state.real-final),axis=1)
    total_peaks=np.max(abs(final),axis=1)
    nulls=np.array([amp==0,amp==0,False,eta==1 and amp==0])
    assert np.isfinite(state).all() and np.all(end_checks[nulls]<64*np.finfo(float).eps)
    assert np.all(end_checks[~nulls]<2.e-7*total_peaks[~nulls]),(end_checks,total_peaks)
    prefix="higher" if model.high else ("conserved" if conserved else "coupled")
    archive(f"{prefix}-{mesh}-eta{eta:g}-h{amp:g}-s{variant}.npz",time=np.linspace(0,6.5,257),radius=SITES,
            delta=saved,base=background,budget=budgets,exterior_dm=from_outside,delta_final=state.imag/EPS,
            real_endpoint_error=end_checks,real_endpoint_peak=total_peaks,initial_adm=adm,
            labels=["mass","mass_rate","F","radial","angular","trace","scalar_trace","local_r","local_t","charge","h","Pi","f","D"])
    print(mesh,eta,amp,variant, "real endpoint", end_checks, "initial ADM",adm,flush=True)


if __name__=="__main__":
    if sys.argv[1] in ("group","repair"):
        for mesh in (960,1920):
            for eta,amp,variant in ((1.,0.,0),(.8,0.,0),(.8,1/160,0),(.8,1.,0)):
                run(mesh,eta,amp,variant,sys.argv[1]=="repair")
    elif sys.argv[1]=="higher":
        for mesh in (960,1920):
            for eta,amp in ((1.,0.),(.8,0.),(.8,1/160),(.8,1.)):
                run(mesh,eta,amp,0,"higher")
    else:run(int(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]),int(sys.argv[4]),"higher" if "--higher" in sys.argv else False)

