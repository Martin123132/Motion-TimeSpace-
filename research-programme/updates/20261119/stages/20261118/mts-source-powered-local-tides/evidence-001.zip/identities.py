from common import HOME, guard, json
import sympy as sp


def main():
    guard()
    checks={}
    def check(key,expr):
        if sp.factor(expr)!=0:raise ArithmeticError((key,expr))
        checks[key]=True
    time,rad,theta,angle=coords=sp.symbols("time rad theta phi",real=True)
    size,rate=sp.symbols("size rate",positive=True)
    metric=sp.diag(-1,1,1,size**2)
    metric[0,0]+=size**2*rate**2*rad**2
    metric[0,3]=metric[3,0]=-size**2*rate*rad
    at=lambda exp:exp.subs(rad,0)
    inverse=metric.subs(rad,0).inv()
    def gamma(low,first,second):
        return at((metric[low,second].diff(coords[first])+metric[low,first].diff(coords[second])-metric[first,second].diff(coords[low]))/2)
    def electric(direction):
        raw=at(metric[0,direction].diff(time,coords[direction])-metric[0,0].diff(coords[direction],2)/2-metric[direction,direction].diff(time,2)/2)
        return raw+sum(inverse[low,other]*(gamma(low,0,direction)*gamma(other,0,direction)-
                       gamma(low,0,0)*gamma(other,direction,direction)) for low in range(4) for other in range(4))
    check("4D connection radial section",electric(1)+3*size**2*rate**2/4)
    check("4D connection orthogonal angular section",electric(2))
    check("4D connection fibre angular section",electric(3)/size**2-size**2*rate**2/4)
    norm,ampl,charge,fluxfun,field,spin=sp.symbols("N sigma Q F A I")
    delta=charge*field-spin
    potential=field**2/rad**2+2*delta**2/rad**4
    twist=16*norm*ampl*delta**2/rad**6
    tang=-norm*ampl*sp.diff(potential,rad)/(2*rad)
    check("radial projected cancellation",2*norm*ampl*potential/rad**2+2*tang-sp.Rational(3,4)*twist-4*norm*ampl*field**2/rad**4)
    check("mean angular projected cancellation",-norm*ampl*potential/rad**2+twist/8+norm*ampl*field**2/rad**4)
    eta,law,dnum=sp.symbols("eta law dn")
    lower=(charge-eta*dnum)*field-(spin-law*dnum)
    check("shell displacement of constrained rotation energy",
          sp.diff(2*fluxfun*lower**2/rad**4,dnum).subs(dnum,0)-4*fluxfun*delta*(law-eta*field)/rad**4)
    check("electric force from shell displacement",sp.diff(fluxfun*(charge-eta*dnum)**2/(2*rad**2),dnum).subs(dnum,0)+eta*fluxfun*charge/rad**2)
    f,p,dens,alpha,pi,grad=sp.symbols("f p D alpha Pi grad",positive=True)
    mech=law-eta*sp.Function("A")(rad)
    mass2=1+f*p**2+norm*ampl*mech**2/rad**2
    lor=sp.sqrt(mass2)
    check("velocity from particle Hamiltonian",sp.diff(alpha*lor,p)-alpha*f*p/lor)
    check("centrifugal plus magnetic force",-sp.diff(alpha*lor,rad)-norm*ampl*alpha*(mech**2/rad**3+eta*mech*sp.diff(sp.Function("A")(rad),rad)/rad**2)/lor)
    energy=dens*sp.sqrt(f)*lor
    pressure=energy*p**2*f/lor**2
    check("mass integrating factor",2*sp.diff(energy+f*(pi**2+grad**2)/2,f)-(energy+pressure)/f-pi**2-grad**2)
    tangential=dens*sp.sqrt(f)*norm*ampl*mech**2/(2*lor*rad**2)
    check("physical dust active trace",energy+pressure+2*tangential-dens*sp.sqrt(f)*(2*lor-1/lor))
    f0=sp.Function("f")(rad)
    df=sp.Function("df")(time,rad)
    shift=sp.Function("L")(time,rad)
    bridge=f0+ampl*df
    lapsed=1+ampl*shift
    radial=(sp.diff(sp.diff(lapsed,rad)*bridge+lapsed*sp.diff(bridge,rad)/2,rad)+sp.diff(sp.diff(bridge,time)/(2*lapsed*bridge**2),time))/lapsed
    check("polar metric curvature linearization",sp.diff(radial,ampl).subs(ampl,0)-f0*sp.diff(shift,rad,2)-
          sp.Rational(3,2)*sp.diff(f0,rad)*sp.diff(shift,rad)-sp.diff(df,rad,2)/2-sp.diff(df,time,2)/(2*f0**2))
    (HOME/"exact.json").write_text(json.dumps(checks,indent=2),encoding="utf8")
    print(len(checks),"exact identities")


if __name__=="__main__":main()

