from common import np


def first(grid,field,parity):
    padded=np.r_[parity*field[4:0:-1],field,field[-2:-6:-1]]
    count=len(field)
    derivative=np.zeros_like(field)
    for shift,weight in enumerate((4/5,-1/5,4/105,-1/280),1):
        derivative+=weight*(padded[4+shift:4+shift+count]-padded[4-shift:4-shift+count])
    out=derivative/grid.step
    out[-4:]=grid.first(field,parity)[-4:]
    return out


def second(grid,field):
    padded=np.r_[field[4:0:-1],field,field[-2:-6:-1]]
    count=len(field)
    derivative=(-205/72)*field
    for shift,weight in enumerate((8/5,-1/5,8/315,-1/560),1):
        derivative+=weight*(padded[4+shift:4+shift+count]+padded[4-shift:4-shift+count])
    out=derivative/grid.step**2
    out[-4:]=grid.second(field)[-4:]
    return out

