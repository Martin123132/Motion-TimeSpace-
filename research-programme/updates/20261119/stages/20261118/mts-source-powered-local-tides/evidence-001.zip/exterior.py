from common import *
from scipy.special import roots_legendre


def initial_mass(variant):
    radii,weights=nodes(.25,16,20)
    number,density,lapse,alpha,bridge=static(radii)
    law,inside=spin(number,variant)
    return NORM*weights@(density*alpha*law**2/2+2*lapse*inside**2/radii**4)


def calculate(mesh,variant):
    with np.load(source(SRC,f"driven-{mesh}-eta1-h0-spin{variant}.npz")) as packet:
        time,rad=packet["time"],packet["radius"]
        use=rad>=5
        rad=rad[use]
        wave,mom,grad=packet["fields"][:,:,use].transpose(1,0,2)
    mass=charge=.002
    factor=(1-mass/rad)**2
    potential=wave**2/rad**2+2*charge**2*wave**2/rad**4
    kinetic=(mom**2+grad**2)/2
    energy=NORM*(factor*kinetic+potential)
    flux=-NORM*factor**2*mom*grad
    outside=tail(rad,energy)
    lapse=-tail(rad,2*NORM*kinetic/rad)
    mass_burst=-outside
    from_flux=-integral(time,flux)
    factor_change=-2*mass_burst/rad
    tidal_r=-2*mass_burst/rad**3+4*NORM*wave**2/rad**4
    tidal_a=mass_burst/rad**3+NORM*(factor*kinetic/rad**2-wave**2/rad**4)
    twist=NORM*16*charge**2*wave**2/rad**6
    dl=make_interp_spline(rad,lapse,axis=-1,k=5)
    df=make_interp_spline(rad,factor_change,axis=-1,k=5)
    dtt=make_interp_spline(time,factor_change,axis=0,k=5)(time,2)
    radial_geom=factor*dl(rad,2)+1.5*(2*mass*(1-mass/rad)/rad**2)*dl(rad,1)+df(rad,2)/2+dtt/(2*factor**2)-.75*twist
    angular_geom=(factor*dl(rad,1)+df(rad,1)/2)/rad+twist/8
    trace=NORM*(2*factor*kinetic/rad**2+2*wave**2/rad**4)
    initial=initial_mass(variant)
    columns={"mass_burst":mass_burst,"mass_flux":from_flux,"mass_total":initial+mass_burst,"logF":lapse,
             "radial_burst":tidal_r,"angular_burst":tidal_a,"radial_metric":radial_geom,"angular_metric":angular_geom,
             "radial_total":tidal_r-2*initial/rad**3,"angular_total":tidal_a+initial/rad**3,"ricci_trace":trace,
             "twist_term":twist,"flux":flux,"A":wave,"P":mom,"Ar":grad}
    sites=np.array([5.5,6.,7.])
    chosen=[np.flatnonzero(rad==site).item() for site in sites]
    rows=[]
    for idx,site in zip(chosen,sites):
        def err(first,second):return peak(first[:,idx]-second[:,idx])/peak(second[:,idx])
        rows.append(dict(mesh=mesh,spin=variant,radius=site,initial_mass=initial,burst_mass_min=float(mass_burst[:,idx].min()),
                         final_burst_mass=mass_burst[-1,idx],mass_flux_error=err(from_flux,mass_burst),
                         radial_curvature_error=err(radial_geom,tidal_r),angular_curvature_error=err(angular_geom,tidal_a),
                         trace_error=err(tidal_r+2*tidal_a,trace),radial_burst_min=tidal_r[:,idx].min(),
                         radial_burst_max=tidal_r[:,idx].max(),angular_burst_min=tidal_a[:,idx].min(),
                         angular_burst_max=tidal_a[:,idx].max(),radial_prepared=-2*initial/site**3,
                         twist_radial_peak=.75*peak(twist[:,idx])))
    archive(f"metric-{mesh}-spin{variant}.npz",time=time,radius=sites,**{name:value[:,chosen] for name,value in columns.items()})
    return rows


def main():
    guard()
    rows=[]
    for mesh in (960,1920):
        for variant in (0,1):
            rows.extend(calculate(mesh,variant))
    write("static_checks.csv",rows)
    print([(row["radius"],row["mass_flux_error"],row["radial_curvature_error"],row["angular_curvature_error"]) for row in rows if row["mesh"]==1920])


if __name__=="__main__":
    main()

