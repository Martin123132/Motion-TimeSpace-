from common import *

CLOCK=np.linspace(0.,6.4,257)
ARMS=((1.,0.),(.8,0.),(.8,1/160),(.8,1.))


def error(value,control):
    return np.max(abs(value-control),axis=0)/np.max(abs(control),axis=0)


def difference(value):
    return value-value[0]


def read(prefix,mesh,eta,amp):
    with np.load(HOME/f"{prefix}-{mesh}-eta{eta:g}-h{amp:g}-s0.npz") as data:
        return dict(data)


def measurement(data):
    base=data["base"];delta=data["delta"];time=data["time"];rad=data["radius"]
    mass_flux=integral(time,delta[:,1]);mass_rad=data["exterior_dm"]
    radial=difference(delta[:,7])-2*mass_rad/rad**3
    angular=difference(delta[:,8])+mass_rad/rad**3
    alpha=base[:,2]*np.sqrt(base[:,12])
    da=alpha*(delta[:,2]/base[:,2]+delta[:,12]/(2*base[:,12]))
    tau=integral(time,alpha);dtau=integral(time,da)
    ks=make_interp_spline(time,base[:,7],k=5)(time,1)
    trace_s=make_interp_spline(time,base[:,6],k=5)(time,1)
    rate_r=ks-2*base[:,1]/rad**3
    rate_t=(trace_s-rate_r)/2
    clock_r=-dtau*rate_r/alpha
    clock_a=-dtau*rate_t/alpha
    def align(value):
        return np.stack([make_interp_spline(tau[:,idx],value[:,idx],k=5)(CLOCK) for idx in range(len(rad))],axis=1)
    dm=difference(delta[:,0])
    return dict(radial=align(radial+clock_r),angular=align(angular+clock_a),clock_r=align(clock_r),clock_a=align(clock_a),
                mass=align(mass_rad),rate_mass=align(mass_flux),inner_mass=align(dm),scalar_trace=align(difference(delta[:,6])),
                trace=align(difference(delta[:,5])+clock_r+2*clock_a),mass_only=align(-2*mass_rad/rad**3),
                radial_fixed=radial,angular_fixed=angular,tau=tau)


def main(scheme="conserved"):
    guard()
    measures={};budgets=[];mesh_rows=[];samples=[];signal_rows=[]
    for mesh in (960,1920):
        for eta,amp in ARMS:
            for prefix in (("coupled","conserved") if scheme=="conserved" else (scheme,)):
                data=read(prefix,mesh,eta,amp)
                vals=measurement(data)
                vel=vals["rate_mass"]
                ext=error(vals["mass"],vel)
                inner=error(vals["inner_mass"],vel)
                for idx,site in enumerate(data["radius"]):
                    budgets.append(dict(scheme=prefix,mesh=mesh,eta=eta,amp=amp,site=site,inner_error=inner[idx],outer_error=ext[idx],
                                        adm_drift=np.ptp(data["budget"][:,0]),baryon_drift=peak(data["budget"][:,1]),
                                        initial_local_mass=data["delta"][0,0,idx],initial_adm=data["initial_adm"].item()))
                if prefix==scheme:
                    measures[mesh,eta,amp]=vals
                    for idx,site in enumerate(data["radius"]):
                        for slot,clock in enumerate(CLOCK):
                            samples.append(dict(mesh=mesh,eta=eta,amp=amp,radius=site,proper=clock,
                                                **{name:vals[name][slot,idx] for name in ("mass","radial","angular","scalar_trace","clock_r","clock_a")}))
    def get(mesh,eta,amp,channel,mode):
        out=measures[mesh,eta,amp][channel]
        return out-measures[mesh,.8,0.][channel] if mode=="difference" else out
    for eta,amp in ARMS:
        for mode in (("absolute","difference") if amp else ("absolute",)):
            for channel in ("mass","radial","angular","trace"):
                low=get(960,eta,amp,channel,mode);high=get(1920,eta,amp,channel,mode)
                errors=error(low,high)
                for idx,site in enumerate((5.5,6.,7.)):
                    mesh_rows.append(dict(eta=eta,amp=amp,comparison=mode,channel=channel,radius=site,
                                          peak=peak(high[:,idx]),minimum=high[:,idx].min(),maximum=high[:,idx].max(),
                                          final=high[-1,idx],mesh_error=errors[idx],pass_gate=errors[idx]<TOL))
            trace=get(1920,eta,amp,"trace",mode);rad=get(1920,eta,amp,"radial",mode);ang=get(1920,eta,amp,"angular",mode)
            mass=get(1920,eta,amp,"mass",mode);vel=get(1920,eta,amp,"rate_mass",mode)
            for idx,site in enumerate((5.5,6.,7.)):
                signal_rows.append(dict(eta=eta,amp=amp,comparison=mode,site=site,trace_error=peak((rad+2*ang-trace)[:,idx])/peak(trace[:,idx]),
                                        paired_flux_error=peak((mass-vel)[:,idx])/peak(vel[:,idx])))
    stub="" if scheme=="conserved" else scheme+"_"
    write(stub+"mass_audit.csv",budgets);write(stub+"ruler_mesh.csv",mesh_rows);write(stub+"ruler_series.csv",samples);write(stub+"paired_controls.csv",signal_rows)
    print("mesh failures",[(r["amp"],r["channel"],r["radius"],float(r["mesh_error"])) for r in mesh_rows if not r["pass_gate"]])
    print("paired max",max(r["trace_error"] for r in signal_rows),max(r["paired_flux_error"] for r in signal_rows))
    print("fine ordinary/mts at r6", [r for r in mesh_rows if r["radius"]==6 and r["channel"]=="radial" and (r["comparison"]=="difference" or r["amp"]==0)])


if __name__=="__main__":main(sys.argv[1] if len(sys.argv)>1 else "conserved")

