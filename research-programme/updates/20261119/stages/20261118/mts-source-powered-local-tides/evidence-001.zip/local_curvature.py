from common import *


def check(mesh,variant):
    with np.load(source(SRC,f"driven-{mesh}-eta1-h0-spin{variant}.npz")) as packet:
        time,rad=packet["time"],packet["radius"]
        keep=rad>=5
        rad=rad[keep]
        wave,mom,grad=packet["fields"][:,:,keep].transpose(1,0,2)
    with np.load(HOME/f"metric-{mesh}-spin{variant}.npz") as prior:
        sites=prior["radius"]
        indices=[np.flatnonzero(rad==point).item() for point in sites]
        m2=prior["mass_burst"];goal=prior["radial_burst"]
    mass=charge=.002
    factor=(1-mass/sites)**2;rate=2*mass*(1-mass/sites)/sites**2
    def slope(field):
        return make_interp_spline(rad,field,axis=-1,k=7)(sites,1)
    mom_r,grad_r=slope(mom),slope(grad)
    val,pm,xr=[field[:,indices] for field in (wave,mom,grad)]
    local=pm**2+xr**2
    dlocal=2*(pm*mom_r+xr*grad_r)
    l1=NORM*local/sites
    l2=NORM*(dlocal/sites-local/sites**2)
    vpot=1/sites**2+2*charge**2/sites**4
    vp=-2/sites**3-8*charge**2/sites**5
    mass1=NORM*(factor*local/2+vpot*val**2)
    mass2=NORM*((rate*local+factor*dlocal)/2+vp*val**2+2*vpot*val*xr)
    f2=-2*mass2/sites+4*mass1/sites**2-4*m2/sites**3
    dflux=make_interp_spline(time,pm*xr,axis=0,k=7)(time,1)
    twist=NORM*16*charge**2*val**2/sites**6
    metric=factor*l2+1.5*rate*l1+f2/2-NORM*dflux/sites-.75*twist
    rows=[]
    for idx,site in enumerate(sites):
        rows.append(dict(mesh=mesh,spin=variant,radius=site,error=peak(metric[:,idx]-goal[:,idx])/peak(goal[:,idx]),
                         excluding_endpoints=peak(metric[4:-4,idx]-goal[4:-4,idx])/peak(goal[:,idx])))
    return rows


if __name__=="__main__":
    guard()
    rows=[row for mesh in (960,1920) for variant in (0,1) for row in check(mesh,variant)]
    write("local_curvature.csv",rows)
    print(rows[-6:])

