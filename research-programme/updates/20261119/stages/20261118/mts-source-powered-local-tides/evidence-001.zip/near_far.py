from common import *
from scipy.integrate import solve_ivp, cumulative_simpson


def transfer(freq,rad):
    mass=.002
    eps=mass*freq
    target=rad*freq
    start=np.maximum(55.,target)
    coeff=[np.ones_like(freq,dtype=complex)]
    for rank in range(1,16):
        prev=((rank-1)*rank-2)*coeff[-1]
        if rank>=2:prev-=2*eps*(rank-2)*rank*coeff[-2]
        if rank>=3:prev+=eps**2*((rank-3)*rank-4)*coeff[-3]
        coeff.append(prev/(2j*rank))
    val=sum(item/start**rank for rank,item in enumerate(coeff))
    grad=sum(-rank*item/start**(rank+1) for rank,item in enumerate(coeff))
    take=target<start
    if np.any(take):
        spread=np.log(target[take]/start[take]);small=eps[take];count=len(small)
        def eq(position,state):
            arg=start[take]*np.exp(position*spread)
            normal=1-small/arg
            shape,slope=state[:count],state[count:]
            curvature=((2/arg**2+4*small**2/arg**4)*shape-(2*small*normal/arg**2+2j)*slope)/normal**2
            return np.r_[spread*arg*slope,spread*arg*curvature]
        sol=solve_ivp(eq,(0.,1.),np.r_[val[take],grad[take]],method="DOP853",t_eval=[1.],rtol=2e-11,atol=2e-14)
        assert sol.success
        val[take],grad[take]=np.split(sol.y[:,-1],2)
    return val,grad


def run(mode):
    data=dict(np.load(source(ESC,mode+".npz")))
    time=np.linspace(-8,16,1201)
    freq=data["k"];weight=data["weight"]/np.pi
    phase=np.exp(-1j*time[:,None]*freq)
    integral_phase=(phase-phase[0])/(-1j*freq)
    news=data["news"]*weight[:,None]
    v=(phase@news).real
    potential=(integral_phase@news).real
    bondi=-NORM*cumulative_simpson(v**2,x=time,axis=0,initial=0.)
    rows=[];curves=[]
    for rad in (7,14,28,56,112,224,448,1792):
        factor=(1-.002/rad)**2
        val,grad=transfer(freq,rad)
        at=(phase@(news*val[:,None])).real
        xr=(integral_phase@(news*(freq*(grad+1j*val/factor))[:,None])).real
        mass=NORM*cumulative_simpson(factor*at*xr,x=time,axis=0,initial=0.)
        correction=-NORM*potential**2/rad
        for variant in (0,1):
            observed=(mass-bondi)[:,variant]
            predicted=correction[:,variant]
            denom=peak(bondi[:,variant])
            rows.append(dict(grid=mode,spin=variant,radius=rad,raw_error=peak(observed)/denom,
                             corrected_error=peak(observed-predicted)/denom,
                             first_coefficient_miss=peak(observed-predicted)/peak(predicted),
                             signed_predicted_peak=predicted[np.argmin(predicted)],
                             signed_measured_at_peak=observed[np.argmin(predicted)],
                             end_ratio=bondi[-1,variant]/(-NORM*sum(data["weight"]*abs(data["news"][:,variant])**2/np.pi))))
        curves.append(mass)
    return rows,np.stack(curves)


if __name__=="__main__":
    guard()
    first,low=run("checkgrid");second,high=run("fine")
    for idx,row in enumerate(second):
        wave=high[idx//2,:,idx%2]
        row["mesh_error"]=peak(wave-low[idx//2,:,idx%2])/peak(wave)
    for row in first:row["mesh_error"]=""
    write("near_far.csv",first+second)
    print(second[-6:])

