from rulers import *
from exterior import initial_mass


def independent(mesh,eta,amp):
    data=read("higher",mesh,eta,amp)
    time=data["time"];rad=data["radius"]
    base,delta=data["base"],data["delta"]
    with np.load(source(SRC,f"driven-{mesh}-eta{eta:g}-h{amp:g}-spin0.npz")) as field:
        indices=[np.flatnonzero(field["radius"]==site).item() for site in rad]
        val,pm,xr=field["fields"][::2].transpose(1,0,2)[:,:,indices]
    metric_direct=NORM*(base[:,12]*(pm**2+xr**2)/rad**2+2*val**2/rad**4)
    ph,pi,fac=base[:,10],base[:,11],base[:,12]
    dphi,dpi,df=delta[:,10],delta[:,11],delta[:,12]
    scalar_fields=4*fac*pi*dpi-2*ph*dphi
    scalar_geometry=2*df*pi**2
    meas=measurement(data)
    def align(field):
        return np.stack([make_interp_spline(meas["tau"][:,idx],field[:,idx],k=5)(CLOCK) for idx in range(len(rad))],axis=1)
    channels=dict(photons=align(metric_direct),scalar_fields=align(difference(scalar_fields)),scalar_geometry=align(difference(scalar_geometry)),
                  clock=meas["clock_r"]+2*meas["clock_a"])
    channels["total"]=meas["radial"]+2*meas["angular"]
    return channels


def main():
    guard()
    results=[];controls=[]
    for mesh in (960,1920):
        arms={amp:independent(mesh,.8,amp) for amp in (0.,1/160,1.)}
        for amp in (0.,1/160,1.):
            data=arms[amp]
            for mode in (("absolute","difference") if amp else ("absolute",)):
                part={key:(field-arms[0.][key] if mode=="difference" else field) for key,field in data.items()}
                for idx,site in enumerate((5.5,6.,7.)):
                    total=part["total"][:,idx]
                    parts=[part[key][:,idx] for key in ("photons","scalar_fields","scalar_geometry","clock")]
                    norm=peak(total)
                    results.append(dict(mesh=mesh,amp=amp,mode=mode,radius=site,total_peak=norm,independent_error=peak(total-sum(parts))/norm,
                                        only_photons_error=peak(total-parts[0])/norm,
                                        omit_induced_matter=peak(parts[1])/norm,omit_clock=peak(parts[3])/norm,
                                        total_at_tau6_4=total[-1],photon_final=parts[0][-1],induced_scalar_final=parts[1][-1],
                                        scalar_metric_final=parts[2][-1],clock_final=parts[3][-1]))
    static=read("higher",1920,1.,0.)
    with np.load(HOME/"metric-1920-spin0.npz") as exterior:
        ref=exterior["mass_burst"][::2]
        controls.append(dict(test="source mass cost against independent stationary charge preparation",
                             error=abs(static["initial_adm"].item()/initial_mass(0)-1),normalization="initial mass cost"))
        for idx,site in enumerate(static["radius"]):
            controls.append(dict(test=f"coupled vs electrovac exterior burst mass at {site}",
                                 error=peak(static["exterior_dm"][:,idx]-ref[:,idx])/peak(ref[:,idx]),normalization="burst mass"))
    neutral=read("higher",1920,0.,0.)
    null=measurement(neutral);prep=float(neutral["initial_adm"])
    for field in ("mass","radial","angular"):
        scale=prep if field=="mass" else prep/7**3
        controls.append(dict(test="neutral rotating cloud exterior dynamic "+field,error=peak(null[field])/scale,
                             normalization="prepared monopole mass or tide; continuum dynamic null"))
    controls.append(dict(test="neutral nonzero initial spin energy",error=0. if prep>0 else 1.,normalization=f"initial mass cost {prep}"))
    write("ricci_components.csv",results);write("source_controls.csv",controls)
    print([row for row in results if row["mode"]=="difference" and row["mesh"]==1920 and row["radius"]==6.])
    print(controls)


if __name__=="__main__":main()

