import csv
import json
import os
import sys
from pathlib import Path

for variable in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
sys.dont_write_bytecode=True
HOME=Path(__file__).resolve().parent
ESC=HOME.parent/"mts-escaping-spectrum-20261118"
SRC=HOME.parent/"mts-driven-current-20261118"
CH=HOME.parent/"mts-charged-exterior-rulers-20261118"
sys.path.insert(0,str(ESC))
from outgoing import guard as previous_guard, sha, spin, np, static, geometry, nodes
from scipy.interpolate import make_interp_spline
from scipy.integrate import cumulative_simpson

NORM=2/3
TOL=2e-5
LOCK="c88c91c248083d9da42c9c0daaad57a06a7a303aa620baa5edd4642dc13c1a0c"


def guard():
    previous_guard()
    assert sha(ESC/"closeout.json")==LOCK and not (HOME/"STOP-REQUESTED").exists()


def source(folder,name):
    path=folder/name
    manifest=json.loads((folder/"closeout.json").read_text())["files"]
    assert sha(path)==manifest[name]
    return path


def write(name,rows):
    with (HOME/name).open("w",newline="",encoding="utf8") as stream:
        out=csv.DictWriter(stream,fieldnames=list(rows[0]))
        out.writeheader()
        out.writerows(rows)


def archive(name,**data):
    with (HOME/name).open("xb") as stream:
        np.savez_compressed(stream,**data)


def peak(array):
    return float(np.max(np.abs(array)))


def tail(radius,field):
    anti=make_interp_spline(radius,field,axis=-1,k=5).antiderivative()
    return anti(radius[-1])[...,None]-anti(radius)


def integral(time,field):
    anti=make_interp_spline(time,field,axis=0,k=5).antiderivative()
    return anti(time)-anti(time[0])

