from common import *
import sympy as sp
from scipy.special import roots_legendre


def evaluator():
    rad,pol,mass,charge,spin=sp.symbols("r theta M Q a",real=True)
    sine=sp.sin(pol)**2
    sigma=rad**2+spin**2*sp.cos(pol)**2
    disc=rad**2-2*mass*rad+spin**2+charge**2
    pack=(rad**2+spin**2)**2-disc*spin**2*sine
    terms=[-1+(2*mass*rad-charge**2)/sigma,-spin*(2*mass*rad-charge**2)*sine/sigma,
           sigma/disc,sigma,pack*sine/sigma]
    jet=[term for arg in ((),(rad,),(pol,),(rad,rad),(rad,pol),(pol,pol)) for term in
         [item.diff(*arg) if arg else item for item in terms]]
    return sp.lambdify((rad,pol,mass,charge,spin),jet,modules="numpy",cse=True)


def measure(jets,rad,mass,charge,spin):
    knots,weights=roots_legendre(30)
    area=dmean=0.
    tides=np.zeros(3)
    for cos,weight in zip(knots,weights):
        pol=np.arccos(cos)
        data=np.asarray(jets(rad,pol,mass,charge,spin)).reshape(6,5)
        matrices=np.zeros((6,4,4))
        for col,(first,second) in enumerate(((0,0),(0,3),(1,1),(2,2),(3,3))):
            matrices[:,first,second]=matrices[:,second,first]=data[:,col]
        metric=matrices[0];inv=np.linalg.inv(metric)
        grad=np.zeros((4,4,4));grad[1:3]=matrices[1:3]
        hess=np.zeros((4,4,4,4))
        hess[1,1],hess[1,2],hess[2,2]=matrices[3:]
        hess[2,1]=hess[1,2]
        gamma=(grad.transpose(1,0,2)+grad.transpose(1,2,0)-grad)/2
        normal=-inv[0]/np.sqrt(-inv[0,0])
        sky=weight*np.sqrt(metric[2,2]*metric[3,3])/np.sin(pol)/2
        area+=sky
        expansion=(matrices[1,2,2]/metric[2,2]+matrices[1,3,3]/metric[3,3])/(2*np.sqrt(metric[1,1]))
        dmean+=sky*expansion**2
        first= np.einsum("mij,i,j->m",gamma,normal,normal)
        for idx in (1,2,3):
            cross=gamma[:,:,idx]@normal
            section=-normal@hess[idx,idx]@normal/2+cross@inv@cross-first@inv@gamma[:,idx,idx]
            tides[idx-1]+=sky*section/metric[idx,idx]
    radius=np.sqrt(area);hawking=radius*(1-dmean/4)/2
    tides/=area
    return radius,np.array([hawking,tides[0],(tides[1]+tides[2])/2])


def predict(rad,mass,charge):
    factor=1-2*mass/rad+charge**2/rad**2
    dm=-(charge**2+3*mass**2)/(3*rad**3)+7*mass*charge**2/(6*rad**4)-charge**4/(3*rad**5)
    return np.array([dm,-2*dm/rad**3+4*NORM*charge**2/rad**6,
                     dm/rad**3+NORM*(factor/2-1)*charge**2/rad**6])


def main():
    guard()
    jets=evaluator();rows=[]
    for charge in (0.,.6):
        for coord in (4.,7.,12.):
            mass=1.
            predictions=predict(coord,mass,charge);estimates=[]
            for spin in (.08,.04,.02):
                rad,actual=measure(jets,coord,mass,charge,spin)
                base=np.array([mass-charge**2/(2*rad),-2*mass/rad**3+3*charge**2/rad**4,mass/rad**3-charge**2/rad**4])
                estimates.append((actual-base)/spin**2)
            first=(4*estimates[1]-estimates[0])/3
            fine=(4*estimates[2]-estimates[1])/3
            for name,est,ctrl,expected in zip(("Hawking_mass","radial_tide","mean_angular_tide"),fine,first,predictions):
                rows.append(dict(charge=charge,BL_radius=coord,channel=name,exact_coefficient=est,
                                 predicted=expected,relative_miss=abs(est/expected-1),extraction_change=abs((est-ctrl)/expected)))
    write("kerr_newman.csv",rows)
    print(max(row["relative_miss"] for row in rows),max(row["extraction_change"] for row in rows))
    print([row for row in rows if row["relative_miss"]>TOL][:4])


if __name__=="__main__":main()

