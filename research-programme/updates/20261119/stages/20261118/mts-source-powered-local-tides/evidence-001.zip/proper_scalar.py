from rulers import *


def main():
    guard()
    rows=[];curves={}
    for mesh in (960,1920):
        for amp in (1/160,1.):
            data=read("higher",mesh,.8,amp)
            t,base,delta=data["time"],data["base"],data["delta"]
            rad=data["radius"];fac=base[:,12]
            alpha=base[:,2]*np.sqrt(fac)
            dtau=integral(t,alpha*(delta[:,2]/base[:,2]+delta[:,12]/(2*fac)))
            tau=integral(t,alpha)
            rate=np.sqrt(fac)*base[:,11]
            xi=delta[:,10]-rate*dtau
            packet=measurement(data)
            with np.load(source(SRC,f"driven-{mesh}-eta0.8-h{amp:g}-spin0.npz")) as wave:
                idx=[np.flatnonzero(wave["radius"]==point).item() for point in rad]
                field,pm,grad=wave["fields"][::2].transpose(1,0,2)[:,:,idx]
            em=NORM*(fac*(pm**2+grad**2)/rad**2+2*field**2/rad**4)
            for col,site in enumerate(rad):
                def interpolate(value):
                    return make_interp_spline(tau[:,col],value[:,col],k=7)
                curve=interpolate(xi)
                scalar=4*interpolate(rate)(CLOCK)*curve(CLOCK,1)-2*interpolate(base[:,10])(CLOCK)*curve(CLOCK)
                scalar-=scalar[0]
                target=(packet["radial"]+2*packet["angular"])[:,col]-interpolate(em)(CLOCK)
                common_em=make_interp_spline(tau[:,col],em[:,col],k=5)(CLOCK)
                common=(packet["radial"]+2*packet["angular"])[:,col]-common_em
                stress=make_interp_spline(tau[:,col],difference(delta[:,6])[:,col],k=5)(CLOCK)+packet["clock_r"][:,col]+2*packet["clock_a"][:,col]
                curves[mesh,amp,site]=scalar
                rows.append(dict(mesh=mesh,amp=amp,site=site,scalar_peak=peak(target),
                                 mixed_interpolant_error=peak(scalar-target)/peak(target),independent_error=peak(scalar-common)/peak(common),
                                 scalar_only_error=peak(scalar-stress)/peak(stress),
                                 scalar_final=scalar[-1],matched_h_peak=peak(curve(CLOCK))))
    for row in rows:
        amp,site=row["amp"],row["site"]
        row["mesh_change"]=peak(curves[960,amp,site]-curves[1920,amp,site])/peak(curves[1920,amp,site])
    write("proper_scalar.csv",rows)
    print("max independent",max(row["independent_error"] for row in rows),"max mesh",max(row["mesh_change"] for row in rows))


if __name__=="__main__":main()

