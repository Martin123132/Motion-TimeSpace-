from gas_cases import *
from tail_moments import census
from numpy.polynomial.legendre import leggauss

def weights():
    design=js(safe("weights.json"));x=np.array(design["x"]);u=design["u0"]
    primary={name:np.array(row["w"]) for name,row in design["weights"].items()}
    for start in range(3):
        active=np.arange(start,start+4)
        sub=x[active];dd=np.array([1/np.prod(v-np.delete(sub,i)) for i,v in enumerate(sub)])
        vec=np.zeros(7);vec[active]=dd*np.exp(u*sub);vec/=sum(abs(vec));vec*=np.sign(vec[active[0]])
        primary["stencil"+str(start)]=vec
    return design,primary

def evaluate(k,vals,h,temp,lo,hi,query,order=12,linear=False):
    assert hi<=k[-1] and lo>=k[0] and hi>lo,(lo,hi,k[0],k[-1])
    grid=np.log(k);bounds=np.log(np.unique(np.r_[lo,k[(k>lo)&(k<hi)],query[(query>lo)&(query<hi)],hi]))
    rule,w=leggauss(order);dl=np.diff(bounds)
    loc=bounds[:-1,None]+dl[:,None]*(1+rule)/2;mode=np.exp(loc)
    weight=dl[:,None]*w/2*spec.META["As"]*(mode/spec.META["pivot_Mpc"])**(spec.META["ns"]-1)/mode
    curve=lambda v:np.interp(loc,grid,v) if linear else PchipInterpolator(grid,v)(loc)
    d=1.65*curve(vals[:,1]);v=(query[-1]/mode)**2*curve(vals[:,2])
    damp=.25*(query[-1]/h)**2*2*gas.KB*temp/(gas.MP*1e6);x=(query/query[-1])**2
    signed=d[...,None]+x*(v-.5*damp*d/1.65)[...,None]
    factor=np.pi*h*.65**2*np.exp(-2*damp*x)
    full=weight[...,None]*factor*signed**2
    mask=mode[...,None]>=query
    parts=np.sum(full*mask,axis=1)
    return parts

def old(mode,arm,tag,label,temp):
    if label=="matched" and arm in ("wave","off") and tag=="1200":
        a=archive(THERM/f"matched-temperature-{arm}.npz")
        return a["k"],a["fields"][6]
    packets=[]
    for panel in ("fine","wide"):
        if label=="reference":
            raw=data(panel,arm,tag,"gas");packets.append(dict(k=raw["k"],field=raw[arm+"-1-2048-1"]))
        else:
            src=data(panel,arm,tag,"source");packets.append(dict(k=src["k"],field=direct(src,arm,temp,2048,1)))
    kk,_=joined(packets)
    return kk,combined(packets,"field")[6]

def low_test():
    gate();design,templates=weights()
    rows0=[];tests=[];signals=[];trunc=[];qbase=np.array(design["kv"]);u=design["u0"]
    for arm in ("wave","off","cold"):
        tags=("225",) if arm=="cold" else ("1200","1500")
        for tag in tags:
            label0="cold" if arm=="cold" else "heavy";src=packet("bandlow",f"gas-fine-{label0}-{tag}.npz")
            kk=src["k"];h=src["h"][6];query=qbase*h;offset=query-np.array(design["q"])
            for label,temp in temperatures(arm).items():
                oldk,oldval=old("low",arm,tag,label,temp);ii=np.searchsorted(oldk,kk[-1],side="right");assert ii<len(oldk)
                assert max(abs(offset))<1e-7
                for variant,steps,stride,reduction,linear in (("full",2048,1,1,False),("half-k",2048,1,2,False),("linear-k",2048,1,1,True),("half-time",1024,1,1,False),("thin-source",2048,2,1,False)):
                    knot=np.r_[kk[::reduction],oldk[ii]]
                    values=np.vstack([src[f"{arm}-{label}-{steps}-{stride}"][6,::reduction],oldval[ii]])
                    cells=evaluate(knot,values,h,temp,query[0],query[-1],query,linear=linear);power=np.sum(cells,axis=0)
                    if variant=="full":
                        tail=evaluate(oldk,oldval,h,temp,max(oldk[0],query[-1]),oldk[-1],query).sum(axis=0)
                        for j in range(7):
                            rows0.append(dict(arm=arm,tag=tag,temp=temp,bin=j,kv=qbase[j],q=query[j],low=power[j],known_high=tail[j]))
                    for name,w in templates.items():
                        use_exact=(name=="dual" and label=="matched") or (name!="dual" and label=="reference")
                        protected=use_exact or name=="robust"
                        result=float(np.sum(cells@w))
                        signals.append(dict(arm=arm,tag=tag,label=label,temp=temp,variant=variant,name=name,contrast=result,
                            exact_damping=use_exact,temperature_robust=protected,absolute_weight_low_power=np.dot(abs(w),power)))
                        if variant!="full":continue
                        pref=np.exp(-u*temp/TREF*np.array(design["x"]))
                        col=abs((w*pref)@np.array(design["x"])[:,None]**np.arange(3))
                        high_sum=float(w@tail);high_scale=float(abs(w)@tail)
                        tests.append(dict(arm=arm,tag=tag,label=label,name=name,exact=use_exact,model_columns=max(col),high_leak=high_sum,high_relative=high_sum/high_scale,
                            low=result,known_high_abs_scale=high_scale,known_sum=result+high_sum))
    table(safe("finite-support-bins.csv"),rows0);table(safe("finite-support-contrast.csv"),signals);table(safe("finite-support-tail-tests.csv"),tests)
    print("source-independent high tail: exact-column residual",max(r["model_columns"] for r in tests if r["exact"]),"measured-high residual",max(abs(r["high_relative"]) for r in tests if r["exact"]),flush=True)
if __name__=="__main__":low_test()

