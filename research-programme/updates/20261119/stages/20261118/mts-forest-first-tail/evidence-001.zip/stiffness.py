from bank import *
from numpy.polynomial import Polynomial
import re
from scipy.optimize import brentq

def run():
    gate();sys.path.insert(0,str(PARENT));import session
    src=session.engine();model=src.camb.get_background(session.params(src,"exact","fine"))
    at=7.9716700141732604;floor=4.5366729435227107e-6;k=38.638129949814306
    tg=np.array([at*.9999,at,at*1.0001])
    red=model.redshift_at_conformal_time(tg);scale=1/(1+red);thermal=model.get_background_time_evolution(tg,vars=["opacity"],format="dict")
    density=model.get_background_densities(scale,vars=["baryon","photon"])
    drag=thermal["opacity"]*(1+4*density["photon"]/(3*density["baryon"]))
    code=read(prior.MATCH/"native/fortran/subroutines.f90").lower()
    start=code.index("temp = c(18)/1398169080000.");end=code.index("!           add 7 to the no of fcn evals",start)
    expressions=re.findall(r"w\(k,9\)\s*=\s*y\(k\)\s*\+\s*temp\*([^\n]*(?:&\n[^\n]*)*)",code[start:end].replace("&\n"," "))
    assert len(expressions)==8
    zz=Polynomial([0,1]);stages=[Polynomial([1])]
    for expr in expressions:
        co=re.findall(r"([+\-]?)\s*w\(k,(\d+)\)\*(\d+)\._dl",expr)
        assert co
        stages.append(1+zz*sum(((-1 if sign=="-" else 1)*int(v)/1398169080000)*stages[int(index)-1] for sign,index,v in co))
    poly=stages[-1]
    assert np.allclose(poly.coef[:7],[1,1,.5,1/6,1/24,1/120,1/720],atol=5e-16)
    edge=brentq(lambda t:abs(poly(-t))-1,2.,8.)
    dump(safe("slip-stability.json"),dict(k=k,tau=at,a=scale[1],redshift=red[1],opacity=thermal["opacity"][1],drag=drag[1],floor=floor,
        stability_coefficients=poly.coef.tolist(),negative_real_stability_limit=edge,dimensionless_floor=floor*drag[1],
        floor_growth_factor=abs(poly(-floor*drag[1])),stable_step_ceiling=edge/drag[1],mode_sampling=2*np.pi/k,
        source_sha=digest(prior.MATCH/"native/fortran/subroutines.f90"),instantaneous_drag_only=True))
    print(js(safe("slip-stability.json")),flush=True)
if __name__=="__main__":run()

