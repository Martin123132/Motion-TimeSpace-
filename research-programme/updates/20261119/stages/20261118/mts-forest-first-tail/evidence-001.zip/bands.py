from assess import *
from contrast import old,weights,evaluate
from tail_moments import census,summary

def integral(k,fields,h,temp,zi,lower):
    response,w,_=spec.project(k,fields,h,zi,temp/TREF)
    return float(PchipInterpolator(np.log(k),w*response**2).integrate(np.log(lower),np.log(k[-1])))

def gram_stats(raw,h,temp):
    mass,mean,j,err=summary(raw);qref=spec.RADS[6]
    d=.25*(qref/h)**2*2*gas.KB*temp/(gas.MP*1e6)
    c=.5*d/1.65;x=np.array(weights()[0]["x"])
    f=np.pi*h*.65**2*np.exp(-2*d*x)*(mass+2*x*(raw[1]-c*mass)+x*x*(raw[2]-2*c*raw[1]+c*c*mass))
    lo,mid,hi=x[-3:];a,b,e=np.log(f[-3:])
    return dict(J=j,E=err,velocity_mean=mean,Q=b-((hi-mid)*a+(mid-lo)*e)/(hi-lo),angular_high=f[-1])

def original(arm,label,temp):
    if label=="matched" and arm in ("wave","off"):
        source=archive(THERM/f"matched-temperature-{arm}.npz");return source["k"],source["fields"]
    blocks=[]
    for panel in ("fine","wide"):
        g=data(panel,arm,"1200","gas")
        v=g[arm+"-1-2048-1"] if label=="reference" else direct(data(panel,arm,"1200","source"),arm,temp,2048,1)
        blocks.append(dict(k=g["k"],f=v))
    k,_=joined(blocks);return k,combined(blocks,"f")

def report(count):
    gate();powers=[];grams=[];contrasts=[];cancel=[];design,templates=weights()
    for arm in ("wave","off","cold","exact"):
        for label,temp in temperatures(arm).items():
            k0,v0=original(arm,label,temp)
            total={};raw=census(k0,v0[6]).sum(axis=0)
            for index in range(1,count+1):
                band=str(index);g=extract(band,"fine",arm,"1200");k=g["k"];v=g[f"{arm}-{label}-2048-1"];h=g["h"]
                for zi in FOUR:
                    if index==1:total[zi]=integral(k0,v0[zi],h[zi],temp,zi,spec.RADS[zi])
                    before=total[zi]
                    partial=integral(k,v[zi],h[zi],temp,zi,k[0]);half=integral(k[::2],v[zi,::2],h[zi],temp,zi,k[0])
                    total[zi]+=partial
                    powers.append(dict(arm=arm,label=label,z=Z[zi],band=band,lo=k[0],hi=k[-1],partial=partial,previous=before,total=total[zi],
                        fraction_added=partial/before,thinning_delta=half-partial,thinning_relative=half/partial-1))
                addition=census(k,v[6]).sum(axis=0);previous=raw.copy();raw=raw+addition
                a=summary(previous);b=summary(addition);w=a[0]/raw[0];stats=gram_stats(raw,h[6],temp)
                local=gram_stats(addition,h[6],temp);small=census(k[::2],v[6,::2]).sum(axis=0)
                grams.append(dict(arm=arm,label=label,band=band,k=k[-1],total_I0=raw[0],total_I01=raw[1],total_I2=raw[2],added_I0=addition[0],
                    added_I01=addition[1],added_I2=addition[2],new_only_J=local["J"],previous_J=a[2],added_density_fraction=b[0]/a[0],
                    joined_variance=w*a[2]+(1-w)*b[2]+w*(1-w)*(a[1]-b[1])**2,
                    thin_J=gram_stats(previous+small,h[6],temp)["J"],**stats))
                q=np.array(design["kv"])*h[6]
                bins=evaluate(k,v[6],h[6],temp,k[0],k[-1],q).sum(axis=0)
                for name,vec in templates.items():
                    cancel.append(dict(band=band,arm=arm,label=label,name=name,absolute_tail=float(vec@bins),
                        relative_to_absolute_weight=float(vec@bins/(abs(vec)@bins))))
    for label in ("reference","matched"):
        for index in range(1,count+1):
            for zi in FOUR:
                subset={r["arm"]:r for r in powers if r["label"]==label and r["band"]==str(index) and r["z"]==Z[zi]}
                wave,off=subset["wave"],subset["off"]
                contrasts.append(dict(label=label,band=index,z=Z[zi],earlier=off["previous"]/wave["previous"],
                    extended=off["total"]/wave["total"],band_alone=off["partial"]/wave["partial"],
                    unseen_wave_needed_for_parity=max(0.,off["total"]-wave["total"]),last_wave_band=wave["partial"]))
    for name,ledger in (("powers",powers),("gram",grams),("contrasts",contrasts),("external-cancellation",cancel)):
        table(safe(f"through-{count}-{name}.csv"),ledger)
    print([r for r in contrasts if r["z"]==4.2],flush=True)
if __name__=="__main__":report(int(sys.argv[1]))

