from local_susceptibility import *

def compare():
    gate();direct=[];scales=[]
    for ratio in (.25,1.,4.):
        for phase in (0.,.73):
            for epsilon in np.array([1e-4,5e-5])*min(ratio**2,1.):
                out=evolve(ratio,epsilon,phase,"stationary",1.,True)
                direct.append(dict(k_over_m=ratio,phase=phase,epsilon=epsilon,expected_dc=-4*(1+ratio**-2),expected_double_carrier=4*(1+3*ratio**-2),**out))
    src=packet("band1","source-fine-heavy-1200.npz")
    pc=3.085677581491367e16;au=149597870700.;speed=299792458.;gee=6.67430e-11
    inverse_compton=float(src["mass"])/(1e6*pc)
    for name,length in (("1 AU",au),("1 pc",pc),("2π reduced Compton lengths",2*np.pi/inverse_compton),("10 kpc",1e4*pc)):
        wavenumber=2*np.pi/length;mu=(inverse_compton/wavenumber)**2
        pref=4*np.pi*gee/(speed**2*wavenumber**2)
        scales.append(dict(fourier_wavelength=name,wavelength_m=length,k_over_inverse_compton=wavenumber/inverse_compton,
            mean_induced_Ricci_ratio_per_kg_m3=pref*4*(1+mu),phase_uniform_induced_Ricci_ratio_per_kg_m3=pref*(8+16*mu),
            max_lapse_for_perturbation_parameter_one=min(1.,1/(2*mu))))
    table(safe("local-tidal-controls.csv"),direct);table(safe("local-tidal-density-coefficients.csv"),scales)
    print("predicted active tidal response, maximum relative error",max(r["relative_trace_error"] for r in direct),flush=True)
if __name__=="__main__":compare()

