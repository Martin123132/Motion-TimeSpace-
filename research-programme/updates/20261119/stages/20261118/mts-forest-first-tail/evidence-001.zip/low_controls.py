from assess import scale_diff
from contrast import *

def verify_low():
    gate()
    design,templates=weights()
    grid=nodes("low")
    assert np.array_equal(grid[::8],np.array(design["q"]))
    assert (np.diff(grid)>0).all() and len(grid)==49
    checks=[]
    def record(name,arm,tag,limit,error):
        error=np.asarray(error)
        assert np.isfinite(error).all() and np.all(error>=0)
        checks.append(dict(test=name,arm=arm,surface=tag,limit=limit,maximum=float(error.max()),tested=int(error.size),failed=int(np.sum(error>=limit))))
    for tag in ("1200","1500"):
        seed=packet("bandlow",f"seed-fine-{tag}.npz")
        assert np.array_equal(seed["k"],grid) and len(seed["eligible"])==49
        for field,limit in (("pe",2e-6),("de",2e-5),("qe",2e-5)):
            record(field,"field",tag,limit,abs(seed[field]))
    bridge=packet("bandlow","bridge-fine.npz")
    assert np.array_equal(bridge["k"],grid)
    for idx,field in enumerate(("D","Q","P")):
        record("interface-"+field,"field","both",2e-6 if idx==2 else 2e-5,abs(bridge["defect"][:,idx]))
    for arm in ("wave","exact","off","cold"):
        gasref=None
        for tag in (("225",) if arm=="cold" else ("1200","1500")):
            case,tag=scenario(arm,tag)
            src=packet("bandlow",f"source-fine-{case}-{tag}.npz")
            heated=packet("bandlow",f"gas-fine-{case}-{tag}.npz")
            assert np.array_equal(src["k"],grid) and np.array_equal(heated["k"],grid)
            record("metric-constraint",arm,tag,2e-5,abs(src["constraint"]))
            if arm in ("exact","cold"):
                record("unheated-native",arm,tag,2e-5,scale_diff(heated[arm+"-native"],src["truth"]))
            for label in temperatures(arm):
                key=arm+"-"+label
                center=heated[key+"-2048-1"]
                for alt in ("1024-1","2048-2"):
                    record(key+"-"+alt,arm,tag,2e-5,scale_diff(heated[key+"-"+alt],center))
                if gasref is not None:
                    record(key+"-surface",arm,tag,2e-5,scale_diff(center,gasref[key+"-2048-1"]))
            if gasref is None:gasref=heated
    table(safe("low-source-controls.csv"),checks)
    sample=rows(safe("finite-support-contrast.csv"));high=rows(safe("finite-support-tail-tests.csv"))
    scores=[]
    for row in sample:
        if row["variant"]!="full" or row["tag"]=="1500":continue
        same=[r for r in sample if (r["arm"],r["label"],r["name"])==(row["arm"],row["label"],row["name"])]
        value=float(row["contrast"]);scale=float(row["absolute_weight_low_power"])
        assert scale>0
        for other in same:
            change=float(other["contrast"])-value
            scores.append(dict(arm=row["arm"],label=row["label"],name=row["name"],surface=other["tag"],test=other["variant"],
                difference=change,relative_to_contrast=change/value if value else None,relative_to_absolute_power=change/scale))
    table(safe("low-contrast-sensitivity.csv"),scores)
    print("low source checks",len(checks),"failed samples",sum(r["failed"] for r in checks),"point-center exact exterior",max(abs(float(r["high_relative"])) for r in high if r["exact"]=="True"))
if __name__=="__main__":verify_low()

