from bank import *
from direct import direct

def temperatures(arm):
    picked={r["arm"]:r["temp"] for r in js(THERM/"matched-null-freeze.json")["choices"]}
    result={"reference":TREF}
    if arm in picked or arm=="exact":result["matched"]=picked.get(arm,picked["wave"])
    return result

def process(band,mesh,case,tag):
    gate()
    prefix="band"+band
    src=packet(prefix,f"source-{mesh}-{case}-{tag}.npz")
    results=dict(k=src["k"],h=src["h"][np.searchsorted(src["N"],src["epochs"])]*SPEED)
    ledger=[]
    for arm in (("wave","exact","off") if case=="heavy" else ("cold",)):
        null=gas.run(src,arm,0,2048,1)
        results[arm+"-native"]=null
        for label,temp in temperatures(arm).items():
            vals=[]
            for step,stride in ((2048,1),(1024,1),(2048,2)):
                fields=direct(src,arm,temp,step,stride)
                assert np.isfinite(fields).all()
                vals.append(fields)
                results[f"{arm}-{label}-{step}-{stride}"]=fields
            ledger.append(dict(arm=arm,label=label,source_native=peak_error(null,src["truth"]) if arm in ("exact","cold") else None,
                constraint=float(np.max(src["constraint"])),time=peak_error(vals[0],vals[1]),stride=peak_error(vals[0],vals[2])))
    save(safe(f"{prefix}-gas-{mesh}-{case}-{tag}.npz"),**results)
    table(safe(f"{prefix}-numerics-{mesh}-{case}-{tag}.csv"),ledger)
    print(band,mesh,case,tag,"max time",max(r["time"] for r in ledger),flush=True)
if __name__=="__main__":process(*sys.argv[1:])

