from contrast import *
from gas_cases import temperatures
import argparse

def verify(seal=False):
    gate()
    checks={}
    def check(name,condition):
        assert name not in checks and condition,name
        checks[name]=True
    protected={}
    for root,subfiles in ((PARENT,["session.py","switch.py","wide.py","bridge.py","build.py","native.diff","PhaseMesh.f90","build.json"]),
                            (THERM,["spectrum.py","common.py","direct.py","compare.py","angular.py","tail_moments.py","matched-null-freeze.json","matched-temperature-wave.npz","matched-temperature-off.npz","forecast-lock.json"])):
        record=js(root/"closeout.json")
        for name in subfiles+([item for item in record["files"] if item.startswith(("source-fine-","source-wide-","gas-fine-","gas-wide-","engine/"))] if root==PARENT else []):
            path=root/name
            check("previous artifact unchanged "+root.name+"/"+name,digest(path)==record["files"][name])
            protected[str(path)]=record["files"][name]
        protected[str(root/"closeout.json")]=digest(root/"closeout.json")
        for path,value in record["protected"].items():
            if path not in protected:
                check("upstream dependency "+path,digest(path)==value)
                protected[path]=value
    for path in (POST/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md",prior.MATCH/"native/fortran/subroutines.f90",OLD/"transfer.py",OLD/"gas.py",prior.table("1200"),prior.table("1500"),prior.table("225"),prior.COLD):
        value=digest(path)
        check("field/control input "+path.name+str(path.parent),value==protected.get(str(path),value))
        protected[str(path)]=value
    check("thermal parent fingerprint",digest(THERM/"closeout.json")==THERM_LOCK)
    for path,value in js(PARENT/"build.json")["inputs"].items():
        check("native build input "+path,digest(path)==value)
        protected[path]=value
    for style in ("resolve","trace"):
        result=js(safe(style+"-build.json"))
        check(style+" private compiled binary",digest(safe("engine-"+style+"/native/camb/cambdll.dll"))==result["binary"] and result["parent"]==digest(PARENT/"build.json"))
    for name in ("cov_H_inverted.pkl","upstream.txt"):
        source=POST/"mts-forest-transfer-test-20261118";path=source/"release"/name;expected=js(source/"release.json")[name]["sha256"]
        check("covariance source "+name,digest(path)==expected);protected[str(path)]=expected
    design,templates=weights();source=rows(safe("source-controls-1.csv"));release=js(safe("first-release.json"))
    check("prespecified angular weights",design["protocol_sha"]==digest(safe("COMPENSATED-DESIGN.md")) and all(float(x["residual"])<1e-55 for x in design["weights"].values()))
    check("angular freeze predates low native acquisition",(safe("weights.json").stat().st_mtime_ns < safe("bandlow-windows-fine.npz").stat().st_mtime_ns))
    for band,size,meshes in (("low",49,["fine"]),("1",17,["fine","coarse"])):
        k=nodes(band)
        check("node count "+band,len(k)==size and np.all(np.diff(k)>0))
        for mesh in meshes:
            for tag in ("1200","1500"):
                seed=packet("band"+band,f"seed-{mesh}-{tag}.npz")
                check("source eligibility "+band+mesh+tag,np.array_equal(k,seed["k"]) and np.all(seed["eligible"]) and max(seed["pe"])<2e-6 and max(max(seed["de"]),max(seed["qe"]))<2e-5)
            bridge=packet("band"+band,f"bridge-{mesh}.npz");check("independent endpoint "+band+mesh,np.all(abs(bridge["defect"])<np.array([2e-5,2e-5,2e-6])))
            for case,tag in (("heavy","1200"),("heavy","1500"),("cold","225")):
                native=packet("band"+band,f"source-{mesh}-{case}-{tag}.npz");gasout=packet("band"+band,f"gas-{mesh}-{case}-{tag}.npz")
                ident=band+mesh+case+tag
                check("metric source "+ident,np.array_equal(native["k"],k) and native["truth"].shape==(7,len(k),3) and np.all(abs(native["constraint"])<2e-5))
                check("gas output "+ident,np.array_equal(gasout["k"],k) and all(np.isfinite(val).all() for val in gasout.values()))
    alltrue=all(r["passes"]=="True" for r in source) and all(float(r["max_peak_transfer"])<2e-5 for r in rows(safe("seam-1.csv")))
    check("controlled release decision matches individual tests",len(source)==17*7 and release["permitted"]==alltrue and release["source_hash"]==digest(safe("source-controls-1.csv")))
    obs=rows(safe("observable-controls-1.csv"));check("relative exceptions disclosed",sum(abs(float(r["relative_kernel"]))>=2e-5 for r in obs)==release["relative_kernel_exceptions"])
    lc=rows(safe("low-source-controls.csv"));check("low source tests complete",len(lc)>40 and {r["arm"] for r in lc}=={"field","wave","off","exact","cold"})
    ext=rows(safe("finite-support-tail-tests.csv"));check("independent exterior cancellation",max(abs(float(r["high_relative"])) for r in ext if r["exact"]=="True")<1e-12)
    block=rows(safe("through-1-external-cancellation.csv"))
    target=[r for r in block if (r["name"]=="dual" and r["label"]=="matched") or (r["name"]!="dual" and r["label"]=="reference")]
    check("new short scales independently cancel",len(target)>10 and max(abs(float(r["relative_to_absolute_weight"])) for r in target)<1e-12)
    for row in rows(safe("through-1-powers.csv")):
        current=float(row["partial"]);prev=float(row["previous"]);total=float(row["total"])
        check("positive finite-band norm "+row["arm"]+row["label"]+row["z"],0<prev<total and current>0 and abs(total-prev-current)<5e-14*total)
    for row in rows(safe("through-1-gram.csv")):
        check("positive Gram variance and reassembly "+row["arm"]+row["label"],abs(float(row["joined_variance"])-float(row["J"]))<1e-11 and float(row["J"])>=0)
    cov=js(safe("noise-design.json"));check("covariance only",not cov["observed_flux_read"] and not cov["real_window_available_in_used_input"] and np.all(np.linalg.eigvalsh(cov["covariance"])>0))
    sensitivity=rows(safe("normalization-sensitivity.csv"))
    check("normalization projection",len(sensitivity)==4 and all(0<=float(r["free_amplitude_sigma"])<=float(r["fixed_sigma"])+1e-14 for r in sensitivity))
    prof=next(float(r["fixed_sigma"]) for r in sensitivity if r["label"]=="reference")
    optimum=next(float(r["conditional_point_bin_separation_over_sigma"]) for r in rows(safe("ideal-bin-sensitivity.csv")) if r["name"]=="design-optimum")
    check("independent optimum/quotient agree",abs(prof-abs(optimum))<1e-12*max(1,prof))
    for band in ("1","low"):
        newton=rows(safe(f"newton-reduction-{band}.csv"));slow=rows(safe(f"slow-gravity-{band}.csv"))
        check("direct Newton reductions "+band,len(newton)==60 and {r["choice"] for r in newton}=={"all","cluster","comoving"})
        check("positive frozen growth "+band,len(slow)==len(nodes(band))*5 and all(int(r["positive_eigenvalues"])==1 and 0<float(r["growing_lambda_over_G"])<=1+1e-10 for r in slow))
    stability=js(safe("slip-stability.json"));check("stability polynomial",len(stability["stability_coefficients"])>=7 and stability["negative_real_stability_limit"]>0 and stability["drag"]>0)
    live=rows(safe("live-switch-1.csv"));check("live arms all complete",len(live)==16 and all(float(r["force_off_on"])==1. for r in live if r["case"]=="cold"))
    kg=rows(safe("local-KG-metric-controls.csv"))
    check("nonlinear covariant field in the imposed metric",len(kg)==24 and all(abs(float(r["profile_error"]))<2e-5 and abs(float(r["energy_drift"]))<2e-10 for r in kg))
    check("predicted material susceptibilities",all(float(r["relative_density_error"])<2e-5 and float(r["absolute_pressure_error"])<2e-5 for r in kg if r["relative_density_error"]))
    check("independent zero occupation controls",all(float(r["density"])==float(r["pressure"])==0. for r in kg if float(r["amplitude"])==0))
    cold=rows(safe("rolling-cold-comparison.csv"));check("identical treatment for cold and both heavy branches",len(cold)==18 and all(float(r["fixed_separation_sigma"])==0 for r in cold if r["truth"]==r["rival"]))
    independent=rows(safe("forecast-refinement-controls.csv"));check("independent contrast basis and numerical refinements",len(independent)==30 and len({r["test"] for r in independent})==5)
    tides=rows(safe("local-tidal-controls.csv"))
    check("instantaneous tidal-source response",len(tides)==12 and all(float(r["relative_trace_error"])<2e-5 and float(r["direct_trace_identity"])<1e-12 and abs(float(r["measured_double_carrier"])/float(r["expected_double_carrier"])-1)<2e-5 for r in tides))
    check("no scratch or pycache",not list(HERE.rglob("__pycache__")) and not list(HERE.glob("tmp-*")))
    check("readable physics, results and replay",all(safe(name).stat().st_size>500 for name in ("RESULTS.md","REPLAY.md","DISTINGUISHABILITY.md","ANGULAR-REMAINDER.md")))
    files={p.relative_to(HERE).as_posix():digest(p) for p in sorted(HERE.rglob("*")) if p.is_file() and p.name!="closeout.json"}
    receipt=dict(parent=THERM_LOCK,checks=checks,protected=protected,files=files)
    if seal:dump(safe("closeout.json"),receipt)
    else:assert js(safe("closeout.json"))==receipt
    print(len(checks),"checks",len(protected),"external files",len(files),"artifacts",digest(safe("closeout.json")))
if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("--seal",action="store_true");verify(parser.parse_args().seal)

