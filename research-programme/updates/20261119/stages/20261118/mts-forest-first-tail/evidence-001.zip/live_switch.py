from bank import *
from diagnostic_build import bind

def test(band,arm,case="heavy"):
    prior.guard();assert not (HERE/"STOP-REQUESTED").exists() and digest(THERM/"closeout.json")==THERM_LOCK
    sys.path.insert(0,str(PARENT));import session
    bind("resolve")
    tag="1200" if case=="heavy" else "225"
    keys=np.array([0,4,8,16]);grid=nodes(band);session.K=grid[keys]
    import switch
    target=HERE/f"live-four-{band}";target.mkdir(exist_ok=True)
    switch.ROOT=target
    def source(name):
        seed=packet("band"+band,name)
        return {key:(arr[keys] if arr.shape==grid.shape else arr) for key,arr in seed.items()}
    switch.load=source;switch.save=lambda name,**vals:save(target/name,**vals)
    switch.run("fine",case,tag,arm)

def compare_live(band):
    gate();out=[]
    for case,tag in (("heavy","1200"),("cold","225")):
        k=nodes(band);keys=np.array([0,4,8,16])
        g=packet("band"+band,f"gas-fine-{case}-{tag}.npz");target=HERE/f"live-four-{band}"
        get=lambda arm:archive(target/f"switch-fine-{case}-{tag}-{arm}/result.npz")
        on=get("on");off=get("off")
        assert np.array_equal(on["raw"][:,0],off["raw"][:,0]) and np.array_equal(on["k"],k[keys])
        for initial in (target/f"switch-fine-{case}-{tag}-on").glob("initial-*.bin"):
            assert digest(initial)==digest(target/f"switch-fine-{case}-{tag}-off"/initial.name)
        if case=="cold":assert np.array_equal(on["raw"],off["raw"])
        for arm,branch in (("on",on),("off",off)):
            surrogate=g[("cold" if case=="cold" else ("exact" if arm=="on" else "off"))+"-native"][:,keys,:]
            for j,mode in enumerate(k[keys]):
                out.append(dict(case=case,arm=arm,k=mode,unheated_peak=peak_error(surrogate[:,j],branch["obs"][:,j]),
                    force_off_on=off["obs"][-1,j,0]/on["obs"][-1,j,0],off_heavy_density=off["D"][j,-1],on_heavy_density=on["D"][j,-1]))
    table(safe(f"live-switch-{band}.csv"),out);print("max reduced vs live",max(r["unheated_peak"] for r in out),flush=True)

if __name__=="__main__":
    if sys.argv[1]=="score":compare_live(sys.argv[2])
    else:test(*sys.argv[1:])

