from bank import *
from scipy.integrate import solve_ivp

def evolve(ratio,epsilon,phase,preparation,amplitude,trace=False):
    count=24
    coordinate=np.arange(count)*2*np.pi/count
    harmonic=np.cos(coordinate)
    wave_numbers=np.fft.fftfreq(count,d=1/count)
    def gradient(value):
        return np.fft.ifft(1j*wave_numbers*np.fft.fft(value)).real
    lapse=np.sqrt(1+2*epsilon*harmonic);spatial=np.sqrt(1-2*epsilon*harmonic)
    equilibrium=1-2*epsilon*harmonic/ratio**2
    profile=equilibrium if preparation=="stationary" else np.ones(count)
    height=amplitude*np.cos(phase)*profile
    velocity=-amplitude*np.sin(phase)*profile
    start=np.r_[height,spatial**3/lapse*velocity]
    def rhs(time,state):
        field,momentum=np.split(state,2)
        return np.r_[lapse/spatial**3*momentum,ratio**2*gradient(lapse*spatial*gradient(field))-lapse*spatial**3*field]
    times=np.linspace(0,2*np.pi,257)
    sol=solve_ivp(rhs,(0,times[-1]),start,t_eval=times,method="DOP853",rtol=2e-12,atol=2e-14,max_step=.08)
    assert sol.success and sol.t.size==times.size
    field,momentum=np.split(sol.y.T,2,axis=1);kinetic=(momentum/spatial**3)**2
    grad=(ratio*gradient(field)/spatial)**2
    density=.5*(kinetic+grad+field**2);stress=.5*(kinetic-grad/3-field**2)
    killing=np.mean(lapse*spatial**3*density,axis=1)
    if trace:
        assert preparation=="stationary" and amplitude>0
        basis=np.cos(2*(times+phase))
        source=2*np.mean((2*kinetic-field**2)*harmonic,axis=1)/(.5*amplitude**2*epsilon)
        predicted=-4*(1+ratio**-2)+4*(1+3*ratio**-2)*basis
        ceiling=8+16/ratio**2
        return dict(relative_trace_error=max(abs(source-predicted))/ceiling,measured_dc=np.trapezoid(source,times)/(2*np.pi),
            measured_double_carrier=np.trapezoid(source*basis,times)/np.pi,peak=max(abs(source)),ceiling=ceiling,
            direct_trace_identity=np.max(abs((density+3*stress)-(2*kinetic-field**2))))
    if amplitude==0:
        assert np.count_nonzero(sol.y)==0 and np.count_nonzero(killing)==0
        return dict(density=0.,pressure=0.,profile_error=0.,energy_drift=0.)
    carrier=amplitude*np.cos(times+phase)
    target=(-2*epsilon/ratio**2)*carrier
    if preparation=="sudden":
        assert phase==0
        target=target+2*epsilon/ratio**2*amplitude*np.cos(np.sqrt(1+ratio**2)*times)
    projection=lambda arr:2*np.mean(arr*harmonic,axis=-1)
    rho=amplitude**2/2
    return dict(density=np.trapezoid(projection(density),times)/(2*np.pi*rho*epsilon),
        pressure=np.trapezoid(projection(stress),times)/(2*np.pi*rho*epsilon),
        profile_error=np.max(abs(projection(field)-target))/(2*epsilon/ratio**2*amplitude),
        energy_drift=np.max(abs(killing/killing[0]-1)))

def calculate():
    gate();ledger=[];history=[]
    for ratio in (.25,1.,4.):
        for amp,phase,prep in ((1.,0.,"stationary"),(1.,.73,"stationary"),(1.,0.,"sudden"),(0.,0.,"stationary")):
            for base in (1e-4,5e-5):
                epsilon=base*min(1.,ratio**2)
                ans=evolve(ratio,epsilon,phase,prep,amp)
                compare=prep=="stationary" and amp>0
                rho=-(1+4/ratio**2)
                ledger.append(dict(k_over_m=ratio,amplitude=amp,phase=phase,preparation=prep,metric_epsilon=epsilon,**ans,
                    relative_density_error=abs(ans["density"]/rho-1) if compare else None,
                    absolute_pressure_error=abs(ans["pressure"]+1) if compare else None))
    for band in ("low","1"):
        for case,tag in (("heavy","1200"),("cold","225")):
            native=packet("band"+band,f"source-fine-{case}-{tag}.npz")
            for zi in FOUR:
                stamp=np.searchsorted(native["N"],native["epochs"][zi]);scale=native["a"][stamp];hh=native["h"][stamp]
                mass=float(native["mass"]);g=native["g"][2,stamp]
                for mode in native["k"]:
                    ratio=mode/(scale*mass);stiff=mode**4/(4*(scale*mass)**2)
                    rest=stiff-g
                    history.append(dict(band=band,case=case,z=Z[zi],k=mode,k_over_am=ratio,
                        proper_reduced_Compton_pc=1e6/mass,proper_wavelength_kpc=2*np.pi*scale/mode*1000,
                        nonrel_static_energy_density_fraction_missing=ratio**2/(4+ratio**2) if case=="heavy" else None,
                        static_local_susceptibility_KG_per_unit_density=-(1+4/ratio**2) if case=="heavy" else None,
                        g_heavy_over_S=g/stiff,omega_env_over_H=np.sqrt(stiff)/hh,
                        frozen_static_force_excess=g/rest if rest>0 else None,stable_oscillatory_operator=rest>0,
                        induced_half_frequency_ceiling=g/(.75*stiff-g) if .75*stiff>g else None))
    table(safe("local-KG-metric-controls.csv"),ledger);table(safe("local-domain-in-cosmological-bank.csv"),history)
    print("nonlinear KG test:",max(r["relative_density_error"] or 0. for r in ledger),max(r["absolute_pressure_error"] or 0. for r in ledger),max(r["profile_error"] for r in ledger),max(r["energy_drift"] for r in ledger))
if __name__=="__main__":calculate()

