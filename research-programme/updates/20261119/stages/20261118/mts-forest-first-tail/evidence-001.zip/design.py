from bank import *
import mpmath as mp

def compute():
    gate();mp.mp.dps=85
    records=rows(POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv")
    sel=sorted([r for r in records if r["instrument"]=="HIRES" and float(r["z"])==4.2],key=lambda r:float(r["kv_s_per_km"]))
    q=[float(r["k_parent"]) for r in sel];kv=[mp.mpf(r["kv_s_per_km"]) for r in sel]
    assert len(q)==7 and q[-1]==spec.RADS[6]
    xx=[(v/kv[-1])**2 for v in kv]
    choices=js(THERM/"matched-null-freeze.json")["choices"]
    temps=[mp.mpf(str(r["temp"])) for r in choices]
    u0=mp.mpf(str(gas.KB))*10000*kv[-1]**2/(mp.mpf(str(gas.MP))*10**6)
    designs={}
    for name,live,constraints in (("four",list(range(3,7)),[(mp.mpf(10000),m) for m in range(3)]),("dual",list(range(7)),[(v,m) for v in temps for m in range(3)]),("robust",list(range(7)),[(mp.mpf(10000),m) for m in range(6)])):
        mat=mp.matrix([[mp.exp(-u0*t/10000*xx[j])*xx[j]**m for j in live] for t,m in constraints])
        minors=[(-1)**i*mp.det(mp.matrix([[mat[r,c] for c in range(len(live)) if c!=i] for r in range(mat.rows)])) for i in range(len(live))]
        norm=sum(map(abs,minors));assert norm>0
        w=[v/norm*mp.sign(minors[0]) for v in minors]
        residual=max(abs(v) for v in mat*mp.matrix(w));assert residual<mp.mpf('1e-55')
        allw=[mp.mpf(0)]*7
        for i,v in zip(live,w):allw[i]=v
        designs[name]=dict(w=[float(v) for v in allw],w_high=[str(v) for v in allw],residual=str(residual),live=live)
    saved=dict(z=4.2,q=q,kv=[float(v) for v in kv],x=[float(v) for v in xx],u0=float(u0),weights=designs,
        max_relative_remainder=float(mp.exp(u0/10)*(u0/10)**4/24),equal_root=[float(v) for v in temps],protocol_sha=digest(safe("COMPENSATED-DESIGN.md")))
    dump(safe("weights.json"),saved)
    print("normalized temperature-leak ceiling",saved["max_relative_remainder"])
if __name__=="__main__":compute()

