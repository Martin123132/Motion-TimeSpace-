from gas_cases import *

def extract(band,mesh,arm,tag):
    case="cold" if arm=="cold" else "heavy"
    key="225" if case=="cold" else tag
    name=f"{mesh}-{case}-{key}.npz"
    return packet("band"+band,"gas-"+name)

def handover(band,arm,label,temp):
    if band=="1":
        if label=="reference":
            data0=data("fine",arm,"1200","gas")
            return data0[arm+"-1-2048-1"][:,-1]
        if arm in ("wave","off"):
            return archive(THERM/f"matched-temperature-{arm}.npz")["fields"][:,-1]
        src=data("fine",arm,"1200","source")
        return direct(src,arm,temp,2048,1)[:,-1]
    return extract("1","fine",arm,"1200")[f"{arm}-{label}-2048-1"][:,-1]

def scale_diff(left,right):
    den=np.max(abs(right),axis=0,keepdims=True)
    return np.max(abs(left-right)/np.maximum(den,1e-25),axis=(0,2))

def assess(band):
    gate();k=nodes(band);out=[];links=[];klass=[];geometric=[]
    for arm in ("wave","off","exact","cold"):
        cold=arm=="cold"
        combos=[(mesh,tag) for mesh in ("fine","coarse") for tag in (("225",) if cold else ("1200","1500"))]
        runs={c:extract(band,*[c[0],arm,c[1]]) for c in combos}
        for label,temp in temperatures(arm).items():
            key=f"{arm}-{label}-2048-1"
            central=runs[combos[0]];ref=central[key]
            if band!="low":
                anchor=handover(band,arm,label,temp)
                links.append(dict(arm=arm,label=label,overlap=k[0],max_peak_transfer=peak_error(ref[:,:1],anchor[:,None,:]),max_direct_relative=np.max(abs(ref[:,0]/anchor-1))))
            errs={name:np.zeros(len(k)) for name in ("time","stride","clock","match","unheated","constraint","window","bridge")}
            def charged(mesh,tag):
                src=packet("band"+band,f"source-{mesh}-{'cold' if cold else 'heavy'}-{tag}.npz")
                bank=runs[mesh,tag];assert np.array_equal(src["k"],k)
                errs["constraint"]=np.maximum(errs["constraint"],src["constraint"])
                errs["unheated"]=np.maximum(errs["unheated"],scale_diff(bank[("cold" if cold else "exact")+"-native"],src["truth"]))
                if not cold:
                    seed=packet("band"+band,f"seed-{mesh}-{tag}.npz");br=packet("band"+band,f"bridge-{mesh}.npz")
                    errs["window"]=np.maximum(errs["window"],np.maximum.reduce([seed["pe"]/2e-6,seed["de"]/2e-5,seed["qe"]/2e-5]))
                    errs["bridge"]=np.maximum(errs["bridge"],np.max(abs(br["defect"])/np.array([2e-5,2e-5,2e-6]),axis=1))
            for mesh,tag in combos:
                charged(mesh,tag)
                cur=runs[mesh,tag][key];other=runs["coarse" if mesh=="fine" else "fine",tag][key]
                errs["clock"]=np.maximum(errs["clock"],scale_diff(cur,other))
                if not cold:errs["match"]=np.maximum(errs["match"],scale_diff(cur,runs[mesh,"1500" if tag=="1200" else "1200"][key]))
                for desc,suffix in (("time","1024-1"),("stride","2048-2")):
                    errs[desc]=np.maximum(errs[desc],scale_diff(runs[mesh,tag][arm+"-"+label+"-"+suffix],cur))
            for j,kk in enumerate(k):
                values={key0:vec[j] for key0,vec in errs.items()}
                passes=all(values[c]<2e-5 for c in ("clock","match","time","stride","constraint","unheated")) and max(values["window"],values["bridge"])<1
                out.append(dict(arm=arm,label=label,k=kk,**values,passes=passes))
            for zi in FOUR:
                response,pref,_=spec.project(k,ref[zi],central["h"][zi],zi,temp/TREF)
                for mesh,tag in combos:
                    dat=runs[mesh,tag]
                    for desc,suffix in (("interface_clock","2048-1"),("time","1024-1"),("stride","2048-2")):
                        rs,ws,_=spec.project(k,dat[f"{arm}-{label}-{suffix}"][zi],dat["h"][zi],zi,temp/TREF)
                        peak=max(abs(response))
                        for j,node in enumerate(k):
                            klass.append(dict(arm=arm,label=label,z=Z[zi],mesh=mesh,tag=tag,test=desc,k=node,peak_error=(rs[j]-response[j])/peak,
                                relative_kernel=ws[j]*rs[j]**2/(pref[j]*response[j]**2)-1))
    table(safe(f"source-controls-{band}.csv"),out);table(safe(f"observable-controls-{band}.csv"),klass)
    if links:table(safe(f"seam-{band}.csv"),links)
    support=all(r["passes"] for r in out) and all(r["max_peak_transfer"]<2e-5 for r in links)
    if band=="1":dump(safe("first-release.json"),dict(permitted=bool(support),source_hash=digest(safe("source-controls-1.csv")),fails=sum(not r["passes"] for r in out),relative_kernel_exceptions=int(sum(abs(r["relative_kernel"])>=2e-5 for r in klass)),note="source/transport permission only; pointwise kernel exceptions are separate"))
    print(band,"pass",sum(r["passes"] for r in out),"/",len(out),"seams",links,"kernel exceptions",sum(abs(r["relative_kernel"])>=2e-5 for r in klass),flush=True)
if __name__=="__main__":assess(sys.argv[1])

