from bank import *
import difflib
import shutil
import subprocess

def build(style):
    gate()
    sys.path.insert(0,str(PARENT))
    import session
    from build import apply_hunks,replace_once
    native=prior.MATCH/"native";ft=native/"fortran";meta=js(PARENT/"build.json");tool=prior.EARLY/"toolchain/mingw64";compiler=tool/"bin/gfortran.exe"
    assert all(digest(p)==v for p,v in meta["inputs"].items())
    work=HERE/("tmp-"+style);runtime=HERE/("engine-"+style)
    assert not runtime.exists()
    blocks={}
    for section in read(PARENT/"native.diff").split("--- ")[1:]:
        name=section.split(".orig",1)[0];blocks[name]=apply_hunks(read(ft/(name+".f90")),"--- "+section)
    assert len(blocks)==4
    original=blocks["equations"]
    instrument="        write(*,*) 'tail-dverk k,tau,target,hmin,trial,norm,tol,imax,nvar',EV%q,tau,tauend,c(13),c(14),c(12),tol1,maxloc(abs(y(1:EV%ScalEqsToPropagate))),EV%ScalEqsToPropagate"
    blocks["equations"]=replace_once(original,"    if (ind==-3) then","    if (ind==-3) then\n"+instrument)
    if style=="resolve":
        mark="    call dverk(EV,EV%ScalEqsToPropagate,derivs,tau,y,tauend,tol1,ind,c,EV%nvar,w)"
        extra="""    if (ind==-3) then
        write(*,*) 'floor-entry',EV%q,tau,c(13),maxval(abs(y(1:EV%ScalEqsToPropagate))),EV%TightCoupling
        floor_value=c(13);c=0._dl;ind=2
        call get_environment_variable('MTS_PRIVATE_FLOOR',floor_name,status=floor_status)
        if(floor_status/=0) error stop 'explicit floor divisor required'
        read(floor_name,*) floor_divisor
        if(floor_divisor/=32 .and. floor_divisor/=512) error stop 'unsupported floor divisor'
        c(3)=max(64._dl*spacing(tau),floor_value/floor_divisor)
        c(4)=max(c(3),floor_value/floor_divisor)
        call dverk(EV,EV%ScalEqsToPropagate,derivs,tau,y,tauend,tol1,ind,c,EV%nvar,w)
        write(*,*) 'floor-exit',EV%q,tau,ind,c(13)
    end if"""
        blocks["equations"]=replace_once(blocks["equations"],mark,"    real(dl) floor_value\n    integer floor_status,floor_divisor\n    character(12) floor_name\n"+mark+"\n"+extra)
    else:assert style=="trace"
    mods=meta["commands"]
    binding=next(r for r in read(PARENT/"build.py").splitlines() if 'switch=replace_once(switch' in r)
    import ast
    call=ast.parse(binding.strip()).body[0].value
    forest=replace_once(read(prior.POST/"mts-forest-pressure-switch-20261118/ForestSwitch.f90"),ast.literal_eval(call.args[1]),ast.literal_eval(call.args[2]))
    work.mkdir(exist_ok=True);assert not list(work.iterdir())
    try:
        for path in meta["inputs"]:
            p=Path(path)
            if p.suffix in (".mod",".o",".spec") or p.name in ("f951.exe","collect2.exe"):shutil.copyfile(p,work/p.name)
        for name,src in dict(PhaseMesh=read(PARENT/"PhaseMesh.f90"),ForestSwitch=forest,**blocks).items():
            (work/(name+".f90")).write_text(src,encoding="utf8")
        rel=Path(os.path.relpath(tool,work));lib=["lib","lib/gcc/x86_64-w64-mingw32/14.2.0","x86_64-w64-mingw32/lib"]
        switches=["-B./",*["-B"+(rel/v).as_posix()+"/" for v in ["libexec/gcc/x86_64-w64-mingw32/14.2.0","bin",*lib]],*["-L"+(rel/v).as_posix() for v in lib],"-shared","-static","-cpp","-fopenmp","-O2","-fcheck=bounds","-fmax-errors=4","-fno-use-linker-plugin"]
        env=dict(os.environ,PATH=str(tool/"bin")+";"+os.environ["PATH"])
        for cmd in mods:
            ret=subprocess.run([str(compiler),*switches,*cmd],cwd=work,env=env,capture_output=True,text=True,timeout=180)
            if ret.returncode:raise RuntimeError(ret.stderr)
        pkg=runtime/"native/camb";pkg.mkdir(parents=True)
        for path in (PARENT/"engine/native/camb").iterdir():
            if path.is_file() and path.suffix in (".py",".dat"):shutil.copyfile(path,pkg/path.name)
        for name in ("matching_common.py","stage_common.py"):shutil.copyfile(PARENT/"engine"/name,runtime/name)
        shutil.copyfile(work/"mesh.dll",pkg/"cambdll.dll")
        dump(safe(style+"-build.json"),dict(binary=digest(pkg/"cambdll.dll"),diff=list(difflib.unified_diff(original.splitlines(),blocks["equations"].splitlines())),parent=digest(PARENT/"build.json")))
    finally:
        assert work.resolve().parent==HERE and work.name=="tmp-"+style
        for p in work.iterdir():
            assert p.is_file() and not p.is_symlink();p.unlink()
        work.rmdir()

def bind(style):
    import session
    def engine():
        where=HERE/("engine-"+style)
        sys.path[:0]=[str(where),str(session.BASE/"radiation-and-slow-field-transfer-20261007")]
        import matching_common as src
        assert Path(src.camb.__file__).resolve().parent==(where/"native/camb").resolve()
        assert digest(where/"native/camb/cambdll.dll")==js(safe(style+"-build.json"))["binary"]
        return src
    session.engine=engine

if __name__=="__main__":
    if sys.argv[1]=="build":build(sys.argv[2])
    else:
        sys.path.insert(0,str(PARENT));bind(sys.argv[2])
        if sys.argv[2]=="resolve":os.environ["MTS_PRIVATE_FLOOR"]=os.environ.get("MTS_PRIVATE_FLOOR","32")
        progress(*sys.argv[3:])

