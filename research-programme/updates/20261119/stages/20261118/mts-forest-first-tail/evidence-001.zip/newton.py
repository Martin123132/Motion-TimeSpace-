from gas_cases import *
from scipy.optimize import brentq

def approximation(source,arm,temp,choice):
    src=dict(source);src["init"]=source["init"].copy()
    phi_start=(source["truth"][0,:,1]-source["init"][:,1])/3
    src["init"][:,:2]+=3*phi_start[:,None]
    if arm!="cold":src["init"][:,2]+=3*phi_start
    original=gas.affine
    def limit(env,k,mass,branch,hot):
        a=env[...,0,None];h=env[...,1,None];g=env[...,None,2:5];cs=env[...,5,None]
        opacity=env[...,7,None];light=env[...,8,None]
        ext,slip,entropy,phot=np.moveaxis(env[...,9:].reshape(*env.shape[:-1],len(k),4),-1,0)
        kk=k*k
        co=np.zeros((*ext.shape,6,7));phi=np.zeros((*ext.shape,7))
        phi[...,:3]=-g/kk[...,None]
        if choice!="cluster":phi[...,6]=-ext/kk
        if choice=="comoving":phi[...,3:6]=3*(h/a)[...,None]*g/kk[...,None]
        psi=phi.copy()
        if choice!="cluster":psi[...,6]-=slip/kk
        for field in range(3):
            co[...,field,field+3]=kk/(a*h)
            co[...,field+3,:]=-(a/h)[...,None]*psi
        ramp=np.clip(np.log(10*a)/np.log(10/8),0,1)
        thermal=1.5*gas.KB*temp/(.61*gas.MP*(SPEED*1000)**2)*ramp**2*(3-2*ramp)
        co[...,4,1]-=a/h*(cs+thermal)
        co[...,4,4]-=4*light*opacity/(3*h)
        co[...,4,6]-=a/h*(entropy+light*opacity*phot/k)
        if branch=="wave":co[...,5,2]-=a/h*kk/(4*(a*mass)**2)
        elif branch=="cold":co[...,2,:]=0;co[...,5,:]=0
        else:assert branch=="off"
        return co,phi*0,psi
    try:
        gas.affine=limit
        return gas.run(src,arm,1,2048,1)
    finally:gas.affine=original

def measure(band):
    gate();ledger=[];stability=[];density=[]
    for arm in ("wave","off","cold"):
        case,tag=scenario(arm,"1200")
        source=packet("band"+band,f"source-fine-{case}-{tag}.npz");gas0=packet("band"+band,f"gas-fine-{case}-{tag}.npz")
        k=source["k"]
        for label,temp in temperatures(arm).items():
            ref=gas0[f"{arm}-{label}-2048-1"]
            for choice in ("all","cluster","comoving"):
                out=approximation(source,arm,temp,choice);scale=np.maximum(1e-25,np.max(abs(ref),axis=0))
                for zi in FOUR:
                    delta=abs(out[zi]-ref[zi])/scale
                    rr,pref,_=spec.project(k,ref[zi],gas0["h"][zi],zi,temp/TREF)
                    rq=spec.project(k,out[zi],gas0["h"][zi],zi,temp/TREF)[0]
                    cut=max(k[0],spec.RADS[zi]);area=lambda values:float(PchipInterpolator(np.log(k),values).integrate(np.log(cut),np.log(k[-1]))) if cut<k[-1] else None
                    f=area(rr**2*pref)
                    ledger.append(dict(band=band,arm=arm,label=label,choice=choice,z=Z[zi],max_force=max(delta[:,0]),max_gas=max(delta[:,1]),
                        max_velocity=max(delta[:,2]),peak_signed=max(abs(rq-rr))/max(abs(rr)),partial_power_change=area(rq**2*pref)/f-1 if f else None))
            zi=6;ind=np.searchsorted(source["N"],source["epochs"][zi]);a=source["a"][ind];h=source["h"][ind];g=source["g"][:,ind]
            cb=source["thermal"][ind,0]+1.5*gas.KB*temp/(.61*gas.MP*(SPEED*1000)**2)
            for j,node in enumerate(k):
                ss=np.array([0.,node**2*cb,node**4/(4*(a*source["mass"])**2) if arm=="wave" else 0.])
                active=g>0;weights=g[active]/sum(g);rates=ss[active]/sum(g)
                matrix=np.outer(np.sqrt(weights),np.sqrt(weights))-np.diag(rates)
                eig=np.linalg.eigvalsh(matrix);lam=eig[-1];gd=sum(weights[rates==0]);nz=rates>0
                low=gd+np.sum(weights[nz]*gd/(gd+rates[nz]));up=gd+np.sum(weights[nz]/(1+rates[nz]))
                assert abs(sum(weights/(lam+rates))-1)<2e-10 and low-1e-10<=lam<=up+1e-10
                stability.append(dict(arm=arm,label=label,k=node,z=Z[zi],k_over_h=node/h,pressure_over_gravity=ss[2]/sum(g),baryon_pressure_over_gravity=ss[1]/sum(g),
                    growing_lambda_over_G=lam,lower=low,upper=up,free_dust_fraction=gd,positive_eigenvalues=int(sum(eig>1e-10)),heavy_in_slow_eigenvector=lam/(lam+ss[2]/sum(g)) if arm!="cold" else None))
            w=spec.META["As"]*(k/spec.META["pivot_Mpc"])**(spec.META["ns"]-1)
            measure=lambda val:np.sqrt(PchipInterpolator(np.log(k),w*val**2).integrate(np.log(k[0]),np.log(k[-1])))
            density.append(dict(arm=arm,label=label,sigma_potential=measure(ref[zi,:,0]/k**2),sigma_force_div_H2=measure(ref[zi,:,0]/h**2),
                sigma_baryon=measure(ref[zi,:,1]),sigma_velocity_div_H=measure(ref[zi,:,2])))
    table(safe("newton-reduction-"+band+".csv"),ledger);table(safe("slow-gravity-"+band+".csv"),stability);table(safe("weak-metric-"+band+".csv"),density)
    print(band,"direct Newton comparison",[(r["arm"],r["max_force"],r["max_gas"]) for r in ledger if r["z"]==4.2 and r["choice"]=="all" and r["label"]=="reference"],flush=True)
if __name__=="__main__":measure(sys.argv[1])

