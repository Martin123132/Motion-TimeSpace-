from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
THERM=HERE.parent/"mts-forest-thermal-response-20261118"
sys.path.insert(0,str(THERM))
import spectrum as spec
from common import *
sys.path.remove(str(THERM))
sys.path.insert(0,str(THERM))
THERM_LOCK="f8ab4e7a37a59d63f6b427bb92bf60ab53ac8b547c0dc4dc0b21a5fb8d5303e6"

def gate():
    spec.locked()
    assert digest(THERM/"closeout.json")==THERM_LOCK and not (HERE/"STOP-REQUESTED").exists()
    assert not any(key in os.environ for key in ("MTS_FOREST_INDEX","MTS_FOREST_FACTOR","MTS_FOREST_SCALE"))

def safe(name):
    return HERE/name

def packet(prefix,name):
    return archive(safe(f"{prefix}-{name}"))

def nodes(band):
    if band=="low":
        limits=js(safe("weights.json"))["q"]
        return np.r_[limits[0],np.concatenate([np.geomspace(lo,hi,9)[1:] for lo,hi in zip(limits[:-1],limits[1:])])]
    b=int(band)
    assert b in (1,2)
    if b==2:
        release=js(safe("first-release.json"))
        assert release["permitted"] and release["source_hash"]==digest(safe("source-controls-1.csv"))
    return 37*2.**(np.arange(16*(b-1),16*b+1)/32.)

def progress(band,mesh,step,case="heavy",tag="1200"):
    gate()
    prefix="band"+band;k=nodes(band)
    sys.path.insert(0,str(PARENT))
    import session
    session.K=k
    def local_save(name,**vals):save(safe(prefix+"-"+name),**vals)
    def local_load(name):return packet(prefix,name)
    if step=="seed":
        import wide
        wide.save=local_save
        wide.seeds(mesh)
    elif step=="bridge":
        import bridge
        bridge.save=local_save;bridge.load=local_load
        bridge.run(mesh)
    else:
        assert step=="source" and mesh in ("coarse","fine")
        if case=="heavy":
            br=local_load("bridge-"+mesh+".npz")
            defect=abs(br["defect"])/np.array([2e-5,2e-5,2e-6])
            assert np.array_equal(br["k"],k) and np.all(defect<1.),(k[np.max(defect,axis=1)>=1],np.max(defect,axis=0))
        import transfer
        native=session.engine();session.use_mesh(native,mesh,tag if case=="heavy" else "none")
        transfer.native=lambda kind:native;transfer.modes=lambda panel:k;transfer.save=local_save;transfer.load=local_load
        transfer.run(mesh,case,tag,"full")
if __name__=="__main__":progress(*sys.argv[1:])

