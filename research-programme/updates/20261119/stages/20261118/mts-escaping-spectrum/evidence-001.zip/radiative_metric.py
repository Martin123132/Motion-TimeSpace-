from outgoing import np, ROOT, guard
from diagnostics import write_table
from scipy.special import roots_legendre, eval_legendre
from scipy.integrate import simpson
import csv


def main():
    guard()
    data = np.genfromtxt(ROOT/"retarded_signal.csv", delimiter=",", names=True)
    spec = np.genfromtxt(ROOT/"spectrum.csv", delimiter=",", names=True)
    mu, weights = roots_legendre(41)
    phi = np.arange(128)*2*np.pi/128
    solid = weights[:, None]*2*np.pi/128
    rows, closure = [], []
    for variant in (0, 1):
        news = data[f"spin{variant}_news"]
        energy = (2/3)*np.dot(spec["dk_weight"], spec[f"spin{variant}_dE_dk"])
        angular = simpson(news**2, x=data["u"])*(1-mu**2)/(4*np.pi)
        monopole = 2*np.pi*weights@angular
        momentum = 2*np.pi*(weights*mu)@angular
        moments = np.array([(2*ell+1)/2*(weights*eval_legendre(ell, mu))@angular for ell in range(7)])
        source = -energy/(4*np.pi)
        phi2 = 16*np.pi*moments[2]/12
        closure.append(dict(spin=variant, reduced_mass_loss=-energy, integrated_sky_energy=monopole,
                            fractional_energy_miss=abs(monopole/energy-1), recoil_momentum_over_energy=momentum/energy,
                            harmonic_leakage=max(abs(moments[[1,3,4,5,6]]/source)), quadrupole_error=abs(moments[2]/source-1),
                            equatorial_distance_times_strain=1.5*phi2))
        for degrees in (0, 15, 30, 45, 60, 75, 90, 135, 180):
            angle = np.deg2rad(degrees)
            sinpol = np.sqrt(1-mu[:, None]**2)
            projtheta, projphi = sinpol*np.cos(phi), sinpol*np.sin(phi)
            source_cos = np.cos(angle)*mu[:, None]-np.sin(angle)*projtheta
            fluence = simpson(news**2, x=data["u"])*(1-source_cos**2)/(4*np.pi)
            plus = 2*np.sum(solid*fluence*(projtheta**2-projphi**2)/(1-mu[:, None]))
            cross = 4*np.sum(solid*fluence*projtheta*projphi/(1-mu[:, None]))
            signed = -energy/2*np.sin(angle)**2
            rows.append(dict(spin=variant, inclination_deg=degrees, TT_plus=plus, TT_cross=cross, flux_law=signed,
                             sphere_constraint=1.5*phi2*np.sin(angle)**2,
                             TT_difference_on_equatorial_peak=abs(plus-signed)/(energy/2),
                             cross_on_equatorial_peak=abs(cross)/(energy/2)))
    write_table("bondi_loss.csv", closure)
    write_table("null_metric_memory.csv", rows)
    print(closure)


if __name__ == "__main__":
    main()

