from outgoing import PARENT, ROOT, guard, sha, np, json
from diagnostics import GATE, write_table
from scipy.interpolate import RectBivariateSpline

LAUNCH = np.linspace(.06, 4.9, 65)
FILES = []


class Slab:
    def __init__(self, mesh, amp):
        self.amp = amp
        names = [f"core-{mesh}-eta0.8-h{amp:g}.npz", f"driven-{mesh}-eta0.8-h{amp:g}-spin0.npz"]
        hashes = json.loads((PARENT/"closeout.json").read_text())["files"]
        for name in names:
            assert sha(PARENT/name) == hashes[name]
            FILES.append(name)
        with np.load(PARENT/names[0]) as src:
            rad = src["radius"]
            take = (rad >= 5.25) & (rad <= 7.25)
            radius = rad[take]
            time = src["time"]
            back = src["background"][:, :, take]
        def spline(clock, values):
            return RectBivariateSpline(clock, radius, values, kx=5, ky=5, s=0.)
        self.bridge = spline(time, back[:, 0])
        self.bridge_r = spline(time, back[:, 8])
        self.lapse = spline(time, back[:, 1])
        self.charge = .8*np.median(back[:, 4])
        self.charge_range = np.max(abs(.8*back[:, 4]-self.charge))
        self.max_dust = np.max(abs(back[:, 3]))
        with np.load(PARENT/names[1]) as src:
            assert np.array_equal(rad, src["radius"])
            field = src["fields"][:, :, take]
            self.wave = spline(src["time"], field[:, 0])
            self.out = spline(src["time"], (field[:, 1]-field[:, 2])/2)
    def rhs(self, rad, state):
        clock, logweight, forcing = state
        radius = np.full_like(clock, rad)
        bridge = self.bridge.ev(clock, radius)
        rate = self.bridge_r.ev(clock, radius)
        barrier = self.lapse.ev(clock, radius)*(2/rad**2+4*self.charge**2/rad**4)
        wave = self.wave.ev(clock, radius)
        return np.stack([1/bridge, -rate/bridge, -.5*np.exp(-logweight)*barrier*wave/bridge])
    def trace(self, resolution):
        state = np.stack([LAUNCH, np.zeros_like(LAUNCH), np.zeros_like(LAUNCH)])
        launch = self.out.ev(LAUNCH, np.full_like(LAUNCH, 5.5))
        step = 1.5/resolution
        records = []
        for tick in range(resolution):
            rad = 5.5+tick*step
            first = self.rhs(rad, state)
            second = self.rhs(rad+step/2, state+step/2*first)
            third = self.rhs(rad+step/2, state+step/2*second)
            fourth = self.rhs(rad+step, state+step*third)
            state += step/6*(first+2*second+2*third+fourth)
            if tick+1 in (resolution//3, resolution):
                clock, logweight, forcing = state
                site = 5.5+(tick+1)*step
                radius = np.full_like(clock, site)
                bridge = self.bridge.ev(clock, radius)
                predicted = bridge*np.exp(logweight)*(launch+forcing)
                no_barrier = bridge*np.exp(logweight)*launch
                observed = bridge*self.out.ev(clock, radius)
                assert max(clock) < 6.5 and min(clock) >= 0.
                records.append(np.stack([clock, predicted, no_barrier, observed]))
        return np.array(records)


def main():
    guard()
    measurements, traces = [], []
    for mesh in (960, 1920):
        arms = []
        for amplitude in (0., 1/160, 1.):
            slab = Slab(mesh, amplitude)
            small, fine = slab.trace(120), slab.trace(240)
            arms.append((small, fine))
            for idx, site in enumerate((6., 7.)):
                obs = fine[idx, 3]
                denom = np.max(abs(obs))
                measurements.append(dict(mesh=mesh, amplitude=amplitude, site=site, comparison="absolute",
                                         readout_peak=denom, discrepancy=np.max(abs(fine[idx, 1]-obs))/denom,
                                         step_change=np.max(abs(small[idx, 1]-fine[idx, 1]))/denom,
                                         no_barrier_miss=np.max(abs(fine[idx, 2]-obs))/denom,
                                         max_dust=slab.max_dust, charge_variation=slab.charge_range))
                for tick, launch in enumerate(LAUNCH):
                    traces.append(dict(mesh=mesh, amplitude=amplitude, site=site, launch=launch, arrival=fine[idx, 0, tick],
                                       propagated=fine[idx, 1, tick], no_barrier=fine[idx, 2, tick], receiver=obs[tick]))
        for idx, amplitude in enumerate((1/160, 1.), start=1):
            coarse, fine = [arms[idx][slot]-arms[0][slot] for slot in range(2)]
            for spot, site in enumerate((6., 7.)):
                obs = fine[spot, 3]
                denom = np.max(abs(obs))
                measurements.append(dict(mesh=mesh, amplitude=amplitude, site=site, comparison="difference",
                                         readout_peak=denom, discrepancy=np.max(abs(fine[spot, 1]-obs))/denom,
                                         step_change=np.max(abs(coarse[spot, 1]-fine[spot, 1]))/denom,
                                         no_barrier_miss=np.max(abs(fine[spot, 2]-obs))/denom,
                                         max_dust="", charge_variation=""))
    write_table("finite_transport.csv", measurements)
    write_table("finite_traces.csv", traces)
    print([(row["amplitude"],row["site"], float(row["discrepancy"]), float(row["step_change"])) for row in measurements if row["mesh"] == 1920])


if __name__ == "__main__":
    main()

