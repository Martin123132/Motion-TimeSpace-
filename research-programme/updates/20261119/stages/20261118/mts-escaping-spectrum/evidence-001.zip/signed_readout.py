from outgoing import ROOT, np, guard
from diagnostics import write_table
from scipy.integrate import simpson


def main():
    guard()
    spectrum = dict(np.load(ROOT/"checks.npz"))
    energies = np.genfromtxt(ROOT/"escape_energy.csv", names=True, delimiter=",")
    history = np.genfromtxt(ROOT/"retarded_signal.csv", names=True, delimiter=",")
    traces = np.genfromtxt(ROOT/"finite_traces.csv", names=True, delimiter=",")
    clock = history["u"]
    rows, soft, mesh_results = [], [], []
    for spin in (0, 1):
        news = history[f"spin{spin}_news"]
        moment = energies["soft_moment"][spin]
        for end in (6., 10., 16.):
            use = clock <= end
            estimate = -simpson((clock*news)[use], x=clock[use])
            rows.append(dict(spin=spin, start=clock[0], end=end, net_news=simpson(news[use], x=clock[use]),
                             inferred_moment=estimate, stationary_moment=moment, relative_miss=abs(estimate/moment-1)))
        for idx, freq in enumerate(spectrum["k"]):
            soft.append(dict(spin=spin, k=freq, curved_density=abs(spectrum["news"][idx, spin])**2/np.pi,
                             flat_density=abs(spectrum["flat"][idx, spin])**2/np.pi,
                             density_ratio=abs(spectrum["news"][idx, spin]/spectrum["flat"][idx, spin])**2))
    for site in (6., 7.):
        for amp in (1/160, 1.):
            for field in ("receiver", "propagated"):
                delta = []
                for mesh in (960, 1920):
                    part = traces[(traces["mesh"]==mesh) & (traces["site"]==site)]
                    base, changed = part[part["amplitude"]==0], part[part["amplitude"]==amp]
                    assert np.array_equal(base["launch"], changed["launch"])
                    delta.append(changed[field]-base[field])
                mesh_results.append(dict(radius=site, amplitude=amp, field=field,
                                         relative_change=max(abs(delta[0]-delta[1]))/max(abs(delta[1]))))
    write_table("signed_tail.csv", rows)
    write_table("long_wavelength_control.csv", soft)
    write_table("transfer_mesh.csv", mesh_results)


if __name__ == "__main__":
    main()

