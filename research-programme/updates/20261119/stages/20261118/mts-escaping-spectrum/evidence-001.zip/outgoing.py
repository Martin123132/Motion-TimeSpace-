import os
import sys
import json
from pathlib import Path

for variable in ("OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "OMP_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
    os.environ[variable] = "1"
sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
PARENT = ROOT.parent / "mts-driven-current-20261118"
sys.path.insert(0, str(PARENT))
from current_source import MASS, DENSITY, guard as parent_guard, sha, spin, np
from static_modes import static
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from scipy.special import roots_legendre, spherical_jn

LOCK = "de420586aa95be651494e7cc86da72645ebf25d61a795534685ebb81df749568"
RADII = np.array([5., 5.5, 6., 7.])


def guard():
    parent_guard()
    assert sha(PARENT/"closeout.json") == LOCK
    assert not (ROOT/"STOP-REQUESTED").exists()


def nodes(width, order, count):
    knots, weights = roots_legendre(order)
    return ((np.arange(count)[:, None] + (1+knots)/2)*width).ravel(), np.tile(weights*width/2, count)


def geometry():
    radii = np.linspace(0, 5, 1001)
    enclosed, density, lapse, alpha, bridge = static(radii)
    rate = np.divide(enclosed, radii**2, out=np.zeros_like(radii), where=radii != 0)
    normal = alpha/lapse
    table = CubicSpline(radii, np.stack([1/bridge**2, (2*rate-radii*density)/normal,
                                          3*density/normal+6*(rate/normal)**2], axis=1))
    knots, weights = nodes(.25, 16, 20)
    enclosed, density, lapse, alpha, bridge = static(knots)
    direct, slope, term = [], [], []
    for variant in (0, 1):
        law, integral = spin(enclosed, variant)
        direct.append(weights*(knots**2*density*alpha*law+4*lapse*enclosed*integral/knots**2))
        slope.append(-weights*integral*alpha)
        term.append(weights*integral*3*lapse*enclosed/knots**2)
    return table, knots, np.array(direct), np.array(slope), np.array(term), weights @ (1/bridge)


def regular(freq, geom):
    table, knots, direct, slope, term, _ = geom
    start = 1.e-6
    count = len(freq)
    def rhs(rad, state):
        invb2, logb, restore = table(rad)
        val, grad = state[:count], state[count:]
        return np.r_[grad, (restore-freq**2*invb2)*val-(4/rad+logb)*grad]
    accel = (3*DENSITY-freq**2*table(0)[0])/5
    sol = solve_ivp(rhs, (start, 5.), np.r_[1+accel*start**2/2, accel*start],
                    method="DOP853", t_eval=np.r_[knots, 5.], rtol=1.e-11, atol=1.e-14)
    assert sol.success and sol.t[-1] == 5.
    val, grad = sol.y[:count], sol.y[count:]
    signed = val[:, :-1]@term.T+grad[:, :-1]@slope.T
    unsplit = val[:, :-1]@direct.T
    return 25*val[:, -1], 10*val[:, -1]+25*grad[:, -1], signed, unsplit


def exterior(freq, x5, far=45., degree=14, mass=MASS):
    eps = mass*freq
    count = len(freq)
    top = np.maximum(far, 7*freq+far*.5)
    coeff = [np.ones(count, dtype=complex)]
    for order in range(1, degree+1):
        num = ((order-1)*order-2)*coeff[-1]
        if order >= 2:
            num = num-2*eps*(order-2)*order*coeff[-2]
        if order >= 3:
            num = num+eps**2*((order-3)*order-4)*coeff[-3]
        coeff.append(num/(2j*order))
    val = sum(coef/top**order for order, coef in enumerate(coeff))
    grad = sum(-order*coef/top**(order+1) for order, coef in enumerate(coeff))
    state = np.r_[val, grad]
    values, slopes = [], []
    for radius in RADII[::-1]:
        target = radius*freq
        span = np.log(target/top)
        def rhs(clock, state):
            arg = top*np.exp(clock*span)
            val, grad = state[:count], state[count:]
            normal = 1-eps/arg
            bridge = normal**2
            bridge_z = 2*normal*eps/arg**2
            second = ((2/arg**2+4*eps**2/arg**4)*val-(bridge_z+2j)*grad)/bridge
            return np.r_[span*arg*grad, span*arg*second]
        sol = solve_ivp(rhs, (0., 1.), state, method="DOP853", rtol=2.e-11, atol=2.e-14, t_eval=[1.])
        assert sol.success
        state = sol.y[:, -1]
        top = target
        optical = x5+radius-5+2*mass*np.log((radius-mass)/(5-mass))-mass**2*(1/(radius-mass)-1/(5-mass))
        phase = np.exp(1j*freq*optical)
        bridge = (1-mass/radius)**2
        values.append(phase*state[:count])
        slopes.append(freq*phase*(state[count:]+1j*state[:count]/bridge))
    return np.array(values[::-1]).T, np.array(slopes[::-1]).T


def evaluate(freq, geom, far=45.):
    reg, grad, overlap, raw = regular(freq, geom)
    val, slope = exterior(freq, geom[-1], far)
    bridge = (1-MASS/RADII)**2
    wronskian = bridge[0]*(grad*val[:, 0]-reg*slope[:, 0])
    outgoing = overlap/wronskian[:, None]
    conserved = np.imag(val.conj()*slope)*bridge[None, :]/freq[:, None]
    return outgoing, val, slope, raw/wronskian[:, None], conserved


def flat_news(freq, geom):
    _, radii, _, _, _, _ = geom
    knots, weights = nodes(.25, 16, 20)
    label, density, _, _, _ = static(knots)
    arg = freq[:, None]*radii
    shape = arg*spherical_jn(1, arg)
    small = np.abs(arg) < .1
    sq = arg[small]**2
    difference = shape-arg**2/3
    difference[small] = sq**2*(-1/30+sq*(1/840+sq*(-1/45360+sq/3991680)))
    result = []
    for variant in (0, 1):
        law, _ = spin(label, variant)
        normal = weights*density*law
        result.append(np.where(freq<.15, difference@normal, shape@normal)/(1j*freq))
    return np.array(result).T


def generate(mode):
    guard()
    import psutil
    proc = psutil.Process()
    proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    geom = geometry()
    if mode == "checks":
        freq = np.r_[.000003, .00001, .00003, .0001, .0003, .001, .005, .02, .1, .4, 1., 2., 4., 12., 23., 41.]
        weight = np.zeros(len(freq))
    else:
        width = {"fine": .25, "checkgrid": .5}[mode]
        freq, weight = nodes(width, 8, int(48/width))
    blocks = []
    for first in range(0, len(freq), 64):
        guard()
        blocks.append(evaluate(freq[first:first+64], geom))
    rows = [np.concatenate(column, axis=0) for column in zip(*blocks)]
    extra = {}
    if mode == "checks":
        extra["far_alt"] = evaluate(freq, geom, 70.)[0]
        exterior_flat = exterior(freq, 5., mass=0.)[0]
        analytic = np.exp(1j*freq[:, None]*RADII)*(1+1j/(freq[:, None]*RADII))
        extra["flat_jost_error"] = np.abs(exterior_flat/analytic-1)
    with (ROOT/f"{mode}.npz").open("xb") as stream:
        np.savez_compressed(stream, k=freq, weight=weight, news=rows[0], exterior=rows[1], dr=rows[2],
                            raw=rows[3], current=rows[4], flat=flat_news(freq, geom), x5=geom[-1], **extra)
    print(mode, len(freq), flush=True)


if __name__ == "__main__":
    generate(sys.argv[1])

