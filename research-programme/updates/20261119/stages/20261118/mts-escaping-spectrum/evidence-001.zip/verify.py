import ast
import csv
import json
import sys
from outgoing import ROOT, PARENT, LOCK, RADII, MASS, guard, sha, np
from diagnostics import GATE

def table(name):
    with (ROOT/name).open(newline="") as stream:
        return list(csv.DictReader(stream))


def audit():
    guard()
    parents = json.loads((PARENT/"closeout.json").read_text())["files"]
    names = {"current_source.py", "static_modes.py", "stationary_moments.csv", "static-refined-448.npz"}
    for mesh in (960, 1920):
        for amp in (0., 1/160, 1.):
            names.update([f"core-{mesh}-eta0.8-h{amp:g}.npz", f"driven-{mesh}-eta0.8-h{amp:g}-spin0.npz"])
    for spin in (0, 1):
        names.add(f"driven-1920-eta1-h0-spin{spin}.npz")
    assert all(parents[name] == sha(PARENT/name) for name in names)
    checks = json.loads((ROOT/"diagnostics.json").read_text())["checks"]
    checks["all local scripts parse"] = all(ast.parse(path.read_text(encoding="utf8")) for path in ROOT.glob("*.py"))
    file = dict(np.load(ROOT/"fine.npz"))
    spectrum = np.genfromtxt(ROOT/"spectrum.csv", names=True, delimiter=",")
    checks["ordered complete positive frequency panel"] = len(spectrum)==1536 and np.all(np.diff(spectrum["k"])>0) and np.all(spectrum["dk_weight"]>0)
    time = np.load(PARENT/"static-refined-448.npz")["time"]
    rows = table("escape_energy.csv")
    mass = table("bondi_loss.csv")
    direct_errors = {}
    for spin in (0, 1):
        tt = file["news"][:, spin]
        checks[f"spin{spin} complex spectral archive"] = np.array_equal(tt, spectrum[f"spin{spin}_Re"]+1j*spectrum[f"spin{spin}_Im"])
        expected = tt.real**2+tt.imag**2
        energy = np.dot(spectrum["dk_weight"], expected)/np.pi
        checks[f"spin{spin} physical Bondi loss sign and angular units"] = abs(float(mass[spin]["reduced_mass_loss"])/(-2*energy/3)-1)<GATE
        checks[f"spin{spin} sky and harmonic moments"] = all(abs(float(mass[spin][key]))<GATE for key in
                                                            ("fractional_energy_miss", "recoil_momentum_over_energy", "harmonic_leakage", "quadrupole_error"))
        checks[f"spin{spin} energy and nonzero high band"] = abs(energy/float(rows[spin]["available"])-1)<GATE and 0<float(rows[spin]["omitted_24_to_48"])<GATE
        with np.load(PARENT/f"driven-1920-eta1-h0-spin{spin}.npz") as driven:
            assert np.array_equal(time, driven["time"])
            data = driven["fields"]
            for pos, rad in enumerate(RADII[1:], 1):
                index = np.flatnonzero(driven["radius"]==rad).item()
                bridge = (1-MASS/rad)**2
                phase = -1j*time[:,None]*file["k"]
                integ = np.expm1(phase)/(-1j*file["k"])
                weight = file["weight"]*tt/np.pi
                src = file["exterior"][:, pos]*weight
                field = np.real(integ@src)
                at = np.real(np.exp(phase)@src)
                ar = np.real(integ@(file["dr"][:, pos]*weight))
                ref, mom, ref_r = data[:, :, index].T
                ref_t = bridge*mom
                for what, obtained, original in zip(("A","At","Ar","flux"), (field,at,ar,-bridge*at*ar),
                                                     (ref,ref_t,ref_r,-bridge*ref_t*ref_r)):
                    err = max(abs(obtained-original))/max(abs(original))
                    key = f"spin{spin} r{rad:g} independent field evolution {what}"
                    direct_errors[key] = float(err)
                    checks[key] = err < GATE
    soft = table("soft_flux_repair.csv")
    checks["soft raw cancellation misses retained"] = sum(float(row["raw_flux_error"]) >= GATE for row in soft) >= 1
    checks["soft phase representation agrees with outgoing complex solution"] = len(soft)==16 and all(
        float(row[key])<GATE for row in soft for key in row if key not in ("k", "raw_flux_error"))
    transfer = table("finite_transport.csv")
    checks["65 arrivals per mesh preparation and detector"] = len(table("finite_traces.csv"))==65*2*3*2
    for row in transfer:
        key = f"transport {row['mesh']} {row['amplitude']} {row['site']} {row['comparison']}"
        checks[key] = max(float(row["discrepancy"]), float(row["step_change"]))<GATE and float(row["no_barrier_miss"])>GATE
    mesh = table("transfer_mesh.csv")
    checks["mesh differences on scalar change scale"] = len(mesh)==8 and max(float(row["relative_change"]) for row in mesh)<GATE
    memory = table("null_metric_memory.csv")
    checks["inclinations, transverse polarizations and axis nulls"] = len(memory)==18 and all(
        max(float(row["TT_difference_on_equatorial_peak"]),float(row["cross_on_equatorial_peak"]),
            abs(float(row["sphere_constraint"])-float(row["TT_plus"]))/abs(float(mass[int(row["spin"])]["equatorial_distance_times_strain"])))<GATE for row in memory)
    tails = table("signed_tail.csv")
    checks["late signed tail not hidden by energy convergence"] = len(tails)==6 and all(
        float(row["relative_miss"])>GATE for row in tails if float(row["end"])==16)
    for key in checks:
        checks[key] = bool(checks[key])
    assert all(checks.values()), [key for key in checks if not checks[key]]
    files = {path.name:sha(path) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name!="closeout.json"}
    assert not (ROOT/"__pycache__").exists()
    evidence = dict(parent_closeout=LOCK, parent_files={name:parents[name] for name in sorted(names)},
                    checks=checks, independent_evolution_errors=direct_errors, files=files)
    target = ROOT/"closeout.json"
    if "--seal" in sys.argv:
        with target.open("x",encoding="utf8") as out:
            json.dump(evidence,out,indent=2,sort_keys=True)
    if target.exists():
        assert json.loads(target.read_text())==evidence
    print(len(checks), "checks;", len(files), "files;", len(names), "parent inputs; direct waveform worst",max(direct_errors.values()))
    if target.exists():
        print("receipt", sha(target))


if __name__=="__main__":
    audit()

