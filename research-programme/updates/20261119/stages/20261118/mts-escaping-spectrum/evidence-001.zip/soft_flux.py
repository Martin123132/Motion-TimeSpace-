import csv
from outgoing import ROOT, MASS, RADII, np, guard, geometry, regular
from diagnostics import write_table, GATE
from scipy.integrate import solve_ivp


def polar(freq, x5):
    epsilon = MASS*freq
    top = max(75., 7*freq+40.)
    coeff = [1.+0j]
    for order in range(1, 19):
        term = ((order-1)*order-2)*coeff[-1]
        if order >= 2:
            term -= 2*epsilon*(order-2)*order*coeff[-2]
        if order >= 3:
            term += epsilon**2*((order-3)*order-4)*coeff[-3]
        coeff.append(term/(2j*order))
    start = sum(val/top**order for order, val in enumerate(coeff))
    slope = sum(-order*val/top**(order+1) for order, val in enumerate(coeff))
    init = [np.log(abs(start)), top*(slope/start).real, np.angle(start)]
    def ode(logz, state):
        arg = np.exp(logz)
        logamp, rate, shift = state
        normal = 1-epsilon/arg
        bridge = normal**2
        dbridge = 2*epsilon/arg*normal
        return [rate, rate*(1-dbridge/bridge-rate)+(2+4*(epsilon/arg)**2)/bridge+
                np.expm1(-4*logamp)*arg**2/bridge**2, arg*np.expm1(-2*logamp)/bridge]
    zval = freq*RADII[::-1]
    sol = solve_ivp(ode, (np.log(top), np.log(zval[-1])), init, method="DOP853",
                    t_eval=np.log(zval), rtol=2.e-12, atol=5.e-15)
    assert sol.success
    logamp, rate, shift = sol.y[:, ::-1]
    opt = x5+RADII-5+2*MASS*np.log((RADII-MASS)/(5-MASS))-MASS**2*(1/(RADII-MASS)-1/(5-MASS))
    val = np.exp(logamp+1j*(freq*opt+shift))
    bridge = (1-MASS/RADII)**2
    grad = rate/RADII+1j*freq*np.exp(-2*logamp)/bridge
    return val, grad


def main():
    guard()
    file = dict(np.load(ROOT/"checks.npz"))
    freq = file["k"]
    geom = geometry()
    val, grad, overlap, raw = regular(freq, geom)
    rows = []
    for idx, wave in enumerate(freq):
        mode, loggrad = polar(wave, geom[-1])
        bridge = (1-MASS/RADII)**2
        polar_w = bridge[0]*mode[0]*(grad[idx]-val[idx]*loggrad[0])
        prediction = overlap[idx]/polar_w
        flux = abs(mode)**2*bridge*loggrad.imag/wave
        rows.append(dict(k=wave, raw_flux_error=max(abs(file["current"][idx]-1)),
                         amplitude_phase_flux_algebra=max(abs(flux-1)),
                         exterior_field_disagreement=max(abs(mode/file["exterior"][idx]-1)),
                         exterior_gradient_disagreement=max(abs(mode*loggrad/file["dr"][idx]-1)),
                         primary_news_disagreement=abs(prediction[0]/file["news"][idx, 0]-1),
                         secondary_news_disagreement=abs(prediction[1]/file["news"][idx, 1]-1)))
    write_table("soft_flux_repair.csv", rows)
    for key in list(rows[0])[1:]:
        print(key, max(row[key] for row in rows))


if __name__ == "__main__":
    main()

