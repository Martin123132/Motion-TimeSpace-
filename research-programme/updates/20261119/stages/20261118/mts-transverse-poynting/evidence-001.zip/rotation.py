from numpy.polynomial import Polynomial
from scipy.integrate import cumulative_simpson, simpson
from scipy.interpolate import CubicSpline, make_interp_spline
from background import HERE, MESHES, END, guard, np, packet, output
from pulse import DETECTORS, outgoing

NODES=np.arange(-3.5,4.,1.)
POWER=np.arange(8)
VANDER=NODES[None,:]**POWER[:,None]
DWEIGHT=np.linalg.solve(VANDER,(POWER==1).astype(float))
WEIGHT=np.linalg.solve(VANDER,(POWER==0).astype(float))
QWEIGHT=np.linalg.solve(np.arange(-3.,5.)[None,:]**POWER[:,None],(.5**(POWER+1)-(-.5)**(POWER+1))/(POWER+1))


def on_faces(values,weights):
    count=values.shape[-1]
    out=np.zeros(values.shape[:-1]+(count-1,))
    for index,coef in enumerate(weights):
        out[...,3:count-4]+=coef*values[...,index:count-7+index]
    return out


def on_centers(values,weights):
    count=values.shape[-1]+1
    out=np.zeros(values.shape[:-1]+(count,))
    for index,coef in enumerate(weights):
        out[...,4:count-4]+=coef*values[...,index:count-8+index]
    return out


def run(mesh,eta,amp):
    guard()
    with np.load(HERE/packet(mesh,abs(eta),amp or 1.)) as source:
        radius=source["radius"];bank=source["metric"];mass=float(source["mass"]);times=source["time"]
    charge=.002*eta;coupling=4*charge**2
    spacing=radius[1]-radius[0];faces=(radius[1:]+radius[:-1])/2
    coord=1-2*mass/radius+(charge/radius)**2
    inv=1/radius**2
    strength=amp**2
    def metric(time):
        j=min(int(time/times[1]),255);frac=time/times[1]-j
        if amp:
            values=(1-frac)**2*(1+2*frac)*bank[j,:2]+frac**2*(3-2*frac)*bank[j+1,:2]+times[1]*frac*(1-frac)*((1-frac)*bank[j,2:]-frac*bank[j+1,2:])
            bridge=coord+strength*values[0];lapse=1+strength*values[1]
        else:
            bridge=coord;lapse=np.ones_like(coord)
        return bridge,on_faces(bridge,WEIGHT),lapse
    count=len(radius)
    initial,speed,grad=outgoing(0.,radius)
    magnetic=outgoing(0.,faces)[2]
    primitive=make_interp_spline(radius,grad,k=5).antiderivative()
    state=np.zeros((7,count))
    state[0]=initial;state[1]=speed;state[2,:-1]=magnetic
    state[6]=-(2*charge/3)*(primitive(radius)-primitive(radius[0]))
    def rhs(state,geometry):
        bridge,facebridge,lapse=geometry
        fixed,deriv=state[:3],state[3:6]
        enclosed=state[6]
        result=np.zeros_like(state)
        for index,fields in enumerate((fixed,deriv)):
            off=3*index;field,speed,bfield=fields
            result[off]=bridge*speed
            result[off+1]=on_centers(facebridge*bfield[:-1],DWEIGHT)/spacing-2*lapse*inv*field
            result[off+2,:-1]=on_faces(bridge*speed,DWEIGHT)/spacing
        if charge:
            result[4]+=6*charge/coupling*lapse*enclosed*inv**2
            result[6]=-(2*charge/3)*bridge*(fixed[1]+coupling*deriv[1])
        result[:,:4]=0.;result[:,-4:]=0.
        return result
    mask=(radius>=17)&(radius<=23)
    detectors=np.searchsorted(radius,DETECTORS)
    def measure(state,geometry):
        bridge,facebridge,lapse=geometry
        enclosed=state[6];measure=state[:3]+coupling*state[3:6]
        nodal=on_centers(measure[2,:-1],WEIGHT)
        fixed_grad=on_centers(state[2,:-1],WEIGHT)
        grad_deriv=on_centers(state[5,:-1],WEIGHT)
        wave=-bridge**2*state[1]*fixed_grad
        flux_deriv=-bridge**2*(state[4]*nodal+state[1]*grad_deriv)
        increments=np.zeros_like(faces)
        for idx,coef in enumerate(QWEIGHT):
            increments[4:-4]+=coef*measure[2,1+idx:len(faces)-7+idx]
        from_flux=-(2*charge/3)*np.r_[0.,np.cumsum(increments*spacing)]
        curl=-6*lapse*enclosed*inv**2
        drag=-simpson(curl[mask],x=radius[mask])
        return (np.array([wave[detectors],flux_deriv[detectors],enclosed[detectors],from_flux[detectors],
                         -(2*charge/3)*measure[0,detectors],curl[detectors]]),drag,
                np.max(np.abs(enclosed[mask]-from_flux[mask])))
    ticks=int(np.ceil(END/(.29*spacing)/1024))*1024
    step=END/ticks;data=[];shear=[];residual=[]
    for tick in range(ticks+1):
        time=tick*step;geom=metric(time)
        if tick%(ticks//1024)==0:
            values,rate,error=measure(state,geom)
            data.append(values);shear.append(rate);residual.append(error)
        if tick==ticks:
            break
        mid=metric(time+.5*step)
        first=rhs(state,geom);second=rhs(state+.5*step*first,mid)
        third=rhs(state+.5*step*second,mid);fourth=rhs(state+step*third,metric(time+step))
        state+=step/6*(first+2*second+2*third+fourth)
    proper_axis=np.linspace(0,END,1025)
    output(name(mesh,eta,amp),time=proper_axis,probes=data,shear=shear,radial_constraint=residual,
           angle=cumulative_simpson(shear,x=proper_axis,initial=0),charge=charge,amp=amp)
    print("rotation",mesh,eta,amp,flush=True)

def name(mesh,eta,amp):
    return f"rotation-{mesh}-eta{eta:g}-h{amp:g}.npz"

if __name__=="__main__":
    for mesh in MESHES:
        for eta,amp in ((0.,0.),(.8,0.),(.8,1/160),(.8,1.),(-.8,1.)):
            run(mesh,eta,amp)

