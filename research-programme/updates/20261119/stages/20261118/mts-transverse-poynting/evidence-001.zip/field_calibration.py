import csv
from scipy.constants import c, epsilon_0, mu_0, G
from background import AMPLITUDES, HERE, PARENT, MESHES, np, peak, guard
from pulse import DETECTORS, pulse_name
from measure import GATE, table
from rotation import name

def audit():
    guard()
    with (PARENT/"source-calibration.csv").open(encoding="utf8") as stream:
        gauss={(int(row["mesh"]),float(row["eta"])):float(row["charge"]) for row in csv.DictReader(stream)}
    cosines,weights=np.polynomial.legendre.leggauss(7)
    def moments(field):
        mag=2*field[:,:,None]*cosines/DETECTORS[None,:,None]**2
        return np.sum(mag*cosines*weights/2,axis=-1)*DETECTORS**2
    units=np.sqrt(G/(4*np.pi*epsilon_0))/c**2*np.sqrt(4*np.pi*G/mu_0)/c**2/(G/c**3)
    assert abs(units-1)<1e-10
    rows=[]
    for mesh in MESHES:
        for eta,amp in ((0.,0.),(.8,0.),(.8,1/160),(.8,1.),(-.8,1.)):
            charge=gauss[mesh,abs(eta)]*np.sign(eta)
            with np.load(HERE/pulse_name(mesh,abs(eta),amp or 1.,False)) as src:
                field=src["signals"][:,3 if amp else 2,0]
                increments=src["signals"][:,5,0]
            with np.load(HERE/name(mesh,eta,amp)) as src:
                local=src["probes"][::2,2]
            if amp and eta>0:
                with np.load(HERE/name(mesh,eta,0.)) as src:
                    original=src["probes"][::2,2]
            for left,right in [(0,2),(1,3)]:
                def between(values):
                    return values[:,right]-values[:,left]
                predicted=-charge*between(moments(field))*units
                actual=between(local)
                err=peak(predicted-actual)
                size=peak(actual)
                diff=None
                if amp and eta>0:
                    d_pred=-charge*amp**2*between(moments(increments))*units
                    d_obs=between(local-original)
                    diff=peak(d_pred-d_obs)/peak(d_pred)
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,left=DETECTORS[left],right=DETECTORS[right],
                                signed_Q=charge,si_conversion_ratio=units,absolute=err,scale=size,
                                relative=err/size if size else None,scalar_effect_error=diff,
                                passes=err<GATE*size if size else err==0))
    return rows

if __name__=="__main__":
    table("field-calibration.csv",audit())

