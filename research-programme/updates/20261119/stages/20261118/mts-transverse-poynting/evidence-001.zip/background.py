from pathlib import Path
import os
import sys

for variable in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-charged-exterior-rulers-20261118"
sys.path.insert(0,str(PARENT))
from charged import Charged, filename, np, peak, sha, guard as original_guard
from response import initial_adm_excess
from reference import core_adm

LOCK="82ca87aa878361587c6943b10e2ee2bd31315a1f98ec4db06ee40de497ffa7a4"
END=6.5
MESHES=(960,1920)
AMPLITUDES=(1/160,1.)
CHARGES=(0.,.8)

def guard():
    original_guard()
    assert sha(PARENT/"closeout.json")==LOCK and not (HERE/"STOP-REQUESTED").exists()

def output(name,**data):
    with (HERE/name).open("xb") as stream:
        np.savez_compressed(stream,**data)

def packet(mesh,eta,amp):
    return f"geometry-{mesh}-eta{eta:g}-h{amp:g}.npz"

def acquire(mesh,eta,amp):
    guard()
    grid=Charged(mesh,eta)
    state,probe=grid.initial("both","prepared",1.,amp)
    probe[[3,5]]-=1
    parent=PARENT/filename(mesh,eta,amp)
    if parent.exists():
        with np.load(parent) as saved:
            assert np.array_equal(state,saved["initial"])
    diff=initial_adm_excess(mesh,eta,amp)
    charge=eta*.002
    mass=core_adm(1.,charge)
    radius=grid.r
    inv=grid.inv
    part=(radius>=6)&(radius<=38)
    ref=1-2*mass*inv+(charge*inv)**2
    steps=int(np.ceil(END/(.26*grid.step)/256))*256
    step=END/steps
    history=[];constraints=[]
    def tail(values):
        return grid.integral(values[::-1])[::-1]
    for tick in range(steps+1):
        if tick%(steps//256)==0:
            aa,alpha,bridge,logs,slope,ms,en,sr,st,current,scalar,dust,velocity,grad=grid.metric(state)
            field,mom,density,flow=state
            derivative=grid.push(state,probe)[0]
            tail_energy=tail(radius**2*scalar)
            delta_mass=diff-tail_energy
            log_lapse=-tail(radius*(mom**2+grad**2))
            delta_lapse=np.expm1(log_lapse)
            lapse=1+delta_lapse
            factor=ref-2*inv*delta_mass
            dbridge=delta_lapse*ref-2*lapse*inv*delta_mass
            dlapse=-2*lapse*tail(radius*(mom*derivative[1]+grad*grid.first(derivative[0],1)))
            dmass=radius**2*bridge*mom*grad/aa**2
            dtbridge=dlapse*factor-2*lapse*inv*dmass
            history.append(np.stack([dbridge,delta_lapse,dtbridge,dlapse])[:,part]/amp**2)
            constraints.append([peak((lapse-alpha*aa)[part]),peak((ref+dbridge-bridge)[part]),
                                peak(dust[part]),peak(field[-5:]),peak(mom[-5:])])
        if tick==steps:
            break
        first,probe1=grid.push(state,probe)
        second,probe2=grid.push(state+.5*step*first,probe+.5*step*probe1)
        third,probe3=grid.push(state+.5*step*second,probe+.5*step*probe2)
        fourth,probe4=grid.push(state+step*third,probe+step*probe3)
        state+=step/6*(first+2*second+2*third+fourth)
        probe+=step/6*(probe1+2*probe2+2*probe3+probe4)
    if parent.exists():
        with np.load(parent) as saved:
            assert np.array_equal(state,saved["final"])
    output(packet(mesh,eta,amp),radius=radius[part],time=np.linspace(0,END,257),
           metric=np.array(history),constraints=constraints,mass=mass,charge=charge,
           original_endpoint=parent.exists(),initial_delta_ADM=diff)
    print("saved geometry",mesh,eta,amp,"original endpoint",parent.exists(),flush=True)

if __name__=="__main__":
    for cells in MESHES:
        for specific_charge in CHARGES:
            for amplitude in AMPLITUDES:
                acquire(cells,specific_charge,amplitude)

