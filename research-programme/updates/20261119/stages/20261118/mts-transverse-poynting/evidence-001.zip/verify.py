import csv
import json
import math
import sys

import crosschecks
import field_calibration
import identities
import measure
import mixed_precision
from background import AMPLITUDES, CHARGES, HERE, LOCK, MESHES, PARENT, guard, np, packet, peak, sha
from pulse import TIMES, pulse_name
from rotation import name

def audit():
    guard()
    checks={};inputs={}
    def demand(label,truth):
        if not truth:
            raise ValueError(label)
        checks[label]=True
    def pin(path,digest):
        real=sha(path)
        demand("previous "+path.relative_to(HERE.parent).as_posix(),real==digest)
        inputs[path.relative_to(HERE.parent).as_posix()]=real
    pin(PARENT/"closeout.json",LOCK)
    receipt=json.loads((PARENT/"closeout.json").read_text(encoding="utf8"))
    for path,digest in receipt["inputs"].items():
        pin(HERE.parent/path,digest)
    for filename in ("charged.py","reference.py","response.py","source-calibration.csv","PROTOCOL.md","EQUATIONS.md","RESULTS.md"):
        pin(PARENT/filename,receipt["files"][filename])
    for mesh in MESHES:
        for eta in CHARGES:
            for amp in AMPLITUDES:
                previous=f"charged-{mesh}-eta{eta:g}-h{amp:g}-b1.npz"
                if previous in receipt["files"]:
                    pin(PARENT/previous,receipt["files"][previous])
    files={}
    for path in sorted(HERE.iterdir()):
        if path.name=="closeout.json":
            continue
        if not path.is_file() or path.suffix not in {".npz",".md",".csv",".py"}:
            raise ValueError(str(path))
        files[path.name]=sha(path)
        if path.suffix==".npz":
            with np.load(path,allow_pickle=False) as data:
                for key in data.files:
                    if data[key].dtype.kind in "fci":
                        assert np.isfinite(data[key]).all(),(path.name,key)
                if "time" in data:
                    assert np.all(np.diff(data["time"])>0) and data["time"][-1]==6.5
            demand("decoded "+path.name,True)
    checks.update(identities.exact())
    metrics=measure.score()
    other=crosschecks.checks()
    calibration=field_calibration.audit()
    precision=mixed_precision.scores()
    series={**metrics,**other,"field-calibration":calibration,"mixed_precision":precision}
    for label,generated in series.items():
        with (HERE/(label+".csv")).open(encoding="utf8",newline="") as stream:
            rows=list(csv.DictReader(stream,strict=True))
        assert len(generated)==len(rows)
        for item,row in zip(generated,rows):
            assert set(item)==set(row)
            for key,value in item.items():
                field=row[key]
                if value is None:
                    assert field==""
                elif isinstance(value,(bool,str,np.bool_)):
                    assert field==str(value)
                else:
                    assert math.isclose(float(value),float(field),rel_tol=3e-9,abs_tol=2e-24),(label,key,field,value)
        demand("recalculate "+label,True)
    geom=metrics["geometry"]
    demand("restart endpoint counts and exterior mass",len(geom)==8 and sum(row["parent_state_matched"] for row in geom)==6
           and max(row["largest_exterior_dust"] for row in geom)<1e-25)
    demand("two independent metric constraint evaluations",
           max(row["lapse_absolute"] for row in geom)<1e-14 and max(row["bridge_absolute"] for row in geom)<2e-11)
    demand("outgoing flat analytic solution",len(metrics["flat"])==8 and all(row["passes"] for row in metrics["flat"]))
    demand("integrate physical angular fields",all(max(row["energy_absolute"],row["flux_absolute"])<2e-13 for row in metrics["angular"]))
    demand("refinement on signal itself",len(metrics["refinements"])==14 and all(row["passes"] for row in metrics["refinements"]))
    bud=metrics["budgets"];paired=[row for row in bud if row["mesh"]==1920 and row["arm"].startswith("dscalar")]
    demand("matched work on its own scale across slabs and preparations",len(paired)==12 and
           all(row["work_scale_error"]<2e-5 for row in paired))
    demand("raw small-signal miss preserved",all(row["work_scale_error"]>2e-5 for row in bud if row["mesh"]==1920
           and row["arm"]=="MTS" and row["amp"]==1/160))
    for mesh in MESHES:
        with np.load(HERE/pulse_name(mesh,0.,1.,True)) as src:
            energy=src["history"][:,0,1,0]
            demand("static null normalized to initial energy "+str(mesh),peak(energy-energy[0])/energy[0]<2e-5)
    demand("electromagnetic work into rotational energy",len(metrics["exchange"])==16 and all(row["passes"] for row in metrics["exchange"]))
    demand("raw mixed misses and repaired own-scale gate",
           all(not row["passes"] for row in precision if row["mesh"]==1920 and row["shell"]==0 and row["rule"].startswith("Simpson"))
           and all(row["passes"] for row in precision if row["rule"]=="higher space and time"))
    for row in other["rotation_checks"]:
        if row["eta"]==0:
            demand("neutral rotational null "+str(row["mesh"]),row["neutral_exact"])
        else:
            assert max(row[key] for key in ("fixed_wave","wave_response_on_own_scale","angular_momentum_radial_constraint",
                       "signed_metric_vs_action","integrated_rotation_rate_vs_action"))<2e-5
    demand("staggered metric and action solver agree",len(other["rotation_checks"])==10)
    demand("charge-even energy and charge-odd torque",all(all(value==0 for key,value in row.items() if key!="mesh") for row in other["charge_parity"]))
    demand("SI two-sphere calibration",len(calibration)==20 and all(row["passes"] for row in calibration)
           and max(row["scalar_effect_error"] or 0. for row in calibration)<2e-5)
    for test,direct in zip(metrics["arrivals"],other["clock_direct"],strict=True):
        assert all(test[key]==direct[key] for key in ("mesh","eta","amp"))
        assert abs(test["proper_arrival_shift"]/direct["direct_proper_shift"]-1)<2e-5
        assert test["d_clock_per_amp2"]<0<test["proper_arrival_per_amp2"]<test["d_coordinate_arrival_per_amp2"]
    demand("direct versus stably differenced proper detector arrivals",len(other["clock_direct"])==8)
    return dict(parent=LOCK,files=files,inputs=inputs,checks=checks)

if __name__=="__main__":
    receipt=audit();path=HERE/"closeout.json"
    if sys.argv[1:]==["--seal"]:
        with path.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(receipt,stream,indent=2,sort_keys=True)
            stream.write("\n")
    elif sys.argv[1:] or json.loads(path.read_text(encoding="utf8"))!=receipt:
        raise ValueError("changed receipt or invalid verification arguments")
    print(len(receipt["checks"]),"checks;",len(receipt["files"]),"files;",len(receipt["inputs"]),"parent inputs;",sha(path))

