from background import AMPLITUDES, CHARGES, END, HERE, MESHES, guard, np, output, packet
from scipy.integrate import simpson

DETECTORS=np.array([17.,21.,23.,25.])
SHELLS=((17.,23.),(6.,38.))
BRANCHES=("ordinary","MTS","ordinary+twist","MTS+twist","dscalar/test","dscalar/coupled","dtwist/ordinary","dtwist/MTS")
COLUMNS=("stored","left","right","metric_work")
TIMES=np.linspace(0,END,513)


def outgoing(time,radius):
    scaled=(time-radius+18)/4
    positive=np.maximum(0.,1-scaled**2)
    envelope=positive**12
    velocity=-6*scaled*positive**11
    accel=-1.5*positive**11+33*scaled**2*positive**10
    return velocity+envelope/radius,accel+velocity/radius,-accel-velocity/radius-envelope/radius**2


def gradient(values,spacing):
    out=np.zeros_like(values)
    for offset,coefficient in enumerate((4/5,-1/5,4/105,-1/280),1):
        out[...,4:-4]+=coefficient*(values[...,4+offset:values.shape[-1]-4+offset]-values[...,4-offset:values.shape[-1]-4-offset])
    return out/spacing


def acquire(mesh,eta,amp,flat=False,mixed_audit=False):
    guard()
    with np.load(HERE/packet(mesh,eta,amp)) as src:
        radius=src["radius"]; histories=src["metric"]; source_time=src["time"]
        charge=0. if flat else float(src["charge"]);mass=0. if flat else float(src["mass"])
    if flat:
        histories[:]=0.
    spacing=radius[1]-radius[0]
    base=1-2*mass/radius+(charge/radius)**2
    strength=amp**2
    twist=4*charge**2
    barrier=2/radius**2
    rotational=1/radius**4
    detectors=np.array([np.abs(radius-value).argmin() for value in DETECTORS])
    masks=[(radius>=left)&(radius<=right) for left,right in SHELLS]
    spots=np.array([[np.abs(radius-left).argmin(),np.abs(radius-right).argmin()] for left,right in SHELLS])
    source_step=source_time[1]
    def geometry(time):
        key=min(int(time/source_step),255);frac=time/source_step-key
        left,right=histories[key],histories[key+1]
        product=frac*(1-frac)
        vals=(1-frac)**2*(1+2*frac)*left[:2]+frac**2*(3-2*frac)*right[:2]+source_step*product*((1-frac)*left[2:]-frac*right[2:])
        rates=6*product/source_step*(right[:2]-left[:2])+(1-frac)*(1-3*frac)*left[2:]+frac*(3*frac-2)*right[2:]
        return vals[0],vals[1],rates[0],rates[1]
    def rate(state,metric):
        dbridge,dlapse=metric[:2]
        bridge=base+strength*dbridge
        lapse=1+strength*dlapse
        field,scalar,rotation,mixed=state[:,0]
        speed,dspeed,rspeed,mspeed=state[:,1]
        slopes=gradient(state[:,0],spacing)
        gx,gs,gr,gm=slopes
        out=np.empty_like(state)
        out[:,0]=[base*speed,bridge*dspeed+dbridge*speed,base*rspeed,bridge*mspeed+dbridge*rspeed]
        currents=np.stack([base*gx,bridge*gs+dbridge*gx,base*gr,bridge*gm+dbridge*gr])
        out[:,1]=gradient(currents,spacing)-barrier*np.stack([field,lapse*scalar+dlapse*field,rotation,lapse*mixed+dlapse*rotation])
        out[2,1]-=rotational*(field+twist*rotation)
        out[3,1]-=rotational*(lapse*(scalar+twist*mixed)+dlapse*(field+twist*rotation))
        out[...,:4]=0.;out[...,-4:]=0.
        return out
    def pack(energy,flux,work):
        return np.array([[simpson(energy[mask],x=radius[mask]),flux[left],flux[right],simpson(work[mask],x=radius[mask])]
                  for mask,(left,right) in zip(masks,spots)])
    def value(fields,bridge,bar,bt,ut):
        field,speed,slope=fields
        kinetic=speed**2+slope**2
        return pack(.5*(bridge*kinetic+bar*field**2),-bridge**2*speed*slope,.5*(bt*kinetic+ut*field**2))
    def difference(fields,change,scale,bridge,bar,db,du,bt,ut,dbt,dut):
        field,speed,slope=fields
        df,dp,dx=change
        kinetic=speed**2+slope**2
        varied=dp*(2*speed+scale*dp)+dx*(2*slope+scale*dx)
        vfield=df*(2*field+scale*df)
        energy=.5*(db*kinetic+(bridge+scale*db)*varied+du*field**2+(bar+scale*du)*vfield)
        work=.5*(dbt*kinetic+(bt+scale*dbt)*varied+dut*field**2+(ut+scale*dut)*vfield)
        flux=-db*(2*bridge+scale*db)*speed*slope-(bridge+scale*db)**2*(dp*(slope+scale*dx)+speed*dx)
        return pack(energy,flux,work)
    def observe(state,metric):
        db,df,dbt,dft=metric
        bridge=base+strength*db;lapse=1+strength*df
        bt=strength*dbt;ft=strength*dft
        old,ds,rot,mix=np.concatenate([state,gradient(state[:,:1],spacing)],axis=1)
        new=old+strength*ds
        spin0=old+twist*rot
        dspin=ds+twist*mix
        spin1=spin0+strength*dspin
        dr1=rot+strength*mix
        totalbar=barrier+twist*rotational
        budgets=[value(old,base,barrier,0.,0.),value(new,bridge,lapse*barrier,bt,ft*barrier),
                 value(spin0,base,totalbar,0.,0.),value(spin1,bridge,lapse*totalbar,bt,ft*totalbar),
                 difference(old,ds,strength,base,barrier,db,df*barrier,0.,0.,dbt,dft*barrier),
                 difference(spin0,dspin,strength,base,totalbar,db,df*totalbar,0.,0.,dbt,dft*totalbar),
                 difference(old,rot,twist,base,barrier,0.,rotational,0.,0.,0.,0.),
                 difference(new,dr1,twist,bridge,lapse*barrier,0.,lapse*rotational,bt,ft*barrier,0.,ft*rotational)]
        flux_delta=-db*(2*base+strength*db)*old[1]*old[2]-bridge**2*(ds[1]*new[2]+old[1]*ds[2])
        flux_twist=-bridge**2*(dr1[1]*spin1[2]+new[1]*dr1[2])
        twistpower=[]
        for fields,geom,motion,change in [(spin0,base,1.,0.),(spin1,bridge,lapse,ft)]:
            mode,power,spatial=fields
            twistpower.append([[simpson(z[mask],x=radius[mask]) for z in
                (.5*motion*rotational*mode**2,motion*rotational*mode*geom*power,.5*change*rotational*mode**2)] for mask in masks])
        detector_state=np.array([fields[:,detectors] for fields in (old,new,spin0,spin1,ds,dspin,rot,dr1)])
        geom=np.stack([base[detectors],bridge[detectors],lapse[detectors]])
        return budgets,twistpower,detector_state,geom,np.stack([flux_delta[detectors],flux_twist[detectors]])
    state=np.zeros((4,2,len(radius)))
    field,speed,slope=outgoing(0,radius)
    state[0,0]=field;state[0,1]=speed
    ticks=int(np.ceil(END/(.43*spacing)/512))*512
    step=END/ticks
    series=[[] for index in range(5)]
    profiles=[]
    if mixed_audit:
        from mixed_precision import MixedReadout
        auditor=MixedReadout(radius,masks,spots,base,barrier,rotational,strength,twist)
    for tick in range(ticks+1):
        time=tick*step
        metric=geometry(time)
        if tick%(ticks//512)==0:
            if mixed_audit:
                auditor.sample(state,gradient(state[:,0],spacing),metric)
            else:
                for history,item in zip(series,observe(state,metric)):
                    history.append(item)
                if tick%(ticks//4)==0:
                    profiles.append(state.copy())
        if tick==ticks:
            break
        mid=geometry(time+step/2)
        first=rate(state,metric)
        second=rate(state+.5*step*first,mid)
        third=rate(state+.5*step*second,mid)
        fourth=rate(state+step*third,geometry(time+step))
        state+=step/6*(first+2*second+2*third+fourth)
    if mixed_audit:
        auditor.finish(mesh,eta,amp,state)
        return
    output(pulse_name(mesh,eta,amp,flat),time=TIMES,radius=radius,detectors=DETECTORS,profiles=profiles,
           history=series[0],exchange=series[1],signals=series[2],geometry=series[3],effects=series[4],charge=charge,
           mass=mass,amp=amp,branches=np.array(BRANCHES),columns=np.array(COLUMNS))
    print("pulse",mesh,eta,amp,flat,flush=True)


def pulse_name(mesh,eta,amp,flat):
    return f"pulse-{mesh}-eta{eta:g}-h{amp:g}-flat{int(flat)}.npz"

if __name__=="__main__":
    for cells in MESHES:
        acquire(cells,0.,1.,True)
        for specific_charge in CHARGES:
            for amplitude in AMPLITUDES:
                acquire(cells,specific_charge,amplitude)

