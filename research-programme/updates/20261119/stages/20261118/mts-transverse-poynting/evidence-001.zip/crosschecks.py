from scipy.integrate import simpson
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq
from background import HERE, MESHES, guard, np, packet, peak
from pulse import DETECTORS, SHELLS, TIMES, outgoing, pulse_name
from measure import GATE, integrated, table
from rotation import name

def checks():
    guard()
    moments=[];sign=[];mixed=[];arrival=[];waves={}
    for mesh in MESHES:
        for eta,amp in [(0.,0.),(.8,0.),(.8,1/160),(.8,1.),(-.8,1.)]:
            with np.load(HERE/name(mesh,eta,amp)) as rot:
                probes=rot["probes"];time=rot["time"];angle=rot["angle"];shear=rot["shear"]
                residual=peak(rot["radial_constraint"]);q=rot["charge"].item()
            waves[mesh,eta,amp]=(probes,shear,angle)
            fallback=amp or 1.
            with np.load(HERE/pulse_name(mesh,abs(eta),fallback,False)) as pulse:
                signals=pulse["signals"];effects=pulse["effects"];prof=pulse["profiles"]
                geo=pulse["geometry"];rad=pulse["radius"];history=pulse["history"]
            with np.load(HERE/packet(mesh,abs(eta),fallback)) as src:
                met=src["metric"]
            field=signals[:,1 if amp else 0]
            bridge=geo[:,1 if amp else 0]
            flux=-bridge**2*field[:,1]*field[:,2]
            response=effects[:,1] if amp else -bridge**2*(signals[:,6,1]*signals[:,2,2]+field[:,1]*signals[:,6,2])
            err=peak(probes[::2,0]-flux)/peak(flux)
            res=peak(probes[::2,1]-response)/peak(response) if q else None
            relative_constraint=residual/peak(probes[:,2]) if q else None
            expected=-(2*q/3)*signals[:,3 if amp else 2,0]
            action_diff=peak(probes[::2,2]-expected)/peak(expected) if q else None
            predicted=[]
            mask=(rad>=17)&(rad<=23)
            for idx,stage in enumerate(prof):
                matter=amp**2
                active=stage[0,0]+matter*stage[1,0]+4*q*q*(stage[2,0]+matter*stage[3,0])
                lapse=1+matter*met[64*idx,1]
                predicted.append(-simpson((4*q*lapse*active/rad**4)[mask],x=rad[mask]))
            drift=peak(shear[::256]-predicted)/peak(shear) if q else None
            moments.append(dict(mesh=mesh,eta=eta,amp=amp,fixed_wave=err,wave_response_on_own_scale=res,
                                angular_momentum_radial_constraint=relative_constraint,signed_metric_vs_action=action_diff,
                                integrated_rotation_rate_vs_action=drift,peak_angle=peak(angle),signed_final_angle=angle[-1],
                                peak_enclosed_momentum=peak(probes[:,2]),peak_rotation_rate=peak(shear),
                                neutral_exact=peak(shear)==peak(angle)==peak(probes[:,2])==0 if not q else None))
            if eta==.8 and amp:
                arm=history[:,7]-history[:,6]
                for index,(left,right) in enumerate(SHELLS):
                    stored,flux_in,flux_out,power=(arm[:,index]/amp**2).T
                    flow=integrated(flux_in-flux_out)
                    work=integrated(power)
                    delta=stored-stored[0]
                    balance=peak(delta-flow-work)
                    mixed.append(dict(mesh=mesh,amp=amp,shell=index,energy_change=delta[-1],net_flux=flow[-1],metric_work=work[-1],
                        relative_work_error=balance/peak(work),relative_effect_error=balance/max(peak(flow),peak(delta),peak(work))))
        for eta in (0.,.8):
            for amp in (1/160,1.):
                with np.load(HERE/pulse_name(mesh,eta,amp,False)) as src:
                    field=src["signals"][:,:2,:,2];geom=src["geometry"][:,:,2]
                    rad=src["radius"];initial,velocity,grad=outgoing(0.,rad)
                threshold=.1*simpson((velocity**2+grad**2)/2+initial**2/rad**2,x=rad)
                measured=[]
                for arm in range(2):
                    b=geom[:,arm];f=geom[:,2] if arm else np.ones_like(b)
                    alpha=np.sqrt(b*f);proper=integrated(alpha)
                    power=-b/f*field[:,arm,1]*field[:,arm,2]
                    cumulative=integrated(power,proper)
                    measured.append(brentq(lambda point:CubicSpline(proper,cumulative)(point)-threshold,0.,proper[-1],xtol=1e-15))
                arrival.append(dict(mesh=mesh,eta=eta,amp=amp,direct_proper_shift=measured[1]-measured[0]))
        pos=waves[mesh,.8,1.];neg=waves[mesh,-.8,1.]
        sign.append(dict(mesh=mesh,energy_flux_even=peak(pos[0][:,0]-neg[0][:,0]),
            induced_flux_even=peak(pos[0][:,1]-neg[0][:,1]),momentum_odd=peak(pos[0][:,2]+neg[0][:,2]),
            rotation_rate_odd=peak(pos[1]+neg[1]),rotation_angle_odd=peak(pos[2]+neg[2])))
    return dict(rotation_checks=moments,charge_parity=sign,mixed_work=mixed,clock_direct=arrival)

if __name__=="__main__":
    for key,rows in checks().items():
        table(key+".csv",rows)

