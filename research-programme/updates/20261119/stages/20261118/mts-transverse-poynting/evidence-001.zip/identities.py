import sympy as sym

def exact():
    radius,time,cosine=sym.symbols("r t z",real=True)
    mass,charge,spin,angular=sym.symbols("M Q a J",real=True)
    field,momentum,bridge,lapse,omega,link,rotation=[sym.Function(label)(time,radius) for label in ("A","P","B","F","omega","beta","chi")]
    curvature=omega.diff(radius)-link.diff(time)
    lag=field.diff(time)**2/(2*bridge)-bridge*field.diff(radius)**2/2-lapse*field**2/radius**2+radius**4*curvature**2/(8*lapse)-charge*field*curvature
    result={}
    def demand(name,expr):
        if sym.simplify(expr)!=0:
            raise ArithmeticError(name)
        result[name]=True
    def euler(var):
        return lag.diff(var)-lag.diff(var.diff(time)).diff(time)-lag.diff(var.diff(radius)).diff(radius)
    demand("potential Euler equation",euler(field)+(field.diff(time)/bridge).diff(time)-(bridge*field.diff(radius)).diff(radius)+2*lapse*field/radius**2+charge*curvature)
    const=radius**4*curvature/(4*lapse)-charge*field
    demand("angular shift constraint",euler(omega)+const.diff(radius))
    demand("radial link constraint",euler(link)-const.diff(time))
    demand("gauge-invariant twist",(omega+rotation.diff(time)).diff(radius)-(link+rotation.diff(radius)).diff(time)-curvature)
    static=1-2*mass/radius+charge**2/radius**2
    magnet=charge*spin/radius
    dragging=2*mass*spin/radius**3-charge**2*spin/radius**4
    demand("rotating KN constraint",radius**4*dragging.diff(radius)-4*charge*magnet+6*mass*spin)
    demand("rotating KN Ampere equation",(static*magnet.diff(radius)).diff(radius)-2*magnet/radius**2-charge*dragging.diff(radius))
    barrier=lapse*(2/radius**2+4*charge**2/radius**4)
    stored=(bridge*(momentum**2+field.diff(radius)**2)+barrier*field**2)/2
    flow=-bridge**2*momentum*field.diff(radius)
    work=(bridge.diff(time)*(momentum**2+field.diff(radius)**2)+barrier.diff(time)*field**2)/2
    balance=stored.diff(time)+flow.diff(radius)-work
    demand("local dynamical Poynting balance",balance.subs({field.diff(radius,time):(bridge*momentum).diff(radius),field.diff(time):bridge*momentum,
                  momentum.diff(time):(bridge*field.diff(radius)).diff(radius)-barrier*field},simultaneous=True))
    demand("dipole moment normalization",radius**2*sym.integrate(2*field*cosine**2/radius**2,(cosine,-1,1))/2-2*field/3)
    demand("solid-angle dipole normalization",sym.integrate(1-cosine**2,(cosine,-1,1))/2-sym.Rational(2,3))
    return result

