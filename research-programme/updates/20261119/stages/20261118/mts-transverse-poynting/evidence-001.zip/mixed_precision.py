from scipy.integrate import newton_cotes, simpson
from scipy.interpolate import make_interp_spline
from background import HERE, MESHES, AMPLITUDES, np, output, peak
from pulse import TIMES, acquire, pulse_name

class MixedReadout:
    def __init__(self,radius,masks,spots,base,barrier,rotation,strength,twist):
        self.radius=radius;self.masks=masks;self.spots=spots;self.base=base;self.barrier=barrier
        self.rotation=rotation;self.strength=strength;self.twist=twist;self.history=[]
        self.weights=newton_cotes(8,equal=1)[0]*(radius[1]-radius[0])
    def mul(self,left,right):
        base,scalar,rot,mixed=left
        other,shift,twist,cross=right
        ss,rr=self.strength,self.twist
        return (base*other,base*shift+scalar*other+ss*scalar*shift,base*twist+rot*other+rr*rot*twist,
                base*cross+mixed*other+scalar*twist+rot*shift+ss*(scalar*cross+mixed*shift)+
                rr*(rot*cross+mixed*twist)+ss*rr*mixed*cross)
    def sample(self,state,slopes,metric):
        db,df,dbt,dft=metric
        bridge=(self.base,db,0.,0.);rate=(0.,dbt,0.,0.)
        potential=(self.barrier,df*self.barrier,self.rotation,df*self.rotation)
        change=(0.,dft*self.barrier,0.,dft*self.rotation)
        pot=state[:,0];speed=state[:,1]
        square=self.mul(pot,pot)
        kinetic=tuple(v+w for v,w in zip(self.mul(speed,speed),self.mul(slopes,slopes)))
        energy=.5*(self.mul(bridge,kinetic)[3]+self.mul(potential,square)[3])
        flux=-self.mul(self.mul(bridge,bridge),self.mul(speed,slopes))[3]
        work=.5*(self.mul(rate,kinetic)[3]+self.mul(change,square)[3])
        rows=[]
        for mask,(left,right) in zip(self.masks,self.spots):
            def integrate(values):
                block=values[mask]
                assert (len(block)-1)%8==0
                return sum(weight*block[index:index+len(block)-1:8].sum() for index,weight in enumerate(self.weights))
            rows.append([integrate(energy),flux[left],flux[right],integrate(work),simpson(energy[mask],x=self.radius[mask]),
                         simpson(work[mask],x=self.radius[mask])])
        self.history.append(rows)
    def finish(self,mesh,eta,amp,state):
        with np.load(HERE/pulse_name(mesh,eta,amp,False)) as prev:
            assert np.array_equal(state,prev["profiles"][-1])
        output(f"mixed-precise-{mesh}-h{amp:g}.npz",time=TIMES,values=self.history,identical_final=True)

def primitive(values):
    spline=make_interp_spline(TIMES,values,k=5).antiderivative()
    return spline(TIMES)-spline(TIMES[0])

def scores():
    from measure import table, integrated
    rows=[]
    for mesh in MESHES:
        for amp in AMPLITUDES:
            with np.load(HERE/f"mixed-precise-{mesh}-h{amp:g}.npz") as src:
                assert src["identical_final"]
                for shell,series in enumerate(src["values"].transpose(1,0,2)):
                    energy,left,right,work,energy_low,work_low=series.T
                    for label,density,supply,rule in (("Simpson space and time",energy_low,work_low,integrated),
                              ("higher time only",energy_low,work_low,primitive),("higher space only",energy,work,integrated),
                              ("higher space and time",energy,work,primitive)):
                        flow=rule(left-right);transfer=rule(supply)
                        residual=peak(density-density[0]-flow-transfer)
                        rows.append(dict(mesh=mesh,amp=amp,shell=shell,rule=label,absolute=residual,work_peak=peak(transfer),
                                     own_work_error=residual/peak(transfer),passes=residual<2e-5*peak(transfer)))
    return rows

if __name__=="__main__":
    from measure import table
    for count in MESHES:
        for amplitude in AMPLITUDES:
            acquire(count,.8,amplitude,mixed_audit=True)
    table("mixed_precision.csv",scores())

