import csv
from scipy.integrate import cumulative_simpson, simpson
from scipy.interpolate import CubicHermiteSpline, CubicSpline
from scipy.optimize import brentq
from pulse import BRANCHES, DETECTORS, SHELLS, TIMES, gradient, outgoing, pulse_name
from background import AMPLITUDES, CHARGES, HERE, MESHES, guard, np, packet, peak

GATE=2e-5

def table(name,rows):
    with (HERE/name).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)

def integrated(values,axis=TIMES):
    return cumulative_simpson(values,x=axis,initial=0,axis=0)

def score():
    guard()
    budgets=[];exchange=[];effects=[];flat_rows=[];angular=[];inspect=[];rays=[]
    curves={};angles,weights=np.polynomial.legendre.leggauss(6)
    for mesh in MESHES:
        with np.load(HERE/pulse_name(mesh,0.,1.,True)) as src:
            positions=src["radius"];ideal=src["signals"][:,0]
            exact=np.stack(outgoing(TIMES[:,None],DETECTORS[None,:]),axis=1)
            for index,key in enumerate(("potential","electric momentum","magnetic gradient")):
                rel=peak(ideal[:,index]-exact[:,index])/peak(exact[:,index])
                flat_rows.append(dict(mesh=mesh,readout=key,relative=rel,passes=rel<GATE))
            exact_flux=-exact[:,1]*exact[:,2]
            measured=-ideal[:,1]*ideal[:,2]
            err=peak(measured-exact_flux)/peak(exact_flux)
            flat_rows.append(dict(mesh=mesh,readout="outgoing Poynting",relative=err,passes=err<GATE))
            val,speed,slope=outgoing(0.,positions)
            threshold=.1*simpson(.5*(speed**2+slope**2)+val**2/positions**2,x=positions)
        for eta in CHARGES:
            for amp in AMPLITUDES:
                strength=amp**2
                with np.load(HERE/pulse_name(mesh,eta,amp,False)) as src:
                    history=src["history"];signals=src["signals"];radiation=src["effects"]
                    rotation=src["exchange"];geometry=src["geometry"];q=src["charge"].item()
                    profiles=src["profiles"]
                with np.load(HERE/packet(mesh,eta,amp)) as src:
                    pos=src["radius"];metric=src["metric"];source_times=src["time"]
                    con=np.max(src["constraints"],axis=0)
                    inspect.append(dict(mesh=mesh,eta=eta,amp=amp,lapse_absolute=con[0],bridge_absolute=con[1],
                          largest_exterior_dust=con[2],parent_state_matched=src["original_endpoint"].item()))
                for arm,name in enumerate(BRANCHES):
                    if (arm in (6,7) and not eta) or (arm in (2,3,5) and not eta):
                        continue
                    for shell in range(2):
                        stored,left,right,work=history[:,arm,shell].T
                        flow=integrated(left-right)
                        total_work=integrated(work)
                        delta=stored-stored[0]
                        residual=delta-flow-total_work
                        size=max(peak(delta),peak(flow),peak(total_work))
                        label=dict(mesh=mesh,eta=eta,amp=amp,arm=name,shell=shell)
                        budgets.append(dict(**label,delta_E=delta[-1],integrated_left_minus_right=flow[-1],metric_work=total_work[-1],
                                work_peak=peak(total_work),absolute_residual=peak(residual),relative=peak(residual)/size if size else None,
                                work_scale_error=peak(residual)/peak(total_work) if peak(total_work) else None,
                                scale=size,flux_peak=peak(flow),passes=peak(residual)<GATE*size if size else None))
                if eta:
                    for arm in range(2):
                        for shell in range(2):
                            kept,inter,work=rotation[:,arm,shell].T
                            change=kept-kept[0]
                            passed=integrated(inter)
                            correction=integrated(work)
                            err=peak(change-passed-correction)/max(peak(change),peak(passed))
                            exchange.append(dict(mesh=mesh,amp=amp,arm=("ordinary","MTS")[arm],shell=shell,
                                    max_storage_change_per_4Q2=peak(change),max_transfer_per_4Q2=peak(passed),
                                    max_work_per_4Q2=peak(correction),relative=err,passes=err<GATE))
                for tick,step in enumerate([0,128,256,384,512]):
                    time=TIMES[step];inverse=1/pos**2
                    base=1-2*src_mass(mesh,eta,amp)/pos+(q/pos)**2
                    b=base+strength*metric[step//2,0];f=1+strength*metric[step//2,1]
                    radial_metric=np.sqrt(f/b);lapse=np.sqrt(f*b)
                    old,ds,rot,mix=profiles[tick]
                    potential,p=(old+strength*ds)+4*q*q*(rot+strength*mix)
                    deriv=gradient(potential,pos[1]-pos[0])
                    energy=np.zeros_like(pos);flux=np.zeros_like(pos)
                    for cosine,weight in zip(angles,weights):
                        sine=np.sqrt(1-cosine**2)
                        electric=-p*sine/(radial_metric*pos)
                        btheta=-deriv*sine/(radial_metric*pos)
                        brad=2*potential*cosine*inverse
                        energy+=.75*weight*(f*pos**2/2)*(electric**2+btheta**2+brad**2)
                        flux+=.75*weight*lapse**2*pos**2*(-electric*btheta)
                    mask=(pos>=17)&(pos<=23);bounds=np.searchsorted(pos,[17.,23.])
                    observed=history[step,3,0]
                    twist_energy=4*q*q*rotation[step,1,0,0]
                    energy_abs=abs(simpson(energy[mask],x=pos[mask])+twist_energy-observed[0])
                    flux_abs=peak(flux[bounds]-observed[1:3])
                    angular.append(dict(mesh=mesh,eta=eta,amp=amp,time=time,energy_absolute=energy_abs,flux_absolute=flux_abs))
                slot=2
                baseline=signals[:,0,:,slot];pert=signals[:,1,:,slot]
                bare_geom=geometry[:,0,slot];bridge=geometry[:,1,slot];lapsefactor=geometry[:,2,slot]
                index=np.searchsorted(pos,23.)
                samples=metric[:,:,index]
                dbridge,dlapse=np.array([CubicHermiteSpline(source_times,samples[:,which],samples[:,which+2])(TIMES) for which in (0,1)])
                alpha0=np.sqrt(bare_geom[0]);alpha=np.sqrt(bridge*lapsefactor)
                dsquare=dbridge+bare_geom*dlapse+strength*dbridge*dlapse
                da=dsquare/(alpha+alpha0)
                initial_flux=-bare_geom**2*baseline[:,1]*baseline[:,2]
                scalar_flux=radiation[:,0,slot]
                scalar_lum=(scalar_flux-initial_flux/bare_geom*dsquare)/(alpha**2)
                clock=CubicSpline(TIMES,integrated(da))
                base_lum=CubicSpline(TIMES,initial_flux/bare_geom)
                change_lum=CubicSpline(TIMES,scalar_lum)
                test=TIMES[TIMES<=6.375]
                theta=-clock(test)/alpha0
                for iteration in range(4):
                    theta=-clock(test+strength*theta)/alpha0
                matched=change_lum(test+strength*theta)+theta*sum(w/2*base_lum(test+strength*theta*(v+1)/2,1) for v,w in zip(angles,weights))
                old_power=initial_flux/alpha0
                fluence=CubicSpline(TIMES,integrated(old_power))
                power_diff=(scalar_flux-old_power*da)/alpha
                fchange=CubicSpline(TIMES,integrated(power_diff))
                crossing=brentq(lambda t:fluence(t)-threshold,0.,TIMES[-1])
                lag=-fchange(crossing)/fluence(crossing,1)
                for iteration in range(5):
                    mean=sum(w/2*fluence(crossing+strength*lag*(v+1)/2,1) for v,w in zip(angles,weights))
                    lag=-fchange(crossing+strength*lag)/mean
                arrival=alpha0*lag+clock(crossing+strength*lag)
                coupled_flux=radiation[:,1,slot]*4*q*q
                rays.append(dict(mesh=mesh,eta=eta,amp=amp,threshold=threshold,ordinary_proper_arrival=alpha0*crossing,
                        d_coordinate_arrival_per_amp2=lag,d_clock_per_amp2=clock(crossing+strength*lag),proper_arrival_shift=arrival*strength,
                        proper_arrival_per_amp2=arrival,proper_flux_fraction=peak(matched)*strength/peak(base_lum(test)),
                        twist_flux_fraction=peak(coupled_flux)/peak(initial_flux),flux_scale=peak(initial_flux)))
                curves[mesh,eta,amp]=(matched,scalar_flux,radiation[:,1,slot],np.array([arrival]))
    for eta in CHARGES:
        for amp in AMPLITUDES:
            for name,coarse,fine in zip(("proper flux scalar","coordinate flux scalar","coordinate flux twist per 4Q2","proper arrival shift"),curves[960,eta,amp],curves[1920,eta,amp]):
                if eta==0 and "twist" in name:
                    continue
                rel=peak(coarse-fine)/peak(fine)
                effects.append(dict(eta=eta,amp=amp,readout=name,mesh_difference_over_effect=rel,passes=rel<GATE))
    return dict(budgets=budgets,exchange=exchange,refinements=effects,flat=flat_rows,angular=angular,geometry=inspect,arrivals=rays)

def src_mass(mesh,eta,amp):
    with np.load(HERE/packet(mesh,eta,amp)) as src:
        return src["mass"].item()

if __name__=="__main__":
    for name,result in score().items():
        table(name+".csv",result)

