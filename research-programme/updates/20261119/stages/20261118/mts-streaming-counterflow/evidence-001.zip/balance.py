from constraint import validate as hamiltonian
from bank import ROOT,OLD,MODE,Track,np,json,write,CubicSpline
from angular import MU
from scipy.integrate import cumulative_simpson

def audit(case,tag):
    track=Track(case)
    with np.load(ROOT/(tag+'-'+case+'.npz')) as data:
        tau=data['tau'];core=data['core'];out=data['diagnostics']
    table=track.curve(tau)
    dc,dcprime,shear,eta=table[:,7],table[:,8],table[:,11],table[:,12]
    density,flux=table[:,18],table[:,19]
    quadrupole=(density-3*CubicSpline(tau,flux)(tau,1)/MODE)/2
    lower=.25*((-2*dc+6*eta)*MU-2*eta)
    covcurrent=out[:,13]+lower*flux
    rate=4*(core[:,1]+density*dcprime)/3-MODE*covcurrent-2.5*MODE*eta*flux+shear*(MU**2-1/3)*quadrupole
    predicted=out[0,6]+cumulative_simpson(rate,x=tau,initial=0.)
    err=max(abs(predicted-out[:,6]))/max(abs(out[:,6]))
    return dict(energy_fractional_peak_error=float(err),constraint=hamiltonian(case,tag))

def run():
    print({case:audit(case,'fine') for case in ('heavy','cold')})
if __name__=='__main__':run()
