from bank import ROOT,MODE,Track,np,json,write
from scipy.integrate import cumulative_simpson
from angular import MU
from itertools import product

def curvature(density,eta):
    waves= np.array([[np.sqrt(.75),0,.5],[-np.sqrt(.75),0,.5]])
    vector=waves[0]+waves[1]
    metrics=[(-2*density+6*eta)*np.outer(wave,wave)-2*eta*np.eye(3) for wave in waves]
    def gamma(wave,metric):
        return -.5*(np.einsum('b,ac->abc',wave,metric)+np.einsum('c,ab->abc',wave,metric)-np.einsum('a,bc->abc',wave,metric))
    conn=[gamma(wave,metric) for wave,metric in zip(waves,metrics)]
    combined=gamma(vector,(metrics[0]@metrics[1]+metrics[1]@metrics[0])/4)
    scalar=0.
    def derivative(wave,coeff):
        return np.einsum('l,lij->ij',wave,coeff)-np.einsum('j,lil->ij',wave,coeff)
    for one,two in [(0,1),(1,0)]:
        combined-=.5*np.einsum('am,mbc->abc',metrics[one],conn[two])
        scalar-=.5*np.sum(metrics[one]*derivative(waves[two],conn[two]))
        scalar-=.5*(np.einsum('llm,mii',conn[one],conn[two])-np.einsum('lim,mil',conn[one],conn[two]))
    return scalar+np.trace(derivative(vector,combined))

def validate(case,tag):
    track=Track(case)
    options=json.loads((ROOT/(tag+'.json')).read_text())['cases'][case]
    with np.load(ROOT/(tag+'-'+case+'.npz')) as packet:
        time=packet['tau'];core=packet['core'];data=packet['diagnostics']
    table=track.curve(time).T
    (scale,hub,cdm,bary,phot,rel,massive,dens,rate,beta,flow,shear,eta,field,vel,mass2,fluct,speed,*_)=table
    tidal=options['regular']['quadratic_tide']
    first=curvature(1,0);last=curvature(0,1);cross=curvature(1,1)-first-last
    curvature2=MODE**2*(first*dens**2+cross*dens*eta+last*eta**2)
    eta_start=(last+3)/4+(tidal-3/8)*(MODE*time[0])**2/6
    eta2=eta_start+cumulative_simpson((data[:,8]+core[:,1])/3,x=time,initial=0.)
    ricci=curvature2-4*MODE**2*eta2
    proper=cdm*(core[:,0]+.5*dens**2)+bary*(core[:,4]+.5*beta**2-MU*flow**2/2)
    photon=phot*(4*core[:,4]/3+8*beta**2/9-2*MU*flow**2/3)
    scalar=vel*core[:,3]+mass2*field*core[:,2]+.5*(speed**2+(mass2-MU*MODE**2)*fluct**2)
    radiation=rel*data[:,6]+massive*data[:,7]
    energy=proper+photon+scalar+radiation
    residual=ricci-4*hub*core[:,1]+2*rate**2/3-(MU**2-1/3)*shear**2-2*energy
    norm=abs(ricci)+4*hub*abs(core[:,1])+2*rate**2/3+abs((MU**2-1/3)*shear**2)+2*abs(energy)
    return dict(curvature_polynomial=[first,cross,last],initial_eta2=eta_start,peak_residual_over_k2=float(max(abs(residual))/MODE**2),
          peak_residual_over_peak_terms=float(max(abs(residual))/max(norm)),
          residuals_over_k2_at_prefix=[float(residual[np.argmin(abs(MODE*time-end))]/MODE**2) for end in [MODE*time[0],1,3,10,20]],
          peak_local_fraction=float(max(abs(residual)/np.maximum(MODE**2,norm))),final_eta2=float(eta2[-1]))

if __name__=='__main__':
    for case in ('heavy','cold'):
        for tag in ['first','refined','earlier']:
            print(case,tag,validate(case,tag))
