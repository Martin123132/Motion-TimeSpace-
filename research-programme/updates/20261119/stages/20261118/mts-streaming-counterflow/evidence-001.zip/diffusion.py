from bank import ROOT,OLD,EARLY,MATCH,MODE,guard,np,json,sys,store,write,CubicSpline
from scipy.integrate import solve_ivp,cumulative_simpson

def histories(case):
    sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    native=camb.get_background(params_for(EARLY/(case+'.npz')))
    with np.load(OLD/(case+'-native.npz')) as bank:
        top=float(bank['center_t']);times=np.unique(np.r_[np.linspace(bank['t'][0],top,6001),np.array([1.,3.,10.,20.,40.,80.,120.,160.])/MODE])
        table=CubicSpline(bank['t'],bank['raw'],axis=0)(times)
        names=bank['names'].tolist()
        val=lambda name:table[:,names.index(name)]
        bary=CubicSpline(bank['t'],bank['baryon'])(times);cold=CubicSpline(bank['t'],bank['cdm'])(times)
        light=CubicSpline(bank['t'],bank['photon'])(times)
        frac=bary/(bary+cold)
        rate=val('H')*val('growth')*((1-frac)*val('delta_cdm')+frac*val('delta_baryon'))+frac*MODE*val('v_baryon_cdm')
        target=np.stack([val(key) for key in ('delta_baryon','v_baryon_cdm','delta_photon','v_photon','pi_photon')],axis=1)
        therm=native.get_background_time_evolution(times,['opacity','cs2b'])
        coeff=np.stack([val('H'),rate,-val('H')*val('v_newtonian_cdm'),3*bary/(4*light),therm['opacity'],therm['cs2b']],axis=1)
    return times,coeff,target

def evolve(times,coeff,target,lmax,polar):
    count=lmax+1;dims=2+2*count
    photon=2;pol=2+count
    advect=np.zeros((dims,dims));collide=np.zeros_like(advect)
    for offset in [photon,pol]:
        for degree in range(count):
            if degree:advect[offset+degree,offset+degree-1]=MODE*degree/(2*degree+1)
            if degree<lmax:advect[offset+degree,offset+degree+1]=-MODE*(degree+1)/(2*degree+1)
    advect[0,1]=-MODE
    for degree in range(1,count):collide[photon+degree,photon+degree]=-1.
    collide[photon+1,1]=4/3
    for degree in range(count):collide[pol+degree,pol+degree]=-1.
    supply=[photon+2,pol,pol+2] if polar else [photon+2]
    collide[photon+2,supply]+=.1
    if polar:collide[pol,supply]+=.5;collide[pol+2,supply]+=.1
    interp=CubicSpline(times,coeff,axis=0)
    def at(time):
        hub,rate,shear,loading,opacity,pressure=interp(time)
        matrix=advect+opacity*collide
        matrix[1,0]=MODE*pressure;matrix[1,1]=-hub-opacity/loading;matrix[1,photon+1]=.75*opacity/loading
        source=np.zeros(dims)
        source[[0,photon,photon+2]]=[rate,4*rate/3,8*shear/15]
        return matrix,source
    def rhs(time,state):
        matrix,src=at(time)
        return matrix@state+src
    initial=np.zeros(dims);initial[:5]=target[0]
    if polar:initial[[pol,pol+2]]=[1.25*target[0,4],.25*target[0,4]]
    sol=solve_ivp(rhs,(times[0],times[-1]),initial,jac=lambda time,state:at(time)[0],t_eval=times,
                  method='BDF',rtol=2e-9,atol=5e-12,max_step=.15)
    assert sol.success
    return sol.y.T

def run(case):
    times,coeff,target=histories(case);interp=CubicSpline(times,coeff,axis=0)
    def ideal(time,state):
        hub,rate,shear,loading,opacity,pressure=interp(time)
        return [rate-MODE*state[1],(-hub*loading*state[1]+MODE*(1/3+pressure*loading)*state[0])/(1+loading)]
    ideal_state=solve_ivp(ideal,(times[0],times[-1]),target[0,:2],method='DOP853',rtol=1e-10,atol=1e-12,max_step=.1,t_eval=times)
    assert ideal_state.success
    tests={}
    main=evolve(times,coeff,target,12,True)
    alternate=evolve(times,coeff,target,8,True);nopolar=evolve(times,coeff,target,12,False)
    peak=np.max(abs(target),axis=0)
    for name,table in [('full',main),('angular8',alternate),('no_polarization',nopolar)]:tests[name]=(np.max(abs(target-table[:,:5]),axis=0)/peak).tolist()
    tests['full_vs_angular8']=(np.max(abs(main[:,:5]-alternate[:,:5]),axis=0)/peak).tolist()
    assert max(tests['full'])<.01
    loading=coeff[:,3];opacity=coeff[:,4]
    damping=cumulative_simpson(MODE**2/(6*opacity*(1+loading))*(loading**2/(1+loading)+16/15),x=times,initial=0)
    prefixes=[]
    for x in [20,40,80,120,160,MODE*times[-1]]:
        mask=MODE*times<=x+1e-12
        index=int(np.flatnonzero(mask)[-1])
        prefixes.append(dict(k_tau=x,k_over_opacity=MODE/opacity[index],diffusion_exponent=damping[index],
                 ideal_photon_density_error_over_peak=float(np.max(abs(target[mask,2]-4*ideal_state.y[0,mask]/3))/np.max(abs(target[mask,2]))),
                 polarized_density_error_over_peak=float(np.max(abs(target[mask,2]-main[mask,2]))/np.max(abs(target[mask,2])))))
    store(case+'-thomson.npz',times=times,sources=coeff,native=target,ideal=ideal_state.y.T,full_hierarchy=main,unpolarized_hierarchy=nopolar,diffusion_exponent=damping)
    return dict(comparison=tests,prefixes=prefixes)
if __name__=='__main__':
    guard();results={}
    for case in ['heavy','cold']:
        results[case]=run(case);print(case,results[case],flush=True)
    write('diffusion.json',results)
