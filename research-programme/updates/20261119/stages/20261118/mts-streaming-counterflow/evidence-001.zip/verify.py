from balance import audit
from bank import ROOT,OLD,MODE,np,json,guard,write
from pathlib import Path
import ast

def read(name):return json.loads((ROOT/name).read_text(encoding='utf8'))

def summary(case):
    def packet(name):return read(name+'.json')['cases'][case]
    def final(name):return np.array(packet(name)['observables'][-1])
    baseline=final('passive-deep')
    change=final('fine')-baseline
    refinements={}
    for first,last in [('deep','angle'),('angle','thermal'),('thermal','fine'),('fine','restart')]:
        drift=final(last)-final(first)
        frac=max(abs(drift)/np.maximum(1,abs(change)))
        refinements[first+' to '+last]=dict(drift=drift.tolist(),worst=float(frac))
        assert frac<.001
    assert max(packet('restart')['linear_fractional_peak_errors'])<.01
    assert packet('restart')['restart_bit_exact']
    with np.load(ROOT/(case+'-sources.npz')) as source:mass_check=float(source['mass_residual'])
    compare=audit(case,'restart')
    assert compare['energy_fractional_peak_error']<5e-5 and compare['constraint']['peak_local_fraction']<.001
    assert max(abs(final('passive')-np.array(json.loads((OLD/'prepared.json').read_text())[case]['windowed_prepared_result'])))<3e-6
    sampled=read('screen-collision.json')[case];errors=[]
    with np.load(ROOT/(case+'-thomson.npz')) as data:
        for row in sampled:
            ix=np.argmin(abs(data['times']*MODE-row['k_tau']))
            beta,flow,delta,flux,pi=data['full_hierarchy'][ix,:5]
            expected=.5*(beta*(4*flow/3-flux)+4*delta*flow/3-pi*(-.5-1/3)*flow)
            errors.append(row['per_opacity_I_and_Q'][0][1]-expected)
    assert max(abs(np.array(errors)))<2e-10
    mass_change=final('fine')-final('zero-mass')
    return dict(same_start_same_resolution_active=final('fine').tolist(),passive=baseline.tolist(),difference=change.tolist(),
                active_prefix_minus_passive=(np.array(packet('fine')['observables'])-packet('passive-deep')['observables']).tolist(),
                matched_relative_density_fraction=(change[-1]/baseline[-1] if case=='heavy' else None),
                convergence=refinements,active_shift_when_moving_start_early= (final('deep')-final('earlier')).tolist(),
                finite_mass_minus_streaming_as_relativistic=mass_change.tolist(),native_background_mass_check=mass_check,
                maximum_dipole_force_residual=max(abs(np.array(errors))),checks=compare)

if __name__=='__main__':
    guard()
    ans={case:summary(case) for case in ('heavy','cold')}
    for path in ROOT.glob('*.py'):ast.parse(path.read_text(encoding='utf8'))
    write('validation.json',ans)
    print([(case,row['difference']) for case,row in ans.items()])

