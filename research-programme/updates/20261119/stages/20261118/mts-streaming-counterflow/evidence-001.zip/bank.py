from pathlib import Path
import os,sys,json
for setting in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[setting]='1'
ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'mts-early-counterflow-20261118'
sys.path.insert(0,str(OLD))
from histories import MATCH,EARLY,MODE,np,CubicSpline,digest
from scipy.optimize import brentq
from scipy.special import roots_laguerre

def guard():
    assert digest(OLD/'closeout.json')=='b10e2e0829f86c1f7dfe93efea1a26f588b970e30154c6261b1a4ac24d8f45bd'
    assert not any((p/'STOP-REQUESTED').exists() for p in (ROOT,OLD,ROOT.parent))

def store(name,**arrays):
    with (ROOT/name).open('xb') as stream:np.savez_compressed(stream,**arrays)

def write(name,value):
    with (ROOT/name).open('x',encoding='utf8') as stream:json.dump(value,stream,indent=2,allow_nan=False)

def acquire(case):
    guard()
    sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    engine=camb.get_background(params_for(EARLY/(case+'.npz')));engine.Params.Accuracy.IntTolBoost=6
    assert engine.Params.nu_mass_eigenstates==1
    times=np.unique(np.r_[np.geomspace(.003,1,401),np.linspace(.25,20.001,4001)])/MODE
    names=['a','H','delta_cdm','delta_baryon','growth','etak','v_baryon_cdm','v_newtonian_cdm','delta_neutrino','v_neutrino','delta_nu','delta_photon','mts_dphi_h','mts_dphidot_h','mts_q_s']
    raw=engine.get_time_evolution([MODE],times,vars=names,lAccuracyBoost=4)[0]
    scale=raw[:,0];assert scale.min()>0 and np.isfinite(raw).all()
    rho=engine.get_background_densities(scale,['cdm','baryon','photon','neutrino','nu'])
    reference=engine.get_background_densities(np.array([1e-6,.1,1.]),['nu'])['nu']
    nodes,weights=roots_laguerre(64)
    def energy(am):return (weights*nodes**2/(1+np.exp(-nodes)))@np.hypot(nodes,am)
    mass=brentq(lambda mass:energy(mass)/energy(1e-6*mass)-reference[-1]/reference[0],1,1000)
    residual=energy(.1*mass)/energy(1e-6*mass)/(reference[1]/reference[0])-1
    assert abs(residual)<3e-5
    with np.load(OLD/(case+'-native.npz')) as old:
        indices=np.searchsorted(times,[old['t'][0],1/MODE,10/MODE,20/MODE]);oldnames=old['names'].tolist()
        common=[key for key in names if key in oldnames]
        saved=CubicSpline(old['t'],old['raw'][:,[oldnames.index(key) for key in common]],axis=0)(times[indices])
        difference=np.max(abs(saved-raw[indices][:,[names.index(key) for key in common]])/np.maximum(1,abs(saved)))
        assert difference<1e-4
        old_start=float(old['t'][0])
    store(case+'-sources.npz',times=times,raw=raw,names=names,mass=mass,mass_residual=residual,old_start=old_start,native_overlap=difference,**{key:value/scale**2 for key,value in rho.items()})
    print(case,'m/T=',mass,'overlap',difference,flush=True)

class Track:
    def __init__(self,case):
        self.case=case
        with np.load(ROOT/(case+'-sources.npz')) as packet,np.load(EARLY/(case+'.npz')) as bg:
            self.old_start=float(packet['old_start'])
            self.mass=float(packet['mass'])
            raw=packet['raw'];names=packet['names'].tolist();val=lambda name:raw[:,names.index(name)]
            scale=val('a');hub=val('H')
            cdm,bary,phot,rel,massive=(packet[key] for key in ('cdm','baryon','photon','neutrino','nu'))
            dens=val('delta_cdm'); beta=val('delta_baryon');flow=val('v_baryon_cdm')
            frac=bary/(bary+cdm)
            rate=hub*val('growth')*((1-frac)*dens+frac*beta)+frac*MODE*flow
            shear=-hub*val('v_newtonian_cdm');eta=val('etak')/MODE
            field=CubicSpline(bg['heavy_efold'],bg['phi_h'])(np.log(scale)) if case=='heavy' else np.zeros(len(scale))
            vel=CubicSpline(bg['heavy_efold'],bg['phidot_h'])(np.log(scale)) if case=='heavy' else np.zeros(len(scale))
            mass2=(scale*float(bg['heavy_mass_mpc']))**2
            cols=[scale,hub,cdm,bary,phot,rel,massive,dens,rate,beta,flow,shear,eta,field,vel,mass2,val('mts_dphi_h'),val('mts_dphidot_h'),val('delta_neutrino'),val('v_neutrino'),val('delta_nu'),val('delta_photon')]
            self.curve=CubicSpline(packet['times'],np.array(cols).T,axis=0,extrapolate=False)

if __name__=='__main__':
    for case in ('heavy','cold'):acquire(case)
