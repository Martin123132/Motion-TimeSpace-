from bank import ROOT,OLD,EARLY,MATCH,MODE,digest,guard,json,write
import ast
from pathlib import Path
def run():
    guard()
    post=ROOT.parent
    path=ROOT/'closeout.json'
    if path.exists():
        doc=json.loads(path.read_text(encoding='utf8'))
        assert set(doc['files'])=={p.name for p in ROOT.iterdir() if p.is_file() and p!=path}
        for name,value in doc['files'].items():assert digest(ROOT/name)==value,name
        for name,value in doc['inputs'].items():assert digest(post/name)==value,name
        print('verified',len(doc['files']),'files;',len(doc['inputs']),'inputs;',digest(path))
        return
    assert not (ROOT/'__pycache__').exists()
    before=json.loads((OLD/'closeout.json').read_text())
    locked={}
    def include(p,expected=None):
        got=digest(p); assert expected is None or expected==got,p
        locked[p.relative_to(post).as_posix()]=got
    include(OLD/'closeout.json')
    for name in ('histories.py','prepared.json','heavy-green.npz','cold-green.npz','heavy-native.npz','cold-native.npz','heavy-response.json','cold-response.json'):
        include(OLD/name,before['files'][name])
    for source,expected in before['inputs'].items():include(post/source,expected)
    for name in ('native/fortran/massive_neutrinos.f90','native/fortran/results.f90','native/camb/results.py','native/camb/model.py'):
        include(MATCH/name)
    for item in ROOT.glob('*.py'):ast.parse(item.read_text(encoding='utf8'))
    validated=json.loads((ROOT/'validation.json').read_text())
    for case in ('heavy','cold'):
        assert validated[case]['maximum_dipole_force_residual']<2e-10
        assert json.loads((ROOT/'restart.json').read_text())['cases'][case]['restart_bit_exact']
        assert json.loads((ROOT/'diffusion.json').read_text())[case]['comparison']['full'][2]<.01
    write('closeout.json',dict(files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file()},inputs=locked,scope='collisionless nonlinear gravity to k*tau=20; linear polarized diffusion to match; tested quadratic collision samples, no later nonlinear extrapolation',mode=MODE))
    run()
if __name__=='__main__':run()
