from initial import *
import sympy as sp


def main():
    rad,mass,uv,up=sp.symbols("r M u u_r",nonzero=True)
    f=1-2*mass/rad
    d2=(6*uv/rad**2-(2*f/rad+sp.diff(f,rad)/2)*up)/f
    def deriv(expr):return sp.factor(sp.diff(expr,rad)+sp.diff(expr,uv)*up+sp.diff(expr,up)*d2)
    psi=4*rad/3*(uv+f/(2+3*mass/rad)*(uv-rad*up))
    pot=2*f*(12*rad**3+12*mass*rad**2+18*mass**2*rad+9*mass**3)/(rad**3*(2*rad+3*mass)**2)
    acceleration=sp.collect(sp.factor(f*deriv(f*deriv(psi))-pot*psi),[uv,up])
    reduced=sp.factor(acceleration/(mass*f))
    result={"master":str(psi),"initial_acceleration":str(acceleration),"divided":str(reduced)}
    print(result)
    return result


if __name__=="__main__":main()

