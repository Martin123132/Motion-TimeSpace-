from initial import *
from scipy.integrate import simpson


def diff_tide(model,base,baseline,contrast,site):
    u0,v0=baseline(np.log(site));du,dv=contrast(np.log(site))
    mass,md=model.M(site),model.M(site)-base.M(site)
    f=model.f(site);root=np.sqrt(f);f0=base.f(site)
    drt=-2*md/(site*(root+np.sqrt(f0)))
    q=model.qtot
    h,hr,hrr=[model.scalar(site,k) for k in (0,1,2)]
    coef=(-12/site**2-4*mass/site**3+2*q*q/site**4+2*h*h+
          (6*f+2*site*model.f(site,1))*hr*hr+4*site*f*hr*hrr)
    delta_coef=-4*md/site**3+2*h*h+(6*f+2*site*model.f(site,1))*hr*hr+4*site*f*hr*hrr
    return coef*du+delta_coef*u0+4*(root*dv+drt*v0)/site**2


def relative(a,b):
    return abs(a-b)/abs(b) if b else abs(a-b)


def main():
    guard()
    rows=[];mixed=[];norms=[];hist={}
    for mesh in (960,1920):
        for eta,amp in ARMS:
            guard()
            model=Model(mesh,eta,amp)
            out,green=solve(model)
            small,_=solve(model,endpoint=36,green=False)
            rad=model.grid.r
            far=-simpson(rad**4*model.src,x=rad)/5
            exact_far=out.sol(np.log(48))[0]
            ext=1.
            with mp.workdps(45):
                mass,charge=model.mass_infty,model.qtot
                terms=[1.]
                for power in range(4,19):
                    c=(mass*(power-1)*(2*power-3)*terms[-1]-charge**2*((power-2)**2-1)*(terms[-2] if len(terms)>1 else 0))/((power-3)*(power+2))
                    terms.append(c)
                ext=sum(term/48**i for i,term in enumerate(terms))
            asym=48**3*exact_far/ext
            norms.append(dict(mesh=mesh,eta=eta,amp=amp,asymptotic_conformal=asym,flat_green=far,
                              flat_fractional_miss=relative(far,asym),newton_pole_minus_equator_r5=-36*asym,
                              min_coercive=float(min(6+rad**2*model.pot))))
            if amp==0 and eta==.8: baseline=(model,out,green)
            if amp:
                base,ordinary,ogreen=baseline;paired,pairgreen=solve(model,base,ordinary)
            for site in SITES:
                raw=launch(model,out.sol,site);alt=launch(model,green,site)
                u,ur,er,trace=raw
                independently=independent_tide(model,green,site)
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,radius=site,u2=u,radial_pole_eq=1.5*er,
                                 volume_acc_pole_eq=-1.5*trace,radial_length_quadratic=-.75*er,
                                 green_error=relative(alt[2],er),boundary_error=relative(launch(model,small.sol,site)[2],er),
                                 geom_error=relative(independently[0],er),trace_abs_error=abs(independently[1]-trace)))
                if amp:
                    delta=diff_tide(model,base,ordinary.sol,paired.sol,site)
                    other=diff_tide(model,base,ogreen,pairgreen,site)
                    subtract=er-launch(base,ordinary.sol,site)[2]
                    mixed.append(dict(mesh=mesh,amp=amp,radius=site,radial_pole_eq=1.5*delta,volume_acc_pole_eq=-1.5*trace,
                                      conformal_change=paired.sol(np.log(site))[0],green_error=relative(other,delta),
                                      direct_subtraction_error=relative(subtract,delta)))
            key=f"{mesh}-eta{eta:g}-h{amp:g}"
            history=np.linspace(.05,48.,960);hist[key]=np.column_stack([history,*out.sol(np.log(history)),*green(np.log(history))])
    for records,names in ((rows,("radial_pole_eq","volume_acc_pole_eq")),(mixed,("radial_pole_eq","volume_acc_pole_eq","conformal_change"))):
        half=len(records)//2
        for idx,row in enumerate(records):
            first,second=records[idx%half],records[idx%half+half]
            for col in names:row["mesh_"+col]=relative(first[col],second[col])
    write("launch_tides.csv",rows);write("scalar_contrasts.csv",mixed);write("source_moments.csv",norms)
    with (HERE/"constraint_profiles.npz").open("xb") as stream:np.savez_compressed(stream,**hist)
    print([r for r in rows if r["mesh"]==1920 and r["radius"]==6.])
    print([r for r in mixed if r["mesh"]==1920 and r["radius"]==6.])


if __name__=="__main__":main()

