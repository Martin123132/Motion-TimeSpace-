from metric_jets import run


if __name__=="__main__":
    for charge,amp in ((.8,1/160),(.8,1.),(.8,0.),(1.,0.),(0.,0.)):
        for count in (8,10):run(charge,amp,count)

