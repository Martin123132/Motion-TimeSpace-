from initial import *
import sympy as sp


def identities():
    chi,wr,wz,wt,alpha,fac,rad,sin,L,Q,F,cur,law,eta,sigma=sp.symbols("chi wr wz wt alpha fac r sin L Q F C l eta sigma", nonzero=True)
    J=sp.symbols("J");angle=sp.symbols("theta");wave=sp.symbols("A");theta=sp.sin(angle)
    derivative=-sp.diff((J-eta*wave*theta**2)**2/(2*rad**2*theta**2),angle).subs(J,law*theta**2)
    checks={"dust meridional fixed-canonical-label gradient":sp.simplify(derivative-(law**2-eta**2*wave**2)*theta*sp.cos(angle)/rad**2)==0}
    H=sp.Matrix([[1,0,0,0],[0,1,0,0],[0,0,1,0],[wt,wr,wz,1]])
    diag=sp.diag(-alpha**2,fac**2,rad**2,L**2)
    inv=H.inv()*diag.inv()*H.inv().T
    er,et,br,ct,cr,cz=sp.symbols("er et br ct cr cz")
    horiz=sp.Matrix([[0,er+chi*cur,et,ct],[-er-chi*cur,0,br,cr],[-et,-br,0,cz],[-ct,-cr,-cz,0]])
    actual=H.T*horiz*H
    checks["horizontal Maxwell norm incl cross term"]=sp.simplify(sp.trace(inv*actual*inv*actual)-sp.trace(diag.inv()*horiz*diag.inv()*horiz))==0
    checks["polar Maxwell displacement"]=sp.simplify((inv*actual*inv)[1,0]-(er+chi*cur)/(fac*alpha)**2)==0
    checks["fixed background electric cross sign"]=sp.simplify((F*rad**2/4)*(4*(-F*Q/rad**2)*wave*cur/F**2)+Q*wave*cur)==0
    assert all(checks.values()),checks
    return checks


def main():
    guard();checks=identities();rows=[]
    for mesh in (960,1920):
        for eta,amp in ARMS:
            tag=f"{mesh}-eta{eta:g}-h{amp:g}"
            with np.load(source(SRC,f"driven-{tag}-spin0.npz")) as wave:
                rad=wave["radius"];idx=np.flatnonzero(rad==6.).item()
                val=wave["fields"][:,0,idx];q=eta*.002
                signed=-(2/3)*4*q*val**2/6.**2
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,radius=6.,gauss_cross_l2_final=signed[-1],
                                 gauss_cross_l2_peak=max(abs(signed)),null=eta==0.))
    write("polar_source_bridge.csv",rows)
    with (HERE/"reduction_checks.json").open("x") as stream:json.dump(checks,stream,indent=2)
    print(rows[-4:])


if __name__=="__main__": main()

