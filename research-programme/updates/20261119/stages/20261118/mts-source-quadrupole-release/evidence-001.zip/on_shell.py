from initial import *


class ShellModel(Model):
    shell=True
    def __init__(self,mesh,eta,amp,profile=0):
        super().__init__(mesh,eta,amp,profile)
        rad=self.grid.r
        h=self.h
        hr=self.scalar(rad,1);hrr=self.scalar(rad,2)
        hr[rad>=26.]=0.;hrr[rad>=26.]=0.
        primitive=spline(rad,rad*hr*hr).antiderivative()
        mu=np.exp(primitive(rad)-primitive(0.))
        self.mu=spline(rad,mu-1.)
        f=self.root**2
        extra=f*hr**2+rad*f*hr*hrr+rad*h*hr
        self.C=spline(rad,np.column_stack([1/(self.root*mu),
                         mu*(6+rad**2*(self.pot-extra))/self.root,mu*rad*rad*self.src/self.root]))
    def outer(self,rad):
        return (1.+self.mu(rad))*float(super().outer(rad))

