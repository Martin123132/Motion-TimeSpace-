from initial import *
from scipy.integrate import simpson
from exterior import initial_mass


def main():
    guard();rows=[]
    for mesh in (960,1920):
        for eta,amp in ARMS:
            original=Model(mesh,eta,amp)
            primary,primary_green=solve(original)
            with np.load(source(CH,f"charged-{mesh}-eta{eta:g}-h{amp:g}-b1.npz")) as saved:state=saved["initial"]
            aa,alpha=original.grid.metric(state)[:2]
            retained=None
            if mesh==1920 or eta!=0:
                with np.load(source(PARENT,f"higher-{mesh}-eta{eta:g}-h{amp:g}-s0.npz")) as higher:retained=float(higher["initial_adm"])
            for mode in (0,1):
                model=Model(mesh,eta,amp,mode)
                out,green=(primary,primary_green) if mode==0 else solve(model)
                rad=model.grid.r;inv=model.grid.inv
                ell,I=spin(model.grid.integral(rad**2*model.dens),mode)
                adm=2/3*simpson(model.dens*alpha*ell**2/2+2*alpha*aa*I**2*inv**4,x=rad)
                ref=retained if mode==0 else (initial_mass(mode) if eta==1 else None)
                gain=out.sol(np.log(14.))[0]/primary.sol(np.log(14.))[0]
                direct=green(np.log(SITES))/primary_green(np.log(SITES))
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,profile=mode,adm=adm,adm_control=ref,
                                 adm_error=(abs(adm/ref-1) if ref else ""),transfer=gain,
                                 transfer_radius_error=np.max(abs(direct/gain-1)),radial_pole_eq_per_adm=1.5*launch(model,green,6.)[2]/adm))
    write("source_calibration.csv",rows)
    print([row for row in rows if row["mesh"]==1920 and row["eta"]==.8 and row["amp"]==1.])


if __name__=="__main__":main()

