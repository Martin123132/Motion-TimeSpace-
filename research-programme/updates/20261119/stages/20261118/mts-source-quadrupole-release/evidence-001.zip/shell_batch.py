from local_adm import run
from metric_jets import run as jets


if __name__=="__main__":
    for amp in (1.,.00625):
        for mesh in (960,1920):
            run(mesh,amp,"resolved-refined",.8,shell=True)
        for variant in ("resolved-domain","resolved-angle"):
            run(1920,amp,variant,.8,shell=True)
        for order in (8,10):jets(.8,amp,order,shell=True)

