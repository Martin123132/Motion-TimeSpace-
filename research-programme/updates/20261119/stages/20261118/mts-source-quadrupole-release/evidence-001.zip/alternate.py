from local_adm import *


def main():
    guard()
    assert (HERE/"source_calibration.csv").is_file()
    for mesh in (1920,960):
        for eta,amp in ((.8,1.),(.8,1/160),(.8,0.),(0.,0.),(1.,0.)):
            run(mesh,amp,"resolved-refined",eta,1)


if __name__=="__main__":main()

