from local_adm import HERE, guard, np, run


def main():
    for eta,amps in ((.8,(1.,1/160,0.)),(1.,(0.,)),(0.,(0.,))):
        for amp in amps:
            for mesh,variant in [(1920,"resolved-"+key) for key in ("refined","primary","domain","angle","time")]+[(960,"resolved-refined")]:
                guard();path=HERE/f"adm-{mesh}-eta{eta:g}-h{amp:g}-{variant}.npz"
                if path.exists():
                    with np.load(path) as saved:
                        assert saved["time"][-1]==.12 and np.isfinite(saved["volume"]).all()
                    continue
                run(mesh,amp,variant,eta)


if __name__=="__main__":main()

