from initial import *
from score import rowset as csv_rows, archive, sample, score
from source_bridge import identities
from scipy.optimize import brentq


def rowset(stem):return csv_rows(stem+".csv")


def main():
    guard();checks={};origins={}
    def test(label,ok):
        assert label not in checks and bool(ok),label
        checks[label]=True
    def link(folder,member):
        origins[f"{folder.name}/{member}"]=sha(source(folder,member))
    def records(name,count):
        result=rowset(name);assert len(result)==count and all(None not in row for row in result),name
        return result
    def below(row,cols):return all(0<=float(row[k])<TOL for k in cols)
    for folder,items in ((CH,("charged.py",)),(PARENT,("CONSTRAINTS.md","exact_exterior.py","exterior.py","common.py")),
                         (SRC,("current_source.py","EQUATIONS.md")),(CLOUD,("strip.py","EQUATIONS.md","RESULTS.md"))):
        origins[folder.name+"/closeout.json"]=sha(folder/"closeout.json")
        for file in items:link(folder,file)
    for mesh in (960,1920):
        for eta,amp in ARMS:
            tag=f"{mesh}-eta{eta:g}-h{amp:g}"
            link(CH,"charged-"+tag+"-b1.npz");link(SRC,"driven-"+tag+"-spin0.npz")
            if mesh==1920 or eta!=0.:
                link(PARENT,"higher-"+tag+"-s0.npz");link(CLOUD,"strip-"+tag+".npz");link(CLOUD,"path-"+tag+".npz")
                if mesh==1920:link(CLOUD,"cloud-"+tag+".npz")
    test("parent cloud seal",sha(CLOUD/"closeout.json")==LOCK)
    launch=records("launch_tides",50)
    for i,row in enumerate(launch):
        test(f"sourced launch tide {i}",float(row["u2"])<0 and float(row["radial_pole_eq"])>0 and below(row,("green_error","boundary_error","geom_error","mesh_radial_pole_eq")))
    for i,row in enumerate(records("scalar_contrasts",20)):
        test(f"paired launch difference {i}",below(row,("green_error","mesh_radial_pole_eq","mesh_conformal_change")))
    for i,row in enumerate(records("physical_trace",50)):
        if row["structural_null"]=="True":test(f"validated support null {i}",float(row["physical_volume_acceleration"])==0.)
        else:test(f"nonzero scalar focusing at release {i}",float(row["physical_volume_acceleration"])!=0.)
    for i,row in enumerate(records("source_constraint_checks",10)):
        test(f"canonical material and angular momentum input {i}",below(row,("energy_quadrupole_error","momentum_error")) and float(row["external_K_norm"])==0.)
    for i,row in enumerate(records("source_moments",10)):
        test(f"elliptic positivity and flat approximation control {i}",float(row["min_coercive"])>5.9 and float(row["asymptotic_conformal"])<0 and float(row["flat_fractional_miss"])>TOL)
    for i,row in enumerate(records("exact_round",8)):
        test(f"round-sphere stationary reference {i}",below(row,("error","extrapolation","sky_residual")) and float(row["omit_round_surface_shift"])>TOL)
    for i,row in enumerate(records("vacuum_wave",10)):
        reference=next(r for r in launch if r["mesh"]==row["mesh"] and r["eta"]=="0.0" and r["radius"]==row["radius"])
        test(f"pre-front vacuum master {i}",float(row["flat_dynamic"])==0 and below(row,("wave_vs_series","wave_refine","series_refine"))
             and abs(float(row["launch"])/float(reference["radial_pole_eq"])-1)<TOL and float(row["change"])<0)
    for i,row in enumerate(records("source_calibration",20)):
        test(f"independent normalization {i}",float(row["adm"])>0 and below(row,("transfer_radius_error",)) and (not row["adm_error"] or float(row["adm_error"])<TOL))
    for i,row in enumerate(records("cloud_launch_series",50)):
        test(f"launch curvature and scalar EM work {i}",float(row["quartic"])>0 and below(row,("direct_quartic_relative","mesh_quartic"))
             and abs(sum(float(row[k]) for k in ("scalar","electric","anisotropy"))/float(row["quartic"])-1)<1e-12)
    for i,row in enumerate(records("cloud_series_contrasts",20)):test(f"quartic contrasts {i}",below(row,("mesh_quartic",)))
    for i,row in enumerate(records("free_tensor",40)):
        test(f"free momentum checks {i}",below(row,("trace","momentum","magnetic_antisym")) and (float(row["magnetic_norm"])>0 if float(row["radius"])<8.3 else float(row["magnetic_norm"])==0))
    for i,row in enumerate(records("free_shape",20)):
        test(f"free geometry changes invariant tide {i}",float(row["unit_free_tide"])!=0 and below(row,("green_error",)))
    test("retained metric difference constraint floor",any(float(r["linear_constraint_residual"])>TOL for r in rowset("free_shape")))
    for i,row in enumerate(records("constraint_crosschecks",20)):test(f"free shape independent derivative {i}",below(row,("slice_residual",)))
    for i,row in enumerate(records("direct_stress",27)):test(f"angular stress and monopole {i}",below(row,("saved_mean","projection")))
    test("tensor norm, meridional force and Maxwell displacement exact",
         json.loads((HERE/"reduction_checks.json").read_text())==identities() and all(identities().values()))
    for row in records("polar_source_bridge",10):
        assert (float(row["gauss_cross_l2_peak"])>0)==(float(row["eta"])!=0)
    for i,row in enumerate(records("local_radial_representation",4)):test(f"high-precision seed matches stored variation {i}",below(row,("variation_error","gradient_error")))
    for i,row in enumerate(records("clock_evolution_checks",10)):
        eta,amp=float(row["eta"]),float(row["amp"])
        z=archive(eta,amp);t=z["time"];v=z["volume"]
        mask=t<=(.0008 if row["window"]=="short" else .12)
        assert np.isfinite(v).all() and t[0]==v[0]==0 and t[-1]==.12
        co=json.loads((HERE/f"metric-jet-eta{eta:g}-h{amp:g}-n10.json").read_text())["volume_coeff"]
        det=t*t*np.polynomial.polynomial.polyval(t*t,co)
        test(f"independent geometry versus evolved matter and focusing {i}",
             score(det,v,mask)<TOL and float(row["terminal"])==v[mask][-1] and below(row,("jet_order","spatial","time_step","domain","angle","parent_mesh","alternate_error","unspun_error")))
        if amp:
            root=float(row["root"]);assert abs(np.polynomial.polynomial.polyval(root*root,co)/co[0])<TOL
            test(f"nonzero crossing and distinct source {i}",np.any(v[t<root*.95]<0) and np.any(v[t>root*1.05]>0)
                 and below(row,("root_discrepancy","alternate_root_discrepancy")))
        else:test(f"ordinary no observed crossing {i}",np.all(v[t>0]>0) and row["root"]=="")
    test("raw curvature insufficient for early weak zero",any(float(r["raw_metric_error"])>1 for r in rowset("clock_evolution_checks") if r["amp"]=="0.00625" and r["window"]=="short"))
    for i,row in enumerate(records("clock_evolution_contrasts",4)):test(f"time-dependent scalar contrasts {i}",below(row,("jet_error","mesh","space","time_step","angle","domain")))
    for i,row in enumerate(records("shell_constraints",20)):test(f"re-solved shell-fixed constraints {i}",below(row,("normalized_constraint","green_difference")) and float(row["scalar_on_shell"])==0.)
    for i,row in enumerate(records("shell_evolution_checks",4)):
        amp=float(row["amp"])
        with np.load(HERE/f"shell-1920-eta0.8-h{amp:g}-resolved-refined.npz") as z:
            mask=(z["time"]>0)&(z["time"]<=(.0008 if row["window"]=="early" else .12))
            test(f"alternate scalar state no negative sampled volume {i}",np.all(z["volume"][mask]>0) and np.isnan(z["root"]) and
                 below(row,("jet_error","jet_order","parent_mesh","domain","angle")) and abs(float(row["initial_quadratic"]))<1e-50)
    for i,row in enumerate(records("shell_vs_ordinary",4)):
        good=below(row,("jet_error","mesh","angle","domain"))
        test(f"shell scalar contrast not silently promoted {i}",good==(row["passes"]=="True")==(float(row["amp"])==1.))
    for i,row in enumerate(records("weak_limit",20)):
        if row["actual_if_tested"]:
            test(f"small-amplitude law domain {i}",(float(row["leading_relative_miss"])<TOL)==(float(row["amplitude"])<1.))
    for script in HERE.glob("*.py"):compile(script.read_text(encoding="utf8"),str(script),"exec")
    test("all stage outputs regular files",all(p.is_file() and p.suffix in (".py",".md",".csv",".npz",".json") for p in HERE.iterdir()))
    payload={"scope":"conditional analytic and pre-front evolution checks; raw precision misses retained", "tolerance":TOL,
             "parents":origins,"checks":checks,"files":{p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!="closeout.json"}}
    manifest=HERE/"closeout.json"
    if sys.argv[1:]==["--seal"]:
        with manifest.open("x",encoding="utf8") as stream:json.dump(payload,stream,sort_keys=True,indent=2);stream.write("\n")
    else:
        assert not sys.argv[1:] and json.loads(manifest.read_text(encoding="utf8"))==payload
    print("verified",len(checks),"checks",len(payload["files"]),"files",len(origins),"direct/linked sources",sha(manifest))


if __name__=="__main__":assert sys.flags.optimize==0;main()

