from initial import *
from experiment import relative


def quantities(model,out,rad):
    u,bb=out.sol(np.log(rad));f=model.f(rad);fp=model.f(rad,1);fpp=model.f(rad,2)
    up=bb/(rad*np.sqrt(f))
    if rad>=26:
        hs=np.zeros(4)
    else:hs=[model.scalar(rad,n) for n in range(4)]
    h,hr,hrr,hrrr=hs
    electric=model.qtot**2/rad**4
    V=electric-h**2
    upp=((6/rad**2+V)*u-(2*f/rad+fp/2)*up)/f
    grad_lap=f*hrr+(2*f/rad+fp/2)*hr
    h2=grad_lap-h
    h2_r=f*hrrr+(2*f/rad+1.5*fp)*hrr+(2*fp/rad-2*f/rad**2+fpp/2-1)*hr
    dr=-2*rad*u
    h2var=-4*u*grad_lap+2*f*up*hr+dr*h2_r
    m=model.M(rad)
    er=-2*m/rad**3+2*electric-f*hr**2;ric=-h*h+electric;et=(ric-er)/2
    er2=(-12/rad**2-4*m/rad**3+2*electric+2*h**2+(6*f+2*rad*fp)*hr**2+4*rad*f*hr*hrr)*u+4*f*up/rad
    ric2=-2*h*hr*dr
    scalar=(8*h2-2*h)*h2var-2*h2*hr*dr
    electric_work=2*electric*(ric2-er2)+24*electric*u/rad**2
    anisotropy=4*((er-et)*er2+et*ric2)
    return (u,up,upp,hs),np.array([-.5*ric2,-(scalar+electric_work+anisotropy)/24,
                                      -scalar/24,-electric_work/24,-anisotropy/24])


def direct(model,rad,geom,cos):
    u,ur,urr,(hh,first,second,third)=geom
    ds=1j*1e-22
    leg=(3*cos**2-1)/2
    theta2=3*(1-2*cos**2);phi2=-3*cos**2
    dr=-ds*2*rad*u*leg;radius=rad+dr
    f0=model.f(rad);df=model.f(rad,1);f=f0+dr*df
    fr=df+dr*model.f(rad,2)
    h=hh+dr*first;hr=first+dr*second;hrr=second+dr*third
    psi=1+ds*u*leg;pr=ds*ur*leg;prr=ds*urr*leg
    S=radius*psi**2;L=psi**2/np.sqrt(f)
    Lr=L*(2*pr/psi-fr/(2*f))
    cur=(1/radius+2*pr/psi)/L
    cr=(-1/radius**2+2*prr/psi-2*(pr/psi)**2)/L-cur*Lr/L
    radial_t=-cr/L-cur**2-2*ds*u*theta2/S**2
    radial_p=-cr/L-cur**2-2*ds*u*phi2/S**2
    tangent=(1+12*ds*u*leg)/S**2-cur**2
    field=model.qtot/S**2
    tides=np.array([radial_t+radial_p-2*(hr/L)**2-h*h+field**2,
                    radial_t+tangent-h*h-field**2,radial_p+tangent-h*h-field**2])
    trace=field**2-h*h
    acceleration=(f*hrr+(2*f/radius+fr/2)*hr+2*f*pr/psi*hr)/psi**4-h
    dens_e_dd=12*ds*model.qtot*u*leg/rad**4
    metric2=-2*tides[0];jac2=-trace
    phot_dd=(metric2-2*jac2)*field**2+2*field*dens_e_dd
    ric_dd=4*acceleration**2-2*h*acceleration+phot_dd
    return np.array([-trace/2,-(ric_dd+2*sum(tides**2))/24]).imag/ds.imag


def main():
    guard();rows=[];contrasts=[]
    for mesh in (960,1920):
        for eta,amp in ARMS:
            model=Model(mesh,eta,amp);out,_=solve(model,green=False)
            for site in SITES:
                geom,parts=quantities(model,out,site)
                compare=(direct(model,site,geom,1)-direct(model,site,geom,0.))
                result=1.5*parts
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,radius=site,quadratic=result[0],quartic=result[1],
                                 scalar=result[2],electric=result[3],anisotropy=result[4],
                                 flux_support_null=bool(site>=26 or amp==0),direct_quad_abs_error=abs(compare[0]-result[0]),
                                 direct_quartic_relative=relative(compare[1],result[1])))
    for row in rows:
        other=next(s for s in rows if s["mesh"]!=row["mesh"] and all(s[k]==row[k] for k in ("eta","amp","radius")))
        row["mesh_quartic"]=abs(other["quartic"]-row["quartic"])/abs((row if row["mesh"]==1920 else other)["quartic"])
        if row["amp"]:
            base=next(s for s in rows if s["amp"]==0. and all(s[k]==row[k] for k in ("mesh","eta","radius")))
            contrasts.append(dict(mesh=row["mesh"],amp=row["amp"],radius=row["radius"],quadratic=row["quadratic"],
                                  quartic=row["quartic"]-base["quartic"]))
    for row in contrasts:
        other=next(s for s in contrasts if s["mesh"]!=row["mesh"] and s["amp"]==row["amp"] and s["radius"]==row["radius"])
        row["mesh_quartic"]=abs(other["quartic"]-row["quartic"])/abs((row if row["mesh"]==1920 else other)["quartic"])
    write("cloud_launch_series.csv",rows);write("cloud_series_contrasts.csv",contrasts)
    print([r for r in rows if r["mesh"]==1920 and r["radius"]==6.])
    print("worst direct, absolute mesh, raw contrast mesh",max(r["direct_quartic_relative"] for r in rows),
          max(r["mesh_quartic"] for r in rows),max(r["mesh_quartic"] for r in contrasts))


if __name__=="__main__":main()

