from initial import *
from scipy.special import eval_legendre
from numpy.polynomial import Polynomial


def envelope(radius):
    origin,width=6.8,1.5
    coordinate=(radius-origin)/width
    if abs(coordinate)>=1:return np.zeros(4)
    poly=(1-Polynomial([0,1])**2)**7
    return np.array([poly.deriv(k)(coordinate)/width**k for k in range(4)])


def physical(model,r):
    a,ar,arr,_=envelope(r)
    fac=model.f(r);df=model.f(r,1);root=np.sqrt(fac)
    v=root*(r*ar+3*a)/6
    dv=df/(2*root)*(r*ar+3*a)/6+root*(r*arr+4*ar)/6
    w=(r*root*dv+3*root*v-a/2)/2
    return a,v,w


def geometry(model,r,theta):
    f=model.f(r);df=model.f(r,1)
    st=np.sin(theta);ct=np.cos(theta);y=eval_legendre(2,ct)
    tangent=-3*st*ct;plus=1.5*st**2
    u,v,w=physical(model,r)
    metric=np.diag([1/f,r*r,(r*st)**2])
    tensor=np.array([[u/f*y,r*v/np.sqrt(f)*tangent,0],[r*v/np.sqrt(f)*tangent,r*r*(-u*y/2+w*plus),0],
                     [0,0,(r*st)**2*(-u*y/2-w*plus)]])
    gamma=np.zeros((3,3,3));gamma[0,0,0]=-df/(2*f);gamma[0,1,1]=-f*r;gamma[0,2,2]=-f*r*st**2
    gamma[1,0,1]=gamma[1,1,0]=gamma[2,0,2]=gamma[2,2,0]=1/r
    gamma[1,2,2]=-st*ct;gamma[2,1,2]=gamma[2,2,1]=ct/st
    return metric,tensor,gamma


def check(model,r,theta):
    metric,tensor,connection=geometry(model,r,theta)
    inv=np.linalg.inv(metric)
    derivative=np.zeros((3,3,3))
    for axis,step in ((0,1.5e-4),(1,2e-4)):
        def at(off):
            return geometry(model,r+(axis==0)*off*step,theta+(axis==1)*off*step)[1]
        derivative[axis]=(at(-2)-8*at(-1)+8*at(1)-at(2))/(12*step)
    cov=derivative-np.einsum("aij,ak->ijk",connection,tensor)-np.einsum("aik,ja->ijk",connection,tensor)
    div=np.einsum("ij,ijk->k",inv,cov)
    scale=np.sqrt(np.diag(metric));tr=np.trace(inv@tensor)
    ortho=cov/(scale[:,None,None]*scale[None,:,None]*scale[None,None,:])
    magnetic=np.array([ortho[1,2]-ortho[2,1],ortho[2,0]-ortho[0,2],ortho[0,1]-ortho[1,0]])
    return abs(tr),np.linalg.norm(div/scale),np.linalg.norm(magnetic),np.linalg.norm(magnetic-magnetic.T)


def main():
    guard();rows=[]
    for eta,amp in ((0.,0.),(.8,0.),(.8,1/160),(.8,1.)):
        model=Model(1920,eta,amp)
        for radius in (5.75,6.,6.6,7.25,8.6):
            for angle in (.55,1.1):
                tr,div,curl,asym=check(model,radius,angle)
                if eta==0:
                    root=np.sqrt(model.f(radius))
                    u,v,w=physical(model,radius);ar=envelope(radius)[1]
                    kprime=root*ar+u*model.f(radius,1)/(2*root)
                    gdot=radius/3*(root*(u-6*w)+root**2/(2+3*model.mass_infty/radius)*(-2*root*u-radius*kprime+12*v))
                else:gdot=""
                rows.append(dict(eta=eta,amp=amp,radius=radius,theta=angle,trace=tr,momentum=div,magnetic_norm=curl,
                                 magnetic_antisym=asym,neutral_master_rate=gdot))
    write("free_tensor.csv",rows)
    print(max(row["momentum"] for row in rows), max(row["magnetic_norm"] for row in rows),rows[2])


if __name__=="__main__":main()

