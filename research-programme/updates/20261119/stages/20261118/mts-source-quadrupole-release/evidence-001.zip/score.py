from initial import *
from scipy.optimize import brentq


def rowset(name):
    with (HERE/name).open() as stream:return list(csv.DictReader(stream))


def archive(eta,amp,variant="refined",mesh=1920,alternate=False):
    tag="alternate" if alternate else "adm"
    with np.load(HERE/f"{tag}-{mesh}-eta{eta:g}-h{amp:g}-resolved-{variant}.npz") as src:return dict(src)


def sample(data,t,slot):
    arr=data[slot]
    return arr if np.array_equal(data["time"],t) else spline(data["time"],arr)(t)


def score(a,b,mask):
    scale=np.max(abs(b[mask]))
    return np.max(abs(a[mask]-b[mask]))/scale if scale else np.max(abs(a[mask]))


def main():
    guard()
    rows=[];pairs=[];cal=rowset("source_calibration.csv")
    for eta,amp in ARMS:
        sample_data=archive(eta,amp)
        t=sample_data["time"]
        a8,a10=[json.loads((HERE/f"metric-jet-eta{eta:g}-h{amp:g}-n{n}.json").read_text()) for n in (8,10)]
        def compute(coeff):return t*t*np.polynomial.polynomial.polyval(t*t,coeff)
        measured=sample_data["volume"];geom=sample_data["geometric"]
        jets=compute(a10["volume_coeff"]);lower=compute(a8["volume_coeff"])
        zero=np.nan
        if amp:
            coeff=a10["volume_coeff"];zguess=np.sqrt(-coeff[0]/coeff[1])
            zero=brentq(lambda tau:np.polynomial.polynomial.polyval(tau*tau,coeff),.5*zguess,1.5*zguess,xtol=1e-15)
        with np.load(source(CLOUD,f"cloud-1920-eta{eta:g}-h{amp:g}.npz")) as spring:
            ref=spline(spring["tau"],spring["results"][1,:,8])(t)
        baseline_error=score(compute(a10["unspun_coeff"]),ref,t>.025)
        for suffix,mask in (("short",t<=.0008),("whole",t<=.12)):
            runs=[archive(eta,amp,v) for v in ("primary","time","angle","domain")]+[archive(eta,amp,mesh=960)]
            controls=[score(sample(x,t,"volume"),measured,mask) for x in runs]
            another=archive(eta,amp,alternate=True)
            gain=float(next(s["transfer"] for s in cal if int(s["mesh"])==1920 and float(s["eta"])==eta and float(s["amp"])==amp and s["profile"]=="1"))
            rows.append(dict(eta=eta,amp=amp,window=suffix,maximum=np.max(abs(measured[mask])),terminal=measured[mask][-1],
                             jet_error=score(jets,measured,mask),jet_order=score(lower,jets,mask),
                             spatial=controls[0],time_step=controls[1],angle=controls[2],domain=controls[3],parent_mesh=controls[4],
                             raw_metric_error=score(geom,measured,mask),alternate_error=score(another["volume"]/gain,measured,mask),
                             root=sample_data["root"].item() if amp else "",jet_root=zero if amp else "",
                             root_discrepancy=abs(sample_data["root"].item()/zero-1) if amp else "",
                             alternate_root_discrepancy=abs(another["root"].item()/zero-1) if amp else "",unspun_error=baseline_error))
        if amp:
            ctrl=archive(.8,0.);base=ctrl["volume"]
            changed=measured-base
            refcoeff=json.loads((HERE/"metric-jet-eta0.8-h0-n10.json").read_text())["volume_coeff"]
            dj=compute(np.array(a10["volume_coeff"])-refcoeff)
            for label,mask in (("short",t<=.0008),("whole",t<=.12)):
                tests=[]
                for mesh,kind in ((960,"refined"),(1920,"primary"),(1920,"time"),(1920,"angle"),(1920,"domain")):
                    one,two=archive(.8,amp,kind,mesh),archive(.8,0.,kind,mesh)
                    tests.append(score(sample(one,t,"volume")-sample(two,t,"volume"),changed,mask))
                pairs.append(dict(amp=amp,window=label,terminal=changed[mask][-1],peak=np.max(abs(changed[mask])),
                                  jet_error=score(dj,changed,mask),mesh=tests[0],space=tests[1],time_step=tests[2],angle=tests[3],domain=tests[4]))
    write("clock_evolution_checks.csv",rows);write("clock_evolution_contrasts.csv",pairs)
    print("volume jet agreement",max(r["jet_error"] for r in rows),"unspun",max(r["unspun_error"] for r in rows),"contrasts",pairs)


if __name__=="__main__":main()

