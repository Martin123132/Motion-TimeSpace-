from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
CLOUD=HERE.parent/"mts-released-neutral-cloud-20261118"
sys.path.insert(0,str(CLOUD))
from strip import np, csv, json, sha, CH, SRC, PARENT, source, guard as old_guard, TOL
from charged import Charged
from current_source import spin
from scipy.interpolate import make_interp_spline
from scipy.integrate import solve_bvp, solve_ivp, cumulative_simpson
import mpmath as mp

SITES=np.array([5.5,6.,7.,14.,32.])
ARMS=((1.,0.),(.8,0.),(.8,1/160),(.8,1.),(0.,0.))
LOCK="c33dad342d8ad086ebe2e51e62cc7a12a488ab23310fc3d0a71e3592f360d413"


def guard():
    old_guard()
    assert sha(CLOUD/"closeout.json")==LOCK and not (HERE/"STOP-REQUESTED").exists()


def write(name,rows):
    with (HERE/name).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def spline(rad,data):return make_interp_spline(rad,data,axis=0,k=5)


class Model:
    def __init__(self,mesh,eta,amp,profile=0):
        self.grid=Charged(mesh,eta)
        rad=self.grid.r;inv=self.grid.inv;self.eta=eta;self.amp=amp
        with np.load(source(CH,f"charged-{mesh}-eta{eta:g}-h{amp:g}-b1.npz")) as saved: state=saved["initial"]
        h,momentum,density,velocity=state
        assert not np.any(momentum) and not np.any(velocity)
        aa,_,_,_,_,mass,energy,sr,st,_,_,dust,_,grad=self.grid.metric(state)
        q=self.grid.extra[0]
        label=self.grid.integral(rad**2*density)
        ell,internal=spin(label,profile)
        rotational=4*internal**2*inv**6
        kinetic=dust*ell**2*inv**2
        eff=dust+q**2*inv**4-h**2
        src=(rotational+kinetic)/6
        self.root=1/aa;self.pot=eff;self.src=src;self.mass=mass;self.dens=density;self.ell=ell
        self.h=h;self.q=q;self.rot=rotational;self.kin=kinetic
        self.C=spline(rad,np.column_stack([aa,(6+rad**2*eff)*aa,rad**2*src*aa]))
        self.f=spline(rad,1-2*mass*inv);self.scalar=spline(rad,h);self.M=spline(rad,mass)
        self.mass_infty=mass[-1]+q[-1]**2*inv[-1]/2
        self.qtot=q[-1]
        assert np.min(6+rad**2*eff)>5.9 and np.min(1/aa**2)>.95
    def pair(self,base):
        rad=self.grid.r;inv=self.grid.inv
        drt=-2*(self.mass-base.mass)*inv/(self.root+base.root)
        da=-drt/(self.root*base.root)
        dpot=self.dens*drt-self.h**2
        dsrc=self.dens*drt*self.ell**2*inv**2/6
        return spline(rad,np.column_stack([da,rad**2*dpot/self.root+(6+rad**2*base.pot)*da,
                                           rad**2*(dsrc/self.root+base.src*da)]))
    def outer(self,rad):
        with mp.workdps(45):
            rr=mp.mpf(float(rad));mass=mp.mpf(float(self.mass_infty));charge=mp.mpf(float(self.qtot))
            factors=[mp.mpf(1)]
            for power in range(4,19):
                prior=0 if power==4 else factors[-2]
                factors.append((mass*(power-1)*(2*power-3)*factors[-1]-charge**2*((power-2)**2-1)*prior)/((power-3)*(power+2)))
            weights=[coef/rr**idx for idx,coef in enumerate(factors)]
            return -mp.sqrt(1-2*mass/rr+charge**2/rr**2)*sum((3+idx)*term for idx,term in enumerate(weights))/sum(weights)


def solve(model,base=None,original=None,endpoint=48.,green=True):
    small=.0078125
    xmin,xmax=np.log([small,endpoint]);nodes=np.linspace(xmin,xmax,553)
    beta=float(model.outer(endpoint))
    if base:
        dc=model.pair(base)
        with mp.workdps(45):dbeta=float(model.outer(endpoint)-base.outer(endpoint))
        edge=dbeta*original.sol(xmax)[0]
    else:edge=0.
    def coeff(xx):
        rad=np.exp(xx)
        aa,bb,src=model.C(rad).T
        if not base:return aa,bb,np.zeros_like(src),src
        one,two,three=dc(rad).T
        u,v=original.sol(xx)
        return aa,bb,one*v,two*u+three
    typ=max(np.max(abs(coeff(nodes)[3])),abs(edge),1e-45)
    def rhs(x,y):
        a,b,one,two=coeff(x);return np.array([a*y[1]+one/typ,-y[1]+b*y[0]+two/typ])
    out=solve_bvp(rhs,lambda left,right:[left[1]-2*left[0],right[1]-beta*right[0]-edge/typ],
                  nodes,np.zeros((2,len(nodes))),tol=3e-10,max_nodes=15000)
    assert out.success,out.message
    raw=out.sol
    out.sol=lambda x: typ*raw(x)
    if not green:return out,None
    dense=np.linspace(xmin,xmax,12501)
    def hom(x,y):
        a,b,_=model.C(np.exp(x))
        return [a*y[1],b*y[0]-y[1]]
    def basis(start,end,seed,grid):
        ivp=solve_ivp(hom,(start,end),seed,method="DOP853",atol=2e-14,rtol=5e-12,t_eval=grid,max_step=.1)
        assert ivp.success
        return ivp.y
    inside=basis(xmin,xmax,[1.,2.],dense)
    outside=basis(xmax,xmin,[1.,beta],dense[::-1])[:,::-1]
    determinant=inside[0]*outside[1]-inside[1]*outside[0]
    _,_,one,two=coeff(dense)
    deriv_a=(outside[1]*one-outside[0]*two)/determinant
    deriv_b=(inside[0]*two-inside[1]*one)/determinant
    reg=edge/(inside[1,-1]-beta*inside[0,-1])-cumulative_simpson(deriv_a[::-1],x=-dense[::-1],initial=0.)[::-1]
    dec=cumulative_simpson(deriv_b,x=dense,initial=0.)
    both=inside*reg+outside*dec
    other=spline(dense,both.T)
    return out,lambda x:other(x).T


def launch(model,solution,radius):
    u,b=solution(np.log(radius))
    f=model.f(radius);df=model.f(radius,1)
    dr=b/(radius*np.sqrt(f))
    eff=model.C(radius)[1]*np.sqrt(f)/radius**2-6/radius**2
    lap=eff*u
    rr_hess=lap-2*f/radius*dr+6*u/radius**2
    m,dm=model.M(radius),model.M(radius,1)
    h,dh,ddh=[model.scalar(radius,n) for n in (0,1,2)]
    field=model.qtot**2/radius**4
    ric3=-df/radius
    tide_deriv=-2*dm/radius**3+6*m/radius**4-8*field/radius-df*dh**2-2*f*dh*ddh
    e2=-4*u*ric3-2*rr_hess-2*lap+8*u*f*dh**2-8*u*field-2*radius*u*tide_deriv
    trace2=4*radius*u*h*dh
    return np.array([u,dr,e2,trace2])


def independent_tide(model,solution,rad):
    u,b=solution(np.log(rad))
    fac=model.f(rad);fp=model.f(rad,1);fpp=model.f(rad,2)
    ur=b/(rad*np.sqrt(fac))
    coeff=model.C(rad)
    urr=(-(2*fac/rad+fp/2)*ur+coeff[1]/coeff[0]*u/rad**2)/fac
    results=[]
    for pol in (1.,-.5):
        ds=1j*1e-23
        radius=rad-2*rad*u*pol*ds
        shift=radius-rad
        factor=fac+fp*shift
        slope=fp+fpp*shift
        psi=1+ds*u*pol;pr=ds*ur*pol;prr=ds*urr*pol
        lapse=psi**2/np.sqrt(factor)
        dlapse=lapse*(2*pr/psi-slope/(2*factor))
        curvature=(1/radius+2*pr/psi)/lapse
        dcurv=(-1/radius**2+2*prr/psi-2*(pr/psi)**2)/lapse-curvature*dlapse/lapse
        laplapse=-12*ds*u*pol/(psi*(radius*psi**2)**2)
        spatial=-2*dcurv/lapse-2*curvature**2-laplapse
        h_0,hr_0,hrr_0=[model.scalar(rad,n) for n in (0,1,2)]
        h=h_0+hr_0*shift;hr=hr_0+hrr_0*shift
        em=model.qtot**2/(radius*psi**2)**4
        er=spatial-2*(hr/lapse)**2-h**2+em
        trace=-h**2+em
        results.append([er.imag/ds.imag,trace.imag/ds.imag])
    return np.subtract(*results)/1.5

