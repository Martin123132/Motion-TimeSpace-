from initial import *
from scipy.special import factorial


def series_setup(order=22):
    u=np.zeros(order);u[0]=1.
    for idx in range(1,order):
        power=idx+3
        u[idx]=(power-1)*(2*power-3)*u[idx-1]/((power-3)*(power+2))
    def mul(left,right):return np.convolve(left,right)[:order]
    def div(num,den):
        out=np.zeros(order)
        for idx in range(order):
            out[idx]=((num[idx] if idx<len(num) else 0)-sum(den[k]*out[idx-k] for k in range(1,min(idx+1,len(den)))))/den[0]
        return out
    f=[1.,-2.]
    v=div(mul([2.,-4.],[12.,12.,18.,9.]),[4.,12.,9.])
    init=(u+div(mul(f,(4+np.arange(order))*u),[2.,3.]))*4/3
    return u,v,init


def powers(radius,ts,mass,coefficient,terms,order):
    u,v,init=series_setup(order)
    y=np.longdouble(mass)/radius
    poly=np.polynomial.polynomial.polyval
    field=init.astype(np.longdouble)
    total=np.longdouble(0);term=np.longdouble(1)
    for iteration in range(1,terms+1):
        p=2*iteration+np.arange(order)
        xx=p*(p+1)*field
        result=xx.copy()
        result[1:] -= 4*xx[:-1]+2*p[:-1]*field[:-1]
        result[2:] += 4*xx[:-2]+4*p[:-2]*field[:-2]
        field=result-np.convolve(v,field)[:order]
        term*=np.longdouble(ts/radius)**2/((2*iteration-1)*(2*iteration))
        total+=term*poly(y,field)
    return float(coefficient/radius**2*total)


def diamond(radius,ts,mass,coefficient,steps):
    h=ts/steps
    displacement=h*np.arange(-steps,steps+1)
    rr=radius+displacement
    for _ in range(6):
        gap=rr-radius+2*mass*np.log1p((rr-radius)/(radius-2*mass))-displacement
        rr-=gap*(1-2*mass/rr)
    assert rr.min()>5.
    uu,_,_=series_setup()
    y=mass/rr;fac=1-2*y
    u=coefficient/rr**3*np.polynomial.polynomial.polyval(y,uu)
    ru=coefficient/rr**3*np.polynomial.polynomial.polyval(y,-(3+np.arange(len(uu)))*uu)
    forcing=4*mass*fac*(ru+2*u)/(rr*(3*mass+2*rr))
    pot=2*fac*(12+12*y+18*y**2+9*y**3)/(rr**2*(2+3*y)**2)
    last=np.zeros_like(rr);now=.5*h*h*forcing[1:-1];history=[0.,now[len(now)//2]]
    for tick in range(1,steps):
        center=now[1:-1]
        part=slice(tick+1,-tick-1)
        later=now[2:]+now[:-2]-last[2:-2]+h*h*(forcing[part]-pot[part]*center)
        last,now=now,later
        history.append(now[len(now)//2])
    return np.array(history)


def main():
    guard();rows=[];hist={}
    with (HERE/"source_moments.csv").open() as stream:
        moments=list(csv.DictReader(stream))
    for mesh in (960,1920):
        m=Model(mesh,0.,0.)
        mass=m.mass_infty;coef=float(next(row["asymptotic_conformal"] for row in moments if int(row["mesh"])==mesh and float(row["eta"])==0.))
        for rad,ts in zip(SITES,(.3,.65,1.4,6.4,6.4)):
            trajectories=[diamond(rad,ts,mass,coef,steps) for steps in (96,192,384)]
            first,second,third=trajectories
            fine=(4*third[::2]-second)/3;coarse=(4*second[::2]-first)/3
            sample=np.linspace(0,ts,len(fine))
            ref=np.array([powers(rad,t,mass,coef,24,22) for t in sample])
            shorter=powers(rad,ts,mass,coef,16,17)
            dk=-4.5*(2+3*mass/rad)/rad**3
            initial=coef/rad**2*np.polynomial.polynomial.polyval(mass/rad,series_setup()[2])
            scale=np.max(abs(ref));assert scale>0
            rows.append(dict(mesh=mesh,radius=rad,coordinate_time=ts,static_clock_background=ts*np.sqrt(1-2*mass/rad),
                             launch=dk*initial,change=dk*fine[-1],change_to_initial=fine[-1]/initial,
                             wave_vs_series=np.max(abs(fine-ref))/scale,wave_refine=np.max(abs(fine[::2]-coarse))/scale,
                             series_refine=abs(shorter-ref[-1])/scale,flat_dynamic=powers(rad,ts,0.,coef,10,14)))
            hist[f"{mesh}-{rad:g}"]=np.array([sample,dk*fine,dk*ref])
    write("vacuum_wave.csv",rows)
    with (HERE/"vacuum_wave.npz").open("xb") as f:np.savez_compressed(f,**hist)
    print(rows[-5:])


if __name__=="__main__":main()

