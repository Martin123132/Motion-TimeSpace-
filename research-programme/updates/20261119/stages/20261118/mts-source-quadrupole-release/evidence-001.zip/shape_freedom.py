from initial import *
from scipy.interpolate import make_interp_spline
from free_tensor import envelope


class Seed:
    def __init__(self,model):
        self.base=model
        self.outer=model.outer
    def C(self,rad):
        base=self.base
        rr=np.asarray(rad);fac=base.f(rr);fp=base.f(rr,1)
        x=(rr-6.8)/1.5
        z=np.maximum(1-x*x,0.)
        g=z**7
        gp=-14*x*z**6/1.5
        hr=base.scalar(rr,1)
        source=(fac*gp/rr+(fp/rr+(3+fac)/rr**2)*g+fac*hr**2*g)/4
        parent=base.C(rr).copy()
        parent[...,2]=rr**2*source/np.sqrt(fac)
        return parent


def main():
    guard();rows=[]
    for eta,amp in ((0.,0.),(.8,0.),(.8,1/160),(.8,1.)):
        model=Model(1920,eta,amp);seed=Seed(model);solved,alternate=solve(seed)
        for rad in SITES:
            val,flux=solved.sol(np.log(rad));f=model.f(rad);fp=model.f(rad,1)
            hr=model.scalar(rad,1) if rad<26 else 0.
            g,gp,_,_=envelope(rad)
            source=(f*gp/rad+(fp/rad+(3+f)/rad**2)*g+f*hr**2*g)/4
            read=launch(model,solved.sol,rad)[2]+(f*hr**2-f/rad**2)*g
            other=launch(model,alternate,rad)[2]-4*source+f*gp/rad+(fp/rad+3/rad**2+2*f*hr**2)*g
            def components(radius):
                u,v=solved.sol(np.log(radius))
                return np.array([envelope(radius)[0]+4*u,4*u])
            step=.0009
            t=np.arange(-3,4)*step
            fit=make_interp_spline(t,np.array([components(rad+offset) for offset in t]),k=5)
            H,K=fit(0.)
            Hp,Kp=fit(0.,nu=1);_,Kpp=fit(0.,nu=2)
            sc=2*(-f*Kpp-(fp/2+3*f/rad)*Kp+f*Hp/rad+(fp/rad+(3+f)/rad**2)*H+2*K/rad**2)
            density=-hr**2*f*H/2-model.qtot**2*K/rad**4
            measured=sc-4*density
            scale=max(abs(f*Hp/rad),abs(f*Kpp),abs((3+f)*H/rad**2),abs(2*K/rad**2),abs(4*density),1e-40)
            rows.append(dict(eta=eta,amp=amp,radius=rad,unit_free_tide=1.5*read,green_error=abs(other-read)/abs(read),
                             linear_constraint_residual=abs(measured)/scale))
    write("free_shape.csv",rows)
    print(max(row["linear_constraint_residual"] for row in rows))
    print([row for row in rows if row["radius"]==6.])


if __name__=="__main__":main()

