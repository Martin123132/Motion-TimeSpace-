from initial import *
from score import rowset


def main():
    guard();rows=[];prep=[]
    for mesh in (960,1920):
        bare=Model(mesh,.8,0.)
        full=Model(mesh,.8,1.)
        solution,_=solve(bare,green=False)
        weak=Model(mesh,.8,.00625)
        for site in SITES:
            h=full.scalar(site) if site<26 else 0.
            hr=full.scalar(site,1) if site<26 else 0.
            leading= -3*site*solution.sol(np.log(site))[0]*h*hr
            saved=rowset("cloud_launch_series.csv")
            fourth=float(next(r["quartic"] for r in saved if int(r["mesh"])==mesh and float(r["eta"])==.8 and float(r["amp"])==0. and float(r["radius"])==site))
            factor=np.sqrt(-leading/fourth) if leading*fourth<0 else None
            for amp in (.00625,1.):
                root=""
                if site==6.:
                    with np.load(HERE/f"adm-{mesh}-eta0.8-h{amp:g}-resolved-refined.npz") as src:root=float(src["root"])
                rows.append(dict(mesh=mesh,amplitude=amp,radius=site,leading_quadratic=leading*amp**2,
                                 weak_limit_slope=factor if factor is not None else "",root_forecast=amp*factor if factor is not None else "",
                                 actual_if_tested=root,leading_relative_miss=(abs(amp*factor/root-1) if root!="" and factor is not None else ""),
                                 category="opposite signs; local candidate" if factor is not None else "no leading small-time crossing"))
        for mod in (full,weak):
            rad=np.linspace(5.1,7.,71)
            h0=mod.scalar(6.);cs=-.0008*mod.amp*.002
            const=(mod.scalar(6.,1)-cs)*36
            shape=h0+cs*(rad-6)+const*(1/6-1/rad)
            prep.append(dict(mesh=mesh,amp=mod.amp,variation_error=max(abs(shape-mod.scalar(rad)))/np.ptp(mod.scalar(rad)),
                             gradient_error=max(abs(cs+const/rad**2-mod.scalar(rad,1)))/max(abs(mod.scalar(rad,1)))))
        assert np.allclose(weak.h*160,full.h,rtol=1e-14,atol=1e-30)
    write("weak_limit.csv",rows);write("local_radial_representation.csv",prep)
    print([r for r in rows if r["radius"]==6. and r["mesh"]==1920])


if __name__=="__main__":main()

