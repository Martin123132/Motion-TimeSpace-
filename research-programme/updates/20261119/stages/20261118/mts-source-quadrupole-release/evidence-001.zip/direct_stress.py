from initial import *
from scipy.special import roots_legendre
from scipy.interpolate import RectBivariateSpline


def project(Ephi,Btheta,Brpole):
    cos,w=roots_legendre(8)
    sin=np.sqrt(1-cos*cos);leg=(3*cos*cos-1)/2;der=-3*sin*cos
    tensor=1.5*sin**2
    e_phi=Ephi[:,None]*sin;b_t=Btheta[:,None]*sin;br=Brpole[:,None]*cos
    energy=(e_phi**2+b_t**2+br**2)/2
    p_rr=energy-br**2
    ptt=energy-b_t**2;ppp=energy-e_phi**2
    vals=[energy,-e_phi*b_t,p_rr,(ptt+ppp)/2,e_phi*br,-b_t*br,(ptt-ppp)/2]
    bases=[leg]*4+[der,der,tensor]
    sampled=np.array([(val@(w*b))/(b@(w*b)) for val,b in zip(vals,bases)]).T
    both=Ephi**2+Btheta**2
    energy2=(Brpole**2-both)/3
    exact=np.column_stack([energy2,2*Ephi*Btheta/3,energy2-2*Brpole**2/3,Brpole**2/3,
                           -Ephi*Brpole/3,Btheta*Brpole/3,(Ephi**2-Btheta**2)/3])
    return sampled,exact,energy@w


def main():
    guard();rows=[];archive={}
    for mesh in (960,1920):
        for eta,amp in ARMS:
            tag=f"{mesh}-eta{eta:g}-h{amp:g}"
            if not (CLOUD/f"path-{tag}.npz").exists():continue
            with np.load(source(CLOUD,f"path-{tag}.npz")) as p,np.load(source(CLOUD,f"strip-{tag}.npz")) as strip,np.load(source(SRC,f"driven-{mesh}-eta{eta:g}-h{amp:g}-spin0.npz")) as wave:
                sol=p["state"];times=p["tau"];sources=p["force"]
                coeff=[RectBivariateSpline(wave["time"],wave["radius"],wave["fields"][:,k],kx=5,ky=5) for k in range(3)]
                mass=RectBivariateSpline(strip["time"],strip["radius"],strip["values"][:,0],kx=5,ky=5)
                for idx,r0 in enumerate(p["sites"]):
                    tick,rad,momentum=sol[idx,:,:3].T
                    f=1-2*mass.ev(tick,rad)/rad;wp=np.sqrt(f)*momentum;lor=np.sqrt(1+wp**2)
                    aval,pm,xr=[item.ev(tick,rad) for item in coeff]
                    t=-np.sqrt(f)*(lor*pm+wp*xr)/rad;s=-np.sqrt(f)*(lor*xr+wp*pm)/rad
                    sampled,anal,trace0=project(t,s,2*aval/rad**2)
                    direct=3*anal[:,0]
                    trace=sources[idx,:,11]
                    def rel(x,y):
                        norm=np.max(abs(y))
                        return np.max(abs(x-y))/(norm if norm else 1.)
                    errors=[rel(left,right) for left,right in zip(sampled.T,anal.T)]
                    rows.append(dict(mesh=mesh,eta=eta,amp=amp,radius=r0,peak=max(abs(direct)),terminal=direct[-1],
                                     projection=max(errors),saved_mean=rel(trace0,trace)))
                    archive[f"{tag}-R{r0:g}"]=np.column_stack([direct,anal])
    write("direct_stress.csv",rows)
    with (HERE/"direct_stress.npz").open("xb") as stream:np.savez_compressed(stream,tau=times,**archive)
    print(max(r["projection"] for r in rows),max(r["saved_mean"] for r in rows))


if __name__=="__main__":main()

