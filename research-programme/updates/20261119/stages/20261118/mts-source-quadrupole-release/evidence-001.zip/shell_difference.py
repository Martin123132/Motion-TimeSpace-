from score import *


def main():
    rows=[]
    for amp in (.00625,1.):
        def diff(mesh,var):
            with np.load(HERE/f"shell-{mesh}-eta0.8-h{amp:g}-resolved-{var}.npz") as src:
                time=src["time"];val=src["volume"]
            ordinary=archive(.8,0.,var,mesh)
            return time,val-sample(ordinary,time,"volume")
        t,data=diff(1920,"refined")
        one,two=[json.loads(p.read_text())["volume_coeff"] for p in (HERE/f"shell-jet-eta0.8-h{amp:g}-n10.json",HERE/"metric-jet-eta0.8-h0-n10.json")]
        coeff=np.subtract(one,two)
        jet=t*t*np.polynomial.polynomial.polyval(t*t,coeff)
        for label,mask in (("early",t<=.0008),("whole",t<=.12)):
            vals=[]
            for mesh,kind in ((960,"refined"),(1920,"angle"),(1920,"domain")):
                tt,signal=diff(mesh,kind)
                vals.append(score(signal if np.array_equal(t,tt) else spline(tt,signal)(t),data,mask))
            rows.append(dict(amp=amp,window=label,terminal=data[mask][-1],jet_error=score(jet,data,mask),
                             mesh=vals[0],angle=vals[1],domain=vals[2],passes=max(*vals,score(jet,data,mask))<=TOL))
    write("shell_vs_ordinary.csv",rows)
    print(rows)


if __name__=="__main__":guard();main()

