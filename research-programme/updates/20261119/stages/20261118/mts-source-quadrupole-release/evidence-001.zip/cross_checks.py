from initial import *
from shape_freedom import Seed, envelope
from experiment import relative


def main():
    guard();rows=[];source_rows=[];nulls=[]
    with (HERE/"launch_tides.csv").open() as stream:raw=list(csv.DictReader(stream))
    for mesh in (960,1920):
        for eta,amp in ARMS:
            model=Model(mesh,eta,amp)
            rad=model.grid.r;dens=model.dens;inv=model.grid.inv
            label=model.grid.integral(rad**2*dens);ell,I=spin(label,0)
            from scipy.integrate import simpson
            from scipy.special import roots_legendre
            cos,weights=roots_legendre(12);leg=(3*cos*cos-1)/2
            sin2=1-cos*cos
            energy=model.dens*model.root*ell**2*inv**2
            K2=8*I**2*inv**6
            src_numeric=-((2*energy+K2)[:,None]*sin2)@(2.5*weights*leg)/8
            norm=np.max(abs(model.src))
            residual=np.max(abs(src_numeric-model.src))/norm
            mask=(rad>.6)&(rad<4.5)
            slope=make_interp_spline(rad,I,k=5)(rad[mask],nu=1)
            expect=dens[mask]*rad[mask]**2*ell[mask]
            source_rows.append(dict(mesh=mesh,eta=eta,amp=amp,energy_quadrupole_error=residual,
                                    momentum_error=np.max(abs(slope-expect))/max(abs(expect)),external_K_norm=max(abs(K2[rad>5.]))))
            for row in raw:
                if int(row["mesh"])!=mesh or float(row["amp"])!=amp or float(row["eta"])!=eta:continue
                r=float(row["radius"])
                if r>=26:
                    assert np.count_nonzero(model.h[rad>=26])==0
                value=0. if r>=26 or not amp else float(row["volume_acc_pole_eq"])
                nulls.append(dict(mesh=mesh,eta=eta,amp=amp,radius=r,structural_null=bool(r>=26 or not amp),
                                  physical_volume_acceleration=value,raw_spline=float(row["volume_acc_pole_eq"])))
            if mesh!=1920 or eta==1:continue
            seed=Seed(model);_,green=solve(seed)
            for r in SITES:
                dx=.0008*r
                offsets=np.arange(-3,4)*dx
                def get(t):
                    u,v=green(np.log(t))
                    up=v/(t*np.sqrt(model.f(t)))
                    g,gp,_,_=envelope(t)
                    return np.array([g+4*u,4*u,gp+4*up,4*up])
                vals=np.array([get(r+d) for d in offsets])
                H,K,Hp,Kp=vals[3]
                Kpp=spline(offsets,vals[:,3])(0.,nu=1)
                f=model.f(r);fp=model.f(r,1)
                terms=np.array([-f*Kpp,-(fp/2+3*f/r)*Kp,f*Hp/r,(fp/r+(3+f)/r**2)*H,2*K/r**2])
                hr=model.scalar(r,1) if r<26 else 0.
                de=-f*hr**2*H/2-model.qtot**2*K/r**4
                rows.append(dict(eta=eta,amp=amp,radius=r,slice_residual=abs(2*sum(terms)-4*de)/max(abs(terms)),
                                 uses="independent Green flux derivative"))
    write("constraint_crosschecks.csv",rows);write("source_constraint_checks.csv",source_rows);write("physical_trace.csv",nulls)
    print("max",max(row["slice_residual"] for row in rows),max(row["momentum_error"] for row in source_rows))


if __name__=="__main__":main()

