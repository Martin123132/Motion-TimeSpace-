from initial import *
from exact_exterior import evaluator


def direct(jets,rad,angle,charge,spin):
    values=np.asarray(jets(rad,angle,1.,charge,spin)).reshape(6,5)
    metric=np.zeros((4,4));grad=np.zeros((4,4,4));hess=np.zeros((4,4,4,4))
    for idx,(row,col) in enumerate(((0,0),(0,3),(1,1),(2,2),(3,3))):
        for r,c in ((row,col),(col,row)):
            metric[r,c]=values[0,idx]
            grad[1,r,c],grad[2,r,c]=values[1:3,idx]
            hess[1,1,r,c],hess[1,2,r,c],hess[2,2,r,c]=values[3:,idx]
            hess[2,1,r,c]=values[4,idx]
    inv=np.linalg.inv(metric)
    gamma=(grad.transpose(1,0,2)+grad.transpose(1,2,0)-grad)/2
    un=-inv[0]/np.sqrt(-inv[0,0])
    aa=gamma[:,:,1]@un
    return (-un@hess[1,1]@un/2+aa@inv@aa-(np.einsum("mij,i,j->m",gamma,un,un)@inv@gamma[:,1,1]))/metric[1,1]


def main():
    guard();jets=evaluator();rows=[]
    for q in (0.,.6):
        for radius in (4.5,7.,14.,30.):
            f=1-2/radius+q**2/radius**2;k=1-f
            predicted=12/radius**5-10*q**2/radius**6-f/radius**2*(-3/radius**3+4*q**2/radius**4)+(6/radius**4-12*q**2/radius**5)*(1+2*k)/(2*radius)
            vals=[]
            for spin in (.12,.06,.03):
                diffs=[]
                for cos in (.35,.82):
                    doff=lambda c:((1+2*k)*c**2-1-k)/(2*radius)
                    def value(c):
                        return direct(jets,radius+spin**2*doff(c),np.arccos(c),q,spin)
                    diffs.append((value(cos)-value(0.))/cos**2/spin**2)
                vals.append(diffs)
            vals=np.array(vals);one=(4*vals[1]-vals[0])/3;two=(4*vals[2]-vals[1])/3
            rows.append(dict(q=q,radius=radius,forecast=predicted,riemann=two[1],error=abs(two[1]/predicted-1),
                             extrapolation=abs(two[1]-one[1])/abs(predicted),sky_residual=abs(two[0]-two[1])/abs(predicted),
                             omit_round_surface_shift=abs((6/radius**4-12*q**2/radius**5)*(1+2*k)/(2*radius*predicted))))
    write("exact_round.csv",rows);print(rows[0],max(r["error"] for r in rows))


if __name__=="__main__":main()

