from initial import *
import gmpy2 as gp
from functools import lru_cache

gp.get_context().precision=180
number=gp.mpfr
Z=number(0)
TIME=4096;RAD=128;ANGLE=4;SPIN=1


@lru_cache(maxsize=64)
def keys(size,time_max):
    return {t*TIME+x*RAD+a*ANGLE+s for t in range(time_max+1) for x in range(size-t+1) for a in range(size-t-x+1) for s in range(2)}


class Jet:
    allowed={0}
    def __init__(self,items):
        self.terms=items if isinstance(items,dict) else ({0:number(items)} if items else {})
    def __add__(self,other):
        if not isinstance(other,Jet):other=Jet(other)
        merged=self.terms.copy()
        for key,val in other.terms.items():merged[key]=merged.get(key,Z)+val
        return Jet(merged)
    __radd__=__add__
    def __neg__(self):return Jet({k:-v for k,v in self.terms.items()})
    def __sub__(self,other):return self+(-other)
    def __rsub__(self,other):return other+(-self)
    def __mul__(self,other):
        if not isinstance(other,Jet):return Jet({k:v*other for k,v in self.terms.items() if k in Jet.allowed})
        sums={};keep=Jet.allowed
        for left,first in self.terms.items():
            for right,second in other.terms.items():
                key=left+right
                if key in keep:sums[key]=sums.get(key,Z)+first*second
        return Jet(sums)
    __rmul__=__mul__
    def __truediv__(self,other):
        return self*other.recip() if isinstance(other,Jet) else self*(number(1)/other)
    def recip(self):
        val=Jet(1/self.terms[0])
        for _ in range(4):val=val+val*(1-self*val)
        return val
    def sqrt(self):
        val=Jet(1/gp.sqrt(self.terms[0]))
        for _ in range(4):val=val*(3-self*val*val)/2
        return self*val
    def diff(self,direction):
        stride=(TIME,RAD,ANGLE)[direction]
        return Jet({k-stride:v*((k//stride)%32) for k,v in self.terms.items() if ((k//stride)%32)>0})
    def without_time(self):return Jet({k:v for k,v in self.terms.items() if k<TIME})


def initialise(model,solved,cosine,size):
    Jet.allowed=keys(size,0)
    rr=Jet({0:number(6),RAD:number(1)});ir=rr.recip()
    scalar0=number(float(model.scalar(6.)))
    derivative0=number(float(model.scalar(6.,1)))
    slope_const=-number(".0008")*number(float(model.amp))*number(".002")
    B=(derivative0-slope_const)*36
    scalar=scalar0+slope_const*(rr-6)+B*(number(1)/6-ir)
    grad=slope_const+B*ir*ir
    uc,vc=solved.sol(np.log(6.))
    shell=getattr(model,"shell",False)
    if shell:vc=vc/(1.+model.mu(6.))
    mass0=number(float(model.M(6.)))
    mass=Jet(mass0);uv=Jet(number(float(uc)));flux=Jet(number(float(vc)))
    charge=number(float(model.qtot));spinjet=Jet({SPIN:number(1)})
    for j in range(size):
        Jet.allowed=keys(j,0)
        ff=1-2*mass*ir;aa=ff.sqrt().recip()
        massprime=(rr*rr*(ff*grad*grad+scalar*scalar)+charge**2*ir*ir)/2
        uprime=aa*ir*flux
        vprime=ir*(-flux+(6+charge**2*ir*ir-rr*rr*scalar*scalar)*aa*uv)
        if shell:
            extra=ff*grad*grad-2*B*ff*grad*ir*ir+rr*scalar*grad
            vprime=vprime-rr*(grad*grad*flux+aa*extra*uv)
        for val,rhs in ((mass,massprime),(uv,uprime),(flux,vprime)):val.terms[(j+1)*RAD]=rhs.terms.get(j*RAD,Z)/(j+1)
    Jet.allowed=keys(size,0)
    ct=number(str(cosine));st=gp.sqrt(1-ct*ct)
    cc=Jet({ANGLE*j:[ct,-st,-ct,st][j%4]/gp.fac(j) for j in range(size+1)})
    ss=Jet({ANGLE*j:[st,ct,-st,-ct][j%4]/gp.fac(j) for j in range(size+1)})
    pert=spinjet*uv*((3*cc*cc-1)/2)
    radial=(1+4*pert)*(1-2*mass*ir).recip();angular=rr*rr*(1+4*pert)
    cyl=rr*ss*(1+2*pert)
    zeros=lambda:Jet(0)
    state=[radial,zeros(),angular,cyl,zeros(),zeros(),zeros(),zeros(),scalar+2*rr*grad*pert if shell else scalar,zeros(),charge*ss,zeros(),zeros()]
    return state,-12*number(float(uc))*(3*ct*ct-1)/2


def rhs(state,odd):
    A,B,C,S,kx,kb,kz,ko,h,ph,dx,dz,db=state
    det=A*C-B*B;idet=det.recip();isize=S.recip()
    ia,ib,ic=C*idet,-B*idet,A*idet
    jac=S*det.sqrt();ijac=jac.recip()
    Ex=(A*dx+B*dz)*ijac;Ez=(B*dx+C*dz)*ijac;bphi=S*S*db*ijac
    if odd:
        return [-2*kx,-2*kb,-2*kz,-S*ko,ph*ijac,bphi.diff(2),-bphi.diff(1)]
    gx,gz=h.diff(1),h.diff(2)
    ux,uz=ia*gx+ib*gz,ib*gx+ic*gz
    e2=(dx*Ex+dz*Ez)*ijac;b2=(S*db*ijac)*(S*db*ijac)
    px,pz=A.diff(1)/2,B.diff(1)-A.diff(2)/2
    mx,mz=A.diff(2)/2,C.diff(1)/2
    qx,qz=B.diff(2)-C.diff(1)/2,C.diff(2)/2
    def inner(x1,z1,x2,z2):return (ia*x1+ib*z1)*x2+(ib*x1+ic*z1)*z2
    gauss=(B.diff(1).diff(2)-(C.diff(1).diff(1)+A.diff(2).diff(2))/2+inner(mx,mz,mx,mz)-inner(px,pz,qx,qz))*idet
    sx,sz=S.diff(1),S.diff(2)
    Hxx=sx.diff(1)-inner(px,pz,sx,sz);Hxz=sx.diff(2)-inner(mx,mz,sx,sz);Hzz=sz.diff(2)-inner(qx,qz,sx,sz)
    rxx=gauss*A-Hxx*isize;rxz=gauss*B-Hxz*isize;rzz=gauss*C-Hzz*isize
    ro=-(ia*Hxx+2*ib*Hxz+ic*Hzz)*isize
    tr=ia*kx+2*ib*kb+ic*kz+ko;common=h*h+e2+b2
    return [rxx+tr*kx-2*inner(kx,kb,kx,kb)-common*A-2*gx*gx+2*Ex*Ex,
            rxz+tr*kb-2*inner(kx,kb,kb,kz)-common*B-2*gx*gz+2*Ex*Ez,
            rzz+tr*kz-2*inner(kb,kz,kb,kz)-common*C-2*gz*gz+2*Ez*Ez,
            ro+tr*ko-common+2*b2,(jac*ux).diff(1)+(jac*uz).diff(2)-jac*h,-Ez.diff(1)+Ex.diff(2)]


def time_series(model,solution,cosine,order):
    size=order+1
    state,dr=initialise(model,solution,cosine,size)
    for tick in range(order):
        Jet.allowed=keys(size,tick)
        indices=(0,1,2,3,8,10,11) if tick%2 else (4,5,6,7,9,12)
        pieces=rhs(state,tick%2)
        for idx,curve in zip(indices,pieces):
            state[idx].terms.update({k+TIME:v/(tick+1) for k,v in curve.terms.items() if k//TIME==tick and k+TIME in keys(size,tick+1)})
    Jet.allowed=keys(size,order)
    A,B,C,S=state[:4];det=A*C-B*B
    rate=det.diff(0)*det.recip()/2+S.diff(0)*S.recip()
    return [[rate.terms.get((k-1)*TIME+SPIN,Z)/k+dr*rate.terms.get((k-1)*TIME+RAD,Z)/k,
             rate.terms.get((k-1)*TIME,Z)/k] for k in range(2,order+1,2)]


def run(eta,amp,order,shell=False):
    from on_shell import ShellModel
    guard();model=(ShellModel if shell else Model)(1920,eta,amp);out,_=solve(model,green=False)
    first=time_series(model,out,0.,order);second=time_series(model,out,.8,order)
    coeff=[float((b[0]-a[0])/number(".64")) for a,b in zip(first,second)]
    prefix="shell-jet" if shell else "metric-jet"
    with (HERE/f"{prefix}-eta{eta:g}-h{amp:g}-n{order}.json").open("x") as stream:
        json.dump(dict(eta=eta,amp=amp,order=order,volume_coeff=coeff,unspun_coeff=[float(a[1]) for a in first],
                       bits=gp.get_context().precision,spherical_consistency=[float(b[1]-a[1]) for a,b in zip(first,second)]),stream,indent=2)
    print(eta,amp,order,coeff,flush=True)


if __name__=="__main__":run(float(sys.argv[1]),float(sys.argv[2]),int(sys.argv[3]))

