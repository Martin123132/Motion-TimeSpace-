from on_shell import *
from score import archive, score, sample


def main():
    guard();rows=[];constraints=[]
    for amp in (.00625,1.):
        for mesh in (960,1920):
            model=ShellModel(mesh,.8,amp);out,green=solve(model);old=Model(mesh,.8,amp)
            old_solution,_=solve(old,green=False)
            for r in SITES:
                u,v=out.sol(np.log(r))
                up=v/(r*np.sqrt(model.f(r))*(1+model.mu(r)))
                hr=model.scalar(r,1) if r<26 else 0.;hrr=model.scalar(r,2) if r<26 else 0.
                euler=2*r*u*hr
                eulerprime=2*(u+r*up)*hr+2*r*u*hrr
                f=model.f(r);fp=model.f(r,1)
                step=r*.0007;t=np.arange(-3,4)*step
                def deriv(rv):
                    return green(np.log(rv))[1]/(rv*np.sqrt(model.f(rv))*(1+model.mu(rv)))
                upp=spline(t,np.array([deriv(r+d) for d in t]))(0.,nu=1)
                lap=f*upp+(2*f/r+fp/2)*up-6*u/r**2
                pot=model.qtot**2/r**4-model.scalar(r)**2
                h=model.scalar(r) if r<26 else 0.
                de=f*hr*eulerprime+h*euler
                residual=abs(lap-pot*u+de/2)/max(abs(6*u/r**2),1e-40)
                constraints.append(dict(mesh=mesh,amp=amp,radius=r,normalized_constraint=residual,
                                        green_difference=abs(green(np.log(r))[0]/u-1),
                                        conformal_shift_relative=u/old_solution.sol(np.log(r))[0]-1,
                                        scalar_on_shell=euler-2*r*u*hr))
        def get(mesh,variant):
            with np.load(HERE/f"shell-{mesh}-eta0.8-h{amp:g}-resolved-{variant}.npz") as z:return dict(z)
        mainrun=get(1920,"refined");time=mainrun["time"];vol=mainrun["volume"]
        jets=[json.loads((HERE/f"shell-jet-eta0.8-h{amp:g}-n{order}.json").read_text())["volume_coeff"] for order in (8,10)]
        expansion=[time*time*np.polynomial.polynomial.polyval(time*time,c) for c in jets]
        earlier=archive(.8,amp);null=archive(.8,0.)
        for name,mask in (("early",time<=.0008),("whole",time<=.12)):
            controls=[score(sample(get(mesh,var),time,"volume"),vol,mask) for mesh,var in ((960,"refined"),(1920,"domain"),(1920,"angle"))]
            negative=np.min(vol[mask & (time>0)])
            rows.append(dict(amp=amp,window=name,initial_quadratic=jets[1][0],quartic=jets[1][1],
                             smallest_positive_time_value=negative,final=vol[mask][-1],fixed_label_final=earlier["volume"][mask][-1],
                             ordinary_final=null["volume"][mask][-1],jet_error=score(expansion[1],vol,mask),
                             jet_order=score(expansion[0],expansion[1],mask),parent_mesh=controls[0],domain=controls[1],angle=controls[2],
                             positive_samples=int(np.sum(vol[mask & (time>0)]>0)),total_nonzero_times=int(np.sum(mask & (time>0)))))
    write("shell_evolution_checks.csv",rows);write("shell_constraints.csv",constraints)
    print(rows)


if __name__=="__main__": main()

