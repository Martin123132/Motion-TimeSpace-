from stage import ROOT,SOURCE,guard,read,np,digest,packet
import sys
import psutil


BASE=ROOT.parent/'condensate-origin-20261003'
MATCH=BASE/'native-heavy-matching-20261007'
SPEC=BASE/'resolved-matter-spectrum-20261007'
GROW=ROOT.parent/'mts-growth-mode-native-20261118'


def main(case):
    guard()
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([process.cpu_affinity()[0]])
    sys.path.insert(0,str(MATCH))
    import matching_common as source
    from pathlib import Path
    assert Path(source.camb.__file__).resolve().is_relative_to(MATCH/'native')
    library=MATCH/'native/camb/cambdll.dll'
    assert digest(library)==read(GROW/'input-lock.json')['inputs'][str(library)]
    initial=SPEC/'runs/projection/a225-w6-d8.npz' if case=='heavy' else BASE/'native-two-field-transfer-20261007/runs/backgrounds/cold.npz'
    params=source.params_for(initial)
    if case=='lcdm':params.DarkEnergy=source.camb.dark_energy.DarkEnergyFluid()
    params.DoLateRadTruncation=False
    assert not params.WantCls and params.Accuracy.AccuracyBoost==2.5 and params.Accuracy.BackgroundTimeStepBoost==8
    native=source.camb.get_background(params)
    native.Params.Accuracy.IntTolBoost=6
    with np.load(SPEC/'runs'/case/'chunk-0000.npz') as file:
        anchors=file['requested_scale'];anchors=anchors[anchors>=1/3-1e-8]
    with np.load(SPEC/'results/spectrum'/(case+'.npz')) as file:
        kk=file['modes'];kk=kk[kk<=.30]
    times=np.unique(np.r_[anchors,1/np.linspace(3.,1.,81)])
    eta=native.conformal_time(1/times-1,tol=1e-10)
    assert np.all(np.diff(eta)>0)
    names=['a','Weyl','mts_match_count','mts_nonheavy_change']
    pieces=[]
    for start in range(0,len(kk),24):
        guard()
        vals=native.get_time_evolution(kk[start:start+24],eta,vars=names,lAccuracyBoost=4)
        assert np.isfinite(vals).all() and np.max(abs(vals[:,:,0]/times-1))<2e-5
        assert np.all(vals[:,:,2]==(case=='heavy')) and np.all(vals[:,:,3]==0)
        pieces.append(vals[:,:,1])
    packet('dense-'+case+'.npz',modes=kk,scales=times,times=eta,weyl=np.concatenate(pieces),anchors=anchors,
           library=digest(library),initial=digest(initial))
    print(case,len(kk),'modes',len(eta),'epochs',flush=True)


if __name__=='__main__':
    for case in sys.argv[1:]:main(case)
