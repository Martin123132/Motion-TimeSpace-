from stage import ROOT,SOURCE,np,h5py,guard,read,save,digest,sums,delta_chi,meanband,BANDS
from predict import BRANCHES,distance
from run import estimator
import sys


def case(cap,cone):
    guard()
    locks=read(ROOT/'all-forecasts.json')
    assert len(locks)==4 and all(digest(ROOT/name)==val for name,val in locks.items())
    label=cap+str(cone)
    pred=read(ROOT/(label+'-prediction.json'))
    assert pred['packet']==digest(ROOT/(label+'-fields.npz'))
    with h5py.File(SOURCE/'inputs'/f'COMB_{cap}_Uchuu_{cone}.dat.h5') as handle, np.load(ROOT/(label+'-fields.npz')) as forecast:
        def column(name):
            out=np.empty(handle[name].shape);handle[name].read_direct(out);return out
        obs=column('z_obs');weight=column('w_cp')*column('w_fkp')*column('w_npcf')
        idx=np.flatnonzero((obs>=.5)&(obs<.6)&(weight>0))
        assert np.array_equal(idx,forecast['index'])
        weight=weight[idx];red=column('z_cos')[idx];velocity=column('vlos')[idx];obs=obs[idx]
        assert np.max(abs((obs-red)*300000/(1+red)-velocity))<1e-6
        ra,dec=(np.deg2rad(column(key)[idx]) for key in ('ra','dec'))
        unit=np.column_stack([np.cos(ra)*np.cos(dec),np.sin(ra)*np.cos(dec),np.sin(dec)])
        radius=np.linalg.norm(np.column_stack([column(key)[idx] for key in ('x','y','z')]),axis=1)
        shift=delta_chi(red,obs)
        assert np.max(abs(shift-distance(red,velocity)))<1e-9
        half=forecast['half'];truth=[];errs=[]
        for split in (0,1):
            ok=half==split
            field,err=sums(unit[ok],(radius+shift)[ok],weight[ok])
            truth.append(field);errs.append(err)
        real=np.stack([forecast['real'+str(idx)] for idx in (0,1)])
        with np.load(ROOT/f'random-{cap}.npz') as win:
            alpha=np.array(pred['alphas'])
            assert np.allclose(alpha,np.bincount(half,weights=weight)/win['sumw'],rtol=2e-12,atol=0)
            assert abs(pred['norm']/(weight@weight)-1)<1e-12
            def evaluate(fields):return estimator(fields,win['amplitude'],alpha,pred['norm'])
            truth,auto=evaluate(truth);real_power,real_auto=evaluate(real)
            obs_shift=meanband(truth-real_power,True)
            gauss={};ordinary={};per_direction={}
            for mode in BRANCHES:
                predicted=evaluate(np.stack([forecast[mode+str(idx)] for idx in (0,1)]))[0]
                gauss[mode]=meanband(truth-predicted,True).tolist()
                ordinary[mode]=meanband(truth-predicted,False).tolist()
                assert np.max(abs(obs_shift-np.array(pred['spectra'][mode])-gauss[mode]))<1e-9
        finite=forecast['amp'][0]>5
        case_info=dict(high_amplification_rows=int(finite.sum()),missing_high_weight=float(weight[finite&(forecast['kind']==2)].sum()/weight.sum()))
    save(label+'-score.json',dict(freeze=digest(ROOT/'all-forecasts.json'),measured=obs_shift.tolist(),
         auto=meanband(auto-real_auto,True).tolist(),ordinary=meanband(truth-real_power,False).tolist(),errors=gauss,
         ordinary_errors=ordinary,mean_abs={key:float(np.mean(abs(np.array(value)[:,:2]))) for key,value in gauss.items()},
         max_abs={key:float(np.max(abs(np.array(value)[:,:2]))) for key,value in gauss.items()},direct=float(np.max(errs)),**case_info))
    print('scored',label,flush=True)


if __name__=='__main__':
    for arg in sys.argv[1:]:case(arg[0],int(arg[1:]))
