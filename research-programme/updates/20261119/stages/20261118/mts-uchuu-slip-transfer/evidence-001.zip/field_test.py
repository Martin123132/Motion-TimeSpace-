from stage import ROOT,np,guard,digest,read,save,packet
from scipy.linalg import solve_triangular
import itertools


BOSS=ROOT.parent/'mts-boss-window-20261118'
MODELS=('heavy','cold','lcdm')


def basis(cap,order):
    if order=='linear':
        with np.load(BOSS/f'{cap}-frozen.npz') as src:return {key:src[key+'__primary'] for key in MODELS}
    result={}
    for key in MODELS:
        with np.load(BOSS/f'map-{key}-5-{cap}.npz') as src:result[key]=src['fine']
    return result


def experiment(mat,cov,branch1,branch2,cutoff,union):
    root=np.linalg.cholesky(cov)
    white=lambda values:solve_triangular(root,values,lower=True)
    raw={key:white(val) for key,val in mat.items()}
    template=np.column_stack([raw[key][:,idx] for key in (MODELS if union else ('lcdm',)) for idx in (0,1,3)])
    scaled=template/np.linalg.norm(template,axis=0)
    left,sing,_=np.linalg.svd(scaled,full_matrices=False)
    keep=sing>sing[0]*cutoff
    kept=left[:,keep]
    proj=lambda value:value-kept@(kept.T@value)
    delta=raw[branch1][:,2]-raw[branch2][:,2]
    signal=proj(delta);snr=np.linalg.norm(signal)
    assert snr>1e-15 and snr<=np.linalg.norm(delta)*(1+1e-11)
    weights=solve_triangular(root.T,signal/snr,lower=False)
    assert abs(weights@cov@weights-1)<2e-11
    responses={key:(weights@val).tolist() for key,val in mat.items()}
    null=float(np.max(abs(signal/snr@scaled)))
    if cutoff==1e-12 and union:
        assert null<2e-9
        for bias1,bias2 in ((.83,3.17),(3.8,1.04),(1.91,1.91)):
            injection=weights@(mat[branch1]@np.array([bias1**2,bias1,1.,327.])-mat[branch2]@np.array([bias2**2,bias2,1.,-91.]))
            assert abs(injection-snr)<2e-7
    return dict(rank=int(keep.sum()),singular_ratios=(sing/sing[0]).tolist(),raw_constant_distance=float(np.linalg.norm(delta)),
                projected_distance=float(snr),largest_unit_nuisance_leak=null,weights=weights.tolist(),branch_responses=responses)


def main():
    guard()
    seal=read(BOSS/'closeout.json')
    assert digest(BOSS/'closeout.json')=='05e2d4b0f31609a84a379a078844d1714c8e38dd8d0e00979ec6b8f6478f42fe'
    band=(np.arange(40)+.5)*.01
    qual=np.flatnonzero((band>=.02)&(band<.10))
    result={}
    for cap in ('NGC','SGC'):
        covfile=next((BOSS/'inputs').glob('C_2048*'+cap+'*'))
        assets=[covfile,BOSS/f'{cap}-frozen.npz',*[BOSS/f'map-{key}-5-{cap}.npz' for key in MODELS]]
        for file in assets:
            rec=seal['files'][file.relative_to(BOSS).as_posix()]
            expected=rec if isinstance(rec,str) else rec['sha256']
            assert digest(file)==expected
        cov=np.loadtxt(covfile)
        for order,ells in itertools.product(('linear','coherent'),((0,2),(0,2,4))):
            ids=np.concatenate([40*ell+qual for ell in ells]);mat={key:val[ids] for key,val in basis(cap,order).items()}
            local=cov[np.ix_(ids,ids)]
            for one,two in (('heavy','cold'),('heavy','lcdm')):
                prefix=f'{cap}:{order}:{"".join(map(str,ells))}:{one}-{two}'
                case={name:experiment(mat,local,one,two,cut,union) for name,cut,union in [('common',1e-12,True),('relaxed',1e-6,True),('ref_only',1e-12,False)]}
                case['data_indices']=ids.tolist();result[prefix]=case
    mu,wt=np.polynomial.legendre.leggauss(48)
    for cross,vel in ((4.17,1.82),(-.73,2.14),(725.,.0001)):
        delta=2*cross*mu**2+vel*mu**4
        mono=np.dot(wt,delta)/2;quad=5*np.dot(wt,delta*(1.5*mu**2-.5))/2
        assert abs(quad-2*mono-6*vel/35)<1e-10
    save('field-accessibility.json',dict(parent_seal=digest(BOSS/'closeout.json'),observable_powers_read=False,cases=result))


if __name__=='__main__':main()
