from lensing import ROOT,SPEC,GROW,CASES,AMPS,INDEX,np,guard,save,read,digest,build,leggauss
from null_lens import PLANES,projection
from scipy.special import spherical_jn
from scipy.integrate import quad


CEIL=np.array([.10,.16,.20,.25])
MULT=(30,100,188)


def quadrature(edges,order):
    points,weights=leggauss(order)
    widths=np.diff(edges)/2
    return ((edges[:-1]+widths)[:,None]+widths[:,None]*points).ravel(),(widths[:,None]*weights).ravel()


def run(item,coefs,order,matched):
    ds=np.array([item['dist'][str(z)] for z in PLANES])
    grid=item['modes'];kmin=grid[0]
    kb=np.unique(np.clip(np.r_[np.arange(0,CEIL[-1],2*np.pi/ds[-1]),grid,CEIL],kmin,CEIL[-1]))
    kval,kw=quadrature(kb,order)
    vals=np.zeros((len(MULT),len(kval)));white=np.zeros_like(vals)
    lower=ds[0] if matched else 0.
    for start in range(0,len(kval),64):
        select=slice(start,start+64);kk=kval[select]
        spacing=2*np.pi/max(kk)
        cb=np.unique(np.clip(np.r_[lower,np.arange(lower,ds[-1],spacing),ds,item['chi']],lower,ds[-1]))
        chi,cw=quadrature(cb,order)
        geom=np.maximum(0,1-chi[:,None]/ds)@coefs/chi
        if not matched:geom[chi<ds[0]]=-np.sum(coefs/ds)
        xx=kk[:,None]*chi
        kvals,dist=np.broadcast_arrays(kk[:,None],chi)
        weyl=-item['w'](kvals.ravel(),dist.ravel(),'cubic').reshape(xx.shape)/kk[:,None]**2
        weighted=weyl*(geom*cw)
        for loc,ell in enumerate(MULT):
            bessel=spherical_jn(ell,xx)
            vals[loc,select]=np.einsum('ij,ij->i',bessel,weighted)
            if matched:white[loc,select]=bessel@(geom*cw)
    result={}
    for loc,ell in enumerate(MULT):
        pre=(ell*(ell+1))**2
        integrand=4*np.pi*pre*kw/kval*AMPS*(kval/.05)**INDEX*vals[loc]**2
        powers=[float(sum(integrand[kval<cut])) for cut in CEIL]
        receipt=dict(powers=powers)
        if matched:
            target=pre*sum(quad(lambda xx:float(np.maximum(0.,1-xx/ds)@coefs)**2/xx**4,left,right,epsabs=1e-24)[0] for left,right in zip(ds[:-1],ds[1:]))
            tested=(2/np.pi)*pre*np.sum(kw*kval**2*white[loc]**2)
            receipt.update(white_full=target,white_captured=tested/target)
        result[str(ell)]=receipt
    return result


def main():
    guard()
    native=read(GROW/'closeout.json')['files'];old=read(SPEC/'results/stage-integrity.json')['file_hashes'];sources={}
    prior=read(ROOT/'nulled-lensing.json');weights=np.array(prior['weights'])
    result={};geom=read(ROOT/'weyl-projection.json')
    for case in CASES:
        item=build(case,'live',native,old,sources)
        matched=case!='lcdm'
        if matched:assert abs(np.sum(weights/np.array([item['dist'][str(z)] for z in PLANES])))<1e-15
        result[case]={str(order):run(item,weights,order,matched) for order in (6,9)}
        result[case]['limber']={str(ell):[projection(item,weights,ell,kmax=cut)['null'] for cut in CEIL] for ell in MULT}
        print('Bessel check',case,flush=True)
    assert set(sources.items()).issubset(geom['sources'].items())
    save('exact-lensing.json',dict(null_source=digest(ROOT/'nulled-lensing.json'),protocol=digest(ROOT/'EXACT-PROJECTION.md'),
         ceilings=CEIL.tolist(),cases=result))


if __name__=='__main__':main()
