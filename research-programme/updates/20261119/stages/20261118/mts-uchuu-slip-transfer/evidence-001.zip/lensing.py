from stage import ROOT,guard,read,save,digest,np
from scipy.interpolate import RectBivariateSpline,PchipInterpolator
from scipy.optimize import brentq
from numpy.polynomial.legendre import leggauss
from pathlib import Path


POST=ROOT.parent
GROW=POST/'mts-growth-mode-native-20261118'
SPEC=POST/'condensate-origin-20261003/resolved-matter-spectrum-20261007'
CASES=('heavy','cold','lcdm')
CUTS=(.1,.2,.5,1.,5.)
AMPS=2.1e-9
INDEX=-.0347


class Surface:
    def __init__(self,modes,chi,field):
        assert np.all(field>0)
        self.logk=np.log(modes);self.chi=chi
        table=np.log(field)
        self.spline=RectBivariateSpline(self.logk,chi,table,kx=3,ky=3,s=0)
        self.linear=RectBivariateSpline(self.logk,chi,table,kx=3,ky=1,s=0)
        self.pieces=PchipInterpolator(chi,table.T,axis=0).c

    def __call__(self,mode,chi,style):
        logk=np.log(mode)
        assert np.min(logk)>=self.logk[0]-1e-12 and np.max(logk)<=self.logk[-1]+1e-12
        assert np.min(chi)>=self.chi[0]-1e-9 and np.max(chi)<=self.chi[-1]+1e-9
        if style!='pchip':
            return np.exp((self.spline if style=='cubic' else self.linear).ev(logk,chi))
        left=np.clip(np.searchsorted(self.logk,logk)-1,0,len(self.logk)-2)
        base=np.clip(np.searchsorted(self.chi,chi)-1,0,len(self.chi)-2)
        frac=(logk-self.logk[left])/(self.logk[left+1]-self.logk[left])
        coef=self.pieces[:,base,left]*(1-frac)+self.pieces[:,base,left+1]*frac
        dx=chi-self.chi[base]
        return np.exp(((coef[0]*dx+coef[1])*dx+coef[2])*dx+coef[3])


def build(case,hierarchy,native,old,sources):
    def check(path,ledger,base):
        record=ledger[path.relative_to(base).as_posix()]
        want=record if isinstance(record,str) else record['sha256']
        assert digest(path)==want;sources[str(path)]=want
    bg=SPEC/'runs'/case/'background.npz';check(bg,old,SPEC)
    with np.load(bg) as data:
        zv,dm=data['redshifts'],data['DM']
        cdm,baryon,nu=(data[key] for key in ('cdm','baryon','nu'))
    proj=SPEC/'runs/projection/a225-w6-d8.npz'
    with np.load(proj) as data:abundance=float(data['matching_density'])
    sources[str(proj)]=digest(proj)
    if case=='lcdm':
        paths=sorted((SPEC/'runs/lcdm').glob('chunk-*.npz'));ledger,base=old,SPEC
    else:
        prefix='stock-'+case+'-live' if hierarchy=='live' else ('fixed-heavy-rsa' if case=='heavy' else 'stock-cold-rsa')
        paths=sorted((GROW/'full-grid').glob(prefix+'-chunk-*.npz'));ledger,base=native,GROW
    entries=[];modes=[];density=[]
    for path in paths:
        check(path,ledger,base)
        with np.load(path) as data:
            ok=data['modes']<=5
            if not ok.any():continue
            modes.extend(data['modes'][ok])
            vals=data['values'][ok];names=data['names'].tolist()
            get=lambda key:vals[:,:,names.index(key)]
            entries.append(get('Weyl'))
            scales=data['requested_scale' if case=='lcdm' else 'scales']
            times=data['conformal_time' if case=='lcdm' else 'times']
            if len(entries)>1:assert np.array_equal(times,previous)
            previous=times
            if case=='lcdm':
                density.append(get('delta_tot'))
            else:
                weighted=cdm*get('delta_cdm')+baryon*get('delta_baryon')+nu*get('delta_nu')
                denom=cdm+baryon+nu
                if case=='heavy':
                    weighted+=get('a')**2*get('mts_drho_h');denom=denom+abundance*get('a')
                density.append(weighted/denom)
    modes=np.array(modes);assert len(modes)==399 and np.all(np.diff(modes)>0)
    select=np.flatnonzero((scales>=1/3-1e-8)&(scales<=1))[::-1]
    chi=times[-1]-times[select];z=1/scales[select]-1
    assert np.all(np.diff(chi)>0) and np.all(np.diff(z)>0)
    distances={str(zs):float(chi[np.argmin(abs(z-zs))]) for zs in (.51,1.,2.)}
    assert all(abs(distances[str(zs)]-dm[np.argmin(abs(zv-zs))])<1e-4 for zs in (.51,1.,2.))
    wfield=np.concatenate(entries)[:,select];assert (wfield<0).all()
    mat=np.concatenate(density)[:,select];assert (mat>0).all()
    return dict(w=Surface(modes,chi,-wfield),matter=Surface(modes,chi,mat),modes=modes,chi=chi,dist=distances)


def solve(allfields,zsource,ell,order,style):
    nu=ell+.5
    distance=np.array([allfields[case]['dist'][str(zsource)] for case in CASES])
    lo=max(nu/(5*distance))
    breaks=[lo,1.]
    for case,ds in zip(CASES,distance):
        item=allfields[case]
        breaks.extend(nu/(item['modes']*ds));breaks.extend(item['chi']/ds);breaks.extend(nu/(np.array(CUTS)*ds))
    breaks=np.unique(np.clip(breaks,lo,1.))
    breaks=breaks[np.r_[True,np.diff(breaks)>1e-12]]
    breaks[-1]=1.
    def contrast(points):
        return np.max([AMPS*(nu/(points*ds*.05))**INDEX*allfields[case]['matter'](nu/(points*ds),points*ds,style)**2
                       for case,ds in zip(CASES,distance)],axis=0)
    scan=np.unique(np.r_[breaks,(breaks[1:]+breaks[:-1])*.5])
    discriminant=contrast(scan);extra=[]
    for threshold in (.2,1.):
        for idx in np.flatnonzero((discriminant[1:]-threshold)*(discriminant[:-1]-threshold)<0):
            extra.append(brentq(lambda xx:contrast(np.array([xx]))[0]-threshold,scan[idx],scan[idx+1],xtol=1e-14))
    breaks=np.unique(np.r_[breaks,extra])
    nodes,wt=leggauss(order)
    width=np.diff(breaks)/2
    u=((breaks[:-1]+width)[:,None]+width[:,None]*nodes).ravel()
    weights=(width[:,None]*wt).ravel()
    score=contrast(u)
    out={}
    for case,ds in zip(CASES,distance):
        k=nu/(u*ds);chi=u*ds;weyl=allfields[case]['w'](k,chi,style)
        power=2*np.pi**2/k**3*AMPS*(k/.05)**INDEX
        kernel=ds*(ell*(ell+1)/nu**2)**2*(1-u)**2*power*weyl**2
        weighted=weights*kernel
        direct=ds*(ell*(ell+1))**2*(1-u)**2*power*(weyl/k**2)**2/chi**4
        assert np.max(abs(direct/kernel-1))<1e-10
        out[case]=dict(all=float(sum(weighted)),by_k=[float(sum(weighted[k<=cut])) for cut in CUTS],
                       common_linear=[float(sum(weighted[score<threshold])) for threshold in (.2,1.)])
    return out


def main():
    guard()
    native=read(GROW/'closeout.json')['files'];old=read(SPEC/'results/stage-integrity.json')['file_hashes'];sources={}
    live={case:build(case,'live',native,old,sources) for case in CASES}
    approx={case:(build(case,'rsa',native,old,sources) if case!='lcdm' else live[case]) for case in CASES}
    rows=[]
    for zs in (.51,1.,2.):
        for ell in (30,60,100,200,400,800,1200):
            variants={key:solve(fields,zs,ell,order,style) for key,fields,order,style in [
                ('main',live,12,'cubic'),('quadrature',live,24,'cubic'),('linear_time',live,12,'linear'),
                ('pchip',live,12,'pchip'),('fast_hierarchy',approx,12,'cubic')]}
            error=max(abs(variants['main'][case]['all']/variants['quadrature'][case]['all']-1) for case in CASES)
            assert error<2e-5
            rows.append(dict(z=zs,L=ell,shared_u_min=float(max((ell+.5)/(live[case]['dist'][str(zs)]*5) for case in CASES)),
                    variants=variants,quadrature_error=error))
    save('weyl-projection.json',dict(sources=sources,distances={case:live[case]['dist'] for case in CASES},
         cutoffs=CUTS,assumptions=digest(ROOT/'LENSING-PROTOCOL.md'),rows=rows))


if __name__=='__main__':main()
