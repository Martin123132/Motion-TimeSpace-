from stage import ROOT,PRIOR,np,guard,digest,read,save,packet,sums,delta_chi,meanband
from inputs import geometry,environment
from slip_seed import prepare
from population import gauss
from run import estimator
import sys


FILES=('PROTOCOL.md','stage.py','inputs.py','predict.py','score.py')
BRANCHES=('host','independent','pooled','slip_mean','scatter_only','slip_scatter')


def freeze():
    guard()
    seed=read(PRIOR/'boost-safe-seed.json')
    output={}
    for cap in ('S','N'):
        prior,_=prepare(cap,0)
        data=geometry(cap,0,(.2,.5));info=environment(data)
        idx=np.flatnonzero(data['kind']!=0)
        assert np.array_equal(idx,prior['indices']) and np.array_equal(data['kind'][idx],prior['kind'])
        err={}
        for ours,theirs in [('host','host'),('slip','slip'),('scatter','scatter'),('red','zcos')]:
            err[ours]=float(np.max(abs(data[ours][idx]-prior[theirs])/np.maximum(1,abs(prior[theirs]))))
            assert err[ours]<2e-5
        controls={}
        for kind in (1,2):
            keep=prior['kind']==kind
            residual=(prior['velocity']-prior['host'])[keep];wt=prior['weight'][keep]
            vals=np.r_[residual,-residual]
            controls[str(kind)]=gauss(vals,np.tile(wt,2),12)
        output[cap]=dict(control=controls,forecast=seed['caps'][cap]['classes'],reader_parity=err,training_geometry=info)
    save('freeze.json',dict(seed=digest(PRIOR/'boost-safe-seed.json'),caps=output,locks={name:digest(ROOT/name) for name in FILES}))


def distance(red,velocity):
    return delta_chi(red,red+(1+red)*velocity/300000.)


def components(cat,which,cal,mode):
    if mode=='host':
        yield which,cat['host'][which],1.
        return
    for kind in (1,2):
        here=which[cat['kind'][which]==kind];spec=cal['forecast'][str(kind)]
        shift=cat['host'][here].copy()
        if mode in ('slip_mean','slip_scatter'):shift+=spec['gamma']*cat['slip'][here]
        if mode in ('scatter_only','slip_scatter'):
            group=np.searchsorted(spec['edges_kms2'],cat['scatter'][here]);rules=spec['laws']
        else:
            group=np.zeros(len(here),int)
            rules=[cal['control'][str(kind)] if mode=='independent' else spec['pooled']]
        for level,rule in enumerate(rules):
            keep=group==level
            for node,prob in zip(rule['nodes'],rule['probs']):
                yield here[keep],shift[keep]+node,prob


def field(cat,which,cal,mode):
    positions=[];weights=[];directions=[]
    for idx,velocity,prob in components(cat,which,cal,mode):
        positions.append(cat['radius'][idx]+distance(cat['red'][idx],velocity))
        directions.append(cat['unit'][idx]);weights.append(cat['weight'][idx]*prob)
    assert abs(sum(map(np.sum,weights))/cat['weight'][which].sum()-1)<1e-12
    return sums(np.concatenate(directions),np.concatenate(positions),np.concatenate(weights))


def case(cap,cone):
    guard()
    frozen=read(ROOT/'freeze.json')
    assert all(digest(ROOT/name)==val for name,val in frozen['locks'].items())
    data=geometry(cap,cone,(.5,.6));info=environment(data);cal=frozen['caps'][cap]
    half=np.random.default_rng(660551+10*cone+int(cap=='N')).integers(0,2,len(data['index']))
    count=len(half);label=cap+str(cone)
    arrays={};checks=[]
    for split in (0,1):
        mask=half==split;ci=np.flatnonzero(mask&(data['kind']==0));sat=np.flatnonzero(mask&(data['kind']!=0))
        real,err=sums(data['unit'][mask],data['radius'][mask],data['weight'][mask]);checks.append(err)
        central,err=sums(data['unit'][ci],data['radius'][ci]+distance(data['red'][ci],data['host'][ci]),data['weight'][ci]);checks.append(err)
        arrays['real'+str(split)]=real
        for mode in BRANCHES:
            val,err=field(data,sat,cal,mode);checks.append(err);arrays[mode+str(split)]=central+val
    with np.load(ROOT/f'random-{cap}.npz') as win:
        alpha=np.bincount(half,weights=data['weight'])/win['sumw'];norm=data['weight']@data['weight']
        spec={mode:estimator(np.stack([arrays[mode+str(idx)] for idx in (0,1)]),win['amplitude'],alpha,norm)[0] for mode in ('real',*BRANCHES)}
        shifts={mode:meanband(val-spec['real'],True).tolist() for mode,val in spec.items()}
    packet(label+'-fields.npz',**arrays,index=data['index'],half=half,kind=data['kind'],amp=data['amplification'],
           scatter=data['scatter'],slip=data['slip'],host=data['host'])
    save(label+'-prediction.json',dict(window=digest(ROOT/f'random-{cap}.npz'),freeze=digest(ROOT/'freeze.json'),cap=cap,
         cone=cone,selected=count,types=np.bincount(data['kind']).tolist(),geometry=info,alphas=alpha.tolist(),norm=float(norm),
         spectra=shifts,direct_check=float(np.max(checks)),packet=digest(ROOT/(label+'-fields.npz'))))
    print('saved forecast',label,count,flush=True)


def lock():
    names=[cap+str(cone)+'-prediction.json' for cap in ('S','N') for cone in (0,1)]
    assert not list(ROOT.glob('*-score.json'))
    save('all-forecasts.json',{name:digest(ROOT/name) for name in names})


if __name__=='__main__':
    for cmd in sys.argv[1:]:
        if cmd=='freeze':freeze()
        elif cmd=='lock':lock()
        else:case(cmd[0],int(cmd[1:]))
