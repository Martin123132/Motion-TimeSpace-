from stage import ROOT,PRIOR,SOURCE,np,h5py,guard,digest,read,save
from lensing import GROW,SPEC,build
from null_lens import projection,PLANES
from scipy.interpolate import PchipInterpolator


def diagnostic(cap,cone):
    label=cap+str(cone);pred=read(ROOT/(label+'-prediction.json'))
    cal=read(ROOT/'freeze.json')['caps'][cap]
    assert (ROOT/(label+'-score.json')).is_file()
    with np.load(ROOT/(label+'-fields.npz')) as fields,h5py.File(SOURCE/'inputs'/f'COMB_{cap}_Uchuu_{cone}.dat.h5') as source:
        idx=fields['index'];kind=fields['kind'];slip=fields['slip'];host=fields['host'];scatter=fields['scatter']
        def column(key):
            arr=np.empty(source[key].shape);source[key].read_direct(arr);return arr[idx]
        velocity=column('vlos')
        wt=column('w_cp')*column('w_fkp')*column('w_npcf')
    out={}
    for code in (1,2):
        take=kind==code;weight=wt[take]
        residual=velocity[take]-host[take];relative=slip[take]
        obj=cal['forecast'][str(code)];mean=obj['gamma']*relative
        discr=scatter[take];groups=np.searchsorted(obj['edges_kms2'],discr)
        out[str(code)]=dict(gamma_training=obj['gamma'],gamma_diagnostic=float(np.sum(weight*relative*residual)/np.sum(weight*relative**2)),
            rms_independent=float(np.sqrt(np.average(residual**2,weights=weight))),rms_mean=float(np.sqrt(np.average((residual-mean)**2,weights=weight))),
            conditional_rms=[(float(np.sqrt(np.average((residual[groups==level]-mean[groups==level])**2,weights=weight[groups==level]))),rule['rms_kms']) for level,rule in enumerate(obj['laws'])])
    return out


def null_sources():
    native=read(GROW/'closeout.json')['files'];old=read(SPEC/'results/stage-integrity.json')['file_hashes'];sources={}
    data={case:build(case,'live',native,old,sources) for case in ('cold','lcdm')}
    prior=read(ROOT/'nulled-lensing.json');coefs=np.array(prior['weights'])
    def hybrid(geometry,physics):
        geo=data[geometry];donor=data[physics]
        convert=PchipInterpolator(geo['chi'],donor['chi'],extrapolate=False)
        return dict(geo,w=lambda kval,chi,style:donor['w'](kval,convert(chi),style))
    combos=[hybrid('cold','lcdm'),hybrid('lcdm','cold')]
    examples={}
    for row in prior['dense']:
        ell=row['L']
        if str(ell) not in prior['examples']:continue
        hybrids=[np.log(projection(item,coefs,ell)['null']) for item in combos]
        heavy,cold,lcdm=np.log([row[key] for key in ('heavy','cold','lcdm')])
        geom=.5*((hybrids[0]-lcdm)+(cold-hybrids[1]))
        evolution=.5*((hybrids[1]-lcdm)+(cold-hybrids[0]))
        assert abs(geom+evolution+heavy-cold-(heavy-lcdm))<1e-11
        examples[str(ell)]=dict(total_log=float(heavy-lcdm),geometry_log=float(geom),cold_weyl_log=float(evolution),heavy_increment_log=float(heavy-cold))
    sensitivity={}
    for case in ('cold','lcdm'):
        rows=[row for row in prior['dense'] if row['L']<=prior['integer_L'][1]]
        degree=np.array([row['L'] for row in rows])
        y=np.array([row['heavy']/row[case]-1 for row in rows])
        root=np.sqrt(degree+.5)
        responses=np.column_stack([np.ones(len(rows)),np.log((degree+.5)/100.)])
        outcomes=[]
        for num in (1,2):
            design=root[:,None]*responses[:,:num]
            coeff=np.linalg.lstsq(design,root*y,rcond=None)[0]
            outcomes.append(dict(nuisance_coeff=coeff.tolist(),distance=float(np.linalg.norm(root*y-design@coeff))))
        sensitivity[case]=dict(fixed=prior['ideal_auto_distance'][case],amplitude_removed=outcomes[0],amplitude_and_tilt_removed=outcomes[1])
    return dict(log_decomposition=examples,ideal_after_calibration=sensitivity)


if __name__=='__main__':
    guard()
    save('attribution.json',dict(kinematics={cap+str(cone):diagnostic(cap,cone) for cap in ('S','N') for cone in (0,1)},lensing=null_sources()))
