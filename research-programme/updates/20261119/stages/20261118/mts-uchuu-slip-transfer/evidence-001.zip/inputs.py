from stage import SOURCE,ROOT,np,h5py,digest,read
from slip_seed import projected_environment
from scipy.spatial import cKDTree


def geometry(cap,cone,limits):
    path=SOURCE/'inputs'/f'COMB_{cap}_Uchuu_{cone}.dat.h5'
    assert digest(path)==read(SOURCE/(path.name+'.receipt.json'))['sha256']
    with h5py.File(path) as handle:
        def column(name):
            data=np.empty(handle[name].shape)
            handle[name].read_direct(data);return data
        ids,parent=handle['id'][:],handle['pid'][:]
        central=parent==-1
        centers=np.flatnonzero(central)
        wt=column('w_cp')*column('w_fkp')*column('w_npcf')
        def select(redshifts):
            return (redshifts>=limits[0])&(redshifts<limits[1])&(wt>0)
        index=np.flatnonzero(select(column('z_obs')))
        cart=np.column_stack([column(key) for key in ('x','y','z')])
        ra,dec=(np.deg2rad(column(key)) for key in ('ra','dec'))
        radius=np.linalg.norm(cart,axis=1)
        unit=np.column_stack([np.cos(ra)*np.cos(dec),np.sin(ra)*np.cos(dec),np.sin(dec)])
        sky=unit*radius[:,None]
        zcos=column('z_cos')[index]
        cv=np.column_stack([handle[key].astype('f8')[central] for key in ('vx','vy','vz')])
        radial=handle['vlos'].astype('f8')[central]
    sat=np.flatnonzero(~central[index]);ci=np.flatnonzero(central[index])
    central_rows=np.searchsorted(centers,index[ci])
    assert np.max(abs(np.einsum('ij,ij->i',cv[central_rows],cart[index[ci]]/radius[index[ci],None])-radial[central_rows]))<1e-6
    family=np.where(central[index],ids[index],parent[index])
    order=np.argsort(ids[centers],kind='stable')
    ordered=centers[order]
    lower=np.searchsorted(ids[ordered],family[sat]);upper=np.searchsorted(ids[ordered],family[sat],side='right')
    count=np.zeros(len(sat),int);host_ord=np.full(len(sat),-1,int)
    for off in range(max(upper-lower,default=0)):
        loc=np.flatnonzero(lower+off<upper)
        src=index[sat[loc]];ords=order[lower[loc]+off];dst=centers[ords]
        near=(np.linalg.norm(cart[src]-cart[dst],axis=1)<=3)&(np.linalg.norm(sky[src]-sky[dst],axis=1)<=3)
        count[loc[near]]+=1;host_ord[loc[near]]=ords[near]
    matched=count==1
    host=np.full(len(index),np.nan)
    host[ci]=radial[central_rows]
    rr=index[sat[matched]]
    host[sat[matched]]=np.einsum('ij,ij->i',cv[host_ord[matched]],cart[rr]/radius[rr,None])
    kind=np.zeros(len(index),int);kind[sat]=np.where(matched,1,2)
    return dict(index=index,object_id=ids[index],family=family,unit=unit[index],sky=sky[index],radius=radius[index],
                red=zcos,weight=wt[index],kind=kind,host=host)


def environment(cat):
    sat=np.flatnonzero(cat['kind']!=0);centers=np.flatnonzero(cat['kind']==0)
    tree=cKDTree(cat['sky'][centers]);unit=cat['unit'];host=cat['host'].copy()
    env=np.zeros(len(host));scatter=np.zeros(len(host))
    amplification=np.zeros((2,len(host)))
    boost=np.array([-177.,89.,311.]);maxerr=0.;varerr=0.
    for start in range(0,len(sat),3500):
        src=sat[start:start+3500];dist,near=tree.query(cat['sky'][src],k=64,workers=1)
        tally=np.zeros(len(src),int)
        families=np.full((len(src),32),-1,dtype=np.int64)
        which=families.copy();radii=np.empty(which.shape)
        for col in range(64):
            cand=centers[near[:,col]];family=cat['family'][cand]
            take=np.flatnonzero((tally<32)&(dist[:,col]>0)&(family!=cat['family'][src])&~np.any(families==family[:,None],axis=1))
            families[take,tally[take]]=family[take];which[take,tally[take]]=cand[take]
            radii[take,tally[take]]=dist[take,col];tally[take]+=1
        assert np.all(tally==32)
        for idx,size in enumerate((8,32)):
            neighbors=which[:,:size];dirs=unit[neighbors];vel=host[neighbors]
            result=projected_environment(dirs,vel,radii[:,:size],unit[src])
            moved=projected_environment(dirs,vel+dirs@boost,radii[:,:size],unit[src])
            maxerr=max(maxerr,float(max(abs(moved[0]-result[0]-unit[src]@boost))))
            varerr=max(varerr,float(max(abs(moved[1]-result[1])/np.maximum(1,result[1]))))
            amplification[idx,src]=result[2]
            if size==8:
                missing=cat['kind'][src]==2;host[src[missing]]=result[0][missing]
            else:
                env[src]=result[0];scatter[src]=result[1]
    assert np.isfinite(host).all() and maxerr<2e-7 and varerr<2e-5
    slip=np.where(cat['kind']!=0,host-env,0.)
    meta=dict(boost_error_kms=maxerr,boost_relative_variance_error=varerr,
              noise_quantiles={str(size):np.quantile(amplification[idx,sat],[.5,.95,.99,1]).tolist() for idx,size in enumerate((8,32))},
              eight_neighbor_amplification_gt5=int(sum(amplification[0,sat]>5)),
              missing_using_amplification_gt5=int(sum((cat['kind']==2)&(amplification[0]>5))))
    cat.update(host=host,slip=slip,scatter=scatter,amplification=amplification)
    return meta
