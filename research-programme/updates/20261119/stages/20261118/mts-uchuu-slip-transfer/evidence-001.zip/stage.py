from pathlib import Path
import os
import sys
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS','MKL_NUM_THREADS'):
    os.environ[key]='1'
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-uchuu-window-motion-20261118'
SOURCE=ROOT.parent/'mts-uchuu-tracer-20261118'
sys.path.insert(0,str(PRIOR))
from fourier import np,h5py,digest,read,sums,delta_chi,BANDS,meanband
import json


def guard():
    assert digest(PRIOR/'closeout.json')=='3cbd7b8835ee6f1ba79fcb3c88f9c0204bb8572a5225a5fbe9e39795ea831332'
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (ROOT,PRIOR,SOURCE,ROOT.parent))


def save(name,obj):
    with (ROOT/name).open('x',encoding='utf8') as stream:json.dump(obj,stream,indent=2,allow_nan=False)


def packet(name,**fields):
    with (ROOT/name).open('xb') as stream:np.savez(stream,**fields)


def randoms(cap):
    guard()
    path=PRIOR/'inputs'/f'COMB_{cap}_Uchuu.ran.h5'
    assert digest(path)==read(PRIOR/(path.name+'.json'))['sha256']
    result=0
    count=sumw=sumw2=0
    checks=[]
    with h5py.File(path) as handle:
        for start in range(0,len(handle['z_obs']),2500000):
            guard()
            part=slice(start,start+2500000)
            zz=handle['z_obs'][part].astype(float)
            use=(zz>=.5)&(zz<.6);zz=zz[use]
            if not len(zz):continue
            ra,dec=(np.deg2rad(handle[key][part][use].astype(float)) for key in ('ra','dec'))
            unit=np.column_stack([np.cos(ra)*np.cos(dec),np.sin(ra)*np.cos(dec),np.sin(dec)])
            wt=handle['w_fkp'][part][use].astype(float)*handle['w_npcf'][part][use].astype(float)
            val,err=sums(unit,delta_chi(np.zeros(len(zz)),zz),wt)
            result+=val;sumw+=wt.sum();sumw2+=wt@wt;count+=len(wt);checks.append(err)
    packet('random-'+cap+'.npz',amplitude=result,sumw=sumw,sumw2=sumw2,count=count,checks=checks)
    print('random window',cap,count,flush=True)


if __name__=='__main__':
    for cap in sys.argv[1:]:randoms(cap)
