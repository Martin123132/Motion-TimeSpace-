from whole import ROOT,np,guard,read,save,geometry,components,distance,angular_terms,meanband,K,BRANCHES,factorial,comb


def run(cap,cone,prior,cal):
    label=cap+str(cone);cat=geometry(cap,cone,(.5,.6))
    with np.load(ROOT/(label+'-fields.npz')) as file:cat.update({key:file[key] for key in ('host','slip','scatter')})
    sat=np.flatnonzero(cat['kind']!=0);lookup=np.full(len(cat['index']),-1);lookup[sat]=np.arange(len(sat))
    norm=cat['weight']@cat['weight']
    basis={}
    for deg in (12,14):
        pieces=[]
        for rank in (deg,deg+2):
            angles=np.zeros((len(sat),4))
            for aa,bb,cc,wt in angular_terms(rank,deg):
                mon=np.prod(cat['unit'][sat]**np.array([aa,bb,cc]),axis=1)
                angles+=mon[:,None]*wt
            pieces.append(angles)
        basis[deg]=np.stack([pieces[0],5*(1.5*pieces[1]-.5*pieces[0])])
    result={}
    for branch in BRANCHES:
        count=np.zeros(len(sat),int);nodes=np.zeros((len(sat),12));prob=nodes.copy()
        for idx,velocity,weight in components(cat,sat,cal,branch):
            pos=lookup[idx];nodes[pos,count[pos]]=distance(cat['red'][idx],velocity)
            prob[pos,count[pos]]=weight;count[pos]+=1
        nodes-=np.sum(nodes*prob,axis=1)[:,None]
        mom=[np.sum(prob*nodes**idx,axis=1) for idx in range(17)]
        diff={deg:cat['weight'][sat]**2*sum((-1)**idx*comb(deg,idx)*mom[idx]*mom[deg-idx] for idx in range(deg+1)) for deg in (12,14,16)}
        add=sum((-1)**(deg//2+1)*np.einsum('i,eib->eb',diff[deg],basis[deg])/(norm*factorial(deg)) for deg in basis)
        bound=np.array([1,5])[:,None]*meanband(K**16,True)*sum(diff[16])/(norm*factorial(16))
        assert np.max(bound)<2e-5
        assert np.all(abs(add)<=np.array(prior[branch]['maximum_remainder'])+bound+1e-12)
        error=np.array(prior[branch]['errors'])-add
        result[branch]=dict(errors=error.tolist(),mean_abs=float(np.mean(abs(error[:,:2]))),maximum_remainder=bound.tolist())
    return result


if __name__=='__main__':
    guard();prior=read(ROOT/'whole-catalogue.json');cal=read(ROOT/'freeze.json')['caps']
    save('whole-refined.json',{cap+str(cone):run(cap,cone,prior[cap+str(cone)],cal[cap]) for cap in ('S','N') for cone in (0,1)})
