import csv
import sys
from pathlib import Path
from unittest.mock import patch

from stage import BANDS, PRIOR, ROOT, SOURCE, digest, guard, np, read, save
import inputs


LABELS = ('S0', 'N0', 'S1', 'N1')
BRANCHES = ('host', 'independent', 'pooled', 'slip_mean', 'scatter_only', 'slip_scatter')


class CentralsOnly:
    def __init__(self, data, central):
        self.data, self.central = data, central

    def __getitem__(self, mask):
        if not isinstance(mask, np.ndarray) or mask.dtype != bool or not np.array_equal(mask, self.central):
            raise ValueError('satellite velocity is protected')
        return self.data[mask]


class ProtectedColumn:
    def __init__(self, data, central, visited, name):
        self.args = data, central, visited, name

    def astype(self, dtype):
        data, central, visited, name = self.args
        visited.append(name)
        return CentralsOnly(data.astype(dtype), central)


class ProtectedBank:
    def __init__(self, original, path, visited):
        self.file = original(path)
        self.central = self.file['pid'][:] == -1
        self.visited = visited

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.file.close()

    def __getitem__(self, key):
        data = self.file[key]
        if key in ('vx','vy','vz','vlos'):
            return ProtectedColumn(data, self.central, self.visited, key)
        if key not in ('id','pid','ra','dec','x','y','z','z_obs','z_cos','w_cp','w_fkp','w_npcf'):
            raise ValueError(key)
        return data


def masked_replay():
    guard()
    original = inputs.h5py.File
    results = {}
    for label in LABELS:
        visited = []
        with patch.object(inputs.h5py, 'File', lambda path: ProtectedBank(original, path, visited)):
            model = inputs.geometry(label[0], int(label[1]), (.5,.6))
            inputs.environment(model)
        assert sorted(visited) == sorted(['vx','vy','vz','vlos'])
        with np.load(ROOT/(label+'-fields.npz')) as saved:
            for key in ('index','kind','host','slip','scatter','amp'):
                assert np.array_equal(saved[key], model[key if key != 'amp' else 'amplification'])
        results[label] = dict(selected=len(model['index']), prohibited_rows=int(sum(model['kind']!=0)), central_only_columns=visited)
    save('protected-replay.json', results)


def write_csv(name, header, rows):
    with (ROOT/name).open('x', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def summary():
    guard()
    frozen=ROOT/'all-forecasts.json'
    predictions=read(frozen)
    assert set(predictions) == {label+'-prediction.json' for label in LABELS}
    seed=read(ROOT/'freeze.json')
    assert digest(PRIOR/'boost-safe-seed.json') == seed['seed']
    assert all(digest(ROOT/name)==sig for name,sig in seed['locks'].items())
    whole=read(ROOT/'whole-refined.json')
    replay=read(ROOT/'protected-replay.json')
    remainder=0.
    transfer=[]
    for label in LABELS:
        path=ROOT/(label+'-prediction.json')
        score_path=ROOT/(label+'-score.json')
        assert path.stat().st_mtime_ns <= frozen.stat().st_mtime_ns <= score_path.stat().st_mtime_ns
        pred,score=read(path),read(score_path)
        assert digest(path)==predictions[path.name] and score['freeze']==digest(frozen)
        assert digest(ROOT/(label+'-fields.npz'))==pred['packet'] and digest(ROOT/('random-'+label[0]+'.npz'))==pred['window']
        assert pred['freeze']==digest(ROOT/'freeze.json') and replay[label]['selected']==pred['selected']
        assert replay[label]['prohibited_rows']==sum(pred['types'][1:]) and max(pred['direct_check'],score['direct'])<2e-5
        assert set(score['errors'])==set(whole[label])==set(BRANCHES)
        for branch in BRANCHES:
            error=np.array(score['errors'][branch]);auto=np.array(whole[label][branch]['errors'])
            assert error.shape==auto.shape==(2,4) and np.isfinite([error,auto]).all()
            np.testing.assert_allclose(np.array(pred['spectra'][branch])+error,score['measured'],rtol=0,atol=1e-9)
            assert abs(np.mean(abs(error[:,:2]))-score['mean_abs'][branch])<1e-14
            for row,ell in enumerate((0,2)):
                for col,band in enumerate(BANDS):
                    bound=whole[label][branch]['maximum_remainder'][row][col]
                    remainder=max(remainder,bound)
                    transfer.append((label,branch,ell,band,'primary' if col<2 else 'stress',pred['spectra'][branch][row][col],score['measured'][row][col],error[row,col],auto[row,col],bound))
    assert remainder<2e-5 and len(transfer)==192
    spectrum=read(ROOT/'weyl-projection.json')
    assert all(digest(Path(name))==sig for name,sig in spectrum['sources'].items())
    single=[]
    for item in spectrum['rows']:
        main=item['variants']['main']
        heavy,cold,lcdm=(main[key] for key in ('heavy','cold','lcdm'))
        hc,cc,lc=(obj['common_linear'][0] for obj in (heavy,cold,lcdm))
        single.append((item['z'],item['L'],heavy['all']/cold['all']-1,heavy['all']/lcdm['all']-1,cc/cold['all'],hc/cc-1 if cc>0 else '',hc/lc-1 if lc>0 else ''))
    assert len(single)==21
    dense=read(ROOT/'dense-lensing.json'); exact=read(ROOT/'exact-lensing.json')
    null=read(ROOT/'nulled-lensing.json')
    assert exact['null_source']==digest(ROOT/'nulled-lensing.json')
    assert len(dense['limber_dense_partial'])==159
    note=[]
    for label,example in dense['examples'].items():
        assert dense['inputs'][label]['packet']==digest(ROOT/('dense-'+label+'.npz'))
        for degree,entry in example.items():
            old=exact['cases'][label]
            a=np.array(old['6'][degree]['powers']);b=np.array(old['9'][degree]['powers'])
            assert np.max(abs(a/b-1))<2e-5
            updated=np.array(entry['dense_exact']['powers'])
            assert np.isfinite(updated).all() and np.all(updated>0) and np.all(np.diff(updated)>=0)
            if label!='lcdm':assert abs(entry['dense_exact']['white_captured']-1)<2e-5
            note.append((label,degree,*updated,entry['dense_limber'],entry['nested_limber']/entry['dense_limber']-1,entry['old_exact']/updated[-1]-1))
    assert len(note)==9 and abs(sum(null['weights']))<1e-13
    write_csv('transfer-scores.csv',('catalogue','forecast','ell','k_h_per_Mpc','use','predicted_shift','truth_shift','split_truth_minus_forecast','whole_truth_minus_forecast','whole_remainder_bound'),transfer)
    write_csv('source-plane-lensing.csv',('z_source','ell','heavy_over_cold_minus_one','heavy_over_lcdm_minus_one','cold_fraction_common_delta2_lt_0p2','restricted_heavy_over_cold_minus_one','restricted_heavy_over_lcdm_minus_one'),single)
    write_csv('exact-null-lensing.csv',('model','ell','C_k_le_0p10','C_k_le_0p16','C_k_le_0p20','C_k_le_0p25','C_limber_k_le_0p25','nested_over_dense_limber_minus_one','sparse_over_dense_bessel_minus_one'),note)
    save('verification.json', dict(masked_catalogues=len(replay),ordered_forecasts=len(predictions),transfer_cells=len(transfer),
        maximum_whole_remainder=remainder,native_source_hashes=len(spectrum['sources']),single_plane_rows=len(single),exact_null_rows=len(note)))


def seal():
    guard()
    assert (ROOT/'verification.json').exists() and (ROOT/'RESULTS.md').exists()
    assert all(path.is_file() and '.partial' not in path.name for path in ROOT.iterdir())
    manifest={path.name:digest(path) for path in sorted(ROOT.iterdir()) if path.name!='closeout.json'}
    save('closeout.json',dict(files=manifest))
    assert all(digest(ROOT/name)==sig for name,sig in read(ROOT/'closeout.json')['files'].items())
    print(len(manifest),digest(ROOT/'closeout.json'))


if __name__=='__main__':
    {'masked':masked_replay,'summary':summary,'seal':seal}[sys.argv[1]]()
