from stage import ROOT,np,read,save,guard,meanband
from inputs import geometry
from predict import distance,components,BRANCHES
from run import estimator
from fourier import NHAT,K
from math import factorial,comb
from functools import lru_cache


@lru_cache(None)
def angular_terms(rank,degree):
    terms=[]
    for aa in range(0,rank+1,2):
        for bb in range(0,rank+1-aa,2):
            cc=rank-aa-bb
            factor=factorial(rank)/(factorial(aa)*factorial(bb)*factorial(cc))
            dirs=NHAT[:,0]**aa*NHAT[:,1]**bb*NHAT[:,2]**cc
            terms.append((aa,bb,cc,factor*meanband(K**degree*dirs,True)))
    return terms


def angular(unit):
    result={}
    for degree in (2,4,6,8,10):
        pieces=[]
        for rank in (degree,degree+2):
            values=np.zeros((len(unit),4))
            for aa,bb,cc,weights in angular_terms(rank,degree):
                monomial=unit[:,0]**aa*unit[:,1]**bb*unit[:,2]**cc
                values+=monomial[:,None]*weights
            pieces.append(values)
        result[degree]=np.stack([pieces[0],5*(1.5*pieces[1]-.5*pieces[0])])
    return result


def variance_terms(cat,sats,cal,branch):
    local=np.full(len(cat['weight']),-1,int);local[sats]=np.arange(len(sats))
    nodes=np.zeros((len(sats),12));prob=np.zeros_like(nodes)
    count=np.zeros(len(sats),int)
    for rows,velocity,weight in components(cat,sats,cal,branch):
        pos=local[rows]
        nodes[pos,count[pos]]=distance(cat['red'][rows],velocity)
        prob[pos,count[pos]]=weight;count[pos]+=1
    assert (count==(1 if branch=='host' else 12)).all() and np.max(abs(prob.sum(axis=1)-1))<1e-12
    nodes-=np.sum(nodes*prob,axis=1)[:,None]
    moments=[np.sum(prob*nodes**deg,axis=1) for deg in range(13)]
    ans={}
    for deg in (2,4,6,8,10,12):
        moment=sum((-1)**idx*comb(deg,idx)*moments[idx]*moments[deg-idx] for idx in range(deg+1))
        assert np.min(moment)>=-1e-12
        ans[deg]=cat['weight'][sats]**2*moment
    return ans


def case(cap,cone):
    label=cap+str(cone);pred=read(ROOT/(label+'-prediction.json'));score=read(ROOT/(label+'-score.json'))
    cal=read(ROOT/'freeze.json')['caps'][cap]
    cat=geometry(cap,cone,(.5,.6))
    with np.load(ROOT/(label+'-fields.npz')) as fields,np.load(ROOT/f'random-{cap}.npz') as win:
        cat.update({key:fields[key] for key in ('host','slip','scatter')})
        sats=np.flatnonzero(cat['kind']!=0);harm=angular(cat['unit'][sats]);norm=pred['norm']
        def power(mode):
            halves=np.stack([fields[mode+str(idx)] for idx in (0,1)])
            return estimator(halves,win['amplitude'],np.array(pred['alphas']),norm)[1]
        real=power('real');out={}
        for name in BRANCHES:
            moments=variance_terms(cat,sats,cal,name)
            repair=sum((-1)**(deg//2+1)*np.einsum('i,eib->eb',moments[deg],harm[deg])/(norm*factorial(deg)) for deg in harm)
            bound=np.array([1,5])[:,None]*meanband(K**12,True)*np.sum(moments[12])/(norm*factorial(12))
            simulated=meanband(power(name)-real,True)+repair
            errors=np.array(score['auto'])-simulated
            out[name]=dict(errors=errors.tolist(),mean_abs=float(np.mean(abs(errors[:,:2]))),correction=repair.tolist(),
                maximum_remainder=bound.tolist())
    return out


if __name__=='__main__':
    guard()
    save('whole-catalogue.json',{cap+str(cone):case(cap,cone) for cap in ('S','N') for cone in (0,1)})
