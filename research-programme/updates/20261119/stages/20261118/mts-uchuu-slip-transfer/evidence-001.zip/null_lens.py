from lensing import ROOT,SPEC,GROW,CASES,AMPS,INDEX,guard,np,read,save,digest,build,leggauss


PLANES=(.51,1.,2.)


def projection(item,coefs,ell,order=10,style='cubic',kmax=5.):
    ds=np.array([item['dist'][str(val)] for val in PLANES])
    nu=ell+.5
    lo=nu/kmax
    breaks=np.unique(np.clip(np.r_[lo,ds,item['chi'],nu/item['modes']],lo,ds[-1]))
    center=(breaks[1:]+breaks[:-1])/2;half=np.diff(breaks)/2
    roots,weights=leggauss(order)
    chi=(center[:,None]+half[:,None]*roots).ravel();wt=(half[:,None]*weights).ravel()
    kval=nu/chi
    cols=np.maximum(0.,1-chi[:,None]/ds)
    kernel=cols@coefs
    value=item['w'](kval,chi,style)
    power=(ell*(ell+1)/nu**2)**2*2*np.pi**2*AMPS*(kval/.05)**INDEX/kval**3*value**2
    total=wt*power
    matrix=cols.T@(total[:,None]*cols)
    null=np.dot(total,kernel**2)
    assert np.linalg.eigvalsh(matrix).min()>0 and abs(coefs@matrix@coefs/null-1)<2e-9
    fg=chi<ds[0]
    if fg.any():assert np.max(abs(kernel[fg]+chi[fg]*np.sum(coefs/ds)))<2e-13
    return dict(null=float(null),fraction_foreground=float(np.dot(total[fg],kernel[fg]**2)/null),
                matrix=matrix.tolist(),matrix_check=float(abs(coefs@matrix@coefs/null-1)))


def main():
    guard()
    native=read(GROW/'closeout.json')['files'];old=read(SPEC/'results/stage-integrity.json')['file_hashes'];sources={}
    live={case:build(case,'live',native,old,sources) for case in CASES}
    ds=1/np.array([live['heavy']['dist'][str(value)] for value in PLANES])
    mid=-(ds[0]-ds[2])/(ds[0]-ds[1]);coefs=np.array([-1-mid,mid,1.])
    assert abs(sum(coefs))<1e-14 and abs(ds@coefs)<1e-16
    hi=int(.1/ds[0]-.5)
    dense=[];specific={}
    for ell in sorted(set(range(30,hi+1))|{200,400,800,1200}):
        records={case:projection(live[case],coefs,ell) for case in CASES}
        for case in ('heavy','cold'):assert records[case]['fraction_foreground']<1e-17
        row={case:records[case]['null'] for case in CASES}
        row.update(L=ell,lcdm_leak=records['lcdm']['fraction_foreground']);dense.append(row)
        if ell in (30,60,100,hi,200,400,800,1200):
            alternatives={}
            for style,order in [('quadrature',20),('linear',10),('pchip',10)]:
                alternatives[style]={case:projection(live[case],coefs,ell,order,'cubic' if style=='quadrature' else style)['null'] for case in CASES}
            assert max(abs(row[case]/alternatives['quadrature'][case]-1) for case in CASES)<2e-5
            specific[str(ell)]=dict(native=records,alternatives=alternatives)
    ceiling={case:float(np.sqrt(sum((row['L']+.5)*(row['heavy']/row[case]-1)**2 for row in dense if row['L']<=hi))) for case in ('cold','lcdm')}
    assert set(sources.items()).issubset(read(ROOT/'weyl-projection.json')['sources'].items())
    save('nulled-lensing.json',dict(source=digest(ROOT/'weyl-projection.json'),protocol=digest(ROOT/'NULL-LENS.md'),
         weights=coefs.tolist(),equal_independent_noise=float(coefs@coefs),integer_L=[30,hi],ideal_auto_distance=ceiling,
         max_foreground_k_for_matched_geometry=(hi+.5)*ds[0],dense=dense,examples=specific))


if __name__=='__main__':main()
