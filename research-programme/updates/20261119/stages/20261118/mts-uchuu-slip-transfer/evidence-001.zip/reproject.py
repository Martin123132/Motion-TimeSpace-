from lensing import ROOT,GROW,SPEC,CASES,guard,read,save,digest,np,Surface,build
from exact_lens import run,CEIL,MULT
from null_lens import projection,PLANES


def main():
    guard()
    native=read(GROW/'closeout.json')['files'];old=read(SPEC/'results/stage-integrity.json')['file_hashes'];sources={}
    refs=read(ROOT/'exact-lensing.json');prior=read(ROOT/'nulled-lensing.json')
    weights=np.array(prior['weights'])
    diagnostics={};dense={};nested={}
    for case in CASES:
        ref=build(case,'live',native,old,sources)
        with np.load(ROOT/('dense-'+case+'.npz')) as data:
            modes,scales,eta,weyl,anc=(data[key] for key in ('modes','scales','times','weyl','anchors'))
        keep=np.isin(scales,anc)
        assert np.array_equal(anc,scales[keep]) and np.all(weyl<0)
        chi=(eta[-1]-eta)[::-1];z=1/scales[::-1]-1;ww=(-weyl)[:,::-1]
        distance={str(value):float(chi[np.argmin(abs(z-value))]) for value in PLANES}
        assert all(abs(distance[key]-ref['dist'][key])<1e-4 for key in distance)
        loc=np.flatnonzero(keep[::-1])
        mesh,rad=np.broadcast_arrays(modes[:,None],chi[loc])
        reference=ref['w'](mesh.ravel(),np.clip(rad.ravel(),ref['chi'][0],ref['chi'][-1]),'cubic').reshape(mesh.shape)
        check=np.max(abs(ww[:,loc]/reference-1),axis=1)
        new=np.flatnonzero(~keep[::-1])
        mid,rr=np.broadcast_arrays(modes[:,None],chi[new])
        midref=ref['w'](mid.ravel(),rr.ravel(),'cubic').reshape(mid.shape)
        interval=(modes>=.005)&(modes<=.12)
        alt=np.sort(np.r_[loc,new[::2]])
        dense[case]=dict(w=Surface(modes,chi,ww),modes=modes,chi=chi,dist=distance)
        nested[case]=dict(w=Surface(modes,chi[alt],ww[:,alt]),modes=modes,chi=chi[alt],dist=distance)
        diagnostics[case]=dict(epochs=len(chi),knots=len(modes),new_epochs=len(new),anchor_max=float(check.max()),
           anchor_design_band_max=float(check[interval].max()),old_interpolant_vs_new_max=float(np.max(abs(midref[interval]/ww[interval][:,new]-1))),
           packet=digest(ROOT/('dense-'+case+'.npz')))
    answers={}
    for case in CASES:
        exact=run(dense[case],weights,8,case!='lcdm')
        examples={}
        for ell in MULT:
            name=str(ell)
            main=projection(dense[case],weights,ell,kmax=.25)['null']
            sub=projection(nested[case],weights,ell,kmax=.25)['null']
            examples[name]=dict(dense_limber=main,nested_limber=sub,dense_exact=exact[name],
                old_limber=refs['cases'][case]['limber'][name][-1],old_exact=refs['cases'][case]['9'][name]['powers'][-1])
        answers[case]=examples
    dense_spectra=[]
    for ell in range(30,prior['integer_L'][1]+1):
        row={case:projection(dense[case],weights,ell,kmax=.25)['null'] for case in CASES}
        row['L']=ell;dense_spectra.append(row)
    ideal={}
    for case in ('cold','lcdm'):
        yy=np.array([row['heavy']/row[case]-1 for row in dense_spectra])
        degree=np.array([row['L']+.5 for row in dense_spectra])
        centered=yy-np.average(yy,weights=degree)
        ideal[case]=dict(fixed=float(np.sqrt(degree@yy**2)),amplitude_removed=float(np.sqrt(degree@centered**2)))
    save('dense-lensing.json',dict(inputs=diagnostics,examples=answers,limber_dense_partial=dense_spectra,ideal=ideal,
         qualification='k<=0.25/Mpc only, native linear metric, diagnostic ideal shear; exact means spherical-Bessel kernel not nonlinear or all-k.'))


if __name__=='__main__':main()
