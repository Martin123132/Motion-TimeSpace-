from local import *
from scipy.integrate import solve_ivp
from gas import KB,MP

def main():
    guard();out=[]
    for case,tag,arm in (("heavy","1200","off"),("cold","225","cold")):
        source=load(f"source-outer-{case}-{tag}.npz");gas=load(f"gas-outer-{case}-{tag}.npz")
        k=source["k"];epochs=source["epochs"];initial=source["init"];track=source["N"]
        if case=="cold":
            initial=initial.copy();initial[:,2]=initial[:,0];initial[:,5]=initial[:,3]
        env=CubicSpline(track,np.column_stack([source["a"],source["h"],source["g"].T,source["thermal"],source["external"].transpose(1,0,2).reshape(len(track),-1)]),axis=0)
        weights=source["g"][2]/(source["g"][0]+source["g"][2]);w=weights[0]
        assert max(abs(weights-w))<1e-12
        rel=initial[:,5]-initial[:,3];seed=np.column_stack([(1-w)*initial[:,0]+w*initial[:,2],initial[:,1],(1-w)*initial[:,3]+w*initial[:,5],initial[:,4]])
        def physics(loga,vec,mode):
            a,h,gc,gb,gh,cs,tbar,opacity,light,*tail=env(loga)
            ext,slip,entropy,phot=np.array(tail).reshape(-1,4).T
            dr,db,pr,pb=vec.T;gd=gc+gh
            phi=(-gd*dr-gb*db+3*h/a*(gd*pr+gb*pb)-ext)/(k*k+3*(gd+gb))
            psi=phi-slip/k**2;eta=phi-h/a*(pr-w*rel)
            if mode=="read":return np.column_stack([-k**2*psi,db+3*phi,k**2*pb/(a*h)])
            heat=np.clip(np.log(10*a)/np.log(10/8),0,1);hot=1.5*KB*1e4/(.61*MP*(SPEED*1000)**2)*heat**2*(3-2*heat)
            pressure=(cs+hot)*db+3*cs*eta+entropy+light*opacity*(phot/k+4*pb/(3*a))
            return np.column_stack([k**2*pr/(a*h),k**2*pb/(a*h),-a*psi/h,-a*(psi+pressure)/h])
        def rhs(loga,vec):return physics(loga,vec.reshape(-1,4),"derive").ravel()
        sol=solve_ivp(rhs,(track[0],track[-1]),seed.ravel(),method="DOP853",rtol=2e-10,atol=1e-13,
            max_step=(track[-1]-track[0])/400,t_eval=epochs)
        assert sol.success
        vals=np.array([physics(t,v.reshape(-1,4),"read") for t,v in zip(epochs,sol.y.T,strict=True)])
        ref=gas[arm+"-1-2048-1"]
        defect=abs(vals-ref)/np.maximum(np.max(abs(ref),axis=0),1e-30)
        direct=abs(vals-ref)/np.maximum(abs(ref),1e-30)
        for i,node in enumerate(k):
            out.append(dict(case=case,k=node,heavy_fraction_of_dust=w,weight_drift=float(max(abs(weights-w))),relative_canonical_momentum=rel[i],
                evaluations=int(sol.nfev),max_peak_normalized=float(np.max(defect[:,i])),max_relative=float(np.max(direct[:,i]))))
        assert np.max(defect)<2e-5 and np.max(direct)<2e-5
        print("reduced-dust",case,np.max(defect),np.max(direct),flush=True)
    csvout("two-dust-gravity.csv",out)
if __name__=="__main__":main()

