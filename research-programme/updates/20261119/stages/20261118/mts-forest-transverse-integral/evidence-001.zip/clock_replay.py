from projection import *

def main():
    guard();records=[]
    seeds=modes("clock32")
    for name in ("outer","clock16","clock32"):
        corrected=rows("clock-defect-"+name+".csv")
        for tag in ("1200","1500"):
            s=load(f"seed-{name}-{tag}.npz");idx=np.searchsorted(s["k"],seeds)
            assert np.array_equal(s["k"][idx],seeds)
            for i,j in enumerate(idx):
                entry=next(r for r in corrected if float(r["k"])==seeds[i] and r["stride"]=="1" and r["tag"]==tag)
                records.append(dict(panel=name,k=seeds[i],tag=tag,lookup=float(entry["lookup_vs_carrier"]),raw_identity=float(entry["unrepaired"]),
                    compensated_identity=float(entry["corrected"]),simple_pressure=s["pe"][j],window_pass=bool(s["eligible"][j])))
    csvout("clock-refinement.csv",records)
    for name in ("outer","clock16","clock32"):
        selected=[r for r in records if r["panel"]==name]
        print(name, max(r["lookup"] for r in selected),max(r["raw_identity"] for r in selected),max(r["simple_pressure"] for r in selected))
    if (ROOT/"gas-clock32-heavy-1500.npz").is_file():
        drift=[]
        for name in ("outer","clock32"):
            first=load(f"gas-{name}-heavy-1200.npz");second=load(f"gas-{name}-heavy-1500.npz")
            incoming=load(f"averaged-impulse-{name}.npz");last=load(f"seed-{name}-1500.npz")
            qend=CubicSpline(np.log(incoming["scale"]),incoming["q"].T)(np.log(float(last["scale"])))
            dend=CubicSpline(np.log(incoming["scale"]),incoming["d"].T)(np.log(float(last["scale"])))
            for arm in ("wave","off"):
                integ1=sample(name,"heavy","1200",arm);integ2=sample(name,"heavy","1500",arm)
                vals=first[arm+"-1-2048-1"];vals2=second[arm+"-1-2048-1"]
                for node in seeds:
                    j=int(np.searchsorted(first["k"],node))
                    rel=np.max(abs(vals[:,j]/vals2[:,j]-1),axis=0);kernel=integ1[j,3]/integ2[j,3]-1
                    drift.append(dict(panel=name,arm=arm,k=node,force=rel[0],gas=rel[1],velocity=rel[2],kernel=kernel,
                        d_endpoint=(last["D"][j]-dend[j])/last["normalization"][j],q_endpoint=(last["Q"][j]-qend[j])/last["qnorm"][j],
                        passes=bool(max(max(rel),abs(kernel))<2e-5)))
        csvout("clock-interface-replay.csv",drift)
        for name in ("outer","clock32"):
            inside=[r for r in drift if r["panel"]==name]
            print(name,"interface",sum(r["passes"] for r in inside),"/",len(inside),"max deltaQ",max(abs(r["q_endpoint"]) for r in inside))
if __name__=="__main__":main()

