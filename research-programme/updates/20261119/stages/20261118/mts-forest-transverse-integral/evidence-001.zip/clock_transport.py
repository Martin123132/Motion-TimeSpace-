from local import *
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline

def main():
    guard();src=native("earlyenv")
    old=load("exact-clock32-1200-1500.npz");k=old["k"];times=old["tau"]
    bg=load("background-1500.npz");mass=float(bg["heavy_mass_mpc"]);rho=float(bg["rho_star"])
    params=src.params_for(table("1500"),background_boost=32.)
    params.DarkEnergy.heavy_exact_limit=min(float(bg["interface_a"])*1.02,np.exp(bg["heavy_efold"][-1])*(1-1e-8))
    model=src.camb.get_background(params);model.Params.Accuracy.IntTolBoost=6.4
    species=("cdm","baryon","photon","neutrino","nu")
    names=["a","H","etak",*["delta_"+sp for sp in species],"mts_drho_s","mts_dp_s","delta_tot_de","v_newtonian_baryon","mts_dphi_h","mts_dphidot_h","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count"]
    raw=model.get_time_evolution(k,times,vars=names,lAccuracyBoost=4)
    get=lambda key:raw[:,:,names.index(key)]
    assert np.all(get("mts_match_count")==0)
    for key in old["names"]:
        assert np.allclose(get(key),old["raw"][:,:,old["names"].tolist().index(key)],rtol=2e-10,atol=2e-20),key
    a=get("a")[0].copy();dens=model.get_background_densities(a,vars=list(species));N=np.log(a)
    d={sp:dens[sp]/a**2*get("delta_"+sp) for sp in species}
    total=sum(d.values())+get("mts_drho_s")
    ext=.5*(total+d["photon"]+d["neutrino"]+3*(get("mts_dp_s")+get("delta_tot_de")+get("v_newtonian_baryon")))
    hub=get("H")[0];J=-(k[:,None]*get("etak")+.5*(total+get("mts_drho_h")))/hub
    fields=[CubicSpline(bg["heavy_efold"],bg[key]) for key in ("phi_h","phidot_h")]
    out=[]
    for tag,indices in zip(("1200","1500"),np.split(np.arange(len(a)),2),strict=True):
        seed=load(f"seed-clock32-{tag}.npz")
        nodes=indices[12:-12];scale=seed["scale"];omega=scale*mass;norm=scale*seed["qnorm"]
        clock=make_interp_spline(times[indices],N[indices],k=5)(times[indices],1)
        env=CubicSpline(N[indices],np.column_stack([clock,hub[indices],ext[:,indices].T]))
        grid=N[nodes];target=np.stack([get("mts_dphi_h")[:,nodes],get("mts_dphidot_h")[:,nodes]/omega,J[:,nodes]],axis=-1)
        units=np.column_stack([np.max(abs(target),axis=1),norm])
        initial=np.column_stack([target[:,0],np.zeros(len(k))])/units
        qstart=get("mts_q_h")[:,nodes[0]]*a[nodes[0]]**2/rho
        for label in ("lookup","friedmann"):
            for spacing in (2,4):
                def rhs(n,y):
                    state=y.reshape(len(k),4)*units
                    field,vel,jpert,integral=state.T
                    cf,vf=[fn(n) for fn in fields];scale0=math.exp(n);pot=(scale0*mass)**2
                    environment=env(n);lookup,hc=environment[:2];other=environment[2:]
                    dr=vf*vel*omega+pot*cf*field;pr=vf*vel*omega-pot*cf*field
                    rate=lookup if label=="lookup" else hc
                    deriv=np.column_stack([omega*vel,(-2*hc*omega*vel-(k*k+pot)*field+vf*jpert)/omega,
                        -hc*jpert+other+.5*(dr+3*pr),k*scale0**2*pr/rho])
                    return (deriv/(rate*units)).ravel()
                sol=solve_ivp(rhs,(grid[0],grid[-1]),initial.ravel(),t_eval=grid,method="DOP853",rtol=3e-11,atol=1e-12,max_step=spacing*np.min(np.diff(grid)))
                assert sol.success
                state=sol.y.T.reshape(len(grid),len(k),4)*units
                q=(k*a[nodes,None]**2/rho)*fields[1](grid)[:,None]*state[:,:,0]
                balance=(q-qstart-state[:,:,3])/norm
                qreference=(get("mts_q_h")[:,nodes]*a[nodes]**2/rho).T
                errq=(q-qreference)/norm;errf=(state[:,:,:2]-target[:,:,:2].transpose(1,0,2))/units[:,:2]
                for loc,node in enumerate(k):
                    out.append(dict(tag=tag,k=node,transport=label,max_step_grid_spacings=spacing,
                        max_scaled_momentum_imbalance=np.max(abs(balance[:,loc])),max_change_from_native_current=np.max(abs(errq[:,loc])),
                        max_change_from_native_fields=np.max(abs(errf[:,loc]))))
    csvout("common-clock-transport.csv",out)
    for label in ("lookup","friedmann"):
        picked=[r for r in out if r["transport"]==label]
        print(label,{key:max(r[key] for r in picked) for key in ("max_scaled_momentum_imbalance","max_change_from_native_current","max_change_from_native_fields")},flush=True)
if __name__=="__main__":main()

