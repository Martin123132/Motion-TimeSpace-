from projection import *

def main():
    guard();report=[]
    for arm in ("wave","off","exact"):
        for early in ("225","250"):
            first=sample("mid","heavy",early,arm)
            for late in ("1200","1500"):
                other=sample("overlap","heavy",late,arm)
                idx=np.searchsorted(first[:,0],other[:,0]);assert np.all(first[idx,0]==other[:,0])
                transfer1=load(f"gas-mid-heavy-{early}.npz")[arm+"-1-2048-1"][:,idx]
                transfer2=load(f"gas-overlap-heavy-{late}.npz")[arm+"-1-2048-1"]
                rel=np.max(abs(transfer2/transfer1-1),axis=0)
                for j,node in enumerate(other[:,0]):
                    kernel=other[j,3]/first[idx[j],3]-1
                    report.append(dict(arm=arm,k=node,early=early,late=late,relative_power=kernel,force=rel[j,0],gas=rel[j,1],velocity=rel[j,2],
                        passes=bool(max(abs(kernel),np.max(rel[j]))<2e-5)))
    csvout("cross-range-join.csv",report)
    for arm in ("wave","off","exact"):
        picked=[r for r in report if r["arm"]==arm]
        print(arm,"across distinct surface ranges",sum(r["passes"] for r in picked),"/",len(picked),"max power",max(abs(r["relative_power"]) for r in picked),flush=True)
if __name__=="__main__":main()

