from local import *
from gas import run

def main():
    guard();output=[]
    settings=read(PREV/"primordial-settings.json")
    for case,tag,arms in (("heavy","1200",["wave","off"]),("cold","225",["cold"])):
        data=load(f"source-outer-{case}-{tag}.npz");gas=load(f"gas-outer-{case}-{tag}.npz")
        k=data["k"];vh=data["h"][-1]*SPEED
        kx=max(float(r["k_parent"]) for r in rows(POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv") if float(r["z"])==4.2)
        thermal=.25*(kx/vh)**2*2*1.380649e-23*1e4/(1.67262192369e-27*1e6)
        for arm in arms:
            split=run(data,arm,1,2048,1,split=True);original=gas[arm+"-1-2048-1"]
            norm=np.maximum(np.max(abs(original),axis=0),1e-25)
            closure=np.max(abs(split[:,:,:,:7].sum(axis=3)-original)/norm)
            replay=np.max(abs(split[:,:,:,7]-original)/norm)
            assert max(closure,replay)<1e-9
            line=(2-.5*(.7+thermal))*split[-1,:,1,:]+(kx/k[:,None])**2*split[-1,:,2,:]
            for i,mode in enumerate(k):
                response=line[i]
                output.append(dict(arm=arm,k=mode,total=response[7],cold_density=response[0],gas_density=response[1],
                    wave_density=response[2],cold_momentum=response[3],gas_momentum=response[4],wave_momentum=response[5],
                    radiation_metric_thermal_drive=response[6],initial_heavy_sum=response[2]+response[5],
                    all_other_response=response[0]+response[1]+response[3]+response[4]+response[6],sum_error=closure,replay_error=replay))
    csvout("response-decomposition.csv",output)
    print("Duhamel split",len(output),"worst closure",max(r["sum_error"] for r in output),flush=True)
if __name__=="__main__":main()

