from local import *
def run(panel,tags):
    guard();source=native();k=modes(panel)
    with np.load(table("225")) as t:
        rho=float(t["matching_density"]);mass=float(t["heavy_mass_mpc"])
    centers=np.array([float(np.load(table(tag))["matching_scale" if tag in ("200","225","250") else "interface_a"]) for tag in tags])
    bgfile=table("1500") if max(centers)>.00093 else table("900") if max(centers)>.0004 else BG
    params=source.params_for(bgfile,background_boost={"clock16":16.,"clock32":32.}.get(panel,8.))
    with np.load(bgfile) as tab:
        params.DarkEnergy.heavy_exact_limit=min(max(.00028,max(centers)*1.02),np.exp(tab["heavy_efold"][-1])*(1-1e-8))
    engine=source.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6.4
    with np.load(bgfile) as t:
        phase=CubicSpline(t["heavy_efold"],t["phase_h"]);inverse=PchipInterpolator(t["phase_h"],t["heavy_efold"])
        scales=np.exp(np.unique(np.concatenate([inverse(phase(np.log(c))+np.linspace(-6.15*np.pi,6.15*np.pi,643)) for c in centers])))
        assert scales[-1]<np.exp(t["heavy_efold"][-1])
        times=engine.conformal_time(1/scales-1,tol=1e-10)
        names=["a","H","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count"]
        raw=engine.get_time_evolution(k,times,vars=names,lAccuracyBoost=4)
        assert np.isfinite(raw).all() and np.all(raw[:,:,-1]==0)
        actual=raw[0,:,0];vals=raw[:,:,1:5].copy();vals[:,:,1:]*=actual[None,:,None]/rho
        summary=[]
        for center,tag in zip(centers,tags):
            base=projects(actual,vals,t,center,6,8);h,d,q,p=base.T
            normpressure,dnorm,qnorm=pressure(k,center,mass,h,d,q)
            errs=[abs(p-normpressure)/dnorm];delta=[];current=[]
            for width,degree,thin in ((6,8,2),(4,8,1),(6,10,1)):
                alt=projects(actual,vals,t,center,width,degree,thin)
                hup,dup,qup,pup=alt.T
                predicted,nn,_=pressure(k,center,mass,hup,dup,qup)
                errs.append(abs(pup-predicted)/nn);delta.append(abs(dup-d)/dnorm);current.append(abs(qup-q)/qnorm)
            emax=np.max(errs,axis=0);dmax=np.max(delta,axis=0);qmax=np.max(current,axis=0)
            ok=(emax<2e-6)&(np.maximum(dmax,qmax)<2e-5)
            save(f"seed-{panel}-{tag}.npz",k=k,scale=center,D=d,Q=q,P=p,H=h,eligible=ok,pe=emax,de=dmax,qe=qmax,normalization=dnorm,qnorm=qnorm)
            print(panel,tag,int(ok.sum()),"/",len(k),"max pressure",emax.max(),flush=True)
            for index,mode in enumerate(k):summary.append(dict(k=mode,center=tag,pe=emax[index],de=dmax[index],qe=qmax[index],pass_local=bool(ok[index])))
    suffix="-".join(tags);save("exact-"+panel+"-"+suffix+".npz",raw=raw,names=names,tau=times,k=k)
    csvout("gate-"+panel+"-"+suffix+".csv",summary)
if __name__=="__main__":run(sys.argv[1],sys.argv[2:])

