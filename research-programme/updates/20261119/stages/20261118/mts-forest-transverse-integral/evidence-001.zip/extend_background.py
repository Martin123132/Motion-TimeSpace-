from local import *
from scipy.integrate import cumulative_simpson
from scipy.optimize import brentq
def rotate(initial,end,species,mass,slow,r0,dx):
    start,field,velocity,phase=initial
    ref=np.linspace(start-.01,math.log(end)+.02,6001)
    standard=CubicSpline(ref,np.log(species.values(ref)[0]))
    ndata=[];fdata=[];vdata=[];phdata=[]
    z0=complex(field,velocity);n0=start;x0=0.
    while n0<math.log(end):
        xx=np.arange(2049)*dx;phase_angle=xx+x0
        osc=np.exp(2j*phase_angle)
        n=np.full(len(xx),n0);z=np.full(len(xx),z0)
        for _ in range(9):
            h=np.sqrt((np.exp(standard(n))+slow)/mass**2+abs(z)**2*np.exp(-3*(n-start))/6)
            zn=z0+1.5*(cumulative_simpson((h*osc*np.conj(z)).real,dx=dx,initial=0)+1j*cumulative_simpson((h*osc*np.conj(z)).imag,dx=dx,initial=0))
            nn=n0+cumulative_simpson(h,dx=dx,initial=0)
            difference_n=max(abs(nn-n));difference_z=max(abs(zn-z))/abs(z0)
            if difference_n<2e-14 and difference_z<1e-14:break
            n,z=nn,zn
        assert difference_n<2e-11 and difference_z<2e-11 and np.all(np.diff(n)>0)
        fv=z*np.exp(-1j*phase_angle-1.5*(n-start))
        ndata.append(n[1:]);fdata.append(fv.real[1:]);vdata.append(fv.imag[1:]);phdata.append(phase+phase_angle[1:])
        x0+=xx[-1];n0=n[-1];z0=z[-1]
    n=np.concatenate(ndata);scale=np.exp(n)
    return n,np.concatenate(fdata),np.concatenate(vdata)*r0*scale,np.concatenate(phdata)
def main():
    guard();src=native();old=src.previous
    with np.load(BG) as source:base=dict(source)
    omega,slow_m=old.inherited_parameters()
    species=old.StandardSpecies(omega,float(base["fraction"]));unit=old.H0/old.C_LIGHT
    mass=float(base["heavy_mass_mpc"]);slow=slow_m**2*float(base["phi_s"][0])**2/6
    ns=base["heavy_efold"];parent=[CubicSpline(ns,base[key]) for key in ("phi_h","phidot_h","phase_h")]
    def initial(loga):
        return loga,float(parent[0](loga)),float(parent[1](loga))/(math.exp(loga)*mass),float(parent[2](loga))
    late=sys.argv[1:]==["late"]
    assert late or not sys.argv[1:]
    end=.001524 if late else .00093
    steps=(.05,.025) if late else (.1,.05)
    coarse=rotate(initial(ns[-1]),end,species,mass/unit,slow,mass,steps[0])
    fine=rotate(initial(ns[-1]),end,species,mass/unit,slow,mass,steps[1])
    interpolated=rotate(initial(math.log(.00035)),.000401,species,mass/unit,slow,mass,.05)
    pos=int(np.searchsorted(ns,np.log(.00035)));pos+=(-pos)%4
    check=rotate(initial(ns[pos]),.000401,species,mass/unit,slow,mass,.05)
    def compare(data,splines,grid):
        spl=[CubicSpline(data[0],v) for v in data[1:]]
        f,v,p=[fn(grid) for fn in splines]; ff,vv,pp=[fn(grid) for fn in spl]
        norm=np.hypot(f,v/(mass*np.exp(grid)))
        return [float(np.max(np.hypot(ff-f,(vv-v)/(mass*np.exp(grid)))/norm)),float(np.max(abs(pp-p)))]
    overlap=compare(check,parent,np.linspace(np.log(.000351),np.log(.0003999),2001))
    refine=compare(coarse,[CubicSpline(fine[0],v) for v in fine[1:]],np.linspace(np.log(.000401),np.log(end*.995),9001))
    assert max(overlap)<2e-5 and max(refine)<2e-5,(overlap,refine)
    extended=dict(heavy_efold=np.r_[ns,fine[0]],phi_h=np.r_[base["phi_h"],fine[1]],phidot_h=np.r_[base["phidot_h"],fine[2]],phase_h=np.r_[base["phase_h"],fine[3]])
    zz=extended["heavy_efold"];phi,vel,phase=[CubicSpline(zz,extended[name]) for name in ("phi_h","phidot_h","phase_h")]
    inv=PchipInterpolator(extended["phase_h"],zz)
    target=float(base["fraction"])*omega;rho=3*unit**2*target
    def residual(n):
        a=np.exp(n)
        return a*(vel(n)**2+(a*mass*phi(n))**2)/(2*rho)-1
    reports=[]
    for tag in (("1200","1500") if late else ("750","900")):
        center=float(tag)*1e-6;mid=phase(math.log(center));trial=inv(mid+np.linspace(-2*np.pi,2*np.pi,201))
        pos=np.flatnonzero(residual(trial[:-1])*residual(trial[1:])<0)
        roots=[brentq(residual,trial[i],trial[i+1],xtol=2e-14) for i in pos]
        cross=min(roots,key=lambda n:abs(n-math.log(center)))
        def density(n):
            s=np.minimum(n,cross);a=np.exp(s);vv=vel(s)
            density=(vv**2+(a*mass*phi(s))**2)/(6*unit**2*a*a)
            dust=target*np.exp(-3*np.asarray(n))
            return np.where(n<cross,density,dust),np.where(n<cross,-vv**2/(unit**2*a*a),-3*dust)
        displacement,solution,flat=old.solve_slow(species,density,slow_m)
        n=np.unique(np.r_[base["efold"],cross,fine[0][fine[0]<cross]])
        a=np.exp(n);field,velocity=solution.sol(n);rh,rh_n=density(n)
        expansion=(species.values(n)[0]+rh+slow_m**2*field**2)/(1-velocity**2)
        save(f"background-{tag}.npz",**extended,heavy_mass_mpc=mass,slow_mass_mpc=slow_m*unit,fraction=base["fraction"],efold=n,scale=a,phi_s=np.sqrt(6)*field,phidot_s=np.sqrt(6)*a*unit*np.sqrt(expansion)*velocity,
              expansion2=expansion,heavy_logrho_mpc=np.log(3*unit**2*rh),heavy_w=-1-rh_n/(3*rh),interface_a=math.exp(cross),rho_star=rho)
        reports.append(dict(tag=tag,a=math.exp(cross),density_jump=float(abs(residual(cross))),flatness=float(abs(flat-1)),initial_slow=displacement))
    write("homogeneous-late.json" if late else "homogeneous.json",dict(original=sha(BG),steps_phase=steps,tested_overlap=overlap,interpolated_restart_miss=compare(interpolated,parent,np.linspace(np.log(.000351),np.log(.0003999),2001)),coarse_fine=refine,surfaces=reports,upper_scale=float(np.exp(zz[-1]))))
    print("Background overlap",overlap,"refinement",refine,reports,flush=True)
if __name__=="__main__":main()

