from local import *
from gas import run

def main():
    guard();out=[]
    for panel in ("outer","outer-mid"):
        first=load(f"source-{panel}-heavy-1200.npz");second=load(f"source-{panel}-heavy-1500.npz")
        assert np.array_equal(first["k"],second["k"])
        crossed=dict(first,init=second["init"])
        for arm in ("wave","off"):
            left=run(first,arm,1,2048,1,split=True)
            right=run(second,arm,1,2048,1,split=True)
            cross=run(crossed,arm,1,2048,1,split=True)
            raw=left[...,7]-right[...,7]
            signal=np.maximum(1e-20,np.max(np.abs(right[...,7]),axis=0))
            init=left[...,:6]-cross[...,:6];operators=(cross[...,:6]-right[...,:6]).sum(axis=-1)
            drive=left[...,6]-right[...,6];closure=(init.sum(axis=-1)+operators+drive-raw)/signal
            assert np.max(abs(closure))<1e-9
            for j,k in enumerate(first["k"]):
                for iz,z in enumerate(Z):
                    for obs,key in enumerate(("force","gas","velocity")):
                        idx=(iz,j,obs);delta=raw[idx]
                        out.append(dict(panel=panel,arm=arm,k=k,z=z,observable=key,original=right[idx+(7,)],
                            signed_difference=delta,heavy_initial_density=init[idx+(2,)],heavy_initial_momentum=init[idx+(5,)],
                            baryon_cdm_initial=sum(init[idx][[0,1,3,4]]),changed_linear_response=operators[idx],
                            changed_external_work=drive[idx],closure=float(closure[idx])))
    csvout("matching-error-origin.csv",out)
    print("closed",len(out),"response comparisons")
if __name__=="__main__":main()

