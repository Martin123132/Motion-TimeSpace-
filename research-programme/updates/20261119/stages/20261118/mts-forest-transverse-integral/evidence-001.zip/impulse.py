from local import *
from scipy.interpolate import make_interp_spline

def early_transfer(panel):
    guard();tag="1200";seed=load(f"seed-{panel}-{tag}.npz")
    src=native();k=seed["k"];params=src.params_for(table(tag),background_boost={"clock16":16.,"clock32":32.}.get(panel,8.));a1=float(seed["scale"])
    center=float(load(f"seed-{panel}-1500.npz")["scale"])
    with np.load(table(tag)) as tab:
        rho=float(tab["rho_star"]);params.DarkEnergy.matching_density=rho
    params.DarkEnergy.heavy_exact_limit=a1*1.012;params.DarkEnergy.matching_scale=a1
    params.DarkEnergy.set_table("SetMatching",k,seed["D"],seed["Q"]);params.DoLateRadTruncation=False
    engine=src.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6.4
    targets=np.geomspace(a1*(1+1e-6),center*(1+2e-6),4097)
    times=engine.conformal_time(1/targets-1,tol=1e-10)
    names=["a","H","mts_q_h","mts_dp_h","mts_drho_h","mts_match_count"]
    result=engine.get_time_evolution(k,times,vars=names,lAccuracyBoost=4)
    assert np.all(result[:,:,-1]==1) and np.isfinite(result).all()
    a=result[0,:,0].copy()
    assert a[-1]>center and np.all(np.diff(a)>0)
    print(panel,"initial fractional offset",a[0]/a1-1,flush=True)
    save(f"averaged-impulse-{panel}.npz",k=k,scale=a,tau=times,q=result[:,:,2]*a/rho,p=result[:,:,3]*a/rho,d=result[:,:,4]*a/rho,h=result[0,:,1])

def score():
    guard();rawout=[];bridge=[]
    for panel in ("outer","outer-mid"):
        rawdata=load(f"exact-{panel}-1200-1500.npz");raw=rawdata["raw"];total=rawdata["tau"];k=rawdata["k"]
        with np.load(table("1500")) as bg:rho=float(bg["rho_star"])
        for tag,indices in zip(("1200","1500"),np.split(np.arange(len(total)),2),strict=True):
            seed=load(f"seed-{panel}-{tag}.npz");a=raw[0,indices,0];tau=total[indices];a0=float(seed["scale"])
            momentum=raw[:,indices,3]*a[None,:]**2/rho
            rhs=(k[:,None]*a**2/rho*raw[:,indices,4]).T
            core=np.arange(12,len(tau)-12);anchor=core[len(core)//2]
            for stride in (1,2):
                use=np.arange(0,len(tau),stride)
                anti=make_interp_spline(tau[use],rhs[use],k=7).antiderivative()
                defect=((anti(tau[core])-anti(tau[anchor])).T-(momentum[:,core]-momentum[:,anchor,None]))/(a0*seed["qnorm"][:,None])
                for loc,node in enumerate(k):
                    rawout.append(dict(panel=panel,tag=tag,k=node,stride=stride,max_scaled_impulse_defect=np.max(abs(defect[loc]))))
        data=load(f"averaged-impulse-{panel}.npz");early=load(f"seed-{panel}-1200.npz");late=load(f"seed-{panel}-1500.npz")
        a=data["scale"];N=np.log(a);a1=float(early["scale"]);a2=float(late["scale"])
        deltaN=N[0]-math.log(a1)
        assert abs(deltaN)<5e-6 and a[-1]>=a2
        anti=CubicSpline(N,(k[:,None]*a*data["p"]/data["h"]).T).antiderivative()
        qfn=CubicSpline(N,(a*data["q"]).T)
        endq=qfn(math.log(a2));numeric_impulse=anti(math.log(a2))-anti(N[0])
        initial=a[0]*data["q"][:,0]
        err=(endq-initial-numeric_impulse)/(a2*late["qnorm"])
        d2=CubicSpline(N,data["d"].T)(math.log(a2))
        for i,node in enumerate(k):
            bridge.append(dict(panel=panel,k=node,initial_offset_ln_a=deltaN,fluid_integral_error=err[i],
                q_missing=(a2*late["Q"][i]-endq[i])/(a2*late["qnorm"][i]),d_missing=(late["D"][i]-d2[i])/late["normalization"][i],
                required_projected_endpoint_impulse=(a2*late["Q"][i]-a1*early["Q"][i])/node,
                fluid_endpoint_impulse=(endq[i]-a1*early["Q"][i])/node,
                missing_endpoint_impulse=(a2*late["Q"][i]-endq[i])/node))
    csvout("microscopic-impulse.csv",rawout);csvout("averaged-impulse.csv",bridge)
    print("actual scalar short-window impulse",max(r["max_scaled_impulse_defect"] for r in rawout),"averaged fluid conservation",max(abs(r["fluid_integral_error"]) for r in bridge),"normalized endpoint misses D,Q",max(abs(r["d_missing"]) for r in bridge),max(abs(r["q_missing"]) for r in bridge))
if __name__=="__main__":
    if sys.argv[1]=="score":score()
    else:early_transfer(sys.argv[1])

