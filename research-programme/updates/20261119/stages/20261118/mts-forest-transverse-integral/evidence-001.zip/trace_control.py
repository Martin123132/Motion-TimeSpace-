from local import *

def main():
    guard()
    src=native("earlyenv");sys.path.insert(0,str(ENV))
    from trace_map import run
    from setup_stage import OTHER
    with np.load(ENV/"trace-driver.npz") as prev:
        driver={name:prev[name] for name in ("tau","a","H","rho","mass")}
    direct=load("seed-mid-200.npz");k=direct["k"];initial=np.column_stack([direct["D"],direct["Q"]])
    params=src.params_for(table("200"));params.DarkEnergy.set_table("SetMatching",k,*initial.T)
    engine=src.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6
    span=engine.conformal_time(1/np.array([.000197,.0002636])-1,tol=1e-10)
    times=np.linspace(*span,len(driver["tau"]));names=["a","etak",*["delta_"+key for key in OTHER],"mts_drho_s","mts_dp_s","delta_tot_de","v_newtonian_baryon","mts_match_count"]
    values=engine.get_time_evolution(k,times,vars=names,lAccuracyBoost=4)
    get=lambda key:values[:,:,names.index(key)]
    a=get("a")[0].copy();dens=engine.get_background_densities(a,vars=list(OTHER))
    d={key:dens[key]*get("delta_"+key)/a**2 for key in OTHER}
    total=sum(d.values())+get("mts_drho_s")
    rest=d["photon"]+d["neutrino"]+3*(get("delta_tot_de")+get("v_newtonian_baryon")+get("mts_dp_s"))
    fn=lambda val:CubicSpline(np.log(a),val,axis=1,extrapolate=False)(np.log(driver["a"]))
    assert np.all(get("mts_match_count")[:,-1]==1)
    driver.update(modes=k,initial=initial,environment=fn(k[:,None]*get("etak")+.5*total),external_trace=fn(.5*(total+rest)))
    results=[]
    with np.load(table("200")) as tab:
        for stride in (1,2):
            pred=run(driver,tab,stride,True)[0]
            for name,index in (("225",2),("250",4)):
                actual=load("seed-mid-"+name+".npz");norm=np.column_stack([actual["normalization"],actual["qnorm"],actual["normalization"]])
                defect=(pred[index]-np.column_stack([actual["D"],actual["Q"],actual["P"]]))/norm
                for loc,mode in enumerate(k):
                    results.append(dict(k=mode,tag=name,stride=stride,density=defect[loc,0],current=defect[loc,1],pressure=defect[loc,2]))
    csvout("trace-control.csv",results)
    print("trace maxima",np.max(abs(np.array([[r[c] for c in ("density","current","pressure")] for r in results])),axis=0),flush=True)
if __name__=="__main__":main()

