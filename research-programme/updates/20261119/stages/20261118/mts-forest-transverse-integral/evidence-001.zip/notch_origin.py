from local import *
from scipy.optimize import brentq

def main():
    guard();out=[]
    radial=rows(POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv")
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        for epoch,z in enumerate(Z):
            if z>5.4:continue
            kx=max(float(r["k_parent"]) for r in radial if float(r["z"])==z)
            for scenario in ("warm-full","warm-density-only","native-gas-fixed-flux-conversion"):
                blocks=[]
                for panel in ("mid","quarter","outer","outer-mid","notch"):
                    tag="1200" if case=="heavy" and panel not in ("mid","quarter") else "225"
                    gas=load(f"gas-{panel}-{case}-{tag}.npz")
                    src=load(f"source-{panel}-{case}-{tag}.npz")
                    vh=src["h"][np.searchsorted(src["N"],src["epochs"][epoch])]*SPEED
                    assert abs(kx/vh/.0794328-1)<2e-5
                    k=gas["k"];temp=int(not scenario.startswith("native"))
                    field=gas[f"{arm}-{temp}-2048-1"][epoch]
                    thermal=.25*(kx/vh)**2*2*1.380649e-23*1e4/(1.67262192369e-27*1e6)
                    density=(2-.5*(.7+thermal))*field[:,1]
                    velocity=(kx/k)**2*field[:,2]
                    if scenario=="warm-density-only":velocity=np.zeros_like(velocity)
                    blocks.append(np.column_stack([k,density,velocity]))
                bank=np.vstack(blocks);bank=bank[np.argsort(bank[:,0])];bank=bank[bank[:,0]>=kx]
                k,d,v=bank.T;total=d+v
                roots=np.flatnonzero(total[:-1]*total[1:]<0)
                if not len(roots):
                    out.append(dict(arm=arm,z=z,scenario=scenario,lo=None,hi=None,k_zero_interp=None,d_plus_v_lo=None,d_plus_v_hi=None))
                else:
                    fn=PchipInterpolator(k,total)
                    for j in roots:
                        out.append(dict(arm=arm,z=z,scenario=scenario,lo=k[j],hi=k[j+1],k_zero_interp=brentq(fn,k[j],k[j+1]),
                            d_plus_v_lo=total[j],d_plus_v_hi=total[j+1]))
    csvout("notch-physics.csv",out)
    for row in out:
        if row["z"]==4.2:print(row["arm"],row["scenario"],row["k_zero_interp"])
if __name__=="__main__":main()

