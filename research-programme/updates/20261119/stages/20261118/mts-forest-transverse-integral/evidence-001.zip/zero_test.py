from projection import *
from scipy.optimize import brentq

def main(action):
    guard();defs=rows("node-gates.csv")
    cases=(("heavy","wave"),("heavy","off"),("cold","cold"))
    if action=="freeze":
        assert not list(ROOT.glob("*notch*.npz"))
        forecast=[];nodes=[]
        for case,arm in cases:
            data=sorted([r for r in defs if r["arm"]==arm],key=lambda r:float(r["k"]))
            k=np.array([float(r["k"]) for r in data]);v=np.array([float(r["signed_density"])+float(r["signed_velocity"]) for r in data])
            indices=np.flatnonzero(v[1:]*v[:-1]<0);assert len(indices)==1
            idx=indices.item();lo,hi=k[idx:idx+2]
            fn=PchipInterpolator(np.log(k),v);root=math.exp(brentq(fn,np.log(lo),np.log(hi)))
            width=min(.1*(hi-lo),.8*(root-lo),.8*(hi-root));probe=[root-width,root,root+width];assert lo<probe[0]<probe[-1]<hi
            nodes+=probe
            forecast.append(dict(arm=arm,lower=lo,upper=hi,predicted_root=root,probes=probe,signed_forecast=list(fn(np.log(probe))),tag="1200" if case=="heavy" else "225"))
        write("notch-freeze.json",dict(nodes_sha=sha(ROOT/"node-gates.csv"),test="Require opposite signs on the two predicted flanks on both MTS interfaces and cold. Keep relative transfer/power gates separate; near the null never replace them by an amplitude-floor pass.",predictions=forecast))
        write("modes-notch.json",dict(modes=list(np.sort(nodes))))
    else:
        assert action=="score"
        freeze=read("notch-freeze.json");assert sha(ROOT/"node-gates.csv")==freeze["nodes_sha"];out=[]
        for row,(case,arm) in zip(freeze["predictions"],cases,strict=True):
            assert row["arm"]==arm
            for tag in (["1200","1500"] if case=="heavy" else ["225"]):
                probe=np.array(row["probes"]);observed=sample("notch",case,tag,arm)
                idx=np.searchsorted(observed[:,0],probe);assert np.array_equal(observed[idx,0],probe)
                signed=observed[idx,1]+observed[idx,2]
                bracket=bool(signed[0]*signed[-1]<0)
                root=None
                if bracket:
                    fn=PchipInterpolator(probe,signed)
                    root=brentq(fn,probe[0],probe[-1])
                controls=observed if case=="cold" else sample("notch",case,"1500" if tag=="1200" else "1200",arm)
                for pos,(k,val) in enumerate(zip(probe,signed,strict=True)):
                    j=idx[pos];power=observed[j,3];contrast=(observed[j,1:3]-controls[j,1:3])
                    out.append(dict(arm=arm,tag=tag,k=k,pred_root=row["predicted_root"],direct_root_interpolated=root,bracket_sign=bracket,
                        forecast=row["signed_forecast"][pos],actual=val,signed_density=observed[j,1],signed_velocity=observed[j,2],
                        integrand=power,relative_interface_integrand=abs(controls[j,3]/power-1),
                        absolute_interface_mean_amplitude=abs(sum(contrast)),passes_relative_kernel=bool(abs(controls[j,3]/power-1)<2e-5)))
        csvout("notch-test.csv",out)
        for row in out[1::3]:print(row["arm"],row["tag"],row["pred_root"],row["direct_root_interpolated"],row["bracket_sign"],flush=True)
if __name__=="__main__":main(sys.argv[1])

