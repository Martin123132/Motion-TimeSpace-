from projection import *

def main(seal):
    guard();checks=[]
    def require(label,test):
        if not test:raise ValueError(label)
        checks.append(label)
    old=read(PREV/"closeout.json");older=read(ENV/"closeout.json")
    protected={}
    def protect(path,expected=None):
        path=Path(path).resolve();value=sha(path)
        if expected is not None:require("source fingerprint "+path.name,value==expected)
        protected[str(path)]=value
    protect(PREV/"closeout.json",LOCK)
    for name in ("heavy-inputs.npz","mapped-frozen-midpoint-kernels.csv","mapped-continuous-band.csv","warm-linear.npz","primordial-settings.json","observer/native/camb/cambdll.dll"):
        protect(PREV/name,old["files"][name])
    for name in ("trace-driver.npz","trace_map.py","setup_stage.py","envelope.py","trace_input.py","observer/native/camb/cambdll.dll"):
        protect(ENV/name,older["files"][name])
    for path in (BG,COLD,*[table(i) for i in ("200","225","250")],MATCH/"native/camb/cambdll.dll",MATCH/"native/fortran/MTSTwoField.f90",MATCH/"matching_common.py",MATCH/"stage_common.py",BASE/"radiation-and-slow-field-transfer-20261007/radiation_common.py",POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv",POST/"mts-forest-pressure-switch-20261118/engine/native/camb/cambdll.dll"):
        protect(path,old["protected"].get(str(path.resolve())) or older["protected"].get(str(path.resolve())))
    import ast
    for path in ROOT.glob("*.py"):ast.parse(path.read_text(encoding="utf8"),filename=path.name)
    require("old midpoint forecasts were evaluated, not rewritten",len(rows("frozen-midpoint-tests.csv"))==9 and max(abs(float(r["fractional_forecast_error"])) for r in rows("frozen-midpoint-tests.csv"))>2e-5)
    for filename in ("homogeneous.json","homogeneous-late.json"):
        h=read(filename);require("carrier overlap and refinement "+filename,max(h["tested_overlap"]+h["coarse_fine"])<2e-5)
        for surface in h["surfaces"]:
            require("density join and flatness "+surface["tag"],max(surface["density_jump"],surface["flatness"])<2e-8)
    for tag in ("750","900"):require("rejected transition retained "+tag,not np.any(load(f"seed-outer-{tag}.npz")["eligible"]))
    for panel in ("outer","outer-mid","notch","overlap"):
        for tag in ("1200","1500"):
            seed=load(f"seed-{panel}-{tag}.npz")
            require("local projection pressure and modes "+panel+tag,np.array_equal(seed["k"],modes(panel)) and np.all(seed["eligible"]) and np.max(seed["pe"])<2e-6 and max(np.max(seed["de"]),np.max(seed["qe"]))<2e-5)
    trace=rows("trace-control.csv")
    require("independent early trace",len(trace)==28 and all(max(abs(float(r["density"])),abs(float(r["current"])))<2e-5 and abs(float(r["pressure"]))<2e-6 for r in trace))
    for case,tag,arm in (("heavy","1200","off"),("cold","225","cold")):
        native=load(f"native-off-outer-{case}-{tag}/result.npz")
        require("independent pressure intervention "+case,np.array_equal(native["k"],modes("outer")) and np.max(abs(native["scaled"]))<2e-5)
    reduce=rows("two-dust-gravity.csv")
    require("independent four-coordinate geodesic calculation",len(reduce)==24 and max(float(r["max_relative"]) for r in reduce)<2e-5)
    nodes=rows("node-gates.csv");allbands=rows("finite-bands.csv")
    for arm in ("wave","off","exact","cold"):
        points=[r for r in nodes if r["arm"]==arm]
        require("complete distinct knots "+arm,len({r["k"] for r in points})==37)
        for r in points:
            calculated=max(float(r[key]) for key in ("interface_force_all_epochs","interface_gas_all_epochs","interface_velocity_all_epochs","interface_integrand","max_other_checks"))<2e-5
            require("point classification "+arm+" "+r["k"],calculated==(r["passes_common_gate"]=="True"))
        areas=[r for r in allbands if r["arm"]==arm]
        total=max(areas,key=lambda r:float(r["hi"])-float(r["lo"]))
        primary=float(total["primary"]);subs=[float(r["primary"]) for r in areas if r["hi"] in ("12.0","24.0") or float(r["lo"])==24 or float(r["hi"])==modes("mid")[-1]]
        require("finite partition "+arm,len(subs)==4 and abs(sum(subs)/primary-1)<1e-12)
        require("two-sided integral classification "+arm,(total["all_support_gates"]=="True")==all(r["passes_common_gate"]=="True" for r in points))
        require("complete frozen tests "+arm,len([r for r in rows("held-out-kernels.csv") if r["arm"]==arm])==12)
    require("cold control not spuriously censored",all(r["passes_common_gate"]=="True" for r in nodes if r["arm"]=="cold"))
    require("failed heavy cases not promoted",any(r["passes_common_gate"]=="False" for r in nodes if r["arm"]=="wave") and any(r["passes_common_gate"]=="False" for r in nodes if r["arm"]=="off"))
    joined=rows("cross-range-join.csv");require("seam tested at same actual k",len(joined)==36 and any(r["passes"]=="False" for r in joined))
    nulls=rows("notch-test.csv");require("signed forecasts precede new direct fields",sha(ROOT/"node-gates.csv")==read("notch-freeze.json")["nodes_sha"] and len(nulls)==15)
    for pred in read("notch-freeze.json")["predictions"]:
        for tag in (["225"] if pred["arm"]=="cold" else ["1200","1500"]):
            group=[r for r in nulls if r["arm"]==pred["arm"] and r["tag"]==tag]
            require("prospective sign brackets "+pred["arm"]+tag,list(map(float,[r["k"] for r in group]))==pred["probes"] and float(group[0]["actual"])*float(group[-1]["actual"])<0)
    require("near-null failures kept",any(r["passes_relative_kernel"]=="False" for r in nulls))
    required=rows("notch-physics.csv")
    require("native thermal null not invented",all(not r["k_zero_interp"] for r in required if r["z"]=="4.2" and r["scenario"].startswith("native")))
    origin=rows("matching-error-origin.csv")
    require("exact crossed response difference",len(origin)==1008 and max(abs(float(r["closure"])) for r in origin)<1e-9)
    require("affine split closes",max(float(r["sum_error"]) for r in rows("response-decomposition.csv"))<1e-9)
    wave=rows("microscopic-impulse.csv");fluid=rows("averaged-impulse.csv")
    require("actual microscopic impulses recorded",len(wave)==96 and all(np.isfinite(float(r["max_scaled_impulse_defect"])) for r in wave))
    require("projected impulse recorded",len(fluid)==24 and all(abs(float(r["fluid_integral_error"]))<2e-5 for r in fluid))
    for name,expected_count in (("outer",48),("outer-mid",48),("notch",36),("clock16",16),("clock32",16)):
        table0=rows("clock-defect-"+name+".csv")
        require("predicted clock remainder "+name,len(table0)==expected_count and max(float(r["corrected"]) for r in table0)<2e-6)
    transport=rows("common-clock-transport.csv")
    require("actual shared-clock transport and positive control",len(transport)==32 and max(float(r["max_scaled_momentum_imbalance"]) for r in transport if r["transport"]=="lookup")>2e-5 and max(float(r["max_scaled_momentum_imbalance"]) for r in transport if r["transport"]=="friedmann")<2e-6)
    require("unrepaired native trace control reproduced",max(float(r["max_change_from_native_fields"]) for r in transport if r["transport"]=="lookup")<2e-5)
    pair=rows("clock-interface-replay.csv")
    require("refined native negative/positive controls",len(pair)==16 and sum(r["passes"]=="True" for r in pair if r["panel"]=="clock32")==8 and sum(r["passes"]=="True" for r in pair if r["panel"]=="outer")==4)
    require("all four refined endpoints sourced",max(abs(float(r["q_endpoint"])) for r in pair if r["panel"]=="clock32")<2e-5)
    require("no temporary bytecode or stop marker",not list(ROOT.rglob("__pycache__")) and not (ROOT/"STOP-REQUESTED").exists())
    files={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(ROOT.rglob("*")) if p.is_file() and p.name!="closeout.json"}
    if seal:
        require("prospective output creation order",all((ROOT/a).stat().st_mtime_ns<(ROOT/b).stat().st_mtime_ns for a,b in (("frozen-outer-mid-heavy-1200.csv","seed-outer-mid-1200.npz"),("frozen-outer-mid-cold-225.csv","source-outer-mid-cold-225.npz"),("notch-freeze.json","seed-notch-1200.npz"))))
        write("closeout.json",dict(previous=LOCK,checks=checks,files=files,protected=protected))
    else:
        receipt=read("closeout.json")
        require("stage and sources sealed",receipt["files"]==files and receipt["protected"]==protected and receipt["previous"]==LOCK)
    print(len(checks),"checks",len(files),"files",len(protected),"source fingerprints",sha(ROOT/"closeout.json"),flush=True)
if __name__=="__main__":main(sys.argv[1:]==["--seal"])

