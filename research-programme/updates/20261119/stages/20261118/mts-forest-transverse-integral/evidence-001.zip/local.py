from pathlib import Path
import os, sys, math, json, csv, hashlib
for var in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[var]="1"
sys.dont_write_bytecode=True
import numpy as np
import psutil
from scipy.interpolate import CubicSpline, PchipInterpolator
ROOT=Path(__file__).resolve().parent; POST=ROOT.parent
PREV=POST/"mts-wave-gas-sightlines-20261118"; ENV=POST/"mts-forest-envelope-pressure-20261118"
BASE=POST/"condensate-origin-20261003"; EARLY=BASE/"native-two-field-transfer-20261007"; MATCH=BASE/"native-heavy-matching-20261007"; SPEC=BASE/"resolved-matter-spectrum-20261007"
BG=EARLY/"runs/backgrounds/heavy.npz"; COLD=EARLY/"runs/backgrounds/cold.npz"
LOCK="1d2f0f677e51a30d0e869b4f7ebe623edc6c9ac21671bef4fb66580d6c09d94c"
SPEED=299792.458; Z=np.array([99.,49.,8.,5.4,5.,4.6,4.2])
def sha(path):
    with Path(path).open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    proc=psutil.Process();proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([proc.cpu_affinity()[0]])
    assert sha(PREV/"closeout.json")==LOCK and not any((p/"STOP-REQUESTED").exists() for p in (POST,BASE,PREV,ENV,ROOT))
def save(name,**vals):
    with (ROOT/name).open("xb") as stream:np.savez_compressed(stream,**vals)
def load(name):
    with np.load(ROOT/name) as packet:return dict(packet)
def write(name,rec):
    with (ROOT/name).open("x",encoding="utf8") as stream:json.dump(rec,stream,indent=2,allow_nan=False)
def read(name):return json.loads((ROOT/name).read_text())
def rows(name):
    with (ROOT/name).open(newline="",encoding="utf8") as stream:return list(csv.DictReader(stream))
def csvout(name,lines):
    with (ROOT/name).open("x",newline="",encoding="utf8") as stream:
        out=csv.DictWriter(stream,fieldnames=list(lines[0]));out.writeheader();out.writerows(lines)
def modes(panel):
    base=np.load(PREV/"heavy-inputs.npz")["k"]
    frozen=np.array([float(r["frozen_total_k"]) for r in rows(PREV/"mapped-frozen-midpoint-kernels.csv") if r["arm"]=="wave"])
    if panel=="overlap":return base[-3:].copy()
    if panel in ("clock16","clock32"):
        return modes("outer")[[0,4,9,11]]
    if panel=="mid":return np.sort(np.r_[base,frozen])
    if panel=="quarter":return np.sqrt(modes("mid")[:-1]*modes("mid")[1:])
    grid=[base[-1],12.,24.,37.]
    if panel in ("outer","outer-mid"):
        knots=np.concatenate([np.geomspace(lo,hi,5)[1:] for lo,hi in zip(grid[:-1],grid[1:])])
        return knots if panel=="outer" else np.sqrt(np.r_[base[-1],knots[:-1]]*knots)
    if (ROOT/("modes-"+panel+".json")).exists():return np.array(read("modes-"+panel+".json")["modes"])
    raise ValueError(panel)
def table(tag):
    if tag in ("200","225","250"):return SPEC/f"runs/projection/a{tag}-w6-d8.npz"
    return ROOT/f"background-{tag}.npz"
def native(kind="stock"):
    where={"stock":MATCH,"source":PREV/"observer","earlyenv":ENV/"observer","switch":POST/"mts-forest-pressure-switch-20261118/engine"}[kind]
    sys.path[:0]=[str(where),str(BASE/"radiation-and-slow-field-transfer-20261007")]
    import matching_common as src
    assert Path(src.camb.__file__).resolve().parent==(where/"native/camb").resolve()
    return src
def pressure(k,scale,mass,h,d,q):
    u=k/(scale*mass);cs=u/(np.sqrt(1+u*u)+1)
    norm=np.maximum.reduce([abs(d),np.abs(k*q/h)/np.maximum(1,k*cs/h),np.full_like(d,1e-6)])
    return cs**2*(d+3*h*q/k),norm,norm*np.maximum(h/k,cs)
def projects(scale,values,table0,center,width,degree,thin=1):
    phase=CubicSpline(table0["heavy_efold"],table0["phase_h"])(np.log(scale))
    middle=float(CubicSpline(table0["heavy_efold"],table0["phase_h"])(np.log(center)))
    use=np.flatnonzero(abs(phase-middle)<width*np.pi)[::thin]
    x=(phase[use]-middle)/(width*np.pi)
    columns=[x**power for power in range(degree+1)]
    columns.extend(x**power*fn(2*phase[use]) for power in range(degree-1) for fn in (np.cos,np.sin))
    columns.extend(x**power*fn(4*phase[use]) for power in range(3) for fn in (np.cos,np.sin))
    design=np.array(columns).T;w=np.linalg.pinv(design)[0]
    assert len(use)>=90 and np.linalg.cond(design)<1e5
    return np.einsum("t,ktj->kj",w,values[:,use])

