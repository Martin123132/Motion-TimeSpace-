from local import *
def integrand(k,z,velocity_h,transfer,kx):
    meta=json.loads((PREV/"primordial-settings.json").read_text());gamma=1.5;A=.65
    b2=2*1.380649e-23*1e4/(1.67262192369e-27*1e6)
    d=.25*(kx/velocity_h)**2*b2;factor=2-(.7+d)*(gamma-1)
    prim=2*np.pi**2*meta["As"]*(k/meta["pivot_Mpc"])**(meta["ns"]-1)/k**3
    response=factor*transfer[:,1]+(kx/k)**2*transfer[:,2]
    return velocity_h*A*A*np.exp(-2*d)*k**2/(2*np.pi)*prim*response**2
def vector(panel,case,tag,arm,zi=-1):
    gas=load("gas-"+panel+"-"+case+"-"+tag+".npz");src=load("source-"+panel+"-"+case+"-"+tag+".npz")
    k=gas["k"];epoch=src["epochs"][zi];vh=src["h"][np.searchsorted(src["N"],epoch)]*SPEED
    mapping={float(r["z"]):float(r["k_parent"]) for r in rows(POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv") if float(r["k_parent"])>5}
    kx=mapping[Z[zi]]
    get=lambda label:integrand(k,Z[zi],vh,gas[label][zi],kx)
    return k,get(arm+"-1-2048-1"),get(arm+"-1-1024-1"),get(arm+"-1-2048-2")
def mid():
    guard();frozen=rows(PREV/"mapped-frozen-midpoint-kernels.csv");out=[];banks=[]
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        k,value,coarse,sparse=vector("mid",case,"225",arm)
        check=load("gas-mid-"+case+"-225.npz")[arm+"-1-2048-1"][:,::2]
        old=np.load(PREV/"warm-linear.npz")[arm]
        assert np.max(abs(check/old-1))<2e-5
        if case=="heavy":
            _,later,_,_=vector("mid",case,"250",arm)
            assert np.max(abs(later/value-1))<2e-5
        for row in frozen:
            if row["arm"]!=arm:continue
            fi=float(row["frozen_total_k"]);idx=np.flatnonzero(k==fi).item();pred=float(row["per_log_k_kms"])
            out.append(dict(arm=arm,k=fi,frozen=pred,direct=value[idx],fractional_forecast_error=pred/value[idx]-1,
                earlier_interface_ratio=later[idx]/value[idx]-1 if case=="heavy" else None,
                time_refinement=coarse[idx]/value[idx]-1,source_resolution=sparse[idx]/value[idx]-1))
        poly=PchipInterpolator(np.log(k),value);area=float(poly.integrate(np.log(k[0]),np.log(k[-1])))
        original=next(float(r["partial_band_kms"]) for r in rows(PREV/"mapped-continuous-band.csv") if r["arm"]==arm and float(r["z"])==4.2)
        banks.append(dict(arm=arm,old=original,fresh=area,relative=area/original-1,max_forecast=max(abs(r["fractional_forecast_error"]) for r in out if r["arm"]==arm)))
    csvout("frozen-midpoint-tests.csv",out);csvout("first-band-update.csv",banks);print(banks)
if __name__=="__main__":mid()

