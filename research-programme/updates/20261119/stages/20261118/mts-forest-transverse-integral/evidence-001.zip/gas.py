from local import *
from numpy.polynomial import Polynomial
KB=1.380649e-23;MP=1.67262192369e-27
def affine(env,k,mass,arm,hot):
    a=env[...,0,None];h=env[...,1,None];g=env[...,None,2:5];cs=env[...,5,None];opacity=env[...,7,None];light=env[...,8,None]
    other=env[...,9:].reshape(*env.shape[:-1],len(k),4);ext,slip,entropy,phot=np.moveaxis(other,-1,0)
    kk=k**2
    den=kk+3*g.sum(axis=-1)
    base=np.zeros((*den.shape,7));base[...,:3]=-g/den[...,None]
    base[...,3:6]=3*(h/a)[...,None]*g/den[...,None];base[...,6]=-ext/den
    psi=base.copy();psi[...,6]-=slip/kk
    eta=base.copy();eta[...,3]-=h/a
    pressure=cs[...,None]*3*eta;pressure[...,1]+=cs;pressure[...,6]+=entropy+light*opacity*phot/k
    pressure[...,4]+=4*light*opacity/(3*a)
    if hot:
        ramp=np.clip(np.log(10*a)/np.log(10/8),0,1)
        pressure[...,1]+=1.5*KB*1e4/(.61*MP*(SPEED*1000)**2)*ramp**2*(3-2*ramp)
    coeff=np.zeros((*den.shape,6,7))
    for axis in range(3):
        coeff[...,axis,axis+3]=kk/(a*h)
        coeff[...,axis+3,:]=-(a/h)[...,None]*psi
    coeff[...,4,:]-=(a/h)[...,None]*pressure
    if arm in ("exact","wave"):
        usq=kk/(a*mass)**2
        if arm=="exact":
            pp=(usq/(np.sqrt(1+usq)+1)**2)[...,None]*(3*base)
            cs_h=usq/(np.sqrt(1+usq)+1)**2
            pp[...,2]+=cs_h;pp[...,5]-=3*h*cs_h/a
            coeff[...,2,:]-=3*pp
        else:
            pp=np.zeros_like(base);pp[...,2]=usq/4
        coeff[...,5,:]-=(a/h)[...,None]*pp
    elif arm=="cold":
        coeff[...,2,:]=0;coeff[...,5,:]=0
    else:assert arm=="off"
    return coeff,base,psi
def run(data,arm,hot,steps,stride,split=False):
    ef=data["N"];k=data["k"];mass=float(data["mass"]);epochs=data["epochs"]
    ii=np.unique(np.r_[np.arange(0,len(ef),stride),len(ef)-1,np.searchsorted(ef,epochs)])
    env=np.column_stack([data["a"],data["h"],data["g"].T,data["thermal"],data["external"].transpose(1,0,2).reshape(len(ef),-1)])
    fn=CubicSpline(ef[ii],env[ii],axis=0)
    grid=np.unique(np.r_[np.linspace(ef[0],ef[-1],steps+1),epochs]);dt=np.diff(grid)
    state=data["init"].copy()
    if split:
        original=state;state=np.zeros((len(k),6,8))
        for field in range(6):state[:,field,field]=original[:,field]
        state[:,:,7]=original
        offset=np.array([0,0,0,0,0,0,1,1])
    nodes,weights=np.polynomial.legendre.leggauss(3);nodes=(nodes+1)/2;weights/=2
    coll=[]
    for idx in range(3):
        p=Polynomial.fromroots(np.delete(nodes,idx));v=(p/p(nodes[idx])).integ();coll.append(v(nodes)-v(0))
    coll=np.array(coll).T
    outs=[];land=set(np.searchsorted(grid,epochs))
    def record(time):
        env=fn(time);_,phi,psi=affine(env,k,mass,arm,hot)
        if split:
            potential=np.einsum("ki,kij->kj",phi[:,:6],state)+phi[:,6,None]*offset
            lapse=np.einsum("ki,kij->kj",psi[:,:6],state)+psi[:,6,None]*offset
            outs.append(np.stack([-k[:,None]**2*lapse,state[:,1]+3*potential,k[:,None]**2*state[:,4]/(env[0]*env[1])],axis=1))
            return
        vec=np.column_stack([state,np.ones(len(k))])
        outs.append(np.column_stack([-k**2*np.sum(psi*vec,axis=-1),state[:,1]+3*np.sum(phi*vec,axis=-1),k**2*state[:,4]/(env[0]*env[1])]))
    record(grid[0])
    for first in range(0,len(dt),48):
        ds=dt[first:first+48];t=grid[first:first+len(ds),None]+nodes*ds[:,None]
        co=affine(fn(t),k,mass,arm,hot)[0].transpose(0,2,1,3,4)
        model=co[...,:6];src=co[...,6]
        blocks=ds[:,None,None,None,None,None]*coll[None,None,:,None,:,None]*model.transpose(0,1,3,2,4)[:,:,None,:,:,:]
        mat=np.eye(18)-blocks.reshape(len(ds),len(k),18,18)
        rhs=np.zeros((len(ds),len(k),3,6,7));rhs[...,:6]=np.eye(6)
        rhs[...,6]=ds[:,None,None,None]*np.einsum("ij,tkjl->tkil",coll,src)
        stage=np.linalg.solve(mat,rhs.reshape(len(ds),len(k),18,7)).reshape(len(ds),len(k),3,6,7)
        slope=model@stage;slope[...,6]+=src
        jump=ds[:,None,None,None]*np.einsum("i,tkijl->tkjl",weights,slope);jump[...,:6]+=np.eye(6)
        for loc,trans in enumerate(jump):
            if split:state=trans[:,:,:6]@state+trans[:,:,6,None]*offset
            else:state=(trans[:,:,:6]@state[:,:,None])[:,:,0]+trans[:,:,6]
            if first+loc+1 in land:record(grid[first+loc+1])
    return np.array(outs)
def main(name):
    guard();data=load("source-"+name+".npz");case=name.split("-")[-2]
    arms=["wave","off","exact"] if case=="heavy" else ["cold"]
    result={}
    for arm in arms:
        for heat,step,stride in ((0,2048,1),(1,1024,1),(1,2048,1),(1,2048,2)):
            result[f"{arm}-{heat}-{step}-{stride}"]=run(data,arm,heat,step,stride)
    save("gas-"+name+".npz",k=data["k"],z=Z,**result)
    key=("exact" if case=="heavy" else "cold")+"-0-2048-1"
    print(name,"unheated native max",np.max(abs(result[key]/data["truth"]-1)),flush=True)
if __name__=="__main__":main(sys.argv[1])

