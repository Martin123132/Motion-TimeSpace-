from projection import *

def component_ratios(x,y):
    assert x.shape==y.shape
    return np.max(np.abs(x-y)/np.maximum(np.abs(y),1e-30),axis=0)

def compare():
    guard()
    bands=[];knots=[];scores=[];contrast=[];dispersion=[]
    for case,arm in (("heavy","wave"),("heavy","exact"),("heavy","off"),("cold","cold")):
        inputs={};alternates={};gates={}
        for panel in ("mid","quarter","outer","outer-mid"):
            broad=panel.startswith("outer");tag="1200" if broad and case=="heavy" else "225"
            data=sample(panel,case,tag,arm)
            src=load(f"source-{panel}-{case}-{tag}.npz")
            gas=load(f"gas-{panel}-{case}-{tag}.npz")
            controls=[np.abs(data[:,4]/data[:,3]-1),np.abs(data[:,5]/data[:,3]-1),data[:,6],data[:,7]]
            later="1500" if broad else "250"
            if case=="heavy":
                second=sample(panel,case,later,arm)
                late=load(f"gas-{panel}-{case}-{later}.npz")
                peak=component_ratios(gas[arm+"-1-2048-1"],late[arm+"-1-2048-1"])
                localp=np.maximum(load(f"seed-{panel}-{tag}.npz")["pe"],load(f"seed-{panel}-{later}.npz")["pe"])
                localok=load(f"seed-{panel}-{tag}.npz")["eligible"] & load(f"seed-{panel}-{later}.npz")["eligible"]
                assert np.all(localok) and np.all(localp<2e-6)
                kernel=np.abs(data[:,3]/second[:,3]-1)
                controls+=[np.abs(second[:,4]/second[:,3]-1),np.abs(second[:,5]/second[:,3]-1),second[:,6],second[:,7]]
            else:second=data;peak=np.zeros((len(data),3));kernel=np.zeros(len(data));localp=np.zeros(len(data))
            technical=np.max(controls,axis=0)
            gates[panel]=(np.maximum(technical,kernel)<2e-5)&(np.max(peak,axis=1)<2e-5)
            settings=read(PREV/"primordial-settings.json")
            for idx,k in enumerate(data[:,0]):
                knots.append(dict(arm=arm,panel=panel,k=k,signed_density=data[idx,1],signed_velocity=data[idx,2],integrand=data[idx,3],
                    local_pressure=localp[idx],interface_force_all_epochs=peak[idx,0],interface_gas_all_epochs=peak[idx,1],
                    interface_velocity_all_epochs=peak[idx,2],interface_integrand=kernel[idx],max_other_checks=technical[idx],passes_common_gate=bool(gates[panel][idx])))
                dimless=settings["As"]*(k/settings["pivot_Mpc"])**(settings["ns"]-1)
                disp=gas[arm+"-1-2048-1"][-1,idx]
                dispersion.append(dict(arm=arm,panel=panel,k=k,z=4.2,delta2_gas=dimless*disp[1]**2,delta2_velocity_divergence=dimless*disp[2]**2,passes_common_gate=bool(gates[panel][idx])))
            inputs[panel]=data;alternates[panel]=second
        forecast=[r for r in rows(f"frozen-outer-mid-{case}-"+("1200" if case=="heavy" else "225")+".csv") if r["arm"]==arm]
        for row,actual in zip(forecast,inputs["outer-mid"],strict=True):
            assert float(row["k"])==actual[0]
            signed=float(actual[1]+actual[2]);err=float(row["integrand_kms"])/actual[3]-1
            scores.append(dict(arm=arm,k=actual[0],frozen=float(row["integrand_kms"]),direct=actual[3],relative=err,
                predicted_amplitude=float(row["signed_sqrt_kms"]),direct_amplitude=signed,
                passes_integrand_prediction=bool(abs(err)<2e-5)))
        full=ordered(*inputs.values());second=ordered(*alternates.values());coarse=ordered(inputs["mid"],inputs["outer"])
        for lo,hi in ((full[0,0],modes("mid")[-1]),(modes("mid")[-1],12.),(12.,24.),(24.,37.),(full[0,0],37.),(modes("outer")[-2],37.)):
            area=integral(full,lo,hi);other=integral(second,lo,hi);fewer=integral(coarse,lo,hi)
            x=full[:,0];first=np.searchsorted(x,lo);last=np.searchsorted(x,hi)
            influences=set(x[max(0,first-1):min(len(x),last+2)])
            relevant=[r for r in knots if r["arm"]==arm and r["k"] in influences]
            assert len(relevant)==len(influences)
            bands.append(dict(arm=arm,lo=lo,hi=hi,**area,coarse_area=fewer["primary"],refinement=area["primary"]/fewer["primary"]-1,
                later_area=other["primary"],interface_change=other["primary"]/area["primary"]-1,
                all_support_gates=all(r["passes_common_gate"] for r in relevant),
                bad_support_points=sum(not r["passes_common_gate"] for r in relevant),
                positive_tail_unbounded=True))
    for row in bands:
        if row["arm"]!="wave":continue
        companions={r["arm"]:r for r in bands if r["lo"]==row["lo"] and r["hi"]==row["hi"]}
        contrast.append(dict(lo=row["lo"],hi=row["hi"],wave=row["primary"],off_over_wave=companions["off"]["primary"]/row["primary"],
            wave_over_cold=row["primary"]/companions["cold"]["primary"],leading_over_exact=row["primary"]/companions["exact"]["primary"],
            all_three_supports_pass=all(r["all_support_gates"] for r in companions.values())))
    csvout("node-gates.csv",knots);csvout("held-out-kernels.csv",scores);csvout("finite-bands.csv",bands)
    csvout("finite-contrasts.csv",contrast);csvout("linear-amplitudes.csv",dispersion)
    for row in contrast:print(row,flush=True)
if __name__=="__main__":compare()

