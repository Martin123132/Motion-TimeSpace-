from local import *
from scipy.interpolate import make_interp_spline

def run(panel):
    guard();packet=load(f"exact-{panel}-1200-1500.npz");raw=packet["raw"];k=packet["k"]
    with np.load(table("1500")) as tab:
        mass=float(tab["heavy_mass_mpc"]);rho=float(tab["rho_star"])
        spline=[CubicSpline(tab["heavy_efold"],tab[name]) for name in ("phi_h","phidot_h","phase_h")]
    ledger=[]
    for tag,ind in zip(("1200","1500"),np.split(np.arange(len(packet["tau"])),2),strict=True):
        tau=packet["tau"][ind];a=raw[0,ind,0];loga=np.log(a);h=raw[0,ind,1]
        clock=make_interp_spline(tau,loga,k=5)(tau,1)
        field,velocity,phase=[fn(loga) for fn in spline];derivative=spline[1](loga,1)
        carrier=a*mass/spline[2](loga,1)
        rest=(derivative+2*velocity)*carrier+(a*mass)**2*field
        mismatch=(derivative+2*velocity)*(clock-carrier)
        potential=(raw[:,ind,2]-raw[:,ind,4])/2
        prod=(a*mass)**2*field;mom=a*mass*velocity
        perturb=(prod*potential+mom*(a*mass/k[:,None])*raw[:,ind,3])/(prod**2+mom**2)
        projected=load(f"seed-{panel}-{tag}.npz");norm=(projected["scale"]*projected["qnorm"])[:,None]
        j=a**2*raw[:,ind,3]/rho; pressure=k[:,None]*a**2*raw[:,ind,4]/rho
        fc=k[:,None]*a**2*perturb/rho
        core=np.arange(12,len(tau)-12);mid=core[len(core)//2]
        for stride in (1,2):
            use=np.arange(0,len(tau),stride)
            def integral(rhs):
                fn=make_interp_spline(tau[use],rhs[:,use].T,k=7).antiderivative()
                return (fn(tau[core])-fn(tau[mid])).T/norm
            actual=(j[:,core]-j[:,mid,None])/norm-integral(pressure)
            predicted=integral(fc*mismatch);native=integral(fc*rest)
            for i,mode in enumerate(k):
                peak=lambda x:float(np.max(abs(x[i])))
                ledger.append(dict(panel=panel,tag=tag,stride=stride,k=mode,unrepaired=peak(actual),clock_only=peak(actual-predicted),
                    corrected=peak(actual-predicted-native),clock_contribution=peak(predicted),tabulated_kg_contribution=peak(native),
                    lookup_vs_carrier=float(np.max(abs(clock[core]/carrier[core]-1))),friedmann_vs_carrier=float(np.max(abs(h[core]/carrier[core]-1)))))
    csvout("clock-defect-"+panel+".csv",ledger)
    print(panel,{name:max(r[name] for r in ledger) for name in ("unrepaired","clock_only","corrected","clock_contribution","tabulated_kg_contribution","lookup_vs_carrier","friedmann_vs_carrier")})
if __name__=="__main__":run(sys.argv[1])

