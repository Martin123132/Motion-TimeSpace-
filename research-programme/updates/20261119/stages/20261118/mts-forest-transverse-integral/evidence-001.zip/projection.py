from local import *
from kernel import integrand
from scipy.integrate import simpson

def sample(panel,case,tag,arm):
    source=load(f"source-{panel}-{case}-{tag}.npz")
    gas=load(f"gas-{panel}-{case}-{tag}.npz")
    k=gas["k"];epoch=source["epochs"][-1]
    vh=source["h"][np.searchsorted(source["N"],epoch)]*SPEED
    entry=max(float(row["k_parent"]) for row in rows(POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv") if float(row["z"])==4.2)
    assert abs(entry/vh/.0794328-1)<2e-5
    data=gas[f"{arm}-1-2048-1"][-1];control=source["truth"][-1]
    d=.25*(entry/vh)**2*(2*1.380649e-23*1e4/(1.67262192369e-27*1e6))
    bare=integrand(k,4.2,vh,np.column_stack([k*0,k*0+1,k*0]),entry)/(2-.5*(.7+d))**2
    density=np.sqrt(bare)*(2-.5*(.7+d))*data[:,1]
    velocity=np.sqrt(bare)*(entry/k)**2*data[:,2]
    kernel=(density+velocity)**2
    canonical=integrand(k,4.2,vh,data,entry)
    if not np.allclose(kernel,canonical,rtol=2e-13,atol=1e-22):
        assert panel=="notch"
        rounding=32*np.finfo(float).eps*(abs(density)+abs(velocity))
        assert np.all(abs(kernel-canonical)<=rounding*(2*abs(density+velocity)+rounding))
    native=gas[("exact" if case=="heavy" else "cold")+"-0-2048-1"]
    return np.column_stack([k,density,velocity,kernel,integrand(k,4.2,vh,gas[arm+"-1-1024-1"][-1],entry),
        integrand(k,4.2,vh,gas[arm+"-1-2048-2"][-1],entry),
        np.max(abs(native-source["truth"])/np.maximum(np.max(abs(source["truth"]),axis=0)[None,:,:],1e-25),axis=(0,2)),source["constraint"]])

def ordered(*arrays):
    combined=np.vstack(arrays);out=combined[np.argsort(combined[:,0])]
    assert np.all(np.diff(out[:,0])>0)
    return out

def predict(data,nodes):
    x=np.log(data[:,0]);coord=np.log(nodes)
    assert min(coord)>x[0] and max(coord)<x[-1]
    power=PchipInterpolator(x,data[:,3])(coord)
    amplitude=PchipInterpolator(x,data[:,1]+data[:,2])(coord)
    return power,amplitude

def freeze(case,tag):
    guard();arms=["cold"] if case=="cold" else ["wave","off","exact"];ledger=[]
    for arm in arms:
        data=ordered(sample("mid",case,"225",arm),sample("quarter",case,"225",arm),sample("outer",case,tag,arm))
        assert np.array_equal(data[-12:,0],modes("outer"))
        mode=modes("outer-mid")
        power,amplitude=predict(data,mode)
        for loc,node in enumerate(mode):
            ledger.append(dict(arm=arm,k=node,integrand_kms=power[loc],signed_sqrt_kms=amplitude[loc],tag=tag))
    assert not (ROOT/f"source-outer-mid-{case}-{tag}.npz").exists()
    csvout(f"frozen-outer-mid-{case}-{tag}.csv",ledger)

def integral(data,lo,hi):
    x=np.log(data[:,0]);limits=np.log([lo,hi]);selection=(data[:,0]>=lo*(1-1e-13))&(data[:,0]<=hi*(1+1e-13))
    assert abs(x[selection][0]-limits[0])<1e-12 and abs(x[selection][-1]-limits[1])<1e-12
    def cubic(values):
        return float(PchipInterpolator(x,values).integrate(*limits))
    def product(left,right):
        lpoly=PchipInterpolator(x,left);rpoly=PchipInterpolator(x,right);nodes,weights=np.polynomial.legendre.leggauss(4)
        knots=x[selection];width=np.diff(knots)
        points=knots[:-1,None]+(nodes+1)*width[:,None]/2
        return float(np.sum(width[:,None]*weights*lpoly(points)*rpoly(points))/2)
    density,velocity=data[:,1:3].T
    area=cubic(data[:,3]);squared=product(density+velocity,density+velocity)
    auto_density=product(density,density);auto_velocity=product(velocity,velocity)
    return dict(primary=area,signed_field=squared,density_auto=auto_density,velocity_auto=auto_velocity,
        interference=2*product(density,velocity),
        simpson=float(simpson(data[selection,3],x=x[selection])),trap=float(np.trapezoid(data[selection,3],x=x[selection])),
        timestep=cubic(data[:,4])-area,source_stride=cubic(data[:,5])-area)
if __name__=="__main__":freeze(*sys.argv[1:])

