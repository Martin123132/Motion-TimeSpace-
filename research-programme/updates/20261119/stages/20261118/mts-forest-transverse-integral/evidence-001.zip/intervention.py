from local import *

def main(panel,case,tag):
    guard();root=ROOT/f"native-off-{panel}-{case}-{tag}"
    assert not root.exists()
    assert all(os.environ.get(key)==value for key,value in (("MTS_FOREST_INDEX","1"),("MTS_FOREST_SCALE","0.01"),("MTS_FOREST_FACTOR","0")))
    src=native("switch");prior=POST/"mts-forest-pressure-switch-20261118"
    assert sha(Path(src.camb.__file__).parent/"cambdll.dll")==read(prior/"build.json")["binary"]
    k=modes(panel);params=src.params_for(table(tag) if case=="heavy" else COLD)
    if case=="heavy":
        seed=load(f"seed-{panel}-{tag}.npz")
        assert np.all(seed["eligible"]) and np.array_equal(k,seed["k"])
        with np.load(table(tag)) as bg:
            params.DarkEnergy.matching_scale=float(bg["interface_a"]);params.DarkEnergy.matching_density=float(bg["rho_star"])
        params.DarkEnergy.heavy_exact_limit=max(.00028,float(seed["scale"])*1.012)
        params.DarkEnergy.set_table("SetMatching",k,seed["D"],seed["Q"])
    else:assert case=="cold"
    params.DoLateRadTruncation=False
    root.mkdir();os.chdir(root)
    engine=src.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6.4
    names=["a","H","etak","Weyl","v_newtonian_cdm","v_newtonian_baryon","delta_baryon","mts_match_count","mts_nonheavy_change"]
    tau=engine.conformal_time(Z,tol=1e-10)
    raw=engine.get_time_evolution(k,tau,vars=names,lAccuracyBoost=4)
    get=lambda key:raw[:,:,names.index(key)]
    assert np.isfinite(raw).all() and np.all(get("mts_match_count")==int(case=="heavy")) and np.all(get("mts_nonheavy_change")==0)
    assert len(list(root.glob("initial-*.bin")))==len(k)
    phi=get("etak")/k[:,None]+(get("H")/k[:,None])**2*get("v_newtonian_cdm")
    data=np.stack([k[:,None]**2*phi-2*get("Weyl"),get("delta_baryon")+3*(get("H")/k[:,None])**2*get("v_newtonian_cdm"),get("v_newtonian_baryon")],axis=2).transpose(1,0,2)
    gas=load(f"gas-{panel}-{case}-{tag}.npz")[("off" if case=="heavy" else "cold")+"-0-2048-1"]
    delta=(gas-data)/np.maximum(np.max(abs(data),axis=0),1e-30)
    save(root.name+"/result.npz",k=k,z=Z,raw=raw,names=names,off=data,difference=gas-data,scaled=delta)
    print(root.name,"field maxima",np.max(abs(delta),axis=(0,1)),flush=True)
if __name__=="__main__":main(*sys.argv[1:])

