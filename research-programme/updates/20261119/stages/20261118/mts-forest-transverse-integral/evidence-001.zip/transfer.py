from local import *
def run(panel,case,tag,selection):
    guard();src=native("source")
    active=modes(panel)
    if selection=="full":use=np.ones(len(active),bool)
    elif selection=="admitted":
        use=np.logical_and.reduce([load(f"seed-{panel}-{entry}.npz")["eligible"] for entry in read(f"pair-{panel}.json")["tags"]])
    else:raise ValueError(selection)
    if not any(use):raise ValueError("no eligible modes")
    k=active[use];heavy=case=="heavy"
    params=src.params_for(table(tag) if heavy else COLD,background_boost={"clock16":16.,"clock32":32.}.get(panel,8.))
    if heavy:
        seed=load(f"seed-{panel}-{tag}.npz");assert np.array_equal(seed["k"],active) and np.all(seed["eligible"][use])
        params.DarkEnergy.heavy_exact_limit=max(.00028,float(seed["scale"])*1.012)
        if tag not in ("200","225","250"):
            with np.load(table(tag)) as bg:
                params.DarkEnergy.matching_scale=float(bg["interface_a"]);params.DarkEnergy.matching_density=float(bg["rho_star"])
        source_k=k;density=seed["D"][use];momentum=seed["Q"][use]
        if panel=="overlap" and len(k)==3:
            neighbor=load(f"seed-outer-{tag}.npz")
            assert neighbor["k"][0]>k[-1] and neighbor["eligible"][0] and neighbor["scale"]==seed["scale"]
            source_k=np.r_[k,neighbor["k"][0]];density=np.r_[density,neighbor["D"][0]];momentum=np.r_[momentum,neighbor["Q"][0]]
        params.DarkEnergy.set_table("SetMatching",source_k,density,momentum)
    elif case=="lcdm":params.DarkEnergy=src.camb.dark_energy.DarkEnergyFluid()
    else:assert case=="cold"
    params.DoLateRadTruncation=False;model=src.camb.get_background(params);model.Params.Accuracy.IntTolBoost=6.4
    ef=np.unique(np.r_[np.linspace(-np.log(100),-np.log(5.2),4097),-np.log1p(Z)])
    times=model.conformal_time(np.expm1(-ef),tol=1e-10)
    cols=["a","H","etak","Weyl","delta_cdm","delta_baryon","v_newtonian_cdm","v_newtonian_baryon","mts_drho_h","mts_q_h","mts_dp_h","mts_drho_s","mts_q_s","delta_tot_de","delta_nonu","delta_tot","delta_nu","mts_match_count"]
    raw=model.get_time_evolution(k,times,vars=cols,lAccuracyBoost=4)
    val=lambda name:raw[:,:,cols.index(name)]
    scale=val("a")[0].copy();hub=val("H")[0].copy();mode=k[:,None]
    assert np.isfinite(raw).all() and np.all(val("mts_match_count")==heavy) and np.all(np.diff(scale)>0)
    thermal=model.get_background_time_evolution(times,vars=["cs2b","T_b","opacity"],format="dict")
    den=model.get_background_densities(scale,vars=["cdm","baryon","photon"])
    with np.load(table("225")) as original:rho=float(original["matching_density"]);mass=float(original["heavy_mass_mpc"])
    grav=np.array([den["cdm"]/scale**2,den["baryon"]/scale**2,rho/scale if heavy else np.zeros_like(scale)])/2
    cd=val("v_newtonian_cdm");eta=val("etak")/mode
    phi=eta+(hub/mode)**2*cd;force=mode**2*phi-2*val("Weyl")
    d=np.stack([val("delta_cdm")-3*eta,val("delta_baryon")-3*eta,val("mts_drho_h")*scale/rho-3*eta],axis=2)
    u=np.stack([cd,val("v_newtonian_baryon"),cd-mode*scale*val("mts_q_h")/(rho*hub)],axis=2)
    if not heavy:d[:,:,2]=0;u[:,:,2]=0
    ext=val("delta_tot_de")+(val("mts_drho_s")+3*hub*val("mts_q_s")/mode)/2
    slip=val("delta_nonu");phot=val("delta_nu")-4*hub*cd/(3*mode)
    internal=np.sum(grav.T[None,:,:]*(d+3*phi[:,:,None]-3*(hub/mode)[:,:,None]**2*u),axis=2)
    residual=np.max(abs(internal+ext+slip-force),axis=1)/np.max(abs(force),axis=1)
    assert np.max(residual)<2e-5
    anchors=np.array([np.argmin(abs(ef+np.log1p(z))) for z in Z])
    truth=np.stack([force[:,anchors],(d[:,:,1]+3*phi)[:,anchors],u[:,anchors,1]],axis=2).transpose(1,0,2)
    name=f"{panel}-{case}-{tag}"
    save("source-"+name+".npz",N=np.log(scale),a=scale,h=hub,k=k,mass=mass,g=grav,thermal=np.stack([thermal["cs2b"],thermal["T_b"],thermal["opacity"],den["photon"]/den["baryon"]],axis=-1),external=np.stack([ext,slip,val("delta_tot"),phot],axis=-1),init=np.column_stack([d[:,0],(scale[0]*hub[0]/mode**2)*u[:,0]]),epochs=np.log(scale[anchors]),constraint=residual,truth=truth)
    print(name,"sourced",len(k),"constraint",residual.max(),flush=True)
if __name__=="__main__":run(*sys.argv[1:])

