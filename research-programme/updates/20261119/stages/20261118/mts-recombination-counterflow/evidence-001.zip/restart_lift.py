from angular_lift import *
from support import Projection
from forward_bank import Future

def diagonal_table(limit):
    matrices=operators(limit,0)[:5];stride=limit+1;order=np.arange(stride)
    bands=np.zeros((5,5,stride))
    for pos,matrix in enumerate(matrices):
        for offset in range(-2,3):
            valid=(order+offset>=0)&(order+offset<stride);bins=order[valid]
            bands[pos,offset+2,bins]=matrix[bins,bins+offset].A1
    return np.ascontiguousarray(np.r_[MODE*order/(2*order+1),MODE*(order+1)/(2*order+1),bands.ravel()])

def ordinates(samples,nodes,limit):
    axes,weights=roots_legendre(len(nodes));assert np.max(abs(axes-nodes))<5e-15
    phases=(1j)**(np.arange(limit+1)%4)
    arr=samples@(legvander(nodes,limit)*weights[:,None]*phases/2)
    assert np.max(abs(arr.imag))<1e-10*max(1,np.max(abs(arr.real)))
    return arr.real

def lift(case,length,step,label):
    guard();proj=Projection(case);weights=Thermal(36,proj.track.nu_mass);stage2=Future(case)
    kernels,w=proj.kernel(.00015)
    op=diagonal_table(length);ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    lib=ctypes.CDLL(str(ROOT/'ray_transport.dll'));fun=lib.ray_integrate;fun.argtypes=[ctypes.c_int]*3+[ctypes.c_double]+[ptr]*7;fun.restype=ctypes.c_int
    nodes=weights.grid;shells=len(nodes)+1;degree=length+1
    with np.load(SOURCE/f'refined-{case}.npz') as early,np.load(LAST/f'fine-{case}.npz') as mid,np.load(LAST/f'forecast-carried-fine-{case}.npz') as late,np.load(LAST/f'start-{case}-0.npz') as start:
        axis=early['mu'];assert np.array_equal(nodes,early['thermal_q']) and np.array_equal(nodes,start['thermal_q'])
        state=np.zeros((3,shells,degree));state[:,:,:65]=ordinates(early['radiation_10.0'],axis,64)
        loops=[(early['times'],early['states'],early['report'],early['times'][0],kernels[-1],kernels,w,proj.track,start['rays']),
               (mid['times'],mid['states'],mid['report'],mid['times'][0],mid['times'][-1],[],[],proj.track,mid['rays_3']),
               (late['time'],late['states'],late['report'],late['time'][0],late['time'][-1],[],[],stage2,late['rays_3'])]
    clock_offset=loops[2][3]-loops[1][4]
    assert loops[1][3]==proj.time(.00015) and abs(clock_offset)<1e-6 and abs(stage2.physics(loops[2][3])[0]/proj.match-1)<1e-8
    metrics=[];records={};elapsed=clock.monotonic()
    for index,(old,core,diag,left,right,points,wgt,track,reference) in enumerate(loops):
        times=np.unique(np.r_[np.linspace(left,right,int(np.ceil((right-left)/step))+1),points]);runweight=np.zeros(len(times))
        if len(points):runweight[np.searchsorted(times,points)]=wgt
        both=np.empty(2*len(times)-1);both[::2]=times;both[1::2]=(times[:-1]+times[1:])/2
        phy=track.physics(both);time_source=CubicSpline(old,np.c_[core[:,1],diag[:,2]],axis=0,extrapolate=False)(both)
        a=phy[:,0];speed=np.c_[np.ones(len(a)),nodes/np.hypot(nodes,a[:,None]*weights.mass)]
        driver=np.ascontiguousarray(np.c_[phy[:,8],phy[:,11],-2*phy[:,7]+6*phy[:,12],-2*phy[:,12],time_source,speed])
        assert np.isfinite(driver).all()
        projected=np.zeros_like(state);code=fun(len(times),length,shells,MODE,times,driver,runweight,op,weights.ell.ravel(),state,projected)
        assert code==0 and np.isfinite(state).all()
        if len(points):state=projected
        base=ordinates(reference,axis,96);delta=state[:,:,:97]-base
        metrics.append(dict(peak_low_0_to_3_by_channel=np.max(abs(delta[:,:,:4]),axis=(1,2)).tolist(),peak_reference_low=np.max(abs(base[:,:,:4]),axis=(1,2)).tolist(),
            rms_bins_48_95=np.sqrt(np.mean(delta[:,:,48:96]**2,axis=(1,2))).tolist(),peak_of_last_six=np.max(abs(state[:,:,-6:]),axis=(1,2)).tolist()))
        records[f'match_{index}']=state.copy()
    store(f'rays-{label}-{case}.npz',mu=axis,q=nodes,case=case,length=length,step=step,matching_clock_rebase=clock_offset,metrics=json.dumps(metrics),times=np.array([loops[1][3],loops[2][3],loops[2][4]]),**records)
    print(case,label,round(clock.monotonic()-elapsed,1),'s',metrics[-1],flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('label');parser.add_argument('--length',type=int,required=True);parser.add_argument('--step',type=float,required=True)
    options=parser.parse_args()
    for case in ['heavy','cold']:lift(case,options.length,options.step,options.label)

