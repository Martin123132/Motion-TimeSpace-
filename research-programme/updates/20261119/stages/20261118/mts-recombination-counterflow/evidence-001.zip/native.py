from common import *
from forward_bank import MODE_NAMES,Future
def run(case):
    guard();sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    params=params_for(PROJ if case=='heavy' else EARLY/'cold.npz')
    params.DoLateRadTruncation=False
    engine=camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6
    z=np.array([3999.,3500.,3000.,2500.,2100.,1800.,1600.,1400.,1200.,1100.,1050.,1000.,900.,800.,600.,400.,199.,99.])
    its=engine.conformal_time(z,tol=1e-10)
    native=np.unique(np.r_[its,np.linspace(its[0],its[-1],int(np.ceil((its[-1]-its[0])/.10))+1)])
    ref=Future(case);time=ref.t[-2]+(native-its[0])
    vals=engine.get_time_evolution([MODE],native,vars=MODE_NAMES,lAccuracyBoost=16)[0]
    control_ix=np.unique(np.r_[np.arange(0,len(time),9),len(time)-1,np.searchsorted(native,its)])
    lower=engine.get_time_evolution([MODE],native[control_ix],vars=MODE_NAMES,lAccuracyBoost=4)[0]
    val=lambda name:vals[:,MODE_NAMES.index(name)]
    a=val('a');bg=engine.get_background_densities(a,['cdm','baryon','photon','neutrino','nu'])
    cdm,bary,phot,rel,neut=(bg[key]/a**2 for key in ('cdm','baryon','photon','neutrino','nu'))
    frac=bary/(cdm+bary)
    rate=val('H')*val('growth')*((1-frac)*val('delta_cdm')+frac*val('delta_baryon'))+frac*MODE*val('v_baryon_cdm')
    with np.load(PROJ) as proj:mass=float(proj['heavy_mass_mpc']);norm=float(proj['matching_density'])
    zero=np.zeros_like(a)
    phy=np.stack([a,val('H'),cdm,bary,phot,rel,neut,val('delta_cdm'),rate,val('delta_baryon'),val('v_baryon_cdm'),
                  -val('H')*val('v_newtonian_cdm'),val('etak')/MODE,zero,zero,(a*mass)**2,zero,zero],axis=1)
    thermo=engine.get_background_time_evolution(native,['opacity','visibility','x_e','T_b','cs2b'])
    assert np.isfinite(vals).all() and np.all(val('mts_match_count')==int(case=='heavy')) and np.min(thermo['opacity'])>0
    with np.load(SOURCE/(case+'-ionization.npz')) as src:he=float(src['helium_by_number'])
    meta=dict(T0=params.TCMB,H0=params.H0,ombh2=params.ombh2,YHe=params.YHe,helium_by_number=he,fu=params.Recomb.RECFAST_fudge,
              helium_fudge=params.Recomb.RECFAST_fudge_He,helium_switch=params.Recomb.RECFAST_Heswitch,H_switch=params.Recomb.RECFAST_Hswitch)
    store('history-'+case+'.npz',time=time,native_time=native,redshift=z,anchors=ref.t[-2]+(its-its[0]),phy=phy,raw=vals,raw_names=np.array(MODE_NAMES),
          norm=norm,comparison_ix=control_ix,usual=lower,**thermo)
    save('native-'+case+'.json',meta);print(case,len(time),meta,'visibility peak z',1/a[np.argmax(thermo['visibility'])]-1,flush=True)
if __name__=='__main__':
    for case in ('heavy','cold'):run(case)

