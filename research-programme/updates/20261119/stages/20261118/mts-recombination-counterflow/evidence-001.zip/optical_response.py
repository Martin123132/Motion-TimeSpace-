from common import *
import argparse,ctypes,time as clock
from angular import Thermal
from support import FullTrack
from scipy.special import eval_legendre,gammaln,lpmv,roots_legendre

def spin_map(limit=12):
    axis,weights=roots_legendre(2*limit+8);orders=np.arange(limit+1)
    scalar=np.array([eval_legendre(ell,axis) for ell in orders])
    spin=np.zeros_like(scalar)
    for ell in orders[2:]:spin[ell]=np.exp(.5*(gammaln(ell-1)-gammaln(ell+3)))*lpmv(2,ell,axis)
    def mapping(target,source):
        phases=1j**orders[:,None]*(-1j)**orders
        raw=(target*weights/2)@source.T*(2*orders+1)*phases
        assert np.max(abs(raw.imag))<1e-12
        return raw.real
    return mapping(spin,scalar),mapping(scalar,spin)

def field(case,tag):
    with np.load(ROOT/f'history-{case}.npz') as bank:
        phy=bank['phy'];time=bank['time'];anchor=bank['anchors'];norm=float(bank['norm']);cap=bank['opacity'];sound=bank['cs2b']
        raw=bank['raw'];names=bank['raw_names'].tolist()
    kinetic=np.load(ROOT/f'kinetic-{tag}-{case}.npz');fraction=kinetic['values'][:,6]/kinetic['values'][:,2]
    extra=np.interp(np.log(phy[:,0]),kinetic['N'],fraction)
    grid=CubicSpline(time,np.column_stack([phy[:,1:5],phy[:,8],phy[:,11],phy[:,10],cap,extra,phy[:,0]/norm,phy[:,15],sound,phy[:,0],phy[:,5:7]]),axis=0,extrapolate=False)
    return time,anchor,grid,raw,names,norm

def advance(case,tag,length,order,max_step,label,gas=False,zero=False):
    guard();out_path=ROOT/f'response-{label}-{case}.npz'
    if out_path.exists():raise FileExistsError(out_path)
    time,anchors,curve,raw,names,norm=field(case,tag);mode=np.arange(length+1)
    times=[time[0]]
    for target in anchors[1:]:
        while times[-1]<target:
            hub,cdm,bary,phot,rate,shear,flow,cap,*rest=curve(times[-1])
            times.append(min(target,times[-1]+min(max_step,1.3/(cap*(1+4*phot/(3*bary))))))
    times=np.array(times);evals=np.empty(2*len(times)-1);evals[::2]=times;evals[1::2]=(times[1:]+times[:-1])/2
    vals=curve(evals);hc=curve(evals,1)[:,0];a=vals[:,12];mass=FullTrack(case).nu_mass
    thermal=Thermal(order,mass);energy=np.hypot(thermal.grid,a[:,None]*mass);speed=np.c_[np.ones(len(a)),thermal.grid/energy]
    measures=thermal.base*energy;weights=np.c_[4*vals[:,13],vals[:,14,None]*thermal.gradient*measures/measures.sum(axis=1)[:,None]]
    if zero:vals[:,8]=0
    table=np.ascontiguousarray(np.c_[vals[:,:11],hc,vals[:,11]*int(gas),speed,.5*(1+speed**2)*weights,weights*speed,weights])
    up=lambda spin:MODE*np.sqrt(np.maximum(mode**2-spin**2,0))/(2*mode+1)
    down=lambda spin:MODE*np.sqrt(np.maximum((mode+1)**2-spin**2,0))/(2*mode+1)
    ops=np.array([up(0),down(0),up(2),down(2)])
    rotation=eval_legendre(mode,.5);stride=length+1;shells=order+1
    with np.load(LAST/f'forward-bank-matched-{case}.npz') as history:
        incoming=CubicSpline(history['time'],history['photon'],axis=0)(time[0])[4:]
    vec=np.zeros(7+(4+shells)*stride);vec[7:20]=incoming[:13];vec[7+stride:20+stride]=spin_map()[0]@incoming[13:]
    rows=np.empty((len(times),34+2*shells))
    library=ctypes.CDLL(str(ROOT/'response.dll'));ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
    library.integrate.argtypes=[ctypes.c_int]*3+[ctypes.c_double,ctypes.c_int]+[ptr]*6;library.integrate.restype=ctypes.c_int
    start=clock.monotonic();code=library.integrate(len(times),length,shells,MODE,int(case=='heavy'),times,table,ops,rotation,vec,rows)
    assert code==0 and np.all(np.isfinite(rows)) and np.all(np.isfinite(vec))
    digest_inputs={path.name:digest(path) for path in [ROOT/'response.dll',ROOT/'response.c',ROOT/f'history-{case}.npz',ROOT/f'kinetic-{tag}-{case}.npz',LAST/f'forward-bank-matched-{case}.npz']}
    store(out_path.name,time=times,anchor_indices=np.searchsorted(times,anchors),history=rows,last=vec,order=order,length=length,max_step=max_step,tag=tag,gas=gas,zero=zero,
          columns=np.array(['log_cdm','expansion','heavy_energy','heavy_current','log_baryon','baryon_current','curvature','shear','active_nu','nu_flux','pressure','net_drag','opacity_source','nu_energy','hamiltonian','exchange_residual','expansion_prime','baryon_current_prime']+[f'{channel}{ell}' for channel in ['in_I','in_P','delta_I','delta_P'] for ell in range(4)]+[f'nu_{shell}_{ell}' for shell in range(shells) for ell in (0,1)]),
          source_hashes=json.dumps(digest_inputs))
    print(case,label,len(times),round(clock.monotonic()-start,2),'s; final',rows[-1,:7],'; exchange',max(abs(rows[:,15])),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('label');parser.add_argument('--case',choices=['both','cold','heavy'],default='both')
    parser.add_argument('--length',type=int,required=True);parser.add_argument('--order',type=int,required=True)
    parser.add_argument('--step',type=float,required=True);parser.add_argument('--chem',default='local');parser.add_argument('--gas',action='store_true');parser.add_argument('--zero',action='store_true')
    opt=parser.parse_args()
    for case in (['heavy','cold'] if opt.case=='both' else [opt.case]):advance(case,opt.chem,opt.length,opt.order,opt.step,opt.label,opt.gas,opt.zero)

