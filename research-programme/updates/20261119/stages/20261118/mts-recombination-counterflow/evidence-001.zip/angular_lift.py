from optical_response import *
from scipy.sparse import diags,eye,block_diag,csr_matrix
from angular import Sphere
from numpy.polynomial.legendre import legvander

def operators(limit,spin):
    size=limit+4;axis=np.arange(size);rows=2*axis+1
    side=np.sqrt(np.maximum(axis**2-spin**2,0));next_side=np.sqrt(np.maximum((axis+1)**2-spin**2,0))
    left=(side/rows)[1:];right=(next_side/rows)[:-1]
    xpos=diags([left,right],[-1,1],shape=(size,size),format='csr')
    deriv=diags([-axis[:-1]*left,(axis[1:]+1)*right],[-1,1],shape=(size,size),format='csr')
    rot=diags(eval_legendre(axis,.5),format='csr')
    wx=xpos@rot-rot@xpos
    wx2=xpos@xpos@rot-2*xpos@rot@xpos+rot@xpos@xpos
    grad=deriv@rot-rot@deriv
    wgrad=xpos@grad-grad@xpos+MU*rot-xpos@rot@xpos+rot@xpos@xpos
    def phase(matrix,factor=1):
        matrix=matrix[:limit+1,:limit+1].tocoo()
        vals=matrix.data*(1j**((matrix.row-matrix.col)%4))*factor
        if spin:vals[(matrix.row<spin)|(matrix.col<spin)]=0
        assert np.max(abs(vals.imag),initial=0)<1e-11
        out=csr_matrix((vals.real,(matrix.row,matrix.col)),shape=(limit+1,limit+1));out.eliminate_zeros();return out
    return [phase(.5*MODE*MU*wx,1j),phase(.5*MODE*(rot@xpos-grad),1j),phase(.5*wgrad),phase(.5*wx2),phase(.5*rot),phase(wx,-1j),phase(-rot)]

def scalar_geo(row,fields,spectral,ell,speed,coef):
    first,second,slope,trace=coef
    return (speed[:,None]*(first*(row[0]@fields.T).T+second*(row[1]@fields.T).T)+
        slope*((row[2]@fields.T).T+(row[3]@(ell*fields+spectral).T).T)+trace*(row[4]@(ell*fields+spectral).T).T)

def photon_ops(limit):
    scalar,spin=[operators(limit,s) for s in [0,2]];both=[block_diag((s,p),format='csr') for s,p in zip(scalar,spin)]
    ge=[both[0],both[1],both[2]-4*both[3],-4*both[4]]
    with np.load(SOURCE/'screen-12.npz') as basis:
        forward,back=spin_map();into=block_diag((np.eye(13),forward)).toarray();frm=block_diag((np.eye(13),back)).toarray()
        slots=np.r_[0:13,limit+1:limit+14]
        def add_low(index,name):
            old=into@basis[name]@frm
            gap=old-both[index][slots][:,slots].toarray()
            keep=np.r_[0:9,13:22]
            absent=np.r_[9:13,22:26];high=np.max(abs(gap[np.ix_(keep,absent)]))
            assert high<1e-10,(name,high)
            fix=gap[np.ix_(keep,keep)]
            assert max(np.max(abs(fix[4:9])),np.max(abs(fix[13:18])))<1e-10
            off1,off2=np.where(abs(fix)>1e-12)
            return both[index]+csr_matrix((fix[off1,off2],(slots[keep[off1]],slots[keep[off2]])),shape=both[index].shape)
        coll=[add_low(5,'velocity_matrix'),add_low(6,'opacity_matrix')]
        constants=np.zeros((2,2*(limit+1)));constants[:,slots]=[into@basis[key] for key in ('bulk','opacity_bulk')]
    return ge,coll,constants

def check():
    rng=np.random.default_rng(6618);limit=23;row=operators(limit,0);sphere=Sphere(38,56)
    phys=rng.normal(size=(4,limit+1));spec=rng.normal(size=phys.shape);phys[:,15:]=0;spec[:,15:]=0
    vel=np.array([1,.98,.78,.32]);ell=np.array([-4,-1,1,-9.])[:,None];coeff=rng.normal(size=4)
    axis=sphere.axis;degree=np.arange(limit+1);source=legvander(axis,limit)*((-1j)**degree*(2*degree+1))
    relative=sphere.bilinear(phys@source.T,spec@source.T,vel[:,None],*coeff,ell)
    target=(relative@(legvander(axis,limit)*sphere.weights[:,None]*(1j)**degree)).real
    nu_error=float(np.max(abs(target-scalar_geo(row,phys,spec,ell,vel,coeff))))
    ge,co,constant=photon_ops(36);forward,back=spin_map();slots=np.r_[0:13,37:50]
    into=block_diag((np.eye(13),forward)).toarray();frm=block_diag((np.eye(13),back)).toarray()
    seed=np.zeros(74);seed[np.r_[0:8,39:45]]=rng.normal(size=14)
    with np.load(SOURCE/'screen-12.npz') as bank:
        old=frm@seed[slots]
        ge_error=[max(abs(matrix@seed)[np.r_[13:37,50:74]]) for matrix in ge]
        ge_points=[max(abs((matrix@seed)[slots]-into@raw@old)) for matrix,raw in zip(ge,bank['geo'])]
        co_points=[max(abs((matrix@seed)[slots]-into@bank[name]@old)) for matrix,name in zip(co,['velocity_matrix','opacity_matrix'])]
    return dict(scalar_neutrino_error=nu_error,photon_geodesic_errors=ge_points,photon_exterior=ge_error,photon_collision_errors=co_points)
if __name__=='__main__':
    guard();packet=check();print(packet);assert max([packet['scalar_neutrino_error']]+packet['photon_geodesic_errors']+packet['photon_exterior']+packet['photon_collision_errors'])<1e-9
    save('angular-lift.json',packet)

