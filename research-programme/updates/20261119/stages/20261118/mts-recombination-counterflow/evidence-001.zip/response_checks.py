from optical_response import *
from scipy.integrate import cumulative_simpson,simpson,solve_ivp
from scipy.special import spherical_jn

TARGET=ROOT.parent/'mts-two-mode-response-20261118'
def operator():
    rng=np.random.default_rng(4129);spin,back=spin_map();rotation=eval_legendre(np.arange(13),.5)
    with np.load(SOURCE/'screen-12.npz') as bank:
        errors=[]
        for idx in range(8):
            first=rng.normal(size=13);pol=np.r_[0.,0.,rng.normal(size=11)];flow=rng.normal();ordinary=back@pol
            pi=first[2]-np.sqrt(6)*pol[2];ct=-first;ct[0]=0;ct[1]+=4*flow/3;ct[2]+=pi/10
            cp=-pol;cp[2]-=np.sqrt(6)*pi/10
            screen=bank['opacity_bulk']*flow+bank['opacity_matrix']@np.r_[first,ordinary]
            errors.append(max(abs(screen-np.r_[rotation*ct,back@(rotation*cp)])))
    return max(errors)
def project(case,tag):
    sealed=load(TARGET/'closeout.json')['files']
    for key in [f'early-{case}.npz','initial-state-requirement.json']:assert digest(TARGET/key)==sealed[key]
    with np.load(ROOT/f'response-{tag}-{case}.npz') as packet:row=packet['history'][-1]
    with np.load(ROOT/f'history-{case}.npz') as bank:
        phy=bank['phy'][-1];h=phy[1];end=phy[0];current_time=bank['time'][-1]
    transform=row[7]/MODE**2
    dust=np.array([row[0],row[4]]+([row[2]] if case=='heavy' else []))
    motion=np.array([0.,row[5]]+([row[3]] if case=='heavy' else []))
    projected=np.r_[dust-3*h*transform,-MODE*(motion+MODE*transform)/h]
    with np.load(TARGET/f'early-{case}.npz') as bank:
        idx=np.where(np.isclose(bank['k'],MODE,atol=1e-13,rtol=0))[0].item()
        frac=bank['rho0']/sum(bank['rho0']);ns=len(frac);assert abs(end-.01)<1e-11 and abs(bank['N'][0]+np.log(100))<1e-13
        linear=bank['D'][:,idx,0]@frac;epoch=bank['N']
        final_linear=CubicSpline(epoch,frac@bank['D'][:,idx,:])(-np.log(9))
        hub=CubicSpline(epoch,np.log(bank['H']));source=bank['rho0'];press=np.zeros(ns);
        if ns==3:press[-1]=1/float(bank['mass'])**2
    fixed=load(TARGET/'initial-state-requirement.json')['response_row'];adj=np.asarray(fixed[:6] if ns==3 else fixed[6:])* (1 if ns==3 else -1)
    def forward(efold,vec):
        amp=np.exp(efold);H=np.exp(hub(efold));rho=source/(2*amp**3*H**2)
        return np.r_[vec[ns:],rho@vec[:ns]-(2+hub(efold,1))*vec[ns:]-press*MODE**4*vec[:ns]/(4*amp**4*H**2)]
    answer=solve_ivp(forward,(epoch[0],-np.log(9)),projected,method='DOP853',rtol=1e-11,atol=1e-14,max_step=.035)
    assert answer.success
    return dict(projected=projected.tolist(),linear_start=linear,linear_end=float(final_linear),shear=row[7],time_shift=transform,
        Q_from_frozen_row=float(adj@projected/linear**2),Q_forward=float(2*(frac@answer.y[:ns,-1])/final_linear**2),
        contributions=(adj*projected/linear**2).tolist(),z99_state=row[:7].tolist())
def rays(case):
    with np.load(ROOT/f'response-thermal-{case}.npz') as bank:times=bank['time'];hist=bank['history'];anchors=bank['anchor_indices']
    with np.load(ROOT/f'history-{case}.npz') as bank:scale=CubicSpline(bank['time'],bank['phy'][:,0]);red=bank['redshift']
    thermal=Thermal(36,FullTrack(case).nu_mass);sources=CubicSpline(times,hist[:,[1,7]],axis=0)
    rows=[]
    for epoch in (1600,1100,800,199,99):
        pos=anchors[red.tolist().index(epoch)];stop=times[pos];trials=[]
        for dt in (.16,.08):
            grid=np.linspace(times[0],stop,2*int(np.ceil((stop-times[0])/(2*dt)))+1)
            a=scale(grid)[:,None];vel=np.c_[np.ones(len(a)),thermal.grid/np.hypot(thermal.grid,thermal.mass*a)]
            dist=cumulative_simpson(vel,x=grid,axis=0,initial=0);x=MODE*(dist[-1]-dist)
            clock,shear=sources(grid).T
            mono=simpson((clock[:,None]*spherical_jn(0,x)+2*shear[:,None]*spherical_jn(2,x))/3,x=grid,axis=0)
            dip=simpson((clock[:,None]*spherical_jn(1,x)-2*shear[:,None]*spherical_jn(2,x,derivative=True))/3,x=grid,axis=0)
            trials.append(np.array([mono,dip]).T)
        ref=hist[pos,34:].reshape(-1,2)
        rows.append(dict(z=epoch,max_absolute=np.max(abs(trials[-1]-ref),axis=0).tolist(),peak_signal=np.max(abs(ref),axis=0).tolist(),
            grid_difference=np.max(abs(trials[-1]-trials[0]),axis=0).tolist()))
    return rows
def assert_all():
    guard();out=dict(screen_real_space_error=operator(),branches={})
    assert out['screen_real_space_error']<1e-10
    for case in ('heavy','cold'):
        with np.load(ROOT/f'response-thermal-{case}.npz') as sample:
            times=sample['time'];hist=sample['history'];slots=sample['anchor_indices'];base=hist[slots]
        with np.load(ROOT/f'history-{case}.npz') as native:
            raw=CubicSpline(native['time'],native['raw'][:,8:11],axis=0)(times)
            beta=raw-hist[:,18:21];native_compare=(np.max(abs(beta),axis=0)/np.max(abs(raw),axis=0)).tolist()
            usual=(np.max(abs(native['usual'][:,8:11]-native['raw'][native['comparison_ix'],8:11]),axis=0)/np.max(abs(raw),axis=0)).tolist()
            shear=hist[:,7];terms=np.c_[4*MODE**2*hist[:,6],4*np.interp(times,native['time'],native['phy'][:,1])*hist[:,1]]
        outcomes={};shifts={}
        for tag in ['zero','short','angular','deep','fine','thermal','barotropic','escape']:
            with np.load(ROOT/f'response-{tag}-{case}.npz') as saved:
                anchor=saved['history'][saved['anchor_indices']]
                if tag=='zero':assert np.count_nonzero(saved['history'][:,:18])==0 and np.count_nonzero(saved['history'][:,26:])==0
                outcomes[tag]=project(case,tag)
                shifts[tag]=np.max(abs(anchor[:,:16]-base[:,:16]),axis=0).tolist()
                assert abs(outcomes[tag]['Q_from_frozen_row']-outcomes[tag]['Q_forward'])<1e-11
        out['branches'][case]=dict(native_peak_normalized_I012=native_compare,native_angular_control_I012=usual,
            endpoint=outcomes,anchor_differences_from_thermal=shifts,characteristic_check=rays(case),exchange_residual=max(abs(hist[:,15])),
            maximum_constraint_relative_to_peak_metric=np.max(abs(hist[:,14]))/np.max(np.sum(abs(terms),axis=1)),names='ionization-dependent response only')
    out['contrasts']={tag:out['branches']['heavy']['endpoint'][tag]['Q_forward']-out['branches']['cold']['endpoint'][tag]['Q_forward'] for tag in outcomes}
    print(out['contrasts'])
    for case,d in out['branches'].items():print(case,d['native_peak_normalized_I012'],d['maximum_constraint_relative_to_peak_metric'],d['characteristic_check'][-1],d['endpoint']['thermal'])
    save('response-validation.json',out)
if __name__=='__main__':assert_all()

