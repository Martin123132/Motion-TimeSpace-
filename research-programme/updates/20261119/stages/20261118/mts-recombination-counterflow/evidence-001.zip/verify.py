from common import *
from response_checks import TARGET,operator

def evidence():
    guard()
    checks={}
    def take(key,predicate):
        checks[key]=bool(predicate)
        if not checks[key]:raise ValueError(key)
    chem=load(ROOT/'chemistry-budget.json');resp=load(ROOT/'response-validation.json');gauge=load(ROOT/'absolute-slicing.json')
    local=load(ROOT/'angular-lift.json')
    for script in ROOT.glob('*.py'):compile(script.read_bytes(),str(script),'exec')
    take('closed_saved_screen_matches_angular_operator',max(local['photon_geodesic_errors']+local['photon_collision_errors'])<1e-10 and local['scalar_neutrino_error']<1e-10 and operator()<1e-10)
    for case in ('heavy','cold'):
        row=resp['branches'][case];ion=chem[case];other=load(LAST/'gauge-current.json');old=load(LAST/'gauge-pair.json')
        take(case+' paired_chemistry',ion['background_peak_fractional']<.003 and ion['direct']['half']['visibility_weighted_fractional_response_error']<3e-5 and ion['direct']['large']['visibility_weighted_fractional_response_error']<1e-4)
        for tag,vals in row['endpoint'].items():
            take(case+' forward_kernel_'+tag,abs(vals['Q_forward']-vals['Q_from_frozen_row'])<1e-12)
            with np.load(ROOT/f'response-{tag}-{case}.npz') as src:
                for key,want in json.loads(str(src['source_hashes'])).items():
                    path=ROOT/key if (ROOT/key).is_file() else LAST/key
                    take(case+' input '+key,digest(path)==want)
        take(case+' photon_and_gravity',max(row['native_peak_normalized_I012'])<.0006 and row['maximum_constraint_relative_to_peak_metric']<1e-7 and row['exchange_residual']<1e-18)
        take(case+' free_streaming',all(np.max(np.array(ref['max_absolute'])/np.array(ref['peak_signal']))<2e-5 for ref in row['characteristic_check']))
        take(case+' null',np.count_nonzero(row['endpoint']['zero']['projected'])==0)
        loc=row['endpoint']['thermal']['Q_forward']
        take(case+' resolution',all(abs(row['endpoint'][tag]['Q_forward']-loc)<1e-11 for tag in ['angular','deep','fine']))
        for idx,test in enumerate(gauge[case]):
            take(case+f' pullback {idx}',max(abs(np.array(test['direct_minus_predicted'])))<2e-6 and min(abs(np.array(test['no_common_generator_scalar_metric_and_shift'])))>.1)
            if case=='heavy':
                diff=np.array(test['predicted']['heavy'])-np.array(test['predicted']['cdm'])
                take(f'earlier independent relative energy and velocity {idx}',abs(diff[0]-old[case][idx]['newtonian_relative'])<2e-10 and abs(diff[1]-other[case][idx]['newtonian_energy_frame_relative_velocity'])<2e-10)
        with np.load(ROOT/f'rays-refined-{case}.npz') as high,np.load(ROOT/f'rays-carry-{case}.npz') as low:
            metrics=json.loads(str(high['metrics']))[-1]
            take(case+' angular_restart',max(metrics['peak_low_0_to_3_by_channel'])<1e-6 and max(metrics['peak_of_last_six'])<1e-15 and high['match_2'].shape==(3,37,281) and np.max(abs(high['match_2'][:,:,:4]-low['match_2'][:,:,:4]))<2e-5)
    return checks

def inputs():
    refs=[LAST/'closeout.json',SOURCE/'closeout.json',TARGET/'closeout.json',PROJ,EARLY/'heavy.npz',EARLY/'cold.npz',MATCH/'native/camb/cambdll.dll',MATCH/'native/fortran/recfast.f90',MATCH/'matching_common.py',
        SOURCE/'screen-12.npz',TARGET/'initial-state-requirement.json',LAST/'gauge-pair.json',LAST/'gauge-current.json']
    from support import PRIOR,OLD
    for case in ('heavy','cold'):
        refs.extend([LAST/f'{name}-{case}.npz' for name in ['forecast-carried-fine','forward-bank-matched','fine']]+[LAST/f'start-{case}-0.npz',TARGET/f'early-{case}.npz',SOURCE/f'refined-{case}.npz',SOURCE/f'{case}-ionization.npz',SOURCE/f'{case}-linear-tail.npz',PRIOR/f'{case}-sources.npz',PRIOR/f'{case}-thomson.npz',OLD/f'{case}-native.npz'])
    refs.extend([LAST/f'{name}.py' for name in ['support','forward_bank','model']]+[SOURCE/f'{name}.py' for name in ['common_local','linear_tail','photon_source']]+[PRIOR/'angular.py'])
    return {str(path):digest(path) for path in refs}

if __name__=='__main__':
    checks=evidence();source=inputs()
    if '--seal' in sys.argv:
        save('validation.json',checks)
        files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='closeout.json'}
        save('closeout.json',dict(files=files,source_inputs=source,kind='local effective recombination; isolated physical response and absolute gauge map; angular restarts'))
    sealed=load(ROOT/'closeout.json')
    assert set(sealed['files'])=={p.name for p in ROOT.iterdir() if p.is_file() and p.name!='closeout.json'}
    assert all(digest(ROOT/name)==want for name,want in sealed['files'].items()) and sealed['source_inputs']==source and load(ROOT/'validation.json')==checks
    print('Verified',len(checks),'checks,',len(sealed['files']),'local files,',len(source),'source inputs. Closeout:',digest(ROOT/'closeout.json'))

