from pathlib import Path
import sys,json
ROOT=Path(__file__).resolve().parent
LAST=ROOT.parent/'mts-active-stress-junction-20261118'
sys.path.insert(0,str(LAST))
from support import MODE,MU,np,CubicSpline,PROJ,EARLY,load,digest,SOURCE
from histories import MATCH
def guard():
    assert digest(LAST/'closeout.json')=='7dde68714a837b21cb83d579b55f9118dc536eb2a8ca3f69e8a476c336f2facc'
    assert not any((base/'STOP-REQUESTED').exists() for base in (ROOT,ROOT.parent,LAST,SOURCE))
def save(name,data):
    with (ROOT/name).open('x',encoding='utf8') as stream:json.dump(data,stream,indent=2,allow_nan=False)
def store(name,**values):
    with (ROOT/name).open('xb') as stream:np.savez_compressed(stream,**values)

