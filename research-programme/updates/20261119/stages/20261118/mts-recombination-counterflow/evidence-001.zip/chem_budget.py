from common import *

def check(case):
    bank=np.load(ROOT/f'history-{case}.npz')
    local=np.load(ROOT/f'kinetic-local-{case}.npz')
    grid=local['N'];values=local['values'];tangent=values[:,4:];z=np.exp(-grid)-1
    native_grid=np.log(bank['phy'][:,0])
    visibility=np.interp(grid,native_grid,bank['visibility']);xe=np.interp(grid,native_grid,bank['x_e'])
    time=np.interp(grid,native_grid,bank['time']);peak=np.argmax(visibility);fraction=tangent[:,2]/values[:,2]
    def read(tag):
        with np.load(ROOT/f'kinetic-{tag}-{case}.npz') as ion:
            arr=ion['values'];ni=ion['N']
            return arr if np.array_equal(ni,grid) else np.column_stack([np.interp(grid,ni,col) for col in arr.T])
    def weighted(quantity):
        return float(np.sqrt(np.trapezoid(quantity**2*visibility,time)/np.trapezoid(visibility,time)))
    budget={}
    for tag,pos,neg in [('large','plus','minus'),('half','p_half','m_half')]:
        with np.load(ROOT/f'kinetic-{pos}-{case}.npz') as p,np.load(ROOT/f'kinetic-{neg}-{case}.npz') as m:
            eps,emin=p['options'][0],m['options'][0];assert eps==-emin and eps>0
        deriv=(read(pos)-read(neg))/(2*eps)
        diff=(deriv[:,2]-tangent[:,2])/values[:,2]
        budget[tag]=dict(epsilon=eps,peak_normalized_component_error=(np.max(abs(deriv-tangent),axis=0)/np.max(abs(tangent),axis=0)).tolist(),
            visibility_weighted_fractional_response_error=weighted(diff)/weighted(fraction),peak_absolute_fractional_response_error=max(abs(diff)))
    variants={}
    for tag in ['no_escape_velocity','matter_photo','switch']:
        control=read(tag);delta=control[:,6]/control[:,2]-fraction
        variants[tag]=dict(peak_difference=max(abs(delta)),visibility_rms_relative=weighted(delta)/weighted(fraction),difference_at_peak=delta[peak])
    samples=[]
    for red in bank['redshift']:
        idx=np.argmin(abs(z-red));samples.append(dict(z=z[idx],hydrogen_response=tangent[idx,0],helium_response=tangent[idx,1],
            fractional_xe=fraction[idx],baryon_density=np.interp(grid[idx],native_grid,bank['phy'][:,9]),xe=values[idx,2],native=xe[idx]))
    native_temp=np.interp(grid,native_grid,bank['T_b']);temp=load(ROOT/f'native-{case}.json')['T0']*np.exp(-grid)*values[:,3]
    return dict(steps=len(grid),z_visibility=z[peak],free_electrons_at_peak=values[peak,2],fractional_response_at_peak=fraction[peak],
        peak_fractional_response=max(abs(fraction)),background_peak_absolute=max(abs(values[:,2]-xe)),
        background_peak_fractional=max(abs(values[:,2]/xe-1)),background_gas_temperature_peak_fractional=max(abs(temp/native_temp-1)),
        visibility_rms_response=weighted(fraction),direct=budget,alternatives=variants,samples=samples)
if __name__=='__main__':
    guard();result={case:check(case) for case in ['heavy','cold']};save('chemistry-budget.json',result)
    for case,row in result.items():print(case,{key:val for key,val in row.items() if key!='samples'})

