from common import *
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
MPC=3.085677581e22
LIGHT=299792458.
PLANCK=6.62607015e-34
BOLTZ=1.380649e-23
ME=9.1093837015e-31
MH=1.673575e-27
GRAV=6.67430e-11
THOMSON=6.6524587321e-29
HEL_R=3.9715
HC=PLANCK*LIGHT/BOLTZ
PHASE=2*np.pi*ME*BOLTZ/PLANCK**2
COMPTON=8*THOMSON/(3*ME*LIGHT)*(8*np.pi**5*BOLTZ**4/(15*LIGHT**3*PLANCK**3))
HION=1.096787737e7;LYA=8.225916453e6
HEION=1.98310772e7;HE2S=1.66277434e7;HE2P=1.71134891e7
TRIP=1.690871466e7;TRIPS=1.5985597526e7;TRIPION=3.8454693845e6

def equilibrium(temp,n,helium):
    stat=(PHASE*temp)**1.5/n
    rh=stat*np.exp(-HC*HION/temp)
    neutral=2/(2+rh+np.sqrt(rh*rh+4*rh))
    rh4=4*stat*np.exp(-HC*HEION/temp)
    he=2*rh4/(1+rh4+np.sqrt((1+rh4)**2+4*helium*rh4))
    return 1-neutral,neutral,he

def escape(rate,line,sigma,atom,temp,nhe,neutral_he,neutral_h,h_local,triplet):
    tau=3*rate*nhe*neutral_he/(8*np.pi*h_local*line**3)
    sob=-np.expm1(-tau)/tau
    width=LIGHT*line*np.sqrt(2*BOLTZ*temp/(MH*atom*LIGHT**2))
    amp=3*rate*neutral_he/(np.sqrt(np.pi)*sigma*8*np.pi*width*line**2)
    return rate*(sob+1/(1+(.66 if triplet else .36)*amp**(.9 if triplet else .86)/neutral_h**(.9 if triplet else .86))/(3 if triplet else 1))

class Chemistry:
    def __init__(self,case,end=99,knob='local',switch=.99):
        self.case=case;self.knob=knob;self.meta=load(ROOT/('native-'+case+'.json'))
        self.he=self.meta['helium_by_number'];self.t0=self.meta['T0'];self.fu=self.meta['fu']
        assert self.meta['helium_switch']==6 and self.meta['H_switch'] and self.meta['helium_fudge']==.86
        self.atom=self.meta['YHe']/((1-self.meta['YHe'])*self.he)
        self.n0=3*(1e5/MPC)**2*self.meta['ombh2']*(1-self.meta['YHe'])/(8*np.pi*GRAV*MH)
        with np.load(ROOT/('history-'+case+'.npz')) as bank:
            names=bank['raw_names'].tolist();raw=bank['raw'];val=lambda name:raw[:,names.index(name)]
            phy=bank['phy'];a=phy[:,0];self.grid=np.log(a)
            self.initial=self.grid[0];self.end=min(self.grid[-1],-np.log(1+end))
            self.native=CubicSpline(self.grid,np.c_[bank['x_e'],bank['T_b'],bank['opacity'],bank['visibility'],bank['time']],axis=0)
            self.waves=CubicSpline(self.grid,np.c_[phy[:,1],val('delta_baryon'),val('delta_photon')/4,(MODE*val('v_baryon_cdm')-phy[:,8])/(3*phy[:,1])],axis=0,extrapolate=False)
        def cross(N,idx):
            a=np.exp(N);return equilibrium(self.t0/a,self.n0/a**3,self.he)[idx]-switch
        self.he_switch=brentq(cross,self.initial,-np.log(1801),args=(2,));self.h_switch=brentq(cross,-np.log(2401),-np.log(1201),args=(0,))
    def env(self,N,eps):
        a=np.exp(N);hc,beta,theta,div=self.waves(N);base=self.t0/a
        n=self.n0/a**3*(1+eps*beta);tr=base*(1+eps*theta)
        hz=hc*LIGHT/(MPC*a);h_local=hz*(1+eps*(div if self.knob!='no_escape_velocity' else 0.))
        return n,tr,base,hz,h_local,theta,div
    def state(self,N,y,eps,stage):
        n,tr,*_=self.env(N,eps)
        h,neutral,he=equilibrium(tr,n,self.he)
        if stage==0:h,neutral=1.,0.
        if stage>=1:he=y[1]
        if stage==2:h,neutral=y[0],1-y[0]
        return h,neutral,he,h+self.he*he
    def rhs(self,N,y,eps,stage):
        n,tr,base,hz,h_local,theta,div=self.env(N,eps);tm=base*y[2]
        h,neutral,he,xe=self.state(N,y,eps,stage)
        photo=tm if self.knob=='matter_photo' else tr
        stat=(PHASE*photo)**1.5;dfh=0.;dfhe=0.
        temp_ratio=tm/1e4
        if stage==2:
            alpha=4.309e-19*temp_ratio**(-.6166)/(1+.6703*temp_ratio**.53)
            beta=alpha*stat*np.exp(-HC*(HION-LYA)/photo)
            fudge=1-.14*np.exp(-((-N-7.28)/.18)**2)+.079*np.exp(-((-N-6.73)/.33)**2)
            trap=fudge*n*neutral/(8*np.pi*LYA**3*h_local)
            peebles=(1+8.2245809*trap)/((1+8.2245809*trap)/self.fu+trap*beta)
            dfh=peebles*(beta*neutral*np.exp(-HC*LYA/photo)-n*alpha*h*xe)/hz
        if stage>=1 and N< -np.log(1251):
            nhe=self.he*n;neutral_he=1-he;low=np.sqrt(tm/10**.477121);high=np.sqrt(tm/10**5.114)
            def recomb(logamp,slope):return 10**logamp/(low*(1+low)**(1-slope)*(1+high)**(1+slope))
            ah=recomb(-16.744,.711);bh=4*ah*stat*np.exp(-HC*(HEION-HE2S)/photo)
            at=recomb(-16.306,.761);bt=(4./3)*at*stat*np.exp(-HC*TRIPION/photo)
            sing=escape(1.798287e9,HE2P,1.436289e-22,self.atom,tm,nhe,neutral_he,neutral/self.he,h_local,False)
            trip=escape(177.58,TRIP,1.484872e-22,self.atom,tm,nhe,neutral_he,neutral/self.he,h_local,True)
            boltz=np.exp(HC*(HE2P-HE2S)/photo)
            srate=3*sing/boltz
            cs=(srate+51.3)/(srate+51.3+bh)
            trate=trip*np.exp(-HC*(TRIP-TRIPS)/photo);ct=trate/(bt+trate)
            dfhe=(cs*(bh*neutral_he*np.exp(-HC*HE2S/photo)-n*ah*he*xe)
                  +ct*(3*bt*neutral_he*np.exp(-HC*TRIPS/photo)-n*at*he*xe))/hz
        coupling=COMPTON*tr**4*xe/(1+self.he+xe)/hz
        dt=-(1+2*eps*div)*y[2]+coupling*(1+eps*theta-y[2])
        return np.array([dfh,dfhe,dt])
    def compute(self,epsilon=0.,tangent=False,rtol=3e-8):
        tiny=1e-24;ei=1j*tiny
        bounds=[self.initial,self.he_switch,self.h_switch,self.end];columns=[];knots=[]
        theta=self.waves(self.initial)[2];b0=self.native(self.initial)[1]/(self.t0*np.exp(-self.initial))
        y=np.array([1.,1.,b0*(1+epsilon*theta)])
        if tangent:y=np.r_[y,0.,0.,b0*theta]
        for stage,(left,right) in enumerate(zip(bounds[:-1],bounds[1:])):
            if stage:
                slot=1 if stage==1 else 0
                def init(e):
                    n,tr,*_=self.env(left,e);eq=equilibrium(tr,n,self.he)
                    return eq[2 if stage==1 else 0]
                y[slot]=init(epsilon)
                if tangent:y[slot+3]=np.imag(init(ei))/tiny
            def deriv(N,state):
                if not tangent:return self.rhs(N,state,epsilon,stage)
                val=self.rhs(N,state[:3]+ei*state[3:],ei,stage)
                return np.r_[val.real,val.imag/tiny]
            grid=np.unique(np.r_[left,self.grid[(self.grid>left)&(self.grid<right)],right])
            sol=solve_ivp(deriv,(left,right),y,method='Radau' if tangent else 'BDF',rtol=rtol,atol=np.array([1e-12,1e-15,2e-12]* (2 if tangent else 1)),t_eval=grid,max_step=.01)
            if not sol.success:raise RuntimeError((stage,sol.message,sol.t[-1]))
            y=sol.y[:,-1].copy();take=slice(None,-1 if stage<2 else None)
            rows=[]
            for N,val in zip(grid[take],sol.y.T[take]):
                if tangent:
                    h,_,he,xe=self.state(N,val[:3]+ei*val[3:],ei,stage); rows.append([np.real(h),np.real(he),np.real(xe),val[2],np.imag(h)/tiny,np.imag(he)/tiny,np.imag(xe)/tiny,val[5]])
                else:
                    h,_,he,xe=self.state(N,val,epsilon,stage);rows.append([h,he,xe,val[2]])
            columns.extend(rows);knots.extend(grid[take])
        return np.array(knots),np.array(columns)
if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('case');parser.add_argument('tag');parser.add_argument('--eps',type=float,default=0.);parser.add_argument('--direct',action='store_true')
    parser.add_argument('--rtol',type=float,default=3e-8);parser.add_argument('--switch',type=float,default=.99);parser.add_argument('--knob',default='local')
    args=parser.parse_args();guard();job=Chemistry(args.case,knob=args.knob,switch=args.switch)
    grid,values=job.compute(args.eps,not args.direct,args.rtol)
    nc=job.native(grid);dxe=values[:,2]-nc[:,0]
    store('kinetic-'+args.tag+'-'+args.case+'.npz',N=grid,values=values,options=np.array([args.eps,args.rtol,args.switch]),switches=[job.he_switch,job.h_switch])
    print(args.case,args.tag,'background max abs and relative',max(abs(dxe)),max(abs(dxe)/nc[:,0]),'peak fractional response',max(abs(values[:,6]/values[:,2])) if not args.direct else None,flush=True)

