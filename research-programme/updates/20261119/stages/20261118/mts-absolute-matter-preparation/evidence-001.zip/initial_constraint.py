from readout import *
from scipy.special import eval_legendre

def directions(case):
    base=load(HERE/'bridge-primary.json')[case];c0=base['diagnostic']['full']['initial']
    with np.load(HERE/f'full-{case}.npz') as packet:
        t0=packet['times'];anchors=packet['anchors'];red=packet['redshift']
    grid=np.unique(np.r_[np.arange(t0[0],t0[-1],.115),anchors,t0[t0<t0[0]+23]])
    coarse=np.diff(grid);steps=np.concatenate([np.linspace(lo,hi,int(np.ceil((hi-lo)/min(.115,.025 if lo<t0[0]+26 else .115)))+1)[:-1] for lo,hi in zip(grid[:-1],grid[1:])]+[[grid[-1]]])
    st=np.empty(2*len(steps)-1);st[::2]=steps;st[1::2]=(steps[:-1]+steps[1:])/2
    drv,thermal=table(case,st,'zero',False,same=True)
    hc,cdm,bary,photon,weight=drv[0,[0,7,5,6,12]]
    simple=np.ascontiguousarray(np.c_[drv[:,[0,7,5,6,3,4,9,10]],np.zeros(len(drv)),drv[:,[12,13,14,23]],drv[:,24:]])
    size=1450;stride=size+1;shells=37;mode=np.arange(stride)
    up=lambda spin:MODE*np.sqrt(np.maximum(mode**2-spin**2,0))/(2*mode+1)
    down=lambda spin:MODE*np.sqrt(np.maximum((mode+1)**2-spin**2,0))/(2*mode+1)
    ops=np.array([up(0),down(0),up(2),down(2)]);rot=eval_legendre(mode,.5)
    ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS');lib=ctypes.CDLL(str(PREV/'response.dll'));fun=lib.integrate
    fun.argtypes=[ctypes.c_int]*3+[ctypes.c_double,ctypes.c_int]+[ptr]*6;fun.restype=ctypes.c_int
    choices={'expansion':(1,c0/(4*hc)),'spatial_curvature':(6,c0/(4*MODE**2)),'cdm_density':(0,c0/(2*cdm)),'baryon_density':(4,c0/(2*bary)),'photon_density':(7+2*stride,c0/(2*photon))}
    if case=='heavy':choices['heavy_density']=(2,weight*c0/2)
    ns=3 if case=='heavy' else 2;old=load(TARGET/'initial-state-requirement.json')['response_row'];adj=np.array(old[:6] if ns==3 else old[6:])*(1 if ns==3 else -1)
    answer={}
    for name,(slot,kick) in choices.items():
        state=np.zeros(7+(4+shells)*stride);state[slot]=kick
        history=np.empty((len(steps),34+2*shells))
        code=fun(len(steps),size,shells,MODE,int(ns==3),steps,simple,ops,rot,state,history)
        assert code==0 and np.isfinite(state).all()
        row=history[-1];t2=row[7]/MODE**2;h=simple[-1,0]
        normal=np.r_[np.r_[row[0],row[4],row[2]][:ns]-3*h*t2,-MODE*(np.r_[0.,row[5],row[3]][:ns]+MODE*t2)/h]
        shift=adj@normal/base['results']['full']['scores']['normal']['D_initial']**2
        answer[name]=dict(initial_shift=kick,initial_constraint_perturbation=history[0,14],z99_seed=normal.tolist(),Q_change=shift)
        assert abs(history[0,14]+c0)<1e-12
    return answer
if __name__=='__main__':
    guard();data={case:directions(case) for case in ['heavy','cold']};save('constraint-directions.json',data)
    print({c:{k:v['Q_change'] for k,v in row.items()} for c,row in data.items()})

