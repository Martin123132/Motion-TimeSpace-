from driver import *
from scipy.integrate import cumulative_simpson
def diagnose(case,label):
    with np.load(HERE/f'{label}-{case}.npz') as bank:
        times,history,anchors=bank['times'],bank['history'],bank['anchors'];same=bool(bank['same']) if 'same' in bank else False
        prior=str(bank['prior']) if 'prior' in bank else None
        driver,_=table(case,times,'local',False,same=same,owner=HERE/'overlap-data' if prior else None)
    hub,dc,eta,rate,tide,bary,phot,cdm,beta,v,cap,extra,weight,ma=driver[:,:14].T
    curvature=3*dc**2/32-9*dc*eta/16-45*eta**2/32
    iso=-2*eta;anis=-2*dc+6*eta;lower=(anis*MU+iso)/4
    grav=history[:,3]/weight+bary*history[:,5]+phot*(history[:,29]+lower*history[:,21])+history[:,9]
    source=grav/(2*MODE)+eta*(12*rate+7*tide)/8
    def integral(y):return cumulative_simpson(y,x=times,initial=0)
    rebase=-diagnose(case,prior)['integral_disagreement']/(4*MODE**2) if prior else 0.
    zeta0=history[0,6]-curvature[0]+rebase;zeta=zeta0+integral(source)
    corrected=-4*MODE**2*zeta-4*hub*history[:,1]+2*rate**2/3-(MU**2-1/3)*tide**2-2*history[:,19]
    denom=4*MODE**2*abs(zeta)+4*abs(hub*history[:,1])+2*rate**2/3+abs((MU**2-1/3)*tide**2)+2*abs(history[:,19])
    ix=np.searchsorted(times,anchors)
    with np.load(LAST/f'forecast-carried-fine-{case}.npz') as original:old_res=original['report'][-1,7]
    return dict(redshift_rows=[dict(z=r,raw=history[i,13],compensated=corrected[i],scale=denom[i],relative=corrected[i]/denom[i]) for r,i in zip(np.load(HERE/f'{label}-{case}.npz')['redshift'].tolist(),ix)],
        original_z3999_constraint=old_res,initial=corrected[0],final=corrected[-1],peak=np.max(abs(corrected)),max_pointwise_normalized=np.max(abs(corrected)/denom),
        raw_peak_normalized=np.max(abs(history[:,13])/history[:,14]),integral_disagreement=4*MODE**2*(history[-1,6]-curvature[-1]-zeta[-1]),
        density_continuity_mismatch=float(dc[-1]-dc[0]-integral(rate)[-1]),max_photon_energy_identity=max(abs(history[:,16])),max_momentum_exchange=max(abs(history[:,15])))
if __name__=='__main__':
    label=sys.argv[1];rows={case:diagnose(case,label) for case in ['heavy','cold']};save(f'constraint-{label}.json',rows)
    for case,res in rows.items():print(case,{k:v for k,v in res.items() if k!='redshift_rows'},res['redshift_rows'][-1])

