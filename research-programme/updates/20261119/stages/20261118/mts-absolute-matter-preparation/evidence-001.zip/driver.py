from pathlib import Path
import sys,json,os,ctypes,argparse,time as wall
HERE=Path(__file__).resolve().parent
PREV=HERE.parent/'mts-recombination-counterflow-20261118'
sys.path.insert(0,str(PREV))
from restart_lift import np,MODE,MU,CubicSpline,Thermal,Future,FullTrack,spin_map,field,photon_ops,diagonal_table
from common import digest,load,LAST,PROJ,EARLY,MATCH,SOURCE
sys.path.insert(0,str(HERE))

def guard():
    assert digest(PREV/'closeout.json')=='6339aaea61d3bc61af0e6d2bc677ccf9931f03f680eec31dbbfca1f23a65ba13'
    assert not any((path/'STOP-REQUESTED').exists() for path in [HERE,PREV,HERE.parent,LAST])

def save(name,body):
    with (HERE/name).open('x',encoding='utf8') as stream:json.dump(body,stream,indent=2,allow_nan=False)

def pack(name,**vals):
    with (HERE/name).open('xb') as stream:np.savez_compressed(stream,**vals)

def matrices(length):
    ge,coll,const=photon_ops(length);mats=ge+coll
    pattern=sum((abs(mat) for mat in mats)).tocsr();pattern.eliminate_zeros();pattern.sort_indices()
    rows=np.repeat(np.arange(pattern.shape[0]),np.diff(pattern.indptr));cols=pattern.indices
    coeff=np.ascontiguousarray(np.column_stack([mat[rows,cols].A1 for mat in mats]))
    return pattern.indptr.astype('int32'),cols.astype('int32'),coeff,np.ascontiguousarray(const)

def runtime():
    ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS');ip=np.ctypeslib.ndpointer(dtype=np.int32,flags='C_CONTIGUOUS')
    lib=ctypes.CDLL(str(HERE/'transport.dll'));fun=lib.absolute_run
    fun.argtypes=[ctypes.c_int]*3+[ctypes.c_double,ctypes.c_int]+[ptr]*4+[ip]*2+[ptr]*4;fun.restype=ctypes.c_int
    return fun

def table(case,times,chem,barotropic,model='native',same=False,owner=None):
    owner=owner or (HERE if same else PREV)
    bank=np.load(owner/f'history-{case}.npz')
    native=bank['time'];phy=bank['phy'];raw=bank['raw'];names=bank['raw_names'].tolist();a=phy[:,0];norm=float(bank['norm']);weight=a/norm
    use=lambda name:raw[:,names.index(name)]
    dh=use('mts_drho_h')*weight;qh=use('mts_q_h')*weight;ph=use('mts_dp_h')*weight
    grad=qh**2+MODE**2*dh**2/(4*phy[:,15]);work=phy[:,8]*(dh+ph)-2.5*MODE*phy[:,12]*qh;velwork=.5*phy[:,8]*qh+.375*grad/(weight*MODE)
    with np.load(owner/f'kinetic-{chem if chem!="zero" else "local"}-{case}.npz') as ion:
        frac=np.interp(np.log(a),ion['N'],ion['values'][:,6]/ion['values'][:,2])
    c=CubicSpline(native,np.c_[phy[:,1],phy[:,7],phy[:,12],phy[:,8],phy[:,11],phy[:,3],phy[:,4],phy[:,2],phy[:,9],phy[:,10],bank['opacity'],frac if chem!='zero' else frac*0,weight,phy[:,15],dh,qh,work,velwork,grad,bank['cs2b'],a,phy[:,5:7]],axis=0,extrapolate=False)
    val=c(times);der=c(times,1)
    dprime=der[:,14];qprime=der[:,15]
    if model=='conserved':
        dprime=val[:,3]-MODE*val[:,15]-3*val[:,0]*np.interp(times,native,ph) if case=='heavy' else np.zeros(len(times))
        qprime=MODE*np.interp(times,native,ph)-val[:,0]*val[:,15]
    thermal=Thermal(36,FullTrack(case).nu_mass);scales=val[:,20]
    energy=np.hypot(thermal.grid,scales[:,None]*thermal.mass);speed=np.c_[np.ones(len(times)),thermal.grid/energy]
    measures=thermal.base*energy;weights=np.c_[4*val[:,21],val[:,22,None]*thermal.gradient*measures/measures.sum(axis=1)[:,None]]
    extra=val[:,19]*int(barotropic)
    driver=np.ascontiguousarray(np.c_[val[:,:14],der[:,0],val[:,14:16],dprime,qprime,val[:,16],der[:,16],val[:,17:19],extra,speed,.5*(1+speed**2)*weights,speed*weights,weights])
    assert driver.shape==(len(times),24+4*37) and np.isfinite(driver).all()
    return driver,thermal

def start(case,length,tau):
    with np.load(LAST/f'forecast-carried-fine-{case}.npz') as bank:
        assert abs(tau-bank['time'][-1])<1e-7;core=bank['states'][-1]
    with np.load(LAST/f'forward-bank-matched-{case}.npz') as bank:first=CubicSpline(bank['time'],bank['photon'],axis=0)(tau)[4:]
    stride=length+1;state=np.zeros(7+(4+3*37)*stride);state[:7]=np.r_[core[:6],core[-1]]
    sky=state[7:7+4*stride].reshape(4,stride)
    for idx,raw in enumerate([first[:13],first[13:],core[6:19],core[19:32]]):sky[idx,:13]=spin_map()[0]@raw if idx%2 else raw
    with np.load(PREV/f'rays-refined-{case}.npz') as packet:
        rays=state[7+4*stride:].reshape(3,37,stride);common=min(stride,281);rays[:,:,:common]=packet['match_2'][:,:,:common]
    return state

def run(case,label,length,step,end,chem='local',gas=False,model='native',same=False):
    guard();path=HERE/f'{label}-{case}.npz';assert not path.exists()
    with np.load(PREV/f'history-{case}.npz') as packet:
        anchors=packet['anchors'];red=packet['redshift'];take=red>=end;assert end in red
        anchors=anchors[take];red=red[take];native=packet['time'];rate=packet['opacity']*(1+4*packet['phy'][:,4]/(3*packet['phy'][:,3]))
    time=[anchors[0]]
    for target in anchors[1:]:
        while time[-1]<target:time.append(min(target,time[-1]+min(step,1.3/np.interp(time[-1],native,rate))))
    times=np.array(time);stages=np.empty(2*len(times)-1);stages[::2]=times;stages[1::2]=(times[:-1]+times[1:])/2
    driver,thermal=table(case,stages,chem,gas,model,same);state=start(case,length,times[0]);history=np.empty((len(times),36))
    ops=diagonal_table(length);mat=matrices(length);fun=runtime()
    start_wall=wall.monotonic()
    code=fun(len(times),length,37,MODE,int(case=='heavy'),times,driver,ops,thermal.ell.ravel(),*mat,state,history)
    assert code==0 and np.all(np.isfinite(history)) and np.all(np.isfinite(state))
    pack(path.name,times=times,anchors=anchors,redshift=red,history=history,final=state,length=length,step=step,chem=chem,gas=gas,model=model,same=same,src=digest(HERE/'transport.dll'))
    print(case,label,len(times),round(wall.monotonic()-start_wall,2),'seconds; final core',history[-1,:7],'; constraint',history[-1,13:17],flush=True)
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('label');parser.add_argument('--case',default='both');parser.add_argument('--length',type=int,required=True);parser.add_argument('--step',type=float,required=True)
    parser.add_argument('--end',type=int,default=99);parser.add_argument('--chem',default='local');parser.add_argument('--gas',action='store_true');parser.add_argument('--conserved',action='store_true')
    parser.add_argument('--same',action='store_true');cfg=parser.parse_args()
    for case in (['heavy','cold'] if cfg.case=='both' else [cfg.case]):run(case,cfg.label,cfg.length,cfg.step,cfg.end,cfg.chem,cfg.gas,'conserved' if cfg.conserved else 'native',cfg.same)


