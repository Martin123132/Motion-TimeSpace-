from readout import *
from constraint import diagnose
def bridge(case,first,second):
    answers={};con={}
    for label in (first,second):
        con[label]=diagnose(case,label)
        with np.load(HERE/f'{label}-{case}.npz') as packet:
            local=gauge(case,packet,-con[label]['integral_disagreement']/(4*MODE**2))
            raw=gauge(case,packet);red=int(packet['redshift'][-1])
        scores={k:output(case,np.asarray(v),k=='coordinate',k!='normal',red,8) for k,v in local['seeds'].items()}
        answers[label]=dict(map=local,scores=scores,curvature_choice_mass_difference=(np.array(local['seeds']['coordinate'])-raw['seeds']['coordinate']).tolist())
    controls={}
    for key,vec in answers[first]['map']['seeds'].items():
        forecast=output(case,np.asarray(vec),key=='coordinate',key!='normal',99,49)
        actual=np.array(answers[second]['map']['seeds'][key]);pred=np.array(forecast['species_state'])
        nr=output(case,pred,key=='coordinate',key!='normal',49,8)
        late=answers[second]['scores'][key]
        controls[key]=dict(newtonian_z49=pred.tolist(),relativistic_z49=actual.tolist(),signed_difference=(actual-pred).tolist(),relative_difference=((actual-pred)/np.maximum(abs(actual),1)).tolist(),
            change_z8=late['Q']-nr['Q'],newtonian_restart_error=nr['Q']-answers[first]['scores'][key]['Q'])
    return dict(results=answers,diagnostic=con,overlap=controls)
if __name__=='__main__':
    label,first,second=sys.argv[1:4];data={case:bridge(case,first,second) for case in ['heavy','cold']}
    save(f'bridge-{label}.json',data)
    for case,row in data.items():print(case,[(k,r['scores']['proper']['Q']) for k,r in row['results'].items()],row['overlap']['proper'],row['diagnostic'][second]['redshift_rows'][-1])

