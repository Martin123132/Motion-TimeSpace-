from driver import *
import chemistry

def acquire(case):
    guard();sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    params=params_for(PROJ if case=='heavy' else EARLY/'cold.npz');params.DoLateRadTruncation=False
    native=camb.get_background(params);native.Params.Accuracy.IntTolBoost=6
    with np.load(PREV/f'history-{case}.npz') as prior:
        data={key:prior[key] for key in prior.files}
    raw=native.get_time_evolution([MODE],data['native_time'],vars=data['raw_names'].tolist(),lAccuracyBoost=4)[0];names=data['raw_names'].tolist();phy=data['phy'].copy()
    val=lambda key:raw[:,names.index(key)]
    assert np.max(abs(val('a')/phy[:,0]-1))<1e-12 and np.all(np.isfinite(raw))
    frac=phy[:,3]/(phy[:,3]+phy[:,2]);phy[:,7:13]=np.c_[val('delta_cdm'),val('H')*val('growth')*((1-frac)*val('delta_cdm')+frac*val('delta_baryon'))+frac*MODE*val('v_baryon_cdm'),
        val('delta_baryon'),val('v_baryon_cdm'),-val('H')*val('v_newtonian_cdm'),val('etak')/MODE]
    error=np.max(abs(raw[data['comparison_ix']]-data['usual']),axis=0);data.update(raw=raw,phy=phy,versus_saved_usual=error)
    pack(f'history-{case}.npz',**data);save(f'native-{case}.json',load(PREV/f'native-{case}.json'))
    chemistry.ROOT=HERE
    atom=chemistry.Chemistry(case);grid,vals=atom.compute(tangent=True)
    pack(f'kinetic-local-{case}.npz',N=grid,values=vals)
    print(case,'native CDM disagreement vs cached usual',error[names.index('delta_cdm')],flush=True)
if __name__=='__main__':
    for branch in ['heavy','cold']:acquire(branch)

