from readout import *
from scipy.fft import fft2,ifft2

def inputs(case):
    native=np.load(TARGET/f'early-{case}.npz');idx=np.flatnonzero(abs(native['k']-MODE)<1e-12)[0]
    left=-np.log(50);right=-np.log(9);epochs=native['N'];mass=float(native['mass']);rho=native['rho0'];frac=rho/rho.sum()
    densities=CubicSpline(epochs,native['D'][:,idx,:].T)(left);vel=CubicSpline(epochs,native['U'][:,idx,:].T)(left)
    if case=='heavy':
        omega=np.sqrt(1+MODE**2/(mass*np.exp(left))**2);densities[-1]/=(omega+1)/(2*np.sqrt(omega));vel[-1]*=np.sqrt(omega)
    expansion=CubicSpline(epochs,np.log(native['H']))
    def background(N):
        a=np.exp(N);hub=np.exp(expansion(N));return (2+expansion(N,1),rho/(2*a**3*hub**2),mass*a*a*hub)
    seed=np.array(load(HERE/'bridge-primary.json')[case]['results']['to49']['map']['seeds']['proper'])
    return left,right,background,rho,frac,np.r_[densities,vel],seed

def evolve(case,side,steps,stepamp):
    left,right,bg,rho,frac,initial,seed=inputs(case);ns=len(frac);k=MODE
    d,u=initial.reshape(2,ns);ds,us=seed.reshape(2,ns)
    start=left;dt=(right-left)/steps
    dirs=np.fft.fftfreq(side)*side;ix,iy=np.meshgrid(dirs,dirs,indexing='ij')
    kx=k*(ix+MU*iy);ky=k*np.sqrt(1-MU**2)*iy;square=kx*kx+ky*ky;mask=(abs(ix)<side/3)&(abs(iy)<side/3)
    inv=np.divide(-1,square,out=np.zeros_like(square),where=square>0)
    ax=np.arange(side)*2*np.pi/side;single=np.cos(ax[:,None])+np.cos(ax[None,:]);pair=np.cos(ax[:,None]+ax[None,:])
    n=stepamp*d[:,None,None]*single+stepamp**2*ds[:,None,None]*pair
    pot=(stepamp*u[:,None,None]*single+stepamp**2*us[:,None,None]*pair)/(k*k)
    pieces=[n[:2],pot[:2]];has=case=='heavy'
    if has:pieces.append((np.sqrt(1+n[-1])*np.exp(1j*bg(start)[2]*pot[-1]))[None])
    state=np.concatenate(pieces).astype(complex)
    def rhs(st,terms):
        drag,om,coupling=terms;dust=st[:2].real;source=om[:2]@dust.reshape(2,-1)
        if has:source+=om[-1]*(abs(st[-1])**2-1).ravel()
        gravity=ifft2(fft2(source.reshape(side,side))*inv*mask).real
        coeff=fft2(st[2:4].real)*mask;gx=ifft2(1j*kx*coeff).real;gy=ifft2(1j*ky*coeff).real
        density=ifft2(-1j*(kx*fft2((1+dust)*gx)+ky*fft2((1+dust)*gy))*mask).real
        vel=ifft2(fft2(-drag*st[2:4].real-.5*(gx**2+gy**2)-gravity)*mask).real
        response=[density,vel]
        if has:response.append(ifft2(-1j*mask*(square*fft2(st[-1])/(2*coupling)+coupling*fft2(gravity*st[-1])))[None])
        return np.concatenate(response)
    for ix in range(steps):
        tm=left+ix*dt;m=bg(tm+.5*dt);one=rhs(state,bg(tm));two=rhs(state+dt*one/2,m);three=rhs(state+dt*two/2,m);four=rhs(state+dt*three,bg(tm+dt))
        state+=dt*(one+2*two+2*three+four)/6
    n=state[:2].real
    if has:n=np.concatenate([n,(abs(state[-1])**2-1)[None]])
    fk=2*fft2(n)/side**2;lin=fk[:,1,0]/stepamp;gen=fk[:,1,1]/stepamp**2
    return dict(side=side,steps=steps,amplitude=stepamp,linear=lin.real.tolist(),generated=gen.real.tolist(),mean_residual=max(abs(n.mean(axis=(1,2)))),
        Q=float(2*(gen.real@frac)/(lin.real@frac)**2),sine_leak_fraction=float(max(abs(gen.imag))/max(abs(gen.real))))

def reference(case):
    left,right,bg,rho,frac,initial,seed=inputs(case);ns=len(frac)
    def rhs(epoch,state):
        d,u,ds,us=state.reshape(4,ns);drag,om,c=bg(epoch);pres=np.zeros(ns);
        if ns==3:pres[-1]=MODE**4/(4*c*c)
        return np.r_[u,om@d-drag*u-pres*d,us+.5*d*u,om@ds-drag*us-pres*ds-.25*u*u+.75*pres*d*d]
    ans=solve_ivp(rhs,(left,right),np.r_[initial,seed],method='DOP853',rtol=1e-11,atol=1e-12,max_step=.025);assert ans.success
    d,u,ds,us=ans.y[:,-1].reshape(4,ns)
    return dict(linear=d.tolist(),generated=ds.tolist(),Q=2*(ds@frac)/(d@frac)**2)
if __name__=='__main__':
    guard();report={}
    for case in ['heavy','cold']:
        ref=reference(case);variants=[evolve(case,*args) for args in [(24,256,1.6e-6),(24,256,.8e-6),(32,512,.8e-6)]]
        extrapolated=(4*variants[1]['Q']-variants[0]['Q'])/3
        report[case]=dict(reference=ref,trials=variants,amplitude_extrapolated=extrapolated,extrapolated_minus_reference=extrapolated-ref['Q']);print(case,report[case],flush=True)
    save('wave-replay.json',report)

