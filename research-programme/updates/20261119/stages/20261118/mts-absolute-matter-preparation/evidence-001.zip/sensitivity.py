from readout import *
def evaluate(case):
    rowref=load(HERE/'observable-full.json')[case];ctrl=rowref['scores']['normal']
    prepared=load(HERE/'bridge-primary.json')[case]['results']['to49']['scores']['proper'];ns=3 if case=='heavy' else 2
    adj=np.asarray(load(TARGET/'initial-state-requirement.json')['response_row']);adj=adj[:6] if ns==3 else -adj[6:]
    q={}
    for label in ['pilot','off','matched','angular','time','screened','full','full-off']:
        with np.load(HERE/f'{label}-{case}.npz') as packet:st=np.asarray(gauge(case,packet)['seeds']['normal'])
        q[label]=ctrl['Q_late_forcing']+adj@st/ctrl['D_initial']**2
    return dict(z99_q_by_run=q,z99_variations=dict(short_vs_wide_angular=q['matched']-q['angular'],time_at_fixed_angular=q['time']-q['matched'],
        final_vs_wide=q['full']-q['angular'],joint_baryon_pressure_and_conserved_driver=q['screened']-q['time'],
        matched_ionization_increment=q['full']-q['full-off'],alternative_first_hierarchy_and_small_angular_change=q['pilot']-q['matched']),
        prepared_z49=prepared)
if __name__=='__main__':
    guard();d={c:evaluate(c) for c in ['heavy','cold']};save('sensitivity-budget.json',d)
    print({c:row['z99_variations'] for c,row in d.items()})

