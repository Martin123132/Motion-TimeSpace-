import csv
from readout import *

def curves():
    rows=[]
    for case in ['heavy','cold','lcdm']:
        with np.load(TARGET/f'early-{case}.npz') as data:
            rho=data['rho0'];efold=data['N'];d=CubicSpline(efold,data['D'].transpose(2,1,0),axis=0);exp=CubicSpline(efold,np.log(data['H']))
            for z in [3.,3.6,4.2,5.,5.4,8.]:
                N=-np.log1p(z);H=299792.458*np.exp(exp(N));transfer=d(N);total=transfer@(rho/rho.sum())
                for idx,k in enumerate(data['k']):
                    P=2*np.pi**2/k**3*2.1e-9*(k/.05)**(-.0347)*total[idx]**2
                    rows.append(dict(branch=case,z=z,k_comoving_Mpc_inverse=k,k_parallel_velocity_s_per_km=k*(1+z)/H,H_km_s_Mpc=H,
                            D_matter=total[idx],D_baryon=transfer[idx,1],P_matter_linear_Mpc3=P,dimensionless_linear_power=k**3*P/(2*np.pi**2),is_flux_prediction=False))
    refs={(r['z'],r['k_comoving_Mpc_inverse']):r['P_matter_linear_Mpc3'] for r in rows if r['branch']=='cold'}
    for row in rows:row['P_ratio_to_all_cold']=row['P_matter_linear_Mpc3']/refs[(row['z'],row['k_comoving_Mpc_inverse'])]
    with (HERE/'matter-scale-targets.csv').open('x',newline='',encoding='utf8') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    print([row for row in rows if row['branch']=='heavy' and row['z']==4.2 and abs(row['k_comoving_Mpc_inverse']-MODE)<1e-10])
if __name__=='__main__':
    guard();curves()

