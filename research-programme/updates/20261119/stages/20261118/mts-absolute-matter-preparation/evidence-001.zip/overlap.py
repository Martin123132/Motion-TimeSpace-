from driver import *
from scipy.integrate import solve_ivp
import chemistry
OVER=HERE/'overlap-data'

def prepare(case):
    guard();OVER.mkdir(exist_ok=True);sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    params=params_for(PROJ if case=='heavy' else EARLY/'cold.npz');params.DoLateRadTruncation=False
    bg=camb.get_background(params);bg.Params.Accuracy.IntTolBoost=6
    z=np.array([99.,89.,79.,69.,59.,49.]);knots=bg.conformal_time(z,tol=1e-10)
    grid=np.unique(np.r_[np.linspace(knots[0],knots[-1],1+int(np.ceil((knots[-1]-knots[0])/.1))),knots])
    with np.load(HERE/f'history-{case}.npz') as src:
        names=src['raw_names'].tolist();norm=float(src['norm']);initial=src['time'][-1]
        previous=src['raw'][-1];factor=src['phy'][-1,15]/src['phy'][-1,0]**2
    tm=initial+(grid-grid[0]);aa=initial+(knots-knots[0])
    raw=bg.get_time_evolution([MODE],grid,vars=names,lAccuracyBoost=4)[0];val=lambda key:raw[:,names.index(key)]
    a=val('a');dens=bg.get_background_densities(a,['cdm','baryon','photon','neutrino','nu'])
    c,b,g,f,n=(dens[key]/a**2 for key in ('cdm','baryon','photon','neutrino','nu'))
    frac=b/(b+c);rate=val('H')*val('growth')*((1-frac)*val('delta_cdm')+frac*val('delta_baryon'))+frac*MODE*val('v_baryon_cdm')
    zero=np.zeros(len(a));phy=np.stack([a,val('H'),c,b,g,f,n,val('delta_cdm'),rate,val('delta_baryon'),val('v_baryon_cdm'),-val('H')*val('v_newtonian_cdm'),val('etak')/MODE,zero,zero,factor*a*a,zero,zero],axis=1)
    therm=bg.get_background_time_evolution(grid,['x_e','T_b','opacity','visibility','cs2b']);N=np.log(a)
    assert np.all(val('mts_match_count')==int(case=='heavy')) and np.max(abs(val('mts_nonheavy_change')))==0
    pack(f'overlap-data/history-{case}.npz',time=tm,native_time=grid,redshift=z,anchors=aa,phy=phy,raw=raw,raw_names=np.array(names),norm=norm,overlap_raw=raw[0]-previous,**therm)
    chemistry.ROOT=HERE;atom=chemistry.Chemistry(case)
    atom.waves=CubicSpline(N,np.c_[phy[:,1],phy[:,9],val('delta_photon')/4,(MODE*phy[:,10]-phy[:,8])/(3*phy[:,1])],axis=0)
    with np.load(HERE/f'kinetic-local-{case}.npz') as old:rest=old['values'][-1];nold=old['N'][-1]
    assert abs(nold-N[0])<1e-9
    tiny=1e-24;initial_state=rest[[0,1,3,4,5,7]]
    def rhs(t,state):
        ans=atom.rhs(t,state[:3]+1j*tiny*state[3:],1j*tiny,2)
        return np.r_[ans.real,ans.imag/tiny]
    fitted=solve_ivp(rhs,(N[0],N[-1]),initial_state,t_eval=N,method='Radau',atol=[1e-12,1e-18,1e-12]*2,rtol=3e-8,max_step=.01)
    assert fitted.success;h,he,temp,dh,dhe,dt=fitted.y
    values=np.c_[h,he,h+atom.he*he,temp,dh,dhe,dh+atom.he*dhe,dt]
    pack(f'overlap-data/kinetic-local-{case}.npz',N=N,values=values,join=values[0]-rest)
    print(case,'z99 linear mismatch',np.max(abs(raw[0]-previous)),'z49 chemical contribution',values[-1,6]/values[-1,2],flush=True)

def extend(case,label,prior,length,step):
    guard()
    with np.load(OVER/f'history-{case}.npz') as bank:anchors=bank['anchors'];red=bank['redshift']
    with np.load(HERE/f'{prior}-{case}.npz') as old:
        prev=int(old['length'])+1;assert old['times'][-1]==anchors[0] and str(old['chem'])=='local'
        state=np.zeros(7+115*(length+1));state[:7]=old['final'][:7]
        keep=min(prev,length+1);state[7:].reshape(115,-1)[:,:keep]=old['final'][7:].reshape(115,-1)[:,:keep]
    times=np.unique(np.r_[np.linspace(anchors[0],anchors[-1],1+int(np.ceil((anchors[-1]-anchors[0])/step))),anchors]);stages=np.empty(2*len(times)-1)
    stages[::2]=times;stages[1::2]=(times[:-1]+times[1:])/2
    driver,thermal=table(case,stages,'local',False,owner=OVER);history=np.empty((len(times),36))
    timer=wall.monotonic();code=runtime()(len(times),length,37,MODE,int(case=='heavy'),times,driver,diagonal_table(length),thermal.ell.ravel(),*matrices(length),state,history)
    assert code==0 and np.isfinite(state).all() and np.isfinite(history).all()
    pack(f'{label}-{case}.npz',times=times,anchors=anchors,redshift=red,history=history,final=state,length=length,step=step,chem='local',gas=False,same=True,prior=prior,src=digest(HERE/'transport.dll'))
    print(case,label,len(times),round(wall.monotonic()-timer,2),history[-1,:7],flush=True)
if __name__=='__main__':
    for case in ['heavy','cold']:
        if sys.argv[1]=='prepare':prepare(case)
        else:extend(case,sys.argv[1],sys.argv[2],int(sys.argv[3]),float(sys.argv[4]))

