from readout import *
from constraint import diagnose
from slow import hull

def slow_envelope(case):
    with np.load(EARLY/f'{case}.npz') as bg:
        fields=CubicSpline(bg['efold'],np.c_[bg['phi_s'],bg['phidot_s']],axis=0)
        mass=float(bg['slow_mass_mpc'])
    norm0=load(LAST/'slow-bound.json')[case]['norm_bound'];result=[]
    for label,src,dr,record in [('junction',LAST/f'forward-bank-matched-{case}.npz',LAST/f'forecast-carried-fine-{case}.npz','time'),('full',HERE/f'history-{case}.npz',HERE/f'full-{case}.npz','times'),('to49',HERE/f'overlap-data/history-{case}.npz',HERE/f'to49-{case}.npz','times')]:
        with np.load(src) as bank,np.load(dr) as run:
            t=run[record];exp=run['states' if label=='junction' else 'history'][:,1]
            phy=bank['phy'];names=bank['names' if label=='junction' else 'raw_names'].tolist()
            bgvalues=fields(np.log(phy[:,0]));a=phy[:,0];r=bank['raw']
            val=lambda word:r[:,names.index(word)];data=np.c_[a,phy[:,8],phy[:,12],bgvalues,val('mts_dphi_s'),val('mts_dphidot_s')]
            native=bank['time'];knots=np.unique(np.r_[native[(native>t[0])&(native<t[-1])],t])
            cv=CubicSpline(native,data,axis=0);bound=np.stack([np.max(abs(hull(CubicSpline(knots,cv(knots)[:,j]),knots)),axis=0) for j in range(7)])
            zz=CubicSpline(t,exp);clk=np.max(abs(hull(CubicSpline(knots,zz(knots)),knots)),axis=0)
        mass2=(mass*bound[0])**2;om=np.sqrt(MODE**2+mass2);f0,p0,f1,p1=bound[3:7]
        drive=clk*p0+bound[1]*p1+2.5*MODE**2*bound[2]*f1
        envelope=om/MODE*(norm0+np.cumsum(np.diff(knots)*drive))
        active=(2*p0+mass2*f0/MODE)*envelope+p1**2+.5*mass2*f1**2
        energy=(p0+mass2*f0/MODE)*envelope+.5*(p1**2+(mass2+abs(MU)*MODE**2)*f1**2)
        momentum=p0*envelope+.5*MODE*f1*p1
        result.append(dict(segment=label,initial_norm=norm0,terminal_bound=envelope[-1],max_active=max(active),max_energy=max(energy),max_current=max(momentum)));norm0=envelope[-1]
    return result

def kg_fixture():
    grid=np.arange(36)*2*np.pi/36;pp,qq=np.meshgrid(grid,grid,indexing='ij');dirs=np.array([[np.sqrt(.75),0,.5],[-np.sqrt(.75),0,.5]])
    results=[]
    for ratio in [.00132155,.38,1.2]:
        omega=np.sqrt(1+ratio**2);root=np.sqrt(omega);ec=(omega+1)/(2*root);xc=(2+(1-MU)*ratio**2)/(2*omega)
        for amp,bilinear in [(.9+.24j,-.7-.33j),(-.4+.7j,.6-.5j)]:
            def physical(step):
                phi=np.ones_like(pp,dtype=complex);prime=-1j*phi.copy();grad=np.zeros((*pp.shape,3),dtype=complex)
                psi=phi.copy();pgrad=grad.copy()
                for phase,vec,coef in [(pp,dirs[0],step*amp),(qq,dirs[1],step*amp),(pp+qq,dirs.sum(axis=0),step**2*bilinear)]:
                    mode=np.cos(phase)*coef;slope=-ratio*coef*np.sin(phase)[...,None]*vec
                    phi+=mode/root;prime-=1j*root*mode;grad+=slope/root;psi+=mode;pgrad+=slope
                en=(abs(phi)**2+abs(prime)**2+np.sum(abs(grad)**2,axis=-1))/2
                mom=-(np.conj(prime)[...,None]*grad).real
                ns=abs(psi)**2;vel=(pgrad/psi[...,None]).imag
                cosine2=2*np.cos(pp+qq);sine2=2*np.sin(pp+qq)
                return np.array([np.mean(cosine2*en),np.mean(sine2*mom[...,2]),np.mean(cosine2*ns),np.mean(sine2*vel[...,2]),np.mean(2*np.cos(pp)*en),np.mean(2*np.sin(pp)*(mom@dirs[0]))])
            def measure(step):
                pos=physical(step);neg=physical(-step)
                return np.r_[(pos[:4]+neg[:4]-2*physical(0)[:4])/(2*step**2),(pos[4:]-neg[4:])/(2*step)]
            data=(4*measure(.0005)-measure(.001))/3;e2,j2,n2,v2,en,j=data
            re=en/(2*ec);im=-root*j/ratio
            desired=e2/ec+(1-xc/ec)*(re**2+im**2);speed=root*(j2-re*j)
            results.append(dict(k_over_am=ratio,number_error=desired-n2,phase_speed_error=speed-v2,first_density=en,first_flux=j))
    return results

def isolate(case):
    with np.load(HERE/f'pilot-{case}.npz') as plus,np.load(HERE/f'off-{case}.npz') as minus,np.load(PREV/f'response-angular-{case}.npz') as reference:
        slots=np.searchsorted(plus['times'],plus['anchors']);anchor=reference['anchor_indices']
        difference=(plus['history']-minus['history'])[slots,:7]
        expect=reference['history'][anchor,:7];absolute=np.max(abs(difference-expect),axis=0)
        scale=np.max(abs(expect),axis=0)
        return dict(peak_absolute=absolute.tolist(),peak_scale=scale.tolist(),fraction_of_peak=(absolute/np.where(scale>0,scale,1)).tolist(),final=difference[-1].tolist())
if __name__=='__main__':
    guard();res={case:dict(omitted_slow=slow_envelope(case),ionization_subtraction=isolate(case)) for case in ['heavy','cold']}
    res['positive_frequency_reconstruction']=kg_fixture();save('physical-controls.json',res)
    print(res)

