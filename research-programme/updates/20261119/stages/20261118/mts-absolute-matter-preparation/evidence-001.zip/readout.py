from driver import *
from absolute_slicing import generators,matter
from scipy.integrate import solve_ivp,cumulative_simpson
from scipy.interpolate import PchipInterpolator
TARGET=HERE.parent/'mts-two-mode-response-20261118'
sys.path.append(str(TARGET))
from threepoint import cyclic,Bank

def gauge(case,run,curvature_shift=0.):
    native=(HERE/'overlap-data') if 'prior' in run else (HERE if ('same' in run and bool(run['same'])) else PREV)
    with np.load(native/f'history-{case}.npz') as bank:
        raw=bank['raw'];names=bank['raw_names'].tolist();time=bank['time'];phy=bank['phy'];norm=float(bank['norm'])
        length=float(bank['native_time'][-1]);p1=raw[-1,names.index('mts_dp_h')]*phy[-1,0]/norm
        d1=raw[-1,names.index('mts_drho_h')]*phy[-1,0]/norm;q1=raw[-1,names.index('mts_q_h')]*phy[-1,0]/norm
        cap=float(bank['opacity'][-1]);sound=float(bank['cs2b'][-1])
    with np.load(TARGET/f'early-{case}.npz') as late:
        knot=int(np.flatnonzero(np.isclose(late['k'],MODE,atol=1e-13,rtol=0))[0]);when=-np.log1p(run['redshift'][-1])
        weyl=float(CubicSpline(late['N'],(late['Phi']+late['Psi'])[knot])(when))
        boundary_d=CubicSpline(late['N'],late['D'][:,knot,:].T)(when);boundary_u=CubicSpline(late['N'],late['U'][:,knot,:].T)(when)
    state=run['history'][-1].copy();state[6]+=curvature_shift;a,hub,cdm,bary,phot,_rel,_nu,dc,rate,beta,v,shear,eta=phy[-1,:13]
    k=MODE;ma=phy[-1,15];hp=CubicSpline(time,phy[:,1])(time[-1],1);anis=-2*dc+6*eta;iso=-2*eta
    T=shear/k**2;Tprime=weyl-eta
    diff_slope=np.polyfit(time[-21:]-time[-1],phy[-21:,11]/k**2,2)[1]-Tprime
    ruler,L2,Lp,U=generators(-2*state[0]+6*state[6],state[7],anis,iso,T,Tprime)
    beta_dot=rate-k*v
    bary_vel_rate=-hub*v+k*sound*beta+cap*phot/bary*(state[21]-4*v/3)
    components={'cdm':(dc,0,0,rate,0,state[0]+dc**2/2,0),
        'baryon':(beta,v,0,beta_dot,bary_vel_rate,state[4]+beta**2/2-MU*v*v/2,state[5])}
    if case=='heavy':components['heavy']=(d1,q1,p1,rate-k*q1-3*hub*p1,-hub*q1+k*p1,state[2],state[3])
    spatial_potential=eta-hub*T
    volume1=-3*spatial_potential
    volume2=3*hub*U+1.5*hp*T*T-state[0]-T*rate+MU*k*k*ruler*dc-k*k*L2-.5*MU**2*k**4*ruler**2+.5*MU*(k*T)**2+.5*volume1**2
    modes={};proper=[];coordinate=[];normal=[];lin=[];uline=[]
    for name,args in components.items():
        densN,velN=matter(*args,hub,hp,anis,iso,T,U)
        d,pv,p,*_=args;linN=d-3*hub*T;vN=pv+k*T
        mass1=linN;phase1=vN
        if name=='heavy':
            omega=np.sqrt(1+k*k/ma);root=np.sqrt(omega);ec=(omega+1)/(2*root)
            cross=(2+(1-MU)*k*k/ma)/(2*omega);re=linN/(2*ec);im=-root*vN*np.sqrt(ma)/k
            mass=densN/ec+(1-cross/ec)*(re*re+im*im)
            phase=root*(velN+((linN+p)/2-re)*vN)
            mass1=linN/ec;phase1=root*vN
        else:mass=densN+.5*MU*vN*vN;phase=velN
        coord_mass=mass+volume1*mass1+volume2
        coord_vel=phase+.5*weyl*phase1
        normal.append([densN,-k*velN/hub]);proper.append([mass,-k*phase/hub]);coordinate.append([coord_mass,-k*coord_vel/hub])
        lin.append(linN);uline.append(-k*vN/hub)
        modes[name]=dict(energy_N=densN,v_N=velN,mass_normal_observer=mass,bulk_or_phase=phase,coordinate_mass=coord_mass,coordinate_speed=coord_vel)
    jac=-k*k*L2+.5*(1-MU**2)*(k*k*ruler)**2;vcd=k*Lp+.5*MU*k**3*ruler*T
    bary_jac=jac+state[4]-state[0]+.5*(beta-dc)**2+T*(beta_dot-rate)-(1+MU)*k*k*ruler*(beta-dc)-MU*k*T*v
    seeds={key:np.array(val).T.ravel().tolist() for key,val in [('normal',normal),('proper',proper),('coordinate',coordinate)]}
    return dict(seeds=seeds,species=modes,volume1=volume1,volume2=volume2,T=T,T2=U,weyl=weyl,Tprime_numerical_minus_metric=diff_slope,
        comoving_action_parameters=dict(k_over_am=k/np.sqrt(ma),H_over_am=hub/np.sqrt(ma)),cdm_jacobian_error=modes['cdm']['coordinate_mass']-jac,
        baryon_number_pullback_error=modes['baryon']['coordinate_mass']-bary_jac,cdm_trajectory_error=modes['cdm']['coordinate_speed']-vcd,
        density_linear_overlap=(np.array(lin)-boundary_d).tolist(),velocity_linear_overlap=(np.array(uline)-boundary_u).tolist())

def output(case,seed,coordinate=False,canonical=False,start_z=99,end_z=8):
    with np.load(TARGET/f'early-{case}.npz') as bank:
        idx=np.flatnonzero(np.isclose(bank['k'],MODE,atol=1e-13,rtol=0))[0];efold=bank['N'];rho=bank['rho0'];frac=rho/sum(rho)
        densities=bank['D'][:,idx,:].T.copy();speeds=bank['U'][:,idx,:].T.copy();mass=float(bank['mass'])
        if canonical and case=='heavy':
            omega=np.sqrt(1+MODE**2/(np.exp(efold)*mass)**2)
            densities[:,-1]/=(omega+1)/(2*np.sqrt(omega));speeds[:,-1]*=np.sqrt(omega)
        if coordinate:densities-=3*bank['Phi'][idx,:,None]
        hub=CubicSpline(efold,np.log(bank['H']));curves=CubicSpline(efold,np.c_[densities,speeds],axis=0)
    ns=len(rho);start=-np.log1p(start_z);end=-np.log1p(end_z);pres=np.zeros(ns)
    if ns==3:pres[-1]=1/mass**2
    def ode(t,state):
        d,u=np.split(curves(t),2);a=np.exp(t);H=np.exp(hub(t));press=pres*MODE**4/(4*a**4*H**2)
        def linear(d,u):return np.r_[u,rho@d/(2*a**3*H**2)-(2+hub(t,1))*u-press*d]
        sources=np.r_[.5*d*u,-.25*u*u+.75*press*d*d]
        homogeneous,forced=state.reshape(2,2*ns)
        return np.r_[linear(*np.split(homogeneous,2)),linear(*np.split(forced,2))+sources]
    ans=solve_ivp(ode,(start,end),np.r_[seed,np.zeros(2*ns)],rtol=2e-11,atol=1e-13,method='DOP853',max_step=.035)
    assert ans.success;parts=ans.y[:,-1].reshape(2,2*ns)[:,:ns]@frac;final=curves(end)[:ns]@frac;initial=curves(start)[:ns]@frac
    normalization=2/final**2;seedq,forcedq=normalization*parts;Q=seedq+forcedq
    P=2*np.pi**2/MODE**3*2.1e-9*(MODE/.05)**(-.0347)*final**2
    return dict(Q=Q,Q_seed=seedq,Q_late_forcing=forcedq,B_Mpc6=3*Q*P**2,P_Mpc3=P,delta2=MODE**3*P/(2*np.pi**2),D_initial=initial,D_final=final,species_state=np.sum(ans.y[:,-1].reshape(2,2*ns),axis=0).tolist())
def results(case,label):
    with np.load(HERE/f'{label}-{case}.npz') as run:
        state=gauge(case,run)
    scores={}
    for kind,coords in state['seeds'].items():
        scores[kind]=output(case,np.array(coords),coordinate=kind=='coordinate',canonical=kind!='normal')
    krow=np.asarray(load(TARGET/'initial-state-requirement.json')['response_row']);ns=3 if case=='heavy' else 2
    row=krow[:6] if ns==3 else -krow[6:]
    model=scores['normal'];old=cyclic(case,[4,4],MODE,99,8)
    with np.load(TARGET/'early-cold.npz') as cold:norm=cold['rho0']@cold['D'][:,4,-1]/sum(cold['rho0'])
    seed=float(row@state['seeds']['normal']/model['D_initial']**2);forcing=2*old['total']*(norm/model['D_final'])**2
    return dict(map=state,scores=scores,independent_seed=seed,independent_forcing=forcing,independent_total=seed+forcing)
if __name__=='__main__':
    label=sys.argv[1];data={case:results(case,label) for case in ['heavy','cold']};print(label)
    for case,res in data.items():print(case,res['scores'],res['independent_total'],res['map']['velocity_linear_overlap'])
    save(f'observable-{label}.json',data)

