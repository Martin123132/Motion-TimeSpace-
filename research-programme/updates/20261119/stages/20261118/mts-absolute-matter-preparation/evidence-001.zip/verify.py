from readout import *
import csv
from controls import kg_fixture

def checks():
    guard();out={}
    def gate(name,condition):
        out[name]=bool(condition)
        if not out[name]:raise ValueError(name)
    for file in HERE.glob('*.py'):compile(file.read_bytes(),str(file),'exec')
    res=load(HERE/'bridge-primary.json');alternate=load(HERE/'bridge-overlapcheck.json');field=load(HERE/'wave-replay.json')
    physical=load(HERE/'physical-controls.json');choices=load(HERE/'constraint-directions.json')
    variations=load(HERE/'sensitivity-budget.json')
    reference=load(HERE/'observable-full.json');refc=load(HERE/'constraint-full.json')
    gate('positive frequency independent inverse',all(max(abs(r['number_error']),abs(r['phase_speed_error']))<1e-8 for r in kg_fixture()))
    for case in ['heavy','cold']:
        row=res[case];a=row['results']['full'];b=row['results']['to49'];primary=b['scores']['proper']
        for label,key,size in [('full','full',2704),('to49','to49',4080)]:
            with np.load(HERE/f'{label}-{case}.npz') as bank:
                gate(case+' angular state '+label,int(bank['length'])==size and bank['final'].size==7+115*(size+1) and np.isfinite(bank['final']).all() and len(bank['times'])==len(bank['history']) and digest(HERE/'transport.dll')==str(bank['src']))
                gate(case+' same photons '+label,max(abs(bank['history'][:,15]))<1e-13 and max(abs(bank['history'][:,16]))<1e-10)
                gate(case+' safe chronology '+label,np.all(np.diff(bank['times'])>0) and np.array_equal(bank['times'][np.searchsorted(bank['times'],bank['anchors'])],bank['anchors']))
            g=row['results'][key]['map']
            gate(case+' coordinate number '+label,abs(g['cdm_jacobian_error'])<1e-7 and abs(g['baryon_number_pullback_error'])<1e-7 and abs(g['cdm_trajectory_error'])<1e-10)
            gate(case+' transfer normalization '+label,max(abs(np.array(g['density_linear_overlap'])))<1e-7 and max(abs(np.array(g['velocity_linear_overlap'])))<4e-6)
            gate(case+' gravity constraint '+label,row['diagnostic'][key]['max_pointwise_normalized']<.0015 and abs(row['diagnostic'][key]['final']-refc[case]['original_z3999_constraint'])<3e-6)
        gate(case+' independent frozen row',abs(reference[case]['independent_total']-a['scores']['normal']['Q'])<1e-8)
        gate(case+' early angular/time sensitivity',abs(variations[case]['z99_variations']['final_vs_wide'])<1e-8 and abs(variations[case]['z99_variations']['time_at_fixed_angular'])<1e-8)
        gate(case+' matching restart',abs(row['overlap']['proper']['newtonian_restart_error'])<1e-9 and max(abs(np.array(row['overlap']['proper']['relative_difference'])))<.000102)
        gate(case+' comparison of switch epochs',abs(primary['Q']-a['scores']['proper']['Q'])<6e-7)
        gate(case+' alternate angular/time continuation',abs(primary['Q']-alternate[case]['results']['check49']['scores']['proper']['Q'])<1e-8)
        gate(case+' choice of mass density',all(abs(v['Q']-primary['Q'])<5e-7 for v in b['scores'].values()))
        gate(case+' direct preparation format',np.all(np.isfinite(b['map']['seeds']['proper'])) and primary['delta2']<.2)
        gate(case+' late modes on grid',abs(field[case]['extrapolated_minus_reference'])<1e-8 and all(r['mean_residual']<1e-12 and r['sine_leak_fraction']<1e-8 for r in field[case]['trials']))
        gate(case+' independent matter evolution',abs(field[case]['reference']['Q']-primary['Q'])<1e-6)
        gate(case+' omitted direct slow trace',physical[case]['omitted_slow'][-1]['max_active']<1e-10)
        gate(case+' full minus no-ion matches forced response',max(physical[case]['ionization_subtraction']['fraction_of_peak'][:6])<6e-8)
        gate(case+' initial constraint alternatives',all(abs(v['initial_constraint_perturbation']+refc[case]['initial'])<1e-12 and abs(v['Q_change'])<.00015 for v in choices[case].values()))
        with np.load(HERE/'overlap-data'/f'kinetic-local-{case}.npz') as bank:gate(case+' atomic restart',np.max(abs(bank['join']))<1e-12)
    with (HERE/'matter-scale-targets.csv').open(encoding='utf8') as f:rows=list(csv.DictReader(f))
    gate('matter not transmitted flux',len(rows)==144 and len({(r['branch'],r['z'],r['k_comoving_Mpc_inverse']) for r in rows})==144 and all(r['is_flux_prediction']=='False' and float(r['P_matter_linear_Mpc3'])>0 for r in rows))
    return out

def sources():
    files=[PREV/'closeout.json',LAST/'closeout.json',TARGET/'closeout.json',PROJ,EARLY/'heavy.npz',EARLY/'cold.npz',MATCH/'native/camb/cambdll.dll',MATCH/'matching_common.py']
    files.extend(PREV/name for name in ['common.py','absolute_slicing.py','restart_lift.py','optical_response.py','angular_lift.py','ray_transport.c','response.dll','chemistry.py'])
    files.extend(LAST/name for name in ['model.py','support.py','forward_bank.py','slow.py','slow-bound.json'])
    files.extend(TARGET/name for name in ['initial-state-requirement.json','threepoint.py','triangles.py','setup_local.py','high-redshift-check.json','early-lcdm.npz'])
    files.append(SOURCE/'screen-12.npz')
    for case in ['heavy','cold']:
        files.extend(PREV/f'{name}-{case}.{ext}' for name,ext in [('native','json'),('rays-refined','npz'),('history','npz'),('kinetic-local','npz'),('response-angular','npz')])
        files.extend([LAST/f'forward-bank-matched-{case}.npz',LAST/f'forecast-carried-fine-{case}.npz',TARGET/f'early-{case}.npz'])
    return {str(file):digest(file) for file in files}

def names():
    return {f.relative_to(HERE).as_posix():f for f in HERE.rglob('*') if f.is_file() and f!=HERE/'closeout.json'}
if __name__=='__main__':
    report=checks();src=sources()
    if '--seal' in sys.argv:
        save('validation.json',report);save('closeout.json',dict(files={k:digest(v) for k,v in names().items()},inputs=src))
    manifest=load(HERE/'closeout.json')
    assert load(HERE/'validation.json')==report and src==manifest['inputs'] and manifest['files']=={k:digest(v) for k,v in names().items()}
    print(len(report),'checks,',len(names()),'local files,',len(src),'inputs; SHA256',digest(HERE/'closeout.json'))

