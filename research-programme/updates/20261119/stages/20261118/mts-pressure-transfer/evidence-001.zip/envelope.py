from score import *


def integral(clock,values):
    anti=CubicSpline(clock,values).antiderivative()
    return anti(clock)-anti(clock[0])


def oscillator(clock,omega,pos,vel,source):
    spline=CubicSpline(clock,omega)
    ratio=spline(clock,1)/omega
    residual=.75*ratio**2-.5*spline(clock,2)/omega
    phase=integral(clock,omega)
    sine,cosine=np.sin(phase),np.cos(phase)
    root=np.sqrt(omega)
    initial_cos=pos*root[0]
    initial_sin=(vel+.5*ratio[0]*pos)/root[0]
    records=[]
    feedback=0.
    for iteration in range(3):
        forcing=source-feedback
        cosine_weight=initial_cos-integral(clock,np.broadcast_to(forcing,clock.shape)*sine/root)
        sine_weight=initial_sin+integral(clock,np.broadcast_to(forcing,clock.shape)*cosine/root)
        position=(cosine_weight*cosine+sine_weight*sine)/root
        velocity=-.5*ratio*position+root*(sine_weight*cosine-cosine_weight*sine)
        records.append((position,velocity))
        feedback=residual*position
    norm_estimate=np.trapezoid(abs(residual)/root,clock)/min(root)
    return phase,records,float(norm_estimate)


def calculate(stride):
    job=Continuation('heavy',2)
    cold=Continuation('cold',2)
    case=pack(ROOT/'heavy-dense-physical.npz')
    baseline=pack(ROOT/'cold-dense-physical.npz')
    common=pack(ROOT/'common-scale-2.npz')['log_a']
    ix=np.arange(0,len(case['x']),stride);t=case['x'][ix];out=case['physical'][ix]
    scale=case['background'][ix,1];h=case['background'][ix,3];c=job.const
    homogeneous=job.solution(t);phi,vel=homogeneous[3],homogeneous[4]
    mu=job.masses[1]*scale;rho,pnu=thermal(scale*c[8])
    enthalpy=((c[0]+c[1])/scale+4/3*(c[2]+c[3])/scale**2+c[14]*(rho+pnu)/scale**2)/K**2
    enthalpy+=homogeneous[2]**2+vel**2
    acc_over_a=2*h**2-.5*enthalpy
    freq0=np.sqrt(mu**2-acc_over_a);freq1=np.sqrt(1+mu**2-acc_over_a)
    phase0,bg,err0=oscillator(t,freq0,scale[0]*phi[0],scale[0]*(vel[0]+h[0]*phi[0]),0.)
    field_bg=bg[-1][0]/scale
    speed_bg=bg[-1][1]/scale-h*field_bg
    pert=out[:,17];der=out[:,18]
    known=[scale[0]*pert[0],scale[0]*(der[0]+h[0]*pert[0])]
    phase1,full,err1=oscillator(t,freq1,*known,scale*speed_bg*out[:,0])
    _,free,_=oscillator(t,freq1,*known,0.)
    def energy(coordinates,field=field_bg,speed=speed_bg):
        position,velocity=coordinates
        u=position/scale; w=velocity/scale-h*u
        return speed*w+mu**2*field*u+3*h*speed*u
    truth=vel*der+mu**2*phi*pert+3*h*vel*pert
    inferred=energy(full[-1]);noforce=energy(free[-1])
    scalar_density=(vel**2+(mu*phi)**2)/2
    removed_bg=(cold.const[0]-c[0])/(K**2*scale)
    mask=(np.log(scale)>=common[0])&(np.log(scale)<=common[-1])
    cold_cdm=CubicSpline(np.log(baseline['background'][:,1]),baseline['physical'][:,13],extrapolate=False)(np.log(scale[mask]))
    removed=removed_bg[mask]*cold_cdm
    beat=1/(freq1+freq0)
    result={'ratio_mu_range':[min(mu),max(mu)],'physical_ticks_per_hubble_range':[min(mu/h),max(mu/h)],
        'beat_phase_radians':float(phase1[-1]-phase0[-1]),'sum_phase_cycles':float((phase1[-1]+phase0[-1])/(2*np.pi)),
        'beat_frequency_squared_over_isolated_self_gravity_range':[min(beat**2/(scalar_density/2)),max(beat**2/(scalar_density/2))],
        'homogeneous_replacement_fraction_range':[min(scalar_density/removed_bg),max(scalar_density/removed_bg)],
        'max_abs_heavy_comoving_over_required_cold_comoving':peak(truth[mask]/removed),
        'required_contrast_range':[min(cold_cdm),max(cold_cdm)],
        'measured_heavy_comoving_density_contrast_range':[min(truth/scalar_density),max(truth/scalar_density)],
        'WKB_unforced_controls':{'no_external_metric_forcing_rel_error':rel(noforce-truth,truth),'true_zero_initial_and_source':True},
        'WKB_conditional_source_relative_errors':[rel(energy(item)-truth,truth) for item in full],
        'rho_comoving_derived_vs_direct_peak_rel':rel(inferred-truth,truth),
        'field_and_velocity_max_relative_to_peak':[rel(field_bg-phi,phi),rel(speed_bg-vel,vel)],
        'kernel_integral_norm_estimates':[err0,err1],
        'terminal_free_contribution':float(noforce[-1]),'terminal_forced_contribution':float(inferred[-1]-noforce[-1]),
        'terminal_total':float(inferred[-1]),'phase_rate_consistency':float(abs(integral(t,beat)[-1]-(phase1[-1]-phase0[-1])))}
    _,null,_=oscillator(t,freq1,0.,0.,np.zeros_like(t))
    assert np.count_nonzero(null[-1][0])+np.count_nonzero(null[-1][1])==0
    if stride==1:
        np.savez_compressed(ROOT/'heavy-density-envelope.npz',x=t,scale=scale,phase0=phase0,phase1=phase1,true_comoving=truth,
                   driven=inferred,free=noforce,background_density=scalar_density,removed_background=removed_bg,
                   overlap_mask=mask,required_clustering=removed)
    return result


if __name__=='__main__':
    guard()
    results={str(stride):calculate(stride) for stride in (2,1)}
    save('heavy-envelope.json',results)
    print(results['1'],flush=True)
