from score import *
import csv


def gate():
    guard()
    heavy=Continuation('heavy',2);cold=Continuation('cold',2)
    dense=pack(ROOT/'heavy-dense-physical.npz')
    time=dense['x']; h=dense['background'][:,3]; aval=dense['background'][:,1]
    vals=heavy.solution(time); const=heavy.const; mpc_mass=const[7]
    massive_rho,massive_p=thermal(aval*const[8])
    enthalpy=((const[0]+const[1])/aval+(4/3*(const[2]+const[3])+const[14]*(massive_rho+massive_p))/aval**2)/K**2
    enthalpy+=vals[2]**2+vals[4]**2
    curvature=K**2*(2*h**2-enthalpy/2)
    effective=(aval*mpc_mass)**2-curvature
    grav=K**2/4*(vals[4]**2+(aval*heavy.masses[1]*vals[3])**2)
    threshold=np.sqrt(2*np.sqrt(effective*grav)+grav)
    assert np.all(effective>0) and np.all(grav>0)
    calculated=np.sqrt(threshold**2+effective)-np.sqrt(effective)
    assert peak(calculated/np.sqrt(grav)-1)<1e-10
    paths={};out=[]
    archive=Path(heavy.obj.config['ref']).parent
    control_path=Path(cold.obj.config['ref'])
    with np.load(control_path) as base:
        names=base['names'].tolist()
        for wave,chunk in [(.03,'0144'),(.1,'0192'),(1.,'0352'),(5.,'0384')]:
            path=archive/('chunk-'+chunk+'.npz')
            with np.load(path) as data:
                fields=data['names'].tolist(); slot=int(np.flatnonzero(data['modes']==wave).item())
                active=data['values'][slot,START:END+1]
            ref=base['values'][int(np.flatnonzero(base['modes']==wave).item())]
            base_scale=ref[:,names.index('a')]
            scale=active[:,fields.index('a')]
            mask=(scale>=base_scale[0])&(scale<=base_scale[-1]);assert mask.sum()>=len(scale)-1
            scale=scale[mask];active=active[mask]
            cdm=PchipInterpolator(base_scale,ref[:,names.index('delta_cdm')])(scale)
            ref_lens=PchipInterpolator(base_scale,ref[:,names.index('Weyl')])(scale)
            linear=np.interp(scale,base_scale,ref[:,names.index('delta_cdm')])
            removed=(cold.const[0]-const[0])/scale*cdm
            com=active[:,fields.index('mts_drho_h')]+3*active[:,fields.index('H')]/wave*active[:,fields.index('mts_q_h')]
            frac=com/removed
            lens=active[:,fields.index('Weyl')]
            out.append({'k_Mpc_inv':wave,'points':len(scale),'scale_initial':scale[0],'scale_end':scale[-1],
                'k_over_kstar_at_end':wave/threshold[-1],'max_H_over_k':max(active[:,fields.index('H')]/wave),
                'minimum_signed_fraction':min(frac),'maximum_signed_fraction':max(frac),
                'max_abs_fraction':peak(frac),'last_signed_fraction':frac[-1],
                'max_relative_cold_interpolation_change':peak(linear/cdm-1),
                'end_MTS_over_baseline_Weyl':lens[-1]/ref_lens[-1]})
            paths[str(path.relative_to(ROOT.parent))]=study.digest(path)
    paths[str(control_path.relative_to(ROOT.parent))]=study.digest(control_path)
    with (ROOT/'four-mode-archive-check.csv').open('w',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=out[0]);writer.writeheader();writer.writerows(out)
    low=[row for row in out if row['k_Mpc_inv']<min(threshold)/2]
    test=all(out[-1]['max_abs_fraction']<row['max_abs_fraction'] for row in low)
    save('four-mode-archive-check.json',{'kstar_range_Mpc_inv':[min(threshold),max(threshold)],'source_hashes':paths,
        'frozen_test':study.digest(ROOT/'SCALE-TEST.md'),'low_modes':[row['k_Mpc_inv'] for row in low],
        'short_mode_less_clustered_than_both_long_modes':test,'archive_only':True,
        'physical_k5_max_abs_fraction':study.read(ROOT/'heavy-envelope.json')['1']['max_abs_heavy_comoving_over_required_cold_comoving']})
    print('kstar',min(threshold),max(threshold),'fractions',[(row['k_Mpc_inv'],row['max_abs_fraction'],row['end_MTS_over_baseline_Weyl']) for row in out],flush=True)


if __name__=='__main__':gate()
