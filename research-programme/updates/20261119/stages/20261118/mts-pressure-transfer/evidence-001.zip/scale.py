from score import *
from scipy.interpolate import CubicSpline

FACTORY=CDLL(str(ROOT/'scale_split.dll'))
FACTORY.cross_scale.argtypes=[c_int,c_double,PTR,PTR,PTR,PTR];FACTORY.cross_scale.restype=None
LOGRATE=.0025
PARTS=['carried_environment','heavy_stress_after_start','changed_CDM_weight','remaining_medium_and_clock']


class ScaleMap:
    def __init__(self,job):
        self.job=job
        times=np.linspace(job.times[0],job.times[-1],8193)
        logs=job.solution(times)[0]
        assert np.all(np.diff(logs)>0)
        self.inverse=CubicSpline(logs,times,extrapolate=False)
        self.bounds=logs[[0,-1]]

    def at(self,logs):
        clock=self.inverse(logs)
        assert np.all(np.isfinite(clock))
        clock=np.clip(clock-(self.job.solution(clock)[0]-logs)*self.inverse(logs,1),self.job.times[0],self.job.times[-1])
        error=self.job.solution(clock)[0]-logs
        assert peak(error)<2e-14
        return clock

    def initial(self,logscale):
        initial=self.job.seed[ARMS[4]].copy()
        lo=self.job.times[0]; hi=float(self.at(logscale))
        if hi==lo:return initial
        assert 0<hi-lo<.01
        points=np.linspace(lo,hi,33)
        medium=self.job.media(points)[1]
        states=np.zeros((17,185));states[0]=initial
        out=np.empty((17,3))
        LIB.full_sweep(0,1,16,(hi-lo)/16,medium,states,out)
        return states[-1].copy()


def carry(level):
    guard()
    jobs=[Continuation(case,level) for case in ('cold','heavy')]
    maps=[ScaleMap(job) for job in jobs]
    lo=max(mapper.bounds[0] for mapper in maps);hi=min(mapper.bounds[1] for mapper in maps)
    initial=[mapper.initial(lo) for mapper in maps]
    inherited=initial[1]-initial[0];inherited[182:]=0
    combo=np.r_[initial[0],initial[1],inherited,np.zeros(3*185)]
    intervals=32768*2**level;stride=intervals//4096
    dt=(hi-lo)/(intervals*LOGRATE)
    snaps=[];logs_out=[];clocks_out=[];chunk=512
    for offset in range(0,intervals,chunk):
        if offset%16384==0:guard()
        logs=lo+(hi-lo)*(np.arange(2*chunk+1)/2+offset)/intervals
        if offset+chunk==intervals: logs[-1]=hi
        clocks=[mapper.at(logs) for mapper in maps]
        media=[job.media(clock)[1] for job,clock in zip(jobs,clocks)]
        response=np.empty((chunk+1,60))
        FACTORY.cross_scale(chunk,dt,*media,combo,response)
        keep=np.arange(stride if offset else 0,chunk+1,stride)
        snaps.append(response[keep]);logs_out.append(logs[2*keep]);clocks_out.append(np.array(clocks).T[2*keep])
    assert np.all(np.isfinite(combo))
    np.savez_compressed(ROOT/f'common-scale-{level}.npz',log_a=np.concatenate(logs_out),clocks=np.vstack(clocks_out),
          terminal=combo,initial=np.array(initial),signals=np.vstack(snaps).reshape(-1,6,10))
    print('common scale',level,intervals,'steps',flush=True)


def summarize():
    guard()
    runs=[pack(ROOT/f'common-scale-{i}.npz') for i in range(3)]
    fine=runs[-1];v=fine['signals'];change=v[:,1]-v[:,0];parts=v[:,2:];ln=fine['log_a']
    check={}
    for col,case in enumerate(('cold','heavy')):
        prior=pack(ROOT/(case+'-2-trajectory.npz'))
        axis=np.log(prior['medium'][:,1]); vals=prior[ARMS[4]][:,:10]
        calc=CubicSpline(axis,vals)(ln)
        check[case]={key:rel(calc[:,i]-v[:,col,i],v[:,col,i]) for i,key in enumerate(SIGNALS)}
    result={'scale':np.exp(ln[[0,-1]]).tolist(),'points':len(ln),'independent_x_vs_log_a_checks':check,'observable':{}}
    for i,key in enumerate(SIGNALS):
        target=change[:,i]; site=int(np.argmax(abs(target))); per=parts[:,:,i]
        err=[(res['signals'][:,1,i]-res['signals'][:,0,i]) for res in runs]
        result['observable'][key]={'peak_difference_over_baseline_peak':rel(target,v[:,0,i]),'peak_scale':float(np.exp(ln[site])),
            'terminal_baseline':float(v[-1,0,i]),'terminal_MTS':float(v[-1,1,i]),
            'terminal_change':float(target[-1]),'signed_share_at_peak':dict(zip(PARTS,(per[site]/target[site]).tolist())),
            'signed_share_at_end':dict(zip(PARTS,(per[-1]/target[-1]).tolist())),
            'reconstruction_error_over_contrast':rel(target-per.sum(axis=1),target),
            'mesh_change_over_contrast':[rel(b-a,target) for a,b in zip(err,err[1:])],
            'worst_channel_mesh_change_over_contrast':max(rel(parts[:,j,i]-runs[-2]['signals'][:,j+2,i],target) for j in range(4))}
    save('common-scale-scores.json',result)
    print('matched scale: Weyl',result['observable']['Weyl_k2'],'photon shear',result['observable']['photon_anisotropic_stress'],flush=True)


if __name__=='__main__':
    for level in range(3):carry(level)
    summarize()
