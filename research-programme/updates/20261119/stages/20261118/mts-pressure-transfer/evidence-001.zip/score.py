from transfer import *
from scipy.interpolate import PchipInterpolator,CubicSpline


def peak(arr):
    return float(np.max(np.abs(arr)))


def rel(arr,scale):
    return peak(arr)/peak(scale) if peak(scale)>0 else None


def early_read(case,tag,const):
    path=SWITCH/(case+'-'+tag+'-both-late.npz')
    receipt=study.read(SWITCH/'closeout.json')['files'][path.name]
    assert study.digest(path)==receipt['sha256']
    data=pack(path); val=dict(zip(data['names'].tolist(),data['forecast'].T))
    scale=val['a'];hub=val['H']/K
    cd,ba,ph,ml,mn=(const[[0,1,2,3,14]]/(K**2*scale[:,None]**[1,1,2,2,2])).T
    dens=cd*val['delta_cdm']+ba*val['delta_baryon']+ph*val['delta_photon']+ml*val['delta_neutrino']+mn*val['massive_bg_ratio']*val['delta_nu']+(val['mts_drho_s']+val['mts_drho_h'])/K**2
    flux=ba*val['v_baryon_cdm']+ph*val['v_photon']+ml*val['v_neutrino']+mn*val['massive_flux_moment']+(val['mts_q_s']+val['mts_q_h'])/K**2
    shear=ph*val['pi_photon']+ml*val['massless_shear']+mn*val['massive_shear_moment']
    calc=-(val['etak']/K+dens/2)/hub
    assert rel(calc-val['cdm_x'],val['cdm_x'])<1e-12
    return data['x'],scale,np.column_stack((val['active_cdm_x'],-12.5*(dens+3*hub*flux+shear),
        ph*val['pi_photon'],ph*val['delta_photon']/3,val['E_2'],val['mts_dp_s'],val['mts_dphi_s'],val['mts_dphidot_s']/K,dens,flux)),study.digest(path)


def earlier(job,run):
    case=job.case;time=run['x'];native=run[ARMS[4]][:,:10]; out={}; data={}
    for tag in ('fine','main','highq','angular','trace'):
        xt,at,ref,sha=early_read(case,tag,job.const)
        idx=np.searchsorted(xt,job.times)
        assert np.array_equal(xt[idx],job.times)
        xt,at,ref=xt[idx],at[idx],ref[idx]
        scale=run['medium'][:,1]
        mask=(at>=scale[0])&(at<=scale[-1])
        assert np.count_nonzero(mask)>1200
        clock_pair=native[run['epoch_rows']]
        scale_pair=CubicSpline(scale,native,extrapolate=False)(at[mask])
        subset=np.unique(np.r_[np.arange(0,len(scale),2),len(scale)-1])
        alternatives=[PchipInterpolator(scale,native,extrapolate=False)(at[mask]),CubicSpline(scale[subset],native[subset],extrapolate=False)(at[mask])]
        assert np.all(np.isfinite(alternatives))
        out[tag]={'source_sha256':sha,'matched_scale_epochs':int(sum(mask)),'scale_first_last_epochs':(np.flatnonzero(mask)[[0,-1]]+START).tolist(),
            'clock_peak_relative':dict(zip(SIGNALS,[rel(cur-old,old) for cur,old in zip(clock_pair.T,ref.T)])),
            'scale_peak_relative':dict(zip(SIGNALS,[rel(cur-old,old) for cur,old in zip(scale_pair.T,ref[mask].T)])),
            'fixed_scale_interpolation_sensitivity_relative_to_earlier_peak':dict(zip(SIGNALS,[max(rel(alt[:,i]-scale_pair[:,i],ref[mask,i]) for alt in alternatives) for i in range(10)])),
            'terminal_pressure_at_fixed_clock':{'carried':float(clock_pair[-1,5]),'early':float(ref[-1,5])}}
        data[tag]=ref
    out['early_model_sensitivity_relative_to_fine_peak']={tag:dict(zip(SIGNALS,[rel(other-one,one) for other,one in zip(arr.T,data['fine'].T)]))
            for tag,arr in data.items() if tag!='fine'}
    return out


def score(case):
    guard()
    job=Continuation(case,0)
    paths=[ROOT/(case+'-'+str(i)+'-trajectory.npz') for i in range(3)]
    coarse,mid,fine=[pack(path) for path in paths]
    pts=fine['x'];idx=fine['epoch_rows']; method=ARMS[4]; raw=ARMS[2]; old=ARMS[0]
    assert all(np.array_equal(pts,data['x']) for data in (coarse,mid)) and np.array_equal(pts[idx],job.times)
    pair=fine['paired']; cauchy=fine[method];archive=fine[old]; shift=cauchy-archive
    native=job.obj.cols; epochs=np.arange(START,END+1);packet=job.obj.packet[epochs-1991]
    cols={'drive':-packet[:,6],'Weyl_k2':native['Weyl'][epochs],'g2':native['pi_photon'][epochs],
          'slow_pressure':native['mts_dp_s'][epochs],'heavy_pressure':native['mts_dp_h'][epochs]}
    keys=SIGNALS+EXTRA
    replay={key:rel(archive[idx,keys.index(key)]-reference,reference) for key,reference in cols.items()}
    checks={};impact={}
    for i,key in enumerate(SIGNALS[:6]):
        if i==5: continue
        amp=float(fine['amp'])
        small=pair[:,20+i]; recovered=(pair[:,30+i]-pair[:,10+i])/amp
        changes=[z[method][:,i]-z[old][:,i] for z in (coarse,mid,fine)]
        tail=shift[-1,i]
        impact[key]=dict(peak_total_change_over_archive_peak=rel(changes[-1],archive[:,i]),
            post_start_slow_peak_over_archive_peak=rel(small,archive[:,i]),slow_peak_over_total_change_peak=rel(small,changes[-1]),
            inherited_and_other_not_assigned=True,amplification_control_rel_error=rel(recovered-small,small),
            total_change_mesh_rel=[rel(b-a,changes[-1]) for a,b in zip(changes,changes[1:])],
            isolated_slow_mesh_rel=rel(small-mid['paired'][:,20+i],small),
            max_finite_quadrature_change_on_physical_medium=rel(cauchy[:,i]-fine[raw][:,i],changes[-1]),
            max_background_change_at_raw_quadrature=rel(fine[raw][:,i]-archive[:,i],changes[-1]),
            terminal_total_change=float(tail),terminal_slow_effect=float(small[-1]))
    pressure=shift[:,5]; at=int(np.argmax(abs(pressure)))
    contributions=np.column_stack((pair[:,40:46],pair[:,52]))
    memory={}
    for key,site in [('begin',0),('largest',at),('end',-1)]:
        memory[key]={'x':float(pts[site]),'slow_pressure_difference':float(pressure[site]),
                  'signed_parts':dict(zip(CHANNELS+['readout'],contributions[site].tolist())),
                  'signed_shares':dict(zip(CHANNELS+['readout'],(contributions[site]/pressure[site]).tolist()))}
    for tag,data in [('coarse',coarse),('medium',mid),('fine',fine)]:
        metrics=data[ARMS[5]]-data[method]
        checks[tag]={'trace_vs_constraint':{key:rel(metrics[:,j],data[method][:,j]) for j,key in enumerate(keys)},
            'constraint_along_trace_path':rel(data[ARMS[5]][:,10]-data[ARMS[5]][:,0],data[ARMS[5]][:,10]),
            'paired_archive_drive':rel(data['paired'][:,0]-data[old][:,0],data[old][:,0]),
            'paired_physical_drive':rel(data['paired'][:,10]-data[method][:,0],data[method][:,0])}
    results={'epochs':[START,END],'k_per_Mpc':K,'points':len(pts),'native_epoch_count':len(idx),'controls':checks,'archive_replay':replay,
        'impact':impact,'memory':memory,'peak_slow_pressure_change_relative_to_archived_peak':rel(pressure,archive[:,5]),
        'slow_pressure_balance_over_contrast':rel(pressure-contributions.sum(axis=1),pressure),
        'direct_and_induced_Weyl_at_end':[float(pair[-1,53]),float(pair[-1,21]-pair[-1,53])],
        'earlier_history':earlier(job,fine),'start_sha':study.digest(job.epoch),'tolerance':TOL}
    save(case+'-scores.json',results)
    print(case,'archive',replay,'earlier',results['earlier_history']['fine']['clock_peak_relative'],flush=True)


if __name__=='__main__':
    for name in ('cold','heavy'):score(name)
