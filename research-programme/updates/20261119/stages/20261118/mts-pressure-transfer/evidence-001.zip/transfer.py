import os
import sys
from pathlib import Path
for name in ('OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','OMP_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/'mts-species-trace-20261118'
sys.path.insert(0,str(PREV))
from mixed import Experiment,study,np,thermal,NODES,WEIGHTS,K,PTR,CDLL,c_double,c_int,LIB
from scipy.integrate import solve_ivp
import json

SEAL='a881f79738c952aa3d22dca628398db45323c7349d3f9818f0f5a4a083e9f57a'
SWITCH=ROOT.parent/'mts-neutrino-switch-20261118'
SWEEP=CDLL(str(ROOT/'pressure_response.dll'))
SWEEP.paired.argtypes=[c_int,c_double,PTR,PTR,c_double,PTR,PTR];SWEEP.paired.restype=None
LIB.full_sweep.argtypes=[c_int,c_int,c_int,c_double,PTR,PTR,PTR];LIB.full_sweep.restype=None
SIGNALS=['drive','Weyl_k2','photon_anisotropic_stress','photon_pressure','E2','slow_pressure','u_s','w_s','D','Q']
EXTRA=['actual_drive','trace_source','heavy_pressure','cdm','g0','g2','pi_total','u_h','w_h']
CHANNELS=['inherited_u','inherited_w','changed_beta','changed_drive','expansion','mass']
ARMS=[scheme+'_'+metric for scheme in ('archived_raw','physical_raw','physical_enthalpy') for metric in ('hamiltonian','trace')]
START=3038; END=4252; TOL=2e-5


def save(name,value):
    (ROOT/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n',encoding='utf-8')


def guard():
    study.guard()
    assert study.digest(PREV/'closeout.json')==SEAL
    assert not any((base/'STOP-REQUESTED').exists() for base in (ROOT,PREV))


def pack(path):
    with np.load(path,allow_pickle=False) as saved:
        return {key:saved[key] for key in saved.files}


class Continuation:
    def __init__(self,case,level):
        guard()
        self.obj=Experiment(case)
        self.case=case
        self.level=level
        self.times=self.obj.times[START:END+1]
        sig=self.obj.sig[START-1991:END-1990]
        assert np.array_equal(self.times,self.obj.packet[START-1991:END-1990,0]*K)
        assert np.all(sig==sig[:1]) and np.all(self.obj.packet[START-1991:,15]==(1 if case=='cold' else 2))
        if case=='heavy': assert max(abs(self.obj.cols['mts_averaged_chart'][START:END+1]))==0
        self.epoch=PREV/(case+'-epoch3038-restart.npz')
        self.seed=pack(self.epoch)
        assert self.seed['x']==self.times[0] and study.digest(self.epoch)==study.read(PREV/'closeout.json')['files'][self.epoch.name]['sha256']
        self.const=self.obj.bg.constants
        self.masses=self.const[6:6+len(self.seed['species'])]/K
        self.solution=self.background()
        self.amp=(1e32 if case=='cold' else 1e24)

    def background(self):
        initial=np.r_[np.log(float(self.seed['scale'])),np.stack((self.seed['physical_fields'],self.seed['physical_fields_x']),axis=1).ravel()]
        const=self.const
        def rhs(clock,state):
            scale=np.exp(state[0]); fields=state[1::2]; speeds=state[2::2]
            am=scale*const[8]; mass2=(self.masses*scale)**2
            rho=1+am**2*(5/(7*np.pi**2)+am**2*(.01099926669*np.log(am)-.003492416767-.005866275571*am))
            total=((const[0]+const[1])/scale+(const[2]+const[3]+const[14]*rho)/scale**2)/K**2
            hub=np.sqrt((total+sum(speeds**2+mass2*fields**2)/2)/3)
            rate=np.empty_like(state)
            rate[0]=hub;rate[1::2]=speeds;rate[2::2]=-2*hub*speeds-mass2*fields
            return rate
        absolute=[2e-15,1e-14,1e-27]+([2e-18,2e-18] if self.case=='heavy' else [])
        sol=solve_ivp(rhs,(self.times[0],self.times[-1]),initial,method='DOP853',dense_output=True,
                      max_step=.04/(2**min(self.level,2)),rtol=4e-13,atol=absolute)
        assert sol.success and np.allclose(sol.y[:,0],initial,rtol=0,atol=0)
        return sol.sol

    def media(self,points):
        old,geo=self.obj.medium(points)
        phys=old.copy()
        state=self.solution(points);scale=np.exp(state[0]); fields=state[1::2].T; speeds=state[2::2].T
        mass2=(scale[:,None]*self.masses)**2;const=self.const
        rho,pressure=thermal(scale*const[8])
        phys[:,2:7]=const[[0,1,2,3,14]]/(scale[:,None]**[1,1,2,2,2]*K**2)
        phys[:,1]=np.sqrt((phys[:,2:6].sum(axis=1)+phys[:,6]*rho+(speeds**2+mass2*fields**2).sum(axis=1)/2)/3)
        for idx in range(fields.shape[1]):
            phys[:,7+3*idx:10+3*idx]=np.column_stack((speeds[:,idx],mass2[:,idx]*fields[:,idx],mass2[:,idx]))
        phys[:,15:20]=1/np.sqrt(1+(scale[:,None]*const[8]/NODES)**2)
        phys[:,25]=(rho+pressure)/((4/3)*((1/phys[:,15:20])@WEIGHTS))
        return old,phys,np.column_stack((geo['scale'],scale,old[:,1],phys[:,1],old[:,7],phys[:,7],old[:,8],phys[:,8]))


def observe(state,med,out):
    slowkin=med[:,7]*state[:,91]; slowpot=med[:,8]*state[:,90]
    heavykin=med[:,10]*state[:,183]; heavypot=med[:,11]*state[:,182]
    speed=med[:,15:20];mom=state[:,97:182:17]
    dens=med[:,2]*state[:,93]+med[:,3]*state[:,0]+med[:,4]*state[:,2]+med[:,5]*state[:,94]+med[:,6]*((mom/speed)@WEIGHTS)+slowkin+slowpot+heavykin+heavypot
    flux=med[:,3]*state[:,1]+med[:,4]*state[:,3]+med[:,5]*state[:,95]+med[:,6]*(state[:,98:182:17]@WEIGHTS)+med[:,7]*state[:,90]+med[:,10]*state[:,182]
    pi=med[:,4]*state[:,4]+med[:,5]*state[:,96]+med[:,6]*((state[:,99:182:17]*speed)@WEIGHTS)
    return np.column_stack((out[:,0],-12.5*(dens+3*med[:,1]*flux+pi),med[:,4]*state[:,4],med[:,4]*state[:,2]/3,
            state[:,47],25*(slowkin-slowpot),state[:,90],state[:,91],dens,flux,
            out[:,1],out[:,2],25*(heavykin-heavypot),state[:,93],state[:,2],state[:,4],pi,state[:,182],state[:,183]))


def run(case,level):
    job=Continuation(case,level)
    endpoints=job.times
    base=2**np.maximum(0,np.ceil(np.log2(np.diff(endpoints)/.032)).astype(int))
    factor=8*2**level
    counts=factor*base
    state={arm:job.seed[arm].copy() for arm in ARMS}
    old=state[ARMS[0]].copy();real=state[ARMS[4]].copy()
    control=real.copy();control[[90,91,184]]=0
    pair=np.r_[old,real,np.zeros(185),control,np.zeros(12)]
    pair[-12]=real[90]-old[90];pair[-9]=real[91]-old[91]
    records={key:[] for key in ['x','medium','paired']+ARMS}
    for idx,(lo,hi,count) in enumerate(zip(endpoints[:-1],endpoints[1:],counts)):
        if idx%100==0: guard()
        chunk=min(1024,count)
        for offset in range(0,count,chunk):
            size=min(count-offset,chunk)
            dt=(hi-lo)/count
            ts=lo+dt*(np.arange(2*size+1)/2+offset)
            if offset+size==count: ts[-1]=hi
            old,phys,bg=job.media(ts)
            keep=np.arange(0,size+1,factor)
            if idx or offset: keep=keep[1:]
            records['x'].append(ts[2*keep]);records['medium'].append(bg[2*keep])
            for j,arm in enumerate(ARMS):
                med=old if j<2 else phys
                states=np.empty((size+1,185));obs=np.empty((size+1,3));states[0]=state[arm]
                LIB.full_sweep(j%2,j>=4,size,dt,med,states,obs)
                assert np.all(np.isfinite(states[-1]))
                state[arm]=states[-1].copy()
                records[arm].append(observe(states[keep],med[2*keep],obs[keep]))
            responses=np.empty((size+1,56))
            SWEEP.paired(size,dt,old,phys,job.amp,pair,responses)
            assert np.all(np.isfinite(responses))
            records['paired'].append(responses[keep])
    data={key:np.concatenate(vals) for key,vals in records.items()}
    idx=np.searchsorted(data['x'],endpoints)
    assert np.array_equal(data['x'][idx],endpoints)
    assert np.array_equal(pair[:185],state[ARMS[0]]) and np.array_equal(pair[185:370],state[ARMS[4]])
    data['epoch_rows']=idx;data['columns']=np.array(SIGNALS+EXTRA);data['amp']=job.amp
    np.savez_compressed(ROOT/(case+'-'+str(level)+'-trajectory.npz'),**data)
    final=job.solution(endpoints[-1])
    np.savez(ROOT/(case+'-'+str(level)+'-restart.npz'),**state,pair=pair,x=endpoints[-1],scale=np.exp(final[0]),
        physical_fields=final[1::2],physical_fields_x=final[2::2],species=job.seed['species'])
    print(case,level,'accepted',int(sum(counts)),'steps and',len(data['x']),'common readouts',flush=True)


if __name__=='__main__':
    for level in map(int,sys.argv[1:] or ['0','1','2']):
        for case in ('cold','heavy'): run(case,level)
