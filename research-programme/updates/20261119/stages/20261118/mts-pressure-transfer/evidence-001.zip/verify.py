from score import *
from datetime import datetime,timezone
import csv


def main():
    guard()
    checks={}; sources={}; not_resolved=[]
    def test(name,value):
        if not value:raise RuntimeError(name)
        checks[name]=True
    prior=study.read(PREV/'closeout.json')['files']
    for file,rec in prior.items():
        path=PREV/file
        test('prior '+file,study.digest(path)==rec['sha256'] and path.stat().st_size==rec['bytes'])
    def own_source(path):
        path=Path(path)
        sources[str(path.relative_to(ROOT.parent))]=study.digest(path)
    for case in ('cold','heavy'):
        obj=Experiment(case)
        for path in obj.source_paths:own_source(path)
        own_source(PREV/(case+'-epoch3038-restart.npz'))
        scoring=study.read(ROOT/(case+'-scores.json'))
        for tag in ('fine','main','angular','highq','trace'):
            path=SWITCH/(case+'-'+tag+'-both-late.npz');own_source(path)
            test(case+tag+' existing origin',study.digest(path)==scoring['earlier_history'][tag]['source_sha256'])
        hi=pack(ROOT/(case+'-2-trajectory.npz'));start=pack(PREV/(case+'-epoch3038-restart.npz'));end=pack(ROOT/(case+'-2-restart.npz'))
        test(case+' original clocks all covered',np.array_equal(hi['x'][hi['epoch_rows']],obj.times[START:END+1]) and len(hi['epoch_rows'])==1215)
        test(case+' signed chart unchanged',np.all(obj.sig[START-1991:]==obj.sig[START-1991]))
        test(case+' recorded restart reach',end['x']==hi['x'][-1]==obj.times[END] and start['x']==hi['x'][0]==obj.times[START])
        for arm in ARMS:
            series=hi[arm]
            test(case+arm+' start state',np.array_equal(start[arm][[90,91,182,183]],series[0,[6,7,17,18]]))
            test(case+arm+' terminal state',np.array_equal(end[arm][[90,91,182,183]],series[-1,[6,7,17,18]]) and np.all(np.isfinite(end[arm])))
        test(case+' augmented RK equations bit-identical terminals',np.array_equal(end['pair'][:185],end[ARMS[0]]) and np.array_equal(end['pair'][185:370],end[ARMS[4]]))
        tests=scoring['controls']['fine']['trace_vs_constraint']
        test(case+' alternate physical Einstein trajectory',max(x for x in tests.values() if x is not None)<TOL)
        test(case+' archive common observables validated',max(x for x in scoring['archive_replay'].values() if x is not None)<TOL)
        paired=hi['paired'];pp=hi[ARMS[4]][:,5]-hi[ARMS[0]][:,5]
        test(case+' causal pressure split',rel(pp-np.sum(paired[:,40:46],axis=1)-paired[:,52],pp)<TOL)
        for i,name in enumerate(SIGNALS[:5]):
            projected=paired[:,20+i]
            recovered=(paired[:,30+i]-paired[:,10+i])/hi['amp']
            test(case+name+' independent amplification test',rel(recovered-projected,projected)<TOL)
            if scoring['impact'][name]['total_change_mesh_rel'][-1]>TOL:
                not_resolved.append(case+' '+name+' mesh precision of within-branch (physical minus archived) difference')
            if scoring['impact'][name]['isolated_slow_mesh_rel']>TOL:
                not_resolved.append(case+' '+name+' mesh precision of isolated slow contribution')
        test(case+' earlier scale support',scoring['earlier_history']['fine']['matched_scale_epochs']==1214)
        test(case+' earlier preparation pressure distinction', (scoring['earlier_history']['fine']['clock_peak_relative']['slow_pressure']>1)==(case=='heavy'))
        potential=study.read(ROOT/(case+'-potential.json'))
        test(case+' independent scale and clock integrations',max(potential['131072'].values())<TOL)
        dense=pack(ROOT/(case+'-dense-physical.npz'))
        test(case+' lens and acceleration potentials',rel(.5*(dense['curvature_k2']+dense['lapse_k2'])-dense['physical'][:,1],dense['physical'][:,1])<1e-13)
        test(case+' density-only not spuriously exact',potential['newtonian_density_diagnostic']['max_fractional_Weyl_error_if_D_only']>TOL)
    common=pack(ROOT/'common-scale-2.npz');scorecard=study.read(ROOT/'common-scale-scores.json')
    test('shared scale strictly increasing',np.all(np.diff(common['log_a'])>0))
    sig=common['signals'];change=sig[:,1]-sig[:,0];reconstructed=np.sum(sig[:,2:],axis=1)
    for i,name in enumerate(SIGNALS):
        test(name+' common scale superposition',rel(change[:,i]-reconstructed[:,i],change[:,i])<TOL)
        test(name+' common scale resolution of individual shares',scorecard['observable'][name]['worst_channel_mesh_change_over_contrast']<TOL)
    env=study.read(ROOT/'heavy-envelope.json'); reference=pack(ROOT/'heavy-density-envelope.npz')
    for stride in ('2','1'):
        test('field response at sampling '+stride,env[stride]['rho_comoving_derived_vs_direct_peak_rel']<TOL)
        test('forcing deletion is detectable '+stride,env[stride]['WKB_unforced_controls']['no_external_metric_forcing_rel_error']>1)
    test('conditional density response from saved fields',rel(reference['driven']-reference['true_comoving'],reference['true_comoving'])<TOL)
    test('lowest perturbation kernel specifically fails tolerance',env['1']['WKB_conditional_source_relative_errors'][0]>TOL)
    test('homogeneous replacement versus perturbation replacement',peak(reference['background_density']/reference['removed_background']-1)<.001 and
         peak(reference['true_comoving'][reference['overlap_mask']]/reference['required_clustering'])<.002)
    with (ROOT/'four-mode-archive-check.csv').open(newline='',encoding='utf-8') as file:
        modes=list(csv.DictReader(file))
    audit=study.read(ROOT/'four-mode-archive-check.json')
    test('all preregistered shared archive modes', [float(r['k_Mpc_inv']) for r in modes]==[.03,.1,1.,5.] and audit['archive_only'] and audit['frozen_test']==study.digest(ROOT/'SCALE-TEST.md'))
    test('short-wave inequality checked without hiding opposite sign',audit['short_mode_less_clustered_than_both_long_modes'] and float(modes[2]['last_signed_fraction'])<0)
    for name,sha in audit['source_hashes'].items():
        path=ROOT.parent/name;test('four-mode input '+name,study.digest(path)==sha);own_source(path)
    own_source(ROOT.parent/'condensate-origin-20261003/resolved-matter-spectrum-20261007/RESULTS.md')
    test('negative precision controls documented',len(not_resolved)>0)
    test('no staged numerical scratch or local bytecode',not (ROOT/'__pycache__').exists() and not any(p.suffix in ('.obj','.exp','.lib') for p in ROOT.iterdir()))
    save('verification.json',{'checks':checks,'source_hashes':sources,'nonpassing_numeric_sensitivities':not_resolved,'previous_sealed_files':len(prior),'tolerance':TOL})
    files={p.name:{'bytes':p.stat().st_size,'sha256':study.digest(p)} for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='closeout.json'}
    save('closeout.json',{'utc':datetime.now(timezone.utc).isoformat(),'prior':SEAL,'files':files})
    print(len(checks),'checks;',len(not_resolved),'precision limits retained;',len(files),'artifacts;',sum(x['bytes'] for x in files.values()),'bytes;',study.digest(ROOT/'closeout.json'))


if __name__=='__main__':main()
