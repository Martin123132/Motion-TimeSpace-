from score import *


def resolved(case):
    guard()
    obj=Continuation(case,2)
    left,right=obj.times[[0,-1]]
    common=pack(ROOT/'common-scale-2.npz')
    slot=0 if case=='cold' else 1
    matched=common['clocks'][:,slot]
    result={}
    for steps in (65536,131072):
        step=(right-left)/steps
        stride=steps//32768
        initial=obj.seed[ARMS[4]].copy()
        rows=[];clocks=[];background=[]
        for offset in range(0,steps,1024):
            points=left+step*(np.arange(2049)/2+offset)
            if offset+1024==steps:points[-1]=right
            _,med,bg=obj.media(points)
            states=np.empty((1025,185));obs=np.empty((1025,3));states[0]=initial
            LIB.full_sweep(0,1,1024,step,med,states,obs)
            initial=states[-1].copy()
            keep=np.arange(stride if offset else 0,1025,stride)
            rows.append(observe(states[keep],med[2*keep],obs[keep]))
            clocks.append(points[2*keep]);background.append(bg[2*keep])
        vals=np.vstack(rows);clock=np.concatenate(clocks);bg=np.vstack(background)
        compare=CubicSpline(clock,vals)(matched)[:,:10]
        result[str(steps)]={key:rel(compare[:,i]-common['signals'][:,slot,i],common['signals'][:,slot,i]) for i,key in enumerate(SIGNALS)}
        assert peak(obj.solution(matched)[0]-common['log_a'])<2e-14
        assert max(result[str(steps)].values())<TOL
    dens,flux,stress=vals[:,8],vals[:,9],vals[:,16]
    h=bg[:,3]
    bare=-12.5*dens;curvature=-12.5*(dens+3*h*flux)
    lapse=curvature-25*stress;lens=.5*(curvature+lapse)
    assert np.all(abs(lens)>0) and rel(lens-vals[:,1],vals[:,1])<1e-14
    error=abs((lens-bare)/lens)
    bound=12.5*(abs(3*h*flux)+abs(stress))/abs(lens)
    assert np.all(error<=bound+4e-16)
    result['newtonian_density_diagnostic']={'max_fractional_Weyl_error_if_D_only':peak(error),
        'max_triangle_bound_at_samples':peak(bound),'max_fractional_Weyl_error_with_comoving_density':peak((lens-curvature)/lens),
        'max_fractional_lensing_vs_lapse_difference':peak((lens-lapse)/lapse),
        'terminal_density_only_error':float((bare[-1]-lens[-1])/lens[-1]),'nonzero_Weyl_min_abs':float(min(abs(lens)))}
    np.savez_compressed(ROOT/(case+'-dense-physical.npz'),x=clock,physical=vals,background=bg,curvature_k2=curvature,lapse_k2=lapse)
    save(case+'-potential.json',result)
    print(case,result['newtonian_density_diagnostic'],flush=True)


if __name__=='__main__':
    for case in ('cold','heavy'):resolved(case)
