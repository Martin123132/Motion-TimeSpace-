from forward_bank import *
from propagate import advance
from model import Medium
from types import SimpleNamespace

def predict(case,carried,dx):
    track=Future(case);proj=SimpleNamespace(track=track,norm=track.norm)
    tag=('carried' if carried else 'centre')+('-fine' if dx<.04 else '')
    model=Medium(case,proj,144,True,0,True)
    if carried:
        with np.load(HERE/('fine-'+case+'.npz')) as packet:state=packet['states'][-1];rays=packet['rays_3']
    else:
        state=np.array(load(HERE/('scores-'+case+'.json'))['rows'][-1]['state'])
        with np.load(SOURCE/('matching-restart-'+case+'.npz')) as packet:rays=packet['phase_smoothed_angular_rays']
    points=track.t[:-1];begin=points[0];last=points[-1]
    knots=np.unique(np.r_[points,np.linspace(begin,last,1+int(np.ceil((last-begin)*MODE/dx)))])
    from propagate import NODES
    step=np.diff(knots);steps=model.data((knots[:-1,None]+step[:,None]*NODES).ravel()).reshape(len(step),2,-1)
    station=model.data(knots);states=[];diag=[];captures={}
    for pos,time in enumerate(knots):
        states.append(state.copy());diag.append(model.diagnostics(station[pos],state,rays))
        if time in points:captures['rays_'+str(np.flatnonzero(points==time)[0])]=rays.copy()
        if pos<len(step):state,rays=advance(model,steps[pos],state,rays,step[pos])
    states=np.array(states);diag=np.array(diag);assert np.isfinite(states).all() and np.isfinite(diag).all()
    store('forecast-'+tag+'-'+case+'.npz',time=knots,states=states,report=diag,anchors=points,**captures)
    print(case,tag,states[-1,:4],diag[-1,5:7])
def freeze():
    assert not list(HERE.glob('forward-bank-exact-*')) and not list(HERE.glob('heldout-field-*'))
    files=[*HERE.glob('forecast-*.npz'),*HERE.glob('forward-bank-matched-*'),*(HERE/key for key in ('forecast.py','propagate.py','model.py','forward_bank.py','FORWARD-TEST.md','support.py','prepare.py','fine-heavy.npz','fine-cold.npz','scores-heavy.json','scores-cold.json'))]
    assert len(list(HERE.glob('forecast-*.npz')))==6
    save('forecast-freeze.json',dict(files={p.name:digest(p) for p in files},scales=FORWARD_SCALES,resolution=[.04,.025],
         heldout_kind='uncomputed exact nonlinear field continuation; not observational data'))
if __name__=='__main__':
    guard()
    for case in ('heavy','cold'):
        for carry,dx in ((True,.04),(True,.025),(False,.025)):predict(case,carry,dx)
    freeze()

