from support import *
from scipy.integrate import solve_ivp

def hull(spline,mesh):
    h=np.diff(mesh)
    return np.array([spline(mesh[:-1]),spline(mesh[:-1])+h*spline(mesh[:-1],1)/3,
                     spline(mesh[1:])-h*spline(mesh[1:],1)/3,spline(mesh[1:])])

class Slow:
    def __init__(self,case):
        with np.load(OLD/(case+'-native.npz')) as native,np.load(EARLY/(case+'.npz')) as bg:
            times=native['uniform'];raw=native['raw'][np.searchsorted(native['t'],times)]
            names=native['names'].tolist();field=lambda name:raw[:,names.index(name)]
            aval=field('a');self.mass=float(bg['slow_mass_mpc'])
            self.time=times;self.const=CubicSpline(times,np.column_stack([CubicSpline(bg['efold'],bg['phi_s'])(np.log(aval)),
                CubicSpline(bg['efold'],bg['phidot_s'])(np.log(aval)),field('mts_dphi_s'),field('mts_dphidot_s')]),axis=0,extrapolate=False)
    def prep(self,case):
        proj=Projection(case);track=proj.track
        with np.load(PRIOR/('restart-'+case+'.npz')) as src,np.load(SOURCE/('refined-'+case+'.npz')) as late:
            early=src['tau']<late['times'][0];ts=np.r_[src['tau'][early],late['times']]
            exp=CubicSpline(ts,np.r_[src['core'][early,1],late['states'][:,1]])
        time=self.time;phy=track.physics(time);a,hub,rate,eta=phy[:,0],phy[:,1],phy[:,8],phy[:,12]
        f0,p0,f1,p1=self.const(time).T
        force=CubicSpline(time,exp(time)*p0+rate*p1-2.5*MODE**2*eta*f1,extrapolate=False)
        mass2=(a*self.mass)**2
        coef=CubicSpline(time,np.c_[hub,mass2],axis=0,extrapolate=False)
        def solve(start):
            initial=-.75*self.const(time[start])[2:]*1e15
            def rhs(t,y):
                hh,mm=coef(t);return [y[1],-2*hh*y[1]-(MODE**2+mm)*y[0]+1e15*force(t)]
            sol=solve_ivp(rhs,(time[start],time[-1]),initial,t_eval=time[start:],rtol=2e-11,atol=1e-17,
                          method='DOP853',max_step=.12)
            assert sol.success
            return sol.y.T*1e-15
        solution=solve(0);other=solve(20)
        omega=np.sqrt(MODE**2+mass2)
        bound=omega[-1]/omega[0]*(np.hypot(solution[0,1],omega[0]*solution[0,0])+np.sum(np.diff(time)*np.mean(abs(hull(force,time)),axis=0)))
        max_field=[np.max(abs(hull(CubicSpline(time,column),time))) for column in [f0,p0,f1,p1]]
        ff,pf,df,dp=max_field;mm=max(mass2)
        active_bound=(2*pf+mm*ff/MODE)*bound+dp**2+.5*mm*df**2
        flux_bound=pf*bound+.5*MODE*df*dp
        energy_bound=(pf+mm*ff/MODE)*bound+.5*(dp**2+(mm+abs(MU)*MODE**2)*df**2)
        osc=np.hypot(omega*solution[:,0],solution[:,1])
        assert max(osc)<=bound
        slow,prime=solution.T
        energy=p0*prime+mass2*f0*slow+.5*(p1**2+(mass2-MU*MODE**2)*f1**2)
        active=2*p0*prime-mass2*f0*slow+p1**2-.5*mass2*f1**2
        flux=MODE*(p0*slow+.5*p1*f1)
        assert max(abs(energy))<=energy_bound and max(abs(active))<=active_bound and max(abs(flux))<=flux_bound
        store('slow-'+case+'.npz',time=time,field=solution,energy=energy,active=active,flux=flux,forcing=force(time))
        return dict(initiality='regular adiabatic, no independent slow entropy mode',first_x=MODE*time[0],alternate_x=MODE*time[20],
            max_state_norm=float(max(osc)),norm_bound=float(bound),later_start_difference=float(np.max(np.abs(other-solution[20:]))),
            max_active=float(max(abs(active))),max_energy=float(max(abs(energy))),max_flux=float(max(abs(flux))),
            active_bound=float(active_bound),energy_bound=float(energy_bound),flux_bound=float(flux_bound))
if __name__=='__main__':
    guard();rows={case:Slow(case).prep(case) for case in ('heavy','cold')};save('slow-bound.json',rows);print(rows)

