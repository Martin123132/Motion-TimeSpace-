from pathlib import Path
import sys
HERE=Path(__file__).resolve().parent
SOURCE=HERE.parent/'mts-polarized-counterflow-20261118'
sys.path.insert(0,str(SOURCE))
from common_local import PRIOR,OLD,EARLY,MODE,MU,np,CubicSpline,digest,load
from linear_tail import FullTrack
from histories import PROJ
from scipy.interpolate import CubicHermiteSpline
import json
def guard():
    assert digest(SOURCE/'closeout.json')=='2dab8a4231fd6e1cf60f8772ff0627eef0810ebc2c2d1c95ea300a5f855b0d2b'
    assert not any((d/'STOP-REQUESTED').exists() for d in [HERE,HERE.parent,SOURCE,PRIOR,OLD])
def save(file,body):
    with (HERE/file).open('x',encoding='utf8') as target:json.dump(body,target,indent=2,allow_nan=False)
def store(file,**arrays):
    with (HERE/file).open('xb') as target:np.savez_compressed(target,**arrays)
class Projection:
    def __init__(self,case):
        self.track=FullTrack(case)
        with np.load(PROJ) as data:self.match=float(data['matching_scale']);self.norm=float(data['matching_density'])
        with np.load(EARLY/'heavy.npz') as data:self.phase=CubicSpline(data['heavy_efold'],data['phase_h'])
        time=np.linspace(110/MODE,self.track.end,12001);scale=self.track.physics(time)[:,0];angle=self.phase(np.log(scale))
        self.inverse=CubicSpline(angle,time,extrapolate=False);self.angle_range=angle[[0,-1]]
        self.centres=[.00015,.00018,.0002,self.match]
    def time(self,scale):return self.inverse(self.phase(np.log(scale)))
    def kernel(self,scale):
        u=np.linspace(-1,1,701)
        angle=self.phase(np.log(scale))+6*np.pi*u
        assert angle[0]>=self.angle_range[0]-1e-6 and angle[-1]<=self.angle_range[-1]+1e-6
        times=self.inverse(np.clip(angle,*self.angle_range))
        basis=np.column_stack([u**i for i in range(9)]+[u**i*fn(h*angle) for h,upper in [(2,6),(4,3)] for i in range(upper+1) for fn in [np.sin,np.cos]])
        return times,np.linalg.pinv(basis)[0]
    def forcing(self,scale):
        times,weights=self.kernel(scale)
        a,_,_,_,_,_,_,dc,rate,_,_,_,eta,f0,p0,ma,f1,p1=self.track.physics(times).T
        weight=a/self.norm;q1=weight*MODE*p0*f1
        return np.array([weight*p0**2,2*weight*rate*p0*p1-2.5*MODE*eta*q1,.5*rate*q1,weight*(p0**2+ma*f0**2)/2,weight*(p0*p1+ma*f0*f1),q1,rate,eta])@weights

