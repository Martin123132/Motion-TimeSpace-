from support import *
from scipy.integrate import cumulative_simpson

def split(case):
    proj=Projection(case);trk=proj.track
    with np.load(HERE/('fine-'+case+'.npz')) as data:
        t=data['times'];curve=CubicSpline(t,data['states'],axis=0);diag=CubicSpline(t,data['report'],axis=0)
    with np.load(SOURCE/('refined-'+case+'.npz')) as data:
        times=data['times'];states=data['states'];report=data['report']
    with np.load(PRIOR/('restart-'+case+'.npz')) as src:
        tau=src['tau'];seed=load(PRIOR/'restart.json')['cases'][case]['regular']['quadratic_tide']
        eta0=(-5.625+3)/4+(seed-3/8)*(MODE*tau[0])**2/6
        eta0+=cumulative_simpson((src['diagnostics'][:,8]+src['core'][:,1])/3,x=tau,initial=0.)[tau.tolist().index(times[0])]
    curvature=eta0+cumulative_simpson((states[:,1]+report[:,2])/3,x=times,initial=0.)
    exp=CubicSpline(times,states[:,1]);eta2=CubicSpline(times,curvature);energy=CubicSpline(times,report[:,4])
    def incoming(at):
        phy=trk.physics(at);wave=trk.photons(at)
        cdm,bary,dc,rate,shear,eta=phy[:,2],phy[:,3],phy[:,7],phy[:,8],phy[:,11],phy[:,12]
        return np.column_stack([MODE**2*(3*dc**2/8-9*dc*eta/4-45*eta**2/8),2*rate**2/3,-(MU**2-1/3)*shear**2,
                                -cdm*dc**2-bary*(wave[:,2]**2-MU*wave[:,3]**2)])
    out=[]
    for scale in np.geomspace(proj.centres[0],proj.match,81):
        tc=float(proj.time(scale));tt,w=proj.kernel(scale);phy=trk.physics(tt)
        lin=w@incoming(tt)-incoming(np.array([tc]))[0]
        src=incoming(tt);field_h=w@(src[:,:3].sum(axis=1)-4*MODE**2*eta2(tt)-4*phy[:,1]*exp(tt)-2*energy(tt))
        local=curve(tc);native=trk.physics(tc);observed=diag(tc)
        corrected=(w@src).sum()-4*MODE**2*local[-1]-4*native[1]*local[1]-2*(observed[3]+native[2]*local[0]+native[3]*local[4]+native[4]*local[6]+local[2]*proj.norm/native[0])
        straight=corrected-lin.sum()
        out.append([scale,field_h,straight,corrected,*lin])
    arr=np.array(out)
    return dict(columns=['a','field','instantaneous_products','projected_products','ricci_change','rate_change','shear_change','density_change'],rows=out,
                before_peak=float(np.max(abs(arr[:,2]-arr[:,1]))),after_peak=float(np.max(abs(arr[:,3]-arr[:,1]))),
                direct_field_peak=float(np.max(abs(arr[:,1]))),projected_residual_peak=float(np.max(abs(arr[:,3]))))
if __name__=='__main__':
    guard();rows={case:split(case) for case in ('heavy','cold')};save('constraint-products.json',rows)
    for case in rows:print(case,{k:v for k,v in rows[case].items() if 'peak' in k})

