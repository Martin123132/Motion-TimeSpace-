from forward_bank import *
from forward_score import score
from gauge_current import evaluate
from gauge_pair import point
def check():
    guard();require_freeze()
    outcomes={};rows={};match=load(HERE/'forward-test.json');slow=load(HERE/'slow-bound.json')
    for case in ('heavy','cold'):
        ref=load(HERE/('scores-'+case+'.json'));constraint=load(HERE/'constraint-products.json')[case]
        outcomes[case+'_seed_bitwise_replay']=ref['bit_exact_replay_x160']
        with np.load(HERE/('fine-'+case+'.npz')) as f, np.load(HERE/('common-'+case+'.npz')) as base,np.load(HERE/('no-stress-'+case+'.npz')) as dust,np.load(HERE/('later-'+case+'.npz')) as late:
            y=f['states'][-1];truth=np.array(ref['rows'][-1]['state']);err=y-truth
            rows[case]=dict(overlap_delta=err.tolist(),control_error=(dust['states'][-1]-truth).tolist(),switch_shift=(late['states'][-1]-y).tolist(),
                            step_and_source_grid_shift=(base['states'][-1]-y).tolist(),disable_stress_radiation_change=(dust['report'][-1,:3]-f['report'][-1,:3]).tolist())
            outcomes[case+'_posterior_step_check']=max(abs(base['states'][-1]-y))<.001
            outcomes[case+'_overlap_radiation']=max(abs(err[4:32]))<.001
            outcomes[case+'_hamiltonian_separation']=constraint['after_peak']<constraint['before_peak'] and constraint['projected_residual_peak']>0
            if case=='heavy':
                outcomes['pressure_affects_momentum']=abs(err[3])<.01*abs(rows[case]['control_error'][3])
                outcomes['metric_feedback_to_photons_and_neutrinos']=abs(dust['states'][-1,7]-y[7])>.001 and abs(dust['report'][-1,1]-f['report'][-1,1])>1e-8
            else:outcomes['cold_mutation_null']=np.array_equal(dust['states'],f['states'])
        reference=match[case]
        outcomes[case+'_forward_score_replay']=reference==score(case)
        norm=np.max(np.abs(reference['direct_reference']),axis=0);errors=np.array(reference['scores']['carried-fine']['error'])
        rows[case]['forward_component_error_per_reference_peak']=(np.max(abs(errors),axis=0)/np.maximum(norm,1e-30)).tolist()
        rows[case]['forward_stage_end_hamiltonian']={}
        for tag in ('carried','carried-fine','centre-fine'):
            with np.load(HERE/('forecast-'+tag+'-'+case+'.npz')) as packet:
                rows[case]['forward_stage_end_hamiltonian'][tag]=float(packet['report'][-1,7])
        allreports=[]
        for pattern in ['common','fine','later','no-stress','forecast-carried','forecast-carried-fine','forecast-centre-fine','heldout-field-main','heldout-field-fine']:
            with np.load(HERE/(pattern+'-'+case+'.npz')) as data:
                block=data['report'][:,5:7] if pattern.startswith('heldout-field') else data['report'][:,9:11]
                allreports.append(np.max(abs(block),axis=0))
        outcomes[case+'_unchanged_collision_gate']=np.max(allreports)<1e-8
        rows[case]['peak_exchange']=np.max(allreports,axis=0).tolist()
        gs=load(HERE/'gauge-pair.json')[case];vs=load(HERE/'gauge-current.json')[case]
        for index,(g,v) in enumerate(zip(gs,vs)):
            assert point(case,index)==g and evaluate(case,index)==v
            assert abs(g['newtonian_relative']-g['replay'][str((False,1,0))])<.001
            assert max(abs(np.array([v['newtonian_orthonormal_relative_momentum'],v['newtonian_energy_frame_relative_velocity']])-v['direct_tensor_replay'][str((11,False))]))<2e-6
            assert abs(g['replay'][str((False,1,13))]-g['replay'][str((False,1,0))])<3e-6
        outcomes[case+'_gauge_replay']=len(gs)==len(vs)==3
        s=slow[case];outcomes[case+'_slow_forcing_bound']=s['max_state_norm']<=s['norm_bound'] and s['max_energy']<s['energy_bound'] and s['max_active']<s['active_bound'] and s['max_flux']<s['flux_bound']
    return dict(gates={k:bool(v) for k,v in outcomes.items()},scores=rows,forecast_seal=digest(HERE/'forecast-freeze.json'))
if __name__=='__main__':
    r=check();assert all(r['gates'].values())
    if '--write' in sys.argv:save('validation.json',r)
    else:assert r==load(HERE/'validation.json')
    print(r['gates'])

