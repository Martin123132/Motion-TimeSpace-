from forward_bank import *
from argparse import Namespace
from evolution import Solver,C
from photon_source import PhotonSource
from scipy.integrate import cumulative_simpson

def raw_metric_start(case):
    with np.load(SOURCE/('refined-'+case+'.npz')) as ref:
        t=ref['times'];core=ref['states'];report=ref['report']
    with np.load(PRIOR/('restart-'+case+'.npz')) as saved:
        tau=saved['tau'];tidal=load(PRIOR/'restart.json')['cases'][case]['regular']['quadratic_tide']
        eta0=(-5.625+3)/4+(tidal-3/8)*(MODE*tau[0])**2/6
        eta0+=cumulative_simpson((saved['diagnostics'][:,8]+saved['core'][:,1])/3,x=tau,initial=0.)[tau.tolist().index(t[0])]
    return float(eta0+cumulative_simpson((core[:,1]+report[:,2])/3,x=t,initial=0.)[t.tolist().index(FullTrack(case).center)])

def solve(case,dphase):
    require_freeze();guard();cfg=Namespace(**load(SOURCE/('refined-'+case+'.json')))
    solver=Solver(case,cfg);track=Future(case,exact=True);solver.track=track;ph=PhotonSource(track,12)
    trial=np.linspace(track.start,track.end,2201);phy=track.physics(trial)
    arc=np.r_[0,np.cumsum(np.diff(trial)*.5*(np.sqrt(phy[:-1,15]+MODE**2)+np.sqrt(phy[1:,15]+MODE**2))/dphase)]
    t=np.unique(np.r_[track.t,np.interp(np.linspace(0,arc[-1],1+int(np.ceil(arc[-1]))),arc,trial)])
    solver.grid=t;phases=t[:-1,None]+np.diff(t)[:,None]*C;phases[:,-1]=t[1:]
    def inp(time):
        g,c,o=ph.evaluate(time,extra=0);return np.c_[track.physics(time),track.photons(time),g,c,np.zeros(len(time))]
    solver.inputs=inp(phases.ravel()).reshape(len(t)-1,3,-1);station=inp(t)
    with np.load(SOURCE/('matching-restart-'+case+'.npz')) as start:
        assert start['coordinate_time']==t[0] and np.array_equal(start['angular_mu'],solver.axis)
        state=start['exact_coordinate_core'];rays=start['exact_angular_rays']
    states=[];records=[]
    for i in range(len(t)):
        states.append(state.copy());records.append(solver.report(station[i],state,rays))
        if i+1<len(t):state,rays=solver.integrate(i,state,rays)
    states=np.array(states);records=np.array(records);assert np.isfinite(states).all() and np.isfinite(records).all()
    eta=raw_metric_start(case)+cumulative_simpson((states[:,1]+records[:,2])/3,x=t,initial=0.)
    tag='fine' if dphase<.16 else 'main'
    store('heldout-field-'+tag+'-'+case+'.npz',times=t,states=states,report=records,eta2=eta,final_rays=rays)
    print(case,tag,len(t),'exchange',np.max(abs(records[:,5:7]),axis=0),flush=True)
if __name__=='__main__':
    for case in ('heavy','cold'):
        for step in (.17,.11):solve(case,step)

