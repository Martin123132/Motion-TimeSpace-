from checks import check
from support import *
def manifest():
    guard();old=load(SOURCE/'closeout.json')
    inputs={**old['inputs'],**{SOURCE.name+'/'+key:val for key,val in old['files'].items()},SOURCE.name+'/closeout.json':digest(SOURCE/'closeout.json')}
    for key,val in inputs.items():assert digest(HERE.parent/key)==val,key
    assert not any(p.is_dir() for p in HERE.iterdir())
    for path in HERE.glob('*.py'):compile(path.read_text(encoding='utf8'),path.name,'exec')
    for path in HERE.glob('*.json'):load(path)
    for path in HERE.glob('*.npz'):
        with np.load(path,allow_pickle=False) as bank:
            for key in bank.files:
                arr=bank[key]
                if np.issubdtype(arr.dtype,np.number):assert np.isfinite(arr).all(),(path,key)
    tests=check();assert all(tests['gates'].values()) and load(HERE/'validation.json')==tests
    files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.name!='closeout.json'}
    return dict(scope='Paired active two-wave junction; frozen three-point numerical forecast through z=3999; relative gauge map in the averaged branch. No observational fit.',
                checks=len(tests['gates']),files=files,inputs=inputs,frozen_forecast=digest(HERE/'forecast-freeze.json'))
if __name__=='__main__':
    report=manifest()
    if '--seal' in sys.argv:save('closeout.json',report)
    assert report==load(HERE/'closeout.json')
    print(len(report['files']),'local files;',len(report['inputs']),'inputs;',report['checks'],'checks; SHA256',digest(HERE/'closeout.json'))

