from support import *
from argparse import Namespace
from evolution import Solver
from scipy.integrate import cumulative_simpson

def prepare(case):
    tag='refined-'+case
    config=load(SOURCE/(tag+'.json'))
    solver=Solver(case,Namespace(**config));projection=Projection(case)
    with np.load(SOURCE/(tag+'.npz')) as saved:
        times=saved['times'];states=saved['states'];report=saved['report']
        begin=int(np.flatnonzero(times==120/MODE)[0]);expect=int(np.flatnonzero(times==160/MODE)[0])
        matter=saved['matter_120.0'];rays=saved['radiation_120.0'];checkr=saved['radiation_160.0']
    assert np.array_equal(times,solver.grid)
    with np.load(PRIOR/('restart-'+case+'.npz')) as saved:
        tau=saved['tau'];tide=load(PRIOR/'restart.json')['cases'][case]['regular']['quadratic_tide']
        eta0=(-5.625+3)/4+(tide-3/8)*(MODE*tau[0])**2/6
        etaold=eta0+cumulative_simpson((saved['diagnostics'][:,8]+saved['core'][:,1])/3,x=tau,initial=0.)
    eta2=etaold[tau.tolist().index(times[0])]+cumulative_simpson((report[:,2]+states[:,1])/3,x=times,initial=0.)
    core=CubicSpline(times,states,axis=0);curv=CubicSpline(times,eta2);moments=CubicSpline(times,report,axis=0)
    field=CubicHermiteSpline(times,states[:,2],states[:,3])
    windows=[];snapshots={};targets=[]
    for index,scale in enumerate(projection.centres):
        t,w=projection.kernel(scale);tc=float(projection.time(scale))
        a,hub,cdm,bary,phot,rel,nu,dc,rate,_,_,shear,eta,f0,p0,ma,f1,p1=projection.track.physics(t).T
        weight=a/projection.norm;f2=field(t);p2=field(t,1)
        energy=p0*p2+ma*f0*f2+.5*(p1**2+(ma-MU*MODE**2)*f1**2)
        lag=p0*p2-ma*f0*f2+.5*(p1**2-(ma-MU*MODE**2)*f1**2);gradient=MODE**2*f1**2
        state=np.r_[w@core(t),w@curv(t)];state[2:4]=[w@(weight*energy),w@(weight*MODE*(p0*f2+.5*p1*f1))]
        scores=w@moments(t);stress=np.array([w@(weight*(lag-gradient/4)),w@(weight*(lag-MU*gradient/3))])
        targets.append(dict(scale=scale,time=tc,state=state.tolist(),report=scores.tolist(),stress=stress.tolist()))
        if index in (0,1):
            subset=np.arange(np.searchsorted(times,t[0])-3,np.searchsorted(times,t[-1])+4)
            assert subset[0]>begin and subset[-1]<expect
            weights=w@CubicSpline(times[subset],np.eye(len(subset)),axis=0)(t)
            windows.append((subset,weights));snapshots[index]=np.zeros_like(rays)
    for pos in range(begin,expect+1):
        for index,(subset,weights) in enumerate(windows):
            if subset[0]<=pos<=subset[-1]:snapshots[index]+=weights[pos-subset[0]]*rays
        if pos<expect:matter,rays=solver.integrate(pos,matter,rays)
    assert np.array_equal(rays,checkr) and np.array_equal(matter,states[expect])
    for index in (0,1):
        row=targets[index]
        store('start-'+case+'-'+str(index)+'.npz',tau=row['time'],scale=row['scale'],state=row['state'],rays=snapshots[index],
              thermal_q=solver.thermal.grid,mu=solver.axis,weights=solver.weight)
    save('scores-'+case+'.json',dict(rows=targets,bit_exact_replay_x160=True,k=MODE))
    print(case,'initial packets, scoring rows, bit-exact endpoint',flush=True)

if __name__=='__main__':
    guard()
    for branch in ('heavy','cold'):prepare(branch)

