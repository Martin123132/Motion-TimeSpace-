from forward_bank import *
from scipy.integrate import simpson

def point(case,index):
    track=Future(case);tt=track.t[index+1]
    with np.load(HERE/('forecast-carried-fine-'+case+'.npz')) as src:
        state=src['states'][np.searchsorted(src['time'],tt)]
    a,hub,_,_,_,_,_,dc,rate,_,_,shear,eta,*_=track.physics(tt)
    norm=track.norm
    with np.load(HERE/('forward-bank-matched-'+case+'.npz')) as bank:
        time=bank['time'];raw=bank['raw'];names=bank['names'].tolist()
        at=lambda name:raw[:,names.index(name)]
        density=CubicSpline(time,at('mts_drho_h')*at('a')/norm)
        velocity=CubicSpline(time,at('mts_q_h')*at('a')/norm)
        pressure=CubicSpline(time,at('mts_dp_h')*at('a')/norm)
    if case!='heavy':
        density=lambda t:track.physics(t)[...,7]
        velocity=lambda t:np.zeros_like(t)
        pressure=lambda t:np.zeros_like(t)
    d1=float(density(tt));flow=float(velocity(tt));pres=float(pressure(tt))
    temporal=shear/MODE**2;spatial=(-2*dc+6*eta)/(2*MODE**2);difference=d1-dc
    cold2=state[0]+dc**2/2
    heavy2=state[2] if case=='heavy' else cold2
    sync=heavy2-cold2
    logcontrast=heavy2-state[0]-d1*d1/2
    clock=temporal*(-MODE*flow-3*hub*pres);ruler=-MU*MODE**2*spatial*difference
    boost=-2*MU*MODE*temporal*flow
    relabel=(d1-3*hub*temporal)**2/2-(dc-3*hub*temporal)**2/2
    predicted=logcontrast+clock+ruler+boost+relabel
    simple=sync-(3*hub*temporal+MU*MODE**2*spatial)*difference-3*hub*temporal*pres
    assert abs(predicted-simple)<2e-12
    axis=2*np.pi*np.arange(32)/32
    p,q=np.meshgrid(axis,axis,indexing='ij');wave=np.cos(p)+np.cos(q);pair=np.cos(p+q)
    directions=np.array([[np.sqrt(.75),0,.5],[-np.sqrt(.75),0,.5]])
    gradient=np.sin(p)[:,:,None]*directions[0]+np.sin(q)[:,:,None]*directions[1]
    def sample(eps,alter,tilt,smoothed):
        time_s=tt+eps*temporal*wave+eps**2*alter*pair
        displacement=-eps*MODE*spatial*gradient+eps**2*alter*np.sin(p+q)[:,:,None]*np.array([0.,0.,1.])
        up=p+MODE*(displacement@directions[0]);uq=q+MODE*(displacement@directions[1])
        waves=np.cos(up)+np.cos(uq);combined=np.cos(up+uq)
        phys=track.physics(time_s);background=(a/phys[...,0])**3
        if smoothed:
            cd=dc+rate*(time_s-tt);hv=d1+(rate-MODE*flow-3*hub*pres)*(time_s-tt)
        else:cd=phys[...,7];hv=density(time_s)
        ec=np.exp(eps*cd*waves+eps**2*state[0]*combined)
        eh=1+eps*hv*waves+eps**2*heavy2*combined
        if case=='cold':eh=ec
        vobs=-eps*MODE*temporal*gradient*tilt
        current=eps*velocity(time_s)[:,:,None]*(np.sin(up)[:,:,None]*directions[0]+np.sin(uq)[:,:,None]*directions[1])
        lorentz=1/(1-np.sum(vobs**2,axis=2))
        value=background*lorentz*((eh-ec)-2*np.sum(current*vobs,axis=2)+eps*pressure(time_s)*waves*np.sum(vobs**2,axis=2))
        return 2*np.mean(value*pair)
    def extract(eps,alter,tilt,smoothed):
        def even(step):return (sample(step,alter,tilt,smoothed)+sample(-step,alter,tilt,smoothed))/(2*step**2)
        return (4*even(eps/2)-even(eps))/3
    replay={}
    for style in (False,True):
        for frame in (0,1):
            for gen in (0,13):
                replay[str((style,frame,gen))]=extract(.0008,gen,frame,style)
    expected_cdm_observer=predicted-boost
    localvar=extract(.0011,0,1,False)
    halfwidth=.15
    arr=np.linspace(tt-halfwidth,tt+halfwidth,301);phy=track.physics(arr)
    angular_shift=((-2*phy[-1,7]+6*phy[-1,12])-(-2*phy[0,7]+6*phy[0,12]))/2
    generator_error=angular_shift-simpson(phy[:,11],x=arr)
    nr_error=(density(arr[-1])-density(arr[0]))-(phy[-1,7]-phy[0,7])+simpson(MODE*velocity(arr)+3*phy[:,1]*pressure(arr),x=arr)
    return dict(a=a,conformal_time=tt,k=MODE,T=temporal,L=spatial,sync_relative=sync,newtonian_relative=predicted,
                newtonian_time_and_thread_cdm_observer=expected_cdm_observer,clock_in_log_ratio=clock,ruler=ruler,observer_boost=boost,
                linear_relative=difference,linear_pressure=pres,linear_flux=flow,logcontrast_sync=logcontrast,linear_square_to_density=relabel,
                first_order_continuity_integrated_error=float(nr_error),shift_condition_integrated_error=float(generator_error),
                replay=replay,raw_check_second_amplitude=localvar)
if __name__=='__main__':
    guard();require_freeze();rows={case:[point(case,index) for index in range(3)] for case in ('heavy','cold')}
    save('gauge-pair.json',rows)
    for case in rows:
        for row in rows[case]:print(case,row['a'],row['sync_relative'],row['newtonian_relative'],row['replay'][str((False,1,0))],row['replay'][str((True,1,0))],row['observer_boost'],row['shift_condition_integrated_error'])

