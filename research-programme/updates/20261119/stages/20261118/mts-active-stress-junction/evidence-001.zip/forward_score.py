from forward_bank import *
def reference(case,tag):
    track=Future(case,True)
    with np.load(HERE/('heldout-field-'+tag+'-'+case+'.npz')) as src:
        times=src['times'];state=src['states'];report=src['report'];eta2=CubicSpline(times,src['eta2'])
    core=CubicSpline(times,state,axis=0);field=CubicHermiteSpline(times,state[:,2],state[:,3]);ledger=CubicSpline(times,report,axis=0)
    with np.load(EARLY/'heavy.npz') as bank:phase=CubicSpline(bank['heavy_efold'],bank['phase_h'])
    angles=phase(np.log(track.physics(times)[:,0]));inverse=CubicSpline(angles,times,extrapolate=False);result=[]
    for scale in FORWARD_SCALES:
        u=np.linspace(-1,1,1001);theta=phase(np.log(scale))+6*np.pi*u
        assert theta[0]>=angles[0] and theta[-1]<=angles[-1]
        tt=inverse(theta);tmean=float(inverse(phase(np.log(scale))))
        basis=np.column_stack([u**i for i in range(9)]+[u**i*fn(h*theta) for h,upper in [(2,6),(4,3)] for i in range(upper+1) for fn in [np.cos,np.sin]])
        w=np.linalg.pinv(basis)[0];st=core(tt);a,hub,cdm,bary,phot,rel,nu,dc,rate,_,_,shear,eta,f0,p0,ma,f1,p1=track.physics(tt).T
        weight=a/track.norm;f2=field(tt);p2=field(tt,1);grad=MODE**2*f1**2
        energy=p0*p2+ma*f0*f2+.5*(p1*p1+(ma-MU*MODE**2)*f1*f1)
        lag=p0*p2-ma*f0*f2+.5*(p1*p1-(ma-MU*MODE**2)*f1*f1)
        result.append(np.r_[w@st[:,0],w@st[:,1],w@(weight*energy),w@(weight*MODE*(p0*f2+.5*p1*f1)),w@st[:,4:9],
                              w@eta2(tt),w@(weight*(lag-grad/4)),w@(weight*(lag-MU*grad/3)),w@ledger(tt)[:,:3]])
    return np.array(result)
def score(case):
    expect=reference(case,'fine');base=reference(case,'main')
    tests={}
    for tag in ('carried','carried-fine','centre-fine'):
        with np.load(HERE/('forecast-'+tag+'-'+case+'.npz')) as run:
            ids=np.searchsorted(run['time'],run['anchors'][1:]);st=run['states'][ids];re=run['report'][ids]
            val=np.c_[st[:,:9],st[:,-1],re[:,5:7],re[:,:3]]
        tests[tag]=dict(prediction=val.tolist(),error=(val-expect).tolist())
    return dict(scale=FORWARD_SCALES,columns=['C_log','K','heavy_energy','heavy_cov_momentum','beta','P_b','F0','F1','F2','eta2','S_long','P_iso','nu_active','nu_current','shear'],
                direct_reference=expect.tolist(),field_refinement=(expect-base).tolist(),scores=tests)
if __name__=='__main__':
    guard();require_freeze()
    result={case:score(case) for case in ('heavy','cold')};save('forward-test.json',result)
    for case,r in result.items():
        print(case,'reference',np.round(np.array(r['direct_reference'])[:,:4],7))
        for tag,v in r['scores'].items():print(tag,np.round(np.array(v['error'])[:,:4],7))
        print('direct refinement',np.round(np.array(r['field_refinement'])[:,:4],7))

