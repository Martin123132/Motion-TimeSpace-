from support import *
from scipy.integrate import cumulative_simpson

def test(case):
    proj=Projection(case);trk=proj.track
    with np.load(SOURCE/('refined-'+case+'.npz')) as ref:
        times=ref['times'];state=ref['states'];report=ref['report']
    with np.load(PRIOR/('restart-'+case+'.npz')) as src:
        tau=src['tau'];seed=load(PRIOR/'restart.json')['cases'][case]['regular']['quadratic_tide']
        eta0=(-5.625+3)/4+(seed-3/8)*(MODE*tau[0])**2/6
        eta0+=cumulative_simpson((src['diagnostics'][:,8]+src['core'][:,1])/3,x=tau,initial=0.)[tau.tolist().index(times[0])]
    eta=eta0+cumulative_simpson((report[:,2]+state[:,1])/3,x=times,initial=0.)
    phy=trk.physics(times);hub,dc,rate,shear,curve=phy[:,1],phy[:,7],phy[:,8],phy[:,11],phy[:,12]
    ricci=MODE**2*(3*dc**2/8-9*dc*curve/4-45*curve**2/8-4*eta)
    terms=np.column_stack([ricci,-4*hub*state[:,1],2*rate**2/3,-(MU**2-1/3)*shear**2,-2*report[:,4]])
    reference=CubicSpline(times,terms,axis=0);reported=CubicSpline(times,report,axis=0)
    saved={}
    for tag in ('common','fine','later','no-stress'):
        with np.load(HERE/(tag+'-'+case+'.npz')) as data:
            t=data['times'];state=data['states'];obs=data['report'];anchors=data['anchor_times']
        first=proj.centres[1] if tag=='later' else proj.centres[0]
        scales=np.unique(np.r_[np.geomspace(first,proj.match,81),[a for a in proj.centres if a>=first]])
        mean=[];moment=[];tc=[]
        for a in scales:
            rt,w=proj.kernel(a);mean.append(w@reference(rt));moment.append(w@reported(rt));tc.append(proj.time(a))
        mean=np.array(mean);moment=np.array(moment);tc=np.array(tc)
        num=CubicSpline(t,obs,axis=0)(tc)
        residual=mean.sum(axis=1);weekend=num[:,7]-residual
        source_error=num[:,:3]-moment[:,:3]
        denom=np.max(np.abs(mean).sum(axis=1))
        saved[tag]=dict(samples=len(tc),reference_peak=float(max(abs(residual))),absolute_active_peak=float(max(abs(num[:,7]))),
            common_term_scale=denom,reference_peak_fraction=float(max(abs(residual))/denom),
            active_minus_reference_peak=float(max(abs(weekend))),additional_peak_fraction=float(max(abs(weekend))/denom),
            additional_endpoint=float(weekend[-1]),linear_or_numerical_source_discrepancies_over_peaks=(np.max(abs(source_error),axis=0)/np.max(abs(moment[:,:3]),axis=0)).tolist(),
            fractions_use_shared_late_window=True)
    return saved
if __name__=='__main__':
    guard()
    rows={case:test(case) for case in ('heavy','cold')};save('constraint.json',rows)
    for case in rows:print(case,rows[case]['fine'])

