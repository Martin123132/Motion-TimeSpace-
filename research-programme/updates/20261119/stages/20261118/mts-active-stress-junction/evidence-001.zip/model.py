from support import *
from angular import Sphere,Thermal,geometric_flux
from photon_source import PhotonSource

class Medium:
    def __init__(self,case,projection,angle,stress,samples,future=False):
        self.case=case;self.projection=projection;self.track=projection.track;self.stress=stress
        self.photon=PhotonSource(self.track,12);self.thermal=Thermal(36,self.track.nu_mass)
        self.sphere=Sphere(angle,angle+8);self.axis=self.sphere.axis;self.weight=self.sphere.weights
        self.tidal=self.axis**2-1/3
        self.operators=[np.ascontiguousarray(x,dtype=complex) for x in (MU*self.sphere.other,self.sphere.ray-self.sphere.aberr,
                              self.sphere.aberr_other,self.sphere.other2,self.sphere.avg)]
        if future:
            self.xe=lambda times:np.zeros_like(times)
            self.driving=self.track.driver
        else:
            with np.load(SOURCE/(case+'-ionization.npz')) as saved:self.xe=CubicSpline(saved['times'],saved['values'],extrapolate=False)
            scales=np.unique(np.r_[np.geomspace(projection.centres[0],projection.match,samples),projection.centres])
            self.driving=CubicSpline(projection.time(scales),[projection.forcing(sc) for sc in scales],axis=0,extrapolate=False)
        self.size=33;self.basis=np.eye(self.size+3)
        self.stream=np.zeros((self.size,self.size+3));self.collision=np.zeros_like(self.stream)
        for offset in (6,19):
            for ell in range(13):
                if ell:self.stream[offset+ell,offset+ell-1]=MODE*ell/(2*ell+1)
                if ell<12:self.stream[offset+ell,offset+ell+1]=-MODE*(ell+1)/(2*ell+1)
                self.collision[offset+ell,offset+ell]=-1
        self.collision[6,6]=0;self.collision[7,5]=4/3
        for pos,fac in ((8,.1),(19,.5),(21,.1)):self.collision[pos,[8,19,21]]+=fac
        self.stream[0,1]=1;self.stream[4,1]=1;self.stream[4,5]=-MODE;self.stream[6,1]=4/3
        self.stream[8,-3]=8/15;self.stream[-1,1]=1/3;self.stream[-1,-3]=1/3

    def data(self,times):
        phy=self.track.physics(times)
        wave=self.track.photons(times);extra=self.xe(times)
        ge,co,_=self.photon.evaluate(times,extra=extra)
        return np.column_stack([phy,wave,ge,co,extra,self.driving(times),self.driving(times,1),self.track.physics(times,1)[:,1]])

    def rows(self,data):
        a,hub,cdm,bary,phot,rel,nu,dc,rate,_,_,shear,eta,f0,p0,ma,f1,p1=data[:18]
        opacity,cs,beta,v,dg,qg,pi=data[18:25];geometry=data[48:74];collision=data[74:100];extra=data[100]
        kin,work,velwork,d0,d1,q1,d_rate,slow_eta=data[101:109]
        kinp,workp,_,d0p,d1p,q1p,_,_=data[109:117];hp=data[117]
        basis=self.basis;c2,expansion,dens,current,number,pb=basis[:6]
        enu,one=basis[-2:];weight=a/self.projection.norm;gain=3/(2*weight)
        mat=self.stream+opacity*self.collision
        anis=-2*dc+6*eta;iso=-2*eta;lower=(anis*MU+iso)/4
        external=(rate**2/3+(MU**2-1/3)*shear**2+cdm*dc**2/4+bary*(.5*beta**2-1.5*MU*v**2)/2)*one
        independent=-hub*expansion+cdm*c2/2+dens/(2*weight)+external+bary*number/2+phot*basis[6]+enu
        gradient=(q1*q1+MODE**2*d1*d1/(4*ma))/d0 if self.case=='heavy' else 0.
        pref=3/(4*weight*MODE);corr=pref*(d0*current+.5*d1*q1*one)
        supply=kin*expansion+work*one+corr
        supdot=kinp*expansion+kin*independent+workp*one-hub*corr+pref*(d0p*current+d0*(-hub*current+(velwork-MODE*gradient/4)*one)+.5*(d1p*q1+d1*q1p)*one)
        denom=4*ma+MODE**2-kin*gain-pref*d0*MODE
        assert denom>0
        lag=(MODE*(hub*current-velwork*one)+supdot-4*hub*(supply-MODE*current)+(3*hub**2-3*hp)*dens
             -d_rate*(d1p-3*hub*d1)*one-expansion*(d0p-3*hub*d0)+MODE**2*(dens+(2.5*slow_eta*d1+gradient/4)*one)-kin*gain*MU*gradient*one/3)/denom
        pressure=(lag-MU*gradient*one/3)*self.stress;long=(lag-gradient*one/4)*self.stress
        mat[1]=independent+gain*pressure
        mat[2]=-3*hub*pressure-MODE*current+supply;mat[3]=MODE*long+velwork*one-hub*current
        mat[4,-1]+=MODE*v*(beta-2.5*eta)
        factor=(beta/2+lower)*v;first=4*v/3-qg
        drag=(beta+extra)*first/2+2*dg*v/3-pi*(MU-1/3)*v/2
        mat[5]=-(hub+opacity*phot/bary*4/3)*pb+opacity*phot/bary*basis[7]+(.5*rate*v-MODE*v*v/4-opacity*phot/bary*(-4*factor/3+drag+lower*first))*one
        mat[6:32,-1]+=geometry+opacity*collision;mat[7,-1]-=opacity*4*factor/3
        tide=-expansion+1.5/MODE*(current/weight+bary*pb+phot*basis[7]+(phot*lower*qg+geometric_flux(dc,rate,shear,anis,iso))*one)
        speed,grav=self.thermal.state(a);grav[0]*=rel;grav[1:]*=nu
        return mat,tide,(.5*(1+speed[:,0]**2)*grav,grav*speed[:,0],grav),speed,lower,pressure,long

    def diagnostics(self,data,state,rays):
        mat,tide,(ew,jw,gw),speed,lower,pressure,long=self.rows(data)
        mu=self.axis;w=self.weight;active=ew@(rays[2].real@w);current=-jw@((rays[2]+lower*rays[0]).imag@(mu*w));energy=gw@(rays[2].real@w)
        vec=np.r_[state,0.,active,1.];tideval=tide@vec+1.5*current/MODE;vec[-3]=tideval
        deriv=mat@vec
        a,hub,cdm,bary,phot,rel,nu,dc,rate,_,_,shear,eta,*_=data[:18]
        opacity,cs,beta,v,dg,qg,pi=data[18:25]
        logcdm,expansion,rho,flux,number,pb=state[:6];eta2=state[-1]
        den=energy+cdm*(logcdm+.5*dc**2)+bary*(number+.5*beta**2-MU*v**2/2)+rho*self.projection.norm/a+phot*state[6]
        ricci=MODE**2*(3*dc**2/8-9*dc*eta/4-45*eta**2/8-4*eta2)
        terms=[ricci,-4*hub*expansion,2*rate**2/3,-(MU**2-1/3)*shear**2,-2*den]
        first=4*v/3-qg;force=opacity*(4*(pb-(beta/2+lower)*v)/3-state[7]+data[75])
        balance=bary/phot*(deriv[5]+hub*pb-.5*rate*v+MODE*v*v/4)+force+lower*opacity*first
        emono=deriv[6]-(4*(expansion+dg*rate)/3-MODE*(state[7]+lower*qg)-2.5*MODE*eta*qg+shear*(MU**2-1/3)*pi-opacity*MU*v*first)
        return np.array([active,current,tideval,energy,den,long@vec,pressure@vec,sum(terms),sum(map(abs,terms)),balance,emono])

