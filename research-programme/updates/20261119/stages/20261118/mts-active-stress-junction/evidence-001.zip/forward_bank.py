from support import *
from histories import MATCH
from scipy.integrate import solve_ivp

MODE_NAMES=['a','H','delta_cdm','delta_baryon','growth','etak','v_newtonian_cdm','v_baryon_cdm','delta_photon','v_photon','pi_photon',
            'mts_drho_h','mts_dp_h','mts_q_h','mts_dphi_h','mts_dphidot_h','mts_match_count','mts_nonheavy_change','mts_dphi_s','mts_dphidot_s']
FORWARD_SCALES=[.000235,.000245,.000250]
def acquire(case,exact):
    guard()
    if exact:
        require_freeze()
    proj=Projection(case);label='exact' if exact else 'matched';start=proj.match;last=.0002524
    sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    params=params_for(PROJ if case=='heavy' and not exact else EARLY/(case+'.npz'))
    engine=camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6
    anchors=np.r_[start,FORWARD_SCALES,last];etas=engine.conformal_time(1/anchors-1,tol=1e-10)
    native_tau=np.unique(np.r_[np.linspace(etas[0],etas[-1],6145),etas])
    coordinate=proj.track.center+(native_tau-etas[0])
    vals=engine.get_time_evolution([MODE],native_tau,vars=MODE_NAMES,lAccuracyBoost=4)[0]
    val=lambda name:vals[:,MODE_NAMES.index(name)]
    scale=val('a');assert np.all(np.diff(scale)>0)
    active=val('mts_match_count');changed=case=='heavy' and not exact
    assert np.all(active[scale>start*1.001]==int(changed)) and np.max(abs(val('mts_nonheavy_change')))==0
    bg=engine.get_background_densities(scale,['cdm','baryon','photon','neutrino','nu'])
    cdm,bary,phot,rel,neut=(bg[key]/scale**2 for key in ('cdm','baryon','photon','neutrino','nu'))
    frac=bary/(bary+cdm);rate=val('H')*val('growth')*((1-frac)*val('delta_cdm')+frac*val('delta_baryon'))+frac*MODE*val('v_baryon_cdm')
    with np.load(EARLY/(case+'.npz')) as hist:
        field=CubicSpline(hist['heavy_efold'],hist['phi_h'],extrapolate=False)(np.log(scale)) if case=='heavy' and exact else np.zeros_like(scale)
        prime=CubicSpline(hist['heavy_efold'],hist['phidot_h'],extrapolate=False)(np.log(scale)) if case=='heavy' and exact else np.zeros_like(scale)
        ma=(float(hist['heavy_mass_mpc'])*scale)**2
    phy=np.stack([scale,val('H'),cdm,bary,phot,rel,neut,val('delta_cdm'),rate,val('delta_baryon'),val('v_baryon_cdm'),
                 -val('H')*val('v_newtonian_cdm'),val('etak')/MODE,field,prime,ma,val('mts_dphi_h') if exact else np.zeros_like(scale),val('mts_dphidot_h') if exact else np.zeros_like(scale)],axis=1)
    working=CubicSpline(coordinate,phy,axis=0,extrapolate=False)
    thermal=engine.get_background_time_evolution(native_tau,['opacity','cs2b','x_e'])
    op=CubicSpline(coordinate,thermal['opacity']);cs=CubicSpline(coordinate,thermal['cs2b'])
    high=proj.track.photons(proj.track.center);initial=high[2:];maximum=12
    def rhs(t,s):
        a,h,_,b,p,_,_,_,r,_,_,tide,*_=working(t)
        kap=op(t);out=np.zeros_like(s);out[0]=r-MODE*s[1];out[1]=-h*s[1]+MODE*cs(t)*s[0]+kap*(s[3]-.0-4*s[1]/3)*p/b
        for head in (2,15):
            for ell in range(13):out[head+ell]=MODE/(2*ell+1)*((ell*s[head+ell-1] if ell else 0)-((ell+1)*s[head+ell+1] if ell<maximum else 0))-kap*s[head+ell]
        mix=s[4]+s[15]+s[17];out[2]+=kap*s[2]+4*r/3;out[3]+=4*kap*s[1]/3
        out[4]+=8*tide/15+kap*mix/10;out[15]+=kap*mix/2;out[17]+=kap*mix/10
        return out
    sol=solve_ivp(rhs,(coordinate[0],coordinate[-1]),initial,t_eval=coordinate,method='DOP853',rtol=2e-10,atol=5e-12,max_step=.025)
    assert sol.success
    values=np.c_[thermal['opacity'],thermal['cs2b'],sol.y.T]
    d0=np.zeros_like(scale)+float(case=='heavy');q=scale*val('mts_q_h')/proj.norm;d=scale*val('mts_drho_h')/proj.norm
    pressure=scale*val('mts_dp_h')/proj.norm
    if changed:
        mode_table=np.load(PROJ)
        idx=mode_table['modes'].tolist().index(MODE)
        prematch=(active==0)
        if np.any(prematch):
            assert max(scale[prematch]/start)<1.00001
            d[prematch]=mode_table['matching_delta'][idx];q[prematch]=mode_table['matching_momentum'][idx]
            ratio=MODE**2/ma[prematch];pressure[prematch]=ratio/(np.sqrt(1+ratio)+1)**2*(d[prematch]+3*val('H')[prematch]*q[prematch]/MODE)
        mode_table.close()
    grad=q*q+MODE**2*d*d/(4*ma)
    work=rate*(d+pressure)-2.5*MODE*phy[:,12]*q
    vwork=.5*rate*q+3*grad/(8*(scale/proj.norm)*MODE)
    drivers=np.stack([d0,work,vwork,d0,d,q,rate,phy[:,12]],axis=1)
    with np.load(SOURCE/(case+'-ionization.npz')) as bank:he=float(bank['helium_by_number'])
    ion_offset=thermal['x_e']-(1+he)
    assert np.max(np.abs(ion_offset))<1e-6 and np.isfinite(values).all() and np.isfinite(phy).all()
    store('forward-bank-'+label+'-'+case+'.npz',time=coordinate,native_time=native_tau,phy=phy,photon=values,drive=drivers,
          raw=vals,names=np.array(MODE_NAMES),norm=proj.norm,anchors=anchors,anchor_times=proj.track.center+(etas-etas[0]),xe_deviation=ion_offset,
          photon_error=np.max(abs(values[:,4:7]-vals[:,8:11]),axis=0),prematch_count=int(np.sum(active==0)))
    print(label,case,'matched flags',active[0],active[-1],'xe',max(abs(ion_offset)),flush=True)
def require_freeze():
    freeze=load(HERE/'forecast-freeze.json')
    for key,fingerprint in freeze['files'].items():assert digest(HERE/key)==fingerprint,key
class Future:
    def __init__(self,case,exact=False):
        label='exact' if exact else 'matched'
        with np.load(HERE/('forward-bank-'+label+'-'+case+'.npz')) as bank:
            t=bank['time'];self.physics=CubicSpline(t,bank['phy'],axis=0,extrapolate=False)
            self.photons=CubicSpline(t,bank['photon'],axis=0,extrapolate=False)
            self.driver=CubicSpline(t,bank['drive'],axis=0,extrapolate=False)
            self.scales=bank['anchors'];self.t=bank['anchor_times'];self.norm=float(bank['norm'])
            self.start=self.t[0];self.end=t[-1]
        self.nu_mass=FullTrack(case).nu_mass
if __name__=='__main__':
    for case in ('heavy','cold'):acquire(case,'--exact' in sys.argv)

