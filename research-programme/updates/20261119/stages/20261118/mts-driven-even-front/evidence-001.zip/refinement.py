from falling_test import run, HOME
from constraint_test import run as balance

def main():
    for dx in (.025,.0125):
        for profile in (0,1):
            run(dx,1.,0.,False,direct=True,profile=profile,endtime=4)
    for profile in (0,1):
        run(.0125,1.,0.,False,wide=True,direct=True,profile=profile,endtime=4)
    for eta,amp,shell in ((0.,0.,False),(.8,1.,False),(.8,1.,True)):
        for dx in (.05,.025,.0125):
            balance(dx,eta,amp,shell)
    for amp,shell in ((0.,False),(1.,False),(1.,True),(.00625,False),(.00625,True)):
        run(.00625,.8,amp,shell,direct=True)
    run(.0125,.8,1.,False,wide=True,direct=True)
    run(.0125,.8,1.,False,step_ratio=.16,direct=True)

if __name__=="__main__":main()
