from falling_test import run
from vacuum_master_test import run as vacuum
from front_equations import HOME
import csv

if __name__=="__main__":
    rows=[vacuum(dx) for dx in (.05,.025,.0125,.00625)]
    with (HOME/"neutral-master.csv").open("x",newline="") as stream:
        writer=csv.writer(stream);writer.writerow("spacing tau launch_label start master_start change master_change fractional_change_error".split());writer.writerows(rows)
    print("neutral vacuum",rows,flush=True)
    for profile in (0,1):
        run(.00625,1.,0.,False,wide=True,direct=True,profile=profile,endtime=4)
