import csv
from front_equations import Front, HOME, PRE, EPS, DUAL, SIN, COS, ANG, POL, angle, mixed, divang, coeff, np

def constraints(model,y):
    radius=model.x
    ax,bz,ct,cf,kx,kxt,ktt,kff,scalar,dp,exd,etd,mag,dens,px,pt,theta,vol,label,wave,mom,unused=y
    aa=1+ax; cc=radius**2*(1+ct); kt=radius**2*ktt
    det=aa*cc-bz**2;ia=cc/det;ib=-bz/det;ic=aa/det
    jac,tr,ham,gauss,nn,ksq,rot=model.rhs(y,True)
    ku=ia*kx+ib*kxt;kv=ib*kx+ic*kxt;mu=ia*kxt+ib*kt;mv=ib*kxt+ic*kt
    ko=kff/(1+cf)
    kxx=ku*ia+mu*ib;kxtup=ku*ib+mu*ic;ktup=kv*ib+mv*ic
    dr=model.dr
    ar=dr(ax);at=angle(ax);br=dr(bz);bt=mixed(bz)
    cr=2*radius*(1+ct)+radius**2*dr(ct);ca=radius**2*angle(ct)
    logjr=1/radius+dr(cf)/(2*(1+cf))+(ar*cc+aa*cr-2*bz*br)/(2*det)
    logja=angle(cf)/(2*(1+cf))+(at*cc+aa*ca-2*bz*bt)/(2*det)
    geomx=[dr(ku-tr),divang(kv),logjr*ku,logja*kv,-(ar*kxx+2*br*kxtup+cr*ktup)/2,-ko*(1/radius+dr(cf)/(2*(1+cf)))]
    geomt=[dr(mu),angle(mv-tr),logjr*mu,logja*mv,(COS/SIN)*(mv-ko),-(at*kxx+2*bt*kxtup+ca*ktup)/2,-ko*angle(cf)/(2*(1+cf))]
    econtr=-mom.real[:,:1]/(np.sqrt(aa.real[:,:1])*cc.real[:,:1])
    sourcex=[2*dp*dr(scalar)/jac,-2*dens*px/jac,-2*(mag*etd/jac+DUAL*econtr*dr(wave.real[:,:1])*SIN**2)]
    sourcet=[2*dp*angle(scalar)/jac,-2*dens*pt/jac,-2*(-mag*exd/jac+DUAL*econtr*2*wave.real[:,:1]*SIN*COS)]
    mx=sum(geomx+sourcex);mt=sum(geomt+sourcet)
    rhs=model.rhs(y)
    electric=rhs[4]/aa
    out={}
    for site in (2.5,3.5,6.):
        idx=round((site-radius[0,0])/model.dx)
        xdata=lambda val:float(coeff(val.imag)[idx,0]/EPS)
        tdata=lambda val:float(val[idx,0].imag/(EPS*ANG[0]))
        out[site]=[xdata(mx),sum(abs(xdata(v)) for v in geomx+sourcex),
                   tdata(mt),sum(abs(tdata(v)) for v in geomt+sourcet),
                   xdata(ham),xdata(gauss),float((dr(label.real[:,:1])-dens.real[:,:1])[idx,0]),
                   float(1.5*(xdata(electric)+model.shift[idx,0]*dr(electric.real[:,:1])[idx,0])),
                   tdata(pt),tdata(etd)]
    return out

def run(dx,eta,amp,shell=False):
    model=Front(dx,eta,amp,shell,direct=True)
    y=model.initial.copy()
    tau=0.;rows=[]
    for end in [0.,.12,1.,2.,3.]:
        steps=max(1,int(np.ceil((end-tau)/(.27*dx))));dt=(end-tau)/steps
        if end:
            for idx in range(steps):
                if idx%20==0 and (HOME/"STOP-REQUESTED").exists():raise SystemExit("owner hold")
                first=model.rhs(y);second=model.rhs(y+.5*dt*first);third=model.rhs(y+.5*dt*second)
                y+=dt/6*(first+2*second+2*third+model.rhs(y+dt*third))
        tau=end
        for site,values in constraints(model,y).items():rows.append([end,site,*values])
    path=HOME/f"balances-{dx:g}-eta{eta:g}-h{amp:g}-{'shell' if shell else 'label'}.csv"
    with path.open("x",newline="") as stream:
        writer=csv.writer(stream);writer.writerow("tau radius momentum_x scale_x momentum_theta scale_theta ham gauss label_gradient radial_E_at_launch_only p_theta polar_displacement".split());writer.writerows(rows)
    print(path.name,flush=True)

if __name__=="__main__":
    import sys
    run(float(sys.argv[1]),float(sys.argv[2]),float(sys.argv[3]),"--shell" in sys.argv)
