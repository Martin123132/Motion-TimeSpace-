from pathlib import Path
import os
import sys

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
HOME=Path(__file__).resolve().parent
PRE=HOME.parent/"mts-source-quadrupole-release-20261118"
sys.path.insert(0,str(PRE))
from initial import Model, solve, source, spin, np, sha, guard, spline, CLOUD, SRC
from on_shell import ShellModel
from scipy.ndimage import correlate1d

LOCK="3fa8972c15fa9d37a0e27b10e7921a5aebf4b192150830dc38498632b3abe4e9"
EPS=1e-24
DUAL=1j*EPS
COS=np.sqrt([1/6,2/3])
SIN=np.sqrt(1-COS**2)
POL=(3*COS**2-1)/2
ANG=-3*SIN*COS
ANG2=3*(1-2*COS**2)
UNIT=np.ones(2)
FIRST=np.array([-1,9,-45,0,45,-9,1])/60
SECOND=np.array([2,-27,270,-490,270,-27,2])/180
AXIAL_SECOND=np.array([-9,128,-1008,8064,-14350,8064,-1008,128,-9])/5040

def coeff(value):
    return (value[...,1:2]-value[...,0:1])/(POL[1]-POL[0])

def angle(value):
    return coeff(value)*ANG

def mixed(value):
    return value[...,0:1]/ANG[0]*ANG2

def divang(value):
    return value[...,0:1]/ANG[0]*(-6*POL)

def cov_project(left,right):
    background=(left.real[...,0:1]+right.real[...,0:1])/2
    trace=coeff((left.imag+right.imag)/2)*POL
    shear=(left.imag[...,0:1]-right.imag[...,0:1])/(2*SIN[0]**2)*SIN**2
    return background+1j*(trace+shear),background+1j*(trace-shear)

class Front:
    def __init__(self,spacing,eta,amp,shell=False,wide=False,direct=False,profile=0):
        guard()
        assert sha(PRE/"closeout.json")==LOCK
        self.eta=eta
        self.direct=direct
        self.profile=profile
        self.homogeneous=False
        self.dx=spacing
        self.x=np.arange(round((.5 if wide else 1.)/spacing),round((11.5 if wide else 11.)/spacing)+1)[:,None]*spacing
        radius=self.x
        self.centre=round((6-radius[0,0])/spacing)
        self.mask=np.minimum(1,np.maximum(0,np.minimum(radius-radius[0],radius[-1]-radius)/.65))
        self.mask=self.mask**3*(10-15*self.mask+6*self.mask**2)
        model=(ShellModel if shell else Model)(1920,eta,amp,profile)
        self.model=model
        bvp,_=solve(model,green=False)
        u=bvp.sol(np.log(radius[:,0]))[0][:,None]
        self.shift=-2*radius*u
        fac=model.f(radius)
        number=spline(model.grid.r,model.grid.integral(model.grid.r**2*model.dens))(radius)
        initial=np.zeros((22,len(radius),2),complex)
        initial[0]=(1-fac)/fac+4*DUAL*u*POL/fac
        initial[2]=initial[3]=4*DUAL*u*POL
        initial[8]=model.scalar(radius)
        if shell:initial[8]+=DUAL*2*radius*u*model.scalar(radius,1)*POL
        initial[10]=eta*number
        initial[13]=radius**2*spline(model.grid.r,model.dens)(radius)
        initial[18]=number
        self.initial=initial

    def dr(self,val):
        return correlate1d(val,FIRST,axis=0,mode="nearest")/self.dx

    def drr(self,val):
        return correlate1d(val,SECOND,axis=0,mode="nearest")/self.dx**2

    def rhs(self,y,read=False):
        radius=self.x
        rr=radius**2
        ax,cross,ct,cf,kx,ktx,ktt,kff,scalar,dpi,disx,dist,mag,dens,px,pt,theta,vol,label,wave,mom,unused=y
        aa=1+ax; cc=rr*(1+ct); orbit=radius*np.sqrt(1+cf)*SIN
        det=aa*cc-cross**2; jac=orbit*np.sqrt(det)/SIN
        ia=cc/det;ib=-cross/det;ic=aa/det
        scale=cf/(1+np.sqrt(1+cf))
        sx=SIN*(1+scale+radius*self.dr(scale)); st=radius*(COS*(1+scale)+SIN*angle(scale))
        sx2=SIN*(2*self.dr(scale)+radius*self.drr(scale))
        sxt=COS*(1+scale+radius*self.dr(scale))+SIN*(angle(scale)+radius*self.dr(angle(scale)))
        st2=radius*(-SIN*(1+scale)+2*COS*angle(scale)+SIN*coeff(scale)*ANG2)
        ar=self.dr(ax);at=angle(ax);br=self.dr(cross);bt=mixed(cross)
        cr=2*radius*(1+ct)+rr*self.dr(ct);cang=rr*angle(ct)
        crr=2*(1+ct)+4*radius*self.dr(ct)+rr*self.drr(ct)
        def dot(one,two,three,four):
            return (ia*one+ib*two)*three+(ib*one+ic*two)*four
        gx,gz=ar/2,br-at/2
        mx,mz=at/2,cr/2
        zx,zz=bt-cr/2,cang/2
        gauss=(self.dr(bt)-(crr+coeff(ax)*ANG2)/2+dot(mx,mz,mx,mz)-dot(gx,gz,zx,zz))/det
        hxx=sx2-dot(gx,gz,sx,st);hxt=sxt-dot(mx,mz,sx,st);htt=st2-dot(zx,zz,sx,st)
        rxx=aa*gauss-hxx/orbit;rxt=cross*gauss-hxt/orbit
        rtt=cc*gauss-htt/orbit;rff=-(ia*hxx+2*ib*hxt+ic*htt)/orbit
        kt=rr*ktt; ko=kff/(1+cf)
        tr=ia*kx+2*ib*ktx+ic*kt+ko
        kkx=dot(kx,ktx,kx,ktx);kkb=dot(kx,ktx,ktx,kt);kkt=dot(ktx,kt,ktx,kt)
        ksq=ia*kkx+2*ib*kkb+ic*kkt+ko**2
        hr=self.dr(scalar);ht=angle(scalar);hu=ia*hr+ib*ht;hv=ib*hr+ic*ht
        pi=dpi/jac
        ex=(aa*disx+cross*dist)/jac;et=(cross*disx+cc*dist)/jac
        bphi=orbit**2*mag/(jac*SIN)
        electric=(disx*ex+dist*et)/jac
        amag=np.sqrt(aa.real[:,:1]);area=radius*np.sqrt(1+ct.real[:,:1])
        avec=wave.real[:,:1];pm=mom.real[:,:1];agrad=self.dr(avec)
        num=label.real[:,:1];ell,internal=spin(num,self.profile)
        if self.homogeneous:ell,internal=0.,0.
        charge=self.eta*num
        mech=ell-self.eta*avec
        rot=2*(charge*avec-internal)/area**3
        twist=2*amag*rot/area
        ewave=-pm/(amag*area)*SIN
        bnormal=2*avec/area**2*COS
        bside=-agrad/(amag*area)*SIN
        bcx=amag*bnormal;bct=area*bside
        em=electric+DUAL*(ewave**2+bnormal**2+bside**2)
        velx=ia*px+ib*pt;velt=ib*px+ic*pt
        lor=np.sqrt(1+px*velx+pt*velt+DUAL*(mech*SIN/area)**2)
        vx=velx/lor;vt=velt/lor
        rho=dens/(jac*lor)
        common=scalar**2+em+rho
        tt=2*DUAL*(rot*SIN)**2
        nn=2*pi**2-scalar**2+em+rho*(2*lor**2-1)+tt
        if read:
            ham=ia*rxx+2*ib*rxt+ic*rtt+rff+tr**2-ksq-2*(pi**2+hu*hr+hv*ht+scalar**2+em+2*rho*lor**2)-tt
            gausslaw=self.dr(disx)+divang(dist)-self.eta*dens
            return jac,tr,ham,gausslaw,nn,ksq,rot
        dy=np.zeros_like(y)
        dy[0]=-2*kx;dy[1]=-2*ktx;dy[2]=-2*ktt;dy[3]=-2*kff
        dy[4]=rxx+tr*kx-2*kkx-common*aa-2*hr**2+2*ex**2-2*rho*px**2+2*DUAL*bcx**2+tt*amag**2
        dy[5]=rxt+tr*ktx-2*kkb-common*cross-2*hr*ht+2*ex*et-2*rho*px*pt+2*DUAL*bcx*bct
        dy[6]=(rtt+tr*kt-2*kkt-common*cc-2*ht**2+2*et**2-2*rho*pt**2+2*DUAL*bct**2)/rr
        dy[7]=(1+cf)*(rff+tr*ko-2*ko**2-common+2*DUAL*(ewave**2-rho.real*(mech*SIN/area)**2)-tt)
        dy[8]=pi;dy[9]=self.dr(jac*hu)+divang(jac*hv)-jac*scalar
        dy[10]=divang(bphi/SIN)-self.eta*dens*vx
        dy[11]=-self.dr(bphi)/SIN-self.eta*dens*vt
        dy[12]=-self.dr(et)+angle(ex)+DUAL*2*avec*SIN*COS*twist
        dy[13]=-self.dr(dens*vx)-divang(dens*vt)
        dy[14]=-vx*self.dr(px)-vt*angle(px)+(ar*velx**2+2*br*velx*velt+cr*velt**2)/(2*lor)+self.eta*(ex+mag*vt)+DUAL*SIN**2*(mech**2*self.dr(area)/area**3/lor.real+self.eta*mech*agrad/(area**2*lor.real)-mech*twist)
        dy[15]=-vx*self.dr(pt)-vt*mixed(pt)+(at*velx**2+2*bt*velx*velt+cang*velt**2)/(2*lor)+self.eta*(et-mag*vx)+DUAL*(ell**2-(self.eta*avec)**2)*SIN*COS/(area**2*lor.real)
        dy[16]=-ksq-nn;dy[17]=theta
        dy[18]=-vx.real[:,:1]*self.dr(num)
        dy[19]=pm/amag
        lap=(correlate1d(avec,AXIAL_SECOND,axis=0,mode="nearest")/(self.dx**2*amag)-agrad*self.dr(amag)/amag**2 if self.direct else self.dr(agrad/amag))
        dy[20]=lap-2*amag*avec/area**2+self.eta*dens.real[:,:1]*mech/(lor.real[:,:1]*area**2)-charge*twist
        for slot in (0,4,8,9,10,13,14,16,17):
            field=dy[slot]
            dy[slot]=field.real[:,:1]+1j*coeff(field.imag)*POL
        for slot in (1,5,11,12,15):
            dy[slot]=1j*dy[slot].imag[:,:1]*ANG/ANG[0]
        dy[2],dy[3]=cov_project(dy[2],dy[3])
        dy[6],dy[7]=cov_project(dy[6],dy[7])
        return dy*self.mask
