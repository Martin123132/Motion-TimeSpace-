import argparse
import json
from front_equations import HOME, PRE, CLOUD, SRC, EPS, Front, coeff, source, np
from scipy.interpolate import CubicSpline, RectBivariateSpline

def run(spacing,eta,amp,shell,wide=False,step_ratio=.32,direct=False,profile=0,endtime=3):
    model=Front(spacing,eta,amp,shell,wide,direct,profile)
    radius=model.x;center=model.centre
    state=model.initial.copy()
    def contrast(field):
        return float(1.5*(coeff(field.imag)[center,0]/EPS+model.shift[center,0]*model.dr(field.real[:,:1])[center,0]))
    def logmetric(data):
        aa,cross,ct,cf=data[:4]
        return (np.log1p(aa)+np.log1p(ct-cross**2/((1+aa)*radius**2))+np.log1p(cf))/2
    launch=logmetric(state)
    rows=[]
    tag=f"eta{eta:g}-h{amp:g}"
    with np.load(source(PRE,f"{'shell' if shell else ('alternate' if profile else 'adm')}-1920-{tag}-resolved-refined.npz")) as old:
        early=float(old["volume"][-1])
    with np.load(source(SRC,f"driven-1920-{tag}-spin{profile}.npz")) as old:
        bank=RectBivariateSpline(old["time"],old["radius"],old["fields"][:,0,:],kx=5,ky=5,s=0)
    if eta:
        with np.load(source(CLOUD,f"path-1920-{tag}.npz")) as saved:
            assert saved["sites"][1]==6
            path=CubicSpline(saved["tau"],saved["state"][1,:,:2],axis=0)
    tau=0.
    for end in np.arange(0,round(endtime/.02)+1)*.02:
        steps=max(1,int(np.ceil((end-tau)/(spacing*step_ratio)-1e-9)))
        dt=(end-tau)/steps
        if dt:
            if (HOME/"STOP-REQUESTED").exists():raise SystemExit("owner hold")
            for tick in range(steps):
                first=model.rhs(state)
                second=model.rhs(state+dt/2*first)
                third=model.rhs(state+dt/2*second)
                fourth=model.rhs(state+dt*third)
                state+=dt/6*(first+2*second+2*third+fourth)
        tau=end
        jac,tr,ham,charge,nn,ksq,rot=model.rhs(state,True)
        wave=state[19,center,0].real
        areal=radius[center,0]*np.sqrt(1+state[2,center,0].real)
        tc,rc=path(tau) if eta else (0.,areal)
        wref=bank.ev(tc,rc) if eta else 0.
        rows.append([tau,contrast(state[17]),contrast(logmetric(state)-launch),contrast(state[16]),contrast(tr),
                     contrast(ham),contrast(charge),contrast(nn),contrast(ksq),wave,wref,areal,rc,early,
                     float(np.max(abs(state[15,:,0].imag/EPS))),float(np.max(abs(state[11,:,0].imag/EPS)))])
        if not np.isfinite(state).all():raise ArithmeticError(f"nonfinite at {tau}")
    name=f"front-{spacing:g}-{tag}-{'shell' if shell else 'label'}{'-wide' if wide else ''}"+(f"-dt{step_ratio:g}" if step_ratio!=.32 else "")+".npz"
    if direct:name=name.replace(".npz","-direct.npz")
    if profile:name=name.replace(".npz",f"-spin{profile}.npz")
    if endtime!=3:name=name.replace(".npz",f"-to{endtime:g}.npz")
    with (HOME/name).open("xb") as stream:
        np.savez_compressed(stream,rows=np.array(rows),columns="tau ray geom expansion trace ham gauss ricci shear wave bank radius worldline prefront max_p_theta max_D_theta".split())
    print(name,np.array(rows)[-1,[1,2,5,9,10]],flush=True)

if __name__=="__main__":
    arg=argparse.ArgumentParser()
    arg.add_argument("dx",type=float);arg.add_argument("eta",type=float);arg.add_argument("amp",type=float)
    arg.add_argument("--shell",action="store_true");arg.add_argument("--wide",action="store_true")
    arg.add_argument("--ratio",type=float,default=.32)
    arg.add_argument("--direct",action="store_true")
    arg.add_argument("--profile",type=int,choices=[0,1],default=0);arg.add_argument("--end",type=float,default=3)
    opt=arg.parse_args();run(opt.dx,opt.eta,opt.amp,opt.shell,opt.wide,opt.ratio,opt.direct,opt.profile,opt.end)
