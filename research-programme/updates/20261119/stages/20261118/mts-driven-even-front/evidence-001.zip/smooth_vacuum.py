from vacuum_master_test import run, HOME, csv

if __name__=="__main__":
    rows=[run(dx,True) for dx in (.05,.025,.0125,.00625)]
    with (HOME/"neutral-master-analytic-seed.csv").open("x",newline="") as stream:
        writer=csv.writer(stream);writer.writerow("spacing tau launch_label start master_start change master_change fractional_change_error".split());writer.writerows(rows)
    print(rows,flush=True)
