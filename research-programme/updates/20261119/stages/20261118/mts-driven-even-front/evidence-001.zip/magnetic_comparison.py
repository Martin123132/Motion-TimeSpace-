from summarise import front, write, np

def main():
    rows=[]
    for dx,wide in ((.025,False),(.0125,False),(.0125,True),(.00625,True)):
        middle="-wide-direct" if wide else "-direct"
        first=front(dx,1,0,False,middle+"-to4")
        second=front(dx,1,0,False,middle+"-spin1-to4")
        tick=150;later=200
        assert first[tick,0]==3 and first[later,0]==4
        factor=first[tick,10]/second[tick,10];direct=first[tick,9]/second[tick,9]
        calibrated=factor**2*second[later,1]/first[later,1]
        geometric=direct**2*second[later,2]/first[later,2]
        rows.append(dict(dx=dx,wide=wide,first_B_per_spin=2*first[tick,10]/first[tick,12]**2,
                         second_B_per_spin=2*second[tick,10]/second[tick,12]**2,
                         spin_ratio_from_bank=factor,spin_ratio_direct=direct,field_match=direct/factor-1,
                         late_volume_ratio=calibrated,metric_crosscheck=geometric,
                         field_ratio_at_4_without_retuning=factor*second[later,9]/first[later,9]))
    write("magnetic-normalization.csv",rows)
if __name__=="__main__":main()
