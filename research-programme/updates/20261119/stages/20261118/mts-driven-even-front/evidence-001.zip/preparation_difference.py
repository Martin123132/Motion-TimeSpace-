import csv
from front_equations import HOME, Front, PRE, EPS, DUAL, POL, np, coeff, spline, solve, source
from scipy.integrate import solve_bvp

def prepare(model):
    base=model.model;rad=base.grid.r
    hr=base.scalar(rad,1);hrr=base.scalar(rad,2);hr[rad>=26]=0.;hrr[rad>=26]=0.
    primitive=spline(rad,rad*hr**2).antiderivative()
    dmu=np.expm1(primitive(rad)-primitive(0.));mu=1+dmu
    mu_fn=spline(rad,dmu)
    aa,bb,forcing=base.C(rad).T
    extra=base.root**2*(hr**2+rad*hr*hrr)+rad*base.h*hr
    db=bb*dmu-mu*aa*rad**2*extra
    diff=spline(rad,np.column_stack([-aa*dmu/mu,db,forcing*dmu]))
    original,_=solve(base,green=False)
    xmin,xmax=np.log([.0078125,48.]);nodes=np.linspace(xmin,xmax,553)
    beta=float(base.outer(48.));edge=mu_fn(48.)*beta*original.sol(xmax)[0]
    def sources(xx):
        rr=np.exp(xx);dc=diff(rr).T;orig=original.sol(xx)
        return dc[0]*orig[1],dc[1]*orig[0]+dc[2]
    scale=np.max(np.abs(sources(nodes)))
    def rhs(xx,y):
        rr=np.exp(xx);aa,bb,ss=base.C(rr).T;da,db,ds=diff(rr).T
        one,two=sources(xx)
        return np.array([(aa+da)*y[1]+one/scale,-y[1]+(bb+db)*y[0]+two/scale])
    out=solve_bvp(rhs,lambda left,right:[left[1]-2*left[0],right[1]-beta*(1+mu_fn(48.))*right[0]-edge/scale],
                  nodes,np.zeros((2,len(nodes))),tol=3e-10,max_nodes=15000)
    assert out.success
    radius=model.x
    du=scale*out.sol(np.log(radius[:,0]))[0][:,None]
    u=original.sol(np.log(radius[:,0]))[0][:,None]
    y=model.initial.copy();y.imag[:]=0
    y[0]+=4*DUAL*du*POL/base.f(radius);y[2]+=4*DUAL*du*POL;y[3]+=4*DUAL*du*POL
    y[8]+=2*radius*(u+du)*base.scalar(radius,1)*DUAL*POL
    model.shift=-2*radius*du;model.homogeneous=True
    return y

def run(dx,amp):
    model=Front(dx,.8,amp,direct=True);y=prepare(model);idx=model.centre
    def contrast(val):
        return float(1.5*(coeff(val.imag)[idx,0]/EPS+model.shift[idx,0]*model.dr(val.real)[idx,0]))
    def geom(y):
        return (np.log1p(y[0])+np.log1p(y[2]-y[1]**2/((1+y[0])*model.x**2))+np.log1p(y[3]))/2
    start=geom(y);rows=[]
    for tick in range(151):
        if (HOME/"STOP-REQUESTED").exists():raise SystemExit("owner hold")
        rows.append([tick*.02,contrast(y[17]),contrast(geom(y)-start)])
        if tick==150:break
        count=int(np.ceil(.02/(dx*.32)));dt=.02/count
        for _ in range(count):
            first=model.rhs(y);second=model.rhs(y+dt/2*first);third=model.rhs(y+dt/2*second)
            y+=dt/6*(first+2*second+2*third+model.rhs(y+dt*third))
    assert not np.any(y[19:21])
    with (HOME/f"homogeneous-{dx:g}-h{amp:g}.npz").open("xb") as stream:
        np.savez_compressed(stream,rows=rows,columns=["tau","shell_minus_label_ray","shell_minus_label_metric"])
    print("homogeneous",dx,amp,rows[-1],flush=True)

if __name__=="__main__":
    for dx in (.025,.0125,.00625):
        for amp in (1.,1/160):run(dx,amp)
