from front_equations import HOME, PRE, SRC, CLOUD, LOCK, sha, source, guard, np
from initial import CH
from summarise import front, TOL, read, error
import csv
import json
import sys

def records(name):
    with (HOME/name).open(newline="",encoding="utf8") as stream:
        result=list(csv.DictReader(stream))
    assert result and all(None not in row and None not in row.values() for row in result)
    return result

def audit():
    guard()
    assert sha(PRE/"closeout.json")==LOCK
    checks={};gates={};origins={}
    def require(label,test):
        assert label not in checks and bool(test),label
        checks[label]=True
    def assess(label,value):
        assert label not in gates and np.isfinite(value) and value>=0,label
        gates[label]={"error":float(value),"within_2e-5":bool(value<TOL)}
    def link(folder,name):
        origins[f"{folder.name}/{name}"]=sha(source(folder,name))
    for folder,names in ((PRE,("initial.py","on_shell.py","THROUGH-THE-FRONT.md","source_calibration.csv","vacuum_wave.csv")),
                         (CLOUD,("strip.py","trajectory.py")),(SRC,("radiate.py","current_source.py")),(CH,("charged.py",))):
        for member in names:link(folder,member)
    for file in sorted(HOME.glob("*.npz")):
        with np.load(file,allow_pickle=False) as saved:
            data=saved["rows"];head=saved["columns"]
        end=4. if "-to4" in file.name else 3.
        require(file.name+" finite on full clock",data.shape==(round(end/.02)+1,len(head)) and np.isfinite(data).all() and
                np.allclose(np.diff(data[:,0]),.02,rtol=0,atol=1e-15) and data[0,0]==0 and data[-1,0]==end)
    falling=records("falling-comparisons.csv")
    require("seven independent arm or preparation combinations",len({(r["eta"],r["amp"],r["shell"]) for r in falling})==7)
    for row in falling:
        eta,amp=float(row["eta"]),float(row["amp"])
        tag=f"1920-eta{eta:g}-h{amp:g}";shell=row["shell"]=="True"
        link(CH,"charged-"+tag+"-b1.npz");link(SRC,"driven-"+tag+"-spin0.npz")
        if eta:link(CLOUD,"path-"+tag+".npz")
        link(PRE,f"{'shell' if shell else 'adm'}-{tag}-resolved-refined.npz")
        case=tag+("-shell" if shell else "-label")
        for key in ("pre_control","wave","grid","metric","spherical_radius"):
            if row[key]:assess(case+" "+key,float(row[key]))
        array=front(float(row["dx"]),eta,amp,shell,"-direct")
        require(case+" detected or exact neutral null",float(row["logvolume_at_3"])==array[-1,1] and
                ((np.any(array[:,9]) and abs(array[-1,9])>1e-10) if eta else not np.any(array[:,9:11])))
    link(SRC,"driven-1920-eta1-h0-spin1.npz");link(PRE,"alternate-1920-eta1-h0-resolved-refined.npz")
    for row in records("preparation-contrasts.csv"):
        amp,dx=float(row["amp"]),float(row["dx"])
        require(str(amp)+str(dx)+" identical magnetic history",row["same_axial_wave"]=="True")
        for key in ("direct_vs_subtraction","independent_volume","direct_grid"):
            if row[key]:assess(f"state difference {amp} dx {dx} "+key,float(row[key]))
    prof=records("interior-source-transfer.csv")
    for row in prof:
        if row["tau"] not in ("3.0","4.0"):continue
        for key in ("wave_first","wave_second"):assess("two currents "+row["dx"]+row["wide"]+row["tau"]+key,float(row[key]))
    primary=prof[-1];earlier=prof[-4];late=float(primary["relative_departure"])
    require("late source transfer differs materially from frozen transfer",abs(late)>.001 and abs(late)>50*abs(late-float(earlier["relative_departure"])))
    require("early transfer independently matches launch",abs(float(prof[-3]["relative_departure"]))<TOL)
    assess("absolute late transfer convergence",abs(float(primary["measured"])/float(earlier["measured"])-1))
    assess("late transfer minus launch on its own scale",abs(late/float(earlier["relative_departure"])-1))
    assess("late transfer from independent determinant",abs(float(primary["metric_ratio"])/float(primary["measured"])-1))
    assess("late transfer residual from independent determinant",abs(float(primary["metric_residual"])/float(primary["physical_residual"])-1))
    assess("late transfer residual under moving boundary at same spacing",abs(float(prof[-4]["physical_residual"])/float(prof[-7]["physical_residual"])-1))
    mag=records("magnetic-normalization.csv")
    for key in ("late_volume_ratio","spin_ratio_from_bank"):require("magnetic normalization finite "+key,np.isfinite(float(mag[-1][key])))
    assess("matched magnetic field",abs(float(mag[-1]["field_match"])))
    assess("calibrated late volume independent readout",abs(float(mag[-1]["metric_crosscheck"])/float(mag[-1]["late_volume_ratio"])-1))
    assess("calibrated late volume refinement",abs(float(mag[-2]["late_volume_ratio"])/float(mag[-1]["late_volume_ratio"])-1))
    for file in ("neutral-master.csv","neutral-master-analytic-seed.csv"):
        raw=records(file)
        for row in raw:assess(file+" dynamic "+row["spacing"],abs(float(row["fractional_change_error"])))
        require(file+" dynamic sign in all tests",all(float(r["master_change"])*float(r["change"])>0 for r in raw))
    residuals=[r for r in records("constraint-residuals.csv") if r["interior_check"]=="True" and "0.0125-" in r["packet"]]
    for comp in ("xfrac","thetafrac"):assess("momentum in causal interior "+comp,max(float(r[comp]) for r in residuals))
    require("outside causal regions not hidden",any(float(r["xfrac"])>.01 for r in records("constraint-residuals.csv") if r["interior_check"]=="False"))
    for key,value in json.loads((HOME/"method-controls.json").read_text()).items():assess(key,value)
    failed=front(.025,.8,0);fixed=front(.025,.8,0,False,"-direct")
    require("composed derivative fails independently saved axial wave",error(failed[:,9],failed[:,10])>.01 and error(fixed[:,9],fixed[:,10])<TOL)
    for path in HOME.glob("*.csv"):records(path.name)
    require("no bytecode or temporary server",not (HOME/"__pycache__").exists())
    return dict(checks=checks,accuracy=gates,inputs=origins)

def main():
    report=audit()
    report["files"]={p.name:sha(p) for p in sorted(HOME.iterdir()) if p.is_file() and p.name!="closeout.json"}
    path=HOME/"closeout.json"
    if "--seal" in sys.argv:
        with path.open("x",encoding="utf8") as out:json.dump(report,out,sort_keys=True,indent=2)
    else:assert json.loads(path.read_text())==report
    print("checks",len(report["checks"]),"accuracy",sum(g["within_2e-5"] for g in report["accuracy"].values()),"/",len(report["accuracy"]),"files",len(report["files"]),"inputs",len(report["inputs"]),"seal",sha(path))
if __name__=="__main__":main()
