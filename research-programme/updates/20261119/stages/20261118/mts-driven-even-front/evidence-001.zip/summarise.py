from front_equations import HOME, PRE, CLOUD, SRC, source, np
import csv
import json

TOL=2e-5
def write(name,rows):
    with (HOME/name).open("x",newline="",encoding="utf8") as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def read(name):
    with np.load(HOME/name) as saved:return saved["rows"]
def front(dx,eta,amp,shell=False,more=""):
    return read(f"front-{dx:g}-eta{eta:g}-h{amp:g}-{'shell' if shell else 'label'}{more}.npz")
def peak(values):return np.max(abs(values)).item()
def error(test,ref):
    denom=peak(ref)
    return peak(test-ref)/denom if denom else (0. if not np.any(test) else float("inf"))

def main():
    rows=[]
    for eta,amp,shell in ((1.,0.,False),(.8,0.,False),(.8,1.,False),(.8,1.,True),(.8,1/160,False),(.8,1/160,True),(0.,0.,False)):
        fine=.00625 if eta==.8 else .0125
        gold=front(fine,eta,amp,shell,"-direct");silver=front(2*fine,eta,amp,shell,"-direct")
        with np.load(source(PRE,f"{'shell' if shell else 'adm'}-1920-eta{eta:g}-h{amp:g}-resolved-refined.npz")) as old:
            pre=np.interp(gold[:7,0],old["time"],old["volume"])
            from scipy.interpolate import CubicSpline
            pre=CubicSpline(old["time"],old["volume"])(gold[:7,0])
        metrics=dict(pre_control=error(gold[:7,1],pre),wave=error(gold[:,9],gold[:,10]),
                     grid=error(silver[:,1],gold[:,1]),metric=error(gold[:,2],gold[:,1]),
                     spherical_radius=error(gold[:,11]-6,gold[:,12]-6) if eta else None)
        rows.append(dict(eta=eta,amp=amp,shell=shell,dx=fine,logvolume_at_3=gold[-1,1],
                         wave_at_3=gold[-1,9],**metrics,
                         controls_pass=all(v<TOL for v in metrics.values() if v is not None)))
    write("falling-comparisons.csv",rows)
    pairs=[]
    for amp in (1.,1/160):
        for dx in (.025,.0125,.00625):
            l=front(dx,.8,amp,False,"-direct");s=front(dx,.8,amp,True,"-direct");b=front(dx,.8,0.,False,"-direct")
            hom=read(f"homogeneous-{dx:g}-h{amp:g}.npz")
            hgrid=read(f"homogeneous-{dx*2:g}-h{amp:g}.npz") if dx<.025 else None
            pairs.append(dict(amp=amp,dx=dx,label_minus_ordinary=l[-1,1]-b[-1,1],
                              shell_minus_ordinary=s[-1,1]-b[-1,1],
                              subtract_two=s[-1,1]-l[-1,1],direct_difference=hom[-1,1],
                              difference_fraction_of_ordinary=hom[-1,1]/b[-1,1],
                              same_axial_wave=bool(np.array_equal(l[:,9],s[:,9])),
                              direct_vs_subtraction=error(s[:,1]-l[:,1],hom[:,1]),
                              independent_volume=error(hom[:,2],hom[:,1]),
                              direct_grid=error(hgrid[:,1],hom[:,1]) if hgrid is not None else None))
    write("preparation-contrasts.csv",pairs)
    with source(PRE,"source_calibration.csv").open() as stream:
        transfer=float(next(i for i in csv.DictReader(stream) if i["mesh"]=="1920" and i["eta"]=="1.0" and i["profile"]=="1")["transfer"])
    profiles=[]
    for dx,wide in ((.025,False),(.0125,False),(.0125,True),(.00625,True)):
        middle="-wide-direct" if wide else "-direct"
        one=front(dx,1,0,False,middle+"-to4");two=front(dx,1,0,False,middle+"-spin1-to4")
        for tick in (6,150,200):
            ratio=two[tick,1]/one[tick,1];deviation=ratio/transfer-1
            geometry=two[tick,2]/one[tick,2];residual=two[tick,1]-transfer*one[tick,1]
            profiles.append(dict(dx=dx,wide=wide,tau=two[tick,0],transfer=transfer,
                                 measured=ratio,relative_departure=deviation,physical_residual=residual,metric_ratio=geometry,
                                 metric_residual=two[tick,2]-transfer*one[tick,2],
                                 wave_first=error(one[:tick+1,9],one[:tick+1,10]) if tick>6 else None,
                                 wave_second=error(two[:tick+1,9],two[:tick+1,10]) if tick>6 else None))
    write("interior-source-transfer.csv",profiles)
    derived=[]
    for path in sorted(HOME.glob("balances-*.csv")):
        with path.open() as stream: tests=list(csv.DictReader(stream))
        for row in tests:
            time=float(row["tau"]);rr=float(row["radius"])
            if time==0:continue
            margin=min(rr-1.65,10.35-rr)-time
            value=lambda k:float(row[k])
            derived.append(dict(packet=path.name,tau=time,radius=rr,
                                causal_buffer_estimate=margin,interior_check=margin>.2,
                                xfrac=abs(value("momentum_x"))/value("scale_x"),
                                thetafrac=abs(value("momentum_theta"))/value("scale_theta"),
                                ham=value("ham"),gauss=value("gauss")))
    write("constraint-residuals.csv",derived)
    primary=front(.0125,.8,1,False,"-direct")
    wide=front(.0125,.8,1,False,"-wide-direct")
    slow=front(.0125,.8,1,False,"-dt0.16-direct")
    tested=dict(full_scalar_time=error(slow[:,1],primary[:,1]),full_scalar_domain=error(wide[:,1],primary[:,1]))
    (HOME/"method-controls.json").write_text(json.dumps(tested,indent=2)+"\n")
    print(rows);print(pairs[-1]);print(profiles[-1]);print(tested)
if __name__=="__main__":main()
