import csv
from front_equations import HOME, PRE, Front, COS, SIN, POL, ANG, ANG2, EPS, angle, mixed, coeff, source, np
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from scipy.optimize import root

def readout(model,y,label):
    ax,cross,ct,cf,kx,kxt,ktt,kff=y[:8];radius=model.x
    aa=1+ax;cc=radius**2*(1+ct);det=aa*cc-cross**2;ia=cc/det;ib=-cross/det
    zz=np.sqrt(1+cf);omega=radius*zz*SIN;cslope=angle(cc)
    wt=radius*(COS*zz+SIN*angle(zz))
    wtt=radius*(-SIN*zz+2*COS*angle(zz)+SIN*coeff(zz)*ANG2)
    wr=SIN*(zz+radius*model.dr(zz));cr=2*radius*(1+ct)+radius**2*model.dr(ct)
    norm=np.sqrt(det/cc)
    ktang=-norm*(ia*(mixed(cross)-cr/2)+ib*cslope/2)/cc
    kcirc=(wr-cross/cc*wt)/(norm*omega)
    intrinsic=-(wtt-cslope*wt/(2*cc))/(cc*omega)
    section=ktang*kcirc-intrinsic-ktt*kff/((1+ct)*(1+cf))
    areal=radius*np.sqrt(1+ct.real[:,:1])
    th=ct.imag/(EPS*(1+ct.real));ph=cf.imag/(EPS*(1+cf.real))
    trace=coeff((th+ph)/2);tensor=(th[:,:1]-ph[:,:1])/(3*SIN[0]**2)
    mass=model.model.mass_infty
    relative=1.5*(coeff(section.imag)/EPS-3*mass/areal**3*(trace+3*tensor))
    return CubicSpline(radius[:,0],relative[:,0])(label).item()

def regular_exterior(model):
    radius=model.x;mass=model.model.mass_infty
    coeffs=[1.]
    for power in range(4,19):
        coeffs.append(mass*(power-1)*(2*power-3)*coeffs[-1]/((power-3)*(power+2)))
    def shape(rr):
        return np.polynomial.polynomial.polyval(1/rr,coeffs)/rr**3
    centre=model.centre
    u6=model.initial[2,centre,0].imag/(4*EPS*POL[0])
    u=u6*shape(radius)/shape(6.)
    mask=radius[:,0]>=5.04
    ff=1-2*mass/radius
    model.initial[0,mask,:]=(2*mass/radius[mask]+4j*EPS*u[mask]*POL)/ff[mask]
    model.initial[2,mask,:]=model.initial[3,mask,:]=4j*EPS*u[mask]*POL

def run(dx,smooth=False):
    model=Front(dx,0.,0.,direct=True);mass=model.model.mass_infty
    if smooth:regular_exterior(model)
    y=model.initial.copy()
    with source(PRE,"vacuum_wave.csv").open() as stream:
        saved=next(row for row in csv.DictReader(stream) if row["mesh"]=="1920" and float(row["radius"])==6.)
    end=float(saved["coordinate_time"])
    def final(par):
        tau,launch=par;energy=np.sqrt(1-2*mass/launch)
        return solve_ivp(lambda _,q:[q[1],-mass/q[0]**2,energy/(1-2*mass/q[0])],(0,tau),[launch,0.,0.],rtol=1e-13,atol=1e-15,method="DOP853").y[:,-1]
    result=root(lambda par:final(par)[[0,2]]-[6.,end],[end,6.])
    assert result.success and max(abs(result.fun))<1e-12
    tau,label=result.x
    start=readout(model,y,6.)
    count=int(np.ceil(tau/(.2*dx)));dt=tau/count
    for idx in range(count):
        first=model.rhs(y);second=model.rhs(y+.5*dt*first);third=model.rhs(y+.5*dt*second)
        y+=dt/6*(first+2*second+2*third+model.rhs(y+dt*third))
    finish=readout(model,y,label);dynamic=finish-start;ref=float(saved["change"])
    return [dx,tau,label,start,float(saved["launch"]),dynamic,ref,(dynamic-ref)/ref]

if __name__=="__main__":
    rows=[run(dx) for dx in (.05,.025,.0125,.00625)]
    with (HOME/"neutral-master.csv").open("x",newline="") as stream:
        writer=csv.writer(stream);writer.writerow("spacing tau launch_label start master_start change master_change fractional_change_error".split());writer.writerows(rows)
    print(rows,flush=True)
