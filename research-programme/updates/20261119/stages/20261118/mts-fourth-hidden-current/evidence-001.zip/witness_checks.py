from hidden_family import HERE,GRIDS,ARMS,np,json,data,at,read,table,family
from hidden_run import saved,magnetic_file
from hidden_detector import LATE_B,LATE_G
from itertools import product


def evaluate():
    report=[];summary=[];plan=json.loads((HERE/"frozen-tests.json").read_text())
    jobs={(row["arm"],row["tag"]):row for row in plan["tests"]}
    trials=[("centre","centre")]
    for tags in (("imitation","centre"),("centre","imitation"),("joint","joint")):
        if all(tag=="centre" or (arm,tag) in jobs for arm,tag in enumerate(tags)):trials.append(tags)
    calibration=saved("three-clock-forecasts.npz");scale=np.linalg.norm(calibration["g1a0_basisB"][LATE_B],axis=1)
    for label in ("coarse","joint"):
        for spec in json.loads((HERE/f"{label}-detectors.json").read_text())["design"]:
            if spec["weights"] is None:continue
            w=np.array(spec["weights"]);fieldcase=spec["which"]=="field"
            for otag,stag in trials:
                outputs=[]
                for idx,dx in enumerate(GRIDS):
                    predictions=[];actuals=[];alternates=[];ledgers=[]
                    for arm,tag in enumerate((otag,stag)):
                        t=jobs[arm,tag]["t"] if tag!="centre" else 0.
                        line=family(dx,arm);field,ruler=data(dx,arm,tag)
                        if fieldcase:
                            pred=at(line["field"][LATE_B,0],t)/scale
                            obs=field[LATE_B,0]/scale
                            alternate=(line["field"][LATE_B,0,0]+t*(read(magnetic_file(dx,arm))["fields"][LATE_B,0]+
                                calibration[f"g{idx}a{arm}_basisB"][LATE_B]@line["direction"][:3]))/scale
                            ledger=obs
                        else:
                            pred=at(line["ruler"][LATE_G,0],t);obs=ruler[LATE_G,0]
                            alternate=ruler[LATE_G,1];ledger=ruler[LATE_G,2:].sum(axis=1)
                        predictions.append(pred);actuals.append(obs);alternates.append(alternate);ledgers.append(ledger)
                    differential=lambda mats:float(w@(mats[1]-mats[0]))
                    predicted=differential(predictions);test=differential(actuals);other=differential(alternates);focus=differential(ledgers)
                    outputs.append(test)
                    report.append(dict(design=label,observable=spec["which"],dx=dx,ordinary=otag,scalar=stag,model_gap=predicted,
                        directly_measured_gap=test,alternate_gap=other,focus_gap=(None if fieldcase else focus),
                        prediction_error=abs(predicted-test)/max(abs(test),1e-300),alternate_error=abs(test-other)/max(abs(test),1e-300),
                        focus_error=(None if fieldcase else abs(test-focus)/max(abs(test),1e-300))))
                spread=abs(outputs[0]-outputs[1]);last=report[-1];control=abs(last["directly_measured_gap"]-last["alternate_gap"])
                if not fieldcase:control=max(control,abs(last["directly_measured_gap"]-last["focus_gap"]))
                residue=spread+control+abs(last["directly_measured_gap"]-last["model_gap"])
                summary.append(dict(design=label,observable=spec["which"],ordinary=otag,scalar=stag,
                         signed_fine_difference=outputs[1],grid_spread=spread,numerical_stress_ratio=residue/max(abs(outputs[1]),1e-300),
                         same_sign_both_grids=bool(outputs[0]*outputs[1]>0),absolute_noise_halfwidth_before_early_errors=abs(outputs[1])/2))
    return report,summary


if __name__=="__main__":
    first,second=evaluate();table("direct-detector-gaps.csv",first);table("detector-stress-test.csv",second)
