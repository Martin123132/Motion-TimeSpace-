from hidden_family import HERE,GRIDS,PICKS,np,json,parent,read,table,digest,data,at,relative,family
from hidden_run import original,store_packet,fast_hold,saved,checkpoint
from unittest.mock import patch
import sys

SMALL=(.125,.5)


def historical(member):
    assert digest(parent.PRE/"closeout.json")==parent.LOCK
    path=parent.PRE/member;assert digest(path)==json.loads((parent.PRE/"closeout.json").read_text())["files"][member]
    return read(path)


def derive():
    old=saved("three-clock-forecasts.npz");result={}
    for index,dx in enumerate(GRIDS):
        tang=historical(f"tangent-minus-d{dx:g}-to6.4.npz")["history"][:,2]
        fields=old[f"g{index}a0_basisB"];matrix=old[f"g{index}a0_basisK"][:,0]
        reference=old[f"g{index}a0_v"];line=family(dx,0)
        velocity=np.linalg.solve(fields[PICKS],-tang[PICKS,2])
        slope=tang[:,0]+2*(velocity@matrix@reference);polar=tang[:,2]+fields@velocity
        b=line["ruler"][-1,0,1];c=line["ruler"][-1,0,2]
        if b==0:raise ArithmeticError("zero matching derivative")
        prime=slope[-1]/b
        for key,value in dict(u=velocity,L=slope,B=polar,t=prime,kinetic=line["cost"][1]*prime,
             Wref=line["cost"][0],b=b,c=c,withheld_L=slope-prime*line["ruler"][:,0,1],
             withheld_B=polar-prime*line["field"][:,0,1]).items():result[f"g{index}_"+key]=value
        assert np.max(abs(polar[PICKS]))<2e-12*np.max(abs(tang[PICKS,2]))
    result["protocol"]=digest(HERE/"WEAK-LIMIT.md")
    return result


def forecast_file():return HERE/"weak-limit-forecast.npz"
def packet_file(amp,tag):return HERE/f"intermediate-{tag}-A{amp:g}.npz"
def ticket(amp):return HERE/f"intermediate-calibration-A{amp:g}.json"


def evolve(amp,phase):
    checkpoint();assert amp in SMALL and phase in ("magnetic","matched")
    assert str(read(forecast_file())["protocol"])==digest(HERE/"WEAK-LIMIT.md")
    only=phase=="magnetic";dx=.0125;target=packet_file(amp,phase);end=250 if only else 320
    weights=[0.,0.,1.] if only else json.loads(ticket(amp).read_text())["weights"]
    if target.exists():raise FileExistsError(target)
    model=original.Centre(dx,.8,0.,cap=12,reduced=True,damping=.5,mass_form=True)
    model.profile=tuple(weights);full=original.regular.Model(1920,.8,1.,0)
    with patch.object(model.model,"scalar",lambda *args:amp*full.scalar(*args)),patch.object(model.model,"h",amp*full.h),patch.object(original.smooth_launch,"spin",original.law):
        initial=original.smooth_launch.refresh(model,.8,amp,False,model.profile)
    state=model.y0.copy();start=model.logmetric(state);series=[];steps=int(np.ceil(.02/(.30*dx)-1e-12));dt=.02/steps
    with patch.object(original.signed_equations,"spin",original.law),patch.object(original.exposure,"spin",original.law):
        for tick in range(end+1):
            fast_hold();radius=model.rad*np.sqrt(1+state[2].real[:,:1])
            value=model.atsite((2*state[19].real[:,:1]/radius**2)[:,0])
            series.append([value] if only else [value,model.contrast(state[17]),model.contrast(model.logmetric(state)-start),*original.exposure.terms(model,state)])
            if tick==end:break
            for _ in range(steps):
                one=model.rhs(state);two=model.rhs(state+.5*dt*one);three=model.rhs(state+.5*dt*two);four=model.rhs(state+dt*three)
                state+=dt/6*(one+2*two+2*three+four)
    assert np.isfinite(series).all() and np.isfinite(state).all()
    store_packet(target,rows=series,clock=np.arange(end+1)*.02,weights=weights,amplitude=amp,dx=dx,
        initial=json.dumps(initial),forecast=digest(forecast_file()),authorization="column only" if only else digest(ticket(amp)))
    print(target.name,flush=True)


def calibrate(amp):
    path=packet_file(amp,"magnetic");old=historical(f"finite-fixed-d0.0125-A{amp:g}.npz")
    second=old["rows"][PICKS,12];fixed=old["rows"][PICKS,2];third=read(path)["rows"][PICKS,0]
    matrix=np.column_stack((fixed+original.COEFFICIENT*second,second,third))
    target=saved("three-clock-forecasts.npz")["target"];delta=np.linalg.solve(matrix,target-fixed)
    return dict(weights=(parent.VREF+delta).tolist(),change=delta.tolist(),matrix=matrix.tolist(),target=target.tolist(),
        third=digest(path),forecast=digest(forecast_file()),fixed_receipt=digest(parent.PRE/f"finite-fixed-d0.0125-A{amp:g}.npz"))


def run(amp):
    evolve(amp,"magnetic")
    with ticket(amp).open("x") as stream:json.dump(calibrate(amp),stream,indent=2,allow_nan=False)
    evolve(amp,"matched")


def stats():
    result=[];pred=read(forecast_file());line=family(.0125,0);camera=saved("three-clock-forecasts.npz")
    for amp in (*SMALL,1.):
        z=amp**2
        if amp==1.:
            sf,sg=data(.0125,1,"centre");field=sf[:,0];gravity=sg[:,0];metric=sg[:,1];ledger=sg[:,2:].sum(axis=1)
            vw=family(.0125,1)["centre"][:3]-parent.VREF
        else:
            block=read(packet_file(amp,"matched"));record=json.loads(ticket(amp).read_text())
            assert record==calibrate(amp) and np.array_equal(block["weights"],record["weights"])
            rows=block["rows"];field=rows[:,0];gravity=rows[:,1];metric=rows[:,2]
            ledger=original.double_integral(block["clock"],rows[:,3:]).sum(axis=1);vw=np.array(record["change"])
        change=gravity[-1]-line["ruler"][-1,0,0];b=pred["g1_b"];c=pred["g1_c"];disc=b*b+4*c*change
        regular=disc>0
        t=2*change/(b+np.copysign(np.sqrt(disc),b)) if regular else -b/(2*c)
        g=z*pred["g1_L"][-1];guess_disc=b*b+4*c*g
        inv=2*g/(b+np.copysign(np.sqrt(guess_disc),b)) if guess_disc>0 else None
        rd=gravity-at(line["ruler"][:,0],t);fd=field-at(line["field"][:,0],t)
        result.append(dict(A=amp,regular_local_root=bool(regular),local_root=t if regular else None,closest_test_t=t,root_per_A2=t/z if regular else None,derived_root_slope=float(pred["g1_t"]),
            local_tangent_error=abs(t/(z*pred["g1_t"])-1) if regular else None,ordinary_nonlinear_inversion_error=abs(inv/t-1) if regular and inv is not None else None,
            cost_change_per_A2=(line["cost"][1]+line["cost"][2]*t)*t/z,derived_cost_slope=float(pred["g1_kinetic"]),
            observed_L_per_A2=change/z,derived_L_derivative=pred["g1_L"][-1],late_scalar_coefficient_error=abs(change/g-1),
            three_clock_match=np.max(abs((field[PICKS]-camera["target"])/np.linalg.norm(camera["g1a0_basisB"][PICKS],axis=1))),
            source_velocity_error=relative(vw/z,pred["g1_u"]),postmatch_ruler_shape_error=relative(rd/z,pred["g1_withheld_L"]),
            postmatch_field_shape_error=relative(fd/z,pred["g1_withheld_B"]),ruler_at_six=rd[300],predicted_ruler_at_six=z*pred["g1_withheld_L"][300],
            B_at_six=fd[300],predicted_B_at_six=z*pred["g1_withheld_B"][300],total_metric_check=relative(metric,gravity),total_focusing_check=relative(ledger,gravity)))
    return result


if __name__=="__main__":
    if sys.argv[1]=="freeze":
        if any(HERE.glob("intermediate-*")):raise RuntimeError("out of sequence")
        store_packet(forecast_file(),**derive())
    elif sys.argv[1]=="score":table("near-ordinary-limit.csv",stats())
    else:run(float(sys.argv[1]))

