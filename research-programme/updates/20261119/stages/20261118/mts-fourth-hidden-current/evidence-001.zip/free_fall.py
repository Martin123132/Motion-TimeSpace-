from itertools import combinations
from functools import lru_cache
from scipy.optimize import linprog
from focusing_witness import GRIDS, TOL, np, packet, table


TIMES = (3., 4., 5., 5.6, 6., 6.4)
METHODS = ("radius7", "radius5", "stride2", "metric_velocity")


@lru_cache(maxsize=32)
def weights(offsets):
    points=np.array(offsets, dtype=float)
    powers=np.vstack([points**power for power in range(len(points))])
    target=np.zeros(len(points));target[1]=1.
    return np.linalg.solve(powers,target)


def derivative(values, index, dt, width, stride):
    start=max(0,min(index-(width//2)*stride,len(values)-1-(width-1)*stride))
    sample=np.arange(start,start+width*stride,stride)
    assert index in sample
    return float(weights(tuple((sample-index)//stride))@(values[sample]-values[index])/(stride*dt))


def minimax(abscissa, ordinate, decreasing):
    if not np.all(np.diff(abscissa)>0):
        raise ValueError("distinct increasing inverse radius required")
    scale_x=abscissa[-1]-abscissa[0]
    scale_y=float(np.ptp(ordinate)) or 1.
    locations=(abscissa-abscissa[0])/scale_x
    values=(ordinate-ordinate[0])/scale_y
    bounds=[]
    for left,middle,right in combinations(range(len(values)),3):
        fraction=(locations[middle]-locations[left])/(locations[right]-locations[left])
        signed=values[middle]-((1-fraction)*values[left]+fraction*values[right])
        bounds.append((abs(signed)/2,"triple",(left,middle,right),signed*scale_y))
    if decreasing:
        for left,right in combinations(range(len(values)),2):
            signed=values[right]-values[left]
            bounds.append((max(0.,signed)/2,"rise",(left,right),signed*scale_y))
    radius,kind,indices,contrast=max(bounds,key=lambda row:row[0])
    slope_low=-np.inf;slope_high=0. if decreasing else np.inf
    for left,right in combinations(range(len(values)),2):
        rise=values[right]-values[left];width=locations[right]-locations[left]
        slope_low=max(slope_low,(rise-2*radius)/width)
        slope_high=min(slope_high,(rise+2*radius)/width)
    assert slope_low-slope_high<2e-12
    slope=(slope_low+slope_high)/2
    offsets=values-slope*locations
    intercept=(max(offsets)+min(offsets))/2
    assert abs(max(abs(offsets-intercept))-radius)<2e-12
    design=np.column_stack((np.ones(len(values)),locations))
    inequalities=np.column_stack((np.vstack((design,-design)),-np.ones(2*len(values))))
    opt=linprog([0.,0.,1.],A_ub=inequalities,b_ub=np.r_[values,-values],
                bounds=((None,None),(None,0. if decreasing else None),(0.,None)),method="highs-ds",
                options={"threads":1,"primal_feasibility_tolerance":1e-10,"dual_feasibility_tolerance":1e-10})
    assert opt.success and abs(radius-opt.fun)<2e-9
    physical_slope=slope*scale_y/scale_x
    physical_intercept=ordinate[0]+intercept*scale_y-physical_slope*abscissa[0]
    return dict(distance=radius*scale_y,kind=kind,indices=indices,contrast=contrast,
                slope=physical_slope,intercept=physical_intercept,lp_distance=opt.fun*scale_y)


def controls():
    coords=np.array([0.,.125,.5,1.])
    roots=[minimax(coords, 3.-2*coords,True)["distance"],
           minimax(coords, 4.+coords,False)["distance"],
           abs(minimax(coords,4.+coords,True)["distance"]-.5),
           abs(minimax(np.array([0.,.5,1.]),np.array([0.,1.,0.]),False)["distance"]-.5)]
    time=np.arange(321)*.02
    for width,stride,degree in ((7,1,6),(7,2,6),(5,1,4)):
        curve=((time-3)/4)**degree
        for tick in (0,150,200,250,280,300,320):
            analytic=degree*((time[tick]-3)/4)**(degree-1)/4
            roots.append(abs(derivative(curve,tick,.02,width,stride)-analytic))
    assert max(roots)<2e-10


def contrast_values(xdata,ydata,summary):
    indices=summary["indices"]
    if summary["kind"]=="rise":
        left,right=indices
        return ydata[right]-ydata[left]
    left,middle,right=indices
    frac=(xdata[middle]-xdata[left])/(xdata[right]-xdata[left])
    return ydata[middle]-((1-frac)*ydata[left]+frac*ydata[right])


def evaluate():
    controls()
    clocks=[];scores=[];checks=[];stored={}
    for dx in GRIDS:
        for arm in (0,1):
            block=packet(dx,arm,"centre");rows=block["rows"];mass=block["mass"];radii=rows[:,6]
            assert mass[0,7]==0 and np.array_equal(rows[::10,0],mass[:,0])
            assert np.max(abs(radii[::10]-mass[:,11]))<1e-13
            for meth in METHODS:
                width=5 if meth=="radius5" else 7;stride=2 if meth=="stride2" else 1
                release=mass[0,7] if meth=="metric_velocity" else derivative(radii,0,.02,width,stride)
                assert abs(release)<1e-10
                speed=np.array([mass[round(tau/.2),7] if meth=="metric_velocity" else
                             derivative(radii,round(tau/.02),.02,width,stride) for tau in TIMES])
                positions=radii[[round(tau/.02) for tau in TIMES]]
                xdata=(radii[0]-positions)/(radii[0]*positions)
                assert min(xdata)>0 and max(speed)<0
                ydata=speed**2/xdata
                slope=(ydata[2]-ydata[0])/(xdata[2]-xdata[0])
                pred=ydata[0]+slope*(xdata-xdata[0])
                for idx,tau in enumerate(TIMES):
                    clocks.append(dict(dx=dx,arm=arm,method=meth,tau=tau,radius=positions[idx],speed=speed[idx],
                         x=xdata[idx],Y=ydata[idx],line_from_3_5=pred[idx],heldout=idx not in (0,2),
                         residual=ydata[idx]-pred[idx],inferred_Q_squared=-slope,rest_speed=release))
                for decreasing in (False,True):
                    res=minimax(xdata,ydata,decreasing);stored[dx,arm,meth,decreasing]=(xdata,ydata,res)
                    scores.append(dict(dx=dx,arm=arm,method=meth,decreasing=decreasing,uniform_error=res["distance"],
                        error_on_Y=res["distance"]/max(abs(ydata)),witness=res["kind"],
                        witness_times=";".join(str(TIMES[i]) for i in res["indices"]),signed_contrast=res["contrast"],
                        optimal_Q_squared=-res["slope"],optimal_mass=(res["intercept"]-2*res["slope"]/radii[0])/2,
                        independent_lp_distance=res["lp_distance"]))
    for decreasing in (False,True):
        fine=min(GRIDS);coarse=max(GRIDS)
        cert=stored[fine,1,"radius7",decreasing][2]
        reference=cert["contrast"];assert reference!=0.
        scalar=[(dx,meth,contrast_values(*stored[dx,1,meth,decreasing][:2],cert)) for dx in GRIDS for meth in METHODS]
        ordinary=[contrast_values(*stored[dx,0,meth,decreasing][:2],cert) for dx in GRIDS for meth in METHODS]
        worst_method=max(abs(entry-reference) for dx,meth,entry in scalar if dx==fine)
        grid=abs(next(entry for dx,meth,entry in scalar if dx==coarse and meth=="radius7")-reference)
        floor=max(abs(elem) for elem in ordinary)
        total=worst_method+grid+floor
        checks.append(dict(decreasing=decreasing,kind=cert["kind"],witness_times=";".join(str(TIMES[i]) for i in cert["indices"]),
                    scalar_certificate=reference,ordinary_floor=floor,grid_change=grid,derivative_change=worst_method,
                    numerical_stress_on_contrast=total/abs(reference),survives_stress=bool(total<abs(reference)),
                    within_accuracy=bool(total<=TOL*abs(reference)),allowable_equal_Y_halfwidth_after_stress=max(0.,abs(reference)-total)/2))
    return {"free-fall-readings.csv":clocks,"free-fall-distance.csv":scores,"free-fall-robustness.csv":checks}


if __name__=="__main__":
    for filename,values in evaluate().items():
        table(filename,values)
