import csv
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline
from free_fall import TIMES, GRIDS, TOL, np, packet, table
from vacuum_stress_control import design, weight
from hidden_run import HERE


def propagate(block, stride, degree, variant, max_step):
    mass=block["mass"];raw=mass[::stride]
    charge=mass[0,17];radius0=mass[0,11]
    mass0=mass[0,8]+charge**2/(2*radius0)
    assert max(abs(mass[:,17]-charge))<abs(charge)*1e-12
    pressure=-(raw[:,14]+raw[:,16])/raw[:,11]
    outward=-raw[:,13]/raw[:,11]**2
    histories=make_interp_spline(raw[:,0],np.column_stack((pressure,outward)),k=degree)
    def system(clock,values):
        displacement,speed,delta_mass=values[:3];radius=radius0+displacement
        local_p,flux=histories(clock)
        if variant in ("no_pressure","electrovac"):local_p=0.
        if variant in ("no_transport","electrovac"):flux=0.
        acceleration_p=-radius*local_p
        acceleration_extra=-delta_mass/radius**2
        return [speed, -mass0/radius**2+charge**2/radius**3+acceleration_extra+acceleration_p,
                -radius**2*(local_p*speed+flux), 2*speed*acceleration_p, 2*speed*acceleration_extra]
    sol=solve_ivp(system,(0.,TIMES[-1]),np.zeros(5),t_eval=TIMES,method="DOP853",rtol=1e-12,
                  atol=(1e-18,1e-19,1e-20,1e-24,1e-24),max_step=max_step)
    assert sol.success and len(sol.t)==len(TIMES)
    delta,speeds,extra_mass,pressure_work,mass_work=sol.y
    xi=-delta/(radius0*(radius0+delta));values=speeds**2/xi
    pressure_y=pressure_work/xi;mass_y=mass_work/xi;base=2*mass0-2*charge**2/radius0-charge**2*xi
    assert np.all(xi>0)
    return xi,values,base,pressure_y,mass_y,extra_mass,delta,speeds


def results(fall=None,vacuum=None):
    def load(member):
        with (HERE/member).open(newline="") as handle:return list(csv.DictReader(handle))
    clocks=fall["free-fall-readings.csv"] if fall is not None else load("free-fall-readings.csv")
    control=(vacuum["constant-vacuum-stress.csv"] if vacuum is not None else load("constant-vacuum-stress.csv"))[0]
    indices=[TIMES.index(float(token)) for token in control["witness"].split(";")]
    scale=abs(float(control["fine_scalar_certificate"]))
    outcome=[];details=[]
    for dx in GRIDS:
        for arm in (0,1):
            block=packet(dx,arm,"centre");bank=block["mass"];radius0=bank[0,11]
            measured=[row for row in clocks if float(row["dx"])==dx and int(row["arm"])==arm and row["method"]=="radius7"]
            xx=np.array([float(row["x"]) for row in measured]);yy=np.array([float(row["Y"]) for row in measured])
            def contrast(vect,coeff):
                subset=vect[indices]
                return coeff@(subset-subset[0])
            truth=contrast(yy,weight(design(xx,radius0)[indices]))
            rows_idx=[round(tau/.2) for tau in TIMES]
            observed_mass=bank[:,8]+bank[:,17]**2/(2*bank[:,11])
            for stride,degree,variant,step in ((1,5,"all",.05),(1,3,"all",.05),(2,5,"all",.05),(1,5,"all",.025),
                    (1,5,"no_pressure",.05),(1,5,"no_transport",.05),(1,5,"electrovac",.05)):
                coords,values,base,pressure_y,mass_y,delta_mass,displacement,speeds=propagate(block,stride,degree,variant,step)
                coeff=weight(design(coords,radius0)[indices]);pred=contrast(values,coeff)
                press=contrast(pressure_y,coeff);enclosed=contrast(mass_y,coeff)
                outcome.append(dict(dx=dx,arm=arm,spacing=.2*stride,degree=degree,variant=variant,max_step=step,
                     predicted_certificate=pred,geometric_certificate=truth,pressure_piece=press,accumulated_mass_piece=enclosed,
                     source_error_on_nominal_scalar=abs(pred-truth)/scale,passes=bool(abs(pred-truth)<=TOL*scale),
                     decomposition_error_on_nominal_scalar=abs(pred-press-enclosed)/scale,
                     max_energy_integral_error=max(abs(values-base-pressure_y-mass_y)),
                     max_radius_error=max(abs(radius0+displacement-bank[rows_idx,11])),
                     max_speed_error=max(abs(speeds-bank[rows_idx,7])),
                     max_mass_error=max(abs(delta_mass-(observed_mass[rows_idx]-observed_mass[0])))))
                if variant=="all" and degree==5 and stride==1 and step==.05:
                    for idx,tau in enumerate(TIMES):
                        details.append(dict(dx=dx,arm=arm,tau=tau,delta_R=displacement[idx],v=speeds[idx],delta_enclosed=delta_mass[idx],
                            predicted_Y=values[idx],radius_only_Y=yy[idx],ordinary_release_Y=base[idx],pressure_Y=pressure_y[idx],
                            accumulated_mass_Y=mass_y[idx]))
    return {"clock-source-balance.csv":outcome,"clock-source-history.csv":details}


if __name__=="__main__":
    for filename,values in results().items():
        table(filename,values)
