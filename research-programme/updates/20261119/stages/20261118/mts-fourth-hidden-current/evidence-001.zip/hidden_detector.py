from hidden_family import HERE,GRIDS,ARMS,PICKS,np,json,read,table,digest,family,at
from hidden_run import saved
import sympy as sp
import sys

LATE_G=np.arange(255,321,5)
LATE_B=np.array([275,300,320])


def columns(dx,which):
    arms=[family(dx,amp) for amp in ARMS]
    if which=="ruler":
        time=LATE_G
        base=[line["ruler"][time,0,0] for line in arms]
        columns=[line["ruler"][time,0,1:] for line in arms]
    elif which=="field":
        time=LATE_B;scale=np.linalg.norm(saved("three-clock-forecasts.npz")["g1a0_basisB"][time],axis=1)
        base=[line["field"][time,0,0]/scale for line in arms]
        columns=[line["field"][time,0,1:]/scale[:,None] for line in arms]
    else:raise ValueError(which)
    return base[1]-base[0],np.column_stack(columns),base


def rational(array):
    arr=np.asarray(array)
    if arr.ndim==1:return sp.Matrix([sp.Rational(float(v)) for v in arr])
    return sp.Matrix([[sp.Rational(float(v)) for v in row] for row in arr])


def design(which,grids):
    grouped=[columns(dx,which) for dx in grids]
    aim=sum((rational(data[0]) for data in grouped),sp.zeros(len(grouped[0][0]),1))/len(grids)
    nuisance=sp.Matrix.hstack(*(rational(data[1]) for data in grouped))
    independent=nuisance.columnspace()
    basis=sp.Matrix.hstack(*independent)
    remainder=aim-basis*(basis.T*basis).inv()*(basis.T*aim)
    norm=sum(abs(value) for value in remainder)
    if norm==0:return dict(which=which,grids=grids,rank=len(independent),weights=None,reason="no separating weight")
    weights=remainder/norm
    assert weights.T*nuisance==sp.zeros(1,nuisance.cols) and (weights.T*aim)[0]>0 and sum(abs(v) for v in weights)==1
    return dict(which=which,grids=grids,rank=len(independent),weights=[float(v) for v in weights],
                exact_weights=[str(v) for v in weights],separation=float((weights.T*aim)[0]))


def write_design(label):
    path=HERE/f"{label}-detectors.json"
    if path.exists():raise FileExistsError(path)
    if label=="coarse":
        items=[design(which,(.025,)) for which in ("field","ruler")]
    elif label=="joint":
        if not (HERE/"coarse-detectors.json").exists():raise RuntimeError("coarse weights must already be fixed")
        items=[design("ruler",GRIDS)]
    else:raise ValueError(label)
    if any(HERE.glob("source-imitation-*")) or any(HERE.glob("source-joint-*")):raise RuntimeError("design after test")
    with path.open("x") as stream:json.dump(dict(protocol=digest(HERE/"WITHHELD-PROTOCOL.md"),design=items),stream,indent=2,allow_nan=False)


def budget(line,limit):
    base,linear,quad=line["cost"];centre=-linear/(2*quad);least=at(line["cost"],centre)
    if least>limit:return None
    width=np.sqrt(max(0,(limit-least)/quad))
    return centre-width,centre+width


def shift_interval(linear,quad,interval):
    low,high=interval;points=[low,high]
    if quad and low< -linear/(2*quad)<high:points.append(-linear/(2*quad))
    vals=[linear*x+quad*x*x for x in points];return min(vals),max(vals)


def scores():
    rows=[]
    for label in ("coarse","joint"):
        specs=json.loads((HERE/f"{label}-detectors.json").read_text())
        for spec in specs["design"]:
            if spec["weights"] is None:continue
            weights=np.array(spec["weights"]);which=spec["which"];width=1 if which=="field" else 2
            for dx in GRIDS:
                gap,mat,base=columns(dx,which);terms=weights@mat
                gain=weights@gap
                one=terms[:width];two=terms[width:]
                curve0=family(dx,0);curve1=family(dx,1);ref=curve0["cost"][0]
                for factor in (1.,2.):
                    intervals=[budget(row,factor*ref) for row in (curve0,curve1)]
                    if None in intervals:continue
                    lo0,hi0=shift_interval(one[0],one[1] if width==2 else 0.,intervals[0])
                    lo1,hi1=shift_interval(two[0],two[1] if width==2 else 0.,intervals[1])
                    end1=gain+lo1-hi0;end2=gain+hi1-lo0
                    lower=max(0.,end1,-end2)
                    noise_gain=None;early_radius=None
                    if which=="field":
                        prev=saved("three-clock-forecasts.npz")
                        scales=np.linalg.norm(prev["g1a0_basisB"][LATE_B],axis=1)
                        early=np.linalg.norm(prev["g1a0_basisB"][PICKS],axis=1)
                        noise_gain=0.
                        for arm in ARMS:
                            fields=prev[f"g{GRIDS.index(dx)}a{arm}_basisB"]
                            op=(fields[LATE_B]/scales[:,None])@np.linalg.solve(fields[PICKS],np.diag(early))
                            noise_gain+=np.linalg.norm(weights@op,ord=1)
                        early_radius=lower/noise_gain
                    rows.append(dict(design=label,observable=which,dx=dx,energy_cap_ratio=factor,
                        gap=gain,low=end1,high=end2,guaranteed_within_fixed_grid_and_cap=lower,
                        max_leak_on_gap=max(abs(end1-gain),abs(end2-gain))/max(abs(gain),1e-300),
                        equal_late_error_halfwidth=lower/2,early_field_only_epsilon=early_radius,
                        closed_ordinary_coefficients=json.dumps(one.tolist()),closed_scalar_coefficients=json.dumps(two.tolist())))
    return rows


if __name__=="__main__":
    if sys.argv[1]=="score":table("detector-budgets.csv",scores())
    else:write_design(sys.argv[1])
