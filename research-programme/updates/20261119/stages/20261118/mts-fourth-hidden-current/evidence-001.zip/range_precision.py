from itertools import combinations
from free_fall import np, weights, table, packet
import csv
from hidden_run import HERE


def saturated_bracket(lower, initial):
    high=initial
    if not lower(0.)>0:
        return 0.,0.
    while lower(high)>0:
        high*=2
    low=0.
    for step in range(64):
        middle=(low+high)/2
        if lower(middle)>0:low=middle
        else:high=middle
    return low,high


def extremes(range0, positions, speeds, ticks, fixed_floor, radius_error, speed_fraction, use_camera):
    sizes=len(positions)
    delta=range0-positions
    if min(delta)<=2*radius_error or min(-np.diff(positions))<=2*radius_error:
        return -np.inf
    bounds=[]
    for pos in range(sizes):
        vabs=abs(speeds[pos])
        if use_camera:
            idx=ticks[pos];start=max(0,min(idx-3,314))
            factors=weights(tuple(np.arange(start,start+7)-idx))
            dv=radius_error*sum(abs(factors))/.02
        else:dv=0.
        dv+=vabs*speed_fraction
        lo=max(0.,vabs-dv)**2*(positions[pos]-radius_error)*(range0-radius_error)/(delta[pos]+2*radius_error)
        hi=(vabs+dv)**2*(positions[pos]+radius_error)*(range0+radius_error)/(delta[pos]-2*radius_error)
        bounds.append((lo,hi))
    ref=speeds[0]**2*positions[0]*range0/delta[0]
    numerator_lo=0.;numerator_hi=0.;denom_upper=0.
    for drop in range(sizes):
        others=[jj for jj in range(sizes) if jj!=drop]
        group=positions[others]
        gap=np.array([positions[left]-positions[right] for left,right in combinations(others,2)])
        minor_lo=(range0+sum(group)-4*radius_error)*np.prod(gap-2*radius_error)/np.prod(group+radius_error)
        minor_hi=(range0+sum(group)+4*radius_error)*np.prod(gap+2*radius_error)/np.prod(group-radius_error)
        vals=[(-1)**drop*minor*(val-ref) for val in bounds[drop] for minor in (minor_lo,minor_hi)]
        numerator_lo+=min(vals);numerator_hi+=max(vals);denom_upper+=minor_hi
    return max(0.,numerator_lo,-numerator_hi)/denom_upper-fixed_floor


def results(fall=None, vacuum=None):
    def load(member):
        with (HERE/member).open(newline="") as handle:return list(csv.DictReader(handle))
    readings=fall["free-fall-readings.csv"] if fall is not None else load("free-fall-readings.csv")
    stress=(vacuum["constant-vacuum-stress.csv"] if vacuum is not None else load("constant-vacuum-stress.csv"))[0]
    use=[float(token) for token in stress["witness"].split(";")]
    rows=[row for row in readings if float(row["dx"])==.0125 and int(row["arm"])==1 and row["method"]=="radius7" and float(row["tau"]) in use]
    assert [float(row["tau"]) for row in rows]==use and len(use)==4
    fine=packet(.0125,1,"centre");r0=float(fine["rows"][0,6])
    positions=np.array([float(row["radius"]) for row in rows]);speed=np.array([float(row["speed"]) for row in rows]);ticks=np.rint(np.array(use)/.02).astype(int)
    floor=sum(float(stress[key]) for key in ("grid_change","derivative_change","ordinary_floor"))
    signal=abs(float(stress["fine_scalar_certificate"]))
    def bound(radius_err,speed_err,camera=False):
        return extremes(r0,positions,speed,ticks,floor,radius_err,speed_err,camera)
    assert abs((bound(0.,0.)+floor)/signal-1.)<1e-10
    limits={}
    for channel in ("radius","speed","radius_including_velocity"):
        if channel=="speed":law=lambda err:bound(0.,err);seed=1e-5
        elif channel=="radius":law=lambda err:bound(err,0.);seed=1e-9
        else:law=lambda err:bound(err,0.,True);seed=1e-11
        first,last=saturated_bracket(law,seed)
        assert first>0 and last>=first and law(first)>0 and law(last)<=0
        limits[channel]=first
    def row(label,radius_error,speed_error,camera):
        lower=bound(radius_error,speed_error,camera)
        return dict(test=label,clocks=";".join(str(v) for v in use),radius_abs_halfwidth=radius_error,
             fractional_speed_halfwidth=speed_error,radius_also_differentiated=camera,
             lower_distance_after_stress=lower,lower_relative_to_nominal_signal=lower/signal,
             radius_fraction_of_release=radius_error/r0,radius_fraction_of_smallest_fall=radius_error/min(r0-positions))
    out=[row("exact",0.,0.,False),
         row("radius_only_last_certified",limits["radius"],0.,False),
         row("speed_only_last_certified",0.,limits["speed"],False),
         row("radius_also_differentiated_last_certified",limits["radius_including_velocity"],0.,True),
         row("quarter_separate_allowances",limits["radius"]/4,limits["speed"]/4,False)]
    assert out[-1]["lower_distance_after_stress"]>0
    return {"free-fall-input-precision.csv":out}


if __name__=="__main__":
    for filename,records in results().items():
        table(filename,records)
