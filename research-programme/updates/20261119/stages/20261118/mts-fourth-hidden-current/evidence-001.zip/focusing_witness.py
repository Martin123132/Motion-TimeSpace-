from hidden_run import ARMS, GRIDS, HERE, PRE, TOL, name, np, original, parent, read, saved, table
from scipy.integrate import simpson


CLOCKS = (150, 200, 250, 275, 300, 320)
TAGS = ("centre", "hidden", "sum", "imitation", "joint")
PAIRS = (("centre", "centre"), ("imitation", "centre"), ("centre", "imitation"), ("joint", "joint"))
COLUMNS = "tau ray determinant polar_B equator_E equator_B R potential shear twist scalar polar_E dipole material H2 gauss".split()


def packet(dx, arm, tag):
    if tag == "centre":
        if arm:
            return saved(name(dx, .8, 1, "matched3"))
        return parent.old(name(dx, .8, 0, "minus"))
    return read(HERE / name(dx, .8, arm, tag))


def convolution(clock, terms, index):
    sampling = clock[:index+1]
    return simpson((sampling[-1] - sampling)[:, None] * terms[:index+1], x=sampling, axis=0)


def readout(block):
    rows, mass = block["rows"], block["mass"]
    clock = rows[:, 0]
    assert list(block["columns"]) == COLUMNS and mass.shape == (33, 20)
    assert np.array_equal(mass[:, 0], clock[::10]) and np.all(rows[0, 1:3] == 0)
    charge = np.interp(clock, mass[:, 0], mass[:, 17])
    dipole = rows[:, 4]**2 + rows[:, 5]**2 - rows[:, 3]**2
    exterior = 2 * (charge * rows[:, 3] / rows[:, 6])**2
    terms = np.column_stack((rows[:, 8:14], dipole - rows[:, 12], exterior - rows[:, 9],
                             abs(rows[:, 8])+abs(rows[:, 11]), np.sum(rows[:, 3:6]**2, axis=1), exterior))
    if not np.isfinite(terms).all():
        raise ArithmeticError("nonfinite stress in readout")
    at_clocks = {}
    for index in CLOCKS:
        integrated = convolution(clock, terms, index)
        shear, twist, scalar, polar, wave, material, wave_error, twist_error = integrated[:8]
        non_scalar = shear + twist + polar + wave + wave_error + material
        exterior_known = non_scalar + twist_error - material
        ruler, determinant = rows[index, 1:3]
        at_clocks[index] = dict(
            scalar=scalar, archived_scalar=block["integrated"][index, 2],
            general_metric=determinant-non_scalar, general_ray=ruler-non_scalar,
            exterior_metric=determinant-exterior_known, exterior_ray=ruler-exterior_known,
            geometry_and_polar_gain=integrated[8], squared_field_gain=integrated[9], exterior_axial_gain=integrated[10],
            omit_polar_electric=determinant-exterior_known+polar,
            omit_wave_stress=determinant-exterior_known+wave+wave_error,
            omit_shear=determinant-exterior_known+shear, instantaneous_wave_error_max=np.max(abs(terms[:index+1, 6])),
            wave_reconstruction=wave_error, exterior_twist_error=twist_error, discarded_material=material,
            metric_minus_ray=determinant-ruler, saved_quadrature_error=np.max(abs(integrated[:6]-block["integrated"][index])),
            displacement_vs_external_charge=np.max(abs(charge[:index+1]/(.8*original.MASS)-1)),
            max_sampled_abs_dust_density=np.max(abs(mass[mass[:, 0] <= clock[index], 18])))
    return at_clocks


def input_allowance(gains, margin):
    if margin <= 0:
        return 0.
    geometry, fields, axial = gains
    assert min(gains) >= 0 and max(gains) > 0
    def worst(epsilon):
        return epsilon*(geometry+(2+epsilon)*fields)+axial*np.expm1(4*np.log1p(epsilon)-2*np.log1p(-epsilon))
    low, high = 0., 1.-1e-12
    if worst(high) < margin:
        raise ArithmeticError("calibration threshold not bracketed below one")
    for unused in range(80):
        mid=(low+high)/2
        if worst(mid) < margin:
            low=mid
        else:
            high=mid
    return low


def findings():
    readings, contrasts, budgets = [], [], []
    for dx in GRIDS:
        samples = {(arm, tag):readout(packet(dx, arm, tag)) for arm in ARMS for tag in TAGS}
        scale = abs(samples[1, "centre"][320]["scalar"])
        assert scale > 0 and all(samples[0, tag][index]["scalar"] == 0 for tag in TAGS for index in CLOCKS)
        for (arm, tag), observations in samples.items():
            for index, record in observations.items():
                readings.append(dict(dx=dx, arm=arm, tag=tag, clock=index*.02, nominal_scalar_scale=scale, **record,
                    exterior_metric_error_on_nominal_scalar=abs(record["exterior_metric"]-record["scalar"])/scale,
                    exterior_ray_error_on_nominal_scalar=abs(record["exterior_ray"]-record["scalar"])/scale))
        for ordinary, scalar in PAIRS:
            for index in CLOCKS:
                ordinary_read = samples[0, ordinary][index]
                scalar_read = samples[1, scalar][index]
                true = scalar_read["scalar"]-ordinary_read["scalar"]
                ray = scalar_read["exterior_ray"]-ordinary_read["exterior_ray"]
                metric = scalar_read["exterior_metric"]-ordinary_read["exterior_metric"]
                general = scalar_read["general_metric"]-ordinary_read["general_metric"]
                absolute_budget = abs(scalar_read["exterior_metric"]-scalar_read["scalar"])+abs(ordinary_read["exterior_metric"])
                contrasts.append(dict(dx=dx, ordinary=ordinary, scalar=scalar, clock=index*.02, predicted_scalar=true,
                    inferred_metric=metric, inferred_ray=ray, inferred_general=general,
                    ordinary_false_signal=ordinary_read["exterior_metric"], signed_metric_error=metric-true,
                    metric_error_on_pair_signal=abs(metric-true)/abs(true) if true else None,
                    single_arm_error_sum_on_pair=absolute_budget/abs(true) if true else None,
                    ray_error_on_pair_signal=abs(ray-true)/abs(true) if true else None,
                    **{key:ordinary_read[key]+scalar_read[key] for key in
                       ("geometry_and_polar_gain","squared_field_gain","exterior_axial_gain")}))
    for ordinary, scalar in PAIRS:
        for index in CLOCKS:
            levels=[entry for entry in contrasts if entry["ordinary"]==ordinary and entry["scalar"]==scalar and entry["clock"]==index*.02]
            assert len(levels)==2 and levels[-1]["dx"]==min(GRIDS)
            coarse, fine=levels
            discrepancy=abs(coarse["inferred_metric"]-fine["inferred_metric"])
            signal=abs(fine["predicted_scalar"])
            stress=discrepancy + fine["single_arm_error_sum_on_pair"]*signal if signal else None
            gains = [fine[key] for key in ("geometry_and_polar_gain","squared_field_gain","exterior_axial_gain")]
            budgets.append(dict(ordinary=ordinary,scalar=scalar,clock=index*.02,scalar_magnitude=signal,
                grid_difference=discrepancy,stress_ratio=stress/signal if signal else None,
                same_sign_as_predicted_both=all(entry["predicted_scalar"]*entry["inferred_metric"]>0 for entry in levels),
                within_target=bool(signal and stress<=TOL*signal),
                equal_abs_ruler_halfwidth_if_exact_fields=max(0.,signal-stress)/2 if signal else None,
                fractional_channel_allowance_if_exact_ruler=input_allowance(gains,signal-stress) if signal else None,
                fractional_allowance_at_accuracy_target=input_allowance(gains,TOL*signal-stress) if signal else None))
    return {"focusing-readouts.csv":readings, "focusing-pairs.csv":contrasts, "focusing-budget.csv":budgets}


if __name__ == "__main__":
    for filename, values in findings().items():
        table(filename, values)
