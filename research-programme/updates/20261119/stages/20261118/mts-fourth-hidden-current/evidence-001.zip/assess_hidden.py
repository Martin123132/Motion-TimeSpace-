from hidden_family import HERE,PRE,GRIDS,ARMS,PICKS,TOL,np,json,parent,digest,name,read,table,at,data,relative,family,plan,solve_grid
from hidden_run import magnetic_file,line_file,saved,source,LOCK
from hidden_detector import LATE_B,LATE_G
from scipy.integrate import simpson


def peak(value):return float(np.max(abs(value)))


def compute():
    frozen=json.loads((HERE/"frozen-tests.json").read_text());bank=saved("three-clock-forecasts.npz")
    results=[];outcomes=[];packets=[];checks=[];independent=[];crossings=[];expected=set()
    def chk(tag,err,category="prediction"):
        checks.append(dict(tag=tag,category=category,relative_error=float(err),target=TOL,passes=bool(err<=TOL)))
    direct_grids={};dets=[]
    for label in ("coarse","joint"):
        for spec in json.loads((HERE/f"{label}-detectors.json").read_text())["design"]:
            if spec["weights"] is not None:dets.append((label,spec["which"],np.array(spec["weights"])))
    for dx in GRIDS:
        idx=GRIDS.index(dx);bases=[family(dx,amp) for amp in ARMS]
        scalar_gap=abs(bases[1]["ruler"][-1,0,0]-bases[0]["ruler"][-1,0,0])
        scale=np.linalg.norm(bank["g1a0_basisB"][PICKS],axis=1)
        late_scale=np.linalg.norm(bank["g1a0_basisB"][LATE_B],axis=1)
        partner=dict()
        for amp in ARMS:
            line=bases[amp];key=f"g{idx}a{amp}"
            baseB,baseG=data(dx,amp,"centre");rawB,rawG=data(dx,amp,"hidden")
            predicted_hidden=read(magnetic_file(dx,amp))["fields"][:,0]+bank[key+"_basisB"]@line["direction"][:3]
            cc=read(magnetic_file(dx,amp))["fields"][:,1]
            chk(f"{dx}/{amp}/passive old magnetic basis",relative(cc,bank[key+"_basisB"][:,1]))
            chk(f"{dx}/{amp}/direct compensated field",relative(rawB[:,0],predicted_hidden))
            chk(f"{dx}/{amp}/unseen by three clocks",peak(rawB[PICKS,0]/scale))
            chk(f"{dx}/{amp}/sum magnetic linearity",peak(line["add_field_discrepancy"])/peak(baseB))
            items=[j for j in frozen["tests"] if j["arm"]==amp]
            weights_by_tag={"hidden":line["direction"],"sum":line["centre"]+line["direction"]}
            for item in items:
                tag=item["tag"];parameter=item["t"];testB,testG=data(dx,amp,tag);weights_by_tag[tag]=item["weights"]
                otherB,otherG=data(dx,1-amp,"centre")
                forecastB=at(line["field"],parameter);forecastG=at(line["ruler"],parameter)
                chk(f"{dx}/{amp}/{tag} absolute gravity",relative(forecastG[:,0],testG[:,0]))
                chk(f"{dx}/{amp}/{tag} absolute magnetic",relative(forecastB[:,0],testB[:,0]))
                chk(f"{dx}/{amp}/{tag} gravity prediction on nominal gap",peak(forecastG[:,0]-testG[:,0])/scalar_gap)
                chk(f"{dx}/{amp}/{tag} early fields on measured channel",peak((testB[PICKS,0]-otherB[PICKS,0])/scale))
                for label,which,detector in dets:
                    if which=="field":
                        values=testB[LATE_B,0]/late_scale;base=baseB[LATE_B,0]/late_scale;predicted=forecastB[LATE_B,0]/late_scale
                    else:values=testG[LATE_G,0];base=baseG[LATE_G,0];predicted=forecastG[LATE_G,0]
                    independent.append(dict(dx=dx,arm=amp,tag=tag,design=label,observable=which,
                          measured=float(detector@values),predicted=float(detector@predicted),nominal=float(detector@base),
                          numerical_residual=float(detector@(values-predicted)),change_from_nominal=float(detector@(values-base))))
                if tag=="imitation":
                    chk(f"{dx}/{amp} final imitation on nominal gap",abs(testG[-1,0]-otherG[-1,0])/scalar_gap)
                if tag=="joint":partner[amp]=(testB,testG)
                for tau in (3.,4.,5.,5.5,6.,6.4):
                    atime=round(tau/.02)
                    results.append(dict(dx=dx,arm=amp,tag=tag,t=parameter,tau=tau,actual=testG[atime,0],
                        predicted=forecastG[atime,0],other_nominal=otherG[atime,0],actual_minus_other=testG[atime,0]-otherG[atime,0],
                        normalized_gap=(testG[atime,0]-otherG[atime,0])/scalar_gap,
                        polar_B_actual=testB[atime,0],polar_B_other=otherB[atime,0],polar_B_difference=testB[atime,0]-otherB[atime,0],
                        polar_B_difference_on_channel=(testB[atime,0]-otherB[atime,0])/np.linalg.norm(bank["g1a0_basisB"][atime]),
                        direct_scalar_minus_other=testG[atime,4]-otherG[atime,4]))
                direct_grids[dx,amp,tag]=testG[:,0]-otherG[:,0]
            for tag,weights in weights_by_tag.items():
                fname=name(dx,.8,amp,tag);expected.add(fname);block=read(HERE/fname)
                assert np.array_equal(block["weights"],weights) and str(block["parent"])==LOCK and str(block["protocol"])==digest(HERE/"PROTOCOL.md")
                rows=block["rows"];quality=block["quality"];mass=block["mass"];integrals=block["integrated"];ts=rows[:,0]
                assert rows.shape==(321,16) and np.array_equal(ts,.02*np.arange(321)) and integrals.shape==(321,6)
                assert quality.shape==(33,17) and mass.shape==(33,20)
                assert all(np.isfinite(v).all() for v in (rows,quality,mass,integrals))
                assert np.array_equal(quality[:,0],ts[::10]) and np.array_equal(mass[:,0],ts[::10])
                def add(category,reason,absolute,norm):
                    ratio=absolute/norm if norm else (0. if absolute==0 else np.inf)
                    packets.append(dict(packet=fname,category=category,check=reason,absolute=absolute,reference=norm,
                                        relative_error=ratio,passes=bool(ratio<=TOL)))
                add("physical","initial Green",json.loads(str(block["initial_info"]))["green_relative"],1.)
                add("physical","ruler from metric",peak(rows[:,2]-rows[:,1]),peak(rows[:,1]))
                add("physical","ruler from stress",peak(integrals.sum(axis=1)-rows[:,1]),peak(rows[:,1]))
                times=[150,200,250,300,320]
                trap=[simpson((ts[i]-ts[:i+1])*rows[:i+1,8:14].sum(axis=1),x=ts[:i+1]) for i in times]
                add("physical","independent convolution",peak(np.array(trap)-rows[times,1]),peak(rows[times,1]))
                add("physical","mass gradient",peak(mass[:,1]),peak(mass[:,2]))
                add("physical","mass from metric",peak(mass[:,3]),peak(mass[:,4]))
                for zone,start in (("core",1),("domain",9)):
                    for count,title in enumerate(("radial momentum","angular momentum","radial connection","angular connection")):
                        offset=start+2*count
                        add("auxiliary",zone+" "+title,peak(quality[:,offset]),peak(quality[:,offset+1]))
        if partner:
            assert set(partner)==set(ARMS)
            of,og=partner[0];sf,sg=partner[1];delta=sg-og
            selected=frozen["selected_joint"]
            chk(f"{dx}/joint early fields",peak((sf[PICKS,0]-of[PICKS,0])/scale))
            chk(f"{dx}/joint final ruler",abs(delta[-1,0])/scalar_gap)
            if selected["test"]=="two-rulers":chk(f"{dx}/joint penultimate ruler",abs(delta[300,0])/scalar_gap)
            for tau in (3.,4.,5.,5.5,6.,6.4):
                pos=round(tau/.02)
                outcomes.append(dict(dx=dx,tau=tau,actual_scalar_minus_ordinary=delta[pos,0],ratio_to_nominal=delta[pos,0]/scalar_gap,
                           metric_difference=delta[pos,1],focus_difference=delta[pos,2:].sum(),B_difference=sf[pos,0]-of[pos,0]))
        roots,shared,known=solve_grid(dx)
        for row in shared:
            crossings.append(dict(dx=dx,kind=row["test"],o=row["ordinary_t"],s=row["scalar_t"],largest_cost=row["maximum_cost_ratio"]))
    assert {p.name for p in HERE.glob("source-*.npz")}==expected
    scale=abs(bases[1]["ruler"][-1,0,0]-bases[0]["ruler"][-1,0,0])
    for item in frozen["tests"]:
        arm=item["arm"];tag=item["tag"];chk(f"two-grid/{arm}/{tag}/difference on nominal gap",
            peak(direct_grids[.025,arm,tag]-direct_grids[.0125,arm,tag])/scale)
    return {"source-checks.csv":checks,"packet-checks.csv":packets,"candidate-clock-results.csv":results,
            "joint-clock-results.csv":outcomes,"independent-detector-results.csv":independent}


if __name__=="__main__":
    for member,rows in compute().items():
        if rows:table(member,rows)
