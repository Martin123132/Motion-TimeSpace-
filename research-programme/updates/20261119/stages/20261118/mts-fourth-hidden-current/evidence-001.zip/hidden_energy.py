from fractions import Fraction
from functools import lru_cache
from math import comb
from hidden_run import np,source,original
from source_energy import compose,convolve,exact_gram
from scipy.special import roots_legendre,betainc


@lru_cache(maxsize=1)
def exact():
    density=[Fraction(0)]*13;number=[Fraction(0)]*16
    for index in range(7):
        coefficient=(-1)**index*comb(6,index)
        density[2*index]=Fraction(coefficient)
        number[3+2*index]=Fraction(coefficient,3+2*index)
    central=Fraction(1,500)/(125*sum(number))
    normalized=np.array(number,dtype=object)/sum(number)
    primitive=[0,0,0,Fraction(32,3),-32,32,Fraction(-32,3)]
    profiles=[]
    for mode in range(4):
        profiles.append(compose([(j+1)*v for j,v in enumerate(primitive[1:])],normalized))
        primitive=convolve(primitive,[-1,2])
    matrix=[]
    for left in profiles:
        row=[]
        for right in profiles:
            kernel=convolve(density,convolve(left,right))
            row.append(5*central/3*sum(Fraction(val,k+1) for k,val in enumerate(kernel)))
        matrix.append(row)
    assert [row[:3] for row in matrix[:3]]==exact_gram()
    return matrix


def gram():
    return np.array(exact(),dtype=float)


def quadrature(order):
    nodes,weights=roots_legendre(order);radius=2.5*(nodes+1)
    number=original.MASS*betainc(1.5,7,(radius/5)**2)
    density=.000703828125*(1-(radius/5)**2)**6
    velocity=np.array([source(number,direction)[0] for direction in np.eye(4)])
    return np.einsum("ir,jr,r->ij",velocity,velocity,2.5*weights*density/3)


def invariant_checks():
    import sympy as sp
    import math
    frac=sp.symbols("fraction")
    for power in range(4):
        core=sp.Rational(32,3)*frac**3*(1-frac)**3
        primitive=core*(2*frac-1)**power
        slope=32*frac**2*(1-frac)**2*(1-2*frac)*(2*frac-1)**power
        if power:slope+=2*power*core*(2*frac-1)**(power-1)
        assert sp.expand(primitive.diff(frac)-slope)==0
        assert primitive.subs(frac,1)==primitive.subs(frac,0)==0
        assert slope.subs(frac,1)==slope.subs(frac,0)==0
    matrix=gram()
    assert np.linalg.eigvalsh(matrix)[0]>0
    return {str(order):float(np.max(abs(quadrature(order)-matrix))/np.max(abs(matrix))) for order in (128,160)}

