from itertools import combinations
from scipy.optimize import linprog
from free_fall import TIMES, METHODS, TOL, GRIDS, np, table, evaluate, packet


def design(xdata, radius0):
    red=radius0*xdata
    scaled=xdata/max(xdata)
    return np.column_stack((np.ones(len(red)),scaled,scaled**2*(4+3*red)/(1+red)**2))


def weight(matrix):
    minor=np.array([(-1.)**pos*np.linalg.det(np.delete(matrix,pos,0)) for pos in range(4)])
    minor/=sum(abs(minor))
    if minor[0]<0:minor=-minor
    assert np.max(abs(minor@matrix))<1e-13 and np.all(minor!=0)
    return minor


def measure(xdata, ydata, radius0):
    matrix=design(xdata,radius0)
    shift=ydata[0];scale=float(np.ptp(ydata)) or 1.
    values=(ydata-shift)/scale
    options=[]
    for indices in combinations(range(len(values)),4):
        positions=list(indices);coeff=weight(matrix[positions])
        value=(coeff@(values[positions]-values[positions[0]]))*scale
        options.append((abs(value),indices,value))
    dist,indices,signed=max(options,key=lambda item:item[0])
    limits=np.column_stack((np.vstack((matrix,-matrix)),-np.ones(2*len(values))))
    opt=linprog([0.,0.,0.,1.],A_ub=limits,b_ub=np.r_[values,-values],bounds=[(None,None)]*3+[(0.,None)],
                method="highs-ds",options={"threads":1,"primal_feasibility_tolerance":1e-10,"dual_feasibility_tolerance":1e-10})
    assert opt.success and abs(opt.fun-dist/scale)<3e-9 and abs(max(abs(matrix@opt.x[:3]-values))-opt.fun)<3e-9
    trained=np.linalg.solve(matrix[:3],values[:3])
    return dist,indices,signed,opt.fun*scale,(values-matrix@trained)*scale


def results(existing=None):
    if existing is None:existing=evaluate()
    example=np.linspace(.01,.04,6)
    known=design(example,6.)@np.array([4.,-2.,.3])
    assert measure(example,known,6.)[0]<5e-15
    assert measure(example,known+np.array([0.,0.,0.,.015,0.,0.]),6.)[0]>.001
    scores=[];holdouts=[];sets={}
    for dx in GRIDS:
        for arm in (0,1):
            radius0=packet(dx,arm,"centre")["rows"][0,6]
            for method in METHODS:
                sample=[entry for entry in existing["free-fall-readings.csv"] if (entry["dx"],entry["arm"],entry["method"])==(dx,arm,method)]
                assert tuple(row["tau"] for row in sample)==TIMES
                coords=np.array([entry["x"] for entry in sample]);values=np.array([entry["Y"] for entry in sample])
                dist,indices,signed,opt,errors=measure(coords,values,radius0)
                sets[dx,arm,method]=design(coords,radius0),values,indices
                scores.append(dict(dx=dx,arm=arm,method=method,minimax_distance=dist,witness=";".join(str(TIMES[i]) for i in indices),
                             signed_certificate=signed,lp_distance=opt,relative_to_ordinate=dist/max(abs(values))))
                for pos in range(3,6):holdouts.append(dict(dx=dx,arm=arm,method=method,clock=TIMES[pos],observed=values[pos],
                            prediction_from_first_three=values[pos]-errors[pos],signed_difference=errors[pos]))
    fine=min(GRIDS)
    indices=list(sets[fine,1,"radius7"][2])
    def same(dx,arm,method):
        matrix,values,unused=sets[dx,arm,method]
        return weight(matrix[indices])@(values[indices]-values[indices[0]])
    ref=same(fine,1,"radius7")
    worst_diff=max(abs(same(fine,1,method)-ref) for method in METHODS)
    grid=abs(same(max(GRIDS),1,"radius7")-ref)
    ordinary=max(abs(same(dx,0,method)) for dx in GRIDS for method in METHODS)
    total=grid+ordinary+worst_diff
    robustness=[dict(witness=";".join(str(TIMES[i]) for i in indices),fine_scalar_certificate=ref,ordinary_floor=ordinary,
                     derivative_change=worst_diff,grid_change=grid,numerical_stress_ratio=total/abs(ref),
                     resolved_on_tested_controls=bool(total<abs(ref)),within_accuracy=bool(total<=TOL*abs(ref)),
                     remaining_equal_Y_halfwidth=max(0.,abs(ref)-total))]
    return {"constant-vacuum-distance.csv":scores,"constant-vacuum-holdouts.csv":holdouts,"constant-vacuum-stress.csv":robustness}


if __name__=="__main__":
    for filename,values in results().items():
        table(filename,values)
