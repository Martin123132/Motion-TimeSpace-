import sys
import json
import csv
from pathlib import Path
from types import FunctionType
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-three-current-magnetic-test-20261118"
LOCK="ef256ddddcdb05040090a9e502e147f858052380b75bf9ec128b9d0212545219"
sys.path.insert(0,str(PRE))
import stage as parent
from stage import np, GRIDS, ARMS, PICKS, VREF, TOL, name, digest, read, original


def hold():
    parent.ensure()
    if (HERE/"STOP-REQUESTED").exists():raise SystemExit("owner hold")


def checkpoint():
    hold();assert digest(PRE/"closeout.json")==LOCK
    return json.loads((PRE/"closeout.json").read_text())["files"]


def saved(path):
    assert digest(PRE/path)==checkpoint()[path],path
    return read(PRE/path)


def source(label,weights):
    if len(weights)!=4:raise ValueError("four weights required")
    first,second,third,fourth=weights
    frac=np.clip(label/original.MASS,0.,1.);variable=2*frac-1
    primitive=(32/3)*frac**3*(1-frac)**3;slope=32*frac**2*(1-frac)**2*(1-2*frac)
    poly=first+second*variable+third*variable**2+fourth*variable**3
    return slope*poly+2*primitive*(second+2*third*variable+3*fourth*variable**2),original.MASS*primitive*poly


def fast_hold():
    original.hold()
    if any((place/"STOP-REQUESTED").exists() for place in (HERE,PRE,parent.PRE,HERE.parent)):raise SystemExit("owner hold")


def table(member,rows):
    with (HERE/member).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def store_packet(path,**values):
    temp=path.with_suffix(".partial")
    if path.exists() or temp.exists():raise FileExistsError(path)
    with temp.open("xb") as stream:np.savez_compressed(stream,**values)
    temp.rename(path)


def magnetic_file(dx,arm):return HERE/f"magnetic-only-d{dx:g}-A{arm}.npz"


def magnetic(dx,arm):
    path=magnetic_file(dx,arm);checkpoint()
    if path.exists():return
    if path.with_suffix(".partial").exists():raise FileExistsError(path)
    model=original.Centre(dx,.8,arm,cap=12,reduced=True,damping=.5,mass_form=True)
    model.profile=(0.,0.,0.,1.)
    with patch.object(original.smooth_launch,"spin",source):
        original.smooth_launch.refresh(model,.8,arm,False,model.profile)
    state=model.y0.copy();series=[];steps=int(np.ceil(.02/(.30*dx)-1e-12));dt=.02/steps
    from scipy.ndimage import correlate1d
    stencil=np.array([1,-8,28,-56,70,-56,28,-8,1])/256
    def passive(state,wave):
        ghost=model.ghost;ext=model.extend(state)
        extended=np.concatenate((wave[:,:ghost][:,::-1],wave),axis=1)
        potential,momentum=extended
        metric=np.sqrt(1+ext[0].real[:,:1]);radius=model.x*np.sqrt(1+ext[2].real[:,:1])
        label=ext[18].real[:,:1];charge=.8*label
        ell,primitive=original.law(abs(label),(0.,1.,0.));primitive*=np.sign(label)
        slope=model.dr(potential)
        lap=correlate1d(potential,original.regular.AXIAL_SECOND,axis=0,mode="nearest")/(model.dx**2*metric)-slope*model.dr(metric)/metric**2
        twist=4*metric*(charge*potential-primitive)/radius**4;lor=np.hypot(1,ext[14].real[:,:1]/metric)
        rates=np.stack((momentum/metric,lap-2*metric*potential/radius**2+.8*ext[13].real[:,:1]*(ell-.8*potential)/(lor*radius**2)-charge*twist))
        rates=((rates-model.damping/model.dx*correlate1d(extended,stencil,axis=1,mode="nearest"))*model.mask)[:,ghost:].copy()
        rates[:,:model.cap.count]=model.cap.mat[2]@rates[:,:model.cap.count]
        return rates
    wave=np.zeros((2,len(model.rad),1))
    with patch.object(original.signed_equations,"spin",source):
        for index in range(321):
            fast_hold()
            radius=model.rad*np.sqrt(1+state[2].real[:,:1])
            series.append([model.atsite((2*potential/radius**2)[:,0]) for potential in (state[19].real[:,:1],wave[0])])
            if index==320:break
            for _ in range(steps):
                one=model.rhs(state);p1=passive(state,wave)
                lev=state+.5*dt*one;two=model.rhs(lev);p2=passive(lev,wave+.5*dt*p1)
                lev=state+.5*dt*two;three=model.rhs(lev);p3=passive(lev,wave+.5*dt*p2)
                lev=state+dt*three;four=model.rhs(lev);p4=passive(lev,wave+dt*p3)
                state+=dt/6*(one+2*two+2*three+four);wave+=dt/6*(p1+2*p2+2*p3+p4)
    assert np.isfinite(series).all()
    store_packet(path,fields=series,dx=dx,arm=arm,clock=np.arange(321)*.02,protocol=digest(HERE/"PROTOCOL.md"),parent=LOCK)
    print("magnetic only",path.name,flush=True)


def line_file(arm):return HERE/f"fixed-null-line-A{arm}.npz"


def projection(arm):
    path=line_file(arm);pack=saved("three-clock-forecasts.npz");fine=GRIDS[1];key=f"g1a{arm}"
    field=read(magnetic_file(fine,arm))["fields"];basis=pack[key+"_basisB"]
    normalized=lambda value:float(np.max(abs(value))/np.max(abs(basis[:,1])))
    check=normalized(field[:,1]-basis[:,1]);assert check<TOL
    hidden=np.r_[np.linalg.solve(basis[PICKS],-field[PICKS,0]),1.]
    centre=np.r_[pack[key+"_v"],0.]
    residual=basis@hidden[:3]+field[:,0]
    assert np.max(abs(residual[PICKS])/np.linalg.norm(basis[PICKS],axis=1))<1e-12
    return dict(hidden=hidden,centre=centre,hidden_B=residual,second_control=check,
                magnetic=digest(magnetic_file(fine,arm)),upstream=digest(PRE/"three-clock-forecasts.npz"),parent=LOCK)


def trajectory(dx,arm,tag,weights):
    path=HERE/name(dx,.8,arm,tag)
    if path.exists():
        receipt=read(path)
        assert np.array_equal(receipt["weights"],weights) and str(receipt["parent"])==LOCK and str(receipt["protocol"])==digest(HERE/"PROTOCOL.md")
        return
    ctx=dict(original.run.__globals__,LOCAL=HERE,WEIGHTS={tag:tuple(weights)},law=source,LOCK=LOCK,hold=fast_hold)
    FunctionType(original.run.__code__,ctx)(dx,.8,arm,tag)


def prepare(arm):
    checkpoint();magnetic(GRIDS[1],arm)
    info=projection(arm);line=line_file(arm)
    if not line.exists():
        assert not any(HERE.glob(f"source-*-eta0.8-h{arm}.npz"))
        store_packet(line,**info)
    else:
        old=read(line);assert all(np.array_equal(old[k],v) for k,v in info.items())
    for dx in (GRIDS[1],GRIDS[0]):
        if dx!=GRIDS[1]:magnetic(dx,arm)
        for tag,v in (("hidden",info["hidden"]),("sum",info["centre"]+info["hidden"])):
            trajectory(dx,arm,tag,v)


def test(arm):
    checkpoint()
    plan=json.loads((HERE/"frozen-tests.json").read_text())
    assert plan["protocol"]==digest(HERE/"PROTOCOL.md") and plan["inputs"]==input_hashes()
    for dx in (GRIDS[1],GRIDS[0]):
        for item in plan["tests"]:
            if item["arm"]==arm:trajectory(dx,arm,item["tag"],np.array(item["weights"]))


def input_hashes():
    paths=[line_file(arm) for arm in ARMS]+[magnetic_file(dx,arm) for dx in GRIDS for arm in ARMS]
    paths.extend(HERE/name(dx,.8,arm,tag) for dx in GRIDS for arm in ARMS for tag in ("hidden","sum"))
    return {path.name:digest(path) for path in paths}


if __name__=="__main__":
    arm=int(sys.argv[1]);assert arm in ARMS
    {"prepare":prepare,"test":test}[sys.argv[2]](arm)
