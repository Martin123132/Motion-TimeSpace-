from hidden_family import HERE,PRE,GRIDS,ARMS,PICKS,TOL,np,parent,json,digest,read,plan,solve_grid,table,real_one,common_roots
from hidden_run import LOCK,saved,checkpoint,line_file,magnetic_file,projection,name,source,original
from hidden_energy import invariant_checks,gram
from hidden_detector import design,scores
from assess_hidden import compute
from witness_checks import evaluate
from focusing_witness import findings
from free_fall import evaluate as free_fall
from vacuum_stress_control import results as vacuum_stress
from range_precision import results as range_precision
from clock_source import results as clock_source
from weak_limit import derive,forecast_file,packet_file,ticket,SMALL,calibrate,stats
from launch_measurement import calculate as launch_precision
import csv
import sys


def validate():
    checkpoint()
    frozen=json.loads((HERE/"frozen-tests.json").read_text());assert frozen==plan()
    tests=compute();packet_checks=tests["packet-checks.csv"];prediction=tests["source-checks.csv"]
    for arm in ARMS:
        line=read(line_file(arm));assert all(np.array_equal(line[k],val) for k,val in projection(arm).items())
        for dx in GRIDS:
            pp=read(magnetic_file(dx,arm));assert pp["fields"].shape==(321,2) and np.array_equal(pp["clock"],np.arange(321)*.02)
            assert str(pp["protocol"])==digest(HERE/"PROTOCOL.md") and str(pp["parent"])==LOCK
    allroots=[[],[],[]]
    for dx in GRIDS:
        for buf,rows in zip(allroots,solve_grid(dx)):buf.extend(rows)
    for target,rows in zip(("nominal-imitation-roots.csv","joint-intersections.csv","specified-cost-solutions.csv"),allroots):tests[target]=rows
    for label in ("coarse","joint"):
        spec=json.loads((HERE/f"{label}-detectors.json").read_text())
        assert spec["protocol"]==digest(HERE/"WITHHELD-PROTOCOL.md")
        for entry in spec["design"]:
            recomputed=design(entry["which"],tuple(entry["grids"]));recomputed["grids"]=list(recomputed["grids"])
            assert recomputed==entry
    tests["detector-budgets.csv"]=scores()
    tests["direct-detector-gaps.csv"],tests["detector-stress-test.csv"]=evaluate()
    tests.update(findings())
    fall=free_fall();vacuum=vacuum_stress(fall);tests.update(fall);tests.update(vacuum);tests.update(range_precision(fall,vacuum))
    tests.update(clock_source(fall,vacuum))
    tests["launch-measurement-tolerances.csv"],accounting=launch_precision()
    assert accounting==json.loads((HERE/"launch-accounting.json").read_text())
    forecast=read(forecast_file());assert all(np.array_equal(forecast[key],value) for key,value in derive().items())
    tests["near-ordinary-limit.csv"]=stats()
    for amp in SMALL:
        assert calibrate(amp)==json.loads(ticket(amp).read_text())
        for tag,size,count in (("magnetic",251,1),("matched",321,9)):
            packet=read(packet_file(amp,tag))
            assert packet["rows"].shape==(size,count) and np.isfinite(packet["rows"]).all()
            assert np.array_equal(packet["clock"],np.arange(size)*.02) and str(packet["forecast"])==digest(forecast_file())
            if tag=="matched":assert str(packet["authorization"])==digest(ticket(amp))
    checked=0
    for member,rows in tests.items():
        if not rows:assert not (HERE/member).exists();continue
        with (HERE/member).open(newline="",encoding="utf8") as stream:old=list(csv.DictReader(stream))
        assert len(rows)==len(old),member
        for output,truth in zip(old,rows):
            assert set(output)==set(truth)
            for key,value in truth.items():assert output[key]==("" if value is None else str(value)),(member,key,output[key],value)
        checked+=len(rows)
    assert real_one([0.,0.,1.],-1.)==[] and real_one([0.,0.,1.],0.)==[0.]
    assert real_one([1.,2.,0.],4.)==[1.5]
    simple=common_roots([0.,1.,0.],[0.,1.,0.],[0.,0.,1.],[1.,0.,0.])
    assert sorted((x,y) for x,y,lo,hi in simple)==[(-1.,-1.),(1.,1.)]
    integrals=invariant_checks();assert max(integrals.values())<1e-12
    assert not list(HERE.glob("*.partial")) and not (HERE/"__pycache__").exists()
    parents={}
    def keep(path):parents[str(path.relative_to(HERE.parent))]=digest(path)
    for path in (PRE/"closeout.json",PRE/"three-clock-forecasts.npz",PRE/"stage.py",parent.OLDER/"closeout.json",
                 parent.OLDER/"mixed_current.py",parent.OLDER/"source_energy.py",parent.PRE/"closeout.json",parent.PRE/"finite.py"):keep(path)
    for dx in GRIDS:
        keep(PRE/name(dx,.8,1,"matched3"));keep(parent.OLDER/name(dx,.8,0,"minus"))
        keep(parent.PRE/f"tangent-minus-d{dx:g}-to6.4.npz")
    for amp in SMALL:keep(parent.PRE/f"finite-fixed-d0.0125-A{amp:g}.npz")
    ancestor_record=original.receipt()
    keep(original.BASE/"closeout.json")
    for member in ("WHY-NEWTON-APPEARS.md","regular.py","signed_equations.py","exposure.py","mass_flux.py"):
        path=original.BASE/member
        assert digest(path)==ancestor_record["files"][member],member
        keep(path)
    groups={}
    for label,rows in (("source_tests",prediction),("physical",[r for r in packet_checks if r["category"]=="physical"]),
                       ("auxiliary",[r for r in packet_checks if r["category"]=="auxiliary"])):
        groups[label]=dict(total=len(rows),passed=sum(bool(r["passes"]) for r in rows))
    files={p.name:digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.name not in ("closeout.json","STOP-REQUESTED")}
    return dict(parent=LOCK,files=files,protected_inputs=parents,comparisons=groups,rows_recomputed=checked,cost_checks=integrals,
                coupled_source_packets=len(list(HERE.glob("source-*.npz"))),magnetic_only=4,intermediate_runs=4,
                scope="one measured-field triple in retained four-current subspace, finite prepared burst",target=TOL)


if __name__=="__main__":
    record=validate();path=HERE/"closeout.json"
    if sys.argv[1:]==["seal"]:
        with path.open("x") as stream:json.dump(record,stream,sort_keys=True,indent=2,allow_nan=False)
    else:assert json.loads(path.read_text())==record
    print("verified",len(record["files"]),"files",record["comparisons"],record["rows_recomputed"],"scored rows",digest(path))
