from hidden_run import HERE,PRE,LOCK,PICKS,TOL,GRIDS,ARMS,np,json,parent,digest,name,read,checkpoint,line_file,input_hashes,table
from hidden_energy import gram
from functools import lru_cache
import sympy as sp


def data(dx,arm,tag):
    if tag=="centre":
        if arm:
            path=PRE/name(dx,.8,1,"matched3");assert digest(path)==checkpoint()[path.name];block=read(path)
        else:block=parent.old(name(dx,.8,0,"minus"))
    else:
        block=read(HERE/name(dx,.8,arm,tag))
        assert str(block["parent"])==LOCK and str(block["protocol"])==digest(HERE/"PROTOCOL.md")
    rows=block["rows"];assert np.array_equal(rows[:,0],.02*np.arange(321))
    return rows[:,3:6],np.column_stack((rows[:,1:3],block["integrated"]))


@lru_cache(maxsize=8)
def family(dx,arm):
    line=read(line_file(arm));centre=line["centre"];direction=line["hidden"];matrix=gram()
    basefield,base=data(dx,arm,"centre");hiddenfield,hidden=data(dx,arm,"hidden");bothfield,both=data(dx,arm,"sum")
    return dict(field=np.stack((basefield,hiddenfield),axis=-1),
                ruler=np.stack((base,both-base-hidden,hidden),axis=-1),
                cost=np.array([centre@matrix@centre,2*centre@matrix@direction,direction@matrix@direction]),
                centre=centre,direction=direction,add_field_discrepancy=bothfield-basefield-hiddenfield)


def at(coeff,t):
    return np.polynomial.polynomial.polyval(t,np.moveaxis(coeff,-1,0))


def relative(first,reference):
    first=np.asarray(first);reference=np.asarray(reference)
    scale=np.max(abs(reference))
    return float(np.max(abs(first-reference))/scale if scale else (0. if not np.any(first) else np.inf))


def root_intervals(polynomial):
    variable=polynomial.gens[0]
    if polynomial.is_zero:raise ArithmeticError("constraint is identically zero")
    return [(float((lo+hi)/2),int(mul),str(lo),str(hi)) for (lo,hi),mul in polynomial.intervals(eps=sp.Rational(1,10**22))]


def coeffs(values):
    return [sp.Rational(float(value)) for value in values]


def real_one(parabola,desired):
    variable=sp.symbols("a")
    coeff=coeffs(parabola)
    eq=sp.Poly(coeff[0]-sp.Rational(float(desired))+coeff[1]*variable+coeff[2]*variable**2,variable)
    return [r[0] for r in root_intervals(eq)]


def common_roots(first,second,other_first,other_second):
    variable=sp.symbols("a")
    ordinary=coeffs(first);scalar=coeffs(second);additional=coeffs(other_first);other=coeffs(other_second)
    def expr(co):return co[0]+co[1]*variable+co[2]*variable**2
    g=expr(ordinary)-scalar[0];w=expr(additional)-other[0]
    denom=other[2]*scalar[1]-scalar[2]*other[1]
    numerator=other[2]*g-scalar[2]*w
    if scalar[2]==other[2]==0:
        if scalar[1]==other[1]==0:raise ArithmeticError("both constraints independent of scalar amplitude")
        relation=sp.Poly(scalar[1]*w-other[1]*g,variable)
        yexpr=g/scalar[1] if scalar[1]!=0 else w/other[1]
        return [(x,float(yexpr.subs(variable,(sp.Rational(lo)+sp.Rational(hi))/2)),lo,hi)
                for x,_,lo,hi in root_intervals(relation)]
    if denom==0:
        if sp.expand(numerator)==0:raise ArithmeticError("dependent conics; common family, not isolated roots")
        result=[]
        for x,_,lo,hi in root_intervals(sp.Poly(numerator,variable)):
            for y in real_one(second,at(first,x)):
                if abs(at(other_second,y)-at(other_first,x))<1e-10*max(1,abs(at(other_first,x))):
                    result.append((x,y,lo,hi))
        return result
    resultant=sp.Poly(sp.expand(g*denom**2-scalar[1]*numerator*denom-scalar[2]*numerator**2),variable)
    result=[]
    for x,_,lo,hi in root_intervals(resultant):
        midpoint=(sp.Rational(lo)+sp.Rational(hi))/2
        y=float(numerator.subs(variable,midpoint)/denom)
        for a,b in ((first,second),(other_first,other_second)):
            scale=max(1e-280,abs(at(a,x)),abs(at(b,y)),np.max(abs(a)),np.max(abs(b)))
            assert abs(at(a,x)-at(b,y))/scale<5e-11
        result.append((x,y,lo,hi))
    return result


def solve_grid(dx):
    arms=[family(dx,a) for a in ARMS];normal=arms[0]["cost"][0];single=[];shared=[];known=[]
    for arm,line in enumerate(arms):
        opp=arms[1-arm];target=opp["ruler"][-1,0,0]
        for t in real_one(line["ruler"][-1,0],target):
            single.append(dict(dx=dx,arm=arm,t=t,cost_ratio=at(line["cost"],t)/normal,
                own_nominal_ratio=at(line["cost"],t)/line["cost"][0],weights=(line["centre"]+t*line["direction"]).tolist(),
                withheld_gravity_6=at(line["ruler"][300,0],t)-opp["ruler"][300,0,0],
                withheld_B_6_4=at(line["field"][-1,0],t)-opp["field"][-1,0,0],
                matched_error=at(line["ruler"][-1,0],t)-target))
    fixed=[real_one(line["cost"],normal) for line in arms]
    for t in fixed[0]:
        for s in fixed[1]:
            known.append(dict(dx=dx,ordinary_t=t,scalar_t=s,cost_ratio=1.,final_ruler_gap=at(arms[1]["ruler"][-1,0],s)-at(arms[0]["ruler"][-1,0],t)))
    for mode in ("shared-energy","two-rulers"):
        left,right=arms
        aux_o=left["cost"] if mode=="shared-energy" else left["ruler"][300,0]
        aux_s=right["cost"] if mode=="shared-energy" else right["ruler"][300,0]
        for t,s,lo,hi in common_roots(left["ruler"][-1,0],right["ruler"][-1,0],aux_o,aux_s):
            ec=at(left["cost"],t)/normal;es=at(right["cost"],s)/normal
            shared.append(dict(dx=dx,test=mode,ordinary_t=t,scalar_t=s,ordinary_cost_ratio=ec,scalar_cost_ratio=es,
                   maximum_cost_ratio=max(ec,es),isolating_left=lo,isolating_right=hi,
                   withheld_B_6_4=at(right["field"][-1,0],s)-at(left["field"][-1,0],t),
                   gravity_gap_6=at(right["ruler"][300,0],s)-at(left["ruler"][300,0],t),
                   gravity_gap_6_4=at(right["ruler"][-1,0],s)-at(left["ruler"][-1,0],t)))
    return single,shared,known


def plan():
    dx=.0125;single,shared,fixed=solve_grid(dx);jobs=[]
    for arm in ARMS:
        pick=min((row for row in single if row["arm"]==arm),key=lambda row:row["cost_ratio"],default=None)
        if pick is not None and pick["cost_ratio"]<=10.:
            jobs.append(dict(arm=arm,tag="imitation",t=pick["t"],weights=pick["weights"],purpose="least-cost nominal imitation"))
        else:
            line=family(dx,arm);coeff=line["ruler"][-1,0];t=-coeff[1]/(2*coeff[2]) if coeff[2]!=0 else -.25
            purpose="nearest quadratic extremum" if pick is None else "bounded direct control"
            if pick is not None or at(line["cost"],t)>10*family(dx,0)["cost"][0]:
                t=-.25;purpose="bounded direct control"
            jobs.append(dict(arm=arm,tag="control",t=float(t),weights=(line["centre"]+t*line["direction"]).tolist(),purpose=purpose))
    picked=None
    for mode in ("shared-energy","two-rulers"):
        candidates=[row for row in shared if row["test"]==mode and row["maximum_cost_ratio"]<=10.]
        if candidates:
            picked=min(candidates,key=lambda row:row["maximum_cost_ratio"]);break
    if picked:
        for arm,key in enumerate(("ordinary_t","scalar_t")):
            line=family(dx,arm);t=picked[key]
            jobs.append(dict(arm=arm,tag="joint",t=t,weights=(line["centre"]+t*line["direction"]).tolist(),purpose=picked["test"]))
    return dict(parent=LOCK,protocol=digest(HERE/"PROTOCOL.md"),later=digest(HERE/"WITHHELD-PROTOCOL.md"),
                tests=jobs,selected_joint=picked,inputs=input_hashes(),reference_cost=family(dx,0)["cost"][0])


def freeze():
    target=HERE/"frozen-tests.json"
    if target.exists() or any(HERE.glob("source-imitation-*")) or any(HERE.glob("source-joint-*")):raise RuntimeError("freeze out of sequence")
    allrows=[[],[],[]]
    for dx in GRIDS:
        for buf,rows in zip(allrows,solve_grid(dx)):buf.extend(rows)
    for member,rows in zip(("nominal-imitation-roots.csv","joint-intersections.csv","specified-cost-solutions.csv"),allrows):
        if rows:table(member,rows)
    document=plan()
    with target.open("x") as stream:json.dump(document,stream,indent=2,allow_nan=False)
    print("frozen",digest(target),[(x["arm"],x["purpose"],x["t"]) for x in document["tests"]],flush=True)


if __name__=="__main__":freeze()
