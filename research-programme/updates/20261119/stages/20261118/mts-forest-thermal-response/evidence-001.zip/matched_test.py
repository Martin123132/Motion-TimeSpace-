from angular import moments
from direct import direct
from compare import *

def freeze_match():
    locked();ledger=[]
    for arm in ("wave","off"):
        k,jet,h=load_jets(arm,"1200");index=np.flatnonzero(k>25.)[0];node=k[index]
        def aim(temp):
            delta=temp/TREF-1
            fields=jet[6]@np.array([1.,delta,delta**2,delta**3])
            return project(k,fields,h[6],6,1+delta)[0][index]
        temp=brentq(aim,9000.,11000.)
        ledger.append(dict(arm=arm,k=node,index=int(index),temp=temp,lower=temp-.1,upper=temp+.1,frozen_R=aim(temp)))
    assert ledger[0]["k"]==ledger[1]["k"]
    dump("matched-null-freeze.json",dict(choices=ledger,forecast=digest(ROOT/"forecast-lock.json"),purpose="Choose temperatures from the cubic dynamics for the same existing k; enumerate predictions on this basis only. No observed targets. Test +/-0.1 K signs and do not re-tune."))
    print(ledger,flush=True)

def one_mode(source,indices):
    return dict(source,k=source["k"][indices],init=source["init"][indices],external=source["external"][indices])

def evaluate():
    locked();design=js("matched-null-freeze.json");checks=[];observables=[]
    for row in design["choices"]:
        arm=row["arm"];k,jet,h=load_jets(arm,"1200");node=row["k"];pos=row["index"]
        assert k[pos]==node
        output=[]
        for panel in ("fine","wide"):
            src=data(panel,arm,"1200","source")
            full=direct(src,arm,row["temp"],2048,1)
            output.append(dict(k=src["k"],fields=full))
            where=np.flatnonzero(src["k"]==node)
            if not len(where):continue
            just=one_mode(src,where)
            bracket=[]
            for temp in (row["lower"],row["temp"],row["upper"]):
                single=direct(just,arm,temp,2048,1)
                impulse,_,_=project(just["k"],single[-1],h[-1],6,temp/TREF)
                bracket.append(float(impulse[0]))
            checks.append(dict(arm=arm,k=node,temp=row["temp"],lower_R=bracket[0],center_R=bracket[1],upper_R=bracket[2],straddles=bracket[0]*bracket[2]<0))
        fields=combined(output,"fields")
        save(f"matched-temperature-{arm}.npz",k=k,fields=fields,temp=row["temp"])
        for zi in FOUR:
            signed,w,_=project(k,fields[zi],h[zi],zi,row["temp"]/TREF)
            rr=rootinfo(k,signed,zi)
            obs=dict(arm=arm,temp=row["temp"],z=Z[zi],k=node,R_at_k=signed[pos],normalized_R_at_k=signed[pos]/np.max(abs(signed[k>=RADS[zi]])),
                power=integral(k,w*signed**2,zi),root=rr["root"] if rr else None,J=None,curvature=None)
            if zi==6:
                angular=moments(k,fields[zi],h[zi],row["temp"]/TREF,10);obs.update(J=angular["J"],curvature=angular["curvature"])
            observables.append(obs)
    table("matched-sign-checks.csv",checks);table("matched-observables.csv",observables)
    print(checks,[r for r in observables if r["z"]==4.2],flush=True)
if __name__=="__main__":
    if sys.argv[1]=="freeze":freeze_match()
    elif sys.argv[1]=="test":evaluate()
    else:raise ValueError(sys.argv[1])

