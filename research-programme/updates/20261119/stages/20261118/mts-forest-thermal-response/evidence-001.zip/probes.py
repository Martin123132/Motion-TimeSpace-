from spectrum import *

def run(action,case,tag="1200"):
    locked()
    assert not any(key in os.environ for key in ("MTS_FOREST_INDEX","MTS_FOREST_FACTOR","MTS_FOREST_SCALE"))
    design=js("design.json")
    selected=[r for r in design["radii"] if (r["arm"]=="cold")==(case=="cold")]
    nodes=np.sort([value for row in selected for value in [*row["flanks"],row["center"]]])
    assert np.min(np.diff(nodes))>0 and not set(nodes).intersection(load_jets("wave","1200")[0])
    sys.path.insert(0,str(PARENT))
    import session
    session.K=nodes
    def local_save(name,**vals):save("probe-"+name,**vals)
    def local_load(name):return archive("probe-"+name)
    if action=="seed":
        assert case=="heavy"
        import wide
        wide.save=local_save
        wide.seeds("fine")
    elif action=="bridge":
        import bridge
        bridge.save=local_save;bridge.load=local_load
        bridge.run("fine")
    else:
        assert action=="source"
        if case=="heavy":
            br=local_load("bridge-fine.npz")
            assert np.array_equal(br["k"],nodes) and np.all(abs(br["defect"])<np.array([2e-5,2e-5,2e-6]))
        import transfer
        native=session.engine()
        session.use_mesh(native,"fine",tag if case=="heavy" else "none")
        transfer.native=lambda kind:native
        transfer.modes=lambda panel:nodes
        transfer.save=local_save;transfer.load=local_load
        transfer.run("fine",case,tag,"full")
if __name__=="__main__":run(*sys.argv[1:])

