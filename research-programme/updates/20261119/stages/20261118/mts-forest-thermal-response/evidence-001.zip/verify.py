from spectrum import *
import ast

def check(seal):
    locked();checks=[]
    def require(label,test):
        if not test:raise AssertionError(label)
        checks.append(label)
    for p in ROOT.glob("*.py"):ast.parse(read(p))
    pinned={str(PARENT/"closeout.json"):LOCK}
    parent=js(PARENT/"closeout.json")
    for path in (PARENT/"session.py",PARENT/"wide.py",PARENT/"bridge.py",PARENT/"carrier-fine.npz",PARENT/"engine/native/camb/cambdll.dll",PARENT/"full-grid-bands.csv"):
        pinned[str(path)]=parent["files"][path.relative_to(PARENT).as_posix()]
    for name in parent["files"]:
        if name.endswith(".npz") and name.startswith(("gas-fine-","gas-wide-","source-fine-","source-wide-")):pinned[str(PARENT/name)]=parent["files"][name]
    pinned.update(parent["protected"])
    require("all parent physics and operator fingerprints",all(digest(p)==h for p,h in pinned.items()))
    locktime=(ROOT/"forecast-lock.json").stat().st_mtime_ns
    require("actual forecasts frozen before new evaluations",all(locktime<p.stat().st_mtime_ns for pat in ("direct-*.npz","probe-*.npz") for p in ROOT.glob(pat)))
    require("matched-control prescription frozen before verification", all((ROOT/"matched-null-freeze.json").stat().st_mtime_ns<p.stat().st_mtime_ns for p in ROOT.glob("matched-temperature-*.npz")))
    base=rows(PARENT/"full-grid-bands.csv")
    forecasts=rows("frozen-predictions.csv");scores=rows("forecast-scores.csv")
    require("all requested temperatures, redshifts, arms and surfaces",len(forecasts)==len(scores)==40 and len(rows("frozen-spectra.csv"))==1480)
    for surface in ("1200","1500"):
        for arm in cases(surface):
            k,jet,h=load_jets(arm,surface)
            require("37 finite modes and zero incoming tangent "+arm+surface,len(k)==37 and jet.shape==(7,37,3,4) and not np.any(jet[:2,:,:,1:]))
            if surface=="1200":
                old=next(r for r in base if r["arm"]==arm and float(r["lo"])==k[0] and float(r["hi"])==k[-1])
                R,W,_=project(k,jet[6,...,0],h[6],6,1.)
                require("old finite power "+arm,abs(integral(k,W*R*R,6)/float(old["area"])-1)<2e-5)
            for panel in ("fine","wide"):
                j=archive(f"jet-{panel}-{arm}-{surface}.npz")
                ref=data(panel,arm,surface,"gas")[arm+"-1-2048-1"]
                require("independent gas equation reproduction "+arm+surface+panel,peak_error(j["jet"][:,:,:,0],ref)<2e-5)
                packet=archive(f"direct-{panel}-{arm}-{surface}.npz")
                for temp in (9000,11000):
                    st=[packet[f"T{temp}-{step}-{stride}"] for step,stride in ((2048,1),(1024,1),(2048,2))]
                    require("finite histories, time and source resolution "+arm+surface+panel+str(temp),all(np.isfinite(arr).all() for arr in st) and max(peak_error(sol,st[0]) for sol in st[1:])<2e-5)
    require("all finite cubic power and peak-amplitude predictions checked",all(abs(float(r["cubic_power"]))<2e-5 and float(r["cubic_R_peak"])<2e-5 and r["cubic_root_presence"]=="True" for r in scores))
    pts=rows("point-tests.csv");match=rows("matching-checks.csv")
    require("near-zero exceptions retained rather than promoted",len(pts)==1240 and sum(float(r["time_kernel"])>=2e-5 for r in pts)==2 and sum(abs(float(r["cubic_kernel"]))>=2e-5 for r in pts)>0 and any(float(r["pointwise_kernel"])>=2e-5 for r in match))
    require("integral controls",all(max(abs(float(r[key])) for key in ("time","source"))<2e-5 for r in rows("integral-numerics.csv")) and max(abs(float(r["power"])) for r in match)<2e-5)
    require("late extra time refinements",all(abs(float(r["kernel_relative"]))<2e-5 for r in rows("near-zero-refinement.csv") if int(r["high"])>=4096))
    require("separate differential controls",len(rows("differential-controls.csv"))==12 and all(max(abs(float(r[key])) for key in ("symmetric_R_change","power_derivative_relative"))<2e-5 for r in rows("differential-controls.csv")))
    roots=rows("independent-mode-tests.csv");design=js("design.json")
    require("six prospective source brackets both matching surfaces",len(roots)==10 and len(design["radii"])==6 and all(r["verified_signs"]=="True" and float(r["left_R"])*float(r["right_R"])<0 and float(r["left"])<float(r["measured_root"])<float(r["right"]) for r in roots))
    br=archive("probe-bridge-fine.npz")
    require("independent microscopic state prediction for probes",br["defect"].shape==(12,3) and np.all(abs(br["defect"])<np.array([2e-5,2e-5,2e-6])))
    for arm in ("cold","heavy"):
        for tag in (("225",) if arm=="cold" else ("1200","1500")):
            src=archive(f"probe-source-fine-{arm}-{tag}.npz")
            require("fresh sourced modes, not an interpolation "+arm+tag,len(set(src["k"]))==(6 if arm=="cold" else 12) and max(src["constraint"])<2e-5 and not set(src["k"]).intersection(k))
    require("thermal contrast weights fixed",abs(np.dot(design["contrast_weights"],design["wave_log_gradient"]))<1e-12 and abs(np.linalg.norm(design["contrast_weights"])-1)<1e-12)
    contrasts=rows("contrast-grid.csv")
    require("full and reduced mesh comparison of two-redshift contrast",len(contrasts)==9 and max(abs(float(r["difference"])) for r in contrasts)<min(float(r["full"]) for r in contrasts if r["arm"]=="off")-max(float(r["full"]) for r in contrasts if r["arm"]=="wave"))
    mt=rows("matched-sign-checks.csv");mobs=[r for r in rows("matched-observables.csv") if float(r["z"])==4.2]
    require("matched physical null independently straddled at one k",len(mt)==2 and float(mt[0]["k"])==float(mt[1]["k"]) and all(float(r["lower_R"])*float(r["upper_R"])<0 for r in mt))
    require("matched fields and resolved finite powers",len(mobs)==2 and all(abs(float(r["normalized_R_at_k"]))<2e-5 for r in mobs) and float(mobs[1]["power"])>float(mobs[0]["power"]))
    ang=rows("angular-moments.csv")
    for arm in ARMS:
        a=[r for r in ang if r["arm"]==arm]
        require("independent positive moment and damping identities "+arm,len(a)==9 and all(float(r["J"])>0 and max(float(r[key]) for key in ("width_check","shear_check","shape_check"))<1e-12 for r in a))
        j=[float(r["J"]) for r in a if r["scenario"]=="readout-only"];require("readout-only shear invariant "+arm,np.ptp(j)<1e-12)
    grams=rows("gram-band-ledger.csv")
    require("variance law and residual monotonicity across each partition",len(grams)==10 and all(abs(float(r["rejoined_J"])-float(r["J"]))<1e-11 and float(r["E"])+1e-18>=float(r["left_E"])+float(r["right_E"]) for r in grams))
    stress=rows("thermal-stress-comparison.csv");precision=js("stress-accuracy.json")
    require("stress-effect accuracy",max(precision.values())<2e-5 and len(stress)==20)
    for r in stress:
        require("control thermal replay "+r["arm"]+r["temp"]+r["z"],float(r["baseline_peak"])<2e-5 and np.isfinite(float(r["using_number_power"])))
    require("no scratch or bytecode",not list(ROOT.rglob("__pycache__")))
    require("report and replay present",all((ROOT/key).stat().st_size>500 for key in ("RESULTS.md","THERMAL-EQUATIONS.md","ANGULAR-DERIVATION.md","REPLAY.md")))
    files={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(ROOT.rglob("*")) if p.is_file() and p.name!="closeout.json"}
    record=dict(parent=LOCK,checks=checks,files=files,protected=pinned)
    if seal:dump("closeout.json",record)
    else:assert record==js("closeout.json")
    print(len(checks),"checks;",len(files),"files;",len(pinned),"physical inputs;",digest(ROOT/"closeout.json"))
if __name__=="__main__":check(sys.argv[1:]==["--seal"])

