from angular import *

def census(k,field):
    x=np.log(k);rule,weights=np.polynomial.legendre.leggauss(12)
    loc=x[:-1,None]+np.diff(x)[:,None]*(1+rule)/2;mode=np.exp(loc)
    w=META["As"]*(mode/META["pivot_Mpc"])**(META["ns"]-1)/mode*np.diff(x)[:,None]*weights/2
    den=1.65*PchipInterpolator(x,field[:,1])(loc)
    vel=(RADS[6]/mode)**2*PchipInterpolator(x,field[:,2])(loc)
    return np.stack([np.sum(w*den**2,axis=1),np.sum(w*den*vel,axis=1),np.sum(w*vel**2,axis=1)],axis=-1)

def summary(raw):
    mass,mixed,velocity=raw
    assert mass>0 and velocity>=0
    mean=mixed/mass
    residual=velocity-mean*mixed
    assert residual>=0
    return mass,mean,residual/mass,residual

def main():
    locked();ledger=[];thresholds=[]
    for arm in ARMS:
        k,jets,h=load_jets(arm,"1200")
        for label,temp,field in [("reference",TREF,jets[6,...,0])]+([( "matched",float(archive(f"matched-temperature-{arm}.npz")["temp"]),archive(f"matched-temperature-{arm}.npz")["fields"][6])] if arm!="cold" else []):
            cells=census(k,field)
            full=summary(cells.sum(axis=0));mom=moments(k,field,h[6],temp/TREF,10)
            assert abs(full[2]-mom["J"])<1e-11
            for cut in (12.,24.):
                assert cut in k
                left=summary(cells[k[1:]<=cut].sum(axis=0));right=summary(cells[k[:-1]>=cut].sum(axis=0))
                frac=left[0]/full[0];spread=frac*(1-frac)*(left[1]-right[1])**2
                rejoined=frac*left[2]+(1-frac)*right[2]+spread
                ledger.append(dict(arm=arm,scenario=label,temp=temp,cut=cut,I0=full[0],J=full[2],E=full[3],
                    left_density_weight=frac,left_mean=left[1],right_mean=right[1],left_J=left[2],right_J=right[2],
                    mixing=spread,rejoined_J=rejoined,left_E=left[3],right_E=right[3]))
    for label in ("reference","matched"):
        subset=[r for r in ledger if r["scenario"]==label and r["cut"]==24.]
        wave=next(r for r in subset if r["arm"]=="wave")
        for other in [r for r in subset if r["arm"]!="wave"]:
            thresholds.append(dict(scenario=label,branch=other["arm"],J_measured_band=other["J"],wave_band_target=wave["J"],
                min_unseen_I0_in_measured_units=max(0.,other["J"]/wave["J"]-1.),
                condition="If this branch alone must drop to the fixed finite-band wave value; wave tail not bounded."))
    table("gram-band-ledger.csv",ledger);table("gram-tail-conditions.csv",thresholds)
    print(thresholds)
if __name__=="__main__":main()

