from compare import *

def check():
    locked();ledger=[]
    for row in js("design.json")["radii"]:
        arm=row["arm"];temp=row["temp"];trial=row["center"];pts=np.array([row["flanks"][0],trial,row["flanks"][1]])
        for surface in (["1200"] if arm=="cold" else ["1200","1500"]):
            direct=archive(f"direct-probe-{arm}-{surface}.npz")
            ids=np.searchsorted(direct["k"],pts);assert np.array_equal(direct["k"][ids],pts)
            h=direct["h_kms"][6];scale=load_jets(arm,surface)[0]
            norm=np.max(abs(project(scale,load_direct(arm,surface,temp)[6],h,6,temp/TREF)[0]))
            roots=[];signs=[]
            for step,stride in ((2048,1),(1024,1),(2048,2)):
                r=project(pts,direct[f"T{temp}-{step}-{stride}"][6,ids],h,6,temp/TREF)[0];signs.append(r)
                roots.append(brentq(PchipInterpolator(pts,r),pts[0],pts[-1]) if r[0]*r[-1]<0 else None)
            probe=signs[0];bracketed=roots[0] is not None
            ledger.append(dict(arm=arm,surface=surface,temp=temp,forecast=trial,left=pts[0],right=pts[-1],left_R=probe[0],center_R=probe[1],
                right_R=probe[-1],center_over_peak=probe[1]/norm,verified_signs=all(rs[0]*rs[-1]<0 for rs in signs),
                measured_root=roots[0],root_error=trial-roots[0] if bracketed else None,
                root_linear_error=(pts[0]-probe[0]*(pts[-1]-pts[0])/(probe[-1]-probe[0])-roots[0]) if bracketed else None,
                root_step_change=roots[1]-roots[0] if None not in roots[:2] else None,
                root_stride_change=roots[2]-roots[0] if None not in (roots[2],roots[0]) else None,
                center_relative_kernel_step=(signs[1][1]/probe[1])**2-1,center_relative_kernel_stride=(signs[2][1]/probe[1])**2-1))
    table("independent-mode-tests.csv",ledger)
    for r in ledger:print(r["arm"],r["temp"],r["surface"],r["verified_signs"],r["root_error"],flush=True)
if __name__=="__main__":check()

