from compare import *

def histories(src,arm,temp,rtol):
    interp=envs(src,1);k=src["k"];mass=float(src["mass"]);epochs=src["epochs"]
    first=interp(epochs[0]);units=np.ones((len(k),6));units[:,3:]=k[:,None]**2/(first[0]*first[1])
    units/=np.max(abs(units*src["init"]),axis=1)[:,None]
    tiny=1e-8;initial=np.zeros((len(k),13));initial[:,:6]=units*src["init"]
    def context(time,arr):
        env=interp(time);a,h=env[:2];state=arr.reshape(-1,13)
        y=state[:,:6]/units;delta=state[:,6:12]*tiny/units
        cold,phi,psi=gas.affine(env,k,mass,arm,0)
        ramp=np.clip(np.log(10*a)/np.log(10/8),0,1)
        cs=1.5*gas.KB*temp/(.61*gas.MP*(SPEED*1000)**2)*ramp**2*(3-2*ramp)
        cold[:,4,1]-=a/h*cs
        return a,h,y,delta,state[:,12]*tiny/units[:,1],cold,phi,psi,cs
    def rhs(time,arr):
        a,h,y,delta,_,op,phi,_,cs=context(time,arr)
        move=lambda matrix,vec:np.einsum("kij,kj->ki",matrix,vec)
        base=move(op[:,:,:6],y)+op[:,:,6]
        shift=move(op[:,:,:6],delta)
        target=y+delta
        potential=np.sum(phi[:,:6]*target,axis=1)+phi[:,6]
        gauge_term=3*(potential-h/a*target[:,4]);rest=target[:,1]+gauge_term
        work=3*cs*rest
        shift[:,1]-=work;shift[:,4]-=a/h*cs*gauge_term
        return np.column_stack([base*units,shift*units/tiny,work*units[:,1]/tiny]).ravel()
    def record(time,arr):
        a,h,y,delta,entropy,_,phi,psi,_=context(time,arr)
        obs=lambda field,add:np.column_stack([-k**2*(np.sum(psi[:,:6]*field,axis=1)+add*psi[:,6]),
            field[:,1]+3*(np.sum(phi[:,:6]*field,axis=1)+add*phi[:,6]),k**2*field[:,4]/(a*h)])
        return obs(y,1),obs(delta,0),entropy
    out=[record(epochs[0],initial)];last=initial.ravel()
    edges=[epochs[0],np.log(.1),np.log(.125),epochs[-1]]
    for left,right in zip(edges[:-1],edges[1:]):
        chosen=epochs[(epochs>left)&(epochs<=right)];probes=np.unique(np.r_[chosen,right])
        sol=solve_ivp(rhs,(left,right),last,t_eval=probes,rtol=rtol,atol=rtol*.004,method="DOP853")
        assert sol.success and np.isfinite(sol.y).all()
        for time in chosen:out.append(record(time,sol.y[:,np.searchsorted(probes,time)]))
        last=sol.y[:,-1]
    return [np.array(x) for x in zip(*out,strict=True)]

def main():
    locked();out=[]
    for arm in ARMS:
        k,jet,h=load_jets(arm,"1200")
        temperatures=[int(TREF)]
        if arm!="cold":temperatures.append(float(archive(f"matched-temperature-{arm}.npz")["temp"]))
        for temp in temperatures:
            blocks=[]
            for panel in ("fine","wide"):
                src=data(panel,arm,"1200","source")
                baseline,shift,entropy=histories(src,arm,temp,2e-10)
                assert not np.any(shift[:2]) and not np.any(entropy[:2])
                blocks.append(dict(k=src["k"],baseline=baseline,shift=shift,entropy=entropy))
            center=combined(blocks,"baseline");correction=combined(blocks,"shift");extra=combined(blocks,"entropy")
            ref=jet[...,0] if temp==TREF else archive(f"matched-temperature-{arm}.npz")["fields"]
            assert peak_error(center,ref)<2e-5
            matter=center+correction
            count=matter.copy();count[:,:,1]+=extra
            if temp==TREF and arm=="wave":
                src=data("fine",arm,"1200","source");b2,c2,e2=histories(src,arm,temp,1e-11)
                precision=dict(delta_peak=peak_error(c2,blocks[0]["shift"]),internal_peak=peak_error(e2,blocks[0]["entropy"]))
                dump("stress-accuracy.json",precision)
            for zi in FOUR:
                r,w,_=project(k,center[zi],h[zi],zi,temp/TREF)
                dr=project(k,correction[zi],h[zi],zi,temp/TREF)[0]
                number=correction[zi].copy();number[:,1]+=extra[zi]
                dn=project(k,number,h[zi],zi,temp/TREF)[0]
                base=integral(k,w*r**2,zi)
                root=rootinfo(k,r,zi);rnew=rootinfo(k,r+dn,zi)
                out.append(dict(arm=arm,temp=temp,z=Z[zi],baseline_peak=peak_error(center,ref),base_power=base,
                    gravitating_density_change_peak=np.max(abs(correction[zi,:,1]))/np.max(abs(center[zi,:,1])),
                    number_energy_difference_peak=np.max(abs(extra[zi]))/np.max(abs(center[zi,:,1])),
                    force_change_peak=np.max(abs(correction[zi,:,0]))/np.max(abs(center[zi,:,0])),
                    using_energy_power=integral(k,w*(r+dr)**2,zi)/base-1,
                    using_number_power=integral(k,w*(r+dn)**2,zi)/base-1,
                    delta_root=rnew["root"]-root["root"] if rnew and root else None))
            save(f"stress-{arm}-{'reference' if temp==TREF else 'matched'}.npz",k=k,baseline=center,delta=correction,number_minus_energy=extra)
        print("tested added pressure stress and number",arm,flush=True)
    table("thermal-stress-comparison.csv",out)
if __name__=="__main__":main()

