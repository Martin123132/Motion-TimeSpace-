from common import *

META=js(prior.PREV/"primordial-settings.json")
RADS=radial()

def project(k,fields,hubble,zi,ratio):
    kx=RADS[zi]
    tilt=META["As"]*(k/META["pivot_Mpc"])**(META["ns"]-1)
    d=.25*(kx/hubble)**2*2*gas.KB*TREF*ratio/(gas.MP*1e6)
    B=2-.5*(.7+d)
    R=B*fields[:,1]+(kx/k)**2*fields[:,2]
    pref=np.pi*hubble*.65**2*np.exp(-2*d)*tilt/k
    return R,pref,d

def integral(k,values,zi):
    assert k[0]<=RADS[zi]*(1+1e-12) and k[-1]==37
    return float(PchipInterpolator(np.log(k),values).integrate(np.log(RADS[zi]),np.log(37)))

def rootinfo(k,values,zi):
    ids=np.flatnonzero((values[1:]*values[:-1]<0)&(k[1:]>RADS[zi]))
    if len(ids)==0:return None
    index=ids[0]
    fit=PchipInterpolator(k,values)
    root=brentq(fit,k[index],k[index+1])
    linear=k[index]-values[index]*(k[index+1]-k[index])/(values[index+1]-values[index])
    return dict(root=root,lo=k[index],hi=k[index+1],linear_root=linear,count=len(ids))

def signed_slope(k,values,change,zi,root):
    derivative=PchipInterpolator(k,values).derivative()(root)
    eps=1e-5
    up=PchipInterpolator(k,values+eps*change)(root);dn=PchipInterpolator(k,values-eps*change)(root)
    return float(-(up-dn)/(2*eps*derivative))

def power_slope(k,base,delta,zi):
    eps=1e-5
    return (integral(k,base+eps*delta,zi)-integral(k,base-eps*delta,zi))/(2*eps)

def load_jets(arm,surface):
    blocks=[archive(f"jet-{panel}-{arm}-{surface}.npz") for panel in ("fine","wide")]
    k,_=joined(blocks)
    assert np.allclose(blocks[0]["h_kms"],blocks[1]["h_kms"],rtol=1e-11)
    return k,combined(blocks,"jet"),blocks[0]["h_kms"]

def freeze():
    guard();assert not list(ROOT.glob("direct-*.npz")) and not (ROOT/"forecast-lock.json").exists()
    ledger=[];forecast=[];group=[];addresses=[]
    for surface in ("1200","1500"):
        for arm in cases(surface):
            k,jet,hubble=load_jets(arm,surface)
            for zi in FOUR:
                field=jet[zi,...,0];response,weight,d=project(k,field,hubble[zi],zi,1.)
                dynam=project(k,jet[zi,...,1],hubble[zi],zi,1.)[0]
                conv=-.5*d*field[:,1];density=weight*response**2;power=integral(k,density,zi)
                metric=power_slope(k,density,2*weight*response*dynam,zi)/power
                shape=power_slope(k,density,2*weight*response*conv,zi)/power
                root=rootinfo(k,response,zi);rr=root["root"] if root else None
                dyn_shift=signed_slope(k,response,dynam,zi,rr) if root else None
                map_shift=signed_slope(k,response,conv,zi,rr) if root else None
                ledger.append(dict(arm=arm,surface=surface,z=Z[zi],power=power,root=rr,root_count=root["count"] if root else 0,
                    dynam_logpower=metric,readout_logpower=shape,pref_logpower=-2*d,total_logpower=metric+shape-2*d,
                    dynam_root_shift=dyn_shift,readout_root_shift=map_shift))
                for delta in DELTAS:
                    pred=jet[zi]@np.array([1.,delta,delta**2,delta**3])
                    r3,w3,_=project(k,pred,hubble[zi],zi,1+delta)
                    three=rootinfo(k,r3,zi)
                    logstep=np.log1p(delta)
                    rpred=response+logstep*(dynam+conv)
                    forecast.append(dict(arm=arm,surface=surface,z=Z[zi],temp=round(TREF*(1+delta)),p0=power,root0=rr,
                        tangent_power=power*(1+(metric+shape-2*d)*logstep),cubic_power=integral(k,w3*r3**2,zi),
                        tangent_root=rr+logstep*(dyn_shift+map_shift) if root else None,cubic_root=three["root"] if three else None,
                        cubic_lo=three["lo"] if three else None,cubic_hi=three["hi"] if three else None))
                    if zi==6 and surface=="1200":
                        assert three and three["count"]==1
                        center=three["root"]
                        addresses.append(dict(arm=arm,temp=round(TREF*(1+delta)),center=center,flanks=[center-.03,center+.03]))
                    for index,node in enumerate(k):
                        group.append(dict(arm=arm,surface=surface,z=Z[zi],temp=round(TREF*(1+delta)),k=node,r0=response[index],
                            tangent_R=rpred[index],cubic_R=r3[index]))
    table("thermal-slopes.csv",ledger);table("frozen-spectra.csv",group);table("frozen-predictions.csv",forecast)
    w=[r for r in ledger if r["surface"]=="1200" and r["arm"]=="wave" and r["z"] in (4.2,4.6)]
    assert [r["z"] for r in w]==[4.2,4.6]
    grad=np.array([r["total_logpower"] for r in w])
    contrast=np.array([-grad[1],grad[0]])/np.linalg.norm(grad)
    dump("design.json",dict(radii=addresses,probe_halfwidth_mpc_inv=.03,contrast_z=[4.2,4.6],wave_log_gradient=grad.tolist(),
        contrast_weights=contrast.tolist(),reference_wave_power=[r["power"] for r in w],definition="weights dot log(P/P_wave_ref); nulls wave linear temperature slope"))
    files=[ROOT/n for n in ("common.py","tangent.py","spectrum.py","PROTOCOL.md","thermal-slopes.csv","frozen-spectra.csv","frozen-predictions.csv","design.json")]+sorted(ROOT.glob("jet-*.npz"))
    dump("forecast-lock.json",{p.name:digest(p) for p in files})
    print("frozen:",[(r["arm"],r["temp"],round(r["center"],5)) for r in addresses],flush=True)

def locked():
    guard()
    assert all(digest(ROOT/key)==val for key,val in js("forecast-lock.json").items())

if __name__=="__main__":freeze()

