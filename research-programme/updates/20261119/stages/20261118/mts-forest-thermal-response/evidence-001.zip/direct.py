from spectrum import *

ORIGINAL=gas.affine

def direct(source,arm,temperature,steps,stride):
    ratio=temperature/TREF
    def finite_temperature(env,k,mass,branch,hot):
        assert hot==1
        warm,base,psi=ORIGINAL(env,k,mass,branch,1)
        native=ORIGINAL(env,k,mass,branch,0)[0]
        warm[...,4,1]=native[...,4,1]+ratio*(warm[...,4,1]-native[...,4,1])
        return warm,base,psi
    try:
        gas.affine=finite_temperature
        return gas.run(source,arm,1,steps,stride)
    finally:gas.affine=ORIGINAL

def run(surface,group):
    locked();ledger=[]
    if group=="probe":pairs=[("probe",arm) for arm in cases(surface)]
    else:pairs=[(panel,arm) for arm in cases(surface) for panel in ("fine","wide")]
    for panel,arm in pairs:
        case,tag=scenario(arm,surface)
        src=data(panel,arm,surface,"source") if panel!="probe" else archive(f"probe-source-fine-{case}-{tag}.npz")
        packet=dict(k=src["k"],h_kms=src["h"][np.searchsorted(src["N"],src["epochs"])]*SPEED)
        for temperature in (9000,11000):
            results=[]
            for steps,stride in ((2048,1),(1024,1),(2048,2)):
                out=direct(src,arm,temperature,steps,stride)
                assert np.isfinite(out).all()
                packet[f"T{temperature}-{steps}-{stride}"]=out
                results.append(out)
            ledger.append(dict(panel=panel,arm=arm,temp=temperature,time_error=peak_error(results[1],results[0]),source_error=peak_error(results[2],results[0])))
        save(f"direct-{panel}-{arm}-{surface}.npz",**packet)
        print(group,panel,arm,surface,"time/stride",max(r["time_error"] for r in ledger),max(r["source_error"] for r in ledger),flush=True)
    table(f"direct-checks-{group}-{surface}.csv",ledger)
if __name__=="__main__":run(*sys.argv[1:])

