from matched_test import one_mode
from compare import *
from direct import direct

def controls():
    locked();budgets=[];remainders=[];derivatives=[]
    failed={(r["arm"],r["surface"],int(r["temp"]),float(r["z"]),float(r["k"])) for r in rows("point-tests.csv") if float(r["time_kernel"])>=2e-5}
    for arm,surface,temp,z,node in sorted(failed):
        zi=np.where(Z==z)[0].item()
        k,jet,h=load_jets(arm,surface);pos=np.flatnonzero(k==node).item()
        for panel in ("fine","wide"):
            src=data(panel,arm,surface,"source")
            ix=np.flatnonzero(src["k"]==node)
            if not len(ix):continue
            part=one_mode(src,ix)
            original=archive(f"direct-{panel}-{arm}-{surface}.npz")
            spectra={}
            for step in (1024,2048,4096,8192):
                fields=original[f"T{temp}-{step}-1"][zi,ix] if step<=2048 else direct(part,arm,temp,step,1)[zi]
                spectra[step]=float(project(np.array([node]),fields,h[zi],zi,temp/TREF)[0][0])
            peak=max(abs(project(k,load_direct(arm,surface,temp)[zi],h[zi],zi,temp/TREF)[0][k>=RADS[zi]]))
            for a,b in ((1024,2048),(2048,4096),(4096,8192)):
                remainders.append(dict(arm=arm,surface=surface,temp=temp,z=z,k=node,low=a,high=b,
                    kernel_relative=(spectra[a]/spectra[b])**2-1,peak_R_change=(spectra[a]-spectra[b])/peak,signal_over_peak=spectra[b]/peak))
    for surface in ("1200","1500"):
        for arm in cases(surface):
            k,jet,h=load_jets(arm,surface);few=reduced(k)
            for temp in (9000,11000):
                solutions=[load_direct(arm,surface,temp,*variant) for variant in ((2048,1),(1024,1),(2048,2))]
                for zi in FOUR:
                    measures=[]
                    for sol in solutions:
                        r,w,_=project(k,sol[zi],h[zi],zi,temp/TREF);measures.append(integral(k,w*r**2,zi))
                    budgets.append(dict(arm=arm,surface=surface,temp=temp,z=Z[zi],reference=measures[0],time=measures[1]/measures[0]-1,source=measures[2]/measures[0]-1))
            if surface!="1200":continue
            blocks=[]
            for panel in ("fine","wide"):
                source=data(panel,arm,surface,"source")
                grid={f"s{sign}":direct(source,arm,TREF*(1+sign*.001),2048,1) for sign in (-1,1)}
                blocks.append(dict(k=source["k"],**grid))
            plus=combined(blocks,"s1");minus=combined(blocks,"s-1")
            for zi in FOUR:
                q1,w1,_=project(k,plus[zi],h[zi],zi,1.001);q2,w2,_=project(k,minus[zi],h[zi],zi,.999)
                r,w,d=project(k,jet[zi,...,0],h[zi],zi,1.);dr=project(k,jet[zi,...,1],h[zi],zi,1.)[0]-.5*d*jet[zi,:,1,0]
                ok=k>=RADS[zi];scale=max(abs(dr[ok]));dp=power_slope(k,w*r**2,2*w*(r*dr-d*r**2),zi)
                direct_delta=(integral(k,w1*q1**2,zi)-integral(k,w2*q2**2,zi))/.002
                derivatives.append(dict(arm=arm,z=Z[zi],symmetric_R_change=np.max(abs((q1-q2)/.002-dr)[ok])/scale,power_derivative_relative=direct_delta/dp-1))
    table("integral-numerics.csv",budgets);table("near-zero-refinement.csv",remainders);table("differential-controls.csv",derivatives)
    print("derivative",max(r["symmetric_R_change"] for r in derivatives),max(abs(r["power_derivative_relative"]) for r in derivatives),
        "late refinements",[(r["high"],r["kernel_relative"]) for r in remainders],flush=True)
if __name__=="__main__":controls()

