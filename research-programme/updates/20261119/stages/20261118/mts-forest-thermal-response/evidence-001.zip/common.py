from pathlib import Path
import csv
import hashlib
import json
import os
import sys

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
import numpy as np
from scipy.interpolate import CubicSpline,PchipInterpolator
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
import psutil
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PARENT=POST/"mts-common-clock-hierarchy-20261118"
OLD=POST/"mts-forest-transverse-integral-20261118"
sys.path.insert(0,str(OLD))
import gas
import local as prior
LOCK="480ee8e298a6462d57f9c810e86e8879a3808694d48e63b20e9f7f7286d356fb"
Z=prior.Z
SPEED=prior.SPEED
ARMS=("wave","off","cold")
FOUR=(6,5,4,3)
TREF=10000.
DELTAS=(-.1,.1)

def digest(path):
    with Path(path).open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()

def read(path):
    return (ROOT/path).read_text(encoding="utf8")

def js(path):
    return json.loads(read(path))

def dump(path,value):
    with (ROOT/path).open("x",encoding="utf8") as stream:json.dump(value,stream,indent=2,allow_nan=False)

def archive(path):
    with np.load(ROOT/path) as data:return dict(data)

def save(path,**value):
    with (ROOT/path).open("xb") as stream:np.savez_compressed(stream,**value)

def table(path,rows):
    with (ROOT/path).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def rows(path):
    with (ROOT/path).open(newline="",encoding="utf8") as stream:return list(csv.DictReader(stream))

def guard():
    prior.guard()
    assert digest(PARENT/"closeout.json")==LOCK and not any((d/"STOP-REQUESTED").exists() for d in (PARENT,ROOT))
    receipt=js(PARENT/"closeout.json")
    for path in (OLD/"gas.py",OLD/"local.py",prior.PREV/"primordial-settings.json",prior.POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv"):
        assert digest(path)==receipt["protected"][str(path)]

def scenario(arm,surface):
    return ("cold","225") if arm=="cold" else ("heavy",str(surface))

def cases(surface):
    return ARMS if surface=="1200" else ARMS[:2]

def data(panel,arm,surface,kind):
    case,tag=scenario(arm,surface)
    name=f"{kind}-{panel}-{case}-{tag}.npz"
    assert digest(PARENT/name)==js(PARENT/"closeout.json")["files"][name]
    return archive(PARENT/name)

def peak_error(actual,reference):
    return float(np.max(abs(actual-reference)/np.maximum(np.max(abs(reference),axis=0,keepdims=True),1e-24)))

def envs(data,stride):
    axis=data["N"];epochs=data["epochs"]
    selected=np.unique(np.r_[np.arange(0,len(axis),stride),len(axis)-1,np.searchsorted(axis,epochs)])
    env=np.column_stack([data["a"],data["h"],data["g"].T,data["thermal"],data["external"].transpose(1,0,2).reshape(len(axis),-1)])
    return CubicSpline(axis[selected],env[selected],axis=0)

def radial():
    entries=rows(POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv")
    return {zi:max(float(r["k_parent"]) for r in entries if float(r["z"])==Z[zi]) for zi in FOUR}

def joined(packets):
    k=np.concatenate([d["k"] for d in packets])
    order=np.argsort(k,kind="stable")
    keep=order[np.r_[True,np.diff(k[order])!=0]]
    assert len(keep)==37 and np.sum(k==37)==2
    return k[keep],keep

def combined(packets,key):
    k,keep=joined(packets)
    return np.concatenate([d[key] for d in packets],axis=1)[:,keep]

