from common import *

def integrate(data,arm,rtol):
    k=data["k"];mass=float(data["mass"]);times=data["epochs"];interp=envs(data,1)
    first=interp(times[0]);units=np.ones((len(k),6))
    units[:,3:]=k[:,None]**2/(first[0]*first[1])
    initial=data["init"]*units
    norm=np.maximum(1e-10,np.max(abs(initial),axis=1))
    units=units/norm[:,None]
    state=np.zeros((len(k),6,4));state[:,:,0]=data["init"]*units
    def rhs(time,arr):
        env=interp(time)
        matrix=gas.affine(env,k,mass,arm,1)[0]
        tensor=arr.reshape(-1,6,4)
        change=((units[:,:,None]*matrix[:,:,:6]/units[:,None,:])@tensor)
        change[:,:,0]+=units*matrix[:,:,6]
        ramp=np.clip(np.log(10*env[0])/np.log(10/8),0,1)
        term=-(env[0]/env[1])*1.5*gas.KB*TREF/(.61*gas.MP*(SPEED*1000)**2)*ramp**2*(3-2*ramp)
        change[:,4,1:]+=term*(units[:,4]/units[:,1])[:,None]*tensor[:,1,:-1]
        return change.ravel()
    def observation(time,arr):
        env=interp(time);_,phi,psi=gas.affine(env,k,mass,arm,1)
        coord=arr.reshape(-1,6,4)/units[:,:,None]
        metric=np.einsum("ki,kij->kj",phi[:,:6],coord);metric[:,0]+=phi[:,6]
        lapse=np.einsum("ki,kij->kj",psi[:,:6],coord);lapse[:,0]+=psi[:,6]
        return np.stack([-k[:,None]**2*lapse,coord[:,1,:]+3*metric,k[:,None]**2*coord[:,4,:]/(env[0]*env[1])],axis=1)
    out=[observation(times[0],state)]
    count=0
    edges=[times[0],np.log(.1),np.log(.125),times[-1]]
    for left,right in zip(edges[:-1],edges[1:]):
        chosen=times[(times>left)&(times<=right)]
        probes=np.unique(np.r_[chosen,right])
        sol=solve_ivp(rhs,(left,right),state.ravel(),method="DOP853",rtol=rtol,atol=rtol*.004,t_eval=probes)
        assert sol.success and np.isfinite(sol.y).all()
        count+=sol.nfev;state=sol.y[:,-1].reshape(-1,6,4)
        for time in chosen:out.append(observation(time,sol.y[:,np.searchsorted(probes,time)]))
    assert len(out)==len(times)
    return np.array(out),count

def run(surface):
    guard();ledger=[]
    for arm in cases(surface):
        for panel in ("fine","wide"):
            sources=data(panel,arm,surface,"source");fixed=data(panel,arm,surface,"gas")
            jet,calls=integrate(sources,arm,2e-11)
            assert np.all(jet[:2,:,:,1:]==0)
            ref=fixed[arm+"-1-2048-1"]
            diff=peak_error(jet[:,:,:,0],ref)
            assert diff<2e-5
            key=f"jet-{panel}-{arm}-{surface}.npz"
            save(key,k=sources["k"],jet=jet,h_kms=sources["h"][np.searchsorted(sources["N"],sources["epochs"])]*SPEED)
            ledger.append(dict(arm=arm,panel=panel,surface=surface,calls=calls,baseline_peak_error=diff))
            print(arm,panel,surface,"reference difference",diff,"RHS calls",calls,flush=True)
    table(f"jet-checks-{surface}.csv",ledger)
if __name__=="__main__":run(sys.argv[1])

