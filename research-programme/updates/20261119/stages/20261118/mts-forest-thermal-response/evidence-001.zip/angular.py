from compare import *

def moments(k,fields,h,std_ratio,order,linear=False):
    kref=RADS[6];d=.25*(kref/h)**2*(2*gas.KB*TREF*std_ratio/(gas.MP*1e6))
    qx,w=np.polynomial.legendre.leggauss(order)
    grid=np.log(k);width=np.diff(grid)
    points=(grid[:-1,None]+width[:,None]*(1+qx)/2).ravel()
    weights=(width[:,None]*w/2).ravel()
    kk=np.exp(points)
    def interp(values):
        return np.interp(points,grid,values) if linear else PchipInterpolator(grid,values)(points)
    p=1.65*interp(fields[:,1]);v=(kref/kk)**2*interp(fields[:,2])
    q=v-.5*d*p/1.65
    weights*=META["As"]*(kk/META["pivot_Mpc"])**(META["ns"]-1)/kk
    norm=np.sum(weights*p*p);cross=np.sum(weights*p*q);square=np.sum(weights*q*q)
    j=square/norm-(cross/norm)**2
    velproj=np.sum(weights*p*v)/norm
    invariant=np.sum(weights*(v-velproj*p)**2)/norm
    selected=sorted({float(r["k_parent"]) for r in rows(POST/"mts-forest-pressure-switch-20261118/forest-radial-inputs.csv") if float(r["z"])==4.2})
    x=(np.asarray(selected)/kref)**2; factors=np.pi*h*.65**2*np.exp(-2*d*x)
    power=factors*(norm+2*x*cross+x**2*square)
    bare=np.array([np.sum(weights*(p+xi*q)**2) for xi in x])
    assert np.all(power>0) and j>=0
    def bend(values):
        left,mid,right=np.log(values[-3:]);lo,center,hi=x[-3:]
        return mid-((hi-center)*left+(center-lo)*right)/(hi-lo)
    return dict(J=j,curvature=bend(power),bias=cross/norm,velocity_coherent_part=velproj,
        shear_check=abs(j-invariant),width_check=abs(bend(power)-bend(bare)),shape_check=np.max(abs(power/(factors*bare)-1)),
        high_k_projection=power[-1],radial_count=len(selected),I0=norm,I1=cross,I2=square)

def main():
    locked();out=[]
    for arm in ARMS:
        k,jet,h=load_jets(arm,"1200")
        for t in (9000,10000,11000):
            direct=jet[6,...,0] if t==10000 else load_direct(arm,"1200",t)[6]
            for name,field,ratio in (("both",direct,t/TREF),("readout-only",jet[6,...,0],t/TREF),("gas-only",direct,1.)):
                target=moments(k,field,h[6],ratio,10)
                few=reduced(k)
                subs=moments(k[few],field[few],h[6],ratio,10)
                lin=moments(k,field,h[6],ratio,10,True);qc=moments(k,field,h[6],ratio,5)
                out.append(dict(arm=arm,temp=t,scenario=name,**target,
                    quadrature_J_change=qc["J"]-target["J"],quadrature_Q_change=qc["curvature"]-target["curvature"],
                    thin_J_change=subs["J"]-target["J"],thin_Q_change=subs["curvature"]-target["curvature"],
                    linear_J_change=lin["J"]-target["J"],linear_Q_change=lin["curvature"]-target["curvature"]))
    table("angular-moments.csv",out)
    for r in out:
        if r["scenario"]=="both":print(r["arm"],r["temp"],"J,Q",r["J"],r["curvature"])
if __name__=="__main__":main()

