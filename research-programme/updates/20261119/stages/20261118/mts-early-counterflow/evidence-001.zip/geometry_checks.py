from response import ROOT, MODE, MU, np, json
from scipy.linalg import expm

def fixture(amp):
    nodes=32
    coord=2*np.pi*np.arange(nodes)/nodes
    one,two=np.meshgrid(coord,coord,indexing='ij')
    vectors=MODE*np.array([[1,0,0],[MU,np.sqrt(1-MU**2),0]])
    normals=vectors/MODE
    summed=normals.sum(axis=0)
    modes=np.fft.fftfreq(nodes)*nodes
    dual=modes[:,None,None]*vectors[0]+modes[None,:,None]*vectors[1]
    def deriv(data,axis):
        return np.fft.ifft2(1j*dual[:,:,axis]*np.fft.fft2(data)).real
    def tracecos(value):
        return 2*np.mean(value*np.cos(one+two))
    def tracesin(value):
        return 2*np.mean(value*np.sin(one+two))
    cos=np.cos(one)+np.cos(two); sin=np.sin(one)[:,:,None]*normals[0]+np.sin(two)[:,:,None]*normals[1]
    cold,beta,flow,eta,rate,frac,fluct=.37,.46,-.28,-.15,.42,.81,-.34
    metric=np.zeros((nodes,nodes,3,3));ident=np.eye(3)
    for normal,angle in zip(normals,[one,two]):
        block=(-2*cold+6*eta)*np.outer(normal,normal)-2*eta*ident
        metric+=amp*np.cos(angle)[:,:,None,None]*block
    metric=expm(metric); inverse=np.linalg.inv(metric)
    volume=np.sqrt(np.linalg.det(metric));log_density=amp*beta*cos
    log_compress=-np.log(volume);rate_total=amp*rate*cos
    field=amp*fluct*cos
    grad=lambda data:np.stack([deriv(data,axis) for axis in range(3)],axis=-1)
    up=lambda cov:np.einsum('...ij,...j->...i',inverse,cov)
    div=lambda vec:sum(deriv(vec[:,:,axis],axis) for axis in range(3))
    laplace=div(volume[:,:,None]*up(grad(field)))/volume
    momentum=amp*flow*sin
    boost=np.ones_like(cos)
    for _ in range(7):
        proper=np.exp(log_density)/boost;enthalpy=(1-frac)*proper+frac*proper**(4/3)
        velocity=momentum/(enthalpy*boost**2)[:,:,None]
        vel_up=up(velocity)
        boost=1/np.sqrt(1-np.sum(velocity*vel_up,axis=-1))
    bdot=rate_total-div(vel_up)+np.sum(vel_up*grad(log_compress-log_density),axis=-1)
    pdot=rate_total[:,:,None]*momentum-grad(frac/4*proper**(4/3))
    for axis in range(3):
        pdot[:,:,axis]-=div(volume[:,:,None]*vel_up*momentum[:,:,axis,None])/volume
        for first in range(3):
            for second in range(3):
                pdot[:,:,axis]+=.5*deriv(metric[:,:,first,second],axis)*vel_up[:,:,first]*up(momentum)[:,:,second]
    baryon_trace=proper*(2*boost**2-1)
    photon_trace=2*proper**(4/3)*(4*boost**2-1)/3
    shift=-3*amp*sin/MODE
    physical=[angle+np.einsum('...i,i->...',shift,wave) for angle,wave in zip([one,two],vectors)]
    zeta=amp*sum(np.cos(angle) for angle in physical)
    dzeta=-amp*sum(np.sin(angle)[:,:,None]*wave for angle,wave in zip(physical,vectors))
    ricci=np.exp(-2*zeta)*(4*MODE**2*zeta-2*np.sum(dzeta**2,axis=-1))
    calc=np.array([tracecos(laplace),tracecos(bdot),tracesin(np.einsum('...i,i->...',pdot,summed)),tracecos(baryon_trace),tracecos(photon_trace),tracecos(ricci)])/amp**2
    exact=np.array([-2.5*MODE**2*eta*fluct, MODE*flow*((1+frac/6)*beta-2.5*eta),
        .5*rate*flow+frac*MODE/3*(2*beta**2/3+MU*flow**2/2)-.25*MODE*flow**2,
        .5*beta**2-1.5*MU*flow**2,2*(8*beta**2/9-2*MU*flow**2/3),-3*MODE**2])
    return calc,exact

def run():
    coarse,exact=fixture(.004)
    fine,_=fixture(.002)
    extrap=(4*fine-coarse)/3
    errors=abs(extrap-exact)
    assert np.max(errors/np.maximum(1,abs(exact)))<2e-8
    return dict(terms=['curved_laplacian','log_baryon_current','covariant_momentum','baryon_trace','photon_trace','primordial_curvature_in_native_labels'],
                extracted=extrap.tolist(),analytic=exact.tolist(),absolute_errors=errors.tolist())
if __name__=='__main__':print(run())
