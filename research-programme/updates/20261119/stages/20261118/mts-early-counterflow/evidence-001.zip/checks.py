from geometry_checks import run as fixture
from response import ROOT, MODE, MU, np, json, guard
from scipy.integrate import solve_ivp
import ast

def dust():
    def rhs(tau,state):
        hubble=2/tau
        linear=tau**2
        rate=2*tau
        compression,derivative=state
        return [derivative,-hubble*derivative+1.5*hubble**2*compression+
                .75*hubble**2*linear**2+rate**2/3+(MU**2-1/3)*rate**2]
    start=.01; last=1.
    coefficient=(3+4*MU**2)/14
    sol=solve_ivp(rhs,(start,last),[coefficient*start**4,4*coefficient*start**3],rtol=2e-12,atol=1e-15,method='DOP853')
    assert sol.success
    density=float(sol.y[0,-1]+.5)
    assert abs(density-(5+2*MU**2)/7)<1e-11
    return density

def independent_forcing(case):
    from response import matrices
    from scipy.interpolate import CubicSpline
    with np.load(ROOT/(case+'-acoustic.npz')) as data:
        tau=data['tau']; drive=CubicSpline(tau,data['external_drive'])
    with np.load(ROOT/(case+'-native.npz')) as table:
        native=table['uniform']; points=table['knots'];weights=table['weights'];center=float(table['center_t'])
    coeff,dr=matrices(case,native,1);size=coeff.shape[1]
    operator=CubicSpline(native,coeff[:,:,:size],axis=0)
    expansion=CubicSpline(native,dr['expansion'])
    def deriv(time,state):
        ret=operator(time)@state
        ret[1]+=expansion(time)**2*drive(time)
        return ret
    active=solve_ivp(deriv,(native[0],tau[-1]),np.zeros(size),rtol=5e-10,atol=2e-13,method='DOP853')
    assert active.success
    later=solve_ivp(lambda time,state:operator(time)@state,(tau[-1],native[-1]),active.y[:,-1],dense_output=True,rtol=1e-9,atol=2e-12,method='DOP853')
    assert later.success
    direct=[float(later.sol(center)[0]),float(later.sol(center)[1]/expansion(center))]
    if case=='heavy':
        from histories import PROJ
        _,tab=matrices(case,points,1)
        with np.load(PROJ) as source:weights=weights*tab['scale']/float(source['matching_density'])
        held=later.sol(points)
        direct.extend([float(weights@(tab['gravity_mass']*tab['field']*held[2]+tab['velocity']*held[3])),float(weights@(MODE*tab['velocity']*held[2]))])
        direct.append(direct[2]-direct[0])
    expected=json.loads((ROOT/'acoustic.json').read_text())[case]['prefixes'][-1]['added_observable_response']
    difference=np.array(direct)-expected
    assert max(abs(difference)/np.maximum(1,abs(np.array(expected))))<1e-4
    return dict(direct=direct,direct_minus_green=difference.tolist())

def run():
    guard()
    fixture_result=fixture(); validation={'nonlinear_checks':fixture_result,'EdS_Lagrangian_density':dust()}
    acoustic=json.loads((ROOT/'acoustic.json').read_text())
    for case in ('heavy','cold'):
        rows=json.loads((ROOT/(case+'-response.json')).read_text())
        reference=rows[-1];diff=abs(np.subtract(reference['known_part'],rows[-2]['known_part']))
        assert max(diff/np.maximum(1,np.abs(reference['known_part'])))<.001
        assert max(reference['linear_replay_fractional_peak_errors'])<5e-6
        for item in acoustic[case]['prefixes']:
            assert item['meets_primary_gates']
        validation[case]=dict(step_halving_changes=diff.tolist(),direct_acoustic_check=independent_forcing(case),
                               maximum_native_replay_error=max(reference['linear_replay_fractional_peak_errors']))
    primordial=json.loads((ROOT/'primordial.json').read_text())
    assert primordial['relative_gain_difference']<1e-4
    for result in primordial['leading_gradient_control'].values():
        for errors in result['linear_relative_errors'].values():
            assert np.all(np.diff(np.abs(errors))>0) and max(abs(np.array(errors)))<.001
    for path in ROOT.glob('*.py'):ast.parse(path.read_text(encoding='utf8'))
    with (ROOT/'validation.json').open('x',encoding='utf8') as stream:json.dump(validation,stream,indent=2,allow_nan=False)
    print(validation)
if __name__=='__main__':run()
