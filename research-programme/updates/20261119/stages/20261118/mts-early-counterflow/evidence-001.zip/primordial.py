from histories import EARLY, ROOT, MATCH, PRIOR, MODE, np, CubicSpline, guard
import json,sys

def early(case):
    sys.path.insert(0,str(MATCH))
    from matching_common import params_for,camb
    engine=camb.get_background(params_for(EARLY/(case+'.npz')))
    engine.Params.Accuracy.IntTolBoost=6
    times=np.array([.0125,.025,.05,.0918])/MODE
    names=['a','etak','delta_cdm','delta_baryon','v_baryon_cdm','mts_dphi_h','mts_dphidot_h']
    raw=engine.get_time_evolution([MODE],times,vars=names,lAccuracyBoost=4)[0]
    assert min(raw[:,0])>0
    predicted=(MODE*times)**2/4
    errors=dict(cdm=raw[:,2]/predicted-1,baryon=raw[:,3]/predicted-1,flow=raw[:,4]/(MODE*times*predicted/9)-1)
    with np.load(EARLY/(case+'.npz')) as bg:
        if case=='heavy':
            mass=float(bg['heavy_mass_mpc'])
            phi=CubicSpline(bg['heavy_efold'],bg['phi_h'])(np.log(raw[:,0]))
            initial=-phi*(mass*raw[:,0]*times)**2*predicted/105
            errors.update(field=raw[:,5]/initial-1,field_speed=raw[:,6]/(6*initial/times)-1)
    return dict(k_tau=(MODE*times).tolist(),curvature=(-raw[:,1]/MODE).tolist(),linear_relative_errors={key:val.tolist() for key,val in errors.items()})

def run():
    guard()
    prior=json.loads((PRIOR/'initial-state-requirement.json').read_text())
    final={}; vectors=[]
    for case in ['heavy','cold']:
        with np.load(PRIOR/('early-'+case+'.npz')) as bank:
            index=bank['k'].tolist().index(MODE)
            initial=np.argmin(abs(bank['N']+np.log(100)))
            assert abs(bank['N'][initial]+np.log(100))<1e-12 and bank['N'][0]<-np.log(9)<bank['N'][-1]
            density=bank['D'][:,index,initial]; velocity=bank['U'][:,index,initial]
            total=np.average(density,weights=bank['rho0'])
            vectors.extend(np.r_[density,velocity]/total**2)
            final[case]=np.average(CubicSpline(bank['N'],bank['D'][:,index,:],axis=1)(-np.log(9)),weights=bank['rho0'])
    full=2/final['heavy']-2/final['cold']
    row=np.asarray(prior['response_row'])@vectors
    assert abs(full-row)<.002*abs(full)
    gain=3*full/5
    center=-.9; sigma=5.1
    out=dict(leading_gradient_control={case:early(case) for case in ['cold','heavy']},gaussian_geometric_C2_over_C1_leading=-.75,
      native_z8_transfers=final,z99_adiabatic_direction=vectors,Qcontrast_gain_per_zeta2=full,
      older_matter_only_row_gain=row,relative_gain_difference=abs(row/full-1),old_conditional_gap=prior['contrast'],
      gain_per_common_scale_independent_local_fNL=gain,change_in_local_fNL_to_erase_old_contrast=-prior['contrast']/gain,
      illustrative_Planck68_shift=[gain*(center-sigma),gain*(center+sigma)],illustrative_Planck_1sigma_size=gain*sigma,
      reference='https://arxiv.org/abs/1905.05697',scope='Template convention zeta=zeta_G+3 fNL/5*(zeta_G squared minus mean), curvature positive in spatial metric exp(2 zeta). This compares one common primordial direction. Extrapolating a constant to this k and using published CMB calibration are assumptions, not an MTS data likelihood or a bound on all modes.')
    with (ROOT/'primordial.json').open('x',encoding='utf8') as stream: json.dump(out,stream,indent=2,allow_nan=False)
    print(out)
if __name__=='__main__':run()
