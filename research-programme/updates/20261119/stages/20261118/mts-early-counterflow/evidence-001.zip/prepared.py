from response import ROOT, MODE, np, json, guard, field_table
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp

def prepared(case):
    with np.load(ROOT/(case+'-green.npz')) as green:
        grid=green['grid']; rows=green['initial_response'];kernel=green['cell_responses'][:,:,0]
    with np.load(ROOT/(case+'-acoustic.npz')) as packet:
        tau=packet['tau']
    tab=field_table(case,tau)
    initial=tau[0]
    compression=-3*MODE**2*initial**2/16
    rate=2*compression/initial
    matter=[compression,rate]
    if case=='heavy':
        scalar=-tab['field'][0]*tab['gravity_mass'][0]*initial**2*compression/105
        matter.extend([scalar,6*scalar/initial])
    first=np.r_[matter,compression,MODE*initial*compression/9]
    size=len(first)
    hubble=tab['expansion'];rho=tab['dens']
    frac=4*rho['photon']/(3*rho['baryon']+4*rho['photon'])
    acoustic_weight=.5*rho['baryon']+4*rho['photon']/3
    matrix=np.zeros((len(tau),size,size))
    matrix[:,0,1]=1;matrix[:,1,0]=rho['cdm']/2;matrix[:,1,1]=-hubble
    matrix[:,1,-2]=acoustic_weight;matrix[:,-2,1]=1;matrix[:,-2,-1]=-MODE
    matrix[:,-1,-2]=MODE*frac/3;matrix[:,-1,-1]=-(1-frac)*hubble
    if case=='heavy':
        matrix[:,1,2]=-tab['gravity_mass']*tab['field'];matrix[:,1,3]=2*tab['velocity']
        matrix[:,2,3]=1;matrix[:,3,1]=tab['velocity'];matrix[:,3,2]=-MODE**2-tab['gravity_mass'];matrix[:,3,3]=-2*hubble
    coeff=CubicSpline(tau,matrix,axis=0)
    sol=solve_ivp(lambda time,state:coeff(time)@state,(tau[0],tau[-1]),first,t_eval=tau,method='DOP853',rtol=2e-11,atol=1e-15,max_step=.02)
    assert sol.success
    ids=np.flatnonzero(grid[:-1]<tau[-1])
    ends=np.minimum(grid[ids+1],tau[-1]);frac_cell=(ends-grid[ids])/(grid[ids+1]-grid[ids])
    drive=CubicSpline(tau,acoustic_weight*sol.y[-2]/hubble**2)((grid[ids]+ends)/2)
    homogeneous=rows@matter+(drive*frac_cell)@kernel[ids]
    forced=json.loads((ROOT/(case+'-response.json')).read_text())[-1]['known_part']
    acoustic=json.loads((ROOT/'acoustic.json').read_text())[case]['prefixes'][-1]['added_observable_response']
    return dict(regular_initial_matter_and_acoustic=first.tolist(),initial_data_and_acoustic_feedback=homogeneous.tolist(),
                windowed_prepared_result=(homogeneous+forced+acoustic).tolist(),
                label='Leading geometric initial data for zeta2=0, no decaying or isocurvature mode. Tight acoustic external trace only through k*tau=20; omitted sectors and later radiation trace explicitly external. Not the physical completed seed.')
if __name__=='__main__':
    guard()
    out={case:prepared(case) for case in ['heavy','cold']}
    with (ROOT/'prepared.json').open('x',encoding='utf8') as stream:json.dump(out,stream,indent=2,allow_nan=False)
    print(out)
