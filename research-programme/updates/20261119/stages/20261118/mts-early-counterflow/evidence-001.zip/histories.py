from pathlib import Path
import hashlib
import os
import sys

for setting in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[setting]='1'
import numpy as np
from scipy.interpolate import CubicSpline

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
BRANCH=POST/'condensate-origin-20261003'
MATCH=BRANCH/'native-heavy-matching-20261007'
EARLY=BRANCH/'native-two-field-transfer-20261007/runs/backgrounds'
SPEC=BRANCH/'resolved-matter-spectrum-20261007/runs'
PROJ=SPEC/'projection/a225-w6-d8.npz'
RAW=SPEC/'exact-grid/chunk-0368.npz'
PRIOR=POST/'mts-two-mode-response-20261118'
MODE=1.98095677855

def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def guard():
    assert digest(PRIOR/'closeout.json')=='21072dd84f30b8a9c122ce95879c6ea17c2bbc7384af50be6faf453fb4b24a2e'
    assert not any((directory/'STOP-REQUESTED').exists() for directory in (ROOT,POST,PRIOR))

def weights():
    with np.load(RAW) as raw,np.load(PROJ) as source:
        index=raw['modes'].tolist().index(MODE)
        hist=raw['values'][index]; names=raw['names'].tolist()
        scales=hist[:,names.index('a')]
        center=float(source['matching_scale'])
        phase=CubicSpline(source['heavy_efold'],source['phase_h'])
        angle=phase(np.log(scales)); offset=(angle-phase(np.log(center)))/(6*np.pi)
        keep=abs(offset)<1
        pos=offset[keep];ang=angle[keep]
        basis=np.column_stack([pos**power for power in range(9)]+[pos**power*trig(2*ang) for power in range(7) for trig in (np.cos,np.sin)]+[pos**power*trig(4*ang) for power in range(3) for trig in (np.cos,np.sin)])
        return raw['requested_scale'][keep],np.linalg.pinv(basis)[0],center

def acquire(case):
    guard()
    import psutil
    process=psutil.Process();process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS);process.cpu_affinity([process.cpu_affinity()[0]])
    sys.path.insert(0,str(MATCH))
    from matching_common import params_for,camb
    path=EARLY/(case+'.npz')
    engine=camb.get_background(params_for(path));engine.Params.Accuracy.IntTolBoost=6
    scale_knots,weight,center=weights()
    limits=engine.conformal_time(1/np.array([1e-7,scale_knots.max()*1.0001])-1,tol=1e-10)
    times=np.linspace(*limits,32769)
    sample=np.unique(np.r_[times,engine.conformal_time(1/scale_knots-1,tol=1e-10)])
    names=['a','H','delta_cdm','delta_baryon','delta_photon','delta_neutrino','delta_nu','growth','etak','v_baryon_cdm','v_newtonian_cdm','mts_dphi_h','mts_dphidot_h','mts_dphi_s','mts_dphidot_s','mts_drho_h','mts_q_h','mts_match_count','v_photon','pi_photon','v_neutrino']
    values=engine.get_time_evolution([MODE],sample,vars=names,lAccuracyBoost=4)[0]
    assert np.isfinite(values).all() and not np.any(values[:,names.index('mts_match_count')])
    actual=values[:,0];assert actual.min()>0 and np.all(np.diff(actual)>0)
    rho=engine.get_background_densities(actual,['cdm','baryon','photon','neutrino','nu'])
    with (ROOT/(case+'-native.npz')).open('xb') as target:
        np.savez_compressed(target,t=sample,names=names,raw=values,knots=engine.conformal_time(1/scale_knots-1,tol=1e-10),weights=weight,center=center,center_t=engine.conformal_time(1/center-1,tol=1e-10),uniform=times,**{key:val/actual**2 for key,val in rho.items()})
    print(case,'stored',len(sample),flush=True)

if __name__=='__main__':
    for case in sys.argv[1:]:acquire(case)
