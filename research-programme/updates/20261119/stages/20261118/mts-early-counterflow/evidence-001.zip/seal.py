from histories import ROOT, POST, MATCH, SPEC, RAW, EARLY, PRIOR, PROJ, digest, guard
import json
import sys

def read(path):return json.loads(path.read_text(encoding='utf8'))
def run():
    guard()
    lock=ROOT/'closeout.json'
    if lock.exists():
        doc=read(lock)
        for name,value in doc['files'].items():assert digest(ROOT/name)==value,name
        for name,value in doc['inputs'].items():assert digest(POST/name)==value,name
        assert set(doc['files'])=={path.name for path in ROOT.iterdir() if path.is_file() and path!=lock}
        print('verified',len(doc['files']),'files;',len(doc['inputs']),'parent inputs;',digest(lock))
        return
    assert not (ROOT/'__pycache__').exists()
    for name in ('validation.json','prepared.json','acoustic.json','primordial.json','heavy-response.json','cold-response.json','RESULTS.md','EQUATIONS.md'):
        assert (ROOT/name).is_file()
    old=read(PRIOR/'closeout.json')
    locked={}
    def add(path,expected=None):
        actual=digest(path)
        assert expected is None or actual==expected,path
        locked[path.relative_to(POST).as_posix()]=actual
    add(PRIOR/'closeout.json')
    for name in ('early-heavy.npz','early-cold.npz','initial-state-requirement.json','setup_local.py'):
        add(PRIOR/name,old['files'][name])
    for base,path in [(SPEC/'exact-grid',RAW),(SPEC/'projection',PROJ)]:
        receipt=base/'status.json';add(receipt);add(path,read(receipt)['input_hashes'][str(path)])
    native=read(POST/'mts-growth-mode-native-20261118/input-lock.json')['inputs']
    for path in (MATCH/'native/camb/cambdll.dll',MATCH/'native/fortran/equations.f90',MATCH/'native/fortran/MTSTwoField.f90'):
        expected=native.get(str(path)) or read(SPEC/'exact-grid/status.json')['input_hashes'][str(path)]
        add(path,expected)
    for path in (MATCH/'matching_common.py',MATCH/'native/fortran/camb_python.f90',SPEC.parent/'project_grid.py',
                 EARLY/'heavy.npz',EARLY/'cold.npz',ROOT.parent/'MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md'):
        add(path)
    doc=dict(scope='Pre-averaging counterflow and windowed acoustic gravity; no physical late-time seed inferred',inputs=locked,
             files={path.name:digest(path) for path in sorted(ROOT.iterdir()) if path.is_file()})
    with lock.open('x',encoding='utf8') as stream:json.dump(doc,stream,indent=2,allow_nan=False)
    run()
if __name__=='__main__':run()
