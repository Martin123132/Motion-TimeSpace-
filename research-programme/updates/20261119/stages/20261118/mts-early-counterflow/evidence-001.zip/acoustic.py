from response import field_table, run, MU, ROOT, EARLY, MODE, guard, np, json
from histories import MATCH
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
import sys

def optical(case,times):
    sys.path.insert(0,str(MATCH))
    from matching_common import params_for,camb
    native=camb.get_background(params_for(EARLY/(case+'.npz')))
    return native.get_background_time_evolution(times,['opacity'])['opacity']

def trial(case,limits,ratio,sample_count):
    size=4 if case=='heavy' else 2
    with np.load(ROOT/(case+'-native.npz')) as st:
        start=float(st['t'][0])
    tau=np.linspace(start,max(limits),sample_count)
    tab=field_table(case,tau)
    take=tab['val']; den=tab['dens']
    radiation=4*den['photon']/3
    frac=radiation/(den['baryon']+radiation)
    expansion=tab['expansion']; speed=tab['speed']; fluct=tab['fluct']; mass=tab['gravity_mass']
    rate=tab['rate']; shear=tab['shear']; vel=tab['velocity']; field=tab['field']
    cold=tab['cold']; beta=tab['baryon']; flow=tab['drift']; eta=take('etak')/MODE
    betaix=size;pix=size+1; size+=2
    matrix=np.zeros((len(tau),size,size))
    matrix[:,0,1]=1
    matrix[:,1,0]=den['cdm']/2
    matrix[:,1,1]=-expansion
    matrix[:,1,betaix]=.5*den['baryon']+4*den['photon']/3
    if case=='heavy':
        matrix[:,1,2]=-mass*field
        matrix[:,1,3]=2*vel
        matrix[:,2,3]=1
        matrix[:,3,1]=vel
        matrix[:,3,2]=-(MODE**2+mass)
        matrix[:,3,3]=-2*expansion
    matrix[:,betaix,1]=1
    matrix[:,betaix,pix]=-MODE
    matrix[:,pix,betaix]=frac*MODE/3
    matrix[:,pix,pix]=-(1-frac)*expansion
    driving=np.zeros((len(tau),size,2))
    driving[:,1,0]=rate**2/3+(MU**2-1/3)*shear**2+.25*den['cdm']*cold**2
    acoustic_trace=.5*den['baryon']*(.5*beta**2-1.5*MU*flow**2)+den['photon']*(8*beta**2/9-2*MU*flow**2/3)
    driving[:,1,0]+=acoustic_trace
    driving[:,1,1]=tab['external']-.5*den['baryon']*beta-den['photon']*take('delta_photon')
    if case=='heavy':
        driving[:,1,0]+=speed**2-.5*mass*fluct**2
        driving[:,3,0]=rate*speed-2.5*MODE**2*eta*fluct
    driving[:,betaix,0]=MODE*flow*((1+frac/6)*beta-2.5*eta)
    driving[:,pix,0]=.5*rate*flow+frac*MODE/3*(2*beta**2/3+MU*flow**2/2)-.25*MODE*flow**2
    coefficients=CubicSpline(tau,np.concatenate((matrix,driving),axis=2),axis=0)
    def rhs(time,flat):
        coeff=coefficients(time)
        return (coeff[:,:size]@flat.reshape(size,2)+coeff[:,size:]).ravel()
    initial=np.zeros((size,2));initial[:2,1]=[cold[0],rate[0]]
    if case=='heavy':initial[2:4,1]=[fluct[0],speed[0]]
    initial[betaix:,1]=[beta[0],flow[0]]
    sol=solve_ivp(rhs,(start,tau[-1]),initial.ravel(),rtol=2e-10,atol=2e-13,method='DOP853',t_eval=tau,max_step=.04)
    assert sol.success
    result=sol.y.T.reshape(len(tau),size,2)
    native=np.array([beta,flow,take('delta_photon')]).T
    replay=np.column_stack([result[:,betaix,1],result[:,pix,1],4*result[:,betaix,1]/3])
    diff=(matrix[:,1,betaix]*result[:,betaix,0]+acoustic_trace+MU*den['baryon']*flow**2)/expansion**2
    with np.load(ROOT/(case+'-green.npz')) as green:
        grid=green['grid']; kernels=green['cell_responses'][:,:,0]
    midpoint=(grid[1:]+grid[:-1])/2
    data=[]
    for limit,opacity_ratio in zip(limits,ratio):
        mask=tau<=limit
        error=np.max(abs(replay[mask]-native[mask]),axis=0)/np.max(abs(native[mask]),axis=0)
        slip=np.max(abs(flow[mask]-.75*take('v_photon')[mask]))/np.max(abs(flow[mask]))
        entropy=np.max(abs(beta[mask]-.75*take('delta_photon')[mask]))/np.max(abs(beta[mask]))
        eligible=bool(max(error)<.01 and opacity_ratio<=.01)
        ids=np.flatnonzero((grid[:-1]<limit)&(grid[1:]>start))
        lengths=grid[ids+1]-grid[ids]
        ends=np.minimum(grid[ids+1],limit)
        frac_cell=(ends-grid[ids])/lengths
        drive=CubicSpline(tau,diff)((grid[ids]+ends)/2)
        delta=(drive*frac_cell)@kernels[ids]
        data.append(dict(k_tau=float(limit*MODE),max_k_over_opacity=opacity_ratio,linear_errors=error.tolist(),slip_over_peak=slip,entropy_over_peak=entropy,
            meets_primary_gates=eligible,added_observable_response=delta.tolist(),peak_dimensionless_trace_drive=float(max(abs(diff[mask])))))
    return data,dict(tau=tau,combined=result,external_drive=diff,native_linear=native,linear_replay=replay)

def main():
    guard(); output={}
    for case in ('heavy','cold'):
        with np.load(ROOT/(case+'-native.npz')) as st:start=float(st['t'][0])
        times=np.linspace(start,20/MODE,2001)
        opacity=optical(case,times); assert np.all(opacity>0)
        limits=np.array([1,3,10,20])/MODE
        ratios=[float(max(MODE/opacity[times<=end])) for end in limits]
        data,arrays=trial(case,limits,ratios,6001)
        coarse,_=trial(case,limits,ratios,3001)
        changes=[float(max(abs(np.array(left['added_observable_response'])-right['added_observable_response']))) for left,right in zip(data,coarse)]
        output[case]=dict(prefixes=data,drive_sampling_changes=changes)
        with (ROOT/(case+'-acoustic.npz')).open('xb') as stream:np.savez_compressed(stream,**arrays)
        print(case,data,flush=True)
    with (ROOT/'acoustic.json').open('x',encoding='utf8') as stream:json.dump(output,stream,indent=2,allow_nan=False)
if __name__=='__main__':main()
