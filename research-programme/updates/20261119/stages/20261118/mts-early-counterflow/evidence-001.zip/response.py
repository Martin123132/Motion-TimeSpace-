from histories import ROOT, EARLY, PROJ, MODE, guard, np, CubicSpline
import json

MU=-0.5
SOURCES=('matter','baryon_kinetic','unit_external','osc_external','photon_unit','baryon_unit','other_linear','zero')
OBS=('cdm_density','cdm_log_rate_over_H','heavy_density','heavy_covariant_momentum','relative_density')
def field_table(case,tau,thin=1):
    native=np.load(ROOT/(case+'-native.npz'))
    names=native['names'].tolist()
    subset=np.searchsorted(native['t'],native['uniform'][::thin])
    raw=CubicSpline(native['t'][subset],native['raw'][subset],axis=0)(tau)
    val=lambda name:raw[:,names.index(name)]
    scale=val('a'); expansion=val('H')
    dens={name:CubicSpline(native['t'][subset],native[name][subset])(tau) for name in ('cdm','baryon','photon','neutrino','nu')}
    native.close()
    cold=val('delta_cdm'); baryon=val('delta_baryon'); drift=val('v_baryon_cdm')
    part=dens['baryon']/(dens['cdm']+dens['baryon'])
    rate=expansion*val('growth')*((1-part)*cold+part*baryon)+part*MODE*drift
    shear=-expansion*val('v_newtonian_cdm')
    with np.load(EARLY/(case+'.npz')) as bg:
        gravity_mass=(scale*float(bg['heavy_mass_mpc']))**2
        def back(name,coord):
            return CubicSpline(bg[coord],bg[name])(np.log(scale))
        field=back('phi_h','heavy_efold') if case=='heavy' else np.zeros(len(scale))
        velocity=back('phidot_h','heavy_efold') if case=='heavy' else np.zeros(len(scale))
        slow=2*back('phidot_s','efold')*val('mts_dphidot_s')-(scale*float(bg['slow_mass_mpc']))**2*back('phi_s','efold')*val('mts_dphi_s')
    fluct=val('mts_dphi_h'); speed=val('mts_dphidot_h')
    external=.5*dens['baryon']*baryon+dens['photon']*val('delta_photon')+dens['neutrino']*val('delta_neutrino')+dens['nu']*val('delta_nu')+slow
    return locals()

def matrices(case,tau,thin):
    table=field_table(case,tau,thin)
    exp,den,rate,shear,mass,field,vel,fluct,speed,cold=(table[key] for key in ('expansion','dens','rate','shear','gravity_mass','field','velocity','fluct','speed','cold'))
    size=4 if case=='heavy' else 2
    matrix=np.zeros((len(tau),size,size))
    source=np.zeros((len(tau),size,len(SOURCES)))
    matrix[:,0,1]=1
    matrix[:,1,0]=den['cdm']/2
    matrix[:,1,1]=-exp
    source[:,1,0]=rate**2/3+(MU**2-1/3)*shear**2+.25*den['cdm']*cold**2
    source[:,1,1]=-MU*den['baryon']*table['drift']**2
    source[:,1,2]=exp**2
    source[:,1,3]=exp**2*np.cos(MODE*tau)
    source[:,1,4]=den['photon']
    source[:,1,5]=.5*den['baryon']
    source[:,1,6]=table['external']
    if size==4:
        matrix[:,1,2]=-mass*field
        matrix[:,1,3]=2*vel
        matrix[:,2,3]=1
        matrix[:,3,1]=vel
        matrix[:,3,2]=-(MODE**2+mass)
        matrix[:,3,3]=-2*exp
        source[:,1,0]+=speed**2-.5*mass*fluct**2
        source[:,3,0]=rate*speed-2.5*MODE**2*table['val']('etak')/MODE*fluct
    return np.concatenate((matrix,source),axis=2),table

def local_maps(case,grid,thin):
    half=np.diff(grid)[:,None,None]/2
    edge,table=matrices(case,grid,thin)
    mid,_=matrices(case,(grid[:-1]+grid[1:])/2,thin)
    size=edge.shape[1]
    first=edge[:-1]
    second=mid+half*(mid[:,:,:size]@first)
    third=mid+half*(mid[:,:,:size]@second)
    fourth=edge[1:]+2*half*(edge[1:,:,:size]@third)
    maps=half/3*(first+2*second+2*third+fourth)
    maps[:,:,:size]+=np.eye(size)
    return maps,table

def project(case,grid,tab,stash):
    size=4 if case=='heavy' else 2
    points=np.searchsorted(grid,stash['knots']);center=np.searchsorted(grid,stash['center_t'])
    assert np.array_equal(grid[points],stash['knots']) and grid[center]==stash['center_t']
    obs=len(OBS) if size==4 else 2
    read=np.zeros((len(grid),obs,size)); direct=np.zeros(obs)
    read[center,0,0]=1; direct[0]=.5*tab['cold'][center]**2
    read[center,1,1]=1/tab['expansion'][center]
    linear={}
    if size==4:
        with np.load(PROJ) as proj:
            idx=proj['modes'].tolist().index(MODE)
            weight=stash['weights']*tab['scale'][points]/float(proj['matching_density'])
            val=lambda key:tab[key][points]
            read[points,2,2]=weight*val('gravity_mass')*val('field')
            read[points,2,3]=weight*val('velocity')
            direct[2]=weight@(.5*(val('speed')**2+(val('gravity_mass')-MU*MODE**2)*val('fluct')**2))
            read[points,3,2]=weight*MODE*val('velocity')
            direct[3]=weight@(.5*MODE*val('speed')*val('fluct'))
            read[:,4]=read[:,2]-read[:,0];direct[4]=direct[2]-direct[0]
            linear={'density':float(weight@(val('velocity')*val('speed')+val('gravity_mass')*val('field')*val('fluct'))),'current':float(weight@(MODE*val('velocity')*val('fluct'))),'archive':[float(proj[key][idx]) for key in ('matching_delta','matching_momentum')]}
            assert np.max(abs(np.array([linear['density'],linear['current']])-linear['archive']))<2e-5
    return read,direct,linear

def run(case,steps,thin,retain):
    with np.load(ROOT/(case+'-native.npz')) as stash:
        grid=np.unique(np.r_[np.linspace(stash['uniform'][0],stash['uniform'][-1],steps+1),stash['knots'],stash['center_t']])
        maps,table=local_maps(case,grid,thin)
        read,direct,linproj=project(case,grid,table,stash)
    size=read.shape[-1]; count=read.shape[1]
    forward=np.zeros((size,len(SOURCES)))
    forward[:2,6]=[table['cold'][0],table['rate'][0]]
    if size==4:forward[2:,6]=[table['fluct'][0],table['speed'][0]]
    history=np.zeros((len(grid),size))
    history[0]=forward[:,6]
    answers=read[0]@forward
    for step,local in enumerate(maps):
        forward=local[:,:size]@forward+local[:,size:]
        history[step+1]=forward[:,6]
        answers+=read[step+1]@forward
    kernel=np.zeros((len(grid)-1,count,4))
    adjoint=read[-1].copy()
    for step in reversed(range(len(maps))):
        kernel[step]=adjoint@maps[step,:,size+2:size+6]
        adjoint=adjoint@maps[step,:,:size]+read[step]
    np.testing.assert_allclose(kernel.sum(axis=0),answers[:,2:6],atol=3e-8,rtol=1e-7)
    physical=answers[:,0]+answers[:,1]+direct
    target=np.stack([table[name] for name in (['cold','rate','fluct','speed'] if size==4 else ['cold','rate'])],axis=1)
    error=np.max(abs(history-target),axis=0)/np.max(abs(target),axis=0)
    if retain:
        with (ROOT/(case+'-green.npz')).open('xb') as handle:
            np.savez_compressed(handle,grid=grid,scale=table['scale'],cell_responses=kernel,initial_response=adjoint,linear_check=history,linear_native=target,
               readout=OBS[:count],cell_drives=['Hconformal^2','Hconformal^2 cos(k tau)','8piG a^2 rho_photon','4piG a^2 rho_baryon'])
    return dict(case=case,steps=steps,input_thin=thin,observables=OBS[:count],known_part=physical.tolist(),direct_product=direct.tolist(),evolved_matter=answers[:,0].tolist(),baryon_kinetic=answers[:,1].tolist(),
                constant_source_gain=answers[:,2].tolist(),largest_cellwise_bounded_response=np.sum(abs(kernel[:,:,0]),axis=0).tolist(),
                photon_density_gain_L1=np.sum(abs(kernel[:,:,2]),axis=0).tolist(),baryon_rest_density_gain_L1=np.sum(abs(kernel[:,:,3]),axis=0).tolist(),
                initial_rows=adjoint.tolist(),linear_replay_fractional_peak_errors=error.tolist(),linear_projection=linproj)

def main():
    guard()
    for case in ('heavy','cold'):
        results=[run(case,steps,thin,retain) for steps,thin,retain in [(16384,1,False),(32768,2,False),(32768,1,False),(65536,1,True)]]
        with (ROOT/(case+'-response.json')).open('x',encoding='utf8') as stream:json.dump(results,stream,indent=2,allow_nan=False)
        print(case,results[-1],flush=True)

if __name__=='__main__':main()
