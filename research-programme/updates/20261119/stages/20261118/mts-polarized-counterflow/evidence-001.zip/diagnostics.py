from common_local import *
from linear_tail import FullTrack
from scipy.integrate import cumulative_simpson
from scipy.interpolate import CubicSpline
from angular import MU

def analyze(tag,case):
    track=FullTrack(case);prefix=tag+'-'+case
    with np.load(ROOT/(prefix+'.npz')) as data:
        t=data['times'];state=data['states'];report=data['report']
    opts=load(ROOT/(prefix+'.json'))
    prim=load(PRIOR/'restart.json')['cases'][case]['regular']['quadratic_tide']
    with np.load(PRIOR/('restart-'+case+'.npz')) as old:
        tau0=old['tau'];eta0=(-5.625+3)/4+(prim-3/8)*(MODE*tau0[0])**2/6
        eta2=eta0+cumulative_simpson((old['diagnostics'][:,8]+old['core'][:,1])/3,x=tau0,initial=0.)
        initial=eta2[tau0.tolist().index(t[0])]
    beta,v=track.photons(t)[:,2:4].T
    sc,hub,cdm,bary,phot,rel,nu,dc,rate,betan,vn,shear,eta,field,vel,ma,fluct,speed=track.physics(t).T
    eta2=initial+cumulative_simpson((state[:,1]+report[:,2])/3,x=t,initial=0.)
    ricci=MODE**2*(3*dc**2/8-9*dc*eta/4-45*eta**2/8-4*eta2)
    lhs=ricci-4*hub*state[:,1]+2*rate**2/3-(MU**2-1/3)*shear**2
    rhs=2*report[:,4]
    denom=abs(ricci)+4*hub*abs(state[:,1])+2*rate**2/3+abs(MU**2-1/3)*shear**2+abs(rhs)
    native=track.native(t)[:,:3];rad_error=np.max(abs(native-report[:,9:12]),axis=0)/np.max(abs(native),axis=0)
    stats=dict(start=opts['start'],end=float(t[-1]*MODE),number_steps=len(t)-1,
               collision_momentum_absolute=float(max(abs(report[:,5]))),photon_energy_rhs_absolute=float(max(abs(report[:,6]))),
               Hamiltonian_residual_over_peak=float(max(abs(lhs-rhs))/max(denom)),peak_local_Hamiltonian_residual=float(max(abs(lhs-rhs)/np.maximum(MODE**2,denom))),
               native_neutrino_checks=rad_error.tolist())
    with np.load(OLD/(case+'-green.npz')) as green:
        grid=green['grid'];rows=green['cell_responses'][:,:,0]
    with np.load(PRIOR/('restart-'+case+'.npz')) as packet:
        oldtime=packet['tau'];oldext=packet['diagnostics'][:,2];incoming=packet['core'][oldtime.tolist().index(grid[0]),:4 if case=='heavy' else 2]
    with np.load(OLD/(case+'-green.npz')) as green:
        base=np.array(load(OLD/(case+'-response.json'))[-1]['known_part'])+green['initial_response']@incoming
    def drive(first,last,fn):
        ids=np.flatnonzero((grid[:-1]<last)&(grid[1:]>first))
        left=np.maximum(grid[ids],first);right=np.minimum(grid[ids+1],last)
        return ((right-left)/(grid[ids+1]-grid[ids])*fn((left+right)/2))@rows[ids]
    base+=drive(grid[0],t[0],CubicSpline(oldtime,oldext))
    external=report[:,3]+MU*bary*(vn**2-v**2)/hub**2
    spline=CubicSpline(t,external)
    stats['windowed']={str(x):(base+drive(t[0],x/MODE,spline)).tolist() for x in [20,30,40,60,80,100,120,140,160] if t[0]<=x/MODE<=t[-1]}
    stats['windowed_end']=(base+drive(t[0],t[-1],spline)).tolist()
    if t[-1]>=track.end-1e-12:
        center=track.center;points=track.knots;centerstate=CubicSpline(t,state)(center)
        tab=track.physics(np.r_[center,points]);direct=[float(centerstate[0]+tab[0,7]**2/2),float(centerstate[1]/tab[0,1])]
        if case=='heavy':
            with np.load(OLD/(case+'-native.npz')) as old:
                weights=old['weights']
            from histories import PROJ
            with np.load(PROJ) as norm:weights=weights*tab[1:,0]/float(norm['matching_density'])
            states=CubicSpline(t,state)(points)
            ma,field0,speed0,f1,s1=tab[1:,15],tab[1:,13],tab[1:,14],tab[1:,16],tab[1:,17]
            d=weights@(ma*field0*states[:,2]+speed0*states[:,3]+.5*(s1**2+(ma-MU*MODE**2)*f1**2))
            q=weights@(MODE*(speed0*states[:,2]+s1*f1/2))
            direct.extend([d,q,d-direct[0]])
        stats['matching_direct']=direct
        stats['Green_minus_direct']=(np.array(stats['windowed_end'])-direct).tolist()
    return stats

if __name__=='__main__':
    for name in sys.argv[1:]:
        for case in ('heavy','cold'):
            if (ROOT/(name+'-'+case+'.npz')).exists():print(name,case,analyze(name,case))

