from pathlib import Path
import sys,os,json
for setting in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):os.environ[setting]='1'
ROOT=Path(__file__).resolve().parent
PRIOR=ROOT.parent/'mts-streaming-counterflow-20261118'
sys.path.insert(0,str(PRIOR))
from bank import OLD,MODE,MATCH,EARLY,np,CubicSpline,digest
from angular import MU
def guard():
    assert digest(PRIOR/'closeout.json')=='fdaf1726da80da25839d069db250c4a72de9e3f8961107dd80cb99edc32df978'
    assert not any((directory/'STOP-REQUESTED').exists() for directory in (ROOT,ROOT.parent,PRIOR,OLD))
def load(path):return json.loads(path.read_text(encoding='utf8'))
def save(name,val):
    with (ROOT/name).open('x',encoding='utf8') as stream:json.dump(val,stream,indent=2,allow_nan=False)
def store(name,**arrays):
    with (ROOT/name).open('xb') as stream:np.savez_compressed(stream,**arrays)
class Track:
    def __init__(self,case):
        with np.load(OLD/(case+'-native.npz')) as bank,np.load(EARLY/(case+'.npz')) as bg:
            times=bank['uniform'];idcs=np.searchsorted(bank['t'],times)
            names=bank['names'].tolist();raw=bank['raw'][idcs];val=lambda name:raw[:,names.index(name)]
            scale=val('a');hub=val('H');cold,bary,phot,rel,nu=(bank[key][idcs] for key in ('cdm','baryon','photon','neutrino','nu'))
            frac=bary/(bary+cold);dens=val('delta_cdm');beta=val('delta_baryon');flow=val('v_baryon_cdm')
            rate=hub*val('growth')*((1-frac)*dens+frac*beta)+frac*MODE*flow
            field=CubicSpline(bg['heavy_efold'],bg['phi_h'])(np.log(scale)) if case=='heavy' else np.zeros(len(scale))
            vel=CubicSpline(bg['heavy_efold'],bg['phidot_h'])(np.log(scale)) if case=='heavy' else np.zeros(len(scale))
            mass2=(float(bg['heavy_mass_mpc'])*scale)**2
            self.center=float(bank['center_t']);self.knots=bank['knots']; self.end=float(times[-1])
            self.physics=CubicSpline(times,np.stack([scale,hub,cold,bary,phot,rel,nu,dens,rate,beta,flow,-hub*val('v_newtonian_cdm'),val('etak')/MODE,field,vel,mass2,val('mts_dphi_h'),val('mts_dphidot_h')],axis=1),axis=0,extrapolate=False)
            self.native=CubicSpline(times,np.stack([val(name) for name in ('delta_neutrino','v_neutrino','delta_nu','delta_photon','v_photon','pi_photon')],axis=1),axis=0,extrapolate=False)
        with np.load(PRIOR/(case+'-thomson.npz')) as saved:
            self.photons=CubicSpline(saved['times'],np.c_[saved['sources'][:,-2:],saved['full_hierarchy']],axis=0,extrapolate=False)
        with np.load(PRIOR/(case+'-sources.npz')) as early:self.nu_mass=float(early['mass'])
        self.case=case

