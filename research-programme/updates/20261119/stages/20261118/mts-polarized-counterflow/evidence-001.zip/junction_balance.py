from common_local import *
from linear_tail import FullTrack
from histories import PROJ
from scipy.interpolate import CubicHermiteSpline

def transfer(tag, case, subdivisions=3, centres=65):
    track=FullTrack(case)
    with np.load(ROOT/(tag+'-'+case+'.npz')) as data:
        times=data['times'];state=data['states']
    field=CubicHermiteSpline(times,state[:,2],state[:,3],extrapolate=False)
    metric=CubicSpline(times,state[:,:2],axis=0,extrapolate=False)
    with np.load(PROJ) as bank:
        last_scale=float(bank['matching_scale']);normal=float(bank['matching_density'])
    with np.load(EARLY/'heavy.npz') as bank:
        phase=CubicSpline(bank['heavy_efold'],bank['phase_h'])
    def geom(time):return track.physics(time)
    phase_to_time=CubicSpline(phase(np.log(geom(times)[:,0])),times,extrapolate=False)
    anchor=np.log([.00015,.00018,.00020,last_scale])
    scale=np.unique(np.r_[np.linspace(anchor[0],anchor[-1],centres),anchor])
    centre=phase_to_time(phase(scale))
    half=6*np.pi
    coord=np.linspace(-1,1,1001)
    def projector(logscale):
        angle=phase(logscale)+half*coord
        lower_angle,upper_angle=phase(np.log(geom(times[[0,-1]])[:,0]))
        assert angle[0]>=lower_angle-1e-6 and angle[-1]<=upper_angle+1e-6,(case,angle[-1]-upper_angle)
        angle=np.clip(angle,lower_angle,upper_angle)
        t=phase_to_time(angle)
        poly=np.column_stack([coord**degree for degree in range(9)]+[coord**degree*trig(harm*angle) for harm,limit in [(2,6),(4,3)] for degree in range(limit+1) for trig in (np.sin,np.cos)])
        coeff=np.linalg.pinv(poly)
        middle=phase(logscale)
        dphi=phase_to_time(middle,1);ddphi=phase_to_time(middle,2)
        return t,coeff[0],coeff[1]/(half*dphi),2*coeff[2]/(half*dphi)**2-coeff[1]*ddphi/(half*dphi**3)
    def components(t):
        a,hub,_,_,_,_,_,d1,rate,_,_,_,eta,f0,p0,ma,f1,p1=geom(t).T
        c2,cp=metric(t).T
        f2=field(t);p2=field(t,1)
        energy0=.5*(p0*p0+ma*f0*f0);energy1=p0*p1+ma*f0*f1
        energy=p0*p2+ma*f0*f2+.5*(p1*p1+(ma-MU*MODE**2)*f1*f1)
        lag=p0*p2-ma*f0*f2+.5*(p1*p1-(ma-MU*MODE**2)*f1*f1)
        weight=a/normal
        grad=weight*MODE**2*f1*f1
        longstress=weight*lag-grad/4;pressure=weight*lag-MU*grad/3
        q1=weight*MODE*p0*f1;moment=weight*MODE*(p0*f2+.5*p1*f1)
        factor=a/last_scale
        densities=np.column_stack([weight*energy,factor*moment,c2+.5*d1*d1])
        sources=np.column_stack([-3*hub*pressure,-MODE*moment,weight*cp*p0**2,2*weight*rate*p0*p1,-2.5*MODE*eta*q1,
                                factor*MODE*longstress,.5*factor*rate*q1,cp,d1*rate])
        return densities,sources,(energy0,energy1,energy,weight,q1,rate,cp,eta,ma)
    lower=projector(scale[0])[0][0];upper=projector(scale[-1])[0][-1]
    nodes=np.unique(np.r_[lower,times[(times>lower)&(times<upper)],upper])
    sub=np.r_[(nodes[:-1,None]+np.diff(nodes)[:,None]*np.arange(subdivisions)/subdivisions).ravel(),nodes[-1]]
    primitive=CubicSpline(sub,components(sub)[1],axis=0).antiderivative()
    table=[];rates=[]
    for logscale,time in zip(scale,centre):
        t,w,wd,wdd=projector(logscale);density,source,extra=components(t)
        mean=w@density; cumulative=w@primitive(t)
        energy0,energy1,energy,weight,q1,rate,cp,eta,ma=extra
        phys=geom(time);ac,hc,mc=phys[0],phys[1],phys[15];wm=ac/normal
        gradnr=0 if case=='cold' else ((w@q1)**2+MODE**2*(w@(weight*energy1))**2/(4*mc))/(w@(weight*energy0))
        lag=wm/4*((wdd@(energy/ma))+2*hc*(wd@(energy/ma))-(w@rate)*(wd@(energy1/ma))-(w@cp)*(wd@(energy0/ma))
                    +MODE**2*(w@(energy/ma)+2.5*(w@eta)*(w@(energy1/ma))))
        estimated=(ac/last_scale)*MODE*(lag-gradnr/4)
        rates.append([*(w@source)[5:7],estimated])
        table.append(np.r_[mean,cumulative])
    rows=np.array(table);rates=np.array(rates)
    envelope=CubicSpline(centre,rates,axis=0).antiderivative()(centre)
    indices=[int(np.flatnonzero(scale==a)[0]) for a in anchor]
    def interval(first,second):
        dl=rows[second]-rows[first];work=dl[3:]
        p_effect,shear,closure=(envelope[second]-envelope[first])
        return dict(scale_from=float(np.exp(scale[first])),scale_to=float(np.exp(scale[second])),
                    delta_density=dl[0],density_work=work[:5].tolist(),density_residual=dl[0]-sum(work[:5]),
                    delta_weighted_momentum=dl[1],stress_impulse=work[5],geometry_impulse=work[6],
                    momentum_residual=dl[1]-work[5]-work[6],momentum_residual_without_stress=dl[1]-work[6],
                    delta_cdm_contrast=dl[2],cold_work=work[7:].tolist(),cdm_residual=dl[2]-sum(work[7:]),
                    projected_stress_impulse=p_effect,coherent_closure_impulse=closure,
                    projected_work=shear,propagated_direct_stress_momentum_error=p_effect+shear-dl[1],
                    propagated_closure_momentum_error=closure+shear-dl[1],stress_approximation_impulse_error=closure-p_effect)
    return [interval(i,j) for i,j in list(zip(indices[:-1],indices[1:]))+[(indices[0],indices[-1])]]

if __name__=='__main__':
    guard()
    for tag in sys.argv[1:]:
        fine={case:transfer(tag,case) for case in ('heavy','cold')}
        control={case:transfer(tag,case,2,33) for case in ('heavy','cold')}
        save('junction-'+tag+'.json',dict(fine=fine,sampling_control=control))
        for case in fine:print(tag,case,fine[case][-1])

