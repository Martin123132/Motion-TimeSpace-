from common_local import *
from diagnostics import analyze
from screen_check import test
from photon_source import PhotonSource
from linear_tail import FullTrack

def diagnostics():
    guard()
    cases=['heavy','cold']; result={}; gates={}
    tests=['overlap10','overlap20','full','refined','late-start','no-xe','thermal-gas','photon8']
    runs={case:{tag:analyze(tag,case) for tag in tests} for case in cases}
    result['runs']=runs;result['screen_tensor_finite_difference']=test()
    for case in cases:
        measures=runs[case];track=FullTrack(case)
        with np.load(ROOT/(case+'-native-angular-control.npz')) as native,np.load(ROOT/('full-'+case+'.npz')) as base:
            t=base['times'];idx=np.searchsorted(native['times'],t);native_names=native['names'].tolist()
            reported=base['report'][:,9:12];old=native['usual'][idx];new=native['resolved'][idx]
            assert np.array_equal(native['times'][idx],t)
            peaks=np.maximum(1e-40,np.max(abs(new),axis=0))
            drift=dict(zip(native_names,(np.max(abs(new-old),axis=0)/peaks).tolist()))
            resolved=np.max(abs(new[:,5:8]-reported),axis=0)/peaks[5:8]
        wave=track.photons(t)
        with np.load(ROOT/(case+'-ionization.npz')) as saved:
            extra=CubicSpline(saved['times'],saved['values'])(t)
            deriv=float(saved['background_derivative_fraction'])
        angular=PhotonSource(track,12); standard=angular.evaluate(t,extra=extra)
        coarse=PhotonSource(track,12,coarse=True).evaluate(t,extra=extra)
        geometry_error=float(np.max(abs(standard[0]-coarse[0])))
        collision_error=float(np.max(abs(standard[1]-coarse[1])))
        pole_factor=(2*np.arange(13)+1)*(-1j)**np.arange(13)
        pole_error=float(np.max(abs(wave[:,-13:]@pole_factor)))
        gates[case+'_protocol_exchange']=all(max(meas['collision_momentum_absolute'],meas['photon_energy_rhs_absolute'])<1e-8 for meas in measures.values())
        gates[case+'_native_hierarchy']=max(resolved)<5e-5
        gates[case+'_hamiltonian_diagnostic']=max(m['Hamiltonian_residual_over_peak'] for m in measures.values())<2e-4
        gates[case+'_same_window']=abs(measures['refined']['end']-measures['full']['end'])<1e-12
        gates[case+'_ionization_shape']=deriv<.015
        gates[case+'_physical_angular_sources']=max(geometry_error,collision_error)<1e-7
        gates[case+'_retarded_comparison']=max(abs(np.array(measures['refined']['Green_minus_direct'])))<.001
        comparison={name:(np.array(measures[name]['matching_direct'])-measures['full']['matching_direct']).tolist() for name in tests[3:]}
        result[case]=dict(native_stream_difference_over_peak=resolved.tolist(),native_changes_over_peak=drift,
            geometry_coarse_difference=geometry_error,collision_coarse_difference=collision_error,polarization_pole_residual=pole_error,
            ionization_background_error=deriv,MTS_or_control_minus_own_full=comparison)
        with np.load(ROOT/('refined-'+case+'.npz')) as saved:
            gates[case+'_restart_arrays']=all(np.isfinite(saved['radiation_'+k]).all() and np.isfinite(saved['matter_'+k]).all() for k in ['10.0','20.0','40.0','60.0','80.0','120.0','160.0',str(round(float(saved['times'][-1])*MODE,6))])
        for name in ('full','refined'):
            impulse=load(ROOT/('junction-'+name+'.json'))['fine'][case]
            envelope=load(ROOT/('averaged-'+name+'.json'))[case]
            approx=np.array([row['difference'] for row in envelope['65:1']]);bare=np.array(envelope['65:-1'][-1]['difference'])
            gates[name+'_'+case+'_dust_energy']=max(abs(row['cdm_residual']) for row in impulse)<1e-5
            if case=='heavy':
                gates[name+'_stress_needed']=abs(impulse[-1]['momentum_residual_without_stress'])>100*abs(impulse[-1]['momentum_residual'])
                gates[name+'_density_and_momentum_transfer']=abs(approx[-1,0])<.01*abs(bare[0]) and abs(approx[-1,1])<.01*abs(bare[1])
            else:gates[name+'_cold_scalar_null']=np.max(abs(approx[:,[0,1,3,4]]))==0 and np.max(abs(approx[:,2]))<.0001
    gates['screen_projection']=max(result['screen_tensor_finite_difference'])<1e-8
    result['checks']={name:bool(value) for name,value in gates.items()}
    return result
if __name__=='__main__':
    checks=diagnostics()
    print('checks',checks['checks'])
    print('source checks',[(case,checks[case]['geometry_coarse_difference'],checks[case]['collision_coarse_difference']) for case in ('heavy','cold')])
    assert all(checks['checks'].values())
    if '--record' in sys.argv:save('validation.json',checks)

