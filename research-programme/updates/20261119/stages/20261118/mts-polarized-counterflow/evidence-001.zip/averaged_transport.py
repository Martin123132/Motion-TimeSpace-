from common_local import *
from linear_tail import FullTrack
from histories import PROJ
from scipy.interpolate import CubicHermiteSpline
from scipy.integrate import solve_ivp

def run(tag,case,centres,order):
    track=FullTrack(case)
    with np.load(ROOT/(tag+'-'+case+'.npz')) as data:
        times=data['times'];st=data['states']
    with np.load(PROJ) as src:
        last=float(src['matching_scale']);norm=float(src['matching_density'])
    with np.load(EARLY/'heavy.npz') as bg:
        phase=CubicSpline(bg['heavy_efold'],bg['phase_h'])
    ref=track.physics(times)[:,0];angle_grid=phase(np.log(ref));inv=CubicSpline(angle_grid,times,extrapolate=False)
    exp=CubicSpline(times,st[:,1],extrapolate=False);logcdm=CubicSpline(times,st[:,0],extrapolate=False)
    field=CubicHermiteSpline(times,st[:,2],st[:,3],extrapolate=False)
    anchors=np.log([.00015,.00018,.0002,last]);grid=np.unique(np.r_[np.linspace(*anchors[[0,-1]],centres),anchors])
    clock=inv(phase(grid));old=np.linspace(-1,1,1001)
    drivers=[];target={}
    for knot,tc in zip(grid,clock):
        theta=phase(knot)+6*np.pi*old
        assert theta[0]>=angle_grid[0]-1e-6 and theta[-1]<=angle_grid[-1]+1e-6
        t=inv(np.clip(theta,angle_grid[0],angle_grid[-1]))
        reg=np.column_stack([old**deg for deg in range(9)]+[old**deg*fn(h*theta) for h,top in ((2,6),(4,3)) for deg in range(top+1) for fn in (np.sin,np.cos)])
        w=np.linalg.pinv(reg)[0]
        a,hub,_,_,_,_,_,dc,rate,_,_,_,eta,f0,p0,ma,f1,p1=track.physics(t).T
        factor=a/norm;cp=exp(t);q1=factor*MODE*p0*f1
        e0=(p0**2+ma*f0**2)/2;e1=p0*p1+ma*f0*f1
        work=factor*(cp*p0**2+2*rate*p0*p1)-2.5*MODE*eta*q1
        drivers.append([w@work,.5*w@(rate*q1),w@(factor*e0),w@(factor*e1),w@q1,w@rate,w@cp,w@eta,w@(cp+dc*rate)])
        if knot in anchors:
            f2=field(t);p2=field(t,1)
            e=p0*p2+ma*f0*f2+.5*(p1**2+(ma-MU*MODE**2)*f1**2)
            lag=p0*p2-ma*f0*f2+.5*(p1**2-(ma-MU*MODE**2)*f1**2)
            grad=MODE**2*f1**2
            target[float(tc)]=[w@(factor*e),w@(factor*MODE*(p0*f2+.5*p1*f1)),w@(logcdm(t)+dc**2/2),w@(factor*(lag-grad/4)),w@(factor*(lag-MU*grad/3))]
    forces=CubicSpline(clock,drivers,axis=0,extrapolate=False)
    true_times=np.array(list(target)); start=target[clock[0]][:3]
    def evaluate(t,y):
        density,moment,cdm=y
        work,geometry,d0,d1,q1,rate,cp,eta,cforce=forces(t)
        workp,_,d0p,d1p,*_=forces(t,1)
        phys=track.physics(t);hub,ma=phys[1],phys[15];hubp=track.physics(t,1)[1]
        gradient=0 if case=='cold' else (q1**2+MODE**2*d1**2/(4*ma))/d0
        lag=MODE**2*(density+2.5*eta*d1)/(4*ma)
        if order==1:
            temporal=MODE*(hub*moment-geometry)+workp-4*hub*(work-MODE*moment)+(3*hub**2-3*hubp)*density
            metric=-rate*(d1p-3*hub*d1)-cp*(d0p-3*hub*d0)
            lag=(4*ma*lag+temporal+metric+MODE**2*gradient/4)/(4*ma+MODE**2)
        long=lag-gradient/4
        pressure=lag-MU*gradient/3
        if order==-1:long=pressure=0
        return np.array([-3*hub*pressure-MODE*moment+work,MODE*long+geometry-hub*moment,cforce]),long,pressure
    sol=solve_ivp(lambda t,y:evaluate(t,y)[0],(clock[0],clock[-1]),start,t_eval=true_times,method='DOP853',
                  rtol=5e-11,atol=2e-12,max_step=(clock[-1]-clock[0])/180)
    assert sol.success
    out=[]
    for t,point in zip(true_times,sol.y.T):
        observed=np.array(target[t]);predicted=np.r_[point,evaluate(t,point)[1:]]
        out.append(dict(scale_factor=float(track.physics(t)[0]),reference=observed.tolist(),propagated=predicted.tolist(),difference=(predicted-observed).tolist()))
    return out

if __name__=='__main__':
    guard()
    for tag in sys.argv[1:]:
        rows={case:{str(n)+':'+str(order):run(tag,case,n,order) for n,order in [(33,1),(65,1),(65,0),(65,-1)]} for case in ('heavy','cold')}
        save('averaged-'+tag+'.json',rows)
        for case,tests in rows.items():
            for opt,val in tests.items():print(tag,case,opt,np.round(val[-1]['difference'],8))

