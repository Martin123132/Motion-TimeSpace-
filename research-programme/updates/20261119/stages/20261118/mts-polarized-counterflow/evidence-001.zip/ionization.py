from common_local import *
from linear_tail import FullTrack
from scipy.constants import h,k as boltzmann,c
def run(case):
    sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    track=FullTrack(case)
    par=params_for(EARLY/(case+'.npz'))
    native=camb.get_background(par)
    times=np.linspace(1/MODE,track.end,4201);scale=track.physics(times)[:,0]
    therm=native.get_background_time_evolution(times,['x_e','T_b'])
    electrons=therm['x_e'];temp=par.TCMB/scale
    assert min(1/scale-1)>3500
    helium=(max(electrons)-1)/2
    fraction=(electrons-1-helium)/helium
    bounded=np.clip(fraction,0,1);ratio=helium*bounded*(1-bounded)/electrons
    factor=ratio/(1+ratio);red=1/scale-1
    factor[(red<5000)|(red>8000)]=0
    energy=1.5+(h*c*4.389088863e7/boltzmann)/temp
    wave=track.photons(times)
    delta=factor*(energy*wave[:,4]/4-wave[:,2])
    mid=(bounded>.01)&(bounded<.99)
    derivative=np.gradient(np.log(electrons),np.log(scale))
    error=float(max(abs(derivative[mid]-factor[mid]*(3-energy[mid])))/max(abs(derivative[mid])))
    assert error<.015 and np.isfinite(delta).all()
    store(case+'-ionization.npz',times=times,values=delta,electrons=electrons,thermal_factor=factor,energy=energy,
          helium_by_number=helium,background_derivative_fraction=error,range_excursion=max(np.max(fraction-1),-np.min(fraction)))
    print(case,helium,error,max(abs(delta)))
if __name__=='__main__':
    guard()
    for label in ('heavy','cold'):run(label)
