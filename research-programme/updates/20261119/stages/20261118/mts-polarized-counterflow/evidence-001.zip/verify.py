from common_local import *
from validation import diagnostics

def collect_inputs():
    previous=load(PRIOR/'closeout.json')
    inputs={PRIOR.name+'/closeout.json':digest(PRIOR/'closeout.json')}
    for key,val in previous['files'].items():
        inputs[PRIOR.name+'/'+key]=val
    inputs.update(previous['inputs'])
    for key,val in inputs.items():
        assert digest(ROOT.parent/key)==val,key
    return inputs

def verify_state():
    measured=load(ROOT/'validation.json');assert all(measured['checks'].values())
    assert diagnostics()==measured
    count=0
    for tag in ('full','refined'):
        new=load(ROOT/('coherent-work-'+tag+'.json'))
        first=load(ROOT/('coupled-'+tag+'.json'))
        for case in ('heavy','cold'):
            result=new[case]['65']
            for key in ('full','no_stress'):assert result[key]==first[case]['65'][key]
            true=result['coherent_work'][-1]['reference'];error=np.array(result['coherent_work'][-1]['difference'])
            miss=np.array(result['no_stress'][-1]['difference'])
            corr=result['covariance'];sampling=np.array(new[case]['33']['coherent_work'][-1]['propagated'])-result['coherent_work'][-1]['propagated']
            assert max(abs(sampling))<.003
            if case=='heavy':
                assert max(abs(error[:2]/true[:2]))<.001
                assert np.all(abs(error[:2])<.01*abs(miss[:2]))
                assert abs(corr['predicted_integral']/corr['signed_integral']-1)<.002
                assert max(abs(np.subtract(corr['measured'],corr['from_envelope'])))<.002*corr['peak']
                assert np.max(abs(np.array([row['difference'] for row in result['coherent_work']])[:,0]))<.01
            else:
                assert result['coherent_work']==result['no_stress'] and np.max(abs(error))<.0001
            assert len(result['coherent_work'])==4
            count+=1
    receipt=load(ROOT/'junction-restart-check.json')
    for case,info in receipt.items():
        assert info['exact_terminal_replay'] and info['replayed_cells']>1000 and info['report_reprojection']<1e-12
        with np.load(ROOT/('matching-restart-'+case+'.npz')) as packet,np.load(ROOT/('refined-'+case+'.npz')) as reference:
            pos=int(np.flatnonzero(reference['times']==packet['coordinate_time'])[0])
            assert np.array_equal(reference['states'][pos],packet['exact_coordinate_core'])
            assert packet['exact_angular_rays'].shape==packet['phase_smoothed_angular_rays'].shape==(3,37,144)
            checked=packet['cubic_kernel']@reference['report'][packet['cell_indices']]
            assert max(abs(packet['phase_smoothed_report']-checked))<1e-12
            assert np.isfinite(packet['exact_angular_rays']).all() and np.isfinite(packet['phase_smoothed_angular_rays']).all()
    return dict(paired_cases=count,frozen_and_diagnostic_checks=len(measured['checks']),matching_packets=len(receipt))

def run():
    guard()
    files={p.name:digest(p) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='closeout.json'}
    assert not any(p.is_dir() for p in ROOT.iterdir())
    for path in ROOT.glob('*.py'):compile(path.read_text(encoding='utf8'),path.name,'exec')
    for path in ROOT.glob('*.json'):load(path)
    for path in ROOT.glob('*.npz'):
        with np.load(path,allow_pickle=False) as archive:
            for name in archive.files:
                array=archive[name]
                if np.issubdtype(array.dtype,np.number):assert np.isfinite(array).all(),(path,name)
    stamp=dict(files=files,inputs=collect_inputs(),verified=verify_state(),
               scope='Retained two-wave heavy and cold pre-averaging histories; early elastic scattering and conditional nonlinear stress-transfer overlap. No observational fit or gauge substitution.')
    if '--seal' in sys.argv:save('closeout.json',stamp)
    assert load(ROOT/'closeout.json')==stamp
    print(len(files),'files;',len(stamp['inputs']),'inputs;',stamp['verified'],'closeout SHA256',digest(ROOT/'closeout.json'))
if __name__=='__main__':run()

