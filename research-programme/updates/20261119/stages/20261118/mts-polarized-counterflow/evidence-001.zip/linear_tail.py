from common_local import *
from scipy.integrate import solve_ivp
def extend(case):
    from matching_common import camb,params_for
    track=Track(case);t=np.linspace(track.center,track.end,65)
    native=camb.get_background(params_for(EARLY/(case+'.npz')))
    therm=native.get_background_time_evolution(t,['opacity','cs2b'])
    opacity=CubicSpline(t,therm['opacity']);pressure=CubicSpline(t,therm['cs2b'])
    raw=track.photons(t[0]);state=raw[2:];maximum=12
    def rhs(time,state):
        scale,hub,cold,bary,phot,rel,nu,dens,rate,beta,flow,shear,*_=track.physics(time)
        kappa=opacity(time);loading=3*bary/(4*phot)
        answer=np.zeros_like(state);delta,move=state[:2]
        answer[0]=rate-MODE*move
        answer[1]=-hub*move+MODE*pressure(time)*delta+kappa/loading*(.75*state[3]-move)
        for offset in [2,15]:
            for ell in range(maximum+1):
                answer[offset+ell]=MODE/(2*ell+1)*((ell*state[offset+ell-1] if ell else 0)-((ell+1)*state[offset+ell+1] if ell<maximum else 0))-kappa*state[offset+ell]
        mix=state[4]+state[15]+state[17]
        answer[2]+=kappa*state[2]+4*rate/3
        answer[3]+=4*kappa*move/3
        answer[4]+=8*shear/15+kappa*mix/10;answer[15]+=kappa*mix/2;answer[17]+=kappa*mix/10
        return answer
    sol=solve_ivp(rhs,(t[0],t[-1]),state,t_eval=t,method='BDF',rtol=2e-10,atol=3e-12,max_step=.01)
    assert sol.success
    store(case+'-linear-tail.npz',time=t,values=np.c_[therm['opacity'],therm['cs2b'],sol.y.T])
class FullTrack(Track):
    def __init__(self,case):
        super().__init__(case)
        with np.load(ROOT/(case+'-linear-tail.npz')) as tail,np.load(PRIOR/(case+'-thomson.npz')) as old:
            t=np.r_[old['times'],tail['time'][1:]]
            values=np.r_[np.c_[old['sources'][:,-2:],old['full_hierarchy']],tail['values'][1:]]
            self.photons=CubicSpline(t,values,axis=0,extrapolate=False)
if __name__=='__main__':
    guard();sys.path.insert(0,str(MATCH))
    for label in ('heavy','cold'):extend(label)

