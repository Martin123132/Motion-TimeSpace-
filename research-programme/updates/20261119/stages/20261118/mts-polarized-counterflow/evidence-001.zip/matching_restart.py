from argparse import Namespace
from common_local import *
from evolution import Solver

def run(case):
    tag='refined-'+case
    solver=Solver(case,Namespace(**load(ROOT/(tag+'.json'))))
    track=solver.track;times=solver.grid;center=track.center;ix=int(np.flatnonzero(times==center)[0])
    knots=track.knots;start=int(np.flatnonzero(times==160/MODE)[0])
    subset=np.arange(max(start,np.searchsorted(times,knots[0])-3),min(len(times),np.searchsorted(times,knots[-1])+4))
    with np.load(OLD/(case+'-native.npz')) as bank:weights=bank['weights']
    cubic=CubicSpline(times[subset],np.eye(len(subset)),axis=0,extrapolate=False)
    interp=weights@cubic(knots)
    bracket=np.searchsorted(times[subset],knots)-1
    frac=(knots-times[subset][bracket])/(times[subset][bracket+1]-times[subset][bracket])
    local=np.zeros(len(subset));np.add.at(local,bracket,(1-frac)*weights);np.add.at(local,bracket+1,frac*weights)
    with np.load(ROOT/(tag+'.npz')) as packet:
        assert np.array_equal(times,packet['times'])
        state=packet['matter_160.0'];rays=packet['radiation_160.0']
        avg=np.zeros_like(rays);lin=np.zeros_like(rays);mean=np.zeros_like(state);ledger=np.zeros(12)
        for pos in range(start,len(times)):
            assert np.array_equal(state,packet['states'][pos]) if pos==ix or pos==start else True
            if subset[0]<=pos<=subset[-1]:
                index=pos-subset[0];avg+=interp[index]*rays;lin+=local[index]*rays;mean+=interp[index]*state
                ledger+=interp[index]*np.asarray(solver.report(solver.inputs[pos-1,2],state,rays))
            if pos==ix:exact_state=state.copy();exact_rays=rays.copy()
            if pos+1<len(times):state,rays=solver.integrate(pos,state,rays)
        key=str(round(times[-1]*MODE,6))
        assert np.array_equal(rays,packet['radiation_'+key]) and np.array_equal(state,packet['matter_'+key])
        assert np.isfinite(avg).all() and abs(np.sum(interp)-1)<1e-12
        assert np.max(abs(ledger-interp@packet['report'][subset]))<2e-10
        store('matching-restart-'+case+'.npz',coordinate_time=center,mode=MODE,angular_mu=solver.axis,angular_weights=solver.weight,thermal_q=solver.thermal.grid,
              exact_coordinate_core=exact_state,exact_angular_rays=exact_rays,phase_smoothed_coordinate_core=mean,phase_smoothed_angular_rays=avg,
              phase_smoothed_report=ledger,cell_indices=subset,cubic_kernel=interp,linear_kernel=local)
        summary=dict(case=case,begin=160,replayed_cells=int(len(times)-start-1),exact_terminal_replay=True,center_k_tau=float(center*MODE),
                     kernel_cells=int(len(subset)),linear_vs_cubic_angular_max=float(np.max(abs(lin-avg))),phase_packet_peak=float(np.max(abs(avg))),
                     report_reprojection=float(np.max(abs(ledger-interp@packet['report'][subset]))))
        return summary
if __name__=='__main__':
    guard()
    rows={case:run(case) for case in ('heavy','cold')};save('junction-restart-check.json',rows);print(rows)

