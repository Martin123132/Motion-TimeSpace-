from common_local import *
from linear_tail import FullTrack
from histories import PROJ
from scipy.interpolate import CubicHermiteSpline
from scipy.integrate import solve_ivp

def prepare(track,t,weights,bnumber,brightness,neutrinos,norm):
    a,hub,cold,bary,phot,rel,nu,dc,rate,_,_,shear,eta,f0,p0,ma,f1,p1=track.physics(t).T
    beta,flow=track.photons(t)[:,2:4].T
    weight=a/norm
    q1=weight*MODE*p0*f1
    e0=weight*(p0*p0+ma*f0*f0)/2;e1=weight*(p0*p1+ma*f0*f1)
    other=(rate**2/3+(MU**2-1/3)*shear**2+.5*bary*(bnumber+.5*beta**2-1.5*MU*flow**2)
           +phot*brightness+neutrinos)
    fields=np.array([weight*p0**2,2*weight*rate*p0*p1-2.5*MODE*eta*q1,.5*rate*q1,
                     e0,e1,q1,rate,eta,dc*rate,other])
    return fields@weights

def evolution(clock,forcing,track,norm,start,targets,case,stress=True,covariance=False):
    spl=CubicSpline(clock,forcing,axis=0,extrapolate=False)
    def rhs(t,y):
        rho,flux,cdm,expansion=y
        electrons,work,shear,d0,d1,q1,rate,eta,volume,external=spl(t)
        electronp,workp,_,d0p,d1p,q1p,*_=spl(t,1)
        a,hub,cold=track.physics(t)[:3];ma=track.physics(t)[15];dh=track.physics(t,1)[1]
        weight=a/norm
        grad=(q1*q1+MODE**2*d1*d1/(4*ma))/d0 if case=='heavy' else 0.
        independent=-hub*expansion+.5*cold*cdm+rho/(2*weight)+external
        gain=3/(2*weight)
        supply=electrons*expansion+work
        supplyp=electronp*expansion+electrons*independent+workp
        cov_gain=0.
        if covariance:
            pref=3/(4*weight*MODE);corr=pref*(d0*flux+d1*q1/2)
            supply+=corr
            supplyp+=-hub*corr+pref*(d0p*flux+d0*(-hub*flux+shear-MODE*grad/4)+(d1p*q1+d1*q1p)/2)
            cov_gain=pref*d0*MODE
        terms=MODE*(hub*flux-shear)+supplyp-4*hub*(supply-MODE*flux)+(3*hub**2-3*dh)*rho
        terms+=(-rate*(d1p-3*hub*d1)-expansion*(d0p-3*hub*d0)+MODE**2*(rho+2.5*eta*d1+grad/4))
        denom=4*ma+MODE**2-electrons*gain-cov_gain
        assert denom>0
        lag=(terms-electrons*gain*MU*grad/3)/denom
        long=lag-grad/4 if stress else 0.
        pressure=lag-MU*grad/3 if stress else 0.
        return [-3*hub*pressure-MODE*flux+supply,MODE*long+shear-hub*flux,expansion+volume,independent+gain*pressure],long,pressure
    sample=np.array(list(targets))
    sol=solve_ivp(lambda t,y:rhs(t,y)[0],(clock[0],clock[-1]),start,t_eval=sample,rtol=3e-11,atol=2e-12,method='DOP853',max_step=(clock[-1]-clock[0])/160)
    assert sol.success
    ret=[]
    for t,point in zip(sample,sol.y.T):
        observed=targets[t];predict=np.r_[point,rhs(t,point)[1:]]
        ret.append(dict(scale=float(track.physics(t)[0]),reference=observed.tolist(),propagated=predict.tolist(),difference=(predict-observed).tolist()))
    return ret

def compare(tag,case,samples):
    track=FullTrack(case)
    with np.load(ROOT/(tag+'-'+case+'.npz')) as data:
        times=data['times'];states=data['states'];nu=data['report'][:,0]
    with np.load(PROJ) as proj:
        last=float(proj['matching_scale']);norm=float(proj['matching_density'])
    with np.load(EARLY/'heavy.npz') as bg:phase=CubicSpline(bg['heavy_efold'],bg['phase_h'])
    angle_mesh=phase(np.log(track.physics(times)[:,0]));inverse=CubicSpline(angle_mesh,times,extrapolate=False)
    geom=CubicSpline(times,states[:,:2],axis=0);field=CubicHermiteSpline(times,states[:,2],states[:,3])
    frozen=CubicSpline(times,np.column_stack([states[:,4],states[:,6],nu]),axis=0,extrapolate=False)
    anchors=np.log([.00015,.00018,.00020,last]);grid=np.unique(np.r_[np.linspace(anchors[0],anchors[-1],samples),anchors])
    clock=inverse(phase(grid));coord=np.linspace(-1,1,1001);forces=[];targets={};correlations=[];predictions=[]
    for sc,tc in zip(grid,clock):
        ang=phase(sc)+6*np.pi*coord
        assert ang[0]>=angle_mesh[0]-1e-6 and ang[-1]<=angle_mesh[-1]+1e-6
        t=inverse(np.clip(ang,angle_mesh[0],angle_mesh[-1]))
        basis=np.column_stack([coord**p for p in range(9)]+[coord**p*fn(m*ang) for m,limit in [(2,6),(4,3)] for p in range(limit+1) for fn in [np.sin,np.cos]])
        w=np.linalg.pinv(basis)[0]
        forces.append(prepare(track,t,w,*frozen(t).T,norm))
        a,hub,cold,bary,phot,rel,nu,dc,rate,_,_,shear,eta,f0,p0,ma,f1,p1=track.physics(t).T
        cd,cp=geom(t).T;weight=a/norm
        correlations.append(w@(weight*p0**2*cp)-(w@(weight*p0**2))*(w@cp))
        drive=forces[-1];measured_flux=w@(weight*MODE*(p0*field(t)+.5*p1*f1))
        predictions.append(3*norm/(4*track.physics(tc)[0]*MODE)*(drive[3]*measured_flux+.5*drive[4]*drive[5]))
        if sc in anchors:
            f2=field(t);p2=field(t,1)
            energy=p0*p2+ma*f0*f2+.5*(p1*p1+(ma-MU*MODE**2)*f1*f1)
            lag=p0*p2-ma*f0*f2+.5*(p1*p1-(ma-MU*MODE**2)*f1*f1)
            grad=MODE**2*f1*f1
            targets[tc]=np.array([w@(weight*energy),w@(weight*MODE*(p0*f2+.5*p1*f1)),w@(cd+dc**2/2),w@cp,w@(weight*(lag-grad/4)),w@(weight*(lag-MU*grad/3))])
    start=targets[clock[0]][:4].copy()
    return dict(full=evolution(clock,forces,track,norm,start,targets,case),no_stress=evolution(clock,forces,track,norm,start,targets,case,False),
                coherent_work=evolution(clock,forces,track,norm,start,targets,case,covariance=True),
                covariance=dict(scale=np.exp(grid).tolist(),measured=correlations,from_envelope=predictions,
                    peak=float(np.max(abs(np.array(correlations)))),signed_integral=float(CubicSpline(clock,correlations).integrate(clock[0],clock[-1])),
                    predicted_integral=float(CubicSpline(clock,predictions).integrate(clock[0],clock[-1]))))

if __name__=='__main__':
    guard()
    for tag in sys.argv[1:]:
        rows={case:{str(n):compare(tag,case,n) for n in (33,65)} for case in ('heavy','cold')}
        save('coherent-work-'+tag+'.json',rows)
        for case,tests in rows.items():
            end=tests['65']
            cov=end['covariance'];print(tag,case,'with work',end['coherent_work'][-1]['difference'],'cov',cov['signed_integral'],cov['predicted_integral'],np.max(abs(np.subtract(cov['measured'],cov['from_envelope']))))

