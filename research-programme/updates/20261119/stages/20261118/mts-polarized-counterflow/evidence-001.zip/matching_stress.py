from common_local import *
from linear_tail import FullTrack
from scipy.interpolate import CubicHermiteSpline
MU=-.5
def run(tag):
    track=FullTrack('heavy')
    with np.load(ROOT/(tag+'-heavy.npz')) as packet:
        times=packet['times'];states=packet['states']
    curve=CubicSpline(times,states,axis=0)
    scalar=CubicHermiteSpline(times,states[:,2],states[:,3])
    with np.load(EARLY/'heavy.npz') as bg:phase=CubicSpline(bg['heavy_efold'],bg['phase_h'])
    from histories import PROJ
    with np.load(PROJ) as proj:dmatch=float(proj['matching_density']); center=float(proj['matching_scale'])
    scale=track.physics(times)[:,0];ang=phase(np.log(scale));time_from_angle=CubicSpline(ang,times)
    captures=[]
    for a in np.r_[.00015,.00018,.00020,center]:
        angle=phase(np.log(a));tc=float(time_from_angle(angle))
        hc=track.physics(tc)[1];ma_c=track.physics(tc)[15];wc=a/dmatch
        for width,degree in [(4,6),(6,8),(5,6)]:
            half=width*np.pi;coords=np.linspace(-1,1,1001);theta=angle+half*coords;t=time_from_angle(theta)
            assert t.min()>=times[0] and t.max()<=times[-1]+2e-5
            basis=np.column_stack([coords**p for p in range(degree+1)]+[coords**p*trig(harm*theta) for harm,pmax in [(2,degree-2),(4,3)] for p in range(pmax+1) for trig in [np.sin,np.cos]])
            inv=np.linalg.pinv(basis)
            w=inv[0]; tprime=float(time_from_angle(angle,1));tsecond=float(time_from_angle(angle,2))
            dy=1/(half*tprime);ddy=-tsecond/(half*tprime**3)
            dweight=inv[1]*dy;ddweight=2*inv[2]*dy**2+inv[1]*ddy
            sc,hub,cdm,bary,phot,rel,nu,dc,rate,beta,v,shear,eta,f0,p0,m2,f1,p1=track.physics(t).T
            gauge=curve(t);f2=scalar(t);p2=scalar(t,1);c2p=gauge[:,1]
            e0=(p0**2+m2*f0**2)/2
            e1=p0*p1+m2*f0*f1
            e2=p0*p2+m2*f0*f2+.5*(p1**2+(m2-MU*MODE**2)*f1**2)
            lag=p0*p2-m2*f0*f2+.5*(p1**2-(m2-MU*MODE**2)*f1**2)
            weight=sc/dmatch
            d0=w@(weight*e0);d1=w@(weight*e1);d2=w@(weight*e2)
            q1=w@(weight*MODE*p0*f1);q2=w@(weight*MODE*(p0*f2+.5*p1*f1))
            gradient=w@(weight*MODE**2*f1**2)
            gradnr=(q1**2+MODE**2*d1**2/(4*ma_c))/d0
            direct_lag=w@(weight*lag);direct_long=direct_lag-.25*gradient
            direct_trace_pressure=direct_lag-MU*gradient/3
            def virial(arr0,arr1,arr2):
                temporal=wc/4*(ddweight@arr2+2*hc*(dweight@arr2)-(w@rate)*(dweight@arr1)-(w@c2p)*(dweight@arr0))
                spatial=wc*MODE**2/4*(w@arr2+2.5*(w@eta)*(w@arr1))
                return temporal,spatial
            time_est,space_est=virial(e0/m2,e1/m2,e2/m2)
            time_field,space_field=virial(f0**2,2*f0*f1,2*f0*f2+f1**2)
            comoving=w@(weight*(rate*(2*(p0*f1+f0*p1))+c2p*2*f0*p0))
            corr=-.25*(comoving-wc*((w@rate)*(dweight@(2*f0*f1))+(w@c2p)*(dweight@(f0**2))))
            predicted=time_est+space_est-.25*gradnr
            captures.append(dict(scale=float(a),width=width,degree=degree,density=d2,momentum=q2,homogeneous_density=d0,gradient=gradient,
                predicted_gradient=gradnr,measured_longitudinal=direct_long,measured_pressure=direct_trace_pressure,kinetic_long=-.25*gradnr,
                spatial_lagrangian=space_est,temporal_lagrangian=time_est,leading_longitudinal=space_est-.25*gradnr,
                corrected_longitudinal=predicted,corrected_pressure=time_est+space_est-MU*gradnr/3,projected_exact_lagrangian=direct_lag,
                envelope_virial_using_field=time_field+space_field,expansion_covariance=corr,
                time_to_mass=hc/np.sqrt(ma_c),wave_to_mass=MODE/np.sqrt(ma_c)))
    return captures

if __name__=='__main__':
    guard()
    for tag in sys.argv[1:]:
        results=run(tag);save('stress-'+tag+'.json',results)
        for row in results:
            if row['width']==6:print({key:row[key] for key in ['scale','measured_longitudinal','leading_longitudinal','corrected_longitudinal','measured_pressure','corrected_pressure','gradient','predicted_gradient','expansion_covariance']})

