from common_local import *
from linear_tail import FullTrack

def run(case):
    sys.path.insert(0,str(MATCH))
    from matching_common import camb,params_for
    track=FullTrack(case)
    with np.load(ROOT/('full-'+case+'.npz')) as sol:
        times=sol['times'];reported=sol['report'][:,9:12]
    par=params_for(EARLY/(case+'.npz'))
    times=np.unique(np.r_[times,np.linspace(times[0],times[-1],1201)])
    names=['a','H','etak','delta_cdm','v_newtonian_cdm','delta_neutrino','v_neutrino','delta_nu','delta_baryon','delta_photon','v_photon','pi_photon','growth','v_baryon_cdm','mts_dphi_h','mts_dphidot_h']
    base=camb.get_background(par);base.Params.Accuracy.IntTolBoost=6
    normal=base.get_time_evolution([MODE],times,vars=names,lAccuracyBoost=4)[0]
    high=base.get_time_evolution([MODE],times,vars=names,lAccuracyBoost=16)[0]
    assert np.isfinite(high).all()
    store(case+'-native-angular-control.npz',times=times,names=names,usual=normal,resolved=high)
    with np.load(ROOT/('full-'+case+'.npz')) as sol:idcs=np.searchsorted(times,sol['times'])
    expected=high[idcs,5:8]
    error=np.max(abs(expected-reported),axis=0)/np.max(abs(expected),axis=0)
    print(case,'higher native vs streamed',error)
if __name__=='__main__':
    guard()
    for case in ('heavy','cold'):run(case)
