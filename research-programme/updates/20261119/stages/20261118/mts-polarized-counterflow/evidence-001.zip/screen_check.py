from common_local import *
from thomson_screen import Screen,outer,trans
from numpy.polynomial.legendre import legval
def test():
    screen=Screen(24,32);n=screen.directions
    p=np.array([np.sqrt(.75),0,.5]);q=np.array([-np.sqrt(.75),0,.5])
    incoming=np.zeros(26);incoming[:5]=[.34,-.15,.13,.04,-.03]
    incoming[13:18]=[.12,.10,.04,.02,.01]
    incoming[13:]=[.08,.04,.08/5,.04*3/7,0,0,0,0,0,0,0,0,0]
    def at(direction):
        xi=direction@q
        normal=np.cross(direction,q);normal/=np.linalg.norm(normal,axis=1)[:,None]
        tangent=np.cross(direction,normal);align=outer(tangent,tangent)-outer(normal,normal)
        polar=np.eye(3)-outer(direction,direction)
        coefficients=(2*np.arange(13)+1)*(-1j)**np.arange(13)
        return .5*(legval(xi,incoming[:13]*coefficients)[:,None,None]*polar+legval(xi,incoming[13:]*coefficients)[:,None,None]*align)
    tensor=at(n);u=n@p
    with np.load(ROOT/'screen-12.npz') as maps:matrix=maps['geo']
    errors=[]
    for which in range(4):
        anis,iso,deriv,trace=np.eye(4)[which]
        metric=anis*outer(p,p)+iso*np.eye(3);rate=deriv*outer(p,p)+trace*np.eye(3)
        normal=n@metric;metric_time=n@rate
        sn=np.sum(n*normal,axis=1);sd=np.sum(n*metric_time,axis=1)
        direction=.5*((1j*MODE*sn[:,None]*p-metric_time-1j*MODE*u[:,None]*normal))
        direction-=n*np.sum(direction*n,axis=1)[:,None]
        def derivative(move):
            step=1e-5
            plus=n+step*move;minus=n-step*move
            plus/=np.linalg.norm(plus,axis=1)[:,None];minus/=np.linalg.norm(minus,axis=1)[:,None]
            return (at(plus)-at(minus))/(2*step)
        affine=.5j*MODE*(outer(normal,p)-outer(p,normal))
        out=(.5j*MODE*(normal@q)-2*sd)[:,None,None]*tensor-screen.proj@(derivative(direction.real)+1j*derivative(direction.imag)+affine@tensor-tensor@affine)@screen.proj
        exact=screen.moments(out,12).ravel()
        errors.append(float(max(abs(exact-matrix[which]@incoming))))
    assert max(errors)<1e-8
    return errors
if __name__=='__main__':print(test())

