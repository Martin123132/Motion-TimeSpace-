import sympy as s

def check():
    t,r=s.symbols("t r",real=True)
    eta=s.symbols("eta",real=True)
    A,P,B,F,H,N,V=[s.Function(name)(t,r) for name in ("A","P","B","F","H","N","V")]
    lfun=s.Function("l");ifun=s.Function("I")
    law=lfun(N);cum=ifun(N);w=N.diff(r);charge=eta*N
    m=law-eta*A;Y=charge*A-cum
    twist=4*F*Y/r**4
    derivatives={s.diff(cum,N):law}
    def clean(expr):
        return s.simplify(expr.subs(derivatives).subs(N.diff(t),-V*w))
    checks={}
    def require(key,expression):
        if clean(expression)!=0:
            raise ArithmeticError(key)
        checks[key]=True
    K=-s.Rational(2,3)*Y
    require("radial angular constraint",K.diff(r)-s.Rational(2,3)*(w*m-charge*A.diff(r)))
    require("temporal angular constraint",K.diff(t)+s.Rational(2,3)*(V*w*m+charge*A.diff(t)))
    require("advected canonical angular momentum",m.diff(t)+V*m.diff(r)+eta*(A.diff(t)+V*A.diff(r)))
    ueff=F*A**2/r**2+w*H*m**2/2+2*F*Y**2/r**4
    require("source and restoring terms",ueff.diff(A)-(2*F*A/r**2-eta*w*H*m+charge*twist))
    er=2*F*Y**2/r**4
    require("rotational work",er.diff(t)-2*F.diff(t)*Y**2/r**4-twist*(charge*A.diff(t)+V*w*m))
    em=w*H*m**2/2
    expr=em.diff(t)+(V*em).diff(r)-w*(H.diff(t)+V*H.diff(r))*m**2/2+eta*w*H*m*(A.diff(t)+V*A.diff(r))
    require("mechanical recoil work",expr.subs(N.diff(t,r),-(V*w).diff(r)))
    energy=(B*(P**2+A.diff(r)**2)+2*F*A**2/r**2)/2
    flux=-B**2*P*A.diff(r)
    work=B.diff(t)*(P**2+A.diff(r)**2)/2+F.diff(t)*A**2/r**2+(eta*w*H*m-charge*twist)*A.diff(t)
    expr=energy.diff(t)+flux.diff(r)-work
    require("Poynting with current and twist",expr.subs({A.diff(r,t):(B*P).diff(r),A.diff(t):B*P,
           P.diff(t):(B*A.diff(r)).diff(r)-2*F*A/r**2+eta*w*H*m-charge*twist},simultaneous=True))
    return checks

