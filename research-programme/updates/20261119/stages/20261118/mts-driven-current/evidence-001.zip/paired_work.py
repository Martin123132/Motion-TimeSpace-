from current_source import MESHES, guard, np, peak
from readouts import as_rows, save

def scores():
    guard();rows=[]
    for mesh in MESHES:
        base={}
        as_rows(mesh,.8,0.,0,base)
        for amp in (1/160,1.):
            changed={}
            as_rows(mesh,.8,amp,0,changed)
            for key,values in changed.items():
                left,right,sector=key
                if left==5.5 and sector=="mechanical":
                    continue
                delta,flux,work=(values-base[key])/amp**2
                scale=max(peak(delta),peak(flux),peak(work))
                err=peak(delta+flux-work)
                rows.append(dict(mesh=mesh,amp=amp,left=left,right=right,sector=sector,residual_per_amp2=err,
                         effect_per_amp2=scale,relative=err/scale if scale else None,passes=err<2e-5*scale if scale else err==0))
    return rows

if __name__=="__main__":
    save("paired_energy.csv",scores())

