from scipy.interpolate import CubicSpline
from scipy.integrate import simpson
from current_source import MESHES, MASS, guard, np, peak
from radiate import Core, TIMES, name
from readouts import primitive, save

def scores():
    guard();rows=[]
    for mesh in MESHES:
        cache={}
        for amp in (0.,1/160,1.):
            core=Core(mesh,.8,amp,0)
            mask=(core.rad>=5.5)&(core.rad<=7)
            radius=core.rad[mask]
            data=core.interp(TIMES)[:,:,mask]
            with np.load(core_path(mesh,amp)) as src:
                wave=src["fields"][:,:2,mask]
            cache[amp]=(data,wave)
        old,oldwave=cache[0.]
        for amp in (1/160,1.):
            new,newwave=cache[amp]
            source=4*(.8*MASS)**2/radius**4
            base=oldwave[:,0];active=newwave[:,0]
            df=new[:,1]-old[:,1];da=active-base
            basal=old[:,0]*oldwave[:,1];at=new[:,0]*newwave[:,1]
            dat=(new[:,0]-old[:,0])*newwave[:,1]+old[:,0]*(newwave[:,1]-oldwave[:,1])
            ft=CubicSpline(TIMES,new[:,1],axis=0)(TIMES,1)
            dft=CubicSpline(TIMES,df,axis=0)(TIMES,1)
            energy=source/2*(df*base**2+new[:,1]*da*(base+active))
            supply=source*(df*base*basal+new[:,1]*(da*at+base*dat))
            background=source/2*(dft*base**2+ft*da*(base+active))
            def collect(data):
                return simpson(data,x=radius,axis=1)/amp**2
            delta=collect(energy);work=primitive(collect(supply+background))
            err=peak(delta-delta[0]-work);scale=max(peak(delta),peak(work))
            rows.append(dict(mesh=mesh,amp=amp,scale_per_amp2=scale,absolute_per_amp2=err,relative=err/scale,
                          max_density=peak(new[:,3]),max_fractional_charge_deviation=peak(new[:,4]/MASS-1),
                          passes=err<2e-5*scale))
    return rows

def core_path(mesh,amp):
    from current_source import HERE
    return HERE/name(mesh,.8,amp,0)

if __name__=="__main__":
    save("local_exterior_work.csv",scores())

