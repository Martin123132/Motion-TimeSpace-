import json
from scipy.linalg import eigh
from scipy.interpolate import lagrange
from current_source import DENSITY, MASS, DETECTORS, END, HERE, guard, np, betainc, spin, write, sha

SIZES=(56,112,224)
TARGET=np.linspace(0,END,513)

def static(radius):
    def enclosed(rad):
        return MASS*betainc(1.5,7,np.minimum(1.,(rad/5)**2))
    def untrapped(rad):
        return 1-enclosed(rad)/np.where(rad==0,1.,rad)
    def density(rad):
        return DENSITY*np.maximum(0.,1-(rad/5)**2)**6
    roots,weights=np.polynomial.legendre.leggauss(24)
    width=np.maximum(0.,5-radius)
    rr=radius[...,None]+width[...,None]*(1+roots)/2
    lapse=np.exp(-width/2*np.sum(weights*rr*density(rr)/untrapped(rr),axis=-1))
    normal=untrapped(radius)
    return enclosed(radius),density(radius),lapse,normal*lapse,normal**2*lapse

def solve(elements):
    degree=4;size=elements*degree+1;width=14/elements
    nodes=np.array([-1.,-np.sqrt(3/7),0.,np.sqrt(3/7),1.])
    basis=[lagrange(nodes,np.eye(degree+1)[slot]) for slot in range(degree+1)]
    knots,weights=np.polynomial.legendre.leggauss(11)
    values=np.array([fun(knots) for fun in basis]);slopes=np.array([fun.deriv()(knots)*2/width for fun in basis])
    stiffness=np.zeros((size,size));norm=np.zeros_like(stiffness);source=np.zeros((size,2))
    for cell in range(elements):
        radius=(cell+(1+knots)/2)*width
        label,density,lapse,alpha,bridge=static(radius)
        barrier=2*lapse/radius**2+4*lapse*label**2/radius**4+density*alpha
        ix=slice(cell*degree,cell*degree+degree+1)
        vol=weights*width/2
        stiffness[ix,ix]+=(slopes*(vol*bridge))@slopes.T+(values*(vol*barrier))@values.T
        norm[ix,ix]+=(values*(vol/bridge))@values.T
        for variant in (0,1):
            law,inside=spin(label,variant)
            source[ix,variant]+=values@(vol*(density*alpha*law+4*lapse*label*inside/radius**4))
    freq2,modes=eigh(stiffness[1:-1,1:-1],norm[1:-1,1:-1])
    assert min(freq2)>0
    freq=np.sqrt(freq2);overlap=modes.T@source[1:-1]
    clock=TARGET[:,None]*freq
    sin=np.sin(clock)/freq
    cosine=2*np.sin(clock/2)**2/freq2
    readings=[]
    for rad in DETECTORS:
        index=rad/width
        cell=int(np.floor(index))
        cells=[cell] if abs(index-round(index))>1e-12 else [int(round(index))-1,int(round(index))]
        projection=np.zeros((2,size))
        for cell in cells:
            coord=2*(index-cell)-1
            sel=slice(cell*degree,cell*degree+degree+1)
            projection[:,sel]+=np.array([[fun(coord) for fun in basis],[fun.deriv()(coord)*2/width for fun in basis]])/len(cells)
        val,grad=projection[:,1:-1]@modes
        at=cosine@(val[:,None]*overlap)
        atime=sin@(val[:,None]*overlap)
        ar=cosine@(grad[:,None]*overlap)
        bridge=static(np.asarray(rad))[-1]
        readings.append(np.stack([at,atime,ar,-bridge*atime*ar]))
    return np.array(readings).transpose(3,2,1,0)


def freeze():
    guard();files={}
    for size in SIZES:
        curves=solve(size)
        name=f"static-modes-{size}.npz"
        write(name,time=TARGET,probes=DETECTORS,wave=curves)
        files[name]=sha(HERE/name)
    receipt=dict(files=files,code=sha(HERE/"static_modes.py"),source=sha(HERE/"current_source.py"),
                 protocol=sha(HERE/"SPECTRAL-PREDICTION.md"),gate=2e-5)
    with (HERE/"frozen.json").open("x",encoding="utf8") as stream:
        json.dump(receipt,stream,indent=2,sort_keys=True)
    print(sha(HERE/"frozen.json"))

if __name__=="__main__":
    freeze()

