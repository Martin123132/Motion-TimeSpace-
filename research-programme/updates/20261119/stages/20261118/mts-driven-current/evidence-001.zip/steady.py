from scipy.integrate import solve_ivp, quad
from scipy.interpolate import lagrange
from scipy.linalg import solve
from scipy.special import betainc
from current_source import DENSITY, MASS, guard, np, spin, peak
from readouts import save

def moment(scale,variant):
    def matter(rad):
        number=MASS*scale*betainc(1.5,7.,np.minimum(1.,(rad/5)**2))
        density=DENSITY*scale*np.maximum(0.,1-(rad/5)**2)**6
        good=1-number/np.where(rad==0,1.,rad)
        return number,density,good
    def material(rad):
        number,density,good=matter(rad)
        law,inside=spin(number/scale,variant)
        return number,density,good,law,scale*inside
    def ode(rad,values):
        number,density,good=matter(rad)
        logF,c,rate=values
        return [rad*density/good,rate,
                (3*density/good+6*(number/(rad**2*good))**2)*c-(4/rad+(2*number/rad**2-rad*density)/good)*rate]
    start=1e-7
    sol=solve_ivp(ode,(start,5.),[0.,1.,3*DENSITY*scale*start/5],method="DOP853",rtol=1e-13,
                  atol=1e-17,max_step=.034,dense_output=True)
    assert sol.success
    mass=MASS*scale
    coeff=[1.,1.5]
    for degree in range(2,10):
        coeff.append((2*degree*(degree+2)*coeff[-1]-((degree-1)*(degree+2)-4)*coeff[-2])/((degree+1)*(degree+2)-2))
    powers=np.arange(len(coeff))
    tail=sum(coeff*(mass/5)**powers)/5
    dtail=-sum((powers+1)*coeff*(mass/5)**powers)/25
    def quantities(rad):
        logF,c,rate=sol.sol(rad)
        F=np.exp(logF-sol.y[0,-1])
        number,density,good,law,inside=material(rad)
        alpha=F*good;B=F*good**2
        U=2*F/rad**2+4*F*number**2/rad**4+density*alpha
        S=density*alpha*law+4*F*number*inside/rad**4
        return F,c,rate,number,inside,alpha,B,U,S
    F,c,dc,num,inside,alpha,bridge,U,S=quantities(5.)
    W=bridge*((10*c+25*dc)*tail-25*c*dtail)
    def raw(rad):
        F,c,dc,num,inside,alpha,bridge,U,S=quantities(rad)
        return rad**2*c*S
    def safe(rad):
        F,c,dc,num,inside,alpha,bridge,U,S=quantities(rad)
        return inside*(3*F*num*c/rad**2-alpha*dc)
    def leading(rad):
        number,density,good,law,inside=material(rad)
        fourth=MASS*scale*(75/17)*betainc(2.5,7.,(rad/5)**2)
        return inside*(number/rad**2-fourth/rad**4)
    integrate=lambda fun:quad(fun,0.,5.,epsabs=1e-23,epsrel=3e-12,limit=70)[0]
    raw_mu=integrate(raw)/W;safe_mu=integrate(safe)/W
    analytic=integrate(leading)
    def galerkin(elements):
        order=4;width=5/elements;size=order*elements+1
        nodes=np.array([-1.,-np.sqrt(3/7),0.,np.sqrt(3/7),1.])
        roots,weights=np.polynomial.legendre.leggauss(12)
        basis=[lagrange(nodes,row) for row in np.eye(5)]
        val=np.array([fun(roots) for fun in basis])
        grad=np.array([fun.deriv()(roots)*2/width for fun in basis])
        lhs=np.zeros((size,size));force=np.zeros(size);initial=0.
        for idx in range(elements):
            rad=(idx+(1+roots)/2)*width
            number,density,good,law,inside=material(rad)
            points,wg=np.polynomial.legendre.leggauss(20)
            rr=rad[:,None]+(5-rad[:,None])*(1+points)/2
            nums,dens,red=matter(rr)
            F=np.exp(-(5-rad)/2*np.sum(wg*rr*dens/red,axis=1))
            alpha=F*good;B=F*good**2
            barrier=2*F/rad**2+4*F*number**2/rad**4+density*alpha
            drive=density*alpha*law+4*F*number*inside/rad**4
            ix=slice(idx*order,idx*order+5)
            weight=weights*width/2
            lhs[ix,ix]+=(val*(weight*barrier))@val.T+(grad*(weight*B))@grad.T
            force[ix]+=val@(weight*drive)
            initial+=sum(weight*(.5*density*alpha*law**2+2*F*inside**2/rad**4))
        lhs[-1,-1]-=(1-mass/5)**2*dtail/tail
        field=solve(lhs[1:,1:],force[1:],assume_a="pos")
        energy=.5*np.dot(force[1:],field)
        norm=.5*np.dot(field,lhs[1:,1:]@field)
        return field[-1]/tail,energy,norm,initial
    coarse=galerkin(48);fine=galerkin(96)
    return dict(scale=scale,spin=variant,adjoint=safe_mu,unsubtracted=raw_mu,weak_form=fine[0],
                weak_vs_adjoint=abs(fine[0]/safe_mu-1),mesh_error=abs(fine[0]-coarse[0])/abs(safe_mu),
                leading=analytic,leading_relative=abs(analytic/safe_mu-1),mu_over_scale2=safe_mu/scale**2,
                initially_available=fine[1],initial_axial_energy=fine[3],free_fraction=fine[1]/fine[3],
                energy_form_error=abs(fine[2]/fine[1]-1),surface_dipole=fine[0]*tail)

def scores():
    guard()
    return [moment(scale,variant) for variant in (0,1) for scale in (1.,.5,.25,.125)]
if __name__=="__main__":
    save("stationary_moments.csv",scores())

