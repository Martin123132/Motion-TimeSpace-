import json
from scipy.interpolate import CubicSpline
from current_source import ARMS, END, HERE, MESHES, bankname, guard, np, sha, spin, write

FREEZE="a93ded2b53509f2bffa654420ae1067139a54afebdce9838b99c640dfa0d3117"
TIMES=np.linspace(0,END,513)

def gradient(values,spacing,even=True):
    parity=1 if even else -1
    padded=np.r_[parity*values[4:0:-1],values,[0.]*4]
    result=np.zeros_like(values)
    length=len(values)
    for shift,coef in enumerate((4/5,-1/5,4/105,-1/280),1):
        result+=coef*(padded[4+shift:4+shift+length]-padded[4-shift:4-shift+length])
    return result/spacing

def second(values,spacing):
    padded=np.r_[values[4:0:-1],values,[0.]*4]
    result=(-205/72)*values
    length=len(values)
    for shift,coef in enumerate((8/5,-1/5,8/315,-1/560),1):
        result+=coef*(padded[4+shift:4+shift+length]+padded[4-shift:4-shift+length])
    return result/spacing**2


class Core:
    def __init__(self,mesh,eta,amp,variant):
        with np.load(HERE/bankname(mesh,abs(eta),amp)) as src:
            self.rad=src["radius"];self.interp=CubicSpline(src["time"],src["background"],axis=0)
        self.eta=eta;self.variant=variant;self.spacing=self.rad[1]
        self.inv=np.zeros_like(self.rad);self.inv[1:]=1/self.rad[1:]
    def coefficients(self,time):
        bridge,lapse,weight,density,number,vel,rho,scalar,br=self.interp(time)
        q=self.eta*number;law,moment=spin(number,self.variant)
        h=weight*density
        base=lapse*(rho+scalar+(q*self.inv**2)**2)
        stiff=2*base+self.eta**2*h+4*lapse*(q*self.inv**2)**2
        source=self.eta*h*law*self.inv**2+4*lapse*(q*self.inv**3)*(moment*self.inv**3)
        return np.array([bridge,br,stiff,source])
    def rhs(self,values,terms):
        field,mom=values
        bridge,br,stiff,source=terms
        slopes=gradient(field,self.spacing)
        curvature=second(field,self.spacing)
        radlap=curvature+4*self.inv*slopes;radlap[0]=5*curvature[0]
        out=np.stack([bridge*mom,bridge*radlap+br*slopes-stiff*field+source])
        out[:,-4:]=0.
        return out

def name(mesh,eta,amp,variant):
    return f"driven-{mesh}-eta{eta:g}-h{amp:g}-spin{variant}.npz"

def run(mesh,eta,amp,variant=0):
    guard()
    assert sha(HERE/"frozen.json")==FREEZE
    sys=Core(mesh,eta,amp,variant);rad=sys.rad
    state=np.zeros((2,len(rad)));saved=[]
    steps=int(np.ceil(END/(.22*sys.spacing)/512))*512
    step=END/steps
    start=sys.coefficients(0.)
    for tick in range(steps+1):
        if tick%(steps//512)==0:
            val,mom=state
            A=rad**2*val;P=rad**2*mom
            Ar=2*rad*val+rad**2*gradient(val,sys.spacing)
            saved.append(np.stack([A,P,Ar]))
        if tick==steps:
            break
        mid=sys.coefficients((tick+.5)*step);last=sys.coefficients((tick+1)*step)
        first=sys.rhs(state,start);nextval=sys.rhs(state+step/2*first,mid)
        third=sys.rhs(state+step/2*nextval,mid);fourth=sys.rhs(state+step*third,last)
        state+=step/6*(first+2*nextval+2*third+fourth)
        start=last
    assert np.isfinite(saved).all()
    write(name(mesh,eta,amp,variant),time=TIMES,radius=rad,fields=saved,steps=steps,eta=eta,amp=amp,variant=variant)
    print("radiation",mesh,eta,amp,variant,flush=True)

if __name__=="__main__":
    for size in MESHES:
        for charge,amplitude in ARMS:
            run(size,charge,amplitude)
        run(size,1.,0.,1)
        run(size,-.8,1.)

