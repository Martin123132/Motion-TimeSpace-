import csv
import json
from scipy.interpolate import CubicSpline, make_interp_spline
from scipy.optimize import brentq
from current_source import DETECTORS, ARMS, MASS, HERE, MESHES, guard, np, peak, spin
from radiate import Core, FREEZE, TIMES, name
from static_modes import SIZES

def save(name,rows):
    with (HERE/name).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)

def primitive(values,axis=TIMES):
    spline=make_interp_spline(axis,values,k=5,axis=0).antiderivative()
    return spline(axis)-spline(axis[0])
def integral(radius,parts,left,right):
    spline=make_interp_spline(radius,parts,k=5,axis=1).antiderivative()
    return spline(right)-spline(left)
def as_rows(mesh,eta,amp,variant,collect=None):
    core=Core(mesh,eta,amp,variant);rad=core.rad;inv=core.inv
    b,F,Hbar,D,n,V,rho,scalar,br=core.interp(TIMES).transpose(1,0,2)
    bt,ft,ht=core.interp(TIMES,1)[:,:3].transpose(1,0,2)
    with np.load(HERE/name(mesh,eta,amp,variant)) as src:
        A,P,X=src["fields"].transpose(1,0,2)
    At=b*P;alpha=np.sqrt(b*F)
    q=eta*n;w=rad**2*D
    law,I=spin(n,variant);m=law-eta*A;Y=q*A-I
    K=-2*Y/3
    twist=4*F*Y*inv**4
    flux=-b*At*X
    e=.5*b*(P**2+X**2)+F*(A*inv)**2
    eM=.5*D*Hbar*eta*A*(eta*A-2*law)
    eR=2*F*q*A*(q*A-2*I)*inv**4
    W=.5*bt*(P**2+X**2)+ft*(A*inv)**2
    matter=eta*D*Hbar*m*At
    spinwork=-q*twist*At
    advective=V*D*Hbar*eta*m*X
    dweight=CubicSpline(rad,Hbar,axis=1)(rad,1)
    radial=.5*D*(ht+V*(dweight-2*Hbar*inv))*eta*A*(eta*A-2*law)
    rotexplicit=2*ft*q*A*(q*A-2*I)*inv**4+4*F*V*w*(q*A*m+I*eta*A)*inv**4
    syslabel=dict(mesh=mesh,eta=eta,amp=amp,spin=variant)
    budgets=[];momenta=[]
    ix=np.searchsorted(rad,DETECTORS)
    for left,right in [(0.,14.),(0.,6.),(5.5,7.)]:
        il,ir=np.searchsorted(rad,[left,right])
        def integ(data):
            return integral(rad,data,left,right)
        photon=integ(e);mech=integ(eM);geom=integ(eR)
        clock_work=primitive(integ(W));charge_work=primitive(integ(matter));metric_work=primitive(integ(spinwork))
        mech_explicit=primitive(integ(radial));mech_magnetic=primitive(integ(advective))
        geometry_explicit=primitive(integ(rotexplicit))
        emit=primitive(flux[:,ir]-flux[:,il])
        matflux=primitive(V[:,ir]*eM[:,ir]-V[:,il]*eM[:,il])
        total=photon+mech+geom
        for key,change,passed,driven,scale in (
            ("EM",photon,emit,clock_work+charge_work+metric_work,max(peak(charge_work),peak(emit),peak(photon))),
            ("mechanical",mech,matflux,mech_explicit-charge_work-mech_magnetic,max(peak(charge_work),peak(mech),peak(matflux))),
            ("twist",geom,np.zeros(len(TIMES)),geometry_explicit-metric_work,max(peak(geom),peak(metric_work))),
            ("combined",total,emit+matflux,clock_work+mech_explicit+geometry_explicit-mech_magnetic,
               max(peak(charge_work),peak(emit),peak(photon),peak(mech)))):
            error=peak(change-change[0]+passed-driven)
            if collect is not None:
                collect[left,right,key]=np.stack([change-change[0],passed,driven])
            budgets.append(dict(**syslabel,left=left,right=right,sector=key,change=change[-1]-change[0],outward=passed[-1],
                supplied=driven[-1],error=error,scale=scale,relative=error/scale if scale else None,
                work_from_current=charge_work[-1],work_from_rotation=metric_work[-1],photon_metric_work=clock_work[-1],
                passes=error<2e-5*scale if scale else error==0))
    for idx,rad0 in zip(ix,DETECTORS):
        density=2/3*(w*m-q*X)
        measured=integral(rad,density,0.,rad0)
        change=primitive(-2/3*(V[:,idx]*w[:,idx]*m[:,idx]+q[:,idx]*At[:,idx]))
        signal=K[:,idx]-K[0,idx]
        target=peak(signal);spatial=peak(K[:,idx])
        momenta.append(dict(**syslabel,r0=rad0,peak_K=spatial,delta_K=target,radial_abs=peak(measured-K[:,idx]),
            time_abs=peak(signal-change),radial_relative=peak(measured-K[:,idx])/spatial if spatial>1e-18 else None,
            time_relative=peak(signal-change)/target if target>1e-18 else None))
    signals=np.stack([A[:,ix],At[:,ix],X[:,ix],flux[:,ix]])
    return budgets,momenta,signals,K[:,ix],alpha[:,ix]

def scores():
    guard()
    budgets=[];momenta=[];spectrum=[];arrivals=[];mesh_scores=[];parity=[];waves={};threshold=None
    curves={}
    for size in SIZES:
        with np.load(HERE/f"static-modes-{size}.npz") as src:
            curves[size]=src["wave"]
    for mesh in MESHES:
        for eta,amp,variant in [(*arm,0) for arm in ARMS]+[(1.,0.,1),(-.8,1.,0)]:
            energy,momentum,signal,K,alpha=as_rows(mesh,eta,amp,variant)
            budgets.extend(energy);momenta.extend(momentum);waves[mesh,eta,amp,variant]=(signal,K,alpha)
            if eta==1.:
                for method in range(4):
                    for slot,r0 in enumerate(DETECTORS):
                        target=curves[SIZES[-1]][variant,:,method,slot]
                        reading=signal[method,:,slot]
                        scale=peak(target);error=peak(target-reading)/scale
                        spectrum.append(dict(mesh=mesh,spin=variant,r0=r0,readout=("A","At","Ar","flux")[method],
                             peak=scale,relative=error,passes=error<2e-5,
                             FEM_112_224=peak(target-curves[112][variant,:,method,slot])/scale,
                             FEM_56_112=peak(curves[56][variant,:,method,slot]-curves[112][variant,:,method,slot])/scale))
        p=waves[mesh,.8,1.,0];m=waves[mesh,-.8,1.,0]
        parity.append(dict(mesh=mesh,field_odd=peak(p[0][:3]+m[0][:3]),flux_even=peak(p[0][3]-m[0][3]),
                           twist_even=peak(p[1]-m[1]),neutral_wave=peak(waves[mesh,0.,0.,0][0]),
                           neutral_interior_K=peak(waves[mesh,0.,0.,0][1][:,0])))
    slot=2
    base,_,alpha=waves[1920,.8,0.,0]
    threshold=.1*primitive(np.maximum(base[3,:,slot],0)/alpha[:,slot])[-1]
    for mesh in MESHES:
        for amp in (0.,1/160,1.):
            sig,K,alpha=waves[mesh,.8,amp,0]
            power=np.maximum(sig[3,:,slot],0)/alpha[:,slot]
            integral=primitive(power)
            times=primitive(alpha[:,slot]);clock=CubicSpline(TIMES,times)
            start=np.flatnonzero((integral[:-1]<threshold)&(integral[1:]>=threshold))[0]
            derived=brentq(lambda t:CubicSpline(TIMES,integral)(t)-threshold,TIMES[start],TIMES[start+1],xtol=1e-15)
            arrivals.append(dict(mesh=mesh,amp=amp,threshold=threshold,positive_fluence=integral[-1],
                net_fluence=primitive(sig[3,:,slot]/alpha[:,slot])[-1],coord=derived,proper=float(clock(derived))))
    for amp in (1/160,1.):
        for slot,r0 in enumerate(DETECTORS):
            for method,key in enumerate(("A","At","Ar","flux")):
                def effect(mesh):
                    return waves[mesh,.8,amp,0][0][method,:,slot]-waves[mesh,.8,0.,0][0][method,:,slot]
                fine=effect(1920);coarse=effect(960)
                scale=peak(fine);error=peak(coarse-fine)/scale
                mesh_scores.append(dict(amp=amp,r0=r0,readout=key,fraction_of_ordinary=scale/peak(waves[1920,.8,0.,0][0][method,:,slot]),
                                       relative_mesh=error,passes=error<2e-5))
    return dict(budgets=budgets,momenta=momenta,static_prediction=spectrum,arrival=arrivals,mesh=mesh_scores,parity=parity)

if __name__=="__main__":
    for label,rows in scores().items():
        save(label+".csv",rows)

