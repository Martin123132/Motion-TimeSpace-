from pathlib import Path
import os
import sys

for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PREVIOUS=HERE.parent/"mts-transverse-poynting-20261118"
CHARGED=HERE.parent/"mts-charged-exterior-rulers-20261118"
sys.path.insert(0,str(PREVIOUS))
from background import Charged, END, sha, guard as old_guard, np, filename, peak
from scipy.integrate import simpson
from scipy.special import betainc
from numpy.polynomial import Polynomial

LOCK="0aa09d1cfa9532ff127adcf5d8d76922288f788cb55e36742b5c7fbb70dfe5a2"
MASS=.002
DENSITY=.000703828125
MESHES=(960,1920)
ARMS=((0.,0.),(.8,0.),(.8,1/160),(.8,1.),(1.,0.))
DETECTORS=(3.,5.5,6.,7.)

def guard():
    old_guard()
    assert sha(PREVIOUS/"closeout.json")==LOCK and not (HERE/"STOP-REQUESTED").exists()

def write(name,**data):
    with (HERE/name).open("xb") as stream:
        np.savez_compressed(stream,**data)

def spin(label,variant=0):
    x=np.clip(label/MASS,0.,1.)
    integral=(32./3)*x**3*(1-x)**3
    derivative=32*x**2*(1-x)**2*(1-2*x)
    if variant==1:
        return (2*x-1)*derivative+2*integral,MASS*integral*(2*x-1)
    if variant!=0:
        raise ValueError(variant)
    return derivative,MASS*integral

def bankname(mesh,eta,amp):
    return f"core-{mesh}-eta{eta:g}-h{amp:g}.npz"

def acquire(mesh,eta,amp):
    guard()
    grid=Charged(mesh,eta)
    state,probe=grid.initial("both" if amp else "dust","prepared" if amp else "bare",1.,amp)
    probe[[3,5]]-=1
    source=CHARGED/filename(mesh,eta,amp)
    with np.load(source) as saved:
        assert np.array_equal(state,saved["initial"])
    steps=int(np.ceil(END/(.26*grid.step)/256))*256
    step=END/steps
    mask=grid.r<=14
    series=[];audit=[]
    for tick in range(steps+1):
        if tick%(steps//256)==0:
            aa,alpha,bridge,logs,slope,ms,en,sr,st,current,eh,ed,vd,grad=grid.metric(state)
            nr=grid.r**2*state[2]
            label=grid.integral(nr)
            weight=grid.extra[3]
            scalar=state[0]**2
            rho=ed*(1-vd**2)
            motion=bridge*vd
            data=np.stack([bridge,alpha*aa,alpha/weight,state[2],label,motion,rho,scalar,bridge*(slope-logs)])
            series.append(data[:,mask])
            audit.append([label[-1],peak(grid.extra[0]-eta*label),peak(nr[grid.r>=5.5])])
        if tick==steps:
            break
        k1,p1=grid.push(state,probe);k2,p2=grid.push(state+.5*step*k1,probe+.5*step*p1)
        k3,p3=grid.push(state+.5*step*k2,probe+.5*step*p2);k4,p4=grid.push(state+step*k3,probe+step*p3)
        state+=step/6*(k1+2*k2+2*k3+k4)
        probe+=step/6*(p1+2*p2+2*p3+p4)
    with np.load(source) as saved:
        assert np.array_equal(state,saved["final"])
    write(bankname(mesh,eta,amp),time=np.linspace(0,END,257),radius=grid.r[mask],background=series,audit=audit,
          columns=["bridge","F","alpha_over_W","D","label","transport","rho","field_squared","bridge_r"],parent=sha(source))
    print(mesh,eta,amp,"matched original endpoint",flush=True)

if __name__=="__main__":
    for mesh in MESHES:
        for eta,amp in ARMS:
            acquire(mesh,eta,amp)

