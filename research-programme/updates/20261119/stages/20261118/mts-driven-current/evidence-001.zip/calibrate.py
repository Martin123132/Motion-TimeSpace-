from scipy.interpolate import CubicSpline, make_interp_spline
from scipy.optimize import brentq
from current_source import HERE, MESHES, DETECTORS, MASS, guard, np, peak, spin, write
from readouts import integral, primitive, save
from radiate import Core, TIMES, name
from static_modes import solve

def extra_modes():
    guard()
    waves=solve(448)
    write("static-refined-448.npz",wave=waves,time=TIMES,probes=DETECTORS)

def restore():
    guard();rows=[];timing=[];refinement=[];shells=[]
    with np.load(HERE/"static-refined-448.npz") as data:
        high=data["wave"]
    with np.load(HERE/"static-modes-224.npz") as data:
        low=data["wave"]
    threshold=None
    for mesh in (1920,960):
        basetimes=None
        for eta,amp,variant in ((.8,0.,0),(.8,1/160,0),(.8,1.,0),(1.,0.,0),(1.,0.,1)):
            core=Core(mesh,eta,amp,variant);rad=core.rad
            bridge,F,H,density,num,V,*rest=core.interp(TIMES).transpose(1,0,2)
            with np.load(HERE/name(mesh,eta,amp,variant)) as data:
                A,P,X=data["fields"].transpose(1,0,2)
            w=density*rad**2
            measure=make_interp_spline(rad,w,k=5,axis=1).antiderivative()
            label=measure(rad)-measure(0)[:,None]
            law,I=spin(label,variant)
            K=2/3*(I-eta*label*A)
            density_K=2/3*(w*(law-eta*A)-eta*label*X)
            old_l,old_I=spin(num,variant)
            oldK=2/3*(old_I-eta*num*A)
            idx=np.searchsorted(rad,DETECTORS)
            for r0,col in zip(DETECTORS,idx):
                from_charge=integral(rad,density_K,0.,r0)
                scale=peak(oldK[:,col])
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,spin=variant,r0=r0,label_max=peak(label-num)/MASS,
                        corrected_source_vs_original=peak(K[:,col]-oldK[:,col])/scale,
                        corrected_density_vs_original_metric=peak(from_charge-oldK[:,col])/scale,
                        corrected_density_vs_corrected_metric=peak(from_charge-K[:,col])/scale))
            if eta==1.:
                signals=np.stack([A[:,idx],(bridge*P)[:,idx],X[:,idx],(-bridge**2*P*X)[:,idx]])
                for kind in range(4):
                    for index,r0 in enumerate(DETECTORS):
                        refined=high[variant,:,kind,index]
                        scale=peak(refined)
                        refinement.append(dict(mesh=mesh,spin=variant,r0=r0,readout=kind,order_doubling=peak(refined-low[variant,:,kind,index])/scale,
                            refined_vs_domain=peak(refined-signals[kind,:,index])/scale))
            for fraction in (.2,.5,.8):
                target=fraction*MASS
                trace=np.array([brentq(lambda z:spline(z)-target,.1,4.98) for spline in
                                (make_interp_spline(rad,entry,k=5) for entry in label)])
                def at(array):
                    return np.array([make_interp_spline(rad,entry,k=5)(point) for entry,point in zip(array,trace)])
                atime=at(bridge*P);speed=at(V);grad=at(X);pot=at(A)
                electric=primitive(-eta*atime);magnetic=primitive(-eta*speed*grad)
                scale=peak(eta*pot)
                shells.append(dict(mesh=mesh,eta=eta,amp=amp,spin=variant,baryon_fraction=fraction,
                    final_dmechanical=-eta*pot[-1],electric_impulse=electric[-1],motional_impulse=magnetic[-1],
                    relative_recoil=peak(-eta*pot-electric-magnetic)/scale,
                    omit_motional=peak(-eta*pot-electric)/scale,path_drift=peak(trace-trace[0])))
            if eta!=.8:
                continue
            slot=idx[2]
            alpha=np.sqrt(bridge[:,slot]*F[:,slot])
            flux=-bridge[:,slot]**2*P[:,slot]*X[:,slot]/alpha
            flu=primitive(np.maximum(0.,flux))
            if threshold is None:
                threshold=.1*flu[-1]
            if amp==0:
                baseA=P[:,slot].copy();baseX=X[:,slot].copy();baseB=bridge[:,slot].copy();baseF=F[:,slot].copy()
                basepower=baseB**2/alpha;baseflux=flux.copy()
                basespline=CubicSpline(TIMES,flu)
                crossing=brentq(lambda t:basespline(t)-threshold,3.,5.,xtol=1e-15)
                basealpha=alpha.copy();basetimes=CubicSpline(TIMES,primitive(basealpha));continue
            coeff=bridge[:,slot]**2/alpha
            db=bridge[:,slot]-baseB;df=F[:,slot]-baseF
            dalpha=(db*F[:,slot]+baseB*df)/(alpha+basealpha)
            dcoeff=(db*(bridge[:,slot]+baseB)-basepower*dalpha)/alpha
            delta=-dcoeff*baseA*baseX-coeff*((P[:,slot]-baseA)*X[:,slot]+baseA*(X[:,slot]-baseX))
            physical=np.where((flux>0)&(baseflux>0),delta,np.maximum(0.,flux)-np.maximum(0.,baseflux))
            shift_flu=CubicSpline(TIMES,primitive(physical))
            lag=-shift_flu(crossing)/basespline(crossing,1)
            knots,weights=np.polynomial.legendre.leggauss(5)
            for repetition in range(4):
                lag=-shift_flu(crossing+lag)/sum(wt/2*basespline(crossing+(point+1)*lag/2,1) for point,wt in zip(knots,weights))
            clock_term=CubicSpline(TIMES,primitive(dalpha))(crossing+lag)
            proper_shift=clock_term+lag*sum(wt/2*basetimes(crossing+(point+1)*lag/2,1) for point,wt in zip(knots,weights))
            timing.append(dict(mesh=mesh,amp=amp,threshold=threshold,coordinate_shift=lag,clock_term=clock_term,
                               proper_shift=proper_shift))
    return dict(corrected_label=rows,static_resolution=refinement,stable_arrival=timing,shell_recoil=shells)

if __name__=="__main__":
    extra_modes()
    for label,rows in restore().items():
        save(label+".csv",rows)

