import csv
from sympy import Poly, Rational, symbols, simplify
from current_source import HERE, guard
from readouts import save

def coefficients():
    radius=symbols("r")
    def polynomial(expression):
        return Poly(expression,radius,domain="QQ")
    one=polynomial(1);rad=polynomial(radius)
    density=Rational(9009,12800000)*polynomial(1-radius**2/25)**6
    mass=(rad**2*density).integrate()
    total=Rational(1,500)
    assert mass.eval(5)==total
    label=mass.mul_ground(1/total)
    nu=mass.exquo(rad)
    dc1=(3*rad**4*density).integrate().exquo(rad**4)
    c1=dc1.integrate()
    rhs=3*density*(c1+nu)+6*(mass.exquo(rad**2))**2-(2*mass.exquo(rad**2)-rad*density)*dc1
    dc2=(rad**4*rhs).integrate().exquo(rad**4)
    L1=(rad*density).integrate()
    L1=L1-polynomial(L1.eval(5))
    wfirst=3*c1.eval(5)+5*dc1.eval(5)
    rows=[]
    for variant in (0,1):
        inside=Rational(32,3)*total*label**3*(one-label)**3
        if variant:
            inside=inside*(2*label-one)
        n2=inside*(3*mass.exquo(rad**2)-dc1)
        n3=inside*(3*mass.exquo(rad**2)*(L1+c1)-dc2-(L1-nu)*dc1)
        second=n2.integrate().eval(5)/3
        third=(n3.integrate().eval(5)-wfirst*second)/3
        rows.append(dict(spin=variant,mu2_exact=str(second),mu3_exact=str(third),mu2=float(second),mu3=float(third)))
    return rows

def signs():
    r,u,v,k=symbols("r u v k",positive=True)
    udot=k-2*u/r+u*v-u**2
    value=3*udot+9*u**2+(4/r+2*u-v)*3*u-(3*k+6*u**2)
    assert simplify(value-6*u*(1/r+u))==0
    return True

def scores():
    guard();assert signs()
    coeff=coefficients()
    with (HERE/"stationary_moments.csv").open(encoding="utf8") as stream:
        saved=list(csv.DictReader(stream))
    rows=[]
    for item in saved:
        variant=int(item["spin"]);scale=float(item["scale"]);moment=float(item["adjoint"])
        quad=coeff[variant]["mu2"]*scale**2
        cubic=quad+coeff[variant]["mu3"]*scale**3
        eq=abs(quad/moment-1);ec=abs(cubic/moment-1)
        rows.append(dict(scale=scale,spin=variant,adjoint=moment,second=quad,cubic=cubic,quadratic_error=eq,
                         cubic_error=ec,passes=ec<2e-5))
    return coeff,rows

if __name__=="__main__":
    coeff,rows=scores()
    save("exact_coefficients.csv",coeff);save("moment_law_tests.csv",rows)

