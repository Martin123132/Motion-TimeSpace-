import csv
import json
import math
import sys
import calibrate
import exterior_work
import source_identities
import moment_law
import paired_work
import readouts
import steady
from current_source import ARMS, CHARGED, HERE, LOCK, MESHES, PREVIOUS, bankname, filename, guard, np, peak, sha
from radiate import FREEZE, name

def audit():
    guard()
    checks={};inputs={};files={}
    def require(label,condition):
        if not condition:
            raise ValueError(label)
        checks[label]=True
    def pin(path,digest):
        value=sha(path)
        label=path.relative_to(HERE.parent).as_posix()
        require("parent "+label,value==digest)
        inputs[label]=value
    parent=json.loads((PREVIOUS/"closeout.json").read_text(encoding="utf8"))
    pin(PREVIOUS/"closeout.json",LOCK)
    for path,digest in parent["inputs"].items():
        pin(HERE.parent/path,digest)
    for file in ("background.py","AXIAL-ACTION.md","FIELD-TO-ROTATION.md","RESULTS.md","pulse-1920-eta0.8-h0.00625-flat0.npz"):
        pin(PREVIOUS/file,parent["files"][file])
    charged=json.loads((CHARGED/"closeout.json").read_text(encoding="utf8"))
    for mesh in MESHES:
        for eta,amp in ARMS:
            src=filename(mesh,eta,amp)
            pin(CHARGED/src,charged["files"][src])
            with np.load(HERE/bankname(mesh,eta,amp)) as data:
                assert data["parent"].item()==charged["files"][src] and np.max(data["audit"][:,1])==0.
    require("frozen independent solutions",sha(HERE/"frozen.json")==FREEZE)
    frozen=json.loads((HERE/"frozen.json").read_text(encoding="utf8"))
    for file,digest in {**frozen["files"],"current_source.py":frozen["source"],"SPECTRAL-PREDICTION.md":frozen["protocol"],"static_modes.py":frozen["code"]}.items():
        require("frozen "+file,sha(HERE/file)==digest)
    for path in sorted(HERE.iterdir()):
        if path.name=="closeout.json":
            continue
        if not path.is_file() or path.suffix not in (".npz",".csv",".json",".md",".py"):
            raise ValueError(path.name)
        files[path.name]=sha(path)
        if path.suffix==".npz":
            with np.load(path,allow_pickle=False) as data:
                assert all(np.isfinite(data[key]).all() for key in data.files if data[key].dtype.kind in "fci")
                if "time" in data:
                    assert np.all(np.diff(data["time"])>0)
            require("finite "+path.name,True)
    checks.update(source_identities.check())
    result=readouts.scores()
    corrected=calibrate.restore()
    pair=paired_work.scores()
    local=exterior_work.scores()
    static=steady.scores()
    coeff,cubic=moment_law.scores()
    tables={**result,**corrected,"paired_energy":pair,"local_exterior_work":local,"stationary_moments":static,
            "exact_coefficients":coeff,"moment_law_tests":cubic}
    for table,values in tables.items():
        with (HERE/(table+".csv")).open(encoding="utf8",newline="") as stream:
            prior=list(csv.DictReader(stream,strict=True))
        assert len(prior)==len(values) and len(prior)>0
        for row,val in zip(prior,values):
            assert set(row)==set(val)
            for key,item in val.items():
                if item is None:
                    assert row[key]==""
                elif isinstance(item,(str,np.bool_,bool)):
                    assert row[key]==str(item)
                else:
                    assert math.isclose(float(row[key]),item,abs_tol=2e-25,rel_tol=3e-9),(table,key,item,row[key])
        require("recomputed "+table,True)
    fine=lambda rows:[row for row in rows if row["mesh"]==1920]
    require("static predictions; actual forecast not replacement",len(fine(result["static_prediction"]))==32 and all(r["passes"] for r in result["static_prediction"]))
    require("unresolved initial mode refinement and resolution check",max(r["FEM_112_224"] for r in result["static_prediction"])>2e-5 and
            all(max(r["order_doubling"],r["refined_vs_domain"])<2e-5 for r in corrected["static_resolution"]))
    require("energy calibration on whole cloud and material interior",all(r["passes"] for r in fine(result["budgets"]) if r["left"]==0))
    failed=[r for r in fine(result["budgets"]) if not r["passes"]]
    require("raw material exterior nulls",len(failed)==4 and all(r["sector"]=="mechanical" and r["error"]<2.3e-67 for r in failed))
    require("ordinary and MTS waveforms converge on difference",len(result["mesh"])==32 and all(r["passes"] for r in result["mesh"]))
    require("charge reversal and neutral spin",all(r["field_odd"]==r["flux_even"]==r["twist_even"]==r["neutral_wave"]==0 and r["neutral_interior_K"]>0 for r in result["parity"]))
    require("material recoil with motional term",all(r["relative_recoil"]<2e-5 for r in corrected["shell_recoil"]) and
            max(r["omit_motional"] for r in corrected["shell_recoil"])>1e-3)
    require("source label consistency not a false spin signal",
            max(r["radial_relative"] or 0 for r in fine(result["momenta"]))>2e-5 and
            max(r["corrected_density_vs_original_metric"] for r in fine(corrected["corrected_label"]))<2e-5)
    for amp in (1/160,1.):
        clocks=[r for r in corrected["stable_arrival"] if r["amp"]==amp]
        require("finite proper delay "+str(amp),len(clocks)==2 and 0<clocks[0]["proper_shift"]<clocks[0]["coordinate_shift"]
                and abs(clocks[1]["proper_shift"]/clocks[0]["proper_shift"]-1)<2e-5)
    require("ordinary/MTS paired budget old failure and repaired slab",
        sum(not r["passes"] for r in fine(pair))==1 and all(r["passes"] for r in local))
    require("static positive energy and independent moment",all(0<r["free_fraction"]<1 and r["weak_vs_adjoint"]<2e-5
             and r["energy_form_error"]<2e-5 for r in static))
    require("exact Wronskian residual and cubic moment",moment_law.signs() and all(r["passes"] and r["quadratic_error"]>r["cubic_error"] for r in cubic)
            and all(r["adjoint"]>0 for r in static if r["spin"]==0))
    return dict(parent=LOCK,forecast=FREEZE,checks=checks,files=files,inputs=inputs)

if __name__=="__main__":
    receipt=audit();path=HERE/"closeout.json"
    if sys.argv[1:]==["--seal"]:
        with path.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(receipt,stream,indent=2,sort_keys=True);stream.write("\n")
    elif sys.argv[1:] or json.loads(path.read_text(encoding="utf8"))!=receipt:
        raise ValueError("changed packet or unexpected arguments")
    print(len(receipt["checks"]),"checks;",len(receipt["files"]),"files;",len(receipt["inputs"]),"source files;",sha(path))

