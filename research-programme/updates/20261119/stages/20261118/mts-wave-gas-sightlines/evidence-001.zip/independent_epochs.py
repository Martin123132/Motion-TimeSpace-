from setup_stage import *
import physics
from photon_frame import InertialHistory,frame_rhs
REDS=np.array([99.,6.3,5.15,4.2])
class Target(InertialHistory):
    def __init__(self,case,stride=1):
        super().__init__(case,stride)
        self.epochs=np.r_[self.start,-np.log1p(REDS[1:-1]),self.end]
def freeze():
    guard();physics.History=Target;physics.lin=frame_rhs
    preds={}
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold"),("lcdm","cold")):
        preds[arm if case!="lcdm" else case]=physics.advance(case,arm,"full",2048)
    save("new-epoch-forecast.npz",**preds)
    write("new-epoch-receipt.json",dict(redshift=REDS.tolist(),files={key:sha(ROOT/key) for key in ("new-epoch-forecast.npz","photon_frame.py","physics.py","independent_epochs.py","heavy-photon.npz","heavy-inputs.npz","cold-inputs.npz","cold-photon.npz","lcdm-inputs.npz","lcdm-photon.npz")},no_new_direct_results_at_freeze=not list(ROOT.glob("events-*/truth.npz"))))
def direct(case,arm):
    guard();rec=read("new-epoch-receipt.json")
    assert rec["no_new_direct_results_at_freeze"] and all(sha(ROOT/key)==val for key,val in rec["files"].items())
    folder=ROOT/("events-"+case+"-"+arm);folder.mkdir()
    os.chdir(folder);factor="0" if arm=="off" else "1"
    assert all(os.environ.get(key)==v for key,v in dict(MTS_FOREST_INDEX="1",MTS_FOREST_FACTOR=factor,MTS_FOREST_SCALE="0.01").items())
    sys.path[:0]=[str(SWITCH/"engine"),str(BASE/"radiation-and-slow-field-transfer-20261007")]
    import matching_common as src
    params=src.params_for(TABLE if case=="heavy" else COLD);modes=load(case+"-inputs.npz")["k"]
    if case=="heavy":
        points=np.load(LAST/"trace-frozen.npz")["pred_1_1"][2,:,:2];params.DarkEnergy.set_table("SetMatching",modes,*points.T)
    elif case=="lcdm":params.DarkEnergy=src.camb.dark_energy.DarkEnergyFluid()
    params.DoLateRadTruncation=False
    engine=src.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6.4
    times=engine.conformal_time(REDS,tol=1e-10)
    cols=["a","H","Weyl","etak","delta_baryon","v_newtonian_cdm","v_newtonian_baryon","mts_match_count"]
    raw=engine.get_time_evolution(modes,times,vars=cols,lAccuracyBoost=4)
    col=lambda name:raw[:,:,cols.index(name)];k=modes[:,None]
    gauge=(col("H")/k)**2*col("v_newtonian_cdm")
    actual=np.stack([k**2*(col("etak")/k+gauge)-2*col("Weyl"),col("delta_baryon")+3*gauge,col("v_newtonian_baryon")],axis=-1).transpose(1,0,2)
    assert np.all(col("mts_match_count")==(case=="heavy"))
    forecast=load("new-epoch-forecast.npz")[arm if case!="lcdm" else case]
    err=np.max(abs(forecast[1:3]/actual[1:3]-1),axis=(0,1))
    save(folder/"truth.npz",z=REDS,raw=raw,columns=cols,actual=actual,error=err)
    print(case,arm,err,flush=True)
if __name__=="__main__":
    if sys.argv[1]=="freeze":freeze()
    else:direct(*sys.argv[1:])

