from setup_stage import *
from box import Box,KB,MP
from sightlines import csv_out,flux
from scipy.integrate import quad
from scipy.optimize import brentq
import csv
def main():
    guard();meta=read("primordial-settings.json")
    with (SWITCH/"forest-radial-inputs.csv").open() as stream:
        entries=[r for r in csv.DictReader(stream) if float(r["k_parent"])>5.]
    result=[];scale_rows=[]
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        history=None
        for which in range(4):
            box=Box(case,arm,24,which,0,1.,1,history);history=box.hist
            k=box.fund[0];orig=history.modes
            transverse=np.sqrt(orig[[1,3]]**2-orig[0]**2)
            volume=(2*np.pi)**3/(k*np.prod(transverse))
            power=2*np.pi**2*meta["As"]*(k/meta["pivot_Mpc"])**(meta["ns"]-1)/k**3
            ampl=2*np.sqrt(power/volume)
            box.basis*=ampl;box.amplitude=ampl;data=box.integrate(512)
            save(f"boxes/radial-{arm}-{which}.npz",**data,volume=volume)
            for entry in entries:
                if float(entry["k_parent"])!=k:continue
                red=float(entry["z"]);idx=np.flatnonzero(Z==red).item();scale,hc=data["background"][idx]
                p=flux(*data["fields"][idx,:2],hc,k)
                kv=k/(hc*SPEED)
                same_map=case=="heavy"
                if same_map:assert abs(kv/float(entry["kv_s_per_km"])-1)<2e-5
                result.append(dict(arm=arm,instrument=entry["instrument"],redshift=red,observed_kv=float(entry["kv_s_per_km"]),actual_kv=kv,
                              comoving_k=k,own_volume=volume,real_seed_amplitude=ampl,radial_p1=p["p1"],density_min=data["min_classical_gas"],same_parent_mapping=same_map))
        def terms(ef):
            env=history.fn(ef);w=np.clip((ef+np.log(10))/np.log(10/8),0,1)
            cs=np.sqrt(env[5]+1.5*KB*1e4/(.61*MP*(SPEED*1000)**2)*w*w*(3-2*w))
            return cs,env[1],env[2:5].sum()
        for idx in range(3,7):
            ef=history.epochs[idx];cuts=[-np.log(10),-np.log(8)]
            horizon=quad(lambda t:terms(t)[0]/terms(t)[1],history.start,ef,points=cuts,epsabs=1e-9,limit=200)[0]
            cold_horizon=quad(lambda t:np.sqrt(history.fn(t)[5])/history.fn(t)[1],history.start,ef,epsabs=1e-9,limit=200)[0]
            cs,h,gravity=terms(ef)
            scale_rows.append(dict(arm=arm,z=Z[idx],cs_kms=cs*SPEED,sound_horizon_Mpc=horizon,native_sound_horizon_Mpc=cold_horizon,
                unity_phase_k=1/horizon,half_period_k=np.pi/horizon,instantaneous_Jeans_k=np.sqrt(gravity)/cs,
                instantaneous_wave_crossing_k=(4*history.m**2*np.exp(2*ef)*gravity)**.25 if arm=="wave" else None))
    csv_out("radial-only-entries.csv",result);csv_out("gas-propagation-scales.csv",scale_rows)
    print(scale_rows[3],flush=True)
if __name__=="__main__":main()

