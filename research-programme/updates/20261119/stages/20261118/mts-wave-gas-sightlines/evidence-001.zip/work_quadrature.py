from setup_stage import *
from box import Box,KB,MP
from energy import energy
from sightlines import csv_out
def score(series,fn,conv,order):
    ef,K,W,U,metric,entropy,drag,rawheat=series.T
    cuts=np.unique(np.r_[ef,-np.log(10),-np.log(8)])
    nodes,weights=np.polynomial.legendre.leggauss(order)
    delta=np.diff(cuts)
    at=cuts[:-1,None]+delta[:,None]*(nodes+1)/2
    thermal=CubicSpline(ef,conv,axis=0)(at)
    ramp=np.clip((at+np.log(10))/np.log(10/8),0,1)
    hotprime=1.5*KB*1e4/(.61*MP*(SPEED*1000)**2)*6*ramp*(1-ramp)/np.log(10/8)
    heat=thermal[:,:,0]*fn(at,1)[:,:,5]+thermal[:,:,1]*hotprime
    rate=CubicSpline(ef,-2*K-W+metric+entropy+drag)(at)
    def primitive(r):
        incr=delta*(r@weights)/2
        return np.r_[0,np.cumsum(incr)][np.searchsorted(cuts,ef)]
    budget=primitive(rate+heat);change=K+W+U-(K+W+U)[0]
    norm=max(abs(change))+max(abs(primitive(abs(rate+heat))))
    return max(abs(change-budget))/norm,max(abs(change-primitive(rate)))/norm,budget
def main():
    guard();rows=[]
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        for steps in (320,640):
            box=Box(case,arm,12,-1,2,1e-5,1);record=[];conv=[]
            series=load("work-"+arm+".npz")["series"] if steps==640 else None
            def tap(index,ef,state,env):
                if series is None:record.append(energy(box,state,env,ef))
                density=box.ifft(state[1]).real
                conv.append([env[3]/sum(env[2:5])*np.mean(np.expm1(gamma*np.log1p(density))-gamma*density)/(gamma*(gamma-1)) for gamma in (5/3,1.5)])
            result=box.integrate(steps,record=tap)
            target=load("boxes/"+("time-" if steps==640 else "main-")+arm+("" if steps==640 else "-2")+".npz")
            assert np.array_equal(result["fields"],target["fields"])
            if series is None:series=np.array(record)
            low=score(series,box.hist.fn,np.array(conv),4);high=score(series,box.hist.fn,np.array(conv),8)
            assert len(conv)==len(series)
            save("work-split-"+arm+"-"+str(steps)+".npz",series=series,thermodynamic_factors=conv,integral=high[2])
            rows.append(dict(arm=arm,steps=steps,split_error=high[0],omitted_heating=high[1],order_delta=abs(low[0]-high[0])))
            print(rows[-1],flush=True)
    csv_out("split-work.csv",rows)
if __name__=="__main__":main()

