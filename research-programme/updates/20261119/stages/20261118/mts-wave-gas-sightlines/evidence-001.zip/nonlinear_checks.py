from setup_stage import *
from box import Box

class AnalyticHistory:
    def __init__(self,free=False):
        self.case="analytic";self.m=9.;self.modes=np.array([7.,8.,9.,10.])
        self.start=-np.log(4);self.end=0.;self.epochs=np.linspace(self.start,self.end,5)
        self.free=free
    def fn(self,times):
        arr=np.zeros((*np.shape(times),25));scale=np.exp(times);hub=.0002/np.sqrt(scale)
        arr[...,0]=scale;arr[...,1]=hub
        if not self.free:arr[...,2:4]=1.5*hub[...,None]**2*np.array([.84,.16])
        return arr
    def sfn(self,times):return (-2/.0002)*(np.exp(-.5*np.asarray(times))-2)
class Zeldovich(Box):
    def exact(self,ef):
        side=self.shape[0]; angle=2*np.pi*np.arange(side)/side;amplitude=.12*np.exp(ef-self.hist.start)
        lag=angle.copy()
        for _ in range(12):lag-=(lag-amplitude*np.sin(lag)-angle)/(1-amplitude*np.cos(lag))
        den=1/(1-amplitude*np.cos(lag));scale=np.exp(ef);hub=.0002/np.sqrt(scale)
        vel=-scale*hub*amplitude*np.sin(lag)/self.fund[0]
        return den,vel
    def seed(self):
        den,velocity=self.exact(self.hist.start);theta=self.fft(velocity)*(-self.ik[0])*self.inv
        state=np.zeros((7,*self.shape),complex)
        state[0]=state[1]=self.fft(den-1)*self.mask
        state[3]=state[4]=theta*self.mask
        return state
class Free(Box):
    def seed(self):
        vals=np.zeros((7,*self.shape),complex)
        vals[6,1]=1/np.sqrt(2);vals[6,-2]=1/np.sqrt(2)
        self.wave_mean0=1.
        return vals
def main():
    guard();report={}
    for side in (48,96):
        box=Zeldovich("cold","cold",side,0,0,0,0,AnalyticHistory())
        data=box.integrate(320); errs=[];verrs=[]
        for index,ef in enumerate(box.hist.epochs):
            den,vel=box.exact(ef)
            actual=data["fields"][index,2]
            errs.append(float(np.max(abs(actual-den))/np.max(abs(den-1))))
            verrs.append(float(np.max(abs(data["fields"][index,1]*np.exp(ef)/SPEED-vel))/np.max(abs(vel))))
        report[str(side)]=dict(max_density= max(errs),max_velocity=max(verrs))
    box=Free("heavy","wave",24,0,0,0.,0,AnalyticHistory(True))
    result=box.integrate(67);errs=[]
    for idx,ef in enumerate(box.hist.epochs):
        seed=box.seed()[6]*np.exp(-.5j*box.k2*box.hist.sfn(ef)/box.m)
        den=abs(box.ifft(seed))**2
        errs.append(float(np.max(abs(result["fields"][idx,3]-den))))
    report["free_interference"]=dict(error=max(errs),mass=result["wave_mass_error"],initial_node=float(result["fields"][0,3].min()))
    assert report["96"]["max_density"]<2e-5 and report["96"]["max_velocity"]<2e-5
    assert report["96"]["max_density"]<report["48"]["max_density"] and max(errs)<1e-7
    write("nonlinear-controls.json",report);print(report)
if __name__=="__main__":main()

