from setup_stage import *
import csv
def rows(name):
    with (ROOT/name).open(newline="",encoding="utf8") as stream:return list(csv.DictReader(stream))
def verify():
    guard();checks=[]
    def require(label,value):
        if not value:raise AssertionError(label)
        checks.append(label)
    prior=json.loads((LAST/"closeout.json").read_text())
    paths=[LAST/"closeout.json",TABLE,COLD,SWITCH/"forest-radial-inputs.csv",SWITCH/"engine/native/camb/cambdll.dll",MATCH/"native/camb/cambdll.dll",MATCH/"matching_common.py",MATCH/"stage_common.py",LAST/"trace-frozen.npz",LAST/"trace-driver.npz"]
    paths += [LAST/f"late-{name}.npz" for name in ("225pred","cold","lcdm")]
    paths += [LAST/f"restart-{case}-{arm}/fields.npz" for case,arm in (("heavy","off"),("heavy","on"),("cold","on"),("lcdm","on"))]
    oldswitch=json.loads((SWITCH/"closeout.json").read_text())
    for path in paths:
        if path.is_relative_to(LAST) and path.name!="closeout.json":require("retained "+str(path.relative_to(LAST)),prior["files"][path.relative_to(LAST).as_posix()]==sha(path))
        if path.is_relative_to(SWITCH):require("previous "+str(path.relative_to(SWITCH)),oldswitch["files"][path.relative_to(SWITCH).as_posix()]==sha(path))
    protected={**read("observer.json")["inputs"],**{str(p):sha(p) for p in paths}}
    require("observer build inputs remain intact",all(sha(path)==val for path,val in protected.items()))
    require("observer readout binary",sha(ROOT/"observer/native/camb/cambdll.dll")==read("observer.json")["binary"])
    for case in ("heavy","cold","lcdm"):
        src=read(case+"-source.json")
        require(case+" full constraint from other species",src["closure"]<2e-5 and max(src["replay"])<2e-5)
        require(case+" source and reference separated",src["source"]==sha(ROOT/(case+"-inputs.npz")) and src["target"]==sha(ROOT/(case+"-check.npz")))
    first=read("linear.json");second=read("frame-linear.json")
    require("synchronous counterfactual failure retained",first["heavy-off-full-2048-1"][2]>2e-5)
    require("isolated failure retained",first["heavy-wave-isolated-1024-1"][1]>2e-5)
    require("common-frame forecast passes unchanged limits",max(max(x) for x in second.values())<2e-5)
    freeze=read("new-epoch-receipt.json");require("new epochs prospectively sealed",freeze["no_new_direct_results_at_freeze"] and all(sha(ROOT/key)==val for key,val in freeze["files"].items()))
    target=load("linear.npz");peak=0.;new_max=0.
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold"),("lcdm","cold")):
        key=arm if case!="lcdm" else case
        future=load(f"events-{case}-{arm}/truth.npz")
        future_forecast=load("new-epoch-forecast.npz")[key]
        error=np.max(abs(future_forecast[1:-1]/future["actual"][1:-1]-1))
        require("independent redshifts "+case+"/"+arm,error<2e-5);new_max=max(new_max,error)
        for index in range(4):
            data=load(f"boxes/probe-{key}-k{index}.npz")
            err=np.max(abs(2*data["transfer"][:,:,0]/float(data["amplitude"])/target[case+"-"+arm+"-target"][:,index]-1))
            require(f"box transfer {case} {arm} k{index}",err<2e-5);peak=max(peak,err)
        twice=load("boxes/probe-repeat-"+arm+"-"+case+".npz")
        require(case+"/"+arm+" doubled amplitude, mesh and time check",np.max(abs(2*twice["transfer"][:,:,0]/float(twice["amplitude"])/target[case+"-"+arm+"-target"][:,-1]-1))<2e-5)
    for path in (ROOT/"events-heavy-wave").glob("initial-*.bin"):
        require("counterfactual initial state "+path.name,path.read_bytes()==(ROOT/"events-heavy-off"/path.name).read_bytes())
    allboxes=list((ROOT/"boxes").glob("*.npz"));maxmass=0.;minimum=1.
    for path in allboxes:
        with np.load(path) as archive:
            minimum=min(minimum,float(archive["min_classical_gas"]),float(archive["min_cdm"]))
            maxmass=max(maxmass,float(archive["wave_mass_error"]),float(archive["mean_classical_error"]))
            assert np.isfinite(archive["fields"]).all() and np.isfinite(archive["transfer"]).all()
    require("all boxes smooth-positive on tested grids and mass retained",len(allboxes)==83 and minimum>0 and maxmass<2e-5)
    control=read("nonlinear-controls.json")
    require("analytic nonlinear dust control",control["96"]["max_density"]<2e-5 and control["48"]["max_density"]>control["96"]["max_density"])
    require("exact dynamical wave node",control["free_interference"]["initial_node"]<1e-14 and control["free_interference"]["error"]<1e-7)
    require("independent sightline Fourier controls",max(read("readout-controls.json").values())<2e-7)
    three=rows("split-work.csv");original=rows("energy-budget.csv")
    require("unsplit heating quadrature miss retained",float(next(r["error"] for r in original if r["arm"]=="wave"))>2e-5)
    for arm in ("wave","off","cold"):
        records=[r for r in three if r["arm"]==arm]
        lo,hi=sorted(records,key=lambda r:int(r["steps"]))
        require(arm+" resolved energy work",float(hi["split_error"])<min(2e-5,float(lo["split_error"])) and float(hi["omitted_heating"])>.05)
    data=rows("fixed-power-sightlines.csv");ratios=rows("fixed-power-contrasts.csv")
    require("fixed-power runs and all redshifts",len(data)==120 and len(ratios)==12)
    for arm in ("wave","off","cold"):
        row=next(r for r in ratios if r["arm"]==arm and float(r["z"])==4.2)
        require(arm+" physical truncation distinct from mesh",float(row["transverse_second"])>.4 and abs(float(row["grid18_vs24"]))<2e-5)
    scene=load("boxes/power-wave-2-0-1-12.npz");meta=read("primordial-settings.json");k=load("heavy-inputs.npz")["k"]
    for index,re,im in scene["pairs"]:
        mode=k[int(index)];variance=(2*np.pi**2/mode**3)*meta["As"]*(mode/meta["pivot_Mpc"])**(meta["ns"]-1)/scene["volume"]
        require("Fourier pair covariance",abs((re**2+im**2)/variance-1)<1e-12)
    require("seven original instrument rows per radial-only arm",len(rows("radial-only-entries.csv"))==21)
    source_pairs={float(r["z"]):(float(r["k_parent"]),float(r["kv_s_per_km"])) for r in rows(SWITCH/"forest-radial-inputs.csv") if float(r["k_parent"])>5}
    band=rows("mapped-continuous-band.csv");mid=rows("mapped-frozen-midpoint-kernels.csv")
    require("continuous kernels map to released radial bins",len(band)==12 and all(float(r["kx"])==source_pairs[float(r["z"])][0] and abs(float(r["kv"])/source_pairs[float(r["z"])][1]-1)<2e-5 for r in band))
    require("missing finite integral not fabricated",all((not r["partial_band_kms"])==(int(r["knots"])==1) for r in band))
    require("midpoint forecasts not fabricated source modes",len(mid)==9 and all(np.all(abs(k-float(r["frozen_total_k"]))>1e-5) and sha(ROOT/"warm-linear.npz")==r["source"] for r in mid))
    require("no temporary compiler or pycache",not list(ROOT.rglob("__pycache__")) and not (ROOT/"observer-compile").exists())
    files={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(ROOT.rglob("*")) if p.is_file() and p.name!="closeout.json"}
    stats=dict(maximum_box_transfer=float(peak),independent_epoch_max=float(new_max),boxes=len(allboxes),max_mass_error=maxmass,min_ordinary_density=minimum)
    if sys.argv[1:]==["--seal"]:write("closeout.json",dict(checks=checks,stats=stats,files=files,protected=protected,previous=LOCK))
    else:
        stored=read("closeout.json")
        require("sealed entire stage",files==stored["files"] and stats==stored["stats"])
        require("sealed inputs",protected==stored["protected"])
    print(len(checks),"checks",len(files),"files",len(protected),"source hashes",stats,sha(ROOT/"closeout.json"))
if __name__=="__main__":verify()

