from setup_stage import *
import physics
from physics import split,History
original=physics.lin
class InertialHistory(History):
    def __init__(self,case,stride=1):
        super().__init__(case,stride)
        src=self.src;rows=np.unique(np.r_[np.arange(0,len(src["N"]),stride),len(src["N"])-1,src["target_indices"]])
        phot=load(case+"-photon.npz")["newtonian"]
        data=np.column_stack((src["a"],src["h"],src["g"].T,src["thermal"],src["external"].transpose(1,0,2).reshape(-1,16)))
        data[:,12::4]=phot.T
        self.fn=CubicSpline(src["N"][rows],data[rows],axis=0)
def frame_rhs(history,states,env,arm,prescription):
    deriv,obs=original(history,states,env,arm,prescription)
    scale,hub,_,thermal,_=split(env)
    if prescription!="isolated":
        deriv[:,4]-=thermal[3]*thermal[2]*4*states[:,3]/(3*hub)
    return deriv,obs
def prepare():
    guard()
    for case in ("heavy","cold","lcdm"):
        src=load(case+"-inputs.npz");parent=load(case+"-check.npz")
        newtonian=src["external"][:,:,3]-4*src["h"]*parent["U"][:,:,0]/(3*src["k"][:,None])
        save(case+"-photon.npz",newtonian=newtonian)
    write("frame-protocol.json",dict(source="synchronous q_gamma + 4 sigma/3; reuse the physical dipole, not the original CDM frame",first_result=sha(ROOT/"linear.npz"),files={case:sha(ROOT/(case+"-photon.npz")) for case in ("heavy","cold","lcdm")},no_off_history_used_for_new_source=True))
def test():
    guard()
    physics.History=InertialHistory;physics.lin=frame_rhs
    score={};pred={}
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold"),("lcdm","cold")):
        label=case+"-"+arm;target=load("linear.npz")[label+"-target"]
        for nstep,stride in ((1024,1),(2048,1),(2048,2)):
            result=physics.advance(case,arm,"full",nstep,stride)
            score[label+f"-{nstep}-{stride}"]=np.max(abs(result/target-1),axis=(0,1)).tolist()
            pred[label+f"-{nstep}-{stride}"]=result
        print(label,score[label+"-2048-1"],flush=True)
    save("frame-linear.npz",**pred);write("frame-linear.json",score)
if __name__=="__main__":
    prepare();test()

