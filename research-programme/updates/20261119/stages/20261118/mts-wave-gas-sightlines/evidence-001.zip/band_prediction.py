from setup_stage import *
from scipy.interpolate import PchipInterpolator
from scipy.integrate import simpson
from sightlines import csv_out
from box import KB,MP
import csv
def main():
    guard();data=load("warm-linear.npz");meta=read("primordial-settings.json")
    rows=[];forecast=[];shells=[]
    with (SWITCH/"forest-radial-inputs.csv").open() as stream:
        pairs={float(row["z"]):(float(row["k_parent"]),float(row["kv_s_per_km"])) for row in csv.DictReader(stream) if float(row["k_parent"])>5}
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        driver=load(case+"-inputs.npz");k=driver["k"]
        for zi in range(4):
            red=sorted(pairs)[zi];epoch=np.flatnonzero(Z==red).item()
            hub=driver["h"][driver["target_indices"][epoch]]*SPEED
            kx=k[zi];kv=kx/hub;A=.65;gamma=1.5
            assert kx==pairs[red][0] and abs(kv/pairs[red][1]-1)<2e-5
            d=.25*kv**2*2*KB*1e4/(MP*1e6)
            B=2-.7*(gamma-1)-d*(gamma-1)
            P=2*np.pi**2*meta["As"]*(k/meta["pivot_Mpc"])**(meta["ns"]-1)/k**3
            resp=B*data[arm][epoch,:,1]+(kx/k)**2*data[arm][epoch,:,2]
            integrand=hub*A**2*np.exp(-2*d)*k**2/(2*np.pi)*P*resp**2
            xx=np.log(k[zi:]);fg=integrand[zi:]
            for ki,ff in zip(k[zi:],fg):shells.append(dict(arm=arm,z=red,k_radial=kx,total_k=ki,per_log_k_kms=ff))
            if len(xx)<2:
                rows.append(dict(arm=arm,z=red,kx=kx,kv=kv,kmax=k[-1],knots=1,partial_band_kms=None,trap_change=None,simpson_change=None,endpoint_per_log_k=fg[-1],tail_status="no interval; unavailable"));continue
            poly=PchipInterpolator(xx,fg);area=float(poly.integrate(xx[0],xx[-1]))
            trap=float(np.trapezoid(fg,x=xx));simp=float(simpson(fg,x=xx))
            rows.append(dict(arm=arm,z=red,kx=kx,kv=kv,kmax=k[-1],knots=len(xx),partial_band_kms=area,trap_change=trap/area-1,simpson_change=simp/area-1,endpoint_per_log_k=fg[-1],tail_status="partial, not a full prediction"))
            if zi==0:
                for left,right in zip(xx[:-1],xx[1:]):
                    mid=(left+right)/2
                    forecast.append(dict(arm=arm,z=red,kx=kx,frozen_total_k=float(np.exp(mid)),per_log_k_kms=float(poly(mid)),interpolant="PCHIP integrand vs log k, not microscopic seed",source=sha(ROOT/"warm-linear.npz")))
    csv_out("mapped-continuous-band.csv",rows);csv_out("mapped-continuous-integrand.csv",shells);csv_out("mapped-frozen-midpoint-kernels.csv",forecast)
    print([r for r in rows if r["z"]==4.2])
if __name__=="__main__":main()

