from setup_stage import *
from box import Box,KB,MP
from scipy.integrate import cumulative_simpson
from sightlines import csv_out
def energy(box,state,env,ef):
    a,hub=env[:2];g=env[2:5];fraction=g/g.sum()
    readout=box.evaluate(state,env,True)
    den=1+box.ifft(readout["C"]).real;v=readout["flow"]/a;nd=len(v)
    flux=den[:nd,None]*v
    kinetic=sum(fraction[idx]*np.mean(den[idx]*np.sum(v[idx]**2,axis=0))/2 for idx in range(nd))
    totalflux=np.einsum("i,id...->d...",fraction[:nd],flux)
    if box.arm=="wave":
        wave=box.ifft(state[6]);grad=box.ifft(state[6]*box.ik)
        kinetic+=fraction[2]*np.mean(np.sum(abs(grad)**2,axis=0))/(2*(a*box.m)**2)
        totalflux+=fraction[2]*np.imag(wave.conj()*grad)/(a*box.m)
    density=np.einsum("i,i...->...",fraction,den-1)
    source=np.einsum("i,i...->...",g,readout["C"])
    potential=-box.inv*source;W=.5*np.mean(density*box.ifft(potential).real)
    extra=-readout["force"]*box.inv-potential
    def work(j,forcepot):
        return -np.mean(np.sum(j*box.ifft(box.ik*forcepot).real,axis=0))/hub
    metric=work(totalflux,extra)
    _,_,entropy,phot=box.deposit(env[9:].reshape(4,4))
    eta=readout["phi"]-hub*state[3]/a
    entropywork=fraction[1]*work(flux[1],env[5]*3*eta+entropy)
    dragwork=fraction[1]*work(flux[1],env[7]*env[8]*(phot*np.sqrt(box.inv)+4*state[4]/(3*a)))
    def convex(gamma):
        return fraction[1]*np.mean(np.expm1(gamma*np.log(den[1]))-gamma*(den[1]-1))/(gamma*(gamma-1))
    wb=np.clip((ef+np.log(10))/np.log(10/8),0,1);factor=1.5*KB*1e4/(.61*MP*(SPEED*1000)**2)
    added=box.hot*factor*wb**2*(3-2*wb);added_N=box.hot*factor*6*wb*(1-wb)/np.log(10/8)
    ugas=env[5]*convex(5/3)+added*convex(1.5)
    thermal=box.hist.fn(ef,1)[5]*convex(5/3)+added_N*convex(1.5)
    return np.array([ef,kinetic,W,ugas,metric,entropywork,dragwork,thermal])
def main():
    guard();rows=[]
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        box=Box(case,arm,12,-1,2,1e-5,1);pack=[]
        def callback(index,ef,state,env):
            pack.append(energy(box,state,env,ef))
        pp=box.integrate(640,record=callback);series=np.array(pack)
        reference=load("boxes/time-"+arm+".npz")
        assert np.array_equal(pp["fields"],reference["fields"])
        ef,K,W,U,metric,entropy,drag,thermal=series.T
        allenergy=K+W+U
        rate=-2*K-W+metric+entropy+drag+thermal
        integral=lambda r:cumulative_simpson(r,x=ef,initial=0)
        expected=integral(rate);change=allenergy-allenergy[0]
        norm=np.max(abs(change))+np.max(abs(integral(abs(rate))))
        residual=float(np.max(abs(change-expected))/norm)
        missing=float(np.max(abs(change-integral(rate-thermal)))/norm)
        no_work=float(np.max(abs(change-integral(rate-metric-drag-thermal-entropy)))/norm)
        save("work-"+arm+".npz",columns=["N","K","W","U","metric","entropy","drag","heat"],series=series,energy_change=change,integrated_work=expected)
        rows.append(dict(arm=arm,error=residual,no_heating_work_error=missing,no_external_work_error=no_work,energy_scale=norm,
                         signed_metric_work=integral(metric)[-1],signed_thermal_work=integral(thermal)[-1]))
        print(arm,rows[-1],flush=True)
    csv_out("energy-budget.csv",rows)
if __name__=="__main__":main()

