from setup_stage import *
from box import KB,MP
from scipy.fft import rfft,irfft
import csv
def flux(density,peculiar,hc,kx,temperature=1e4,optical=.65,gamma=1.5,velocity=True,broadening=True,nout=64):
    side=density.shape[0]
    lines=density.reshape(side,-1);speeds=peculiar.reshape(side,-1)
    assert np.min(lines)>0
    period=2*np.pi/kx*hc*SPEED
    angle=2*np.pi*(np.arange(side)[:,None]/side+(speeds/period if velocity else np.zeros_like(speeds)))
    thermal=temperature*lines**(gamma-1)
    sigma2=2*KB*thermal/(MP*1e6)
    weights=optical*lines**2*(thermal/temperature)**(-.7)
    coeff=np.empty((nout//2+1,lines.shape[1]),complex)
    for harm in range(len(coeff)):
        blur=np.exp(-(np.pi*harm/period)**2*sigma2) if broadening else 1.
        coeff[harm]=np.mean(weights*np.exp(-1j*harm*angle)*blur,axis=0)
    coeff[-1]=coeff[-1].real
    tau=irfft(coeff,n=nout,axis=0,norm="forward")
    F=np.exp(-tau);mean=F.mean()
    contrast=F/mean-1;fk=rfft(contrast,axis=0,norm="forward")
    power=period*np.mean(abs(fk)**2,axis=1)
    return dict(mean=float(mean),p1=float(power[1]),p2=float(power[2]),p3=float(power[3]),period=float(period),
                min_tau=float(tau.min()),max_tau=float(tau.max()),mean_tau=float(tau.mean()),neutral_column=float(weights.mean()),
                var=float(np.mean(contrast**2)),parseval=float(np.mean(abs(fk[0])**2+abs(fk[-1])**2)+2*np.sum(np.mean(abs(fk[1:-1])**2,axis=1))),
                mean_flux_power=float(period*abs(fk[1].mean())**2))
def csv_out(name,rows):
    with (ROOT/name).open("x",newline="",encoding="utf8") as stream:
        out=csv.DictWriter(stream,fieldnames=list(rows[0]));out.writeheader();out.writerows(rows)
def control():
    side=256;den0=np.ones((side,1));speed0=np.zeros_like(den0)
    hub=.0003;mode=7.;A=.65;temp=1e4
    flat=flux(den0,speed0,hub,mode,temp,A)
    assert abs(flat["mean"]-np.exp(-A))<1e-13 and flat["p1"]<1e-27
    angle=2*np.pi*np.arange(side)[:,None]/side
    eps=1e-5;gamma=1.5;power=2-.7*(gamma-1)
    mono=flux(den0+eps*np.cos(angle),speed0,hub,mode,temp,A,gamma)
    exponent=(np.pi/mono["period"])**2*(2*KB*temp/(MP*1e6))
    slope=power-exponent*(gamma-1)
    theory=mono["period"]*(A*eps*slope*np.exp(-exponent)/2)**2
    velocity=flux(den0,eps*flat["period"]/(2*np.pi)*np.sin(angle),hub,mode,temp,A,gamma)
    vtheory=flat["period"]*(A*eps*np.exp(-exponent)/2)**2
    assert abs(mono["p1"]/theory-1)<2e-7 and abs(velocity["p1"]/vtheory-1)<2e-7
    dense=(1+.12*np.cos(angle)+.03*np.sin(2*angle));vel=4*np.sin(angle+.3)
    truth=flux(dense,vel,hub,mode,temp,A);shift=flux(np.roll(dense,13,0),np.roll(vel,13,0)+2.5,hub,mode,temp,A)
    assert abs(shift["p1"]/truth["p1"]-1)<1e-12 and abs(truth["mean_tau"]-truth["neutral_column"])<1e-12
    return dict(single_density=abs(mono["p1"]/theory-1),single_velocity=abs(velocity["p1"]/vtheory-1),translation=abs(shift["p1"]/truth["p1"]-1),uniform_power=flat["p1"])
def main():
    guard();analytical=control(); rows=[];sensitivity=[]
    for arm in ("wave","off","cold"):
        for tag in ("main-0","main-1","main-2","space","time","half","noheat"):
            name=tag.split("-")[0]+"-"+arm+(("-"+tag[-1]) if tag.startswith("main") else "")
            data=load("boxes/"+name+".npz")
            for idx in range(3,7):
                density,speeds=data["fields"][idx,:2];hub=data["background"][idx,1]
                result=flux(density,speeds,hub,data["fund"][0])
                assert result["min_tau"]>0 and abs(result["mean_tau"]-result["neutral_column"])<1e-12 and abs(result["parseval"]-result["var"])<1e-12
                rows.append(dict(arm=arm,box=tag,z=Z[idx],grid=density.shape[0],amplitude=float(data["amplitude"]),**result))
                if tag=="main-2":
                    fine=flux(density,speeds,hub,data["fund"][0],nout=96)
                    assert abs(result["p1"]/fine["p1"]-1)<1e-7
                    for temp,optical,vel in ((5000.,.65,True),(20000.,.65,True),(10000.,.4,True),(10000.,1.,True),(10000.,.65,False)):
                        probe=flux(density,speeds,hub,data["fund"][0],temp,optical,velocity=vel)
                        sensitivity.append(dict(arm=arm,z=Z[idx],thermal=temp,optical=optical,positions_with_velocity=vel,relative_p1=probe["p1"]/result["p1"]-1))
    csv_out("mock-sightlines.csv",rows);csv_out("readout-sensitivity.csv",sensitivity)
    effects=[]
    for z in Z[3:]:
        get=lambda arm,tag:next(row["p1"] for row in rows if row["arm"]==arm and row["box"]==tag and row["z"]==z)
        for arm in ("wave","off","cold"):
            ref=get(arm,"main-2")
            effects.append(dict(z=z,arm=arm,space_change=get(arm,"space")/ref-1,time_change=get(arm,"time")/ref-1,
                 first_transverse=get(arm,"main-1")/get(arm,"main-0")-1,second_transverse=ref/get(arm,"main-1")-1,
                 nonlinear_fraction=ref/(4*get(arm,"half"))-1,without_extra_gas_heat=get(arm,"noheat")/ref-1,
                 relative_to_wave=ref/get("wave","main-2"),relative_to_cold=ref/get("cold","main-2")))
    csv_out("mock-effects.csv",effects);write("readout-controls.json",analytical)
    for row in effects[-3:]: print(row)
if __name__=="__main__":main()

