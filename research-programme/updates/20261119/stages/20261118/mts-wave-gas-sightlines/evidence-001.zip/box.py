from setup_stage import *
from photon_frame import InertialHistory
from scipy.fft import fftn,ifftn,fftfreq
import argparse
KB=1.380649e-23;MP=1.67262192369e-27
class Box:
    def __init__(self,case,arm,side,which,cutoff,amplitude,hot,history=None):
        self.hist=InertialHistory(case) if history is None else history
        self.case=case;self.arm=arm;self.hot=hot;self.amplitude=amplitude;self.m=self.hist.m
        modes=self.hist.modes
        if which>=0:
            self.shape=(side,);fund=[modes[which]];points=[((1,),which,1.,0.)]
        else:
            self.shape=(side,)*3;fund=[modes[0],np.sqrt(modes[1]**2-modes[0]**2),np.sqrt(modes[3]**2-modes[0]**2)]
            points=[((1,0,0),0,1.,0.)]
            if cutoff>=1:points.extend([((1,1,0),1,.55,.71),((1,-1,0),1,.37,-.48)])
            if cutoff>=2:points.extend([((1,0,1),3,.48,1.11),((1,0,-1),3,.31,2.09)])
        self.points=points;self.fund=np.array(fund);self.nd=len(self.shape)
        self.axes=tuple(range(-self.nd,0))
        integer=np.array(np.meshgrid(*[fftfreq(size)*size for size in self.shape],indexing="ij"))
        self.k=integer*np.array(fund).reshape((-1,)+(1,)*self.nd)
        self.k2=np.sum(self.k**2,axis=0);self.ik=1j*self.k;self.zero=(0,)*self.nd
        self.inv=np.divide(1.,self.k2,out=np.zeros(self.shape),where=self.k2>0)
        self.mask=np.all(np.abs(integer)<side/3,axis=0)
        self.basis=np.zeros((4,*self.shape),complex)
        for point,index,strength,phase in points:
            assert abs(np.sqrt(self.k2[point])/modes[index]-1)<1e-14
            self.basis[(index,*point)]+=amplitude*strength*np.exp(1j*phase)/2
            self.basis[(index,*[-idx for idx in point])]+=amplitude*strength*np.exp(-1j*phase)/2
        self.gas_min=1.;self.dark_min=1.;self.mass_drift=0.;self.wave_mean0=1.
    def fft(self,field):return fftn(field,axes=self.axes,norm="forward",workers=1)
    def ifft(self,field):return ifftn(field,axes=self.axes,norm="forward",workers=1)
    def deposit(self,values):return np.einsum("j...,ji->i...",self.basis,values,optimize=False)
    def seed(self):
        init=self.deposit(self.hist.seed())
        state=np.zeros((7,*self.shape),complex);state[:6]=init
        if self.arm=="wave":
            density=1+self.ifft(init[2]).real;theta=self.ifft(init[5]).real
            assert density.min()>0
            wave=np.sqrt(density)*np.exp(1j*self.m*theta)
            state[6]=self.fft(wave)*self.mask;state[[2,5]]=0
            self.wave_mean0=float(np.sum(abs(state[6])**2))
        return state
    def evaluate(self,state,env,readout=False):
        scale,hub=env[:2];weights=env[2:5]; cs2,_,opacity,photbar=env[5:9]
        external,slip,entropy,phot=self.deposit(env[9:].reshape(4,4))
        both=3 if self.arm=="off" else 2
        den=np.array(state[:3]);theta=state[3:3+both]
        material=1+self.ifft(den[:both]).real
        self.gas_min=min(self.gas_min,float(material[1].min()))
        self.dark_min=min(self.dark_min,float(material[0].min()))
        if min(self.gas_min,self.dark_min)<=0 or material.min()<=0:raise ArithmeticError("density lost positivity: do not continue as single stream")
        flow=self.ifft(theta[:,None]*self.ik).real
        nflux=self.fft(flow*material[:,None])
        yflux=np.zeros((3,*self.shape),complex)
        yflux[:both]=-np.sum(self.ik*nflux,axis=1)*self.mask
        if self.arm=="wave":
            wave=self.ifft(state[6]);grad=self.ifft(state[6]*self.ik)
            wp=abs(wave)**2;den[2]=self.fft(wp-1)*self.mask
            self.mass_drift=max(self.mass_drift,abs(float(wp.mean())-self.wave_mean0))
            wflux=self.fft(np.imag(np.conj(wave)*grad)/self.m)
            yflux[2]=-np.sum(self.ik*wflux,axis=0)*self.mask
        weight=weights.reshape((3,)+(1,)*self.nd)
        gravity=np.sum(weight*(den-3*hub/scale*yflux*self.inv),axis=0)+external
        denominator=self.k2+3*sum(weights)
        phi=np.divide(-gravity,denominator,out=np.zeros_like(gravity),where=denominator>0);phi[self.zero]=0
        psi=(phi-slip*self.inv)*self.mask
        eta=phi-hub/scale*state[3]
        if readout:return dict(force=-self.k2*psi,gas=den[1]+3*phi,velocity=self.k2*state[4]/(scale*hub),C=den,flow=flow,phi=phi)
        result=np.zeros_like(state);result[:both]=yflux[:both]/(scale*hub)
        adv=self.fft(np.sum(flow**2,axis=1)/2)
        result[3:3+both]=-adv/(scale*hub)-scale/hub*psi
        gas=material[1]
        enthalpy=1.5*cs2*np.expm1((2/3)*np.log(gas))
        if self.hot:
            weight_hot=np.clip((np.log(scale)+np.log(10))/np.log(10/8),0,1)
            weight_hot=weight_hot**2*(3-2*weight_hot)
            enthalpy+=3*KB*1e4/(.61*MP*(SPEED*1000)**2)*weight_hot*np.expm1(.5*np.log(gas))
        drag=photbar*opacity*(phot*np.sqrt(self.inv)+4*state[4]/(3*scale))
        result[4]-=scale/hub*(self.fft(enthalpy)+3*cs2*eta+entropy+drag)
        if self.arm=="wave":result[6]=-1j*self.m*scale/hub*self.fft(self.ifft(psi).real*wave)
        result[3:6][(slice(None),*self.zero)]=0
        return result*self.mask
    def integrate(self,steps,record=None):
        history=self.hist;target=history.epochs
        times=np.unique(np.r_[np.linspace(history.start,history.end,steps+1),target])
        half=(times[:-1]+times[1:])/2;env=history.fn(times);envhalf=history.fn(half)
        swhole=history.sfn(times);shalf=history.sfn(half)
        state=self.seed();saves=set(np.searchsorted(times,target))
        outputs=[];fields=[];scales=[]
        def save_state(index):
            result=self.evaluate(state,env[index],True)
            outputs.append(np.stack([np.array([result[key][point] for point,*_ in self.points]) for key in ("force","gas","velocity")]))
            gas=self.ifft(result["gas"]).real+1
            fields.append(np.stack([gas,result["flow"][1,0]/env[index,0]*SPEED,self.ifft(result["C"][0]).real+1,self.ifft(result["C"][2]).real+1,self.ifft(result["force"]).real]))
            scales.append(env[index,:2])
        save_state(0)
        if record is not None:record(0,times[0],state,env[0])
        for i,delta in enumerate(np.diff(times)):
            def drift(value,space):
                if self.arm=="wave":value[6]*=np.exp(-.5j*self.k2*space/self.m)
                return value
            early=shalf[i]-swhole[i];late=swhole[i+1]-shalf[i]
            k1=self.evaluate(state,env[i]);mid=drift(state.copy(),early)
            k1h=drift(k1,early);k2=self.evaluate(mid+.5*delta*k1h,envhalf[i]);k3=self.evaluate(mid+.5*delta*k2,envhalf[i])
            end=drift(mid+delta*k3,late);k4=self.evaluate(end,env[i+1])
            state=drift(mid+delta*(k1h+2*k2+2*k3)/6,late)+delta*k4/6
            if record is not None:record(i+1,times[i+1],state,env[i+1])
            if i+1 in saves:save_state(i+1)
        return dict(transfer=np.array(outputs),fields=np.array(fields),background=np.array(scales),fund=self.fund,amplitude=self.amplitude,redshift=Z,
                    min_classical_gas=self.gas_min,min_cdm=self.dark_min,wave_mass_error=self.mass_drift,mean_classical_error=float(np.max(abs(state[:3][(slice(None),*self.zero)]))))
def execute(case,arm,side,which,cutoff,amp,hot,steps,label):
    folder=ROOT/"boxes";folder.mkdir(exist_ok=True);path=folder/(label+".npz")
    assert not path.exists()
    box=Box(case,arm,side,which,cutoff,amp,hot);result=box.integrate(steps)
    assert all(np.isfinite(v).all() for v in result.values())
    save(path,**result);print(label,"gas min",round(result["min_classical_gas"],6),"mass",result["wave_mass_error"],flush=True)
if __name__=="__main__":
    guard()
    case,arm,side,which,cutoff,amp,hot,steps,label=sys.argv[1:]
    execute(case,arm,int(side),int(which),int(cutoff),float(amp),int(hot),int(steps),label)

