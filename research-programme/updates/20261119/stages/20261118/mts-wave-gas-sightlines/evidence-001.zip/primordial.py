from setup_stage import *
from box import Box,KB,MP
from photon_frame import InertialHistory,frame_rhs
from sightlines import flux,csv_out
import physics
def spectrum():
    sys.path.insert(0,str(MATCH))
    import matching_common as source
    rows=[]
    for table in (TABLE,COLD):
        params=source.params_for(table)
        init=params.InitPower
        rows.append([init.As,init.ns,init.pivot_scalar,init.nrun,init.nrunrun])
    assert rows[0]==rows[1] and rows[0][-2:]==[0.,0.]
    write("primordial-settings.json",dict(As=rows[0][0],ns=rows[0][1],pivot_Mpc=rows[0][2],case="matched fixed-modulus scalar curvature modes; no galaxy or flux normalization",reference=sha(TABLE),seed=20261118))
def linear():
    def hot(history,states,env,arm,method):
        derivative,result=frame_rhs(history,states,env,arm,method)
        scale,hub=env[:2];weight=np.clip((np.log(scale)+np.log(10))/np.log(10/8),0,1)
        tangent=1.5*KB*1e4/(.61*MP*(SPEED*1000)**2)*weight**2*(3-2*weight)
        derivative[:,4]-=scale/hub*tangent*states[:,1]
        return derivative,result
    physics.History=InertialHistory;physics.lin=hot
    vals={}
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        vals[arm]=physics.advance(case,arm,"full",2048)
    save("warm-linear.npz",**vals)
def realization(case,arm,side,cut,seed,sign,steps,save_box=True):
    box=Box(case,arm,side,-1,cut,1.,1)
    meta=read("primordial-settings.json")
    rng=np.random.default_rng(meta["seed"]+seed)
    volume=float(np.prod(2*np.pi/box.fund));box.basis[:]=0
    pairs=[]
    for point,index,_,_ in box.points:
        k=box.hist.modes[index]
        power=2*np.pi**2/k**3*meta["As"]*(k/meta["pivot_Mpc"])**(meta["ns"]-1)
        val=sign*np.sqrt(power/volume)*np.exp(2j*np.pi*rng.random())
        box.basis[(index,*point)]=val;box.basis[(index,*[-idx for idx in point])]=np.conj(val)
        pairs.append([index,val.real,val.imag])
    if not save_box:return box,volume,pairs
    data=box.integrate(steps);data.update(volume=volume,pairs=pairs,phase_seed=seed,phase_sign=sign)
    save(f"boxes/power-{arm}-{cut}-{seed}-{sign}-{side}.npz",**data)
def analytic(data,pred,idx):
    kx=data["fund"][0];scale,hc=data["background"][idx]
    period=hc*SPEED*2*np.pi/kx
    gamma=1.5;temp=1e4;optical=.65
    expo=(np.pi/period)**2*(2*KB*temp/(MP*1e6))
    density_factor=2-.7*(gamma-1)-expo*(gamma-1)
    modes=load("heavy-inputs.npz")["k"]
    terms=[period*(optical*np.exp(-expo))**2*(float(re)**2+float(im)**2)*(density_factor*pred[idx,int(index),1]+(kx/modes[int(index)])**2*pred[idx,int(index),2])**2 for index,re,im in data["pairs"]]
    return sum(terms)
def campaign():
    guard();spectrum();linear()
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        for cut in (0,1,2):
            for sign in (1,-1):
                realization(case,arm,12,cut,0,sign,320)
        for sign in (1,-1):
            realization(case,arm,12,2,1,sign,320)
        realization(case,arm,18,2,0,1,320)
        realization(case,arm,24,2,0,1,320)
        print("fixed-primordial",arm,flush=True)
def scores():
    guard();rows=[];contrasts=[];pred=load("warm-linear.npz")
    for arm in ("wave","off","cold"):
        for path in sorted((ROOT/"boxes").glob("power-"+arm+"-*.npz")):
            _,_,cut,tail=path.stem.split("-",3);data=load(path)
            for idx in range(3,7):
                gas,vel=data["fields"][idx,:2];hub=data["background"][idx,1]
                power=flux(gas,vel,hub,data["fund"][0])["p1"];lin=analytic(data,pred[arm],idx)
                rows.append(dict(arm=arm,z=Z[idx],cut=int(cut),grid=gas.shape[0],seed=int(data["phase_seed"]),sign=int(data["phase_sign"]),p1=power,linear=lin,nonlinear=power/lin-1))
    def avg(arm,z,cut,seed=0,grid=12,signs=(1,-1)):
        group=[row for row in rows if row["arm"]==arm and row["z"]==z and row["cut"]==cut and row["seed"]==seed and row["grid"]==grid and row["sign"] in signs]
        assert len(group)==len(signs)
        return np.mean([r["p1"] for r in group]),group[0]["linear"]
    for z in Z[3:]:
        for arm in ("wave","off","cold"):
            full,linear_val=avg(arm,z,2)
            fine=avg(arm,z,2,grid=24,signs=(1,))[0]
            contrasts.append(dict(arm=arm,z=z,p1=full,phase_pair_vs_linear=full/linear_val-1,second_phase_pair=avg(arm,z,2,1)[0]/full-1,
                transverse_first=avg(arm,z,1)[0]/avg(arm,z,0)[0]-1,transverse_second=full/avg(arm,z,1)[0]-1,
                grid18_vs24=avg(arm,z,2,grid=18,signs=(1,))[0]/fine-1,grid12_vs24=avg(arm,z,2,signs=(1,))[0]/fine-1,
                p1_over_wave=full/avg("wave",z,2)[0],p1_over_cold=full/avg("cold",z,2)[0]))
    csv_out("fixed-power-sightlines.csv",rows);csv_out("fixed-power-contrasts.csv",contrasts)
    print(contrasts[-3:])
if __name__=="__main__":
    if sys.argv[1]=="campaign":campaign()
    else:scores()

