from setup_stage import *
import shutil, subprocess, difflib
def build():
    guard()
    ft=MATCH/"native/fortran";native=MATCH/"native";toolchain=EARLY/"toolchain/mingw64"
    metadata=json.loads((MATCH/"runs/build-1/status.json").read_text())
    path=ft/"equations.f90"; src=path.read_text()
    assert sha(path)==metadata["input_hashes"][str(path)]
    assert sha(native/"camb/cambdll.dll")==metadata["dll_sha256"]
    compiler=toolchain/"bin/gfortran.exe";assert sha(compiler)==metadata["compiler_sha256"]
    vars_line="    real(dl) q,aq,v\n    real(dl) G11_t"
    diag="            EV%OutputTransfer(Transfer_vel_baryon_cdm) = vb"
    assert src.count(vars_line)==src.count(diag)==1
    after=src.replace(vars_line,"    real(dl) obs_dr,obs_q\n"+vars_line).replace(diag,diag+"""
            obs_dr=grhog_t*clxg+grhor_t*clxr
            obs_q=grhog_t*qg+grhor_t*qr
            if (State%CP%Num_Nu_Massive/=0) then
                call MassiveNuVarsOut(EV,ay,ayprime,a,adotoa,dgrho=obs_dr,dgq=obs_q)
            end if
            EV%OutputTransfer(Transfer_tot_de)=(obs_dr+3*adotoa*obs_q/k)/2
            EV%OutputTransfer(Transfer_nonu)=dgpi
            EV%OutputTransfer(Transfer_tot)=delta_p_b-cs2*clxb
            EV%OutputTransfer(Transfer_nu)=qg""")
    local=ROOT/"observer-compile";local.mkdir()
    runtime=ROOT/"observer"; pkg=runtime/"native/camb"
    inputs={str(path):sha(path),str(compiler):sha(compiler)}
    try:
        rel=Path(os.path.relpath(toolchain,local))
        libdirs=["lib","lib/gcc/x86_64-w64-mingw32/14.2.0","x86_64-w64-mingw32/lib"]
        prefixes=["libexec/gcc/x86_64-w64-mingw32/14.2.0","bin",*libdirs]
        flags=["-B./",*["-B"+(rel/part).as_posix()+"/" for part in prefixes],*["-L"+(rel/part).as_posix() for part in libdirs],"-shared","-static","-cpp","-fopenmp","-O2","-fcheck=bounds","-fmax-errors=4","-fno-use-linker-plugin"]
        objects=[ft/key for key in metadata["commands"][-1] if key.endswith(".o")];assert len(objects)==39
        copies=[obj for obj in objects if obj.stem!="equations"]+list((ft/"WinMTS").glob("*.mod"))
        copies += [toolchain/prefixes[0]/item for item in ("f951.exe","collect2.exe")]+list((toolchain/"lib").glob("*.spec"))
        copies += [next(toolchain/part/obj for part in libdirs if (toolchain/part/obj).is_file()) for obj in ("dllcrt2.o","crtbegin.o","crtend.o")]
        for source in copies:
            inputs[str(source)]=sha(source);shutil.copyfile(source,local/source.name)
        (local/"equations.f90").write_text(after)
        (ROOT/"observer.diff").write_text("".join(difflib.unified_diff(src.splitlines(True),after.splitlines(True),"original","observer")),encoding="utf8")
        env=dict(os.environ,PATH=str(toolchain/"bin")+";"+os.environ["PATH"])
        for args in (["-I.","-J.","-ffree-line-length-none","equations.f90","-c","-o","equations.o"],[*[obj.name for obj in objects],"-o","observer.dll"]):
            proc=subprocess.run([str(compiler),*flags,*args],cwd=local,env=env,capture_output=True,text=True,timeout=170)
            if proc.returncode: raise RuntimeError(proc.stderr)
        pkg.mkdir(parents=True)
        for source in (native/"camb").iterdir():
            if source.is_file() and source.suffix in (".py",".dat"):
                inputs[str(source)]=sha(source);shutil.copyfile(source,pkg/source.name)
        srcs=[ft/"HighLExtrapTemplate_lenspotentialCls.dat",MATCH/"matching_common.py",MATCH/"stage_common.py"]
        for source,dest in zip(srcs,(pkg,runtime,runtime)):
            inputs[str(source)]=sha(source);shutil.copyfile(source,dest/source.name)
        shutil.copyfile(local/"observer.dll",pkg/"cambdll.dll")
        write("observer.json",dict(inputs=inputs,stock=metadata["dll_sha256"],binary=sha(pkg/"cambdll.dll"),overridden_outputs={"delta_tot_de":"external radiation/nu comoving Poisson source","delta_nonu":"total shear contribution to force","delta_tot":"gas thermal entropy residual in sync gauge","delta_nu":"photon synchronous momentum contrast"}))
    finally:
        assert local.resolve().parent==ROOT and local.name=="observer-compile"
        for item in local.iterdir():
            assert item.is_file() and not item.is_symlink()
            item.unlink()
        local.rmdir()
if __name__=="__main__":
    build()
