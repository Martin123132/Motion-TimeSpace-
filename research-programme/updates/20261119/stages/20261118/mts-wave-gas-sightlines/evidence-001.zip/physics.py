from setup_stage import *
from scipy.linalg import solve
from scipy.integrate import cumulative_simpson
from numpy.polynomial import Polynomial

class History:
    def __init__(self,case,stride=1):
        self.case=case;self.src=load(case+"-inputs.npz");data=self.src
        rows=np.unique(np.r_[np.arange(0,len(data["N"]),stride),len(data["N"])-1,data["target_indices"]])
        self.m=float(data["mass"]);self.modes=data["k"]
        self.start=data["N"][0];self.end=data["N"][-1];self.epochs=data["N"][data["target_indices"]]
        values=np.column_stack((data["a"],data["h"],data["g"].T,data["thermal"],data["external"].transpose(1,0,2).reshape(-1,16)))
        self.fn=CubicSpline(data["N"][rows],values[rows],axis=0)
        self.sfn=CubicSpline(data["N"],cumulative_simpson(1/(data["a"]*data["h"]),x=data["N"],initial=0))
    def seed(self):return np.column_stack((self.src["initC"],self.src["initV"]))

def split(env):
    return env[0],env[1],env[2:5],env[5:9],env[9:].reshape(4,4)

def lin(history,states,env,arm,prescription="full"):
    scale,hub,weights,thermal,ext=split(env);mode=history.modes[:,None]
    count=states.shape[2]; cs2,_,opacity,photbar=thermal
    den=states[:,:3];potential=states[:,3:6];external,slip,entropy,phot=ext.T[:,:,None] if ext.ndim>2 else ext.T[:,:,None]
    if prescription=="isolated":external,slip,entropy,phot=[np.zeros_like(external)]*4;opacity=0
    grav=np.sum(weights[None,:,None]*(den-3*hub/scale*potential),axis=1)
    phi=-(grav+external)/(mode**2+3*weights.sum())
    psi=phi-slip/mode**2
    eta=phi-hub*potential[:,0]/scale
    if prescription=="isolated":
        phi=-np.sum(weights[None,:,None]*den,axis=1)/mode**2
        psi=phi;eta=np.zeros_like(phi)
    deriv=np.empty_like(states)
    deriv[:,:3]=mode[:,None]**2*potential/(scale*hub)
    deriv[:,3:6]=-scale/hub*psi[:,None]
    drag=photbar*opacity*(phot-4*mode*(potential[:,0]-potential[:,1])/(3*scale))/mode
    deriv[:,4]-=scale/hub*(cs2*(den[:,1]+3*eta)+entropy+drag)
    if arm=="wave":
        ratio=mode/(scale*history.m)
        if prescription=="exact":
            press=(ratio/(1+np.sqrt(1+ratio**2)))**2*(den[:,2]+3*phi-3*hub*potential[:,2]/scale)
            deriv[:,2]-=3*press
        else:press=(ratio**2/4)*den[:,2]
        deriv[:,5]-=scale/hub*press
    elif arm=="cold":
        deriv[:,2]=0;deriv[:,5]=0
    else:assert arm=="off"
    return deriv,(-mode**2*psi,den[:,1]+3*phi,mode**2*potential[:,1]/(scale*hub))

def advance(case,arm,prescription,nstep,stride=1):
    hist=History(case,stride)
    target=hist.epochs
    times=np.unique(np.r_[np.linspace(hist.start,hist.end,nstep+1),target]);dt=np.diff(times)
    nodes=np.array([.5-np.sqrt(3)/6,.5+np.sqrt(3)/6])
    coll=np.array([[.25,.25-np.sqrt(3)/6],[.25+np.sqrt(3)/6,.25]])
    fixed=np.concatenate((np.zeros((4,6,1)),np.tile(np.eye(6),(4,1,1))),axis=2)
    state=hist.seed();outputs=[];save_idx=set(np.searchsorted(times,target))
    def record(idx):
        _,obs=lin(hist,state[:,:,None],hist.fn(times[idx]),arm,prescription)
        outputs.append(np.column_stack([val[:,0] for val in obs]))
    record(0)
    for first in range(0,len(dt),64):
        last=min(len(dt),first+64);steps=dt[first:last];pos=times[first:last,None]+steps[:,None]*nodes
        inputs=hist.fn(pos)
        coef=np.array([lin(hist,fixed,item,arm,prescription)[0] for item in inputs.reshape(-1,25)]).reshape(-1,2,4,6,7).transpose(0,2,1,3,4)
        const=coef[:,:,:,:,:1];mat=coef[:,:,:,:,1:]-const
        blocks=steps[:,None,None,None,None,None]*coll[None,None,:,None,:,None]*mat.transpose(0,1,3,2,4)[:,:,None,:,:,:]
        systems=np.eye(12)-blocks.reshape(-1,4,12,12)
        rhs=np.zeros((len(steps),4,2,6,7));rhs[:,:,:,:,:6]=np.eye(6)
        rhs[:,:,:,:,6]=steps[:,None,None,None]*np.einsum("ij,tkjl->tkil",coll,const[:,:,:,:,0])
        stages=np.linalg.solve(systems,rhs.reshape(-1,4,12,7)).reshape(-1,4,2,6,7)
        slope=mat@stages;slope[:,:,:,:,6]+=const[:,:,:,:,0]
        jump=steps[:,None,None,None]*slope.mean(axis=2);jump[:,:,:,:6]+=np.eye(6)
        for loc,trans in enumerate(jump):
            state=(trans[:,:,:6]@state[:,:,None])[:,:,0]+trans[:,:,6]
            if first+loc+1 in save_idx:record(first+loc+1)
    return np.array(outputs)
def main():
    guard();allout={};score={}
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold"),("lcdm","cold")):
        label=case+"-"+arm
        with np.load(LAST/("restart-"+case+"-"+("off" if arm=="off" else "on")+"/fields.npz")) as truth:
            targets=np.stack([truth[key][1:].T for key in ("force","gas","velocity")],axis=-1)
        for model,steps,stride in (("full",1024,1),("full",2048,1),("full",2048,2),("isolated",1024,1),("exact",1024,1)):
            result=advance(case,arm,model,steps,stride)
            key=f"{label}-{model}-{steps}-{stride}"
            allout[key]=result;score[key]=np.max(abs(result/targets-1),axis=(0,1)).tolist()
        allout[label+"-target"]=targets
        print(label,score[label+"-full-2048-1"],"isolated",score[label+"-isolated-1024-1"],flush=True)
    save("linear.npz",**allout);write("linear.json",score)
if __name__=="__main__":main()

