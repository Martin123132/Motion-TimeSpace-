from pathlib import Path
import sys, os, json, hashlib
for name in ("OMP_NUM_THREADS","MKL_NUM_THREADS","OPENBLAS_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[name]="1"
sys.dont_write_bytecode=True
import numpy as np
import psutil
from scipy.interpolate import CubicSpline
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
LAST=POST/"mts-forest-envelope-pressure-20261118"
SWITCH=POST/"mts-forest-pressure-switch-20261118"
BASE=POST/"condensate-origin-20261003"
EARLY=BASE/"native-two-field-transfer-20261007"
MATCH=BASE/"native-heavy-matching-20261007"
TABLE=BASE/"resolved-matter-spectrum-20261007/runs/projection/a225-w6-d8.npz"
COLD=EARLY/"runs/backgrounds/cold.npz"
LOCK="2110046a0899d444d61542a608de517fc19c0c2277fb76e9606274b409eea1f7"
SPEED=299792.458
Z=np.array([99.,49.,8.,5.4,5.,4.6,4.2])
def sha(path):
    with open(path,"rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    proc=psutil.Process();proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([proc.cpu_affinity()[0]])
    assert not any((path/"STOP-REQUESTED").exists() for path in (POST,BASE,LAST,ROOT))
    assert sha(LAST/"closeout.json")==LOCK
def write(name,record):
    with (ROOT/name).open("x",encoding="utf8") as stream:json.dump(record,stream,indent=2,allow_nan=False)
def read(name):
    return json.loads((ROOT/name).read_text(encoding="utf8"))
def save(name,**values):
    with (ROOT/name).open("xb") as stream:np.savez_compressed(stream,**values)
def load(name):
    with np.load(ROOT/name) as data:return dict(data)

