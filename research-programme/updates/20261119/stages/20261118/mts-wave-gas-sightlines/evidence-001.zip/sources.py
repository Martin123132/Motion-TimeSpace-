from setup_stage import *
def main(case):
    guard()
    sys.path.insert(0,str(ROOT/"observer"));sys.path.append(str(BASE/"radiation-and-slow-field-transfer-20261007"))
    import matching_common as native
    assert sha(Path(native.camb.__file__).parent/"cambdll.dll")==read("observer.json")["binary"]
    modes=np.load(LAST/"trace-driver.npz")["modes"]
    with np.load(TABLE) as tab:
        mass=float(tab["heavy_mass_mpc"]);rho=float(tab["matching_density"])
    params=native.params_for(TABLE if case=="heavy" else COLD)
    if case=="heavy":
        state=np.load(LAST/"trace-frozen.npz")["pred_1_1"][2,:,:2]
        params.DarkEnergy.set_table("SetMatching",modes,*state.T)
    elif case=="lcdm":params.DarkEnergy=native.camb.dark_energy.DarkEnergyFluid()
    else:assert case=="cold"
    params.DoLateRadTruncation=False
    model=native.camb.get_background(params);model.Params.Accuracy.IntTolBoost=6.4
    ef=np.unique(np.r_[np.linspace(-np.log(100),-np.log(5.2),4097),-np.log1p(Z)])
    times=model.conformal_time(np.expm1(-ef),tol=1e-10)
    cols=["a","H","etak","Weyl","delta_cdm","delta_baryon","v_newtonian_cdm","v_newtonian_baryon","v_baryon_cdm","mts_drho_h","mts_q_h","mts_dp_h","mts_drho_s","mts_q_s","delta_tot_de","delta_nonu","delta_tot","delta_nu","mts_match_count"]
    raw=model.get_time_evolution(modes,times,vars=cols,lAccuracyBoost=4)
    val=lambda name:raw[:,:,cols.index(name)]
    scale=val("a")[0].copy();hub=val("H")[0].copy(); k=modes[:,None]
    assert np.isfinite(raw).all() and np.all(val("mts_match_count")==(case=="heavy")) and np.all(np.diff(scale)>0)
    thermal=model.get_background_time_evolution(times,vars=["cs2b","T_b","opacity"],format="dict")
    den=model.get_background_densities(scale,vars=["cdm","baryon","photon"])
    g=np.array([den["cdm"]/scale**2,den["baryon"]/scale**2,(rho/scale) if case=="heavy" else np.zeros_like(scale)])/2
    cd=val("v_newtonian_cdm"); et=val("etak")/k
    phi=et+(hub/k)**2*cd;force=k*k*phi-2*val("Weyl")
    density=np.stack([val("delta_cdm")-3*et,val("delta_baryon")-3*et,val("mts_drho_h")*scale/rho-3*et],axis=-1)
    growth=np.stack([cd,val("v_newtonian_baryon"),cd-k*scale*val("mts_q_h")/(rho*hub)],axis=-1)
    if case!="heavy":density[:,:,2]=0;growth[:,:,2]=0
    potvel=scale[None,:,None]*hub[None,:,None]*growth/k[:,:,None]**2
    internal=np.sum(g.T[None,:,:]*(density+3*phi[:,:,None]-3*(hub/k)[:,:,None]**2*growth),axis=2)
    external=val("delta_tot_de")+(val("mts_drho_s")+3*hub*val("mts_q_s")/k)/2
    slip=val("delta_nonu")
    residual=abs(internal+external+slip-force)/np.maximum(abs(force),1e-30)
    source=np.stack([external,slip,val("delta_tot"),val("delta_nu")],axis=-1)
    momentum_err=np.max(abs(growth[:,:,1]-(cd-k/hub*val("v_baryon_cdm")))/np.maximum(abs(growth[:,:,1]),1e-30))
    assert residual.max()<2e-5 and momentum_err<2e-5
    anchor=np.array([np.argmin(abs(ef+np.log1p(z))) for z in Z])
    with np.load(LAST/("late-225pred.npz" if case=="heavy" else "late-"+case+".npz")) as ref:
        checks=[float(np.max(abs(item[:,anchor]/ref[key][1:]-1))) for item,key in ((force,"force"),(density[:,:,1]+3*phi,"gas"),(growth[:,:,1],"velocity"))]
    assert max(checks)<2e-5
    save(case+"-inputs.npz",N=np.log(scale),a=scale,h=hub,tau=times,k=modes,mass=mass,g=g,thermal=np.stack([thermal["cs2b"],thermal["T_b"],thermal["opacity"],den["photon"]/den["baryon"]],axis=-1),external=source,
         initC=density[:,0],initV=potvel[:,0],target_indices=anchor,reference_z=Z)
    save(case+"-check.npz",C=density,theta=potvel,phi=phi,force=force,U=growth)
    write(case+"-source.json",dict(closure=float(residual.max()),baryon_velocity=float(momentum_err),replay=checks,source=sha(ROOT/(case+"-inputs.npz")),target=sha(ROOT/(case+"-check.npz"))))
    print(case,len(scale),checks,"closure",residual.max(),flush=True)
if __name__=="__main__":
    main(sys.argv[1])

