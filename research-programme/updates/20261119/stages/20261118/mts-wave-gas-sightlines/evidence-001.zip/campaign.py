from setup_stage import *
from box import execute
import time
def run(id,case,arm,side,which,cutoff,amp,hot,steps):
    path=ROOT/"boxes"/(id+".npz")
    if path.exists():
        with np.load(path) as check:
            assert check["fields"].shape[0]==len(Z) and float(check["amplitude"])==amp
        return
    guard();execute(case,arm,side,which,cutoff,amp,hot,steps,id)
def modes():
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold"),("lcdm","cold")):
        for which in range(4):
            label=f"probe-{arm if case!='lcdm' else case}-k{which}"
            run(label,case,arm,12,which,0,1e-8,0,512)
        run("probe-repeat-"+arm+"-"+case,case,arm,16,3,0,2e-8,0,1024)
def main3():
    target=load("linear.npz")
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold"),("lcdm","cold")):
        for which in range(4):
            label=f"probe-{arm if case!='lcdm' else case}-k{which}"
            probe=load("boxes/"+label+".npz");obs=probe["transfer"][:,:,0]*2/float(probe["amplitude"])
            assert np.max(abs(obs/target[case+"-"+arm+"-target"][:,which]-1))<2e-5
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        for cutoff in (0,1,2):
            run(f"main-{arm}-{cutoff}",case,arm,12,-1,cutoff,1e-5,1,320)
        for tag,side,steps,amp,hot in (("space",18,320,1e-5,1),("time",12,640,1e-5,1),("half",12,320,5e-6,1),("noheat",12,320,1e-5,0)):
            run(tag+"-"+arm,case,arm,side,-1,2,amp,hot,steps)
if __name__=="__main__":
    guard()
    if sys.argv[1]=="modes":modes()
    else:main3()

