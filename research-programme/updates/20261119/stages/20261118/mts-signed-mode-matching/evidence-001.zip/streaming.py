from assess import *
import experiment

STREAM=CDLL(str(ROOT/'stream.dll')).original_additive_step
STREAM.argtypes,STREAM.restype=KERNEL.argtypes,KERNEL.restype
OPTIONS={'live':(0,0,0),'literal':(0,0,0),'included':(1,1,0),'density_only':(1,0,0),
         'flux_only':(0,1,0),'include_pressure':(1,1,1)}
DENSE=COMMON/'native-heavy-matching-20261007/runs/independent-probes/dense-4001.npz'


@lru_cache(None)
def onset():
    with np.load(DENSE) as archive:
        slot=int(np.flatnonzero(archive['modes']==1.).item())
        get=dict(zip(archive['names'],archive['values'][slot].T))
        times=archive['conformal_time']
        brackets=[]
        for key in ('v_neutrino','v_photon','E_2'):
            last=np.flatnonzero(get[key]!=0)[-1]
            assert last<len(times)-2 and np.all(get[key][last+1:]==0)
            brackets.append(times[last:last+2].tolist())
    assert brackets[1]==brackets[2]
    bounds=[max(brackets[0][0],brackets[1][0]/2.5),min(brackets[0][1],brackets[1][1]/2.5)]
    assert bounds[0]<bounds[1] and 15*2.5/min(MODES)<bounds[0]
    dominance={}
    for case in ['cold','heavy']:
        with np.load(POST/'mts-integrated-defect-20261112'/(case+'-native-clock.npz')) as tab:
            const=tab['constants']
        with np.load(POST/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz')) as tab:
            first,step=tab['metadata'];coeff=tab['values'][0]
        tau=first*np.exp(step*np.arange(len(coeff)))
        aval=tau*coeff
        dom=12.5*(const[2]+const[3])/(const[0]+const[1])
        dominance[case]=float(tau[np.searchsorted(aval,dom)])
        assert dominance[case]>bounds[1]
    return dict(neutrino_bracket=brackets[0],photon_bracket=brackets[1],combined=bounds,verydom=dominance)


def run_stream(index,case,scheme,timing,options,cap=.24):
    guard();wave=MODES[index]
    record=load(f'late-{index}-{case}-{scheme}-main-{.24 if scheme=="primary" else .12:g}')
    early=load(f'early-{index}-{case}-{scheme}')
    params_record=early['params']
    _,args,_,cfg,const=setup(case,wave,scheme)
    np.testing.assert_array_equal(params_record,args[6])
    center,_,amp,_=metadata()['main']
    amp=amp if case=='heavy' else 0.
    state=prepare_vector('full',early['main_state'],record['projection'],args)
    x0=float(early['main_x'])
    params=np.r_[args[6],0.,0.,0.,0.,0.]
    params[13:15]=amp,case=='heavy'
    args=(*args[:5],args[5]+(12 if scheme=='native5' else 0),params,*args[7:])
    lower,upper=onset()['combined']
    start={'early':lower,'mid':.5*(lower+upper),'late':upper}[timing]
    transitions=np.array([x0,start*wave,2.5*start*wave,wave*record['clock'][-1]])
    dense=np.geomspace(wave*start*.98,2.5*start*wave*1.02,181)
    coords=np.unique(np.r_[wave*record['clock'],transitions,dense])
    assert coords[0]>=x0-1e-12
    coords=coords[coords>=x0]
    experiment.KERNEL=STREAM
    first,last=np.searchsorted(coords,transitions[:2])
    pre=march(state,args,coords[first:last+1],cap)
    for name in options:
        raw=np.zeros((len(coords),53))
        raw[first:last+1]=pre
        local=state.copy()
        params[18:21]=OPTIONS[name]
        for part in (1,2):
            lo,hi=np.searchsorted(coords,transitions[part:part+2])
            params[16:18]=[(name!='live'),(name!='live') and part==2]
            raw[lo:hi+1]=march(local,args,coords[lo:hi+1],cap)
        vals=reduced(raw,wave,const,amp)
        ids=np.searchsorted(coords,wave*record['clock'][record['epochs']])
        assert peak(vals[ids,0]/LATE-1)<1e-7
        write(f'stream-{index}-{case}-{scheme}-{timing}-{name}',x=coords,values=vals,epochs=ids,
              switch_x=transitions,options=OPTIONS[name],wave=wave,names=NAMES)
        params[16:21]=0.
    print('streaming',index,case,scheme,timing,','.join(options),flush=True)


def radiation_identities():
    records=[]
    for case,path in [('heavy',DENSE),('cold',COMMON/'native-heavy-matching-20261007/runs/late-cold/evolution.npz')]:
        with np.load(path) as tab:
            slot=int(np.flatnonzero(tab['modes']==1.).item())
            get=dict(zip(tab['names'],tab['values'][slot].T));times=tab['conformal_time']
        wave=1.
        with np.load(POST/'mts-integrated-defect-20261112'/(case+'-native-clock.npz')) as tab: const=tab['constants']
        with np.load(POST/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz')) as tab:
            first,step=tab['metadata'];thermal=tab['values']
        scale=get['a'];hub=get['H']/wave;eta=get['etak']/wave
        mask=scale>0
        scale=scale[mask];hub=hub[mask];eta=eta[mask];times=times[mask];get={key:val[mask] for key,val in get.items()}
        tau=first*np.exp(step*np.arange(thermal.shape[1]))
        opacity=np.interp(scale,tau*thermal[0],thermal[4])/wave
        nodes,weights=roots_laguerre(32);weights*=nodes**3/(1+np.exp(-nodes))/(7*np.pi**4/120)
        bgr=np.hypot(1,scale[:,None]*const[8]/nodes)@weights
        coefficients=np.array([const[0]/scale,const[1]/scale,const[14]*bgr/scale**2])/wave**2
        load=np.array([get['delta_cdm'],get['delta_baryon'],get['delta_nu']])
        d=np.sum(coefficients*load,axis=0)
        fields=(get['mts_drho_s']+get['mts_drho_h'])/wave**2
        for component in ['massless','photon']:
            after=times>(1 if component=='massless' else 2.5)*onset()['combined'][1]+2.
            data=get['delta_neutrino' if component=='massless' else 'delta_photon']
            for want in [0,1]:
                used=d+want*fields;z=(eta+.5*used)/hub
                expected=4*(eta+used)-(4*opacity*(get['v_baryon_cdm']+z) if component=='photon' else 0)
                error=expected[after]-data[after]
                records.append(dict(branch=case,component=component,include_scalar_in_reconstruction=want,clocks=int(sum(after)),
                         density_error_over_active_peak=peak(error)/peak(data[after]),rms_error=np.sqrt(np.mean(error**2)),
                         final_expected=expected[-1],final_saved=data[-1],
                         inferred_flux_shift_from_adding_fields_at_end=-2*fields[-1]/(3*hub[-1])))
    table('radiation-formula-in-native-record',records)


if __name__=='__main__':
    save(ROOT/'radiation-switch-bounds.json',onset());radiation_identities()
    for idx in range(len(MODES)):
        for case in ('heavy','cold'):
            suite=list(OPTIONS) if idx in (4,7) else ['literal','included']
            run_stream(idx,case,'primary','mid',suite)
            if idx in (4,7):
                run_stream(idx,case,'native5','mid',['literal','included'],.12)
                if idx==7:
                    for timing in ['early','late']:
                        run_stream(idx,case,'primary',timing,['literal','included'],.12)
