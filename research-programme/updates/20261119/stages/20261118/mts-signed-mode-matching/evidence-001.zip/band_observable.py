from assess import *
from scipy.integrate import simpson
import ast


def run():
    guard()
    source=COMMON/'radiation-and-slow-field-transfer-20261007/radiation_common.py'
    params={entry.targets[0].id:ast.literal_eval(entry.value) for entry in ast.parse(source.read_text()).body if
            isinstance(entry,ast.Assign) and isinstance(entry.targets[0],ast.Name) and entry.targets[0].id in ('AS','NS','H0')}
    folder=SPEC/'results/spectrum'
    old=json.loads((folder/'status.json').read_text())
    assert old['state']=='complete'
    rows=[]
    for case in ('heavy','cold'):
        branch=next(row['central'] for row in old['branches'] if row['label']==case)
        with np.load(folder/(case+'.npz')) as packet:
            allowed=packet['modes']<=5.
            modes=packet['modes'][allowed]
            scal=np.log(packet['scales']);values=packet['delta_m'][allowed];vel=packet['velocity_cdm'][allowed]
        mask=np.isin(modes,MODES)
        assert np.array_equal(modes[mask],MODES)
        for info in branch:
            z=info['z'];pos=int(np.argmin(abs(scal+np.log1p(z))));assert abs(scal[pos]+np.log1p(z))<1e-12
            density=values[:,pos];speed=vel[:,pos]
            def kernel(loggrid):
                grid=np.exp(loggrid);x=grid*8/(params['H0']/100.)
                w=np.ones(len(grid));small=abs(x)<.05
                w[small]=1-x[small]**2/10+x[small]**4/280-x[small]**6/15120
                w[~small]=3*(np.sin(x[~small])-x[~small]*np.cos(x[~small]))/x[~small]**3
                return params['AS']*(grid/.05)**(params['NS']-1)*w*w
            def base(loggrid):
                return [np.exp(CubicSpline(np.log(modes),np.log(val))(loggrid)) for val in (density,speed)]
            whole=np.linspace(np.log(modes[0]),np.log(modes[-1]),8193)
            dm,vc=base(whole);weight=kernel(whole)
            std=np.sqrt(simpson(weight*dm**2,x=whole));fv=simpson(weight*dm*vc,x=whole)/std
            assert abs(std/info['sigma8_m']-1)<1e-10 and abs(fv/info['fsigma8_cdm_m']-1)<1e-10
            test=np.linspace(np.log(MODES[0]),np.log(MODES[-1]),2049)
            dm,vc=base(test);weight=kernel(test)
            for method in ('full','literal','heavy_only'):
                fields=[]
                for idx,wave in enumerate(MODES):
                    path=(f'late-{idx}-{case}-primary-main-0.24' if method=='full' else f'stream-{idx}-{case}-primary-mid-{method}')
                    with np.load(ROOT/(path+'.npz')) as pack:
                        val=pack['full' if method=='full' else 'values'][pack['epochs'][pos]]
                    fields.append([val[13],(val[14]-1.5*val[20]/wave**2)/(val[1]/wave)])
                frac=np.array(fields)/np.c_[density[mask],speed[mask]]
                assert np.all(frac>0)
                for interpol in ('cubic','pchip'):
                    func=CubicSpline if interpol=='cubic' else PchipInterpolator
                    ratio=np.exp(func(np.log(MODES),np.log(frac),axis=0)(test))
                    ds2=simpson(weight*dm**2*(ratio[:,0]**2-1),x=test)
                    dcross=simpson(weight*dm*vc*(ratio[:,0]*ratio[:,1]-1),x=test)
                    news=np.sqrt(std**2+ds2);newf=(fv*std+dcross)/news
                    rows.append(dict(branch=case,z=z,method=method,interpolation=interpol,
                        old_sigma8=std,old_f8=fv,band_fraction_of_old_variance=simpson(weight*dm**2,x=test)/std**2,
                        band_delta_variance=ds2,band_delta_cross=dcross,
                        sigma8_shift_only_if_outside_fixed=news-std,f8_shift_only_if_outside_fixed=newf-fv))
    table('eight-mode-growth-weight',rows)


if __name__=='__main__':
    run()
