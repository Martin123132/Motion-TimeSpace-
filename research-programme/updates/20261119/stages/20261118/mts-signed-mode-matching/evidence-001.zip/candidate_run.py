import streaming
from streaming import ROOT,CDLL,KERNEL,MODES


if __name__=='__main__':
    streaming.STREAM=CDLL(str(ROOT/'heavy_only.dll')).original_additive_step
    streaming.STREAM.argtypes,streaming.STREAM.restype=KERNEL.argtypes,KERNEL.restype
    streaming.OPTIONS['heavy_only']=(1,1,0)
    for idx in range(len(MODES)):
        for case in ('heavy','cold'):
            streaming.run_stream(idx,case,'primary','mid',['heavy_only'])
