from stream_score import *
import ast


def readcsv(name):
    with (ROOT/(name+'.csv')).open(encoding='utf8') as handle:return list(csv.DictReader(handle))


def verify():
    guard()
    tests={}
    def test(key,cond):
        if not cond:raise AssertionError(key)
        tests[key]=True
    prior=json.loads((PREV/'closeout.json').read_text())
    for path,info in prior['files'].items():
        test('prior '+path,digest(PREV/path)==info['sha256'] and (PREV/path).stat().st_size==info['bytes'])
    frozen=json.loads((ROOT/'forecast-lock.json').read_text())
    test('original forecast blind receipt',frozen['paired_packets']==144 and frozen['fold_packets']>60 and frozen['prior']==OLDSEAL)
    for path,sha in frozen['files'].items():
        test('frozen '+path,digest(POST/path)==sha)
    paths={}
    for label in ('cold',*[v[0] for v in CONFIG.values()]):
        status=json.loads((RUNS/label/'status.json').read_text())
        assert status['state']=='complete'
        for path in [RUNS/label/PACKET,RUNS/label/'background.npz']:
            paths[str(path)]=digest(path)
            test('upstream '+label+'/'+path.name, paths[str(path)]==status['input_hashes'][str(path)])
    for tag,(label,key,width,degree) in CONFIG.items():
        path=RUNS/'projection'/f'{key}-w{width}-d{degree}.npz'
        paths[str(path)]=digest(path)
        test('actual matching source '+tag,paths[str(path)]==json.loads((RUNS/label/'status.json').read_text())['source_hash'])
    for idx,wave in enumerate(MODES):
        heavy=load(f'late-{idx}-heavy-primary-main-0.24')
        cold=load(f'late-{idx}-cold-primary-main-0.24')
        ref=reference(idx,'heavy')
        test(f'paired finite scales {idx}',np.array_equal(heavy['scales'],cold['scales']) and np.all(np.isfinite(heavy['full'])) and
             peak(heavy['full'][:,0]/cold['full'][:,0]-1)<1e-8 and not cold['full'][:,8:12].any())
        test(f'late observed signed density {idx}',np.array_equal(np.sign(heavy['full'][heavy['epochs'],11]),np.sign(ref['comoving_h'])))
        test(f'initial coordinate and linearly propagated matter response {idx}',abs(heavy['full'][0,7]-heavy['exact_event'][2]*(wave/5))<1e-14 and
             peak(heavy['full'][:,13]-sum(heavy[case][:,13] for case in ('density','velocity','environment')))<TOL*peak(heavy['full'][:,13]))
        for arm in ['literal','heavy_only']:
            with np.load(ROOT/f'stream-{idx}-cold-primary-mid-{arm}.npz') as packet:
                if arm=='literal':literal=packet['values']
                else:test(f'cold candidate identical at every clock {idx}',np.array_equal(literal,packet['values']))
    event=readcsv('event-balance');constest=readcsv('regeneration')
    test('derived junction laws at all 40 events',len(event)==40 and max(max(abs(float(r[k])) for r in event) for k in
         ('Weyl_jump_identity_over_total','Cx_jump_identity_over_total','intrinsic_metric_change'))<2e-13)
    test('comoving stress continuity integral in all modes',all(float(row['fluid_integral_error_over_peak'])<1e-12 for row in constest))
    test('three independent regeneration crossings',sum(int(r['predicted_recovery_count']) for r in constest)==3)
    anchor=readcsv('k1-native-recovery-bracket')
    test('pre-frozen k=1 crossing bracket, later file starts too late',len(anchor)==2 and anchor[0]['inside']=='True' and anchor[1]['observed_crossings']=='0' and
         float(anchor[1]['sample_min'])>float(anchor[1]['predicted_root']))
    for label,fold in json.loads((ROOT/'fold-forecast.json').read_text()).items():
        test(label+' finite positive temporal and k curvature',.93<fold['k']<.95 and .00032<fold['a']<.00033 and
             fold['S_N']>0 and fold['S_k_S_kk'][-1][1]>0 and abs(fold['S'])<1e-11)
    law=readcsv('fold-law')
    test('six independent two-percent brackets and disappearance',len(law)==6 and all(r['bracket_confirmed']=='True' and float(r['after_fold'])>0 for r in law))
    switched=readcsv('radiation-formula-in-native-record')
    test('both native radiation density outputs reproduced in both branches',len(switched)==8 and
         max(float(r['density_error_over_active_peak']) for r in switched if r['include_scalar_in_reconstruction']=='0')<TOL)
    gap=readcsv('power-gap-budget')
    test('power effect, both controls and all modes',len(gap)==8 and all(.99<float(row['gap_explained_by_literal'])<1.01
         and abs(float(row['candidate_fractional_vs_full']))<TOL for row in gap))
    at=readcsv('streaming-density-versus-flux')
    test('independent hybrid interventions',len(at)==4 and all(abs(float(row['exact_split_residual']))<1e-12 and float(row['flux_share'])>.999 for row in at))
    comp=json.loads((ROOT/'candidate-compile-only.json').read_text());prov=json.loads((ROOT/'candidate-provenance.json').read_text())
    test('compile-only candidate and unchanged actual release source',not comp['native_simulation_run'] and comp['object_bytes']>0 and
         digest(prov['path'])==comp['source_sha']==prov['source'] and comp['patch_sha']==digest(ROOT/'candidate-streaming-heavy-only.patch'))
    test('no temporary compile folder or bytecode',not list(ROOT.glob('compile-*')) and not (ROOT/'__pycache__').exists())
    for path in ROOT.glob('*.py'):ast.parse(path.read_text())
    scores=readcsv('late-reference-comparison')
    test('precision gates not relabeled to force agreement',all((float(r['relative_to_reference_peak'])<=TOL)==(r['within_tolerance']=='True') for r in scores))
    return dict(checks=tests,nchecks=len(tests),comparison_source_hashes=paths,all_channel_comparisons=len(scores),
                nonpassing_peak_channels=sum(r['within_tolerance']=='False' for r in scores),established_tolerance=TOL,
                zero_fresh_fits=True,prior_files=len(prior['files']))


if __name__=='__main__':
    result=verify();path=ROOT/'verification.json'
    if path.exists():assert result==json.loads(path.read_text())
    else:save(path,result)
    if '--seal' in sys.argv:
        files={p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(ROOT.iterdir()) if p.is_file() and p.name!='closeout.json'}
        assert 'RESULTS.md' in files and 'verification.json' in files
        seal=ROOT/'closeout.json'
        if seal.exists():assert json.loads(seal.read_text())['files']==files
        else:save(seal,dict(utc=datetime.now(timezone.utc).isoformat(),prior=OLDSEAL,files=files,total_bytes=sum(r['bytes'] for r in files.values())))
        print('seal',digest(seal),len(files))
    print(result['nchecks'],result['nonpassing_peak_channels'],result['all_channel_comparisons'])
