from late import *
from functools import lru_cache
from scipy.optimize import minimize_scalar,brentq

def packet_name(wave,scheme,tag):
    return f'fold-{scheme}-{tag}-'+float(wave).hex().replace('.','_').replace('+','p')


@lru_cache(maxsize=220)
def segment(wave,scheme='primary',tag='main'):
    guard();wave=float(wave)
    name=packet_name(wave,scheme,tag)
    if (ROOT/(name+'.npz')).exists():
        packet=load(name)
        assert packet['wave']==wave and str(packet['driver'])==digest(Path(__file__))
        return packet
    center,etime,abundance,_=metadata()[tag]
    _,_,width,degree=CONFIG[tag]
    state,args,x0,cfg,const=setup('heavy',wave,scheme)
    with np.load(WAVE_INPUT) as model:
        phases=CubicSpline(model['heavy_efold'],model['phase_h'])
    with np.load(RUNS/'exact-grid'/PACKET) as earlygrid:
        keep=abs(earlygrid['background_phase']-phases(np.log(center)))<width*np.pi+.5
    sample=EARLY[keep]*wave
    pre=(etime-.012)*wave
    cuts=np.unique(np.r_[x0,np.geomspace(.001*wave,sample[-1],39),pre,52.])
    coords=np.unique(np.r_[cuts,sample])
    result=np.zeros((len(coords),53))
    saved=None
    for left,right in zip(cuts[:-1],cuts[1:]):
        first,last=np.searchsorted(coords,[left,right])
        flag=args[5]+(12 if scheme=='native5' and left>=52 else 0)
        arg=(*args[:5],flag,*args[6:])
        cap=min(.04,origin.SCHEMES[scheme][2]/np.hypot(1,3e-6*right*max(cfg['masses'])/wave**2))
        if left==pre:
            trial=etime*wave
            for attempt in range(5):
                saved=state.copy()
                tip=march(saved,arg,np.array([left,trial]),cap)[-1]
                error=np.log(tip[0]/center)
                if abs(error)<2e-14:break
                trial-=error/(tip[1]/5)
            assert abs(error)<2e-14 and trial>left
        result[first:last+1]=march(state,arg,coords[first:last+1],cap)
    assert saved is not None
    raw=result[np.searchsorted(coords,sample)]
    projection,design=projected(wave,raw[:,0],raw,center,abundance,width,degree)
    params=args[6].copy();params[13:15]=[abundance,1.]
    args=(*args[:5],args[5]+(12 if scheme=='native5' else 0),params,*args[7:])
    ngrid=np.linspace(np.log(center),np.log(.00045),1701 if scheme!='fine' else 3401)
    scale=np.exp(ngrid);scale[0]=center
    xs=geometry(cfg,const,wave,center,trial,saved,params,abundance,scale);xs[0]=trial
    saved=prepare_vector('full',saved,projection[:2],args)
    out=march(saved,args,xs,.12 if scheme=='fine' else .24)
    sd=out[:,40]+3*out[:,45]*out[:,41]
    slope=(out[:,51]-(1+1.5*out[:,37])*out[:,41])/out[:,45]
    obs=reduced(out,wave,const,abundance)
    assert max(abs(obs[:,0]/scale-1))<1e-8
    write(name,wave=wave,N=ngrid,S=sd,S_N=slope,weyl=obs[:,12],matter=obs[:,13],cdm=obs[:,2],flow=obs[:,15:17],
          projection=projection,event_x=trial,design=design,driver=digest(Path(__file__)))
    return load(name)


def shape(wave,scheme='primary',tag='main'):
    from scipy.interpolate import CubicHermiteSpline
    data=segment(float(wave),scheme,tag)
    return CubicHermiteSpline(data['N'],data['S'],data['S_N'],extrapolate=False)


def recovery(wave,scheme='primary',tag='main'):
    data=segment(float(wave),scheme,tag)
    hits=np.flatnonzero((data['S'][:-1]<0)&(data['S'][1:]>=0))
    if not len(hits):
        return float('nan')
    assert len(hits)==1
    pos=hits[0]
    return brentq(shape(wave,scheme,tag),*data['N'][pos:pos+2],xtol=2e-14)


def locate(scheme='primary',tag='main'):
    func=lambda w:-recovery(w,scheme,tag)
    search=minimize_scalar(func,bounds=(.90,.985),method='bounded',options={'xatol':6e-7})
    assert search.success and .902<search.x<.983
    wave=float(search.x);efold=-float(search.fun)
    curve=shape(wave,scheme,tag)
    derivatives=[]
    for width in (.001,.0005,.00025):
        down,up=[float(shape(w,scheme,tag)(efold)) for w in (wave-width,wave+width)]
        derivatives.append([(up-down)/(2*width),(up+down-2*curve(efold))/width**2])
    rate=float(curve(efold,1))
    return dict(k=wave,N=efold,a=np.exp(efold),S=float(curve(efold)),S_N=rate,S_k_S_kk=derivatives,
                sqrt_coefficient=float(np.sqrt(2*rate/derivatives[-1][1])))


def run():
    variants=[('primary','main'),('fine','main'),('native5','main'),('primary','earlier'),('primary','later')]
    results={scheme+'_'+tag:locate(scheme,tag) for scheme,tag in variants}
    ans=results['primary_main']
    rows=[]
    for gap in (.00064,.00016,.00004):
        now=ans['N']-gap;pred=ans['sqrt_coefficient']*np.sqrt(gap)
        for sign in (-1,1):
            offset=sign*pred
            ins=ans['k']+.98*offset;out=ans['k']+1.02*offset
            physical=shape(ans['k']+offset)(now)
            denominator=ans['S_N']*gap
            before=float(shape(ins)(now));after=float(shape(out)(now))
            above=float(shape(ans['k']+offset)(ans['N']+gap))
            rows.append(dict(log_time_before=gap,side=sign,k_pred=ans['k']+offset,S_over_local_depth=physical/denominator,
                             two_percent_inside=before,two_percent_outside=after,after_fold=above,
                             bracket_confirmed=bool(before<0<after)))
    table('fold-law',rows)
    save(ROOT/'fold-forecast.json',results)
    print('predicted fold',ans,flush=True)


if __name__=='__main__':
    run()
