from assess import *

if __name__=='__main__':
    folder=SPEC/'results/spectrum'
    rows=list(csv.DictReader((ROOT/'eight-mode-growth-weight.csv').read_text().splitlines()))
    targets=list(csv.DictReader((ROOT/'priority-modes-by-growth-weight.csv').read_text().splitlines()))
    assert len(rows)==2*8*3*2 and len(targets)==2*5*2
    status=json.loads((folder/'status.json').read_text())
    source={}
    for case in ['heavy','cold']:
        path=folder/(case+'.npz');source[str(path)]=digest(path)
        for item in next(row['central'] for row in status['branches'] if row['label']==case):
            matches=[row for row in rows if row['branch']==case and float(row['z'])==item['z']]
            assert len(matches)==6 and all(abs(float(r['old_sigma8'])/item['sigma8_m']-1)<1e-10 and
                abs(float(r['old_f8'])/item['fsigma8_cdm_m']-1)<1e-10 for r in matches)
    for row in targets:
        percentiles=[float(row[key]) for key in ('q05','q25','q50','q75','q95')]
        assert np.all(np.diff(percentiles)>0) and percentiles[-1]<min(MODES)
    assert all(0<float(r['band_fraction_of_old_variance'])<.01 for r in rows)
    save(ROOT/'observable-verification.json',dict(status=digest(folder/'status.json'),sources=source,
         rows=len(rows),weight_targets=len(targets),outside_band_unchanged_for_sensitivity=True,updated_likelihood=False))
