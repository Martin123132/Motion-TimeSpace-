from late import *

PIVOTS=(0,4,5,7)


def tasks():
    for index in range(len(MODES)):
        for case in ('heavy','cold'):
            yield ('late',index,case,'primary','main','only',.12)
        for tag in ('earlier','later','window','degree'):
            yield ('late',index,'heavy','primary',tag,'only',.24)
    for index in PIVOTS:
        for scheme in ('angular','switch','native5','fine'):
            for case in ('heavy','cold'):
                yield ('early',index,case,scheme)
                yield ('late',index,case,scheme,'main','only',.12)


if __name__=='__main__':
    for action,*options in tasks():
        (early if action=='early' else late)(*options)
