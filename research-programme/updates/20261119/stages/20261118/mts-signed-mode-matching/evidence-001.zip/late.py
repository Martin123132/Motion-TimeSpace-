from experiment import *


def geometry(cfg,const,wave,scale,origin_x,state,params,amplitude,query):
    nodes,weights=roots_laguerre(32)
    weights*=nodes**3/(1+np.exp(-nodes))/(7*np.pi**4/120)
    mass=cfg['masses'][0]
    phi=params[8]*(1+params[6]*state[10])
    beta=wave*params[8]*params[6]*state[11]
    def rhs(efold,values):
        aval=np.exp(efold)
        field,speed,_=values
        bgr=weights@(np.hypot(1,aval*const[8]/nodes)-1)+1
        density=(const[0]+const[1]+amplitude)/aval+(const[2]+const[3]+const[14]*bgr)/aval**2
        hub=np.sqrt((density+.5*(speed**2+(aval*mass*field)**2))/3)
        return [speed/hub,-2*speed-(aval*mass)**2*field/hub,wave/hub]
    sol=solve_ivp(rhs,(np.log(scale),0.),[phi,beta,origin_x],method='DOP853',dense_output=True,
                  rtol=2e-13,atol=[1e-15,1e-28,5e-12],max_step=.02)
    assert sol.success
    return sol.sol(np.log(query))[2]


def labels(kind):
    if kind=='matrix':return ['full','environment','density','velocity','raw']
    return ['full']


def prepare_vector(scenario,captured,projection,args):
    state=captured.copy()
    state[-2:]=0
    state[16:18]=projection
    if scenario=='environment':state[16:18]=0.
    if scenario in ('density','velocity'):
        state[:]=0.
        state[[0,10,11,14,15]]=captured[[0,10,11,14,15]]
        count,limit=args[:2]
        pos=18+np.arange(count+1)*(limit+2)+limit+1
        state[pos]=captured[pos]
        idx=0 if scenario=='density' else 1
        state[16+idx]=projection[idx]
    return state


def late(index,case,scheme,tag='main',kind='only',cap=.24):
    guard()
    wave=MODES[index]
    early=load(f'early-{index}-{case}-{scheme}')
    _,args,_,cfg,const=setup(case,wave,scheme)
    key=tag if tag in ('earlier','later') else 'main'
    state=early[key+'_state'];start=float(early[key+'_x']);before=early[key+'_obs']
    center,_,abundance,_=metadata()[tag]
    abundance=abundance if case=='heavy' else 0.
    params=args[6].copy();params[13:15]=[abundance,case=='heavy']
    modeflag=args[5]+(12 if scheme in ('switch','native5') else 0)
    args=(*args[:5],modeflag,params,*args[7:])
    initial=early[tag+'_projection'][:2] if case=='heavy' else np.zeros(2)
    raw=before[[26,28]]*(wave/5)**2*center/abundance if case=='heavy' else np.zeros(2)
    trial=np.unique(np.r_[center,np.geomspace(center,.00065,361),np.geomspace(.00065,1.,301),LATE,
                 [.00025,.000265,.00035,.0004,.0006,.0008,.002,.005,.02,.05,.1,.2,.4,.5,.75,1.]])
    target=trial[trial>=center]
    xs=geometry(cfg,const,wave,center,start,state,params,abundance,target)
    xs[0]=start
    assert np.all(np.diff(xs)>0)
    data=dict(wave=wave,scales=target,epochs=np.searchsorted(target,LATE),clock=xs/wave,names=NAMES,
              exact_event=before,projection=initial,raw_projection=raw,start_state=state,const=const)
    for scenario in labels(kind) if case=='heavy' else ['full']:
        copied=prepare_vector(scenario,state,raw if scenario=='raw' else initial,args)
        if case=='cold':copied[14:18]=0.
        obs=np.empty((len(xs),53))
        for first in range(0,len(xs)-1,64):
            guard()
            last=min(first+64,len(xs)-1)
            values=march(copied,args,xs[first:last+1],cap)
            obs[first+int(first>0):last+1]=values[int(first>0):]
        data[scenario]=reduced(obs,wave,const,abundance)
        data[scenario+'_terminal']=copied
        assert max(abs(obs[:,0]/target-1))<1e-7
    suffix=f'{cap:g}'
    name=f'late-{index}-{case}-{scheme}-{tag}-{suffix}'
    write(name,**data)
    print('forecast',name,len(xs),flush=True)


if __name__=='__main__':
    scheme,tag,kind,cap=sys.argv[1:5]
    for idx in map(int,sys.argv[5:]):
        for case in ['heavy','cold'] if tag=='main' else ['heavy']:
            late(idx,case,scheme,tag,kind,float(cap))
