from pathlib import Path
root=Path(__file__).resolve().parent
code=(root/'matched_generated.c').read_text()
changes={'#include "average.inc"':'#include "average.inc"\n#include "stream.inc"',
    '#include "moment.inc"':'''#include "moment.inc"
    if(obs&&nustr){obs[6]=newnu;obs[9]=radflux;obs[46]=0.;}
    if(obs&&phstr){obs[5]=newphot;obs[8]=radflux;obs[11]=0.;obs[12]=0.;}''',
    '    change[DRAG_INT]=drag;':'''    if(phstr){double extra=rate*(.75*radflux-vg)/rel;change[BULK]+=rel*extra/(1+rel);change[SLIP]+=extra;}
    change[DRAG_INT]=drag;'''}
for old,new in changes.items():
    assert code.count(old)==1
    code=code.replace(old,new)
with (root/'stream_generated.c').open('x') as handle:
    handle.write(code)
