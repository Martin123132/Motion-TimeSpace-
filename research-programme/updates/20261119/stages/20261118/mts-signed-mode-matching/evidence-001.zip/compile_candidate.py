from experiment import *
import re
import subprocess
import tempfile
import shutil


def reconstruct(source,patch):
    lines=source.splitlines(keepends=True);pos=0;output=[]
    diff=patch.splitlines(keepends=True)
    for line in diff[2:]:
        if line.startswith('@@ '):
            start=int(re.match(r'@@ -(\d+)',line)[1])-1
            assert start>=pos
            output.extend(lines[pos:start]);pos=start
        elif line.startswith(' '):
            assert lines[pos]==line[1:];output.append(lines[pos]);pos+=1
        elif line.startswith('-'):
            assert lines[pos]==line[1:];pos+=1
        elif line.startswith('+'):output.append(line[1:])
        else:raise ValueError(line)
    return ''.join(output+lines[pos:])


if __name__=='__main__':
    meta=json.loads((ROOT/'candidate-provenance.json').read_text())
    source=Path(meta['path']);patch=ROOT/'candidate-streaming-heavy-only.patch'
    assert digest(source)==meta['source'] and digest(patch)==meta['candidate_diff']
    check=subprocess.run(['git','apply','--check','--verbose','--ignore-space-change',str(patch)],cwd=source.parent.parent,
                        check=True,capture_output=True,text=True)
    assert 'Checking patch fortran/equations.f90' in check.stderr and 'Skipped' not in check.stderr
    code=reconstruct(source.read_text(),patch.read_text())
    chain=COMMON/'native-two-field-transfer-20261007/toolchain/mingw64'
    compiler=chain/'bin/gfortran.exe'
    env=dict(os.environ,PATH=str(chain/'bin')+';'+os.environ['PATH'])
    with tempfile.TemporaryDirectory(dir=ROOT,prefix='compile-') as tmp:
        local=Path(os.path.relpath(chain,tmp))
        flags=['-B'+(local/name).as_posix()+'/' for name in ['libexec/gcc/x86_64-w64-mingw32/14.2.0','lib','bin','lib/gcc/x86_64-w64-mingw32/14.2.0','x86_64-w64-mingw32/lib']]
        shutil.copyfile(chain/'libexec/gcc/x86_64-w64-mingw32/14.2.0/f951.exe',Path(tmp)/'f951.exe')
        flags.insert(0,'-B./')
        job=subprocess.run([str(compiler),*flags,'-x','f95-cpp-input','-fopenmp','-O1','-fcheck=bounds','-J.',
                       '-I'+str(source.parent/'WinMTS'),'-c','-','-o','candidate.o'],cwd=tmp,env=env,input=code,
                       check=False,text=True,capture_output=True)
        if job.returncode:raise RuntimeError(job.stderr)
        obj=Path(tmp)/'candidate.o'
        report=dict(compiler_sha=digest(compiler),source_sha=digest(source),patch_sha=digest(patch),object_sha=digest(obj),
                    object_bytes=obj.stat().st_size,stdout=job.stdout,stderr=job.stderr,native_simulation_run=False,
                    git_check=check.stderr.strip())
    assert not Path(tmp).exists() and digest(source)==meta['source']
    save(ROOT/'candidate-compile-only.json',report)
    print('Fortran candidate compiled to an isolated object; no link, installation or execution.',flush=True)
