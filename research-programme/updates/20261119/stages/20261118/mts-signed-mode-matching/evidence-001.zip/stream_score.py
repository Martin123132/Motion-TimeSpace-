from streaming import *


def evaluate():
    rows,attribution,budget=[],[],[]
    for path in sorted(ROOT.glob('stream-*-heavy-*.npz')):
        _,idx,case,scheme,timing,name=path.stem.split('-')
        index=int(idx);wave=MODES[index]
        ctrlpath=path.name.replace('-heavy-','-cold-')
        with np.load(path) as h,np.load(ROOT/ctrlpath) as c:
            active=h['values'][h['epochs']];base=c['values'][c['epochs']]
        accept=load(f'late-{index}-heavy-{scheme}-main-{.24 if scheme=="primary" else .12:g}')
        paired=load(f'late-{index}-cold-{scheme}-main-{.24 if scheme=="primary" else .12:g}')
        live=accept['full'][accept['epochs']];cold_live=paired['full'][paired['epochs']]
        saved=reference(index,'heavy');saved_cold=reference(index,'cold')
        for key,exponent in [('total_matter',2),('weyl',1)]:
            col=NAMES.index(key)
            branch=(active[:,col]/base[:,col])**exponent
            truth=(saved[key]/saved_cold[key])**exponent
            full=(live[:,col]/cold_live[:,col])**exponent
            rows.append(dict(k=wave,scheme=scheme,timing=timing,source=name,observable=key,exponent=exponent,end=branch[-1],
                       full=full[-1],archive=truth[-1],
                       end_fractional_vs_full=branch[-1]/full[-1]-1,end_fractional_vs_archive=branch[-1]/truth[-1]-1,
                       maximum_frac_vs_full=peak(branch/full-1),maximum_frac_vs_archive=peak(branch/truth-1),
                       heavy_amplitude_vs_full=active[-1,col]/live[-1,col]-1,cold_amplitude_vs_full=base[-1,col]/cold_live[-1,col]-1))
    for idx in (4,7):
        for key in ('total_matter','weyl'):
            matches={row['source']:np.log(row['end']) for row in rows if row['k']==MODES[idx] and row['scheme']=='primary' and row['timing']=='mid' and row['observable']==key}
            total=matches['included']-matches['literal']
            density=.5*((matches['density_only']-matches['literal'])+(matches['included']-matches['flux_only']))
            flux=.5*((matches['flux_only']-matches['literal'])+(matches['included']-matches['density_only']))
            attribution.append(dict(k=MODES[idx],signal=key,log_change=total,density_share=density/total,flux_share=flux/total,
                                    exact_split_residual=abs(density+flux-total)))
    for wave in MODES:
        target={row['source']:row for row in rows if row['k']==wave and row['scheme']=='primary' and row['timing']=='mid' and row['observable']=='total_matter'}
        lit=target['literal'];inc=target['heavy_only']
        amplitude_gap=lit['full']-lit['archive']
        budget.append(dict(k=wave,archive_power=lit['archive'],full_power=lit['full'],literal_power=lit['end'],heavy_only_candidate=inc['end'],
                           gap_explained_by_literal=(lit['full']-lit['end'])/amplitude_gap,unexplained_fraction=(lit['end']-lit['archive'])/amplitude_gap,
                           candidate_fractional_vs_full=inc['end_fractional_vs_full'],literal_fractional_vs_archive=lit['end_fractional_vs_archive'],
                           candidate_cold_change=inc['cold_amplitude_vs_full']-lit['cold_amplitude_vs_full']))
    table('streaming-ab',rows);table('streaming-density-versus-flux',attribution);table('power-gap-budget',budget)
    print('literal explains fraction',min(row['gap_explained_by_literal'] for row in budget),max(row['gap_explained_by_literal'] for row in budget))


if __name__=='__main__':
    evaluate()
