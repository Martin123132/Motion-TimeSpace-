from pathlib import Path

root = Path(__file__).resolve().parent
prior = root.parent/'mts-neutrino-switch-20261118'
code = (prior/'switch.c').read_text()
def use(old,new,needed=1):
    global code
    assert code.count(old)==needed,(old,code.count(old))
    code=code.replace(old,new)

use('#include "../mts-massive-transport-20261117/shadow_eval.inc"','')
use('#include "branches.inc"','#include "../mts-neutrino-switch-20261118/branches.inc"\n#include "moment.inc"')
use('idx<model->fields;idx++','idx<(par[14]?1:model->fields);idx++')
use('    double hub=sqrt(bg)', '#include "average.inc"\n    double hub=sqrt(bg)')
use('if(idx>=model->fields){','if(idx==1 && par[14]){change[pos]=0;change[pos+1]=0;change[pos+2]=cprime-3*hub*avg_pressure-state[pos+3];change[pos+3]=-hub*state[pos+3]+avg_pressure;continue;}if(idx>=model->fields){')
use('    return isfinite(hub)&&isfinite(density);','''    if(par[15]){
        int ell=model->polar,pos=ell-2;
        bright[pos]=intensity[pos-1]-(ell+1)*intensity[pos]/coord;
        electric[pos]=(double)ell/(ell-2)*pol[pos-1]-(ell+3)*pol[pos]/coord;
    }
    return isfinite(hub)&&isfinite(density);''')
therm=(root.parent/'mts-massive-transport-20261117/thermal_exact.inc').read_text()
marker='if(!(aval>0) || aval>table[8*hi])return 0;'
assert therm.count(marker)==1
therm=therm.replace(marker,'if(!(aval>0) || aval>1.00000002*table[8*hi])return 0; if(aval>table[8*hi])aval=table[8*hi];')
use('#include "../mts-massive-transport-20261117/thermal_exact.inc"',therm)
with (root/'matched_generated.c').open('x') as handle:
    handle.write(code)
