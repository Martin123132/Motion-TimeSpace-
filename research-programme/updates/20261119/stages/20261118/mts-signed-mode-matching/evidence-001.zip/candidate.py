import difflib
from experiment import *


def prepare():
    guard()
    path=COMMON/'native-heavy-matching-20261007/native/fortran/equations.f90'
    text=path.read_text()
    left='    real(dl) dgpi,dgrho_matter,grho_matter, clxnu, gpres_nu'
    begin='    dgrho = dgrho_matter\n'
    finish='    dgrho=dgrho + grhog_t*clxg+grhor_t*clxr'
    assert text.count(left)==text.count(begin)==text.count(finish)==1
    source=text.replace(left,left+', dgrho_rsa')
    pre,tail=source.split(begin);temporary,post=tail.split(finish)
    assert temporary.count('dgrho/k')==4
    addition='''    dgrho_rsa = dgrho_matter
    if (EV%no_nu_multpoles .or. EV%no_phot_multpoles) then
        select type(dark => State%CP%DarkEnergy)
        type is (TMTSTwoField)
            if (dark%heavy_fraction > 0._dl .and. EV%w_ix > 0 .and. EV%w_ix+4 <= n) then
                if (ay(EV%w_ix+4) > 0.5_dl) then
                    dgrho_rsa = dgrho_rsa + dark%matching_density/a*ay(EV%w_ix+2)
                end if
            end if
        end select
    end if
'''
    source=pre+begin+addition+temporary.replace('dgrho/k','dgrho_rsa/k')+finish+post
    assert source.split(finish)[1]==text.split(finish)[1]
    out=ROOT/'candidate-streaming-heavy-only.patch'
    with out.open('x',newline='\n') as handle:
        handle.writelines(difflib.unified_diff(text.splitlines(True),source.splitlines(True),
                     fromfile='a/fortran/equations.f90',tofile='b/fortran/equations.f90'))
    save(ROOT/'candidate-provenance.json',dict(path=str(path),source=digest(path),candidate_diff=digest(out),
                applied=False,production_run=False,scope='only preliminary radiation source for active matched MTS heavy matter; final Einstein stress call unchanged'))
    shader=(ROOT/'stream.inc').read_text()
    assert shader.count('density-live_rad-matter_used')==shader.count('pressure-(monopole+par[3]*pmass)*inv2')==1
    shader=shader.replace('density-live_rad-matter_used','coeff*state[16]').replace('pressure-(monopole+par[3]*pmass)*inv2','coeff*avg_pressure')
    code=(ROOT/'stream_generated.c').read_text().replace('#include "stream.inc"',shader)
    with (ROOT/'heavy_only_generated.c').open('x') as handle:handle.write(code)


if __name__=='__main__':
    prepare()
