from controls import *
from scipy.interpolate import CubicHermiteSpline
from scipy.optimize import brentq


def lock():
    guard()
    required=[f'early-{idx}-{case}-primary' for idx in range(8) for case in ('heavy','cold')]
    required += [f'late-{idx}-{case}-primary-main-0.24' for idx in range(8) for case in ('heavy','cold')]
    for act,idx,case,scheme,*rest in tasks():
        required.append(f'early-{idx}-{case}-{scheme}' if act=='early' else f'late-{idx}-{case}-{scheme}-{rest[0]}-{rest[-1]:g}')
    inputs=[ROOT/(name+'.npz') for name in required]+list(ROOT.glob('fold-*.npz'))+list(ROOT.glob('*.py'))+[
        ROOT/'PROTOCOL.md',ROOT/'FOLD-PROTOCOL.md',ROOT/'fold-forecast.json',ROOT/'fold-law.csv',ROOT/'event-receipts.json',
        ROOT/'matched.dll',ROOT/'matched_generated.c',ROOT/'moment.inc',ROOT/'average.inc',PREV/'closeout.json',
        SPEC/'project_grid.py',SPEC/'analyze_spectrum.py',WAVE_INPUT,NATIVE/'MTSTwoField.f90',NATIVE/'equations.f90',
        RUNS/'exact-grid'/PACKET,PREV/'primordial.py',origin.SWITCH/'switch.c',origin.SWITCH/'branches.inc',
        POST/'mts-massive-transport-20261117/thermal_exact.inc',POST/'mts-native-seed-origin-20261117/first_output.py']
    for case in ('cold','heavy'):
        inputs += [POST/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz'),
                   POST/'mts-integrated-defect-20261112'/(case+'-native-clock.npz')]
    assert len(set(required))==len(required) and len(required)==144
    files={str(path.relative_to(POST)):digest(path) for path in inputs}
    name=ROOT/'forecast-lock.json'
    if name.exists():
        receipt=json.loads(name.read_text())
        assert all(digest(POST/key)==sha for key,sha in receipt['files'].items())
    else:
        save(name,dict(utc=datetime.now(timezone.utc).isoformat(),files=files,paired_packets=len(required),
             fold_packets=len(list(ROOT.glob('fold-*.npz'))),prior=OLDSEAL,prior_knowledge='previous Stage55/56 aggregate and four-mode examples known; internal replay not independent observations'))


def peak(arr):
    return float(np.max(abs(arr)))


def project_value(data,name):
    return data[:,NAMES.index(name)]


def recovery_points(data,wave):
    field=data[:,8]+3*data[:,1]/wave*data[:,9]
    deriv=(data[:,14]-(1+1.5*data[:,17])*data[:,9])/(data[:,1]/wave)
    coords=np.log(data[:,0])
    curve=CubicHermiteSpline(coords,field,deriv)
    hits=np.flatnonzero(field[:-1]*field[1:]<0)
    return [float(np.exp(brentq(curve,*coords[pos:pos+2]))) for pos in hits]


def gates():
    event,phase,parts,signs=[],[],[],[]
    for idx,wave in enumerate(MODES):
        for tag in CONFIG:
            early=load(f'early-{idx}-heavy-primary')
            latepack=load(f'late-{idx}-heavy-primary-{tag}-0.24')
            pred=latepack['full']; scale,tau,amp,_=metadata()[tag]
            real=early[tag+'_projection']; num_norm=early[tag+'_design']
            ordinary=CONFIG[tag]
            with np.load(RUNS/'projection'/f'{ordinary[1]}-w{ordinary[2]}-d{ordinary[3]}.npz') as arc:
                slot=int(np.flatnonzero(arc['modes']==wave).item())
                archived=np.array([arc[key][slot] for key in ('matching_delta','matching_momentum','projected_pressure')])
                norm=float(arc['projection_norm'][slot])
            pressure_expected=pred[0,10]/pred[0,23]
            row=dict(k=wave,tag=tag,clock_archive=tau,clock_generated=latepack['clock'][0],scale=scale,
                     design_count=num_norm[0],condition=num_norm[1],mode_norm=norm)
            for i,key in enumerate(('density','momentum','pressure')):
                row['predicted_'+key]=real[i];row['reference_'+key]=archived[i];row[key+'_error_over_mode_norm']=abs(real[i]-archived[i])/norm
            row['physical_pressure_closure_error_over_mode_norm']=abs(pressure_expected-real[2])/norm
            phase.append(row)
            tip=latepack['exact_event'][None,:]
            pre=origin.derived(tip,wave,latepack['const'])[0]
            post=pred[0];delta_hub=post[1]-pre[1]
            raw=latepack['raw_projection'];jump=latepack['projection']-raw
            rho=post[23]
            expected=-.5*(rho*jump[0]+3/wave*(post[1]*rho*jump[1]+delta_hub*pre[13]))
            exact_delta_cx=-(rho*jump[0]/(2*wave**2)+delta_hub/wave*pre[15])/(post[1]/wave)
            event.append(dict(k=wave,tag=tag,delta_density_per_R=jump[0],delta_flux_per_R=jump[1],
                         delta_pressure_per_R=(post[10]-pre[5])/rho,delta_H_over_H=delta_hub/pre[1],
                         delta_Weyl=post[12]-pre[11],predicted_jump=expected,
                         Weyl_jump_identity_over_total=(post[12]-pre[11]-expected)/abs(pre[11]),
                         delta_Cx=post[14]-pre[15],Cx_jump_identity_over_total=(post[14]-pre[15]-exact_delta_cx)/abs(pre[15]),
                         intrinsic_metric_change=post[7]-pre[3]))
            if tag!='main':continue
            cold=load(f'late-{idx}-cold-primary-main-0.24')['full']
            mask=(pred[:,0]>=.0003*(1-1e-10))
            fullS=pred[:,8]+3*pred[:,1]*pred[:,9]/wave
            identity=fullS-fullS[0]-(pred[:,2]-pred[0,2])-pred[:,15]-pred[:,16]
            roots=recovery_points(pred,wave)
            signs.append(dict(k=wave,start_S=fullS[0],present_S=fullS[-1],predicted_recovery_count=len(roots),
                recovery_a=roots[0] if roots else None,fluid_integral_error_over_peak=peak(identity)/peak(fullS),
                sign_last_early_clock=int(np.sign(np.interp(.000265,pred[:,0],fullS))),
                sign_first_late=int(np.sign(fullS[latepack['epochs'][0]])),cold_matched_scale_error=peak(cold[:,0]/pred[:,0]-1)))
            for key in ('comoving_h','delta_h','momentum_h','weyl','cdm','total_matter'):
                col=NAMES.index(key);vals=pred[:,col]
                basis=np.stack([latepack[arm][:,col] for arm in ('environment','density','velocity')])
                residual=peak(vals-basis.sum(axis=0))/peak(vals)
                parts.append(dict(k=wave,signal=key,superposition_error=residual,
                     final_full=vals[-1],final_environment_share=basis[0,-1]/vals[-1],
                     final_density_share=basis[1,-1]/vals[-1],final_velocity_share=basis[2,-1]/vals[-1],
                     raw_vs_matched_final=latepack['raw'][-1,col]/vals[-1]-1,
                     no_initial_heavy_change_over_late_peak=peak((vals-basis[0])[mask])/peak(vals[mask])))
    table('projected-comparison',phase);table('event-balance',event);table('regeneration',signs);table('initial-source-partition',parts)


@lru_cache(None)
def reference(index,label):
    wave=MODES[index]
    with np.load(RUNS/label/PACKET) as archive:
        slot=int(np.flatnonzero(archive['modes']==wave).item())
        get=dict(zip(archive['names'],archive['values'][slot].T))
        scales=archive['requested_scale']
    with np.load(RUNS/label/'background.npz') as tab:
        cdm,baryon,nu=[tab[key] for key in ('cdm','baryon','nu')]
    mass=0. if label=='cold' else metadata()['main'][2]
    matter=(cdm*get['delta_cdm']+baryon*get['delta_baryon']+nu*get['delta_nu']+get['a']**2*get['mts_drho_h'])/(cdm+baryon+nu+mass*get['a'])
    return dict(a=get['a'],H=get['H'],cdm=get['delta_cdm'],baryon=get['delta_baryon'],photon=get['delta_photon'],
         massless=get['delta_neutrino'],massive=get['delta_nu'],etak=get['etak'],
         delta_h=get['mts_drho_h']*get['a']/mass if mass else np.zeros(len(scales)),
         momentum_h=get['mts_q_h']*get['a']/mass if mass else np.zeros(len(scales)),pressure_h=get['mts_dp_h'],
         comoving_h=get['mts_drho_h']+3*get['H']*get['mts_q_h']/wave,weyl=get['Weyl'],
         slow_pressure=get['mts_dp_s'],total_matter=matter)


def compare_all():
    scores,ratios,sens,slices=[],[],[],[]
    scenarios=[('primary',tag,.24) for tag in CONFIG]+[('primary','main',.12)]+[(scheme,'main',.12) for scheme in ('angular','switch','native5','fine')]
    for idx,wave in enumerate(MODES):
        for scheme,tag,cap in scenarios:
            if scheme!='primary' and idx not in PIVOTS:continue
            heavy=load(f'late-{idx}-heavy-{scheme}-{tag}-{cap:g}')
            cold=load(f'late-{idx}-cold-{scheme}-main-{cap:g}')
            main=load(f'late-{idx}-heavy-primary-main-0.24')
            active=heavy['full'][heavy['epochs']]
            control=cold['full'][cold['epochs']]
            ref=reference(idx,CONFIG[tag][0]);base=reference(idx,'cold')
            for case,pred,truth in [('heavy',active,ref),('cold',control,base)]:
                if case=='cold' and tag!='main':continue
                for key,vals in truth.items():
                    estimate=project_value(pred,key);diff=estimate-vals
                    err=peak(diff)/peak(vals) if peak(vals) else peak(diff)
                    scores.append(dict(k=wave,case=case,scheme=scheme,tag=tag,cap=cap,observable=key,
                        scale_count=len(vals),relative_to_reference_peak=err,within_tolerance=err<=TOL,
                        reference_peak=peak(vals),end_predicted=estimate[-1],end_reference=vals[-1],
                        end_fractional_change=(diff[-1]/vals[-1] if vals[-1] else None),early_error_over_early_peak=peak(diff[:5])/peak(vals[:5]) if peak(vals[:5]) else peak(diff[:5]),
                        sign_agreement=int(np.sum(np.sign(estimate)==np.sign(vals)))))
            for key in ('delta_h','momentum_h','pressure_h','comoving_h','total_matter','weyl'):
                values=project_value(active,key);primary=project_value(main['full'][main['epochs']],key)
                sens.append(dict(k=wave,scheme=scheme,tag=tag,cap=cap,signal=key,relative_to_primary_peak=peak(values-primary)/peak(primary)))
            for pos in range(len(LATE)):
                ratio=active[pos,13]/control[pos,13];ref_ratio=ref['total_matter'][pos]/base['total_matter'][pos]
                lens=active[pos,12]/control[pos,12];ref_lens=ref['weyl'][pos]/base['weyl'][pos]
                ratios.append(dict(k=wave,scheme=scheme,tag=tag,cap=cap,a=LATE[pos],
                    predicted_power=ratio**2,archived_power=ref_ratio**2,power_ratio_error=(ratio/ref_ratio)**2-1,
                    predicted_weyl=lens,archived_weyl=ref_lens,weyl_ratio_error=lens/ref_lens-1))
                if (scheme,tag,cap)==('primary','main',.24):
                    for key in ('cdm','baryon','photon','massive','delta_h','weyl','total_matter'):
                        ix=NAMES.index(key)
                        slices.append(dict(k=wave,a=LATE[pos],signal=key,heavy=active[pos,ix],saved_heavy=ref[key][pos],
                                      cold=control[pos,ix],saved_cold=base[key][pos]))
    table('late-reference-comparison',scores);table('late-contrast',ratios);table('operator-sensitivities',sens);table('species-by-epoch',slices)


def dense_anchor():
    parent=COMMON/'native-heavy-matching-20261007/runs'
    pred=load('late-7-heavy-primary-main-0.24');model=pred['full'];wave=MODES[-1]
    root=recovery_points(model,wave)[0]
    rows=[]
    for path in (parent/'late-225/evolution.npz',parent/'independent-probes/dense-4001.npz'):
        with np.load(path) as archive:
            slot=int(np.flatnonzero(archive['modes']==wave).item())
            get=dict(zip(archive['names'],archive['values'][slot].T))
            keep=(get['a']>=metadata()['main'][0])&(get['mts_averaged_chart']>0)&(get['a']<=.0006)
            scales=get['a'][keep]
            com=(get['mts_drho_h']+3*get['H']*get['mts_q_h']/wave)[keep]*scales/metadata()['main'][2]
        hits=np.flatnonzero(com[:-1]*com[1:]<0)
        for pos in hits:
            interp=brentq(PchipInterpolator(scales,com),*scales[pos:pos+2])
            rows.append(dict(source=str(path.relative_to(POST)),k=wave,observed_crossings=len(hits),sample_min=min(scales),sample_max=max(scales),
                   predicted_root=root,low=scales[pos],high=scales[pos+1],inside=scales[pos]<root<scales[pos+1],interpolated_root=interp))
        if not len(hits):
            rows.append(dict(source=str(path.relative_to(POST)),k=wave,observed_crossings=0,sample_min=min(scales),sample_max=max(scales),
                   predicted_root=root,low=None,high=None,inside=None,interpolated_root=None))
    table('k1-native-recovery-bracket',rows)


if __name__=='__main__':
    lock();gates();compare_all();dense_anchor()
    print('all frozen forecast arms compared',flush=True)
