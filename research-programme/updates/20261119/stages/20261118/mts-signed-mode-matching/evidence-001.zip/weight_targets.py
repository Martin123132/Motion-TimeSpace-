from experiment import *
from scipy.integrate import cumulative_trapezoid


def run():
    rows=[]
    for case in ('cold','heavy'):
        with np.load(SPEC/'results/spectrum'/(case+'.npz')) as data:
            mask=data['modes']<=5.
            modes=data['modes'][mask];scales=data['scales']
            transfer=data['delta_m'][mask]
            speed=data['velocity_cdm'][mask]
        for z in (0.,.38,.51,.698,1.48):
            pos=np.argmin(abs(scales-1/(1+z)))
            log=np.linspace(np.log(modes[0]),np.log(modes[-1]),16385)
            k=np.exp(log);x=k*8/.7
            window=np.ones(len(x));use=x>=.05
            window[~use]=1-x[~use]**2/10+x[~use]**4/280
            window[use]=3*(np.sin(x[use])-x[use]*np.cos(x[use]))/x[use]**3
            amp=np.exp(CubicSpline(np.log(modes),np.log(transfer[:,pos]))(log))
            flow=np.exp(CubicSpline(np.log(modes),np.log(speed[:,pos]))(log))
            for key,other in [('variance',amp),('growth_cross',flow)]:
                integral=cumulative_trapezoid(window**2*(k/.05)**(-.0347)*amp*other,x=log,initial=0)
                values=np.exp(np.interp([.05,.25,.50,.75,.95],integral/integral[-1],log))
                rows.append(dict(case=case,z=z,signal=key,**dict(zip(('q05','q25','q50','q75','q95'),values)),
                                 nearest_native_modes=';'.join(str(modes[np.argmin(abs(np.log(modes/point)))]) for point in values)))
    table('priority-modes-by-growth-weight',rows)


if __name__=='__main__':run()
