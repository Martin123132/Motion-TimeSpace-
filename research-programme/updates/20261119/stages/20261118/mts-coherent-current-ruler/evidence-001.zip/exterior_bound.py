from response_map import COEFFICIENT, LOCAL, Measured, WEIGHTS, digest, json, mixed, name, np, scores, write_table
from mixed_current import MASS, betainc, law
from scipy.integrate import solve_ivp
from scipy.special import roots_legendre
from numpy.polynomial import Legendre
from initial import Model
from types import SimpleNamespace

EDGE=5.
RHO=.000703828125


def geometry(radius):
    charge=MASS*betainc(1.5,7,min((radius/EDGE)**2,1.))
    root=1-charge/radius
    dust=RHO*max(1-(radius/EDGE)**2,0.)**6*root
    return root,charge,dust


def transfer(order,start,outer):
    def rhs(logradius,state):
        radius=np.exp(logradius);root,charge,dust=geometry(radius)
        return [state[1]/root,-state[1]+(6+radius**2*dust+(charge/radius)**2)*state[0]/root]
    left=solve_ivp(rhs,(np.log(start),np.log(EDGE)),[1.,2.],method="DOP853",rtol=8e-14,atol=1e-15,dense_output=True)
    beta=float(Model.outer(SimpleNamespace(mass_infty=MASS,qtot=MASS),outer))
    right=solve_ivp(rhs,(np.log(outer),np.log(EDGE)),[1.,beta],method="DOP853",rtol=8e-14,atol=1e-15,dense_output=True)
    assert left.success and right.success
    nodes,weights=roots_legendre(order);r=EDGE*(1+nodes)/2;wr=EDGE*weights/2
    assert r.min()>start
    charge=MASS*betainc(1.5,7,(r/EDGE)**2);root=1-charge/r
    density=RHO*(1-(r/EDGE)**2)**6
    leftval=left.sol(np.log(r))[0]
    left_edge=left.sol(np.log(EDGE));right_edge=right.sol(np.log(EDGE))
    denom=EDGE*(left_edge[1]*right_edge[0]-left_edge[0]*right_edge[1])
    return r,wr,density,charge,root,leftval/denom,right


def solutions(params):
    radii,wr,density,charge,root,green,outer=params
    alias=json.loads((LOCAL/"two-clock-alias.json").read_text())
    frozen=json.loads((LOCAL/"frozen-midpoint.json").read_text())
    basis=dict(minus=WEIGHTS["minus"],blind=WEIGHTS["blind"],outside=WEIGHTS["outside"],alias=alias["weights"],
               invisible=frozen["null_weights"],midpoint=frozen["weights"])
    profiles={key:law(charge,values) for key,values in basis.items()}
    frac=charge/MASS;prim=32/3*frac**3*(1-frac)**3;slope=32*frac**2*(1-frac)**2*(1-2*frac)
    for degree in (4,8,12):
        poly=Legendre.basis(degree);x=2*frac-1
        profiles[f"Legendre{degree}"]=(slope*poly(x)+2*prim*poly.deriv()(x),MASS*prim*poly(x))
    lower=1-(RHO*MASS**2/3)**(1/3)
    constant=.5+RHO*EDGE**2/(5*lower)
    alpha=(1-MASS/EDGE)*np.exp(-RHO*EDGE**2/(6*lower))
    lines=[]
    for key,(ell,primitive) in profiles.items():
        energy=wr@(density*ell**2)/3
        source=(4*primitive**2/(radii**4*root)+density*ell**2)/6
        amplitude=-wr@(green*source)
        if key in basis:
            seed=json.loads(str(mixed(.0125,1.,0.,key)["initial_info"]))["constraint_at_detector"]
        for radius in (5.,6.,8.,12.,24.,48.):
            dec,vel=amplitude*outer.sol(np.log(radius))
            surf=1-MASS/radius
            bound_u=constant*energy/(5*EDGE*lower)*(EDGE/radius)**3
            dr=vel/(radius*surf);slope=-dr/dec
            hi=(1+MASS**2/(6*radius**2))/surf
            section=1.5*(4*surf**2*dr/radius-(12/radius**2+4*MASS/radius**3-4*MASS**2/radius**4)*dec)
            bound_tide=3*constant*energy*EDGE**2/(10*lower*radius**5)*(12+4*MASS/radius-4*(MASS/radius)**2+12*surf*hi)
            lines.append(dict(profile=key,R=radius,W=energy,I2=wr@source,C=constant,bmin=lower,alpha_min=alpha,
                              u=dec,u_bound=bound_u,slope=slope,exterior_slope_lower=3/radius,exterior_slope_upper=3*hi/(radius*surf),
                              delta_radial_tide=section,tide_bound=bound_tide,fraction_of_tide_bound=section/bound_tide,
                              angular_constraint_error=scores(np.array([dec,vel]),np.array(seed)) if radius==6. and key in basis else None))
    return lines


def main():
    coarse=solutions(transfer(170,5e-6,96.));fine=solutions(transfer(256,1e-6,192.))
    for a,b in zip(coarse,fine,strict=True):
        assert a["R"]==b["R"] and a["profile"]==b["profile"]
        b["adjoint_refinement"]=abs(a["delta_radial_tide"]/b["delta_radial_tide"]-1)
        assert b["W"]/2<=b["I2"]<=b["C"]*b["W"]
        assert 0<b["delta_radial_tide"]<b["tide_bound"] and -b["u"]<=b["u_bound"]
        assert b["exterior_slope_lower"]<=b["slope"]<=b["exterior_slope_upper"]
    write_table("arbitrary-current-launch-bound.csv",fine)


if __name__=="__main__":main()
