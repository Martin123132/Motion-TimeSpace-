from response_map import CLOCKS, COEFFICIENT, LOCAL, TOL, WEIGHTS, digest, json, matrix, mixed, name, np, scores, write_table
from scipy.interpolate import make_interp_spline


def unpack():
    saved=json.loads((LOCAL/"frozen-fourth.json").read_text())
    assert digest(LOCAL/name(.0125,1.,0.,"minus"))==saved["minus"]
    return saved,np.asarray(saved["matrix"]),np.asarray(saved["fields"])


def assess():
    saved,tensor,fields=unpack()
    indices=[150,200]
    design=fields[indices]
    row_unit=np.linalg.norm(design,axis=1)
    normalized=design/row_unit[:,None]
    inverse=np.linalg.inv(design)
    calibration=[]
    comparisons=[]
    bounds=[]
    alias=json.loads((LOCAL/"two-clock-alias.json").read_text())
    blind=np.asarray(saved["specified_weights"])
    blind_history=np.asarray(saved["blind_history"])
    records={tag:mixed(.0125,1.,0.,tag)["rows"] for tag in ("minus","blind","outside","alias")}
    for tag in ("blind","outside","alias"):
        data=records[tag]
        measured=data[indices,3]
        fitted=np.linalg.solve(design,measured)
        curve=np.einsum("i,tkij,j->tk",fitted,tensor,fitted)
        coarse=mixed(.025,1.,0.,tag)["rows"]
        expected=blind if tag=="blind" else (np.array(alias["weights"][:2]) if tag=="alias" else None)
        future=np.arange(len(data))>indices[-1]
        readout_curve=fields@fitted
        at_end=float(curve[-1,0])
        calibration.append(dict(source=tag,weight_a=fitted[0],weight_b=fitted[1],physical_a=None if expected is None else expected[0],
                    physical_b=None if expected is None else expected[1],in_span=(tag!="outside"),
                    weight_error=None if expected is None else scores(fitted,expected),first_B=measured[0],second_B=measured[1],
                    condition_common_units=np.linalg.cond(design),condition_row_scaled=np.linalg.cond(normalized),
                    early_signed_error=max(abs((design@fitted-measured)/row_unit)),
                    future_field_error=scores(readout_curve[future],data[future,3]),
                    future_ruler_error=scores(curve[future,0],data[future,1]),final_predicted=at_end,final_actual=data[-1,1],
                    direct_radial_error=scores(coarse[:,1],data[:,1]),direct_metric_error=scores(data[:,2],data[:,1]),
                    frozen_ruler_error=scores(blind_history[:,0],data[:,1]) if tag=="blind" else None,
                    frozen_polar_error=scores(np.asarray(saved["blind_polar"]),data[:,3]) if tag=="blind" else None))
        for time in CLOCKS:
            at=round(time/.02);clock_matrix=tensor[at,0]
            magnetic_matrix=inverse.T@clock_matrix@inverse
            eig=np.linalg.eigvalsh(clock_matrix)
            grad=2*magnetic_matrix@measured
            slope=np.linalg.norm(grad);hscale=np.linalg.norm(magnetic_matrix,2)
            noise=2*(.01*abs(curve[at,0]))/(slope+np.sqrt(slope**2+4*hscale*.01*abs(curve[at,0])))
            minimum=measured[0]**2/(design[0]@np.linalg.solve(clock_matrix,design[0])) if eig[0]>0 else None
            comparisons.append(dict(source=tag,tau=time,measured_B=data[at,3],predicted_B=readout_curve[at],
                          measured_ruler=data[at,1],predicted_ruler=curve[at,0],minimum_from_first_B=minimum,
                          minimum_eigenvalue=eig[0],maximum_eigenvalue=eig[-1],max_common_noise_norm_one_percent=noise,
                          noise_relative_early_field_norm=noise/np.linalg.norm(measured),
                          linear_sensitivity=slope,quadratic_sensitivity=hscale))
            assert np.isclose(measured@magnetic_matrix@measured,curve[at,0],rtol=1e-11,atol=0.)
            for angle in np.arange(12)*np.pi/6:
                delta=noise*np.array([np.cos(angle),np.sin(angle)])
                noisy=np.linalg.solve(design,measured+delta)
                assert abs(noisy@clock_matrix@noisy-curve[at,0])<=.0100000001*abs(curve[at,0])
            if tag=="blind":
                bounds.append(dict(tau=time,K11=clock_matrix[0,0],K12=clock_matrix[0,1],K22=clock_matrix[1,1],
                            H33=magnetic_matrix[0,0],H34=magnetic_matrix[0,1],H44=magnetic_matrix[1,1]))
    paired=[]
    for dx in (.025,.0125):
        actual=mixed(dx,1.,0.,"outside")["rows"];mimic=mixed(dx,1.,0.,"alias")["rows"]
        for time in CLOCKS:
            at=round(time/.02)
            paired.append(dict(dx=dx,tau=time,true_B=actual[at,3],alias_B=mimic[at,3],true_volume=actual[at,1],
                            alias_volume=mimic[at,1],early_or_late_B_relative=abs((mimic[at,3]-actual[at,3])/actual[at,3]),
                            volume_fraction=(mimic[at,1]-actual[at,1])/actual[at,1]))
    write_table("two-clock-calibration.csv",calibration);write_table("conditional-bounds.csv",comparisons)
    write_table("field-to-volume-matrices.csv",bounds);write_table("direct-degeneracy.csv",paired)


def scalar():
    output=[]
    for dx in (.025,.0125):
        ordinary=mixed(dx,.8,0.,"minus");scalar=mixed(dx,.8,1.,"minus")
        clock=scalar["rows"][:,0]
        delta=scalar["rows"]-ordinary["rows"]
        source=make_interp_spline(clock,delta[:,8:14],k=5,axis=0).antiderivative(2)
        terms=source(clock)-source(0)-clock[:,None]*source.derivative()(0)
        other=mixed(.025 if dx==.0125 else .0125,.8,1.,"minus")["rows"]-mixed(.025 if dx==.0125 else .0125,.8,0.,"minus")["rows"]
        for time in CLOCKS:
            at=round(time/.02)
            output.append(dict(dx=dx,tau=time,ordinary=ordinary["rows"][at,1],scalar=scalar["rows"][at,1],
                    delta=delta[at,1],fractional_delta=delta[at,1]/ordinary["rows"][at,1],scalar_focusing=terms[at,2],
                    induced_shear=terms[at,0],induced_twist=terms[at,1],induced_electric=terms[at,3],
                    induced_dipole=terms[at,4],material=terms[at,5],differential_ledger=scores(terms.sum(axis=1),delta[:,1]),
                    differential_metric=scores(delta[:,2],delta[:,1]),differential_refinement=scores(other[:,1],delta[:,1])))
    write_table("mixed-scalar-control.csv",output)


if __name__=="__main__":
    assess();scalar()
