from mixed_current import BASE, COEFFICIENT, LOCAL, LOCK, TOL, WEIGHTS, digest, double_integral, inherited, name, np
from resolved_flux import Measured
from scipy.interpolate import PPoly, make_interp_spline
import csv
import json

CLOCKS=(3.,4.,5.,6.,6.4)


def packet(path):
    with np.load(path,allow_pickle=False) as saved:
        return {key:saved[key] for key in saved.files}


def write_table(name, rows):
    with (LOCAL/name).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def scores(predicted,measured):
    scale=np.max(abs(measured))
    if scale==0: return 0. if not np.any(predicted) else float("inf")
    return float(np.max(abs(predicted-measured))/scale)


def pure(dx,profile):
    return packet(inherited(f"budget-d{dx:g}-q1-h0-s0-p{profile}-c12-r15-t0.3-ko0.5-seed1.npz"))


def mixed(dx,eta,amp,tag):
    return packet(LOCAL/name(dx,eta,amp,tag))


def flux_integrals(data):
    clock=data[:,0]; values=make_interp_spline(clock,data[:,[4,5,3]],k=5)
    points=list(clock)
    for column in (4,5):
        component=PPoly.from_spline(make_interp_spline(clock,data[:,column],k=5))
        roots=component.roots(extrapolate=False)
        points.extend(roots[np.isfinite(roots)&(roots>clock[0])&(roots<clock[-1])])
    edges=np.unique(points)
    nodes,weights=np.polynomial.legendre.leggauss(10)
    half=np.diff(edges)/2
    proper=(edges[:-1]+half)[:,None]+half[:,None]*nodes
    electric,magnetic,polar=values(proper).transpose((2,0,1))
    direct=electric**2+magnetic**2-polar**2
    floor=2*abs(electric*magnetic)-polar**2
    slack=(abs(electric)-abs(magnetic))**2
    return np.array([[np.sum(half[:,None]*weights*np.maximum(0,time-proper)*term) for term in (direct,floor,slack)] for time in CLOCKS])


def minus_checks(dx):
    data=mixed(dx,1.,0.,"minus")
    rows=data["rows"]; exposure=data["integrated"]
    first=Measured(1.,0.,0);second=Measured(1.,0.,1);clock=rows[:,0]
    fields=np.stack(first.get(clock))-COEFFICIENT*np.stack(second.get(clock))
    flux=flux_integrals(rows)
    with inherited("magnetic-null-predictions.csv").open() as stream:prior=list(csv.DictReader(stream))
    results=[]
    for index,(time,ref) in enumerate(zip(CLOCKS,prior,strict=True)):
        at=round(time/.02);assert float(ref["tau"])==time
        values=flux[index]
        results.append(dict(dx=dx,tau=time,polar_B=rows[at,3],predicted_B=float(ref["polar_B"]),
               polar_error_on_first=abs(rows[at,3]-float(ref["polar_B"]))/abs(first.get(time)[2]),
               dipole=exposure[at,4],frozen_dipole=ref["combined_direct"],dipole_error=abs(exposure[at,4]/float(ref["combined_direct"])-1),
               floor=values[1],floor_error=abs(values[1]/float(ref["combined_floor"])-1),slack=values[2],
               slack_error=abs(values[2]/float(ref["positive_slack"])-1),spatial_sampling_error=abs(values[0]/exposure[at,4]-1),
               ray=rows[at,1],metric=rows[at,2],field_E_error=scores(rows[:,4],fields[0]),
               field_transverse_B_error=scores(rows[:,5],fields[1]),field_polar_B_error=scores(rows[:,3],fields[2]),
               whole_budget_error=scores(exposure.sum(axis=1),rows[:,1]),whole_metric_error=scores(rows[:,2],rows[:,1])))
    return results


def matrix(dx):
    a=pure(dx,0); b=pure(dx,1); minus=mixed(dx,1.,0.,"minus")
    axis=a["rows"][:,0]
    assert np.array_equal(axis,b["rows"][:,0]) and np.array_equal(axis,minus["rows"][:,0])
    readout=lambda pkt:np.column_stack((pkt["rows"][:,1:3],pkt["integrated"][:,:6]))
    first,second,opposed=map(readout,(a,b,minus))
    cross=(first+COEFFICIENT**2*second-opposed)/(2*COEFFICIENT)
    tensor=np.stack((first,cross,cross,second),axis=-1).reshape(len(axis),first.shape[1],2,2)
    magnet=np.stack([Measured(1.,0.,profile).get(axis)[2] for profile in (0,1)],axis=-1)
    return axis,tensor,magnet


def freeze():
    predicted=LOCAL/"frozen-fourth.json"
    if predicted.exists() or list(LOCAL.glob("source-blind*")):raise RuntimeError("freeze out of order")
    rows=minus_checks(.025)+minus_checks(.0125)
    fine=rows[len(CLOCKS):]
    for item in fine:
        for key in ("polar_error_on_first","field_E_error","field_transverse_B_error","field_polar_B_error","whole_budget_error","whole_metric_error"):
            if item[key]>=TOL:raise ArithmeticError(f"precondition failed {item['tau']} {key}: {item[key]}")
    for key in ("dipole_error","floor_error","slack_error"):
        if fine[-1][key]>=TOL:raise ArithmeticError("late electromagnetic prediction "+key)
    axis,tensor,magnet=matrix(.0125)
    actual=np.array(WEIGHTS["blind"][:2])
    history=np.einsum("i,tkij,j->tk",actual,tensor,actual)
    metadata=dict(parent=LOCK,protocol=digest(LOCAL/"PROTOCOL.md"),minus=digest(LOCAL/name(.0125,1.,0.,"minus")),
                  clocks=axis.tolist(),fields=magnet.tolist(),matrix=tensor.tolist(),specified_weights=actual.tolist(),
                  blind_polar=(magnet@actual).tolist(),blind_history=history.tolist(),calibration_clocks=[3.,4.],
                  outputs=["ray","determinant","shear","twist","scalar","polar_E","dipole","material"],
                  probe="specified mixture (.6,.8); no measured blind fields or ruler available at freeze")
    write_table("earlier-frozen-prediction-checks.csv",rows)
    with predicted.open("x",encoding="utf8") as out:json.dump(metadata,out,separators=(",",":"),allow_nan=False)
    print("frozen",digest(predicted),"predicted late ruler",history[-1,0],flush=True)


if __name__=="__main__":freeze()
