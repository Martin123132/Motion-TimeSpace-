import sys
from matched_branch import LOCAL, TOL, WEIGHTS, digest, json, mixed, name, np, run, scores, write_table
from source_energy import exact_gram, extremes, interval, numerical


def vectors():
    alias=json.loads((LOCAL/"two-clock-alias.json").read_text())
    origin=np.asarray(alias["weights"]);end=np.array([0.,0.,1.])
    return origin,end,end-origin


def record():
    target=LOCAL/"frozen-midpoint.json"
    if target.exists() or list(LOCAL.glob("source-midpoint*")):raise RuntimeError("freeze out of order")
    origin,end,direction=vectors()
    direct=[mixed(.0125,1.,0.,tag) for tag in ("alias","outside","invisible")]
    def series(data):
        return np.column_stack((data["rows"][:,1:3],data["integrated"]))
    start,last,quad=map(series,direct);linear=last-start-quad
    data=direct[2]["rows"]
    early=[150,200]
    design=np.array(json.loads((LOCAL/"two-clock-alias.json").read_text())["matrix"])
    early_error=max(abs(data[early,3])/np.linalg.norm(design,axis=1))
    if early_error>=TOL:raise ArithmeticError(f"two-clock null failed: {early_error}")
    exact=exact_gram();gram=np.array(exact,dtype=float)
    assert np.linalg.eigvalsh(gram).min()>0
    ref=numerical(160); test=numerical(128)
    checks={}
    for label,source in (("alias",origin),("outside",end),("midpoint",origin+direction/2),("invisible",direction)):
        rec=source@gram@source
        coarse=numerical(128,.02,source);fine=numerical(160,.01,source)
        checks[label]=abs((4*fine-coarse)/(3*rec)-1)
    frozen=dict(protocol=digest(LOCAL/"PREPARATION-ENERGY.md"),inputs={name(.0125,1.,0.,tag):digest(LOCAL/name(.0125,1.,0.,tag)) for tag in ("alias","outside","invisible")},
                weights=(origin+direction/2).tolist(),null_weights=direction.tolist(),early_null_error=early_error,
                gram=gram.tolist(),exact_gram=[[str(entry) for entry in row] for row in exact],gram_errors=[scores(ref,gram),scores(test,gram)],
                relativistic_checks=checks,midpoint_readout=(start+linear/2+quad/4).tolist(),
                midpoint_polar=((direct[0]["rows"][:,3]+direct[1]["rows"][:,3])/2).tolist())
    with target.open("x") as out:json.dump(frozen,out,separators=(",",":"),allow_nan=False)
    print("frozen null-clock comparison and midpoint",frozen["midpoint_readout"][-1][0],flush=True)


def compare():
    frozen=json.loads((LOCAL/"frozen-midpoint.json").read_text())
    origin,end,direction=vectors();gram=np.array(frozen["gram"]);rows=[]
    first=mixed(.0125,1.,0.,"alias")["rows"][:,1];last=mixed(.0125,1.,0.,"outside")["rows"][:,1]
    invisible=mixed(.0125,1.,0.,"invisible")["rows"][:,1]
    linear=last-first-invisible;mid=mixed(.0125,1.,0.,"midpoint");coarse=mixed(.025,1.,0.,"midpoint")
    for tag,cap in (("alias_cost",origin@gram@origin),("third_shape_cost",end@gram@end)):
        best,least,bound=interval(gram,origin,direction,cap)
        assert bound is not None
        for time in (3.,4.,5.,6.,6.4):
            at=round(time/.02);lo,hi,tlo,thi=extremes(first[at],linear[at],invisible[at],bound)
            samples=np.linspace(bound[0],bound[1],1001)
            values=first[at]+linear[at]*samples+invisible[at]*samples**2
            assert min(values)>=lo-1e-23 and max(values)<=hi+1e-23
            for point in bound:assert abs((origin+point*direction)@gram@(origin+point*direction)/cap-1)<1e-12
            rows.append(dict(tau=time,illustrative_limit=tag,Wcap=cap,Wmin=least,tmin_energy=best,tlo=bound[0],thi=bound[1],
                         lowest_ruler=lo,highest_ruler=hi,t_at_low=tlo,t_at_high=thi,unmeasured_direction_ruler=invisible[at],
                         midpoint_actual=mid["rows"][at,1],midpoint_prediction=frozen["midpoint_readout"][at][0],
                         midpoint_ruler_error=scores(np.array(frozen["midpoint_readout"])[:,0],mid["rows"][:,1]),
                         midpoint_metric_error=scores(mid["rows"][:,2],mid["rows"][:,1]),midpoint_refine=scores(coarse["rows"][:,1],mid["rows"][:,1]),
                         midpoint_B_error=scores(np.array(frozen["midpoint_polar"]),mid["rows"][:,3])))
    write_table("kinetic-energy-bounds.csv",rows)


if __name__=="__main__":
    part=sys.argv[1]
    if part=="freeze":record()
    elif part=="compare":compare()
    else:
        origin,end,direction=vectors()
        if part=="invisible":WEIGHTS[part]=tuple(direction)
        elif part=="midpoint":
            frozen=json.loads((LOCAL/"frozen-midpoint.json").read_text())
            assert frozen["protocol"]==digest(LOCAL/"PREPARATION-ENERGY.md")
            assert all(digest(LOCAL/filename)==value for filename,value in frozen["inputs"].items())
            WEIGHTS[part]=tuple(frozen["weights"])
        else:raise ValueError(part)
        for dx in (.025,.0125):run(dx,1.,0.,part)
