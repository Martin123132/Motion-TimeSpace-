import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from unittest.mock import patch

LOCAL=Path(__file__).resolve().parent
BASE=LOCAL.parent/"mts-regular-centre-burst-20261118"
LOCK="72fffddb0d0e6cbd104aedcca3075ae7d96b4eb477aba11a6a9f2af79cf1e156"
for key in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[key]="1"
sys.dont_write_bytecode=True
sys.path.insert(0,str(BASE))
import regular
import exposure
import signed_equations
import smooth_launch
from regular import Centre, CoreBasis, np
from mass_flux import diagnostics
from metric_controls import core_constraints
from scipy.interpolate import make_interp_spline
from current_source import MASS, spin as original_spin
from scipy.special import betainc

COEFFICIENT=1.1666214009559583
TOL=2e-5
WEIGHTS={"minus":(1.,-COEFFICIENT,0.),"blind":(.6,.8,0.),"outside":(0.,0.,1.)}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def receipt():
    assert digest(BASE/"closeout.json")==LOCK
    return json.loads((BASE/"closeout.json").read_text())


def inherited(name):
    path=BASE/name
    assert digest(path)==receipt()["files"][name],name
    return path


def hold():
    if any((root/"STOP-REQUESTED").exists() for root in (LOCAL,BASE,regular.PARENT)):
        raise SystemExit("owner hold")


def law(label,weights):
    first,second,third=weights
    frac=np.clip(label/MASS,0.,1.)
    variable=2*frac-1
    primitive=(32/3)*frac**3*(1-frac)**3
    slope=32*frac**2*(1-frac)**2*(1-2*frac)
    polynomial=first+second*variable+third*variable**2
    return slope*polynomial+2*primitive*(second+2*third*variable), MASS*primitive*polynomial


def name(dx,eta,amp,tag):
    return f"source-{tag}-dx{dx:g}-eta{eta:g}-h{amp:g}.npz"


def double_integral(clock,values):
    anti=make_interp_spline(clock,values,k=5,axis=0).antiderivative(2)
    return anti(clock)-anti(0)-clock[:,None]*anti.derivative()(0)


def run(dx,eta,amp,tag):
    hold(); regular.ensure()
    for key in ("core_basis.py","centre_base.py","regular.py","signed_equations.py","smooth_launch.py","exposure.py","mass_flux.py","metric_controls.py","connection.py","mass-force-ledger.csv","magnetic-null-predictions.csv"):
        inherited(key)
    target=LOCAL/name(dx,eta,amp,tag);partial=target.with_suffix(".partial")
    if target.exists() or partial.exists():raise FileExistsError(target)
    if tag=="blind" and not (LOCAL/"frozen-fourth.json").exists():raise RuntimeError("freeze the predictions first")
    weights=WEIGHTS[tag]
    model=Centre(dx,eta,amp,cap=12,reduced=True,damping=.5,mass_form=True)
    model.profile=weights
    reference=smooth_launch.solve
    seed={}
    def checked_solve(holder,green=False):
        solution,independent=reference(holder,green=True)
        grid=np.geomspace(.0078125,48,1601);values=solution.sol(np.log(grid))
        delta=independent(np.log(grid))-values
        seed["green_relative"]=float(np.max(abs(delta))/np.max(abs(values)))
        seed["constraint_at_detector"]=solution.sol(np.log(6.)).tolist()
        seed["outer_boundary"]=float(holder.outer(48.))
        return solution,independent
    with patch.object(smooth_launch,"spin",law),patch.object(smooth_launch,"solve",checked_solve):
        seed.update(smooth_launch.refresh(model,eta,amp,False,weights))
    first_y=model.y0.copy()
    start=model.logmetric(first_y)
    time_series=[];quality=[];mass=[];state=first_y
    with patch.object(signed_equations,"spin",law),patch.object(exposure,"spin",law):
        for index in range(321):
            hold(); clock=.02*index
            jac,trace,ham,gauss,*unused=model.rhs(state,True)
            radius=model.rad*np.sqrt(1+state[2].real[:,:1])
            metric=np.sqrt(1+state[0].real[:,:1])
            potential=state[19].real[:,:1]
            electric=-state[20].real[:,:1]/(metric*radius)
            magnetic=-model.dr(potential)/(metric*radius)
            polar=2*potential/radius**2
            sample=lambda array:float(model.atsite(array[:,0]))
            effects=exposure.terms(model,state)
            time_series.append([clock,model.contrast(state[17]),model.contrast(model.logmetric(state)-start),
                    sample(polar),sample(electric),sample(magnetic),sample(radius),sample(potential),
                    *effects,model.contrast(ham),model.contrast(gauss)])
            if index%10==0:
                quality.append([clock,*core_constraints(model,state)])
                mass.append([clock,*diagnostics(model,state)])
            if not np.isfinite(state).all():raise ArithmeticError(f"nonfinite at {clock}")
            if index==320:break
            steps=int(np.ceil(.02/(.30*dx)-1e-12));dt=.02/steps
            for _ in range(steps):
                first=model.rhs(state);second=model.rhs(state+dt*first/2)
                third=model.rhs(state+dt*second/2)
                state+=dt*(first+2*second+2*third+model.rhs(state+dt*third))/6
    data=np.array(time_series)
    integrals=double_integral(data[:,0],data[:,8:14])
    with partial.open("xb") as output:
        np.savez_compressed(output,rows=data,integrated=integrals,quality=quality,mass=mass,initial_info=json.dumps(seed),
                weights=weights,columns="tau ray determinant polar_B equator_E equator_B R potential shear twist scalar polar_E dipole material H2 gauss".split(),
                parent=LOCK,protocol=digest(LOCAL/"PROTOCOL.md"))
    partial.rename(target)
    print(target.name,"final",data[-1,[1,2,3]],"direct",integrals[-1,4],"Green",seed["green_relative"],flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("dx",type=float);parser.add_argument("eta",type=float)
    parser.add_argument("amp",type=float);parser.add_argument("tag",choices=WEIGHTS)
    args=parser.parse_args()
    run(args.dx,args.eta,args.amp,args.tag)
