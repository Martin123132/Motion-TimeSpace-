import ast
import csv
from response_map import CLOCKS, COEFFICIENT, LOCAL, LOCK, TOL, WEIGHTS, digest, inherited, json, matrix, minus_checks, mixed, name, np, scores
from mixed_current import BASE, MASS, law, original_spin, receipt, regular
from source_energy import exact_gram
from matched_branch import series
import sys

def read(name):
    with (LOCAL/name).open() as stream:return list(csv.DictReader(stream))


def verify():
    regular.ensure();receipt()
    checks={};accuracy={};inputs={}
    def check(key,predicate):
        if key in checks or not bool(predicate):raise AssertionError(key)
        checks[key]=True
    def score(key,value):
        value=float(value)
        if key in accuracy or not np.isfinite(value) or value<0:raise ArithmeticError(key)
        accuracy[key]=dict(relative=value,passed=value<TOL)
    def source(path):inputs[str(path.parent.name+"/"+path.name)]=digest(path)
    source(BASE/"closeout.json")
    for key in ("mass_flux.py","centre_base.py","core_basis.py","connection.py","signed_equations.py","smooth_launch.py","exposure.py","metric_controls.py","regular.py","resolved_flux.py","magnetic-null-predictions.csv","mass-force-ledger.csv"):
        source(inherited(key))
    for dx in (.025,.0125):
        for profile in (0,1):source(inherited(f"budget-d{dx:g}-q1-h0-s0-p{profile}-c12-r15-t0.3-ko0.5-seed1.npz"))
        source(inherited(f"budget-d{dx:g}-q0.8-h1-s0-p0-c12-r15-t0.3-ko0.5-seed1-mass.npz"))
    from initial import CH
    for charge,amp in ((1.,0.),(.8,0.),(.8,1.)):
        source(regular.source(CH,f"charged-1920-eta{charge:g}-h{amp:g}-b1.npz"))
    for folder,names in ((regular.PRE,("initial.py",)),(regular.SRC,("current_source.py","driven-1920-eta1-h0-spin0.npz","driven-1920-eta1-h0-spin1.npz")),
                         (regular.CLOUD,("path-1920-eta1-h0.npz","strip-1920-eta1-h0.npz"))):
        for member in names:source(regular.source(folder,member))
    for key in LOCAL.glob("*.py"):ast.parse(key.read_text(encoding="utf-8"))
    for key in LOCAL.glob("*.csv"):
        rows=read(key.name);check(key.name+" parse",len(rows)>0 and all(None not in row and None not in row.values() for row in rows))
    check("no temporary residue",not list(LOCAL.glob("*.partial")) and not (LOCAL/"__pycache__").exists())
    labels=np.linspace(0.,MASS,101);unit=np.eye(3)
    for index in range(2):
        answer=law(labels,unit[index]);old=original_spin(labels,index)
        score("historic primitive "+str(index),scores(answer[1],old[1]));score("historic material law "+str(index),scores(answer[0],old[0]))
    for index in range(3):
        ell,primitive=law(labels,unit[index])
        check("balanced primitive and finite stationary edges "+str(index),not np.any(primitive[[0,-1]]) and not np.any(ell[[0,-1]]))
        nodes,weights=np.polynomial.legendre.leggauss(12)
        rebuilt=np.array([rad/2 * (weights@law(rad/2*(1+nodes),unit[index])[0]) for rad in labels])
        score("independent number integration "+str(index),scores(rebuilt,primitive))
    frozen=json.loads((LOCAL/"frozen-fourth.json").read_text())
    energy=json.loads((LOCAL/"frozen-midpoint.json").read_text())
    calibrated=json.loads((LOCAL/"magnetically-matched-scalar.json").read_text())
    alias=json.loads((LOCAL/"two-clock-alias.json").read_text())
    expected_weights=dict(WEIGHTS,alias=tuple(alias["weights"]),invisible=tuple(energy["null_weights"]),midpoint=tuple(energy["weights"]),
                          first=(1.,0.,0.),second=(0.,1.,0.),calibrated=(*calibrated["scalar"]["weights"],0.))
    check("actual sourced freezes",frozen["parent"]==LOCK and frozen["protocol"]==digest(LOCAL/"PROTOCOL.md") and
          energy["protocol"]==digest(LOCAL/"PREPARATION-ENERGY.md") and calibrated["protocol"]==digest(LOCAL/"MATCHED-SCALAR-PROTOCOL.md")
          and digest(LOCAL/name(.0125,1.,0.,"minus"))==frozen["minus"] and digest(LOCAL/name(.0125,1.,0.,"outside"))==alias["source_packet"])
    for freeze in (energy,calibrated):
        check(freeze["protocol"]+" linked predictions",all(digest(LOCAL/key)==val for key,val in freeze["inputs"].items()))
    expected=set()
    for charge,tag,amp in ([(1.,tag,0.) for tag in ("minus","blind","outside","alias","invisible","midpoint")]+
                [(.8,"minus",0.),(.8,"minus",1.),(.8,"first",0.),(.8,"second",0.),(.8,"second",1.),(.8,"calibrated",1.)]):
        for dx in (.025,.0125):
            member=name(dx,charge,amp,tag);expected.add(member)
            packet=mixed(dx,charge,amp,tag);data=packet["rows"];parts=packet["integrated"];qual=packet["quality"];mass=packet["mass"]
            check(member+" physical run",np.array_equal(packet["weights"],expected_weights[tag]) and str(packet["parent"])==LOCK and str(packet["protocol"])==digest(LOCAL/"PROTOCOL.md") and
                  data.shape==(321,16) and np.array_equal(data[:,0],np.arange(321)*.02) and np.isfinite(data).all() and
                  np.isfinite(parts).all() and np.isfinite(qual).all() and np.isfinite(mass).all())
            score(member+" independent initial Green constraint",json.loads(str(packet["initial_info"]))["green_relative"])
            score(member+" metric volume",scores(data[:,2],data[:,1]));score(member+" integrated stresses",scores(parts.sum(axis=1),data[:,1]))
            score(member+" radial mass",max(mass[:,1])/max(mass[:,2]));score(member+" mass from metric",max(mass[:,3])/max(mass[:,4]))
            for block,offset in (("core",1),("domain",9)):
                for idx,label in enumerate(("Mr","Mtheta","Vr","Vtheta")):
                    where=offset+2*idx
                    score(member+" "+block+" "+label,float(max(qual[:,where])/max(qual[:,where+1])))
            if dx==.0125:
                coarse=mixed(.025,charge,amp,tag)["rows"]
                score(member+" radial ruler",scores(coarse[:,1],data[:,1]))
                score(member+" radial magnetic field",scores(coarse[:,3],data[:,3]))
    check("matched arms and no orphan packet",expected=={path.name for path in LOCAL.glob("*.npz")})
    for dx in (.025,.0125):
        computed=minus_checks(dx)
        saved=[row for row in read("earlier-frozen-prediction-checks.csv") if float(row["dx"])==dx]
        check(str(dx)+" frozen EM recomputation",len(saved)==5 and all(float(earlier[key])==float(now[key]) for earlier,now in zip(saved,computed) for key in now))
        for row in computed:
            for key in ("polar_error_on_first","dipole_error","floor_error","slack_error","spatial_sampling_error"):
                score(f"early freeze {dx} {row['tau']} {key}",row[key])
    clock,mats,fields=matrix(.0125)
    check("frozen matrix reconstructed",np.array_equal(mats,frozen["matrix"]) and np.array_equal(fields,frozen["fields"]))
    predicted=np.einsum("i,tkij,j->tk",frozen["specified_weights"],mats,frozen["specified_weights"])
    check("frozen held-out prediction reconstructed",np.array_equal(predicted,frozen["blind_history"]))
    actual=mixed(.0125,1.,0.,"blind")
    achieved=np.column_stack((actual["rows"][:,1:3],actual["integrated"]))
    for index,label in enumerate(frozen["outputs"]):
        if label=="material":
            check("detector material contribution negligible",np.max(abs(achieved[:,index]))<1e-25)
        else:score("held-out direct "+label,scores(predicted[:,index],achieved[:,index]))
    for row in read("two-clock-calibration.csv"):
        if row["source"]=="outside":continue
        for key in ("weight_error","future_field_error","future_ruler_error"):
            score("conditional inverse "+row["source"]+" "+key,row[key])
    pair=read("direct-degeneracy.csv")
    for row in pair:
        if float(row["tau"]) in (3.,4.):score("two actual matched sources "+row["dx"]+" "+row["tau"],row["early_or_late_B_relative"])
    direct=mixed(.0125,1.,0.,"outside")["rows"];mimic=mixed(.0125,1.,0.,"alias")["rows"]
    late_cross=(mimic[-1,1]-direct[-1,1])/direct[-1,1]
    match=next(row for row in pair if float(row["dx"])==.0125 and float(row["tau"])==6.4)
    check("measured late degeneracy recomputed",float(match["volume_fraction"])==late_cross)
    for table,keys in (("mixed-scalar-control.csv",("differential_ledger","differential_metric","differential_refinement")),
                      ("matched-scalar-contrast.csv",("early_field_error_on_channel","predicted_field_error","matrix_error_on_total","matrix_error_on_difference","radial_error_on_difference","determinant_error_on_difference","ledger_error_on_difference"))):
        for row in read(table):
            if float(row["tau"])==6.4:
                for key in keys:score(table+" "+row["dx"]+" "+key,row[key])
    raw=mixed(.0125,.8,1.,"calibrated")["rows"];ordinary=series(.0125,0.,"minus")
    check("matched differential compared to actual ordinary and scalar histories",np.isclose(float(read("matched-scalar-contrast.csv")[4]["MTS_minus_ordinary"]),raw[-1,1]-ordinary[1][-1],rtol=1e-14,atol=0.))
    check("rational kinetic matrix rederived",[[str(entry) for entry in row] for row in exact_gram()]==energy["exact_gram"])
    for idx,value in enumerate(energy["gram_errors"]):score(f"independent kinetic gram {idx}",value)
    for key,value in energy["relativistic_checks"].items():score("proper relativistic energy "+key,value)
    score("actual invisible two-clock source",energy["early_null_error"])
    midpoint=mixed(.0125,1.,0.,"midpoint")
    score("held-out midpoint direction",scores(np.array(energy["midpoint_readout"])[:,0],midpoint["rows"][:,1]))
    for row in read("kinetic-energy-bounds.csv"):
        if float(row["tau"])==6.4:
            for key in ("midpoint_ruler_error","midpoint_metric_error","midpoint_refine","midpoint_B_error"):
                score("kinetic bound "+row["illustrative_limit"]+" "+key,row[key])
    exterior=read("arbitrary-current-launch-bound.csv")
    check("nine launch profiles, six exterior radii",len(exterior)==54 and
          len({(row["profile"],row["R"]) for row in exterior})==54 and {float(row["R"]) for row in exterior}=={5.,6.,8.,12.,24.,48.})
    for row in exterior:
        key="launch "+row["profile"]+" "+row["R"]
        check(key+" curvature bound and sign",0<float(row["delta_radial_tide"])<=float(row["tide_bound"]) and
              0<-float(row["u"])<=float(row["u_bound"]) and
              float(row["exterior_slope_lower"])<=float(row["slope"])<=float(row["exterior_slope_upper"]) and
              float(row["W"])/2<=float(row["I2"])<=float(row["C"])*float(row["W"]))
        score(key+" refined adjoint",row["adjoint_refinement"])
        if row["angular_constraint_error"]:score(key+" full material constraint",row["angular_constraint_error"])
    scalar_limits=read("scalar-launch-limit.csv")
    check("paired scalar-limit launch profiles",{row["profile"] for row in scalar_limits}=={"minus","second"} and len(scalar_limits)==2)
    for row in scalar_limits:
        label="scalar-to-ordinary launch "+row["profile"]
        check(label+" positive coercivity and verified bounds",float(row["kappa"])>0 and float(row["beta"])>0 and
              abs(float(row["difference_u"]))<=float(row["bound_difference_u"]) and
              abs(float(row["difference_tide"]))<=float(row["bound_difference_tide"]) and
              abs(float(row["actual_trace"]))<=float(row["uniform_trace_bound"]))
        score(label+" quadrature",row["moment_refinement"])
    zero_file=LOCAL/"zero-amplitude-launch-forecast.json";forecast=json.loads(zero_file.read_text())
    trials=read("finite-launch-variation.csv")
    check("scalar slopes matched amplitudes and sources",len(trials)==10 and
          {(float(row["amplitude"]),row["source"]) for row in trials}=={(amp,tag) for amp in (1.,.5,.25,.125,1/160) for tag in ("minus","second")})
    for row in trials:
        label="launch derivative "+row["source"]+" "+row["amplitude"]
        check(label+" frozen before finite test",row["forecast"]==digest(zero_file))
        for key in ("radial_tide_slope","trace_slope"):
            diff=abs(float(row[key])/forecast[row["source"]][key]-1)
            check(label+" calibrated error recomputed "+key,diff==float(row[key+"_forecast_error"]))
            score(label+" leading approximation "+key,diff)
        score(label+" direct subtraction",row["direct_difference_check"])
        if row["saved_full_tide_discrepancy"]:score(label+" matched previous full solve",row["saved_full_tide_discrepancy"])
    for row in read("tangent-refinement.csv"):
        for key in ("tide_refinement","trace_refinement","u_refinement"):score("launch derivative resolution "+row["source"]+" "+key,row[key])
    return dict(checks=checks,accuracy=accuracy,inputs=inputs)


def main():
    result=verify()
    result["files"]={key.name:digest(key) for key in sorted(LOCAL.iterdir()) if key.is_file() and key.name!="closeout.json"}
    target=LOCAL/"closeout.json"
    if "--seal" in sys.argv:
        with target.open("x",encoding="utf8") as out:json.dump(result,out,sort_keys=True,indent=1,allow_nan=False)
    elif "--preflight" not in sys.argv:assert json.loads(target.read_text())==result
    print(len(result["files"]),"files",len(result["inputs"]),"prior sources",len(result["checks"]),"structural checks",
          sum(item["passed"] for item in result["accuracy"].values()),"/",len(result["accuracy"]),"accuracy comparisons",digest(target) if target.exists() else "not sealed")
    if "--preflight" in sys.argv:print([(key,round(item["relative"],8)) for key,item in result["accuracy"].items() if not item["passed"]])


if __name__=="__main__":main()
