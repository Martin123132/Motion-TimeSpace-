from response_map import CLOCKS, COEFFICIENT, LOCAL, TOL, WEIGHTS, digest, inherited, json, mixed, name, np, packet, scores, write_table
from mixed_current import run
import sys


def series(dx,amp,tag):
    if amp==1. and tag=="first":
        old=packet(inherited(f"budget-d{dx:g}-q0.8-h1-s0-p0-c12-r15-t0.3-ko0.5-seed1-mass.npz"))
        data=old["rows"];return 2*data[:,12]/data[:,20]**2,data[:,1],data[:,2],old["integrated"][:,:6]
    current=mixed(dx,.8,amp,tag)
    return current["rows"][:,3],current["rows"][:,1],current["rows"][:,2],current["integrated"]


def infer(dx,amp,target):
    first,second,minus=[series(dx,amp,tag) for tag in ("first","second","minus")]
    design=np.stack((first[0],second[0]),axis=1)
    early=design[[150,200]]
    weights=np.linalg.solve(early,target)
    readouts=[np.column_stack(row[1:]) for row in (first,second,minus)]
    cross=(readouts[0]+COEFFICIENT**2*readouts[1]-readouts[2])/(2*COEFFICIENT)
    prediction=weights[0]**2*readouts[0]+2*weights[0]*weights[1]*cross+weights[1]**2*readouts[1]
    return dict(weights=weights.tolist(),early=early.tolist(),B=(design@weights).tolist(),ruler=prediction.tolist(),
                condition_common=float(np.linalg.cond(early)),condition_rescaled=float(np.linalg.cond(early/np.linalg.norm(early,axis=1)[:,None])))


def freeze():
    path=LOCAL/"magnetically-matched-scalar.json"
    if path.exists() or list(LOCAL.glob("source-calibrated*")):raise RuntimeError("calibrated test already frozen or run")
    ordinary=series(.0125,0.,"minus")[0];target=ordinary[[150,200]]
    document=dict(protocol=digest(LOCAL/"MATCHED-SCALAR-PROTOCOL.md"),clocks=[3.,4.],target_B=target.tolist(),
                  ordinary=infer(.0125,0.,target),scalar=infer(.0125,1.,target),
                  inputs={p.name:digest(p) for p in sorted(LOCAL.glob("source-*-eta0.8-*.npz"))})
    if scores(np.array(document["ordinary"]["weights"]),np.array([1.,-COEFFICIENT]))>=TOL:
        raise ArithmeticError("could not reconstruct the ordinary reference source")
    with path.open("x") as stream:json.dump(document,stream,allow_nan=False,separators=(",",":"))
    print("matched scalar weights",document["scalar"]["weights"],flush=True)


def compare():
    prepared=json.loads((LOCAL/"magnetically-matched-scalar.json").read_text())
    predicted=np.array(prepared["scalar"]["ruler"]);predB=np.array(prepared["scalar"]["B"])
    denominator=np.linalg.norm(np.array(prepared["scalar"]["early"]),axis=1)
    fine=mixed(.0125,.8,1.,"calibrated");coarse=mixed(.025,.8,1.,"calibrated")
    outputs=[]
    for dx,actual,other,otherdx in ((.0125,fine,coarse,.025),(.025,coarse,fine,.0125)):
        data=actual["rows"];fields,base,base_metric,base_terms=series(dx,0.,"minus")
        fixed=series(dx,1.,"minus")[1]-base;delta=data[:,1]-base
        terms=actual["integrated"]-base_terms
        other_delta=other["rows"][:,1]-series(otherdx,0.,"minus")[1]
        for time in CLOCKS:
            at=round(time/.02)
            outputs.append(dict(dx=dx,tau=time,ordinary=base[at],calibrated_scalar=data[at,1],MTS_minus_ordinary=delta[at],
                         fraction_of_ordinary=delta[at]/base[at],unchanged_current_difference=fixed[at],
                         source_reidentification=data[at,1]-base[at]-fixed[at],retained_fraction_of_fixed_effect=delta[at]/fixed[at],
                         scalar_term=terms[at,2],other_terms=sum(terms[at,[0,1,3,4,5]]),
                         early_field_error_on_channel=max(abs((data[[150,200],3]-np.array(prepared["target_B"]))/denominator)),
                         predicted_field_error=scores(predB,data[:,3]),matrix_error_on_total=scores(predicted[:,0],data[:,1]),
                         matrix_error_on_difference=scores(predicted[:,0]-series(.0125,0.,"minus")[1],delta),
                         radial_error_on_difference=scores(other_delta,delta),determinant_error_on_difference=scores(data[:,2]-base_metric,delta),
                         ledger_error_on_difference=scores(terms.sum(axis=1),delta)))
    write_table("matched-scalar-contrast.csv",outputs)


if __name__=="__main__":
    operation=sys.argv[1]
    if operation=="basis":
        for spacing in (.025,.0125):
            for tag,amplitude,weights in (("first",0.,(1.,0.,0.)),("second",0.,(0.,1.,0.)),("second",1.,(0.,1.,0.))):
                WEIGHTS[tag]=weights
                run(spacing,.8,amplitude,tag)
    elif operation=="freeze":freeze()
    elif operation=="test":
        frozen=json.loads((LOCAL/"magnetically-matched-scalar.json").read_text())
        assert frozen["protocol"]==digest(LOCAL/"MATCHED-SCALAR-PROTOCOL.md")
        for source,expected in frozen["inputs"].items():assert digest(LOCAL/source)==expected
        WEIGHTS["calibrated"]=(*frozen["scalar"]["weights"],0.)
        for spacing in (.025,.0125):run(spacing,.8,1.,"calibrated")
        compare()
    else:raise ValueError(operation)
