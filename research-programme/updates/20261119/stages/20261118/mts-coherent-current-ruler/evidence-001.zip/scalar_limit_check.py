from mixed_current import LOCAL, MASS, WEIGHTS, Centre, betainc, digest, json, law, np, patch, regular, smooth_launch
from response_map import mixed, write_table
from scipy.integrate import solve_ivp
from scipy.special import roots_legendre

D0=.000703828125
EDGE=5.
EXTENT=48.
ETA=.8


def shape():
    model=Centre(.025,ETA,1.,cap=12,damping=.5,reduced=True,mass_form=True)
    original=smooth_launch.spline;captured=[]
    def capture(nodes,values):
        result=original(nodes,values)
        if nodes[0]<0:captured.append(result)
        return result
    with patch.object(smooth_launch,"spline",capture):smooth_launch.refresh(model,ETA,1.,False,0)
    assert len(captured)==1
    result=captured[0]
    assert max(abs(result(EXTENT,order)) for order in (0,1,2))<1e-30
    return result


def count(radius):
    return MASS*betainc(1.5,7,np.minimum((radius/EDGE)**2,1.))


def background(fun,amp):
    def rhs(radius,state):
        mass,scaled=state;inv=1/radius if radius else 0.
        charge=ETA*count(radius)
        density=D0*max(0,1-(radius/EDGE)**2)**6
        fac0=1-2*mass*inv+(charge*inv)**2
        root0=np.sqrt(fac0);fac=fac0-2*amp**2*scaled*inv;root=np.sqrt(fac)
        phi=fun(radius);grad=fun(radius,1)
        return [radius**2*density*root0+ETA*radius*density*charge,
                .5*radius**2*(fac*grad**2+phi**2)-2*radius*density*scaled/(root+root0)]
    solution=solve_ivp(rhs,(0,EXTENT),[0.,0.],method="DOP853",rtol=4e-14,atol=1e-22,max_step=.1,dense_output=True)
    assert solution.success
    return solution.sol


def constants(fun,amp):
    compact=MASS**(2/3)*(D0/3)**(1/3)
    beta0=np.sqrt(1-2*compact-(ETA*compact)**2)
    hmax=max(abs(fun.c));gmax=max(abs(fun.derivative().c))
    maxenergy=EXTENT**2*(hmax**2+gmax**2)/6
    beta=np.sqrt(beta0**2-2*amp**2*maxenergy)
    diff=amp**2*maxenergy/beta;inv=diff/beta**2
    qinf=(ETA*compact)**2
    kappa=min(beta,1-(amp*EXTENT*hmax)**2/6)
    upper=(1+qinf/6)/beta+EDGE**2*D0/6
    delta=max(diff,((6+qinf)*inv+(amp*EXTENT*hmax)**2/beta)/6)
    assert beta>0 and kappa>0
    return beta0,beta,kappa,upper,delta,inv


def moments(order,weights):
    xx,omega=roots_legendre(order);xx=(1+xx)/2;omega=omega/2
    radius=EDGE*xx**2
    density=D0*(1-(radius/EDGE)**2)**6
    ell,primitive=law(count(radius),weights)
    baryon=omega@(2*np.sqrt(EDGE)*density*ell**2)/(6*np.sqrt(5))
    twist=2/(3*np.sqrt(5))*(omega@(2*EDGE**(-3.5)*primitive**2/xx**8))
    kinetic=omega@(2*EDGE*xx*density*ell**2)/3
    return np.array([baryon,twist,kinetic])


def main():
    fun=shape();radius=6.
    h0,h1,h2=[float(fun(radius,order)) for order in (0,1,2)]
    beta0,beta,kappa,upper,change,inv=constants(fun,1.)
    baseline_mass,scaled=background(fun,1.)(radius)
    charge=ETA*count(radius)
    mass0=baseline_mass-charge**2/(2*radius)
    fac0=1-2*mass0/radius;fac=fac0-2*scaled/radius
    mass=mass0+scaled
    fac_prime=2*mass/radius**2-radius*(fac*h1**2+h0**2+charge**2/radius**4)
    coeff0=-12/radius**2-4*mass0/radius**3+2*charge**2/radius**4
    coeff=coeff0-4*scaled/radius**3+2*h0**2+(6*fac+2*radius*fac_prime)*h1**2+4*radius*fac*h1*h2
    output=[]
    for tag,weights in (("minus",WEIGHTS["minus"]),("second",(0.,1.,0.))):
        grads=[]
        for amp in (0.,1.):
            data=mixed(.0125,ETA,amp,tag);grads.append(json.loads(str(data["initial_info"]))["constraint_at_detector"])
        (base,flux0),(full,flux)=grads
        baryon,twist,kinetic=moments(320,weights)
        low=moments(256,weights)
        check=np.max(abs(low/np.array([baryon,twist,kinetic])-1))
        source0=(baryon+twist/beta0)*(1+1e-9);dsource=inv*twist*(1+1e-9)
        bound=(dsource+change*source0/beta0)/(kappa*np.sqrt(5*radius))
        csrc=.5+D0*EDGE**2/(5*beta);c0=.5+D0*EDGE**2/(5*beta0)
        norm0=c0*kinetic/(5*radius*beta0)
        maxslope=3*upper/(radius*beta)
        slopechange=3*upper/radius*(change/(beta0*beta)+inv)
        dinitial=1.5*((abs(coeff)+4*fac*maxslope/radius)*bound+
                   (abs(coeff-coeff0)+4*(abs(fac-fac0)*maxslope+fac0*slopechange)/radius)*norm0)
        ordinary=1.5*(coeff0*base+4*np.sqrt(fac0)*flux0/radius**2)
        current=1.5*(coeff*full+4*np.sqrt(fac)*flux/radius**2)
        trace=6*radius*full*h0*h1
        trace_limit=6*csrc*kinetic*abs(h0*h1)/(5*kappa)
        output.append(dict(profile=tag,W=kinetic,beta0=beta0,beta=beta,kappa=kappa,form_change_cap=change,
                  Hmax=max(abs(fun.c)),Hgrad_max=max(abs(fun.derivative().c)),delta_mass=scaled,
                  difference_u=full-base,bound_difference_u=bound,moment_refinement=check,
                  ordinary_tide=ordinary,scalar_tide=current,difference_tide=current-ordinary,bound_difference_tide=dinitial,
                  actual_trace=trace,uniform_trace_bound=trace_limit,flux_moment=twist,kinetic_moment=baryon))
        assert abs(full-base)<=bound and abs(current-ordinary)<=dinitial and abs(trace)<=trace_limit
    write_table("scalar-launch-limit.csv",output)


if __name__=="__main__":main()
