from mixed_current import MASS, betainc, law, np
from fractions import Fraction
from math import comb


def convolve(left,right):
    return np.convolve(np.array(left,dtype=object),np.array(right,dtype=object))


def compose(coefficients,inside):
    total=np.array([Fraction(0)],dtype=object)
    for value in reversed(coefficients):
        total=convolve(total,inside);total[0]+=value
    return total


def exact_gram():
    density=np.zeros(13,dtype=object);fraction=np.zeros(16,dtype=object)
    for power in range(7):
        value=(-1)**power*comb(6,power)
        density[2*power]=Fraction(value)
        fraction[3+2*power]=Fraction(value,3+2*power)
    d0=Fraction(1,500)/(125*sum(fraction))
    assert float(d0)==.000703828125
    fraction=fraction/sum(fraction)
    integral=[0,0,0,Fraction(32,3),-32,32,Fraction(-32,3)]
    laws=[]
    for degree in range(3):
        derivative=[(power+1)*val for power,val in enumerate(integral[1:])]
        laws.append(compose(derivative,fraction))
        integral=convolve(integral,[-1,2])
    matrix=[]
    for left in laws:
        row=[]
        for right in laws:
            chart=convolve(density,convolve(left,right))
            moment=sum(Fraction(val,power+1) for power,val in enumerate(chart))
            row.append(moment*5*d0/3)
        matrix.append(row)
    return matrix


def numerical(degree,spin=None,weights=None):
    nodes,wu=np.polynomial.legendre.leggauss(degree)
    radius=2.5*(1+nodes);wr=2.5*wu
    density=.000703828125*(1-(radius/5)**2)**6
    number=MASS*betainc(1.5,7,(radius/5)**2)
    laws=np.array([law(number,row)[0] for row in np.eye(3)])
    if spin is None:return np.einsum("ir,jr,r->ij",laws,laws,wr*density/3)
    polar,wa=np.polynomial.legendre.leggauss(16)
    momentum=(weights@laws/radius)[:,None]**2*(1-polar**2)[None,:]
    kinetic=momentum/(np.sqrt(1+spin**2*momentum)+1)
    return float((wr*density*radius**2)@kinetic@(wa/2))


def interval(gram,origin,direction,limit):
    curvature=direction@gram@direction
    centre=-(origin@gram@direction)/curvature
    least=(origin+centre*direction)@gram@(origin+centre*direction)
    if limit<least: return centre,least,None
    width=np.sqrt((limit-least)/curvature)
    return centre,least,(centre-width,centre+width)


def extremes(base,linear,quad,limits):
    points=list(limits)
    if quad!=0:
        vertex=-linear/(2*quad)
        if limits[0]<vertex<limits[1]:points.append(vertex)
    values=[base+linear*param+quad*param**2 for param in points]
    lo=int(np.argmin(values));hi=int(np.argmax(values))
    return values[lo],values[hi],points[lo],points[hi]
