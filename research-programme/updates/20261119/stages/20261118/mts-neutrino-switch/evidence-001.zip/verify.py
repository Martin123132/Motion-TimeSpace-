from datetime import datetime,timezone
from pathlib import Path
from fork import HERE,OLD,SEAL,KEYS,MODES,digest,need,np,read,safe,save
from science import archive,readrun
from compare import TOL
from transfer_run import SECTORS


def verify():
    safe()
    sealed=read(OLD/'closeout.json')['files']
    for name,meta in sealed.items():
        path=OLD/name
        need(path.stat().st_size==meta['bytes'] and digest(path)==meta['sha256'],'previous sealed file '+name)
    resolutions=read(HERE/'resolution-budget.json')
    need(resolutions['script']==digest(HERE/'resolution_budget.py') and resolutions['tolerance']==TOL,'fixed late gate')
    operators=read(HERE/'native-operator.json')
    late=read(HERE/'late-comparison.json') if resolutions['matched_pressure_gate'] else None
    checks={}
    for case in ('cold','heavy'):
        branch={}
        for path in sorted(HERE.glob(case+'-*.npz')):
            meta=read(path.with_suffix('.json'))
            need(meta.get('packet',meta.get('forecast'))==digest(path),'numerical packet '+path.name)
            with np.load(path) as data:
                for key in data.files:
                    values=data[key]
                    if values.dtype.kind in 'iuf':
                        need(np.isfinite(values).all(),'finite '+path.name+':'+key)
            if 'fork_sha' in meta:
                scheme='main' if any(part in path.name for part in ('-direct-onset','-unit-shear')) else path.name.split('-')[1]
                need(meta['fork_sha']==digest(HERE/(case+'-'+scheme+'-fork.npz')),'retained identical restart')
            if path.stem.endswith('-late'):
                original=path.with_name(path.name.replace('-late.npz','.npz'))
                need(meta['source']==digest(original) and meta['gate']==digest(HERE/'resolution-budget.json'),'chronological restart receipt')
        for scheme in ('main','fine','native5'):
            states={tag:readrun(case,scheme,tag) for tag in MODES}
            for key in KEYS:
                if key!='massless_shear_x':
                    need(all(vals[key][0]==states['free'][key][0] for vals in states.values()),'matching physical data at switch: '+key)
            matrix=read(HERE/(scheme+'-comparison.json'))['cases'][case]['channels']['both_archive']
            native=archive(case)
            truth=native['mts_dp_s']
            slots=np.searchsorted(states['free']['x'],native['x'])
            errors=states['both']['both_archive'][slots]/truth-1
            need(np.array_equal(errors,matrix['panel']['both']['nine_errors']),'material pressure errors independently read back')
            parts=matrix['effects']['event_fraction_of_free_gap']
            need(abs(sum(parts.values())-1)<2e-12,'complete signed factorial decomposition')
            branch[scheme]=dict(event_error=errors[0],worst_error=max(abs(errors)),nominal_passes=int(sum(abs(errors)<=TOL)))
        test=read(HERE/(case+'-direct-onset.json'))
        with np.load(HERE/(case+'-direct-onset.npz')) as evolution:
            need(not np.any(evolution['zero']) and np.array_equal(evolution['main'],-evolution['reverse']),'zero and opposite source controls')
            t=evolution['t'][1:4]
            for col,key in enumerate(evolution['names']):
                ratio=evolution['fine'][1:4,col]/(evolution['coefficients'][col]*t**evolution['powers'][col])
                intercept=(8*ratio[0]-6*ratio[1]+ratio[2])/3
                need(abs(intercept-test['support'][key]['intercept'])<1e-12 and test['support'][key]['passes'],'independent order and coefficient: '+key)
        unit=read(HERE/(case+'-unit-shear.json'))
        need(unit['source']==digest(HERE/'stress_kernel.py') and unit['method']==digest(HERE/'SHEAR-KERNEL.md'),'independent-source kernel provenance')
        branch['unit_shear_pressure_results']={power:dict(exponent=items['physical_pressure']['exponent'],passes=items['physical_pressure']['passes'])
            for power,items in unit['tests'].items()}
        photon=read(HERE/(case+'-photon-probe.json'))
        need(photon['inputs']==digest(HERE/(case+'-main-fork.npz')) and photon['method']==digest(HERE/'PHOTON-STRESS.md')
             and photon['script']==digest(HERE/'photon_test.py') and photon['source']==digest(HERE/'photon.c')
             and photon['dll']==digest(HERE/'photon.dll') and photon['tolerance']==TOL,'same photon fork, equations and threshold')
        with np.load(HERE/(case+'-photon-probe.npz')) as probes:
            clock=probes['t']
            column=probes['names'].tolist().index('physical_pressure')
            coefficients={}
            for channel,power in [('neutrino',4),('intensity',4),('polarization',5)]:
                receipt=photon['sources'][channel]['physical_pressure']
                def intercept(variant,start):
                    selected=slice(start,start+3)
                    estimates=probes[channel+'_'+variant][selected,column]/clock[selected]**power
                    return (8*estimates[0]-6*estimates[1]+estimates[2])/3
                value=intercept('trace',0)
                coefficients[channel]=value
                sensitivity=sum(abs(value-intercept(tag,start)) for tag,start in [('trace',1),('constraint',0),('coarser',0)])
                error=abs(value/receipt['predicted']-1)+sensitivity/abs(receipt['predicted'])
                need(receipt['power']==power and abs(value/receipt['predicted']-receipt['intercept'])<1e-12
                     and (error<=TOL)==receipt['passes'],'recompute photon coefficient and its budget')
            ratio=coefficients['intensity']/coefficients['neutrino']
            need(abs(ratio/photon['source_ratios']['predicted']-1)<=TOL and
                 abs(coefficients['polarization']/(coefficients['intensity']*.6*photon['thomson_per_x']/5)-1)<=TOL
                 and not np.any(probes['polarization_no_mixing']),'Thomson mixing factor, relative radiation weight and off-diagonal null')
            branch['photon_response']=dict(intensity_to_neutrino=ratio,polarization_to_intensity=coefficients['polarization']/coefficients['intensity'],
                pressure_coefficients_pass=all(record['physical_pressure']['passes'] for record in photon['sources'].values()),mixing_null=True)
        for label in ('main','fine'):
            response=read(HERE/(label+'-sector-response.json'))['cases'][case]['changes']['both']
            need(abs(sum(response['event_fraction_of_jump'].values())-1)<=TOL and response['independent_sum_error_over_jump']<=TOL,'separate source sum on effect scale')
        exact=operators['cases'][case]['variants']['as_Fortran_real4']
        need(all(row['points']==row['boundary']['pass_count'] and row['points']==row['momentum']['pass_count'] for row in exact),'native massive boundary verified on all momenta')
        if late:
            actual=late['cases'][case]
            need(actual['start']==2000 and actual['end']>=actual['start'],'new, nonduplicated window')
            branch['later_rows']=[actual['start'],actual['end']]
            for arm in ('free','both'):
                data=actual['channels'][arm]['both_archive']
                need(data['epochs']==actual['end']-actual['start']+1 and 0<=data['passed']<=data['epochs'],'all later rows counted')
                dense=read(HERE/(case+'-fine-'+arm+'-observed.json'))
                need(dense['original']==digest(HERE/(case+'-fine-'+arm+'-late.npz')) and dense['original_rows']==2254 and
                     dense['steps']==read(HERE/(case+'-fine-'+arm+'-late.json'))['steps'] and
                     dense['all_saved_readouts_identical'] and dense['terminal_identical'],'same trajectories with passive observation')
            with np.load(HERE/(case+'-pressure-terms.npz')) as decomposition:
                need(decomposition['missed'].sum()==2253-actual['channels']['both']['both_archive']['passed'] and
                     max(abs(decomposition['terms'].sum(axis=0)-decomposition['residual']))<2e-14*max(abs(decomposition['truth'])),'unchanged pressure count; exact component sum')
            with np.load(HERE/(case+'-velocity-memory.npz')) as memory:
                for solver in ('small_step','cubic','pchip'):
                    need(max(abs(memory[solver].sum(axis=0)-memory['gap']))<2e-14*max(abs(memory['archive'])),'full signed memory accounting')
            branch['exchange_integrals']={}
            radiation=read(HERE/'dense-radiation.json')
            for key in ('angular','drag'):
                detail=radiation['channels'][key]['both']
                recomputed=sum(value for parts in detail['parts'].values() for name,value in parts.items() if name!='sparse_disagreement')/abs(detail['contrast'])
                need(abs(recomputed-detail['budget_over_contrast'])<1e-15 and detail['passes']==(recomputed<=TOL),'absolute radiation resolution components before cancellations')
                branch['exchange_integrals'][key]=dict(budget_over_contrast=recomputed,passes=detail['passes'])
        checks[case]=branch
    save(HERE/'verification.json',dict(time=datetime.now(timezone.utc).isoformat(),source=digest(Path(__file__)),previous_seal=SEAL,
         older_artifacts_rehashed=len(sealed),tolerance=TOL,branches=checks,pressure_gate=resolutions['matched_pressure_gate']))


if __name__=='__main__':
    verify()
