import math
import sys
from ctypes import CDLL
from pathlib import Path
from fork import HERE,KEYS,bridge,data,digest,need,np,read,safe,save
from onset_test import solve


def prove(case):
    _,_,args,clock,_=data(case,'main')
    checkpoint=HERE/(case+'-main-fork.npz')
    with np.load(checkpoint) as pack:
        common=pack['state']
        readout=dict(zip(KEYS,pack['forecast'][-1]))
    times=2.**np.arange(-11,-6)
    clocks=clock+np.r_[0.,times]
    fw=args[6][2]/common[0]**2
    names=['shear','flux','compensated_density','metric_eta','half_density','cdm_x','cdm','physical_pressure','archived_background_pressure']
    tests={}
    lib=CDLL(str(HERE/'impulse.dll')).propagate2
    lib.argtypes=bridge.SOLVE.argtypes
    lib.restype=bridge.SOLVE.restype
    packets={}
    for power in range(4):
        safe()
        p1,p2,p3,p4=[math.factorial(power)/math.factorial(power+n) for n in (1,2,3,4)]
        coeff=np.array([1.,-2*p1/3,2*p2/3,-fw*p2,fw*p2,2*fw*p3,2*fw*p4,
            2*fw*p4*readout['physical_velocity']**2,2*fw*p4*readout['archived_velocity']**2])
        degree=power+np.array([0,1,2,2,2,3,4,4,4])
        force=np.zeros(4)
        if power:
            force[4-power]=power
        extended=np.r_[args[-1],clock,1.,1.,force]
        results={}
        for tag,mode,ratio in [('fluid',7,128),('stream',3,128),('constraint',2,128),('coarser',3,64)]:
            state=np.zeros_like(common)
            state[0]=common[0]
            for idx in range(args[3]):
                pos=10+idx*4
                state[pos:pos+2]=common[pos:pos+2]
            stride=args[1]+2
            for idx in range(args[0]+1):
                pos=18+(idx+1)*stride-1
                state[pos]=common[pos]
            if not power:
                state[20]=1.
            arguments=(*args[:5],mode+16,*args[6:-1],extended)
            out=dict(zip(KEYS,solve(lib,arguments,state,clocks,times[0]/ratio)[1:].T))
            vals=np.array([out['massless_shear'],out['v_neutrino'],out['delta_neutrino']-4*out['delta_cdm']/3,out['etak']/5,
                1.5*args[6][2]*out['delta_neutrino']/(5*out['a']/args[6][0])**2,out['active_cdm_x'],out['delta_cdm'],out['mts_dp_s'],out['both_archive']]).T
            measured=vals/(coeff*times[:,None]**degree)
            results[tag]=((8*measured[0]-6*measured[1]+measured[2])/3,(8*measured[1]-6*measured[2]+measured[3])/3)
            packets[tag+str(power)]=vals
        central=results['stream'][0]
        sensitivity=abs(central-results['stream'][1])+sum(abs(central-results[tag][0]) for tag in ('fluid','constraint','coarser'))
        tests[str(power)]={name:dict(exponent=int(degree[idx]),analytic=coeff[idx],measured_over_prediction=central[idx],
            fluid_over_prediction=results['fluid'][0][idx],spread=sensitivity[idx],passes=bool(abs(central[idx]-1)+sensitivity[idx]<=2e-5))
            for idx,name in enumerate(names)}
    dest=HERE/(case+'-unit-shear.npz')
    with dest.open('xb') as handle:
        np.savez_compressed(handle,t=times,names=names,**packets)
    save(dest.with_suffix('.json'),dict(tolerance=2e-5,packet=digest(dest),source=digest(Path(__file__)),method=digest(HERE/'SHEAR-KERNEL.md'),
         dll=digest(HERE/'impulse.dll'),include=digest(HERE/'injection.inc'),fork_sha=digest(checkpoint),case=case,tests=tests))


if __name__=='__main__':
    for case in sys.argv[1:]:
        prove(case)
