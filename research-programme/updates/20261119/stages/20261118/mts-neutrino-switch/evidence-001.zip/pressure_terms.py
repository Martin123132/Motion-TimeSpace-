from pathlib import Path
from fork import HERE,KEYS,bridge,digest,need,np,read,safe,save
from compare import TOL,preparation


def inspect(case):
    config,_,splines,_=preparation(case)
    mass=config['masses'][0]
    with np.load(config['ref']) as packet:
        pos=np.flatnonzero(packet['modes']==5)[0]
        native=dict(zip(packet['names'].tolist(),packet['values'][pos,2000:4253].T.astype(float)))
    outputs={}
    for tag in ('main','fine','angular','highq','trace'):
        path=HERE/(case+'-'+tag+'-both-late.npz')
        need(digest(path)==read(path.with_suffix('.json'))['packet'],'saved comparison')
        with np.load(path) as packet:
            outputs[tag]=dict(zip(KEYS,packet['forecast'][1:].T.copy()))
    row=outputs['fine']
    velocity=splines[1](np.log(native['a']))
    weight=(native['a']*mass)**2*splines[0](np.log(native['a']))
    vel_field=native['mts_dphidot_s']
    phi_field=native['mts_dphi_s']
    kinetic,potential=velocity*vel_field,weight*phi_field
    truth=native['mts_dp_s']
    reference=np.abs(truth)
    peak=reference.max()
    gain=(row['a']*mass)**2*row['archived_phi']
    terms=np.array([row['archived_velocity']*(row['shadow_dphidot']-vel_field),
                    -gain*(row['shadow_dphi']-phi_field),
                    (row['archived_velocity']-velocity)*vel_field-(gain-weight)*phi_field,
                    (kinetic-potential)-truth])
    residual=row['both_archive']-truth
    need(max(abs(terms.sum(0)-residual))/peak<2e-14,'paired signed kinetic, potential, readout and archive components')
    native_density=native['mts_drho_s']
    consistency=max(max(abs(kinetic-(native_density+truth)/2)),max(abs(potential-(native_density-truth)/2)))/peak
    budget=sum(abs(outputs[tag]['both_archive']-outputs['main']['both_archive']) for tag in ('fine','angular','highq','trace'))
    missed=abs(residual)+budget>TOL*reference
    names=['perturbation_velocity','perturbation_field_value','background_weights','archived_stress_readback']
    ids=np.arange(2000,4253)
    need(len(ids)==len(truth) and sum(~missed)==read(HERE/'late-comparison.json')['cases'][case]['channels']['both']['both_archive']['passed'],'same sample, same gate')
    condition=(abs(kinetic)+abs(potential))/reference
    groups={}
    for label,mask in [('all',np.ones_like(missed)),('inside',~missed),('outside',missed)]:
        if not np.any(mask):
            groups[label]=dict(epochs=0)
            continue
        groups[label]=dict(epochs=int(mask.sum()),peak_normalized_component_maxima={name:max(abs(term[mask]))/peak for name,term in zip(names,terms)},
            dominant_component_counts=dict(zip(names,np.bincount(np.argmax(abs(terms[:,mask]),axis=0),minlength=len(terms)).tolist())),
            relative_to_peak_reference_range=[min(reference[mask])/peak,max(reference[mask])/peak],
            median_kinetic_potential_condition=np.median(condition[mask]),maximum_kinetic_potential_condition=max(condition[mask]),
            component_fractions_at_first={name:float(term[mask][0]/residual[mask][0]) if residual[mask][0]!=0 else None for name,term in zip(names,terms)})
    path=HERE/(case+'-pressure-terms.npz')
    with path.open('xb') as stream:
        np.savez_compressed(stream,epoch=ids,truth=truth,terms=terms,budget=budget,residual=residual,names=names,condition=condition,missed=missed)
    save(path.with_suffix('.json'),dict(packet=digest(path),native=digest(config['ref']),script=digest(Path(__file__)),
        source=digest(HERE/(case+'-fine-both-late.npz')),native_density_stress_identity_over_peak=consistency,groups=groups,tolerance=TOL))


if __name__=='__main__':
    safe()
    for case in ('cold','heavy'):
        inspect(case)
