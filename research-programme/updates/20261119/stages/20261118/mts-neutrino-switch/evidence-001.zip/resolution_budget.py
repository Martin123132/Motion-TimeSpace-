from pathlib import Path
from science import CHANNELS,TARGETS,archive,collect
from fork import HERE,OLD,digest,need,np,read,safe,save
from compare import TOL


def run():
    safe()
    tags=('main','fine','highq','angular','trace','native5','native5fine','literal5','literal5raw')
    state={}
    outcomes={}
    for case in ('cold','heavy'):
        truth=archive(case)
        allruns={tag:collect(case,tag,['free','both'])[1] for tag in tags}
        state[case]=allruns
        out={}
        for key in allruns['main']['free'][0]:
            native=truth[TARGETS.get(key,key)]
            arrays={tag:{arm:item[0][key]/native for arm,item in runs.items()} for tag,runs in allruns.items()}
            rows={}
            for arm in ('free','both','difference'):
                vals={k:(v['both']-v['free'] if arm=='difference' else v[arm]) for k,v in arrays.items()}
                numerical=sum(abs(vals[tag]-vals['main']) for tag in ('fine','highq','angular','trace'))
                target=vals['fine']
                rows[arm]=dict(worst_numerical_over_native=max(numerical),event=target[0],min_abs_over_native=min(abs(target)),
                    worst_numerical_over_output=max(numerical/np.maximum(abs(target),np.finfo(float).tiny)),
                    numerical_components_over_native={tag:max(abs(vals[tag]-vals['main'])) for tag in ('fine','highq','angular','trace')},
                    own_resolution_passes=int(sum(numerical<=TOL*abs(target))),
                    archive_agreement_passes=int(sum(abs(target-1)+numerical<=TOL)) if arm!='difference' else None,
                    smallest_sign_margin=min(abs(target)-numerical))
            raw=arrays['literal5raw']['both']
            book=abs(arrays['native5fine']['both']-arrays['native5']['both'])+abs(arrays['literal5']['both']-arrays['native5']['both'])
            rows['five_node']=dict(literal_raw_event_error=raw[0]-1,literal_balanced_event_error=arrays['literal5']['both'][0]-1,
                time_and_literal_spread=max(book),matter_source_convention=max(abs(arrays['literal5']['both']-raw)),
                late_agreement_nominal=int(sum(abs(raw-1)<=TOL)))
            out[key]=rows
        outcomes[case]=out
    radiation={}
    native_integrals=read(OLD/'transport-budget.json')['radiation']
    for key in ('drag_rate_x','angular_rate_x'):
        amounts={tag:{arm:state['heavy'][tag][arm][1][key]-state['cold'][tag][arm][1][key] for arm in ('free','both')} for tag in tags}
        true=native_integrals[key]['paired']['native']
        radiation[key]={}
        for arm in ('free','both'):
            core=amounts['fine'][arm]
            err=sum(abs(amounts[tag][arm]-amounts['main'][arm]) for tag in ('fine','highq','angular','trace'))
            radiation[key][arm]=dict(physical_contrast=core,relative_MTS_minus_baseline=core/state['cold']['fine'][arm][1][key],
                native_discrepancy=core/true-1,trial_spread_over_contrast=err/abs(core),internally_resolved=bool(err<=TOL*abs(core)),
                native_pass=bool(abs(core-true)+err<=TOL*abs(true)))
    gate=all(outcomes[case]['both_archive']['both']['archive_agreement_passes']==9 for case in outcomes)
    save(HERE/'resolution-budget.json',dict(script=digest(Path(__file__)),tolerance=TOL,comparisons=outcomes,radiation=radiation,matched_pressure_gate=gate))


if __name__=='__main__':
    run()
