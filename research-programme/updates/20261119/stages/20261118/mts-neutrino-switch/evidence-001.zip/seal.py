from datetime import datetime,timezone
from fork import HERE,digest,need,read,safe,save


if __name__=='__main__':
    safe()
    need((HERE/'verification.json').is_file() and (HERE/'RESULTS.md').is_file(),'check before sealing')
    files={p.name:dict(bytes=p.stat().st_size,sha256=digest(p)) for p in sorted(HERE.iterdir()) if p.is_file() and p.name!='closeout.json'}
    save(HERE/'closeout.json',dict(time=datetime.now(timezone.utc).isoformat(),files=files))
    rows=read(HERE/'closeout.json')['files']
    need(all(digest(HERE/key)==val['sha256'] for key,val in rows.items()),'seal readback')
    print(len(rows),sum(v['bytes'] for v in rows.values()),digest(HERE/'closeout.json'))
