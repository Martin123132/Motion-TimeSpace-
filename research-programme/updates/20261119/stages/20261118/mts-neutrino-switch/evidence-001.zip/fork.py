import os
import sys
from ctypes import CDLL, byref, c_longlong
from pathlib import Path

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'mts-massive-transport-20261117'
sys.path.insert(0,str(OLD))
import bridge
from bridge import NAMES, PRIOR, digest, need, np, read, save
from exact_run import raw_thermal
from first_output import COMMON
from shadow_run import EXTRA
from scipy.interpolate import CubicSpline

SEAL='4ffeac9d425d9d88f79cecf7fdab9074d26f85cc17d75a1011606a30b89308f9'
KEYS=NAMES+EXTRA+['massless_shear','inactive_or_active_octupole','massless_shear_x','massless_density_x','massless_flux_x','active_cdm_x','massive_source_factor']
MODES={'free':0,'fluid':4,'mass16':8,'both':12}
SCHEMES={'main':(24,272,.005,2),'fine':(24,272,.0025,2),'native5':(5,272,.005,2),'native5fine':(5,272,.0025,2),
         'highq':(32,272,.005,2),'angular':(24,320,.005,2),'trace':(24,272,.005,3),'raw5':(5,272,.005,0)}
LIB=CDLL(str(HERE/'switch.dll')).propagate2
LIB.argtypes=bridge.SOLVE.argtypes
LIB.restype=bridge.SOLVE.restype


def safe():
    bridge.guard()
    need(digest(OLD/'closeout.json')==SEAL and not any((p/'STOP-REQUESTED').exists() for p in (HERE,OLD)),'prior seal or owner hold')


def data(case,scheme):
    safe()
    count,limit,cap,mode=SCHEMES[scheme]
    bridge.thermal=raw_thermal
    cfg,xs,state,args,thermal=bridge.setup(case,(count,limit,16,cap,'table',True,0,False))
    source=COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    with np.load(source) as packet:
        grid,vel,phi=(packet[k] for k in ('efold','phidot_s','phi_s'))
    packed=np.column_stack((grid[:-1],CubicSpline(grid,vel,bc_type='natural').c.T,CubicSpline(grid,phi,bc_type='natural').c.T))
    packed=np.vstack((packed,[grid[-1],0,0,0,vel[-1],0,0,0,phi[-1]]))
    args=(*args[:5],mode,*args[6:-1],np.r_[args[-1],len(grid),packed.ravel()])
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as packet:
        signature=packet['signature'][0]
        wave=packet['packet'][0,14]
    threshold=max(20,int(signature[8])-4)
    need(wave==5 and threshold==52 and signature[12]==1 and signature[30]==5 and signature[40]==16,'retained flat branch switch and massive layout')
    return xs,np.r_[state,state[12:14]],args,threshold,dict(thermal=thermal['sha'],homogeneous=digest(source),early=digest(bridge.OLD/(case+'-origin-physical.npz')),native=digest(cfg['ref']))


def same_readout(state,args,clock):
    obs=np.zeros((1,len(KEYS)))
    unused=c_longlong()
    copy=state.copy()
    need(LIB(*args,copy,np.array([clock],float),1,.005,obs,byref(unused))==1 and np.isfinite(obs).all(),'finite zero-step readout')
    return obs[0]


def integrate(state,args,xs,cap):
    values=np.zeros((len(xs),len(KEYS)))
    steps=c_longlong()
    total=0
    cuts=np.unique(np.r_[0,np.arange(96,len(xs),96),len(xs)-1])
    for left,right in zip(cuts[:-1],cuts[1:]):
        safe()
        times=xs[left:right+1]
        obs=np.zeros((len(times),len(KEYS)))
        status=LIB(*args,state,times,len(times),cap,obs,byref(steps))
        need(status==1 and np.all(np.isfinite(obs)) and np.all(np.isfinite(state)),'finite partial trajectory')
        values[left+int(left>0):right+1]=obs[int(left>0):]
        total+=steps.value
    return values,total


def save_packet(base,meta,**arrays):
    with base.with_suffix('.npz').open('xb') as handle:
        np.savez_compressed(handle,**arrays)
    save(base.with_suffix('.json'),dict(**meta,packet=digest(base.with_suffix('.npz')),method=digest(HERE/'METHOD.md'),code=digest(Path(__file__)),library=digest(HERE/'switch.dll'),source=digest(HERE/'switch.c'),branches=digest(HERE/'branches.inc')))


def run(case,scheme,labels):
    xs,start,args,fork,hashes=data(case,scheme)
    count,limit,cap,baseflag=SCHEMES[scheme]
    base=HERE/(case+'-'+scheme+'-fork')
    if not base.with_suffix('.json').exists():
        need(not base.with_suffix('.npz').exists(),'partial restart: inspect, do not overwrite')
        start[2]=same_readout(start,args,xs[0])[35]
        times=np.r_[xs[xs<fork],float(fork)]
        obs,steps=integrate(start,args,times,cap)
        save_packet(base,dict(inputs=hashes,settings=SCHEMES[scheme],steps=steps),x=times,forecast=obs,names=KEYS,state=start)
    meta=read(base.with_suffix('.json'))
    need(meta['inputs']==hashes and meta['packet']==digest(base.with_suffix('.npz')) and meta['library']==digest(HERE/'switch.dll') and meta['settings']==list(SCHEMES[scheme]),'verified identical cached fork')
    with np.load(base.with_suffix('.npz')) as archive:
        common=archive['state']
        need(archive['x'][-1]==fork,'actual switch clock')
    times=np.unique(np.r_[float(fork),fork+np.array([.002,.004,.008,.016,.032,.064,.128]),xs[xs>fork]])
    for label in labels:
        target=HERE/(case+'-'+scheme+'-'+label)
        if target.with_suffix('.json').exists():
            info=read(target.with_suffix('.json'))
            need(info['packet']==digest(target.with_suffix('.npz')) and info['fork_sha']==meta['packet'] and info['flag']==baseflag+MODES[label],'verified existing output')
            continue
        state=common.copy()
        flag=baseflag+MODES[label]
        arguments=(*args[:5],flag,*args[6:])
        initial=same_readout(state,arguments,times[0])
        obs,steps=integrate(state,arguments,times,cap)
        need(np.array_equal(obs[0],initial),'no substep at switch')
        save_packet(target,dict(fork_sha=meta['packet'],settings=SCHEMES[scheme],flag=flag,steps=steps),
                    x=times,forecast=obs,names=KEYS,terminal=state)
        print(case,scheme,label,steps,flush=True)


if __name__=='__main__':
    run(sys.argv[1],sys.argv[2],sys.argv[3:] or tuple(MODES))
