from pathlib import Path
from fork import HERE,digest,need,np,read,safe,save
from compare import TOL
from radiation_window import CASES,RATES,SCHEMES,integrals


def run():
    safe()
    budget=read(HERE/'late-radiation.json')
    dense={}
    for case in CASES:
        dense[case]={}
        for arm in ('free','both'):
            path=HERE/(case+'-fine-'+arm+'-observed.npz')
            receipt=read(path.with_suffix('.json'))
            need(receipt['packet']==digest(path) and receipt['all_saved_readouts_identical'] and receipt['terminal_identical'],'passive observational replay')
            with np.load(path) as packet:
                row=dict(zip(packet['names'].tolist(),packet['values'].T.copy()))
            bounds=np.log(budget['scale_bounds'])
            dense[case][arm]={key:integrals(row,key,bounds) for key in RATES}
    details={}
    for key in RATES:
        previous=budget['channels'][key]
        contrasts={}
        for arm in ('free','both'):
            sums=previous['runs'][arm]
            delta=sums['contrast']
            allocations={}
            for case in CASES:
                family=previous['raw'][case]
                fine=family['fine_'+arm]
                main=family['main_'+arm]
                values=dense[case][arm][key]
                allocations[case]=dict(solver=sum(abs(family[tag+'_'+arm]['cell']-main['cell']) for tag in SCHEMES[1:]),
                    edge=abs(fine['cell_linear_edge']-fine['cell']),sample=max(abs(value-fine['cell']) for value in values.values()),
                    sparse_disagreement=abs(fine['pchip']-fine['cell']))
            absolute=sum(sum(part[k] for k in ('solver','edge','sample')) for part in allocations.values())
            contrasts[arm]=dict(contrast=delta,relative_to_baseline=sums['contrast_over_baseline'],parts=allocations,
                budget_over_contrast=absolute/abs(delta),passes=bool(absolute<=TOL*abs(delta)),
                prior_sparse_pass=sums['internally_resolved'],native_sampling_over_native_contrast=previous['native_sampling_spread_over_contrast'])
        details[key]=contrasts
    save(HERE/'dense-radiation.json',dict(script=digest(Path(__file__)),method=digest(HERE/'DENSE-READOUT.md'),sparse=digest(HERE/'late-radiation.json'),
        tolerance=TOL,scale_bounds=budget['scale_bounds'],channels=details,dense_quadratures=dense))


if __name__=='__main__':
    run()
