import sys
from pathlib import Path
from fork import HERE,OLD,PRIOR,KEYS,MODES,SCHEMES,bridge,data,digest,integrate,need,np,read,safe,save


def run(case,scheme,arms):
    safe()
    gate=read(HERE/'resolution-budget.json')
    need(gate['matched_pressure_gate'],'material nine-epoch gate must pass first')
    _,_,args,_,hashes=data(case,scheme)
    _,_,cap,mode=SCHEMES[scheme]
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as packet:
        times=5*packet['clock']
        scale=packet['packet'][:,1]
        sig=packet['signature']
    with np.load(bridge.inputs(case)['ref']) as ref:
        need(np.array_equal(times,5*ref['conformal_time'][1991:1991+len(times)]),'original forward clocks')
        if case=='heavy':
            names=list(ref['names'])
            ix=np.flatnonzero(ref['modes']==5)[0]
            selector=ref['values'][ix,1991:1991+len(times),names.index('mts_averaged_chart')]
        else:
            selector=np.zeros(len(times))
    cols=[3,4,5,6,7,8,11,12,13,14,27,30,40,60,70]
    valid=np.all(sig[:,cols]==sig[0,cols],axis=1)&(selector==selector[0])
    if case=='heavy':
        valid&=scale<.00028
    end=int(np.flatnonzero(~valid)[0]) if not valid.all() else len(times)
    need(end>9 and np.all(np.diff(times[:end])>0),'strict native time sequence on original chart')
    path=OLD.parent/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz')
    with np.load(path) as packet:
        table=packet['values']
        first,step=packet['metadata']
    tau=first*np.exp(step*np.arange(table.shape[1]))
    thermal_scale=tau*table[0]
    count=max(args[4],int(np.searchsorted(thermal_scale,1.01*max(scale[:end])))+3)
    ext=np.column_stack((thermal_scale[:count],tau[:count],table[:6,:count].T)).ravel()
    need(np.array_equal(ext[:args[4]*8],args[-1][:args[4]*8]) and digest(path)==hashes['thermal'],'bit-identical extended thermal support')
    args=(*args[:4],count,*args[5:-1],np.r_[ext,args[-1][args[4]*8:]])
    for arm in arms:
        original=HERE/(case+'-'+scheme+'-'+arm+'.npz')
        meta=read(original.with_suffix('.json'))
        need(digest(original)==meta['packet'],'verified terminal')
        with np.load(original) as packet:
            state=packet['terminal'].copy()
            previous=packet['forecast'][-1].copy()
            need(packet['x'][-1]==times[8],'previous window ends at the restart')
        args2=(*args[:5],mode+MODES[arm],*args[6:])
        rows,steps=integrate(state,args2,times[8:end],cap)
        keep=[i for i,k in enumerate(KEYS) if k not in ('cell_drag','cell_angular')]
        need(np.array_equal(rows[0,keep],previous[keep]),'no field or stress rematching at restart')
        out=HERE/(case+'-'+scheme+'-'+arm+'-late.npz')
        with out.open('xb') as file:
            np.savez_compressed(file,x=times[8:end],forecast=rows,names=KEYS,terminal=state)
        save(out.with_suffix('.json'),dict(source=digest(original),packet=digest(out),original_capture_hash=digest(PRIOR/(case+'-physical-roots-capture.npz')),
            method=digest(HERE/'CONTINUATION.md'),script=digest(Path(__file__)),gate=digest(HERE/'resolution-budget.json'),library=digest(HERE/'switch.dll'),
            inputs=hashes,first_row=1999,last_row=1991+end-1,capture_rows=len(times),stopped_for_chart=bool(end<len(times)),
            thermal_rows_extended=count,steps=steps))
        print(case,scheme,arm,'late',1991+end-1,steps,flush=True)


if __name__=='__main__':
    run(sys.argv[1],sys.argv[2],sys.argv[3:] or ['free','both'])
