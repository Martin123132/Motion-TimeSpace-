from pathlib import Path
import sys
from fork import HERE,SCHEMES,bridge,digest,np,need,run,save


def native(count):
    need(count==5,'native five-node rule only')
    nodes=np.array([.583165,2.,4.,7.26582,13.],dtype=np.float32).astype(float)
    weights=np.array([.0081201,.689407,2.8063,2.05156,.126817],dtype=np.float32).astype(float)/(7./120*np.pi**4)
    return nodes,weights


if __name__=='__main__':
    case,variant=sys.argv[1:3]
    need(variant in ('literal5','literal5raw'),'explicit weighting convention')
    SCHEMES[variant]=(5,272,.005,2 if variant=='literal5' else 0)
    bridge.quadrature=native
    run(case,variant,sys.argv[3:] or ['free','both'])
    out=HERE/(case+'-'+variant+'-rule.json')
    if not out.exists():
        q,w=native(5)
        save(out,dict(source=digest(Path(__file__)),nodes=q.tolist(),weights=w.tolist(),native_check=digest(HERE/'native-operator.json'),scheme=SCHEMES[variant]))
