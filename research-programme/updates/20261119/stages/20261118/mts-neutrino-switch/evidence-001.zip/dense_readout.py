from ctypes import CDLL,byref,c_int,c_longlong
import sys
from fork import HERE,OLD,KEYS,MODES,SCHEMES,bridge,data,digest,need,np,read,safe,save


def run(case,arm):
    safe()
    original=HERE/(case+'-fine-'+arm+'.npz')
    late=HERE/(case+'-fine-'+arm+'-late.npz')
    receipt=read(late.with_suffix('.json'))
    need(receipt['source']==digest(original) and receipt['packet']==digest(late),'frozen original and terminal')
    with np.load(original) as packet:
        state=packet['terminal'].copy()
    with np.load(late) as packet:
        expected=packet['forecast'].copy()
        clocks=packet['x'].copy()
        terminal=packet['terminal'].copy()
    _,_,args,_,hashes=data(case,'fine')
    thermal=OLD.parent/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz')
    need(digest(thermal)==hashes['thermal'] and receipt['inputs']==hashes,'same raw inputs')
    count=receipt['thermal_rows_extended']
    with np.load(thermal) as packet:
        table=packet['values'][:,:count]
        first,spacing=packet['metadata']
    tau=first*np.exp(spacing*np.arange(count))
    ext=np.column_stack((tau*table[0],tau,table[:6].T)).ravel()
    need(np.array_equal(ext[:8*args[4]],args[-1][:8*args[4]]),'unchanged original table')
    args=(*args[:4],count,args[5]+MODES[arm],*args[6:-1],np.r_[ext,args[-1][args[4]*8:]])
    library=CDLL(str(HERE/'observed.dll'))
    library.propagate2.argtypes=bridge.SOLVE.argtypes
    library.propagate2.restype=bridge.SOLVE.restype
    vector=np.empty((receipt['steps'],5))
    library.set_readout.argtypes=[bridge.PTR,c_int]
    library.set_readout.restype=None
    library.set_readout(vector.ravel(),len(vector))
    partitions=np.unique(np.r_[0,np.arange(96,len(clocks),96),len(clocks)-1])
    tally=0
    for left,right in zip(partitions[:-1],partitions[1:]):
        safe()
        times=clocks[left:right+1]
        rows=np.zeros((len(times),len(KEYS)))
        steps=c_longlong()
        need(library.propagate2(*args,state,times,len(times),SCHEMES['fine'][2],rows,byref(steps))==1,'dense observation bounded')
        start=int(left>0)
        need(np.array_equal(rows[start:],expected[left+start:right+1]),'all original readouts bit identical')
        tally+=steps.value
    need(np.array_equal(state,terminal) and library.count_readout()==tally==len(vector),'unchanged state and accepted step count')
    first=expected[0,[KEYS.index(key) for key in ('a','H','drag_rate_x','angular_rate_x')]]
    array=np.vstack([np.r_[clocks[0],first],vector])
    need(np.isfinite(array).all() and (np.diff(array[:,0])>0).all(),'continuous, finite accepted clocks')
    out=HERE/(case+'-fine-'+arm+'-observed.npz')
    with out.open('xb') as file:
        np.savez_compressed(file,values=array,names=['x','a','H','drag_rate_x','angular_rate_x'])
    save(out.with_suffix('.json'),dict(packet=digest(out),original=digest(late),steps=tally,original_rows=len(expected),
        source=digest(HERE/'observed.c'),include=digest(HERE/'dense_observer.inc'),library=digest(HERE/'observed.dll'),
        script=digest(HERE/'dense_readout.py'),method=digest(HERE/'DENSE-READOUT.md'),all_saved_readouts_identical=True,terminal_identical=True))


if __name__=='__main__':
    for arm in ('free','both'):
        run(sys.argv[1],arm)
