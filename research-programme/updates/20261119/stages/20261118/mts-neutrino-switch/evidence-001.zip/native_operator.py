from pathlib import Path
from fork import HERE, OLD, PRIOR, digest, need, np, read, safe, save
from bridge import inputs


def check(case):
    source=PRIOR/(case+'-physical-roots-capture.npz')
    with np.load(source) as pack:
        sig=pack['signature']
        state=pack['reference']
        derivative=pack['derivative_reference']/5
        x=5*pack['clock']
        aval=pack['packet'][:,1]
    with np.load(OLD/(case+'-quarter-raw.npz')) as old:
        mass=old['parameters'][4]
    grid=np.array([.583165,2.,4.,7.26582,13.])
    res={}
    for precision,qs in [('as_decimal',grid),('as_Fortran_real4',grid.astype(np.float32).astype(float))]:
        records=[]
        for iq,qq in enumerate(qs):
            keep=(sig[:,70]==0)&(sig[:,30]==5)&(sig[:,40]==16)&(sig[:,12]==1)
            rows=np.flatnonzero(keep)
            ix=sig[rows,50]-1+iq*17
            speed=1/np.hypot(1,aval[rows]*mass/qq)
            f1dot=speed*(state[rows,ix]-2*state[rows,ix+2])/3
            boundary=speed*state[rows,ix+15]-17*state[rows,ix+16]/x[rows]
            def compare(pred,answer):
                return dict(error_over_peak=max(abs(pred-answer))/max(abs(answer)),pass_count=int(sum(abs(pred-answer)<=2e-5*abs(answer))))
            records.append(dict(points=len(rows),momentum=compare(f1dot,derivative[rows,ix+1]),boundary=compare(boundary,derivative[rows,ix+16])))
        res[precision]=records
    return dict(capture=digest(source),independent_material_clock=float(x[0]),variants=res)


if __name__=='__main__':
    safe()
    src=OLD.parent/'mts-coupled-metric-consistency-20261117/native/fortran'
    earlier=OLD.parent/'mts-integrated-defect-20261112/native/fortran'
    native={name:digest(src/name) for name in ('equations.f90','camb_python.f90','massive_neutrinos.f90')}
    alternate={name:digest(earlier/name) for name in native}
    save(HERE/'native-operator.json',dict(script=digest(Path(__file__)),native_sources=native,input_audit_sources=alternate,cases={case:check(case) for case in ('cold','heavy')}))
