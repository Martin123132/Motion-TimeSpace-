import sys
from ctypes import CDLL
from pathlib import Path
import fork
from fork import HERE, KEYS, MODES, SCHEMES, bridge, digest, need, np, read, safe, save

SECTORS=['eta','cdm','baryons','photons','massless','massive','slow','heavy','homogeneous']
TRANSFER_KEYS=KEYS+['pressure_'+key for key in SECTORS]+['drive_'+key for key in SECTORS]+['source_zero']


def run(case,scheme,labels):
    xs,_,args,clock,hashes=fork.data(case,scheme)
    source=HERE/(case+'-'+scheme+'-fork.npz')
    meta=read(source.with_suffix('.json'))
    need(meta['packet']==digest(source) and meta['inputs']==hashes,'same verified prestage')
    with np.load(source) as packet:
        initial=packet['state']
    cap=SCHEMES[scheme][2]
    mode=SCHEMES[scheme][3]
    need((mode&1)==0,'Hamiltonian source decomposition')
    lib=CDLL(str(HERE/'transfer.dll')).propagate2
    lib.argtypes=bridge.SOLVE.argtypes
    lib.restype=bridge.SOLVE.restype
    fork.LIB=lib
    fork.KEYS=TRANSFER_KEYS
    for label in labels:
        path=HERE/(case+'-'+scheme+'-'+label+'-transfer.npz')
        base=HERE/(case+'-'+scheme+'-'+label+'.npz')
        with np.load(base) as packet:
            times=packet['x'].copy()
        need(times[0]==clock,'matched fork')
        state=np.r_[initial[:-2],np.zeros(16),initial[-2:],initial[-2:]]
        args2=(*args[:5],mode+MODES[label],*args[6:])
        obs,steps=fork.integrate(state,args2,times,cap)
        need(np.all(np.isfinite(obs)),'all sector responses finite')
        with path.open('xb') as file:
            np.savez_compressed(file,x=times,names=TRANSFER_KEYS,forecast=obs)
        save(path.with_suffix('.json'),dict(fork_sha=digest(source),base_sha=digest(base),packet=digest(path),
            script=digest(Path(__file__)),method=digest(HERE/'SOURCE-TRANSFER.md'),library=digest(HERE/'transfer.dll'),include=digest(HERE/'transfer.inc'),steps=steps))
        print(case,scheme,label,'sector transfer',steps,flush=True)


if __name__=='__main__':
    run(sys.argv[1],sys.argv[2],sys.argv[3:] or ['free','both'])
