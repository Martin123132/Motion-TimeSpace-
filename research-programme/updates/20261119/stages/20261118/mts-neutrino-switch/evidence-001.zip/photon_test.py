from ctypes import CDLL
from pathlib import Path
import sys
from fork import HERE,KEYS,bridge,data,digest,need,np,safe,save
from onset_test import solve


def run(case):
    _,_,args,clock,_=data(case,'main')
    fork=HERE/(case+'-main-fork.npz')
    with np.load(fork) as packet:
        common=packet['state']
        start=dict(zip(KEYS,packet['forecast'][-1]))
    fnu,fmass=args[6][2:4]
    fgamma=1-fnu-fmass
    gg=common[0]
    rate=start['opacity']/5
    inertia=.75*args[6][1]*gg*args[6][5]/fgamma
    relaxation=inertia/(rate*(1+inertia))
    tmin=2.**np.floor(np.log2(relaxation/128))
    times=np.r_[0.,tmin*2.**np.arange(5),relaxation/2,relaxation,2*relaxation]
    clocks=clock+times
    need(np.all(np.diff(clocks)>0) and tmin/128>10*np.spacing(clock),'resolved finite scattering clock')
    lib=CDLL(str(HERE/'photon.dll')).propagate2
    lib.argtypes=bridge.SOLVE.argtypes
    lib.restype=bridge.SOLVE.restype
    photo=18+(args[0]+1)*(args[1]+2)
    names=['shear','flux','cdm_velocity','physical_pressure','crossed_pressure']
    history={}
    detail={}
    predictions={}
    for source in ('neutrino','intensity','polarization'):
        angular=source!='neutrino'
        polarized=source=='polarization'
        order=int(polarized)
        strength=.6*rate if polarized else 1.
        frac=fgamma if angular else fnu
        factor=frac*strength/gg**2
        den=np.prod([1+order,2+order,3+order,4+order])
        pred=np.array([strength,-2*strength/(3*(1+order)),2*factor*(4+order)/den,
            2*factor*start['physical_velocity']**2/den,2*factor*start['archived_velocity']**2/den])
        predictions[source]=pred
        powers=order+np.array([0,1,3,4,4])
        runs={}
        for name,flag,ratio in [('trace',3,128),('constraint',2,128),('coarser',3,64)]+([('no_mixing',35,128)] if polarized else []):
            state=np.zeros_like(common)
            state[0]=gg
            for idx in range(args[3]):
                pos=10+4*idx
                state[pos:pos+2]=common[pos:pos+2]
            for idx in range(args[0]+1):
                pos=18+(idx+1)*(args[1]+2)-1
                state[pos]=common[pos]
            state[photo+int(polarized)*(args[2]-1) if angular else 20]=1.
            arguments=(*args[:5],flag,*args[6:])
            first=solve(lib,arguments,state,clocks[:6],tmin/ratio)
            tail=solve(lib,arguments,state,clocks[5:],relaxation/256)
            out=dict(zip(KEYS,np.vstack([first,tail[1:]])[1:].T))
            result=np.array([out['pi_photon'] if angular else out['massless_shear'],out['v_photon'] if angular else out['v_neutrino'],
                out['active_cdm_x'],out['mts_dp_s'],out['both_archive']]).T
            history[source+'_'+name]=result
            if name=='no_mixing':
                need(not np.any(result) and np.any(out['E_2']),'surviving polarization with no metric response when mixing is removed')
                continue
            rates=result/(pred*times[1:,None]**powers)
            runs[name]=((8*rates[0]-6*rates[1]+rates[2])/3,(8*rates[1]-6*rates[2]+rates[3])/3,rates[-2])
        val=runs['trace'][0]
        spread=abs(val-runs['trace'][1])+abs(val-runs['coarser'][0])+abs(val-runs['constraint'][0])
        detail[source]={key:dict(power=int(powers[idx]),predicted=pred[idx],intercept=val[idx],spread=spread[idx],
            at_one_relaxation_time=runs['trace'][2][idx],passes=bool(abs(val[idx]-1)+spread[idx]<=2e-5)) for idx,key in enumerate(names)}
    ind=names.index('physical_pressure')
    ratio=detail['intensity']['physical_pressure']['intercept']*predictions['intensity'][ind]/(detail['neutrino']['physical_pressure']['intercept']*predictions['neutrino'][ind])
    dest=HERE/(case+'-photon-probe.npz')
    with dest.open('xb') as stream:
        np.savez_compressed(stream,t=times[1:],names=names,**history)
    save(dest.with_suffix('.json'),dict(packet=digest(dest),inputs=digest(fork),script=digest(Path(__file__)),source=digest(HERE/'photon.c'),dll=digest(HERE/'photon.dll'),method=digest(HERE/'PHOTON-STRESS.md'),
         source_ratios=dict(predicted=fgamma/fnu,measured=ratio),thomson_per_x=rate,inertia=inertia,fast_time_x=relaxation,
         tmin=tmin,offdiagonal_null_exact=True,sources=detail,tolerance=2e-5))


if __name__=='__main__':
    safe()
    for case in sys.argv[1:]:
        run(case)
