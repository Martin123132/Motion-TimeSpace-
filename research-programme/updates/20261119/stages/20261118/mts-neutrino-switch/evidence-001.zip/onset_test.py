import sys
from ctypes import CDLL,byref,c_longlong
from pathlib import Path
from fork import HERE,KEYS,bridge,data,digest,need,np,read,safe,save
from scipy.interpolate import CubicSpline


def solve(lib,args,state,times,step):
    rows=np.zeros((len(times),len(KEYS)))
    counter=c_longlong()
    need(lib(*args,state,times,len(times),step,rows,byref(counter))==1 and np.isfinite(rows).all() and np.isfinite(state).all(),'local forced evolution')
    return rows


def extrapolate(rows,index):
    def at_zero(values):
        return (8*values[0]-6*values[1]+values[2])/3
    data=rows[:,index]
    return float(at_zero(data[:3])),float(at_zero(data[1:4]))


def run(case):
    safe()
    _,_,args,clock,hashes=data(case,'main')
    path=HERE/(case+'-main-fork.npz')
    with np.load(path) as packet:
        common=packet['state']
        initial=packet['forecast'][-1]
    d0=dict(zip(KEYS,initial))
    frac=args[6][2]
    gg=common[0]
    onset=-3*d0['massless_shear']/clock-d0['massless_density_x']-d0['massless_shear_x']
    factor=frac*onset/gg**2
    predictions=np.array([onset,-onset/3,onset/9,-factor/6,factor/6,factor/12,factor/60,
        d0['archived_velocity']**2*factor/60,d0['physical_velocity']**2*factor/60])
    powers=np.array([1,2,3,3,3,4,5,5,5])
    lib=CDLL(str(HERE/'onset.dll')).propagate2
    lib.argtypes=bridge.SOLVE.argtypes
    lib.restype=bridge.SOLVE.restype
    times=np.r_[0.,2.**np.arange(-11,-3),.125,.25,.5,1.,2.]
    split=np.searchsorted(times,.03125)
    saved={}
    checks={}
    for tag,spacing,step,flag,sign in [('main',1/256,2**-16,3,1),('fine',1/512,2**-17,3,1),
        ('constraint',1/512,2**-17,2,1),('zero',1/256,2**-16,3,0),('reverse',1/256,2**-16,3,-1)]:
        safe()
        nodes=clock+spacing*np.arange(1+round(times[-1]/spacing))
        args_free=(*args[:5],flag,*args[6:])
        origin=common.copy()
        origin[2]=d0['cdm_x']
        raw=solve(lib,args_free,origin,nodes,min(.001,spacing/2))
        source=-3*raw[:,46]/nodes-raw[:,49]-raw[:,48]
        need(abs(source[0]/onset-1)<1e-12,'independent forcing starts at derived jump')
        coeff=CubicSpline(nodes,sign*source).c.T
        extended=np.r_[args[-1],clock,spacing,len(coeff),coeff.ravel()]
        args_forced=(*args[:5],flag+4+16,*args[6:-1],extended)
        state=np.zeros_like(common)
        state[0]=gg
        for idx in range(args[3]):
            offset=10+idx*4
            state[offset:offset+2]=common[offset:offset+2]
        stride=args[1]+2
        for idx in range(args[0]+1):
            pos=18+idx*stride+stride-1
            state[pos]=common[pos]
        early=solve(lib,args_forced,state,clock+times[:split+1],step)
        tail=solve(lib,args_forced,state,clock+times[split:],min(.0005,spacing/2))
        result=np.vstack([early,tail[1:]])
        items=dict(zip(KEYS,result.T))
        values=np.array([items['massless_shear'],items['v_neutrino'],items['delta_neutrino']-4*items['delta_cdm']/3,
            items['etak']/5,1.5*frac*items['delta_neutrino']/(items['a']*5/args[6][0])**2,
            items['active_cdm_x'],items['delta_cdm'],items['both_archive'],items['mts_dp_s']]).T
        if sign==0:
            need(not np.any(values),'homogeneous background cannot create perturbations from zero')
        saved[tag]=values
        if sign!=0:
            ratios=values[1:]/(sign*predictions*times[1:,None]**powers)
            estimates=np.array([extrapolate(ratios,col) for col in range(len(powers))])
            checks[tag]=dict(first_estimate=estimates[:,0].tolist(),shifted_estimate=estimates[:,1].tolist(),first_finite_time=ratios[0].tolist(),
                maximum_extrapolation_change=max(abs(1-estimates[:,0]/estimates[:,1])))
    index=KEYS.index
    independently={}
    for label,flag in [('free',2),('fluid',6)]:
        full=solve(lib,(*args[:5],flag,*args[6:]),common.copy(),clock+times,.0005)
        independently[label]=dict(zip(KEYS,full.T))
    direct=independently['fluid']
    control=independently['free']
    resolution={}
    for col,key in [(0,'massless_shear'),(1,'v_neutrino'),(5,'active_cdm_x'),(6,'delta_cdm'),(7,'both_archive'),(8,'mts_dp_s')]:
        change=direct[key][-1]-control[key][-1]
        resolution[key]=dict(direct_change=change,forced_change=saved['constraint'][-1,col],relative=saved['constraint'][-1,col]/change-1,
            subtraction_condition=(abs(direct[key][-1])+abs(control[key][-1]))/abs(change))
    tags=['shear','flux','compensated_density','metric_eta','massless_half_density','cdm_velocity','cdm_contrast','crossed_slow_pressure','physical_slow_pressure']
    numerical=abs(np.array(checks['fine']['first_estimate'])-checks['main']['first_estimate'])+abs(np.array(checks['fine']['first_estimate'])-checks['constraint']['first_estimate'])+abs(np.array(checks['fine']['first_estimate'])-checks['fine']['shifted_estimate'])
    reverse=max(np.max(abs(saved['reverse'][1:]+saved['main'][1:])/np.maximum(abs(saved['main'][1:]),1e-280),axis=0))
    out=HERE/(case+'-direct-onset.npz')
    with out.open('xb') as file:
        np.savez_compressed(file,t=times,names=tags,powers=powers,coefficients=predictions,**saved)
    save(out.with_suffix('.json'),dict(trial=checks,zero_source_exact=True,reverse_fraction=reverse,comparison_at_t2=resolution,
        support={tag:dict(predicted=predictions[i],power=powers[i],intercept=checks['fine']['first_estimate'][i],numerical_spread=numerical[i],
            passes=bool(abs(checks['fine']['first_estimate'][i]-1)+numerical[i]<=2e-5)) for i,tag in enumerate(tags)},
        fork_sha=digest(path),forecast=digest(out),inputs=hashes,source=digest(HERE/'onset.c'),include=digest(HERE/'injection.inc'),driver=digest(Path(__file__)),method=digest(HERE/'ONSET-LAW.md')))


if __name__=='__main__':
    for case in sys.argv[1:]:
        run(case)
