from pathlib import Path
from fork import HERE,PRIOR,KEYS,digest,need,np,read,safe,save
from compare import TOL,preparation
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline,PchipInterpolator


SPLIT=['inherited_displacement','inherited_velocity','metric_drive','mass_and_expansion','background_forcing_velocity','stress_readout','native_replay','switched_replay']


def measure(case):
    config,_,splines,_=preparation(case)
    mass=config['masses'][0]
    source=HERE/(case+'-fine-both-late.npz')
    with np.load(source) as pack:
        all_times=pack['x'].copy()
        stop=int(np.flatnonzero(np.diff(all_times)>.025)[0])+1
        clocks=all_times[:stop]-all_times[0]
        switched=dict(zip(KEYS,pack['forecast'][:stop].T.copy()))
    slots=slice(1999,1999+stop)
    with np.load(config['ref']) as pack:
        wave=np.flatnonzero(pack['modes']==5)[0]
        native=dict(zip(pack['names'].tolist(),pack['values'][wave,slots].T.astype(float)))
        need(np.array_equal(5*pack['conformal_time'][slots],all_times[:stop]),'same comparison clocks')
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as capture:
        drive=capture['derivative_reference'][8:8+stop,1]/5
    def coefficients(curve,forcing):
        scale=curve['a']
        return np.array([np.square(scale*mass/5),2*curve['H']/5,forcing,splines[1](np.log(scale)),
                         np.square(scale*mass)*splines[0](np.log(scale))]).T
    raw=coefficients(native,drive)
    evolved=coefficients(switched,switched['active_cdm_x'])
    inputs=np.column_stack([raw,evolved-raw])
    start=np.array([native['mts_dphi_s'][0],native['mts_dphidot_s'][0]/5])
    initial=np.array([switched['shadow_dphi'][0],switched['shadow_dphidot'][0]/5])-start
    norm=max(abs(start))
    seed=np.zeros((6,2))
    seed[0]=start/norm
    seed[1,0]=initial[0]/norm
    seed[2,1]=initial[1]/norm
    truth=native['mts_dp_s']
    gap=switched['both_archive']-truth
    peak=max(abs(truth))
    arrays={}
    for variant,method,step in [('cubic',CubicSpline,.02),('small_step',CubicSpline,.01),('pchip',PchipInterpolator,.01)]:
        spline=method(clocks,inputs)
        def rhs(coord,values):
            alpha,drag,driving,velocity,_,da,dh,df,dv,_=spline(coord)
            fields=values.reshape(6,2)
            changes=fields[:,[1,0]].copy()
            changes[:,1]=-(1+alpha+da)*fields[:,0]-(drag+dh)*fields[:,1]
            changes[0,1]=-(1+alpha)*fields[0,0]-drag*fields[0,1]+driving*velocity/(5*norm)
            changes[3,1]+=df*velocity/(5*norm)
            changes[4,1]+=-da*fields[0,0]-dh*fields[0,1]
            changes[5,1]+=(driving+df)*dv/(5*norm)
            return changes.ravel()
        solution=solve_ivp(rhs,(0.,clocks[-1]),seed.ravel(),method='DOP853',rtol=3e-13,atol=2e-19,max_step=step,t_eval=clocks)
        need(solution.success and np.isfinite(solution.y).all(),'inhomogeneous propagator')
        fields=solution.y.reshape(6,2,-1)*norm
        parts=5*evolved[:,3]*fields[1:,1]-evolved[:,4]*fields[1:,0]
        readout=5*inputs[:,8]*fields[0,1]-inputs[:,9]*fields[0,0]
        replay=5*raw[:,3]*fields[0,1]-raw[:,4]*fields[0,0]-truth
        reconstruction=parts.sum(axis=0)+readout+replay
        arrays[variant]=np.vstack([parts,readout,replay,gap-reconstruction])
    with np.load(HERE/(case+'-pressure-terms.npz')) as terms:
        misses=np.r_[False,terms['missed'][:stop-1]]
    records={}
    for label,selection in [('new_rows',clocks>0),('pressure_misses',misses)]:
        indices=np.flatnonzero(selection)
        if not len(indices):
            records[label]=dict(count=0)
            continue
        terms=arrays['small_step'][:,indices]
        g=gap[indices]
        sensitivities=abs(terms-arrays['cubic'][:,indices])+abs(terms-arrays['pchip'][:,indices])
        error=np.sum(sensitivities,axis=0)+abs(terms[-1])+abs(terms[-2])
        scores=np.argmax(abs(terms),axis=0)
        records[label]=dict(count=len(indices),first_epoch=1999+indices[0],dominant_component_counts=dict(zip(SPLIT,np.bincount(scores,minlength=8).tolist())),
            first_signed_shares=dict(zip(SPLIT,(terms[:,0]/g[0]).tolist())),max_interpolation_and_replay_over_gap=max(error/abs(g)),
            max_interpolation_and_replay_over_pressure=max(error/abs(truth[indices])),max_interpolation_and_replay_over_peak=max(error)/peak,
            pass_on_discrepancy_scale=int(sum(error<=TOL*abs(g))),pass_on_pressure_scale=int(sum(error<=TOL*abs(truth[indices]))),
            dominance_robust_to_error=int(sum(np.sort(abs(terms),axis=0)[-1]-np.sort(abs(terms),axis=0)[-2]>2*error)))
    out=HERE/(case+'-velocity-memory.npz')
    with out.open('xb') as stream:
        np.savez_compressed(stream,clock=clocks,terms=SPLIT,archive=truth,gap=gap,pressure_misses=misses,**arrays)
    save(out.with_suffix('.json'),dict(packet=digest(out),source=digest(source),script=digest(Path(__file__)),method=digest(HERE/'VELOCITY-MEMORY.md'),
        first_epoch=1999,last_epoch=1998+stop,largest_step=max(np.diff(clocks)),next_unresolved_interval=all_times[stop]-all_times[stop-1],tolerance=TOL,scores=records))


if __name__=='__main__':
    safe()
    for case in ('cold','heavy'):
        measure(case)
