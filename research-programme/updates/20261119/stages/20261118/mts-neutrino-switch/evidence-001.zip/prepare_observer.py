from fork import HERE,digest,need,safe


if __name__=='__main__':
    safe()
    path=HERE/'switch.c'
    source=path.read_text()
    header,body=source.split('#undef propagate')
    marker='coord+=step;(*steps)++;'
    need(body.count(marker)==1,'instrument only the accepted step')
    readout='double observer[OBS]; Local observer_local; if(!evaluate(&model,coord,state,NULL,&observer_local,observer) || !append_readout(coord,observer)){status=-9;goto finish;}'
    with (HERE/'observed.c').open('x') as output:
        output.write(header+'#undef propagate\n#include "dense_observer.inc"\n'+body.replace(marker,marker+readout))
