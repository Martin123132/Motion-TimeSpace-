from pathlib import Path
from fork import HERE, OLD, PRIOR, MODES, KEYS, digest, need, np, read, safe, save
from compare import TOL, integral, preparation
from scipy.interpolate import CubicSpline

CHANNELS=['both_archive','mts_dp_s','shadow_dphi','shadow_dphidot','delta_neutrino','v_neutrino','massless_shear','delta_nu','active_cdm_x','geometry_shear','etak','delta_cdm','delta_baryon','pi_photon','slip','drag_rate_x','angular_rate_x']
TARGETS={'both_archive':'mts_dp_s','shadow_dphi':'mts_dphi_s','shadow_dphidot':'mts_dphidot_s','active_cdm_x':'cdm_x'}


def readrun(case,scheme,label):
    path=HERE/(case+'-'+scheme+'-'+label+'.npz')
    meta=read(path.with_suffix('.json'))
    need(meta['packet']==digest(path) and meta['method']==digest(HERE/'METHOD.md'),'frozen result identity')
    with np.load(path) as stored:
        need(stored['names'].tolist()==KEYS,'operator readout')
        result=dict(zip(KEYS,stored['forecast'].T.copy()))
        result['x']=stored['x'].copy()
    return result


def archive(case):
    _,native,_,_=preparation(case)
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as ref:
        sig=ref['signature'][:9]
        state=ref['reference'][:9]
        ix=sig[:,4]-1
        d=ref['derivative_reference'][:9]
        native['massless_shear']=state[np.arange(9),ix+2]
        native['geometry_shear']=-native['cdm_x']+3*d[:,0]/25
        check=-native['H']*native['v_newtonian_cdm']/5
        need(max(abs(native['geometry_shear']/check-1))<TOL,'independent native shear readout')
    return native


def local_law(case,scheme):
    free=readrun(case,scheme,'free')
    fluid=readrun(case,scheme,'fluid')
    need(np.array_equal(free['x'],fluid['x']) and free['x'][0]==52,'same switch clock')
    for key in KEYS:
        if key!='massless_shear_x':
            need(free[key][0]==fluid[key][0],'continuous switch readout '+key)
    base={key:free[key][0] for key in KEYS}
    speed=(2*base['v_neutrino']-3*base['inactive_or_active_octupole'])/5+8*base['geometry_shear']/15
    closed=-3*base['massless_shear']/52-(4*base['active_cdm_x']/3-base['v_neutrino'])
    jump=closed-speed
    need(abs((fluid['massless_shear_x'][0]-free['massless_shear_x'][0])/jump-1)<1e-12,'rate jump')
    delta=free['x']-52
    records=[]
    for index in np.flatnonzero((delta>0)&(delta<=.129)):
        step=delta[index]
        diff={key:(fluid[key][index]-free[key][index]) for key in ('massless_shear','v_neutrino','delta_neutrino','delta_cdm')}
        records.append(dict(elapsed=step,shear_first=diff['massless_shear']/step,
            flux_second=2*diff['v_neutrino']/step**2,metric_free_third=6*(diff['delta_neutrino']-4*diff['delta_cdm']/3)/step**3))
    return dict(jump=jump,predicted_flux_curvature=-2*jump/3,predicted_compensated_third=2*jump/3,small_clocks=records)


def collect(case,scheme,labels):
    native=archive(case)
    bounds=np.log(read(OLD/'transport-budget.json')['common_scale_bounds'])
    result={}
    for label in labels:
        data=readrun(case,scheme,label)
        ix=np.searchsorted(data['x'],native['x'])
        need(np.array_equal(data['x'][ix],native['x']),'all original late epochs')
        fields={key:data[key][ix] for key in CHANNELS+(['mts_dp_h'] if case=='heavy' else [])}
        integrals={key:integral({k:data[k][ix] for k in ('a','H',key)},key,bounds)[0] for key in ('drag_rate_x','angular_rate_x')}
        result[label]=(fields,integrals)
    return native,result


def experiment(case,scheme,labels):
    native,variants=collect(case,scheme,labels)
    out={}
    for key in variants['free'][0]:
        truth=native[TARGETS.get(key,key)]
        fractions={label:fields[key]/truth-1 for label,(fields,_) in variants.items()}
        panel={label:dict(event_error=error[0],max_error=max(abs(error)),nominal_passes=int(sum(abs(error)<=TOL)),nine_errors=error.tolist()) for label,error in fractions.items()}
        parts={}
        if set(labels)==set(MODES):
            values={label:row[0][key] for label,row in variants.items()}
            raw=values['free']
            massless=values['fluid']-raw
            massive=values['mass16']-raw
            interaction=values['both']-raw-massless-massive
            need(max(abs((massless+massive+interaction)-(values['both']-raw)))/max(abs(truth))<1e-13,'factorial arithmetic')
            parts=dict(massless_over_native=(massless/truth).tolist(),massive_over_native=(massive/truth).tolist(),interaction_over_native=(interaction/truth).tolist(),
                event_fraction_of_free_gap=dict(massless=massless[0]/(truth[0]-raw[0]),massive=massive[0]/(truth[0]-raw[0]),interaction=interaction[0]/(truth[0]-raw[0]),remaining=(truth[0]-values['both'][0])/(truth[0]-raw[0])))
        out[key]=dict(panel=panel,effects=parts)
    return dict(channels=out,integrals={label:vals[1] for label,vals in variants.items()})


if __name__=='__main__':
    import sys
    safe()
    scheme=sys.argv[1]
    labels=sys.argv[2:] or list(MODES)
    save(HERE/(scheme+'-comparison.json'),dict(script=digest(Path(__file__)),method=digest(HERE/'METHOD.md'),tolerance=TOL,
         cases={case:experiment(case,scheme,labels) for case in ('cold','heavy')},switch_law={case:local_law(case,scheme) for case in ('cold','heavy')} if 'fluid' in labels else {}))
