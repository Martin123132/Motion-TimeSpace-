from pathlib import Path
from fork import HERE,digest,need,np,read,safe,save
from compare import TOL
from science import archive,readrun
from transfer_run import SECTORS


def summarize(case,scheme,labels):
    native=archive(case)
    truth=native['mts_dp_s']
    values={}
    branch={}
    for label in labels:
        source=HERE/(case+'-'+scheme+'-'+label+'-transfer.npz')
        meta=read(source.with_suffix('.json'))
        need(meta['packet']==digest(source) and meta['method']==digest(HERE/'SOURCE-TRANSFER.md'),'passive transfer provenance')
        reference=readrun(case,scheme,label)
        with np.load(source) as pack:
            fields=dict(zip(pack['names'].tolist(),pack['forecast'].T.copy()))
            x=pack['x']
        ix=np.searchsorted(x,native['x'])
        need(np.array_equal(x,reference['x']) and np.array_equal(x[ix],native['x']),'same saved trajectory epochs')
        terms=np.array([fields['pressure_'+key] for key in SECTORS]).T
        sources=np.array([fields['drive_'+key] for key in SECTORS]).T
        values[label]=(terms[ix],reference['both_archive'][ix],fields['both_archive'][ix])
        branch[label]=dict(absolute_closure_over_reference_pressure=max(abs((terms[ix].sum(1)-fields['both_archive'][ix])/truth)),
            drive_sum_over_cdm_peak=max(abs(sources.sum(1)-fields['active_cdm_x']))/max(abs(fields['active_cdm_x'])),
            independent_solver_difference=max(abs((fields['both_archive'][ix]-reference['both_archive'][ix])/truth)))
    changes={}
    for label in labels:
        if label=='free':
            continue
        term=values[label][0]-values['free'][0]
        jump=values[label][1]-values['free'][1]
        inner=values[label][2]-values['free'][2]
        changes[label]=dict(pressure_jump_over_native=(jump/truth).tolist(),event_fraction_of_jump=dict(zip(SECTORS,(term[0]/jump[0]).tolist())),
            per_epoch_contributions_over_native={key:(term[:,idx]/truth).tolist() for idx,key in enumerate(SECTORS)},
            maximum_term_cancellation_factor=max(np.sum(abs(term),axis=1)/abs(jump)),
            internal_sum_error_over_jump=max(abs((np.sum(term,axis=1)-inner)/jump)),
            independent_sum_error_over_jump=max(abs((np.sum(term,axis=1)-jump)/jump)))
    return dict(branches=branch,changes=changes)


if __name__=='__main__':
    import sys
    safe()
    scheme=sys.argv[1]
    labels=sys.argv[2:] or ['free','fluid','mass16','both']
    save(HERE/(scheme+'-sector-response.json'),dict(script=digest(Path(__file__)),tolerance=TOL,cases={case:summarize(case,scheme,labels) for case in ('cold','heavy')}))
