from pathlib import Path
from fork import HERE,PRIOR,KEYS,bridge,digest,need,np,read,safe,save
from compare import TOL


def crossings(xs,vals):
    left=np.flatnonzero(vals[:-1]*vals[1:]<0)
    return [(int(idx),float(xs[idx]-(xs[idx+1]-xs[idx])*vals[idx]/(vals[idx+1]-vals[idx]))) for idx in left]


def case_score(case):
    tags=('main','fine','highq','angular','trace')
    model={}
    ids=None
    for tag in tags:
        model[tag]={}
        for arm in ('free','both'):
            path=HERE/(case+'-'+tag+'-'+arm+'-late.npz')
            meta=read(path.with_suffix('.json'))
            need(meta['packet']==digest(path) and meta['method']==digest(HERE/'CONTINUATION.md'),'untouched continuation')
            with np.load(path) as packet:
                clocks=packet['x'][1:]
                model[tag][arm]=dict(zip(KEYS,packet['forecast'][1:].T.copy()))
            these=np.arange(meta['first_row']+1,meta['last_row']+1)
            need(ids is None or np.array_equal(these,ids),'common continuation extent')
            ids=these
    with np.load(bridge.inputs(case)['ref']) as packet:
        idx=np.flatnonzero(packet['modes']==5)[0]
        native=dict(zip(packet['names'].tolist(),packet['values'][idx,ids].T.copy()))
        need(np.array_equal(5*packet['conformal_time'][ids],clocks),'no duplicated earlier row')
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as pack:
        pos=ids-1991
        native['active_cdm_x']=pack['derivative_reference'][pos,1]/5
        native['geometry_shear']=-native['active_cdm_x']+3*pack['derivative_reference'][pos,0]/25
    fields=['both_archive','mts_dp_s','delta_neutrino','delta_nu','active_cdm_x','geometry_shear','mts_dp_h'] if case=='heavy' else ['both_archive','mts_dp_s','delta_neutrino','delta_nu','active_cdm_x','geometry_shear']
    metrics={}
    for arm in ('free','both'):
        channels={}
        for key in fields:
            actual=native['mts_dp_s' if key=='both_archive' else key]
            pred=model['fine'][arm][key]
            unc=sum(abs(model['main'][arm][key]-model[tag][arm][key]) for tag in tags[1:])
            err=abs(pred-actual)
            peak=max(abs(actual))
            passed=err+unc<=TOL*abs(actual)
            nonzero=actual!=0
            low=abs(actual)<1e-3*peak
            first=np.flatnonzero(~passed)
            ref_roots=crossings(clocks,actual)
            pred_roots=crossings(clocks,pred)
            channels[key]=dict(passed=int(sum(passed)),epochs=len(ids),first_failure=int(ids[first[0]]) if len(first) else None,
                final_native=actual[-1],final_prediction=pred[-1],final_fraction=pred[-1]/actual[-1]-1 if actual[-1] else None,
                error_over_peak=max(err)/peak,budget_over_peak=max(unc)/peak,worst_fraction_over_nonzero=max(err[nonzero]/abs(actual[nonzero])),
                peak_scale_passes=int(sum(err+unc<=TOL*peak)),small_target_rows=int(sum(low)),small_target_failures=int(sum(low & ~passed)),
                native_sign_changes=len(ref_roots),predicted_sign_changes=len(pred_roots),
                max_linear_crossing_shift_x=max(abs(a[1]-b[1]) for a,b in zip(ref_roots,pred_roots)) if len(ref_roots)==len(pred_roots) and ref_roots else None)
        metrics[arm]=channels
    return dict(start=int(ids[0]),end=int(ids[-1]),tau_range=[clocks[0]/5,clocks[-1]/5],channels=metrics)


if __name__=='__main__':
    safe()
    save(HERE/'late-comparison.json',dict(tolerance=TOL,source=digest(Path(__file__)),method=digest(HERE/'CONTINUATION.md'),
         cases={case:case_score(case) for case in ('cold','heavy')}))
