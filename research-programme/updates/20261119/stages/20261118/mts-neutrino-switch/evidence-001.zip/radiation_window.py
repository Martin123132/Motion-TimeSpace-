from pathlib import Path
import math
from fork import HERE,PRIOR,bridge,digest,need,np,read,safe,save
from compare import TOL
from scipy.interpolate import CubicSpline,PchipInterpolator


RATES=('drag','angular')
SCHEMES=('main','fine','highq','angular','trace')
CASES=('cold','heavy')


def physical(case,scheme,arm):
    path=HERE/f'{case}-{scheme}-{arm}-late.npz'
    receipt=read(path.with_suffix('.json'))
    need(digest(path)==receipt['packet'] and receipt['last_row']==4252,'complete trajectory')
    with np.load(path) as data:
        fields=dict(zip(data['names'].tolist(),data['forecast'].T.copy()))
    return {key:fields[key] for key in ('a','H','cell_drag','cell_angular','angular_rate_x','drag_rate_x')}


def original(case):
    path=PRIOR/(case+'-physical-roots-capture.npz')
    with np.load(path) as packet:
        slots=packet['signature'][8:]
        state=packet['reference'][8:]
        roots=packet['packet'][8:]
        need(np.all(slots[:,[3,5,6,7]]==slots[0,[3,5,6,7]]) and len(state)==2254,'native radiation layout')
        intensity,polar,limit,polar_limit=map(int,slots[0,[3,5,6,7]])
        need(limit==polar_limit and limit>=3,'untruncated native angular sum')
        pi=state[:,intensity+1]
        electric=state[:,polar+1]
        collision=(15/16)*(.75*pi**2+2.4*(electric-.25*pi)**2)
        weight=6*15/16
        for ell in range(3,limit+1):
            prev=ell-1
            weight*=((prev+3)*(prev-1)/((prev+1)*(2*prev+1)))/(ell/(2*ell+1))
            collision+=3*(2*ell+1)/16*state[:,intensity+ell-1]**2+weight*state[:,polar+ell-1]**2
        slip=state[:,3]-.75*state[:,intensity]
        rate=roots[:,174]/5
        result=dict(a=roots[:,1].copy(),H=roots[:,2].copy(),angular_rate_x=rate*collision,drag_rate_x=rate*slip**2)
        times=packet['clock'][8:].copy()
    with np.load(bridge.inputs(case)['ref']) as data:
        names=data['names'].tolist()
        values=data['values'][np.flatnonzero(data['modes']==5)[0],1999:4253]
        need(np.array_equal(times,data['conformal_time'][1999:4253]) and
             all(np.max(abs(entry-values[:,names.index(key)]))/max(abs(entry))<TOL for key,entry in
                 [('pi_photon',pi),('E_2',electric),('a',result['a']),('H',result['H'])]),'independent archive component identities')
    return result


def integrals(row,key,bounds):
    axis=np.log(row['a'])
    rate=5*row[key+'_rate_x']/row['H']
    lower,upper=bounds
    need(axis[0]<lower<upper<axis[-1] and (np.diff(axis)>0).all() and (rate>=0).all(),'supported positive physical rates')
    records={label:float(interpolator(axis,rate).integrate(lower,upper)) for label,interpolator in [('pchip',PchipInterpolator),('cubic',CubicSpline)]}
    inner=axis[(axis>lower)&(axis<upper)]
    knots=np.r_[lower,inner,upper]
    records['linear']=float(np.trapezoid(np.interp(knots,axis,rate),knots))
    for offset in (0,1):
        which=np.unique(np.r_[0,np.arange(1+offset,len(axis)-1,2),len(axis)-1])
        records['alternate'+str(offset)]=float(PchipInterpolator(axis[which],rate[which]).integrate(lower,upper))
    if 'cell_'+key in row:
        cells=row['cell_'+key]
        need((cells[1:]>=0).all(),'positive evolved cell energies')
        left,right=np.searchsorted(axis,[lower,upper],side='right')-1
        need(left<right,'resolved interior')
        def edge(idx,point,hermite):
            width=axis[idx+1]-axis[idx]
            fraction=(point-axis[idx])/width
            total=cells[idx+1]
            if not hermite:
                return total*fraction
            return total*fraction**2*(3-2*fraction)+width*fraction*(1-fraction)*((1-fraction)*rate[idx]-fraction*rate[idx+1])
        for name,hermite in [('cell',True),('cell_linear_edge',False)]:
            records[name]=float(math.fsum(cells[left+1:right+1])-edge(left,lower,hermite)+edge(right,upper,hermite))
    return records


def run():
    safe()
    rows={case:{'native':original(case),**{scheme+'_'+arm:physical(case,scheme,arm) for scheme in SCHEMES for arm in ('free','both')}} for case in CASES}
    allrows=[result for group in rows.values() for result in group.values()]
    bounds=(max(np.log(item['a'][1]) for item in allrows),min(np.log(item['a'][-2]) for item in allrows))
    detail={}
    for key in RATES:
        measures={case:{tag:integrals(row,key,bounds) for tag,row in group.items()} for case,group in rows.items()}
        native={case:measures[case]['native']['pchip'] for case in CASES}
        nspread=sum(max(abs(value-native[case]) for value in measures[case]['native'].values()) for case in CASES)
        native_delta=native['heavy']-native['cold']
        outcomes={}
        for arm in ('free','both'):
            estimates={}
            budgets={}
            for case in CASES:
                scans={tag:measures[case][tag+'_'+arm] for tag in SCHEMES}
                fine=scans['fine']
                estimates[case]=fine['cell']
                budgets[case]=sum(abs(scans[tag]['cell']-scans['main']['cell']) for tag in SCHEMES[1:])+max(abs(fine[method]-fine['cell']) for method in ('pchip','cell_linear_edge'))
            delta=estimates['heavy']-estimates['cold']
            budget=sum(budgets.values())
            paired=sum(abs((measures['heavy'][tag+'_'+arm]['cell']-measures['cold'][tag+'_'+arm]['cell'])-
                           (measures['heavy']['main_'+arm]['cell']-measures['cold']['main_'+arm]['cell'])) for tag in SCHEMES[1:])
            outcomes[arm]=dict(integrals=estimates,contrast=delta,contrast_over_baseline=delta/estimates['cold'],branch_spreads=budgets,
                spread_over_contrast=budget/abs(delta),paired_solver_component=paired,internally_resolved=bool(budget<=TOL*abs(delta)),
                native_fraction=delta/native_delta-1,native_agreement=bool(abs(delta-native_delta)+budget+nspread<=TOL*abs(native_delta)))
        detail[key]=dict(native_integrals=native,native_contrast=native_delta,native_sampling_spread_over_contrast=nspread/abs(native_delta),runs=outcomes,raw=measures)
    save(HERE/'late-radiation.json',dict(method=digest(HERE/'RADIATION-WINDOW.md'),source=digest(Path(__file__)),tolerance=TOL,scale_bounds=np.exp(bounds).tolist(),channels=detail))


if __name__=='__main__':
    run()
