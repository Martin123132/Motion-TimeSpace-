from native_forest import ROOT,GROW,SPEC,PRIOR,np,digest
from scipy.interpolate import PchipInterpolator,CubicSpline
import csv,json

def read(path):
    return json.loads(path.read_text())
def table(path):
    with path.open(encoding="utf-8-sig",newline="") as handle:
        return list(csv.DictReader(handle))
def write_table(path,rows):
    with path.open("w",newline="",encoding="utf8") as out:
        writer=csv.DictWriter(out,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
def array(path):
    with np.load(path) as data:
        return dict(data)
def saved_power(branch):
    if branch=="lcdm":
        path=SPEC/"results/spectrum/lcdm.npz"
        assert digest(path)==read(SPEC/"results/stage-integrity.json")["file_hashes"]["results/spectrum/lcdm.npz"]
        data=array(path)
        good=data["pressure_qualified_band"]
        return data["modes"][good],data["linear_power_Mpc3"][good,-1]
    hashes=read(GROW/"closeout.json")["files"]
    bg_path=SPEC/"runs"/branch/"background.npz"
    assert digest(bg_path)==read(GROW/"integral-lock.json")["inputs"][str(bg_path)]
    bg=array(bg_path)
    modes=[]
    amplitudes=[]
    for path in sorted((GROW/"full-grid").glob(f"stock-{branch}-live-chunk-*.npz")):
        assert digest(path)==hashes["full-grid/"+path.name]["sha256"]
        data=array(path)
        assert data["scales"][-1]==1.
        values=dict(zip(data["names"],data["values"][:,-1,:].T))
        actual=values["a"]
        mass=sum(bg[name][-1] for name in ("cdm","baryon","nu"))
        source=sum(bg[name][-1]*values["delta_"+name] for name in ("cdm","baryon","nu"))
        if branch=="heavy":
            from native_forest import PROJECT
            with np.load(PROJECT) as parent:
                mass=mass+float(parent["matching_density"])*actual
            source+=actual**2*values["mts_drho_h"]
        amplitudes.extend(source/mass)
        modes.extend(data["modes"])
    modes=np.array(modes)
    assert modes.size==399 and modes[-1]==5 and np.all(np.diff(modes)>0)
    return modes,2*np.pi**2/modes**3*2.1e-9*(modes/.05)**(-.0347)*np.array(amplitudes)**2
def templates(kh):
    release=ROOT/"release"
    output=[]
    for filename,count,flat in [("ABG_only_grid.dat",109,False),("ABD_only_grid_sept2020.dat",83,True),("ABG_thermalWDM_only_grid.dat",8,False)]:
        coeff=np.loadtxt(release/filename)
        assert coeff.shape==(count,3)
        for alpha,beta,third in coeff:
            mode=1+(alpha*kh)**beta
            output.append((1-third)*mode**(-1.5*beta)+third if flat else mode**third)
    output.append(np.ones_like(kh))
    result=np.array(output)
    assert result.shape==(201,len(kh)) and result.min()>=0 and result.max()<=1+1e-14
    return result

def calculate():
    dirs=ROOT/"release"
    assert all(digest(dirs/key)==entry["sha256"] for key,entry in read(ROOT/"release.json").items())
    locked=read(PRIOR/"closeout.json")["files"]
    targets=PRIOR/"matter-scale-targets.csv"
    assert digest(targets)==locked[targets.name]
    obs_path=GROW/"all-observables.csv"
    assert digest(obs_path)==read(GROW/"closeout.json")["files"][obs_path.name]["sha256"]
    rows=table(obs_path)
    old=table(targets)
    archive={};report={};red_rows=[]
    for branch in ("lcdm","cold","heavy"):
        pack=array(ROOT/f"native-{branch}.npz")
        modes=pack["k"];red=pack["z"];pivot=float(pack["pivot"])
        dense=array(ROOT/"pivot-sourced-heavy.npz") if branch=="heavy" else pack
        z3=np.flatnonzero(red==3)[0]
        offsets=np.log(dense["k"]/pivot)
        logpower=np.log(dense["P"][:,z3])
        slopes=[]
        for step in (.02,.01,.005):
            left,right=[np.argmin(abs(offsets-edge)) for edge in (-step,step)]
            assert max(abs(offsets[left]+step),abs(offsets[right]-step))<1e-12
            slopes.append(float((logpower[right]-logpower[left])/(offsets[right]-offsets[left])))
        derivative=(4*slopes[2]-slopes[1])/3
        coarse=abs(np.log(modes/pivot))>.021
        cs=CubicSpline(np.log(modes[coarse]),np.log(pack["P"][coarse,z3]))
        spline_deriv=float(cs.derivative()(np.log(pivot)))
        fit=np.polynomial.Polynomial.fit(offsets[abs(offsets)<.021],logpower[abs(offsets)<.021],3).deriv()(0)
        sigma=next(float(row["sigma8_m"]) for row in rows if row["case"]==branch and row["variant"]==("old" if branch=="lcdm" else "live") and float(row["z"])==0)
        grid,base=saved_power(branch)
        anchor=np.array([np.argmin(abs(grid-mode)) for mode in modes])
        exact=abs(grid[anchor]/modes-1)<1e-10
        overlap=float(abs(pack["P"][exact,-1]/base[anchor[exact]]-1).max())
        target_dif=[]
        for row in old:
            if row["branch"]!=branch or float(row["z"]) not in red:
                continue
            index=np.argmin(abs(modes-float(row["k_comoving_Mpc_inverse"])))
            epoch=np.flatnonzero(red==float(row["z"]))[0]
            assert abs(modes[index]-float(row["k_comoving_Mpc_inverse"]))<2e-10
            target_dif.append(abs(pack["Pcl"][index,epoch]/float(row["P_matter_linear_Mpc3"])-1))
        near_bounds=(min(derivative,fit,spline_deriv,*slopes),max(derivative,fit,spline_deriv,*slopes))
        report[branch]=dict(pivot_Mpc_inverse=pivot,slope=float(derivative),centered_slopes=slopes,independent_coarse_spline=spline_deriv,
                            local_cubic=float(fit),slope_range=list(near_bounds),sigma8=sigma,reion=float(pack["params_reion"]),
                            slope_gate=bool(near_bounds[0]>=-2.6 and near_bounds[1]<=-2),sigma_gate=.5<=sigma<=1.5,
                            H0=float(pack["H"][-1]),z0_archive_max_fraction=overlap,prior_clustered_max_fraction=float(max(target_dif)),
                            n_shared=len(target_dif),direct_pivot_power_Mpc3=float(np.exp(logpower[np.argmin(abs(offsets))])))
        assert max(target_dif)<2e-5 and overlap<2e-5,(branch,max(target_dif),overlap)
        archive[branch]=base
        if branch=="lcdm":
            gridref=grid
        else:
            np.testing.assert_array_equal(grid,gridref)
        for epoch,zval in enumerate(red):
            for knot in (.3,1.,1.98095677855,5.):
                index=np.argmin(abs(modes-knot))
                assert abs(modes[index]-knot)<2e-10
                red_rows.append(dict(branch=branch,z=zval,k=modes[index],k_v=modes[index]*(1+zval)/pack["H"][epoch],P_total=pack["P"][index,epoch]))
    h=report["heavy"]["H0"]/100
    positive=(grid/h>=.01)&(grid<=5.)
    grid=grid[positive]
    hydro=templates(grid/h)
    lower,upper=hydro.min(axis=0)**2,hydro.max(axis=0)**2
    hull={};tab=[]
    for branch,ref in [("heavy","cold"),("heavy","lcdm"),("cold","lcdm"),("lcdm","lcdm"),("cold","cold")]:
        actual=(archive[branch]/archive[ref])[positive]
        deficit=np.maximum.reduce([lower-actual,actual-upper,np.zeros_like(actual)])
        worst=int(deficit.argmax())
        key=f"{branch}/{ref}"
        hull[key]=dict(lower_bound_on_max_sq_transfer_error=float(deficit[worst]),k_Mpc_inverse=float(grid[worst]),k_h_Mpc=float(grid[worst]/h),
                       power_ratio=float(actual[worst]),min_simulated=float(lower[worst]),max_simulated=float(upper[worst]),
                       control_identity=bool(np.all(actual==1)),n_outside_010=int((deficit>.1).sum()),
                       limiting_row=int(np.argmin(hydro[:,worst])))
        for index,mode in enumerate(grid):
            tab.append(dict(branch=branch,reference=ref,k_Mpc_inverse=mode,k_h_Mpc=mode/h,P_ratio=actual[index],grid_min_squared=lower[index],
                            grid_max_squared=upper[index],unavoidable_error=deficit[index]))
    assert hull["cold/cold"]["lower_bound_on_max_sq_transfer_error"]==hull["lcdm/lcdm"]["lower_bound_on_max_sq_transfer_error"]==0
    refpower={(row["z"],round(row["k"],8)):row["P_total"] for row in red_rows if row["branch"]=="cold"}
    for row in red_rows:
        row["ratio_to_cold"]=row["P_total"]/refpower[row["z"],round(row["k"],8)]
    write_table(ROOT/"hull.csv",tab)
    write_table(ROOT/"evolution.csv",red_rows)
    result=dict(branches=report,hulls=hull,protocol_sha=digest(ROOT/"PROTOCOL.md"),full_abgd_high_k_available=False)
    (ROOT/"domain.json").write_text(json.dumps(result,indent=2,allow_nan=False))
    print(json.dumps(result,indent=1))
if __name__=="__main__":
    calculate()

