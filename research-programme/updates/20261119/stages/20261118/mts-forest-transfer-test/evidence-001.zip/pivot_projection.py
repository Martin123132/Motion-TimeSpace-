from native_forest import ROOT,SPEC,MATCH,ORIGIN,PROJECT,np,sys,psutil
sys.path.insert(0,str(SPEC))
from project_grid import projection
import matching_common as source

def extend():
    prior=np.load(ROOT/"native-heavy.npz")
    pivot=float(prior["pivot"])
    parent=np.load(PROJECT)
    knots=parent["modes"]
    left=np.searchsorted(knots,pivot)
    anchors=knots[left-1:left+1]
    new=pivot*np.exp(np.array([-.02,-.01,-.005,0.,.005,.01,.02]))
    modes=np.sort(np.r_[anchors,new])
    original=ORIGIN/"native-two-field-transfer-20261007/runs"
    params=source.params_for(original/"backgrounds/heavy.npz")
    engine=source.camb.get_background(params)
    scale=np.load(original/"final-bg8-start/heavy.npz")["requested_scale"]
    eta=engine.conformal_time(1/scale-1,tol=1e-10)
    engine.Params.Accuracy.IntTolBoost=6
    names=["a","mts_drho_h","mts_q_h","mts_dp_h","H","mts_match_count"]
    values=engine.get_time_evolution(modes,eta,vars=names,lAccuracyBoost=4)
    assert not np.any(values[:,:,-1]) and np.isfinite(values).all()
    raw=dict(modes=modes,names=np.array(names),values=values)
    projected=projection(raw,parent,float(parent["matching_scale"]),float(parent["matching_density"]),6,8)
    errors={}
    for component in ("delta","momentum"):
        check=projected[component][np.searchsorted(modes,anchors)]/parent["matching_"+component][np.searchsorted(knots,anchors)]-1
        errors[component]=abs(check).max()
        assert errors[component]<2e-5,(component,errors)
    assert projected["closure_error"].max()<2e-5
    params=source.params_for(PROJECT)
    params.DarkEnergy.set_table("SetMatching",modes,projected["delta"],projected["momentum"])
    params.DoLateRadTruncation=False
    late=source.camb.get_background(params)
    late.Params.Accuracy.IntTolBoost=6
    late_names=["a","delta_cdm","delta_baryon","delta_nu","mts_drho_h","mts_match_count","mts_nonheavy_change"]
    red=prior["z"]
    late_values=late.get_time_evolution(modes,late.conformal_time(red,tol=1e-10),vars=late_names,lAccuracyBoost=4)
    assert np.all(late_values[:,:,-2]==1) and not np.any(late_values[:,:,-1]) and np.isfinite(late_values).all()
    bg=late.get_background_densities(1/(1+red),vars=["cdm","baryon","nu"])
    actual=late_values[:,:,0]
    num=sum(bg[name]*late_values[:,:,index] for index,name in [(1,"cdm"),(2,"baryon"),(3,"nu")])+actual**2*late_values[:,:,4]
    denom=sum(bg.values())+float(parent["matching_density"])*actual
    power=(num/denom)**2*(2*np.pi**2/modes**3*2.1e-9*(modes/.05)**(-.0347))[:,None]
    replay=abs(power[np.searchsorted(modes,anchors)]/prior["P"][np.searchsorted(prior["k"],anchors)]-1).max()
    assert replay<2e-5
    with (ROOT/"pivot-sourced-heavy.npz").open("xb") as out:
        np.savez_compressed(out,k=modes,z=red,P=power,k_added=new,anchor_k=anchors,anchor_replay=replay,
                            phase_delta=projected["delta"],phase_momentum=projected["momentum"],closure=projected["closure_error"],
                            delta_replay=errors["delta"],momentum_replay=errors["momentum"],raw=values,raw_names=names)
    print("seven independently prepared pivot modes",replay,errors,flush=True)
if __name__=="__main__":
    proc=psutil.Process()
    proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([proc.cpu_affinity()[0]])
    extend()

