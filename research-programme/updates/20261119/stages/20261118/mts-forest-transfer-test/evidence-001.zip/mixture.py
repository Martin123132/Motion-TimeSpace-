from transfer import ROOT,read,table,templates,np,json
from scipy.optimize import linprog,OptimizeWarning
import warnings
warnings.filterwarnings("ignore",category=OptimizeWarning,message="Unrecognized options.*")

def bound(grid,ratio,h,tol):
    response=templates(grid/h).T
    count=response.shape[1]
    upper=np.sqrt(ratio+tol)
    lower=np.sqrt(np.maximum(ratio-tol,0))
    matrix=np.vstack([response,-response])
    rhs=np.r_[upper,-lower]
    lp=linprog(np.r_[np.zeros(count),1.],A_ub=np.c_[matrix,-np.ones(len(rhs))],b_ub=rhs,
        A_eq=[np.r_[np.ones(count),0.]],b_eq=[1.],method="highs",options={"threads":1})
    assert lp.success
    weights=np.maximum(lp.x[:-1],0)
    weights/=weights.sum()
    actual=np.max(abs((response@weights)**2-ratio))
    multipliers=np.maximum(-lp.ineqlin.marginals,0)
    dual=(multipliers@matrix).min()-multipliers@rhs
    return dict(error=float(actual),dual_margin=float(dual),w=weights,y=multipliers)
def solve():
    data=table(ROOT/"hull.csv")
    output={}
    for branch,ref in [("heavy","cold"),("heavy","lcdm"),("cold","lcdm"),("lcdm","lcdm")]:
        chosen=[row for row in data if row["branch"]==branch and row["reference"]==ref]
        grid=np.array([float(row["k_Mpc_inverse"]) for row in chosen])
        ratio=np.array([float(row["P_ratio"]) for row in chosen])
        h=read(ROOT/"domain.json")["branches"]["heavy"]["H0"]/100
        target=bound(grid,ratio,h,.10)
        low,high=0.,1.
        witness=None
        best=bound(grid,ratio,h,high)
        for iteration in range(19):
            mid=(low+high)/2
            trial=bound(grid,ratio,h,mid)
            if trial["dual_margin"]>1e-9:
                low=mid
                witness=trial
            else:
                high=mid
                best=trial
        assert best["error"]<high+1e-6
        name=branch+"_"+ref
        if np.all(ratio==1):
            low=0.
            witness=None
            best["w"][:]=0.
            best["w"][-1]=1.
            best["error"]=0.
        if witness:
            assert witness["dual_margin"]>1e-9
        count=len(grid)
        output[name]=dict(lower=low,upper=best["error"],margin_at_010=target["dual_margin"],
                          upper_at_010=target["error"],coverage="overlap only",weights=[[int(index),float(value)] for index,value in enumerate(best["w"]) if value>0],
                          witness_at_lower=[] if witness is None else [[int(index%count),1 if index<count else -1,float(value)] for index,value in enumerate(witness["y"]) if value>0],
                          witness_lower_margin=0 if witness is None else witness["dual_margin"])
        print(name,low,best["error"],target["dual_margin"])
    (ROOT/"mixtures.json").write_text(json.dumps(output,indent=2,allow_nan=False))
if __name__=="__main__":
    solve()

