from transfer import ROOT,PRIOR,GROW,SPEC,read,table,digest,np,json
from native_forest import PROJECT,MATCH,COLD,ORIGIN
from flux import load_release
from pathlib import Path
import math,sys

def verify():
    checks={}
    def check(name,test):
        assert test,name
        checks[name]=True
    old=digest(PRIOR/"closeout.json")
    check("prior sealed",old=="ba3eaecb81c83b3905c5c8f23a2488a4cfc7b13909492e63549fa56c0699ff0b")
    domain=read(ROOT/"domain.json");flux=read(ROOT/"flux-controls.json")
    check("same pre-score protocol",digest(ROOT/"PROTOCOL.md")==domain["protocol_sha"])
    check("no heavy score",flux["heavy_score"] is None and not flux["profiled"])
    check("native slope gates",[v["slope_gate"] for v in domain["branches"].values()]==[True,True,False])
    check("sigma8 all in calibration",all(v["sigma_gate"] for v in domain["branches"].values()))
    for branch,scores in domain["branches"].items():
        check("same prior epochs and overlap "+branch,scores["n_shared"]==40 and max(scores["prior_clustered_max_fraction"],scores["z0_archive_max_fraction"])<2e-5)
        check("derivative stability "+branch,abs(scores["slope"]-scores["local_cubic"])<2e-5)
    release=read(ROOT/"release.json")
    check("pinned upstream tree",len(release)==17 and all(digest(ROOT/"release"/key)==row["sha256"] for key,row in release.items()))
    grids=[np.loadtxt(ROOT/"release"/name) for name in ["ABG_only_grid.dat","ABD_only_grid_sept2020.dat","ABG_thermalWDM_only_grid.dat"]]
    def sky(mode):
        values=[]
        for group,grid in enumerate(grids):
            for alpha,beta,third in grid:
                natural=math.log1p((alpha*mode)**beta)
                response=third+(1-third)*math.exp(-1.5*beta*natural) if group==1 else math.exp(third*natural)
                values.append(response)
        return np.array(values+[1.])
    hull=table(ROOT/"hull.csv")
    for name,saved in read(ROOT/"mixtures.json").items():
        branch,ref=name.split("_")
        rows=[row for row in hull if row["branch"]==branch and row["reference"]==ref]
        template=np.array([sky(float(row["k_h_Mpc"])) for row in rows])
        weights=np.zeros(201)
        for index,value in saved["weights"]:
            weights[index]=value
        truth=np.array([float(row["P_ratio"]) for row in rows])
        check("positive mixture "+name,abs(weights.sum()-1)<1e-12 and np.min(weights)>=0)
        check("attained upper bound "+name,abs(np.max(abs((template@weights)**2-truth))-saved["upper"])<2e-12)
        check("tight bracket "+name,-1e-10<=saved["upper"]-saved["lower"]<3e-6)
        if saved["lower"]>0:
            certificate=np.zeros(201)
            for index,sign,weight in saved["witness_at_lower"]:
                assert weight>=0
                edge=math.sqrt(max(0,truth[index]+sign*saved["lower"]))
                certificate+=sign*weight*(template[index]-edge)
            check("infeasible below bound "+name,certificate.min()>0 and abs(certificate.min()-saved["witness_lower_margin"])<1e-12)
    power=table(ROOT/"flux-controls.csv")
    for key,control in flux["control_scores"].items():
        rows=[row for row in power if row["control"]==key]
        value=0.
        for name,code,size in [("HIRES","H",28),("MIKE","M",21)]:
            use=[row for row in rows if row["instrument"]==name]
            residual=np.array([float(row["flux_power_observed"])-float(row["flux_power_model"]) for row in use])
            covariance=np.linalg.inv(load_release("cov_"+code+"_inverted"))
            score=np.linalg.norm(np.linalg.solve(np.linalg.cholesky(covariance),residual))**2
            check("data ordering and whitening "+key+" "+code,len(use)==size and abs(score-control[name])<1e-9)
            value+=score
        check("joint "+key,abs(value-control["chi2"])<1e-9)
    check("reference astro replay",flux["reference_recovery_max_fraction"]<2e-5)
    check("fallback caveat",not flux["control_scores"]["lcdm_code_defaults"]["gas"]["gamma_inside_scaling_range"])
    with np.load(ROOT/"pivot-sourced-heavy.npz") as data:
        check("independent phase projection",len(data["k_added"])==7 and len(data["anchor_k"])==2 and max(data["anchor_replay"],data["closure"].max(),data["delta_replay"],data["momentum_replay"])<2e-5)
    components=table(ROOT/"slope-components.csv")
    check("signed species identity",len(components)==33 and max(float(row["derivative_discretization"]) for row in components)<2e-5)
    for branch in ("heavy","cold"):
        result=next(row for row in components if row["branch"]==branch and float(row["z"])==3)
        check("independent late evolution "+branch,abs(float(result["n_eff"])-domain["branches"][branch]["slope"])<2e-5)
    controls=read(GROW/"closeout.json")["files"]
    source_lock=read(GROW/"integral-lock.json")["inputs"]
    archive_lock=read(SPEC/"results/stage-integrity.json")["file_hashes"]
    priorfiles=read(PRIOR/"closeout.json")["files"]
    consumed={PRIOR/"closeout.json":old,PRIOR/"matter-scale-targets.csv":priorfiles["matter-scale-targets.csv"],GROW/"all-observables.csv":controls["all-observables.csv"]["sha256"]}
    for key in ["results/spectrum/lcdm.npz","runs/projection/a225-w6-d8.npz","runs/heavy/background.npz","runs/cold/background.npz","project_grid.py","spectrum_common.py"]:
        consumed[SPEC/key]=archive_lock[key]
    for branch in ("cold","heavy"):
        for path in sorted((GROW/"full-grid").glob(f"stock-{branch}-live-chunk-*.npz")):
            consumed[path]=controls["full-grid/"+path.name]["sha256"]
    input_lock=read(GROW/"input-lock.json")["inputs"]
    dll=MATCH/"native/camb/cambdll.dll"
    consumed[dll]=input_lock[str(dll)]
    for key in (COLD,ORIGIN/"native-two-field-transfer-20261007/runs/final-bg8-start/heavy.npz",ORIGIN/"native-two-field-transfer-20261007/runs/backgrounds/heavy.npz",MATCH/"matching_common.py",MATCH/"stage_common.py"):
        consumed[key]=digest(key)
    check("saved read dependencies",all(digest(path)==value for path,value in consumed.items()))
    files={path.relative_to(ROOT).as_posix():digest(path) for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name!="closeout.json"}
    receipt=dict(previous=old,checks=checks,files=files,input_hashes={str(key):value for key,value in consumed.items()})
    dest=ROOT/"closeout.json"
    if dest.exists():
        check_same=read(dest)==receipt
        assert check_same,"sealed files changed"
    elif "--seal" in sys.argv:
        with dest.open("x",encoding="utf8") as output:
            json.dump(receipt,output,indent=2,allow_nan=False)
    print(len(checks),"checks;",len(consumed),"input fingerprints;",len(files),"local files",digest(dest) if dest.exists() else "not sealed")
if __name__=="__main__":
    verify()

