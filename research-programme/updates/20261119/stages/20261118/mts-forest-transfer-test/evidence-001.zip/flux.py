from transfer import ROOT,read,np,json,digest,write_table
from scipy.linalg import block_diag
import pickle
import numpy._core.multiarray as multiarray

class ReleaseArrays(pickle.Unpickler):
    def find_class(self,module,name):
        symbols={("numpy.core.multiarray","_reconstruct"):multiarray._reconstruct,
                 ("numpy","ndarray"):np.ndarray,("numpy","dtype"):np.dtype}
        return symbols[module,name]

def load_release(name):
    path=ROOT/"release"/(name+".pkl")
    assert digest(path)==read(ROOT/"release.json")[path.name]["sha256"]
    with path.open("rb") as stream:
        result=ReleaseArrays(stream,encoding="bytes").load()
        assert stream.read()==b""
    assert type(result)==np.ndarray and result.dtype.kind=="f"
    return result

Z=np.array([4.2,4.6,5.,5.4])
KVEL=[.00501187,.00794328,.0125893,.0199526,.0316228,.0501187,.0794328]
TREF=np.array([9227.31,8270.68,7890.68,7959.4])
TLOW=.1*np.array([6029.94,5501.17,5343.59,5423.34])
THIGH=1.4*np.array([12581.2,11164.9,10479.4,10462.6])
GREF=np.array([1.46909,1.48025,1.50814,1.52578])
GLOW=.8*np.array([.877893,.8884,.937664,.970259])
GHIGH=1.15*GREF
FREF=np.array([.364155,.253828,.146033,.0712724])
FRANGE=np.array([.545471,.439262,.315261,.204999])-np.array([.218493,.146675,.0676442,.0247793])
def hydro(meta,astro,grid,fiducial=False,gamma_sign=1):
    assert meta["slope_gate"] and meta["sigma_gate"]
    if fiducial:
        mean,temp,slope=FREF,TREF,GREF
    else:
        mean=np.array([.35,.26,.18,.07])
        temp=7400*((1+Z)/5.5)**(-4.38)
        slope=1.45*((1+Z)/5.5)**(gamma_sign*1.93)
    result=[];near=[]
    for index in range(len(Z)):
        column=6+index
        chosen=[0,1,2,3,4+column,14+column,24+column]
        target=np.array([np.clip(meta["reion"],7,15)/8,meta["sigma8"],meta["slope"]/.6,0.,
                         mean[index]/FRANGE[index],temp[index]/(THIGH-TLOW)[index],slope[index]/(GHIGH-GLOW)[index]])
        distance=np.linalg.norm(grid[:,chosen]-target,axis=1)
        weights=(distance+1e-8)**-6
        weights/=weights.sum()
        result.append(astro[index]@weights)
        near.append(float(distance.min()))
    return np.array(result),near,dict(temperature_K=temp.tolist(),gamma=slope.tolist(),mean_flux=mean.tolist(),temperature_inside_scaling_range=bool(np.all((temp>=TLOW)&(temp<=THIGH))),gamma_inside_scaling_range=bool(np.all((slope>=GLOW)&(slope<=GHIGH))))
def run():
    obs=[load_release("y_H_reshaped"),load_release("y_M_reshaped")]
    precision=[load_release("cov_H_inverted"),load_release("cov_M_inverted")]
    data=np.concatenate(obs)
    assert [part.shape for part in obs]==[(28,),(21,)]
    joint=block_diag(*precision)
    assert np.isfinite(joint).all() and np.isfinite(data).all() and np.all(data>0)
    asym=float(np.linalg.norm(joint-joint.T,np.inf)/np.linalg.norm(joint,np.inf))
    assert asym<1e-10
    symmetric=(joint+joint.T)/2
    chol=np.linalg.cholesky(symmetric)
    sigma=np.sqrt(np.diag(np.linalg.inv(symmetric)))
    ref=load_release("PF_noPRACE")[7:,19:]
    lcdm=load_release("full_matrix_interpolated_LCDM")[7:,19:,0]
    astro=load_release("full_matrix_interpolated_ASTRO")[7:,19:,:]
    grid=np.loadtxt(ROOT/"release/kriging_GRID_2R_astro_18p_HR_noPRACE.dat",skiprows=1)
    assert ref.shape==lcdm.shape==(4,7) and astro.shape==(4,7,1513) and grid.shape==(1513,34)
    assert np.isfinite(astro).all() and np.allclose(lcdm,1,rtol=0,atol=1e-12)
    meta=read(ROOT/"domain.json")["branches"]
    cases={"released_reference":None,"released_ref_astro_replay":("ref",True,1),
           "lcdm_fiducial_gas":("lcdm",True,1),"cold_conditional_fiducial_gas":("cold",True,1),
           "lcdm_code_defaults":("lcdm",False,1),"cold_conditional_code_defaults":("cold",False,1),
           "lcdm_example_param":("lcdm",False,-1),"cold_conditional_example_param":("cold",False,-1)}
    assert not(meta["heavy"]["slope_gate"] and meta["heavy"]["sigma_gate"])
    results={};bins=[];refdeviation=None
    for case,args in cases.items():
        near=thermal=None
        if args is None:
            flux=ref*lcdm
        else:
            key,fid,sign=args
            model=dict(reion=9.,sigma8=.829,slope=-2.3074,slope_gate=True,sigma_gate=True) if key=="ref" else meta[key]
            correction,near,thermal=hydro(model,astro,grid,fid,sign)
            flux=ref*np.maximum(lcdm+correction-1,0)
            if key=="ref":
                refdeviation=float(abs(flux/ref-1).max())
        assert flux.shape==(4,7) and np.isfinite(flux).all() and np.all(flux>0)
        model=np.r_[flux.ravel(),flux[:3].ravel()]
        residual=data-model
        raw=float(residual@joint@residual)
        white=float(np.linalg.norm(chol.T@residual)**2)
        block=[float(piece@mat@piece) for piece,mat in zip(np.split(residual,[28]),precision)]
        assert abs(raw-white)<1e-9 and abs(sum(block)-white)<1e-9
        results[case]=dict(chi2=raw,HIRES=block[0],MIKE=block[1],whitened=white,nearest_scaled_astro_distance=near,gas=thermal)
        for row in range(49):
            channel="HIRES" if row<28 else "MIKE"
            index=row if row<28 else row-28
            bins.append(dict(control=case,instrument=channel,z=Z[index//7],k_velocity_s_per_km=KVEL[index%7],
                             flux_power_observed=data[row],marginal_error=sigma[row],flux_power_model=model[row]))
    assert refdeviation<2e-5
    write_table(ROOT/"flux-controls.csv",bins)
    report=dict(obs_count=49,eigenvalue_min=float(np.linalg.eigvalsh(symmetric).min()),precision_asymmetry=asym,
                reference_recovery_max_fraction=refdeviation,control_scores=results,heavy_score=None,profiled=False)
    (ROOT/"flux-controls.json").write_text(json.dumps(report,indent=2,allow_nan=False))
    print([(key,res["chi2"]) for key,res in results.items()],"fiducial replay",refdeviation)
if __name__=="__main__":
    run()

