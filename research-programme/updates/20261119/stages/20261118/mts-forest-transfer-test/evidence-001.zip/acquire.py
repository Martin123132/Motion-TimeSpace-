from pathlib import Path
import hashlib
import json
import urllib.request

ROOT = Path(__file__).resolve().parent
PIN = "5b365b093982099b926a0c0c169697c9dc6cbbc4"
REPO = "brinckmann/montepython_public"
DIR = "montepython/likelihoods/Lya_abgd/"
FILES = ["ABG_only_grid.dat","ABD_only_grid_sept2020.dat","ABG_thermalWDM_only_grid.dat","full_matrix_interpolated_ASTRO.pkl","full_matrix_interpolated_ABG_only.pkl","full_matrix_interpolated_ABD_only_sept2020.pkl","full_matrix_interpolated_thermalWDM_only.pkl","full_matrix_interpolated_LCDM.pkl","kriging_GRID_2R_astro_18p_HR_noPRACE.dat","y_M_reshaped.pkl","y_H_reshaped.pkl","cov_M_inverted.pkl","cov_H_inverted.pkl","PF_noPRACE.pkl"]

def obtain():
    dest = ROOT / "release"
    dest.mkdir(exist_ok=True)
    api = f"https://api.github.com/repos/{REPO}/git/trees/{PIN}?recursive=1"
    with urllib.request.urlopen(api,timeout=30) as response:
        tree = json.load(response)
    assert tree["sha"] == PIN and not tree["truncated"]
    lookup = {row["path"]:row for row in tree["tree"]}
    records = {}
    for name in [DIR+"__init__.py",DIR+"Lya_abgd.data","input/base2018TTTEEE_lya_abgd.param"]+["data/Lya_grid/"+entry for entry in FILES]:
        record = lookup[name]
        url = f"https://raw.githubusercontent.com/{REPO}/{PIN}/{name}"
        local = dest / ("upstream.txt" if name.endswith("__init__.py") else Path(name).name)
        size = record["size"]
        assert 0 < size < 13000000
        if local.exists():
            data = local.read_bytes()
        else:
            with urllib.request.urlopen(url,timeout=45) as response:
                data = response.read(size+1)
        assert len(data) == size and hashlib.sha1(b"blob "+str(size).encode()+b"\0"+data).hexdigest() == record["sha"]
        if not local.exists():
            with local.open("xb") as stream:
                stream.write(data)
        records[local.name] = dict(url=url,bytes=size,git_blob=record["sha"],sha256=hashlib.sha256(data).hexdigest())
    outfile=ROOT/"release.json"
    result=json.dumps(records,indent=2)
    if outfile.exists():
        assert outfile.read_text()==result
    else:
        outfile.write_text(result)
    print(len(records),sum(row["bytes"] for row in records.values()),"bytes verified")

if __name__ == "__main__":
    obtain()

