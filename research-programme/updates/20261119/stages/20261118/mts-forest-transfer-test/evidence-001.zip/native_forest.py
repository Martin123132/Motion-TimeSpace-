import hashlib
import os
from pathlib import Path
import sys
import json
for variable in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
import numpy as np
import psutil

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
ORIGIN=POST/"condensate-origin-20261003"
SPEC=ORIGIN/"resolved-matter-spectrum-20261007"
MATCH=ORIGIN/"native-heavy-matching-20261007"
PRIOR=POST/"mts-absolute-matter-preparation-20261118"
GROW=POST/"mts-growth-mode-native-20261118"
PROJECT=SPEC/"runs/projection/a225-w6-d8.npz"
COLD=ORIGIN/"native-two-field-transfer-20261007/runs/backgrounds/cold.npz"
def digest(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle,"sha256").hexdigest()

def run(branch):
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (POST,ROOT))
    assert digest(PRIOR/"closeout.json")=="ba3eaecb81c83b3905c5c8f23a2488a4cfc7b13909492e63549fa56c0699ff0b"
    dll=MATCH/"native/camb/cambdll.dll"
    assert digest(dll)==json.loads((GROW/"input-lock.json").read_text())["inputs"][str(dll)]
    sys.path.insert(0,str(MATCH))
    import matching_common as source
    params=source.params_for(PROJECT if branch=="heavy" else COLD)
    if branch=="lcdm":
        params.DarkEnergy=source.camb.dark_energy.DarkEnergyFluid()
    params.DoLateRadTruncation=False
    engine=source.camb.get_background(params)
    engine.Params.Accuracy.IntTolBoost=6
    red=np.array([99.,8.,5.4,5.,4.6,4.2,3.,0.])
    scale=1/(1+red)
    hubble=engine.hubble_parameter(red)
    pivot=.009*hubble[-2]/4
    with np.load(PROJECT) as data:
        all_modes=data["modes"]
        anchors=[all_modes[np.argmin(abs(all_modes-target))] for target in (.075,.1,.125,.2,.25,.3,1.,2.,5.)]
        nodes=np.unique(np.r_[all_modes[(all_modes>.50)&(all_modes<1.05)],anchors])
        if branch!="heavy":
            nodes=np.unique(np.r_[nodes,pivot*np.exp(np.array([-.02,-.01,-.005,0,.005,.01,.02]))])
        abundance=float(data["matching_density"])
    assert nodes.min()>=all_modes.min() and nodes.max()<=5
    names=["a","delta_cdm","delta_baryon","delta_nu","mts_drho_h","H","v_newtonian_cdm","mts_match_count","mts_nonheavy_change"]
    values=engine.get_time_evolution(nodes,engine.conformal_time(red,tol=1e-10),vars=names,lAccuracyBoost=4)
    assert np.isfinite(values).all() and np.all(values[:,:,-2]==(branch=="heavy")) and not np.any(values[:,:,-1])
    measured=values[:,:,0]
    assert np.max(abs(measured/scale-1))<2e-5
    bg=engine.get_background_densities(scale,vars=["cdm","baryon","nu"])
    density=bg["cdm"]+bg["baryon"]
    source_density=bg["cdm"]*values[:,:,1]+bg["baryon"]*values[:,:,2]
    if branch=="heavy":
        density=density+abundance*measured
        source_density=source_density+measured**2*values[:,:,4]
    total=(source_density+bg["nu"]*values[:,:,3])/(density+bg["nu"])
    clustered=source_density/density+3*(values[:,:,5]/nodes[:,None])**2*values[:,:,6]
    primordial=2*np.pi**2/nodes**3*2.1e-9*(nodes/.05)**(-.0347)
    outfile=ROOT/f"native-{branch}.npz"
    with outfile.open("xb") as output:
        np.savez_compressed(output,k=nodes,z=red,H=hubble,total=total,clustered=clustered,
                            P=primordial[:,None]*total**2,Pcl=primordial[:,None]*clustered**2,
                            pivot=pivot,params_reion=engine.Params.Reion.get_zre(params),h=params.H0/100,
                            origin=digest(PROJECT if branch=="heavy" else COLD),dll=digest(dll))
    print(branch,len(nodes),pivot,flush=True)
if __name__=="__main__":
    proc=psutil.Process()
    proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([proc.cpu_affinity()[0]])
    for branch in sys.argv[1:] or ("lcdm","cold","heavy"):
        run(branch)

