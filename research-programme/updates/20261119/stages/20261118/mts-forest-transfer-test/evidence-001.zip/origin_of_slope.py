from native_forest import ROOT,SPEC,MATCH,PROJECT,COLD,np,psutil,sys
from transfer import write_table
import json

def components(branch,modes,red):
    import matching_common as source
    params=source.params_for(PROJECT if branch=="heavy" else COLD)
    if branch=="heavy":
        with np.load(ROOT/"pivot-sourced-heavy.npz") as projected:
            params.DarkEnergy.set_table("SetMatching",projected["k"],projected["phase_delta"],projected["phase_momentum"])
    if branch=="lcdm":
        params.DarkEnergy=source.camb.dark_energy.DarkEnergyFluid()
    params.DoLateRadTruncation=False
    engine=source.camb.get_background(params)
    engine.Params.Accuracy.IntTolBoost=6
    scale=1/(1+red)
    times=engine.conformal_time(red,tol=1e-10)
    names=["a","delta_cdm","delta_baryon","delta_nu","mts_drho_h","mts_match_count","mts_nonheavy_change"]
    values=engine.get_time_evolution(modes,times,vars=names,lAccuracyBoost=4)
    assert np.all(values[:,:,5]==(branch=="heavy")) and not np.any(values[:,:,6])
    actual=values[:,:,0]
    assert np.max(abs(actual/scale-1))<2e-5
    bg=engine.get_background_densities(scale,vars=["cdm","baryon","nu"])
    ordinary=sum(bg.values())
    parts=np.stack([bg[name]*values[:,:,index] for index,name in [(1,"cdm"),(2,"baryon"),(3,"nu")]]+[np.zeros_like(actual)])
    with np.load(PROJECT) as src:
        mh=float(src["heavy_mass_mpc"]);rhom=float(src["matching_density"])
    if branch=="heavy":
        parts[3]=actual**2*values[:,:,4]
        ordinary=ordinary[None,:]+rhom*actual
    parts/=ordinary
    return parts,np.broadcast_to(ordinary,actual.shape).copy(),mh

def run():
    sys.path.insert(0,str(MATCH))
    with np.load(ROOT/"pivot-sourced-heavy.npz") as prepared:
        modes=prepared["k_added"]
    pivot=modes[3]
    red=np.array([3999.,1100.,99.,49.,8.,5.4,5.,4.6,4.2,3.,0.])
    rows=[];combined={};packets={}
    for branch in ("heavy","cold","lcdm"):
        parts,totalbg,mass=components(branch,modes,red)
        total=parts.sum(axis=0)
        assert np.all(total>0)
        def derivative(values):
            return (values[...,1,:]-8*values[...,2,:]+8*values[...,4,:]-values[...,5,:])/.06
        contrib=2*derivative(parts)/total[3]
        direct=2*derivative(np.log(total))-.0347-3.
        summed=contrib.sum(axis=0)-3.0347
        observed=abs(direct-summed)
        scale=1/(1+red)
        jeans=(2*totalbg[3]*mass**2)**.25
        cs2=(pivot/(scale*mass)/(np.hypot(1.,pivot/(scale*mass))+1))**2
        restoring=pivot**2*cs2/(totalbg[3]/(2*scale**2))
        predicted=(pivot/jeans)**4
        if branch=="heavy":
            assert np.max(abs(restoring/predicted-1))<.001
        for index,epoch in enumerate(red):
            entry=dict(branch=branch,z=epoch,k_Mpc_inverse=pivot,total_delta=total[3,index],n_eff=direct[index],
                       species_sum_slope=summed[index],derivative_discretization=observed[index],
                       k_Jeans_matter_Mpc_inverse=jeans[index] if branch=="heavy" else None,
                       pressure_to_matter_gravity_coeff=restoring[index] if branch=="heavy" else None)
            for pos,key in enumerate(("cdm","baryon","massive_nu","heavy")):
                entry["Dpart_"+key]=parts[pos,3,index]
                entry["slope_"+key]=contrib[pos,index]
            rows.append(entry)
        combined[branch]=(total[3],direct)
        packets["parts_"+branch]=parts
    history=[]
    for index,zval in enumerate(red):
        ratio=(combined["heavy"][0][index]/combined["cold"][0][index])**2
        ds=combined["heavy"][1][index]-combined["cold"][1][index]
        history.append(dict(z=zval,ratio=ratio,excess_slope=ds))
    at99=next(row for row in history if row["z"]==99.)
    for row in history:
        row["ratio_relative_to_z99"]=row["ratio"]/at99["ratio"]
        row["slope_change_since_z99"]=row["excess_slope"]-at99["excess_slope"]
    with (ROOT/"slope-components.npz").open("xb") as out:
        np.savez_compressed(out,k=modes,z=red,**packets)
    write_table(ROOT/"slope-components.csv",rows)
    write_table(ROOT/"slope-history.csv",history)
    print("z=3",history[-2],rows[9])
if __name__=="__main__":
    proc=psutil.Process()
    proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([proc.cpu_affinity()[0]])
    run()

