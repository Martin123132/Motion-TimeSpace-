from susceptibility import HERE,PRE,LOCK,digest,COEFFICIENT,np,json,check_parent,WEIGHTS
import csv
from scipy.interpolate import make_interp_spline

TOL=2e-5
CLOCKS=(3.,4.,5.,6.,6.4)


def load(path):
    with np.load(path,allow_pickle=False) as data:return {key:data[key] for key in data.files}


def prior(name):
    assert digest(PRE/name)==json.loads((PRE/"closeout.json").read_text())["files"][name]
    return load(PRE/name)


def burst(dx,amp,tag):
    return prior(f"source-{tag}-dx{dx:g}-eta0.8-h{amp:g}.npz")


def levels(dx):
    return load(HERE/f"tangent-minus-d{dx:g}-to6.4.npz")


def peak(x):return float(np.max(abs(x)))


def error(test,reference):
    scale=peak(reference)
    if scale==0:return 0. if not np.any(test) else float("inf")
    return peak(test-reference)/scale


def table(name,rows):
    with (HERE/name).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def coords(data):
    return data[:,[1,2,3,4,5,6,8,9,10,11,12,13]]


def integrated(clock,sources):
    primitive=make_interp_spline(clock,sources,k=5,axis=0).antiderivative(2)
    return primitive(clock)-primitive(0)-clock[:,None]*primitive.derivative()(0)


def predict(dx):
    tangent=levels(dx);clock=tangent["clock"];base,odd,even=tangent["history"].transpose(1,0,2)
    refs=[coords(burst(dx,0.,tag)["rows"]) for tag in ("first","second","minus")]
    uno,due,minus=refs
    assert np.array_equal(clock,burst(dx,0.,"minus")["rows"][:,0])
    assert not np.any(odd[:,:12])
    design=np.stack([uno[:,2],due[:,2]],axis=-1)
    fit=design[[150,200]]
    coeff=np.linalg.solve(fit,-even[[150,200],2])
    cross=(uno+COEFFICIENT**2*due-minus)/(2*COEFFICIENT)
    adjust=2*(coeff[0]*(uno-COEFFICIENT*cross)+coeff[1]*(cross-COEFFICIENT*due))
    adjust[:,2:5]=coeff[0]*uno[:,2:5]+coeff[1]*due[:,2:5]
    adjust[:,5]=0.
    matched=even[:,:12]+adjust
    return dict(dx=dx,clock=clock,base=base[:,:12],ordinary=minus,scalar_wave=odd[:,-1],fixed=even[:,:12],
                adjust=adjust,matched=matched,weights=coeff,calibration=fit,seed=tangent["seed"])


def freeze():
    path=HERE/"predictions.npz"
    if path.exists() or list(HERE.glob("finite-*.npz")) or list(HERE.glob("paired-*.npz")):raise RuntimeError("freeze out of sequence")
    check_parent();coarse=predict(.025);fine=predict(.0125)
    rows=[]
    for model in (coarse,fine):
        for branch in ("fixed","matched"):
            data=model[branch];terms=integrated(model["clock"],data[:,6:12])
            for t in CLOCKS:
                pos=round(t/.02)
                rows.append(dict(dx=model["dx"],branch=branch,tau=t,L2=data[pos,0],metric2=data[pos,1],B2=data[pos,2],
                   ordinary_volume=model["base"][pos,0],direct_scalar=terms[pos,2],induced_shear=terms[pos,0],rest=sum(terms[pos,[1,3,4,5]]),
                   focusing_balance=error(terms.sum(axis=1),data[:,0]),determinant_check=error(data[:,1],data[:,0]),
                   refinement=error(coarse[branch][:,0],fine[branch][:,0]),ordinary_replay=error(model["base"][:,0],model["ordinary"][:,0])))
    for branch in ("fixed","matched"):
        for key in ("focusing_balance","determinant_check","refinement","ordinary_replay"):
            row=next(item for item in rows if item["dx"]==.0125 and item["branch"]==branch)
            if row[key]>=TOL:raise ArithmeticError((branch,key,row[key]))
    table("predicted-history-summary.csv",rows)
    with path.open("xb") as stream:
        np.savez_compressed(stream,**{key:val for key,val in fine.items()},parent=LOCK,protocol=digest(HERE/"PROTOCOL.md"),
                            coarse_tangent=digest(HERE/"tangent-minus-d0.025-to6.4.npz"),fine_tangent=digest(HERE/"tangent-minus-d0.0125-to6.4.npz"))
    print("frozen",digest(path),"weight derivative",fine["weights"],"rulers",fine["fixed"][-1,0],fine["matched"][-1,0],flush=True)


if __name__=="__main__":freeze()
