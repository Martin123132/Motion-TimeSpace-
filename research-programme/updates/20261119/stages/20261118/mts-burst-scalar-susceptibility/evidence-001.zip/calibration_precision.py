import itertools
import json
from forecast import HERE,PRE,COEFFICIENT,CLOCKS,np,load,burst,digest,table,TOL
from mixed_current import inherited
from mixed_coefficient import polar


def radius(linear,quadratic,gap):
    return 2*gap/(linear+np.sqrt(linear**2+4*quadratic*gap))


def evaluate():
    dx=.0125;document=json.loads((PRE/"magnetically-matched-scalar.json").read_text())
    archived=json.loads((PRE/"closeout.json").read_text())["files"]
    assert digest(PRE/"magnetically-matched-scalar.json")==archived["magnetically-matched-scalar.json"]
    data=load(inherited("budget-d0.0125-q0.8-h1-s0-p0-c12-r15-t0.3-ko0.5-seed1-mass.npz"))["rows"]
    unit1=[burst(dx,0.,"first")["rows"][:,1],data[:,1]];target=np.array(document["target_B"])
    maps=[np.array(document[tag]["early"]) for tag in ("ordinary","scalar")]
    scale=np.linalg.norm(maps[0],axis=1);templates=[]
    for amp in (0,1):
        response=polar(unit1[amp],burst(dx,amp,"second")["rows"][:,1],burst(dx,amp,"minus")["rows"][:,1])
        weights=np.linalg.solve(maps[amp],target)
        convert=np.linalg.solve(maps[amp],np.diag(scale))
        template=weights@response@weights
        linear=2*(weights@response@convert);square=convert.T@response@convert
        templates.append((template,linear,square))
    rows=[]
    for tau in CLOCKS:
        ix=round(tau/.02);ordinary,scalar=templates
        gap=abs(scalar[0][ix]-ordinary[0][ix])
        direct=abs(burst(dx,1.,"calibrated")["rows"][ix,1]-burst(dx,0.,"minus")["rows"][ix,1])
        assert abs(gap/direct-1)<TOL
        for name in ("separate intervals","same two measured fields"):
            if name=="separate intervals":
                linear=sum(np.sum(abs(item[1][ix])) for item in templates)
                quadratic=sum(np.sum(abs(item[2][ix])) for item in templates)
            else:
                linear=np.sum(abs(scalar[1][ix]-ordinary[1][ix]))
                quadratic=np.sum(abs(scalar[2][ix]-ordinary[2][ix]))
            threshold=radius(linear,quadratic,gap)
            assert abs(((linear+quadratic*threshold)*threshold)/gap-1)<1e-12
            fraction=.5*threshold
            pairs=[np.array(ch)*fraction for ch in itertools.product((-1.,0.,1.),repeat=2)]
            def apply(item,step):return item[1][ix]@step+step@item[2][ix]@step
            deviations=[abs(apply(scalar,right)-apply(ordinary,left)) for left in pairs for right in (pairs if name=="separate intervals" else [left])]
            assert max(deviations)<gap
            rows.append(dict(tau=tau,branch=name,gap=gap,linear_bound=linear,quadratic_bound=quadratic,
                             strict_epsilon_below=threshold,B3_absolute_at_threshold=scale[0]*threshold,
                             B4_absolute_at_threshold=scale[1]*threshold,half_threshold_sampled_max_fraction=max(deviations)/gap))
    return rows


if __name__=="__main__":table("calibration-precision.csv",evaluate())
