from contextlib import ExitStack
from unittest.mock import patch
from taylor import Taylor, lift, times, plus, np


def finite_ring(squared):
    if not squared>0:raise ValueError(squared)
    original_multiple=Taylor.__mul__;original_div=Taylor.__truediv__;original_ufunc=Taylor.__array_ufunc__

    def multiply(self,other):
        result=original_multiple(self,other)
        if isinstance(other,Taylor):
            mixed=plus(times(self.odd,other.even),times(self.even,other.odd))
            result.odd=plus(result.odd,times(squared,mixed))
            result.even=plus(result.even,times(squared,times(self.even,other.even)))
        return result

    def divide(self,other):
        if not isinstance(other,Taylor):return original_div(self,other)
        base=self.base/other.base
        mean=plus(other.base,times(squared,other.even))
        rhs1=plus(self.odd,times(-base,other.odd));rhs2=plus(self.even,times(-base,other.even))
        if other.odd is None:
            return Taylor(base,None if rhs1 is None else rhs1/mean,None if rhs2 is None else rhs2/mean)
        det=mean**2-squared*other.odd**2
        first=plus(times(mean,rhs1),times(-squared*other.odd,rhs2))
        second=plus(times(mean,rhs2),times(-other.odd,rhs1))
        return Taylor(base,None if first is None else first/det,None if second is None else second/det)

    def power(self,exponent):
        if not isinstance(exponent,int) or exponent<1:raise TypeError(exponent)
        return self if exponent==1 else self*(self**(exponent-1))

    def function(self,ufunc,method,*args,**kwargs):
        if ufunc==np.sqrt:
            if method!="__call__" or kwargs:raise TypeError(method)
            root=np.sqrt(self.base);mean=plus(self.base,times(squared,self.even))
            if self.odd is None:
                return Taylor(root,None,None if self.even is None else self.even/(root+np.sqrt(mean)))
            half=np.sqrt(squared)*self.odd
            pair=np.sqrt(mean+half)+np.sqrt(mean-half)
            first=self.odd/pair
            numerator=plus(self.even,-first**2)
            return Taylor(root,first,numerator/(root+pair/2))
        if ufunc==np.log1p:
            if self.odd is not None and np.any(self.odd):raise ValueError("log determinant must be even")
            even=None
            if self.even is not None:
                ratio=squared*self.even/(1+self.base)
                if np.iscomplexobj(ratio):
                    realpart=.5*np.log1p(2*ratio.real+ratio.real**2+ratio.imag**2)
                    even=(realpart+1j*np.arctan2(ratio.imag,1+ratio.real))/squared
                else:even=np.log1p(ratio)/squared
            return Taylor(np.log1p(self.base),None,even)
        return original_ufunc(self,ufunc,method,*args,**kwargs)

    context=ExitStack()
    for key,func in (("__mul__",multiply),("__rmul__",multiply),("__truediv__",divide),("__pow__",power),("__array_ufunc__",function)):
        context.enter_context(patch.object(Taylor,key,func))
    return context
