from susceptibility import np, mp, Taylor, HERE, WEIGHTS, MASS, law, spin_taylor
from pair_algebra import finite_ring
from contextlib import nullcontext
import csv
import json


def checks():
    results={}
    amp=mp.mpf(".00625")
    baryon=mp.mpf(float(MASS))
    def check(name,approx,expected):
        scaled=float(abs(approx-expected)/max(abs(expected),mp.mpf("1e-30")))
        results[name]=scaled
        if scaled>=2e-5:raise ArithmeticError((name,approx,expected,scaled))
    def oddcase(av):
        left=1.5+av/4-av**2/8;right=2-av/2+av**2/16
        return mp.sqrt(left**3/right)+left*right/7
    def evencase(av):
        return mp.log(1+mp.mpc(".003",".004")+av**2*mp.mpc("3e-15","-7e-28"))
    for clock in (0.,float(amp)):
        active=nullcontext() if not clock else finite_ring(clock**2)
        with active:
            left=Taylor(1.5,.25,-.125);right=Taylor(2.,-.5,.0625)
            nonlinear=np.sqrt(left**3/right)+left*right/7
            small=np.log1p(Taylor(complex(.003,.004),None,complex(3e-15,-7e-28)))
        for name,actual,func in (("nonlinear",nonlinear,oddcase),("logarithm",small,evencase)):
            if clock:
                denominator=mp.mpf(clock)
                first=(func(denominator)-func(-denominator))/(2*denominator)
                second=((func(denominator)+func(-denominator))/2-func(0))/denominator**2
            else:
                first=mp.diff(func,0);second=mp.diff(func,0,2)/2
            check(f"{clock}/{name}/odd",0 if actual.odd is None else actual.odd,first)
            check(f"{clock}/{name}/even",actual.even,second)
    for frac in (.12,.34,.68,.89):
        label=MASS*frac;delta=.015*MASS
        ell,ang=spin_taylor(Taylor(label,None,delta),WEIGHTS["minus"])
        def primitive(step):
            number=(mp.mpf(label)+step*mp.mpf(delta))/baryon
            return baryon*mp.mpf(32)/3*number**3*(1-number)**3*(1+WEIGHTS["minus"][1]*(2*number-1))
        check(f"J material motion {frac}",ang.even,mp.diff(primitive,0))
        check(f"ell material motion {frac}",ell.even,mp.diff(primitive,0,2)/mp.mpf(delta))
    return results


if __name__=="__main__":
    with mp.workdps(85):record=checks()
    with (HERE/"arithmetic-checks.json").open("x") as stream:json.dump(record,stream,indent=2,allow_nan=False)
    print(len(record),"arithmetic checks; maximum relative error",max(record.values()))
