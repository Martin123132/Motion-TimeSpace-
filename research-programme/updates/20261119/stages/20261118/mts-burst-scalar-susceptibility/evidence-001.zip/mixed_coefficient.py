from forecast import (HERE,COEFFICIENT,WEIGHTS,TOL,CLOCKS,np,burst,load,coords,predict,error,peak,digest,table)
from assess import FROZEN
import sys


def polar(first,second,minus):
    cross=(first+COEFFICIENT**2*second-minus)/(2*COEFFICIENT)
    return np.stack((first,cross,cross,second),axis=-1).reshape(-1,2,2)


def derive():
    if digest(HERE/"predictions.npz")!=FROZEN:raise ValueError("leading coefficient changed")
    dx=.025;model=predict(dx);weights=np.array(WEIGHTS["minus"][:2])
    directions=("first","second","minus")
    packets=[load(HERE/f"tangent-{tag}-d0.025-to6.4.npz") for tag in directions]
    arrays=[item["history"] for item in packets]
    for tag,record in zip(directions,arrays):
        assert error(record[:,0,0],coords(burst(dx,0.,tag)["rows"])[:,0])<TOL
    matrix=polar(*(record[:,0,0] for record in arrays))
    slope=polar(*(record[:,2,0] for record in arrays))
    early=np.column_stack([record[[150,200],2,2] for record in arrays[:2]])
    assert error(early@weights,arrays[-1][[150,200],2,2])<TOL
    inc=model["weights"];extra=np.linalg.solve(model["calibration"],-early@inc)
    source_field=2*(inc@slope@weights)
    square=inc@matrix@inc
    map_change=2*(extra@matrix@weights)
    return dict(clock=model["clock"],source_field=source_field,square=square,map_change=map_change,
                weight=inc,weight_map_change=extra,mixed=source_field+square+map_change,leading=model["matched"][:,0],
                parent_prediction=FROZEN,protocol=digest(HERE/"MIXED-COUPLING.md"),dx=dx,
                inputs=np.array([digest(HERE/f"tangent-{tag}-d0.025-to6.4.npz") for tag in directions]))


def score():
    frozen=load(HERE/"derived-mixed-coefficient.npz");calc=derive()
    for key in calc:assert np.array_equal(frozen[key],calc[key])
    result=[]
    for dx in (.025,.0125):
        base=coords(burst(dx,0.,"minus")["rows"]);leading=predict(dx)["matched"][:,0]
        sources=[(1.,coords(burst(dx,1.,"calibrated")["rows"])[:,0]-base[:,0],"archived directly evolved")]
        for path in sorted(HERE.glob(f"finite-matched-d{dx:g}-A*.npz")):
            pack=load(path);sources.append((float(pack["amp"]),pack["rows"][:,0]-base[:,0],"new directly evolved"))
        for path in sorted(HERE.glob(f"paired-matched-d{dx:g}-A*.npz")):
            if "-to" in path.name:continue
            pack=load(path);sources.append((float(pack["amp"]),float(pack["amp"])**2*pack["history"][:,2,0],"finite divided equations"))
        for amp,measured,method in sources:
            squared=amp**2;baseline=squared*leading;addition=squared**2*frozen["mixed"]
            for tau in CLOCKS:
                index=round(tau/.02)
                result.append(dict(test_dx=dx,coefficient_dx=float(frozen["dx"]),amp=amp,method=method,tau=tau,
                                   measured=measured[index],leading=baseline[index],mixed_addition=addition[index],
                                   remaining=measured[index]-baseline[index]-addition[index],
                                   leading_error=error(baseline,measured),including_mixed_error=error(baseline+addition,measured),
                                   remainder_resolution=peak(measured-baseline-addition)/peak(measured-baseline)))
    return result


if __name__=="__main__":
    if sys.argv[1]=="derive":
        with (HERE/"derived-mixed-coefficient.npz").open("xb") as stream:np.savez_compressed(stream,**derive())
    elif sys.argv[1]=="compare":table("mixed-coefficient-tests.csv",score())
    else:raise ValueError(sys.argv[1])
