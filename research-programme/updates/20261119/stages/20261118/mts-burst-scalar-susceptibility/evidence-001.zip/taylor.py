import numpy as np


def plus(left,right):
    return right if left is None else left if right is None else left+right


def times(left,right):
    return None if left is None or right is None else left*right


class Taylor:
    __array_priority__=10000

    def __init__(self,base,odd=None,even=None):
        self.base,self.odd,self.even=base,odd,even

    def __len__(self):return len(self.base)
    def __iter__(self):
        for index in range(len(self)):yield self[index]

    def __getitem__(self,index):
        return Taylor(self.base[index],None if self.odd is None else self.odd[index],None if self.even is None else self.even[index])

    def __setitem__(self,index,value):
        value=lift(value);self.base[index]=value.base
        if self.odd is not None:self.odd[index]=0 if value.odd is None else value.odd
        elif value.odd is not None:raise ValueError("missing odd destination")
        if self.even is not None:self.even[index]=0 if value.even is None else value.even
        elif value.even is not None:raise ValueError("missing even destination")

    def map(self,fn):
        return Taylor(fn(self.base),None if self.odd is None else fn(self.odd),None if self.even is None else fn(self.even))

    @property
    def real(self):return self.map(lambda value:value.real)

    @real.setter
    def real(self,value):
        source=lift(value)
        self.base.real[...] = source.base
        if self.odd is not None:self.odd.real[...] = 0 if source.odd is None else source.odd
        if self.even is not None:self.even.real[...] = 0 if source.even is None else source.even

    @property
    def imag(self):return self.map(lambda value:value.imag)

    def __neg__(self):return self.map(lambda value:-value)

    def __add__(self,other):
        if not isinstance(other,Taylor):return Taylor(self.base+other,self.odd,self.even)
        return Taylor(self.base+other.base,plus(self.odd,other.odd),plus(self.even,other.even))

    __radd__=__add__
    def __sub__(self,other):return self+(-other)
    def __rsub__(self,other):return (-self)+other

    def __mul__(self,other):
        if not isinstance(other,Taylor):return Taylor(self.base*other,times(self.odd,other),times(self.even,other))
        return Taylor(self.base*other.base,plus(times(self.base,other.odd),times(self.odd,other.base)),
                      plus(plus(times(self.even,other.base),times(self.base,other.even)),times(self.odd,other.odd)))

    __rmul__=__mul__

    def __truediv__(self,other):
        if not isinstance(other,Taylor):
            return self.map(lambda field:field/other)
        base=self.base/other.base
        one=plus(self.odd,times(-base,other.odd))
        if one is not None:one=one/other.base
        two=plus(self.even,times(-base,other.even))
        coupled=times(one,other.odd)
        if coupled is not None:two=plus(two,-coupled)
        if two is not None:two=two/other.base
        return Taylor(base,one,two)

    def __rtruediv__(self,other):return lift(other)/self

    def __pow__(self,power):
        if power==2:return self*self
        if power==1:return self
        base=self.base**power
        first=power*self.base**(power-1)
        second=None if self.odd is None else (.5*power*(power-1)*self.base**(power-2))*self.odd**2
        return Taylor(base,times(first,self.odd),plus(times(first,self.even),second))

    def __abs__(self):
        if np.iscomplexobj(self.base):raise ValueError("absolute value only for real label")
        sign=np.sign(self.base)
        return Taylor(abs(self.base),times(sign,self.odd),times(sign,self.even))

    def __array_ufunc__(self,ufunc,method,*args,**kwargs):
        if method!="__call__" or kwargs:raise TypeError((ufunc,method,kwargs))
        if ufunc in (np.add,np.subtract,np.multiply,np.true_divide):
            left,right=args
            if isinstance(left,Taylor):
                return {np.add:Taylor.__add__,np.subtract:Taylor.__sub__,np.multiply:Taylor.__mul__,np.true_divide:Taylor.__truediv__}[ufunc](left,right)
            return {np.add:Taylor.__radd__,np.subtract:Taylor.__rsub__,np.multiply:Taylor.__rmul__,np.true_divide:Taylor.__rtruediv__}[ufunc](right,left)
        if ufunc==np.sqrt:
            root=np.sqrt(self.base);one=None if self.odd is None else self.odd/(2*root)
            two=plus(self.even,None if one is None else -one**2)
            return Taylor(root,one,None if two is None else two/(2*root))
        if ufunc==np.hypot:
            left,right=args
            return np.sqrt(left*left+right*right)
        if ufunc==np.sign:return np.sign(self.base)
        if ufunc in (np.fabs,np.absolute):return abs(self)
        if ufunc==np.negative:return -self
        if ufunc==np.log1p:
            inv=1/(1+self.base);one=times(inv,self.odd)
            return Taylor(np.log1p(self.base),one,plus(times(inv,self.even),None if one is None else -.5*one**2))
        raise TypeError(ufunc)


def lift(value):return value if isinstance(value,Taylor) else Taylor(value)


class State(Taylor):
    def __getitem__(self,index):
        if isinstance(index,slice):
            indices=range(len(self))[index]
            return tuple(self[k] for k in indices)
        value=super().__getitem__(index)
        if index not in (8,9):value.odd=None
        return value


class ArrayOps:
    def __getattr__(self,key):return getattr(np,key)
    def zeros_like(self,field):
        if isinstance(field,Taylor):
            return Taylor(np.zeros_like(field.base),np.zeros_like(field.base),np.zeros_like(field.base))
        return np.zeros_like(field)
