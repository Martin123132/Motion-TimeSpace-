from forecast import HERE, PRE, WEIGHTS, CLOCKS, TOL, burst, load, coords, integrated, digest, np, json
from susceptibility import ETA, Centre, regular, smooth_launch, signed_equations, exposure, check_parent, hold, law, correlate1d, patch, sys
from mixed_current import MASS, COEFFICIENT


def prepared(dx,amp,weights):
    model=Centre(dx,ETA,0.,cap=12,reduced=True,damping=.5,mass_form=True)
    model.profile=tuple(weights)
    full=regular.Model(1920,ETA,1.,0)
    with patch.object(model.model,"scalar",lambda *args:amp*full.scalar(*args)),patch.object(model.model,"h",amp*full.h),patch.object(smooth_launch,"spin",law):
        changes=smooth_launch.refresh(model,ETA,amp,False,model.profile)
    return model,changes


def passive_rhs(model,state,field):
    ghost=model.ghost
    ext=model.extend(state);wave=np.concatenate((field[:,:ghost][:,::-1],field),axis=1)
    potential,pm=wave
    metric=np.sqrt(1+ext[0].real[:,:1]);radius=model.x*np.sqrt(1+ext[2].real[:,:1])
    label=ext[18].real[:,:1];charge=ETA*label
    ell,primitive=law(abs(label),WEIGHTS["second"]);primitive*=np.sign(label)
    lor=np.hypot(1,ext[14].real[:,:1]/metric)
    slope=model.dr(potential);lap=correlate1d(potential,regular.AXIAL_SECOND,axis=0,mode="nearest")/(model.dx**2*metric)-slope*model.dr(metric)/metric**2
    twist=4*metric*(charge*potential-primitive)/radius**4
    rates=np.stack((pm/metric,lap-2*metric*potential/radius**2+ETA*ext[13].real[:,:1]*(ell-ETA*potential)/(lor*radius**2)-charge*twist))
    stencil=np.array([1,-8,28,-56,70,-56,28,-8,1])/256
    rates=(rates-model.damping/model.dx*correlate1d(wave,stencil,axis=1,mode="nearest"))*model.mask
    rates=rates[:,ghost:].copy()
    rates[:,:model.cap.count]=model.cap.mat[2]@rates[:,:model.cap.count]
    return rates


def sample(model,state,initial,passive):
    radius=model.rad*np.sqrt(1+state[2].real[:,:1]);metric=np.sqrt(1+state[0].real[:,:1])
    potential=state[19].real[:,:1];local=lambda array:model.atsite(array[:,0])
    return [model.contrast(state[17]),model.contrast(model.logmetric(state)-initial),
            local(2*potential/radius**2),local(-state[20].real[:,:1]/(metric*radius)),
            local(-model.dr(potential)/(metric*radius)),local(radius),*exposure.terms(model,state),
            local(2*passive[0]/radius**2)]


def filename(dx,amp,branch):
    return HERE/f"finite-{branch}-d{dx:g}-A{amp:g}.npz"


def evolve(dx,amp,branch):
    check_parent()
    if not (HERE/"predictions.npz").exists():raise RuntimeError("freeze the tangent first")
    target=filename(dx,amp,branch);partial=target.with_suffix(".partial")
    if target.exists() or partial.exists():raise FileExistsError(target)
    weights=np.array(WEIGHTS["minus"]);weights2=np.zeros(2)
    if branch=="matched":
        previous=load(filename(dx,amp,"fixed"))
        measured=previous["rows"][[150,200],2];second=previous["rows"][[150,200],12]
        first=measured+COEFFICIENT*second
        ordinary=coords(burst(dx,0.,"minus")["rows"])[[150,200],2]
        weights2=np.linalg.solve(np.column_stack((first,second)),ordinary-measured)/amp**2
        weights[:2]+=amp**2*weights2
    model,changes=prepared(dx,amp,weights)
    state=model.y0.copy();start=model.logmetric(state)
    passive=np.zeros((2,len(model.rad),1));history=[]
    steps=int(np.ceil(.02/(.30*dx)-1e-12));dt=.02/steps
    with patch.object(signed_equations,"spin",law),patch.object(exposure,"spin",law):
        for index in range(321):
            hold();history.append(sample(model,state,start,passive))
            if not np.isfinite(history[-1]).all():raise ArithmeticError(index)
            if index==320:break
            for _ in range(steps):
                one=model.rhs(state);p1=passive_rhs(model,state,passive)
                lev=state+dt/2*one;two=model.rhs(lev);p2=passive_rhs(model,lev,passive+dt/2*p1)
                lev=state+dt/2*two;three=model.rhs(lev);p3=passive_rhs(model,lev,passive+dt/2*p2)
                lev=state+dt*three;four=model.rhs(lev);p4=passive_rhs(model,lev,passive+dt*p3)
                state+=dt/6*(one+2*two+2*three+four);passive+=dt/6*(p1+2*p2+2*p3+p4)
    with partial.open("xb") as stream:
        np.savez_compressed(stream,rows=history,clock=np.arange(321)*.02,weights=weights,weight_change_per_A2=weights2,
                            prediction=digest(HERE/"predictions.npz"),amp=amp,dx=dx,branch=branch,seed=json.dumps(changes))
    partial.rename(target);print(target.name,history[-1][:3],flush=True)


if __name__=="__main__":
    for branch in ("fixed","matched"):evolve(float(sys.argv[1]),float(sys.argv[2]),branch)
