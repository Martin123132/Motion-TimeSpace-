import csv
import json
import sys
from scipy.integrate import simpson
from forecast import load, prior, burst, coords, digest, check_parent, TOL, peak, error, np, HERE, PRE, LOCK
from assess import FROZEN,calculate,crossing
from arithmetic_controls import checks,mp
from mixed_coefficient import score as mixed_scores
from nonlinear_remainder import measure
from clock_features import landmarks
from calibration_precision import evaluate as calibration_limits


def verify():
    check_parent()
    with mp.workdps(85):arithmetic=checks()
    assert arithmetic==json.loads((HERE/"arithmetic-checks.json").read_text())
    computed=calculate()
    evidence=list(zip(("amplitude-tests.csv","per-clock-tests.csv","focusing-contributions.csv","numerical-checks.csv"),computed))
    mixed=mixed_scores();closure=measure()
    evidence.extend((("mixed-coefficient-tests.csv",mixed),("nonlinear-remainder.csv",closure),("clock-landmarks.csv",landmarks()),
                     ("calibration-precision.csv",calibration_limits())))
    for name,fresh in evidence:
        with (HERE/name).open(newline="") as stream:saved=list(csv.DictReader(stream))
        assert len(saved)==len(fresh)
        for old,new in zip(saved,fresh):
            assert set(old)==set(new)
            for key,value in new.items():assert old[key]==("" if value is None else str(value)),(name,key)
    full=load(HERE/"predictions.npz")
    assert digest(HERE/"predictions.npz")==FROZEN and str(full["parent"])==LOCK
    assert digest(HERE/"PROTOCOL.md")==str(full["protocol"])
    history_checks={}
    for dx,tag in ((.025,"coarse_tangent"),(.0125,"fine_tangent")):
        packet=HERE/f"tangent-minus-d{dx:g}-to6.4.npz"
        assert digest(packet)==str(full[tag])
        for name in ("fixed","matched"):
            coupled=next(row for row in computed[0] if row["dx"]==dx and row["method"]=="archived finite difference" and row["branch"]==name)
            dp=coords(burst(dx,1.,"minus" if name=="fixed" else "calibrated")["rows"])-coords(burst(dx,0.,"minus")["rows"])
            assert dp[-1,0]==coupled["final_coefficient"]
    ts=full["clock"];assert np.array_equal(ts,np.arange(321)*.02)
    comparisons={}
    comparisons["full_nonlinear_closure_on_remainder"]=closure[-1]["whole_history_closure_on_remainder"]
    assert comparisons["full_nonlinear_closure_on_remainder"]<TOL
    fullarm=next(row for row in mixed if row["amp"]==1. and row["test_dx"]==.0125)
    comparisons["full_leading_error"]=fullarm["leading_error"]
    comparisons["full_after_mixed_term"]=fullarm["including_mixed_error"]
    comparisons["max_corrected_relative_at_five_full_fine_clocks"]=max(abs(row["remaining"]/row["measured"])
            for row in mixed if row["amp"]==1. and row["test_dx"]==.0125)
    assert comparisons["max_corrected_relative_at_five_full_fine_clocks"]<TOL
    for name in ("fixed","matched"):
        jet=full[name];total=jet[:,6:12].sum(axis=1);direct=[]
        for pos in (150,200,250,300,320):
            direct.append(simpson((ts[pos]-ts[:pos+1])*total[:pos+1],x=ts[:pos+1]))
        residual=error(np.array(direct),jet[[150,200,250,300,320],0])
        comparisons[name+"_independent_convolution"]=float(residual)
        assert residual<TOL,(name,residual)
        assert jet[200,0]>0>jet[250,0]
        assert 4<crossing(ts,jet[:,0])<5
    weights=full["weights"];design=full["calibration"]
    comparisons["early_determinant"]=float(np.linalg.det(design))
    comparisons["row_scaled_condition"]=float(np.linalg.cond(design/np.linalg.norm(design,axis=1)[:,None]))
    assert np.linalg.matrix_rank(design)==2
    assert error(-design@weights,full["fixed"][[150,200],2])<TOL
    assert np.allclose(full["matched"][:,0],full["fixed"][:,0]+full["adjust"][:,0],rtol=0,atol=0)
    assert np.array_equal(full["matched"][:,5],full["fixed"][:,5])
    assert not np.any(full["base"][:,8]) and peak(full["scalar_wave"])>0
    for dx in (.025,.0125):
        for branch in ("fixed","matched"):
            for pos in (200,250,320):
                archives=coords(burst(dx,1.,"minus" if branch=="fixed" else "calibrated")["rows"])
                old=coords(burst(dx,0.,"minus")["rows"])
                assert np.sign(archives[pos,0]-old[pos,0])==np.sign(full[branch][pos,0])
    assert not list(HERE.glob("*.partial"))
    names=sorted(p for p in HERE.iterdir() if p.is_file() and p.name not in ("closeout.json","STOP-REQUESTED"))
    compare_files={p.name:digest(p) for p in names}
    assert not (HERE/"__pycache__").exists()
    clean=[r for r in computed[3] if not r["passes"]]
    return dict(parent=LOCK,prediction=FROZEN,files=compare_files,arithmetic_checks=len(arithmetic),
                independent_checks=comparisons,saved_numerical_checks=len(computed[3]),unresolved_numerical=clean,
                finite_tests=len(computed[0]),finite_history_tests_at_target=sum(bool(r["history_pass"]) for r in computed[0]),
                accuracy_target=TOL,scope="two prepared source shapes, charged burst; local finite grids; no observational data")


if __name__=="__main__":
    receipt=verify()
    dest=HERE/"closeout.json"
    if len(sys.argv)==2 and sys.argv[1]=="seal":
        with dest.open("x",encoding="utf8") as stream:json.dump(receipt,stream,sort_keys=True,indent=2,allow_nan=False)
    else:assert receipt==json.loads(dest.read_text())
    print(len(receipt["files"]),"files;",receipt["saved_numerical_checks"],"numerical checks;",
          len(receipt["unresolved_numerical"]),"unresolved;",receipt["finite_history_tests_at_target"],
          "of",receipt["finite_tests"],"finite comparisons at target;",digest(dest))
