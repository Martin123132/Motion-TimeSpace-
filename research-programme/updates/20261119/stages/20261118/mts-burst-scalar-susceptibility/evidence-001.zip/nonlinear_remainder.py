import json
from forecast import HERE,PRE,COEFFICIENT,CLOCKS,np,coords,load,burst,table,peak,digest,error
from assess import FROZEN
from mixed_current import inherited


def measure():
    assert digest(HERE/"predictions.npz")==FROZEN
    frozen=load(HERE/"predictions.npz");dx=.0125
    old=json.loads((PRE/"magnetically-matched-scalar.json").read_text())
    parent=json.loads((PRE/"closeout.json").read_text())["files"]
    assert digest(PRE/"magnetically-matched-scalar.json")==parent["magnetically-matched-scalar.json"]
    weights=np.array((1.,-COEFFICIENT));u0=frozen["weights"];u1=np.array(old["scalar"]["weights"])-weights
    base=burst(dx,0.,"minus")["rows"][:,1]
    fix=burst(dx,1.,"minus")["rows"][:,1]
    marked=burst(dx,1.,"calibrated")["rows"][:,1]
    first=load(inherited(f"budget-d{dx:g}-q0.8-h1-s0-p0-c12-r15-t0.3-ko0.5-seed1-mass.npz"))["rows"][:,1]
    def polar(uno,due,minus):
        cross=(uno+COEFFICIENT**2*due-minus)/(2*COEFFICIENT)
        return np.stack([uno,cross,cross,due],axis=-1).reshape(-1,2,2)
    ordinary=polar(burst(dx,0.,"first")["rows"][:,1],burst(dx,0.,"second")["rows"][:,1],base)
    whole=polar(first,burst(dx,1.,"second")["rows"][:,1],fix)
    direct=(marked-base)-frozen["matched"][:,0]
    intrinsic=(fix-base)-frozen["fixed"][:,0]
    change=2*((u1-u0)@ordinary@weights)
    interaction=2*(u1@(whole-ordinary)@weights)
    selfterm=u1@whole@u1
    combined=intrinsic+change+interaction+selfterm
    output=[]
    for clock in CLOCKS:
        index=round(clock/.02)
        output.append(dict(tau=clock,measured_difference_from_leading=direct[index],fixed_source_remainder=intrinsic[index],
                           nonlinear_weight_identification=change[index],field_source_cross=interaction[index],
                           quadratic_weight_response=selfterm[index],matrix_sum=combined[index],
                           independent_closure=combined[index]-direct[index],whole_history_closure_on_remainder=error(combined,direct),
                           whole_history_closure_on_scalar_signal=peak(combined-direct)/peak(marked-base)))
    return output


if __name__=="__main__":table("nonlinear-remainder.csv",measure())
