from susceptibility import (Evolution, State, Taylor, ETA, MASS, EXTENT, D0, EDGE, PRE, HERE, LOCK, WEIGHTS,
                           check_parent, hold, law, shape, count, background, np, smooth_launch, regular,
                           signed_equations, exposure, flat_vector, mp, robin, solve_bvp, FunctionType, patch, digest)
from forecast import load, coords, burst
from pair_algebra import finite_ring
import argparse


def seed_difference(evolution, amp, change):
    model=evolution.model
    weights=evolution.weights
    squared=amp**2
    field=shape()
    profile=background(field,amp)
    saved=[]
    original=smooth_launch.solve
    def capture(*args,**kwargs):
        result=original(*args,**kwargs);saved.append(result[0]);return result
    with patch.object(smooth_launch,"solve",capture),patch.object(smooth_launch,"spin",law):
        smooth_launch.refresh(model,ETA,0.,False,weights)
    ordinary=saved[0].sol
    limit=.0078125
    nodes=np.linspace(np.log(limit),np.log(EXTENT),553)
    def coefficients(coord):
        radius=np.exp(coord);mass,gain=profile(radius);number=count(radius)
        potential=6+(ETA*number/radius)**2
        root0=np.sqrt(1-2*mass/radius+(ETA*number/radius)**2)
        root=np.sqrt(root0**2-2*squared*gain/radius)
        invdiff=2*gain/(radius*root*root0*(root+root0))
        density=D0*np.maximum(1-(radius/EDGE)**2,0.)**6
        term=radius**2*density+(potential-squared*(radius*field(radius))**2)/root
        var=potential*invdiff-(radius*field(radius))**2/root
        ell,jval=law(number,weights);delta_ell,delta_j=law(number,change)
        force=density*(2*ell+squared*delta_ell)*delta_ell/6
        force+=(2/3)/radius**4*(jval**2*invdiff+(2*jval+squared*delta_j)*delta_j/root)
        value,flux=ordinary(coord)
        return 1/root,term,invdiff*flux,var*value+force
    with mp.workdps(60):
        mass,gain=map(mp.mpf,map(float,profile(EXTENT)))
        edge=mp.mpf(EXTENT);charge=mp.mpf(ETA*MASS);step=mp.mpf(squared)
        old=robin(mass,charge,edge);new=robin(mass+step*gain,charge,edge)
        beta=float(new);boundary=float((new-old)/step)*ordinary(nodes[-1])[0]
    scale=max(np.max(np.abs(coefficients(nodes)[2:])),abs(boundary),1e-50)
    def rhs(coord,values):
        inverse,potential,one,two=coefficients(coord)
        return np.array([inverse*values[1]+one/scale,-values[1]+potential*values[0]+two/scale])
    sol=solve_bvp(rhs,lambda first,last:[first[1]-2*first[0],last[1]-beta*last[0]-boundary/scale],
                  nodes,np.zeros((2,len(nodes))),tol=3e-10,max_nodes=16000)
    if not sol.success:raise ArithmeticError(sol.message)
    radius=model.rad;coord=np.log(np.maximum(radius[:,0],limit));inside=np.minimum(1,radius/limit)**2
    value=ordinary(coord)[0][:,None]*inside;delta=scale*sol.sol(coord)[0][:,None]*inside
    mass,gain=profile(radius[:,0]);mass=mass[:,None];gain=gain[:,None]
    fac0=1-2*mass/radius+(ETA*count(radius)/radius)**2;fac=fac0-2*squared*gain/radius
    first=np.zeros_like(model.y0);second=np.zeros_like(first)
    first[8]=field(radius)
    second[0]=2*gain/radius*(1+4*regular.DUAL*value*regular.POL)/(fac*fac0)+4*regular.DUAL*delta*regular.POL/fac
    second[2]=second[3]=4*regular.DUAL*delta*regular.POL;second[23]=gain/radius**3
    first=model.cap.project(first);second=model.cap.project(second)
    vx,vt=flat_vector(model,*model.extend(second)[:4])
    second[21]=vx[model.ghost:];second[22]=vt[model.ghost:]
    return np.stack((model.y0,first,second)),Taylor(model.shift,None,-2*radius*delta),scale*sol.sol(np.log(6.))


def weights_for(dx,amp,branch):
    if branch=="fixed":return np.zeros(3)
    from finite import filename
    before=load(HERE/f"paired-fixed-d{dx:g}-A{amp:g}.npz")
    finite=load(filename(dx,amp,"fixed"))
    assert str(finite["prediction"])==str(before["prediction"])==digest(HERE/"predictions.npz")
    squared=amp**2;rows=before["history"][[150,200]]
    second=finite["rows"][[150,200],12]
    measured=rows[:,0,2]+squared*rows[:,2,2]
    first=measured-WEIGHTS["minus"][1]*second
    return np.r_[np.linalg.solve(np.column_stack((first,second)),-rows[:,2,2]),0.]


class PairEvolution(Evolution):
    def __init__(self,dx,amp,branch):
        super().__init__(dx,"minus")
        self.squared=amp**2;self.change=weights_for(dx,amp,branch)
        self.initial,self.shift,self.seed=seed_difference(self,amp,self.change)
        self.terms=FunctionType(exposure.terms.__code__,dict(exposure.terms.__globals__,spin=self.spin,float=lambda value:value))

    def spin(self,label,weights):
        if not isinstance(label,Taylor):raise TypeError(type(label))
        if label.odd is not None and np.any(label.odd):raise ValueError("odd particle number")
        raw=label.base/MASS;delta=label.even/MASS;squared=self.squared
        inside=(raw>=0)&(raw<=1)
        clipped=np.where(inside,np.clip(delta,-raw/squared,(1-raw)/squared),
                         np.where(raw<0,np.clip(raw/squared+delta,0.,1/squared),
                                  np.clip((raw-1)/squared+delta,-1/squared,0.)))
        fraction=Taylor(np.clip(raw,0,1),None,clipped)
        variable=2*fraction-1
        primitive=(32/3)*fraction**3*(1-fraction)**3
        slope=32*fraction**2*(1-fraction)**2*(1-2*fraction)
        first,second,third=[Taylor(val,None,inc) for val,inc in zip(weights,self.change)]
        poly=first+second*variable+third*variable**2
        return slope*poly+2*primitive*(second+2*third*variable),MASS*primitive*poly

    def patches(self):
        context=super().patches();context.enter_context(finite_ring(self.squared))
        context.enter_context(patch.object(signed_equations,"spin",self.spin))
        return context


def advance_pair(dx,amp,branch,end=6.4):
    check_parent()
    forecast=HERE/"predictions.npz"
    if not forecast.exists():raise RuntimeError("freeze predictions before testing")
    target=HERE/f"paired-{branch}-d{dx:g}-A{amp:g}{'' if end==6.4 else '-to'+str(end)}.npz"
    partial=target.with_suffix(".partial")
    if target.exists() or partial.exists():raise FileExistsError(target)
    model=PairEvolution(dx,amp,branch)
    steps=int(np.ceil(.02/(.30*dx)-1e-12));dt=.02/steps
    values=model.initial.copy();history=[]
    with model.patches():
        start=model.model.logmetric(State(*values))
        for tick in range(round(end/.02)+1):
            hold();history.append(model.read(values,start))
            if not np.isfinite(history[-1]).all():raise FloatingPointError(tick)
            if tick==round(end/.02):break
            for _ in range(steps):
                one=model.rhs(values);two=model.rhs(values+dt/2*one)
                three=model.rhs(values+dt/2*two);four=model.rhs(values+dt*three)
                values+=dt/6*(one+2*two+2*three+four)
    assert np.isfinite(values).all() and not np.any(values[1,[i for i in range(24) if i not in (8,9)]]) and not np.any(values[2,8:10])
    with partial.open("xb") as stream:np.savez_compressed(stream,history=history,seed=model.seed,change=model.change,
                               prediction=digest(forecast),clock=np.arange(len(history))*.02,dx=dx,amp=amp,branch=branch)
    partial.rename(target)
    print(target.name,history[-1][2,:3],flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("dx",type=float);parser.add_argument("amp",type=float)
    parser.add_argument("branch",choices=("fixed","matched"));parser.add_argument("--end",type=float,default=6.4)
    advance_pair(**vars(parser.parse_args()))
