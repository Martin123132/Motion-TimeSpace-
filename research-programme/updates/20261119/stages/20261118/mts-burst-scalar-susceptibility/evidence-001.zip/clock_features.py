from forecast import load, HERE, np, integrated, table, digest, peak
from assess import FROZEN,calculate


def zeros(ts,arr):
    found=[]
    for ix in range(1,len(ts)-1):
        if arr[ix]*arr[ix+1]<0:
            found.append((float(ts[ix]),float(ts[ix+1]),float(ts[ix]-arr[ix]*(ts[ix+1]-ts[ix])/(arr[ix+1]-arr[ix]))))
    return found


def landmarks():
    assert digest(HERE/"predictions.npz")==FROZEN
    model=load(HERE/"predictions.npz");ts=model["clock"]
    rows=[]
    for key in ("fixed","matched"):
        signal=model[key];terms=integrated(ts,signal[:,6:12])
        for label,arr in (("ruler",signal[:,0]),("metric",signal[:,1]),("direct scalar",terms[:,2]),("induced shear",terms[:,0])):
            for lo,hi,root in zeros(ts,arr):
                rows.append(dict(series=key,source=label,bracket_low=lo,bracket_high=hi,linear_root=root))
    return rows


if __name__=="__main__":table("clock-landmarks.csv",landmarks())
