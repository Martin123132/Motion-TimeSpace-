import csv
import json
from pathlib import Path
from forecast import (HERE,PRE,LOCK,TOL,CLOCKS,WEIGHTS,np,burst,load,coords,predict,
                      integrated,prior,levels,table,peak,error,digest,check_parent)

FROZEN="e14819e289d0829ce1b586f55c1a97d53fde9ca231c554bab4d48d69de0db58d"


def crossing(clock,values):
    choices=np.flatnonzero((clock[:-1]>=4)&(values[:-1]>0)&(values[1:]<=0))
    if len(choices)!=1:return None
    at=choices[0]
    return float(clock[at]+(clock[at+1]-clock[at])*values[at]/(values[at]-values[at+1]))


def calculate():
    check_parent()
    assert digest(HERE/"predictions.npz")==FROZEN
    frozen=load(HERE/"predictions.npz");records=[];clocks=[];parts=[];validation=[]
    def number(name,value,limit=TOL):
        validation.append(dict(check=name,value=float(value),limit=limit,passes=bool(np.isfinite(value) and value<=limit)))
    for dx in (.025,.0125):
        fine=dx==.0125;pred=frozen if fine else predict(dx)
        ts=pred["clock"];base=pred["ordinary"];ref=levels(dx)["history"];coef=pred["weights"]
        seed=json.loads((PRE/"zero-amplitude-launch-forecast.json").read_text())["minus"]
        for num,key in enumerate(("u_slope","flux_slope")):
            number(f"{dx}: independent release {key}",abs(pred["seed"][num]/seed[key]-1))
        number(f"{dx}: scalar focusing is minus the release Ricci trace",abs(ref[0,2,8]/seed["trace_slope"]+1))
        for branch in ("fixed","matched"):
            tangent=pred[branch]
            focus=integrated(ts,tangent[:,6:12])
            number(f"{dx}/{branch}: determinant on susceptibility scale",error(tangent[:,1],tangent[:,0]))
            number(f"{dx}/{branch}: double-integrated focusing on susceptibility scale",error(focus.sum(axis=1),tangent[:,0]))
            for count,clock in enumerate(CLOCKS):
                pos=round(clock/.02)
                parts.append(dict(dx=dx,branch=branch,tau=clock,relative_response=tangent[pos,0]/base[pos,0],
                        **dict(zip(("shear","twist","scalar","polar_E","dipole","material"),focus[pos])),
                        total=tangent[pos,0],early_to_late_zero=crossing(ts,tangent[:,0])))
            if branch=="matched":
                number(f"{dx}: early calibration on coefficient scale",peak(tangent[[150,200],2])/peak(pred["fixed"][[150,200],2]))
            def append(kind,amp,delta):
                ref_l=tangent[:,0];meas=delta[:,0]
                err=error(meas,ref_l);landing=abs(meas[-1]/ref_l[-1]-1)
                records.append(dict(dx=dx,branch=branch,method=kind,amplitude=amp,final_coefficient=meas[-1],
                    final_predicted=ref_l[-1],final_relative_error=landing,history_relative_error=err,
                    history_pass=err<=TOL,determinant_vs_ray=error(delta[:,1],meas),zero_linear_clock=crossing(ts,meas)))
                for clock in CLOCKS:
                    row=round(clock/.02)
                    clocks.append(dict(dx=dx,branch=branch,method=kind,amplitude=amp,tau=clock,
                                       predicted=ref_l[row],tested=meas[row],relative_error=abs(meas[row]/ref_l[row]-1)))
            full=coords(burst(dx,1.,"minus" if branch=="fixed" else "calibrated")["rows"])
            append("archived finite difference",1.,full-base)
            for path in sorted(HERE.glob(f"finite-{branch}-d{dx:g}-A*.npz")):
                calc=load(path);amp=float(calc["amp"])
                assert str(calc["prediction"])==FROZEN and np.array_equal(calc["clock"],ts)
                if amp==0.:
                    number(f"{dx}: independent ordinary ruler replay",error(calc["rows"][:,0],base[:,0]))
                    number(f"{dx}: passive magnetic solution vs independent active solution",
                           error(calc["rows"][:,12],coords(burst(dx,0.,"second")["rows"])[:,2]))
                    continue
                raw=(calc["rows"][:,:12]-base)/amp**2
                append("new finite difference",amp,raw)
                if branch=="matched":
                    scale=np.linalg.norm(pred["calibration"],axis=1)
                    number(f"{dx}/{amp}: raw two measured fields",peak((calc["rows"][[150,200],2]-base[[150,200],2])/scale))
            for path in sorted(HERE.glob(f"paired-{branch}-d{dx:g}-A*.npz")):
                if "-to" in path.name:continue
                pair=load(path);hist=pair["history"];amp=float(pair["amp"]);z=amp**2
                assert str(pair["prediction"])==FROZEN and np.array_equal(pair["clock"],ts)
                quotient=hist[:,2,:12]
                append("finite divided equations",amp,quotient)
                number(f"{dx}/{branch}/{amp}: finite divided determinant",error(quotient[:,1],quotient[:,0]))
                number(f"{dx}/{branch}/{amp}: finite divided energy terms",
                       error(integrated(ts,quotient[:,6:12]).sum(axis=1),quotient[:,0]))
                number(f"{dx}/{branch}/{amp}: finite divided vs frozen derivative",error(quotient[:,0],tangent[:,0]))
                if branch=="matched":
                    number(f"{dx}/{amp}: paired early fields on correction scale",peak(quotient[[150,200],2])/peak(pred["fixed"][[150,200],2]))
                direct=load(HERE/f"finite-{branch}-d{dx:g}-A{amp:g}.npz")["rows"]
                for col,label in ((0,"ray"),(2,"field"),(5,"radius"),(8,"direct scalar stress")):
                    number(f"{dx}/{branch}/{amp}: recomposed vs ordinary finite {label}",
                           error(hist[:,0,col]+z*quotient[:,col],direct[:,col]))
    return records,clocks,parts,validation


if __name__=="__main__":
    records,clocks,parts,validation=calculate()
    for name,rows in (("amplitude-tests.csv",records),("per-clock-tests.csv",clocks),
                      ("focusing-contributions.csv",parts),("numerical-checks.csv",validation)):table(name,rows)
    print("structural numerical checks",sum(r["passes"] for r in validation),"/",len(validation))
    for row in validation:
        if not row["passes"]:print("unresolved",row)
    for row in records:
        print(row["dx"],row["branch"],row["method"],row["amplitude"],f'{row["history_relative_error"]:.6g}',
              f'{row["determinant_vs_ray"]:.4g}',row["zero_linear_clock"])
