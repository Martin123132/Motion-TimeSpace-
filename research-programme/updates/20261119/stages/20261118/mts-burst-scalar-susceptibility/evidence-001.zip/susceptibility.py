from pathlib import Path
import os
import sys
import json
import argparse
from types import FunctionType
from contextlib import ExitStack
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
PRE=HERE.parent/"mts-coherent-current-ruler-20261118"
LOCK="916c0276878ada9f754900be0fdf6480407ee11b4f92d6dd0c5fce91a6ac9e7c"
sys.path.insert(0,str(PRE))
from mixed_current import COEFFICIENT, MASS, Centre, law, np, digest, hold as prior_hold, regular, exposure, smooth_launch, signed_equations
from scalar_limit_check import D0, EDGE, EXTENT, ETA, count, shape, background
from launch_variation import robin, mp
from connection import flat_vector
from scipy.integrate import solve_bvp
from scipy.ndimage import correlate1d
from taylor import Taylor, State, ArrayOps, lift

WEIGHTS={"minus":(1.,-COEFFICIENT,0.),"first":(1.,0.,0.),"second":(0.,1.,0.)}


def hold():
    prior_hold()
    if (HERE/"STOP-REQUESTED").exists():raise SystemExit("owner hold")


def check_parent():
    hold();regular.ensure()
    assert digest(PRE/"closeout.json")==LOCK
    manifest=json.loads((PRE/"closeout.json").read_text())["files"]
    for member in ("launch_variation.py","scalar_limit_check.py","mixed_current.py","matched_branch.py","zero-amplitude-launch-forecast.json"):
        assert digest(PRE/member)==manifest[member]


def spin_taylor(label,weights):
    if not isinstance(label,Taylor):return law(label,weights)
    if label.odd is not None and np.any(label.odd):raise AssertionError("material number odd in scalar amplitude")
    ell,primitive=law(label.base,weights)
    frac=np.clip(label.base/MASS,0.,1.);var=2*frac-1
    pol=weights[0]+weights[1]*var+weights[2]*var**2
    first=32*frac**2*(1-frac)**2*(1-2*frac)
    second=64*frac*(1-frac)*((1-2*frac)**2-frac*(1-frac))
    core=(32/3)*frac**3*(1-frac)**3
    change=(second*pol+4*first*(weights[1]+2*weights[2]*var)+8*core*weights[2])/MASS
    return Taylor(ell,None,change*label.even),Taylor(primitive,None,ell*label.even)


def linear(fn,value):
    return value.map(fn) if isinstance(value,Taylor) else fn(value)


def correction(model,weights,solution):
    fun=shape();mass=background(fun,0.)
    limit=.0078125;grid=np.linspace(np.log(limit),np.log(EXTENT),553)
    def coefs(logr):
        rad=np.exp(logr);mu,gain=mass(rad);num=count(rad);charge=ETA*num
        fac=1-2*mu/rad+(charge/rad)**2;root=np.sqrt(fac);inv=1/root
        delta_i=gain/(rad*root**3);den=D0*np.maximum(1-(rad/EDGE)**2,0.)**6
        potential=6+(charge/rad)**2;_,primitive=law(num,weights)
        u,v=solution.sol(logr)
        return inv,rad**2*den+potential*inv,delta_i*v,(potential*delta_i-(rad*fun(rad))**2*inv)*u+(2/3)*primitive**2*delta_i/rad**4
    with mp.workdps(60):
        base,delta=map(mp.mpf,map(float,mass(EXTENT)));charge=mp.mpf(ETA*MASS);edge=mp.mpf(EXTENT)
        beta=float(robin(base,charge,edge));dbeta=float(mp.diff(lambda value:robin(value,charge,edge),base)*delta)
    boundary=dbeta*solution.sol(grid[-1])[0]
    scale=max(np.max(np.abs(coefs(grid)[2:])),abs(boundary),1e-50)
    def rhs(logr,state):
        inv,pot,one,two=coefs(logr)
        return np.array([inv*state[1]+one/scale,-state[1]+pot*state[0]+two/scale])
    sol=solve_bvp(rhs,lambda first,last:[first[1]-2*first[0],last[1]-beta*last[0]-boundary/scale],
                  grid,np.zeros((2,len(grid))),tol=3e-10,max_nodes=16000)
    assert sol.success,sol.message
    rad=model.rad;inside=np.minimum(1,rad/limit)**2
    coord=np.log(np.maximum(rad[:,0],limit))
    u=solution.sol(coord)[0][:,None]*inside
    deriv=scale*sol.sol(coord)[0][:,None]*inside
    mu,gain=mass(rad[:,0]);mu=mu[:,None];gain=gain[:,None]
    fac=1-2*mu/rad+(ETA*count(rad)/rad)**2
    one=np.zeros_like(model.y0);two=np.zeros_like(one)
    one[8]=fun(rad)
    two[0]=2*gain/rad*(1+4*regular.DUAL*u*regular.POL)/fac**2+4*regular.DUAL*deriv*regular.POL/fac
    two[2]=two[3]=4*regular.DUAL*deriv*regular.POL
    two[23]=gain/rad**3
    one=model.cap.project(one);two=model.cap.project(two)
    vx,vt=flat_vector(model,*model.extend(two)[:4]);two[21]=vx[model.ghost:];two[22]=vt[model.ghost:]
    return one,two,-2*rad*deriv,scale*sol.sol(np.log(6.))


class Evolution:
    def __init__(self,dx,tag):
        check_parent();self.tag=tag;self.weights=WEIGHTS[tag]
        self.model=Centre(dx,ETA,0.,cap=12,reduced=True,damping=.5,mass_form=True)
        self.model.profile=self.weights;source=[]
        solve=smooth_launch.solve
        def remember(*args,**kwargs):
            res=solve(*args,**kwargs);source.append(res[0]);return res
        with patch.object(smooth_launch,"spin",law),patch.object(smooth_launch,"solve",remember):
            smooth_launch.refresh(self.model,ETA,0.,False,self.weights)
        one,two,self.shift2,self.seed=correction(self.model,self.weights,source[0])
        self.initial=np.stack([self.model.y0,one,two]);self.shift=Taylor(self.model.shift,None,self.shift2)
        self.stencil=np.array([1,-8,28,-56,70,-56,28,-8,1])/256
        context=dict(exposure.terms.__globals__,spin=spin_taylor,float=lambda value:value)
        self.terms=FunctionType(exposure.terms.__code__,context)
        self.extfilter=lambda arr:correlate1d(arr,self.stencil,axis=1,mode="nearest")

    def __getattr__(self,key):return getattr(self.model,key)
    def dr(self,field):return linear(self.model.dr,field)
    def drr(self,field):return linear(self.model.drr,field)
    def atsite(self,field):return linear(self.model.atsite,field)
    def contrast(self,value):
        return 1.5*self.atsite(regular.coeff(value.imag)[:,0]/regular.EPS+self.shift[:,0]*self.dr(value.real[:,:1])[:,0])

    def patches(self):
        context=ExitStack()
        context.enter_context(patch.object(signed_equations,"spin",spin_taylor))
        context.enter_context(patch.object(signed_equations,"np",ArrayOps()))
        context.enter_context(patch.object(signed_equations,"correlate1d",lambda field,*args,**kw:linear(lambda v:correlate1d(v,*args,**kw),field)))
        return context

    def rhs(self,levels):
        extended=[self.model.extend(arr) for arr in levels]
        rates=signed_equations.field_rates(self,State(*extended))
        return np.stack([self.cap.project((rate-self.damping/self.dx*self.extfilter(orig)*self.mask)[:,self.ghost:])
                         for rate,orig in zip((rates.base,rates.odd,rates.even),extended)])

    def read(self,levels,initial):
        jet=State(*levels);rad=self.rad*np.sqrt(1+jet[2].real[:,:1]);amag=np.sqrt(1+jet[0].real[:,:1])
        signal=self.contrast(jet[17]);metric=self.contrast(self.model.logmetric(jet)-initial)
        fields=[self.atsite(val[:,0]) for val in (2*jet[19].real[:,:1]/rad**2,-jet[20].real[:,:1]/(amag*rad),
                -self.dr(jet[19].real[:,:1])/(amag*rad),rad)]
        vals=[signal,metric,*fields,*self.terms(self,jet),self.atsite(jet[8][:,0].real)]
        return np.array([[float(getattr(v,level)) if getattr(v,level) is not None else 0. for v in vals] for level in ("base","odd","even")])


def advance(dx,tag,end=6.4):
    model=Evolution(dx,tag);levels=model.initial.copy();initial=model.model.logmetric(State(*levels))
    target=HERE/f"tangent-{tag}-d{dx:g}-to{end:g}.npz"
    if target.exists() or target.with_suffix(".partial").exists():raise FileExistsError(target)
    history=[]
    count_steps=int(np.ceil(.02/(.30*dx)-1e-12));dt=.02/count_steps
    with model.patches():
        for tick in range(round(end/.02)+1):
            hold();history.append(model.read(levels,initial))
            if not np.isfinite(history[-1]).all():raise FloatingPointError(tick)
            if tick==round(end/.02):break
            for _ in range(count_steps):
                first=model.rhs(levels);second=model.rhs(levels+dt/2*first)
                third=model.rhs(levels+dt/2*second);fourth=model.rhs(levels+dt*third)
                levels+=dt/6*(first+2*second+2*third+fourth)
    assert np.isfinite(levels).all() and not np.any(levels[1,[n for n in range(24) if n not in (8,9)]]) and not np.any(levels[2,8:10])
    partial=target.with_suffix(".partial")
    with partial.open("xb") as stream:np.savez_compressed(stream,history=history,clock=.02*np.arange(len(history)),seed=model.seed,
                columns="ray metric B E_trans B_trans R shear twist scalar polar_E dipole material H".split(),parent=LOCK,dx=dx,tag=tag)
    partial.rename(target)
    print(target.name,np.array(history)[-1,2,:3],flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("dx",type=float);parser.add_argument("tag",choices=WEIGHTS)
    parser.add_argument("--end",type=float,default=6.4);advance(**vars(parser.parse_args()))
