from setup_stage import *
import csv

def reference():
    guard()
    receipt=read("forecast-receipt.json")
    assert receipt["reference_not_yet_generated"] and all(sha(ROOT/name)==value for name,value in receipt["files"].items())
    src=native()
    with np.load(ROOT/"driver.npz") as driver,np.load(TABLE) as table:
        modes=driver["modes"];tau=driver["tau"]
        exact=src.camb.get_background(src.params_for(BG));exact.Params.Accuracy.IntTolBoost=6
        keys=["a","H","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count","growth","v_baryon_cdm","delta_cdm","delta_baryon","etak","delta_photon","delta_neutrino","delta_nu","mts_drho_s"]
        values=exact.get_time_evolution(modes,tau,vars=keys,lAccuracyBoost=4)
        col=lambda key:values[:,:,keys.index(key)]
        assert np.array_equal(col("a")[0],driver["a"]) and not np.any(col("mts_match_count"))
        scale=driver["a"]; density=exact.get_background_densities(scale.copy(),vars=list(OTHER))
        environment=modes[:,None]*col("etak")+.5*(sum(density[key]*col("delta_"+key) for key in OTHER)/scale**2+col("mts_drho_s"))
        fraction=density["baryon"]/(density["baryon"]+density["cdm"])
        kz_growth=-col("growth")*col("H")*((1-fraction)*col("delta_cdm")+fraction*col("delta_baryon"))-modes[:,None]*fraction*col("v_baryon_cdm")
        kz_constraint=(environment+.5*col("mts_drho_h"))/col("H")
        controls={}
        for case in ("cold","lcdm"):
            params=src.params_for(COLD)
            if case=="lcdm":
                params.DarkEnergy=src.camb.dark_energy.DarkEnergyFluid()
            model=src.camb.get_background(params);model.Params.Accuracy.IntTolBoost=6
            times=model.conformal_time(1/np.array([value[0] for value in config()[:5]])-1,tol=1e-10)
            ctr=model.get_time_evolution(modes,times,vars=["mts_drho_h","mts_q_h","mts_dp_h","delta_cdm","delta_baryon","Weyl"],lAccuracyBoost=4)
            assert np.isfinite(ctr).all() and not np.any(ctr[:,:,:3]) and np.all(np.max(abs(ctr[:,:,3:]),axis=1)>0)
            controls[case]=ctr
        packet("direct.npz",scale=scale,raw=np.stack([col(key)*scale/float(driver["rho"]) for key in ("mts_drho_h","mts_q_h","mts_dp_h")],axis=-1),true_env=environment,kZ_constraint=kz_constraint,kZ_continuity=kz_growth,**controls)
        print("Reference and common-metric cold controls saved",flush=True)

def score():
    guard()
    rows=[]
    with np.load(ROOT/"driver.npz") as driver,np.load(ROOT/"frozen.npz") as pred,np.load(ROOT/"direct.npz") as direct,np.load(TABLE) as table:
        modes=driver["modes"];mass=float(driver["mass"])
        for idx,conf in enumerate(config()):
            use,weights=basis(driver["a"],conf,table)
            truth=np.einsum("t,ktj->kj",weights,direct["raw"][:,use])
            hbar=weights@driver["H"][use]
            norm,qnorm=norms(modes,conf,mass,*truth[:,:2].T,hbar)
            old=expected(modes,conf,mass,*truth[:,:2].T,hbar)
            forecast=pred["pred_returned_1"][idx];half=pred["pred_returned_2"][idx]
            base=expected(modes,conf,mass,*forecast[:,:2].T,hbar)
            result=dict(old_signed=(truth[:,2]-old)/norm,forecast_old_defect=(forecast[:,2]-base)/norm,
                autonomous_p=(forecast[:,2]-truth[:,2])/norm,autonomous_d=(forecast[:,0]-truth[:,0])/norm,
                autonomous_q=(forecast[:,1]-truth[:,1])/qnorm,autonomous_defect=(forecast[:,2]-base-truth[:,2]+old)/norm,
                step_p=(forecast[:,2]-half[:,2])/norm,step_d=(forecast[:,0]-half[:,0])/norm,step_q=(forecast[:,1]-half[:,1])/qnorm)
            for variant in ("returned","prescribed","unforced"):
                coef=pred["coef_"+variant+"_1"][idx];bias=pred["bias_"+variant+"_1"][idx]
                local=np.sum(coef*truth[:,:2],axis=1)+bias
                result["map_"+variant]=(local-truth[:,2])/norm
                result["time_"+variant]=(pred["pred_"+variant+"_1"][idx,:,2]-truth[:,2])/norm
                if variant=="returned":
                    probe=pred["coef_returned_2"][idx]; bprobe=pred["bias_returned_2"][idx]
                    result["map_step"]=(local-np.sum(probe*truth[:,:2],axis=1)-bprobe)/norm
                    result["weight_d"]=coef[:,0];result["weight_q"]=coef[:,1];result["offset"]=bias
            for num,mode in enumerate(modes):
                row=dict(surface=TAGS[idx],a=conf[0],k=float(mode),mode_norm=norm[num],current_norm=qnorm[num],
                    d_actual=truth[num,0],q_actual=truth[num,1],p_actual=truth[num,2],p_forecast=forecast[num,2])
                row.update({key:float(array[num]) for key,array in result.items()});rows.append(row)
        groups={tag:{key:max(abs(row[key]) for row in rows if row["surface"]==tag) for key in ("old_signed","autonomous_p","autonomous_d","autonomous_q","autonomous_defect","map_returned","map_prescribed","map_unforced","step_p","map_step")} for tag in TAGS}
        kz=direct["kZ_constraint"];trace_test=np.max(abs(kz-direct["kZ_continuity"]),axis=1)/np.max(abs(kz),axis=1)
        envtest=np.max(abs(driver["environment"]-direct["true_env"]),axis=1)/np.max(abs(direct["true_env"]),axis=1)
    with (ROOT/"pressure.csv").open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    write("score.json",dict(maximum=groups,trace_source_control=trace_test.tolist(),external_source_approximation=envtest.tolist(),freeze=sha(ROOT/"forecast-receipt.json"),reference=sha(ROOT/"direct.npz")))
    for key,group in groups.items():
        print(key," ".join(f"{name}={value:.3g}" for name,value in group.items()),flush=True)
if __name__=="__main__":
    if sys.argv[1]=="reference":
        reference()
    elif sys.argv[1]=="score":
        score()

