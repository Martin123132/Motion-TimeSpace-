from setup_stage import *
import csv
def verify():
    guard();checks=[]
    def require(label,condition):
        if not condition: raise ValueError(label)
        checks.append(label)
    def rows(name):
        with (ROOT/name).open(newline="",encoding="utf8") as stream:return list(csv.DictReader(stream))
    first=read("forecast-receipt.json");second=read("trace-forecast.json")
    for name,receipt in (("original",first),("trace",second)):
        require(name+" frozen files intact",all((ROOT/key).is_file() and sha(ROOT/key)==val for key,val in receipt["files"].items()))
    require("original blind prediction",first["reference_not_yet_generated"])
    require("new metric prediction outside original data and before truth",second["no_direct_reference_beyond_previous_endpoint"])
    require("first direct outputs sealed",read("score.json")["reference"]==sha(ROOT/"direct.npz"))
    require("second direct outputs sealed",read("trace-score.json")["truth"]==sha(ROOT/"trace-truth.npz"))
    protected={**read("driver.json")["files"],**read("observer.json")["inputs"]}
    for src in (SPEC/"runs/projection/a225-w6-d8.npz",SPEC/"runs/projection/a250-w6-d8.npz",PRIOR/"build.json",PRIOR/"build-leading.json",PRIOR/"forest-radial-inputs.csv",PRIOR/"heavy-on-fine-z99-radial/result.npz",PRIOR/"engine/native/camb/cambdll.dll",PRIOR/"engine-leading/native/camb/cambdll.dll"):
        expected_hash=json.loads((PRIOR/"closeout.json").read_text())
        relative=src.relative_to(PRIOR).as_posix() if src.is_relative_to(PRIOR) else ""
        known=expected_hash["files"].get(relative)
        if known:require(relative+" parent fingerprints",sha(src)==known)
        protected[str(src)]=sha(src)
    require("original scientific files and compiler inputs",all(sha(Path(key))==value for key,value in protected.items()))
    require("private observer binary",sha(ROOT/"observer/native/camb/cambdll.dll")==read("observer.json")["binary"])
    require("no compiler staging or bytecode",not (ROOT/"observer-compile").exists() and not list(ROOT.rglob("__pycache__")))
    with np.load(ROOT/"driver.npz") as dr,np.load(ROOT/"trace-driver.npz") as tr,np.load(TABLE) as tb:
        require("blind target entirely beyond first run",tr["a"][basis(tr["a"],(.00026,6,8),tb)[0][0]]>dr["a"][-1])
        initial=basis(dr["a"],config()[0],tb)[0]
        require("initial conditioning window separate from two first target windows",all(initial[-1]<basis(dr["a"],config()[idx],tb)[0][0] for idx in (1,3)))
    data=rows("trace-tests.csv");term=rows("pressure-origin.csv");forest=rows("forest-high-radial.csv")
    require("32 pressure decompositions and 96 trace tests",len(term)==32 and len(data)==96)
    primary=[r for r in data if r["stride"]=="1" and r["pressure_gravitates"]=="1"]
    for key,limit in (("error_P",2e-6),("error_Q",2e-5),("error_D",2e-5),("error_map",2e-6)):
        require("all returned "+key,max(abs(float(r[key])) for r in primary)<limit)
    require("uncorrected failures preserved",sum(abs(float(r["original_error"]))>=2e-6 for r in primary if r["surface"]=="a200")==3)
    require("density-only return rejected",read("score.json")["maximum"]["ind2125"]["autonomous_d"]>2e-5)
    require("signed quantities reconstructed without changing tolerance",all(abs(float(r["sum"])-float(r["observed_field_defect"]))<2e-6 for r in term))
    exp=read("experiment.json")
    require("32/32 prospective simple-pressure classifications",all((r["old_law_eligible_on_pressure"]=="True")==(abs(float(r["observed_field_defect"]))<2e-6) for r in term))
    require("step controls",all(r["max_pressure_step"]<2e-6 and r["max_current_step"]<2e-5 for r in exp["frozen_metric_forecasts"]))
    for case,record in read("trace-score.json")["controls"].items():
        require(case+" direct Einstein trace",max(record["trace_integral_error"])<2e-5)
        if case!="heavy":require(case+" no heavy pressure",record["max_heavy_pressure"]==0)
    require("highest seven row mapping",len(forest)==7 and len(set(r["k_fixed"] for r in forest))==4)
    require("both switches and stock comparison",all(max(values.values())<2e-5 for values in exp["late"].values()))
    require("prior k=5 overlap",max(exp["anchor5"].values())<2e-5)
    for case,variants in (("heavy",("off","leading")),("cold",("off",)),("lcdm",("off",))):
        for arm in variants:
            after=ROOT/f"restart-{case}-{arm}";on=ROOT/f"restart-{case}-on"
            starts=list(on.glob("initial-*.bin"))
            require(case+"/"+arm+" complete state identity",len(starts)==5 and all(p.read_bytes()==(after/p.name).read_bytes() for p in starts))
            if case!="heavy":
                with np.load(on/"fields.npz") as left,np.load(after/"fields.npz") as right:
                    require(case+" pressure intervention null",np.array_equal(left["raw"],right["raw"]))
    require("off vs leading stress discrimination",all(float(r["force_off_over_on_minus_one"])>1 for r in forest) and exp["leading_error"]<2e-5)
    require("no inferred flux likelihood",exp["linear_only"] and not exp["scored_flux"])
    seal=ROOT/"closeout.json"
    files={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(ROOT.rglob("*")) if p.is_file() and p!=seal}
    if sys.argv[1:]==["--seal"]:
        write("closeout.json",dict(checks=checks,files=files,protected=protected,previous=PROTECTED))
    else:
        saved=read("closeout.json")
        require("entire sealed directory unchanged",saved["files"]==files)
        require("all saved external inputs unchanged",saved["protected"]==protected)
    print(len(checks),"checks;",len(files),"files;",len(protected),"source fingerprints;",sha(seal))
if __name__=="__main__":
    verify()

