from setup_stage import *
from late import REDS
def run(case,arm):
    guard()
    assert case in ("heavy","cold","lcdm") and arm in ("on","off","leading") and (arm!="leading" or case=="heavy")
    with np.load(ROOT/"late-225pred.npz") as first,np.load(ROOT/"late-250pred.npz") as second:
        assert all(np.max(abs(second[key][1:]/first[key][1:]-1))<2e-5 for key in ("force","gas","velocity"))
    for key,value in dict(MTS_FOREST_INDEX="1",MTS_FOREST_FACTOR="1" if arm=="on" else "0",MTS_FOREST_SCALE="0.01").items():
        assert os.environ.get(key)==value,"set the switch variables before process creation"
    directory=ROOT/("restart-"+case+"-"+arm); directory.mkdir(exist_ok=True)
    assert not list(directory.iterdir())
    os.chdir(directory)
    tag="-leading" if arm=="leading" else ""
    sys.path[:0]=[str(PRIOR/("engine"+tag)),str(BASE/"radiation-and-slow-field-transfer-20261007")]
    import matching_common as source
    assert sha(Path(source.camb.__file__).parent/"cambdll.dll")==json.loads((PRIOR/("build"+tag+".json")).read_text())["binary"]
    with np.load(ROOT/"late-225pred.npz") as orig,np.load(ROOT/"trace-frozen.npz") as forecast,np.load(SPEC/"runs/projection/a225-w6-d8.npz") as match:
        modes=orig["modes"]
        params=source.params_for(SPEC/"runs/projection/a225-w6-d8.npz" if case=="heavy" else COLD)
        if case=="heavy":
            idx=np.flatnonzero(match["modes"]==5.).item()
            initial=np.vstack([[match["matching_delta"][idx],match["matching_momentum"][idx]],forecast["pred_1_1"][2,:,:2]])
            params.DarkEnergy.set_table("SetMatching",modes,*initial.T)
        elif case=="lcdm":
            params.DarkEnergy=source.camb.dark_energy.DarkEnergyFluid()
        params.DoLateRadTruncation=False
        model=source.camb.get_background(params);model.Params.Accuracy.IntTolBoost=6.4
        times=model.conformal_time(REDS,tol=1e-10);names=orig["names"].tolist()
        raw=model.get_time_evolution(modes,times,vars=names,lAccuracyBoost=4)
        get=lambda name:raw[:,:,names.index(name)]
        assert np.isfinite(raw).all() and np.all(get("mts_match_count")==(case=="heavy"))
        assert not np.any(get("mts_nonheavy_change")) and len(list(directory.glob("initial-*.bin")))==len(modes)
        phi=get("etak")/modes[:,None]+(get("H")/modes[:,None])**2*get("v_newtonian_cdm")
        packet(directory.name+"/fields.npz",modes=modes,z=REDS,names=names,raw=raw,force=-2*get("Weyl")+modes[:,None]**2*phi,gas=get("delta_baryon")+3*(get("H")/modes[:,None])**2*get("v_newtonian_cdm"),velocity=get("v_newtonian_baryon"))
        print("Saved",case,arm)
if __name__=="__main__":
    run(*sys.argv[1:])

