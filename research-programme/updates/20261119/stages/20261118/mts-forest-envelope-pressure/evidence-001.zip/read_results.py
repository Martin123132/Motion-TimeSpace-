from setup_stage import *
from trace_map import EXTRA
import csv
def csv_out(name,rows):
    with (ROOT/name).open("x",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0])); writer.writeheader();writer.writerows(rows)
def fields(name):
    with np.load(ROOT/name) as data:
        return dict(data)
def measure():
    guard()
    driver=fields("trace-driver.npz"); exact=fields("trace-truth.npz"); forecast=fields("trace-frozen.npz");check=[]
    initial=fields("driver.npz");tab=fields("frozen.npz")
    modes=driver["modes"]
    terms=[];counts={};primary=forecast["pred_1_1"];coarse=forecast["pred_2_1"]
    with np.load(TABLE) as table,np.load(INPUT) as original:
        for idx,(label,conf) in enumerate(zip([*TAGS,"ind2600"],[*config(),EXTRA])):
            samples,weights=basis(driver["a"],conf,table);hubble=weights@driver["H"][samples]
            direct=np.einsum("t,ktj->kj",weights,exact["actual"][:,samples]);den,qn=norms(modes,conf,driver["mass"],*direct[:,:2].T,hubble)
            coeff=forecast["coef_1_1"][idx];offset=forecast["bias_1_1"][idx]; ratio=modes/(conf[0]*driver["mass"]);sound=(ratio/(1+np.sqrt(1+ratio**2)))**2
            pred=primary[idx];old=expected(modes,conf,driver["mass"],*direct[:,:2].T,hubble)
            delta=np.column_stack([(coeff[:,0]-sound)*direct[:,0],(coeff[:,1]-3*hubble*sound/modes)*direct[:,1],offset])/den[:,None]
            predicted_def=(pred[:,2]-expected(modes,conf,driver["mass"],*pred[:,:2].T,hubble))/den
            step=abs((pred[:,2]-coarse[idx,:,2])-(expected(modes,conf,driver["mass"],*pred[:,:2].T,hubble)-expected(modes,conf,driver["mass"],*coarse[idx,:,:2].T,hubble)))/den
            status=(abs(predicted_def)+step<2e-6)
            counts[label]=int(sum(status))
            signed=(direct[:,2]-old)/den
            assert max(abs(np.sum(delta,axis=1)-signed))<2e-6
            assert np.all((abs(signed)<2e-6)==status)
            if idx in (0,2,4,5,6):
                prior_idx={0:1,2:0,4:2,5:3,6:4}[idx]
                assert np.max(abs(abs(signed)-original["closure"][prior_idx,-4:]))<3e-9
            assert np.max(abs(primary[idx]-direct)/np.column_stack([2e-5*den,2e-5*qn,2e-6*den]))<1
            check.append(dict(tag=label,max_time_density=max(abs(pred[:,0]-direct[:,0])/den),max_time_current=max(abs(pred[:,1]-direct[:,1])/qn),max_time_pressure=max(abs(pred[:,2]-direct[:,2])/den),max_closure_inference=max(abs(delta.sum(axis=1)-signed)),max_pressure_step=max(abs(pred[:,2]-coarse[idx,:,2])/den),max_current_step=max(abs(pred[:,1]-coarse[idx,:,1])/qn)))
            for j,mode in enumerate(modes):
                terms.append(dict(center=label,k=mode,observed_field_defect=signed[j],predicted_defect=predicted_def[j],signed_density_part=delta[j,0],signed_momentum_part=delta[j,1],signed_external_part=delta[j,2],sum=delta[j].sum(),time_refinement_allowance=step[j],old_law_eligible_on_pressure=bool(status[j])))
    csv_out("pressure-origin.csv",terms)
    runs={name:fields("late-"+name+".npz") for name in ("225pred","225direct","250pred","250direct","225tight","cold","lcdm","lcdm-mapped")}
    arms={(case,arm):fields("restart-"+case+"-"+arm+"/fields.npz") for case,variants in (("heavy",("on","off","leading")),("cold",("on","off")),("lcdm",("on","off"))) for arm in variants}
    identical={}
    for case in ("heavy","cold","lcdm"):
        on=ROOT/f"restart-{case}-on";variants=("off","leading") if case=="heavy" else ("off",)
        for arm in variants:
            other=ROOT/f"restart-{case}-{arm}"
            first=sorted(on.glob("initial-*.bin"));second=sorted(other.glob("initial-*.bin"))
            assert len(first)==len(second)==5 and all(one.name==two.name and one.read_bytes()==two.read_bytes() for one,two in zip(first,second))
            for file in first:
                payload=file.read_bytes();count=int.from_bytes(payload[:4],"little",signed=True);array=np.frombuffer(payload[4:],dtype="<f8")
                assert len(array)==count+3 and array[0] in runs["225pred"]["modes"] and abs(array[2]/.01-1)<2e-5
            identical[case+"-"+arm]=len(first)
            if case!="heavy":assert np.array_equal(arms[case,"on"]["raw"],arms[case,arm]["raw"])
    with (PRIOR/"forest-radial-inputs.csv").open() as stream:
        bins=[r for r in csv.DictReader(stream) if float(r["k_parent"])>5]
    assert len(bins)==7
    rows=[];all_rows=[];summary={}
    keys=("force","gas","velocity");first=runs["225pred"]
    old5=np.load(PRIOR/"heavy-on-fine-z99-radial/result.npz")
    oldnames=old5["names"].tolist();kidx=np.flatnonzero(old5["k"]==5.).item();indices=[np.flatnonzero(old5["z"]==red).item() for red in first["z"]]
    h5=lambda name:old5["raw"][kidx,indices,oldnames.index(name)]
    phi5=h5("etak")/5+(h5("H")/5)**2*h5("v_newtonian_cdm")
    my5=arms["heavy","on"]
    anchors={key:float(np.max(abs(my5[key][0]/old-1))) for key,old in zip(keys,[-2*h5("Weyl")+25*phi5,h5("delta_baryon")+3*(h5("H")/5)**2*h5("v_newtonian_cdm"),h5("v_newtonian_baryon")])}
    assert max(anchors.values())<2e-5
    for key in keys:
        frac=lambda a,b:float(np.max(abs(a/b-1)))
        summary[key]=dict(interface=frac(runs["250pred"][key][1:],first[key][1:]),seeds225=frac(runs["225direct"][key][1:],first[key][1:]),
            seeds250=frac(runs["250direct"][key][1:],runs["250pred"][key][1:]),tight=frac(runs["225tight"][key][1:],first[key][1:]),restart=frac(arms["heavy","on"][key][1:],first[key][1:]))
        assert max(summary[key].values())<2e-5
    for i,mode in enumerate(first["modes"]):
        for t,red in enumerate(first["z"]):
            row=dict(k_fixed=mode,z=red)
            for key in keys:
                ref=arms["heavy","on"][key][i,t]
                row[key+"_on"]=ref;row[key+"_off"]=arms["heavy","off"][key][i,t]
                row[key+"_off_over_on_minus_one"]=row[key+"_off"]/ref-1
                row[key+"_leading_over_on_minus_one"]=arms["heavy","leading"][key][i,t]/ref-1
                row[key+"_on_over_cold"]=ref/arms["cold","on"][key][i,t]
                row[key+"_on_over_lcdm"]=ref/arms["lcdm","on"][key][i,t]
            all_rows.append(row)
    for obs in bins:
        mode=float(obs["k_parent"]);red=float(obs["z"]);i=np.flatnonzero(first["modes"]==mode).item();t=np.flatnonzero(first["z"]==red).item()
        row=next(r for r in all_rows if r["k_fixed"]==mode and r["z"]==red)
        assert runs["lcdm-mapped"]["modes"][i]==float(obs["k_lcdm"])
        rows.append(dict(instrument=obs["instrument"],k_velocity=obs["kv_s_per_km"],k_lcdm_mapped=float(obs["k_lcdm"]),**row,gas_amplitude_over_mapped_lcdm=first["gas"][i,t]/runs["lcdm-mapped"]["gas"][i,t]))
    csv_out("late-transfers.csv",all_rows);csv_out("forest-high-radial.csv",rows)
    write("experiment.json",dict(frozen_metric_forecasts=check,cheap_pressure_pass_counts=counts,late=summary,anchor5=anchors,same_binary_states=identical,
        highest_bins=len(rows),linear_only=True,scored_flux=False,off_force_range=[min(abs(r["force_off_over_on_minus_one"]) for r in rows),max(abs(r["force_off_over_on_minus_one"]) for r in rows)],
        leading_error=max(abs(r[key+"_leading_over_on_minus_one"]) for r in rows for key in keys),
        gas_transfer_power_ratio_range=[min(r["gas_on_over_cold"]**2 for r in rows),max(r["gas_on_over_cold"]**2 for r in rows)]))
    print(json.dumps({key:read("experiment.json")[key] for key in ("cheap_pressure_pass_counts","late","anchor5","off_force_range","leading_error","gas_transfer_power_ratio_range")},indent=2))
if __name__=="__main__":
    measure()

