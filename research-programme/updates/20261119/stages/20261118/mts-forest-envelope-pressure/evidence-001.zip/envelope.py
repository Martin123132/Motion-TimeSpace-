from setup_stage import *
from numpy.polynomial import Polynomial

def gauss():
    node=(np.polynomial.legendre.leggauss(4)[0]+1)/2
    matrix=[];weights=[]
    for idx in range(len(node)):
        poly=Polynomial.fromroots(np.delete(node,idx))
        primitive=(poly/poly(node[idx])).integ()
        matrix.append(primitive(node)-primitive(0))
        weights.append(primitive(1)-primitive(0))
    return node,np.array(matrix).T,np.array(weights)

def propagators(driver,table,stride,variant):
    tau,scale,hubble,modes=(driver[key] for key in ("tau","a","H","modes"))
    mass=float(driver["mass"]);freq=config()[0][0]*mass
    time=CubicSpline(tau,scale); hc=CubicSpline(tau,hubble)
    field=CubicSpline(table["heavy_efold"],table["phi_h"])
    velocity=CubicSpline(table["heavy_efold"],table["phidot_h"])
    env=CubicSpline(tau,driver["environment"],axis=1)
    kz=CubicSpline(tau,driver["averaged_kZ"],axis=1)
    use=np.arange(0,len(tau),stride); assert use[-1]==len(tau)-1
    grid=tau[use]; step=np.diff(grid)
    nodes,collocation,weight=gauss()
    times=grid[:-1,None]+step[:,None]*nodes
    scale_q=time(times); hc_q=hc(times); phi=field(np.log(scale_q)); vel=velocity(np.log(scale_q))
    mass2=(mass*scale_q)**2
    result=[]
    for index,mode in enumerate(modes):
        constant=np.zeros((*times.shape,2,2))
        constant[:,:,0,1]=freq
        constant[:,:,1,0]=-(mode**2+mass2)/freq
        constant[:,:,1,1]=-2*hc_q
        forcing=np.zeros((*times.shape,2))
        if variant=="returned":
            constant[:,:,1,0]-=vel*mass2*phi/(2*hc_q*freq)
            constant[:,:,1,1]-=vel**2/(2*hc_q)
            forcing[:,:,1]=-vel*env(times)[index]/(hc_q*freq)
        elif variant=="prescribed":
            forcing[:,:,1]=-vel*kz(times)[index]/freq
        else:
            assert variant=="unforced"
        blocks=step[:,None,None,None,None]*collocation[None,:,None,:,None]*constant.transpose(0,2,1,3)[:,None,:,:,:]
        system=np.eye(8)[None,:,:]-blocks.reshape(-1,8,8)
        rhs=np.zeros((len(step),4,2,3));rhs[:,:,:,0:2]=np.eye(2)
        rhs[:,:,:,2]=step[:,None,None]*np.einsum("ij,tjl->til",collocation,forcing)
        stages=np.linalg.solve(system,rhs.reshape(-1,8,3)).reshape(-1,4,2,3)
        slopes=constant@stages; slopes[:,:,:,-1]+=forcing
        transfers=step[:,None,None]*np.einsum("s,tsij->tij",weight,slopes)
        transfers[:,:,:2]+=np.eye(2)
        total=np.zeros((len(grid),2,3));total[0,:,:2]=np.eye(2)
        for pos,local in enumerate(transfers):
            total[pos+1]=local[:,:2]@total[pos]
            total[pos+1,:,-1]+=local[:,-1]
        result.append(total)
    return np.array(result),use

def stress(driver,table,state,use):
    scale=driver["a"][use];mass=float(driver["mass"]);rho=float(driver["rho"]);modes=driver["modes"]
    freq=config()[0][0]*mass
    phi=CubicSpline(table["heavy_efold"],table["phi_h"])(np.log(scale))
    vel=CubicSpline(table["heavy_efold"],table["phidot_h"])(np.log(scale))
    kinetic=(scale*vel*freq/rho)[None,:,None]*state[:,:,1,:]
    potential=(scale**3*mass**2*phi/rho)[None,:,None]*state[:,:,0,:]
    current=modes[:,None,None]*(scale*vel/rho)[None,:,None]*state[:,:,0,:]
    return np.stack((kinetic+potential,current,kinetic-potential),axis=2)

def evaluate(driver,table,stride,variant):
    state,use=propagators(driver,table,stride,variant)
    output=stress(driver,table,state,use)
    maps=[]; avg_h=[]
    for conf in config():
        selected,weights=basis(driver["a"][use],conf,table)
        maps.append(np.einsum("t,ktij->kij",weights,output[:,selected]))
        avg_h.append(np.dot(weights,driver["H"][use][selected]))
    maps=np.array(maps); avg_h=np.array(avg_h)
    matrix=maps[:,:,:2,:2]
    cond=np.linalg.cond(matrix/np.linalg.norm(matrix,axis=-1,keepdims=True))
    assert np.max(cond)<30
    initial=np.linalg.solve(matrix[0],(driver["initial"]-maps[0,:,:2,2])[...,None])[...,0]
    predictions=(maps[:,:,:,:2]@initial[None,:,:,None])[...,0]+maps[:,:,:,2]
    coef=np.linalg.solve(matrix.transpose(0,1,3,2),maps[:,:,2,:2,None])[...,0]
    bias=maps[:,:,2,2]-np.einsum("cki,cki->ck",coef,maps[:,:,:2,2])
    return predictions,coef,bias,avg_h,cond

def main():
    guard()
    assert sha(ROOT/"driver.npz")==read("driver.json")["driver"]
    with np.load(ROOT/"driver.npz") as driver,np.load(TABLE) as table:
        results={}
        for stride,variant in [(1,"returned"),(2,"returned"),(1,"prescribed"),(1,"unforced")]:
            preds,coef,bias,hubble,cond=evaluate(driver,table,stride,variant)
            results.update({f"{name}_{variant}_{stride}":data for name,data in (("pred",preds),("coef",coef),("bias",bias),("H",hubble),("cond",cond))})
        packet("frozen.npz",modes=driver["modes"],centers=[item[0] for item in config()],**results)
    write("forecast-receipt.json",dict(files={name:sha(ROOT/name) for name in ("PROTOCOL.md","setup_stage.py","prepare.py","driver.json","driver.npz","envelope.py","frozen.npz")},independent=["ind2125","ind2375"],reference_not_yet_generated=not (ROOT/"direct.npz").exists()))
    print("Froze predictions",sha(ROOT/"frozen.npz"),flush=True)
if __name__=="__main__":
    main()

