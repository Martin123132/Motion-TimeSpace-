from setup_stage import *
from trace_map import EXTRA
from scipy.integrate import cumulative_simpson
import csv

def test():
    guard();receipt=read("trace-forecast.json")
    assert receipt["no_direct_reference_beyond_previous_endpoint"] and all(sha(ROOT/key)==value for key,value in receipt["files"].items())
    sys.path.insert(0,str(ROOT/"observer"));sys.path.append(str(BASE/"radiation-and-slow-field-transfer-20261007"))
    import matching_common as src
    assert sha(Path(src.camb.__file__).parent/"cambdll.dll")==read("observer.json")["binary"]
    rows=[];control={};arrays={};tags=[*TAGS,"ind2600"]
    with np.load(ROOT/"trace-driver.npz") as driver,np.load(ROOT/"trace-frozen.npz") as pred,np.load(TABLE) as table:
        modes=driver["modes"];rho=float(driver["rho"]);mass=float(driver["mass"])
        columns=["a","H","etak","growth","v_baryon_cdm",*["delta_"+key for key in OTHER],"mts_drho_s","mts_dp_s","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count","delta_tot_de","v_newtonian_baryon"]
        for case in ("heavy","cold","lcdm"):
            params=src.params_for(BG if case=="heavy" else COLD)
            if case=="lcdm":
                params.DarkEnergy=src.camb.dark_energy.DarkEnergyFluid()
            engine=src.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6
            if case=="heavy":
                tau=driver["tau"]
            else:
                ends=engine.conformal_time(1/driver["a"][[0,-1]]-1,tol=1e-10)
                tau=np.linspace(*ends,len(driver["a"]))
            direct=engine.get_time_evolution(modes,tau,vars=columns,lAccuracyBoost=4)
            get=lambda name:direct[:,:,columns.index(name)]
            scale=get("a")[0].copy();h=get("H")[0];assert not np.any(get("mts_match_count"))
            dens=engine.get_background_densities(scale,vars=list(OTHER))
            parts={key:dens[key]*get("delta_"+key)/scale**2 for key in OTHER}
            other=sum(parts.values())+get("mts_drho_s")
            trace=.5*(other+parts["photon"]+parts["neutrino"]+3*(get("delta_tot_de")+get("v_newtonian_baryon")+get("mts_dp_s")))
            j=-(modes[:,None]*get("etak")+.5*(other+get("mts_drho_h")))/h
            src_full=trace+.5*(get("mts_drho_h")+3*get("mts_dp_h"))
            reconstruct=lambda source:(scale[0]*j[:,:1]+cumulative_simpson(scale*source,x=tau,axis=1,initial=0))/scale
            true_j=reconstruct(src_full);jnorm=np.max(abs(j),axis=1)
            control[case]=dict(trace_integral_error=(np.max(abs(j-true_j),axis=1)/jnorm).tolist(),max_heavy_pressure=float(abs(get("mts_dp_h")).max()))
            arrays["metric_"+case]=j;arrays["j_integrated_"+case]=true_j;arrays["tau_"+case]=tau
            if case!="heavy":
                assert all(not np.any(get(key)) for key in ("mts_drho_h","mts_dp_h","mts_q_h"))
                continue
            assert np.array_equal(scale,driver["a"])
            actual=np.stack([get(key)*scale/rho for key in ("mts_drho_h","mts_q_h","mts_dp_h")],axis=2)
            arrays["actual"]=actual; arrays["exact_external_trace"]=trace
            arrays["external_only_J"]=reconstruct(driver["external_trace"]+.5*(get("mts_drho_h")+3*get("mts_dp_h")))
            control[case]["forecast_J_relative"]=(np.max(abs(j-pred["J_1_1"]),axis=1)/jnorm).tolist()
            for idx,conf in enumerate([*config(),EXTRA]):
                use,weights=basis(scale,conf,table)
                truth=np.einsum("t,ktj->kj",weights,actual[:,use]);hbar=weights@h[use]
                den,cur=norms(modes,conf,mass,*truth[:,:2].T,hbar)
                old=expected(modes,conf,mass,*truth[:,:2].T,hbar)
                for kind in ((1,1),(2,1),(1,0)):
                    suffix="%d_%d"%kind; forecast=pred["pred_"+suffix][idx]
                    coeff=pred["coef_"+suffix][idx];local=np.sum(coeff*truth[:,:2],axis=1)+pred["bias_"+suffix][idx]
                    orig=expected(modes,conf,mass,*forecast[:,:2].T,hbar)
                    for ix,mode in enumerate(modes):
                        rows.append(dict(surface=tags[idx],k=float(mode),a=conf[0],stride=kind[0],pressure_gravitates=kind[1],
                            actual_D=truth[ix,0],actual_Q=truth[ix,1],actual_P=truth[ix,2],norm=den[ix],qnorm=cur[ix],
                            original_error=(old[ix]-truth[ix,2])/den[ix],signed_defect_forecast=(forecast[ix,2]-orig[ix])/den[ix],
                            error_P=(forecast[ix,2]-truth[ix,2])/den[ix],error_D=(forecast[ix,0]-truth[ix,0])/den[ix],
                            error_Q=(forecast[ix,1]-truth[ix,1])/cur[ix],error_map=(local[ix]-truth[ix,2])/den[ix]))
    packet("trace-truth.npz",**arrays)
    with (ROOT/"trace-tests.csv").open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    write("trace-score.json",dict(controls=control,freeze=sha(ROOT/"trace-forecast.json"),truth=sha(ROOT/"trace-truth.npz")))
    for tag in tags:
        group=[r for r in rows if r["surface"]==tag and r["stride"]==1 and r["pressure_gravitates"]]
        print(tag,{key:"%.3g"%max(abs(row[key]) for row in group) for key in ("original_error","error_P","error_D","error_Q","error_map")})
    print("Trace integrals and J",control)
if __name__=="__main__":
    test()

