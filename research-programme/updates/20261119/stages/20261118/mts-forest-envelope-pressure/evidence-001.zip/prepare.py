from setup_stage import *

def main():
    guard()
    source=native()
    with np.load(INPUT) as data,np.load(TABLE) as table:
        modes=data["k"][-4:]
        assert np.all((modes>7)&(modes<8))
        saved=data["raw"][-4:]
        names=list(data["raw_names"])
        scale=saved[0,:,names.index("a")]
        use,weight=basis(np.maximum(scale,1e-20),config()[0],table)
        reference=float(table["matching_density"])
        moments=np.array([(saved[:,use,names.index(key)]*scale[use])@weight/reference for key in ("mts_drho_h","mts_q_h")]).T
        mass=float(table["heavy_mass_mpc"])
    native_exact=source.camb.get_background(source.params_for(BG))
    native_exact.Params.Accuracy.IntTolBoost=6
    ends=native_exact.conformal_time(1/np.array([.0001976,.0002524])-1,tol=1e-10)
    count=8*math.ceil((ends[1]-ends[0])*(.000253*mass)/(8*.077))
    tau=np.linspace(*ends,count+1)
    back=native_exact.get_time_evolution(modes,tau,vars=["a","H"],lAccuracyBoost=4)
    assert np.all(back==back[:1]) and np.min(back)>0
    actual=back[0,:,0]; hubble=back[0,:,1]
    params=source.params_for(TABLE)
    params.DarkEnergy.set_table("SetMatching",modes,*moments.T)
    native_avg=source.camb.get_background(params)
    native_avg.Params.Accuracy.IntTolBoost=6
    limits=native_avg.conformal_time(1/np.array([.000197,.000253])-1,tol=1e-10)
    rough_times=np.linspace(*limits,count+1)
    columns=["a","H","etak",*["delta_"+key for key in OTHER],"mts_drho_s","growth","v_baryon_cdm","mts_match_count"]
    response=native_avg.get_time_evolution(modes,rough_times,vars=columns,lAccuracyBoost=4)
    field=lambda name:response[:,:,columns.index(name)]
    avg_scale=field("a")[0].copy()
    assert np.all(np.diff(avg_scale)>0) and np.all(field("mts_match_count")[:,-1]==1)
    densities=native_avg.get_background_densities(avg_scale,vars=list(OTHER))
    contributions={key:densities[key][None,:]*field("delta_"+key)/avg_scale**2 for key in OTHER}
    environment=modes[:,None]*field("etak")+.5*(sum(contributions.values())+field("mts_drho_s"))
    evaluate=lambda values:CubicSpline(np.log(avg_scale),values,axis=-1)(np.log(actual))
    engine_terms=evaluate(environment)
    fraction=densities["baryon"]/(densities["baryon"]+densities["cdm"])
    regular_expansion=-field("growth")*field("H")*((1-fraction)*field("delta_cdm")+fraction*field("delta_baryon"))-modes[:,None]*fraction*field("v_baryon_cdm")
    matched_expansion=evaluate(regular_expansion)
    assert np.isfinite(engine_terms).all() and avg_scale[0]<actual[0]<actual[-1]<avg_scale[-1]
    packet("driver.npz",modes=modes,initial=moments,tau=tau,a=actual,H=hubble,environment=engine_terms,averaged_kZ=matched_expansion,rho=reference,mass=mass)
    deps=[INPUT,BG,TABLE,COLD,ROOT/"PROTOCOL.md",ROOT/"prepare.py",ROOT/"setup_stage.py",*source.native_hashes()]
    write("driver.json",dict(samples=len(tau),four_k=modes.tolist(),files={str(path):sha(path) for path in deps},driver=sha(ROOT/"driver.npz"),full_heavy_perturbations_at_independent_centers_read=False))
    print("Prepared environment, time nodes",len(tau),"span",actual[[0,-1]],flush=True)
if __name__=="__main__":
    main()

