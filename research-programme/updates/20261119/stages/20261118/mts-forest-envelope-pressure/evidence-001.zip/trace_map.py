from setup_stage import *
from envelope import gauss,stress
EXTRA=(.0002600,6,8)
def run(driver,table,stride,pressure_gravitates):
    tau=driver["tau"];use=np.arange(0,len(tau),stride);assert use[-1]==len(tau)-1
    grid=tau[use];dt=np.diff(grid);modes=driver["modes"]
    nodes,collocation,weight=gauss()
    times=grid[:-1,None]+dt[:,None]*nodes
    scalefn=CubicSpline(tau,driver["a"]);scale=scalefn(times)
    hubble=CubicSpline(tau,driver["H"])(times)
    phi_fn=CubicSpline(table["heavy_efold"],table["phi_h"]);vel_fn=CubicSpline(table["heavy_efold"],table["phidot_h"])
    freq=config()[0][0]*float(driver["mass"]);m2=(scale*float(driver["mass"]))**2
    phi=phi_fn(np.log(scale));vel=vel_fn(np.log(scale))
    ext=CubicSpline(tau,driver["external_trace"],axis=1)(times)
    start=driver["a"][0];hstart=driver["H"][0];pot0=(start*driver["mass"])**2*phi_fn(np.log(start));vel0=vel_fn(np.log(start))
    confs=[*config(),EXTRA]
    selections=[basis(driver["a"][use],conf,table) for conf in confs]
    output=[];j_out=[]
    for index,mode in enumerate(modes):
        coeff=np.zeros((*times.shape,3,3));src=np.zeros((*times.shape,3))
        coeff[:,:,0,1]=freq
        coeff[:,:,1,0]=-(mode**2+m2)/freq;coeff[:,:,1,1]=-2*hubble;coeff[:,:,1,2]=vel/freq
        coeff[:,:,2,0]=(.5-1.5*pressure_gravitates)*m2*phi;coeff[:,:,2,1]=(.5+1.5*pressure_gravitates)*freq*vel
        coeff[:,:,2,2]=-hubble;src[:,:,2]=ext[index]
        blocks=dt[:,None,None,None,None]*collocation[None,:,None,:,None]*coeff.transpose(0,2,1,3)[:,None,:,:,:]
        system=np.eye(12)[None,:,:]-blocks.reshape(-1,12,12)
        rhs=np.zeros((len(dt),4,3,4));rhs[:,:,:,:3]=np.eye(3);rhs[:,:,:,3]=dt[:,None,None]*np.einsum("ij,tjl->til",collocation,src)
        stages=np.linalg.solve(system,rhs.reshape(-1,12,4)).reshape(-1,4,3,4)
        slopes=coeff@stages;slopes[:,:,:,-1]+=src
        trans=dt[:,None,None]*np.einsum("s,tsij->tij",weight,slopes);trans[:,:,:3]+=np.eye(3)
        total=np.zeros((len(grid),3,3));total[0,:2,:2]=np.eye(2)
        total[0,2]=[-pot0/(2*hstart),-vel0*freq/(2*hstart),-driver["environment"][index,0]/hstart]
        for pos,local in enumerate(trans):
            total[pos+1]=local[:,:3]@total[pos];total[pos+1,:,-1]+=local[:,-1]
        output.append(total[:,:2,:]);j_out.append(total[:,2,:])
    fields=stress(driver,table,np.array(output),use)
    maps=np.array([np.einsum("t,ktij->kij",weights,fields[:,selected]) for selected,weights in selections])
    initial=np.linalg.solve(maps[0,:,:2,:2],(driver["initial"]-maps[0,:,:2,2])[...,None])[...,0]
    prediction=(maps[:,:,:,:2]@initial[None,:,:,None])[...,0]+maps[:,:,:,2]
    coef=np.linalg.solve(maps[:,:,:2,:2].transpose(0,1,3,2),maps[:,:,2,:2,None])[...,0]
    offset=maps[:,:,2,2]-np.einsum("cki,cki->ck",coef,maps[:,:,:2,2])
    all_j=np.einsum("kti,ki->kt",np.array(j_out),np.column_stack([initial,np.ones(len(modes))]))
    all_fields=np.einsum("ktji,ki->ktj",fields,np.column_stack([initial,np.ones(len(modes))]))
    return prediction,coef,offset,all_j,all_fields
def main():
    guard()
    result={}
    with np.load(ROOT/"trace-driver.npz") as driver,np.load(TABLE) as table:
        for stride,toggle in ((1,1),(2,1),(1,0)):
            fields,coef,bias,current,raw=run(driver,table,stride,toggle)
            for name,values in (("pred",fields),("coef",coef),("bias",bias),("J",current),("raw",raw)):
                result[f"{name}_{stride}_{toggle}"]=values
    packet("trace-frozen.npz",**result)
    names=("METRIC-PROTOCOL.md","driver.npz","trace-driver.npz","stock-input.json","observer.json","observer.diff","trace_map.py","trace_input.py","make_observer.py","trace-frozen.npz","forecast-receipt.json","score.json","envelope.py","setup_stage.py")
    write("trace-forecast.json",dict(files={name:sha(ROOT/name) for name in names},independent_scale=EXTRA[0],no_direct_reference_beyond_previous_endpoint=not (ROOT/"trace-truth.npz").exists()))
    print("Frozen returned-pressure metric at a=.00026",sha(ROOT/"trace-frozen.npz"),flush=True)
if __name__=="__main__":
    main()

