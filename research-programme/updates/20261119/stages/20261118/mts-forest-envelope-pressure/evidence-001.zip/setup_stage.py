import os, sys, json, hashlib, math
from pathlib import Path
for variable in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
sys.dont_write_bytecode=True
import numpy as np
import psutil
from scipy.interpolate import CubicSpline
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PRIOR=POST/"mts-forest-pressure-switch-20261118"
BASE=POST/"condensate-origin-20261003"
SPEC=BASE/"resolved-matter-spectrum-20261007"
EARLY=BASE/"native-two-field-transfer-20261007"
MATCH=BASE/"native-heavy-matching-20261007"
BG=EARLY/"runs/backgrounds/heavy.npz"
COLD=EARLY/"runs/backgrounds/cold.npz"
INPUT=PRIOR/"forest-radial-inputs.npz"
TABLE=SPEC/"runs/projection/a200-w6-d8.npz"
OTHER=("cdm","baryon","photon","neutrino","nu")
TAGS=("a200","ind2125","a225","ind2375","a250","a225narrow","a225deg10")
PROTECTED="4304967b4cfd38903c92d236adec862590223075a8fe55803242b95662587ee5"
def sha(path):
    with open(path,"rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()
def read(name):
    return json.loads((ROOT/name).read_text(encoding="utf8"))
def write(name,data):
    with (ROOT/name).open("x",encoding="utf8") as stream:
        json.dump(data,stream,indent=2,allow_nan=False)
def packet(name,**values):
    with (ROOT/name).open("xb") as stream:
        np.savez_compressed(stream,**values)
def guard():
    proc=psutil.Process()
    proc.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([proc.cpu_affinity()[0]])
    assert not any((folder/"STOP-REQUESTED").exists() for folder in (ROOT,POST,BASE,PRIOR))
    assert sha(PRIOR/"closeout.json")==PROTECTED
    assert sha(INPUT)==json.loads((PRIOR/"closeout.json").read_text())["files"][INPUT.name]
def native():
    sys.path.insert(0,str(MATCH))
    import matching_common
    return matching_common
def config():
    with np.load(TABLE) as table:
        center=float(table["matching_scale"])
    with np.load(SPEC/"runs/projection/a225-w6-d8.npz") as other:
        mid=float(other["matching_scale"])
    with np.load(SPEC/"runs/projection/a250-w6-d8.npz") as other:
        end=float(other["matching_scale"])
    return [(center,6,8),(.0002125,6,8),(mid,6,8),(.0002375,6,8),(end,6,8),(mid,4,8),(mid,6,10)]
def basis(scale,conf,table):
    center,width,degree=conf
    phase_fn=CubicSpline(table["heavy_efold"],table["phase_h"])
    phase=phase_fn(np.log(scale)); middle=phase_fn(math.log(center))
    use=np.flatnonzero(abs(phase-middle)<width*np.pi)
    coord=(phase[use]-middle)/(width*np.pi)
    columns=[coord**power for power in range(degree+1)]
    columns.extend(coord**power*func(2*phase[use]) for power in range(degree-1) for func in (np.cos,np.sin))
    columns.extend(coord**power*func(4*phase[use]) for power in range(3) for func in (np.cos,np.sin))
    design=np.array(columns).T
    assert len(use)>=50 and np.linalg.cond(design)<1e5
    return use,np.linalg.pinv(design)[0]
def expected(modes,conf,mass,density,current,hubble):
    ratio=modes/(conf[0]*mass)
    speed=(ratio/(np.sqrt(1+ratio**2)+1))**2
    return speed*(density+3*hubble*current/modes)
def norms(modes,conf,mass,density,current,hubble):
    ratio=modes/(conf[0]*mass)
    cs=ratio/(np.sqrt(1+ratio**2)+1)
    norm=np.maximum.reduce([abs(density),abs(modes*current/hubble)/np.maximum(1,modes/hubble*cs),np.full(len(modes),1e-6)])
    return norm,norm*np.maximum(hubble/modes,cs)

