from setup_stage import *
def main(case):
    guard()
    if case=="stock":
        src=native()
    else:
        assert case=="observer"
        sys.path.insert(0,str(ROOT/"observer"))
        sys.path.append(str(BASE/"radiation-and-slow-field-transfer-20261007"))
        import matching_common as src
        assert sha(Path(src.camb.__file__).parent/"cambdll.dll")==read("observer.json")["binary"]
    with np.load(ROOT/"driver.npz") as first:
        modes=first["modes"];initial=first["initial"];mass=float(first["mass"])
    model=src.camb.get_background(src.params_for(BG)); model.Params.Accuracy.IntTolBoost=6
    ends=model.conformal_time(1/np.array([.0001976,.0002630])-1,tol=1e-10)
    count=8*math.ceil(np.diff(ends).item()*(.000264*mass)/(.077*8))
    tau=np.linspace(*ends,count+1)
    geometry=model.get_time_evolution(modes,tau,vars=["a","H"],lAccuracyBoost=4)
    assert np.all(geometry==geometry[:1])
    actual,hubble=geometry[0].T
    params=src.params_for(TABLE); params.DarkEnergy.set_table("SetMatching",modes,*initial.T)
    av=src.camb.get_background(params);av.Params.Accuracy.IntTolBoost=6
    span=av.conformal_time(1/np.array([.000197,.0002636])-1,tol=1e-10)
    grid=np.linspace(*span,count+1)
    columns=["a","H","etak","growth","v_baryon_cdm",*["delta_"+key for key in OTHER],"mts_drho_s","mts_dp_s","mts_match_count"]
    keys=columns+(["delta_tot_de","v_newtonian_baryon"] if case=="observer" else [])
    values=av.get_time_evolution(modes,grid,vars=keys,lAccuracyBoost=4)
    get=lambda name:values[:,:,keys.index(name)]
    fingerprint=hashlib.sha256(np.ascontiguousarray(values[:,:,:len(columns)]).tobytes()).hexdigest()
    geometry_sha=hashlib.sha256(geometry.tobytes()).hexdigest()
    if case=="stock":
        write("stock-input.json",dict(fingerprint=fingerprint,geometry=geometry_sha));return
    assert read("stock-input.json")==dict(fingerprint=fingerprint,geometry=geometry_sha)
    scale=get("a")[0].copy();bg=av.get_background_densities(scale,vars=list(OTHER))
    d={key:bg[key]*get("delta_"+key)/scale**2 for key in OTHER}
    total=sum(d.values())+get("mts_drho_s")
    radiation=d["photon"]+d["neutrino"]
    stress=3*(get("delta_tot_de")+get("v_newtonian_baryon")+get("mts_dp_s"))
    evaluation=lambda array:CubicSpline(np.log(scale),array,axis=1)(np.log(actual))
    trace=evaluation(.5*(total+radiation+stress))
    energy=evaluation(modes[:,None]*get("etak")+.5*total)
    frac=bg["baryon"]/(bg["baryon"]+bg["cdm"])
    kz=evaluation(-get("growth")*get("H")*((1-frac)*get("delta_cdm")+frac*get("delta_baryon"))-modes[:,None]*frac*get("v_baryon_cdm"))
    assert np.isfinite(trace).all() and np.all(get("mts_match_count")[:,-1]==1)
    with np.load(TABLE) as table:
        packet("trace-driver.npz",modes=modes,tau=tau,a=actual,H=hubble,initial=initial,environment=energy,external_trace=trace,averaged_kZ=kz,rho=float(table["matching_density"]),mass=mass)
    print("Independent trace input",fingerprint,len(tau),flush=True)
if __name__=="__main__":
    main(sys.argv[1])

