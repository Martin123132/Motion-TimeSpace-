from setup_stage import *
from trace_map import EXTRA
import csv
REDS=np.array([99.,49.,8.,5.4,5.,4.6,4.2])
def late(case):
    guard()
    if case not in ("225pred","250pred","225direct","250direct","225tight","cold","lcdm","lcdm-mapped"):raise ValueError(case)
    assert sha(ROOT/"trace-truth.npz")==read("trace-score.json")["truth"]
    src=native()
    with np.load(ROOT/"trace-driver.npz") as driver,np.load(ROOT/"trace-frozen.npz") as forecast,np.load(TABLE) as t:
        modes=np.r_[5.,driver["modes"]];selected=modes.copy()
        table_tag="250" if case.startswith("250") else "225"
        tfile=SPEC/f"runs/projection/a{table_tag}-w6-d8.npz"
        heavy=case[:1]=="2"
        if heavy:
            idx={"225":2,"250":4}[table_tag];conf=config()[idx]
            with np.load(tfile) as exact:
                assert float(exact["matching_scale"])==conf[0] and float(exact["matching_density"])==float(driver["rho"])
                pos=np.flatnonzero(exact["modes"]==5.).item()
                anchor=[exact["matching_delta"][pos],exact["matching_momentum"][pos]]
            states=forecast["pred_1_1"][idx];coarse=forecast["pred_2_1"][idx]
            used,weights=basis(driver["a"],conf,t); hc=weights@driver["H"][used];mass=float(driver["mass"])
            nrm,qn=norms(modes[1:],conf,mass,*states[:,:2].T,hc)
            defect=abs(states[:,2]-expected(modes[1:],conf,mass,*states[:,:2].T,hc))/nrm
            numerical=abs(states[:,2]-coarse[:,2])/nrm
            assert np.all(defect+numerical<2e-6)
            with np.load(ROOT/"trace-truth.npz") as truth:
                actual=np.einsum("t,kti->ki",weights,truth["actual"][:,used])
            assert np.all(abs(states-actual)<np.array([2e-5*nrm,2e-5*qn,2e-6*nrm]).T)
            seed=np.vstack([anchor,(actual if case.endswith("direct") else states)[:,:2]])
            params=src.params_for(tfile);params.DarkEnergy.set_table("SetMatching",modes,*seed.T)
        else:
            params=src.params_for(COLD)
            if case.startswith("lcdm"):
                params.DarkEnergy=src.camb.dark_energy.DarkEnergyFluid()
            if case=="lcdm-mapped":
                with (PRIOR/"forest-radial-inputs.csv").open() as stream:
                    origins=sorted({(float(r["k_parent"]),float(r["k_lcdm"])) for r in csv.DictReader(stream) if float(r["k_parent"])>5})
                assert np.array_equal(np.array(origins)[:,0],modes[1:])
                selected=np.r_[5.,np.array(origins)[:,1]]
        params.DoLateRadTruncation=False
        engine=src.camb.get_background(params);engine.Params.Accuracy.IntTolBoost=6.9 if case=="225tight" else 6.4
        times=engine.conformal_time(REDS,tol=1e-10)
        names=["a","H","etak","Weyl","v_newtonian_cdm","v_newtonian_baryon","delta_cdm","delta_baryon","mts_drho_h","mts_dp_h","mts_match_count","mts_nonheavy_change"]
        raw=engine.get_time_evolution(selected,times,vars=names,lAccuracyBoost=4)
        get=lambda key:raw[:,:,names.index(key)]
        assert np.isfinite(raw).all() and np.all(get("mts_match_count")==heavy) and not np.any(get("mts_nonheavy_change"))
        assert np.max(abs(get("a")*(1+REDS)-1))<2e-5
        phi=get("etak")/selected[:,None]+(get("H")/selected[:,None])**2*get("v_newtonian_cdm")
        force=-2*get("Weyl")+selected[:,None]**2*phi
        bar=get("delta_baryon")+3*(get("H")/selected[:,None])**2*get("v_newtonian_cdm")
        packet("late-"+case+".npz",z=REDS,modes=selected,raw=raw,names=names,force=force,gas=bar,velocity=get("v_newtonian_baryon"))
        print("Completed",case,flush=True)
if __name__=="__main__":
    late(sys.argv[1])

