from common import *
import csv
from scipy.interpolate import CubicSpline

FOREST_Z=[5.4,5.,4.6,4.2]
PRIMARY=["baryon_N","baryon_velocity","force"]
TERMS=["cdm_N","baryon_N","baryon_velocity","force","Weyl","clustered_N","total_sync","cdm_velocity","heavy_delta","heavy_q"]

def write_csv(name,rows):
    with (ROOT/name).open("w",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
def read_csv(path):
    with path.open(encoding="utf-8-sig",newline="") as stream:
        return list(csv.DictReader(stream))

def data(run):
    with np.load(ROOT/run/"result.npz") as packet:
        out=dict(packet)
    out["v"]={key:out["raw"][:,:,index] for index,key in enumerate(out["names"])}
    val=out["v"];modes=out["k"][:,None];scale=val["a"];hub=val["H"]
    gauge=3*(hub/modes)**2*val["v_newtonian_cdm"]
    phi=val["etak"]/modes+(hub/modes)**2*val["v_newtonian_cdm"]
    source=-2*val["Weyl"]+modes**2*phi
    heavy=run.startswith("heavy")
    with np.load(PROJECT) as seed:
        rho=float(seed["matching_density"])
    rel=scale/rho
    hdelta=val["mts_drho_h"]*rel
    hq=val["mts_q_h"]*rel
    pressure=val["mts_dp_h"]*rel
    cold=out["bg_cdm"];bar=out["bg_baryon"];nu=out["bg_nu"];bgheavy=rho*scale if heavy else 0
    clustered=(cold*val["delta_cdm"]+bar*val["delta_baryon"]+bgheavy*hdelta)/(cold+bar+bgheavy)
    total=((cold+bar+bgheavy)*clustered+nu*val["delta_nu"])/(cold+bar+bgheavy+nu)
    out["values"]=dict(cdm_N=val["delta_cdm"]+gauge,baryon_N=val["delta_baryon"]+gauge,baryon_velocity=val["v_newtonian_baryon"],force=source,Weyl=val["Weyl"],
                       clustered_N=clustered+gauge,total_sync=total,cdm_velocity=val["v_newtonian_cdm"],heavy_delta=hdelta,heavy_q=hq,pressure=pressure)
    return out

def state_test(first,second,label):
    loc1=ROOT/first;loc2=ROOT/second
    state1=sorted(loc1.glob("initial-*.bin"));state2=sorted(loc2.glob("initial-*.bin"))
    assert len(state1)==len(state2)>0
    sizes=[]
    for path,other in zip(state1,state2):
        assert path.name==other.name and path.read_bytes()==other.read_bytes(),(label,path)
        payload=path.read_bytes()
        count=int.from_bytes(payload[:4],"little",signed=True)
        values=np.frombuffer(payload[4:],dtype="<f8")
        assert len(values)==count+3 and abs(values[2]/.01-1)<TOL and np.isfinite(values).all()
        sizes.append(count)
    return dict(modes=len(state1),length_range=[min(sizes),max(sizes)],state_and_time_byte_identical=True)
def take(pack,epoch):
    return np.flatnonzero(pack["z"]==epoch).item()
def fractional(test,ref):
    assert np.min(np.abs(ref))>1e-24
    return np.abs(test/ref-1)
def derivative_check(loaded,arm):
    first=loaded["heavy-on-"+arm+"-z99"];second=loaded["heavy-off-"+arm+"-z99"]
    start=take(first,99.);end=take(first,4.2)+1
    cut=slice(start,end)
    eta=first["tau"][cut];outputs=[take(first,epoch)-start for epoch in FOREST_Z]
    rows=[]
    for index,mode in enumerate(first["k"]):
        def val(pack,key):
            return pack["values"][key][index,cut]
        def integ(values):
            ant=CubicSpline(eta,values).antiderivative()
            return ant(eta)-ant(eta[0])
        scale=first["v"]["a"][index,cut];hub=first["v"]["H"][index,cut]
        press=val(first,"pressure")
        drive=mode*integ(scale*press)/scale
        kick=-mode*integ(drive)
        dil=-3*integ(hub*press)
        rel_actual=val(first,"heavy_delta")-val(second,"heavy_delta")-(first["v"]["delta_cdm"][index,cut]-second["v"]["delta_cdm"][index,cut])
        momentum=val(first,"heavy_q")-val(second,"heavy_q")
        momscale=np.maximum.reduce([abs(val(first,"heavy_q")),abs(val(second,"heavy_q")),np.abs(hub*val(first,"clustered_N")/mode)])
        den=abs(val(first,"clustered_N"))
        dust=scale[0]/scale*val(second,"heavy_q")[0]
        for epoch,pos in zip(FOREST_Z,outputs):
            rows.append(dict(quality=arm,k=mode,z=epoch,q_pressure_integral=drive[pos],q_difference=momentum[pos],
                q_error_over_mode_scale=abs(drive[pos]-momentum[pos])/momscale[pos],
                dust_q_error_over_mode_scale=abs(dust[pos]-val(second,"heavy_q")[pos])/momscale[pos],
                relative_density_pressure_gradient=kick[pos],relative_density_pressure_dilution=dil[pos],relative_density_actual=rel_actual[pos],
                density_error_over_clustered=abs(kick[pos]+dil[pos]-rel_actual[pos])/den[pos]))
    return rows

def analyse():
    guard();modest()
    labels=["heavy-on-base","heavy-off-base","heavy-on-fine","heavy-off-fine","cold-on-base","cold-off-base","cold-on-fine","lcdm-on-base","heavy-stock-base"]
    loaded={name+"-z99":data(name+"-z99") for name in labels}
    report={"states":{},"prior_power":{},"precision":{}}
    comparisons=[]
    for case,qual in [("heavy","base"),("heavy","fine"),("cold","base")]:
        first=f"{case}-on-{qual}-z99";second=f"{case}-off-{qual}-z99"
        left,right=loaded[first],loaded[second]
        receipt=state_test(first,second,first)
        idx=take(left,99.)
        assert np.array_equal(left["raw"][:,:idx+1,:],right["raw"][:,:idx+1,:]) and np.array_equal(left["H"],right["H"])
        if case=="cold":
            assert np.array_equal(left["raw"],right["raw"])
        else:
            assert np.all(right["values"]["pressure"][:,idx+1:]==0.) and np.all(np.max(abs(left["values"]["pressure"][:,idx+1:]),axis=1)>0)
        report["states"][first]=receipt
        for index,mode in enumerate(left["k"]):
            for zval in FOREST_Z:
                pos=take(left,zval)
                for key in (TERMS if case=="heavy" else TERMS[:-2]):
                    reference=left["values"][key][index,pos]
                    alternative=right["values"][key][index,pos]
                    assert reference!=0.
                    comparisons.append(dict(case=case,quality=qual,k=mode,z=zval,channel=key,on=reference,off=alternative,
                          off_over_on=alternative/reference,off_minus_on_fraction=alternative/reference-1.,power_change_fraction=(alternative/reference)**2-1))
    for case in ("heavy","cold","lcdm"):
        fresh=loaded[case+"-on-base-z99"]
        with np.load(FOREST/f"native-{case}.npz") as anchor:
            shared=[]
            for i,mode in enumerate(fresh["k"]):
                match=np.flatnonzero(abs(anchor["k"]/mode-1)<1e-11)
                if not len(match):continue
                for pos,zval in enumerate(anchor["z"]):
                    now=take(fresh,zval)
                    shared.append(abs(fresh["values"]["total_sync"][i,now]/anchor["total"][match.item(),pos]-1))
            assert len(shared)>=24
            report["prior_power"][case]=dict(common=len(shared),worst_amplitude=float(max(shared)),worst_power_bound=float(2*max(shared)+max(shared)**2))
    summary=[]
    for i,mode in enumerate(loaded["heavy-on-base-z99"]["k"]):
        base=[row for row in comparisons if row["case"]=="heavy" and row["quality"]=="base" and row["k"]==mode and row["channel"] in PRIMARY]
        fine=[row for row in comparisons if row["case"]=="heavy" and row["quality"]=="fine" and row["k"]==mode and row["channel"] in PRIMARY]
        assert [(r["z"],r["channel"]) for r in base]==[(r["z"],r["channel"]) for r in fine]
        worst=max(fine,key=lambda r:abs(r["off_minus_on_fraction"]))
        peak=abs(worst["off_minus_on_fraction"])
        discrepancy=max(abs(r["off_over_on"]/s["off_over_on"]-1) for r,s in zip(base,fine))
        summary.append(dict(k=mode,worst_channel=worst["channel"],worst_z=worst["z"],worst_amplitude=peak,
            worst_power=max(abs(r["power_change_fraction"]) for r in fine),pair_resolution=discrepancy,
            pass_1pc=bool(peak<=.01 and discrepancy<TOL),pass_5pc=bool(peak<=.05 and discrepancy<TOL),
            **{key:max(abs(r["off_minus_on_fraction"]) for r in fine if r["channel"]==key) for key in PRIMARY}))
    for shot,reference in [("heavy-on-base","heavy-stock-base"),("heavy-on-fine","heavy-on-base"),("heavy-off-fine","heavy-off-base"),("cold-on-fine","cold-on-base")]:
        left=loaded[shot+"-z99"];right=loaded[reference+"-z99"]
        diffs={}
        for key in PRIMARY+["Weyl","clustered_N","total_sync"]:
            err=np.array([fractional(left["values"][key][:,take(left,zval)],right["values"][key][:,take(right,zval)]) for zval in FOREST_Z])
            diffs[key]=dict(max_fraction=float(err.max()),over_tolerance=int((err>TOL).sum()))
        report["precision"][shot+" vs "+reference]=diffs
    green=derivative_check(loaded,"base")+derivative_check(loaded,"fine")
    write_csv("green-response.csv",green);write_csv("linear-switch.csv",comparisons);write_csv("scale-test.csv",summary)
    report["green_fine"]={key:max(r[key] for r in green if r["quality"]=="fine") for key in ["q_error_over_mode_scale","dust_q_error_over_mode_scale","density_error_over_clustered"]}
    report["null_allcold_bitwise"]=True
    report["scope"]="linear perturbation experiment, no gas-to-flux likelihood or observational exclusion"
    save(ROOT/"response.json",report)
    print(report["prior_power"],report["green_fine"],flush=True)
    print([(round(r["k"],4),round(100*r["worst_amplitude"],4),r["pair_resolution"]) for r in summary],flush=True)
if __name__=="__main__":
    analyse()

