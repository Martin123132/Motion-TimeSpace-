from readout import *

def run():
    guard();modest()
    on=data("heavy-on-fine-z99")
    wave=data("heavy-leading-fine-z99")
    off=data("heavy-off-fine-z99")
    with np.load(PROJECT) as source:
        mass=float(source["heavy_mass_mpc"])
    index=take(on,99.)
    after=slice(index+1,None)
    k=wave["k"][:,None]
    ratio=k/(wave["v"]["a"]*mass)
    leading=ratio**2/4
    exact=(ratio/(np.hypot(1,ratio)+1))**2
    comoving=wave["values"]["heavy_delta"]+3*wave["v"]["H"]*wave["values"]["heavy_q"]/k
    inferred=wave["values"]["pressure"][:,after]
    expected=(leading*comoving)[:,after]
    assert np.max(abs(inferred-expected)/np.maximum(abs(expected),1e-20))<2e-10
    assert np.array_equal(wave["raw"][:,:index+1],on["raw"][:,:index+1])
    states=state_test("heavy-on-fine-z99","heavy-leading-fine-z99","leading")
    cold=data("cold-leading-base-z99")
    assert np.array_equal(cold["raw"],data("cold-on-base-z99")["raw"])
    states49=[]
    for path in sorted((ROOT/"heavy-on-fine-z49").glob("initial-*.bin")):
        other=ROOT/"heavy-off-fine-z49"/path.name
        assert path.read_bytes()==other.read_bytes()
        payload=np.frombuffer(path.read_bytes()[4:],dtype="<f8")
        assert abs(payload[2]*50-1)<TOL
        states49.append(len(payload)-3)
    assert len(states49)==len(k)
    rows=[]
    for pos,mode in enumerate(wave["k"]):
        for epoch in FOREST_Z:
            time=take(on,epoch)
            for key in PRIMARY+["Weyl","total_sync","clustered_N"]:
                original=on["values"][key][pos,time]
                dust=off["values"][key][pos,time]
                replacement=wave["values"][key][pos,time]
                rows.append(dict(k=mode,z=epoch,channel=key,leading_over_native=replacement/original,
                                 leading_fraction_error=abs(replacement/original-1),dust_over_native=dust/original))
    write_csv("leading-stress.csv",rows)
    report=dict(switch=states,confirmed_z49_states=len(states49),cold_leading_null=True,
                coefficient_max_frac_after_switch=float((leading/exact-1)[:,index:].max()),
                realized_constitutive_max_fraction=float(np.max(abs(inferred-expected)/np.maximum(abs(expected),1e-20))),
                channel_max={key:max(row["leading_fraction_error"] for row in rows if row["channel"]==key) for key in PRIMARY+["Weyl","total_sync","clustered_N"]})
    save(ROOT/"leading-stress.json",report)
    print(report)
if __name__=="__main__":
    run()

