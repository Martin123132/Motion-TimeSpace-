from readout import *

def run():
    guard();modest()
    with np.load(PROJECT) as table:rho=float(table["matching_density"])
    rows=[]
    labels=["heavy-on-fine","heavy-off-fine","heavy-leading-fine","cold-on-fine","lcdm-on-base"]
    for label in labels:
        pack=data(label+"-z99")
        val=pack["v"];start=take(pack,99.);end=take(pack,4.2)+1
        cut=slice(start,end);eta=pack["tau"][cut]
        bg={name:pack["bg_"+name][cut] for name in ("cdm","baryon","photon","neutrino","nu")}
        for index,mode in enumerate(pack["k"]):
            def field(name):return val[name][index,cut]
            aa=field("a");hc=field("H")
            force=pack["values"]["force"][index,cut]
            wave=label.startswith("heavy")
            bgheavy=aa*rho if wave else np.zeros_like(aa)
            partial=(bg["cdm"]*field("delta_cdm")+bg["baryon"]*field("delta_baryon")+bgheavy*pack["values"]["heavy_delta"][index,cut])/(2*aa**2)
            motion=3*hc/mode*(bg["baryon"]*field("v_baryon_cdm")+bgheavy*pack["values"]["heavy_q"][index,cut])/(2*aa**2)
            neutrino=bg["nu"]*field("delta_nu")/(2*aa**2)
            radiation=(bg["photon"]*field("delta_photon")+bg["neutrino"]*field("delta_neutrino")
                      +3*hc/mode*(bg["photon"]*field("v_photon")+bg["neutrino"]*field("v_neutrino")))/(2*aa**2)
            slow=(field("mts_drho_s")+3*hc/mode*field("mts_q_s"))/2
            photon_stress=bg["photon"]*field("pi_photon")/aa**2
            impulse=CubicSpline(eta,aa*force).antiderivative()
            impulse=impulse(eta)-impulse(eta[0])
            cdm=aa*hc*field("v_newtonian_cdm")
            baryon=aa*hc*field("v_newtonian_baryon")
            for epoch in FOREST_Z:
                pos=take(pack,epoch)-start
                actual=force[pos]
                rows.append(dict(arm=label,k=mode,z=epoch,cold_geodesic_error_over_current=(cdm[0]+impulse[pos]-cdm[pos])/cdm[pos],
                                 baryon_nongrav_impulse_over_current=(baryon[pos]-baryon[0]-impulse[pos])/baryon[pos],force=actual,
                                 clustered_density=partial[pos],clustered_momentum=motion[pos],massive_nu_density=neutrino[pos],
                                 relativistic_density_momentum=radiation[pos],slow_density_momentum=slow[pos],photon_shear=photon_stress[pos],
                                 clustered_Poisson_error=(partial[pos]+motion[pos]-actual)/actual,
                                 unallocated_force=actual-partial[pos]-motion[pos]-neutrino[pos]-radiation[pos]-slow[pos]-photon_stress[pos]))
    write_csv("geodesic-and-source.csv",rows)
    report={}
    for label in labels:
        local=[row for row in rows if row["arm"]==label]
        report[label]=dict(geodesic=max(abs(row["cold_geodesic_error_over_current"]) for row in local),
                gravity_only_baryon_impulse_max=max(abs(row["baryon_nongrav_impulse_over_current"]) for row in local),
                clustered_only_force_max=max(abs(row["clustered_Poisson_error"]) for row in local),
                after_known_channels_max=max(abs(row["unallocated_force"]/row["force"]) for row in local))
    save(ROOT/"geodesic-and-source.json",report)
    print(report)
if __name__=="__main__":
    run()

