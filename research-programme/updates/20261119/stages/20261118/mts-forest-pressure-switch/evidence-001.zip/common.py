from pathlib import Path
import os,sys,json,hashlib
for variable in ("OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[variable]="1"
sys.dont_write_bytecode=True
import numpy as np
import psutil

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
FOREST=POST/"mts-forest-transfer-test-20261118"
BASE=POST/"condensate-origin-20261003"
MATCH=BASE/"native-heavy-matching-20261007"
EARLY=BASE/"native-two-field-transfer-20261007"
SPEC=BASE/"resolved-matter-spectrum-20261007"
PROJECT=SPEC/"runs/projection/a225-w6-d8.npz"
TOL=2e-5

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream,"sha256").hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf8"))
def save(path,record):
    with path.open("x",encoding="utf8") as stream:
        json.dump(record,stream,indent=2,allow_nan=False)
def guard():
    assert digest(FOREST/"closeout.json")=="8980961aca5ab08c5b290d3244535b52306a12df1ca7bd2398437909b6eb6d10"
    assert not any((folder/"STOP-REQUESTED").exists() for folder in [ROOT,POST,BASE,FOREST])
def modest():
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([process.cpu_affinity()[0]])

