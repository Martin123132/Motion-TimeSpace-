from common import *
import subprocess,shutil,difflib

def substitute(text,old,new):
    assert text.count(old)==1,old
    return text.replace(old,new)

def build(leading=False):
    guard()
    native=MATCH/"native"
    fortran=native/"fortran"
    receipt=read(MATCH/"runs/build-1/status.json")
    chain=EARLY/"toolchain/mingw64"
    compiler=chain/"bin/gfortran.exe"
    assert digest(compiler)==receipt["compiler_sha256"] and digest(native/"camb/cambdll.dll")==receipt["dll_sha256"]
    inputs={str(compiler):digest(compiler)}
    sourcefiles={}
    for name in ("MTSTwoField","camb_python"):
        src=fortran/(name+".f90")
        assert digest(src)==receipt["input_hashes"][str(src)]
        inputs[str(src)]=digest(src)
        sourcefiles[name]=src.read_text()
    body=sourcefiles["MTSTwoField"]
    match="function MTS_AveragedPressure(this, a, k, hubble, density, momentum) result(pressure)"
    body=substitute(body,match,match+"\nuse ForestSwitch, only: forest_factor")
    if leading:
        body=substitute(body,"pressure = sound2*", "if (forest_factor < 0.5_dl) sound2=0.25_dl*ratio\npressure = sound2*")
    else:
        body=substitute(body,"pressure = sound2*", "pressure = forest_factor*sound2*")
    driver=sourcefiles["camb_python"]
    start=driver.index("    subroutine GetOutputEvolutionFork(")
    end=driver.index("    end subroutine GetOutputEvolutionFork",start)
    block=substitute(driver[start:end],"    use MTSTwoField","    use MTSTwoField\n    use ForestSwitch, only: forest_start,forest_restart")
    block=substitute(block,"    integer j,ind","    integer j,ind,forest_target\n    real(dl) forest_future,forest_scale")
    block=substitute(block,"    w=0","    call forest_start(forest_target,forest_future,forest_scale)\n    w=0")
    block=substitute(block,"        if (global_error_flag/=0) return","        if (global_error_flag/=0) return\n        if (j==forest_target) call forest_restart(EV%q_ix,EV%q,tau,a,forest_scale, &\n            y(:EV%ScalEqsToPropagate),forest_future,ind,c,w)")
    changed={"MTSTwoField":body,"camb_python":driver[:start]+block+driver[end:]}
    local=ROOT/"compile-work"
    local.mkdir(exist_ok=False)
    try:
        rel=Path(os.path.relpath(chain,local))
        libdirs=["lib","lib/gcc/x86_64-w64-mingw32/14.2.0","x86_64-w64-mingw32/lib"]
        prefixes=["libexec/gcc/x86_64-w64-mingw32/14.2.0","bin",*libdirs]
        flags=["-B./",*["-B"+(rel/path).as_posix()+"/" for path in prefixes],*["-L"+(rel/path).as_posix() for path in libdirs],
               "-shared","-static","-cpp","-fopenmp","-O2","-fcheck=bounds","-fmax-errors=4","-fno-use-linker-plugin"]
        sources=[chain/prefixes[0]/tool for tool in ("f951.exe","collect2.exe")]+list((chain/"lib").glob("*.spec"))
        for filename in ("dllcrt2.o","crtbegin.o","crtend.o"):
            sources.append(next(chain/path/filename for path in libdirs if (chain/path/filename).exists()))
        objects=[fortran/key for key in receipt["commands"][-1] if key.endswith(".o")]
        assert len(objects)==39
        sources+= [obj for obj in objects if obj.stem not in changed]
        for src in sources:
            shutil.copyfile(src,local/src.name)
            inputs[str(src)]=digest(src)
        shutil.copyfile(ROOT/"ForestSwitch.f90",local/"ForestSwitch.f90")
        diffs=[]
        for name,after in changed.items():
            (local/(name+".f90")).write_text(after,encoding="utf8")
            diffs.extend(difflib.unified_diff(sourcefiles[name].splitlines(True),after.splitlines(True),name+".orig",name+".f90"))
        tag="-leading" if leading else ""
        (ROOT/f"native-changes{tag}.diff").write_text("".join(diffs),encoding="utf8")
        modules=fortran/"WinMTS"
        for path in modules.glob("*.mod"):
            inputs[str(path)]=digest(path)
            shutil.copyfile(path,local/path.name)
        env=dict(os.environ,PATH=str(chain/"bin")+";"+os.environ["PATH"])
        commands=[]
        for args in [["-I.","-J.",name+".f90","-c","-o",name+".o"] for name in ("ForestSwitch","MTSTwoField","camb_python")]+[["ForestSwitch.o",*[obj.name for obj in objects],"-o","switched.dll"]]:
            commands.append([*flags,*args])
            proc=subprocess.run([str(compiler),*flags,*args],cwd=local,env=env,capture_output=True,text=True,timeout=120)
            if proc.returncode:
                raise RuntimeError(proc.stderr)
        runtime=ROOT/("engine"+tag)
        pkg=runtime/"native/camb"
        pkg.mkdir(parents=True,exist_ok=False)
        for src in (native/"camb").iterdir():
            if src.is_file() and src.suffix in (".py",".dat"):
                shutil.copyfile(src,pkg/src.name)
                inputs[str(src)]=digest(src)
        template=fortran/"HighLExtrapTemplate_lenspotentialCls.dat"
        shutil.copyfile(template,pkg/template.name)
        inputs[str(template)]=digest(template)
        shutil.copyfile(local/"switched.dll",pkg/"cambdll.dll")
        for name in ("matching_common.py","stage_common.py"):
            shutil.copyfile(MATCH/name,runtime/name)
            inputs[str(MATCH/name)]=digest(MATCH/name)
        save(ROOT/("build"+tag+".json"),dict(commands=commands,inputs=inputs,stock=receipt["dll_sha256"],binary=digest(pkg/"cambdll.dll")))
    finally:
        assert local.resolve().parent==ROOT and local.name=="compile-work"
        for item in local.iterdir():
            assert not item.is_symlink() and item.is_file()
            item.unlink()
        local.rmdir()
    print("private solver built, compiler workspace closed")
if __name__=="__main__":
    modest()
    build("--leading" in sys.argv)

