from common import *
import argparse
import time
import subprocess

def mode_table():
    with np.load(PROJECT) as table, np.load(FOREST/"pivot-sourced-heavy.npz") as extra, np.load(FOREST/"native-heavy.npz") as forest:
        source=table["modes"];pivot=float(forest["pivot"])
        desired=[.03,.075,.1,.125,.2,.25,.30,.3425,.4,.45,.5,.57,.64,.835,1.,1.25,1.5,1.981,2.5,3.,3.75,4.5,5.]
        modes=np.sort(np.r_[[source[np.argmin(abs(source-value))] for value in desired],pivot])
        assert np.unique(modes).size==len(modes) and np.all(modes<=5.)
        projection=[]
        for mode in modes:
            if mode==pivot:
                index=np.flatnonzero(extra["k"]==mode).item()
                projection.append((extra["phase_delta"][index],extra["phase_momentum"][index]))
            else:
                index=np.flatnonzero(source==mode).item()
                projection.append((table["matching_delta"][index],table["matching_momentum"][index]))
    return modes,np.asarray(projection)

def run(case,factor,quality,cutoff,stock,leading=False,radial=False):
    guard();modest()
    count=256 if quality=="base" else 512
    mandatory=np.array([200.,120.,100.,99.,98.9,98.,89.,79.,69.,49.,39.,29.,24.,19.,14.,9.,8.,7.,6.,5.4,5.,4.6,4.2,3.,0.])
    red=np.sort(np.unique(np.r_[np.expm1(np.linspace(np.log(5.2),np.log(100),count+1))[1:-1],mandatory]))[::-1].copy()
    scale=1/(1+red)
    index=int(np.flatnonzero(red==cutoff).item())
    control=dict(MTS_FOREST_INDEX=str(index+1),MTS_FOREST_FACTOR=str(factor),MTS_FOREST_SCALE=str(scale[index]))
    if not stock and any(os.environ.get(key)!=value for key,value in control.items()):
        subprocess.run([sys.executable,"-B","-u",str(ROOT/"evolve.py"),*sys.argv[1:]],env=dict(os.environ,**control),check=True)
        return
    branch="stock" if stock else ("on" if factor==1 else "off" if factor==0 else "partial")
    if leading:
        assert not stock and factor==0
        branch="leading"
    name=f"{case}-{branch}-{quality}-z{cutoff}"+(f"-p{factor:g}" if branch=="partial" else "")
    if radial:name+="-radial"
    folder=ROOT/name
    folder.mkdir(exist_ok=True)
    assert not any(folder.iterdir()),"refusing to overwrite an existing run"
    os.chdir(folder)
    enginepath=MATCH if stock else ROOT/("engine-leading" if leading else "engine")
    sys.path[:0]=[str(enginepath),str(BASE/"radiation-and-slow-field-transfer-20261007")]
    import matching_common as source
    build=read(ROOT/("build-leading.json" if leading else "build.json"))
    assert digest(Path(source.camb.__file__).parent/"cambdll.dll")==build["stock" if stock else "binary"]
    early=EARLY/"runs/backgrounds/cold.npz"
    params=source.params_for(PROJECT if case=="heavy" else early)
    modes,projection=mode_table()
    if radial:
        with np.load(ROOT/"forest-radial-inputs.npz") as released:
            use=released["qualified"]
            modes=released["k_lcdm"] if case=="lcdm" else released["k"][use]
            projection=np.array([released["density"][use],released["momentum"][use]]).T
            assert np.all(modes<=5)
    if case=="heavy":
        params.DarkEnergy.set_table("SetMatching",modes,*projection.T)
    if case=="lcdm":
        params.DarkEnergy=source.camb.dark_energy.DarkEnergyFluid()
    params.DoLateRadTruncation=False
    native=source.camb.get_background(params)
    native.Params.Accuracy.IntTolBoost={"base":6.,"fine":6.4}[quality]
    times=native.conformal_time(red,tol=1e-10)
    names=source.camb.model.evolve_names
    start=time.monotonic()
    values=native.get_time_evolution(modes,times,vars=names,lAccuracyBoost=4)
    assert values.shape==(len(modes),len(red),len(names)) and np.isfinite(values).all()
    def field(name):
        return values[:,:,names.index(name)]
    assert np.all(field("mts_match_count")==(case=="heavy")) and not np.any(field("mts_nonheavy_change"))
    assert np.max(abs(field("a")/scale-1))<TOL
    bg=native.get_background_densities(scale,vars=["cdm","baryon","nu","neutrino","photon","de","tot"])
    if not stock:
        assert len(list(folder.glob("initial-*.bin")))==len(modes)
    with (folder/"result.npz").open("xb") as stream:
        np.savez_compressed(stream,k=modes,z=red,tau=times,names=names,raw=values,H=native.hubble_parameter(red),
            **{"bg_"+key:value for key,value in bg.items()},cutoff_index=index,pressure_factor=factor,leading_dispersive=leading)
    print(name,len(modes),len(red),"epochs",round(time.monotonic()-start,1),"seconds",flush=True)
if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("case",choices=["heavy","cold","lcdm"])
    parser.add_argument("factor",type=float)
    parser.add_argument("quality",choices=["base","fine"])
    parser.add_argument("--cutoff",type=int,default=99)
    parser.add_argument("--stock",action="store_true")
    parser.add_argument("--leading",action="store_true")
    parser.add_argument("--radial",action="store_true")
    args=parser.parse_args()
    run(args.case,args.factor,args.quality,args.cutoff,args.stock,args.leading,args.radial)

