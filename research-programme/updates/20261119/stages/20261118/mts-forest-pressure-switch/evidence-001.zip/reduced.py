from common import *
from readout import data,take,FOREST_Z,PRIMARY,write_csv
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp

def isolate(source,cutoff):
    arm=data(source)
    start=take(arm,cutoff);end=take(arm,4.2)+1
    block=slice(start,end);epoch=start;modes=arm["k"];val=arm["v"]
    scale=val["a"][:,epoch]
    hub=val["H"][:,epoch]
    with np.load(PROJECT) as src:
        mass=float(src["heavy_mass_mpc"])
        heavy=float(src["matching_density"]) if source.startswith("heavy") else 0.
    drho=(sum(arm["bg_"+bg][epoch]*val[name][:,epoch] for bg,name in
              [("cdm","delta_cdm"),("baryon","delta_baryon"),("nu","delta_nu"),("photon","delta_photon"),("neutrino","delta_neutrino")])/scale**2
          +val["mts_drho_s"][:,epoch]+val["mts_drho_h"][:,epoch])
    current=-(drho/2+modes*val["etak"][:,epoch])/hub
    cdm=val["delta_cdm"][:,epoch]
    seed=np.array([cdm,current,val["delta_baryon"][:,epoch]-cdm,val["v_baryon_cdm"][:,epoch],
                   arm["values"]["heavy_delta"][:,epoch]-cdm if heavy else np.zeros_like(cdm),arm["values"]["heavy_q"][:,epoch]])
    inputs=dict(k=modes,z=arm["z"][block],Hcon=arm["H"][block]/(1+arm["z"][block])/299792.458,
                gc0=arm["bg_cdm"][-1]/2,gb0=arm["bg_baryon"][-1]/2,gh0=heavy/2,mass=mass,seed=seed)
    return inputs

def predict(inputs,law,reference=None,tight=False):
    modes=inputs["k"];red=inputs["z"];efold=-np.log1p(red);mass=float(inputs["mass"])
    rate=CubicSpline(efold,np.log(inputs["Hcon"]))
    constants=np.array([inputs[key] for key in ("gc0","gb0","gh0")])
    active=constants[-1]>0
    if reference is not None:
        base_density=CubicSpline(efold,reference[0],axis=1)
        base_current=CubicSpline(efold,reference[1],axis=1)
    count=len(modes)
    def evolve(logscale,vector):
        cdm,cdot,relative_b,bvel,relative_h,hvel=vector.reshape(6,count)
        scale=np.exp(logscale);hub=np.exp(rate(logscale))
        gc,gb,gh=constants/scale
        stress=np.zeros(count)
        if active and law!="dust":
            ratio=modes/(scale*mass)
            sound=ratio**2/4 if law=="leading" else (ratio/(1+np.hypot(1.,ratio)))**2
            comoving=cdm+relative_h+3*hub*hvel/modes
            if reference is not None:
                comoving=comoving+base_density(logscale)+3*hub*base_current(logscale)/modes
            stress=sound*comoving
        drive=(gc+gb+gh)*cdm+gb*relative_b+gh*(relative_h+3*stress)
        result=np.array([cdot,-hub*cdot+drive,-modes*bvel,-hub*bvel,
                         -modes*hvel-3*hub*stress,-hub*hvel+modes*stress])
        return (result/hub).ravel()
    seed=inputs["seed"] if reference is None else np.zeros((6,count))
    calc=solve_ivp(evolve,(efold[0],efold[-1]),seed.ravel(),method="DOP853",t_eval=efold,
                   atol=1e-14 if tight else 1e-12,rtol=1e-12 if tight else 2e-10,
                   max_step=.04 if tight else .08)
    assert calc.success and np.isfinite(calc.y).all()
    cdm,cdot,relative_b,bvel,relative_h,hvel=calc.y.reshape(6,count,len(red))
    gc,gb,gh=constants[:,None]*(1+red)
    wave=modes[:,None];hub=inputs["Hcon"]
    current=gb*bvel+gh*hvel
    shear=-cdot/wave+3*current/wave**2
    force=(gc+gb+gh)*cdm+gb*relative_b+gh*relative_h+3*hub*current/wave
    return np.array([cdm+relative_b-3*hub*shear/wave,-wave*(bvel+shear)/hub,force])

def packet(path,**values):
    with (ROOT/path).open("xb") as stream:
        np.savez_compressed(stream,**values)

def freeze():
    guard();modest()
    assert not (ROOT/"heavy-off-fine-z49").exists()
    for case in ("heavy","cold"):
        for cutoff in (99,49):
            base=f"{case}-on-fine-z99"
            inputs=isolate(base,cutoff)
            output=f"{case}-forecast-z{cutoff}"
            packet(output+"-inputs.npz",**inputs)
            forecasts={law:predict(inputs,law) for law in ["dust","exact","leading"]}
            strict=predict(inputs,"leading",tight=True)
            assert np.max(abs(strict/forecasts["leading"]-1))<TOL
            packet(output+".npz",k=inputs["k"],z=inputs["z"],strict=strict,**forecasts)
    saved={path.name:digest(path) for path in ROOT.glob("*-forecast-*.npz")}
    assert len(saved)==8
    save(ROOT/"z49-forecast-lock.json",dict(inputs_and_predictions=saved,code=digest(ROOT/"reduced.py"),protocol=digest(ROOT/"REDUCED-TEST.md"),
           source="pre-existing z99 regular-field run; both start-49 forecasts isolated to z49 state + background",
           not_blind="prior native pressure-on history known; new dust counterfactual not yet calculated"))
    print("two starting times, both matter families, three laws locked")

def compare():
    guard();modest()
    locked=read(ROOT/"z49-forecast-lock.json")
    assert all(digest(ROOT/key)==value for key,value in locked["inputs_and_predictions"].items())
    rows=[];conditional=[]
    for case in ("heavy","cold"):
        for cutoff in (99,49):
            prefix=f"{case}-forecast-z{cutoff}"
            with np.load(ROOT/(prefix+".npz")) as stored: forecast=dict(stored)
            with np.load(ROOT/(prefix+"-inputs.npz")) as stored: inputs=dict(stored)
            on=data(f"{case}-on-fine-z{cutoff}") if case=="heavy" else data("cold-on-fine-z99")
            off=data(f"{case}-off-fine-z{cutoff}") if case=="heavy" else on
            start=take(off,cutoff);end=take(off,4.2)+1
            ref=[off["values"][key][:,start:end] for key in ("heavy_delta","heavy_q")]
            correction={law:predict(inputs,law,reference=ref) for law in ["leading","exact"]}
            if case=="cold":assert not np.any(correction["leading"])
            packet(prefix+"-anchored.npz",k=inputs["k"],z=inputs["z"],**correction)
            for epoch in FOREST_Z:
                pos=take(on,epoch);time=np.flatnonzero(forecast["z"]==epoch).item()
                for index,mode in enumerate(inputs["k"]):
                    for channel,key in enumerate(PRIMARY):
                        exact=on["values"][key][index,pos];dust=off["values"][key][index,take(off,epoch)]
                        full_wave=forecast["leading"][channel,index,time];full_dust=forecast["dust"][channel,index,time]
                        delta=correction["leading"][channel,index,time]
                        rows.append(dict(case=case,cutoff=cutoff,k=mode,z=epoch,channel=key,
                            native_on=exact,native_dust=dust,predicted_standalone_wave=full_wave,predicted_standalone_dust=full_dust,
                            true_dust_over_wave=dust/exact,predicted_dust_over_wave=full_dust/full_wave,
                            standalone_wave_error=full_wave/exact-1,standalone_dust_error=full_dust/dust-1,
                            standalone_contrast_error=full_dust/full_wave-dust/exact,
                            anchored_wave=dust+delta,anchored_wave_fraction_error=(dust+delta)/exact-1,
                            leading_vs_exact_over_signal=(delta-correction["exact"][channel,index,time])/exact))
    write_csv("reduced-forecast-test.csv",rows)
    summary={}
    for case in ("heavy","cold"):
        for cutoff in (99,49):
            subset=[row for row in rows if row["case"]==case and row["cutoff"]==cutoff]
            summary[f"{case}-z{cutoff}"]={key:max(abs(row[key]) for row in subset) for key in [
                "standalone_wave_error","standalone_dust_error","standalone_contrast_error","anchored_wave_fraction_error","leading_vs_exact_over_signal"]}
    save(ROOT/"reduced-results.json",summary)
    print(summary)
if __name__=="__main__":
    if sys.argv[1]=="freeze":freeze()
    elif sys.argv[1]=="compare":compare()

