from readout import *
from scipy.interpolate import PchipInterpolator
from numpy.polynomial import Polynomial
from numpy.polynomial.legendre import leggauss

def projection(k,density,velocity,floor,scale,order=12):
    assert k[0]<=floor<5. and k[-1]==5.
    assert min(density)>0 and min(velocity)>0
    nodes=k[k>floor]
    edges=np.log(np.r_[floor,nodes]);centers=(edges[1:]+edges[:-1])/2;width=np.diff(edges)/2
    sample,weights=leggauss(order)
    coordinate=(centers[:,None]+width[:,None]*sample).ravel()
    measure=(width[:,None]*weights).ravel()
    wave=np.exp(coordinate)
    dens=np.exp(PchipInterpolator(np.log(k),np.log(density))(coordinate))
    vel=np.exp(PchipInterpolator(np.log(k),np.log(velocity))(coordinate))*(floor/wave)**2
    primordial=2*np.pi**2*2.1e-9*(wave/.05)**(-.0347)/wave**3
    weighted=measure*wave**2*primordial*scale/(2*np.pi)
    result=np.array([[np.sum(weighted*dens**2),np.sum(weighted*dens*vel)],[np.sum(weighted*dens*vel),np.sum(weighted*vel**2)]])
    assert np.linalg.eigvalsh(result).min()>0
    return result

def bounds(test,ref):
    def polynomial(matrix):
        return Polynomial([matrix[0,0],2*(matrix[0,1]-matrix[0,0]),matrix[0,0]-2*matrix[0,1]+matrix[1,1]])
    num,den=map(polynomial,(test,ref))
    crit=(num.deriv()*den-den.deriv()*num).roots()
    where=[0.,1.]+[val.real for val in crit if abs(val.imag)<1e-8 and 0<val.real<1]
    ratios=num(np.array(where))/den(np.array(where))
    check=np.linspace(0,1,101)
    direct=num(check)/den(check)
    assert direct.min()>=ratios.min()-1e-10 and direct.max()<=ratios.max()+1e-10
    return ratios.min(),ratios.max()

def run():
    guard();modest()
    base={};new={}
    for name,short in [("heavy-on","hon"),("heavy-off","hoff"),("cold-on","cold"),("lcdm-on","lcdm")]:
        base[short]=data(name+("-base-z99" if short=="lcdm" else "-fine-z99"))
        new[short]=data(name+"-fine-z99-radial")
    state_test("heavy-on-fine-z99-radial","heavy-off-fine-z99-radial","survey")
    gridcheck=0
    for key in base:
        for index,mode in enumerate(new[key]["k"]):
            match=np.flatnonzero(base[key]["k"]==mode)
            if match.size:
                for epoch in FOREST_Z:
                    dif=[abs(new[key]["values"][col][index,take(new[key],epoch)]/base[key]["values"][col][match[0],take(base[key],epoch)]-1) for col in PRIMARY]
                    gridcheck=max(gridcheck,*dif)
    assert gridcheck<TOL
    inputs=read_csv(ROOT/"forest-radial-inputs.csv")
    binrows=[];entries=[];estimates=[]
    for row in inputs:
        epoch=float(row["z"]);kv=float(row["kv_s_per_km"])
        counts=dict(instrument=row["instrument"],z=epoch,kv=kv,k_parent=float(row["k_parent"]),k_lcdm=float(row["k_lcdm"]),qualified=row["common_qualified"]=="True")
        rowout=dict(counts,radial_gas_error=None,radial_velocity_error=None,radial_force_error=None,
                    amplitude_1pc=None,amplitude_5pc=None,band_dust_min_power_ratio=None,band_dust_max_power_ratio=None,
                    band_heavy_to_cold_min=None,band_heavy_to_cold_max=None,band_sampling_max_fraction=None)
        binrows.append(rowout)
        if not counts["qualified"]:continue
        matrices={};sampling=[]
        for short in new:
            floor=counts["k_lcdm" if short=="lcdm" else "k_parent"]
            measure=base[short]["H"][take(base[short],epoch)]/(1+epoch)
            assert abs(floor/(kv*measure)-1)<2e-11
            idx=np.argmin(abs(new[short]["k"]-floor))
            assert abs(new[short]["k"][idx]-floor)<1e-12
            native=new[short]["values"]
            pos=take(new[short],epoch)
            if short=="hoff":
                errors=[native[key][idx,pos]/new["hon"]["values"][key][idx,pos]-1 for key in PRIMARY]
                for lab,value in zip(["radial_gas_error","radial_velocity_error","radial_force_error"],errors):
                    rowout[lab]=value
                rowout["amplitude_1pc"]=max(abs(value) for value in errors)<.01
                rowout["amplitude_5pc"]=max(abs(value) for value in errors)<.05
            saved=base[short]
            basepos=take(saved,epoch)
            basek=saved["k"]
            baseD=saved["values"]["baryon_N"][:,basepos];baseU=saved["values"]["baryon_velocity"][:,basepos]
            grid,indices=np.unique(np.r_[new[short]["k"],basek],return_index=True)
            addD=np.r_[native["baryon_N"][:,pos],baseD][indices];addU=np.r_[native["baryon_velocity"][:,pos],baseU][indices]
            fine=projection(grid,addD,addU,floor,measure)
            coarse=projection(basek,baseD,baseU,floor,measure)
            high=projection(grid,addD,addU,floor,measure,24)
            quad=float(np.max(abs(high/fine-1)))
            assert quad<TOL
            err=float(np.max(abs(coarse/fine-1)))
            sampling.append(err)
            matrices[short]=fine
            entries.append(dict(**counts,branch=short,radial_floor=floor,upper=5.,truncated_DD=fine[0,0],truncated_DU=fine[0,1],
                                truncated_UU=fine[1,1],sampling_change=err,quadrature_change=quad))
        rowout["band_dust_min_power_ratio"],rowout["band_dust_max_power_ratio"]=bounds(matrices["hoff"],matrices["hon"])
        rowout["band_heavy_to_cold_min"],rowout["band_heavy_to_cold_max"]=bounds(matrices["hon"],matrices["cold"])
        rowout["band_sampling_max_fraction"]=max(sampling)
    write_csv("forest-bins.csv",binrows);write_csv("band-matrices.csv",entries)
    used=[row for row in binrows if row["qualified"]]
    report=dict(n=len(binrows),supported=len(used),radial_passing_1pc=sum(bool(row["amplitude_1pc"]) for row in used),radial_passing_5pc=sum(bool(row["amplitude_5pc"]) for row in used),
        max_shared_full_hierarchy_change=gridcheck,matrix_sampling_worst=max(row["sampling_change"] for row in entries),
        matrices_exceeding_sampling_tol=sum(row["sampling_change"]>TOL for row in entries),quadrature_worst=max(row["quadrature_change"] for row in entries),
        count_matrices=len(entries),largest_band_dust_ratio=max(row["band_dust_max_power_ratio"] for row in used),
        smallest_band_dust_ratio=min(row["band_dust_min_power_ratio"] for row in used),
        used_measured_powers=False,flux_score=None)
    save(ROOT/"forest-bins.json",report)
    print(report)
if __name__=="__main__":
    run()

