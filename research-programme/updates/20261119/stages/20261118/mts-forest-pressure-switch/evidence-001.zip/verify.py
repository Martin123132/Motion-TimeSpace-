from common import *
import csv
def table(name):
    with (ROOT/name).open(encoding="utf8",newline="") as source:
        return list(csv.DictReader(source))
def verify():
    guard();checks={}
    def check(name,condition):
        assert condition,name
        checks[name]=True
    source_hashes={}
    for tag in ("","-leading"):
        build=read(ROOT/("build"+tag+".json"))
        check("private binary"+tag,digest(ROOT/("engine"+tag)/"native/camb/cambdll.dll")==build["binary"])
        for path,value in build["inputs"].items():
            if path in source_hashes:assert source_hashes[path]==value
            source_hashes[path]=value
    source_hashes[str(MATCH/"native/camb/cambdll.dll")]=read(ROOT/"build.json")["stock"]
    archive=read(SPEC/"results/stage-integrity.json")["file_hashes"]
    for name in ("a200-w6-d8","a225-w6-d8","a250-w6-d8","a225-w4-d8","a225-w6-d10"):
        key="runs/projection/"+name+".npz"
        source_hashes[str(SPEC/key)]=archive[key]
    last=read(FOREST/"closeout.json")
    for key in ["native-heavy.npz","native-cold.npz","native-lcdm.npz","pivot-sourced-heavy.npz","flux-controls.csv"]:
        source_hashes[str(FOREST/key)]=last["files"][key]
    for key in [EARLY/"runs/backgrounds/cold.npz",EARLY/"runs/backgrounds/heavy.npz",EARLY/"runs/final-bg8-start/heavy.npz"]:
        source_hashes[str(key)]=last["input_hashes"][str(key)]
    for key in ("spectrum_common.py","project_grid.py"):
        source_hashes[str(SPEC/key)]=archive[key]
    for path in [BASE/"radiation-and-slow-field-transfer-20261007/radiation_common.py",BASE/"cosmology-reconnection-20261006/results/comparison/status.json",POST/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md"]:
        source_hashes[str(path)]=digest(path)
    for path,hsh in source_hashes.items():assert digest(Path(path))==hsh,path
    check("input fingerprints",len(source_hashes)>100)
    check("no build helpers left",not (ROOT/"compile-work").exists())
    for kind,other,epoch in [("heavy-on-base-z99","heavy-off-base-z99",99),("heavy-on-fine-z99","heavy-off-fine-z99",99),("heavy-on-fine-z99","heavy-leading-fine-z99",99),
        ("cold-on-base-z99","cold-off-base-z99",99),("cold-on-base-z99","cold-leading-base-z99",99),("heavy-on-fine-z49","heavy-off-fine-z49",49),
        ("heavy-on-fine-z99-radial","heavy-off-fine-z99-radial",99)]:
        with np.load(ROOT/kind/"result.npz") as left,np.load(ROOT/other/"result.npz") as right:
            modes=left["k"];idx=int(left["cutoff_index"])
            assert int(right["cutoff_index"])==idx and left["z"][idx]==epoch and np.array_equal(modes,right["k"])
            raw_a,raw_b=left["raw"],right["raw"]
            check("prehistory "+other,np.array_equal(raw_a[:,:idx+1],raw_b[:,:idx+1]) and np.array_equal(left["H"],right["H"]))
            if kind.startswith("cold"):
                check("all-cold exact null "+other,np.array_equal(raw_a,raw_b))
            for index,mode in enumerate(modes):
                filename=f"initial-{index+1:04d}.bin"
                payload=(ROOT/kind/filename).read_bytes()
                assert payload==(ROOT/other/filename).read_bytes()
                word=np.frombuffer(payload[:4],dtype="<i4")[0]
                state=np.frombuffer(payload[4:],dtype="<f8")
                assert state.size==word+3 and state[0]==mode and abs(state[2]*(1+epoch)-1)<TOL and np.isfinite(state).all()
            check("initial states "+other,len(list((ROOT/other).glob("initial-*.bin")))==len(modes))
    response=read(ROOT/"response.json")
    check("original accuracy",all(rec["worst_power_bound"]<TOL for rec in response["prior_power"].values()))
    check("stock and refinement",all(channel["max_fraction"]<TOL for rec in response["precision"].values() for channel in rec.values()))
    green=table("green-response.csv")
    for key in ("q_error_over_mode_scale","dust_q_error_over_mode_scale","density_error_over_clustered"):
        check("retarded integral "+key,len(green)==192 and max(abs(float(row[key])) for row in green)<TOL)
    scale=table("scale-test.csv")
    check("modes and resolution",len(scale)==24 and max(float(row["pair_resolution"]) for row in scale)<TOL)
    check("dust precision brackets",[float(row["k"]) for row in scale if row["pass_1pc"]=="True"][-1]==.8353625469578 and
          [float(row["k"]) for row in scale if row["pass_5pc"]=="True"][-1]==1.218814184842)
    rows=table("linear-switch.csv")
    for row in scale:
        batch=[r for r in rows if r["case"]=="heavy" and r["quality"]=="fine" and r["k"]==row["k"] and r["channel"] in ("baryon_N","baryon_velocity","force")]
        assert len(batch)==12 and abs(max(abs(float(r["off"])/float(r["on"])-1) for r in batch)-float(row["worst_amplitude"]))<1e-13
    check("physical percentages from raw pairs",True)
    report=read(ROOT/"leading-stress.json")
    check("leading realized law",report["realized_constitutive_max_fraction"]<TOL and report["coefficient_max_frac_after_switch"]<TOL)
    check("leading vs complete hierarchy",max(report["channel_max"].values())<TOL)
    lock=read(ROOT/"z49-forecast-lock.json")
    check("forecast still frozen",all(digest(ROOT/key)==value for key,value in lock["inputs_and_predictions"].items()) and digest(ROOT/"reduced.py")==lock["code"] and digest(ROOT/"REDUCED-TEST.md")==lock["protocol"])
    test=table("reduced-forecast-test.csv")
    for case in ("heavy","cold"):
        for cutoff in ("99","49"):
            local=[r for r in test if r["case"]==case and r["cutoff"]==cutoff]
            check("forecast rows "+case+cutoff,len(local)==288)
            check("standalone practical test "+case+cutoff,max(abs(float(r[key])) for r in local for key in ("standalone_wave_error","standalone_dust_error"))<.01)
            check("standalone numerical limitation preserved "+case+cutoff,max(abs(float(r["standalone_wave_error"])) for r in local)>TOL)
            check("anchored practical test "+case+cutoff,max(abs(float(r["anchored_wave_fraction_error"])) for r in local)<.01)
    geo=table("geodesic-and-source.csv")
    check("independent CDM geodesic",len(geo)==480 and max(abs(float(r["cold_geodesic_error_over_current"])) for r in geo)<TOL)
    check("baryon nongrav term retained",max(abs(float(r["baryon_nongrav_impulse_over_current"])) for r in geo)>TOL)
    check("known metric source terms",max(abs(float(r["unallocated_force"])/float(r["force"])) for r in geo)<TOL)
    controls=table("wave-stress-controls.csv")
    check("node test",len(controls)==12 and all(float(r["min_n_h"])==0 for r in controls if r["kind"]=="node"))
    for key in ("wave_continuity_error","wave_momentum_error","net_internal_force_fraction","expanding_energy_balance_error"):
        check("nonlinear balance "+key,max(abs(float(r[key])) for r in controls if r[key])<TOL)
    check("removing quantum stress fails",min(float(r["omit_stress_error_relative_to_momentum_div"]) for r in controls if r["kind"]=="smooth")>.1)
    with np.load(ROOT/"forest-radial-inputs.npz") as packet:
        check("radial gates",packet["raw"].shape[0]==32 and np.array_equal(packet["qualified"],(packet["k"]<=5)&(packet["closure"].max(axis=0)<2e-6)))
        check("new projection spot checks",packet["anchor_errors"].max()<TOL)
    bins=table("forest-bins.csv")
    check("both instruments",len(bins)==49 and sum(r["instrument"]=="MIKE" for r in bins)==21)
    check("out of band not zero",sum(r["qualified"]=="False" for r in bins)==7 and all(not r["radial_force_error"] and not r["band_dust_min_power_ratio"] for r in bins if r["qualified"]=="False"))
    check("exact radial outcomes",sum(r["amplitude_1pc"]=="True" for r in bins)==14 and sum(r["amplitude_5pc"]=="True" for r in bins)==21)
    matrices=table("band-matrices.csv")
    check("truncated quadratures",len(matrices)==168 and max(float(r["quadrature_change"]) for r in matrices)<TOL)
    check("sampling limits retained",sum(float(r["sampling_change"])>TOL for r in matrices)==154 and not read(ROOT/"forest-bins.json")["used_measured_powers"])
    for row in bins:
        if row["qualified"]!="True":continue
        sub={r["branch"]:r for r in matrices if r["instrument"]==row["instrument"] and r["kv"]==row["kv"] and r["z"]==row["z"]}
        for weight in (0,.1,.5,.9,1):
            def quadratic(key):
                rec=sub[key]
                return sum(float(rec[col])*factor for col,factor in [("truncated_DD",(1-weight)**2),("truncated_DU",2*weight*(1-weight)),("truncated_UU",weight**2)])
            ratio=quadratic("hoff")/quadratic("hon")
            assert float(row["band_dust_min_power_ratio"])-1e-9<=ratio<=float(row["band_dust_max_power_ratio"])+1e-9
    check("bias envelope controls",True)
    files={p.relative_to(ROOT).as_posix():digest(p) for p in sorted(ROOT.rglob("*")) if p.is_file() and p.name!="closeout.json"}
    close=ROOT/"closeout.json"
    full=dict(previous=digest(FOREST/"closeout.json"),checks=checks,inputs=source_hashes,files=files)
    if close.exists():
        assert read(close)==full
    elif "--seal" in sys.argv:
        save(close,full)
    print(len(checks),"checks",len(files),"files",len(source_hashes),"input hashes",digest(close) if close.exists() else "open")
if __name__=="__main__":
    modest()
    verify()

