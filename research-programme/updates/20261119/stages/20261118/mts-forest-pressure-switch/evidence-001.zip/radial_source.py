from common import *
from readout import data,take,read_csv,write_csv,FOREST_Z
sys.path.insert(0,str(SPEC))
from project_grid import projection
import matching_common as source

def run():
    guard();modest()
    powers=FOREST/"flux-controls.csv"
    assert digest(powers)==read(FOREST/"closeout.json")["files"][powers.name]
    rows=[(row["instrument"],float(row["z"]),float(row["k_velocity_s_per_km"])) for row in read_csv(powers) if row["control"]=="released_reference"]
    assert len(rows)==49
    points=sorted(set((red,kv) for _,red,kv in rows))
    assert len(points)==28
    hubble=data("heavy-on-base-z99")
    lcdm=data("lcdm-on-base-z99")
    modes=np.array([kv*hubble["H"][take(hubble,red)]/(1+red) for red,kv in points])
    conventional=np.array([kv*lcdm["H"][take(lcdm,red)]/(1+red) for red,kv in points])
    validation=np.array([.3425,1.,1.98095677855,5.])
    ordered=np.sort(np.r_[modes,validation])
    inputs=EARLY/"runs/backgrounds/heavy.npz"
    engine=source.camb.get_background(source.params_for(inputs))
    scale=np.load(EARLY/"runs/final-bg8-start/heavy.npz")["requested_scale"]
    eta=engine.conformal_time(1/scale-1,tol=1e-10)
    engine.Params.Accuracy.IntTolBoost=6
    names=["a","mts_drho_h","mts_q_h","mts_dp_h","H","mts_match_count"]
    values=engine.get_time_evolution(ordered,eta,vars=names,lAccuracyBoost=4)
    assert np.isfinite(values).all() and not np.any(values[:,:,-1])
    raw=dict(modes=ordered,values=values,names=np.array(names))
    parent=np.load(PROJECT)
    closure=[];anchors=[];active=None
    for tag,width,degree in [("a225",6,8),("a200",6,8),("a250",6,8),("a225",4,8),("a225",6,10)]:
        with np.load(SPEC/f"runs/projection/{tag}-w{width}-d{degree}.npz") as reference:
            projected=projection(raw,parent,float(reference["matching_scale"]),float(reference["matching_density"]),width,degree)
            if active is None:active=projected
            closure.append(projected["closure_error"])
            for channel in ("delta","momentum"):
                truth=reference["matching_"+channel][np.searchsorted(reference["modes"],validation)]
                new=projected[channel][np.searchsorted(ordered,validation)]
                anchors.append(float(np.max(abs(new/truth-1))))
    assert max(anchors)<TOL
    gates=np.max(closure,axis=0)<2e-6
    qualified=gates&(ordered<=5)
    records=[]
    for name,red,kv in rows:
        index=points.index((red,kv));idx=np.searchsorted(ordered,modes[index])
        records.append(dict(instrument=name,z=red,kv_s_per_km=kv,k_parent=modes[index],k_lcdm=conventional[index],
                            max_projection_error=max(row[idx] for row in closure),all_five_pressure_gates=bool(gates[idx]),
                            common_qualified=bool(qualified[idx]),only_radial_minimum=True))
    write_csv("forest-radial-inputs.csv",records)
    with (ROOT/"forest-radial-inputs.npz").open("xb") as stream:
        np.savez_compressed(stream,k=ordered,density=active["delta"],momentum=active["momentum"],closure=np.array(closure),
                            qualified=qualified,validation=validation,anchor_errors=anchors,k_lcdm=np.sort(np.r_[validation,conventional[modes<=5]]),
                            raw=values,raw_names=names)
    print("28 distinct k||; qualified",sum(qualified)-len(validation),"anchor replay",max(anchors),"closure",np.max(closure))
if __name__=="__main__":
    run()

