from pathlib import Path
import os
import sys
for library in ("OPENBLAS_NUM_THREADS","MKL_NUM_THREADS","OMP_NUM_THREADS","NUMEXPR_NUM_THREADS"):
    os.environ[library]="1"
sys.dont_write_bytecode=True
import hashlib
import json
import numpy as np
import psutil
from scipy.special import beta,betainc

HERE=Path(__file__).resolve().parent
POST=HERE.parent
PREVIOUS=POST/"mts-forest-first-tail-20261118"
LOCK="57abc992b64fe5769dff2848359bcd41884e114c4fae4f3e1918baf72906c4e9"
GAUGES=("vacuum","dust","field","both")
PREPS=("bare","prepared","free")
QUANTITIES=("proper","radius","radial","tangent","weyl_radial","ricci_trace","separation_radial","separation_angular","velocity_radial","velocity_angular","frame_a","lapse","speed","euler_energy","scalar_energy","scalar_active","lorentz","canonical_radial_momentum")
def sha(path):
    with Path(path).open("rb") as stream:return hashlib.file_digest(stream,"sha256").hexdigest()
def guard():
    p=psutil.Process();p.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS);p.cpu_affinity([p.cpu_affinity()[0]])
    assert sha(PREVIOUS/"closeout.json")==LOCK and not any((base/"STOP-REQUESTED").exists() for base in (POST,HERE,POST/"condensate-origin-20261003"))
def write(name,**arrays):
    with (HERE/name).open("xb") as stream:np.savez_compressed(stream,**arrays)
def read_np(name):
    with np.load(HERE/name,allow_pickle=False) as src:return dict(src)
def taper(radius,start,stop):
    return 1-betainc(6,6,np.clip((radius-start)/(stop-start),0,1))

class Grid:
    def __init__(self,count):
        self.r=np.linspace(0,48,count+1);self.step=48/count
        self.inv=1/np.where(self.r==0,1,self.r);self.inv[0]=0
        self.points=np.array([2.5,6.])
        self.shift=.05
        self.probes=(self.points[:,None]+[-self.shift,0.,self.shift]).ravel()
    def integral(self,values):
        out=np.empty_like(values);out[0]=0.;step=self.step
        left,mid,right=values[:-2:2],values[1::2],values[2::2]
        out[2::2]=np.cumsum(step/3*(left+4*mid+right))
        out[1::2]=out[:-2:2]+step/12*(5*left+8*mid-right)
        return out
    def first(self,values,parity):
        step=self.step;out=np.empty_like(values)
        out[2:-2]=(values[:-4]-8*values[1:-3]+8*values[3:-1]-values[4:])/(12*step)
        out[0]=(1-parity)*(8*values[1]-values[2])/(12*step)
        out[1]=(parity*values[1]-8*values[0]+8*values[2]-values[3])/(12*step)
        out[-2:]=np.gradient(values[-4:],step,edge_order=2)[-2:]
        return out
    def second(self,values):
        out=np.empty_like(values);unit=12*self.step**2
        out[2:-2]=(-values[:-4]+16*values[1:-3]-30*values[2:-2]+16*values[3:-1]-values[4:])/unit
        out[0]=(-2*values[2]+32*values[1]-30*values[0])/unit
        out[1]=(-values[1]+16*values[0]-30*values[1]+16*values[2]-values[3])/unit
        out[-2:]=0.
        return out
    def at(self,values,points):
        mesh=points/self.step;j=np.floor(mesh).astype(int);s=mesh-j
        return (-s*(s-1)*(s-2)*values[j-1]+3*(s+1)*(s-1)*(s-2)*values[j]-3*(s+1)*s*(s-2)*values[j+1]+(s+1)*s*(s-1)*values[j+2])/6
    def metric(self,state):
        field,mom,dens,flow=state
        grad=self.first(field,1);sp=grad**2+mom**2;pot=.5*field**2;r=self.r;inv=self.inv
        factor=np.ones_like(r)
        for iteration in range(6):
            wh=np.sqrt(1+flow**2*factor)
            dust=dens*np.sqrt(factor)*wh
            energy=dust+.5*sp*factor+pot
            mass=self.integral(r*r*energy);updated=1-2*mass*inv
            assert np.min(updated)>.95
            if np.max(abs(updated-factor))<3e-15:break
            factor=updated
        else:raise ArithmeticError("radial mass constraint")
        aa=1/np.sqrt(factor);vv=flow/aa/wh
        se=.5*sp*factor+pot;sr=dust*vv**2+se-2*pot;st=.5*(mom**2-grad**2)*factor-pot
        current=dust*vv-mom*grad*factor
        slope=(mass*inv**2+r*sr)/factor
        loga=self.integral(slope)
        alpha=np.exp(loga-loga[-1])/aa[-1];bridge=alpha/aa
        logs=(r*energy-mass*inv**2)/factor
        return aa,alpha,bridge,logs,slope,mass,energy,sr,st,current,se,dust,vv,grad
    def initial(self,arm,prep,source_scale=1.,amp_scale=1.):
        radius=self.r;shape=np.maximum(1-(radius/5)**2,0)**6
        norm=125*.5*beta(1.5,7)
        ordinary=.002*source_scale*shape/norm
        if arm in ("shell","shellfield"):
            assert prep=="bare"
            ring=np.maximum(1-((radius-24)/4)**2,0)**6
            ordinary=.002*source_scale*ring/(4*(24**2*beta(.5,7)+16*beta(1.5,7)))
        flat=np.zeros_like(radius)
        has_b=arm in ("both","dust","shell","shellfield");has_h=arm in ("both","field","shellfield")
        dens=ordinary.copy() if has_b else flat.copy()
        _,lapse,*_=self.metric(np.stack([flat,flat,dens,flat]))
        free=(prep=="free")
        phase=.73 if prep in ("free","phase") else 0.
        amplitude=.0008*amp_scale*taper(radius,16,26)*float(has_h)
        correction=np.zeros_like(radius)
        if has_b and prep!="bare":
            newton_mass=self.integral(radius**2*ordinary)
            potential=self.integral(newton_mass*self.inv**2)
            potential=potential-potential[-1]-newton_mass[-1]/radius[-1]
            potential2=self.integral(2*radius**2*potential)*self.inv**2
            correction=self.integral(potential2)
            correction=(correction-self.at(correction,np.array([12.]))[0])*taper(radius,10,15)
        field=amplitude*np.cos(phase)*(1+correction)
        vel=amplitude*(-np.sin(phase)*(1+correction)/(lapse if has_b and prep!="bare" else 1.)
            +(.1*np.sinc(.7*radius/np.pi) if free else 0.))
        mom=vel.copy()
        for repeat in range(5):
            state=np.stack([field,mom,dens,flat]);aa=self.metric(state)[0];mom=aa*vel
        state=np.stack([field,mom,dens,flat]);met=self.metric(state)
        data=np.zeros((7,len(self.probes)));data[0]=self.probes;data[3]=1;data[5]=1
        data[4]=-self.probes*self.at(met[0]*met[9],self.probes)
        return state,data
    def rhs(self,state,probe,outputs=False):
        field,mom,dens,flow=state
        aa,alpha,bb,logs,slope,mass,en,sr,st,current,se,dust,vv,grad=self.metric(state)
        rad,imp,proper,jr,vr,jt,vt=probe
        get=lambda arr:self.at(arr,rad)
        ar,al,ls,lp=get(aa),get(alpha),get(logs),get(slope)
        lor=np.sqrt(1+(imp/ar)**2);speed=imp/ar/lor
        mean=mass*self.inv**3;mean[0]=en[0]/3
        tidal_r=get(en-sr+2*st-2*mean)
        boosted=lor**2*(get(sr)-2*speed*get(current)+speed**2*get(en))
        tidal_t=get(mean)+boosted
        weyl=-2*get(mean-(en-sr+st)/3)
        clock=al/lor
        dp=np.array([al*speed/ar,-al*lor*(lp-speed**2*ls),clock,clock*vr,-clock*tidal_r*jr,clock*vt,-clock*tidal_t*jt])
        if outputs:
            return np.stack([proper,rad,tidal_r,tidal_t,weyl,tidal_r+2*tidal_t,jr,jt,vr,vt,ar,al,speed,get(en),get(se),get(2*mom**2/aa**2-field**2),lor,imp]),(aa,alpha,mass,current,en)
        lap=self.second(field)+2*self.inv*grad;lap[0]=3*self.second(field)[0]
        flux=dens*bb*vv;div=self.first(flux,-1)+2*self.inv*flux;div[0]=3*self.first(flux,-1)[0]
        material=np.stack([bb*mom,bb*(lap+(slope-logs)*grad)-alpha*aa*field,-div,
            -alpha*np.sqrt(1+(flow/aa)**2)*(slope-vv**2*logs)-bb*vv*self.first(flow,-1)])
        return material,dp

def simulate(count,arm,prep,scale=1.,amplitude=1.,courant=.3,outputs=64):
    guard()
    grid=Grid(count);state,probes=grid.initial(arm,prep,scale,amplitude)
    length=6.5;steps=int(np.ceil(length/(courant*grid.step)/64))*64;dt=length/steps
    outputs=int(outputs);assert steps%outputs==0
    snaps=[];clocks=[];metric=[];budgets=[];rad=grid.r
    for step in range(steps+1):
        if step%(steps//outputs)==0:
            snap,(aa,alpha,mass,current,energy)=grid.rhs(state,probes,True)
            snaps.append(snap);clocks.append(dt*step)
            metric.append([aa,alpha,mass,current])
            budgets.append([mass[-1],grid.integral(rad**2*state[2])[-1],np.max(2*mass*grid.inv),np.min(state[2]),np.max(abs(state[:3,-4:])),np.max(abs(state))])
        if step==steps:break
        first,p1=grid.rhs(state,probes)
        second,p2=grid.rhs(state+.5*dt*first,probes+.5*dt*p1)
        third,p3=grid.rhs(state+.5*dt*second,probes+.5*dt*p2)
        fourth,p4=grid.rhs(state+dt*third,probes+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);probes+=dt/6*(p1+2*p2+2*p3+p4)
    assert np.isfinite(state).all() and np.isfinite(probes).all()
    suffix=f"-o{outputs}" if outputs!=64 else ""
    name=f"n{count}-{arm}-{prep}-s{scale:g}-h{amplitude:g}-c{courant:g}{suffix}.npz"
    write(name,time=clocks,grid=rad,variables=QUANTITIES,probes=snaps,metric=metric,budgets=budgets,initial_r=grid.probes)
    print(name,"ADM drift",float(np.ptp(np.array(budgets)[:,0])),flush=True)
if __name__=="__main__":simulate(int(sys.argv[1]),sys.argv[2],sys.argv[3],*map(float,sys.argv[4:]))

