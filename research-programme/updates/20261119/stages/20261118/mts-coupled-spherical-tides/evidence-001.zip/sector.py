from resolved import *
from compare import INDEX,KEYS,TARGET,table,peak
from relational import interp

class Sector(Stable):
    def capture(self,state,probe):
        rad=self.r;aa,alpha,bb,ls,lp,mass,en,sr,st,current,se,dust,vv,grad=self.metric(state)
        h,mom,cons,imp=state
        kinetic=(mom/aa)**2;gradient=(grad/aa)**2;srh=se-h*h;jh=-mom*grad/aa**2
        sd=dust*vv**2;jd=dust*vv;md=self.integral(rad**2*dust);mh=self.integral(rad**2*se)
        work=self.integral(rad**3*alpha*aa*((se+srh)*jd-(dust+sd)*jh))
        fixed=self.points_fixed;ids=np.rint(fixed/self.step).astype(int)
        sections=np.stack([md[ids],mh[ids],(rad**2*bb*jd)[ids],(rad**2*bb*jh)[ids],work[ids],mass[ids]])
        vals=super().rhs(state,self.actual(probe),True)[0]
        r=probe[0];get=lambda vec:self.at(vec,r)
        v=vals[INDEX["speed"]];boost=1/(1-v*v)
        enclosed=lambda mat:get(mat*self.inv**3)
        d0=get(dust-sd);ds=boost*(get(sd)-2*v*get(jd)+v**2*get(dust));mden=enclosed(md);mhen=enclosed(mh)
        out=np.stack([d0-2*mden,mden+ds,-2*(mden-get(dust-sd)/3),get(kinetic-gradient)-2*mhen,
            mhen+boost*(get(srh)-2*v*get(jh)+v*v*get(se)),-2*(mhen-get(se-gradient)/3),
            2*get(se)+2*mhen,(1+abs(v))/(1-abs(v))*get(se)+mhen,2*mhen+2*get(se)/3])
        truth=vals[[INDEX["radial"],INDEX["tangent"],INDEX["weyl_radial"]]]
        assert np.max(abs(out[:3]+out[3:6]-truth))<2e-17
        return sections,np.vstack([probe[2],out]),max(abs(md+mh-mass))
    def actual(self,probe):
        actual=probe.copy();actual[[3,5]]+=1
        return actual
def record(count,arm,prep):
    guard();grid=Sector(count);grid.points_fixed=np.array([2.5,6.,12.,30.]);state,probe=grid.initial(arm,prep)
    probe[[3,5]]-=1
    steps=int(np.ceil(6.5/(.26*grid.step)/256))*256;dt=6.5/steps;snap=[];motions=[];times=[];checks=[]
    for step in range(steps+1):
        if step%(steps//256)==0:
            sect,mot,err=grid.capture(state,probe);snap.append(sect);motions.append(mot);times.append(step*dt);checks.append(err)
        if step==steps:break
        first,p1=grid.push(state,probe);second,p2=grid.push(state+dt/2*first,probe+dt/2*p1)
        third,p3=grid.push(state+dt/2*second,probe+dt/2*p2);fourth,p4=grid.push(state+dt*third,probe+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);probe+=dt/6*(p1+2*p2+2*p3+p4)
    write(f"sectors-{count}-{arm}-{prep}.npz",times=times,mass=snap,motion=motions,split_defect=checks,radii=grid.points_fixed)
    print(count,arm,prep,"mass partition",max(checks))
def check():
    from scipy.integrate import cumulative_simpson
    records=[];tides=[]
    for count in (960,1920):
        compare={}
        for arm,prep in (("dust","bare"),("both","bare"),("both","prepared"),("both","free")):
            raw=read_np(f"sectors-{count}-{arm}-{prep}.npz");trace=raw["motion"];times=raw["times"];sections=raw["mass"]
            compare[arm,prep]=np.stack([interp(trace[:,0,idx],trace[:,1:,idx],TARGET) for idx in (1,4)])
            accum=lambda values:cumulative_simpson(values,x=times,axis=0,initial=0.)
            for j,r in enumerate(raw["radii"]):
                q=sections[:,:,j].T;work=accum(q[4])
                for idx,key in enumerate(("dust","field")):
                    held=q[idx]-q[idx,0];flux=accum(q[2+idx]);wanted=(1 if idx==1 else -1)*work
                    error=peak(held+flux-wanted);mag=peak(wanted)
                    records.append(dict(grid=count,arm=arm,prep=prep,r=r,sector=key,mass_change_peak=peak(held),flux_peak=peak(flux),
                        signed_work_final=wanted[-1],work_peak=mag,residual=error,relative_to_work=error/mag if mag>0 else None,
                        relative_to_mass=error/q[idx,0] if q[idx,0]>0 else None,work_resolved=bool(mag>0 and error<2e-5*mag)))
        for prep in ("bare","prepared","free"):
            out=compare["both",prep];ordinary=compare["dust","bare"]
            for slot,r in enumerate((2.5,6.)):
                for col,kind in enumerate(("radial","tangent","weyl")):
                    response=out[slot,:,3+col];bound=out[slot,:,6+col]
                    delta=out[slot,:,col]-ordinary[slot,:,col]
                    total=response+delta
                    assert np.all(bound>=0) and np.all(abs(response)<=bound+2e-15*max(bound)) and np.all(abs(total)<=bound+abs(delta)+2e-15*max(bound))
                    tides.append(dict(grid=count,prep=prep,r0=r,quantity=kind,direct_peak=peak(response),bound_peak=peak(bound),
                        ordinary_readjustment_peak=peak(delta),total_extra_peak=peak(total),sufficient_total_bound=peak(bound+abs(delta)),
                        direct_final=response[-1],ordinary_delta_final=delta[-1],net_final=total[-1]))
    table("sector-work.csv",records);table("sector-bounds.csv",tides);print("work resolution",sum(r["work_resolved"] for r in records),"/",len(records))
if __name__=="__main__":
    guard()
    if sys.argv[1]=="score":check()
    else:record(int(sys.argv[1]),sys.argv[2],sys.argv[3])

