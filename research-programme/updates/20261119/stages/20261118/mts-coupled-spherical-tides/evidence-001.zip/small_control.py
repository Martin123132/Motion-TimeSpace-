from certificate import Grid, TARGET, ceilings, guard, interp, np, peak, read_np, table
from scipy.optimize import brentq


def evaluate():
    guard()
    mesh = Grid(1920)
    norm_packet = read_np("sobolev-1920-both-prepared-h0.00625.npz")
    field = read_np("account-1920-both-prepared-h0.00625.npz")
    ordinary = read_np("account-1920-dust-bare.npz")
    assert np.array_equal(norm_packet["time"], field["time"])
    assert np.array_equal(field["time"], ordinary["time"])
    initial, _ = mesh.initial("both", "prepared", 1., 1/160)
    dust, _ = mesh.initial("dust", "bare")
    metric, reference = mesh.metric(initial), mesh.metric(dust)
    hzero = norm_packet["energy"][0, 0]
    assert 0 < hzero and abs(mesh.integral(mesh.r**2*metric[0]*metric[1]*metric[10])[-1]/hzero-1) < 2e-12
    norm = sum(norm_packet["energy"][0])
    target = 2e-5
    assert norm_packet["bmin"] >= .98 and norm_packet["vmin"] >= .98 and max(norm_packet["growth"]) < .03
    assert np.all(np.sum(norm_packet["energy"],axis=1) <= norm*np.exp(norm_packet["growth"])*(1+1e-12))
    records = []
    for index, radius in ((1, 2.5), (4, 6.)):
        data = field["events"][:,:,index]
        control = ordinary["events"][:,:,index]
        for packet in (data,control):
            assert packet[0,0] == 0 and packet[-1,0] >= TARGET[-1] and np.all(np.diff(packet[:,0]) > 0)
            assert min(packet[:,1]) >= .9*radius and max(packet[:,1]) <= 1.1*radius
            assert peak(packet[:,12]) < .02 and np.min(packet[:,13]) >= 1 and np.max(packet[:,13]) < 1.01
        assert np.max(abs(1+control[:,2])) < 1.02
        mass, density, conserved = (mesh.at(value, np.array([radius]))[0] for value in (reference[5], reference[11], dust[2]))
        def budget(energy):
            return ceilings(energy, radius, TARGET[-1], mass, density, conserved)
        epsilon, mu, angular, radial = budget(norm)
        limit = brentq(lambda energy:max(budget(energy)[2:])-target,0,.001,xtol=1e-19,rtol=2e-14)
        measured = interp(data[:,0],data[:,2:4],TARGET)-interp(control[:,0],control[:,2:4],TARGET)
        radial_change, angular_change = np.max(abs(measured),axis=0)
        assert norm < limit and peak(data[:,7]) <= epsilon and 0 < data[0,5] <= mu
        assert 0 < radial_change <= radial < target and 0 < angular_change <= angular < target
        records.append(dict(r0=radius,amplitude_fraction=1/160,initial_norm=norm,sufficient_norm=limit,
            max_integrated_C=max(norm_packet["growth"]),min_B=float(norm_packet["bmin"]),min_V=float(norm_packet["vmin"]),
            radial_change=radial_change,radial_ceiling=radial,angular_change=angular_change,
            angular_ceiling=angular,target=target,coordinate_end=field["time"][-1],proper_end=data[-1,0]))
    return records


if __name__ == "__main__":
    table("small-nonzero-control.csv", evaluate())

