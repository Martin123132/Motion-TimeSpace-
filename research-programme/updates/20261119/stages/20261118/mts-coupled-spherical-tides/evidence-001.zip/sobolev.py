from resolved import *
from compare import peak,table,TARGET
from scipy.integrate import cumulative_simpson

def test(count,arm,prep,amp):
    guard();grid=Stable(count);r=grid.r;state,probe=grid.initial(arm,prep,1.,amp);probe[[3,5]]-=1
    steps=int(np.ceil(6.5/(.26*grid.step)/256))*256;dt=6.5/steps
    times=[];stored=[];terms=[];trace=[];hs=[]
    for step in range(steps+1):
        if step%(steps//256)==0:
            aa,alpha,b,ls,lp,mass,en,sr,st,current,se,dust,vd,grad=grid.metric(state)
            field,mom,_,_=state;u=r*field;p=r*mom;ur=field+r*grad
            urr=2*grad+r*grid.second(field);pr=mom+r*grid.first(mom,1)
            m3=mass*grid.inv**3;m3[0]=en[0]/3
            pot=alpha*aa*(1+2*m3+sr-en);br=b*(lp-ls);brr=grid.first(br,-1);potr=grid.first(pot-1,1)
            assert np.min(pot)>.95 and np.min(b)>.95
            h0=.5*grid.integral(b*(p*p+ur*ur)+pot*u*u)[-1]
            h1=.5*grid.integral(b*(pr*pr+urr*urr)+pot*ur*ur)[-1]
            extra=grid.integral(b*brr*pr*ur+2*b*br*pr*urr-b*potr*pr*u+b*brr*urr*p+pot*br*ur*p)[-1]
            c=2*peak(br)+peak(brr*np.sqrt(b/pot))+peak(brr)+peak(potr*np.sqrt(b/pot))+peak(br*np.sqrt(pot/b))
            stored.append([b,pot]);terms.append([p*p+ur*ur,u*u,pr*pr+urr*urr,ur*ur]);hs.append([h0,h1,extra,c])
            trace.append([grid.at(se,np.asarray([rho]))[0] for rho in probe[0,[1,4]]]);times.append(dt*step)
        if step==steps:break
        first,p1=grid.push(state,probe);second,p2=grid.push(state+.5*dt*first,probe+.5*dt*p1)
        third,p3=grid.push(state+.5*dt*second,probe+.5*dt*p2);fourth,p4=grid.push(state+dt*third,probe+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);probe+=dt/6*(p1+2*p2+2*p3+p4)
    from scipy.interpolate import CubicSpline
    sampled=np.asarray(stored);gradt=CubicSpline(times,sampled-1,axis=0).derivative()(times)
    hist=np.asarray(hs);terms=np.asarray(terms);trace=np.asarray(trace)
    ctime=np.max(abs(gradt/sampled),axis=(1,2))
    driver=np.array([.5*grid.integral(bt*material[0]+vt*material[1])[-1] for (bt,vt),material in zip(gradt,terms)])
    driver1=hist[:,2]+np.array([.5*grid.integral(bt*material[2]+vt*material[3])[-1] for (bt,vt),material in zip(gradt,terms)])
    integ=lambda val:cumulative_simpson(val,x=np.array(times),initial=0)
    growth=integ(hist[:,3]+ctime);bound=sum(hist[0,:2])*np.exp(growth)
    herror=hist[:,0]-hist[0,0]-integ(driver);h1error=hist[:,1]-hist[0,1]-integ(driver1)
    caps=[];vmin=np.min(sampled[:,1]);bmin=np.min(sampled[:,0])
    for slot,r in enumerate((2.5,6.)):
        lower=.9*r;upper=1.1*r;eps=bound[-1]*(3/bmin+(1+2/lower**2)/vmin)/lower**2
        caps.append(eps)
        assert peak(trace[:,slot])<=eps
    assert np.all(hist[:,0]+hist[:,1]<=bound+1e-14)
    write(f"sobolev-{count}-{arm}-{prep}-h{amp:g}.npz",time=times,energy=hist[:,:2],growth=growth,C=hist[:,3]+ctime,bound=bound,
        h0_defect=herror,h1_defect=h1error,drives=np.stack([driver,driver1]),local=trace,epsilon=caps,bmin=bmin,vmin=vmin)
    print(arm,prep,amp,"initial H",sum(hist[0,:2]),"growth",growth[-1],"epsilon",caps)
if __name__=="__main__":test(int(sys.argv[1]),sys.argv[2],sys.argv[3],float(sys.argv[4]))

