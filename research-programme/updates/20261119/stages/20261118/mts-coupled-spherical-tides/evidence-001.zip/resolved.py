from evolve import *

class Stable(Grid):
    def push(self,state,probe):
        actual=probe.copy();actual[[3,5]]+=1.
        return super().rhs(state,actual)
    def sample(self,state,probe,indices):
        actual=probe.copy();actual[[3,5]]+=1.
        vals,met=super().rhs(state,actual,True);vals[[6,7]]=probe[[3,5]]
        _,_,_,_,slope,mass,energy,sr,st,current,se,dust,speed,grad=self.metric(state)
        aa,alpha=met[:2];rr=self.r
        gm=2*mass*self.inv;weak_a=gm*aa/(1+np.sqrt(1-gm))
        radialint=self.integral(slope);weak_alpha=np.expm1(.5*np.log1p(-gm[-1])+radialint-radialint[-1])
        connection_space=(1+weak_alpha)*aa*(mass*self.inv**2+rr*sr)
        connection_time=-rr*aa**2*current
        slabs=np.stack([weak_a[indices],weak_alpha[indices],connection_space[indices],connection_time[indices]])
        return vals,slabs
def run(count,arm,prep,cfl=.26):
    guard();grid=Stable(count);state,probe=grid.initial(arm,prep)
    probe[[3,5]]-=1.
    slots=np.array([np.arange(-15,16)+round(r/grid.step) for r in grid.points])
    steps=int(np.ceil(6.5/(cfl*grid.step)/256))*256;dt=6.5/steps
    clocks=[];data=[];metric=[]
    for step in range(steps+1):
        if step%(steps//256)==0:
            vals,slabs=grid.sample(state,probe,slots)
            clocks.append(step*dt);data.append(vals);metric.append(slabs)
        if step==steps:break
        first,p1=grid.push(state,probe)
        second,p2=grid.push(state+dt/2*first,probe+dt/2*p1)
        third,p3=grid.push(state+dt/2*second,probe+dt/2*p2)
        fourth,p4=grid.push(state+dt*third,probe+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);probe+=dt/6*(p1+2*p2+2*p3+p4)
    assert np.isfinite(data).all() and np.isfinite(metric).all()
    write(f"resolved-{count}-{arm}-{prep}-c{cfl:g}.npz",time=clocks,probes=data,weak_metric=metric,tiles=grid.r[slots],steps=steps,dt=dt)
    print(count,arm,prep,steps,flush=True)
if __name__=="__main__":run(int(sys.argv[1]),sys.argv[2],sys.argv[3],*map(float,sys.argv[4:]))

