from relational import *
from math import factorial

class Resolved:
    def __init__(self,count,arm,prep,cfl=.26):
        self.data=read_np(f"resolved-{count}-{arm}-{prep}-c{cfl:g}.npz")
    def raw(self):
        rr=self.data["probes"]
        return np.array([interp(rr[:,INDEX["proper"],idx],rr[:,:,idx][:,[INDEX[q] for q in KEYS]],TARGET) for idx in (1,4)])
    def geometric(self,parity=None):
        data=self.data;mp=data["weak_metric"];times=data["time"];tiles=data["tiles"];raw=data["probes"]
        if parity is not None:
            origin=int(round(tiles[0,0]/(tiles[0,1]-tiles[0,0])))%2
            assert all(int(round(tile[0]/(tile[1]-tile[0])))%2==origin for tile in tiles)
            start=(parity-origin)%2;tiles=tiles[:,start::2];mp=mp[:,:,:,start::2]
        time_step=times[1]-times[0];grid=np.arange(-4,5)
        system=np.stack([grid**j for j in range(9)])
        co=lambda order:np.linalg.solve(system,np.eye(9)[order]*factorial(order))
        def time_derivative(arr,order):
            window=np.lib.stride_tricks.sliding_window_view(arr,9,axis=0)
            return (window-window[...,4,None])@(co(order)/time_step**order)
        spatial_step=tiles[0,1]-tiles[0,0]
        def value_derivative(values,positions,slot,order):
            selected=tiles[slot];mesh=(positions-selected[0])/spatial_step
            indices=np.rint(mesh).astype(int);delta=mesh-indices
            powers=np.arange(9)
            rhs=np.stack([np.where(powers>=order,np.array([factorial(int(k))/factorial(max(0,int(k)-order)) for k in powers])*value**np.maximum(0,powers-order),0.) for value in delta],axis=1)
            weights=np.linalg.solve(system,rhs).T
            stencil=values[np.arange(len(indices))[:,None],indices[:,None]+grid]
            return np.sum((stencil-stencil[:,4,None])*weights,axis=1)/spatial_step**order+(stencil[:,4] if order==0 else 0.)
        def both(arm):
            time0,geo=arm
            return interp(time0,geo,TARGET[6:-6],8)
        results=[];target=TARGET[6:-6]
        for slot,idx in enumerate((1,4)):
            frame=raw[4:-4,:,idx];radius=frame[:,INDEX["radius"]];v=frame[:,INDEX["speed"]]
            weak_a,weak_l,space_conn,time_conn=np.moveaxis(mp[:,:,slot,:],1,0)
            def read(values,order=0):return value_derivative(values,radius,slot,order)
            av=read(weak_a[4:-4]);alv=read(weak_l[4:-4]);aa=1+av;al=1+alv
            ar=read(weak_a[4:-4],1);lr=read(weak_l[4:-4],1)
            at=read(time_derivative(weak_a,1));lt=read(time_derivative(weak_l,1))
            rt=(read(weak_l[4:-4],2)/aa-lr*ar/aa**2-read(time_derivative(weak_a,2))/al+at*lt/al**2)/(al*aa)
            rc=(read(space_conn[4:-4],1)-read(time_derivative(time_conn,1)))/(al*aa)
            sb=ar/(aa**3*radius);ang=av*(2+av)/(aa*radius)**2
            bundle=[]
            for radial,normal,mom in ((rt,lr/(al*aa**2*radius),at/(al*aa**2*radius)),(rc,read(space_conn[4:-4])/(aa*al*radius),read(time_conn[4:-4])/(aa**2*radius))):
                tan=(normal+2*v*mom+v*v*sb)/(1-v*v)
                weyl=(radial-normal+sb-ang)/3
                bundle.append(both((frame[:,INDEX["proper"]],np.column_stack([radial,tan,weyl,radial+2*tan]))))
            results.append(bundle)
        return np.asarray(results)
def analyze():
    guard();records=[];geometry=[];curves=[]
    ridges=(("transition-free","bare"),("prepared","prepared"),("free","free"),("phase","phase"))
    def combo(mapping,p,idx):
        get=lambda arm,prep:mapping[arm,prep][idx]
        return get("both",p)-get("dust","bare")-get("field",p if p in ("phase","free") else "bare")
    datasets={}
    for count,cfl,preps in ((960,.26,PREPS+("phase",)),(1920,.26,PREPS+("phase",)),(1920,.13,("bare","prepared")),(3840,.26,("bare","prepared"))):
        sources=[("dust","bare"),("field","bare"),*[( "both",p) for p in preps]]
        sources+=list(dict.fromkeys(("field",p) for p in preps if p in ("phase","free")))
        dataset={}
        for arm,prep in sources:
            resolved=Resolved(count,arm,prep,cfl)
            dataset[arm,prep]=[resolved.raw(),resolved.geometric()]
        datasets[count,cfl]=dataset
        for prep in preps:
            raw=combo(dataset,prep,0);geo=combo(dataset,prep,1)
            for slot,rad in enumerate((2.5,6.)):
                for j,key in enumerate(KEYS[:4]):
                    anchor=raw[slot,6:-6,j]
                    for idx,name in enumerate(("metric-only","connection")):
                        residual=peak(geo[slot,idx,:,j]-anchor)
                        geometry.append(dict(grid=count,cfl=cfl,prep=prep,r0=rad,quantity=key,method=name,abs_error=residual,
                            mixed_scale=peak(anchor),relative_to_mixed=residual/peak(anchor),passes=residual<2e-5*peak(anchor)))
    for prep in PREPS+("phase",):
        targetset=datasets[3840,.26] if prep in ("bare","prepared") else datasets[1920,.26]
        ref=combo(targetset,prep,0);curves.append(ref)
        for (grid,cfl),other in datasets.items():
            if ("both",prep) not in other or other is targetset:continue
            diff=combo(other,prep,0)-ref
            for slot,rad in enumerate((2.5,6.)):
                for j,key in enumerate(KEYS):
                    scale=peak(ref[slot,:,j]);rel=peak(diff[slot,:,j])/scale
                    records.append(dict(grid=grid,cfl=cfl,prep=prep,r0=rad,quantity=key,abs_error=peak(diff[slot,:,j]),
                        mixed_scale=scale,relative_to_mixed=rel,passes=rel<2e-5))
    table("resolved-mesh-controls.csv",records);table("geometric-mixed-controls.csv",geometry)
    write("resolved-waveforms.npz",curves=curves,preps=PREPS+("phase",),target=TARGET,keys=KEYS)
    print("geometric checks",len(geometry),"mesh",len(records))
if __name__=="__main__":analyze()

