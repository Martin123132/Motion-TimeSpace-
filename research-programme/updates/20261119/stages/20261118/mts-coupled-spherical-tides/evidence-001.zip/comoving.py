from sector import *
from scipy.integrate import cumulative_simpson
from scipy.interpolate import CubicSpline

class Account(Sector):
    def accounting(self,state,probe):
        rad=self.r;aa,alpha,bb,ls,lp,mass,en,sr,st,current,se,dust,vv,grad=self.metric(state)
        h,mom,cons,imp=state;fact=1/aa**2
        scalar_flux=-mom*grad*fact;dustflux=dust*vv
        mh=self.integral(rad**2*se);md=self.integral(rad**2*dust)
        fwo=np.sqrt(1+(imp/aa)**2)/aa;reduced=(-2*mass*self.inv+imp**2*fact**2)/(1+fwo)
        binding=self.integral(rad**2*cons*reduced);bflux=rad**2*cons*bb*vv*reduced
        work=self.integral(rad**3*alpha*aa*((2*se-h**2)*dustflux-(dust+dust*vv**2)*scalar_flux))
        fixed=np.rint(self.points_fixed/self.step).astype(int)
        sums=np.stack([binding[fixed],bflux[fixed],mh[fixed],(rad**2*bb*scalar_flux)[fixed],work[fixed],md[fixed],(rad**2*bb*dustflux)[fixed]])
        r=probe[0];get=lambda x:self.at(x,r)
        ap=get(aa);lor=np.hypot(1,probe[1]/ap);v=probe[1]/ap/lor
        xp=get(grad**2*fact);pp=get(mom**2*fact);eh=get(se);jh=get(scalar_flux);srh=get(se-h**2)
        smove=lor**2*(srh-2*v*jh+v**2*eh)
        observed=np.stack([probe[2],r,probe[3],probe[5],get(mass),get(mh),
            r**2*lor/ap*(v*eh-jh),eh,jh,smove,pp-xp,get(dust*(1-vv**2)),v,ap,get(vv),probe[4],probe[6]])
        return sums,observed
def run(count,arm,prep,amplitude=1.):
    guard();grid=Account(count);grid.points_fixed=np.array([2.5,6.,12.,30.]);state,probe=grid.initial(arm,prep,1.,amplitude)
    probe[[3,5]]-=1.;steps=int(np.ceil(6.5/(.26*grid.step)/256))*256;dt=6.5/steps
    sums=[];events=[];times=[]
    for step in range(steps+1):
        if step%(steps//256)==0:
            a,b=grid.accounting(state,probe);sums.append(a);events.append(b);times.append(dt*step)
        if step==steps:break
        first,p1=grid.push(state,probe);second,p2=grid.push(state+.5*dt*first,probe+.5*dt*p1)
        third,p3=grid.push(state+.5*dt*second,probe+.5*dt*p2);fourth,p4=grid.push(state+dt*third,probe+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);probe+=dt/6*(p1+2*p2+2*p3+p4)
    suffix="" if amplitude==1. else f"-h{amplitude:g}"
    write(f"account-{count}-{arm}-{prep}{suffix}.npz",time=times,fixed=sums,events=events,radii=grid.points_fixed)
def cumulative(arr):
    return cumulative_simpson(arr,x=TARGET,axis=0,initial=0)
def diagnose(count):
    guard();records=[];workrows=[]
    get=lambda arm,prep:read_np(f"account-{count}-{arm}-{prep}.npz")
    dust=get("dust","bare")
    for prep in ("bare","prepared","free"):
        total=get("both",prep);alone=get("field","free" if prep=="free" else "bare")
        sf=total["fixed"];hf=alone["fixed"];df=dust["fixed"];time=total["time"]
        accum=lambda x:cumulative_simpson(x,x=time,initial=0)
        for j,r in enumerate(total["radii"]):
            b=sf[:,:,j];h=hf[:,:,j];d=df[:,:,j]
            work=accum(b[:,4]);scale=peak(work)
            for lbl,held,flux,sign in (("dust-binding",b[:,0],b[:,1],-1),("matched-dust-binding",b[:,0]-d[:,0],b[:,1]-d[:,1],-1),
                                      ("field-excess",b[:,2]-h[:,2],b[:,3]-h[:,3],1)):
                error=peak(held-held[0]+accum(flux)-sign*work)
                workrows.append(dict(prep=prep,r0=r,sector=lbl,work_peak=scale,residual=error,relative=error/scale if scale>0 else None,
                    passes=scale>0 and error<2e-5*scale))
        for slot,idx in enumerate((1,4)):
            rad=total["radii"][slot];lower=.9*rad;upper=1.1*rad;vmax=.02;amax=1.01;T=TARGET[-1];eps=2*.0008**2
            initial_cap=eps*rad**3/3
            raw=total["events"][:,:,idx];refraw=dust["events"][:,:,idx]
            curve=interp(raw[:,0],raw,TARGET);ref=interp(refraw[:,0],refraw,TARGET)
            _,radius,jr,jt,ms,mh,rate,e,j,sprime,kin,rho,vel,metric,vd,rvel,tvel=curve.T
            _,rb,jrb,jtb,mref,*_=ref.T
            m0=mref[0];d0=rho[0]*metric[0];rhob=ref[0,11]
            assert np.max(abs(vel))<vmax and np.max(metric)<amax and np.min(radius)>lower and max(radius)<upper and np.min(rb)>lower and max(rb)<upper
            assert peak(e)<eps and mh[0]<initial_cap and 0<=ms[0]-m0<=mh[0]*(1+2e-12)
            assert peak(1+jrb)<1.02 and np.min(1+jr)>.95
            bm=initial_cap+T*upper**2*(1+vmax)/np.sqrt(1-vmax*vmax)*eps
            kr=2*m0/lower**3;force=bm/lower**2+upper*(1+vmax)/(1-vmax)*eps
            c=lambda k:2*np.sinh(T*np.sqrt(k)/2)**2/k if k else T*T/2
            s=lambda k:np.sinh(T*np.sqrt(k))/np.sqrt(k) if k else T
            br=force*c(kr);kj=2*(m0+bm)/lower**3+2*eps
            fj=1.02*(2*bm/lower**3+6*m0*br/lower**4+2*eps)+(rad/lower)**2*d0*amax*initial_cap/rad+2*rhob*rad**2*br/lower**3
            bj=rad*amax*eps*s(kj)+fj*c(kj)
            measured_r=peak(jr-jrb);measured_t=peak(jt-jtb)
            predicted_rvel=rvel[0]+cumulative((2*ms/radius**3-kin)*(1+jr)-rho[0]*(rad/radius)**2)
            predicted_tvel=tvel[0]+cumulative((-ms/radius**2-radius*sprime)/rad)
            err=peak(ms-ms[0]-cumulative(rate))
            records.append(dict(prep=prep,r0=rad,initial_mass_excess=ms[0]-m0,initial_scalar_mass=mh[0],max_scalar_energy=peak(e),
                max_comoving_energy_flux=peak(rate),moving_mass_excursion=peak(ms-ms[0]),moving_mass_balance_residual=err,
                moving_mass_relative=err/peak(ms-ms[0]) if peak(ms-ms[0]) else None,
                dust_number_residual=peak(rho*(1+jr)*(radius/rad)**2-rho[0]),inner_velocity_slip=peak(vd-vel),
                radial_jacobi_rate_error=peak(predicted_rvel-rvel),transverse_jacobi_rate_error=peak(predicted_tvel-tvel),
                radial_separation_change=measured_r,angular_separation_change=measured_t,
                rigorous_radial_ceiling_given_inputs=bj,rigorous_angular_ceiling_given_inputs=br/rad,
                holds=measured_r<=bj and measured_t<=br/rad,energy_envelope=eps,mass_bound=bm))
    table(f"comoving-bound-{count}.csv",records);table(f"balanced-work-{count}.csv",workrows)
    print(count,"fixed work passing",sum(r["passes"] for r in workrows),"of",len(workrows),"separation ceilings",[r["holds"] for r in records])
if __name__=="__main__":
    if sys.argv[1]=="check":diagnose(int(sys.argv[2]))
    else:run(int(sys.argv[1]),sys.argv[2],sys.argv[3],float(sys.argv[4]) if len(sys.argv)>4 else 1.)

