from relational import *
import math
from scipy.integrate import quad
from numpy.polynomial import Polynomial

def prediction(source,amplitude,prep,arm):
    radius=5.;base=.002*source;normal=base/(125*.5*beta(1.5,7))
    amp=.0008*amplitude if arm in ("field","both") else 0.
    present=arm in ("both","dust")
    ordinary=lambda r:normal*max(0.,1-(r/radius)**2)**6 if present else 0.
    phi=np.zeros(15);phi[0]=-normal*radius**2/14
    for power in range(7):
        phi[2*power+2]=normal*math.comb(6,power)*(-1/radius**2)**power/((2*power+2)*(2*power+3))
    fcoef=np.zeros(17)
    for power,val in enumerate(phi):fcoef[power+2]=2*val/((power+2)*(power+3))
    func=Polynomial(fcoef);edge=func(radius);slope=func.deriv()(radius)
    constant=-(slope+base)*radius**2
    c0=edge+base*radius-constant/radius
    def kernel(r):
        if not present or prep!="prepared":return 0.,0.
        zero=-base*12+c0+constant/12
        if r<=radius:return func(r)-zero,func.deriv()(r)
        return -base*r+c0+constant/r-zero,-base-constant/r**2
    def stress(r,mass):
        correction,deriv=kernel(r);field=amp*(1+correction)
        fact=1-2*mass/max(r,1e-100);dg=ordinary(r)*np.sqrt(fact)
        grad=fact*(amp*deriv)**2
        return np.array([dg+.5*(grad+field**2),.5*(grad-field**2),-.5*(grad+field**2)])
    def rhs(r,y):return np.atleast_1d(r*r*stress(r,float(y[0]))[0])
    sol=solve_ivp(rhs,(0,6.1),[0.],rtol=2e-13,atol=5e-18,method="DOP853",max_step=.1,dense_output=True)
    assert sol.success
    exact=[];leading=[]
    for rad in (2.5,6.):
        mass=float(sol.sol(rad)[0]);e,sr,st=stress(rad,mass)
        exact.append([e-sr+2*st-2*mass/rad**3,sr+mass/rad**3])
        volume=lambda radius:-ordinary(radius)*amp**2*radius**2/6
        integrand=lambda radius:radius**2*(volume(radius)+amp**2*kernel(radius)[0])
        mixedmass=quad(integrand,0,rad,points=[5] if rad>5 else None,epsabs=1e-24,epsrel=1e-13)[0]
        leading.append([volume(rad)-2*mixedmass/rad**3,mixedmass/rad**3-amp**2*kernel(rad)[0]])
    return np.array(exact),np.array(leading)
def check():
    guard();records=[]
    for prep in ("bare","prepared"):
        for s,h in ((1.,1.),(.5,1.),(1.,.5)):
            both,pred=prediction(s,h,prep,"both")
            summed=both-prediction(s,0.,"bare","dust")[0]-prediction(0.,h,"bare","field")[0]
            dense=s==h==1
            observed=decompose(1920 if dense else 960,prep,s,h,dense=dense)[2][:,0,:2]
            for idx,rad in enumerate((2.5,6.)):
                for col,key in enumerate(("radial","tangent")):
                    expected=summed[idx,col];measured=observed[idx,col]
                    records.append(dict(prep=prep,source_fraction=s,field_amplitude_fraction=h,r0=rad,quantity=key,
                        initial_mixed=measured,independent_constraint=expected,leading_cross_derivative=pred[idx,col],
                        relative_to_exact=(measured-expected)/expected,leading_remainder=(expected-pred[idx,col])/expected))
    table("initial-cross-law.csv",records)
    print("exact initial law",max(abs(r["relative_to_exact"]) for r in records),"leading difference",max(abs(r["leading_remainder"]) for r in records))
if __name__=="__main__":check()

