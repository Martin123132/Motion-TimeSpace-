from compare import *
from functools import lru_cache

def interp(axis,values,query,width=8):
    output=[]
    for value in query:
        start=np.clip(np.searchsorted(axis,value)-width//2,0,len(axis)-width)
        picks=slice(start,start+width);knots=axis[picks];block=values[picks]
        centre=width//2
        weights=np.ones(width)
        for idx in range(width):
            others=np.arange(width)!=idx
            weights[idx]=np.prod((value-knots[others])/(knots[idx]-knots[others]))
        output.append(block[centre]+weights@(block-block[centre]))
    return np.array(output)

@lru_cache(maxsize=100)
def traces(count,arm,prep="bare",mass=1.,amp=1.,dense=False,width=8):
    if arm=="vacuum":
        output=np.zeros((2,len(TARGET),len(KEYS)))
        output[:,:,-2:]=1.
        return output
    suffix="-c0.15-o256" if dense else "-c0.3"
    with np.load(HERE/f"n{count}-{arm}-{prep}-s{mass:g}-h{amp:g}{suffix}.npz",allow_pickle=False) as src:
        ps=src["probes"]
        return np.stack([interp(ps[:,INDEX["proper"],idx],ps[:,:,idx][:,[INDEX[q] for q in KEYS]],TARGET,width) for idx in (1,4)])
def decompose(count,prep,source=1.,amp=1.,dense=False,width=8):
    field_prep=prep if prep in ("phase","free") else "bare"
    vac=traces(count,"vacuum")
    dust=traces(count,"dust","bare",source,1.,dense,width)-vac
    field=traces(count,"field",field_prep,1.,amp,dense,width)-vac
    total=traces(count,"both",prep,source,amp,dense,width)-vac
    return dust,field,total-dust-field
def compare_all():
    guard();scores=[];shapes=[];shells=[];pair=[]
    for prep in ("bare","prepared","free","phase"):
        base,field,mixed=decompose(1920,prep,dense=True)
        variants={"time-grid-and-output":decompose(1920,prep)[2] if prep!="phase" else None,
            "half-spatial":decompose(960,prep)[2],"readout-10":decompose(1920,prep,dense=True,width=10)[2]}
        if prep!="phase":variants["quarter-spatial"]=decompose(480,prep)[2]
        for p,rad in enumerate((2.5,6.)):
            for j,name in enumerate(KEYS):
                m=mixed[p,:,j];f=field[p,:,j];b=base[p,:,j]
                for label,other in variants.items():
                    if other is None:continue
                    error=peak(other[p,:,j]-m)
                    scores.append(dict(prep=prep,r0=rad,quantity=name,test=label,absolute=error,
                        relative_to_mixed=error/peak(m) if peak(m) else None,passes=error<2e-5*peak(m)))
                shapes.append(dict(prep=prep,r0=rad,quantity=name,ordinary_peak=peak(b),field_peak=peak(f),extra_peak=peak(m+f),
                    mixed_peak=peak(m),mixed_over_ordinary=peak(m)/peak(b) if peak(b)>0 else None,
                    mixed_initial=m[0],mixed_final=m[-1],standard_initial=b[0],standard_final=b[-1]))
        if prep in ("prepared","bare"):
            full=decompose(960,prep)[2]
            for label,response,expected in (("half-ordinary",decompose(960,prep,.5)[2],.5),("half-scalar-field",decompose(960,prep,1.,.5)[2],.25)):
                for p,rad in enumerate((2.5,6.)):
                    for j,name in enumerate(KEYS):
                        half=response[p,:,j];big=full[p,:,j]
                        pair.append(dict(prep=prep,test=label,r0=rad,quantity=name,peak_ratio=peak(half)/peak(big),
                            departure_from_leading_scaling=peak(half/expected-big)/peak(big)))
    for arm,ref in (("shellfield","field"),("shell","vacuum")):
        dense=arm=="shellfield"
        scalar=traces(1920,arm,"bare",1.,1.,dense);baseline=traces(1920,ref,"bare",1.,1.,dense)
        for p,rad in enumerate((2.5,6.)):
            for j,name in enumerate(KEYS):
                zero=1. if name.startswith("separation") else 0.
                scale=peak(baseline[p,:,j]-zero);diff=peak(scalar[p,:,j]-baseline[p,:,j])
                shells.append(dict(arm=arm,r0=rad,quantity=name,proper_abs=diff,reference_peak=scale,
                    normalized=diff/scale if scale>1e-17 else None))
    table("convergence.csv",scores);table("relational-tides.csv",shapes)
    table("source-scaling.csv",pair);table("causal-null.csv",shells)
    print("own-scale high temporal/spatial failures",[(label,sum(not r["passes"] for r in scores if r["test"]==label)) for label in variants])
if __name__=="__main__":compare_all()

