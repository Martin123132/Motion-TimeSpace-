from small_control import TARGET, guard, interp, np, peak, read_np, table


def differences(mesh,radius_index,suffix):
    arms=(f"account-{mesh}-both-prepared{suffix}.npz",f"account-{mesh}-dust-bare.npz")
    traces=[]
    for name in arms:
        data=read_np(name)["events"][:,:,radius_index]
        assert np.all(np.diff(data[:,0])>0) and data[0,0]==0 and data[-1,0]>=TARGET[-1]
        traces.append(interp(data[:,0],data[:,2:4],TARGET))
    return traces[0]-traces[1]


def evaluate_refinement():
    guard()
    records=[]
    for radius,index in ((2.5,1),(6.,4)):
        lower=differences(1920,index,"-h0.00625")
        finer=differences(3840,index,"-h0.00625")
        original=differences(3840,index,"")
        for column,axis in enumerate(("radial","angular")):
            signal=peak(finer[:,column])
            error=peak(finer[:,column]-lower[:,column])
            scale=peak(original[:,column])
            records.append(dict(r0=radius,axis=axis,nonzero_peak=signal,mesh_difference=error,
                relative_mesh_difference=error/signal,passes_original_gate=error<=2e-5*signal,
                original_peak=scale,observed_peak_ratio=signal/scale,amplitude_squared=(1/160)**2))
    return records


if __name__=="__main__":
    table("small-nonzero-refinement.csv",evaluate_refinement())

