from comoving import *
from scipy.optimize import brentq

def oracle(rad,source):
    total=.002*source;dmax=total/(125*.5*beta(1.5,7))
    density=dmax*max(0,1-(rad/5)**2)**6
    mass=total*betainc(1.5,7.,min((rad/5)**2,1))
    cap=2*total/(3*total/dmax)**(1/3)
    timescale=np.sqrt(rad**3/(8*mass))
    phase=np.array([brentq(lambda eta:timescale*(eta+np.sin(eta))-t,0,np.pi) for t in TARGET])
    dphase=-(1.5/rad-.5*rad**2*density/mass)*(phase+np.sin(phase))/(1+np.cos(phase))
    rr=.5*rad*(1+np.cos(phase));stretch=.5*(1+np.cos(phase)-rad*np.sin(phase)*dphase)
    return rr,stretch,rr/rad,mass,density,cap
def test():
    guard();out=[]
    for arm,prep in (("dust","bare"),("both","bare"),("both","prepared"),("both","free")):
        raw=read_np(f"account-1920-{arm}-{prep}.npz")
        for slot,idx in enumerate((1,4)):
            r0=(2.5,6.)[slot]
            rr,jr,jt,mn,density,cap=oracle(r0,1.)
            data=raw["events"][:,:,idx];sol=interp(data[:,0],data,TARGET)
            eps=0 if arm=="dust" else 2*.0008**2;mu=eps*r0**3/3;T=TARGET[-1]
            lower=.9*r0;upper=1.1*r0;vmax=.02;amax=1.01
            assert min(rr)>lower and peak(jr)<1.02
            binding=cap/(1+np.sqrt(1-cap));bmass=mu+T*upper**2*(1+vmax)/np.sqrt(1-vmax**2)*eps+binding*mn
            cr=lambda val:2*np.sinh(.5*T*np.sqrt(val))**2/val
            acc=bmass/lower**2+upper*(1+vmax)/(1-vmax)*eps
            br=acc*cr(2*mn/lower**3);kj=2*(mn+bmass)/lower**3+2*eps
            fj=1.02*(2*bmass/lower**3+6*mn*br/lower**4+2*eps)+(r0/lower)**2*density*(amax*mu/r0+binding)+2*density*r0**2*br/lower**3
            bj=r0*amax*eps*np.sinh(np.sqrt(kj)*T)/np.sqrt(kj)+fj*cr(kj)
            rd=peak(sol[:,1]-rr);jd=peak(sol[:,2]-(jr-1));td=peak(sol[:,3]-(jt-1))
            assert rd<=br and jd<=bj and td<=br/r0
            out.append(dict(arm=arm,prep=prep,r0=r0,newton_mass=mn,initial_gravitating_mass=sol[0,4],ordinary_compactness_bound=cap,
                initial_mass_deficit=mn-sol[0,4],energy_envelope=eps,radius_difference=rd,radius_ceiling=br,radial_separation_difference=jd,
                radial_ceiling=bj,angular_separation_difference=td,angular_ceiling=br/r0))
    table("newton-bound.csv",out);print("Newton limits",len(out))
if __name__=="__main__":test()

