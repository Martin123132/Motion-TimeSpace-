from evolve import *
from scipy.interpolate import CubicSpline

def solve(count,prep,shell=False):
    guard();grid=Grid(count);rad=grid.r;inv=grid.inv
    ordinary=grid.initial("shell" if shell else "dust","bare")[0][2]
    mb=grid.integral(rad**2*ordinary);ab=mb*inv;lp=mb*inv**2
    lb=grid.integral(lp);lb-=lb[-1]+mb[-1]/rad[-1];bb=lb-ab
    bp=2*lp-rad*ordinary
    profile=.0008*taper(rad,16,26);phase=.73 if prep in ("free","phase") else 0.
    seed=profile*np.cos(phase);kick=-profile*np.sin(phase)
    momentum=kick+(.1*profile*np.sinc(.7*rad/np.pi) if prep=="free" else 0.)
    correction=grid.integral(grid.integral(2*rad**2*lb)*inv**2)
    correction=(correction-grid.at(correction,np.array([12.]))[0])*taper(rad,10,15) if prep!="bare" else np.zeros_like(rad)
    state=np.stack([seed,momentum,seed*correction,ab*momentum+(kick*(correction-lb) if prep!="bare" else 0.),np.zeros_like(rad),np.zeros_like(rad),np.zeros_like(rad)])
    def one(field,dens,pr,pt):
        mus=field*inv**3;mus[0]=dens[0]/3
        return np.stack([dens-pr+2*pt-2*mus,pr+mus,-2*(mus-(dens-pr+pt)/3)])
    eb=one(mb,ordinary,np.zeros_like(rad),np.zeros_like(rad))
    def calc(time,state,out=False):
        f,p,u,v,dvel,dc,dis=state
        fp=grid.first(f,1);up=grid.first(u,1);lap=grid.second(f)+2*inv*fp;lap[0]=3*grid.second(f)[0]
        ed=.5*(p*p+fp*fp+f*f);pres=ed-f*f
        tang=.5*(p*p-fp*fp-f*f);flux=-p*fp
        mh=grid.integral(rad**2*ed);ah=mh*inv;lhp=mh*inv**2+rad*pres
        if not out:
            lapu=grid.second(u)+2*inv*up;lapu[0]=3*grid.second(u)[0]
            df=ordinary*dvel
            div=grid.first(df,-1)+2*inv*df;div[0]=3*grid.first(df,-1)[0]
            return np.stack([p,lap-f,v+bb*p,lapu-u+bb*lap+bp*fp-(lb+ab)*f,-lhp,-div,dvel])
        sel=lambda group:np.stack([grid.at(row,grid.points) for row in group],axis=-1)
        dp=lap-f;ptp=grid.first(p,1);ded=p*dp+fp*ptp+f*p
        dpress=ded-2*f*p;dtang=p*dp-fp*ptp-f*p
        h=one(mh,ed,pres,tang)
        he=one(-rad**2*flux,ded,dpress,dtang)
        ex=p*v+fp*up-ab*(p*p+fp*fp)+f*u
        sx=ex-2*f*u;tx=p*v-fp*up-ab*(p*p-fp*fp)-f*u
        dx=dc-ah*ordinary
        wave=one(grid.integral(rad**2*ex),ex,sx,tx)
        dust=one(grid.integral(rad**2*dx),dx,np.zeros_like(rad),np.zeros_like(rad))
        vb=-time*lp;rb=.5*time*vb
        motion=rb*np.array([grid.first(row,1) for row in h])+dis*np.array([grid.first(row,1) for row in eb])
        clock=-time*lb*he
        boost=np.zeros_like(h);boost[1]=-2*vb*flux
        jmix=-p*up-v*fp+2*ab*p*fp+ordinary*dvel
        vel=grid.at(-rad*(jmix+ab*flux),grid.points)
        j0=grid.at(-rad*flux,grid.points)
        return np.array([sel(group) for group in (wave,dust,motion,clock,boost,h,eb)]),vel,j0
    steps=int(np.ceil(6.4/(.26*grid.step)/256))*256;dt=6.4/steps
    outcomes=[];times=[]
    for step in range(steps+1):
        t=step*dt
        if step%(steps//256)==0:
            got,vel,j0=calc(t,state,True);outcomes.append(got);times.append(t)
            if step==0:dv=vel.copy();dh=j0.copy()
        if step==steps:break
        x1=calc(t,state);x2=calc(t+dt/2,state+.5*dt*x1);x3=calc(t+dt/2,state+.5*dt*x2);x4=calc(t+dt,state+dt*x3)
        state+=dt/6*(x1+2*x2+2*x3+x4)
    out=np.array(outcomes);time=np.array(times);mixed=out[:,:5].sum(axis=1)
    def twice(values,initial):
        curve=CubicSpline(time,values,axis=0);first=curve.antiderivative();both=first.antiderivative()
        linear=np.asarray(initial)-first(0)
        return both(time)-both(0)+time.reshape((-1,)+(1,)*(values.ndim-1))*linear
    hv=np.column_stack([dh,np.zeros(2)]);xv=np.column_stack([dv,np.zeros(2)])
    jb=twice(-out[:,6,:,:2],np.zeros((2,2)));jh=twice(-out[:,5,:,:2],hv)
    jx=twice(-mixed[:,:,:2]-out[:,5,:,:2]*jb-out[:,6,:,:2]*jh,xv)
    suffix="-shell" if shell else ""
    write(f"variation-{count}-{prep}{suffix}.npz",time=time,mixed=mixed,parts=out,jacobi=jx,
        branches=["field-stress","ordinary-motion-volume","moving-event","observer-clock","frame-boost","field-alone","ordinary-alone"])
    print(prep,suffix,"max mixed",np.max(abs(mixed),axis=(0,2)))
if __name__=="__main__":solve(int(sys.argv[1]),sys.argv[2],sys.argv[3:]==["shell"])

