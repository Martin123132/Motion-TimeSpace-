from initial_law import *

def test():
    guard();real=read_np("resolved-waveforms.npz")
    checks=[];pieces=[];null=[];initial=[]
    for prep in ("bare","prepared","free","phase"):
        def projected(count):
            src=read_np(f"variation-{count}-{prep}.npz");mode=src["mixed"]
            totals=np.concatenate((mode,mode[:,:,:1]+2*mode[:,:,1:2],src["jacobi"]),axis=-1)
            return src,totals[::2].transpose(1,0,2)
        src,y=projected(1920);other,coarse=projected(960)
        test=real["curves"][list(real["preps"]).index(prep)]
        if prep in ("bare","prepared"):
            base=decompose(960,prep)[2]
            bh=decompose(960,prep,.5)[2]*2
            hf=decompose(960,prep,1,.5)[2]*4
            estimate=base+2*(bh-base)+4/3*(hf-base)
        for slot,rad in enumerate((2.5,6.)):
            for j,key in enumerate(KEYS):
                pred=y[slot,:,j]
                checks.append(dict(prep=prep,r0=rad,quantity=key,nonlinear_peak=peak(test[slot,:,j]),predicted_peak=peak(pred),
                    prediction_error=peak(pred-test[slot,:,j])/peak(test[slot,:,j]),mesh_error=peak(pred-coarse[slot,:,j])/peak(pred),
                    zero_strength_extrapolation=peak(pred-estimate[slot,:,j])/peak(pred) if prep in ("bare","prepared") else None))
            for k,key in enumerate(("radial","tangent","weyl_radial")):
                for col,label in enumerate(src["branches"][:5]):
                    arr=src["parts"][:,col,slot,k]
                    pieces.append(dict(prep=prep,r0=rad,quantity=key,part=label,peak=peak(arr),final=arr[-1],
                        mixed_final=src["mixed"][-1,slot,k]))
            if prep in ("bare","prepared"):
                expected=prediction(1.,1.,prep,"both")[1]
                for k,key in enumerate(("radial","tangent")):
                    left=y[slot,0,k];right=expected[slot,k]
                    initial.append(dict(prep=prep,r0=rad,quantity=key,relative=abs(left/right-1)))
    for count in (960,1920):
        shell=read_np(f"variation-{count}-bare-shell.npz")
        for slot,rad in enumerate((2.5,6.)):
            for j,key in enumerate(("radial","tangent")):
                origin=shell["parts"][:,0,slot,j];clock=shell["parts"][:,3,slot,j]
                null.append(dict(grid=count,r0=rad,quantity=key,field_peak=peak(origin),clock_peak=peak(clock),
                    contact_relative=peak(origin+clock)/peak(clock),all_parts_relative=peak(shell["mixed"][:,slot,j])/peak(clock)))
    table("retarded-prediction.csv",checks);table("retarded-parts.csv",pieces);table("retarded-shell.csv",null);table("retarded-initial.csv",initial)
    print("shell cancellation",max(r["all_parts_relative"] for r in null),"initial",max(r["relative"] for r in initial))
if __name__=="__main__":test()

