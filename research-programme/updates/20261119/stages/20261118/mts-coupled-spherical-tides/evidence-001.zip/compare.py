from evolve import *
import csv
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from scipy.optimize import brentq

TARGET=np.linspace(0,6.4,129)
INDEX={key:idx for idx,key in enumerate(QUANTITIES)}
KEYS=["radial","tangent","weyl_radial","ricci_trace","separation_radial","separation_angular"]
def table(name,records):
    with (HERE/name).open("x",encoding="utf8",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(records[0]));writer.writeheader();writer.writerows(records)
def packet(count,arm,prep="bare",scale=1.,amplitude=1.,courant=.3):
    name=f"n{count}-{arm}-{prep}-s{scale:g}-h{amplitude:g}-c{courant:g}.npz"
    return read_np(name)
def curve(src,probe,keys,target=TARGET):
    sample=src["probes"][:,:,probe]
    clock=sample[:,INDEX["proper"]]
    assert np.all(np.diff(clock)>0) and target[-1]<=clock[-1]
    return CubicSpline(clock,sample[:,[INDEX[key] for key in keys]],axis=0)(target)
def peak(value):return float(np.max(abs(value)))
def diagnostics(count):
    grid=Grid(count);rows0=[];forces=[];wholes=[];checks=[];history=[]
    load=lambda arm,prep="bare":packet(count,arm,prep)
    for arm,prep in (("dust","bare"),("field","bare"),("both","bare"),("both","prepared"),("both","free"),("field","free"),("vacuum","bare"),("shell","bare"),("shellfield","bare")):
        src=load(arm,prep);clocks=src["time"];budget=src["budgets"];metric=src["metric"]
        delta=clocks[1]-clocks[0];active=slice(3,-3)
        aa=metric[:,0];alpha=metric[:,1];mass=metric[:,2];current=metric[:,3]
        dt=lambda matrix:np.tensordot(np.array([-1,9,-45,0,45,-9,1])/(60*delta),np.lib.stride_tricks.sliding_window_view(matrix,7,axis=0),axes=(0,-1))
        dtt=lambda matrix:np.tensordot(np.array([2,-27,270,-490,270,-27,2])/(180*delta**2),np.lib.stride_tricks.sliding_window_view(matrix,7,axis=0),axes=(0,-1))
        gp=grid.r
        am=aa[active];al=alpha[active]
        velocity=dt(aa-1);accel=dtt(aa-1)
        der=lambda mat,parity:np.array([grid.first(row,parity) for row in mat])
        gradient=der(al-1,1)
        curvr=(der(gradient/am,-1)-accel/al+velocity*dt(alpha-1)/al**2)/(al*am)
        curvt=gradient/(al*am**2)*grid.inv
        curvm=velocity/(al*am**2)*grid.inv
        curvs=der(am-1,1)/(am**3)*grid.inv
        flux=-gp**2*al*current[active]/am
        ediff=dt(mass)-flux
        centre=np.array([1,4])
        t_err=[];r_err=[];s_err=[]
        for idx in centre:
            rlist=src["probes"][active,INDEX["radius"],idx];speed=src["probes"][active,INDEX["speed"],idx]
            evalr=lambda mat:np.array([grid.at(row,np.array([pos]))[0] for row,pos in zip(mat,rlist,strict=True)])
            radial0=src["probes"][active,INDEX["radial"],idx];tangent=src["probes"][active,INDEX["tangent"],idx]
            geo=evalr(curvr);angle=(evalr(curvt)+2*speed*evalr(curvm)+speed**2*evalr(curvs))/(1-speed**2)
            r_err.append(peak(geo-radial0));t_err.append(peak(tangent-angle));s_err.extend([peak(radial0),peak(tangent)])
        scale=max(s_err)
        for idx in centre:
            vals=curve(src,idx,["radius","separation_angular","separation_radial","proper","speed","frame_a","lapse"])
            radius,ang,rad,proper,speed,aa0,lapse=vals.T
            jerr=peak(ang-radius/src["initial_r"][idx])
            neighbours=[]
            for peer in (idx-1,idx+1):
                clock=src["probes"][:,INDEX["proper"],peer];raw=src["probes"][:,INDEX["radius"],peer]
                neighbours.append(np.column_stack([CubicSpline(clock,clocks)(TARGET),CubicSpline(clock,raw)(TARGET)]))
            diff=(neighbours[1]-neighbours[0])/(2*grid.shift)
            jnum=(aa0*diff[:,1]-speed*lapse*diff[:,0])/(np.sqrt(1-speed**2)*aa0[0])
            checks.append(dict(arm=arm,prep=prep,r0=src["initial_r"][idx],jacobi_angular_absolute=jerr,
                finite_neighbor_radial_absolute=peak(jnum-rad),angular_signal=peak(ang-1),radial_signal=peak(rad-1)))
        rows0.append(dict(arm=arm,prep=prep,max_compactness=max(budget[:,2]),ADM0=budget[0,0],rest_mass=budget[0,1],
            adm_abs=peak(budget[:,0]-budget[0,0]),ordinary_rest_abs=peak(budget[:,1]-budget[0,1]),min_dens=float(budget[:,3].min()),boundary_material=budget[:,4].max(),
            momentum_abs=peak(ediff),momentum_relative=peak(ediff)/peak(flux) if peak(flux)>0 else None,
            radial_independent_absolute=max(r_err),angular_independent_absolute=max(t_err),tidal_scale=scale,
            radial_independent_peak=max(r_err)/scale if scale else None,angular_independent_peak=max(t_err)/scale if scale else None))
    for idx in (1,4):
        vacuum=curve(load("vacuum"),idx,KEYS);ordinary=curve(load("dust"),idx,KEYS)
        for prep in PREPS:
            field=curve(load("field","free" if prep=="free" else "bare"),idx,KEYS)
            combined=curve(load("both",prep),idx,KEYS)
            for pos,key in enumerate(KEYS):
                b=ordinary[:,pos]-vacuum[:,pos];h=field[:,pos]-vacuum[:,pos]
                together=combined[:,pos]-vacuum[:,pos]
                cross=(combined[:,pos]-ordinary[:,pos])-h
                forces.append(dict(r0=grid.probes[idx],prep=prep,quantity=key,ordinary_peak=peak(b),field_peak=peak(h),
                    mixed_peak=peak(cross),total_extra_peak=peak(together-b),mixed_final=cross[-1],total_extra_final=together[-1]-b[-1],
                    ordinary_final=b[-1],field_final=h[-1]))
                history.append(cross)
        for arm,ref in (("shellfield","field"),("shell","vacuum")):
            s=load(arm);h=load(ref)
            for key in KEYS:
                kidx=INDEX[key]
                v0=curve(h,idx,[key])[:,0];v1=curve(s,idx,[key])[:,0]
                coord=s["probes"][:,kidx,idx]-h["probes"][:,kidx,idx]
                wholes.append(dict(arm=arm,r0=grid.probes[idx],quantity=key,proper_abs=peak(v1-v0),coordinate_abs=peak(coord),
                    control_scale=peak(v0-(1. if key.startswith("separation") else 0.)),lapse_shift=s["probes"][0,INDEX["lapse"],idx]-h["probes"][0,INDEX["lapse"],idx]))
    table(f"budget-{count}.csv",rows0);table(f"forces-{count}.csv",forces)
    table(f"shell-{count}.csv",wholes);table(f"separation-{count}.csv",checks)
    write(f"mixed-{count}.npz",target=TARGET,curves=history)
    print(count,"metric curvature",max(r["radial_independent_absolute"] for r in rows0),"angular Jacobi",max(r["jacobi_angular_absolute"] for r in checks))
def ltb(count):
    grid=Grid(count);src=packet(count,"dust");records=[]
    def derivative(r,enclosed):
        shape=max(0.,1-(r/5)**2)**6
        return r**2*.002*shape/(125*.5*beta(1.5,7))*np.sqrt(1-2*enclosed/max(r,1e-100))
    sol=solve_ivp(derivative,(0,8),[0.],rtol=2e-13,atol=5e-17,dense_output=True,max_step=.025)
    assert sol.success
    for index in (1,4):
        start=grid.probes[index];mass=float(sol.sol(start)[0]);grad=float(derivative(start,mass));kappa=np.sqrt(start**3/(8*mass))
        phase=np.array([brentq(lambda v:kappa*(v+np.sin(v))-t,0,np.pi) for t in TARGET])
        dphase=-(1.5/start-.5*grad/mass)*(phase+np.sin(phase))/(1+np.cos(phase))
        rr=start*(1+np.cos(phase))/2
        stretch=(1+np.cos(phase))/2-start*np.sin(phase)*dphase/2
        tan=mass/rr**3;rad=grad/(rr**2*stretch)-2*tan
        direct=curve(src,index,["radius","radial","tangent","separation_radial","separation_angular"])
        for name,calc,expected,base in zip(("radius","radial","tangent","Jr","Jt"),direct.T,(rr,rad,tan,stretch,rr/start),(start,0,0,1.,1.)):
            records.append(dict(r0=start,quantity=name,absolute=peak(calc-expected),relative_to_signal=peak(calc-expected)/peak(expected-base),initial_gravitational_mass=mass))
    assert np.all(np.array([r["relative_to_signal"] for r in records])>=0)
    table(f"dust-independent-{count}.csv",records)
if __name__=="__main__":guard();diagnostics(int(sys.argv[1]));ltb(int(sys.argv[1]))

