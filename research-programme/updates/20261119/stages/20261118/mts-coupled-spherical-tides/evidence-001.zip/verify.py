from small_control import evaluate
from small_refinement import evaluate_refinement
from replay_plan import commands
from evolve import HERE, POST, PREVIOUS, LOCK, guard, sha, np
import csv
import json
import math
import platform
import scipy
import sys


def rows(name):
    with (HERE/name).open(encoding="utf8",newline="") as stream:
        reader=csv.DictReader(stream,strict=True)
        columns=reader.fieldnames
        if not columns or len(columns)!=len(set(columns)) or not all(columns):
            raise ValueError(f"Invalid CSV header: {name}")
        return list(reader)


def audit():
    guard()
    checks={}
    def require(label, condition):
        if not condition:
            raise ValueError(label)
        checks[label]=True
    previous=json.loads((PREVIOUS/"closeout.json").read_text(encoding="utf8"))
    external={}
    def protect(path, expected=None):
        actual=sha(path)
        if expected:
            require("prior digest "+path.name,actual==expected)
        external[path.relative_to(POST).as_posix()]=actual
    protect(PREVIOUS/"closeout.json",LOCK)
    for name in ("RESULTS.md","LOCAL-FORCED-RESPONSE.md","INDUCED-TIDAL-SOURCE.md","local-domain-in-cosmological-bank.csv"):
        protect(PREVIOUS/name,previous["files"][name])
    authority=POST/"MTS-HEAVY-BATH-COUNTERFLOW-AND-GALACTIC-STRESS.md"
    protect(authority,previous["protected"][str(authority)])
    protect(POST/"condensate-origin-20261003/motion-bath-matching-20261006/49-real-motion-envelope-and-existing-bath-matching.md")
    files={}
    for path in sorted(HERE.iterdir()):
        if path.name=="closeout.json":
            continue
        require("expected file type "+path.name,path.is_file() and path.suffix in {".py",".md",".npz",".csv"})
        files[path.name]=sha(path)
        if path.suffix==".npz":
            with np.load(path,allow_pickle=False) as data:
                require("read numerical packet "+path.name,bool(data.files) and all(
                    item.size>0 and (np.isfinite(item).all() if item.dtype.kind in "biufc" else item.dtype.kind in "US") for item in data.values()))
        elif path.suffix==".csv":
            rr=rows(path.name)
            require("parse complete table "+path.name,bool(rr) and all(None not in row and all(
                value is not None and value.lower() not in ("nan","inf","+inf","-inf","infinity","-infinity") for value in row.values()) for row in rr))
        elif path.suffix==".py":
            compile(path.read_bytes(),str(path),"exec")
    for filename, replay in (("small-nonzero-control.csv",evaluate()),("small-nonzero-refinement.csv",evaluate_refinement())):
        original=rows(filename)
        require("independent packet reread "+filename,len(original)==len(replay) and all(all(
            str(value)==row[key] if isinstance(value,(str,bool,np.bool_)) else math.isclose(float(value),float(row[key]),rel_tol=1e-12,abs_tol=0)
            for key,value in calc.items()) for calc,row in zip(replay,original,strict=True)))
    def positive_count(records, column):
        return sum(r[column]=="True" for r in records)
    fine=rows("small-nonzero-refinement.csv")
    require("four small-signal mesh comparisons",len(fine)==4 and all(float(row["relative_mesh_difference"])<2e-5 and abs(float(row["observed_peak_ratio"])/float(row["amplitude_squared"])-1)<1.1e-6 for row in fine))
    ordinary=rows("dust-independent-1920.csv")
    require("analytic interior and exterior controls",len(ordinary)==10 and max(float(r["relative_to_signal"]) for r in ordinary)<2e-5)
    geodesics=rows("independent-geodesics-3840.csv")
    require("four preparations, two radii, two axes, two independent readouts",len({(r["prep"],r["r0"],r["separation"],r["method"]) for r in geodesics})==32 and max(float(r["relative_error"]) for r in geodesics)<2e-5)
    geometry=rows("metric-reread-3840.csv")
    require("connection controls, all three stencils",len(geometry)==192 and all(float(r["relative"])<2e-5 for r in geometry if r["method"]=="connection"))
    require("raw curvature failures retained",sum(float(r["relative"])>=2e-5 for r in geometry if r["method"]=="metric-only" and r["radial_stencil"]=="all")==21)
    forced=rows("retarded-prediction.csv")
    require("48 leading response comparisons",len(forced)==48 and max(float(r["mesh_error"]) for r in forced)<2.15e-6 and max(float(r["prediction_error"]) for r in forced)>.04)
    for prep, expected in (("bare",.00044201647),("prepared",.00600347655)):
        match=[r for r in forced if r["prep"]==prep and float(r["r0"])==6 and r["quantity"]=="radial"]
        require("independent radial forced waveform "+prep,len(match)==1 and math.isclose(float(match[0]["prediction_error"]),expected,rel_tol=1e-7))
    require("initial independent constraint",max(abs(float(r["relative_to_exact"])) for r in rows("initial-cross-law.csv"))<3.46e-8)
    require("exterior shell matched clock",max(float(r["all_parts_relative"]) for r in rows("retarded-shell.csv"))<1.02e-9)
    for r in rows("causal-null.csv"):
        if r["quantity"] in ("radial","tangent"):
            require("direct matched clock "+str((r["r0"],r["arm"],r["quantity"])),abs(float(r["proper_abs"]))<4e-19)
    work=rows("balanced-work-3840.csv")
    require("sector work resolved and unresolved cases retained",len(work)==36 and positive_count(work,"passes")==24)
    integral=[r for r in rows("moving-independent-integrals.csv") if r["grid"]=="3840"]
    require("moving mass and ruler rates with separate absolute failures",len(integral)==24 and all(float(r["relative"])<2e-5 for r in integral if r["test"]!="absolute-moving-mass") and positive_count(integral,"passes")==22)
    bounds=rows("comoving-bound-3840.csv")
    require("all local stress envelopes hold",len(bounds)==6 and all(0<float(r["radial_separation_change"])<=float(r["rigorous_radial_ceiling_given_inputs"]) and 0<float(r["angular_separation_change"])<=float(r["rigorous_angular_ceiling_given_inputs"]) for r in bounds))
    newton=rows("newton-bound.csv")
    require("eight matched-source Newton comparisons",len(newton)==8 and all(float(r["radius_difference"])<=float(r["radius_ceiling"]) and float(r["radial_separation_difference"])<=float(r["radial_ceiling"]) and float(r["angular_separation_difference"])<=float(r["angular_ceiling"]) for r in newton))
    energy=rows("initial-energy-identities.csv")
    require("energy identity across preparations",len(energy)==5 and max(float(r["mass_identity"]) for r in energy)<1e-15)
    require("full packet not certified by global energy",all(r["target_certified_by_this_norm"]=="False" for r in rows("initial-norm-certificate.csv") if r["arm"]=="both"))
    plan=commands(files)
    require("replay plan lists every primary acquisition",len(plan)==len(set(plan)) and len(plan)==sum(name.endswith(".npz") for name in files)-4+19)
    return dict(parent=LOCK,protected=external,files=files,checks=checks,
        runtime=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__))


if __name__=="__main__":
    report=audit()
    path=HERE/"closeout.json"
    if sys.argv[1:]==["--seal"]:
        with path.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(report,stream,indent=2,sort_keys=True)
            stream.write("\n")
    elif sys.argv[1:]:
        raise SystemExit("Expected no arguments or --seal")
    else:
        saved=json.loads(path.read_text(encoding="utf8"))
        for key in ("parent","protected","files","checks"):
            if saved[key]!=report[key]:
                raise ValueError(f"Independent reread mismatch: {key}")
    print(f'{len(report["checks"])} checks; {len(report["files"])} files; {len(report["protected"])} parent paths; seal {sha(path)}')

