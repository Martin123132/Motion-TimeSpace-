from newton_bound import *

def ceilings(norm,rad,proper,m0,rho,D,bmin=.98,vmin=.98,integralC=.03):
    lower=.9*rad;upper=1.1*rad;vmax=.02;amax=1.01
    eps=norm*np.exp(integralC)*(3/bmin+(1+2/lower**2)/vmin)/lower**2
    mu=norm/bmin;bm=mu+proper*upper**2*(1+vmax)/np.sqrt(1-vmax*vmax)*eps
    sin=lambda k:np.sinh(proper*np.sqrt(k))/np.sqrt(k) if k>0 else proper
    cos=lambda k:2*np.sinh(.5*proper*np.sqrt(k))**2/k if k>0 else proper**2/2
    kr=2*m0/lower**3
    dr=(bm/lower**2+upper*(1+vmax)/(1-vmax)*eps)*cos(kr)
    kj=2*(m0+bm)/lower**3+2*eps
    fj=1.02*(2*bm/lower**3+6*m0*dr/lower**4+2*eps)+(rad/lower)**2*D*amax*mu/rad+2*rho*rad**2*dr/lower**3
    return eps,mu,dr/rad,rad*amax*eps*sin(kj)+fj*cos(kj)

def run():
    guard();ledger=[];energies=[]
    for arm,prep,amp in (("dust","bare",0.),("both","bare",1.),("both","prepared",1.),("both","prepared",.5),("both","free",1.)):
        count=1920;grid=Grid(count);state,_=grid.initial(arm,prep,1.,amp);met=grid.metric(state)
        src=read_np(f"sobolev-{count}-{arm}-{prep}-h{amp:g}.npz")
        norm=sum(src["energy"][0]);transport=grid.integral(grid.r**2*met[0]*met[1]*met[10])[-1]
        dh=src["energy"]-src["energy"][0]
        energies.append(dict(arm=arm,prep=prep,amplitude=amp,initial_norm=norm,initial_H0=src["energy"][0,0],
            weighted_scalar_mass=transport,mass_identity=abs(transport-src["energy"][0,0]),C_integral=src["growth"][-1],
            bmin=float(src["bmin"]),vmin=float(src["vmin"]),H0_own_change_error=peak(src["h0_defect"])/peak(dh[:,0]) if peak(dh[:,0]) else None,
            H1_own_change_error=peak(src["h1_defect"])/peak(dh[:,1]) if peak(dh[:,1]) else None))
        assert float(src["bmin"])>.98 and float(src["vmin"])>.98 and max(src["growth"])<.03
        for idx,rad in enumerate((2.5,6.)):
            dust,_=grid.initial("dust","bare")
            baseline=grid.metric(dust);m0=grid.at(baseline[5],np.array([rad]))[0];D=grid.at(dust[2],np.array([rad]))[0]
            rho=grid.at(baseline[11],np.array([rad]))[0]
            fun=lambda h:ceilings(h,rad,6.4,m0,rho,D)
            eps,mu,ang,axis=fun(norm)
            target=2e-5
            threshold=brentq(lambda h:max(fun(h)[-2:])-target,0.,.001,xtol=1e-19,rtol=2e-14)
            ledger.append(dict(arm=arm,prep=prep,amplitude=amp,r0=rad,initial_norm=norm,
                sufficient_initial_norm_for_target=threshold,illustrative_separation_target=target,
                eps_ceiling=eps,initial_mass_ceiling=mu,ruler_angular_ceiling=ang,ruler_radial_ceiling=axis,
                target_certified_by_this_norm=(norm<=threshold),minimum_B=.98,minimum_V=.98,max_integral_C=.03))
    table("initial-energy-identities.csv",energies);table("initial-norm-certificate.csv",ledger)
    print("initial H0 identity max",max(r["mass_identity"] for r in energies),"sufficient thresholds",[r["sufficient_initial_norm_for_target"] for r in ledger[:2]])
if __name__=="__main__":run()

