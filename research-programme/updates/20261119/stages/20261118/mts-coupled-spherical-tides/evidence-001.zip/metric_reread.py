from metric_test import *

def certify(count):
    guard();checks=[];paritychecks=[];state={}
    for arm,prep in (("dust","bare"),("field","bare"),("both","bare"),("both","prepared"),("field","free"),("both","free"),("field","phase"),("both","phase")):
        src=Resolved(count,arm,prep)
        state[arm,prep]=[src.raw(),*[src.geometric(kind) for kind in (None,0,1)]]
    for prep in ("bare","prepared","phase","free"):
        picks=[state["both",prep],state["field",prep if prep in ("phase","free") else "bare"],state["dust","bare"]]
        direct,standard,even,odd=[both-field-dust for both,field,dust in zip(*picks,strict=True)]
        for slot,rad in enumerate((2.5,6.)):
            for col,name in enumerate(KEYS[:4]):
                reference=direct[slot,6:-6,col];mag=peak(reference)
                for method,arr in (("all",standard),("even",even),("odd",odd)):
                    for kind,label in enumerate(("metric-only","connection")):
                        error=peak(arr[slot,kind,:,col]-reference)
                        checks.append(dict(grid=count,prep=prep,r0=rad,quantity=name,method=label,radial_stencil=method,
                            error=error,relative=error/mag,passes=error<2e-5*mag))
                paritychecks.append(dict(grid=count,prep=prep,r0=rad,quantity=name,metric_parity_disagreement=peak(even[slot,0,:,col]-odd[slot,0,:,col])/mag))
    table(f"metric-reread-{count}.csv",checks);table(f"parity-{count}.csv",paritychecks)
    print(count,[(m,n,max(r["relative"] for r in checks if (r["method"],r["radial_stencil"])==(m,n))) for m in ("metric-only","connection") for n in ("all","even","odd")])
if __name__=="__main__":certify(int(sys.argv[1]))

