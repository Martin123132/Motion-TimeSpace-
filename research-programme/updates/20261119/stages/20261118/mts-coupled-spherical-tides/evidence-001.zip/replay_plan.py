import json
import re
import sys
from pathlib import Path


def commands(files):
    patterns = (
        (r"n(\d+)-(\w+)-(\w+)-s([\d.]+)-h([\d.]+)-c([\d.]+)(?:-o(\d+))?\.npz","evolve.py"),
        (r"resolved-(\d+)-(\w+)-(\w+)-c([\d.]+)\.npz","resolved.py"),
        (r"sectors-(\d+)-(\w+)-(\w+)\.npz","sector.py"),
        (r"account-(\d+)-(\w+)-(\w+)(?:-h([\d.]+))?\.npz","comoving.py"),
        (r"variation-(\d+)-(\w+)(?:-(shell))?\.npz","variation.py"),
        (r"sobolev-(\d+)-(\w+)-(\w+)-h([\d.]+)\.npz","sobolev.py"))
    result=[]
    for filename in sorted(files):
        for pattern,script in patterns:
            match=re.fullmatch(pattern,filename)
            if match:
                result.append(" ".join([script,*filter(None,match.groups())]))
                break
        else:
            if filename.endswith(".npz") and filename not in {"resolved-waveforms.npz",*(f"mixed-{n}.npz" for n in (480,960,1920))}:
                raise ValueError(f"Unmapped packet: {filename}")
    result.extend(f"compare.py {n}" for n in (480,960,1920))
    result.extend(["relational.py","initial_law.py","metric_test.py","prediction_test.py","sector.py score"])
    for n in (1920,3840):
        result.extend([f"metric_reread.py {n}",f"geodesics.py {n}",f"comoving.py check {n}"])
    result.extend(["moving_test.py","newton_bound.py","certificate.py","small_control.py","small_refinement.py"])
    return result


if __name__=="__main__":
    root=Path(__file__).resolve().parent
    files=json.loads((root/"closeout.json").read_text(encoding="utf8"))["files"]
    for arguments in commands(files):
        print(f'& "{sys.executable}" -B {arguments}; if ($LASTEXITCODE) {{ exit $LASTEXITCODE }}')

