from metric_test import *
from scipy.interpolate import RectBivariateSpline

def extract(src,method):
    data=src.data;times=data["time"];arr=data["weak_metric"];tiles=data["tiles"]
    output=[]
    for p,r0 in enumerate((2.5,6.)):
        grid=tiles[p];dr=grid[1]-grid[0];start=int(round(grid[0]/dr))%2
        interior=grid[start::2]
        aa,al,space,unused=[RectBivariateSpline(times,interior,arr[:,j,p,start::2],kx=5,ky=5) for j in range(4)]
        start_a=aa.ev(0,r0)
        def rhs(t,y):
            radius=r0+y[0];imp=y[1];jac=1+y[3];pj=y[4]
            weak_a=aa.ev(t,radius);weak_l=al.ev(t,radius);ar=aa.ev(t,radius,dy=1);arrad=aa.ev(t,radius,dy=2)
            met=1+weak_a;lapse=1+weak_l;w=np.hypot(1,imp/met);vsq=(imp/(met*w))**2
            if method=="metric":
                lr=al.ev(t,radius,dy=1);lrr=al.ev(t,radius,dy=2)
            else:
                connection=space.ev(t,radius);lr=met*connection;lrr=ar*connection+met*space.ev(t,radius,dy=1)
            ag=ar/met;lg=lr/lapse
            hp=lapse*imp/(met**2*w)
            hpr=hp*(lg-(2-vsq)*ag)
            hrr=w*(lrr-2*lr*vsq*ag+lapse*((2*vsq-vsq**2)*ag**2-vsq*(arrad/met-ag**2)))
            hpp=lapse/(met**2*w**3)
            shift=(weak_l-(imp/met)**2/(1+w))/w
            return [hp,-lapse*w*(lg-vsq*ag),shift,hpr*jac+hpp*pj,-hrr*jac-hpr*pj]
        sol=solve_ivp(rhs,(0.,times[-1]),np.zeros(5),t_eval=times,method="DOP853",rtol=2e-12,atol=1e-18,max_step=.1)
        assert sol.success
        disp,imp,clock,stretch,deriv=sol.y;aw=aa.ev(times,r0+disp)
        logj=np.log1p(aw)-np.log1p(start_a)+np.log1p(stretch)+.5*np.log1p((imp/(1+aw))**2)
        output.append(interp(times+clock,np.stack([np.expm1(logj),disp/r0],axis=1),TARGET))
    return np.array(output)
def calculate(count):
    guard();values={};rows0=[]
    for arm,prep in (("both","bare"),("both","prepared"),("both","free"),("both","phase"),("field","bare"),("field","phase"),("field","free"),("dust","bare")):
        src=Resolved(count,arm,prep)
        values[arm,prep]=[src.raw()[:,:,4:],extract(src,"metric"),extract(src,"connection")]
    for prep in ("bare","prepared","phase","free"):
        field=prep if prep in ("phase","free") else "bare"
        raw,metric,conn=[total-alone-dust for total,alone,dust in zip(values["both",prep],values["field",field],values["dust","bare"],strict=True)]
        for p,rad in enumerate((2.5,6.)):
            for j,key in enumerate(("radial","angular")):
                scale=peak(raw[p,:,j])
                for name,other in (("spacetime-metric",metric),("radial-connection",conn)):
                    err=peak(raw[p,:,j]-other[p,:,j]);rows0.append(dict(prep=prep,r0=rad,separation=key,method=name,
                        mixed_peak=scale,absolute_error=err,relative_error=err/scale,passes=err<2e-5*scale))
    table(f"independent-geodesics-{count}.csv",rows0)
    print(count,"max geodesic discrepancies",[(kind,max(r["relative_error"] for r in rows0 if r["method"]==kind)) for kind in ("spacetime-metric","radial-connection")])
if __name__=="__main__":calculate(int(sys.argv[1]))

