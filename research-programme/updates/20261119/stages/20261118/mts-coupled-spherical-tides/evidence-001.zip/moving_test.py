from newton_bound import *
from numpy.polynomial.legendre import leggauss

def primitive(axis,values):
    nodes,weights=leggauss(5);span=np.diff(axis);coords=(axis[:-1,None]+.5*span[:,None]*(1+nodes)).ravel()
    sampled=interp(axis,values[:,None],coords,8).reshape(-1,len(nodes))
    return np.r_[0.,np.cumsum(.5*span*(sampled@weights))]
def compare():
    guard();rows0=[]
    for count in (1920,3840):
        get=lambda arm,prep:read_np(f"account-{count}-{arm}-{prep}.npz")["events"]
        dust=get("dust","bare")
        for prep in ("bare","prepared","free"):
            both=get("both",prep)
            for slot,idx in enumerate((1,4)):
                rad=(2.5,6.)[slot]
                def compare_at(source):
                    vv=source[:,:,idx];clock=vv[:,0];radius=vv[:,1]
                    comp=vv[:,4]-vv[0,4]
                    predicted=primitive(clock,vv[:,6])
                    jrad=primitive(clock,(2*vv[:,4]/radius**3-vv[:,10])*(1+vv[:,2])-vv[0,11]*(rad/radius)**2)
                    jang=primitive(clock,(-vv[:,4]/radius**2-radius*vv[:,9])/rad)
                    return interp(clock,np.stack([comp,predicted,vv[:,15]-vv[0,15]-jrad,vv[:,16]-vv[0,16]-jang,vv[:,15]-vv[0,15],vv[:,16]-vv[0,16]],axis=1),TARGET)
                actu=compare_at(both);ref=compare_at(dust)
                for name,val in (("absolute-moving-mass",actu),("ordinary-control-subtracted",actu-ref)):
                    err=peak(val[:,0]-val[:,1]);scale=peak(val[:,0])
                    rows0.append(dict(grid=count,prep=prep,r0=rad,test=name,error=err,signal=scale,relative=err/scale,passes=err<2e-5*scale))
                for j,name in enumerate(("radial-rate-change","angular-rate-change")):
                    val=actu-ref;err=peak(val[:,2+j]);scale=peak(val[:,4+j]);rows0.append(dict(grid=count,prep=prep,r0=rad,test=name,error=err,signal=scale,relative=err/scale,passes=err<2e-5*scale))
    table("moving-independent-integrals.csv",rows0)
    print([(key,sum(r["passes"] for r in rows0 if r["test"]==key and r["grid"]==3840)) for key in sorted({row["test"] for row in rows0})])
if __name__=="__main__":compare()

