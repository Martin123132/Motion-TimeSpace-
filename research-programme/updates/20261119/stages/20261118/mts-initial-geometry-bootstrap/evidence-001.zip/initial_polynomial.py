from probe import guard, write
from bootstrap import D0
from math import comb
from sympy import Poly, Rational, symbols


def profile():
    x=symbols("r")
    def poly(expr):
        return Poly(expr,x,domain="QQ")
    def prim(expr):
        ant=poly(expr).integrate()
        return ant.as_expr()-ant.eval(0)
    def taper(start,width):
        y=(x-start)/width
        return 1-2772*sum((-1)**k*comb(5,k)*y**(6+k)/(6+k) for k in range(6))
    density=Rational(str(D0))*(1-x**2/25)**6
    mass=prim(x*x*density)
    total=Rational(1,500)
    assert mass.subs(x,5)==total
    potential_inner=prim(poly(mass).exquo(poly(x**2)).as_expr())
    potential=potential_inner-potential_inner.subs(x,5)-total/5
    aint=prim(2*x**2*potential)
    additive=aint.subs(x,5)+25*total
    rchi=-total*x*(x-12)+additive*(x/12-1)
    chi_inner=prim(poly(aint).exquo(poly(x*x)).as_expr())
    chi_inner+=rchi.subs(x,5)/5-chi_inner.subs(x,5)
    amp=Rational(1,1250)
    pieces=[(0,5,x*(1+chi_inner)),(5,10,x+rchi),(10,15,x+rchi*taper(10,5)),(15,16,x),(16,26,x*taper(16,10))]
    curves=[(lo,hi,poly(amp*f)) for lo,hi,f in pieces]
    for (_,edge,left),(_,_,right) in zip(curves,curves[1:]):
        for degree in range(4):
            assert left.eval(edge)==right.eval(edge)
            left=left.diff();right=right.diff()
    values=[]
    for lo,hi,base in curves:
        for order in range(4):
            integral=(base*base).integrate()
            norm=integral.eval(hi)-integral.eval(lo)
            assert norm>=0
            values.append(dict(start=lo,end=hi,derivative=order,exact_square_integral=str(norm),approx=float(norm)))
            base=base.diff()
    return values


if __name__=="__main__":
    guard();write("initial-polynomial-integrals.csv",profile())

