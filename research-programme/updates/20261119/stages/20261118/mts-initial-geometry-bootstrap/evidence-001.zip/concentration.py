from probe import guard, np, HERE, write, solve_ivp
from bootstrap import D0
from scipy.integrate import quad


def calculate():
    guard()
    power=8
    def shape(x):
        return (1-x*x)**power
    def slope(x):
        return shape(x)-2*power*x*x*(1-x*x)**(power-1)
    h0=quad(lambda x:x*x*shape(x)**2,0,1)[0]/2
    h1=quad(lambda x:slope(x)**2,0,1)[0]/2
    results=[]
    for width in (1/16,1/256,1/4096,1/65536):
        def mass(rad,values):
            base,total=values
            inv=1/rad if rad>0 else 0
            d=D0*(1-(width*rad/5)**2)**6*width**.5
            f0=1-2*width**1.5*base*inv
            f1=1-2*width**1.5*total*inv
            return [rad**2*d*np.sqrt(f0),rad**2*(d*np.sqrt(f1)+.5*shape(rad)**2*f1)]
        mesh=np.linspace(0,1,1001)
        sol=solve_ivp(mass,(0,1),[0,0],rtol=1e-12,atol=1e-16,max_step=.01,method="DOP853",t_eval=mesh)
        assert sol.success
        base,total=sol.y
        compact=2*width**1.5*(total[1:]-base[1:])/mesh[1:]
        excess=(total[-1]-base[-1])*width**2.5
        norm=h0*width**2.5+h1*np.sqrt(width)
        results.append(dict(width=width,initial_H_upper=norm,central_scalar_energy=.5/np.sqrt(width),
            central_Rnn_excess=2/np.sqrt(width),enclosed_mass_excess=excess,
            enclosed_mass_upper=h0*width**2.5,maximum_core_compactness_excess=np.max(compact),
            global_compactness_excess_upper=width**1.5/3))
        assert 0<excess<=h0*width**2.5 and 0<max(compact)<width**1.5/3
    assert all(a["initial_H_upper"]>b["initial_H_upper"] and a["central_Rnn_excess"]<b["central_Rnn_excess"] for a,b in zip(results,results[1:]))
    return results


if __name__=="__main__":
    write("central-concentration.csv",calculate())

