from fractions import Fraction
import csv
import math
from bootstrap import HERE, TIME, SMALL, TOL, envelope, preparation, ruler, write
from probe import guard


def weights():
    with (HERE/"initial-polynomial-integrals.csv").open(encoding="utf8") as stream:
        rows=list(csv.DictReader(stream))
    terms=[sum(Fraction(r["exact_square_integral"]) for r in rows if int(r["derivative"])==order) for order in range(4)]
    return terms


def evaluate():
    terms=weights()
    props=envelope()
    br=props["br"];brr=props["brr"];kappa=props["k_bound"];rk=props["rkr"]
    fv=props["fr"]*(1+kappa);delta=props["compact"]+kappa
    a0=(br+delta)/2
    a1=(3*br+delta+brr+2*rk)/2
    coupling=brr+fv+br
    y0=math.sqrt(float(terms[0]+terms[1]))
    y1=math.sqrt(float(terms[1]+terms[2]))
    x0=y0*math.exp(a0*TIME)
    x1=math.exp(a1*TIME)*(y1+coupling*x0*TIME)
    wav=math.sqrt(2*x0*x1)+x1
    zmax=math.exp(2*br*TIME)*(preparation()+TIME*(brr*wav+(1+kappa+rk)*x1+fv*x0))
    nmax=max(x0,wav,zmax)
    limit=SMALL/nmax
    def tested(amp,rad):
        inner=.9*rad
        eps=amp**2*(2*x0*x1+2*x1**2+(1+2/inner**2)*x0**2)/(2*inner**2)
        mu=.5*(y0*amp)**2
        angle,axis=ruler(eps,rad,mu)
        return eps,mu,angle,axis
    records=[]
    for rad in (2.5,6.):
        lo,hi=0.,limit
        for idx in range(64):
            mid=(lo+hi)/2
            if max(tested(mid,rad)[2:])<TOL:
                lo=mid
            else:
                hi=mid
        for amplitude in (1.,1/160,.000014):
            passed=amplitude<limit
            eps,mu,ang,axis=tested(amplitude,rad) if passed else (None,None,None,None)
            records.append(dict(r0=rad,amplitude=amplitude,initial_Y0=amplitude*y0,initial_Y1=amplitude*y1,
                final_Y0_ceiling=amplitude*x0,final_Y1_ceiling=amplitude*x1,
                first_exit_N_rhs=amplitude*nmax,finite_geometry_limit=limit,
                sufficient_fraction_for_ruler=lo,passes_geometry=passed,epsilon_annular=eps,
                initial_mass_cap=mu,angular_ceiling=ang,radial_ceiling=axis,passes_ruler=passed and max(ang,axis)<TOL))
    return records


if __name__=="__main__":
    guard();write("massive-initial-only-rulers.csv",evaluate())

