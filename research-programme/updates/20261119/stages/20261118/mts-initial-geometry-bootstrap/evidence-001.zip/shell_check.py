from probe import guard, HERE, PARENT, np, Account, write, PROPER
from relational import interp, TARGET, peak
from scipy.integrate import cumulative_simpson
import sys


def collect(count,arm):
    guard();grid=Account(count)
    stencil=.025
    grid.probes=np.concatenate([radius+stencil*np.arange(-2,3) for radius in (2.5,6.)])
    state,path=grid.initial(arm,"prepared" if arm=="both" else "bare")
    initial_metric=grid.at(grid.metric(state)[0],grid.probes)
    path[[3,5]]-=1
    steps=int(np.ceil(6.5/(.26*grid.step)/256))*256;dt=6.5/steps
    histories=[]
    for step in range(steps+1):
        if step%(steps//256)==0:
            field,mom,_,_=state
            aa,al,bridge,loga,logl,mass,energy,press,_,current,eh,ed,vd,grad=grid.metric(state)
            radius,imp,clock,jr,rate,*_=path
            get=lambda variable:grid.at(variable,radius)
            rho=ed*(1-vd**2)
            metric=get(aa);lor=np.hypot(1,imp/metric);v=imp/metric/lor
            stretch=jr+1;A=radius/grid.probes
            ratio=initial_metric*stretch*lor/(metric*A)
            mean=mass*grid.inv**3;mean[0]=energy[0]/3
            kin=(mom**2-grad**2)/aa**2
            drKin=grid.first(kin,1)
            material=grid.rhs(state,path)[0]
            dtKin=(2*mom*material[1]-2*grad*grid.first(material[0],1))/aa**2 +2*kin*grid.r*aa**2*bridge*current
            spin=metric*lor*rate/stretch+radius*metric**2*get(current)
            headers=["clock","radius","Joff","rate","rho","mean","Q","Lmean","LQ","spin","measured_spin","r_rho_r","speed","a","W"]
            histories.append(np.stack([clock,radius,jr,rate,get(rho),get(mean),get(kin),
                ratio*(get(energy)-v*get(current)-3*get(mean)),ratio*radius*(get(drKin)+v/get(bridge)*get(dtKin)),
                spin,get(grid.first(np.arctanh(vd),-1)),radius*get(grid.first(rho,1)),v,metric,lor]))
        if step==steps:break
        first,p1=grid.push(state,path);second,p2=grid.push(state+.5*dt*first,path+.5*dt*p1)
        third,p3=grid.push(state+.5*dt*second,path+.5*dt*p2);fourth,p4=grid.push(state+dt*third,path+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);path+=dt/6*(p1+2*p2+2*p3+p4)
    with (HERE/f"shells-{count}-{arm}.npz").open("xb") as stream:
        np.savez_compressed(stream,events=histories,names=headers,initial_metric=initial_metric,labels=grid.probes,stencil=stencil)


def scores(count,arm):
    with np.load(HERE/f"shells-{count}-{arm}.npz") as packet:
        hist=packet["events"];names=list(packet["names"]);labels=packet["labels"]
        a0=packet["initial_metric"];stencil=float(packet["stencil"])
    common=np.array([interp(hist[:,0,i],hist[:,:,i],TARGET) for i in range(len(labels))])
    records=[]
    for slot,i in ((0,2),(1,7)):
        rad=labels[i];s=common[i]
        get=lambda name:s[:,names.index(name)]
        def diff(name):
            vals=common[i-2:i+3,:,names.index(name)]
            return rad*(vals[0]-8*vals[1]+8*vals[3]-vals[4])/(12*stencil)
        def compare(label,left,right,zero_ref=None):
            err=peak(left-right);scale=peak(left) if zero_ref is None else zero_ref
            records.append(dict(mesh=count,arm=arm,r0=rad,check=label,signal=scale,error=err,
                relative=err/scale if scale else None,passes=err<2e-5*scale if scale else None))
        A=get("radius")/rad;J=1+get("Joff");Z=get("rate");W=get("W");v=get("speed");a=get("a")
        ratio=a0[i]*J*W/(a*A);kin=get("Q");mean=get("mean")
        compare("synchronous enclosed mean slope",diff("mean"),get("Lmean"))
        if arm=="both":
            compare("boosted scalar kinetic slope",diff("Q"),get("LQ"))
        else:
            assert not np.any(get("Q"))
        compare("congruence rapidity gradient",get("measured_spin"),get("spin"))
        rho=get("rho")
        if rad<5:
            drho_tau=-rho*(Z/J+2*W*v/(a*get("radius")))
            estimate=a*W*(A/(a0[i]*J)*diff("rho")-get("radius")*v*drho_tau)
            compare("polar versus synchronous density slope",get("r_rho_r"),estimate)
        source=(2*mean-kin)*diff("Joff")+(2*get("Lmean")-get("LQ"))*J-diff("rho")[0]/A**2+2*rho[0]*(ratio-1)/A**2
        compare("integrated label derivative of ruler rate",diff("rate"),cumulative_simpson(source,x=TARGET,initial=0))
    return records


if __name__=="__main__":
    if sys.argv[1]=="score":
        guard(); write("shell-identity-controls.csv",[row for n in (960,1920) for arm in ("dust","both") for row in scores(n,arm)])
    else:
        collect(int(sys.argv[1]),sys.argv[2])

