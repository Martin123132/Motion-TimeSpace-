import csv
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / "mts-coupled-spherical-tides-20261118"
D0 = 0.000703828125
REST = 0.002
TIME = 6.5
PROPER = 6.4
RSTAR = 26.
REACH = 33.
DMAX = 5.1
SMALL = 0.001
TRIAL_RHO_GRAD = 0.003
TOL = 2e-5


def write(name, records):
    with (HERE/name).open("x", newline="", encoding="utf8") as stream:
        output = csv.DictWriter(stream, fieldnames=records[0])
        output.writeheader()
        output.writerows(records)


def envelope():
    amin, amax, jmin, jmax, vc, cc = .98, 1.02, .95, 1.05, .02, .01
    metric = 1/math.sqrt(1-cc)
    lorentz = 1/math.sqrt(1-vc**2)
    boosted = (1+vc)/(1-vc)
    eps = 1.125*SMALL**2
    ec, mass = .0008, .010
    rho = D0/(jmin*amin**2)
    total = rho*lorentz**2 + eps
    initial_adm = REST+eps*RSTAR**3/3
    compact = 2*(mass**2*ec/3)**(1/3)
    invclock = math.exp(-ec*(3*mass/ec)**(2/3)/(1-cc))
    b_lower = (1-compact)*invclock
    potential_lower = invclock*(1-rho-SMALL**2)
    proper_end = TIME*invclock*math.sqrt(1-compact)/lorentz
    acc = amax*(ec/3+boosted*eps)
    a_dev = .5*TIME**2*acc
    acceleration = (ec/3)**(2/3)*mass**(1/3) + REACH*boosted*eps
    v_bound = metric*TIME*acceleration
    k_j = 2*ec/3+2*eps
    j_down = .5*TIME**2*(2*eps*jmax+D0/amin**2)
    j_up = .5*TIME**2*k_j*jmax
    jt = TIME*(k_j*jmax+D0/amin**2)
    rt_over_r = TIME*acc/amin
    rat_hi = metric*jmax*lorentz/amin
    rat_lo = jmin/(metric*amax)
    tilt = max(rat_hi-1,1-rat_lo)
    rho0_log = 2*(5/6)**5*D0+D0*metric*5**2*(ec+ec/3)
    arlog = metric**2*DMAX**2*(ec+ec/3)
    atlog = metric**2*DMAX**2*ec
    k_bound = 2*ec/3+rho+SMALL**2
    brlog = DMAX**2*metric**2*k_bound
    qr = (6+2.5*arlog)*SMALL**2
    qt_over_b = (2*(3+.5*brlog+DMAX*metric**2)+2+brlog+2.5*atlog)*SMALL**2
    klog = 2*rat_hi*((1+vc)*ec+ec) + rat_hi*(qr+vc*qt_over_b)
    source = klog*jmax + rho0_log/amin**2 + 2*D0*tilt/amin**2
    kernel = 2*math.sinh(.5*TIME*math.sqrt(k_j))**2/k_j
    jlog = source*kernel
    d_rho = rho0_log/(jmin*amin**2) + rho*(jlog/jmin+2*tilt)
    rho_t = rho*(jt/jmin+2*rt_over_r)
    g_density = metric*lorentz*(amax/jmin*d_rho+DMAX*vc*rho_t)
    rkr = 4*ec + TRIAL_RHO_GRAD + 4*SMALL**2
    br = max(DMAX*k_bound, 2*mass/DMAX**2+REACH*SMALL**2)
    fr = 2*metric**2*max(DMAX*ec,REACH*eps)
    rfr = 2*metric**2*max(DMAX**2*ec,REACH**2*eps)
    brr = (1+rfr)*k_bound+rkr
    potential = 1+k_bound
    vr_u = fr*potential+rkr
    growth = max(1,br+potential,2*br+brr+potential+vr_u)
    values = locals().copy()
    for actual, limit in ((total,ec),(initial_adm,mass),(compact,cc),(a_dev,.02),
        (j_down,.05),(j_up,.02),(v_bound,vc),(g_density,TRIAL_RHO_GRAD)):
        if not actual < limit:
            raise ArithmeticError((actual,limit))
    assert b_lower>.98 and potential_lower>.98 and proper_end>PROPER
    return values


def preparation():
    phi = D0*25/14
    correct = 48*phi
    rate, curve = 2*phi*15/3, (2+4/3)*phi
    slope, bend = 2772/1024, 2772*5/256
    corr1 = rate+correct*slope/5
    corr2 = curve+2*rate*slope/5+correct*bend/25
    hmax = 1+correct
    first = max(corr1,slope/10)
    second = max(corr2,bend/100)
    return .0008*max(26*hmax,hmax+26*first,2*first+26*second)


def ruler(epsilon,radius,initial_mass_cap=None):
    mass = min(REST,D0*radius**3/3)
    density = D0*max(0.,1-(radius/5)**2)**6
    lower,upper = .9*radius,1.1*radius
    vel = .02
    mu = epsilon*radius**3/3 if initial_mass_cap is None else initial_mass_cap
    budget = mu+PROPER*upper**2*(1+vel)/math.sqrt(1-vel**2)*epsilon
    def kernel(coef):
        return 2*math.sinh(.5*PROPER*math.sqrt(coef))**2/coef
    disp = (budget/lower**2+upper*(1+vel)/(1-vel)*epsilon)*kernel(2*mass/lower**3)
    kj = 2*(mass+budget)/lower**3+2*epsilon
    forcing = (1.02*(2*budget/lower**3+6*mass*disp/lower**4+2*epsilon)
        +(radius/lower)**2*density*1.01*mu/radius+2*density*radius**2*disp/lower**3)
    return disp/radius, forcing*kernel(kj)


def budgets():
    state=envelope()
    gain=math.exp(TIME*state["growth"])
    initial=preparation()
    limit=SMALL/(initial*gain)
    cases=[]
    for radius in (2.5,6.):
        low,high=0.,limit
        for iteration in range(70):
            mid=(low+high)/2
            if max(ruler(1.125*(gain*initial*mid)**2,radius)) < TOL:
                low=mid
            else:
                high=mid
        for amplitude in (1.,1/160,1e-6,low*.999):
            initial_n=initial*amplitude
            within=initial_n*gain<SMALL
            eps=1.125*(initial_n*gain)**2 if within else None
            angular,radial=ruler(eps,radius) if within else (None,None)
            cases.append(dict(r0=radius,amplitude_fraction=amplitude,initial_characteristic_ceiling=initial_n,
                finite_geometry_limit=limit,sufficient_fraction_for_ruler=low,stress_ceiling=eps,
                angular_ceiling=angular,radial_ceiling=radial,passes_sufficient_test=within and max(angular,radial)<TOL))
    return state,cases


if __name__=="__main__":
    bounds, cases = budgets()
    write("first-exit-box.csv",[{"quantity":k,"value":v} for k,v in bounds.items() if isinstance(v,(float,int))])
    write("initial-only-rulers.csv",cases)
    print([(row["r0"],row["finite_geometry_limit"],row["sufficient_fraction_for_ruler"]) for row in cases[::4]])

