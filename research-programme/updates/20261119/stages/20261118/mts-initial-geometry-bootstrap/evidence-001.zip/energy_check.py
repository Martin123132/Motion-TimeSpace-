from probe import guard, np, Account, HERE, write
from massive_budget import evaluate
from scipy.integrate import cumulative_simpson
import sys


def acquire(count,amplitude):
    guard()
    grid=Account(count);rad=grid.r
    state,path=grid.initial("both","prepared",1.,amplitude);path[[3,5]]-=1
    steps=int(np.ceil(6.5/(.26*grid.step)/256))*256;dt=6.5/steps
    frames=[];times=[]
    for step in range(steps+1):
        if step%(steps//256)==0:
            aa,alpha,bb,ls,lp,mass,energy,sr,st,flow,eh,ed,vd,grad=grid.metric(state)
            field,mom,_,_=state
            uu=rad*field;p=rad*mom
            ur=field+rad*grad;urr=2*grad+rad*grid.second(field);pr=mom+rad*grid.first(mom,1)
            mean=mass*grid.inv**3;mean[0]=energy[0]/3
            ff=alpha*aa;kap=2*mean-ed*(1-vd**2)-field**2
            potential=ff*(1+kap)
            drift=ff*(-2*mass*grid.inv-kap)
            br=rad*ff*kap
            brr=grid.first(br,-1);vr=grid.first(potential-1,1)
            integrate=lambda val:grid.integral(val)[-1]
            e0=.5*integrate(p*p+ur*ur+uu*uu)
            e1=.5*integrate(pr*pr+urr*urr+ur*ur)
            driver0=integrate(br*p*ur+drift*uu*p)
            driver1=integrate(3*br*pr*urr+drift*pr*ur+brr*(pr*ur+urr*p)-vr*pr*uu+br*ur*p)
            n=max(np.max(abs(var)) for var in (uu,p+ur,p-ur,pr+urr,pr-urr))
            frames.append([e0,e1,driver0,driver1,n]);times.append(step*dt)
        if step==steps: break
        first,p1=grid.push(state,path);second,p2=grid.push(state+.5*dt*first,path+.5*dt*p1)
        third,p3=grid.push(state+.5*dt*second,path+.5*dt*p2);fourth,p4=grid.push(state+dt*third,path+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);path+=dt/6*(p1+2*p2+2*p3+p4)
    with (HERE/f"energies-{count}-h{amplitude:g}.npz").open("xb") as stream:
        np.savez_compressed(stream,time=times,series=frames)


def scores():
    guard();rows=[]
    ref=evaluate()[1]
    for n,amp in ((960,1/160),(1920,1/160),(1920,1.)):
        with np.load(HERE/f"energies-{n}-h{amp:g}.npz") as data:
            time=data["time"];series=data["series"]
        for j in range(2):
            en=series[:,j];driver=series[:,j+2]
            initial=ref[f"initial_Y{j}"]*amp/(1/160)
            absolute=float(np.max(abs(en-en[0]-cumulative_simpson(driver,x=time,initial=0))))
            scale=float(np.max(abs(en-en[0])))
            rows.append(dict(mesh=n,amplitude=amp,energy=f"E{j}",initial_Y=np.sqrt(2*en[0]),analytic_initial_Y=initial,
                initial_relative=abs(np.sqrt(2*en[0])/initial-1),max_Y=np.sqrt(2*np.max(en)),
                analytic_Y_ceiling=ref[f"final_Y{j}_ceiling"] if amp==1/160 else None,
                peak_N=np.max(series[:,4]),energy_change=scale,identity_residual=absolute,
                relative_to_own_change=absolute/scale,passes_own_scale=absolute<2e-5*scale))
    return rows


if __name__=="__main__":
    if sys.argv[1]=="score":write("massive-energy-checks.csv",scores())
    else:acquire(int(sys.argv[1]),float(sys.argv[2]))

