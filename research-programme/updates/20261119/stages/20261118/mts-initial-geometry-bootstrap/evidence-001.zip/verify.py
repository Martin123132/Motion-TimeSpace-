from bootstrap import HERE,PARENT,budgets
from probe import guard,LOCK,sha,np
import concentration
import initial_polynomial
import massive_budget
import test_response
import shell_check
import energy_check
import csv
import json
import math
import sys


def rows(name):
    with (HERE/name).open(encoding="utf8",newline="") as stream:
        reader=csv.DictReader(stream,strict=True)
        columns=reader.fieldnames
        assert columns and len(set(columns))==len(columns) and all(columns)
        data=list(reader)
        assert data and all(None not in row and all(v is not None and v.lower() not in ("nan","inf","+inf","-inf") for v in row.values()) for row in data)
        return data


def verify():
    guard();checks={}
    def demand(key,value):
        if not value: raise ArithmeticError(key)
        checks[key]=True
    prior=json.loads((PARENT/"closeout.json").read_text(encoding="utf8"))
    external={"closeout.json":LOCK}
    for name in ("RESULTS.md","evolve.py","resolved.py","comoving.py","sector.py","compare.py","relational.py",
        "COMOVING-GR-BOUND.md","INITIAL-DATA-TO-STRESS.md","NEWTON-LIMIT.md","EQUATIONS.md",
        "small-nonzero-refinement.csv","account-1920-both-prepared-h0.00625.npz","account-1920-dust-bare.npz"):
        external[name]=sha(PARENT/name)
        demand("signed parent "+name,external[name]==prior["files"][name])
    files={}
    for src in sorted(HERE.iterdir()):
        if src.name=="closeout.json":continue
        demand("stage file "+src.name,src.is_file() and src.suffix in (".md",".py",".npz",".csv"))
        files[src.name]=sha(src)
        if src.suffix==".csv":rows(src.name)
        if src.suffix==".py":compile(src.read_bytes(),str(src),"exec")
        if src.suffix==".npz":
            with np.load(src,allow_pickle=False) as packet:
                demand("decode "+src.name,len(packet.files)>0 and all(val.size>0 and (val.dtype.kind in "US" or np.isfinite(val).all()) for val in packet.values()))
    def checksum_table(name,calculated):
        stored=rows(name)
        demand("rows "+name,len(stored)==len(calculated))
        def equivalent(old,new):
            if new is None:return old==""
            if isinstance(new,(str,bool,np.bool_)):return str(new)==old
            return math.isclose(float(old),float(new),rel_tol=2e-12,abs_tol=0)
        demand("recompute "+name,all(set(row)==set(saved) and all(equivalent(saved[key],value) for key,value in row.items()) for row,saved in zip(calculated,stored,strict=True)))
    box,simple=budgets()
    checksum_table("first-exit-box.csv",[dict(quantity=k,value=v) for k,v in box.items() if isinstance(v,(float,int))])
    checksum_table("initial-only-rulers.csv",simple)
    checksum_table("initial-polynomial-integrals.csv",initial_polynomial.profile())
    repaired=massive_budget.evaluate()
    checksum_table("massive-initial-only-rulers.csv",repaired)
    limit=[r for r in repaired if r["amplitude"]==.00625]
    demand("original target passes improved bound at both radii",len(limit)==2 and all(r["first_exit_N_rhs"]<.001 and max(r["angular_ceiling"],r["radial_ceiling"])<2e-5 for r in limit))
    simple_original=[r for r in simple if r["amplitude_fraction"]==.00625]
    demand("simple bound did not certify original target",len(simple_original)==2 and not any(r["passes_sufficient_test"] for r in simple_original))
    demand("larger state kept outside sufficient bound",not any(r["passes_geometry"] for r in repaired if r["amplitude"]==1.))
    with (PARENT/"small-nonzero-refinement.csv").open(encoding="utf8") as stream:
        observed=list(csv.DictReader(stream))
    for r in observed:
        cap=next(rec[r["axis"]+"_ceiling"] for rec in limit if rec["r0"]==float(r["r0"]))
        demand("prior observed within bound "+r["axis"]+r["r0"],0<float(r["nonzero_peak"])<cap)
    checksum_table("central-concentration.csv",concentration.calculate())
    stats,defects=test_response.run()
    checksum_table("metric-and-wave-controls.csv",stats);checksum_table("tiny-ruler-controls.csv",defects)
    demand("four resolved tiny-signal comparisons",len(defects)==4 and max(max(r["defect_vs_original_ruler"],r["amplitude_square_waveform_error"],r["mesh_error_fraction"]) for r in defects)<2e-5)
    shells=[row for n in (960,1920) for arm in ("dust","both") for row in shell_check.scores(n,arm)]
    checksum_table("shell-identity-controls.csv",shells)
    demand("paired shell controls on both meshes",len(shells)==32 and all(r["relative"]<2e-5 for r in shells))
    energies=energy_check.scores()
    checksum_table("massive-energy-checks.csv",energies)
    demand("fine balances and acknowledged coarse failure",all(r["passes_own_scale"] for r in energies if r["mesh"]==1920) and not next(r["passes_own_scale"] for r in energies if r["mesh"]==960 and r["energy"]=="E1"))
    for r in energies:
        if r["amplitude"]==.00625:
            demand("separate positive-energy bound "+str((r["mesh"],r["energy"])),r["max_Y"]<r["analytic_Y_ceiling"] and r["peak_N"]<limit[0]["first_exit_N_rhs"])
    return dict(parent=LOCK,inputs=external,files=files,checks=checks)


if __name__=="__main__":
    receipt=verify()
    name=HERE/"closeout.json"
    if sys.argv[1:]==["--seal"]:
        with name.open("x",encoding="utf8",newline="\n") as stream:
            json.dump(receipt,stream,indent=2,sort_keys=True);stream.write("\n")
    elif sys.argv[1:] or json.loads(name.read_text(encoding="utf8"))!=receipt:
        raise ValueError("Unexpected arguments or changed receipt")
    print(len(receipt["checks"]),"checks;",len(receipt["files"]),"stage files;",len(receipt["inputs"]),"parent inputs;",sha(name))

