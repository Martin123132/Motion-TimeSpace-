from probe import HERE, PARENT, guard, Account, np, defect, write, budgets
from relational import TARGET, interp, peak


def initial_diff(mesh,amp):
    grid=Account(mesh)
    withfield,_=grid.initial("both","prepared",1.,amp)
    ordinary,_=grid.initial("dust","bare")
    metric,ref=grid.metric(withfield),grid.metric(ordinary)
    den=1/metric[0]+1/ref[0]
    fac=np.exp(grid.integral(2*grid.r*ordinary[2]/den))
    excess=grid.integral(fac*grid.r**2*metric[10])/fac
    spots=np.rint(np.array([2.5,6.])/grid.step).astype(int)
    return np.stack([ref[5],ref[11],excess,-2*ordinary[2]*excess*grid.inv/den])[:,spots]


def run():
    guard();bounds,_=budgets()
    stats=[];output=[];checks=[]
    old=1/160
    new=.000014
    for mesh in (960,1920):
        with np.load(HERE/f"control-{mesh}-h{new:g}.npz",allow_pickle=False) as data:
            events,base=data["events"],data["base"]
            series,time=data["stats"],data["time"]
            trial=bounds["growth"];ceiling=new*.02205483*np.exp(time*trial)
            assert np.all(series[:,0]<=ceiling) and np.all(series[:,1]<=1.125*series[:,0]**2)
            assert np.all(series[:,2]<bounds["g_density"]) and np.max(series[:,3])<=bounds["compact"]
            assert np.min(series[:,4])>=bounds["b_lower"] and np.min(series[:,5])>=bounds["potential_lower"]
            assert np.max(series[:,6])<bounds["v_bound"] and min(series[:,7])>=1-bounds["j_down"] and min(series[:,8])>=1-bounds["a_dev"]
            stats.append(dict(mesh=mesh,actual_initial_N=series[0,0],max_N=np.max(series[:,0]),
                initial_analytic_N=ceiling[0],max_fraction_N_envelope=np.max(series[:,0]/ceiling),
                max_energy=np.max(series[:,1]),max_rho_slope=np.max(series[:,2]),max_compact=np.max(series[:,3]),
                min_B=np.min(series[:,4]),min_V=np.min(series[:,5]),max_dust_speed=np.max(series[:,6])))
            output.append(np.array([defect(events[:,:,slot],base[:,slot],radius) for slot,radius in enumerate((2.5,6.))]))
    refbase=initial_diff(1920,old)
    with np.load(PARENT/"account-1920-both-prepared-h0.00625.npz",allow_pickle=False) as src, np.load(PARENT/"account-1920-dust-bare.npz",allow_pickle=False) as dust:
        for slot,(radius,idx) in enumerate(((2.5,1),(6.,4))):
            obs,control=src["events"][:,:,idx],dust["events"][:,:,idx]
            raw=interp(obs[:,0],obs[:,2:4],TARGET)-interp(control[:,0],control[:,2:4],TARGET)
            reference=defect(obs,refbase[:,slot],radius)
            for axis,name in enumerate(("radial","angular")):
                small=output[1][slot,:,axis];coarse=output[0][slot,:,axis]
                signal=peak(small);oldsignal=peak(raw[:,axis])
                checks.append(dict(r0=radius,axis=name,amplitude=new,peak_change=signal,
                    mesh_error_fraction=peak(coarse-small)/signal,
                    defect_vs_original_ruler=peak(reference[:,axis]-raw[:,axis])/oldsignal,
                    amplitude_square_waveform_error=peak(small-(new/old)**2*raw[:,axis])/signal,
                    peak_ratio_to_saved=signal/oldsignal,expected_ratio=(new/old)**2))
    return stats,checks


if __name__=="__main__":
    stats,checks=run();write("metric-and-wave-controls.csv",stats);write("tiny-ruler-controls.csv",checks)

