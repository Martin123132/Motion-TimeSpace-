from bootstrap import HERE, PARENT, write, budgets, PROPER
import sys
sys.dont_write_bytecode=True
sys.path.insert(0,str(PARENT))
from comoving import Account
from evolve import guard as previous_guard, sha, np
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from scipy.special import betainc
from pathlib import Path

LOCK="2ec01956932aed50c5e46b069f8362e18b899542d391019258f87a245ab47762"


def guard():
    previous_guard()
    assert sha(PARENT/"closeout.json")==LOCK and not (HERE/"STOP-REQUESTED").exists()


def collect(count,amplitude):
    guard()
    grid=Account(count)
    grid.points_fixed=np.array([2.5,6.,12.,30.])
    state,probe=grid.initial("both","prepared",1.,amplitude)
    dust,_=grid.initial("dust","bare")
    m0=grid.metric(dust)
    met=grid.metric(state)
    radii=grid.r
    denom=1/met[0]+1/m0[0]
    kernel=2*radii*state[2]/denom
    factor=np.exp(grid.integral(kernel))
    dm=grid.integral(factor*radii**2*met[10])/factor
    picks=np.rint(np.array([2.5,6.])/grid.step).astype(int)
    base=np.stack([m0[5],m0[11],dm,-2*state[2]*dm*grid.inv/denom])[:,picks]
    probe[[3,5]]-=1
    steps=int(np.ceil(6.5/(.26*grid.step)/256))*256
    dt=6.5/steps
    records=[]; events=[]; times=[]
    for index in range(steps+1):
        if index%(steps//256)==0:
            aa,alpha,bridge,ls,lp,mass,energy,pressure,st,jh,eh,ed,vd,grad=grid.metric(state)
            field,momentum=state[:2]
            ur=field+radii*grad
            urr=2*grad+radii*grid.second(field)
            pr=momentum+radii*grid.first(momentum,1)
            w=radii*momentum
            norm=max(np.max(abs(val)) for val in (radii*field,w+ur,w-ur,pr+urr,pr-urr))
            rho=ed*(1-vd**2)
            mu=mass*grid.inv**3
            mu[0]=energy[0]/3
            kappa=2*mu-rho-field**2
            frac=2*mass*grid.inv
            obs=grid.accounting(state,probe)[1][:,[1,4]]
            records.append([norm,np.max(eh),np.max(abs(radii*grid.first(rho,1))),np.max(frac),np.min(bridge),
                np.min(alpha*aa*(1+kappa)),np.max(abs(vd)),np.min(1+obs[2]),np.min(obs[1]/[2.5,6.])])
            events.append(obs);times.append(index*dt)
        if index==steps:
            break
        first,p1=grid.push(state,probe);second,p2=grid.push(state+.5*dt*first,probe+.5*dt*p1)
        third,p3=grid.push(state+.5*dt*second,probe+.5*dt*p2);fourth,p4=grid.push(state+dt*third,probe+dt*p3)
        state+=dt/6*(first+2*second+2*third+fourth);probe+=dt/6*(p1+2*p2+2*p3+p4)
    with (HERE/f"control-{count}-h{amplitude:g}.npz").open("xb") as stream:
        np.savez_compressed(stream,base=base,time=times,stats=records,events=events,
            columns=["N","peak_scalar_energy","weighted_density_gradient","compactness","minimum_B","minimum_V",
                     "max_dust_speed","minimum_probe_J","minimum_probe_A"])


def defect(events,base,radius):
    time=events[:,0]
    assert np.all(np.diff(time)>0) and time[-1]>=PROPER
    drive=CubicSpline(time,events[:,[6,9,10]],axis=0)
    m0,rho,dm0,drho=base
    scale=max(abs(dm0),np.max(abs(drive(time))),abs(drho))
    assert scale>0
    def rhs(clock,x):
        rb,vb,jb,sb,mass,delta,vel,jac,speed=x
        rate,pressure,kin=drive(clock)/scale
        rr=rb+scale*delta
        total=m0+scale*mass
        acc=m0*(rr+rb)*delta/(rb**2*rr**2)-mass/rr**2-rr*pressure
        source=(2*mass/rr**3-2*m0*delta*(rr**2+rr*rb+rb**2)/(rr**3*rb**3)-kin)*jb
        source+=-drho/scale*(radius/rr)**2+rho*radius**2*delta*(rr+rb)/(rr**2*rb**2)
        return [vb,-m0/rb**2,sb,2*m0/rb**3*jb-rho*(radius/rb)**2,rate,vel,acc,speed,(2*total/rr**3-scale*kin)*jac+source]
    axis=np.linspace(0,PROPER,129)
    answer=solve_ivp(rhs,(0,PROPER),[radius,0,1,0,dm0/scale,0,0,0,0],method="DOP853",
        t_eval=axis,rtol=2e-12,atol=1e-15,max_step=.12)
    assert answer.success
    return scale*np.stack([answer.y[7],answer.y[5]/radius],axis=1)


if __name__=="__main__":
    collect(int(sys.argv[1]),float(sys.argv[2]))

