import csv
from functools import lru_cache
from scipy.optimize import brentq
from history import LIB
from primordial import *
from conditional import digest, save, TOL

SCALE_DK = .0001
DELTA_T = .0002
with np.load(CASES['low'][1]) as packet:
    GRID_MODES = packet['modes']
    EPOCHS = packet['conformal_time'][START:END+1]
LOWER = GRID_MODES[selector({'modes':GRID_MODES},.74989421)]
KNOTS = GRID_MODES[(GRID_MODES>LOWER)&(GRID_MODES<1)]
EVENTS = EPOCHS[[0,-1]]
assert len(KNOTS)==5


@lru_cache(maxsize=180)
def solve(wave,case='heavy',scheme='primary'):
    check()
    state,args,x0,cfg,const,_ = model(case,wave,scheme)
    tagged = case=='heavy'
    if tagged:
        state = np.r_[state[:-2],state[16:18],np.zeros(14)]
        args[6][10] = 1
    clocks = np.unique(np.r_[EPOCHS,(EVENTS[:,None]+DELTA_T*np.array([-1,-.5,0,.5,1])[None,:]).ravel(),
                             np.linspace(EVENTS[0]-.08,EVENTS[-1]+.08,1401)])
    final = clocks[-1]
    cuts = np.unique(np.r_[x0,np.geomspace(.001*wave,wave*final,42),wave*final,52.])
    coords = np.unique(np.r_[cuts,wave*clocks])
    result = np.zeros((len(coords),73 if tagged else 53))
    for left,right in zip(cuts[:-1],cuts[1:]):
        first,last = np.searchsorted(coords,[left,right])
        times = coords[first:last+1]
        vals = np.zeros((len(times),result.shape[1]))
        cap = min(.04,SCHEMES[scheme][2]/np.hypot(1,3e-6*right*max(cfg['masses'])/wave**2))
        arguments = (*args[:5],args[5]+(SCHEMES[scheme][4] if left>=52 else 0),*args[6:])
        status = (LIB if tagged else ADDITIVE)(*arguments,state,times,len(times),cap,vals,byref(c_longlong()))
        assert status==1 and np.isfinite(vals).all()
        result[first:last+1] = vals
    raw = result[np.searchsorted(coords,wave*clocks)]
    out = derived(raw[:,:53],wave,const)
    rate = np.zeros(len(out))
    if tagged:
        scale,hub,com,field = (out[:,COLS.index(key)] for key in ('a','H','comoving_h','u_h'))
        b_heavy = wave*raw[:,54]
        b_slow = (wave/5)**2*raw[:,23]/(wave*raw[:,19])
        nodes,weights = roots_laguerre(32)
        weights *= nodes**3/(1+np.exp(-nodes))/(7*np.pi**4/120)
        gamma = np.hypot(1,scale[:,None]*const[8]/nodes)
        enthalpy = (const[0]+const[1])/scale+(4*(const[2]+const[3])/3+const[14]*((gamma+1/(3*gamma))@weights))/scale**2+b_heavy**2+b_slow**2
        rate = -hub*com+b_heavy**2*wave*out[:,COLS.index('drive_k')]-(1.5*enthalpy+wave**2)*b_heavy*field
        assert np.isfinite(rate).all()
    return clocks,out,rate,const


def event(wave,slot,scheme='primary'):
    clocks,out,rate,_ = solve(float(wave),'heavy',scheme)
    pos = np.searchsorted(clocks,EVENTS[slot])
    assert clocks[pos]==EVENTS[slot]
    return out[pos,4],rate[pos]


def forecast():
    results = {}
    arrays = dict(knots=KNOTS,events=EVENTS,epochs=EPOCHS,names=COLS)
    for slot in (0,1):
        root = brentq(lambda wave:event(wave,slot)[0],LOWER,1.,xtol=3e-10)
        clocks,out,rates,_ = solve(root)
        mid = EVENTS[slot]
        positions = np.searchsorted(clocks, mid+DELTA_T*np.array([-1,-.5,0,.5,1]))
        dvals = out[positions,4]
        fd1 = (dvals[-1]-dvals[0])/(2*DELTA_T)
        fd2 = (dvals[-2]-dvals[1])/DELTA_T
        gradients = [(event(root+width,slot)[0]-event(root-width,slot)[0])/(2*width) for width in (SCALE_DK,SCALE_DK/2)]
        actual_rate = rates[positions[2]]
        residual,correction = {},{}
        for scheme in ('primary','fine','moments','switch','native5'):
            residual[scheme] = float(event(root,slot,scheme)[0])
            correction[scheme] = -residual[scheme]/gradients[-1]
        drift = -actual_rate/gradients[-1]
        bracket = GRID_MODES[(GRID_MODES>=LOWER)&(GRID_MODES<=1.)]
        nearest = int(np.searchsorted(bracket,root))
        results[str(slot)] = dict(tau=float(mid),k=root,gradient=gradients,stress=event(root,slot)[0],
            rate_equation=actual_rate,rate_by_independent_readouts=[fd1,fd2],k_per_Mpc_time=drift,
            finite_diff_drift=-((4*fd2-fd1)/3)/gradients[-1],fixed_k_residual=residual,
            first_order_root_displacements=correction,predicted_archive_bracket=bracket[nearest-1:nearest+1].tolist())
    for num,wave in enumerate(KNOTS):
        for case in ('cold','heavy'):
            clocks,out,rate,const = solve(float(wave),case)
            arrays[f'{num}_{case}'] = out
            arrays[f'{num}_{case}_const'] = const
            arrays['clock'] = clocks
            arrays['rows'] = np.searchsorted(clocks,EPOCHS)
    name='node-before-interior-test'
    freeze(name,arrays,[HERE/'NODE-PROTOCOL.md',HERE/'node_forecast.py',HERE/'primordial.py',HERE/'tagged.dll',
               HERE/'before-unblinding.json',CASES['low'][1]], dict(roots=results,changes_are_first_order_estimates=True))
    print('frozen node and five paired controls',[(r['k'],r['k_per_Mpc_time']) for r in results.values()],flush=True)


if __name__=='__main__':
    forecast()
