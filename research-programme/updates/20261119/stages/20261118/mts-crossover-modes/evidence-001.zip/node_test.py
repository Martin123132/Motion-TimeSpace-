from compare import *
from scipy.optimize import brentq


def run():
    check()
    name = 'node-before-interior-test'
    info = json.loads((HERE/(name+'.json')).read_text())
    assert digest(HERE/(name+'.npz'))==info['packet'] and all(digest(path)==sha for path,sha in info['inputs'].items())
    packet = read(name)
    rows,roots,all_fields = [],[],[]
    with np.load(CASES['low'][1]) as archive:
        names = list(archive['names'])
        modes = archive['modes']
        assert np.array_equal(archive['conformal_time'][START:END+1], packet['epochs'])
        full = archive['values']
        for pos,wave in enumerate(packet['knots']):
            active = full[selector(archive,wave),START:END+1]
            get = lambda name:active[:,names.index(name)]
            truth = get('mts_drho_h')+3*get('H')*get('mts_q_h')/wave
            all_fields.append(truth)
            hrows = packet[f'{pos}_heavy'][packet['rows']]
            cold = packet[f'{pos}_cold']
            aligned = interp(cold[:,0],cold,hrows[:,0])
            removed = (packet[f'{pos}_cold_const'][0]-packet[f'{pos}_heavy_const'][0])*aligned[:,2]/hrows[:,0]
            for obs,values in [('comoving_h',truth),('p_h',get('mts_dp_h')),('weyl_k2',get('Weyl'))]:
                predictions = hrows[:,COLS.index(obs)]
                difference = predictions-values
                error = fraction(difference,values)
                same = np.sign(predictions)==np.sign(values)
                rows.append(dict(k=wave,observable=obs,error_over_own_reference_peak=error,within_tolerance=error<=TOL,
                                 max_error_over_removed_cold_source=peak(difference/removed),n=len(values),same_sign=int(sum(same)),
                                 wrong_sign_max_reference_amplitude=peak(values[~same]) if (~same).any() else 0.,
                                 predicted_initial=predictions[0],reference_initial=values[0],predicted_end=predictions[-1],reference_end=values[-1],
                                 end_predicted_over_generated_cold=predictions[-1]/(aligned[-1,11] if obs=='weyl_k2' else removed[-1])))
        for slot,timepos in ((0,0),(1,-1)):
            data = info['info']['roots'][str(slot)]
            grid = modes[(modes>.7)&(modes<=1.)]
            source = []
            for wave in grid:
                vals = full[selector(archive,wave),START if slot==0 else END]
                source.append(vals[names.index('mts_drho_h')]+3*vals[names.index('H')]*vals[names.index('mts_q_h')]/wave)
            source = np.asarray(source)
            changes = np.flatnonzero(source[1:]*source[:-1]<0)
            for cell in changes:
                lower,upper = grid[cell:cell+2]
                linear = lower+(upper-lower)*source[cell]/(source[cell]-source[cell+1])
                pchip = brentq(PchipInterpolator(grid,source),lower,upper)
                roots.append(dict(slot=slot,epoch=START if slot==0 else END,observed_sign_change_count=len(changes),predicted=data['k'],
                               low=lower,high=upper,correct_bracket=data['predicted_archive_bracket']==[lower,upper],
                               low_stress=source[cell],high_stress=source[cell+1],linear_estimate=linear,pchip_estimate=pchip,
                               interpolation_spread=abs(linear-pchip),derivative_from_equation=data['k_per_Mpc_time'],
                               derivative_from_neighboring_times=data['finite_diff_drift'],peak_abs_closure_shift=max(map(abs,data['first_order_root_displacements'].values()))))
    table('held-out-interior-modes',rows)
    table('node-brackets',roots)
    print('archive encloses node',[(row['low'],row['predicted'],row['high'],row['correct_bracket']) for row in roots])


if __name__=='__main__':
    run()
