from compare import *
from conditional import EVOLVE
from pathlib import Path
import ast
import math


def rows(name):
    with (HERE/(name+'.csv')).open() as handle:
        return list(csv.DictReader(handle))


def verify():
    checks = {}
    def test(key, value):
        if not bool(value):
            raise AssertionError(key)
        checks[key] = True
    check()
    seal()
    prev = json.loads((LAST/'closeout.json').read_text())
    for key,entry in prev['files'].items():
        test('preserved prior '+key,digest(LAST/key)==entry['sha256'] and (LAST/key).stat().st_size==entry['bytes'])
    for path in HERE.glob('*.py'):
        ast.parse(path.read_text(encoding='utf8'))
    manifest = json.loads((HERE/'before-unblinding.json').read_text())
    test('scorer matches prerelease hash',manifest['scoring_code']==digest(HERE/'compare.py'))
    test('all 46 paired and tagged forecasts present',len(manifest['packets'])==46)
    clock=np.linspace(0,3,1201)
    med=np.ones((2401,3))
    med[:,0]=0
    med[:,1]=4
    states=np.zeros((1201,2));states[0]=[.75,0]
    EVOLVE(1200,clock,med,states)
    test('analytic forced oscillator amplitude and velocity',peak(states[:,0]-.25-.5*np.cos(2*clock))<3e-11 and peak(states[:,1]+np.sin(2*clock))<4e-11)
    for label in CASES:
        field = 's' if label=='cold5' else 'h'
        frozen = read('conditional-'+label)
        test(label+' binary32 C increments supported',np.array_equal(frozen['cdm'],frozen['cdm'].astype(np.float32)))
        for bg in ('archive','physical'):
            full=frozen[f'{bg}_{field}_pchip_2'];free=frozen[f'{bg}_{field}_free_2'];drive=frozen[f'{bg}_{field}_driven']
            test(label+bg+' signed free plus driven at all clocks',np.all(np.max(abs(full-free-drive),axis=0)<1e-10*np.max(abs(full),axis=0)))
    cond = rows('conditional-test')
    test('recorded conditional pass/fail at unaltered tolerance',all((entry['pass_peak']=='True')==(float(entry['error_over_target_peak'])<=TOL) for entry in cond))
    for label in ('low','high'):
        packet=read('early-'+label+'-heavy-primary')
        cold=read('early-'+label+'-cold-primary')
        epochs=packet['epoch_rows']
        base=packet['values'][epochs]
        test(label+' real empty cold channel',not cold['values'][:,4:9].any())
        test(label+' independent field states and time coverage',len(epochs)==1215 and packet['clock'][0]<.00011 and
             np.all(np.diff(packet['clock'][epochs])>0) and np.all(np.diff(cold['values'][:,0])>0))
        test(label+' metric stress readout',np.allclose(base[:,11],-(base[:,12]+3*base[:,1]*base[:,13]/packet['wave']+base[:,14])/2,atol=0,rtol=2e-15))
        test(label+' WKB not used to predict amplitude',json.loads((HERE/('early-'+label+'-heavy-primary.json')).read_text())['info']['no_late_metric_inputs'])
        tests=[entry for entry in rows('primordial-sensitivity') if entry['mode']==label and entry['branch']=='heavy' and entry['observable']=='comoving_h']
        test(label+' numerical full-transport sensitivities bounded',all(float(entry['change_over_primary_peak'])<TOL for entry in tests))
        tests=[entry for entry in rows('primordial-vs-archive') if entry['mode']==label and entry['variant']=='primary' and entry['observable']=='comoving_h']
        test(label+' distinguish correct signs from precision miss',len(tests)==1 and tests[0]['within_tolerance']=='False' and tests[0]['same_sign']==tests[0]['n'])
        for scheme in ['primary','fine']:
            tagged=read('history-'+label+'-'+scheme)
            observed=tagged['actual']
            residual=tagged['sources'].sum(axis=1)-observed
            test(label+scheme+' physical decomposition including pre-window history',np.all(np.max(abs(residual),axis=0)<TOL*np.max(abs(observed),axis=0)))
    node=json.loads((HERE/'node-before-interior-test.json').read_text())
    test('five-knot predictions immutable',node['packet']==digest(HERE/'node-before-interior-test.npz') and all(digest(src)==sha for src,sha in node['inputs'].items()))
    for slot,data in node['info']['roots'].items():
        test(slot+' derivative sign and scale',abs(data['finite_diff_drift']/data['k_per_Mpc_time']-1)<TOL)
        test(slot+' nonzero slope refined',abs(data['gradient'][0]/data['gradient'][1]-1)<TOL and data['gradient'][1]<0)
        test(slot+' signed component zero',abs(data['stress'])<1e-12)
    interior=rows('held-out-interior-modes')
    interior_d=[row for row in interior if row['observable']=='comoving_h']
    test('five held-out signs checked at every epoch',len(interior_d)==5 and sum(int(row['same_sign']) for row in interior_d)==5*1215)
    test('own-scale misses not promoted',all(row['within_tolerance']=='False' for row in interior_d))
    roots=rows('node-brackets')
    test('both empirical grid brackets without identifying exact continuum zeros',len(roots)==2 and all(row['correct_bracket']=='True' and float(row['interpolation_spread'])>0 for row in roots))
    gravity=rows('gravity-at-frozen-node')
    test('total metric and wave source distinguished at node',len(gravity)==6 and all(abs(float(row['sum_residual']))<1e-13 and
         abs(float(row['directly_removed_fraction']))<2e-5 and abs(float(row['Weyl_relative_to_matched_cold']))>.1 for row in gravity))
    test('nonempty prior k=5 controls',all(row['within_tolerance']=='True' for row in rows('five-unit-forward-control') if row['observable'] in ('cdm','p_s','weyl_k2','comoving_h')))
    failures={name:sum(row[key]=='False' for row in rows(name)) for name,key in
              [('conditional-test','pass_peak'),('primordial-sensitivity','within_fixed_tolerance'),('primordial-vs-archive','within_tolerance'),
               ('held-out-interior-modes','within_tolerance'),('five-unit-forward-control','within_tolerance')]}
    return dict(checks=checks,integrity_checks=len(checks),scientific_checks_outside_tolerance=failures,unchanged_tolerance=TOL,
                prior_files=len(prev['files']),conditional_and_primordial_packets=len(manifest['packets']))


if __name__=='__main__':
    result=verify()
    path=HERE/'verification.json'
    if path.exists():
        assert json.loads(path.read_text())==result
    else:
        save(path,result)
    if '--seal' in sys.argv:
        files={src.name:dict(bytes=src.stat().st_size,sha256=digest(src)) for src in sorted(HERE.iterdir()) if src.is_file() and src.name!='closeout.json'}
        assert 'RESULTS.md' in files and 'verification.json' in files and not (HERE/'__pycache__').exists()
        close=HERE/'closeout.json'
        if close.exists():
            assert json.loads(close.read_text())['files']==files
        else:
            save(close,dict(utc=datetime.now(timezone.utc).isoformat(),prior=SEAL,files=files,total_bytes=sum(record['bytes'] for record in files.values())))
        print('seal',digest(close),len(files),flush=True)
    print(result['integrity_checks'],result['scientific_checks_outside_tolerance'],flush=True)
