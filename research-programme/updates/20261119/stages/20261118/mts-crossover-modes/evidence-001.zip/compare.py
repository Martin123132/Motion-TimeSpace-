import csv
import json
from functools import lru_cache
from datetime import datetime, timezone
from primordial import *
from conditional import OBS, TOL, digest, save, LAST, SEAL, COLD
from scipy.interpolate import PchipInterpolator


def read(name):
    with np.load(HERE/(name+'.npz')) as handle:
        return {key:handle[key] for key in handle.files}


def seal():
    check()
    sources = {}
    expected = ['conditional-'+label for label in CASES]
    expected += ['early-'+label+'-'+case+'-'+scheme for label in ('low','high')
                 for case in ('cold','heavy') for scheme in [*SCHEMES,'implicit']]
    expected += ['early-'+label+'-'+case+'-primary' for label,case in [('cold5','cold'),('heavy5','heavy')]]
    expected += ['history-'+label+'-'+scheme for label in ('low','high') for scheme in ('primary','fine')]
    packet_hashes = {}
    for name in expected:
        receipt = json.loads((HERE/(name+'.json')).read_text())
        for fname,sha in receipt['inputs'].items():
            if fname not in sources:
                sources[fname] = digest(fname)
            assert sources[fname]==sha
        packet_hashes[name] = digest(HERE/(name+'.npz'))
        assert packet_hashes[name]==receipt['packet'] and receipt['prior']==SEAL and receipt['protocol']==digest(HERE/'PROTOCOL.md')
    manifest = HERE/'before-unblinding.json'
    if manifest.exists():
        assert json.loads(manifest.read_text())['packets']==packet_hashes
    else:
        save(manifest,dict(utc=datetime.now(timezone.utc).isoformat(),packets=packet_hashes,source_count=len(sources),
                           prior=SEAL,scoring_code=digest(HERE/'compare.py')))


def peak(values):
    return float(np.max(abs(values)))


def fraction(diff,ref):
    return peak(diff)/peak(ref) if peak(ref) else (0. if peak(diff)==0 else None)


def table(name, rows):
    with (HERE/(name+'.csv')).open('x',newline='',encoding='utf8') as out:
        writer = csv.DictWriter(out,fieldnames=rows[0])
        writer.writeheader()
        writer.writerows(rows)


def actual(label):
    _,path,target = CASES[label]
    with np.load(path) as packet:
        names = list(packet['names'])
        pos = selector(packet,target)
        rows = packet['values'][pos,START:END+1]
        wave = packet['modes'][pos]
    get = lambda key:rows[:,names.index(key)]
    fields = {field:np.column_stack((get('mts_dphi_'+field),get('mts_dphidot_'+field),
        get('mts_drho_'+field)+3*get('H')/wave*get('mts_q_'+field),get('mts_dp_'+field),get('mts_q_'+field))) for field in ('s','h')}
    return get,fields


def conditional_results():
    rows,special = [],{}
    for label in CASES:
        packet = read('conditional-'+label)
        get,truth = actual(label)
        for field in ('s','h'):
            for bg in ('archive','physical'):
                base = packet[f'{bg}_{field}_pchip_2']
                free = packet[f'{bg}_{field}_free_2']
                driven = packet[f'{bg}_{field}_driven']
                for pos,obs in enumerate(OBS):
                    ref = truth[field][1:,pos]
                    pred = base[1:,pos]
                    err = fraction(pred-ref,ref)
                    significant = abs(ref)>1e-3*peak(ref)
                    rows.append(dict(label=label,background=bg,field=field,observable=obs,
                        target_peak=peak(ref),error_over_target_peak=err,pass_peak=err is not None and err<=TOL,
                        max_point_relative_above_per_mille=(peak((pred[significant]-ref[significant])/ref[significant]) if significant.any() else None),
                        correct_sign_count=int(np.sum(np.sign(pred)==np.sign(ref))),n=len(ref),
                        terminal_pred=pred[-1],terminal_reference=ref[-1],terminal_free=free[-1,pos],terminal_driven=driven[-1,pos],
                        free_driven_split_error=fraction((free+driven-base)[1:,pos],ref),
                        fine_step_change=fraction((base-packet[f'{bg}_{field}_pchip_1'])[1:,pos],ref),
                        **{key+'_change':fraction((base-packet[f'{bg}_{field}_{key}_2'])[1:,pos],ref)
                           for key in ('integral','linear','cubic','thinned')}))
        window = len(packet['clock'])
        special[label] = dict(scalar_epochs_scored=window-1,max_source_gap_Mpc=float(max(np.diff(packet['clock']))/5),
            intervals_outside_independent_CDM_rounding=int(sum(abs(packet['increment_mismatch'])>packet['increment_half_ulp_bound'])),
            source_intervals=window-1)
    table('conditional-test',rows)
    return special


def interp(scale,vals,query):
    assert np.all(np.diff(scale)>0) and np.all(query>=scale[0]) and np.all(query<=scale[-1])
    return PchipInterpolator(scale,vals,axis=0,extrapolate=False)(query)


def full_results():
    sensitivities,compares,ratios,history = [],[],[],[]
    idx = COLS.index
    for label in ('low','high'):
        get,actual_fields = actual(label)
        data = {(case,scheme):read('early-'+label+'-'+case+'-'+scheme) for case in ('cold','heavy') for scheme in [*SCHEMES,'implicit']}
        for (case,scheme),packet in data.items():
            primary = data[case,'primary']
            pred = packet['values'][packet['epoch_rows']]
            base = primary['values'][primary['epoch_rows']]
            for pos,obs in enumerate(COLS):
                err = fraction(pred[:,pos]-base[:,pos],base[:,pos])
                sensitivities.append(dict(mode=label,branch=case,variant=scheme,observable=obs,change_over_primary_peak=err,
                                          within_fixed_tolerance=err is not None and err<=TOL))
            if case=='heavy':
                truth = {'a':get('a'),'H':get('H'),'cdm':get('delta_cdm'),'etak':get('etak'),'weyl_k2':get('Weyl')}
                truth.update({'comoving_h':actual_fields['h'][:,2],'p_h':actual_fields['h'][:,3],'u_h':actual_fields['h'][:,0],
                              'udot_h':actual_fields['h'][:,1],'q_h':actual_fields['h'][:,4],'p_s':actual_fields['s'][:,3]})
                for obs,truth_values in truth.items():
                    values=pred[:,idx(obs)]
                    err = fraction(values-truth_values,truth_values)
                    compares.append(dict(mode=label,variant=scheme,observable=obs,peak_error=err,within_tolerance=err<=TOL,
                         same_sign=int(np.sum(np.sign(values)==np.sign(truth_values))),n=len(pred),
                         predicted_end=values[-1],archived_end=truth_values[-1],peak_archived=peak(truth_values)))
        for scheme in [*SCHEMES,'implicit']:
            cold = data['cold',scheme]
            heavy = data['heavy',scheme]
            active = heavy['values'][heavy['epoch_rows']]
            ref = cold['values']
            common = interp(ref[:,0],ref,active[:,0])
            removed = (cold['const'][0]-heavy['const'][0])*common[:,idx('cdm')]/active[:,0]
            assert np.all(removed>0)
            frac = active[:,idx('comoving_h')]/removed
            lens = active[:,idx('weyl_k2')]/common[:,idx('weyl_k2')]
            ratios.append(dict(mode=label,variant=scheme,k=float(heavy['wave']),a_end=active[-1,0],
                       min_replacement=frac.min(),max_replacement=frac.max(),end_replacement=frac[-1],
                       end_Weyl_ratio=lens[-1],min_Weyl_ratio=lens.min(),max_Weyl_ratio=lens.max(),
                       end_CDM_interpolation_change=abs(np.interp(active[-1,0],ref[:,0],ref[:,idx('cdm')])/common[-1,idx('cdm')]-1)))
        for scheme in ('primary','fine'):
            packet = read('history-'+label+'-'+scheme)
            epoch = packet['epoch_rows']
            contributions = packet['sources'][epoch]
            absolute = packet['actual'][epoch]
            standalone = data['heavy',scheme]['values'][data['heavy',scheme]['epoch_rows'],4:6]
            for pos,obs in enumerate(('comoving_h','p_h')):
                signed = contributions[-1,:,pos]/absolute[-1,pos]
                history.append(dict(mode=label,scheme=scheme,observable=obs,closure=fraction(contributions.sum(axis=1)[:,pos]-absolute[:,pos],absolute[:,pos]),
                           physical_trajectory_change=fraction(absolute[:,pos]-standalone[:,pos],standalone[:,pos]),
                           end_value=absolute[-1,pos],end_before_window_share=sum(signed[:-1]),
                           end_in_window_share=signed[-1],sum_abs_shares=sum(abs(signed)),
                           **{'share_'+str(num):val for num,val in enumerate(signed)}))
    table('primordial-sensitivity',sensitivities)
    table('primordial-vs-archive',compares)
    table('matched-cold-replacement',ratios)
    table('causal-history',history)


def control_results():
    rows = []
    for case in ('cold','heavy'):
        tag = 'cold5' if case=='cold' else 'heavy5'
        packet = read('early-'+tag+'-'+case+'-primary')
        with np.load(SWITCH/(case+'-main-fork.npz')) as ref:
            xs = ref['x']/5
            truth = derived(ref['forecast'],5.,packet['const'])
        pred = interp(packet['clock'],packet['values'],xs)
        for pos,obs in enumerate(COLS):
            err = fraction(pred[:,pos]-truth[:,pos],truth[:,pos])
            rows.append(dict(branch=case,observable=obs,old_independent_forward_scale=peak(truth[:,pos]),
                             difference_over_peak=err,within_tolerance=err is not None and err<=TOL))
    table('five-unit-forward-control',rows)


if __name__=='__main__':
    seal()
    info = conditional_results()
    full_results()
    control_results()
    save(HERE/'source-coverage.json',info)
    print('Frozen packet comparisons saved.',flush=True)
