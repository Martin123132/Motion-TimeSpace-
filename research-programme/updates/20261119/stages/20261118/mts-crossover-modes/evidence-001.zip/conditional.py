import ctypes
import hashlib
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

for setting in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[setting] = '1'
HERE = Path(__file__).resolve().parent
POST = HERE.parent
LAST = POST / 'mts-pressure-transfer-20261118'
sys.path.insert(0, str(LAST))
from transfer import Continuation, START, END, PTR, np, guard
from scipy.interpolate import CubicSpline, PchipInterpolator

COMMON = POST / 'condensate-origin-20261003'
GRID = COMMON / 'resolved-matter-spectrum-20261007/runs/exact-grid'
COLD = COMMON / 'native-two-field-transfer-20261007/runs/final-bg8-start/cold.npz'
CASES = {'low': ('heavy', GRID/'chunk-0352.npz', .71049741),
         'high': ('heavy', GRID/'chunk-0352.npz', .74989421),
         'heavy5': ('heavy', GRID/'chunk-0384.npz', 5.),
         'cold5': ('cold', COLD, 5.)}
TOL = 2e-5
SEAL = 'ab54b4974b94628a71cdd1a040c3b284680a73ea9f0b4be511db4d9431092fcf'
EVOLVE = ctypes.CDLL(str(HERE/'oscillator.dll')).evolve
EVOLVE.argtypes = [ctypes.c_int, PTR, PTR, PTR]
EVOLVE.restype = None
OBS = ['dphi','dphidot','comoving','pressure','momentum']


def digest(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def check():
    guard()
    assert digest(LAST/'closeout.json') == SEAL and not (HERE/'STOP-REQUESTED').exists()


def save(path, data):
    with path.open('x', encoding='utf8') as out:
        json.dump(data, out, indent=2, allow_nan=False)


def freeze(name, arrays, inputs, info):
    path = HERE/(name+'.npz')
    with path.open('xb') as out:
        np.savez_compressed(out, **arrays)
    save(HERE/(name+'.json'), dict(utc=datetime.now(timezone.utc).isoformat(), packet=digest(path),
         prior=SEAL, protocol=digest(HERE/'PROTOCOL.md'), inputs={str(src):digest(src) for src in inputs}, info=info))


def selector(packet, target):
    return int(np.flatnonzero(np.isclose(packet['modes'], target, atol=5e-8, rtol=0)).item())


def given(label):
    case, path, target = CASES[label]
    with np.load(path) as packet:
        idx = selector(packet, target)
        wave = packet['modes'][idx]
        names = list(packet['names'])
        rows = packet['values'][idx]
        window = slice(START, END+1)
        clocks = 5*packet['conformal_time'][window]
        source = {col: rows[window, names.index(col)].copy() for col in
                  ('a','H','delta_cdm','v_baryon_cdm','growth','delta_nonu','mts_averaged_chart')}
        initial = {field:np.array([rows[START,names.index('mts_dphi_'+field)],
                                   rows[START,names.index('mts_dphidot_'+field)]/5]) for field in ('s','h')}
    return case, path, wave, clocks, source, initial


def dense_grid(clock, cap):
    steps = np.maximum(1, 2**np.maximum(0, np.ceil(np.log2(np.diff(clock)/cap))).astype(int))
    medium_clock = np.r_[np.concatenate([left+np.arange(2*size)*(right-left)/(2*size)
                             for left,right,size in zip(clock[:-1],clock[1:],steps)]), clock[-1]]
    indexes = np.r_[0,steps.cumsum()]
    assert np.array_equal(medium_clock[2*indexes], clock)
    return medium_clock, indexes


def integrate(wave, field, medium, time, indexes, force, initial):
    start = 7 if field=='s' else 10
    beta, potential, mass2 = medium[:,start:start+3].T
    coeff = np.column_stack((medium[:,1],(wave/5)**2+mass2,beta*force))
    states = np.empty(((len(time)+1)//2,2))
    states[0] = initial
    EVOLVE(len(states)-1, np.ascontiguousarray(time[::2]), coeff, states)
    disp, speed = states[indexes].T
    pos = 2*indexes
    kin, pot = beta[pos]*speed, potential[pos]*disp
    return np.column_stack((disp,5*speed,25*(kin+pot+3*medium[pos,1]*beta[pos]*disp),
                            25*(kin-pot),5*wave*beta[pos]*disp))


def sources(time, clocks, rate, cdm):
    curve = PchipInterpolator(clocks, rate)
    integral = np.diff(curve.antiderivative()(clocks))
    widths = np.diff(clocks)
    error = np.diff(cdm)-integral
    bound = abs(np.spacing(cdm.astype('f4')).astype(float))/2
    radius = bound[1:]+bound[:-1]
    cell = np.clip(np.searchsorted(clocks,time,side='right')-1,0,len(widths)-1)
    weight = (time-clocks[cell])/widths[cell]
    adjust = (6*weight*(1-weight)/widths[cell])*(error-np.clip(error,-radius,radius))[cell]
    thin = np.unique(np.r_[0,np.arange(0,len(clocks),2),len(clocks)-1])
    return dict(pchip=curve(time),integral=curve(time)+adjust,linear=np.interp(time,clocks,rate),
                cubic=CubicSpline(clocks,rate)(time),thinned=PchipInterpolator(clocks[thin],rate[thin])(time),
                free=np.zeros_like(time)), error, radius


def run(label):
    check()
    case,path,wave,clock,source,initial = given(label)
    job = Continuation(case,2)
    assert np.array_equal(clock,job.times) and not source['mts_averaged_chart'].any()
    rate = (source['H']*source['growth']*source['delta_nonu']+job.obj.config['baryon']*wave*source['v_baryon_cdm'])/5
    output = dict(clock=clock,wave=wave,columns=OBS,drive=rate,cdm=source['delta_cdm'],scale=source['a'])
    background = {}
    for level, cap in enumerate((.008,.004,.002)):
        time, rows = dense_grid(clock,cap)
        old,phys,bg = job.media(time)
        variations, error, radius = sources(time,clock,rate,source['delta_cdm'])
        for tag,med in [('archive',old),('physical',phys)]:
            for field in ('s','h'):
                for form,force in variations.items():
                    if level<2 and form!='pchip':
                        continue
                    result = integrate(wave,field,med,time,rows,force,initial[field])
                    assert np.isfinite(result).all()
                    output[f'{tag}_{field}_{form}_{level}'] = result
                if level==2:
                    output[f'{tag}_{field}_driven'] = integrate(wave,field,med,time,rows,variations['pchip'],np.zeros(2))
            if level==2:
                output[tag+'_beta_h'] = med[2*rows,10]
                output[tag+'_mass2_h'] = med[2*rows,12]
                if case=='heavy':
                    freq0 = np.sqrt(med[:,12])
                    beat = (wave/5)**2/(np.hypot(freq0,wave/5)+freq0)
                    background[tag+'_mass_only_beat_phase_radians'] = float(np.trapezoid(beat,time))
        if level==2:
            background['archive_a_fraction_error'] = float(np.max(abs(bg[2*rows,0]/source['a']-1)))
            background['archive_H_fraction_error'] = float(np.max(abs(5*old[2*rows,1]/source['H']-1)))
    output.update(increment_mismatch=error,increment_half_ulp_bound=radius)
    freeze('conditional-'+label,output,[path,job.epoch,job.obj.background_path,HERE/'conditional.py',HERE/'oscillator.dll',LAST/'transfer.py',*job.obj.source_paths],background)
    print('frozen',label,background,flush=True)


if __name__ == '__main__':
    for label in sys.argv[1:] or CASES:
        run(label)
