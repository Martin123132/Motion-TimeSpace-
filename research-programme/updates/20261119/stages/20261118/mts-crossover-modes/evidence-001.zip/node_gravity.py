from node_forecast import *
import json
sys.path.insert(0,str(HERE))
from compare import table, interp


def run():
    lock = HERE/'node-before-interior-test.json'
    receipt = json.loads(lock.read_text())
    assert digest(HERE/'node-before-interior-test.npz')==receipt['packet']
    rows = []
    for slot,clock in enumerate(EVENTS):
        wave = receipt['info']['roots'][str(slot)]['k']
        for scheme in ('primary','fine','switch'):
            times,matter,_,cheavy = solve(wave,'heavy',scheme)
            _,cold,_,ccold = solve(wave,'cold',scheme)
            active = matter[np.searchsorted(times,clock)]
            base = interp(cold[:,0],cold,active[0])
            current = 3*active[1]/wave*active[13]
            direct = -active[4]/2
            other = -(active[12]+current+active[14]-active[4])/2
            rows.append(dict(epoch=START if slot==0 else END,variant=scheme,k=wave,a=active[0],
                      direct_heavy_Weyl=direct,other_species_Weyl=other,total_Weyl=active[11],
                      directly_removed_fraction=direct/active[11],Weyl_relative_to_matched_cold=active[11]/base[11],
                      sum_residual=(direct+other-active[11])/abs(active[11]),
                      heavy_comoving_over_removed=active[4]/((ccold[0]-cheavy[0])*base[2]/active[0])))
    table('gravity-at-frozen-node',rows)
    print('gravity at fixed primary zeros',[(r['epoch'],r['Weyl_relative_to_matched_cold']) for r in rows if r['variant']=='primary'])


if __name__=='__main__':
    run()
