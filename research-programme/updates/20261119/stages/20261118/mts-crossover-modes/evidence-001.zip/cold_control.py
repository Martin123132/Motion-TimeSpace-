import conditional as solver
from conditional import CASES, HERE, START, END, np, selector


def cold_given(label):
    assert label=='cold5'
    case,path,wave = CASES[label]
    with np.load(path) as packet:
        names = list(packet['names'])
        assert 'mts_averaged_chart' not in names
        rows = packet['values'][selector(packet,wave)]
        clock = 5*packet['conformal_time'][START:END+1]
        fields = {col:rows[START:END+1,names.index(col)] for col in
                  ('a','H','delta_cdm','v_baryon_cdm','growth','delta_nonu')}
        fields['mts_averaged_chart'] = np.zeros(len(clock))
        initial = {key:rows[START,[names.index('mts_dphi_'+key),names.index('mts_dphidot_'+key)]]/[1,5]
                   for key in ('s','h')}
        assert not initial['h'].any()
    return case,path,wave,clock,fields,initial


if __name__=='__main__':
    original = solver.freeze
    solver.freeze = lambda name,arrays,paths,info: original(name,arrays,[*paths,HERE/'cold_control.py'],
                      dict(info,cold_has_no_chart_column=True,empty_field_only=True))
    solver.given = cold_given
    solver.run('cold5')
