from primordial import HERE, POST, CASES, START, END, SCHEMES, SWITCH, check, freeze, selector, model, derived, np, CDLL, byref, c_longlong, ADDITIVE

TAGS = ['regular initial displacement and speed','source before k*tau=1','1 to 2pi',
        '2pi to 4pi','4pi to 8pi','8pi to 16pi','16pi to window start','inside test window']
LIB = CDLL(str(HERE/'tagged.dll')).original_additive_step
LIB.argtypes,LIB.restype = ADDITIVE.argtypes,ADDITIVE.restype


def run(label,scheme):
    check()
    _,path,target = CASES[label]
    with np.load(path) as packet:
        wave = packet['modes'][selector(packet,target)]
        epochs = packet['conformal_time'][START:END+1]
    state,args,x0,cfg,const,sources = model('heavy',wave,scheme)
    state = np.r_[state[:-2],state[16:18],np.zeros(14)]
    divisions = np.r_[x0,1.,2*np.pi,4*np.pi,8*np.pi,16*np.pi,epochs[0]*wave,epochs[-1]*wave]
    assert np.all(np.diff(divisions)>0)
    breaks = np.unique(np.r_[divisions,np.geomspace(.001*wave,wave*epochs[-1],44)])
    coords = np.unique(np.r_[breaks,np.geomspace(.001*wave,epochs[0]*wave,800),epochs*wave])
    saved = np.zeros((len(coords),73))
    for left,right in zip(breaks[:-1],breaks[1:]):
        first,last = np.searchsorted(coords,[left,right])
        times = coords[first:last+1]
        args[6][10] = np.searchsorted(divisions,left,side='right')
        cap = min(.04,SCHEMES[scheme][2]/np.hypot(1,3e-6*right*max(cfg['masses'])/wave**2))
        vals = np.zeros((len(times),73))
        status = LIB(*args,state,times,len(times),cap,vals,byref(c_longlong()))
        assert status==1 and np.isfinite(vals).all()
        saved[first:last+1] = vals
    data = derived(saved[:,:53],wave,const)
    tags = saved[:,57:].reshape(-1,8,2)*wave**2
    freeze('history-'+label+'-'+scheme,dict(clock=coords/wave,epoch_rows=np.searchsorted(coords,wave*epochs),
           bands=TAGS,divisions=divisions/wave,sources=tags,actual=data[:,4:6],geom=saved[:,53:57],k=wave),
           [*sources,path,HERE/'history.py',HERE/'tagged.dll',HERE/'tagged.inc',HERE/'tagged_generated.c',
            HERE/'tagged_build.py',HERE/'primordial.py',SWITCH/'switch.c'],dict(adjoint_equivalent=True,
           procedure='forward passive retarded source partitions; mixed metric unaltered, regular origin',
           geom_units='phi, dphi/d(k*tau), a*m/k, conformal_H/k'))
    print('frozen history',label,scheme,flush=True)


if __name__=='__main__':
    for label in ['low','high']:
        for scheme in ['primary','fine']:
            run(label,scheme)
