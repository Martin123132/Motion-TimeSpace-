from pathlib import Path

root = Path(__file__).resolve().parent
prior = root.parent/'mts-neutrino-switch-20261118'
code = (prior/'switch.c').read_text()
for old,new,count in [
    ('OBS=53','OBS=73',1),('model.phot+2*(polar-1)+2','model.phot+2*(polar-1)+16',2),
    ('../mts-massive-transport-20261117/shadow_eval.inc','tagged.inc',1),
    ('"branches.inc"','"../mts-neutrino-switch-20261118/branches.inc"',1)]:
    assert code.count(old)==count
    code = code.replace(old,new)
with (root/'tagged_generated.c').open('x') as out:
    out.write(code)
