from conditional import CASES, HERE, POST, START, END, check, freeze, selector, np, sys
from ctypes import CDLL, byref, c_longlong
from scipy.interpolate import CubicSpline
from scipy.special import roots_laguerre

SWITCH = POST/'mts-neutrino-switch-20261118'
sys.path.insert(0,str(SWITCH))
import fork
from first_output import EarlySystem, inputs
from bridge import quadrature

ADDITIVE = CDLL(str(SWITCH/'switch.dll')).original_additive_step
ADDITIVE.argtypes, ADDITIVE.restype = fork.LIB.argtypes, fork.LIB.restype
SCHEMES = {'coarse':(16,96,.060,2,0,1), 'primary':(16,96,.030,2,0,1),
           'fine':(16,96,.015,2,0,1), 'moments':(24,112,.030,2,0,1),
           'trace':(16,96,.030,3,0,1), 'switch':(16,96,.030,2,12,1),
           'start':(16,96,.030,2,0,.5), 'native5':(5,96,.030,2,12,1)}
COLS = ['a','H','cdm','etak','comoving_h','p_h','u_h','udot_h','q_h','p_s','comoving_s',
        'weyl_k2','density','current','pi','drive_k','trace_minus_constraint']


def thermal(case,wave):
    path = POST/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz')
    with np.load(path) as packet:
        first, step = packet['metadata']
        values = packet['values']
    tau = first*np.exp(step*np.arange(values.shape[1]))
    scale = values[0]*tau
    count = np.searchsorted(scale,.000275)+3
    ratio = wave/5
    rows = np.column_stack((scale[:count],ratio*tau[:count],values[:6,:count].T))
    rows[:,2:4] /= ratio
    rows[:,6:8] /= ratio
    assert np.all(np.diff(rows[:,0])>0) and np.all(rows[:,[4,6]]>0)
    bgpath = POST/'condensate-origin-20261003/native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    with np.load(bgpath) as data:
        grid,vel,phi = (data[key] for key in ('efold','phidot_s','phi_s'))
    vel = vel/ratio
    shadow = np.column_stack((grid[:-1],CubicSpline(grid,vel,bc_type='natural').c.T,
                              CubicSpline(grid,phi,bc_type='natural').c.T))
    shadow = np.vstack(([-46,0,0,0,vel[0],0,0,0,phi[0]],shadow,[grid[-1],0,0,0,vel[-1],0,0,0,phi[-1]]))
    nodes,weights = roots_laguerre(32)
    weights *= nodes**3/(1+np.exp(-nodes))/(7*np.pi**4/120)
    table = np.r_[rows.ravel(),np.c_[nodes,weights].ravel(),len(shadow),shadow.ravel()]
    return table,int(count),step,path,bgpath


def model(case,wave,scheme):
    count,limit,angle,flag,switch,start_factor = SCHEMES[scheme]
    cfg = inputs(case)
    cpath = POST/'mts-integrated-defect-20261112'/(case+'-native-clock.npz')
    with np.load(cpath) as packet:
        const = packet['constants']
    ratio = wave/5
    scaled = dict(cfg,alpha=cfg['alpha']/ratio,omega=cfg['omega']/ratio,masses=cfg['masses']/ratio,
                  start=ratio*.0001*start_factor,table_age=ratio*cfg['table_age'])
    early = EarlySystem(scaled,7)
    seed = early.initialize('regular')
    x0 = 5*scaled['start']
    species = len(early.origin)
    table,nth,spacing,thermal_path,bg_path = thermal(case,wave)
    massive = const[14]/(3*cfg['alpha']**2)
    params = np.zeros(12)
    params[:6] = [scaled['alpha'],cfg['omega']/wave,cfg['fraction']-massive,massive,const[8],cfg['baryon']]
    params[6:6+species] = early.parameters
    params[8:8+species] = early.origin
    params[11] = spacing
    assert np.allclose(early.parameters,(cfg['masses']*cfg['alpha']/wave**2)**2,rtol=1e-15,atol=0)
    nodes,weights = quadrature(count)
    polar = 16
    photo = 18+(count+1)*(limit+2)
    state = np.zeros(photo+2*(polar-1)+2)
    state[:5] = seed[:5]
    state[5] = seed[6]
    state[10:10+4*species] = seed[early.first+1:]
    for index in range(count+1):
        pos = 18+index*(limit+2)
        state[pos:pos+3] = [seed[5],4*seed[7]/3,2*seed[8]]
        state[pos+3:pos+8] = seed[9:14]
        state[pos+limit+1] = x0
    state[-2:] = state[12:14]
    args = (count,limit,polar,species,nth,flag,params,nodes,weights,table)
    state[2] = fork.same_readout(state,args,x0)[35]
    return state,args,x0,cfg,const,[thermal_path,bg_path,cpath]


def derived(values,wave,const):
    get = lambda key: values[:,fork.KEYS.index(key)]
    ratio = wave/5
    scale = get('a')
    hub = get('H')*ratio
    cdm,baryon,photon,nu,massive = (const[idx]/scale**power for idx,power in [(0,1),(1,1),(2,2),(3,2),(14,2)])
    drho = (get('mts_drho_s')+get('mts_drho_h'))*ratio**2
    field_flux = (get('mts_q_h')+get('mts_q_s'))*ratio**2
    dens = drho+cdm*get('delta_cdm')+baryon*get('delta_baryon')+photon*get('delta_photon')+nu*get('delta_neutrino')+massive*get('massive_bg_ratio')*get('delta_nu')
    flux = field_flux+baryon*get('v_baryon_cdm')+photon*get('v_photon')+nu*get('v_neutrino')+massive*get('massive_flux_moment')
    stress = photon*get('pi_photon')+nu*get('massless_shear')+massive*get('massive_shear_moment')
    lens = -(dens+3*hub*flux/wave+stress)/2
    com = lambda field: ratio**2*(get('mts_drho_'+field)+3*hub*get('mts_q_'+field)/wave)
    return np.column_stack((scale,hub,get('delta_cdm'),ratio*get('etak'),com('h'),ratio**2*get('mts_dp_h'),
        get('mts_dphi_h'),ratio*get('mts_dphidot_h'),ratio**2*get('mts_q_h'),ratio**2*get('mts_dp_s'),com('s'),
        lens,dens,flux,stress,get('active_cdm_x'),get('trace_constraint')))


def run(label,case,scheme):
    check()
    _,path,target = CASES[label]
    with np.load(path) as packet:
        wave = packet['modes'][selector(packet,target)]
        epochs = packet['conformal_time'][START:END+1].copy()
    control = wave==5
    state,args,x0,cfg,const,sources = model(case,wave,scheme)
    rate = max(cfg['masses'])
    count,limit,angle,flag,switch,start_factor = SCHEMES[scheme]
    anchor = POST/'mts-neutrino-switch-20261118'/(case+'-main-fork.npz')
    if control:
        with np.load(anchor) as packet:
            readouts = packet['x']/5
        final = readouts[-1]
    else:
        final = epochs[-1]+.06
        readouts = np.r_[np.geomspace(.001,epochs[0],480),epochs,np.linspace(epochs[0]-.08,final,1701)]
    breaks = np.unique(np.r_[x0, np.geomspace(.001*wave,final*wave,42),final*wave,
                              [52.] if wave*final>=52 else []])
    clocks = np.unique(np.r_[breaks,wave*readouts])
    result = np.zeros((len(clocks),len(fork.KEYS)))
    nsteps = 0
    for left,right in zip(breaks[:-1],breaks[1:]):
        check()
        first,last = np.searchsorted(clocks,[left,right])
        xs = clocks[first:last+1]
        cap = min(.04,angle/np.hypot(1,3e-6*(right/wave)*rate/wave))
        arguments = (*args[:5],flag+(switch if left>=52 else 0),*args[6:])
        values = np.zeros((len(xs),len(fork.KEYS)))
        steps = c_longlong()
        status = ADDITIVE(*arguments,state,xs,len(xs),cap,values,byref(steps))
        if status!=1 or not np.isfinite(values).all() or not np.isfinite(state).all():
            raise RuntimeError((label,case,scheme,left,right,status,steps.value))
        result[first:last+1] = values
        nsteps += steps.value
    data = derived(result,wave,const)
    name = 'early-'+label+'-'+case+'-'+scheme
    freeze(name,dict(wave=wave,clock=clocks/wave,values=data,names=COLS,terminal=state,
           const=const,epoch_rows=np.searchsorted(clocks,wave*epochs) if not control else np.array([],int)),
           [*sources,path,SWITCH/'switch.dll',SWITCH/'switch.c',HERE/'primordial.py',HERE/'conditional.py',
            POST/'mts-native-seed-origin-20261117/first_output.py',POST/'mts-native-seed-origin-20261117/mode_check.py'],
           dict(scheme=SCHEMES[scheme],steps=nsteps,regular_tau=x0/wave,wave=float(wave),last_tau=final,
                adiabatic_origin=args[6][8:8+args[3]].tolist(),no_late_metric_inputs=True))
    print('frozen',name,nsteps,flush=True)


if __name__=='__main__':
    for scheme in sys.argv[1:]:
        for label in (['cold5','heavy5','low','high'] if scheme=='primary' else ['low','high']):
            for case in ([CASES[label][0]] if label.endswith('5') else ['cold','heavy']):
                run(label,case,scheme)
