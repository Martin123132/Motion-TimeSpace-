import primordial as forward


if __name__=='__main__':
    forward.ADDITIVE = forward.fork.LIB
    forward.SCHEMES['implicit'] = forward.SCHEMES['primary']
    original = forward.freeze
    forward.freeze = lambda name,data,paths,info: original(name,data,[*paths,forward.HERE/'implicit_control.py'],
                                                            dict(info,method='propagate2 fully coupled SDIRK'))
    for label in ['low','high']:
        for case in ['cold','heavy']:
            forward.run(label,case,'implicit')
