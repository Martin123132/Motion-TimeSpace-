from ctypes import CDLL,byref,c_longlong,c_int
from study import *
from fork import same_readout,data


def build():
    guard()
    source=(PREVIOUS/'switch.c').read_text()
    prefix,body=source.split('#undef propagate')
    marker='coord+=step;(*steps)++;'
    need(body.count(marker)==1,'only observe accepted steps')
    code=prefix+'#undef propagate\n#include "observer.inc"\n'+body.replace(marker,marker+'double samples[OBS];Local cache;if(!evaluate(&model,coord,state,NULL,&cache,samples)||!append_source(coord,samples)){status=-9;goto finish;}')
    code=code.replace('#include "branches.inc"','#include "../mts-neutrino-switch-20261118/branches.inc"')
    with (ROOT/'observed.c').open('x') as out:
        out.write(code)


def replay(case):
    guard()
    _,state,args,_,_=data(case,'fine')
    library=CDLL(str(ROOT/'observed.dll'))
    library.propagate2.argtypes=bridge.SOLVE.argtypes
    library.propagate2.restype=bridge.SOLVE.restype
    library.set_buffer.argtypes=[bridge.PTR,c_int]
    library.set_buffer.restype=None
    for arm in ('fork','both'):
        path=PREVIOUS/(case+'-fine-'+arm+'.npz')
        receipt=read(path.with_suffix('.json'))
        need(digest(path)==receipt['packet'],'saved source run')
        with np.load(path) as pack:
            clocks=pack['x'].copy()
            expected=pack['forecast'].copy()
            final=pack['state' if arm=='fork' else 'terminal'].copy()
        if arm=='fork':
            state[2]=same_readout(state,args,clocks[0])[35]
        else:
            args=(*args[:5],args[5]+12,*args[6:])
        buff=np.empty((receipt['steps'],6))
        library.set_buffer(buff.ravel(),len(buff))
        cuts=np.unique(np.r_[0,np.arange(96,len(clocks),96),len(clocks)-1])
        count=0
        for left,right in zip(cuts[:-1],cuts[1:]):
            guard()
            times=clocks[left:right+1]
            rows=np.zeros((len(times),len(KEYS)))
            steps=c_longlong()
            need(library.propagate2(*args,state,times,len(times),.0025,rows,byref(steps))==1,'passive replay')
            start=int(left>0)
            need(np.array_equal(rows[start:],expected[left+start:right+1]),'no saved output changes')
            count+=steps.value
        need(library.get_count()==count==len(buff) and np.array_equal(state,final),'same grid and full terminal state')
        names=['a','H','active_cdm_x','physical_velocity','archived_velocity']
        initial=np.r_[clocks[0],expected[0,[KEYS.index(name) for name in names]]]
        dest=ROOT/(case+'-'+arm+'-dense.npz')
        values=np.vstack([initial,buff])
        need(np.all(np.diff(values[:,0])>0) and np.isfinite(values).all(),'bounded time increments')
        with dest.open('xb') as out:
            np.savez_compressed(out,values=values,names=['x']+names)
        save(dest.with_suffix('.json'),dict(packet=digest(dest),original=digest(path),mode=arm,script=digest(Path(__file__)),method=digest(ROOT/'PAIRED-SOURCE.md'),
              binary=digest(ROOT/'observed.dll'),source=digest(ROOT/'observed.c'),steps=count,output_rows=len(expected),readouts_bit_identical=True,final_bit_identical=True))
        print(case,arm,count,flush=True)


if __name__=='__main__':
    build() if sys.argv[1]=='build' else replay(sys.argv[1])
