from study import *
from paired import load_dense


def quad(clocks,values,idx,kind):
    spline=kind(clocks,values)
    width=np.diff(clocks)[:,None]
    c3,c2,c1,c0=spline.c
    integral=width*(c0+width*(c1/2+width*(c2/3+width*c3/4)))
    return np.add.reduceat(integral,idx[:-1],axis=0)


def run(case):
    guard()
    raw=load_dense(case)
    clocks,scale,hub,cdm,uphys,uarch=raw.T
    times,native_,_,_,_,_,config,_=native(case)
    points=np.searchsorted(clocks,times)
    mass=config['masses'][0]
    spring=(mass*scale/5)**2
    omega=np.sqrt(1+spring)
    force=(uphys-uarch)*cdm/5
    with np.load(ROOT/(case+'-paired.npz')) as data:
        displacement,speed=data['integrated_pair'].T.copy()
        need(np.array_equal(data['accepted_x'],clocks),'paired work on common clocks')
        observed=data['observed_pair'].copy()
    switched=trajectory(case,'fine',times)
    original=PREVIOUS/(case+'-fine-both.npz')
    matched=[]
    for arm in ('fork','both'):
        with np.load(PREVIOUS/(case+'-fine-'+arm+'.npz')) as pack:
            rr=pack['forecast'][:,KEYS.index('physical_phi')]
            matched.append((pack['x'].copy(),rr.copy()))
    timeline=np.r_[matched[0][0],matched[1][0][1:]]
    phi=np.r_[matched[0][1],matched[1][1][1:]][np.searchsorted(timeline,times)]
    values=np.array([speed*force,2*hub/5*speed**2,hub/5*spring*displacement**2,abs(force)/omega]).T
    by_method={}
    for stride in (1,2,4):
        used=np.unique(np.r_[points,np.arange(0,len(clocks),stride)])
        for name,cls in [('cubic',CubicSpline),('pchip',PchipInterpolator)]:
            by_method[name+str(stride)]=quad(clocks[used],values[used],np.searchsorted(clocks[used],times),cls)
    best=by_method['cubic1']
    net=best[:,0]-best[:,1]+best[:,2]
    actual=.5*(observed[:,1]**2+omega[points]**2*observed[:,0]**2)
    need(actual[0]==0 and (best[:,1]>=0).all() and (best[:,2]>=0).all(),'zero start and nonnegative expansion terms')
    def signed(values):
        return values[:,0]-values[:,1]+values[:,2]
    cumulative=np.cumsum(net)
    variations=np.max([abs(np.cumsum(signed(rows))-cumulative) for rows in by_method.values()],axis=0)
    local_unc=np.max([abs(signed(rows)-net) for rows in by_method.values()],axis=0)
    errors=abs(cumulative-actual[1:])
    passed=errors+variations<=TOL*actual[1:]
    local=abs(np.diff(actual)-net)+local_unc<=TOL*abs(np.diff(actual))
    velocity_weight=5*uphys[points]
    position_weight=(scale[points]*mass)**2*phi
    pressure=velocity_weight*observed[:,1]-position_weight*observed[:,0]
    response_norm=np.hypot(position_weight,velocity_weight*omega[points])
    envelope=response_norm[1:]*np.cumsum(best[:,3])
    env_sensitivity=response_norm[1:]*np.max([abs(np.cumsum(values[:,3]-best[:,3])) for values in by_method.values()],axis=0)
    nonzero=abs(pressure[1:])>0
    info=dict(closure_epochs=int(sum(passed)),local_increments=int(sum(local)),epochs=len(passed),work=best[:,0].sum(),damping=best[:,1].sum(),
              changing_mass=best[:,2].sum(),final_Q=actual[-1],final_net=cumulative[-1],final_error_over_Q=errors[-1]/actual[-1],
              final_quadrature_spread_over_Q=variations[-1]/actual[-1],final_work_gate=bool(passed[-1]),
              sign_safe_dissipation=bool(np.all(best[:,1]>=0)),final_fixed_weight_pressure=pressure[-1],final_bound=envelope[-1],
              final_bound_to_abs_pressure=envelope[-1]/abs(pressure[-1]),enclosed_samples=int(np.sum(abs(pressure[1:])<=envelope+env_sensitivity)),
              resolved_nonzero_pressure_rows=int(nonzero.sum()))
    dest=ROOT/(case+'-work.npz')
    with dest.open('xb') as packet:
        np.savez_compressed(packet,x=times,Q=actual,pressure=pressure,envelope=envelope,envelope_sensitivity=env_sensitivity,closure_spread=variations,**by_method)
    save(dest.with_suffix('.json'),dict(packet=digest(dest),method=digest(ROOT/'SCALAR-WORK.md'),source=digest(Path(__file__)),tolerance=TOL,results=info))


if __name__=='__main__':
    for case in ('cold','heavy'):
        run(case)
