from datetime import datetime,timezone
import hashlib
from study import *


def matches(values,expected,name):
    need(np.allclose(values,expected,rtol=2e-12,atol=1e-280),name)


def verify():
    guard()
    prior=read(PREVIOUS/'closeout.json')['files']
    for key,info in prior.items():
        path=PREVIOUS/key
        need(path.stat().st_size==info['bytes'] and digest(path)==info['sha256'],'preserve previous work: '+key)
    variant_hash=hashlib.sha256((ROOT/'multiscale.py').read_bytes().replace(b'knot_subset',b'subset')).hexdigest()
    need(variant_hash=='d2fa8451504e7dc3e206d2b9a9a6623a4e3fbfce5abd2a19c1903a17d3b51302','preserve original output-naming variant source identity')
    methods={digest(path) for path in ROOT.glob('*.md')}
    scripts={digest(path) for path in ROOT.glob('*.py')}|{variant_hash}
    audited=[]
    for path in sorted(ROOT.glob('*.npz')):
        rec=read(path.with_suffix('.json'))
        need(digest(path)==rec['packet'] and rec['method'] in methods and (rec.get('script') in scripts or rec.get('source') in scripts),'packet and method: '+path.name)
        with np.load(path) as data:
            for key in data.files:
                if data[key].dtype.kind in 'fiu':
                    need(np.isfinite(data[key]).all(),'finite data: '+path.name+' '+key)
        audited.append(path.name)
    timeline={}
    multiscale={}
    for case in ('cold','heavy'):
        times,ref,drive,component,bound,velocity,config,source=native(case)
        primary=ROOT/(case+'-retarded.npz')
        with np.load(primary) as packet,np.load(ROOT/(case+'-paired.npz')) as pair,np.load(ROOT/(case+'-work.npz')) as work:
            need(np.array_equal(packet['growth_drive'],drive) and np.array_equal(packet['component_drive'],component),'independent growth rerun')
            rows=packet['windows']
            obs=packet['fine_crossed_preferred_observed']
            actual=packet['fine_crossed_actual']
            matches(obs.sum(0)+packet['fine_crossed_preferred_initial'],actual,'closed endpoint innovation sum')
            parts=pair['cubic1']
            physical=packet['fine_physical_actual']
            observed=pair['observed_pair'][-1]
            need(np.all(abs(observed-(physical-actual))<=64*np.finfo(float).eps*np.max(abs(packet['native_state']),axis=0)),'matched physical/archived gap partition')
            per_case={}
            for branch in BRANCHES:
                marked=packet['fine_'+branch+'_preferred_observed']
                base=packet['main_'+branch+'_preferred_observed']
                spread=sum(abs(packet[tag+'_'+branch+'_preferred_observed']-base) for tag in ('fine','highq','trace','angular'))
                spread+=sum(abs(packet['fine_'+branch+'_'+method+'_observed']-marked) for method in ('step','linear','pchip'))
                gap=packet['fine_'+branch+'_actual']
                per_case[branch]=dict(shares=(marked/gap).tolist(),window_spread_on_endpoint_scale=(spread/abs(gap)).tolist())
            model_unc=sum(abs((packet[tag+'_physical_actual']-packet[tag+'_crossed_actual'])-
                              (packet['main_physical_actual']-packet['main_crossed_actual'])) for tag in ('fine','angular','trace','highq'))
            paused=read(ROOT/(case+'-paired.json'))['cases']
            fine_prediction=parts.sum(0)
            per_case['paired']={}
            for key,target in [('same_metric_pair',observed),('full_physical_minus_native',physical)]:
                limited=np.array(paused[key]['sampling_and_solver_over_actual'])*abs(target)+model_unc
                per_case['paired'][key]=dict(relative_error=(fine_prediction/target-1).tolist(),full_spread=(limited/abs(target)).tolist(),
                                             passes=((abs(fine_prediction-target)+limited)<=TOL*abs(target)).tolist())
            det=packet['crossed_det']
            hcurve=CubicSpline(times,packet['medium'][:,0]).antiderivative()
            analytic=np.exp(-2*np.diff(hcurve(times)))
            per_case['liouville']=dict(determinant_relative=max(abs(det/analytic-1)),scale_ratio_relative=max(abs(det/(ref['a'][:-1]/ref['a'][1:])**2-1)))
            need(per_case['liouville']['determinant_relative']<=TOL,'Wronskian normalization')
            saved=read(ROOT/(case+'-work.json'))['results']
            net=work['cubic1'][:,0]-work['cubic1'][:,1]+work['cubic1'][:,2]
            matches(np.cumsum(net)[-1],saved['final_net'],'signed supplied-work sum')
            per_case['work']=saved
            per_case['windows']=rows.tolist()
            per_case['physical_force_shares']=(parts/fine_prediction).tolist()
            receipt=read(ROOT/(case+'-common-force.json'))['results']['witness']
            need(receipt['passes'] and max(abs(np.array(receipt['normalized_constraint_errors'])))<=TOL,'off-grid ambiguity witness')
            per_case['witness']=receipt
            per_case['growth']=source['checks']
            timeline[case]=per_case
        populations={}
        paths=[ROOT/(case+'-multiscale.npz')]
        if case=='heavy':
            paths+=[ROOT/(case+'-'+str(wave)+'-multiscale.npz') for wave in [.03,.1,1.]]
        expected_modes=[.03,.1,1.,5.]
        for population in ('shared','additional'):
            totals={}
            selected=[]
            for path in paths:
                receipt=read(path.with_suffix('.json'))
                with np.load(path) as pack:
                    pick=np.isin(pack['modes'],expected_modes)
                    if population=='additional':
                        pick=~pick
                    selected+=pack['modes'][pick].tolist()
                    for label,sign in [('dense',True),('sparse',False)]:
                        ids=np.flatnonzero(pack['dense']==sign)+1
                        for field in receipt['fields']:
                            truth=pack[field+'_target'][ids]
                            predicted=pack[field+'_prediction'][ids]
                            spread=pack[field+'_uncertainty'][ids]
                            bounded=pack[field+'_input_bound'][ids]
                            need((spread>=bounded).all() and (bounded>=0).all(),'absolute precision budget')
                            successes=(abs(truth-predicted)+spread<=TOL*abs(truth))
                            need(np.array_equal(successes.sum(axis=(0,1)),receipt['fields'][field]['windows'][label]['passes_by_coordinate']),'independent per-row/model recomputation')
                            key=field+'_'+label
                            counted=totals.setdefault(key,np.zeros(5,dtype=int))
                            counted[0]+=len(ids)*sum(pick)
                            counted[1:4]+=successes[:,pick].sum(axis=(0,1))
                            counted[4]+=np.sum(abs(pack[field+'_zero'][ids][:,pick,2]-truth[:,pick,2])<=TOL*abs(truth[:,pick,2]))
            if population=='shared':
                need(sorted(selected)==expected_modes,'identical baseline/MTS modes, no duplicates')
            else:
                need(len(selected)==(15 if case=='heavy' else 0),'additional modes disjoint')
            populations[population]=dict(modes=sorted(selected),columns=['scored','displacement_pass','velocity_pass','pressure_pass','source_free_pressure_nominal'],rows={key:v.tolist() for key,v in totals.items()})
        multiscale[case]=populations
    source_dir=ROOT.parent/'mts-integrated-defect-20261112/native/fortran'
    code={k:digest(source_dir/k) for k in ('camb_python.f90','equations.f90','MTSTwoField.f90')}
    save(ROOT/'verification.json',dict(utc=datetime.now(timezone.utc).isoformat(),older_manifest=SEAL,prior_rehashed=len(prior),
         packets=audited,fortran=code,tolerance=TOL,timing=timeline,multiscale=multiscale,script=digest(Path(__file__))))


if __name__=='__main__':
    verify()
