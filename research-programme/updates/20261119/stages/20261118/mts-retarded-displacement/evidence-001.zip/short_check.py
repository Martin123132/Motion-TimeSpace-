from ctypes import CDLL,byref,c_longlong,c_int
from study import *
from fork import same_readout,data


def build():
    guard()
    source=(PREVIOUS/'switch.c').read_text()
    prefix,body=source.split('#undef propagate')
    marker='memcpy(slope+stage*size,freepart,(size_t)size*sizeof(double));'
    need(body.count(marker)==1,'one converged stage per internal sample')
    dump='double samples[OBS];Local cache;if(!evaluate(&model,timepoint,trial,NULL,&cache,samples)||!append_short(coord,step,stage,samples,trial,freepart,size,par)){status=-9;goto finish;}'
    code=prefix+'#undef propagate\n#include "short_buffer.inc"\n'+body.replace(marker,dump+marker)
    with (ROOT/'early_observed.c').open('x') as out:
        out.write(code.replace('#include "branches.inc"','#include "../mts-neutrino-switch-20261118/branches.inc"'))


def run(case):
    guard()
    _,seed,args,_,_=data(case,'fine')
    times,_,_,_,_,_,config,_=native(case)
    clocks=times[:9]
    mass=config['masses'][0]
    seed[2]=same_readout(seed,args,clocks[0])[35]
    weights=np.array([82889/524892,0,15625/83664,69875/102672,-2260/8211,.25])
    need(abs(weights.sum()-1)<2e-15,'consistent signed RK weights')
    lib=CDLL(str(ROOT/'early_observed.dll'))
    lib.propagate2.argtypes=bridge.SOLVE.argtypes
    lib.propagate2.restype=bridge.SOLVE.restype
    lib.set_short.argtypes=[bridge.PTR,c_int]
    lib.set_short.restype=None
    arrays={}
    report=[]
    previous=None
    with np.load(PREVIOUS/(case+'-fine-fork.npz')) as packet:
        baseline=packet['forecast'][:len(clocks)].copy()
    def col(rows,key):
        return rows[:,KEYS.index(key)]
    for level in range(9):
        guard()
        cap=.0025/(2**level)
        state=seed.copy()
        buff=np.empty((6*(len(clocks)*2+int(np.ceil((clocks[-1]-clocks[0])/cap))),11))
        lib.set_short(buff.ravel(),len(buff))
        out=np.zeros((len(clocks),len(KEYS)))
        count=c_longlong()
        need(lib.propagate2(*args,state,clocks,len(clocks),cap,out,byref(count))==1 and lib.get_short()==count.value*6,'complete six-stage record')
        if level==0:
            need(np.array_equal(out,baseline),'exact replay of original eight intervals')
        samples=buff[:6*count.value].reshape(-1,6,11)
        need(np.array_equal(samples[:,:,2],np.tile(np.arange(6),(count.value,1))),'correct order of internal stages')
        dt=samples[:,0,1]
        scale=samples[:,:,3]
        hh=samples[:,:,4]/5
        force=(samples[:,:,6]-samples[:,:,7])*samples[:,:,5]/5
        u=samples[:,:,8]
        v=samples[:,:,9]
        total=force-2*hh*v-(1+(scale*mass/5)**2)*u
        left=samples[:,0,0]
        bins=np.searchsorted(clocks[1:],left,side='right')
        need(np.array_equal(np.unique(bins),np.arange(8)),'no double counted boundary')
        def sum_cells(value):
            return np.bincount(bins,weights=dt*value,minlength=8)
        net=sum_cells(total@weights)
        observed=np.column_stack([col(out,'mts_dphi_s')-col(out,'shadow_dphi'),(col(out,'mts_dphidot_s')-col(out,'shadow_dphidot'))/5])
        pres_weight=(col(out,'a')*mass)**2*col(out,'physical_phi')
        vel_weight=5*col(out,'physical_velocity')
        pressure=vel_weight*observed[:,1]-pres_weight*observed[:,0]
        ownulp=.5*(abs(pres_weight)*(abs(np.spacing(col(out,'mts_dphi_s')))+abs(np.spacing(col(out,'shadow_dphi'))))+
                     abs(vel_weight/5)*(abs(np.spacing(col(out,'mts_dphidot_s')))+abs(np.spacing(col(out,'shadow_dphidot')))))
        gamma=np.hypot(vel_weight*np.sqrt(1+(col(out,'a')*mass/5)**2),pres_weight)
        omega=np.sqrt(1+(scale*mass/5)**2)
        endpoints=.5*(abs(force[:,0])/omega[:,0]+abs(force[:,-1])/omega[:,-1])
        bound=gamma[1:]*np.cumsum(sum_cells(endpoints))
        internal=gamma[1:]*np.cumsum(sum_cells(np.max(abs(force)/omega,axis=1)))
        sampled=sum_cells((force[:,0]+force[:,-1])*.5)
        applied=sum_cells(force@weights)
        saved_scale=max(abs(np.diff(observed[:,1])))
        report.append(dict(level=level,steps=count.value,cap=cap,comparisons=len(bins),early_enclosed=int(sum(abs(pressure[1:])<=bound)),
           sampled_inner_range_enclosed=int(sum(abs(pressure[1:])<=internal)),signed_increment_replay_over_peak=max(abs(net-np.diff(observed[:,1])))/saved_scale,
           direct_rhs_replay_over_peak=max(abs(sum_cells(samples[:,:,10]@weights)-np.diff(observed[:,1])))/saved_scale,
           stage_minus_endpoint_force_over_peak=max(abs(sampled-applied))/saved_scale,pressure_refinement_over_peak=(None if previous is None else max(abs(pressure-previous))/max(abs(pressure))),
           last_pressure=pressure[-1],early_excess_over_final_storage_ulp=max((abs(pressure[1:])-bound)/ownulp[1:])))
        arrays['level'+str(level)]=np.column_stack([pressure[1:],bound,internal,net,sampled,applied,ownulp[1:]])
        previous=pressure
    dest=ROOT/(case+'-short.npz')
    with dest.open('xb') as handle:
        np.savez_compressed(handle,x=clocks,**arrays)
    save(dest.with_suffix('.json'),dict(packet=digest(dest),method=digest(ROOT/'EARLY-STAGES.md'),script=digest(Path(__file__)),binary=digest(ROOT/'early_observed.dll'),
        include=digest(ROOT/'short_buffer.inc'),original=digest(PREVIOUS/(case+'-fine-fork.npz')),tolerance=TOL,records=report))


if __name__=='__main__':
    build() if sys.argv[1]=='build' else run(sys.argv[1])
