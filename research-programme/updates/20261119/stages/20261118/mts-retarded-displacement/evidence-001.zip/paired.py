from study import *
from scipy.integrate import solve_ivp


def load_dense(case):
    chunks=[]
    for arm in ('fork','both'):
        path=ROOT/(case+'-'+arm+'-dense.npz')
        receipt=read(path.with_suffix('.json'))
        need(receipt['packet']==digest(path) and receipt['readouts_bit_identical'] and receipt['final_bit_identical'],'exact observed replay')
        with np.load(path) as pack:
            chunks.append(pack['values'].copy())
    need(np.array_equal(chunks[0][-1],chunks[1][0]),'source continuity at switch')
    return np.vstack([chunks[0],chunks[1][1:]])


def adjoint(x,scale,hub,mass,step):
    medium=CubicSpline(x,np.column_stack([hub/5,(scale*mass/5)**2]))
    def derivative(clock,values):
        damping,alpha=medium(clock)
        rows=values.reshape(2,2)
        return np.column_stack([(1+alpha)*rows[:,1],-rows[:,0]+2*damping*rows[:,1]]).ravel()
    sol=solve_ivp(derivative,(x[-1],x[0]),np.eye(2).ravel(),method='DOP853',rtol=4e-13,atol=3e-15,max_step=step,t_eval=x[::-1])
    need(sol.success,'retarded metric response')
    return sol.y.T[::-1].reshape(-1,2,2)


def run(case):
    guard()
    raw=load_dense(case)
    clocks,ref,_,_,_,_,cfg,_=native(case)
    switched=trajectory(case,'fine',clocks)
    pos=np.searchsorted(raw[:,0],clocks)
    need(np.array_equal(raw[pos,0],clocks),'dense original epochs')
    ranges=windows(clocks)
    start=pos[[left for left,_ in ranges]]
    stop=pos[[right for _,right in ranges]]
    mass=cfg['masses'][0]
    x,scale,hub,drive,physical,archived=raw.T
    force=(physical-archived)*drive/5
    seed_arch=np.array([switched['shadow_dphi'][0],switched['shadow_dphidot'][0]/5])
    seed_phys=np.array([switched['mts_dphi_s'][0],switched['mts_dphidot_s'][0]/5])
    seed=seed_phys-seed_arch
    need(np.array_equal(seed,np.zeros(2)),'paired perturbations start equal')
    obs=np.column_stack([switched['mts_dphi_s']-switched['shadow_dphi'],(switched['mts_dphidot_s']-switched['shadow_dphidot'])/5])
    original=np.column_stack([switched['mts_dphi_s']-ref['mts_dphi_s'],(switched['mts_dphidot_s']-ref['mts_dphidot_s'])/5])
    outputs={}
    groups={}
    for stride,cap in [(1,.12),(2,.20),(4,.20)]:
        indices=np.unique(np.r_[np.arange(0,len(x),stride),pos])
        xs=x[indices]
        ad=adjoint(xs,scale[indices],hub[indices],mass,cap)
        projections=ad[:,:,1]*force[indices,None]
        for name,cls in [('cubic',CubicSpline),('pchip',PchipInterpolator)]:
            interp=cls(xs,projections).antiderivative()
            parts=interp(x[stop])-interp(x[start])
            groups[name+str(stride)]=parts
            outputs[name+str(stride)]=ad[0]@seed+parts.sum(0)
    indices=np.arange(len(x))
    matrix=matrices(x,np.column_stack([hub/5,(scale*mass/5)**2,archived*drive/5,force,-force,np.zeros_like(force)]),'cubic',.0125)
    states=np.zeros((len(x),2,4))
    states[0,:,0]=seed_arch
    states[0,:,1]=seed
    for idx,cell in enumerate(matrix):
        states[idx+1]=cell[:,:2]@states[idx]+cell[:,2:]
    need(not np.any(states[:,:,3]) and np.array_equal(states[:,:,1],-states[:,:,2]),'independent forward zero and opposite forcings')
    forecast=outputs['cubic1']
    expected=obs[-1]
    signed=original[-1]
    errors={}
    for name,target in [('same_metric_pair',expected),('full_physical_minus_native',signed)]:
        numerical=sum(np.max([abs(outputs[tag]-forecast) for tag in tags],axis=0) for tags in [('cubic2','cubic4'),('pchip1','pchip2','pchip4')])+abs(states[-1,:,1]-forecast)
        errors[name]=dict(actual=target.tolist(),forecast=forecast.tolist(),signed_error_over_actual=(forecast/target-1).tolist(),
              sampling_and_solver_over_actual=(numerical/abs(target)).tolist(),passes=((abs(forecast-target)+numerical)<=TOL*abs(target)).tolist())
    dest=ROOT/(case+'-paired.npz')
    with dest.open('xb') as packet:
        np.savez_compressed(packet,x=clocks,accepted_x=x,integrated_archive=states[:,:,0],integrated_pair=states[:,:,1],observed_pair=obs,physical_minus_native=original,
                            windows=ranges,**groups)
    save(dest.with_suffix('.json'),dict(packet=digest(dest),method=digest(ROOT/'PAIRED-SOURCE.md'),script=digest(Path(__file__)),tolerance=TOL,
          source_rows=len(x),seed=seed.tolist(),zero_and_reversal_pass=True,cases=errors,
          archive_absolute_replay_over_peak=(np.max(abs(states[pos,:,0]-np.column_stack([switched['shadow_dphi'],switched['shadow_dphidot']/5])),0)/
           np.max(abs(np.column_stack([switched['shadow_dphi'],switched['shadow_dphidot']/5])),0)).tolist()))


if __name__=='__main__':
    run(sys.argv[1])
