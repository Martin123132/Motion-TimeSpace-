from study import *
from paired import load_dense,adjoint
from scipy.integrate import solve_ivp


def measure(case,panels):
    times,n,_,_,_,vs,cfg,_=native(case)
    idx=int(np.argmax(np.diff(times)))
    lo,hi=times[idx:idx+2]
    raw=load_dense(case)
    whole=raw[:,0]
    slot=np.searchsorted(whole,times)
    xb=whole[whole>=lo]
    an=raw[-len(xb):,1]+PchipInterpolator(times,n['a']-raw[slot,1])(xb)
    hn=raw[-len(xb):,2]+PchipInterpolator(times,n['H']-raw[slot,2])(xb)
    aval=CubicSpline(xb,an)
    hub=CubicSpline(xb,hn/5)
    dual_s=adjoint(xb,an,hn,cfg['masses'][0],.06)
    fs=CubicSpline(xb,dual_s)
    if case=='heavy':
        dual_h=adjoint(xb,an,hn,cfg['masses'][1],.04)
        fh=CubicSpline(xb,dual_h)
        inv=np.linalg.inv(fh(hi))
        with np.load(COMMON/'native-two-field-transfer-20261007/runs/backgrounds/heavy.npz') as cols:
            vh=CubicSpline(cols['heavy_efold'],cols['phidot_h'],bc_type='natural')
    nodes=np.linspace(lo,hi,panels+1)
    scale=aval(nodes)
    primitive=hub.antiderivative()
    mult=np.exp(primitive(nodes)-primitive(lo))
    kernels=[fs(nodes)[:,0,1]*vs(np.log(scale))/5,np.ones(len(nodes))]
    if case=='heavy':
        kernels+=list((inv@fh(nodes)[:,:,1].T)*vh(np.log(scale))/5)
    integrand=CubicSpline(nodes,np.array(kernels).T/mult[:,None]).antiderivative()
    alltr=(integrand(hi)-integrand(nodes))*mult[:,None]
    traces=CubicSpline(nodes,np.column_stack([alltr[:,0],mult/mult[-1],alltr[:,1:]]))
    roots,weights=np.polynomial.legendre.leggauss(6)
    widths=np.diff(nodes)
    xx=(nodes[:-1,None]+.5*widths[:,None]*(1+roots)).ravel()
    ww=(.5*widths[:,None]*weights).ravel()
    values=traces(xx).T
    scaled=values[1:]*np.sqrt(ww)
    norms=np.linalg.norm(scaled,axis=1)
    ortho,singular,span=np.linalg.svd(scaled/norms[:,None],full_matrices=False)
    need(singular[-1]>1e-8*singular[0],'independent normalized constraints')
    projection=(((values[0]*np.sqrt(ww))@span.T)/singular)@ortho.T/norms
    smooth=traces(nodes)
    remainder=CubicSpline(nodes,smooth[:,0]-smooth[:,1:]@projection)
    strength=np.linalg.norm(remainder(xx)*np.sqrt(ww))
    unconstrained=np.linalg.norm(values[0]*np.sqrt(ww))
    need(strength>0 and strength<=unconstrained,'nonempty unresolved trace direction')
    wave=cfg['masses'][0]
    size=6 if case=='heavy' else 4
    def rhs(clock,state,driven):
        a=aval(clock)
        h=hub(clock)
        forcing=remainder(clock)/strength if driven else 0.
        rate=state[0]
        out=[forcing-h*rate,rate,state[3],-2*h*state[3]-(1+(a*wave/5)**2)*state[2]+vs(np.log(a))*rate/5]
        if case=='heavy':
            out+=[state[5],-2*h*state[5]-(1+(a*cfg['masses'][1]/5)**2)*state[4]+vh(np.log(a))*rate/5]
        return out
    sol=solve_ivp(lambda clock,s:rhs(clock,s,True),(lo,hi),np.zeros(size),method='DOP853',rtol=3e-13,
        atol=[2e-15,2e-15,4e-29,4e-29]+([2e-19,2e-19] if size==6 else []),max_step=(hi-lo)/200)
    need(sol.success,'independent trace evolution')
    end=sol.y[:,-1]
    weights_abs=np.sum(abs(values[1:]*remainder(xx)/strength)*ww,axis=1)
    constraint=np.r_[end[:2],end[4:]]/weights_abs
    def tail(clock,y):
        return (y[1],-2*hub(clock)*y[1]-(1+(aval(clock)*wave/5)**2)*y[0])
    terminal=solve_ivp(tail,(hi,xb[-1]),end[2:4],method='DOP853',rtol=3e-13,atol=3e-29,max_step=.04)
    need(terminal.success,'independent retarded tail')
    got=terminal.y[0,-1]
    with np.load(ROOT/(case+'-retarded.npz')) as data:
        amplitudes={key:abs(data['fine_'+key+'_actual'][0]) for key in BRANCHES}
    amplitudes['native_displacement']=abs(n['mts_dphi_s'][-1])
    return dict(interval=[idx,idx+1],x=[lo,hi],l2_gain=strength,without_constraints=unconstrained,retained_fraction=strength/unconstrained,
         critical_rms_for_TOL={label:TOL*target/(np.sqrt(hi-lo)*strength) for label,target in amplitudes.items()},
         forward_gain=got,forward_relative=got/strength-1,normalized_constraint_residuals=constraint.tolist(),
         passes=bool(abs(got/strength-1)+max(abs(constraint))<=TOL))


if __name__=='__main__':
    guard()
    case=sys.argv[1]
    coarse=measure(case,256)
    fine=measure(case,512)
    sensitivity=abs(coarse['l2_gain']/fine['l2_gain']-1)
    save(ROOT/(case+'-trace-bound.json'),dict(coarse=coarse,fine=fine,refinement=sensitivity,
         verified=bool(fine['passes'] and coarse['passes'] and sensitivity<=TOL),method=digest(ROOT/'TRACE-BOUND.md'),script=digest(Path(__file__)),tolerance=TOL))
