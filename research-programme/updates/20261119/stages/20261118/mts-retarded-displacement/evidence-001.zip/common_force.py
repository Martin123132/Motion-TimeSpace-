from study import *
from paired import adjoint,load_dense
from factored import interpolator


def experiment(case,spacing,order,kind,want_witness):
    times,ref,drive,_,_,slow_vel,cfg,_=native(case)
    data=load_dense(case)
    x,scale,expansion,cdm=data[:,:4].T
    positions=np.searchsorted(x,times)
    an=scale+PchipInterpolator(times,ref['a']-scale[positions])(x)
    hn=expansion+PchipInterpolator(times,ref['H']-expansion[positions])(x)
    background=CubicSpline(x,an)
    raw=CubicSpline(x,cdm)
    offset=interpolator(times,cdm[positions]-drive,kind)
    masses=cfg['masses']
    fields=['s','h'] if case=='heavy' else ['s']
    velocity=[slow_vel]
    if case=='heavy':
        path=COMMON/'native-two-field-transfer-20261007/runs/backgrounds/heavy.npz'
        with np.load(path) as pack:
            velocity.append(CubicSpline(pack['heavy_efold'],pack['phidot_h'],bc_type='natural'))
        actual=ref['mts_q_h']/(5*ref['mts_dphi_h'])
        need(np.all(ref['mts_averaged_chart']==0) and max(abs(velocity[1](np.log(ref['a']))/actual-1))<1e-11,'archived exact heavy velocity, no division in the predictor')
    forward=[]
    for idx,field in enumerate(fields):
        dual=adjoint(x,an,hn,masses[idx],spacing)
        forward.append(CubicSpline(x,dual))
    roots,legendre=np.polynomial.legendre.leggauss(order)
    width=np.diff(times)
    frequency=np.sqrt(1+(ref['a'][1:]*max(masses[:len(fields)])/5)**2)
    blocks=np.maximum(1,np.ceil(width*frequency/.3).astype(int))
    records=np.zeros((len(width),2))
    coefs=np.zeros((len(width),2,2))
    moments=np.zeros((len(width),2))
    losses=np.ones((len(width),2))
    sharp=np.ones((len(width),2))
    norm_omitted=np.zeros((len(width),2))
    worst=None
    if 'h' in fields:
        heavy_state=np.array([ref['mts_dphi_h'],ref['mts_dphidot_h']/5]).T
        left=forward[1](times[:-1])
        right=forward[1](times[1:])
        inverse=np.linalg.inv(right)
        transport=inverse@left
        heavy_observed=heavy_state[1:]-np.einsum('nij,nj->ni',transport,heavy_state[:-1])
    def design(points,idx,inverse_right):
        aval=background(points)
        scale_weight=slow_vel(np.log(aval))/5
        slow=forward[0](points)[:,:,1].T*scale_weight
        if 'h' not in fields:
            return slow,np.empty((0,len(points)))
        local=inverse_right@forward[1](points)[:,:,1].T
        local[0]/=width[idx]
        return slow,local*(velocity[1](np.log(aval))/5)
    def project(target,basis,weights):
        weighted=basis*np.sqrt(weights)
        norm=np.linalg.norm(weighted,axis=1)
        normalized=weighted/norm[:,None]
        left,sigma,right=np.linalg.svd(normalized,full_matrices=False)
        need(sigma[-1]>128*np.finfo(float).eps*sigma[0],'identified normalized test functions')
        mapping=(((target*np.sqrt(weights))@right.T)/sigma)@left.T/norm
        return mapping,target-mapping@basis
    def quadrature(idx,degree,subcount):
        nodes,weight=(roots,legendre) if degree==order else np.polynomial.legendre.leggauss(degree)
        frac=((np.arange(subcount)[:,None]+.5+.5*nodes)/subcount).ravel()
        return times[idx]+width[idx]*frac,np.tile(weight,subcount)*width[idx]/(2*subcount),frac
    for idx in range(len(width)):
        if idx%400==0:
            guard()
        xx,ww,frac=quadrature(idx,order,blocks[idx])
        inv_right=inverse[idx] if 'h' in fields else None
        slow,heavy=design(xx,idx,inv_right)
        if len(heavy):
            proxy=raw(xx)-offset(xx)
            measured=heavy_observed[idx]/np.array([width[idx],1])-heavy@(ww*proxy)
            coeff,defect=project(slow,heavy,ww)
            coefs[idx]=coeff
            moments[idx]=measured
            records[idx]=coeff@measured
            losses[idx]=np.linalg.norm(defect*np.sqrt(ww),axis=1)/np.linalg.norm(slow*np.sqrt(ww),axis=1)
        tests=np.vstack([np.ones(len(xx)),heavy])
        taper=frac**2*(1-frac)**2
        weight_coeff,remaining=project(slow*taper,tests*taper,ww)
        residual_norm=np.linalg.norm(remaining*np.sqrt(ww),axis=1)
        sharp[idx]=residual_norm/np.linalg.norm(slow*taper*np.sqrt(ww),axis=1)
        norm_omitted[idx]=residual_norm
        if want_witness and (worst is None or residual_norm[0]>worst[0]):
            worst=(residual_norm[0],idx,weight_coeff[0],inv_right)
    witness={}
    if want_witness:
        magnitude,idx,coefficient,inv_right=worst
        xx,ww,frac=quadrature(idx,order+3,2*blocks[idx])
        slow,heavy=design(xx,idx,inv_right)
        tests=np.vstack([np.ones(len(xx)),heavy])
        taper=frac**2*(1-frac)**2
        forcing=taper**2*(slow[0]-coefficient@tests)/magnitude
        zero=(tests@(ww*forcing))/np.sum(abs(tests)*abs(ww*forcing),axis=1)
        signal=slow@(ww*forcing)
        witness=dict(interval=[int(idx),int(idx+1)],clocks=times[idx:idx+2].tolist(),normalized_constraint_errors=zero.tolist(),
            expected=magnitude,measured=signal.tolist(),signed_response_agreement=signal[0]/magnitude-1,
            zero_endpoints_and_slopes=True,passes=bool(max(abs(zero))<TOL and abs(signal[0]/magnitude-1)<TOL))
    return dict(records=records,moments=moments,coefficients=coefs,unconstrained_ratio=losses,with_dust_and_fixed_ends=sharp,norm_omitted=norm_omitted),witness


def run(case):
    guard()
    out={}
    details={}
    for label,step,order,kind,witness in [('main',.09,8,'linear',True),('refined',.045,12,'linear',False),('pchip',.09,8,'pchip',False)]:
        packet,check=experiment(case,step,order,kind,witness)
        out.update({label+'_'+key:value for key,value in packet.items()})
        if witness:
            details['witness']=check
    factor=read(ROOT/(case+'-factored.json'))['variants']
    for branch in BRANCHES:
        target=np.array(factor['gate_'+branch]['target'])
        corrected={}
        for name,kind in [('main','linear'),('refined','linear'),('pchip','pchip')]:
            base=np.array(factor['pchip_'+kind+'_'+branch]['prediction'])
            correction=out[name+'_records'].sum(0)
            corrected[name]=base-correction
        uncertainty=abs(corrected['refined']-corrected['main'])+abs(corrected['pchip']-corrected['main'])
        details[branch]=dict(target=target.tolist(),actual_supplementary_field=(case=='heavy'),
            corrected=corrected['refined'].tolist(),signed_error_over_actual=(corrected['refined']/target-1).tolist(),
            variants_over_actual=(uncertainty/abs(target)).tolist(),nominal_with_variants=((abs(corrected['refined']-target)+uncertainty)<=TOL*abs(target)).tolist())
    dest=ROOT/(case+'-common-force.npz')
    with dest.open('xb') as handle:
        np.savez_compressed(handle,**out)
    save(dest.with_suffix('.json'),dict(packet=digest(dest),source=digest(Path(__file__)),method=digest(ROOT/'COMMON-FORCE.md'),tolerance=TOL,results=details))


if __name__=='__main__':
    run(sys.argv[1])
