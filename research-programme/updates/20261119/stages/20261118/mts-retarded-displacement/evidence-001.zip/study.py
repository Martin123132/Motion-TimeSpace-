import os
import sys
from pathlib import Path
for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[variable]='1'
ROOT=Path(__file__).resolve().parent
PREVIOUS=ROOT.parent/'mts-neutrino-switch-20261118'
sys.path.insert(0,str(PREVIOUS))
from fork import bridge,COMMON,PRIOR,KEYS,np,digest,need,read,save,safe
from scipy.interpolate import CubicSpline,PchipInterpolator


SEAL='ab642601abec97593217f01220a2251d2c62f9156b9a74634dbdf66b21d8dad3'
TOL=2e-5
END=1999
TAGS=('fine','main','highq','angular','trace')
BRANCHES=('crossed','physical')
TERMS=('metric_drive','background_velocity','expansion','mass_weight')


def guard():
    safe()
    need(digest(PREVIOUS/'closeout.json')==SEAL and not (ROOT/'STOP-REQUESTED').exists(),'owner hold or stale prior seal')


def radius32(arr):
    raw=arr.astype(np.float32)
    need(np.array_equal(raw.astype(float),arr),'transfer values must be exactly representable in float32')
    hi=np.nextafter(raw,np.float32(np.inf)).astype(float)
    lo=np.nextafter(raw,np.float32(-np.inf)).astype(float)
    return .5*np.maximum(hi-arr,arr-lo)


def native(case):
    config=bridge.inputs(case)
    with np.load(config['ref']) as saved:
        index=np.flatnonzero(saved['modes']==5)
        need(len(index)==1,'unique k=5')
        columns=dict(zip(saved['names'].tolist(),saved['values'][index[0]].T.copy()))
        full_x=saved['conformal_time'].copy()*5
    fraction=config['baryon']
    rate=columns['growth']*columns['H']/5
    vel=columns['v_baryon_cdm']
    drive=rate*columns['delta_nonu']+fraction*vel
    bound=abs(rate)*radius32(columns['delta_nonu'])+fraction*radius32(vel)
    component=rate*((1-fraction)*columns['delta_cdm']+fraction*columns['delta_baryon'])+fraction*vel
    component_bound=abs(rate)*((1-fraction)*radius32(columns['delta_cdm'])+fraction*radius32(columns['delta_baryon']))+fraction*radius32(vel)
    cap=PRIOR/(case+'-physical-roots-capture.npz')
    with np.load(cap) as saved:
        ids=np.searchsorted(full_x,saved['clock']*5)
        need(np.array_equal(full_x[ids],saved['clock']*5) and np.array_equal(ids,np.arange(1991,4253)),'all captured clocks')
        actual=saved['derivative_reference'][:,1]/5
        cb=(1-fraction)*saved['reference'][:,1]+fraction*saved['reference'][:,2]
        exact=rate[ids]*cb+fraction*saved['reference'][:,3]
        exact_error=max(abs(exact/actual-1))
        need(exact_error<1e-12,'double precision capture checks growth equation')
    tests={}
    for name,pred,unc in [('nonu',drive,bound),('components',component,component_bound)]:
        residual=pred[ids]-actual
        envelope=unc[ids]+32*np.finfo(float).eps*(abs(actual)+abs(rate[ids]*cb)+abs(fraction*vel[ids]))
        need(np.all(abs(residual)<=envelope),'rounding enclosure on native captures: '+name)
        tests[name]=dict(points=len(actual),max_relative=max(abs(residual/actual)),max_envelope_ratio=max(abs(residual)/envelope))
    times=full_x[:END+1]
    bg=COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    with np.load(bg) as packet:
        phi=CubicSpline(packet['efold'],packet['phidot_s'],bc_type='natural')
    subset={key:arr[:END+1] for key,arr in columns.items()}
    return (times,subset,drive[:END+1],component[:END+1],bound[:END+1],phi,config,
            dict(capture=digest(cap),native=digest(config['ref']),background=digest(bg),baryon_fraction=fraction,full_double_relative=exact_error,checks=tests))


def trajectory(case,tag,times):
    arrays=[]
    allkeys=['a','H','archived_velocity','physical_velocity','shadow_dphi','shadow_dphidot','mts_dphi_s','mts_dphidot_s','active_cdm_x']
    files=read(PREVIOUS/'closeout.json')['files']
    for arm in ('fork','both'):
        path=PREVIOUS/(case+'-'+tag+'-'+arm+'.npz')
        need(digest(path)==files[path.name]['sha256'],'verified saved array')
        with np.load(path) as saved:
            values=saved['forecast'][:,[KEYS.index(key) for key in allkeys]]
            arrays.append((saved['x'].copy(),values))
    xx=np.r_[arrays[0][0],arrays[1][0][1:]]
    positions=np.searchsorted(xx,times)
    need(np.array_equal(xx[positions],times),'identical comparison epochs')
    return dict(zip(allkeys,np.vstack([arrays[0][1],arrays[1][1][1:]])[positions].T))


def windows(times):
    bounds={0,END,1991}
    dense=np.diff(times)<=.025
    bounds.update((np.flatnonzero(dense[1:]!=dense[:-1])+1).tolist())
    for clock in (1.,52.):
        right=int(np.searchsorted(times,clock))
        bounds.update((right-1,right))
    edges=sorted(bounds)
    return list(zip(edges[:-1],edges[1:]))


def matrices(times,coeff,variant,cap):
    cls=PchipInterpolator if variant=='pchip' else CubicSpline
    spline=cls(times,coeff,axis=0)
    width=np.diff(times)
    counts=2**np.maximum(0,np.ceil(np.log2(width/cap)).astype(int))
    size=coeff.shape[1]
    output=np.zeros((len(width),2,size))
    output[:,0,0]=1
    output[:,1,1]=1
    for count in np.unique(counts):
        ids=np.flatnonzero(counts==count)
        interval=width[ids]
        length=interval/count
        sample=(np.arange(2*count+1)/(2*count))[None,:]
        args=times[ids,None]+interval[:,None]*sample
        if variant=='linear':
            values=coeff[ids,None,:]*(1-sample[:,:,None])+coeff[ids+1,None,:]*sample[:,:,None]
        else:
            values=spline(args)
        state=output[ids].copy()
        step=length[:,None,None]
        def rhs(state,point):
            result=np.empty_like(state)
            result[:,0]=state[:,1]
            result[:,1]=-(1+point[:,1,None])*state[:,0]-2*point[:,0,None]*state[:,1]
            result[:,1,2:]+=point[:,2:]
            return result
        for index in range(int(count)):
            left,mid,right=(values[:,2*index+offset,:] for offset in (0,1,2))
            one=rhs(state,left)
            two=rhs(state+step*one/2,mid)
            three=rhs(state+step*two/2,mid)
            four=rhs(state+step*three,right)
            state+=step*(one+2*two+2*three+four)/6
        output[ids]=state
    return output


def project(matrix,errors,windows_):
    prop=matrix[:,:,:2]
    future=np.empty((len(prop)+1,2,2))
    future[-1]=np.eye(2)
    for idx in range(len(prop)-1,-1,-1):
        future[idx]=future[idx+1]@prop[idx]
    innovations=errors[1:]-np.einsum('nij,nj->ni',prop,errors[:-1])
    measured=np.einsum('nij,nj->ni',future[1:],innovations)
    forced=np.einsum('nij,njk->nik',future[1:],matrix[:,:,2:])
    initial=future[0]@errors[0]
    observed=np.array([measured[left:right].sum(0) for left,right in windows_])
    predicted=np.array([forced[left:right].sum(0) for left,right in windows_])
    endpoint=initial+predicted.sum((0,2))
    need(np.allclose(initial+observed.sum(0),errors[-1],rtol=3e-12,atol=1e-35),'signed innovations reconstruct both components')
    return dict(future=future,initial=initial,measured=measured,forced=forced,observed=observed,predicted=predicted,endpoint=endpoint)


def run(case):
    guard()
    times,ref,drive,component,bound,velocity,cfg,provenance=native(case)
    regions=windows(times)
    tables={}
    kernels={}
    field=ref['mts_dphi_s']
    speed=ref['mts_dphidot_s']/5
    native_state=np.array([field,speed]).T
    bnative=velocity(np.log(ref['a']))/5
    mass=cfg['masses'][0]
    medium=np.array([ref['H']/5,(ref['a']*mass/5)**2]).T
    for tag in TAGS:
        guard()
        switched=trajectory(case,tag,times)
        for branch in BRANCHES:
            physical=branch=='physical'
            field_s=switched['mts_dphi_s' if physical else 'shadow_dphi']
            vel_s=switched['mts_dphidot_s' if physical else 'shadow_dphidot']/5
            bs=switched['physical_velocity' if physical else 'archived_velocity']/5
            errors=np.column_stack([field_s,vel_s])-native_state
            def sources(driving):
                return np.column_stack([bnative*(switched['active_cdm_x']-driving),
                    (bs-bnative)*switched['active_cdm_x'],-2*((switched['H']-ref['H'])/5)*vel_s,
                    -(switched['a']-ref['a'])*(switched['a']+ref['a'])*(mass/5)**2*field_s])
            runs=[('preferred','cubic',.0125,drive)]
            if tag=='fine':
                runs+=[('step','cubic',.025,drive),('pchip','pchip',.0125,drive),('linear','linear',.0125,drive),('component','cubic',.0125,component)]
            for name,variant,cap,driving in runs:
                key=tag+'_'+branch+'_'+name
                matrix=matrices(times,np.column_stack([medium,sources(driving)]),variant,cap)
                result=project(matrix,errors,regions)
                for item in ('initial','observed','predicted','endpoint'):
                    tables[key+'_'+item]=result[item]
                if tag=='fine' and name=='preferred':
                    for item in ('future','forced','measured'):
                        kernels[branch+'_'+item]=result[item]
                    kernels[branch+'_prop']=matrix[:,:,:2]
                    kernels[branch+'_det']=np.linalg.det(matrix[:,:,:2])
                    kernels[branch+'_errors']=errors
            tables[tag+'_'+branch+'_actual']=errors[-1]
    dest=ROOT/(case+'-retarded.npz')
    inputs=dict(x=times,windows=np.array(regions),native_state=native_state,growth_drive=drive,drive_bound=bound,component_drive=component,medium=medium)
    with dest.open('xb') as file:
        np.savez_compressed(file,**inputs,**tables,**kernels)
    save(dest.with_suffix('.json'),dict(packet=digest(dest),method=digest(ROOT/'METHOD.md'),source=digest(Path(__file__)),prior=SEAL,provenance=provenance,tolerance=TOL))


if __name__=='__main__':
    run(sys.argv[1])
