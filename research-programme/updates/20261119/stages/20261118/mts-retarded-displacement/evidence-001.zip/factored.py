from paired import adjoint,load_dense
from study import *


def interpolator(times,values,method):
    if method=='linear':
        return lambda x:np.interp(x,times,values)
    return (PchipInterpolator if method=='pchip' else CubicSpline)(times,values)


def bin_offsets(array):
    raw=array.astype(np.float32)
    need(np.array_equal(array,raw.astype(float)),'known transfer precision')
    return np.array([(np.nextafter(raw,np.float32(direction)).astype(float)-array)*.5 for direction in (-np.inf,np.inf)])


def precision(times,x,kernel,ref,fraction):
    primary=ref['delta_nonu']
    primary_box=bin_offsets(primary)
    other=(1-fraction)*ref['delta_cdm']+fraction*ref['delta_baryon']-primary
    alternate=other+(1-fraction)*bin_offsets(ref['delta_cdm'])+fraction*bin_offsets(ref['delta_baryon'])
    lo=np.maximum(primary_box[0],alternate[0])
    hi=np.minimum(primary_box[1],alternate[1])
    need(np.all(lo<=hi),'joint matter-density interval is not empty')
    rate=ref['H']*ref['growth']/5
    vel=fraction*bin_offsets(ref['v_baryon_cdm'])
    bounds=np.stack([np.minimum(rate*lo,rate*hi)+vel[0],np.maximum(rate*lo,rate*hi)+vel[1]])
    centers=(x[1:]+x[:-1])/2
    half=np.diff(x)/2
    cell=np.searchsorted(times,x[:-1],side='right')-1
    need(np.all(x[1:]<=times[cell+1]),'all native hat knots split')
    matrices=[]
    for cls in (CubicSpline,PchipInterpolator):
        basis=np.zeros((len(times),2))
        fun=cls(x,-kernel)
        nodes,weights=np.polynomial.legendre.leggauss(3)
        for point,weight in zip(nodes,weights):
            moment=centers+point*half
            frac=(moment-times[cell])/(times[cell+1]-times[cell])
            pair=(weight*half)[:,None]*fun(moment)
            for idx in (0,1):
                basis[:,idx]+=np.bincount(cell,weights=(1-frac)*pair[:,idx],minlength=len(times))
                basis[:,idx]+=np.bincount(cell+1,weights=frac*pair[:,idx],minlength=len(times))
        matrices.append(basis)
    basis=matrices[0]
    left=basis*bounds[0,:,None]
    right=basis*bounds[1,:,None]
    low=np.minimum(left,right).sum(0)
    high=np.maximum(left,right).sum(0)
    sensitivity=(abs(basis-matrices[1])*np.max(abs(bounds),axis=0)[:,None]).sum(0)
    need(np.all(low<=high),'ordered signed envelope')
    return basis,bounds,low,high,sensitivity


def run(case):
    guard()
    times,n,col,other,_,vel,config,_=native(case)
    dense=load_dense(case)
    x,scale,hub,cprime,physical,archived=dense.T
    slots=np.searchsorted(x,times)
    with np.load(ROOT/(case+'-paired.npz')) as pair:
        need(np.array_equal(x,pair['accepted_x']),'same accepted clocks')
        archive_state=pair['integrated_archive'].copy()
        phys_state=archive_state+pair['integrated_pair']
    with np.load(ROOT/(case+'-retarded.npz')) as stored:
        origin={key:stored[key+'_errors'][0].copy() for key in BRANCHES}
        target={key:stored[key+'_errors'][-1].copy() for key in BRANCHES}
    mass=config['masses'][0]
    regions=windows(times)
    cuts=times[np.r_[[left for left,_ in regions],regions[-1][1]]]
    parts={}
    summary={}
    binout={}
    for background in ('pchip','linear'):
        an=scale+interpolator(times,n['a']-scale[slots],background)(x)
        hn=hub+interpolator(times,n['H']-hub[slots],background)(x)
        un=vel(np.log(an))
        adj=adjoint(x,an,hn,mass,.15)
        kernels=adj[:,:,1]
        if background=='pchip':
            basis,box,low,high,spread=precision(times,x,kernels*un[:,None]/5,n,config['baryon'])
            binout=dict(basis=basis,offsets=box,lower=low,upper=high,basis_sensitivity=spread)
        for label,method,drive in [('linear','linear',col),('pchip','pchip',col),('cubic','cubic',col),('components','linear',other)]:
            difference=interpolator(times,cprime[slots]-drive,method)(x)
            for branch,bval,state in [('crossed',archived,archive_state),('physical',physical,phys_state)]:
                forcing=np.array([un*difference/5,(bval-un)*cprime/5,-2*(hub-hn)*state[:,1]/5,
                                   -(scale-an)*(scale+an)*(mass/5)**2*state[:,0]]).T
                integrand=kernels[:,:,None]*forcing[:,None,:]
                integral=CubicSpline(x,integrand).antiderivative()
                signed=np.diff(integral(cuts),axis=0)
                forecast=adj[0]@origin[branch]+signed.sum(axis=(0,2))
                key=background+'_'+label+'_'+branch
                parts[key]=signed
                summary[key]=dict(prediction=forecast.tolist(),signed_error_over_actual=(forecast/target[branch]-1).tolist())
    with np.load(ROOT/(case+'-retarded.npz')) as saved:
        for key in BRANCHES:
            actual=target[key]
            center=np.array(summary['pchip_linear_'+key]['prediction'])
            variants=[np.array(summary[key2]['prediction']) for key2 in summary if key2.endswith('_'+key)]
            sensitivity=np.max(abs(np.array(variants)-center),axis=0)+np.maximum(abs(binout['lower']),abs(binout['upper']))+binout['basis_sensitivity']
            sensitivity+=sum(abs(saved[tag+'_'+key+'_actual']-actual) for tag in TAGS[1:])
            summary['gate_'+key]=dict(target=actual.tolist(),sensitivity_over_target=(sensitivity/abs(actual)).tolist(),
                signed_rounding_min_over_abs_target=(binout['lower']/abs(actual)).tolist(),signed_rounding_max_over_abs_target=(binout['upper']/abs(actual)).tolist(),
                passes=((abs(center-actual)+sensitivity)<=TOL*abs(actual)).tolist())
    dest=ROOT/(case+'-factored.npz')
    with dest.open('xb') as file:
        np.savez_compressed(file,windows=regions,**binout,**parts)
    save(dest.with_suffix('.json'),dict(packet=digest(dest),source=digest(Path(__file__)),method=digest(ROOT/'FACTOR-GROWTH.md'),tolerance=TOL,variants=summary))


if __name__=='__main__':
    run(sys.argv[1])
