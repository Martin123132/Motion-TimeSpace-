from datetime import datetime,timezone
from study import *


if __name__=='__main__':
    guard()
    verification=read(ROOT/'verification.json')
    need(verification['script']==digest(ROOT/'verify.py') and verification['older_manifest']==SEAL,'current numerical verification')
    for case in ('cold','heavy'):
        trace=read(ROOT/(case+'-trace-bound.json'))
        need(trace['script']==digest(ROOT/'trace_bound.py') and trace['method']==digest(ROOT/'TRACE-BOUND.md') and trace['verified'],'tested trace kernel')
        row=trace['fine']
        with np.load(ROOT/(case+'-retarded.npz')) as pack:
            width=row['x'][1]-row['x'][0]
            for key in BRANCHES:
                expected=TOL*abs(pack['fine_'+key+'_actual'][0])
                actual=row['critical_rms_for_TOL'][key]*np.sqrt(width)*row['l2_gain']
                need(abs(actual/expected-1)<1e-12,'sharp single-cell error allocation')
        trial=read(ROOT/(case+'-short.json'))['records']
        need(len(trial)==9 and all(entry['early_enclosed']==8 for entry in trial[1:]) and trial[-1]['pressure_refinement_over_peak']>TOL,'preserve positive enclosure and own-amplitude failure')
    need((ROOT/'RESULTS.md').is_file() and not any(p.is_dir() for p in ROOT.iterdir()),'inspect scope and final interpretation')
    files={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name!='closeout.json'}
    save(ROOT/'closeout.json',dict(utc=datetime.now(timezone.utc).isoformat(),prior=SEAL,files=files))
    need(all(digest(ROOT/key)==value['sha256'] for key,value in read(ROOT/'closeout.json')['files'].items()),'saved stage readback')
    print(len(files),sum(value['bytes'] for value in files.values()),digest(ROOT/'closeout.json'))
