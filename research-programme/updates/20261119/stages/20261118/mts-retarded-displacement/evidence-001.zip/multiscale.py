from scipy.integrate._ivp.rk import DOP853
from scipy.interpolate import CubicHermiteSpline
from study import *


def spline_ceiling(spline,grid):
    value=np.maximum(abs(spline(grid[1:])),abs(spline(grid[:-1])))
    roots=spline.derivative().roots(extrapolate=False)
    inside=roots[np.isfinite(roots)&(roots>=grid[0])&(roots<grid[-1])]
    where=np.searchsorted(grid,inside,side='right')-1
    np.maximum.at(value,where,abs(spline(inside)))
    return np.nextafter(value*(1+64*np.finfo(float).eps),np.inf)


def maps(times,scale,hub,drive,waves,mass,vel,method,cap,indices,hermite=False):
    curve=(CubicHermiteSpline(times,np.log(scale),hub/5) if hermite else PchipInterpolator(times,np.log(scale)))
    friction=PchipInterpolator(times,hub/5)
    if method=='linear':
        def forces(points):
            slots=np.clip(np.searchsorted(times[indices],points,side='right')-1,0,len(indices)-2)
            left,right=indices[slots],indices[slots+1]
            frac=((points-times[left])/(times[right]-times[left]))[:,None]
            return drive[left]+frac*(drive[right]-drive[left])
    else:
        forces=PchipInterpolator(times[indices],drive[indices])
    widths=np.diff(times)
    rate=np.maximum(np.maximum(hub[:-1],hub[1:])/5,np.sqrt(max(waves)**2+(scale[1:]*mass)**2)/5)
    counts=2**np.maximum(0,np.ceil(np.log2(widths*rate/cap)).astype(int))
    output=np.zeros((len(widths),len(waves),2,3))
    output[:,:,0,0]=1
    output[:,:,1,1]=1
    for count in np.unique(counts):
        bunch=np.flatnonzero(counts==count)
        for first in range(0,len(bunch),192):
            ids=bunch[first:first+192]
            span=widths[ids]/count
            step=span[:,None,None,None]
            state=output[ids].copy()
            for rep in range(count):
                knots=times[ids,None]+span[:,None]*(rep+DOP853.C)
                flat=knots.ravel()
                loga=curve(flat)
                omega=((waves[None,:]**2+(mass*np.exp(loga[:,None]))**2)/25).reshape(len(ids),12,len(waves))
                damping=(2*friction(flat)).reshape(len(ids),12)
                source=(vel(loga)[:,None]*forces(flat)/5).reshape(len(ids),12,len(waves))
                deriv=[]
                for stage in range(12):
                    trial=state if stage==0 else state+step*sum(weight*item for weight,item in zip(DOP853.A[stage,:stage],deriv) if weight)
                    slope=np.empty_like(trial)
                    slope[:,:,0]=trial[:,:,1]
                    slope[:,:,1]=-omega[:,stage,:,None]*trial[:,:,0]-damping[:,stage,None,None]*trial[:,:,1]
                    slope[:,:,1,2]+=source[:,stage]
                    deriv.append(slope)
                state+=step*sum(weight*item for weight,item in zip(DOP853.B,deriv) if weight)
            output[ids]=state
    return output


def run(case,subset=None):
    guard()
    config=bridge.inputs(case)
    archive=Path(config['ref'])
    if subset is not None:
        archive=archive.parent/('chunk-'+{.03:'0144',.1:'0192',1.:'0352'}[subset]+'.npz')
    with np.load(archive) as packet:
        selected=np.arange(len(packet['modes'])) if subset is None else np.flatnonzero(packet['modes']==subset)
        cols=dict(zip(packet['names'].tolist(),packet['values'][selected].T.copy()))
        waves=packet['modes'][selected].copy()
        x=5*packet['conformal_time']
    need(np.array_equal(cols['a'],np.broadcast_to(cols['a'][:,:1],cols['a'].shape)) and
         np.array_equal(cols['H'],np.broadcast_to(cols['H'][:,:1],cols['H'].shape)) and len(waves)==(1 if subset else 4 if case=='cold' else 16),'within-file identical homogeneous background')
    scale,hub=cols['a'][:,0],cols['H'][:,0]
    dense=np.diff(x)<=.025
    edges=np.r_[0,np.flatnonzero(dense[1:]!=dense[:-1])+1,len(x)-1]
    fraction=config['baryon']
    drive=(cols['growth']*cols['H']*cols['delta_nonu']+fraction*waves*cols['v_baryon_cdm'])/5
    radius=(abs(cols['growth']*cols['H'])*radius32(cols['delta_nonu'])+fraction*waves*radius32(cols['v_baryon_cdm']))/5
    bg=COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    study={}
    allfields={}
    with np.load(bg) as packet:
        for index,field in enumerate(('s','h') if case=='heavy' else ('s',)):
            knots=packet['efold' if field=='s' else 'heavy_efold']
            allfields[field]=(config['masses'][index],CubicSpline(knots,packet['phi_'+field],bc_type='natural'),CubicSpline(knots,packet['phidot_'+field],bc_type='natural'))
    results={}
    for field,(mass,phi,vel) in allfields.items():
        need((case=='cold' or np.all(cols['mts_averaged_chart']==0)) and np.all(np.diff(scale)>0) and min(hub)>0,'retained exact chart and expanding background')
        omega=np.sqrt(waves[None,:]**2+(mass*scale[:,None])**2)/5
        pot=(scale*mass)**2*phi(np.log(scale))
        kin=5*vel(np.log(scale))
        maxv=spline_ceiling(vel,np.log(scale))/5
        increments=np.diff(x)[:,None]*maxv[:,None]*np.maximum(radius[:-1],radius[1:])/omega[:-1]
        true=np.stack([cols['mts_dphi_'+field],cols['mts_dphidot_'+field]/5,cols['mts_dp_'+field]],axis=-1)
        identity=(kin[:,None]*true[:,:,1]-pot[:,None]*true[:,:,0])-true[:,:,2]
        identity_peak=max(np.max(abs(identity),axis=0)/np.max(abs(true[:,:,2]),axis=0))
        need(identity_peak<=TOL,'independent native field/background readout')
        solutions={key:np.full_like(true,np.nan) for key in ('linear','refined','pchip','even','odd','geometry','homogeneous')}
        bound=np.zeros_like(true)
        for left,right in zip(edges[:-1],edges[1:]):
            guard()
            sl=slice(left,right+1)
            rows=np.arange(right-left+1)
            for name,method,cap,knot_subset,alternate in [('linear','linear',.20,rows,False),('refined','linear',.1,rows,False),('pchip','pchip',.15,rows,False),
                    ('even','linear',.16,np.unique(np.r_[0,rows[::2],rows[-1]]),False),
                    ('odd','linear',.16,np.unique(np.r_[0,rows[1::2],rows[-1]]),False),('geometry','linear',.15,rows,True)]:
                operators=maps(x[sl],scale[sl],hub[sl],drive[sl],waves,mass,vel,method,cap,knot_subset,alternate)
                state=true[left,:,:2].copy()
                hom=state.copy()
                for idx,cell in enumerate(operators,start=left+1):
                    state=np.einsum('kij,kj->ki',cell[:,:,:2],state)+cell[:,:,2]
                    solutions[name][idx,:,:2]=state
                    solutions[name][idx,:,2]=kin[idx]*state[:,1]-pot[idx]*state[:,0]
                    if name=='refined':
                        hom=np.einsum('kij,kj->ki',cell[:,:,:2],hom)
                        solutions['homogeneous'][idx,:,:2]=hom
                        solutions['homogeneous'][idx,:,2]=kin[idx]*hom[:,1]-pot[idx]*hom[:,0]
            energy=np.cumsum(increments[left:right],axis=0)
            scored=slice(left+1,right+1)
            bound[scored,:,0]=energy
            bound[scored,:,1]=energy*omega[scored]
            bound[scored,:,2]=energy*np.hypot(pot[scored,None],kin[scored,None]*omega[scored])
        for values in solutions.values():
            values[0]=true[0]
            need(np.isfinite(values).all(),'every noninitial target predicted')
        central=solutions['refined']
        sensitivity=abs(central-solutions['linear'])+abs(central-solutions['pchip'])+abs(central-solutions['geometry'])+np.maximum(abs(central-solutions['even']),abs(central-solutions['odd']))+bound
        summary={}
        for label,density in [('dense',True),('sparse',False)]:
            indices=np.flatnonzero(dense==density)+1
            def passed(values):
                return np.sum(abs(values[indices]-true[indices])+sensitivity[indices]<=TOL*abs(true[indices]),axis=0)
            outcome=passed(central)
            control=np.sum(abs(solutions['homogeneous'][indices]-true[indices])<=TOL*abs(true[indices]),axis=0)
            reverse=np.sum(abs((2*solutions['homogeneous'][indices]-central[indices])-true[indices])<=TOL*abs(true[indices]),axis=0)
            peak=np.zeros_like(outcome)
            for left,right in zip(edges[:-1],edges[1:]):
                if dense[left]==density:
                    group=slice(left+1,right+1)
                    peak+=np.sum(abs(central[group]-true[group])+sensitivity[group]<=TOL*np.max(abs(true[group]),axis=0),axis=0)
            summary[label]=dict(epochs=len(indices),number_scored=len(indices)*len(waves),passes_by_coordinate=outcome.sum(axis=0).tolist(),
                     peak_pass_by_coordinate=peak.sum(axis=0).tolist(),pressure_pass_by_mode=outcome[:,2].tolist(),
                     no_source_nominal_by_coordinate=control.sum(axis=0).tolist(),opposite_source_nominal_by_coordinate=reverse.sum(axis=0).tolist())
        study[field]=dict(native_stress_identity_over_peak=identity_peak,windows=summary)
        results.update({field+'_target':true,field+'_prediction':central,field+'_zero':solutions['homogeneous'],field+'_uncertainty':sensitivity,field+'_input_bound':bound})
    path=ROOT/(case+('' if subset is None else '-'+str(subset))+'-multiscale.npz')
    with path.open('xb') as packet:
        np.savez_compressed(packet,modes=waves,x=x,edges=edges,dense=dense,**results)
    save(path.with_suffix('.json'),dict(packet=digest(path),script=digest(Path(__file__)),method=digest(ROOT/'MULTISCALE.md'),native=digest(archive),background=digest(bg),
        tolerance=TOL,block_edges=edges.tolist(),fields=study))


if __name__=='__main__':
    run(sys.argv[1],float(sys.argv[2]) if len(sys.argv)>2 else None)
