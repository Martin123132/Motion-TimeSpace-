from pathlib import Path
import sys
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
PARENT=HERE.parent/"mts-source-powered-local-tides-20261118"
sys.path.insert(0,str(PARENT))
from common import source, sha, np, CH, SRC, NORM, TOL, peak, guard as previous_guard, json, csv
from matter_tangent import Averaged, EPS
import higher

LOCK="77551df8ce8e14549527c507fdd2151c2f07dec360db346011c47862d3a74d4e"
ARMS=((1.,0.),(.8,0.),(.8,1/160),(.8,1.))


def guard():
    previous_guard()
    assert sha(PARENT/"closeout.json")==LOCK and not (HERE/"STOP-REQUESTED").exists()


def write(name,rows):
    with (HERE/name).open("w",newline="",encoding="utf8") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def name(mesh,eta,amp):
    return f"{mesh}-eta{eta:g}-h{amp:g}"


def extract(mesh,eta,amp):
    guard()
    model=Averaged(mesh,eta,amp,0,"higher")
    key=name(mesh,eta,amp)
    expected=source(PARENT,f"higher-{key}-s0.npz")
    with np.load(model.path) as old:state=old["initial"].astype(complex)
    model.sel=np.flatnonzero((model.r>=5.2)&(model.r<=7.3))
    radius=model.r[model.sel]
    steps=int(np.ceil(6.5/(.26*model.grid.step)/256))*256
    dt=6.5/steps;series=[]
    for tick in range(steps+1):
        if tick%256==0:guard()
        clock=tick*dt;wave=model.field(clock)
        if tick%(steps//256)==0:
            first,read,budget,energy=model.rhs(state,wave,1j*EPS,True)
            if tick==0:
                initial_mass=read[0].imag/EPS
                initial_energy=energy.imag/EPS
            delta_mass=initial_mass-model.primitive(((energy.imag/EPS)-initial_energy)[::-1])[::-1][model.sel]
            dhdr=higher.first(model.grid,state[0].imag/EPS,1)[model.sel]
            hdr=model.grid.first(state[0].real,1)[model.sel]
            series.append(np.stack([read[0].real,read[2].real-1,read[10].real,read[11].real,hdr,
                                    delta_mass,read[2].imag/EPS,read[10].imag/EPS,read[11].imag/EPS,dhdr,
                                    *wave[:,model.sel]]))
        else:first=model.rhs(state,wave,1j*EPS)
        if tick==steps:break
        mid=model.field(clock+dt/2)
        second=model.rhs(state+dt/2*first,mid,1j*EPS)
        third=model.rhs(state+dt/2*second,mid,1j*EPS)
        fourth=model.rhs(state+dt*third,model.field(clock+dt),1j*EPS)
        state+=dt/6*(first+2*second+2*third+fourth)
    array=np.array(series)
    with np.load(expected) as check:
        assert np.array_equal(check["delta_final"],state.imag/EPS)
        for idx,rad in enumerate(check["radius"]):
            slot=np.argmin(abs(radius-rad))
            assert radius[slot]==rad and np.array_equal(array[:,5,slot],check["delta"][0,0,idx]+check["exterior_dm"][:,idx])
            assert np.array_equal(array[:,8,slot],check["delta"][:,11,idx])
    with (HERE/f"strip-{key}.npz").open("xb") as stream:
        np.savez_compressed(stream,time=np.linspace(0,6.5,257),radius=radius,values=array,seal=sha(expected),
                            columns=["mass","F_minus_one","h","Pi","h_r","d_mass","d_F","d_h","d_Pi","d_hr","A","P","A_r"])
    print(key,"replayed saved endpoint exactly",flush=True)


if __name__=="__main__":
    for mesh in (960,1920):
        for eta,amp in ARMS:extract(mesh,eta,amp)
    extract(1920,0.,0.)

