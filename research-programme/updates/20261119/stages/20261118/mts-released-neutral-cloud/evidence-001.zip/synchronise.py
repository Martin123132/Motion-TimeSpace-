from paired import *
from trajectory import Strip
from scipy.interpolate import RectBivariateSpline

def root(value):
    before=np.sqrt(value.real)
    return before+1j*value.imag/(before+np.sqrt(value.real+value.imag))


class Matching:
    def __init__(self,mesh,amp,repaired=False):
        self.repaired=repaired
        key=name(mesh,.8,0.)
        changed=name(mesh,.8,amp)
        ordinary=dict(np.load(HERE/f"strip-{key}.npz"))
        scalar=dict(np.load(HERE/f"strip-{changed}.npz"))
        t=ordinary["time"];r=ordinary["radius"]
        self.fields={}
        for label,idx in (("M",0),("F",1)):
            base=ordinary["values"][:,idx];shift=scalar["values"][:,idx]-base
            self.fields[label]=[RectBivariateSpline(t,r,src,kx=5,ky=5,s=0) for src in (base,shift)]
        with np.load(source(SRC,f"driven-{mesh}-eta0.8-h0-spin0.npz")) as one,np.load(source(SRC,f"driven-{mesh}-eta0.8-h{amp:g}-spin0.npz")) as two:
            use=(one["radius"]>=5.2)&(one["radius"]<=7.3)
            aa=one["fields"][:,:,use];other=two["fields"][:,:,use]-aa
            if repaired:
                with np.load(HERE/f"source-difference-{mesh}-h{amp:g}.npz") as bank:
                    assert np.array_equal(one["time"],bank["time"]) and np.array_equal(one["radius"][use],bank["radius"])
                    other=bank["wave_delta"]
            for idx,label in enumerate(("A","P","X")):
                self.fields[label]=[RectBivariateSpline(one["time"],one["radius"][use],arr[:,idx],kx=5,ky=5,s=0) for arr in (aa,other)]
    def at(self,tag,t,r,dr=0):
        a,b=self.fields[tag]
        dt=t.imag;dx=r.imag
        midt=t.real+dt/2;midr=r.real+dx/2
        base=a.ev(t.real,r.real,dy=dr).item()
        shift=b.ev(t.real+dt,r.real+dx,dy=dr).item()
        if self.repaired:
            off=1/(2*np.sqrt(3.))
            for sign in (-off,off):
                shift+=(dt*a.ev(midt+sign*dt,midr+sign*dx,dx=1,dy=dr).item()+dx*a.ev(midt+sign*dt,midr+sign*dx,dy=dr+1).item())/2
        else:
            shift+=dt*a.ev(midt,midr,dx=1,dy=dr).item()+dx*a.ev(midt,midr,dy=dr+1).item()
        return base+1j*shift
    def geodesic(self,_,state,fields=False):
        t,r,p=state[:3]+1j*state[3:]
        mass=self.at("M",t,r);lapse=1+self.at("F",t,r)
        f=1-2*ratio(mass,r)
        fr=2*ratio(ratio(mass,r)-self.at("M",t,r,1),r)
        p2=prod(p,p);fp2=prod(f,p2);lor=root(1+fp2)
        td=ratio(lor,prod(lapse,root(f)));rd=prod(f,p)
        pd=-prod(1+fp2,ratio(self.at("F",t,r,1),lapse))-.5*prod(1+2*fp2,ratio(fr,f))
        if not fields:
            speed=np.array([td,rd,pd])
            return np.r_[speed.real,speed.imag]
        val,pm,xr=[self.at(tag,t,r) for tag in ("A","P","X")]
        charge=.0016
        r2=prod(r,r);r3=prod(r2,r)
        omega=2*charge*ratio(val,r3)
        rate=ratio(rd,r)
        odot=2*charge*ratio(prod(prod(lapse,f),prod(pm,td))+prod(xr,rd),r3)-3*prod(omega,rate)
        wp=prod(root(f),p);pp=prod(lor,pm)+prod(wp,xr);xx=prod(lor,xr)+prod(wp,pm)
        trace=NORM*(ratio(prod(f,prod(pp,pp)+prod(xx,xx)),r2)+2*prod(ratio(val,r2),ratio(val,r2)))
        return np.array([omega,odot,rate,trace])


def check(mesh,amp,repaired):
    model=Matching(mesh,amp,repaired);base=readpath(name(mesh,.8,0.));changed=readpath(name(mesh,.8,amp));tau=base["tau"]
    rows=[];curves=[]
    for idx,site in enumerate(base["sites"]):
        sol=solve_ivp(model.geodesic,(0,tau[-1]),[0.,site,0.,0.,0.,0.],t_eval=tau,method="DOP853",
                      rtol=3e-12,atol=[2e-14,2e-14,2e-16,1e-21,1e-21,1e-23],max_step=.08)
        assert sol.success
        fields=np.array([model.geodesic(t,state,True) for t,state in zip(tau,sol.y.T)])
        first=base["force"][idx].copy()
        delta=changed["force"][idx]-first
        for slot,target in enumerate((4,5,6,11)):
            first[:,target]=fields[:,slot].real
            delta[:,target]=fields[:,slot].imag
        def output(mode,sub):
            return advance(tau,first,None,mode,sub,delta=delta)
        ray=output("ray",1);jac=output("matrix",2)
        volume=ray[:,0].imag;part=ray[:,-1].imag
        curves.append(np.column_stack([volume,ray[:,1].imag,part,jac[:,0].imag,jac[:,1].imag,fields[:,0].imag,sol.y[3],sol.y[4]]))
        rows.append(dict(mesh=mesh,amp=amp,site=site,volume_peak=peak(volume),det_error=peak(volume-jac[:,0].imag)/peak(volume),
                         axial_det_error=peak(part-jac[:,1].imag)/peak(part),final=volume[-1]))
    return curves,rows


if __name__=="__main__":
    guard();allcurves=[];allrows=[]
    repaired="--repaired" in sys.argv
    marker="repaired" if repaired else "synchronised"
    for mesh in (960,1920):
        for amp in (1/160,1.):
            curves,rows=check(mesh,amp,repaired)
            allcurves.extend(curves);allrows.extend(rows)
    curves=np.array(allcurves)
    for idx,row in enumerate(allrows):
        other=idx+6 if idx<6 else idx-6
        fine=max(idx,other)
        for slot,label in enumerate(("volume","photon","axial","det","det_axial","omega","clock_difference","radius_difference")):
            row["mesh_"+label]=peak(curves[idx,:,slot]-curves[other,:,slot])/peak(curves[fine,:,slot])
    write(marker+"_volumes.csv",allrows)
    with (HERE/(marker+".npz")).open("xb") as stream:np.savez_compressed(stream,curves=curves)
    print(allrows[7])

