from strip import HERE, np, EPS, NORM, ARMS, name, guard, write
from scipy.interpolate import RectBivariateSpline
from scipy.integrate import solve_ivp


class Strip:
    def __init__(self,mesh,eta,amp,reference=False):
        data=dict(np.load(HERE/f"strip-{name(mesh,eta,amp)}.npz"))
        self.curves=[RectBivariateSpline(data["time"],data["radius"],field,kx=5,ky=5,s=0) for field in data["values"].transpose(1,0,2)]
        self.charge=.002*eta
        self.inside=0.
        self.reference=reference
        self.mass_cost=data["values"][0,5,-1]
        self.minrad,self.maxrad=data["radius"][[0,-1]]
    def fields(self,clock,rad,slots,dt=0,dr=0):
        assert self.minrad<=rad<=self.maxrad and -.000001<=clock<=6.500001
        vals=np.array([self.curves[slot].ev(clock,rad,dx=dt,dy=dr).item() for slot in slots])
        if self.reference:
            for idx,slot in enumerate(slots):
                if slot>=5:vals[idx]=self.mass_cost if (slot,dt,dr)==(5,0,0) else 0.
        return vals


def varied(model,clock,rad,tc,rc,slots,deltas,order=0):
    get=model.fields
    vals=get(clock,rad,slots,dr=order)
    changes=(get(clock,rad,deltas,dr=order)+tc*get(clock,rad,slots,dt=1,dr=order)+rc*get(clock,rad,slots,dr=1+order))
    return vals+1j*EPS*changes


def quantities(model,state,read=False):
    clock,rad,imp,tc,rc,dp=state
    vals=varied(model,clock,rad,tc,rc,[0,1],[5,6])
    deriv=varied(model,clock,rad,tc,rc,[0,1],[5,6],1)
    rs=rad+1j*EPS*rc;ps=imp+1j*EPS*dp
    mass,lapse=vals;lapse+=1.
    factor=1-2*mass/rs
    slope=2*mass/rs**2-2*deriv[0]/rs
    lor=np.sqrt(1+factor*ps**2);alpha=lapse*np.sqrt(factor)
    tdot=lor/alpha;rvel=factor*ps
    pdot=-lor**2*deriv[1]/lapse-(1+2*factor*ps**2)*slope/(2*factor)
    if not read:
        vel=np.array([tdot,rvel,pdot])
        return np.r_[vel.real,vel.imag/EPS]
    field,pi,grad=varied(model,clock,rad,tc,rc,[2,3,4],[7,8,9])
    wave,pm,xr=model.fields(clock,rad,[10,11,12])
    charge=model.charge
    local_speed=np.sqrt(factor.real)*imp
    boosted=lor.real*pm+local_speed*xr
    xboost=lor.real*xr+local_speed*pm
    hdot=lor*np.sqrt(factor)*pi+rvel*grad
    radial=-2*mass/rs**3+2*charge**2/rs**4+factor*(pi**2-grad**2)
    ricci=2*hdot**2-field**2+charge**2/rs**4
    direct_r=4*NORM*wave**2/rad**4
    direct_tr=NORM*(factor.real*(boosted**2+xboost**2)/rad**2+2*wave**2/rad**4)
    twist=2*(charge*wave-model.inside)/rad**3
    derivative=2*charge*(lapse.real*factor.real*pm*tdot.real+xr*rvel.real)/rad**3-3*twist*rvel.real/rad
    return [radial.real,(ricci.real-radial.real)/2,radial.imag/EPS+direct_r,ricci.imag/EPS+direct_tr,
            twist,derivative,rvel.real/rad,field.real,field.imag/EPS,hdot.real,hdot.imag/EPS,direct_tr,direct_r]


def follow(model,site,end=6.4,count=513):
    tau=np.linspace(0,end,count)
    sol=solve_ivp(lambda _,state:quantities(model,state),(0,end),[0.,site,0.,0.,0.,0.],method="DOP853",
                  rtol=1e-11,atol=[2e-14,2e-14,2e-17,1e-17,1e-17,1e-18],max_step=.16,t_eval=tau)
    assert sol.success and sol.y[0,-1]<6.5
    forcing=np.array([quantities(model,state,True) for state in sol.y.T])
    return tau,sol.y.T,forcing


def run(mesh,eta,amp,reference):
    model=Strip(mesh,eta,amp,reference)
    positions=[];series=[]
    for site in (5.5,6.,7.):
        tau,state,force=follow(model,site)
        positions.append(state);series.append(force)
    key=name(mesh,eta,amp)+("-ref" if reference else "")
    with (HERE/f"path-{key}.npz").open("xb") as stream:
        np.savez_compressed(stream,tau=tau,state=positions,force=series,sites=[5.5,6.,7.],
                            states=["t","r","pr","delta_t","delta_r","delta_pr"],
                            quantities=["Er","Et","delta_Er","delta_Ric","omega","dot_omega","r_rate","h","delta_h","h_rate","delta_h_rate","direct_EM_trace","direct_EM_radial"])
    print(key,flush=True)


if __name__=="__main__":
    guard()
    for mesh in (960,1920):
        for eta,amp in ARMS:
            run(mesh,eta,amp,False)
            if not amp:run(mesh,eta,amp,True)
    run(1920,0.,0.,False)

