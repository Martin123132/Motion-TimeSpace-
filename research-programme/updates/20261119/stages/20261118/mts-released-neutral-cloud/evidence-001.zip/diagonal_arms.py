from strip import HERE, SRC, guard, np, peak, source, write
from killing import difference
from scipy.interpolate import RectBivariateSpline, make_interp_spline


def integrate(time, values):
    primitive = make_interp_spline(time, values, axis=0, k=5).antiderivative()
    return primitive(time) - primitive(0.)


def magnetic(clock, rate, jr, jt):
    return 4 * jt**2 / (jr**2+jt**2) * integrate(clock, rate*jr/jt)


def matrix_arm(jr, jt, cross_r, cross_t, flip=False, rotate=0.):
    hand = -1 if flip else 1
    cosine, sine = np.cos(rotate), np.sin(rotate)
    def length_slope(sign):
        xx, yy, dx, dy = jr, sign*jt, sign*cross_r, cross_t
        rx, ry = cosine*xx-sine*yy, sine*xx+cosine*yy
        rdx, rdy = cosine*dx-sine*dy, sine*dx+cosine*dy
        return (rx*rdx+ry*rdy)/(rx**2+ry**2)
    return length_slope(hand)-length_slope(-hand)


def main():
    guard()
    table, rows, differences = {}, [], []
    for path in sorted(HERE.glob("path-*.npz")):
        label = path.stem[5:]
        parts = label.split("-")
        mesh, eta, amp = int(parts[0]), float(parts[1][3:]), float(parts[2][1:])
        emits = eta != 0 and "ref" not in parts
        if emits:
            with np.load(source(SRC,f"driven-{mesh}-eta{eta:g}-h{amp:g}-spin0.npz")) as wave:
                field = RectBivariateSpline(wave["time"],wave["radius"],wave["fields"][:,0],kx=5,ky=5)
        with np.load(path) as clocks, np.load(HERE/f"cloud-{label}.npz") as measured:
            time = clocks["tau"]
            for idx, radius in enumerate(clocks["sites"]):
                state = clocks["state"][idx]
                jr,jt,_,xx,yy = measured["results"][idx,:,9:14].T
                location = state[:,1]
                rate = 2*.002*eta*field.ev(state[:,0], location)/location**3 if emits else np.zeros_like(time)
                forecast = magnetic(time, rate, jr, location/radius)
                found = matrix_arm(jr,jt,xx,yy)
                rows.append(dict(run=label, radius=radius, final=found[-1], peak=peak(found),
                                 field_to_arms=difference(found,forecast), rotated=difference(matrix_arm(jr,jt,xx,yy,rotate=.71),found),
                                 swapped=difference(matrix_arm(jr,jt,xx,yy,flip=True),-found)))
                table[(mesh,eta,amp,"ref" in parts,radius)] = (forecast,found)

    for row in rows:
        parts = row["run"].split("-")
        first, other = int(parts[0]), 2880-int(parts[0])
        key = (float(parts[1][3:]),float(parts[2][1:]),"ref" in parts,row["radius"])
        if (other,*key) not in table:
            row["mesh_arms"] = ""
        else:
            row["mesh_arms"] = difference(table[(960,*key)][1],table[(1920,*key)][1])
    for amp in (.00625,1.):
        for radius in (5.5,6.,7.):
            def contrast(mesh):
                lhs=table[(mesh,.8,amp,False,radius)]
                rhs=table[(mesh,.8,0.,False,radius)]
                return tuple(left-right for left,right in zip(lhs,rhs))
            coarse, fine = contrast(960),contrast(1920)
            errors=[difference(fine[1],fine[0]),difference(coarse[1],fine[1]),difference(coarse[0],fine[0])]
            differences.append(dict(amp=amp,radius=radius,measured_final=fine[1][-1],peak=peak(fine[1]),
                                    field_to_arms=errors[0],mesh_arms=errors[1],mesh_field=errors[2],
                                    meets_frozen_gate=max(errors)<=2e-5))
    write("diagonal_arms.csv", rows)
    write("diagonal_contrasts.csv",differences)
    print("absolute",max(row["field_to_arms"] for row in rows),"contrast",differences)


if __name__ == "__main__": main()

