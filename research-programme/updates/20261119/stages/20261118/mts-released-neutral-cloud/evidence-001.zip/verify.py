from strip import ARMS, CH, HERE, LOCK, PARENT, SRC, TOL, csv, guard, json, name, np, peak, sha, source, sys


def table(stem, count):
    with (HERE/f"{stem}.csv").open(newline="",encoding="utf8") as stream:
        rows=list(csv.DictReader(stream))
    assert len(rows)==count and all(None not in row for row in rows),stem
    return rows


def verify():
    guard()
    inputs={}
    checks={}
    def test(label,ok):
        assert label not in checks and bool(ok),label
        checks[label]=True
    def link(folder,member):
        path=source(folder,member)
        inputs[folder.name+"/"+member]=sha(path)
        return path
    for folder,members in ((PARENT,("common.py","matter_tangent.py","higher.py","conserved.py","exact_exterior.py","CONSTRAINTS.md")),
                           (SRC,("current_source.py","radiate.py")),(CH,("charged.py",))):
        inputs[folder.name+"/closeout.json"]=sha(folder/"closeout.json")
        for member in members:link(folder,member)
    test("immediate parent is the retained tidal solution",sha(PARENT/"closeout.json")==LOCK)
    volumes=table("volume_checks",39)
    rates=table("killing_readout",39)
    arms=table("diagonal_arms",39)
    expected=set()
    for mesh in (960,1920):
        for eta,amp in ARMS+(((0.,0.),) if mesh==1920 else ()):
            tag=name(mesh,eta,amp)
            link(CH,f"charged-{tag}-b1.npz")
            link(SRC,f"driven-{tag}-spin0.npz")
            high=link(PARENT,f"higher-{tag}-s0.npz")
            if eta==.8:link(SRC,f"core-{tag}.npz")
            with np.load(HERE/f"strip-{tag}.npz") as strip,np.load(high) as previous:
                test("strip provenance "+tag,str(strip["seal"])==sha(high) and strip["time"].size==257)
                for index,rad in enumerate(previous["radius"]):
                    site=np.flatnonzero(strip["radius"]==rad).item()
                    test(f"saved mass and scalar momentum {tag} {rad}",
                         np.array_equal(strip["values"][:,5,site],previous["delta"][0,0,index]+previous["exterior_dm"][:,index])
                         and np.array_equal(strip["values"][:,8,site],previous["delta"][:,11,index]))
            for suffix in (("","-ref") if not amp and eta else ("",)):
                key=tag+suffix
                with np.load(HERE/f"cloud-{key}.npz") as cloud,np.load(HERE/f"path-{key}.npz") as path:
                    data=cloud["results"]
                    test("proper time and release "+key,np.array_equal(cloud["tau"],path["tau"]) and len(cloud["tau"])==513
                         and list(cloud["sites"])==[5.5,6.,7.] and cloud["tau"][-1]==6.4
                         and np.isfinite(data).all() and np.all(data[:,:,9:11]>0) and np.all(data[:,0,:9]==0))
                    for idx,radius in enumerate(cloud["sites"]):
                        expected.add((key,radius))
                        data_row=data[idx]
                        v=next(row for row in volumes if row["run"]=="path-"+key and float(row["radius"])==radius)
                        k=next(row for row in rates if row["run"]==key and float(row["radius"])==radius)
                        a=next(row for row in arms if row["run"]==key and float(row["radius"])==radius)
                        for col in ("det_check","axial_det_check","axial_shear_check"):assert float(v[col])<TOL
                        for col in ("rate","frame_angle","angular_stretch","azimuthal_column","radial_column"):assert float(k[col])<TOL
                        for col in ("field_to_arms","rotated","swapped","mesh_arms"):
                            assert a[col]=="" or float(a[col])<TOL
                        test(f"absolute delivered observables {key} R{radius}",
                             float(v["final_total"])==data_row[-1,0] and
                             peak(data_row[:,0]-data_row[:,1])<TOL*peak(data_row[:,0]) and
                             peak(data_row[:,0]-data_row[:,3:7].sum(axis=1))<TOL*peak(data_row[:,0]) and
                             ((float(a["peak"])==float(k["peak_rate"])==0 and peak(data_row[:,7])==0)
                              if not eta or suffix else (float(a["peak"])>0 and float(k["peak_rate"])>0)))
    test("all matrix entries covered",len(expected)==39)
    for row in table("ancestor_ruler",9):
        test("unchanged ancestor clock and rulers "+row["run"],max(float(row[k]) for k in ("radius_drift","radial_stretch","transverse_stretch","log_volume"))<TOL)
    for label,number,columns in (("early_quartic",15,("relative_miss",)),("paired_quartic",6,("relative_miss",)),
                                 ("newton_limit",3,("fractional_change_error","unperturbed_volume_error")),
                                 ("kerr_cloud",8,("ray_vs_exact","finite_spin_change","latitude_change","normalization_error","optical_step_change")),
                                 ("area_check",30,("unspun_error","full_error"))):
        records=table(label,number)
        for idx,row in enumerate(records):
            test(f"{label} {idx}",max(float(row[k]) for k in columns)<TOL)
        if label=="kerr_cloud":
            ends=[row for row in records if float(row["proper"])==2.4]
            test("both exact spin controls discriminate against omitting angular shear",
                 len(ends)==2 and all(float(row["ignore_axial_error"])>TOL for row in ends) and
                 float(ends[0]["geodesic_volume"])*float(ends[1]["geodesic_volume"])<0)
        if label=="newton_limit":
            test("neutral finite-time solution discriminates against quartic-only approximation",all(float(row["quartic_fractional_miss"])>TOL for row in records))
    with np.load(HERE/"paired_waveforms.npz") as packed:
        curves=packed["results"]
        assert curves.shape==(24,513,7)
        for idx,row in enumerate(table("paired_volumes",24)):
            low,high=idx%12,idx%12+12
            signal=curves[idx,:,0]
            test(f"paired volume on own scale {idx}",np.isfinite(curves[idx]).all() and float(row["final"])==signal[-1]
                 and peak(curves[idx,:,5]-signal)/peak(signal)<TOL
                 and peak(curves[low,:,0]-curves[high,:,0])/peak(curves[high,:,0])<TOL)
    with np.load(HERE/"repaired.npz") as packed:
        repaired=packed["curves"]
        for idx,row in enumerate(table("repaired_volumes",12)):
            low,high=idx%6,idx%6+6
            base=repaired[high]
            relative=np.max(abs(repaired[low]-base),axis=0)/np.max(abs(base),axis=0)
            test(f"repaired volume and separately scored components {idx}",
                 relative[0]<TOL and abs(float(row["mesh_photon"])-relative[1])<1e-14 and
                 abs(float(row["mesh_axial"])-relative[2])<1e-14 and float(row["final"])==repaired[idx,-1,0] and
                 peak(repaired[idx,:,0]-repaired[idx,:,3])<TOL*peak(repaired[idx,:,0]))
            if float(row["amp"])==1.:assert max(relative)<TOL
            if float(row["amp"])<1 and float(row["site"]) in (5.5,6.):
                assert min(relative[1:3])>TOL
    with np.load(HERE/"paired_arms.npz") as bundle:
        curves=bundle["curves"]
        for idx,row in enumerate(table("paired_arms",12)):
            low,high=idx%6,idx%6+6
            delta=np.max(abs(curves[high]-curves[low]),axis=0)/np.max(abs(curves[high]),axis=0)
            cross=peak(curves[idx,:,0]-curves[idx,:,1])/peak(curves[idx,:,0])
            passed=max(max(delta),cross,float(row["clock_reconstruction"]))<=TOL
            test(f"signed differential arms, including failed inner weak row {idx}",
                 (row["meets_frozen_gate"]=="True")==passed and passed==(float(row["amp"])==1. or float(row["radius"])!=5.5)
                 and curves[idx,-1,0]==float(row["final"]))
    for idx,row in enumerate(table("diagonal_contrasts",6)):
        test(f"raw diagonal contrast {idx}",(row["meets_frozen_gate"]=="True")==
             (max(float(row[k]) for k in ("mesh_field","mesh_arms","field_to_arms"))<=TOL))
    for idx,row in enumerate(table("area_differences",18)):
        ok=float(row["discrepancy"])<=TOL
        test(f"independent geometry contrast honestly classified {idx}",ok==(row["meets_frozen_gate"]=="True")
             and (row["mode"]!="ordinary-minus-matched-mass" or ok))
    test("fine raw area contrasts not substituted for convergence",
         all(float(row["discrepancy"])>TOL for row in table("area_differences",18) if row["mesh"]=="1920" and row["mode"]!="ordinary-minus-matched-mass"))
    for script in HERE.glob("*.py"):compile(script.read_text(encoding="utf8"),str(script),"exec")
    test("no abandoned scratch files or bytecode in release folder",
         not any(p.is_dir() or p.suffix.lower() not in (".py",".npz",".csv",".md",".json") for p in HERE.iterdir()))
    return {"scope":"accepted observables and explicitly recorded numerical misses; not a universal convergence or empirical claim",
            "tolerance":TOL,"checks":checks,"parents":inputs,"files":{p.name:sha(p) for p in sorted(HERE.iterdir()) if p.name!="closeout.json"}}


if __name__=="__main__":
    assert sys.flags.optimize==0
    manifest=HERE/"closeout.json"
    result=verify()
    if sys.argv[1:]==["--seal"]:
        with manifest.open("x",encoding="utf8") as stream:json.dump(result,stream,indent=2,sort_keys=True);stream.write("\n")
    else:
        assert not sys.argv[1:] and json.loads(manifest.read_text(encoding="utf8"))==result
    print("verified",len(result["checks"]),"checks",len(result["files"]),"files",len(result["parents"]),"parent inputs",sha(manifest))

