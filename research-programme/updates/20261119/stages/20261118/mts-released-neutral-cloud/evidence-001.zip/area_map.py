from trajectory import *
from strip import peak
from scipy.interpolate import make_interp_spline


class Jet:
    __slots__=("val","spin","launch","cross")
    def __init__(self,val,spin=0.,launch=0.,cross=0.):
        self.val=val;self.spin=spin;self.launch=launch;self.cross=cross
    def __add__(self,other):
        if not isinstance(other,Jet):return Jet(self.val+other,self.spin,self.launch,self.cross)
        return Jet(self.val+other.val,self.spin+other.spin,self.launch+other.launch,self.cross+other.cross)
    __radd__=__add__
    def __neg__(self):return Jet(-self.val,-self.spin,-self.launch,-self.cross)
    def __sub__(self,other):return self+(-other)
    def __rsub__(self,other):return other+(-self)
    def __mul__(self,other):
        if not isinstance(other,Jet):return Jet(self.val*other,self.spin*other,self.launch*other,self.cross*other)
        return Jet(self.val*other.val,self.spin*other.val+self.val*other.spin,self.launch*other.val+self.val*other.launch,
                   self.cross*other.val+self.spin*other.launch+self.launch*other.spin+self.val*other.cross)
    __rmul__=__mul__
    def power(self,expo):
        base=self.val**expo;first=expo*base/self.val
        return Jet(base,first*self.spin,first*self.launch,first*(self.cross+(expo-1)*self.spin*self.launch/self.val))
    def __truediv__(self,other):return self*(other.power(-1) if isinstance(other,Jet) else 1/other)
    def __rtruediv__(self,other):return self.power(-1)*other
    def row(self):return [self.val,self.spin,self.launch,self.cross]


class Coeff:
    def __init__(self,mesh,eta,amp,ref=False):
        data=dict(np.load(HERE/f"strip-{name(mesh,eta,amp)}.npz"))
        time,radius=data["time"],data["radius"]
        self.splines=[];self.offset=[]
        for idx in (0,1,5,6):
            table=data["values"][:,idx].copy()
            if ref and idx>=5:table[:]=table[0,-1] if idx==5 else 0.
            offset=table[0,-1]
            self.offset.append(offset)
            self.splines.append(RectBivariateSpline(time,radius,table-offset,kx=5,ky=5,s=0))
    def jet(self,slot,t,r,order):
        fun=self.splines[slot];dfun=self.splines[slot+2]
        def partial(dt,dr,curve=fun):
            return curve.ev(t.val,r.val,dx=dt,dy=dr+order).item()
        deriv_t=partial(1,0);deriv_r=partial(0,1)
        val=partial(0,0)+(0. if order else self.offset[slot])
        ds=partial(0,0,dfun)+(0. if order else self.offset[slot+2])
        return Jet(val,deriv_t*t.spin+deriv_r*r.spin+ds,deriv_t*t.launch+deriv_r*r.launch,
                   deriv_t*t.cross+deriv_r*r.cross+partial(2,0)*t.spin*t.launch+
                   partial(1,1)*(t.spin*r.launch+t.launch*r.spin)+partial(0,2)*r.spin*r.launch+
                   partial(1,0,dfun)*t.launch+partial(0,1,dfun)*r.launch)
    def rhs(self,tau,state,report=False):
        clock,rad,imp=(Jet(*row) for row in state.reshape(3,4))
        mass=self.jet(0,clock,rad,0);lapse=1+self.jet(1,clock,rad,0)
        factor=1-2*mass/rad
        fp2=factor*imp*imp;lor=(1+fp2).power(.5)
        if report:return rad,lor,factor
        fr=2*(mass/rad-self.jet(0,clock,rad,1))/rad
        pdot=-(1+fp2)*self.jet(1,clock,rad,1)/lapse-(1+2*fp2)*fr/(2*factor)
        return np.r_[(lor/(lapse*factor.power(.5))).row(),(factor*imp).row(),pdot.row()]


def solve(model,site,tau):
    init=np.array([Jet(0.).row(),Jet(site,launch=1.).row(),Jet(0.).row()]).ravel()
    sol=solve_ivp(model.rhs,(0,tau[-1]),init,t_eval=tau,method="DOP853",rtol=2e-12,
                  atol=np.array([[3e-14,3e-18,2e-15,3e-19],[3e-15,3e-18,2e-15,3e-19],[1e-17,3e-19,3e-17,3e-20]]).ravel(),max_step=.068)
    assert sol.success
    initial=model.rhs(0.,init,True)[2]
    out=[]
    for clock,state in zip(tau,sol.y.T):
        rad,lor,fac=model.rhs(clock,state,True)
        log0=2*np.log(rad.val/site)-.5*np.log(fac.val/initial.val)-np.log(lor.val)+np.log(rad.launch)
        log2=2*rad.spin/rad.val-.5*(fac.spin/fac.val-initial.spin/initial.val)-lor.spin/lor.val+rad.cross/rad.launch
        out.append([log0,log2,rad.val,rad.spin,rad.launch,rad.cross])
    return np.array(out)


def main():
    guard();rows=[];allseries=[]
    for mesh in (960,1920):
        for eta,amp,ref in ((1.,0.,False),(.8,0.,False),(.8,1/160,False),(.8,1.,False),(.8,0.,True)):
            key=name(mesh,eta,amp)+("-ref" if ref else "")
            model=Coeff(mesh,eta,amp,ref)
            data=dict(np.load(HERE/f"cloud-{key}.npz"))
            saved=[]
            for idx,site in enumerate(data["sites"]):
                out=solve(model,site,data["tau"])
                result=data["results"][idx]
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,ref=ref,radius=site,
                                 unspun_error=peak(out[:,0]-result[:,8])/peak(result[:,8]),
                                 full_error=peak(out[:,1]-result[:,0])/peak(result[:,0]),
                                 signal_peak=peak(result[:,0]),final=out[-1,1]))
                saved.append(out)
            allseries.append(saved)
    write("area_check.csv",rows)
    with (HERE/"area_series.npz").open("xb") as stream:np.savez_compressed(stream,result=allseries)
    print("worst",max(row["full_error"] for row in rows),max(row["unspun_error"] for row in rows))


if __name__=="__main__":main()

