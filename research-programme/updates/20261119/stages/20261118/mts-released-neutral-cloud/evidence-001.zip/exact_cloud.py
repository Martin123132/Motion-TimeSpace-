from strip import *
from trajectory import follow
from cloud import optical, matrix
from paired import advance
from exact_exterior import evaluator
from scipy.special import roots_legendre
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
import math

SITE=4.5
TIMES=np.array([.6,1.2,1.8,2.4])


class Stationary:
    def __init__(self,charge):
        self.charge=charge;self.inside=1.5
    def fields(self,clock,rad,slots,dt=0,dr=0):
        charge=self.charge
        terms={0:[(0,1),(1,-charge**2/2)],5:[(3,-(charge**2+3)/3),(4,7*charge**2/6),(5,-charge**4/3)],
               6:[(4,-NORM*charge**2/4)],10:[(1,charge)],12:[(2,-charge)]}
        def value(slot):
            if dt:return 0.
            return sum(coef*(-1)**dr*math.prod(range(power,power+dr))/rad**(power+dr) for power,coef in terms.get(slot,[]))
        return np.array([value(slot) for slot in slots])


def jets_at(jets,rad,pol,charge,spin):
    terms=np.asarray(jets(rad,pol,1.,charge,spin)).reshape(6,5)
    mats=np.zeros((6,4,4))
    for idx,(first,second) in enumerate(((0,0),(0,3),(1,1),(2,2),(3,3))):
        mats[:,first,second]=mats[:,second,first]=terms[:,idx]
    metric=mats[0]
    inv=np.linalg.inv(metric)
    first=np.zeros((4,4,4));first[1:3]=mats[1:3]
    dg=-inv@first@inv
    second=np.zeros((2,2,4,4))
    for idx,jdx,slot in ((0,0,3),(0,1,4),(1,1,5)):
        product=inv@first[idx+1]@inv@first[jdx+1]@inv
        second[idx,jdx]=second[jdx,idx]=product+product.T-inv@mats[slot]@inv
    return metric,inv,first,dg,second


def direct(jets,rad,pol,charge,spin):
    metric,inv,grad,_,_=jets_at(jets,rad,pol,charge,spin)
    u=-inv[0]/np.sqrt(-inv[0,0])
    impulse=metric@u
    axes=np.eye(4)[:,1:]/np.sqrt(np.diag(metric)[1:])
    gamma=(grad.transpose(1,0,2)+grad.transpose(1,2,0)-grad)/2
    pi0=np.einsum("m,maj,jk->ak",u,gamma,axes)
    init=np.r_[[0.,rad,pol,0.],impulse,axes.ravel(),pi0.ravel()]
    def rhs(tau,state):
        coords,mom=state[:4],state[4:8]
        sep,response=state[8:].reshape(2,4,3)
        _,inv,_,dg,dd=jets_at(jets,coords[1],coords[2],charge,spin)
        cross=dg@mom
        dpos=inv@response+cross.T@sep
        dmom=-cross@response
        dmom[1:3]-=.5*np.einsum("i,abij,j->ab",mom,dd,mom)@sep[1:3]
        return np.r_[inv@mom,-.5*(cross@mom),dpos.ravel(),dmom.ravel()]
    sol=solve_ivp(rhs,(0.,TIMES[-1]),init,t_eval=TIMES,method="DOP853",rtol=8e-13,atol=5e-15,max_step=.30)
    assert sol.success
    result=[];errors=[]
    for state in sol.y.T:
        metric,inv,*_=jets_at(jets,state[1],state[2],charge,spin)
        frame=state[8:20].reshape(4,3)
        gram=frame.T@metric@frame
        sign,logdet=np.linalg.slogdet(gram)
        assert sign>0
        result.append(logdet/2)
        errors.append(max(peak(state[4:8]@frame),abs(state[4:8]@inv@state[4:8]+1)))
    return np.array(result),max(errors)


def sky(jets,charge,spin,nlat):
    cos,weights=roots_legendre(nlat)
    def elem(rad):
        disc=rad**2-2*rad+spin**2+charge**2
        return np.sqrt((rad**2+spin**2)**2-disc*spin**2*(1-cos**2))
    radius=brentq(lambda rad:np.dot(weights,elem(rad))/2-SITE**2,SITE-.1,SITE+.1,xtol=2e-14)
    avg=np.zeros(len(TIMES));constraint=0.
    for mu,weight in zip(cos[cos>=0],(weights*elem(radius)/SITE**2)[cos>=0]):
        value,err=direct(jets,radius,np.arccos(mu),charge,spin)
        avg+=weight*value
        constraint=max(err,constraint)
    return avg,constraint


def main():
    guard()
    jets=evaluator();rows=[]
    for charge in (0.,.6):
        tau,state,fields=follow(Stationary(charge),SITE,end=2.4,count=481)
        ray=advance(tau,fields,fields,"ray",2).real
        refined=advance(tau,fields,fields,"ray",4).real
        jac=matrix(tau,fields,2)
        take=np.array([np.argmin(abs(tau-t)) for t in TIMES])
        sectors=refined[take,1:]
        prediction=sectors.sum(axis=1)
        estimates=[]
        for nlat in (8,12):
            base,invariant=sky(jets,charge,0.,nlat)
            runs=[]
            for spin in (.12,.06,.03):
                actual,err=sky(jets,charge,spin,nlat)
                invariant=max(invariant,err);runs.append((actual-base)/spin**2)
            first=(4*runs[1]-runs[0])/3;fine=(4*runs[2]-runs[1])/3
            estimates.append(fine)
        norm=peak(prediction)
        for idx,clock in enumerate(TIMES):
            rows.append(dict(charge=charge,proper=clock,prediction=prediction[idx],determinant=jac["volume"][take[idx],0],
                             geodesic_volume=fine[idx],ray_vs_exact=abs(prediction[idx]-fine[idx])/norm,
                             finite_spin_change=abs(first[idx]-fine[idx])/norm,latitude_change=abs(estimates[0][idx]-estimates[1][idx])/norm,
                             ignore_axial_error=abs(prediction[idx]-sectors[idx,3]-fine[idx])/norm,
                             polarization_shear_piece=sectors[idx,3],ricci_piece=sum(sectors[idx,:2]),normalization_error=invariant,
                             optical_step_change=abs(ray[take[idx],0]-refined[take[idx],0])/norm,
                             true_baseline=base[idx],jacobi_baseline=np.log(jac["J0"][take[idx],0])+2*np.log(jac["J0"][take[idx],1])))
    write("kerr_cloud.csv",rows);print(rows[-1]);print("worst",max(row["ray_vs_exact"] for row in rows))


if __name__=="__main__":main()

