from strip import HERE, SRC, guard, np, peak, source, write
from scipy.interpolate import RectBivariateSpline, make_interp_spline


def difference(actual, predicted):
    scale = peak(predicted)
    return peak(actual - predicted) / scale if scale else peak(actual)


def evaluate():
    from functools import lru_cache

    @lru_cache(maxsize=1)
    def dipole(mesh, eta, amplitude):
        archive = source(SRC, f"driven-{mesh}-eta{eta:g}-h{amplitude:g}-spin0.npz")
        with np.load(archive) as wave:
            return RectBivariateSpline(wave["time"], wave["radius"], wave["fields"][:, 0], kx=5, ky=5)

    rows = []
    for path in sorted(HERE.glob("path-*.npz")):
        label = path.stem.removeprefix("path-")
        parts = label.split("-")
        mesh, eta, amplitude = int(parts[0]), float(parts[1][3:]), float(parts[2][1:])
        charged_emission = eta != 0 and "ref" not in parts
        with np.load(path) as clocks, np.load(HERE / f"cloud-{label}.npz") as cloud:
            time = clocks["tau"]
            for radius, state, fields, results in zip(clocks["sites"], clocks["state"], clocks["force"], cloud["results"]):
                position = state[:, 1]
                jr, jt, angle, cross_r, cross_t = results[:, 9:14].T
                field = (2 * dipole(mesh, eta, amplitude).ev(state[:, 0], position) / position**2
                         if charged_emission else np.zeros_like(time))
                rate = .002 * eta * field / position
                assert abs(rate[0]) < 1e-30 and abs(fields[0, 4]) < 1e-30
                angle_t = make_interp_spline(time, rate, k=5).antiderivative()
                gamma = angle_t(time) - angle_t(0.)
                stretch_t = position / radius
                twist_t = make_interp_spline(time, rate * jr / stretch_t, k=5).antiderivative()
                shifted = 2 * stretch_t * (twist_t(time) - twist_t(0.))
                rows.append(dict(run=label, radius=radius, source="emitting" if charged_emission else "null",
                                 terminal_rate=rate[-1], peak_rate=peak(rate), peak_cross=peak(shifted),
                                 angular_stretch=difference(jt, stretch_t), rate=difference(results[:, 7], rate),
                                 frame_angle=difference(angle, gamma), azimuthal_column=difference(cross_r, stretch_t*gamma),
                                 radial_column=difference(cross_t+angle*jr, shifted)))
    write("killing_readout.csv", rows)
    print({key: max(row[key] for row in rows) for key in ("angular_stretch","rate","frame_angle","azimuthal_column","radial_column")})


def area_contrasts():
    with np.load(HERE / "area_series.npz") as area, np.load(HERE / "paired_waveforms.npz") as pair:
        areas, waves = area["result"], pair["results"]
        assert areas.shape == (10,3,513,6) and waves.shape == (24,513,7)
        rows = []
        for level, mesh in enumerate((960,1920)):
            for mode, left, right, couple in (("1/160-minus-ordinary",2,1,0),("full-minus-ordinary",3,1,1),
                                               ("ordinary-minus-matched-mass",1,4,2)):
                direct = areas[5*level+left,:,:,1] - areas[5*level+right,:,:,1]
                for idx, radius in enumerate((5.5,6.,7.)):
                    reference = waves[12*level+3*couple+idx,:,0]
                    miss = difference(direct[idx], reference)
                    rows.append(dict(mesh=mesh,mode=mode,radius=radius,geometric_final=direct[idx,-1],
                                     paired_final=reference[-1],peak_reference=peak(reference),
                                     discrepancy=miss,meets_frozen_gate=miss<=2e-5))
        write("area_differences.csv",rows)


if __name__ == "__main__":
    guard()
    evaluate()
    area_contrasts()

