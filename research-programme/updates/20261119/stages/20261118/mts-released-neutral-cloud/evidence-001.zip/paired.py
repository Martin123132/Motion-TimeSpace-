from cloud import *


def prod(left,right):
    return left.real*right.real+1j*(left.imag*right.real+(left.real+left.imag)*right.imag)


def ratio(num,den):
    base=num.real/den.real
    return base+1j*(num.imag-base*den.imag)/(den.real+den.imag)


def coupled_ray(state,force):
    er,et,der,trace,omega,_,speed=force[:7]
    br,bt,extra=state[:3]
    radial,expand,vol=state[3:].reshape(3,4)
    shear=extra+omega
    source1=np.array([0.,0.,der,NORM*prod(shear,shear+2*omega)])
    source2=np.array([force[11],trace-force[11],0.,2*NORM*prod(shear,shear)])
    return np.r_[-er-prod(br,br),-et-prod(bt,bt),-prod(br+bt,extra)+2*prod(speed-bt,omega),
                 -2*prod(br,radial)-source1,-2*prod(bt,expand)-2*prod(br-bt,radial)-source2,expand]


def coupled_matrix(state,force):
    er,et,der,trace,omega,odot,speed=force[:7]
    jr,jt,vr,vt,angle,crossr,crosst,rater,ratet=state[:9]
    qr,qt,dqr,dqt=state[9:].reshape(4,2)
    mix=-odot-2*prod(speed,omega)
    eup=mix+prod(angle,et-er)
    tilt=NORM*prod(angle,2*mix+prod(angle,et-er))
    rr=-prod(er,qr)-prod(jr,np.array([der+tilt,tilt]))-NORM*prod(eup,crosst)
    tt=-prod(et,qt)-prod(jt,np.array([trace-der-tilt,-tilt]))-NORM*prod(eup,crossr)
    return np.r_[vr,vt,-prod(er,jr),-prod(et,jt),omega,rater,ratet,
                 -prod(er,crossr)-prod(eup,jt),-prod(et,crosst)-prod(eup,jr),dqr,dqt,rr,tt]


def advance(tau,first,second,mode,sub,delta=None):
    step=tau[-1]/((len(tau)-1)*sub)
    times=np.linspace(0.,tau[-1],2*(len(tau)-1)*sub+1)
    force=interp(tau,first)(times)+1j*interp(tau,second-first if delta is None else delta)(times)
    if mode=="ray":
        rhs=coupled_ray
        state=np.zeros(15,dtype=complex);state[2]=-force[0,4]
    else:
        rhs=coupled_matrix
        state=np.zeros(17,dtype=complex);state[:2]=1.
    records=[]
    for tick in range((len(tau)-1)*sub+1):
        if tick%sub==0:
            if mode=="ray":
                sectors=state[11:15]
                records.append(np.r_[sum(sectors),sectors].copy())
            else:
                jr,jt,vr,vt,angle,crossr,crosst=state[:7]
                det=ratio(state[9:11],jr)+ratio(state[11:13],jt)-NORM*ratio(prod(crossr,crosst),prod(jr,jt))
                records.append(det.copy())
        if tick*2==len(force)-1:break
        ka=rhs(state,force[2*tick]);kb=rhs(state+step*ka/2,force[2*tick+1])
        kc=rhs(state+step*kb/2,force[2*tick+1]);kd=rhs(state+step*kc,force[2*tick+2])
        state+=step/6*(ka+2*kb+2*kc+kd)
    return np.array(records)


def readpath(key):return dict(np.load(HERE/f"path-{key}.npz"))


def main():
    guard()
    rows=[];results=[]
    for mesh in (960,1920):
        for eta,amp,ref in ((.8,1/160,False),(.8,1.,False),(.8,0.,True),(1.,0.,True)):
            second=readpath(name(mesh,eta,amp));first=readpath(name(mesh,eta,0.)+("-ref" if ref else ""))
            tau=first["tau"]
            for idx,site in enumerate(first["sites"]):
                pair=(tau,first["force"][idx],second["force"][idx])
                ray=advance(*pair,"ray",1)
                matrix=advance(*pair,"matrix",2)
                def discrepancy(lhs,rhs):
                    norm=peak(rhs)
                    return peak(lhs-rhs)/norm if norm>0 else peak(lhs)
                dr=ray.imag;dm=matrix.imag
                rows.append(dict(mesh=mesh,eta=eta,amp=amp,mode="equal-initial-mass" if ref else "scalar-minus-ordinary",radius=site,
                                 det_volume_error=discrepancy(dm[:,0],dr[:,0]),det_axial_error=discrepancy(dm[:,1],dr[:,-1]),
                                 peak=peak(dr[:,0]),final=dr[-1,0],axial_final=dr[-1,-1]))
                results.append(np.column_stack([dr,dm]))
    archive=np.array(results)
    for idx,row in enumerate(rows):
        neighbor=idx+12 if idx<12 else idx-12
        reference=archive[max(idx,neighbor)]
        for slot,label in enumerate(("volume","EM_trace","other_trace","anisotropy","axial","det_volume","det_axial")):
            norm=peak(reference[:,slot])
            row["mesh_"+label]=peak(archive[idx,:,slot]-archive[neighbor,:,slot])/(norm if norm else 1.)
    write("paired_volumes.csv",rows)
    with (HERE/"paired_waveforms.npz").open("xb") as stream:
        np.savez_compressed(stream,tau=tau,results=archive,keys=["volume","EM_trace","other_trace","anisotropy","axial","det_volume","det_axial"])
    print("worst",[(key,max(row[key] for row in rows)) for key in ("det_volume_error","det_axial_error","mesh_volume","mesh_EM_trace","mesh_axial")])


if __name__=="__main__":main()

