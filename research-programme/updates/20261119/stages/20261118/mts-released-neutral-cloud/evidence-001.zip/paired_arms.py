from synchronise import Matching, root
from paired import prod, ratio, readpath, name, interp, np, guard, HERE, write, peak
from diagonal_arms import integrate
from scipy.interpolate import make_interp_spline


def fields_for(mesh, amplitude, idx, histories):
    model=Matching(mesh, amplitude, repaired=True)
    base=readpath(name(mesh,.8,0.))
    variant=readpath(name(mesh,.8,amplitude))
    tau=base["tau"]
    state=base["state"][idx]
    changed=variant["force"][idx]
    first=base["force"][idx]
    er=first[:,0]+1j*(changed[:,0]-first[:,0])
    et=first[:,1]+1j*(changed[:,1]-first[:,1])
    clock_shift, radius_shift=histories[:,6:8].T
    radial_speed_shift=make_interp_spline(tau,radius_shift,k=5).derivative()(tau)
    output=[]
    for slot,(clock,radius,momentum) in enumerate(state[:,:3]):
        time=clock+1j*clock_shift[slot]
        position=radius+1j*radius_shift[slot]
        fac=1-2*ratio(model.at("M",time,position),position)
        delta_p=(radial_speed_shift[slot]-fac.imag*momentum)/(fac.real+fac.imag)
        qstate=np.array([clock,radius,momentum,clock_shift[slot],radius_shift[slot],delta_p])
        omega,derivative,drift,_=model.geodesic(0.,qstate,fields=True)
        output.append([er[slot],et[slot],omega,derivative,drift])
    return tau,np.array(output)


def transport(time, fields):
    def deriv(state, force):
        jr,jt,vr,vt,angle,xx,yy,vx,vy=state
        er,et,omega,odot,drift=force
        mixed=-odot-2*prod(drift,omega)+prod(angle,et-er)
        return np.array([vr,vt,-prod(er,jr),-prod(et,jt),omega,vx,vy,
                         -prod(er,xx)-prod(mixed,jt),-prod(et,yy)-prod(mixed,jr)])
    current=np.zeros(9,complex);current[:2]=1.
    h=(time[1]-time[0])/2
    samples=interp(time,fields.real)(np.linspace(0,time[-1],4*(len(time)-1)+1))+1j*interp(time,fields.imag)(np.linspace(0,time[-1],4*(len(time)-1)+1))
    output=[current.copy()]
    for tick in range(2*(len(time)-1)):
        start,mid,end=samples[2*tick:2*tick+3]
        ka=deriv(current,start);kb=deriv(current+ka*h/2,mid);kc=deriv(current+kb*h/2,mid);kd=deriv(current+kc*h,end)
        current+=h*(ka+2*kb+2*kc+kd)/6
        if tick%2:output.append(current.copy())
    jr,jt,_,_,_,xx,yy,_,_=np.array(output).T
    jt2=prod(jt,jt)
    denom=prod(jr,jr)+jt2
    signal=2*ratio(prod(jr,xx)+prod(jt,yy),denom)
    integrand=prod(fields[:,2],ratio(jr,jt))
    integral=integrate(time,integrand.real)+1j*integrate(time,integrand.imag)
    predicted=4*prod(ratio(jt2,denom),integral)
    return np.array([signal.imag,predicted.imag]).T


def main():
    guard()
    with np.load(HERE/"repaired.npz") as saved:histories=saved["curves"]
    traces=[];rows=[]
    for mesh in (960,1920):
        for amp in (.00625,1.):
            for idx,radius in enumerate((5.5,6.,7.)):
                history=histories[len(rows)]
                time,inputs=fields_for(mesh,amp,idx,history)
                curve=transport(time,inputs)
                rows.append(dict(mesh=mesh,amp=amp,radius=radius,final=curve[-1,0],peak=peak(curve[:,0]),
                                 crosscheck=peak(curve[:,1]-curve[:,0])/peak(curve[:,0]),
                                 clock_reconstruction=peak(inputs[:,2].imag-history[:,5])/peak(history[:,5])))
                traces.append(curve)
    traces=np.array(traces)
    for idx,row in enumerate(rows):
        low,high=idx%6,idx%6+6
        errors=np.max(abs(traces[high]-traces[low]),axis=0)/np.max(abs(traces[high]),axis=0)
        row["mesh_arms"],row["mesh_field"]=errors
        row["meets_frozen_gate"]=max(*errors,row["crosscheck"],row["clock_reconstruction"])<=2e-5
    write("paired_arms.csv",rows)
    with (HERE/"paired_arms.npz").open("xb") as out:np.savez_compressed(out,time=time,curves=traces)
    print(rows[-6:],flush=True)


if __name__=="__main__": main()

