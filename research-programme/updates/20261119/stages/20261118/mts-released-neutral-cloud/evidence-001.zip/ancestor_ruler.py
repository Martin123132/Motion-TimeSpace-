from strip import ARMS, CH, HERE, guard, name, np, source, write
from killing import difference
from scipy.interpolate import make_interp_spline


def main():
    guard()
    rows=[]
    for mesh in (960,1920):
        for eta,amplitude in ARMS+(((0.,0.),) if mesh==1920 else ()):
            tag=name(mesh,eta,amplitude)
            with np.load(source(CH,f"charged-{tag}-b1.npz")) as history, np.load(HERE/f"cloud-{tag}.npz") as cloud, np.load(HERE/f"path-{tag}.npz") as path:
                release=np.flatnonzero(history["labels"]==6.).item()
                idx=np.flatnonzero(cloud["sites"]==6.).item()
                data=history["events"][:,:,release]
                def column(key):
                    return data[:,list(history["keys"]).index(key)]
                clock=column("clock")
                tau=path["tau"]
                assert tau[0]==clock[0]==0 and tau[-1]<=clock[-1]
                assert max(abs(column(key)[0]) for key in ("Jr_offset","Jt_offset","radial_rate","angular_rate"))<1e-25
                raw=np.column_stack([column("radius")-6.,column("Jr_offset"),column("Jt_offset"),
                                     np.log1p(column("Jr_offset"))+2*np.log1p(column("Jt_offset"))])
                expected=make_interp_spline(clock,raw,axis=0,k=5)(tau)
                observed=cloud["results"][idx]
                measured=np.column_stack([path["state"][idx,:,1]-6.,observed[:,9]-1,observed[:,10]-1,observed[:,8]])
                errors=[difference(left,right) for left,right in zip(measured.T,expected.T)]
                rows.append(dict(run=tag,site=6.,clock_end=tau[-1],radius_drift=errors[0],radial_stretch=errors[1],
                                 transverse_stretch=errors[2],log_volume=errors[3],meets_frozen_gate=max(errors)<=2e-5))
    write("ancestor_ruler.csv",rows)
    print(rows)


if __name__=="__main__": main()

