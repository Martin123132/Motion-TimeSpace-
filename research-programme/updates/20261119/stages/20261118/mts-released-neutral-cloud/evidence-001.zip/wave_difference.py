from paired import prod
from strip import *
sys.path.insert(0,str(SRC))
from radiate import Core, gradient, TIMES
from scipy.interpolate import CubicSpline


def solve(mesh,amp):
    guard()
    core=Core(mesh,.8,0.,0)
    baseline=source(SRC,f"core-{mesh}-eta0.8-h0.npz")
    variant=source(SRC,f"core-{mesh}-eta0.8-h{amp:g}.npz")
    with np.load(baseline) as before,np.load(variant) as after:
        delta=CubicSpline(before["time"],after["background"]-before["background"],axis=0)
    inv=core.inv;rad=core.rad
    def terms(clock):
        material=core.interp(clock)+1j*delta(clock)
        b,fac,weight,density,label,vel,rho,scalar,br=material
        q=.8*label;x=label/.002
        base=x.real;shift=x.imag
        clamped=np.clip(base,0.,1.)
        change=np.where((base>=0)&(base<=1)&(base+shift>=0)&(base+shift<=1),shift,np.clip(base+shift,0.,1.)-clamped)
        occ=clamped+1j*change;ends=prod(occ,1-occ);square=prod(ends,ends)
        law=32*prod(square,1-2*occ)
        inside=.002*(32/3)*prod(square,ends)
        h=prod(weight,density)
        barrier=2*prod(fac,rho+scalar)+6*prod(fac,prod(q*inv**2,q*inv**2))+.8**2*h
        current=.8*prod(h,law)*inv**2+4*prod(fac,prod(q*inv**3,inside*inv**3))
        return core.coefficients(clock),np.array([b.imag,br.imag,barrier.imag,current.imag])
    use=(rad>=5.2)&(rad<=7.3)
    state=np.zeros((2,2,len(rad)));series=[];native=[]
    steps=int(np.ceil(6.5/(.22*core.spacing)/512))*512;dt=6.5/steps
    def right(state,coeff):
        base,diff=coeff
        hom=base+diff
        hom=hom.copy();hom[-1]=0.
        return np.stack([core.rhs(state[0],base),core.rhs(state[1],hom)+core.rhs(state[0],diff)])
    first=terms(0.)
    for tick in range(steps+1):
        if tick%(steps//512)==0:
            arrays=[]
            for val,mom in state:
                arrays.append(np.stack([rad**2*val,rad**2*mom,2*rad*val+rad**2*gradient(val,core.spacing)])[:,use])
            native.append(arrays[0]);series.append(arrays[1])
        if tick==steps:break
        mid=terms((tick+.5)*dt);last=terms((tick+1)*dt)
        ka=right(state,first);kb=right(state+dt/2*ka,mid);kc=right(state+dt/2*kb,mid);kd=right(state+dt*kc,last)
        state+=dt/6*(ka+2*kb+2*kc+kd);first=last
    series=np.array(series);native=np.array(native)
    with np.load(source(SRC,f"driven-{mesh}-eta0.8-h0-spin0.npz")) as one,np.load(source(SRC,f"driven-{mesh}-eta0.8-h{amp:g}-spin0.npz")) as two:
        assert np.array_equal(one["fields"][:,:,use],native)
        raw=two["fields"][:,:,use]-native
    with (HERE/f"source-difference-{mesh}-h{amp:g}.npz").open("xb") as stream:
        np.savez_compressed(stream,time=TIMES,radius=rad[use],wave_delta=series,raw_relative=peak(raw-series)/peak(series))
    print(mesh,amp,"coordinate difference vs raw",peak(raw-series)/peak(series),flush=True)


if __name__=="__main__":
    for mesh in (960,1920):
        for amp in (1/160,1.):solve(mesh,amp)

