from strip import *
from scipy.integrate import solve_ivp
from scipy.interpolate import make_interp_spline


def interp(tau,force):
    return make_interp_spline(tau,force,axis=0,k=5)


def optical(tau,force):
    coeff=interp(tau,force)
    def rhs(clock,state):
        er,et,der,drho,omega,odot,speed=coeff(clock)[:7]
        photons=coeff(clock)[11]
        radial,angular,_,_,extra=state[:5]
        sector=state[5:].reshape(3,4)
        dr,dtot=sector[:2]
        shear=extra+omega
        rs=-2*radial*dr-np.array([0.,0.,der,NORM*(shear**2+2*omega*shear)])
        ts=-2*angular*dtot-2*(radial-angular)*dr-np.array([photons,drho-photons,0.,2*NORM*shear**2])
        return np.r_[-er-radial**2,-et-angular**2,radial,angular,
                     -(radial+angular)*extra+2*(speed-angular)*omega,rs,ts,dtot]
    initial=np.zeros(17);initial[4]=-force[0,4]
    sol=solve_ivp(rhs,(0,tau[-1]),initial,method="DOP853",t_eval=tau,rtol=3e-11,
                  atol=[1e-15]*4+[1e-20]+[1e-22]*3+[1e-30]+[1e-22]*3+[1e-30]+[1e-22]*3+[1e-30],
                  max_step=tau[-1]/80)
    assert sol.success
    out=sol.y.T
    return dict(channels=out[:,13:17],shear=out[:,4]+force[:,4],logV0=out[:,2]+2*out[:,3],expansion=out[:,9:13])


def matrix(tau,force,sub=1):
    coeff=interp(tau,force)
    intervals=(len(tau)-1)*sub
    spacing=tau[-1]/intervals
    bank=coeff(np.linspace(0,tau[-1],2*intervals+1))
    def rhs(state,fields):
        er,et,change,trace,omega,odot,speed=fields[:7]
        jr,jt,vr,vt,angle,cross_r,cross_t,rate_r,rate_t=state[:9]
        qr,qt,dqr,dqt=state[9:].reshape(4,2)
        mixed=-odot-2*speed*omega
        ep=mixed+angle*(et-er)
        tilt=NORM*(2*angle*mixed+angle**2*(et-er))
        dd_r=-er*qr-np.array([change+tilt,tilt])*jr-NORM*ep*cross_t
        dd_t=-et*qt-np.array([trace-change-tilt,-tilt])*jt-NORM*ep*cross_r
        return np.r_[vr,vt,-er*jr,-et*jt,omega,rate_r,rate_t,-er*cross_r-ep*jt,-et*cross_t-ep*jr,dqr,dqt,dd_r,dd_t]
    state=np.zeros(17);state[:2]=1.
    saved=[state.copy()]
    for idx in range(intervals):
        first=rhs(state,bank[2*idx])
        second=rhs(state+spacing/2*first,bank[2*idx+1])
        third=rhs(state+spacing/2*second,bank[2*idx+1])
        fourth=rhs(state+spacing*third,bank[2*idx+2])
        state+=spacing/6*(first+2*second+2*third+fourth)
        if (idx+1)%sub==0:saved.append(state.copy())
    out=np.array(saved)
    jr,jt,_,_,angle,cross_r,cross_t,rate_r,rate_t=out[:,:9].T
    result=out[:,9:11]/jr[:,None]+out[:,11:13]/jt[:,None]-(NORM*cross_r*cross_t/(jr*jt))[:,None]
    shear_parallel=(rate_r-out[:,2]*cross_r/jr)/jt
    shear_horizontal=shear_parallel-angle*(out[:,3]/jt-out[:,2]/jr)
    return dict(volume=result,shear=shear_horizontal,angle=angle,J0=np.stack([jr,jt],axis=1),
                cross=np.stack([cross_r,cross_t],axis=1),cross_rates=np.stack([rate_r,rate_t],axis=1))


def execute(path):
    with np.load(path) as data:
        tau,states,force,sites=data["tau"],data["state"],data["force"],data["sites"]
    checks=[];allrows=[]
    for site,pathstate,fields in zip(sites,states,force):
        ray=optical(tau,fields)
        sep=matrix(tau,fields,2)
        sectors=ray["channels"];total=np.sum(sectors,axis=1)
        def err(meas,ref):
            extent=peak(ref)
            return peak(meas-ref)/extent if extent>1e-35 else peak(meas-ref)
        checks.append(dict(run=path.stem,radius=site,det_check=err(sep["volume"][:,0],total),
                           axial_det_check=err(sep["volume"][:,1],sectors[:,-1]),axial_shear_check=err(sep["shear"],ray["shear"]),
                           final_total=total[-1],final_axial=sectors[-1,-1],final_r=pathstate[-1,1],final_clock=pathstate[-1,0],
                           peak_shear=peak(ray["shear"]),min_stretch=float(sep["J0"].min())))
        allrows.append(np.column_stack([total,sep["volume"],sectors,ray["shear"],ray["logV0"],sep["J0"],sep["angle"],sep["cross"]]))
    key=path.stem.removeprefix("path-")
    with (HERE/f"cloud-{key}.npz").open("xb") as stream:
        np.savez_compressed(stream,tau=tau,sites=sites,results=allrows,keys=["logV2","det2","det_axial","EM_trace",
             "other_trace","radial_anisotropy","axial","shear","logV0","jr","jt","frame_angle","jac_rphi","jac_phir"])
    return checks


if __name__=="__main__":
    guard()
    rows=[]
    for path in sorted(HERE.glob("path-*.npz")):
        rows.extend(execute(path))
    assert len(rows)==39,len(rows)
    write("volume_checks.csv",rows)
    print("max cross checks",*(max(row[key] for row in rows) for key in ("det_check","axial_det_check","axial_shear_check")))

