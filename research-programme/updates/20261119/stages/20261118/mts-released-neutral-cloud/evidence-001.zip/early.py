from trajectory import *
from strip import peak
from scipy.interpolate import make_interp_spline
import mpmath as mp


def quartic(model,site):
    get=model.fields
    mass,lapse,h,pi,hr,dm=get(0.,site,[0,1,2,3,4,5])
    mr,dmr,hrr=get(0.,site,[0,5,4],dr=1)
    fac=1-2*mass/site
    fr=2*mass/site**2-2*mr/site
    df=-2*dm/site
    dfr=2*dm/site**2-2*dmr/site
    h2=fac*hrr+(2*fac/site+fr/2)*hr-h
    dh2=df*hrr+(2*df/site+dfr/2)*hr
    dr2=-dm/site**2-site*df*hr**2/2
    charge=model.charge
    er=-2*mass/site**3+2*charge**2/site**4-fac*hr**2
    ric=-h**2+charge**2/site**4
    et=(ric-er)/2
    der=-2*dm/site**3-df*hr**2
    dric2=(8*h2-2*h)*dh2-4*charge**2*dr2/site**5
    return -(dric2+4*(er-et)*der)/24


def newton(tau,site,mass,dm):
    if not tau:return (0.,0.)
    with mp.workdps(42):
        param=mp.mpf(tau)*mp.sqrt(2*mp.mpf(mass)/site**3)
        phase=mp.findroot(lambda ang:ang+mp.sin(ang)*mp.cos(ang)-param,param/2)
        def log_volume(ang):
            cs=mp.cos(ang)
            jr=cs**2+mp.mpf("1.5")*mp.tan(ang)*(ang+mp.sin(ang)*cs)
            return mp.log(jr)+4*mp.log(cs)
        return float(log_volume(phase)),float(mp.diff(log_volume,phase)*param/(4*mass*mp.cos(phase)**2)*dm)


def main():
    guard()
    rows=[];limit=[];paired_scores=[]
    for eta,amp in ARMS+((0.,0.),):
        key=name(1920,eta,amp)
        model=Strip(1920,eta,amp)
        b=np.load(HERE/f"cloud-{key}.npz");tau=b["tau"]
        for idx,site in enumerate(b["sites"]):
            data=b["results"][idx]
            pred=quartic(model,site)
            ptr=[np.argmin(abs(tau-test)) for test in (.30,.15,.075)]
            vals=data[ptr,0]/tau[ptr]**4
            left=(4*vals[1]-vals[0])/3;right=(4*vals[2]-vals[1])/3
            rows.append(dict(eta=eta,amp=amp,site=site,forecast=pred,extrapolated=right,relative_miss=abs(right/pred-1),
                             extrapolation_change=abs((left-right)/pred),uncorrected_03=abs(vals[0]/pred-1)))
            if eta==0:
                mass=model.fields(0,site,[0])[0]
                exact=np.array([newton(clock,site,mass,model.mass_cost) for clock in tau])
                limit.append(dict(site=site,initial_exterior_mass=mass,added_mass=model.mass_cost,analytic_final=exact[-1,1],
                                  measured_final=data[-1,0],fractional_change_error=peak(exact[:,1]-data[:,0])/peak(data[:,0]),
                                  unperturbed_volume_error=peak(exact[:,0]-data[:,8])/peak(data[:,8]),
                                  quartic_only_final=pred*tau[-1]**4,quartic_fractional_miss=abs(pred*tau[-1]**4/exact[-1,1]-1)))
    pair=np.load(HERE/"paired_waveforms.npz")["results"]
    for slot,amp in enumerate((1/160,1.)):
        for idx,site in enumerate((5.5,6.,7.)):
            match=lambda am:next(row for row in rows if row["eta"]==.8 and row["amp"]==am and row["site"]==site)
            pred=match(amp)["forecast"]-match(0.)["forecast"]
            vals=pair[12+3*slot+idx,ptr,0]/tau[ptr]**4
            right=(4*vals[-1]-vals[-2])/3
            paired_scores.append(dict(amp=amp,radius=site,forecast=pred,extrapolated=right,relative_miss=abs(right/pred-1)))
    write("early_quartic.csv",rows);write("paired_quartic.csv",paired_scores);write("newton_limit.csv",limit)
    print("absolute quartic",max(row["relative_miss"] for row in rows),"difference",max(row["relative_miss"] for row in paired_scores))
    print(limit)


if __name__=="__main__":main()

