from experiment import ROOT, WAVES, EDGES, np, fields, packets, read, digest, save, guard


def split(data,selected,seed,phi):
    cat={key:val[selected] for key,val in data.items()}
    accum=np.zeros((2,len(EDGES)-1,len(WAVES),8))
    for left,right in packets(cat['sky'],seed):
        ok=cat['matched'][left]&cat['matched'][right]&(cat['ids'][left]!=cat['ids'][right])&(cat['host'][left]!=cat['host'][right])
        left,right=left[ok],right[ok]
        shell=np.searchsorted(EDGES[1:],np.linalg.norm(cat['sky'][left]-cat['sky'][right],axis=1),side='left')
        wt=cat['weight'][left]*cat['weight'][right]
        residual=cat['internal'][left]-cat['internal'][right]
        host=(cat['total'][left]-cat['total'][right])-residual
        real=cat['radius'][left]-cat['radius'][right]
        for idx,wave in enumerate(WAVES):
            factor=np.where(cat['sat'][left],phi[idx],1)*np.conj(np.where(cat['sat'][right],phi[idx],1))
            even=np.cos(wave*residual)-factor.real
            odd=np.sin(wave*residual)-factor.imag
            for kind,base in enumerate((host,host+real)):
                angle=wave*base
                for col,values in enumerate((np.ones(len(left)),np.cos(angle)*even,-np.sin(angle)*odd,
                     np.cos(angle),even,np.sin(angle),odd,base*residual)):
                    accum[kind,:,idx,col]+=np.bincount(shell,weights=wt*values,minlength=len(EDGES)-1)
    out=[]
    for grid in accum:
        assert (grid[:,:,0]>0).all()
        averages=grid[:,:,1:]/grid[:,:,0,None]
        even,odd,avg_cos,d_cos,avg_sin,d_sin,cross=np.moveaxis(averages,-1,0)
        independent_error=avg_cos*d_cos-avg_sin*d_sin
        out.append(dict(even=even.tolist(),odd=odd.tolist(),sum=(even+odd).tolist(),
                        mean_product=independent_error.tolist(),covariance_remainder=(even+odd-independent_error).tolist(),
                        mean_base_times_internal=cross[:,0].tolist()))
    return out


def main():
    guard()
    trained,scored=(read(ROOT/name) for name in ('train.json','score.json'))
    assert digest(ROOT/'train.json')==read(ROOT/'freeze.json')['training']
    assert all(digest(ROOT/name)==value for name,value in trained['locks'].items())
    original=np.load(ROOT/'train_ids.npy')
    result={}
    for cap in ('S','N'):
        data,_,_=fields(cap,1)
        forecast=trained['caps'][cap]['one_point']
        phi=np.array(forecast['sat_real'])+1j*np.array(forecast['sat_imag'])
        out={}
        for label,select in [('pairs',np.ones(len(data['ids']),bool)),('disjoint_pairs',~(np.isin(data['family'],original)|np.isin(data['ids'],original)))]:
            blocks=split(data,select,scored['caps'][cap]['pair_seed'],phi)
            for block,col in zip(blocks,('total','radial')):
                expected=np.array([np.subtract(row[col],row[col+'_independent']) for row in scored['caps'][cap][label]['distinct']])
                error=float(np.max(abs(expected-block['sum'])))
                assert error<2e-10
                block['closure_max_abs']=error
            out[label]=blocks
        result[cap]=out
    save('phase-attribution.json',dict(posthoc=True,score=digest(ROOT/'score.json'),caps=result))


if __name__=='__main__':main()
