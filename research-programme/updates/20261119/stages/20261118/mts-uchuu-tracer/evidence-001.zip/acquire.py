import hashlib
import json
import os
import sys
import urllib.request
from datetime import datetime,timezone
from pathlib import Path
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PRIOR=POST/'mts-boss-window-20261118'
SEAL='05e2d4b0f31609a84a379a078844d1714c8e38dd8d0e00979ec6b8f6478f42fe'
BASE='https://skun.iaa.es/SUsimulations/UchuuDR2/Uchuu_GLAM_BOSS-eBOSS/'
CACHE=ROOT/'inputs'


def guard():
    assert digest(PRIOR/'closeout.json')==SEAL
    assert not any((folder/'STOP-REQUESTED').exists() for folder in (ROOT,POST,PRIOR))


def digest(path):
    with Path(path).open('rb') as handle:return hashlib.file_digest(handle,'sha256').hexdigest()


def save(name,data):
    with (ROOT/name).open('x',encoding='utf8') as handle:json.dump(data,handle,indent=2,allow_nan=False)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def fetch(remote,limit):
    name=remote.split('/')[-1];path=CACHE/name
    dest=path.with_suffix('.partial')
    assert not path.exists() and not dest.exists()
    with urllib.request.urlopen(BASE+remote,timeout=75) as response, dest.open('xb') as handle:
        length=int(response.headers.get('Content-Length') or 0)
        assert length<=limit
        total=0
        while chunk:=response.read(1<<20):
            total+=len(chunk);assert total<=limit;handle.write(chunk)
        assert total>0 and (not length or length==total)
    if name.endswith('.h5'):
        with dest.open('rb') as handle:assert handle.read(8)==bytes.fromhex('894844460d0a1a0a')
    dest.rename(path)
    return dict(name=name,url=BASE+remote,bytes=total,sha256=digest(path))


if __name__=='__main__':
    guard();CACHE.mkdir(exist_ok=True)
    for name in ['comments.txt',*[f'Uchuu/COMB_{cap}_Uchuu_{real}.dat.h5' for real in (0,1) for cap in ('S','N')]]:
        receipt=ROOT/(name.split('/')[-1]+'.receipt.json')
        if receipt.exists():
            assert read(receipt)['sha256']==digest(CACHE/read(receipt)['name']);continue
        row=fetch(name,185_000_000)
        save(receipt.name,dict(**row,utc=datetime.now(timezone.utc).isoformat(),protocol=digest(ROOT/'PROTOCOL.md')))
        print(row['name'],row['bytes'],flush=True)
