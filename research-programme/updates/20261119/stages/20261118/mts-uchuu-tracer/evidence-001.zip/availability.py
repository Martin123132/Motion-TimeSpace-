from acquire import BASE, guard, save
from html.parser import HTMLParser
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from datetime import datetime, timezone


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.data_files=[]

    def handle_starttag(self,tag,attrs):
        href=dict(attrs).get('href','')
        if tag=='a' and href.startswith('COMB_') and href.endswith('.dat.h5'):
            self.data_files.append(href)


if __name__=='__main__':
    guard()
    base=BASE+'Uchuu/'
    with urlopen(base,timeout=30) as response:page=response.read(1<<20)
    index=Links();index.feed(page.decode())
    tests={}
    for cap in ('S','N'):
        url=base+f'COMB_{cap}_Uchuu_2.dat.h5'
        try:
            with urlopen(Request(url,method='HEAD'),timeout=30) as response:tests[url]=response.status
        except HTTPError as error:
            tests[url]=error.code
    save('availability.json',dict(index=base,listed=sorted(index.data_files),head=tests,utc=datetime.now(timezone.utc).isoformat()))
