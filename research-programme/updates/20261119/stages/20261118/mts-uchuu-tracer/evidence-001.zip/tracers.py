from acquire import ROOT, CACHE, digest, guard, read, save
import h5py
import numpy as np


WAVES = np.array([0.025, 0.05, 0.075, 0.10, 0.15])
EDGES = np.array([0., 2., 5., 10., 20., 40., 80.])
OMEGA = 0.309


def delta_chi(first, second):
    mid = (first + second) / 2
    half = (second - first) / 2
    roots, weights = np.polynomial.legendre.leggauss(4)
    return 2997.92458 * half * sum(weight / np.sqrt(1 - OMEGA + OMEGA * (1 + mid + half * root) ** 3) for root, weight in zip(roots, weights))


def quant(values):
    return np.quantile(values, [0, .5, .95, .99, 1]).tolist() if len(values) else []


def fields(cap, cone):
    file = CACHE / f'COMB_{cap}_Uchuu_{cone}.dat.h5'
    assert digest(file) == read(ROOT / (file.name + '.receipt.json'))['sha256']
    with h5py.File(file) as handle:
        def column(name):
            target = np.empty(handle[name].shape, dtype=np.float64)
            handle[name].read_direct(target)
            assert np.isfinite(target).all()
            return target

        ids, parent = handle['id'][:], handle['pid'][:]
        assert ids.dtype == parent.dtype == np.int64
        cart = np.column_stack([column(name) for name in ('x','y','z')])
        vel = np.column_stack([column(name) for name in ('vx','vy','vz')])
        ra, dec = (np.deg2rad(column(name)) for name in ('ra','dec'))
        red, obs, vlos = (column(name) for name in ('z_cos','z_obs','vlos'))
        weight = column('w_cp') * column('w_fkp') * column('w_npcf')
        mass = column('Mvir_all')
    assert (weight >= 0).all()
    chosen = np.flatnonzero((.2 <= obs) & (obs < .5) & (weight > 0))
    radius = np.linalg.norm(cart,axis=1)
    unit = cart / radius[:,None]
    sky = radius[:,None] * np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
    projection = np.abs(np.sum(unit * vel,axis=1) - vlos)
    zerror = abs((obs-red)*300000/(1+red)-vlos)
    assert np.max(projection) < 1e-6 and np.max(zerror) < 1e-6
    satellites = chosen[parent[chosen] != -1]
    centrals = np.flatnonzero(parent == -1)
    ordered = centrals[np.argsort(ids[centrals],kind='stable')]
    lower = np.searchsorted(ids[ordered],parent[satellites])
    upper = np.searchsorted(ids[ordered],parent[satellites],side='right')
    count = np.zeros(len(satellites),dtype=int)
    host = np.full(len(ids),-1,dtype=np.int64)
    host[centrals] = centrals
    for offset in range(int(max(upper-lower,default=0))):
        loc = np.flatnonzero(lower+offset < upper)
        src, dst = satellites[loc], ordered[lower[loc]+offset]
        nearby = (np.linalg.norm(cart[src]-cart[dst],axis=1)<=3) & (np.linalg.norm(sky[src]-sky[dst],axis=1)<=3)
        count[loc[nearby]] += 1
        host[src[nearby]] = dst[nearby]
    host[satellites[count != 1]] = -1
    is_sat = parent[chosen] != -1
    matched = host[chosen] >= 0
    index = chosen[matched]
    hostvel = np.sum(vel[host[index]] * unit[index],axis=1)
    ifhost = red[index] + (1+red[index])*hostvel/300000
    internal = np.full(len(chosen),np.nan)
    internal[matched] = delta_chi(ifhost,obs[index])
    internal[~is_sat] = 0.
    total = delta_chi(red[chosen],obs[chosen])
    assert np.max(abs((total[matched]-internal[matched])-delta_chi(red[index],ifhost))) < 1e-10
    wrap = (np.rad2deg(ra[chosen])+180)%360-180 if cap=='S' else np.rad2deg(ra[chosen])
    meta = dict(raw=len(ids), selected=len(chosen), central=int(sum(~is_sat)), satellites=int(sum(is_sat)),
                measured_satellites=int(sum(is_sat&matched)), missing_id=int(sum(upper==lower)),
                nonlocal_id=int(sum((upper>lower)&(count==0))), ambiguous=int(sum(count>1)),
                satellite_match_by_weight=float(weight[chosen][is_sat&matched].sum()/weight[chosen][is_sat].sum()),
                missing_weight_fraction=float(weight[chosen][~matched].sum()/weight[chosen].sum()),
                projection_error_kms=quant(projection), redshift_error_kms=quant(zerror),
                position_minus_chi_mpc_h=quant(radius[chosen]-delta_chi(np.zeros(len(chosen)),red[chosen])),
                measured_subhalo_logmass=quant(np.log10(mass[chosen][is_sat&matched])),
                missing_subhalo_logmass=quant(np.log10(mass[chosen][is_sat&~matched])))
    data=dict(ids=ids[chosen],family=np.where(is_sat,parent[chosen],ids[chosen]),host=host[chosen],sat=is_sat,matched=matched,
              weight=weight[chosen], sky=sky[chosen], radius=radius[chosen], coord=wrap,total=total,internal=internal)
    return data, meta, np.union1d(ids,parent[parent>=0])


def characteristic(data, selected):
    weight = data['weight'][selected]
    internal = data['internal'][selected]
    return np.array([np.average(np.exp(1j*wave*internal),weights=weight) for wave in WAVES])


def amplitudes(data, selected):
    weight, matched, sat = (data[key] for key in ('weight','matched','sat'))
    measured = selected & matched
    phi = characteristic(data, measured)
    satphi = characteristic(data, measured & sat)
    absent = weight[selected & ~matched].sum()/weight[selected].sum()
    second = np.average(data['internal'][measured]**2,weights=weight[measured])
    return dict(measured_count=int(sum(measured)),satellite_count=int(sum(measured&sat)),missing_weight=float(absent),
                empirical_real=phi.real.tolist(),empirical_imag=phi.imag.tolist(),empirical_power=(abs(phi)**2).tolist(),
                sat_real=satphi.real.tolist(),sat_imag=satphi.imag.tolist(),rms_displacement=float(np.sqrt(second)),
                unweighted_real=[float(np.cos(wave*data['internal'][measured]).mean()) for wave in WAVES],
                gaussian_power=np.exp(-WAVES**2*second).tolist(),
                full_power_lower=np.maximum(0,(1-absent)*abs(phi)-absent).__pow__(2).tolist(),
                full_power_upper=np.minimum(1,(1-absent)*abs(phi)+absent).__pow__(2).tolist())
