import sys
from math import comb
from acquire import CACHE, fetch
import h5py
from experiment import guard, ROOT, np, WAVES, EDGES, fields, packets, moments, read, save, digest


NAMES=('MIXED-MOMENTS.md','mixed.py','experiment.py','tracers.py','acquire.py','train.json','score.json','phase-attribution.json')


def joined_moments(data,seed):
    has=data['sat']&data['matched']
    raw=np.array([np.average(data['internal'][has]**degree,weights=data['weight'][has]) for degree in range(7)])
    single=np.array([[1,0,0,0,0,0,0],raw])
    reference=np.zeros((4,7))
    for code in range(4):
        for degree in range(7):
            reference[code,degree]=sum((-1)**(degree-power)*comb(degree,power)*single[code//2,power]*single[code%2,degree-power] for power in range(degree+1))
    sums=np.zeros((2,len(EDGES)-1,5))
    for left,right in packets(data['sky'],seed):
        ok=data['matched'][left]&data['matched'][right]&(data['ids'][left]!=data['ids'][right])&(data['host'][left]!=data['host'][right])
        left,right=left[ok],right[ok]
        shell=np.searchsorted(EDGES[1:],np.linalg.norm(data['sky'][left]-data['sky'][right],axis=1),side='left')
        weight=data['weight'][left]*data['weight'][right]
        types=2*data['sat'][left].astype(int)+data['sat'][right]
        delta=data['internal'][left]-data['internal'][right]
        host=data['total'][left]-data['total'][right]-delta
        for idx,base in enumerate((host,host+data['radius'][left]-data['radius'][right])):
            mixed=-base*(delta-reference[types,1])
            width=-.5*(delta**2-reference[types,2])
            fourth=sum(comb(4,degree)*base**(4-degree)*(delta**degree-reference[types,degree]) for degree in range(1,5))/24
            remainder=((base+delta)**6+sum(comb(6,degree)*base**(6-degree)*reference[types,degree] for degree in range(7)))/720
            assert np.min(remainder,initial=0)>-1e-9
            for col,value in enumerate((1.,mixed,width,fourth,remainder)):
                sums[idx,:,col]+=np.bincount(shell,weight*value,minlength=len(EDGES)-1)
    assert (sums[:,:,0]>0).all()
    return sums[:,:,1:]/sums[:,:,[0]]


def projected(coef):
    return (coef[:,:,0,None]+coef[:,:,1,None])*WAVES**2, coef[:,:,2,None]*WAVES**4, coef[:,:,3,None]*WAVES**6


def discrepancy(rows):
    return np.array([[np.subtract(row[name],row[name+'_independent']) for row in rows['distinct']] for name in ('total','radial')])


def prepare(lock):
    out={}
    for cap in ('S','N'):
        data,_,_=fields(cap,0)
        source=read(ROOT/'train.json')['caps'][cap]
        coef=joined_moments(data,source['pair_seed'])
        quad,quart,bound=projected(coef)
        difference=discrepancy(source['pairs'])-quad-quart
        assert np.all(abs(difference)<=bound+2e-10)
        out[cap]=dict(coef=coef.tolist(),primary_max_taylor_remainder=float(np.max(abs(difference[:,:3,:2]))),
                      primary_max_rigorous_bound=float(bound[:,:3,:2].max()))
    ids=np.load(ROOT/'train_ids.npy')
    for cap in ('S','N'):
        with h5py.File(CACHE/f'COMB_{cap}_Uchuu_1.dat.h5') as handle:
            ids=np.union1d(ids,np.union1d(handle['id'][:],handle['pid'][:]))
    with (ROOT/'exposed_ids.npy').open('xb') as handle:np.save(handle,ids[ids>=0])
    save('moments-frozen.json',dict(locks=lock,caps=out,all_ids=digest(ROOT/'exposed_ids.npy')))


def evaluate(lock):
    frozen=read(ROOT/'moments-frozen.json')
    assert frozen['locks']==lock and frozen['all_ids']==digest(ROOT/'exposed_ids.npy')
    ids=np.load(ROOT/'exposed_ids.npy')
    output={}
    for pos,cap in enumerate(('S','N')):
        guard()
        name=f'COMB_{cap}_Uchuu_2.dat.h5'
        if not (ROOT/(name+'.receipt.json')).exists():
            row=fetch('Uchuu/'+name,185_000_000)
            save(name+'.receipt.json',dict(**row,frozen=digest(ROOT/'moments-frozen.json')))
        assert read(ROOT/(name+'.receipt.json'))['frozen']==digest(ROOT/'moments-frozen.json')
        data,meta,_=fields(cap,2)
        source=read(ROOT/'train.json')['caps'][cap]
        phi=np.array(source['one_point']['sat_real'])+1j*np.array(source['one_point']['sat_imag'])
        quad,quart,_=projected(np.array(frozen['caps'][cap]['coef']))
        out=dict(catalogue=meta)
        for label,mask in [('all',np.ones(len(data['ids']),bool)),('disjoint',~(np.isin(data['ids'],ids)|np.isin(data['family'],ids)))]:
            guard()
            rows=moments(data,mask,phi,np.array(source['region_edges']),491121+pos)
            difference=discrepancy(rows)
            errors=np.stack([difference,difference-quad,difference-quad-quart])
            primary=errors[:,:,:3,:2]
            out[label]=dict(selected=int(mask.sum()),measured=int(sum(mask&data['matched'])),pairs=rows,
                            errors=errors.tolist(),mean_abs=np.mean(abs(primary),axis=(1,2,3)).tolist(),
                            max_abs=np.max(abs(primary),axis=(1,2,3)).tolist(),
                            improved_cells=np.sum(abs(primary)<abs(primary[0]),axis=(1,2,3)).tolist())
        output[cap]=out
        print('evaluated',cap,out['all']['mean_abs'],out['disjoint']['mean_abs'],flush=True)
    save('independent-cone.json',dict(frozen=digest(ROOT/'moments-frozen.json'),caps=output))


if __name__=='__main__':
    guard()
    locks={name:digest(ROOT/name) for name in NAMES}
    if sys.argv[1]=='freeze':prepare(locks)
    elif sys.argv[1]=='evaluate':evaluate(locks)
    else:raise ValueError('expected freeze or evaluate')
