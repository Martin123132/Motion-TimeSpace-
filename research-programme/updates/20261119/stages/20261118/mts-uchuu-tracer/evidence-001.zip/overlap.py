from acquire import CACHE, guard, save
import h5py
import numpy as np


def rows(cap,cone):
    with h5py.File(CACHE/f'COMB_{cap}_Uchuu_{cone}.dat.h5') as handle:
        def fetch(key):
            dest=np.empty(handle[key].shape)
            handle[key].read_direct(dest)
            return dest
        ids=handle['id'][:]
        parents=handle['pid'][:]
        red=fetch('z_obs')
        weight=fetch('w_cp')*fetch('w_fkp')*fetch('w_npcf')
        position=np.column_stack([fetch(name) for name in ('ra','dec','z_cos','vlos')])
    return [(ids[sel],np.where(parents[sel]==-1,ids[sel],parents[sel]),position[sel]) for sel in
        ((.2<=red)&(red<.5)&(weight>0),(.5<=red)&(red<.6)&(weight>0))]


def main():
    guard()
    result={}
    for cap in ('S','N'):
        first,second=(rows(cap,cone) for cone in (0,1))
        for zone,(one,two) in enumerate(zip(first,second)):
            shared,aa,bb=np.intersect1d(one[0],two[0],return_indices=True)
            result[cap+str(zone)]=dict(unique_ids_shared=len(shared),unique_ids_0=len(np.unique(one[0])),
                unique_ids_1=len(np.unique(two[0])),rows_in_1_with_family_in_0=float(np.mean(np.isin(two[1],one[1]))),
                first_representatives_identical_ra_dec_zcos_vlos=int(np.sum(np.all(one[2][aa]==two[2][bb],axis=1))))
    save('overlap.json',dict(zone0='0.2<=z_obs<0.5',zone1='0.5<=z_obs<0.6',result=result))


if __name__=='__main__':main()
