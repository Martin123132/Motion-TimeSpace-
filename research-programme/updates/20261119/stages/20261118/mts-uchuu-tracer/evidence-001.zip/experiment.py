import sys
from tracers import ROOT, WAVES, EDGES, np, fields, amplitudes, guard, read, save, digest
from scipy.spatial import cKDTree


NREG = 8
COLS = ('internal','independent','total','host','total_independent','radial','radial_host','radial_independent')
LOCKED = ('acquire.py','tracers.py','experiment.py','PROTOCOL.md','SPLIT.md')


def packets(sky, seed):
    tree = cKDTree(sky)
    small = tree.query_pairs(10.,output_type='ndarray')
    for pos in range(0,len(small),65536):
        batch=small[pos:pos+65536]
        yield batch[:,0],batch[:,1]
    rng=np.random.default_rng(seed)
    anchors=np.sort(rng.choice(len(sky),size=min(4096,len(sky)),replace=False))
    for pos in range(0,len(anchors),64):
        anchor=anchors[pos:pos+64]
        lists=tree.query_ball_point(sky[anchor],80,workers=1,return_sorted=True)
        left=np.repeat(anchor,[len(neighbors) for neighbors in lists])
        right=np.concatenate(lists).astype(int)
        keep=np.sum((sky[left]-sky[right])**2,axis=1)>100.
        yield left[keep],right[keep]


def summarize(grid, kind):
    sums=grid.sum(axis=(1,2))
    result=[]
    for shell, row in enumerate(sums):
        if not row[1]:
            result.append(None)
            continue
        means=row[2:].reshape(len(COLS),len(WAVES))/row[1]
        out=dict(count=int(round(row[0])),weight=float(row[1]))
        if kind=='all':
            out.update(total=means[2].tolist(),radial=means[5].tolist())
        else:
            out.update({name:values.tolist() for name,values in zip(COLS,means)})
            jack=[]
            for region in range(NREG):
                keep=np.arange(NREG)!=region
                retained=grid[shell][keep][:,keep].sum(axis=(0,1))
                if not retained[1]:break
                values=retained[2:].reshape(len(COLS),len(WAVES))/retained[1]
                jack.append([values[0]-values[1],values[2]-values[4],values[5]-values[7]])
            if len(jack)==NREG:
                out['conditional_jackknife_se']=np.sqrt((NREG-1)*np.var(jack,axis=0)).tolist()
        result.append(out)
    return result


def moments(data,sample,phi,edges,seed):
    cat={key:val[sample] for key,val in data.items()}
    bins=len(EDGES)-1
    region=np.searchsorted(edges,cat['coord'])
    box={kind:np.zeros((bins,NREG,NREG,2+len(COLS)*len(WAVES))) for kind in ('all','same','distinct')}
    duplicated=0
    for left,right in packets(cat['sky'],seed):
        different=cat['ids'][left]!=cat['ids'][right]
        duplicated+=int(sum(~different))
        left,right=left[different],right[different]
        length=np.linalg.norm(cat['sky'][left]-cat['sky'][right],axis=1)
        shell=np.searchsorted(EDGES[1:],length,side='left')
        assert (shell<bins).all()
        key=(shell*NREG+region[left])*NREG+region[right]
        weight=cat['weight'][left]*cat['weight'][right]
        full=cat['total'][left]-cat['total'][right]
        real=cat['radius'][left]-cat['radius'][right]
        measured=cat['matched'][left]&cat['matched'][right]
        same=cat['host'][left]==cat['host'][right]
        for kind,mask in [('all',np.ones(len(left),dtype=bool)),('same',measured&same),('distinct',measured&~same)]:
            if not mask.any():continue
            dest=box[kind].reshape((-1,box[kind].shape[-1]))
            keys,weights=key[mask],weight[mask]
            def add(col,values):
                dest[:,col]+=np.bincount(keys,weights=values,minlength=len(dest))
            add(0,np.ones(len(keys)));add(1,weights)
            shift,separation=full[mask],real[mask]
            if kind!='all':
                first,second=left[mask],right[mask]
                internal=cat['internal'][first]-cat['internal'][second]
                bulk=shift-internal
            for idx,wave in enumerate(WAVES):
                if kind=='all':
                    vals={2:np.cos(wave*shift),5:np.cos(wave*(separation+shift))}
                else:
                    factor=np.where(cat['sat'][first],phi[idx],1)*np.conj(np.where(cat['sat'][second],phi[idx],1))
                    bulk_phase=np.exp(1j*wave*bulk)
                    radial_phase=np.exp(1j*wave*(separation+bulk))
                    vals=dict(enumerate((np.cos(wave*internal),factor.real,np.cos(wave*shift),bulk_phase.real,
                        (bulk_phase*factor).real,np.cos(wave*(separation+shift)),radial_phase.real,(radial_phase*factor).real)))
                for col,values in vals.items():add(2+col*len(WAVES)+idx,weights*values)
    return dict(excluded_duplicate_ids=duplicated,**{kind:summarize(grid,kind) for kind,grid in box.items()})


def consistency():
    from tracers import delta_chi
    from scipy.integrate import quad
    from itertools import combinations
    rng=np.random.default_rng(93103)
    for start,end in ((.31,.314),(.54,.527),(.2,.2)):
        exact=quad(lambda red:2997.92458/np.sqrt(.691+.309*(1+red)**3),start,end)[0]
        assert abs(delta_chi(start,end)-exact)<1e-10
    sky=rng.uniform(-6,6,(35,3))
    aa,bb=np.array(list(combinations(range(len(sky)),2))).T
    dist=np.linalg.norm(sky[aa]-sky[bb],axis=1)
    expected=np.sort(aa[dist<=10]*len(sky)+bb[dist<=10])
    first=next(packets(sky,0))
    assert np.array_equal(expected,np.sort(first[0]*len(sky)+first[1]))
    sat=np.arange(len(sky))%3!=0
    internal=np.where(sat,rng.normal(size=len(sky)),0.)
    bulk=rng.normal(size=len(sky))
    data=dict(sky=sky,coord=sky[:,0],ids=np.arange(len(sky)),weight=rng.uniform(.2,1,len(sky)),
              sat=sat,matched=np.ones(len(sky),bool),radius=np.linalg.norm(sky,axis=1),
              host=np.arange(len(sky)),internal=internal,total=bulk+internal)
    select=np.ones(len(sky),bool)
    trial=moments(data,select,np.ones(len(WAVES)),np.arange(-3.,4.),89)
    for shell,row in enumerate(trial['distinct']):
        if row is None:continue
        include=(dist>EDGES[shell])&(dist<=EDGES[shell+1])
        left,right=aa[include],bb[include]
        weights=data['weight'][left]*data['weight'][right]
        offset=data['total'][left]-data['total'][right]+data['radius'][left]-data['radius'][right]
        truth=[np.average(np.cos(wave*offset),weights=weights) for wave in WAVES]
        assert np.max(abs(np.array(truth)-row['radial']))<1e-12
        assert np.max(abs(np.array(row['independent'])-1))<1e-12
    dx=internal[aa]-internal[bb]
    assert np.max(abs(np.cos(.15*dx)-np.cos(-.15*((internal+122)[aa]-(internal+122)[bb]))))<1e-12
    assert np.all(np.cos(0*dx)==1)


def main(mode):
    assert mode in ('train','score')
    guard();consistency()
    locks={name:digest(ROOT/name) for name in LOCKED}
    cone=int(mode=='score')
    score={'k_parallel':WAVES.tolist(),'shell_edges':EDGES.tolist(),'locks':locks,'caps':{}}
    if cone:
        trained=read(ROOT/'train.json')
        assert locks==trained['locks'] and digest(ROOT/'train.json')==read(ROOT/'freeze.json')['training']
        assert digest(ROOT/'train_ids.npy')==trained['all_ids_sha256']
        original=np.load(ROOT/'train_ids.npy')
    identities=[]
    for capnumber,cap in enumerate(('S','N')):
        guard()
        data,meta,ids=fields(cap,cone)
        allrows=np.ones(len(data['ids']),dtype=bool)
        if not cone:identities.append(ids)
        seed=489121+cone*1000+capnumber
        own=amplitudes(data,allrows)
        forecast=trained['caps'][cap]['one_point'] if cone else own
        phi=np.array(forecast['sat_real'])+1j*np.array(forecast['sat_imag'])
        edges=np.array(trained['caps'][cap]['region_edges']) if cone else np.quantile(data['coord'],np.arange(1,NREG)/NREG)
        out=dict(catalogue=meta,one_point=own,region_edges=edges.tolist(),pair_seed=seed,
                 pairs=moments(data,allrows,phi,edges,seed))
        if cone:
            unshared=~(np.isin(data['family'],original)|np.isin(data['ids'],original))
            out['disjoint_count']=int(unshared.sum())
            if np.any(unshared&data['matched']&data['sat']):
                out['disjoint_one_point']=amplitudes(data,unshared)
                out['disjoint_pairs']=moments(data,unshared,phi,edges,seed)
        score['caps'][cap]=out
        print(mode,cap,meta['selected'],meta['measured_satellites'],flush=True)
    if not cone:
        with (ROOT/'train_ids.npy').open('xb') as stream:np.save(stream,np.unique(np.concatenate(identities)))
        score['all_ids_sha256']=digest(ROOT/'train_ids.npy')
    save(mode+'.json',score)
    if not cone:save('freeze.json',dict(training=digest(ROOT/'train.json'),mode='both cone-zero caps frozen before cone-one scoring'))


if __name__=='__main__':main(sys.argv[1])
