import csv
from acquire import ROOT, CACHE, digest, guard, read, save
from experiment import WAVES, EDGES, np, consistency
from mixed import projected, discrepancy


def table(filename,header,rows):
    with (ROOT/filename).open('x',encoding='utf8',newline='') as handle:
        writer=csv.writer(handle)
        writer.writerow(header)
        writer.writerows(rows)
    with (ROOT/filename).open(encoding='utf8',newline='') as handle:
        recovered=list(csv.reader(handle))
    assert len(recovered)==len(rows)+1 and all(len(row)==len(header) for row in recovered)


def main():
    guard();consistency()
    first,second,attr,frozen,third=(read(ROOT/name) for name in ('train.json','score.json','phase-attribution.json','moments-frozen.json','window-transfer.json'))
    assert digest(ROOT/'train.json')==read(ROOT/'freeze.json')['training']
    assert attr['score']==digest(ROOT/'score.json') and third['locks']==read(ROOT/'window-freeze.json')
    assert not (ROOT/'independent-cone.json').exists()
    availability=read(ROOT/'availability.json')
    assert set(availability['head'].values())=={404} and len(availability['listed'])==4
    for lock in (first['locks'],frozen['locks'],third['locks']):
        assert all(digest(ROOT/key)==value for key,value in lock.items())
    assert first['all_ids_sha256']==digest(ROOT/'train_ids.npy') and frozen['all_ids']==digest(ROOT/'exposed_ids.npy')
    receipts=list(ROOT.glob('*.receipt.json'))
    assert len(receipts)==5
    for path in receipts:
        row=read(path);item=CACHE/row['name']
        assert row['sha256']==digest(item) and item.stat().st_size==row['bytes']
    audit=[];diagnostics=[]
    for cap in ('S','N'):
        source=first['caps'][cap]
        for packet in (source,second['caps'][cap],third['caps'][cap+'0'],third['caps'][cap+'1']):
            meta=packet['catalogue']
            assert meta['selected']==meta['central']+meta['satellites']
            assert meta['satellites']==sum(meta[name] for name in ('measured_satellites','missing_id','nonlocal_id','ambiguous'))
            assert max(meta['projection_error_kms']+meta['redshift_error_kms'])<1e-6
        for mode in ('pairs','disjoint_pairs'):
            result=second['caps'][cap][mode]
            for kind,col in enumerate(('total','radial')):
                block=attr['caps'][cap][mode][kind]
                assert block['closure_max_abs']<2e-10
                for index,row in enumerate(result['distinct']):
                    same=result['same'][index]
                    fraction=(row['weight']+(same['weight'] if same else 0))/result['all'][index]['weight']
                    assert 0<fraction<=1+1e-12
                    for waveidx,wave in enumerate(WAVES):
                        actual=row[col][waveidx];prediction=row[col+'_independent'][waveidx]
                        even,odd=(block[name][index][waveidx] for name in ('even','odd'))
                        assert abs(actual-prediction-even-odd)<2e-10
                        diagnostics.append([cap,mode,col,*EDGES[index:index+2],wave,row['count'],fraction,actual,prediction,even,odd,
                            row['conditional_jackknife_se'][1+kind][waveidx]])
        quadratic,quartic,remainder=projected(np.array(frozen['caps'][cap]['coef']))
        assert np.all(abs(discrepancy(source['pairs'])-quadratic-quartic)<=remainder+2e-10)
        for cone,subset in ((idx,cohort) for idx in (0,1) for cohort in ('all','disjoint')):
            out=third['caps'][cap+str(cone)][subset]
            exact=discrepancy(out['pairs'])
            errors=np.stack([exact,exact-quadratic,exact-quadratic-quartic])
            assert np.max(abs(np.array(out['errors'])-errors))<1e-12
            assert np.max(abs(np.mean(abs(errors[:,:,:3,:2]),axis=(1,2,3))-out['mean_abs']))<1e-12
            for kind,label in enumerate(('total','radial')):
                for shell,row in enumerate(out['pairs']['distinct']):
                    for idx,wave in enumerate(WAVES):
                        audit.append([cone,cap,subset,label,*EDGES[shell:shell+2],wave,row['count'],row[label][idx],row[label+'_independent'][idx],
                            quadratic[kind,shell,idx],quartic[kind,shell,idx],*errors[:,kind,shell,idx]])
    table('cone1-phase-split.csv',['cap','subset','phase','r_lo','r_hi','k','pairs','matched_weight_share_all_pairs','actual',
          'conditional_independent','even_part_error','odd_part_error','jackknife_se'],diagnostics)
    table('higher-redshift-forecast-errors.csv',['cone','cap','subset','phase','r_lo','r_hi','k','pairs','actual','conditional_independent',
          'frozen_k2','frozen_k4_increment','error_independent','error_k2','error_k2_plus_k4'],audit)
    assert len(diagnostics)==240 and len(audit)==480
    assert not any(path.name=='__pycache__' or path.suffix=='.partial' for path in ROOT.rglob('*'))
    files={str(path.relative_to(ROOT)).replace('\\','/'):digest(path) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    assert 'RESULTS.md' in files
    save('closeout.json',dict(files=files,checked_receipts=len(receipts),phase_cells=len(diagnostics),redshift_transfer_cells=len(audit),third_COMB_cone='not available',
         science_scope='published LCDM BOSS tracer simulations; no fit, no BOSS rescore, no MTS occupation calibration'))


if __name__=='__main__':main()
