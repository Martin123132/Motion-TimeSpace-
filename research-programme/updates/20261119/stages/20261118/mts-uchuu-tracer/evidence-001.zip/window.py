from mixed import ROOT, WAVES, np, fields, moments, projected, guard, read, save, digest
from window_tracers import fields as window_fields


def main():
    guard()
    original=(ROOT/'tracers.py').read_text(encoding='utf8').rstrip()
    derived=(ROOT/'window_tracers.py').read_text(encoding='utf8').rstrip()
    assert original.count('(.2 <= obs) & (obs < .5)')==1
    assert original.replace('(.2 <= obs) & (obs < .5)','(.5 <= obs) & (obs < .6)')==derived
    frozen=read(ROOT/'moments-frozen.json')
    assert all(digest(ROOT/key)==val for key,val in frozen['locks'].items())
    names=('window.py','window_tracers.py','WINDOW-TRANSFER.md','moments-frozen.json')
    locks={name:digest(ROOT/name) for name in names}
    save('window-freeze.json',locks)
    identifiers=[]
    for cone in (0,1):
        for cap in ('S','N'):
            data,_,_=fields(cap,cone)
            identifiers.append(np.union1d(data['ids'],data['family']))
    seen=np.unique(np.concatenate(identifiers))
    results={}
    for cone in (0,1):
        for pos,cap in enumerate(('S','N')):
            guard()
            data,meta,_=window_fields(cap,cone)
            source=read(ROOT/'train.json')['caps'][cap]
            phi=np.array(source['one_point']['sat_real'])+1j*np.array(source['one_point']['sat_imag'])
            quad,quart,_=projected(np.array(frozen['caps'][cap]['coef']))
            out=dict(catalogue=meta)
            for label,mask in [('all',np.ones(len(data['ids']),bool)),('disjoint',~(np.isin(data['ids'],seen)|np.isin(data['family'],seen)))]:
                rows=moments(data,mask,phi,np.array(source['region_edges']),592010+10*cone+pos)
                if any(row is None for row in rows['distinct']):
                    out[label]=dict(selected=int(mask.sum()),unavailable_shells=[idx for idx,row in enumerate(rows['distinct']) if row is None],pairs=rows)
                    continue
                exact=np.array([[np.subtract(row[name],row[name+'_independent']) for row in rows['distinct']] for name in ('total','radial')])
                errors=np.stack([exact,exact-quad,exact-quad-quart])
                primary=errors[:,:,:3,:2]
                out[label]=dict(selected=int(mask.sum()),measured=int(sum(mask&data['matched'])),pairs=rows,errors=errors.tolist(),
                    mean_abs=np.mean(abs(primary),axis=(1,2,3)).tolist(),max_abs=np.max(abs(primary),axis=(1,2,3)).tolist(),
                    improved_cells=np.sum(abs(primary)<abs(primary[0]),axis=(1,2,3)).tolist())
            results[cap+str(cone)]=out
            print(cap,cone,out['all'].get('mean_abs'),out['disjoint'].get('mean_abs'),flush=True)
    save('window-transfer.json',dict(locks=locks,training_seal=digest(ROOT/'train.json'),known_lowz_ids=len(seen),caps=results))


if __name__=='__main__':main()
