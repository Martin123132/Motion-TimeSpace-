from session import *

def integral(label):
    guard();bank=load(f"carrier-{label}.npz");a=bank["a"];tau=bank["tau"];N=np.log(a)
    d,q,p=np.moveaxis(bank["stress"],-1,0);k=bank["k"]
    both=[load(f"seed-{label}-{tag}.npz") for tag in ("1200","1500")];begin,end=[float(s["scale"]) for s in both]
    target=np.log([begin,end]);limits=PchipInterpolator(N,tau)(target)
    inside=(a>begin)&(a<end);tt=np.r_[limits[0],tau[inside],limits[1]];magnitude=begin*both[0]["qnorm"]
    num=make_interp_spline(tau,(a*q).T,k=7)(tt).T
    stored=num-num[:,:1]
    with np.load(prev.table("1500")) as bg:
        splines=[CubicSpline(bg["heavy_efold"],bg[key]) for key in ("phi_h","phidot_h","phase_h")]
        mass=float(bg["heavy_mass_mpc"]);rho=float(bg["rho_star"])
    f,v=[sp(N) for sp in splines[:2]];vn=splines[1](N,1);m2=(a*mass)**2
    carrier=a*mass/splines[2](N,1);lookup=make_interp_spline(tau,N,k=5)(tau,1)
    w1=m2*f;w2=a*mass*v;F=(w1*(d-p)/2+w2*a*mass*q/k[:,None])/(w1**2+w2**2)*(rho/a)
    basis=k[:,None]*a*a*F/rho;errclock=(vn+2*v)*(lookup-carrier);errtable=(vn+2*v)*carrier+m2*f
    integrands=np.stack([k[:,None]*a*p,basis*errclock,basis*errtable],axis=2)
    summary=[];coarse=None
    for stride in (4,2,1):
        keep=np.arange(0,len(tau),stride);assert keep[-1]==len(tau)-1
        primitive=make_interp_spline(tau[keep],integrands[:,keep].transpose(1,0,2),k=7).antiderivative()
        sums=(primitive(tt)-primitive(tt[:1])).transpose(1,0,2)
        physical=(stored-sums[:,:,0])/magnitude[:,None]
        corrected=physical-(sums[:,:,1]+sums[:,:,2])/magnitude[:,None]
        change=np.max(abs(sums[:,:,0]-coarse)/magnitude[:,None],axis=1) if coarse is not None else [None]*len(k)
        coarse=sums[:,:,0].copy()
        for j,node in enumerate(k):
            summary.append(dict(label=label,stride=stride,k=node,max_physical=np.max(abs(physical[j])),endpoint=physical[j,-1],
                max_corrected=np.max(abs(corrected[j])),quadrature_change=change[j],clock_defect=np.max(abs(sums[j,:,1]))/magnitude[j],
                table_defect=np.max(abs(sums[j,:,2]))/magnitude[j],lookup_vs_carrier=np.max(abs(lookup[inside]/carrier[inside]-1)),
                native_friedmann_vs_carrier=np.max(abs(bank["H"][inside]/carrier[inside]-1))))
        if stride==1:
            ix=np.unique(np.round(np.linspace(0,len(tt)-1,241)).astype(int))
            save(f"balance-{label}.npz",tau=tt[ix],k=k,measured=stored[:,ix],integrals=sums[:,ix],norm=magnitude)
    csvout(f"impulse-{label}.csv",summary)
    fine=[r for r in summary if r["stride"]==1]
    print(label,{key:max(abs(r[key]) for r in fine) for key in ("max_physical","endpoint","max_corrected","quadrature_change","lookup_vs_carrier","table_defect")},flush=True)
if __name__=="__main__":integral(sys.argv[1])

