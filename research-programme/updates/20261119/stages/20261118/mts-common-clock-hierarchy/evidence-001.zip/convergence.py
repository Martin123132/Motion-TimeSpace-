from session import *

def main(label,other):
    guard();left=load(f"carrier-{label}.npz");right=load(f"carrier-{other}.npz")
    assert np.array_equal(left["k"],right["k"]) and np.array_equal(left["history_indices"],right["history_indices"])
    hist=[];idx=left["history_indices"]
    for key,channel in zip(left["names"],range(len(left["names"])),strict=True):
        x=left["nonheavy"][:,:,channel];y=right["nonheavy"][:,:,channel]
        for j,k in enumerate(K):
            hist.append(dict(left=label,right=other,channel=key,k=k,peak_relative=np.max(abs(x[j]-y[j]))/max(np.max(abs(y[j])),1e-30)))
    csvout(f"matter-feedback-{label}-{other}.csv",hist)
    checks=[]
    for tag in ("1200","1500"):
        one=load(f"seed-{label}-{tag}.npz");two=load(f"seed-{other}-{tag}.npz")
        for j,k in enumerate(K):
            checks.append(dict(tag=tag,k=k,d=(one["D"][j]-two["D"][j])/two["dnorm"][j],
                q=(one["Q"][j]-two["Q"][j])/two["qnorm"][j],p=(one["P"][j]-two["P"][j])/two["dnorm"][j]))
    csvout(f"projected-convergence-{label}-{other}.csv",checks)
    print(label,other,"max sampled scale drift",np.max(abs(left["a"][idx]/right["a"][idx]-1)),"max nonheavy peak drift",max(r["peak_relative"] for r in hist),"projected", [max(abs(r[key]) for r in checks) for key in ("d","q","p")],flush=True)
if __name__=="__main__":main(*sys.argv[1:])

