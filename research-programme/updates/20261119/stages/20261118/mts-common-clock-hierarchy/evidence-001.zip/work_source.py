from session import *

def main(label):
    guard();src=engine();pp=params(src,"exact",label);model=src.camb.get_background(pp);model.Params.Accuracy.IntTolBoost=6.4
    with np.load(ROOT/f"carrier-{label}.npz") as c:
        tau=c["tau"];a=c["a"];h=c["H"];k=c["k"]
    names=["a","H","growth","v_baryon_cdm","delta_cdm","delta_baryon","etak","mts_drho_h","mts_drho_s","delta_tot_de","delta_nonu","mts_match_count"]
    raw=model.get_time_evolution(k,tau,vars=names,lAccuracyBoost=4);get=lambda name:raw[:,:,names.index(name)]
    assert np.array_equal(get("a")[0],a) and np.array_equal(get("H")[0],h) and np.all(get("mts_match_count")==0)
    bg=model.get_background_densities(a.copy(),vars=["cdm","baryon"]);frac=bg["baryon"]/(bg["cdm"]+bg["baryon"])
    weighted=(1-frac)*get("delta_cdm")+frac*get("delta_baryon")
    J=get("growth")*h*weighted+k[:,None]*frac*get("v_baryon_cdm")
    save("metric-work.npz" if label=="fine" else f"metric-work-{label}.npz",tau=tau,k=k,a=a,J=J,cdm=get("delta_cdm"),baryon=get("delta_baryon"))
    print("shared metric work",J.shape,"finite",np.isfinite(J).all(),flush=True)
if __name__=="__main__":main(sys.argv[1] if len(sys.argv)>1 else "fine")

