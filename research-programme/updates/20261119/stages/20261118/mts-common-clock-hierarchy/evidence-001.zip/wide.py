import session
from session import *

def remaining():
    full=np.sort(np.concatenate([prev.modes(panel) for panel in ("mid","quarter","outer","outer-mid")]))
    assert len(full)==len(np.unique(full))==37
    return np.sort(np.r_[np.setdiff1d(full,prev.modes("clock32")),37.])

def seeds(label):
    guard();src=engine();pp=params(src,"exact",label);model=src.camb.get_background(pp);model.Params.Accuracy.IntTolBoost=6.4
    with np.load(ROOT/"carrier-fine.npz") as first:
        a=first["a"];tau=first["tau"]
    with np.load(prev.table("1500")) as tab:
        phase=CubicSpline(tab["heavy_efold"],tab["phase_h"])
        centers=[float(np.load(prev.table(tag))["interface_a"]) for tag in ("1200","1500")]
        x=phase(np.log(a));use=np.logical_or.reduce([abs(x-phase(np.log(c)))<6.3*np.pi for c in centers])
        times=tau[use];names=["a","H","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count"]
        vals=model.get_time_evolution(session.K,times,vars=names,lAccuracyBoost=4)
        assert np.all(vals[:,:,5]==0) and np.isfinite(vals).all()
        aa=vals[0,:,0].copy();fields=vals[:,:,1:5].copy();rho=float(tab["rho_star"]);mass=float(tab["heavy_mass_mpc"])
        fields[:,:,1:]*=aa[None,:,None]/rho
        save("windows-"+label+".npz",tau=times,a=aa,k=session.K,H=fields[0,:,0],stress=fields[:,:,1:])
        for tag,center in zip(("1200","1500"),centers,strict=True):
            h,d,q,p=prev.projects(aa,fields,tab,center,6,8).T;pred,dnorm,qnorm=prev.pressure(session.K,center,mass,h,d,q)
            pe=[abs(p-pred)/dnorm];de=[];qe=[]
            for width,degree,thin in ((6,8,2),(4,8,1),(6,10,1)):
                ha,da,qa,pa=prev.projects(aa,fields,tab,center,width,degree,thin).T
                pr,nm,_=prev.pressure(session.K,center,mass,ha,da,qa)
                pe.append(abs(pa-pr)/nm);de.append(abs(da-d)/dnorm);qe.append(abs(qa-q)/qnorm)
            pe,de,qe=[np.max(l,axis=0) for l in (pe,de,qe)]
            ok=(pe<2e-6)&(np.maximum(de,qe)<2e-5)
            save(f"seed-{label}-{tag}.npz",k=session.K,scale=center,D=d,Q=q,P=p,H=h,dnorm=dnorm,qnorm=qnorm,pe=pe,de=de,qe=qe,eligible=ok)
            print(label,tag,"gates",int(np.sum(ok)),"/",len(ok),flush=True)
def main(action,label,*args):
    session.K=remaining()
    if action=="seeds":seeds(label)
    elif action=="late":
        from late import run
        run(label,*args)
    elif action=="bridge":
        from bridge import run
        run(label)
    else:raise ValueError(action)
if __name__=="__main__":main(*sys.argv[1:])

