from session import *

def main(label):
    guard()
    bank=load(f"carrier-{label}.npz");work=load("metric-work.npz" if label=="fine" else f"metric-work-{label}.npz")
    assert np.array_equal(work["tau"],bank["tau"]) and np.array_equal(work["k"],K)
    small=load(f"seed-{label}-1200.npz");end=load(f"seed-{label}-1500.npz")
    d,q,p=np.moveaxis(bank["stress"],-1,0);a=bank["a"];tau=bank["tau"];h=bank["H"]
    with np.load(prev.table("1500")) as table:
        mass=float(table["heavy_mass_mpc"])
        vel=CubicSpline(table["heavy_efold"],table["phidot_h"])(np.log(a))
        beta=a*vel**2/float(table["rho_star"])
        carrier=CubicSpline(table["heavy_efold"],table["phase_h"])(np.log(a))
    summary=[]
    centers=[float(small["scale"]),.00135,.001445,float(end["scale"])]
    def weights(center):
        theta=CubicSpline(np.log(a),carrier)(math.log(center));ids=np.where(abs(carrier-theta)<6*np.pi)[0]
        x=(carrier[ids]-theta)/(6*np.pi)
        columns=[x**n for n in range(9)]+[x**n*fn(2*carrier[ids]) for n in range(7) for fn in (np.cos,np.sin)]+[x**n*fn(4*carrier[ids]) for n in range(3) for fn in (np.cos,np.sin)]
        wt=np.linalg.pinv(np.array(columns).T)[0];assert abs(wt.sum()-1)<1e-12;return ids,wt
    allw=[weights(c) for c in centers]
    def project(vals,idx):
        ids,wt=allw[idx];return vals[...,ids]@wt
    for stride in (2,1):
        keep=np.arange(0,len(tau),stride)
        def primitive(rhs):
            poly=make_interp_spline(tau[keep],rhs[:,keep].T,k=7).antiderivative()
            return (poly(tau)-poly(tau[0])).T
        A=primitive(K[:,None]*a*p)
        const=(small["Q"]-project(A/a,0))/project(1/a,0)
        qpred=(const[:,None]+A)/a
        terms=[primitive(-3*h*p),primitive(-K[:,None]*qpred),primitive(work["J"]),primitive((beta-1)*work["J"])]
        nodesD=small["D"][:,None]+sum(val-project(val,0)[:,None] for val in terms)
        control=primitive(work["J"])-(work["cdm"]-work["cdm"][:,:1])
        for i,c in enumerate(centers[1:],1):
            true_d=project(d,i);true_q=project(q,i);hp=project(h,i);pred_d=project(nodesD,i);pred_q=project(qpred,i)
            _,dn,qn=prev.pressure(K,c,mass,hp,true_d,true_q)
            for j,mode in enumerate(K):
                pieces=[(project(val,i)-project(val,0))[j] for val in terms]
                summary.append(dict(k=mode,scale=c,stride=stride,pressure_work=pieces[0],current_transport=pieces[1],unit_metric_work=pieces[2],
                    oscillatory_metric_work=pieces[3],forecast_D=pred_d[j],actual_D=true_d[j],norm_D=dn[j],
                    forecast_Q=pred_q[j],actual_Q=true_q[j],norm_Q=qn[j],D_error=(pred_d[j]-true_d[j])/dn[j],Q_error=(pred_q[j]-true_q[j])/qn[j],
                    omitted_beta_error=(pred_d[j]-pieces[3]-true_d[j])/dn[j],cdm_work_error=(project(control,i)-project(control,0))[j]/max(abs(project(work["cdm"],i)[j]),1e-15)))
    csvout("retarded-work.csv" if label=="fine" else f"retarded-work-{label}.csv",summary)
    print({key:max(abs(r[key]) for r in summary if r["stride"]==1) for key in ("D_error","Q_error","omitted_beta_error","cdm_work_error")},flush=True)
if __name__=="__main__":main(sys.argv[1] if len(sys.argv)>1 else "fine")

