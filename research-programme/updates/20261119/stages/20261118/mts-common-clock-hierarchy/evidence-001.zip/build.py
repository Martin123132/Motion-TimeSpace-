from session import *
import difflib,subprocess,shutil

def replace_once(source,before,after):
    assert source.count(before)==1,before
    return source.replace(before,after)

def apply_hunks(source,lines):
    parts=lines.splitlines(keepends=True);before=[];after=[]
    def flush(text):return replace_once(text,"".join(before),"".join(after)) if before else text
    for line in parts:
        if line.startswith(("@@","---","+++")):
            source=flush(source);before=[];after=[]
        else:
            assert line[:1] in (" ","+","-"),repr(line)
            if line[:1]!="+": before.append(line[1:])
            if line[:1]!="-": after.append(line[1:])
    return flush(source)

def build():
    guard();runtime=ROOT/"engine";pkg=runtime/"native/camb";work=ROOT/"compile-job"
    assert not runtime.exists();work.mkdir(exist_ok=False)
    native=MATCH/"native";ft=native/"fortran";toolchain=prev.EARLY/"toolchain/mingw64"
    meta=read(MATCH/"runs/build-1/status.json");compiler=toolchain/"bin/gfortran.exe"
    assert sha(compiler)==meta["compiler_sha256"] and sha(native/"camb/cambdll.dll")==meta["dll_sha256"]
    protected={str(compiler):sha(compiler)}
    watch=lambda file:protected.update({str(file):sha(file)})
    for file in (FOREST/"native-changes.diff",FOREST/"ForestSwitch.f90",prev.PREV/"observer.diff"):watch(file)
    dif= (FOREST/"native-changes.diff").read_text().split("--- camb_python.orig")
    names=("results","MTSTwoField","equations","camb_python")
    sources={name:(ft/(name+".f90")).read_text() for name in names}
    for name in names:
        file=ft/(name+".f90");watch(file)
        assert protected[str(file)]==meta["input_hashes"][str(file)]
    res=sources["results"]
    for proc in ("Thermo_values","Thermo_expansion_values","Thermo_Init"):
        start=res.index("    subroutine "+proc+"(");first=res.index("\n",start)
        res=res[:first]+"\n    use MTSPhaseMesh, only: mts_mesh_active,mts_mesh_insert"+res[first:]
    res=replace_once(res,"    do i=1, ninverse+nlin\n","    call mts_mesh_insert(scale_factors,dt,times)\n    do i=1, size(scale_factors)\n")
    res=replace_once(res,"    times(ninverse+nlin) = State%tau0","    times(size(times)) = State%tau0")
    for proc,body in (("Thermo_values","        if (mts_mesh_active(a)) a=this%ScaleFactorAtTime%Value(tau)"),("Thermo_expansion_values","        if (mts_mesh_active(a)) then\n            a=this%ScaleFactorAtTime%Value(tau)\n            adot=this%ScaleFactorAtTime%Derivative(tau)\n        end if")):
        end=res.index("    end subroutine "+proc+"\n");pos=res.rindex("    end if",0,end);res=res[:pos]+body+"\n"+res[pos:]
    changed=dict(results=res,MTSTwoField=apply_hunks(sources["MTSTwoField"],dif[0]),camb_python=apply_hunks(sources["camb_python"],"--- camb_python.orig"+dif[1]),equations=apply_hunks(sources["equations"],(prev.PREV/"observer.diff").read_text()))
    switch=(FOREST/"ForestSwitch.f90").read_text()
    switch=replace_once(switch,"if(status/=0) error stop 'Missing forest checkpoint index'","if(status/=0) then\n    target=0;factor=1._dl;expected_scale=1._dl;return\nend if")
    try:
        rel=Path(os.path.relpath(toolchain,work));libdirs=["lib","lib/gcc/x86_64-w64-mingw32/14.2.0","x86_64-w64-mingw32/lib"]
        prefixes=["libexec/gcc/x86_64-w64-mingw32/14.2.0","bin",*libdirs]
        flags=["-B./",*["-B"+(rel/part).as_posix()+"/" for part in prefixes],*["-L"+(rel/part).as_posix() for part in libdirs],"-shared","-static","-cpp","-fopenmp","-O2","-fcheck=bounds","-fmax-errors=4","-fno-use-linker-plugin"]
        objects=[ft/key for key in meta["commands"][-1] if key.endswith(".o")];assert len(objects)==39
        copies=[obj for obj in objects if obj.stem not in changed]+list((ft/"WinMTS").glob("*.mod"))
        copies += [toolchain/prefixes[0]/item for item in ("f951.exe","collect2.exe")]+list((toolchain/"lib").glob("*.spec"))
        copies += [next(toolchain/part/obj for part in libdirs if (toolchain/part/obj).is_file()) for obj in ("dllcrt2.o","crtbegin.o","crtend.o")]
        for file in copies:watch(file);shutil.copyfile(file,work/file.name)
        for name,source in dict(PhaseMesh=(ROOT/"PhaseMesh.f90").read_text(),ForestSwitch=switch,**changed).items():
            (work/(name+".f90")).write_text(source,encoding="utf8")
        diff="".join("".join(difflib.unified_diff(sources[name].splitlines(True),source.splitlines(True),name+".orig",name+".f90")) for name,source in changed.items())
        with (ROOT/"native.diff").open("x",encoding="utf8") as stream:stream.write(diff)
        env=dict(os.environ,PATH=str(toolchain/"bin")+";"+os.environ["PATH"])
        commands=[["-I.","-J.","-ffree-line-length-none",name+".f90","-c","-o",name+".o"] for name in ("PhaseMesh","ForestSwitch",*names)]+[["PhaseMesh.o","ForestSwitch.o",*[obj.name for obj in objects],"-o","mesh.dll"]]
        for command in commands:
            proc=subprocess.run([str(compiler),*flags,*command],cwd=work,env=env,capture_output=True,text=True,timeout=210)
            if proc.returncode:raise RuntimeError(proc.stderr)
        pkg.mkdir(parents=True)
        for file in (native/"camb").iterdir():
            if file.is_file() and file.suffix in (".py",".dat"):watch(file);shutil.copyfile(file,pkg/file.name)
        for file,dest in [(ft/"HighLExtrapTemplate_lenspotentialCls.dat",pkg),(MATCH/"matching_common.py",runtime),(MATCH/"stage_common.py",runtime)]:
            watch(file);shutil.copyfile(file,dest/file.name)
        shutil.copyfile(work/"mesh.dll",pkg/"cambdll.dll")
        write("build.json",dict(inputs=protected,binary=sha(pkg/"cambdll.dll"),commands=commands))
    finally:
        assert work.resolve().parent==ROOT and work.name=="compile-job"
        for item in work.iterdir():
            assert not item.is_symlink() and item.is_file();item.unlink()
        work.rmdir()
    print("private common-clock hierarchy ready",flush=True)
if __name__=="__main__":build()

