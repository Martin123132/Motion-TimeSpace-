from session import *
import projection

def main():
    guard();projection.load=load;results=[]
    mapping=list(csv.DictReader((FOREST/"forest-radial-inputs.csv").open()))
    kx=max(float(r["k_parent"]) for r in mapping if float(r["z"])==4.2);cut=37.
    constants=prev.read(prev.PREV/"primordial-settings.json");parity=[]
    bands=list(csv.DictReader((ROOT/"full-grid-bands.csv").open()))
    for case,arm in (("heavy","wave"),("heavy","off"),("cold","cold")):
        tag="1200" if case=="heavy" else "225";blocks=[]
        for panel in ("fine","wide"):
            source=load(f"source-{panel}-{case}-{tag}.npz");gas=load(f"gas-{panel}-{case}-{tag}.npz")
            k=gas["k"];keep=(k!=37) if panel=="wide" else np.ones(len(k),bool);h=source["h"][-1]*prev.SPEED
            params=gas[arm+"-1-2048-1"][-1]
            prim=constants["As"]*(k/constants["pivot_Mpc"])**(constants["ns"]-1)
            blocks.extend(np.column_stack([k,prim*params[:,1]**2,prim*params[:,2]**2])[keep])
        data=np.array(sorted(blocks,key=lambda r:r[0]));assert len(data)==37
        density=PchipInterpolator(np.log(data[:,0]),data[:,1]);velocity=PchipInterpolator(np.log(data[:,0]),data[:,2])
        thermal=.25*(kx/h)**2*(2*1.380649e-23*1e4/(1.67262192369e-27*1e6));B=2-.5*(.7+thermal)
        pref=np.pi*h*.65**2*np.exp(-2*thermal);row=next(r for r in bands if r["arm"]==arm and float(r["lo"])==kx and float(r["hi"])==cut)
        partial=float(row["area"]);threshold=math.sqrt(.01*partial*cut/pref)
        lo=24.;hi=37.;sigD=np.sqrt(density.integrate(np.log(lo),np.log(hi)));sigU=np.sqrt(velocity.integrate(np.log(lo),np.log(hi)))
        diagnostic=pref/lo*(abs(B)*sigD+(kx/lo)**2*sigU)**2
        resolved=next(float(r["area"]) for r in bands if r["arm"]==arm and float(r["lo"])==lo and float(r["hi"])==hi)
        results.append(dict(arm=arm,k_radial=kx,cut=cut,partial_kms=partial,tolerance_fraction=.01,
            abs_density_weight=abs(B),velocity_weight=(kx/cut)**2,required_weighted_rms_upper=threshold,
            last_resolved_sigma_b=sigD,last_resolved_sigma_u=sigU,finite_band_bound_diagnostic=diagnostic,last_resolved_area=resolved,
            external_variance_bound_available=False,tail_certified=False))
        if arm=="wave":
            cold=next(float(r["area"]) for r in bands if r["arm"]=="cold" and float(r["lo"])==kx and float(r["hi"])==cut)
            for share in (.5,1.):
                necessary=max(0.,share*cold-partial)
                parity.append(dict(fraction_of_cold_total_requested=share,wave_finite=partial,cold_finite=cold,
                    minimum_missing_wave_power=necessary,minimum_in_units_of_wave_finite=necessary/partial,
                    minimum_tail_response_rms=math.sqrt(necessary*cut/pref),density_weight=abs(B),velocity_weight=(kx/cut)**2))
    csvout("missing-tail-budget.csv",results)
    csvout("tail-parity-requirement.csv",parity)
    print("sufficient weighted RMS ceilings",[(r["arm"],r["required_weighted_rms_upper"]) for r in results])
if __name__=="__main__":main()

