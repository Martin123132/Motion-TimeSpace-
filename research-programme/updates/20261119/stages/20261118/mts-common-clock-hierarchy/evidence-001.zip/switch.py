from session import *

def run(label,case,tag,arm):
    guard();src=engine();assert arm in ("on","off") and os.environ.get("MTS_FOREST_FACTOR")==("1" if arm=="on" else "0")
    assert os.environ.get("MTS_FOREST_INDEX")=="1" and os.environ.get("MTS_FOREST_SCALE")=="0.01"
    name=f"switch-{label}-{case}-{tag}-{arm}";folder=ROOT/name;folder.mkdir(exist_ok=False);os.chdir(folder)
    pp=params(src,tag,label,case,load(f"seed-{label}-{tag}.npz") if case=="heavy" else None)
    model=src.camb.get_background(pp);model.Params.Accuracy.IntTolBoost=6.4
    tau=model.conformal_time(Z,tol=1e-10)
    names=["a","H","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count","mts_nonheavy_change","etak","Weyl","v_newtonian_cdm","v_newtonian_baryon","delta_baryon","delta_cdm","delta_photon"]
    raw=model.get_time_evolution(K,tau,vars=names,lAccuracyBoost=4)
    get=lambda key:raw[:,:,names.index(key)]
    assert np.isfinite(raw).all() and np.all(get("mts_match_count")==int(case=="heavy")) and not np.any(get("mts_nonheavy_change")) and len(list(folder.glob("initial-*.bin")))==len(K)
    phi=get("etak")/K[:,None]+(get("H")/K[:,None])**2*get("v_newtonian_cdm")
    observables=np.stack([K[:,None]**2*phi-2*get("Weyl"),get("delta_baryon")+3*(get("H")/K[:,None])**2*get("v_newtonian_cdm"),get("v_newtonian_baryon")],axis=2).transpose(1,0,2)
    with np.load(prev.table("1500")) as bg:rho=float(bg["rho_star"])
    save(name+"/result.npz",k=K,z=Z,names=names,raw=raw,obs=observables,D=get("mts_drho_h")*get("a")/rho,Q=get("mts_q_h")*get("a")/rho,P=get("mts_dp_h")*get("a")/rho)
    print(name,"finished",flush=True)
if __name__=="__main__":run(*sys.argv[1:])

