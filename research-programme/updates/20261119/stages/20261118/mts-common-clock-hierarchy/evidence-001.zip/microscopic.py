from session import *
from scipy.integrate import cumulative_simpson

def physical_mesh(model,table):
    first=float(np.load(prev.table("1200"))["interface_a"]);last=float(table["interface_a"])
    phase=CubicSpline(table["heavy_efold"],table["phase_h"]);inverse=PchipInterpolator(table["phase_h"],table["heavy_efold"])
    low=float(phase(math.log(first)))-6.5*np.pi;high=float(phase(math.log(last)))+6.5*np.pi
    count=8*math.ceil((high-low)/(.078*8))
    x=np.linspace(low,high,count+1);a=np.exp(inverse(x));mass=float(table["heavy_mass_mpc"])
    initial=model.conformal_time(1/a[0]-1,tol=1e-10)
    return initial+cumulative_simpson(1/(a*mass),x=x,initial=0)

def run(label):
    guard();src=engine();pp=params(src,"exact",label);model=src.camb.get_background(pp);model.Params.Accuracy.IntTolBoost=6.4
    with np.load(prev.table("1500")) as bg:
        tau=physical_mesh(model,bg);rho=float(bg["rho_star"]);mass=float(bg["heavy_mass_mpc"])
        names=["a","H","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count","Weyl","etak","delta_cdm","delta_baryon","delta_photon","delta_neutrino","v_newtonian_baryon"]
        raw=model.get_time_evolution(K,tau,vars=names,lAccuracyBoost=4)
        assert np.isfinite(raw).all() and np.all(raw[:,:,5]==0)
        a=raw[0,:,0].copy();h=raw[0,:,1].copy()
        assert np.all(raw[:,:,0]==a) and np.all(np.diff(a)>0)
        fields=raw[:,:,1:5].copy();fields[:,:,1:]*=a[None,:,None]/rho
        checkpoints=np.unique(np.round(np.linspace(0,len(a)-1,201)).astype(int))
        save(f"carrier-{label}.npz",k=K,tau=tau,a=a,H=h,stress=fields[:,:,1:],nonheavy=raw[:,checkpoints,6:],names=names[6:],history_indices=checkpoints)
        del raw
        for tag in ("1200","1500"):
            center=float(np.load(prev.table(tag))["interface_a"]);averaged=prev.projects(a,fields,bg,center,6,8)
            hbar,d,q,p=averaged.T;pred,dnorm,qnorm=prev.pressure(K,center,mass,hbar,d,q)
            err=[abs(p-pred)/dnorm];ds=[];qs=[]
            for width,deg,thin in ((6,8,2),(4,8,1),(6,10,1)):
                ha,da,qa,pa=prev.projects(a,fields,bg,center,width,deg,thin).T
                pa0,nrm,_=prev.pressure(K,center,mass,ha,da,qa)
                err.append(abs(pa-pa0)/nrm);ds.append(abs(da-d)/dnorm);qs.append(abs(qa-q)/qnorm)
            pe=np.max(err,axis=0);de=np.max(ds,axis=0);qe=np.max(qs,axis=0)
            save(f"seed-{label}-{tag}.npz",k=K,scale=center,D=d,Q=q,P=p,H=hbar,dnorm=dnorm,qnorm=qnorm,
                eligible=(pe<2e-6)&(np.maximum(de,qe)<2e-5),pe=pe,de=de,qe=qe)
            print(label,tag,"phase gates",len(K),max(pe),max(de),max(qe),flush=True)
    print(label,len(tau),"actual epochs",a[0],a[-1],flush=True)
if __name__=="__main__":run(sys.argv[1])

