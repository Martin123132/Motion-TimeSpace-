from session import *
import ast

def records(name):
    with (ROOT/name).open(encoding="utf8",newline="") as stream:return list(csv.DictReader(stream))

def verify(seal):
    guard();checks=[]
    def require(label,ok):
        if not ok:raise AssertionError(label)
        checks.append(label)
    for file in ROOT.glob("*.py"):ast.parse(file.read_text(encoding="utf8"))
    inputs=read("build.json")["inputs"];require("all native build sources fingerprinted",len(inputs)>90 and all(sha(p)==value for p,value in inputs.items()))
    native=ROOT/"engine/native/camb/cambdll.dll";require("private binary",sha(native)==read("build.json")["binary"] and sha(native)!=sha(MATCH/"native/camb/cambdll.dll"))
    expected=read(MATCH/"runs/build-1/status.json")["input_hashes"]
    for file in ("results","MTSTwoField","equations","camb_python"):
        path=str(MATCH/"native/fortran"/(file+".f90"));require("original "+file,sha(path)==expected[path]==inputs[path])
    require("previous stage fingerprint",sha(PRIOR/"closeout.json")==LOCK)
    protected={}
    old=read(PRIOR/"closeout.json")
    for path,expected_hash in old["protected"].items():
        protected[path]=sha(path)
        require("inherited physical input "+path,protected[path]==expected_hash)
    for name in ("local.py","gas.py","projection.py","kernel.py","transfer.py","background-1200.npz","background-1500.npz","node-gates.csv","finite-bands.csv","gas-outer-cold-225.npz","source-outer-cold-225.npz"):
        path=PRIOR/name;protected[str(path)]=sha(path);require("retained "+name,protected[str(path)]==old["files"][name])
    for label in ("coarse","fine","finer"):
        carrier=load(f"carrier-{label}.npz")
        require("entire microscopic interval "+label,len(carrier["a"])>100000 and min(carrier["a"])<.0012 and max(carrier["a"])>.0015 and np.array_equal(K,carrier["k"]) and np.all(np.diff(carrier["tau"])>0))
        ledger=[r for r in records(f"impulse-{label}.csv") if r["stride"]=="1"]
        require("raw integrated pressure-current identity "+label,len(ledger)==4 and max(float(r["max_physical"]) for r in ledger)<2e-5)
        require("separate quadrature "+label,max(float(r["quadrature_change"]) for r in ledger)<2e-6)
        for tag in ("1200","1500"):
            seed=load(f"seed-{label}-{tag}.npz");require("projection windows "+label+tag,np.all(seed["eligible"]))
    for label in ("fine","finer"):
        work=records("retarded-work.csv" if label=="fine" else "retarded-work-finer.csv")
        core=[r for r in work if r["stride"]=="1"]
        require("action work, independent pressure inputs "+label,len(core)==12 and all(max(abs(float(r["Q_error"])),abs(float(r["D_error"])))<2e-5 for r in core))
        require("CDM metric source test "+label,max(abs(float(r["cdm_work_error"])) for r in core)<2e-5)
    for label,other in (("fine","coarse"),("finer","fine")):
        hist=records(f"matter-feedback-{label}-{other}.csv")
        require("independent live-species mesh replays "+label,len({r["channel"] for r in hist})==7 and max(float(r["peak_relative"]) for r in hist)<2e-5)
    for tag in ("1200","1500"):
        for arm in ("on","off"):
            data=load(f"switch-fine-heavy-{tag}-{arm}/result.npz");require("complete native intervention "+tag+arm,data["obs"].shape==(7,4,3))
        for left in (ROOT/f"switch-fine-heavy-{tag}-on").glob("initial-*.bin"):
            require("identical native preparation "+tag+left.name,sha(left)==sha(ROOT/f"switch-fine-heavy-{tag}-off"/left.name))
    require("unheated native vs predicted off/on",max(float(r["standalone_vs_full"]) for r in records("native-interventions.csv"))<2e-5)
    require("fully native force velocity density interface",all(max(float(r[k]) for k in ("force","gas","velocity"))<2e-5 for r in records("native-interfaces.csv")))
    require("bitwise cold switch",np.array_equal(load("switch-fine-cold-225-on/result.npz")["raw"],load("switch-fine-cold-225-off/result.npz")["raw"]))
    null=records("cold-null.csv");require("disabled private solver and active cold control",all(r["bit_identical"]=="True" for r in null if r["label"]=="stock") and max(float(r["relative"]) for r in null)<2e-5)
    nodes=records("full-grid-gates.csv");bands=records("full-grid-bands.csv");states=records("bridge-state-gates.csv")
    require("complete two-surface acquisitions",len(states)==76 and all((max(abs(float(r["d"])),abs(float(r["q"])))<2e-5 and abs(float(r["p"]))<2e-6)==(r["passes"]=="True") for r in states))
    for arm in ("wave","off","exact","cold"):
        row=[r for r in nodes if r["arm"]==arm]
        require("all 37 knots "+arm,len(row)==len({r["k"] for r in row})==37)
        for r in row:
            late=r["local_pressure_and_windows"]=="True" and max(float(r[k]) for k in ("interface_transfer","mesh_transfer","interface_integrand","mesh_integrand","solver"))<2e-5
            require("source gate classification "+arm+r["k"],late==(r["new_late_pass"]=="True") and (late and r["bridge_state_pass"]=="True")==(r["all_pass"]=="True"))
        subset=[r for r in bands if r["arm"]==arm]
        full=max(subset,key=lambda r:float(r["hi"])-float(r["lo"]));parts=sum(float(r["area"]) for r in subset if float(r["lo"]) in (prev.modes("mid")[-1],12.,24.) or float(r["hi"])==prev.modes("mid")[-1])
        require("finite partition "+arm,len(subset)==6 and abs(parts/float(full["area"])-1)<1e-12 and all(r["all_pass"]=="True" for r in row)==(full["state_support"]=="True"))
    require("overlap anchor not double counted",all(abs(float(r["kernel_change"]))<2e-5 for r in records("repeat-anchor.csv")))
    tail=records("missing-tail-budget.csv");require("tail not fabricated",len(tail)==3 and all(r["tail_certified"]=="False" and float(r["required_weighted_rms_upper"])>0 for r in tail))
    parity=records("tail-parity-requirement.csv")
    require("unseen positive power necessary for parity",len(parity)==2 and all(abs(float(r["minimum_missing_wave_power"])+float(r["wave_finite"])-float(r["fraction_of_cold_total_requested"])*float(r["cold_finite"]))<1e-12 and float(r["minimum_tail_response_rms"])>0 for r in parity))
    gravity=records("gravitating-source-response.csv")
    require("signed source census",len(gravity)==56 and all(abs(sum(float(r[c]) for c in ("change_heavy","change_baryon","change_cdm","change_remainder"))-float(r["change_total"]))<1e-11 for r in gravity))
    require("pressure-on independent metric source constraint",max(abs(float(r["on_constraint_error_peak"])) for r in gravity)<2e-5)
    require("finite-band results present",(ROOT/"BAND-RESULT.md").stat().st_size>100)
    require("no temporary compiler or bytecode",not list(ROOT.rglob("__pycache__")) and not (ROOT/"compile-job").exists())
    files={p.relative_to(ROOT).as_posix():sha(p) for p in sorted(ROOT.rglob("*")) if p.is_file() and p.name!="closeout.json"}
    bundle=dict(previous=LOCK,files=files,protected=protected,checks=checks.copy())
    if seal:write("closeout.json",bundle)
    else:require("sealed private research and inputs",read("closeout.json")==bundle)
    print(len(bundle["checks"]),"checks",len(files),"files",len(inputs)+len(protected),"source entries",sha(ROOT/"closeout.json"))
if __name__=="__main__":verify(sys.argv[1:]==["--seal"])

