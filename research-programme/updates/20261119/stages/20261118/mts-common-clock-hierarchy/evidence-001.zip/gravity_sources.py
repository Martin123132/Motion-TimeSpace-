from session import *

def main():
    guard();out=[]
    for tag in ("1200","1500"):
        env=load("source-fine-heavy-"+tag+".npz")
        indices=np.searchsorted(env["N"],env["epochs"])
        assert np.array_equal(env["N"][indices],env["epochs"]) and np.array_equal(env["k"],K)
        weights=env["g"][:,indices]
        independent_on=env["external"][:,indices,:2].sum(axis=2)
        source={}
        for arm in ("on","off"):
            data=load(f"switch-fine-heavy-{tag}-{arm}/result.npz");raw=data["raw"];names=data["names"].tolist()
            get=lambda key:raw[:,:,names.index(key)]
            h=get("H");k=K[:,None];cd=get("v_newtonian_cdm");vb=get("v_newtonian_baryon")
            matter=np.stack([weights[0]*get("delta_cdm"),weights[1]*(get("delta_baryon")+3*(h/k)**2*(cd-vb)),
                weights[2]*(data["D"]+3*h*data["Q"]/k)],axis=-1)
            total=data["obs"][:,:,0].T
            source[arm]=np.concatenate([matter,(total-matter.sum(axis=2))[:,:,None],total[:,:,None]],axis=2)
        delta=source["off"]-source["on"]
        assert np.array_equal(delta[:,0],np.zeros_like(delta[:,0]))
        for j,node in enumerate(K):
            for i,z in enumerate(Z):
                dc,db,dh,extra,total=delta[j,i]
                out.append(dict(tag=tag,k=node,z=z,on_total=source["on"][j,i,-1],on_heavy=source["on"][j,i,2],
                    off_total=source["off"][j,i,-1],off_heavy=source["off"][j,i,2],change_total=total,
                    change_cdm=dc,change_baryon=db,change_heavy=dh,change_remainder=extra,
                    independent_on_external_and_slip=independent_on[j,i],
                    on_constraint_error_peak=(source["on"][j,i,3]-independent_on[j,i])/np.max(abs(source["on"][j,:,4])),
                    fraction_of_change_from_heavy=dh/total if total!=0 else None,
                    fraction_of_change_from_ordinary=(db+dc)/total if total!=0 else None))
    csvout("gravitating-source-response.csv",out)
    final=[r for r in out if r["z"]==4.2]
    for key in ("fraction_of_change_from_heavy","fraction_of_change_from_ordinary"):
        print(key,min(r[key] for r in final),max(r[key] for r in final),flush=True)
if __name__=="__main__":main()

