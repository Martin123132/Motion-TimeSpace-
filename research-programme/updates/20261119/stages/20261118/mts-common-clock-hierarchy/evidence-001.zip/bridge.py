from session import *

def run(label):
    guard();src=engine();s1=load(f"seed-{label}-1200.npz");s2=load(f"seed-{label}-1500.npz")
    pp=params(src,"1200",label,seed=s1);engine0=src.camb.get_background(pp);engine0.Params.Accuracy.IntTolBoost=6.4
    a1=float(s1["scale"]);a2=float(s2["scale"])
    with np.load(prev.table("1500")) as bg:rho=float(bg["rho_star"])
    interval=np.geomspace(a1*(1+1e-6),a2*(1+1e-5),4097)
    tau=engine0.conformal_time(1/interval-1,tol=1e-10)
    names=["a","H","mts_drho_h","mts_q_h","mts_dp_h","mts_match_count","delta_cdm","delta_baryon","etak","Weyl","delta_photon","delta_neutrino"]
    raw=engine0.get_time_evolution(K,tau,vars=names,lAccuracyBoost=4)
    a=raw[0,:,0].copy()
    assert np.isfinite(raw).all() and np.all(raw[:,:,5]==1) and a[0]/a1-1<8e-6 and a[0]<a2<a[-1]
    end=CubicSpline(np.log(a),(raw[:,:,2:5]*a[None,:,None]/rho).transpose(1,0,2))(math.log(a2))
    defect=(np.column_stack([s2["D"],s2["Q"],s2["P"]])-end)/np.column_stack([s2["dnorm"],s2["qnorm"],s2["dnorm"]])
    save(f"bridge-{label}.npz",k=K,a=a,tau=tau,names=names,raw=raw,end=end,defect=defect)
    print(label,"early switch -> direct endpoint D/Q/P",np.max(abs(defect),axis=0),flush=True)
if __name__=="__main__":run(sys.argv[1])

