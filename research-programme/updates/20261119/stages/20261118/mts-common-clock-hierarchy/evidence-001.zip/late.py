from session import *

def run(label,case,tag):
    guard();src=engine()
    assert "MTS_FOREST_INDEX" not in os.environ
    use_mesh(src,label,tag if case=="heavy" else "none")
    import transfer
    assert Path(transfer.__file__).resolve()==PRIOR/"transfer.py"
    assert sha(PRIOR/"transfer.py")==read(PRIOR/"closeout.json")["files"]["transfer.py"]
    transfer.guard=guard;transfer.native=lambda kind:src;transfer.modes=lambda panel:K
    transfer.save=save;transfer.load=load
    transfer.run(label,case,tag,"full")
    import gas
    assert Path(gas.__file__).resolve()==PRIOR/"gas.py" and sha(PRIOR/"gas.py")==read(PRIOR/"closeout.json")["files"]["gas.py"]
    gas.guard=guard;gas.save=save;gas.load=load;gas.main(f"{label}-{case}-{tag}")
if __name__=="__main__":run(*sys.argv[1:])

