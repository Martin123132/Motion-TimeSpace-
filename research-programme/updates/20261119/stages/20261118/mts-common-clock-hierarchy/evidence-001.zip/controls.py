from session import *

def select_native(name,case,tag):
    bank=load(f"source-{name}-{case}-{tag}.npz")
    gas=load(f"gas-{name}-{case}-{tag}.npz")
    return bank,gas

def main():
    guard();rows=[];null=[]
    on=lambda case,tag,arm:load(f"switch-fine-{case}-{tag}-{arm}/result.npz")
    for case,tag in (("heavy","1200"),("heavy","1500"),("cold","225")):
        source,gas=select_native("fine",case,tag);pp=on(case,tag,"on");off=on(case,tag,"off")
        for left in sorted((ROOT/f"switch-fine-{case}-{tag}-on").glob("initial-*.bin")):
            right=ROOT/f"switch-fine-{case}-{tag}-off"/left.name
            assert sha(left)==sha(right)
        assert np.array_equal(off["raw"][:,0],pp["raw"][:,0])
        if case=="cold":assert np.array_equal(off["raw"],pp["raw"])
        for arm,data in (("on",pp),("off",off)):
            surrogate=gas[(("exact" if arm=="on" else "off") if case=="heavy" else "cold")+"-0-2048-1"]
            scale=np.maximum(np.max(abs(data["obs"]),axis=0),1e-30)
            for j,k in enumerate(K):
                rows.append(dict(case=case,tag=tag,arm=arm,k=k,
                    standalone_vs_full=float(np.max(abs(surrogate[:,j]-data["obs"][:,j])/scale[j])),
                    relative_standalone=float(np.max(abs(surrogate[:,j]/data["obs"][:,j]-1))),
                    epoch99_D=data["D"][j,0],epoch99_Q=data["Q"][j,0],final_force=data["obs"][-1,j,0],
                    final_gas=data["obs"][-1,j,1],final_velocity=data["obs"][-1,j,2]))
    saved=prev.load("gas-outer-cold-225.npz");idx=np.searchsorted(saved["k"],K)
    oldsrc=prev.load("source-outer-cold-225.npz")
    assert np.array_equal(saved["k"][idx],K)
    for label in ("stock","fine"):
        src,gas=select_native(label,"cold","225")
        for key in ("cold-0-2048-1","cold-1-2048-1"):
            ref=saved[key][:,idx];new=gas[key]
            null.append(dict(label=label,key=key,bit_identical=bool(np.array_equal(new,ref)),
                relative=float(np.max(abs(new/ref-1))),native_truth_identical=bool(np.array_equal(src["truth"],oldsrc["truth"][:,idx])),
                native_truth_relative=float(np.max(abs(src["truth"]/oldsrc["truth"][:,idx]-1)))))
    interfaces=[]
    for arm in ("on","off"):
        first=on("heavy","1200",arm);later=on("heavy","1500",arm)
        for i,k in enumerate(K):
            changes=np.max(abs(first["obs"][:,i]/later["obs"][:,i]-1),axis=0)
            interfaces.append(dict(arm=arm,k=k,force=changes[0],gas=changes[1],velocity=changes[2],
                epoch99_density_rel=first["D"][i,0]/later["D"][i,0]-1,
                epoch99_current_rel=first["Q"][i,0]/later["Q"][i,0]-1,
                final_force_ratio=on("heavy","1200","off")["obs"][-1,i,0]/on("heavy","1200","on")["obs"][-1,i,0]))
    csvout("native-interventions.csv",rows);csvout("cold-null.csv",null);csvout("native-interfaces.csv",interfaces)
    print("native vs reduced",max(r["standalone_vs_full"] for r in rows),"native interface",max(max(r[x] for x in ("force","gas","velocity")) for r in interfaces),"cold",null,flush=True)
if __name__=="__main__":main()

