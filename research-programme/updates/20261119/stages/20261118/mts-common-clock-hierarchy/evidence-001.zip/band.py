from session import *
from functools import lru_cache
import projection

@lru_cache(maxsize=24)
def sample(label,case,tag,arm):
    projection.load=load
    return projection.sample(label,case,tag,arm)
@lru_cache(maxsize=8)
def gasdata(label,case,tag):return load(f"gas-{label}-{case}-{tag}.npz")

def proper(label,tag,case,arm):
    data=sample(label,case,tag,arm)
    gas=gasdata(label,case,tag)
    return data,gas[arm+"-1-2048-1"]

def main():
    guard();out=[];bands=[];joins=[];surfaces=[]
    oldrows=list(csv.DictReader((PRIOR/"node-gates.csv").open()))
    oldband=list(csv.DictReader((PRIOR/"finite-bands.csv").open()))
    oldpass={(r["arm"],float(r["k"])):r["passes_common_gate"]=="True" for r in oldrows}
    for pair in (("fine","coarse"),("wide","wideCoarse")):
        for label in pair:
            br=load(f"bridge-{label}.npz")
            for node,res in zip(br["k"],br["defect"],strict=True):
                surfaces.append(dict(label=label,k=node,d=res[0],q=res[1],p=res[2],passes=bool(max(abs(res[:2]))<2e-5 and abs(res[2])<2e-6)))
    for case,arm in (("heavy","wave"),("heavy","off"),("heavy","exact"),("cold","cold")):
        rows37=[];alt37=[];coarse37=[]
        for label,coarse in (("fine","coarse"),("wide","wideCoarse")):
            tag="1200" if case=="heavy" else "225"
            x,raw=proper(label,tag,case,arm)
            if case=="heavy":
                other,twice=proper(label,"1500",case,arm);xx,rawco=proper(coarse,tag,case,arm);yy,twiceco=proper(coarse,"1500",case,arm)
                assert all(np.array_equal(z[:,0],x[:,0]) for z in (other,xx,yy))
                interface=np.maximum(np.max(abs(raw/twice-1),axis=0),np.max(abs(rawco/twiceco-1),axis=0))
                mesh=np.maximum(np.max(abs(raw/rawco-1),axis=0),np.max(abs(twice/twiceco-1),axis=0))
                kinter=np.maximum(abs(x[:,3]/other[:,3]-1),abs(xx[:,3]/yy[:,3]-1))
                kmesh=np.maximum(abs(x[:,3]/xx[:,3]-1),abs(other[:,3]/yy[:,3]-1))
                localpass=np.logical_and.reduce([load(f"seed-{lab}-{key}.npz")["eligible"] for key in ("1200","1500") for lab in (label,coarse)])
                inp=np.logical_and.reduce([np.max(abs(load(f"bridge-{lab}.npz")["defect"])/np.array([2e-5,2e-5,2e-6]),axis=1)<1 for lab in (label,coarse)])
                allx=(x,other,xx,yy)
            else:
                other=x.copy();xx=x.copy();yy=x.copy()
                expected={float(r["k"]):float(r["integrand"]) for r in oldrows if r["arm"]=="cold"}
                kmesh=np.array([abs(v/expected[float(node)]-1) for node,v in x[:,[0,3]]])
                interface=mesh=np.zeros((len(x),3));kinter=np.zeros(len(x));localpass=inp=np.ones(len(x),bool);allx=(x,)
            solver=np.maximum.reduce([np.max(np.column_stack([abs(z[:,4]/z[:,3]-1),abs(z[:,5]/z[:,3]-1),z[:,6],z[:,7]]),axis=1) for z in allx])
            for j,node in enumerate(x[:,0]):
                if label=="wide" and node==37.:
                    ctrl=sample("fine",case,tag,arm)[-1];joins.append(dict(arm=arm,k=node,kernel_change=x[j,3]/ctrl[3]-1,
                        signed_amplitude_change=(x[j,1]+x[j,2])/(ctrl[1]+ctrl[2])-1))
                    continue
                accepted=bool(localpass[j] and max(max(interface[j]),max(mesh[j]),kmesh[j],kinter[j],solver[j])<2e-5)
                out.append(dict(arm=arm,k=node,integrand=x[j,3],interface_transfer=max(interface[j]),mesh_transfer=max(mesh[j]),
                    interface_integrand=kinter[j],mesh_integrand=kmesh[j],solver=solver[j],local_pressure_and_windows=bool(localpass[j]),
                    previous_late_pass=oldpass[(arm,float(node))],new_late_pass=accepted,bridge_state_pass=bool(inp[j]),all_pass=bool(accepted and inp[j])))
                rows37.append(x[j]);alt37.append(other[j]);coarse37.append(xx[j])
        data=projection.ordered(np.array(rows37));alt=projection.ordered(np.array(alt37));co=projection.ordered(np.array(coarse37))
        assert len(data)==37
        few=data[np.isin(data[:,0],np.r_[prev.modes("mid"),prev.modes("outer")])]
        old={ (float(r["lo"]),float(r["hi"])):r for r in oldband if r["arm"]==arm}
        for (lo,hi),original in old.items():
            mainint=projection.integral(data,lo,hi);area=mainint["primary"]
            support=data[max(0,np.searchsorted(data[:,0],lo)-1):min(len(data),np.searchsorted(data[:,0],hi)+2),0]
            relevant=[r for r in out if r["arm"]==arm and r["k"] in support]
            bands.append(dict(arm=arm,lo=lo,hi=hi,area=area,change_vs_old=area/float(original["primary"])-1,
                late_join=projection.integral(alt,lo,hi)["primary"]/area-1,mesh=projection.integral(co,lo,hi)["primary"]/area-1 if case=="heavy" else None,
                frequency_refinement=area/projection.integral(few,lo,hi)["primary"]-1,signed_interpolation=mainint["signed_field"]/area-1,
                late_support=all(r["new_late_pass"] for r in relevant),state_support=all(r["all_pass"] for r in relevant)))
    csvout("full-grid-gates.csv",out);csvout("full-grid-bands.csv",bands);csvout("repeat-anchor.csv",joins);csvout("bridge-state-gates.csv",surfaces)
    for arm in ("wave","exact","off","cold"):
        group=[r for r in out if r["arm"]==arm]
        print(arm,[(key,sum(r[key] for r in group)) for key in ("previous_late_pass","new_late_pass","all_pass")],flush=True)
if __name__=="__main__":main()

