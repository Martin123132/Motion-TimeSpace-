from species import *
from datetime import datetime, timezone


def verify():
    guard()
    checks={}
    def check(label, value):
        if not value:
            raise RuntimeError(label)
        checks[label]=True
    old=study.read(PRIOR/'closeout.json')['files']
    for name,item in old.items():
        path=PRIOR/name
        assert study.digest(path)==item['sha256'] and path.stat().st_size==item['bytes']
    check('unchanged 79-file preceding stage',len(old)==79)
    sources={}
    for case in ('cold','heavy'):
        direct,mixed,projection,physical=(study.read(HERE/(case+'-'+key+'.json')) for key in ('direct','mixed','projection','physical'))
        for name,sha in (direct['input_sha256']|mixed['source_hashes']).items():
            check('input '+name,study.digest(PARENT/name)==sha)
            sources[name]=sha
        with np.load(HERE/(case+'-direct.npz')) as data:
            truth=data['direct']; rebuilt=data['traces'].sum(axis=1)+data['species_correction'].sum(axis=1)+data['background_correction']
            check(case+' independent species recombination matches full capture',np.array_equal(data['epoch'],np.arange(1991,4253)) and
                  np.all(abs(rebuilt-truth)<study.TOL*abs(truth)) and max(abs(rebuilt-truth))<1e-15)
            raw=int(np.count_nonzero(abs(data['traces'].sum(axis=1)-truth)<=study.TOL*abs(truth)))
            check(case+' direct raw negative/control test',raw==direct['within_2e-5_raw']==(2262 if case=='cold' else 6))
        with np.load(HERE/(case+'-mixed.npz')) as data:
            check(case+' independently withheld metric samples',mixed['control']['refined']['interior_points']==1048 and
                  max(abs(data['control_refined'][1:-1]-data['control_truth'][1:-1]))<1.85e-12)
            check(case+' gap both endpoints held out',np.array_equal(data['x'][[0,-1]],mixed['gap_x']) and mixed['gap_epochs']==[1834,1835])
            check(case+' held-out slow coordinates',all(max(mixed['gap_endpoints_withheld'][key]['relative_errors'])<study.TOL for key in ('slow','slow_velocity')))
            check(case+' angular mismatch visibly retained',max(mixed['gap_endpoints_withheld']['photon']['relative_errors'])>study.TOL)
        check(case+' mixed boundary converged',all(item[-1]<2e-15 for item in mixed['gap_iterations'].values()))
        check(case+' direct equation groups',mixed['derivative_checks']['points']==100 and max(mixed['derivative_checks']['max_relative_to_group_scale'].values())<2e-8)
        check(case+' same projected source allowance',abs(projection['prior_gain_relative'])<study.TOL and projection['remainder_orthogonality']<1e-10)
        best=projection['knot_resolved']['order5_step0.0005']
        check(case+' trace integral and independent by-parts route',abs(best['trace_projection']-best['drive_projection'])<.001*projection['allowances']['crossed'])
        check(case+' physical/archive gate distinctions',abs(best['signed_fraction_of_allowance']['crossed'])>1 and
            ((abs(best['signed_fraction_of_allowance']['physical'])<1)==(case=='heavy')))
        full=physical['8192']
        check(case+' original Cauchy solver pressure replay',full['archived_raw']['hamiltonian_slow_pressure_vs_native_peak_normalized']<1e-9)
        check(case+' physical constraint more consistent than raw finite quadrature',full['physical_enthalpy']['trace_form_hamiltonian_defect_peak_normalized']
              <.01*full['physical_raw']['trace_form_hamiltonian_defect_peak_normalized'])
        check(case+' physical background differentiated independently',full['background']['max_acceleration_constraint_defect_over_h_squared']<1e-10)
        for step in ('4096','8192'):
            check(case+' independent Einstein evolutions '+step,max(physical[step]['physical_enthalpy']['metric_form_difference_peak_normalized'].values())<study.TOL)
        with np.load(HERE/(case+'-physical.npz')) as data, np.load(HERE/(case+'-epoch3038-restart.npz')) as state:
            left,right=data['archived_raw_hamiltonian'],data['physical_enthalpy_hamiltonian']
            shift=right[:,3]-left[:,3]
            check(case+' signed pressure components',max(abs(data['slow_pressure_contributions'].sum(axis=1)-shift))<5e-15*max(abs(left[:,3])))
            check(case+' physical size measured from saved arrays',abs(max(abs(shift))/max(abs(left[:,3]))-full['slow_pressure_change']['max_change_relative_to_archived_peak'])<1e-12)
            check(case+' mesh evidence for physical size',abs(full['slow_pressure_change']['max_change_relative_to_archived_peak']-physical['4096']['slow_pressure_change']['max_change_relative_to_archived_peak'])<1e-8)
            check(case+' Cauchy restart location',state['x']==data['x'][-1] and state['physical_enthalpy_hamiltonian'].shape==(185,))
            const=np.load(inputs(case)[1])['constants']
            scale=float(state['scale']); bg=state['physical_fields']; vel=state['physical_fields_x']
            for label in ('physical_enthalpy_hamiltonian','physical_enthalpy_trace'):
                terminal=state[label]; stress=K**2*(vel[0]*terminal[91]-(scale*const[6]/K)**2*bg[0]*terminal[90])
                check(case+' restart recovers terminal pressure '+label,abs(stress-data[label][-1,3])<=1e-13*abs(stress))
    native=PARENT/'mts-coupled-metric-consistency-20261117/native/fortran'
    for path in [native/'equations.f90',native/'massive_neutrinos.f90',native/'mts_curvature_hook.inc',
            PARENT/'mts-integrated-defect-20261112/integrated_math.py',PARENT/'mts-neutrino-switch-20261118/switch.c',
            PARENT/'mts-neutrino-switch-20261118/branches.inc']:
        sources[str(path.relative_to(PARENT))]=study.digest(path)
    check('no local bytecode or temporary workers required',not (HERE/'__pycache__').exists())
    write('verification.json',{'tests':checks,'source_files':sources,'prior_verified_files':len(old),'tolerance':study.TOL})
    files={path.name:{'sha256':study.digest(path),'bytes':path.stat().st_size} for path in sorted(HERE.iterdir()) if path.is_file() and path.name!='closeout.json'}
    write('closeout.json',{'utc':datetime.now(timezone.utc).isoformat(),'prior':SEAL,'files':files})
    print('verified',len(checks),'checks;',len(files),'sealed files;',sum(row['bytes'] for row in files.values()),'bytes;',study.digest(HERE/'closeout.json'))


if __name__=='__main__':
    verify()
