from mixed import *

TARGETS={'cdm':'delta_cdm','baryon':'delta_baryon','photon':'delta_photon','massless':'delta_neutrino',
         'massive':'delta_nu','eta':'etak','slow':'mts_dphi_s','slow_velocity':'mts_dphidot_s','heavy':'mts_dphi_h',
         'heavy_velocity':'mts_dphidot_h'}


def time_rms(arr,clock):
    return float(np.sqrt(np.trapezoid(arr**2,clock)/(clock[-1]-clock[0])))


def conduct(case):
    guard()
    obj=Experiment(case)
    derivative=obj.check_rhs()
    control_start=1991
    duration=obj.times[1991]-obj.times[1833]
    control_end=int(np.searchsorted(obj.times,obj.times[control_start]+duration))
    control=np.arange(control_start,control_end+1)
    grid=obj.times[control]
    with np.load(HERE/(case+'-direct.npz')) as data:
        reference=data['direct'][control-control_start]
    score={}
    artifacts={'control_epochs':control,'control_truth':reference}
    for name,step,seed in [('coarse',.004,'zero'),('fine',.002,'zero'),('exact_left',.002,'exact'),('refined',.001,'zero')]:
        _,fields,iterations=obj.run(control_start,control_end,step,seed,grid)
        error=(fields['trace']-reference)[1:-1]
        interior=grid[1:-1]
        dense=np.flatnonzero(np.diff(interior)>.03)
        last=int(dense[0])+1 if len(dense) else len(interior)
        score[name]={'interior_points':len(error),'max_abs':float(max(abs(error))),'rms_samples':rms(error),
                     'dense_contiguous_time_rms':time_rms(error[:last],interior[:last]),
                     'dense_samples':last,'dense_span_x':float(interior[last-1]-interior[0]),
                     'slow_pressure_proxy_velocity_error_max':float(max(abs(fields['slow_velocity'][1:-1]-obj.cols['mts_dphidot_s'][control[1:-1]]))),
                     'iterations':iterations}
        artifacts['control_'+name]=fields['trace']
    lo,hi=obj.times[[1834,1835]]
    times=np.linspace(lo,hi,4097)
    artifacts['x']=times
    scenarios={'coarse':(1833,1991,.004,'zero'),'fine':(1833,1991,.002,'zero'),
               'refined':(1833,1991,.001,'zero'),'earlier':(1832,1991,.002,'zero'),
               'later_right':(1833,2041,.002,'zero'),'tail':(1833,1991,.002,'tail')}
    history={}
    for name,(start,end,step,seed) in scenarios.items():
        _,fields,iterations=obj.run(start,end,step,seed,times)
        for key in (fields if name=='refined' else ['trace','drive']):
            artifacts[name+'_'+key]=fields[key]
        history[name]=iterations
    centered=artifacts['refined_trace']
    fine=artifacts['fine_trace']
    spreads={key:time_rms(arr,times) for key,arr in {
        'step_004_to_002':artifacts['coarse_trace']-fine,'step_002_to_001':fine-centered,
        'earlier_left':artifacts['earlier_trace']-fine,'later_right':artifacts['later_right_trace']-fine,
        'nonzero_hidden_multipoles':artifacts['tail_trace']-fine}.items()}
    x,n,drive,*_=study.native(case)
    dense=load_dense(case)
    fit=CubicSpline(dense[:,0],dense[:,3])
    left_off,right_off=(fit(x)-drive)[1834:1836]
    nominal=fit(times)-(left_off+(times-lo)*(right_off-left_off)/(hi-lo))
    expansion=obj.bg.evaluate(times/K)['hubble']/K
    nominal_trace=fit(times,1)-(right_off-left_off)/(hi-lo)+expansion*nominal
    artifacts['prior_nominal_trace']=nominal_trace
    artifacts['prior_nominal_drive']=nominal
    eps=centered-nominal_trace
    revision=time_rms(eps,times)
    threshold=study.read(PRIOR/(case+'-trace-bound.json'))['fine']['critical_rms_for_TOL']
    sensitivity_sum=score['refined']['max_abs']+sum(spreads[key] for key in ('step_002_to_001','earlier_left','later_right','nonzero_hidden_multipoles'))
    endpoints={}
    for key,target in TARGETS.items():
        actual=obj.cols[target][[1834,1835]]
        pred=artifacts['refined_'+key][[0,-1]]
        endpoints[key]={'actual':actual.tolist(),'predicted':pred.tolist(),
                        'absolute_errors':abs(pred-actual).tolist(),
                        'relative_errors':(abs((pred-actual)/actual).tolist() if np.all(actual!=0) else None)}
    out={'scope':'mixed-boundary reconstruction of the original native archive, not an independent forward cosmology',
         'tolerance':study.TOL,'source_hashes':{str(Path(path).relative_to(PARENT)):study.digest(path) for path in obj.source_paths},
         'derivative_checks':derivative,'control_epochs':[control_start,control_end],'control_duration_x':float(np.ptp(grid)),
         'gap_bridge_duration_x':float(duration),'control':score,'gap_epochs':[1834,1835],'gap_x':[lo,hi],
         'trace_revision_rms_relative_to_prior_linear_offset':revision,'reference_grid_half_to_full_rms_change':abs(time_rms(eps[::2],times[::2])-revision),
         'withholding_background_and_continuity_corrections_rms':time_rms(centered-artifacts['refined_raw_trace'],times),
         'thresholds':threshold,'trace_revision_over_threshold':{k:revision/v for k,v in threshold.items()},
         'tested_uncertainty_rms_components':spreads,'tested_envelope_including_max_control':sensitivity_sum,
         'tested_envelope_over_threshold':{k:sensitivity_sum/v for k,v in threshold.items()},
         'gap_endpoints_withheld':endpoints,'gap_iterations':history}
    np.savez_compressed(HERE/(case+'-mixed.npz'),**artifacts)
    write(case+'-mixed.json',out)
    print(case,'control max',score['refined']['max_abs'],'gap revision',revision,'envelope',sensitivity_sum,'limits',threshold,flush=True)


if __name__=='__main__':
    for case in ('cold','heavy'):
        conduct(case)
