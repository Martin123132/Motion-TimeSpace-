from mixed import *
from paired import adjoint
from scipy.integrate import simpson


def project(case):
    guard()
    obj=Experiment(case)
    x,n,_,_,_,vs,cfg,_=study.native(case)
    raw=load_dense(case)
    lo,hi=x[1834:1836]
    xx=raw[:,0]
    slots=np.searchsorted(xx,x)
    cell=xx>=lo
    scale=raw[cell,1]+PchipInterpolator(x,n['a']-raw[slots,1])(xx[cell])
    expansion=raw[cell,2]+PchipInterpolator(x,n['H']-raw[slots,2])(xx[cell])
    xx=xx[cell]
    hub=CubicSpline(xx,expansion/K)
    adj=CubicSpline(xx,adjoint(xx,scale,expansion,cfg['masses'][0],.045))
    with np.load(HERE/(case+'-mixed.npz')) as dataset:
        time=dataset['x']; nominal_trace=dataset['prior_nominal_trace']; nominal=dataset['prior_nominal_drive']
        traces={key:dataset[key+'_trace'] for key in ('refined','fine','coarse','earlier','later_right','tail')}
        drives={key:dataset[key+'_drive'] for key in traces}
    high=study.read(PRIOR/(case+'-trace-bound.json'))['fine']
    assert np.array_equal(time[[0,-1]],[lo,hi])
    previous_h=hub(time)
    actual_h=obj.bg.evaluate(time/K)['hubble']/K
    aval=CubicSpline(xx,scale)(time)
    kernels=[adj(time)[:,0,1]*vs(np.log(aval))/K,np.ones(len(time))]
    if case=='heavy':
        hdual=CubicSpline(xx,adjoint(xx,scale,expansion,cfg['masses'][1],.025))
        kernels+=list(np.linalg.solve(hdual(hi),hdual(time)[:,:,1].T)*obj.bg.fields[1][1](np.log(aval))/K)
    primitive=hub.antiderivative()
    factor=np.exp(primitive(time)-primitive(lo))
    anti=CubicSpline(time,np.array(kernels).T/factor[:,None]).antiderivative()
    propagated=(anti(hi)-anti(time))*factor[:,None]
    weights=np.ones(len(time))
    weights[1:-1:2]=4; weights[2:-1:2]=2; weights*=((hi-lo)/(len(time)-1))/3
    allrows=np.column_stack((propagated[:,0],factor/factor[-1],propagated[:,1:]))
    constraints=allrows[:,1:]
    scaled=constraints*np.sqrt(weights)[:,None]
    norms=np.linalg.norm(scaled,axis=0)
    coefs=np.linalg.lstsq(scaled/norms,allrows[:,0]*np.sqrt(weights),rcond=None)[0]/norms
    remaining=allrows[:,0]-constraints@coefs
    gain=np.linalg.norm(remaining*np.sqrt(weights))
    assert abs(gain/high['l2_gain']-1)<study.TOL
    sloped=np.column_stack((-np.array(kernels)[0],np.zeros(len(time)),-np.array(kernels)[1:].T))
    kernel_drive=-(sloped[:,0]-sloped[:,1:]@coefs)
    allowances={key:val*np.sqrt(hi-lo)*high['l2_gain'] for key,val in high['critical_rms_for_TOL'].items()}
    results={}
    for key in traces:
        ddrive=drives[key]-nominal
        dtrace=traces[key]-nominal_trace+(previous_h-actual_h)*ddrive
        by_trace=float(weights@(remaining*dtrace))
        boundary=float(remaining[-1]*ddrive[-1]-remaining[0]*ddrive[0])
        by_drive=boundary+float(weights@(kernel_drive*ddrive))
        half=boundary+simpson((kernel_drive*ddrive)[::2],x=time[::2])
        results[key]={'trace_projection':by_trace,'drive_projection':by_drive,'endpoint_term':boundary,
                      'half_grid_drive_difference':abs(float(half-by_drive)),
                      'two_route_absolute_difference':abs(by_drive-by_trace),
                      'signed_fraction_of_allowance':{k:by_drive/v for k,v in allowances.items()}}
    refined=results['refined']['drive_projection']
    partial=abs(results['fine']['drive_projection']-refined)+sum(abs(results['fine']['drive_projection']-results[key]['drive_projection']) for key in ('earlier','later_right','tail'))
    from scipy.special import roots_legendre
    breaks=np.unique(np.r_[lo,hi,xx[(xx>lo)&(xx<hi)],K*obj.bg.boundaries(lo/K,hi/K)])
    assert np.all(np.diff(breaks)>0)
    physical=CubicSpline(raw[:,0],raw[:,3])
    sample_offsets=(physical(x)-(n['growth']*n['H']/K*n['delta_nonu']+cfg['baryon']*n['v_baryon_cdm']))[1834:1836]
    offset_slope=np.diff(sample_offsets).item()/(hi-lo)
    remainder_spline=CubicSpline(time,remaining)
    driver_spline=CubicSpline(time,kernel_drive)
    segmented={}
    for order,step in ((3,.002),(5,.002),(5,.001),(5,.0005)):
        roots,legweights=roots_legendre(order)
        widths=np.diff(breaks)
        pts=(breaks[:-1,None]+.5*widths[:,None]*(1+roots)).ravel()
        wgt=(widths[:,None]*legweights/2).ravel()
        padded=np.r_[lo,pts,hi]
        _,solution,_=obj.run(1833,1991,step,points=padded)
        cdnom=physical(padded)-(sample_offsets[0]+offset_slope*(padded-lo))
        diff=solution['drive']-cdnom
        ha=obj.bg.evaluate(pts/K)['hubble']/K
        changed=solution['trace'][1:-1]-physical(pts,1)+offset_slope-ha*cdnom[1:-1]
        changed+=(hub(pts)-ha)*diff[1:-1]
        integrated=float(wgt@(remainder_spline(pts)*changed))
        ibp=float(remaining[-1]*diff[-1]-remaining[0]*diff[0]+wgt@(driver_spline(pts)*diff[1:-1]))
        segmented[f'order{order}_step{step}']={'sites':len(pts),'trace_projection':integrated,'drive_projection':ibp,
            'absolute_disagreement':abs(ibp-integrated),'trace_revision_rms':float(np.sqrt(wgt@(changed**2)/(hi-lo))),
            'signed_fraction_of_allowance':{k:ibp/v for k,v in allowances.items()}}
    write(case+'-projection.json',{'prior_gain_relative':gain/high['l2_gain']-1,'constraint_count':len(coefs),
          'allowances':allowances,'variants':results,'boundary_mesh_sensitivity_absolute':partial,
          'boundary_mesh_sensitivity_over_allowance':{k:partial/v for k,v in allowances.items()},
          'remainder_orthogonality':float(max(abs((scaled/norms).T@(remaining*np.sqrt(weights))))/gain),
          'segmented_intervals':len(breaks)-1,'knot_resolved':segmented})
    print(case,list(segmented.values())[-1],flush=True)


if __name__=='__main__':
    for case in ('cold','heavy'):
        project(case)
