from ctypes import CDLL, c_int, c_double
from functools import cached_property
from species import *
from scipy.interpolate import CubicSpline, PchipInterpolator

sys.path.insert(0,str(PARENT/'mts-integrated-defect-20261112'))
from integrated_math import Background
from paired import load_dense

PTR=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
LIB=CDLL(str(HERE/'species_sweep.dll'))
LIB.sweep.argtypes=[c_int,c_int,c_double,PTR,PTR,PTR,PTR]
LIB.sample.argtypes=[c_int,PTR,PTR,PTR,PTR,PTR]
LIB.sweep.restype=LIB.sample.restype=None


class Experiment:
    def __init__(self,case):
        self.case=case
        path,clock=inputs(case)
        self.background_path=study.COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
        self.plasma_path=PARENT/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz')
        with np.load(path) as capture:
            self.ref,self.dot,self.sig,self.packet=(capture[key] for key in ('reference','derivative_reference','signature','packet'))
        with np.load(clock) as archive, np.load(self.background_path) as fields:
            self.bg=Background(archive,fields)
        with np.load(self.plasma_path) as plasma:
            self.table=plasma['values']
            self.minimum,self.spacing=plasma['metadata']
        self.config=study.bridge.inputs(case)
        with np.load(self.config['ref']) as data:
            index=int(np.flatnonzero(data['modes']==K).item())
            self.cols=dict(zip(data['names'].tolist(),data['values'][index].T.copy()))
            self.times=data['conformal_time']*K
        assert np.array_equal(self.times[1991:4253],K*self.packet[:,0])
        self.source_paths=[path,clock,self.background_path,self.plasma_path,self.config['ref'],PRIOR/'closeout.json']

    def medium(self,clock):
        geo=self.bg.evaluate(clock/K)
        scale=geo['scale']
        medium=np.zeros((len(clock),26))
        constants=self.bg.constants
        medium[:,0]=clock
        medium[:,1]=geo['hubble']/K
        medium[:,2:7]=constants[[0,1,2,3,14]]/(scale[:,None]**[1,1,2,2,2]*K**2)
        for field,jet in enumerate(geo['jets']):
            phi,vel,_,_,_,_,mass2=jet
            medium[:,7+field*3:10+field*3]=np.column_stack((vel/K,mass2*phi/K**2,mass2/K**2))
        position=np.log(clock/(K*self.minimum))/self.spacing
        idx=position.astype(int)
        fraction=position-idx
        for col,src in [(13,4),(14,2)]:
            val,slope=self.table[src:src+2,idx]
            nxt,tail=self.table[src:src+2,idx+1]
            medium[:,col]=val+fraction*(slope+fraction*(3*(nxt-val)-2*slope-tail+fraction*(2*(val-nxt)+slope+tail)))
        medium[:,13]/=K
        medium[:,15:20]=1/np.sqrt(1+(scale[:,None]*constants[8]/NODES)**2)
        medium[:,20:25]=WEIGHTS
        return medium,geo

    def captured(self,index,derivative=False):
        raw=(self.dot if derivative else self.ref)[index]
        sig=self.sig[index]
        assert tuple(sig[3:8])==(5,93,48,44,44) and sig[30]==5 and sig[40]==16 and sig[15]==1
        fwd=np.r_[raw[2:4],raw[4:49],raw[49:92],raw[95],raw[96]/K]
        massive=int(sig[50]-1)
        reverse=np.r_[raw[0]/K,raw[1],raw[92:95],raw[massive:massive+85],raw[97:99]/[1,K] if self.case=='heavy' else [0.,0.]]
        return np.ascontiguousarray(fwd/(K if derivative else 1)),np.ascontiguousarray(reverse/(K if derivative else 1))

    def left(self,epoch):
        col=self.cols
        state=np.zeros(92)
        state[[0,1,2,3,4,47,90,91]]=[col[key][epoch]/(K if key=='mts_dphidot_s' else 1) for key in
            ('delta_baryon','v_baryon_cdm','delta_photon','v_photon','pi_photon','E_2','mts_dphi_s','mts_dphidot_s')]
        return state

    def check_rhs(self):
        ids=np.unique(np.r_[0,np.arange(0,len(self.ref),23),len(self.ref)-1])
        medium,_=self.medium(self.packet[ids,0]*K)
        errors=[]; sizes=[]
        for row,idx in zip(medium,ids):
            fwd,back=self.captured(idx)
            fprime,bprime=self.captured(idx,True)
            calc_f,calc_b=np.zeros(92),np.zeros(92)
            force,dfq=np.zeros(2),np.zeros(2)
            LIB.sample(1,row,np.zeros(2),fwd,calc_f,dfq)
            LIB.sample(0,row,dfq,back,calc_b,force)
            LIB.sample(1,row,force,fwd,calc_f,dfq)
            errors.append(abs(np.r_[fprime-calc_f,bprime-calc_b]))
            sizes.append(abs(np.r_[fprime,bprime]))
        norms=np.max(sizes,axis=0)
        errs=np.max(errors,axis=0)
        groups={'baryons':slice(0,2),'photon_intensity':slice(2,47),'polarisation':slice(47,90),
                'slow_field':slice(90,92),'metric_and_cdm':slice(92,94),'massless':slice(94,97),
                'massive':slice(97,182),'heavy_field':slice(182,184)}
        grouped={key:float(max(errs[cols])/max(max(norms[cols]),1e-300)) for key,cols in groups.items()}
        assert max(grouped.values())<2e-8,grouped
        return dict(points=len(ids),max_relative_to_group_scale=grouped)

    def trace(self,clock,fwd,back,force,geo,medium):
        hub=medium[:,1]; rate=geo['rate']/K; speed=medium[:,15:20]; massive=medium[:,6]
        dm=back[:,5:90:17]
        dens=medium[:,2]*back[:,1]+medium[:,3]*fwd[:,0]
        bright=medium[:,4]*fwd[:,2]+medium[:,5]*back[:,2]
        mtrace=massive*((dm*(1/speed+speed))@WEIGHTS)
        combined=dens+2*bright+mtrace
        residual=(hub-rate)*combined
        bgr,pbg=thermal(geo['scale']*self.bg.constants[8])
        mass_ent=massive*(bgr+pbg)
        enthalpy=medium[:,2]+medium[:,3]+(4/3)*(medium[:,4]+medium[:,5])+mass_ent
        residual+=(massive*(4/3)*((1/speed)@WEIGHTS)-mass_ent)*force
        for idx,jet in enumerate(geo['jets']):
            phi,vel,phi_tau,vel_tau,_,_,mass2=jet
            perturb,derivative=(back if idx else fwd)[:,90:92].T
            beta=vel/K; mass=mass2/K**2; pot=mass*phi
            combined+=4*beta*derivative-2*pot*perturb
            residual+=(vel_tau/K**2+2*hub*beta+pot)*derivative+mass*((2*rate-2*hub)*phi+phi_tau/K-beta)*perturb
            enthalpy+=beta**2
        background=geo['hubble_prime']/K**2-hub**2+.5*enthalpy
        return combined/2, combined/2-residual/(2*hub)-background*force/hub

    def run(self,start,end,step,seed='zero',points=None):
        assert end>=1991 and start<end
        left,right=self.times[[start,end]]
        count=int(np.ceil((right-left)/step))
        nodes=np.linspace(left,right,2*count+1)
        clock=nodes[::2]
        medium,geo=self.medium(nodes)
        fwd=np.zeros((count+1,92))
        back=np.zeros_like(fwd)
        fwd[0]=self.left(start)
        if seed=='exact':
            assert start>=1991
            fwd[0]=self.captured(start-1991)[0]
        elif seed=='tail':
            fwd[0,5:47]=fwd[0,4]*(-.5)**np.arange(1,43)
            fwd[0,48:90]=fwd[0,47]*(-.5)**np.arange(1,43)
        else:
            assert seed=='zero'
        back[-1]=self.captured(end-1991)[1]
        stress=np.zeros((count+1,2))
        force=np.zeros_like(stress)
        external=np.zeros((len(nodes),2))
        iterations=[]
        for iteration in range(18):
            last=force.copy()
            LIB.sweep(0,count,(right-left)/count,medium,external,back,force)
            LIB.sweep(1,count,(right-left)/count,medium,CubicSpline(clock,force)(nodes),fwd,stress)
            external=CubicSpline(clock,stress)(nodes)
            shift=np.max(abs(last-force))
            iterations.append(float(shift))
            if iteration>1 and shift<2e-15: break
        assert iterations[-1]<2e-15,iterations
        if points is None:
            selected=medium[::2]
            select_geo={key:value[::2] for key,value in geo.items() if key not in ('jets',)}
            select_geo['jets']=[tuple(arr[::2] for arr in jet) for jet in geo['jets']]
        else:
            assert np.all((points>=left)&(points<=right))
            selected,select_geo=self.medium(points)
            def sampled(values):
                return np.column_stack([CubicSpline(clock,values[:,idx])(points) for idx in range(values.shape[1])])
            fwd,back=sampled(fwd),sampled(back)
            clock=points
        speed=selected[:,15:20]
        density=selected[:,2]*back[:,1]+selected[:,3]*fwd[:,0]+selected[:,4]*fwd[:,2]+selected[:,5]*back[:,2]+selected[:,6]*((back[:,5:90:17]/speed)@WEIGHTS)
        for idx,values in enumerate((fwd,back)):
            density+=selected[:,7+3*idx]*values[:,91]+selected[:,8+3*idx]*values[:,90]
        prediction=-(back[:,0]+density/2)/selected[:,1]
        raw,trace=self.trace(clock,fwd,back,prediction,select_geo,selected)
        assert np.all(np.isfinite(trace))
        return clock, {'trace':trace,'raw_trace':raw,'drive':prediction,'eta':back[:,0]*K,'cdm':back[:,1],
            'massless':back[:,2],'massive':((back[:,5:90:17]/speed)@WEIGHTS)/thermal(select_geo['scale']*self.bg.constants[8])[0],
            'baryon':fwd[:,0],'photon':fwd[:,2],'slow':fwd[:,90],'slow_velocity':K*fwd[:,91],
            'heavy':back[:,90],'heavy_velocity':K*back[:,91]},iterations


if __name__=='__main__':
    guard()
    for case in ('cold','heavy'):
        obj=Experiment(case)
        print(case,obj.check_rhs(),flush=True)
