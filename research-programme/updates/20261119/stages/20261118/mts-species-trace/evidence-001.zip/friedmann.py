from mixed import *
from scipy.integrate import solve_ivp

LIB.full_sweep.argtypes=[c_int,c_int,c_int,c_double,PTR,PTR,PTR]
LIB.full_sweep.restype=None


def physical_background(obj,points,maximum):
    const=obj.bg.constants
    first=obj.bg.evaluate(points[:1]/K)
    masses=const[6:6+len(first['jets'])]/K
    initial=np.r_[np.log(first['scale'][0]),[v for jet in first['jets'] for v in (jet[0][0],jet[1][0]/K)]]
    def rhs(clock,state):
        scale=np.exp(state[0])
        fields=state[1::2]
        speeds=state[2::2]
        mass2=(scale*masses)**2
        rho,_=thermal(scale*const[8])
        total=((const[0]+const[1])/scale+(const[2]+const[3]+const[14]*rho)/scale**2)/K**2
        hub=np.sqrt((total+np.sum(speeds**2+mass2*fields**2)/2)/3)
        der=np.empty_like(state)
        der[0]=hub; der[1::2]=speeds; der[2::2]=-2*hub*speeds-mass2*fields
        return der
    absolute=np.r_[3e-15,[v for idx in range(len(masses)) for v in ((1e-14,1e-27) if idx==0 else (3e-18,3e-18))]]
    sol=solve_ivp(rhs,(points[0],points[-1]),initial,method='DOP853',t_eval=points,
                  rtol=4e-13,atol=absolute,max_step=maximum)
    assert sol.success
    scale=np.exp(sol.y[0]); fields=sol.y[1::2].T; speeds=sol.y[2::2].T
    rho,pressure=thermal(scale*const[8])
    mass2=(masses*scale[:,None])**2
    dust=(const[0]+const[1])/(K**2*scale)
    light=(const[2]+const[3])/(K*scale)**2
    massive=const[14]/(scale*K)**2
    total=dust+light+massive*rho+np.sum(speeds**2+mass2*fields**2,axis=1)/2
    hub=np.sqrt(total/3)
    acc=-2*hub[:,None]*speeds-mass2*fields
    am=scale*const[8]
    log_derivative=2*5/(7*np.pi**2)*am**2+am**4*(.01099926669*(4*np.log(am)+1)-4*.003492416767-5*.005866275571*am)
    total_der=-hub*(dust+2*light)+massive*hub*(log_derivative-2*rho)+np.sum(
        speeds*acc+hub[:,None]*mass2*fields**2+mass2*fields*speeds,axis=1)
    bsum=dust+4*light/3+massive*(rho+pressure)+np.sum(speeds**2,axis=1)
    residual=total_der/(6*hub)-hub**2+bsum/2
    return scale,hub,fields,speeds,mass2,residual


def experiment(case):
    guard()
    obj=Experiment(case)
    left,end=1991,3038
    nx=obj.times[[left,end]]
    fwd,back=obj.captured(0)
    init=np.r_[fwd,back,-obj.packet[0,6]]
    out={}; artifacts={}; restarts={}
    for steps in (4096,8192):
        points=np.linspace(*nx,2*steps+1)
        archived,geo=obj.medium(points)
        physical=archived.copy()
        scale,hub,fields,speeds,mass2,residual=physical_background(obj,points,.024 if steps==4096 else .012)
        const=obj.bg.constants
        physical[:,1]=hub
        physical[:,2:7]=const[[0,1,2,3,14]]/(scale[:,None]**[1,1,2,2,2]*K**2)
        for idx in range(fields.shape[1]):
            physical[:,7+3*idx:10+3*idx]=np.column_stack((speeds[:,idx],mass2[:,idx]*fields[:,idx],mass2[:,idx]))
        physical[:,15:20]=1/np.sqrt(1+(scale[:,None]*const[8]/NODES)**2)
        results={}; factors={}
        for label,med,aval,repair in [('archived_raw',archived,geo['scale'],0),('physical_raw',physical,scale,0),
                                      ('physical_enthalpy',physical,scale,1)]:
            rho,pressure=thermal(aval*const[8])
            med[:,25]=(rho+pressure)/(4/3*((1/med[:,15:20])@WEIGHTS))
            pair={}
            for metric in (0,1):
                states=np.empty((steps+1,185)); obs=np.empty((steps+1,3));states[0]=init
                LIB.full_sweep(metric,repair,steps,(nx[-1]-nx[0])/steps,med,states,obs)
                assert np.all(np.isfinite(states))
                slow=K**2*(med[::2,7]*states[:,91]-med[::2,8]*states[:,90])
                heavy=K**2*(med[::2,10]*states[:,183]-med[::2,11]*states[:,182])
                pair[metric]=np.column_stack((obs,slow,heavy,states[:,2],states[:,4],states[:,93]))
                if steps==8192:
                    artifacts[label+('_trace' if metric else '_hamiltonian')]=pair[metric]
                    restarts[label+('_trace' if metric else '_hamiltonian')]=states[-1].copy()
                if metric==0:
                    factors[label]=np.column_stack((med[::2,7],med[::2,8],states[:,91],states[:,90],slow))
            dif=pair[1]-pair[0]
            measure={key:float(max(abs(dif[:,idx]))/max(max(abs(pair[0][:,idx])),1e-300))
                for key,idx in [('drive',1),('source',2),('slow_pressure',3),('heavy_pressure',4),('photon_density',5),('photon_shear',6),('cdm_density',7)]}
            constraint=max(abs(pair[1][:,1]-pair[1][:,0]))/max(abs(pair[1][:,1]))
            results[label]={'metric_form_difference_peak_normalized':measure,'trace_form_hamiltonian_defect_peak_normalized':float(constraint),
                            'max_weight_adjustment':float(max(abs(med[:,25]-1)))}
            if label=='archived_raw':
                clock=obj.times[left:end+1]; calc=CubicSpline(points[::2],pair[0])(clock)
                results[label]['hamiltonian_drive_vs_native_peak_normalized']=float(max(abs(calc[:,1]+obj.packet[:len(clock),6]))/max(abs(obj.packet[:len(clock),6])))
                results[label]['hamiltonian_slow_pressure_vs_native_peak_normalized']=float(max(abs(calc[:,3]-obj.cols['mts_dp_s'][left:end+1]))/max(abs(obj.cols['mts_dp_s'][left:end+1])))
        results['background']={'max_acceleration_constraint_defect_over_h_squared':float(max(abs(residual)/hub**2)),
              'max_H_physical_vs_archive_relative':float(max(abs(hub/archived[:,1]-1))),
              'max_scale_physical_vs_archive_relative':float(max(abs(scale/geo['scale']-1)))}
        old=factors['archived_raw']; new=factors['physical_enthalpy']
        diff=new-old; mean=(new+old)/2
        sources=K**2*np.column_stack((diff[:,0]*mean[:,2],-diff[:,1]*mean[:,3],diff[:,2]*mean[:,0],-diff[:,3]*mean[:,1]))
        maximum=int(np.argmax(abs(diff[:,-1])))
        assert max(abs(sources.sum(axis=1)-diff[:,-1]))<=5e-15*max(abs(old[:,-1]))
        results['slow_pressure_change']={'max_change_relative_to_archived_peak':float(abs(diff[maximum,-1])/max(abs(old[:,-1]))),
            'at_x':float(points[::2][maximum]),'signed_peak_change':float(diff[maximum,-1]),'archived_peak_abs':float(max(abs(old[:,-1]))),
            'initial_pair':old[0,-1].item(),'terminal_archived':old[-1,-1].item(),'terminal_physical':new[-1,-1].item(),
            'signed_shares_at_peak':dict(zip(('homogeneous_velocity','potential_coefficient','perturbation_velocity','perturbation_displacement'),
                                              (sources[maximum]/diff[maximum,-1]).tolist()))}
        out[str(steps)]=results
        if steps==8192:
            restarts['x']=nx[-1]; restarts['scale']=scale[-1]
            restarts['physical_fields']=fields[-1]; restarts['physical_fields_x']=speeds[-1]
            restarts['species']=np.array(['slow','heavy'][:fields.shape[1]])
            artifacts['slow_pressure_contributions']=sources
    np.savez(HERE/(case+'-epoch3038-restart.npz'),**restarts)
    artifacts['x']=points[::2]; artifacts['columns']=np.array(['constraint','drive','species_trace','slow_pressure','heavy_pressure','photon_density','photon_shear','cdm_density'])
    np.savez_compressed(HERE/(case+'-physical.npz'),**artifacts)
    out['scope']='One shared native Cauchy state at epoch1991. Nothing after initialization enters the perturbation forcing except the external opacity/sound-speed history frozen in conformal time. No measured pressure input.'
    out['epochs']=[left,end]; out['tolerance']=study.TOL
    write(case+'-physical.json',out)
    print(case,out['8192']['slow_pressure_change'],flush=True)


if __name__=='__main__':
    for case in ('cold','heavy'):
        experiment(case)
