import hashlib
import json
import os
import sys
from pathlib import Path

for variable in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[variable] = '1'
import numpy as np

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
PRIOR = PARENT / 'mts-retarded-displacement-20261118'
sys.path.insert(0, str(PRIOR))
import study

SPECIES = ('cdm', 'baryon', 'photon', 'massless', 'massive', 'slow', 'heavy')
NODES = np.array([.583165, 2, 4, 7.26582, 13], dtype=np.float32).astype(float)
WEIGHTS = np.array([.0081201, .689407, 2.8063, 2.05156, .126817], dtype=np.float32).astype(float)/(7*np.pi**4/120)
K = 5.
SEAL = '9b0795db7e978e91941f0b3dbd470a3d30a7e4fdd79b7b5ba09c0efddada4d79'


def guard():
    study.guard()
    assert study.digest(PRIOR/'closeout.json') == SEAL and not (HERE/'STOP-REQUESTED').exists()


def write(name, obj):
    (HERE/name).write_text(json.dumps(obj, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def rms(values):
    return float(np.sqrt(np.mean(np.square(values))))


def thermal(am):
    assert np.all((am >= .01) & (am < .35))
    leading = 5/(7*np.pi**2)
    rho = 1+am**2*(leading+am**2*(.01099926669*np.log(am)-.003492416767-.005866275571*am))
    pressure = (1+am**2*(-leading+am**2*(-.03299780009*np.log(am)-.0005219952794+.02346510229*am)))/3
    return rho, pressure


def inputs(case):
    capture = PARENT/'mts-field-shooting-20261117'/(case+'-physical-roots-capture.npz')
    thermo = PARENT/'mts-integrated-defect-20261112'/(case+'-native-clock.npz')
    return capture, thermo


def decompose(case):
    capture, thermo = inputs(case)
    with np.load(capture) as data:
        ref, dot, sig, packet = (data[name] for name in ('reference','derivative_reference','signature','packet'))
    with np.load(thermo) as data:
        constants = data['constants']
    rows = np.arange(len(ref))
    assert len(rows) == 2262 and np.all(sig[:,30]==5) and np.all(sig[:,40]==16) and np.all(packet[:,14]==K)
    scale, rate, hub, hub_x = packet[:,1], packet[:,2]/K, packet[:,4]/K, packet[:,5]/K**2
    cprime = -packet[:,6]
    direct = -packet[:,7]/K+hub*cprime
    dens, pres, slope, flux, enthalpy = (np.zeros((len(rows),7)) for _ in range(5))
    for col, index, fraction, exponent in [(0,1,constants[0],1),(1,2,constants[1],1),
        (2,sig[:,3]-1,constants[2],2),(3,sig[:,4]-1,constants[3],2)]:
        weight = fraction/(scale**exponent*K**2)
        dens[:,col] = weight*ref[rows,index]
        pres[:,col] = dens[:,col]*(exponent-1)/3
        slope[:,col] = weight*dot[rows,index]/K-exponent*rate*dens[:,col]
        enthalpy[:,col] = weight*(1+(exponent-1)/3)
        if col:
            flux[:,col] = weight*ref[rows,index+1]
    am = scale*constants[8]
    speed = 1/np.sqrt(1+(am[:,None]/NODES)**2)
    index = sig[:,50,None]-1+np.arange(5)*(sig[:,40,None]+1)
    massive = constants[14]/(scale*K)**2
    monopoles = ref[rows[:,None],index]
    dens[:,4] = massive*((monopoles/speed)@WEIGHTS)
    pres[:,4] = massive*((monopoles*speed)@WEIGHTS)/3
    flux[:,4] = massive*(ref[rows[:,None],index+1]@WEIGHTS)
    slope[:,4] = massive*((dot[rows[:,None],index]/speed)@WEIGHTS)/K-rate*(dens[:,4]+3*pres[:,4])
    background, pressure = thermal(am)
    enthalpy[:,4] = massive*(background+pressure)
    scalar_residual = np.zeros((len(rows),2))
    homogeneous={}
    for idx,expo in enumerate((1,1,2,2)):
        rho=constants[idx]/(scale**expo*K**2)
        homogeneous[SPECIES[idx]]=(hub-rate)*expo*rho
    log_deriv=2*(5/(7*np.pi**2))*am**2+am**4*(.01099926669*(4*np.log(am)+1)-4*.003492416767-5*.005866275571*am)
    homogeneous['massive']=massive*(rate*(log_deriv-2*background)+hub*(background+3*pressure))
    for field in range(int(packet[0,15])):
        col = 5+field
        jet = packet[:,20+12*field:32+12*field]
        phi, vel, phi_n, vel_n, _, _, mass2, pert, vel_pert, pert_tau, vel_pert_tau = jet[:,:11].T
        beta, pot = vel/K, mass2*phi/K**2
        kin = beta*vel_pert/K
        dens[:,col] = kin+pot*pert
        pres[:,col] = kin-pot*pert
        enthalpy[:,col] = beta**2
        flux[:,col] = beta*pert
        j_x = mass2/K**2*rate*(2*phi+phi_n)
        slope[:,col] = rate*vel_n/K*vel_pert/K+beta*vel_pert_tau/K**2+j_x*pert+pot*pert_tau/K
        scalar_residual[:,field] = (rate*vel_n/K+2*hub*beta+pot)*vel_pert/K+(j_x-2*hub*pot-beta*mass2/K**2)*pert
        homogeneous[SPECIES[col]+'_acceleration']=beta*(rate*vel_n/K+2*hub*beta+pot)
        homogeneous[SPECIES[col]+'_field_velocity']=pot*(rate*phi_n-beta)
        homogeneous[SPECIES[col]+'_clock']=(rate-hub)*mass2/K**2*phi**2
    traces = (dens+3*pres)/2
    eps = slope+2*hub[:,None]*traces-enthalpy*cprime[:,None]+flux
    bg_defect = hub_x-hub**2+enthalpy.sum(axis=1)/2
    bg_terms={key:-val*cprime/(6*hub**2) for key,val in homogeneous.items()}
    assert max(abs(sum(bg_terms.values())+bg_defect*cprime/hub))<1e-16
    correction = -eps/(2*hub[:,None])
    corrected = traces.sum(axis=1)+correction.sum(axis=1)-bg_defect*cprime/hub
    massive_formula = massive*(4/3*((1/speed)@WEIGHTS)-background-pressure)*cprime+(hub-rate)*(dens[:,4]+3*pres[:,4])
    expected = (hub-rate)[:,None]*2*traces
    expected[:,4] = massive_formula
    expected[:,5:] = scalar_residual
    checks = {'D':float(np.max(abs(dens.sum(axis=1)-packet[:,8]/K**2))),
        'D_x':float(np.max(abs(slope.sum(axis=1)-packet[:,9]/K**3))),
        'Q':float(np.max(abs(flux.sum(axis=1)-2*packet[:,11]/K**2))),
        'separate_continuity':float(np.max(abs(expected-eps))),
        'metric_trace':float(np.max(abs(corrected-direct)))}
    scale_checks = [max(abs(packet[:,8]/K**2)),max(abs(packet[:,9]/K**3)),max(abs(2*packet[:,11]/K**2)),
                    np.max(abs(slope)+abs(flux)+abs(enthalpy*cprime[:,None])),max(abs(direct))]
    relative = dict(zip(checks,(float(val/sc) for val,sc in zip(checks.values(),scale_checks))))
    assert max(relative.values()) < 1e-9, (checks,relative)
    summary = {'points':len(rows),'input_sha256':{str(path.relative_to(PARENT)):study.digest(path) for path in (capture,thermo)},
        'checks_absolute':checks,'checks_scaled_to_channel':relative,
        'trace_rms':rms(direct),'omitting_corrections_rms':rms(direct-traces.sum(axis=1)),
        'corrected_rms':rms(corrected-direct),'omitting_corrections_max':float(max(abs(direct-traces.sum(axis=1)))),
        'species_trace_rms':dict(zip(SPECIES,map(rms,traces.T))),
        'species_continuity_correction_rms':dict(zip(SPECIES,map(rms,correction.T))),
        'background_correction_rms':rms(bg_defect*cprime/hub),
        'background_contributors_rms':{key:rms(val) for key,val in bg_terms.items()},
        'within_2e-5_raw':int(np.count_nonzero(abs(direct-traces.sum(axis=1))<=study.TOL*abs(direct))),
        'within_2e-5_corrected':int(np.count_nonzero(abs(direct-corrected)<=study.TOL*abs(direct)))}
    np.savez(HERE/(case+'-direct.npz'),epoch=rows+1991,x=packet[:,0]*K,direct=direct,traces=traces,
             species_correction=correction,background_correction=-bg_defect*cprime/hub,corrected=corrected)
    write(case+'-direct.json',summary)
    return summary


if __name__=='__main__':
    guard()
    for case in ('cold','heavy'):
        result = decompose(case)
        print(case,result['within_2e-5_raw'],result['within_2e-5_corrected'],result['omitting_corrections_rms'])
