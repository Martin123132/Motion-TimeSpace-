import csv
from native_test import *


def table(name,rows):
    with (ROOT/name).open('x',encoding='utf8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def packet(flavour,case,chart,kind='late'):
    path=ROOT/f'{flavour}-{case}-{chart}-{kind}.npz'
    with np.load(path) as data:
        assert np.array_equal(data['modes'],MODES) and not data['want_cls'] and data['accuracy']==2.5
        values=data['values'];names=list(data['names'])
        return values,names,data['times']


def signals(values,names,case,background,abundance):
    get=lambda name:values[:,:,names.index(name)]
    actual=get('a')
    weight=[background[key][None,:] for key in ('cdm','baryon','nu')]
    density=sum(coeff*get(key) for coeff,key in zip(weight,('delta_cdm','delta_baryon','delta_nu')))
    total=sum(weight)
    if case=='heavy':
        density=density+actual**2*get('mts_drho_h')
        total=total+abundance*actual
    return dict(density=density/total,velocity=get('v_newtonian_cdm'),weyl=get('Weyl'))


def score():
    guard()
    lock=read(ROOT/'input-lock.json')
    for path,expected in lock['inputs'].items():
        assert digest(path)==expected,path
    with np.load(SPEC/'runs/projection/a225-w6-d8.npz') as source:
        abundance=float(source['matching_density'])
    result={};controls=[];events=[];ratios=[]
    for case in ('cold','heavy'):
        ref=[]
        for wave,path,pos in reference(case):
            with np.load(path) as data:
                ref.append(data['values'][pos])
                native_names=list(data['names'])
                scales=data['requested_scale']
        archive=np.array(ref)
        views={}
        with np.load(SPEC/'runs'/case/'background.npz') as data:
            bg={key:data[key] for key in ('cdm','baryon','nu')}
            np.testing.assert_array_equal(data['requested_scale'],scales)
        for flavour in ('stock','fixed'):
            for chart in ('rsa','live'):
                vals,names,times=packet(flavour,case,chart)
                assert names==native_names
                views[flavour,chart]=vals
                result[case,flavour,chart]=signals(vals,names,case,bg,abundance)
        for chart in ('rsa','live'):
            peak=abs(views['stock',chart]-views['fixed',chart]).max(axis=(0,1))
            if case=='cold' or chart=='live':assert np.all(peak==0),(case,chart,peak.max())
        archived=signals(archive,native_names,case,bg,abundance)
        for field,target in archived.items():
            error=abs(result[case,'stock','rsa'][field]/target-1)
            controls.append(dict(case=case,field=field,largest_archive_fractional_error=float(error.max()),
                                 passes=bool(np.all(error<=TOL))))
        switch,snames,tau=packet('stock',case,'rsa','switch')
        for index,wave in enumerate(MODES):
            row=dict(case=case,k=wave,k_tau_match=wave*views['stock','rsa'][index,-1,names.index('mts_match_tau')])
            for label,col in [('nu','v_neutrino'),('photon','v_photon')]:
                velocity=switch[index,:,snames.index(col)]
                last=np.flatnonzero(velocity!=0)[-1]
                assert last<len(tau)-3 and np.all(velocity[last+1:]==0)
                row[label+'_last_on']=tau[last];row[label+'_first_off']=tau[last+1]
            events.append(row)
    assert all(row['passes'] for row in controls),controls
    for index,wave in enumerate(MODES):
        for epoch,scale in enumerate(scales):
            row=dict(k=wave,a=scale)
            for field,exponent in [('density',2),('velocity',1),('weyl',1)]:
                relative={}
                for flavour,chart in [('stock','rsa'),('fixed','rsa'),('stock','live')]:
                    vals=lambda case:result[case,flavour,chart][field][index,epoch]
                    relative[flavour,chart]=(vals('heavy')/vals('cold'))**exponent
                live=relative['stock','live']
                row[field+'_live_ratio']=live
                row[field+'_old_vs_live']=relative['stock','rsa']/live-1
                row[field+'_fixed_vs_live']=relative['fixed','rsa']/live-1
                row[field+'_fixed_vs_old']=relative['fixed','rsa']/relative['stock','rsa']-1
                for case in ('cold','heavy'):
                    row[field+'_'+case+'_fixed_vs_live']=(result[case,'fixed','rsa'][field][index,epoch]/
                                                       result[case,'stock','live'][field][index,epoch])**exponent-1
            ratios.append(row)
    table('switches.csv',events)
    table('archive-controls.csv',controls)
    table('paired-native.csv',ratios)
    today=[row for row in ratios if row['a']==1]
    assert len(today)==5 and len(ratios)==305
    receipt=dict(tol=TOL,archive_controls=controls,source_lock=digest(ROOT/'input-lock.json'),identical_controls=['cold/rsa','cold/live','heavy/live'],
                 today=today,statistics={})
    for field in ('density','velocity','weyl'):
        receipt['statistics'][field]={}
        for key in ('old_vs_live','fixed_vs_live','fixed_vs_old','cold_fixed_vs_live','heavy_fixed_vs_live'):
            col=field+'_'+key
            receipt['statistics'][field][key]=dict(max_abs=max(abs(row[col]) for row in ratios),
                 n_epochs_over_gate=sum(bool(abs(row[col])>TOL) for row in ratios),max_abs_today=max(abs(row[col]) for row in today))
    save('validation.json',receipt)
    print(json.dumps(dict(controls=controls,stats=receipt['statistics']['density'],today=[(row['k'],row['density_old_vs_live'],row['density_fixed_vs_live']) for row in today])))


if __name__=='__main__':score()
