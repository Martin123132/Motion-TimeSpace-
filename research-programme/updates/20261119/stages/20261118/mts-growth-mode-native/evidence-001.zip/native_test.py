import os
import sys
for setting in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[setting]='1'
sys.dont_write_bytecode=True
import hashlib
import json
import shutil
import subprocess
import tempfile
from pathlib import Path
import numpy as np
import psutil

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
OLD=POST/'mts-signed-mode-matching-20261118'
COMMON=POST/'condensate-origin-20261003'
MATCH=COMMON/'native-heavy-matching-20261007'
NATIVE=MATCH/'native'
EARLY=COMMON/'native-two-field-transfer-20261007'
SPEC=COMMON/'resolved-matter-spectrum-20261007'
MODES=np.array([.0345989166087,.075,.1197085030496,.1725,.255])
SEAL='2c6f30d48b4b828f26cc2df48eb77110d74820968e3c7816fa8ca5bc460e560b'
PATCH=OLD/'candidate-streaming-heavy-only.patch'
TOL=2e-5


def digest(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def save(name,data):
    with (ROOT/name).open('x',encoding='utf8') as handle:
        json.dump(data,handle,indent=2,allow_nan=False)


def guard():
    for base in (POST,COMMON,MATCH,SPEC,OLD,ROOT):
        assert not (base/'STOP-REQUESTED').exists(),str(base)
    assert digest(OLD/'closeout.json')==SEAL


def reference(case):
    sources=[]
    for path in sorted((SPEC/'runs'/case).glob('chunk-*.npz')):
        with np.load(path) as packet:
            for pos in np.flatnonzero(np.isin(packet['modes'],MODES)):
                sources.append((float(packet['modes'][pos]),path,int(pos)))
    assert np.array_equal([row[0] for row in sources],MODES)
    return sources


def build():
    guard()
    for name,rec in read(OLD/'closeout.json')['files'].items():
        assert digest(OLD/name)==rec['sha256']
    native_receipt=read(MATCH/'runs/build-1/status.json')
    source=NATIVE/'fortran/equations.f90'
    assert digest(source)==read(OLD/'candidate-provenance.json')['source']
    assert digest(NATIVE/'camb/cambdll.dll')==native_receipt['dll_sha256']
    sys.path.insert(0,str(OLD))
    from compile_candidate import reconstruct
    chain=EARLY/'toolchain/mingw64'
    compiler=chain/'bin/gfortran.exe'
    assert digest(compiler)==native_receipt['compiler_sha256']
    objects=[NATIVE/'fortran'/item for item in native_receipt['commands'][-1] if item.endswith('.o')]
    assert len(objects)==39
    sourcefiles=[source,PATCH,compiler,*objects,MATCH/'matching_common.py',MATCH/'stage_common.py',
        ROOT/'PROTOCOL.md',ROOT/'native_test.py',SPEC/'run_late_grid.py',SPEC/'analyze_spectrum.py',
        SPEC/'runs/projection/a225-w6-d8.npz',EARLY/'runs/backgrounds/cold.npz',
        COMMON/'radiation-and-slow-field-transfer-20261007/radiation_common.py',
        COMMON/'cosmology-reconnection-20261006/results/comparison/status.json',
        *[path for path in (NATIVE/'camb').iterdir() if path.is_file()]]
    for case in ('heavy','cold'):
        sourcefiles.extend(row[1] for row in reference(case))
        sourcefiles.extend([SPEC/'runs'/case/'status.json',SPEC/'runs'/case/'background.npz'])
    inputs={str(path):digest(path) for path in sourcefiles}
    output=ROOT/'matched-rsa.dll'
    if output.exists():
        witness=ROOT/'compile-zeh7eeaw'
        assert not (ROOT/'input-lock.json').exists() and digest(output)==digest(witness/'matched.dll')
        for obj in objects:
            if (witness/obj.name).exists() and obj.name!='equations.o':
                assert digest(witness/obj.name)==digest(obj)
        save('input-lock.json',dict(previous=SEAL,inputs=inputs,patched_library=digest(output),modes=MODES.tolist(),
                  tolerance=TOL,build_note='Compiler and linker exited successfully; retained identical linked object after temporary-folder cleanup error.',
                  expected='improved ratio relative to propagation without late truncation; not assumed to pass'))
        return
    with tempfile.TemporaryDirectory(dir=ROOT,prefix='compile-') as tmp:
        local=Path(tmp)
        rel=Path(os.path.relpath(chain,local))
        libdirs=['lib','lib/gcc/x86_64-w64-mingw32/14.2.0','x86_64-w64-mingw32/lib']
        prefixes=['libexec/gcc/x86_64-w64-mingw32/14.2.0','bin',*libdirs]
        flags=['-B./',*['-B'+(rel/item).as_posix()+'/' for item in prefixes],*['-L'+(rel/item).as_posix() for item in libdirs],
               '-shared','-static','-cpp','-fopenmp','-O2','-fcheck=bounds','-fmax-errors=4','-fno-use-linker-plugin']
        for tool in ('f951.exe','collect2.exe'):
            shutil.copyfile(chain/prefixes[0]/tool,local/tool)
        for spec_file in (chain/'lib').glob('*.spec'):
            shutil.copyfile(spec_file,local/spec_file.name)
        for filename in ('dllcrt2.o','crtbegin.o','crtend.o'):
            source_object=next(chain/item/filename for item in libdirs if (chain/item/filename).exists())
            shutil.copyfile(source_object,local/filename)
        for obj in objects:
            if obj.name!='equations.o':shutil.copyfile(obj,local/obj.name)
        (local/'equations.f90').write_text(reconstruct(source.read_text(),PATCH.read_text()),encoding='utf8')
        env=dict(os.environ,PATH=str(chain/'bin')+';'+os.environ['PATH'])
        for tail in (['-I'+str(source.parent/'WinMTS'),'-J.','equations.f90','-c','-o','equations.o'],
                     [*[obj.name for obj in objects],'-o','matched.dll']):
            job=subprocess.run([str(compiler),*flags,*tail],cwd=tmp,env=env,capture_output=True,text=True,timeout=120)
            if job.returncode:raise RuntimeError(job.stderr)
        shutil.copyfile(local/'matched.dll',output)
    save('input-lock.json',dict(previous=SEAL,inputs=inputs,patched_library=digest(output),modes=MODES.tolist(),
                                tolerance=TOL,expected='improved ratio relative to propagation without late truncation; not assumed to pass'))


def run_case(flavour,case,chart,kind,folder):
    guard()
    sys.path[:0]=[folder,str(COMMON/'radiation-and-slow-field-transfer-20261007')]
    import matching_common as inherited
    import camb
    assert Path(camb.__file__).resolve().is_relative_to(Path(folder).resolve())
    lib=Path(camb.__file__).parent/'cambdll.dll'
    lock=read(ROOT/'input-lock.json')
    assert digest(lib)==(lock['patched_library'] if flavour=='fixed' else lock['inputs'][str(NATIVE/'camb/cambdll.dll')])
    source=SPEC/'runs/projection/a225-w6-d8.npz' if case=='heavy' else EARLY/'runs/backgrounds/cold.npz'
    assert digest(source)==lock['inputs'][str(source)]
    params=inherited.params_for(source)
    assert not params.WantCls and params.Accuracy.AccuracyBoost==2.5
    params.DoLateRadTruncation=chart=='rsa'
    native=camb.get_background(params)
    with np.load(reference(case)[0][1]) as data:
        scales=data['requested_scale']
        archived_times=data['conformal_time']
    times=native.conformal_time(1/scales-1,tol=1e-10)
    assert np.allclose(times,archived_times,rtol=1e-11,atol=0)
    if kind=='switch':
        times=np.arange(60.,2151.,.5)
    native.Params.Accuracy.IntTolBoost=6
    names=list(camb.model.evolve_names)
    values=native.get_time_evolution(MODES,times,vars=names,lAccuracyBoost=4)
    assert values.shape==(5,len(times),len(names)) and np.isfinite(values).all()
    assert np.all(values[:,-1,names.index('mts_match_count')]==(case=='heavy'))
    assert not np.any(values[:,:,names.index('mts_nonheavy_change')])
    with (ROOT/f'{flavour}-{case}-{chart}-{kind}.npz').open('xb') as handle:
        np.savez_compressed(handle,modes=MODES,times=times,names=names,values=values,
                            dll=digest(lib),want_cls=bool(params.WantCls),accuracy=float(params.Accuracy.AccuracyBoost))


def suite(flavour):
    guard()
    with tempfile.TemporaryDirectory(dir=ROOT,prefix='view-') as tmp:
        folder=Path(tmp)
        pkg=folder/'native/camb'
        pkg.mkdir(parents=True)
        for path in (NATIVE/'camb').iterdir():
            if path.is_file() and path.suffix in ('.py','.dat','.dll'):
                original=ROOT/'matched-rsa.dll' if flavour=='fixed' and path.name=='cambdll.dll' else path
                shutil.copyfile(original,pkg/path.name)
        shutil.copyfile(NATIVE/'fortran/HighLExtrapTemplate_lenspotentialCls.dat',pkg/'HighLExtrapTemplate_lenspotentialCls.dat')
        for name in ('matching_common.py','stage_common.py'):
            shutil.copyfile(MATCH/name,folder/name)
        for case in ('cold','heavy'):
            arms=[('rsa','late'),('live','late'),('rsa','switch')] if flavour=='stock' else [('rsa','late'),('live','late')]
            for chart,kind in arms:
                guard()
                out=ROOT/f'{flavour}-{case}-{chart}-{kind}.npz'
                if out.exists():continue
                subprocess.run([sys.executable,'-B',__file__,'one',flavour,case,chart,kind,str(folder)],cwd=ROOT,
                               check=True,timeout=600)
                print(out.name,flush=True)


if __name__=='__main__':
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([process.cpu_affinity()[0]])
    if sys.argv[1]=='build':build()
    elif sys.argv[1]=='suite':suite(sys.argv[2])
    elif sys.argv[1]=='one':run_case(*sys.argv[2:])
