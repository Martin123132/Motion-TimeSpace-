from native_test import *
from datetime import datetime,timezone

FAMILIES=(('fixed','heavy','rsa'),('stock','cold','rsa'),('stock','heavy','live'),('stock','cold','live'))
FIELDS=['a','delta_cdm','delta_baryon','delta_nu','mts_drho_h','v_newtonian_cdm','v_newtonian_baryon','Weyl','mts_nonheavy_change','mts_match_count']


def freeze():
    guard()
    prior=read(ROOT/'validation.json')
    assert prior['statistics']['density']['fixed_vs_live']['n_epochs_over_gate']==0
    paths=[ROOT/'input-lock.json',ROOT/'validation.json',ROOT/'full_grid.py',ROOT/'matched-rsa.dll',
           SPEC/'analyze_spectrum.py',SPEC/'compare_growth.py',SPEC/'results/spectrum/status.json',
           SPEC/'results/growth-screen/status.json',SPEC/'sources/sdss-growth/growth-only.npz']
    for case in ('heavy','cold'):
        paths.extend(sorted((SPEC/'runs'/case).glob('chunk-*.npz')))
        paths.extend([SPEC/'results/spectrum'/(case+'.npz'),SPEC/'runs'/case/'background.npz'])
    save('integral-lock.json',dict(utc=datetime.now(timezone.utc).isoformat(),inputs={str(path):digest(path) for path in paths},
        criterion='All original 399 knots through k=5; report absolute branch and paired observable accuracy vs radiation active (2e-5). Retain failed per-mode tests.',
        screening='Unchanged four exposed SDSS rows and covariance, five pre-existing compression mappings, no refits. Score only after source/grid checks. Not a full-shape likelihood.'))


def evaluate(flavour,case,chart,folder):
    sys.path[:0]=[folder,str(COMMON/'radiation-and-slow-field-transfer-20261007')]
    import matching_common as inherited
    import camb
    pkg=Path(camb.__file__).resolve().parent
    lock=read(ROOT/'input-lock.json')
    assert pkg.is_relative_to(Path(folder).resolve())
    library=digest(pkg/'cambdll.dll')
    assert library==(lock['patched_library'] if flavour=='fixed' else lock['inputs'][str(NATIVE/'camb/cambdll.dll')])
    source=SPEC/'runs/projection/a225-w6-d8.npz' if case=='heavy' else EARLY/'runs/backgrounds/cold.npz'
    params=inherited.params_for(source)
    assert not params.WantCls and params.Accuracy.AccuracyBoost==2.5 and params.Accuracy.BackgroundTimeStepBoost==8
    params.DoLateRadTruncation=chart=='rsa'
    native=camb.get_background(params)
    native.Params.Accuracy.IntTolBoost=6
    ledger=read(ROOT/'integral-lock.json')['inputs']
    for path in sorted((SPEC/'runs'/case).glob('chunk-*.npz')):
        guard()
        assert digest(path)==ledger[str(path)]
        with np.load(path) as data:
            modes=data['modes'][data['modes']<=5]
            times=data['conformal_time'];scales=data['requested_scale']
        if not modes.size:continue
        dest=ROOT/'full-grid'/('-'.join([flavour,case,chart,path.name]))
        if not dest.exists():
            values=native.get_time_evolution(modes,times,vars=FIELDS,lAccuracyBoost=4)
            assert np.isfinite(values).all() and np.all(values[:,:,-2]==0) and np.all(values[:,:,-1]==(case=='heavy'))
            with dest.with_suffix('.partial').open('xb') as handle:
                np.savez_compressed(handle,values=values,modes=modes,times=times,scales=scales,names=FIELDS,dll=library,
                                    source_sha=ledger[str(path)])
            dest.with_suffix('.partial').rename(dest)
        with np.load(dest) as data:
            assert np.array_equal(data['modes'],modes) and np.array_equal(data['times'],times)
            assert str(data['dll'])==library and str(data['source_sha'])==ledger[str(path)]
    print('completed',flavour,case,chart,flush=True)


def go():
    guard()
    (ROOT/'full-grid').mkdir(exist_ok=True)
    for path,expected in read(ROOT/'integral-lock.json')['inputs'].items():assert digest(path)==expected
    for flavour,case,chart in FAMILIES:
        with tempfile.TemporaryDirectory(dir=ROOT,prefix='view-') as tmp:
            folder=Path(tmp);pkg=folder/'native/camb';pkg.mkdir(parents=True)
            for path in (NATIVE/'camb').iterdir():
                if path.is_file() and path.suffix in ('.py','.dat','.dll'):
                    src=ROOT/'matched-rsa.dll' if flavour=='fixed' and path.name=='cambdll.dll' else path
                    shutil.copyfile(src,pkg/path.name)
            shutil.copyfile(NATIVE/'fortran/HighLExtrapTemplate_lenspotentialCls.dat',pkg/'HighLExtrapTemplate_lenspotentialCls.dat')
            for name in ('stage_common.py','matching_common.py'):shutil.copyfile(MATCH/name,folder/name)
            subprocess.run([sys.executable,'-B',__file__,'one',flavour,case,chart,str(folder)],check=True,timeout=2700)


if __name__=='__main__':
    worker=psutil.Process()
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    worker.cpu_affinity([worker.cpu_affinity()[0]])
    if sys.argv[1]=='freeze':freeze()
    elif sys.argv[1]=='run':go()
    elif sys.argv[1]=='one':evaluate(*sys.argv[2:])
