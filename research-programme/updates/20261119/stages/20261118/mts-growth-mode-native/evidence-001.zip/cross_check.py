from observable import *
import csv
from scipy.interpolate import CubicSpline
from scipy.linalg import solve_triangular
from scipy.special import spherical_jn


def rows(name):
    with (ROOT/name).open(encoding='utf8',newline='') as handle:return list(csv.DictReader(handle))


def check():
    guard()
    full=read(ROOT/'full-validation.json')
    for path,checksum in full['packets'].items():assert digest(ROOT/'full-grid'/path)==checksum
    weights=rows('all-observables.csv')
    scores=rows('growth-screen.csv')
    details=[]
    with np.load(SPEC/'sources/sdss-growth/growth-only.npz') as data:
        chol=np.linalg.cholesky(data['covariance'])
        for record in scores:
            prediction=np.array([float(record[f'z{redshift:g}']) for redshift in data['redshifts']])
            whitened=solve_triangular(chol,prediction-data['mean'],lower=True)
            assert abs(whitened@whitened-float(record['conditional_chi2']))<1e-11
    grid,epochs,_=original_spectrum('cold')
    log_grid=np.linspace(np.log(grid[0]),np.log(grid[-1]),32769)
    kvals=np.exp(log_grid);arg=kvals*8/.7
    kernel=2.1e-9*(kvals/.05)**(-.0347)*(3*spherical_jn(1,arg)/arg)**2
    for flavour,case,chart in FAMILIES:
        version='fixed' if chart=='rsa' else 'live'
        spectra,_=evolved(flavour,case,chart)
        for row in [rec for rec in weights if rec['case']==case and rec['variant']==version]:
            redshift=float(row['z']);epoch=np.argmin(abs(epochs-1/(1+redshift)))
            density,speed=[np.exp(CubicSpline(np.log(grid),np.log(spectra[col][:,epoch]))(log_grid)) for col in ('delta_m','velocity_cdm')]
            rms=np.sqrt(np.trapezoid(kernel*density**2,x=log_grid))
            growth=np.trapezoid(kernel*density*speed,x=log_grid)/rms
            details.append(dict(case=case,chart=chart,z=redshift,
                                sigma_rel=rms/float(row['sigma8_m'])-1,velocity_cross_rel=growth/float(row['fsigma8_cdm_m'])-1))
    maxerr=max(max(abs(row[key]) for key in ('sigma_rel','velocity_cross_rel')) for row in details)
    assert len(details)==32 and maxerr<1e-8
    tab=rows('per-mode-precision.csv');counts={}
    for pop in ('cold','heavy','ratio'):
        for col in ('delta_m','velocity_cdm'):
            subset=[row for row in tab if row['case']==pop and row['key']==col]
            assert len(subset)==399
            failed=[row for row in subset if float(row['worst_fractional_error'])>TOL]
            counts[pop+'_'+col]=dict(nonpassing_mode_count=len(failed),worst=max(float(row['worst_fractional_error']) for row in subset),
                   failures_today=sum(float(row['today_fractional_error'])>TOL for row in subset),
                   worst_k=float(max(subset,key=lambda row:float(row['worst_fractional_error']))['k']))
    for path,expected in read(ROOT/'input-lock.json')['inputs'].items():assert digest(path)==expected
    for path,expected in read(ROOT/'integral-lock.json')['inputs'].items():assert digest(path)==expected
    assert not list((ROOT/'full-grid').glob('*.partial')) and not list(ROOT.glob('view-*'))
    save('cross-check.json',dict(independent_top_hat_and_quadrature_peak_relative=maxerr,checked_redshift_branch_charts=len(details),
                                independent_whitened_scores_checked=len(scores),original_hashes_unchanged=True,pointwise=counts))
    print('Independent integrals',maxerr,'pointwise',counts)


if __name__=='__main__':check()
