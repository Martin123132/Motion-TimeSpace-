from cross_check import *
from scipy.integrate import simpson


def compute_budget():
    guard()
    modes,scales,old=original_spectrum('heavy')
    heavy,_=evolved('fixed','heavy','rsa')
    cold,_=evolved('stock','cold','rsa')
    limits=[modes[0],.01,.03413181224396675,.075,.1197085030496,.1725,.25557578689427507,.5,1.,5.]
    details=[];samples=[]
    for redshift in [0.,.38,.51,.698,1.48]:
        epoch=np.argmin(abs(scales-1/(1+redshift)))
        transforms={}
        for name,pack in [('corrected',heavy),('old',old),('cold',cold)]:
            transforms[name]=[CubicSpline(np.log(modes),np.log(pack[col][:,epoch])) for col in ('delta_m','velocity_cdm')]
        integrated={}
        for name,(density,velocity) in transforms.items():
            parts=[]
            for lower,upper in zip(limits[:-1],limits[1:]):
                coord=np.linspace(np.log(lower),np.log(upper),2049)
                kval=np.exp(coord);arg=kval*8/.7
                weight=2.1e-9*(kval/.05)**(-.0347)*(3*spherical_jn(1,arg)/arg)**2
                parts.append([simpson(weight*np.exp(2*density(coord)),x=coord),simpson(weight*np.exp(density(coord)+velocity(coord)),x=coord)])
            integrated[name]=np.array(parts)
        for name in ('old','cold'):
            test,ref=integrated['corrected'],integrated[name]
            std=np.sqrt(test.sum(axis=0)[0]);std0=np.sqrt(ref.sum(axis=0)[0]);base_f=ref.sum(axis=0)[1]/std0
            delta=test-ref
            amp=delta[:,0]/(std+std0)
            growth=(delta[:,1]-base_f*amp)/std
            np.testing.assert_allclose([amp.sum(),growth.sum()],[std-std0,test.sum(axis=0)[1]/std-base_f],atol=5e-15,rtol=0)
            for idx,(lower,upper) in enumerate(zip(limits[:-1],limits[1:])):
                details.append(dict(z=redshift,comparison='corrected_minus_'+name,lower=lower,upper=upper,variance_shift=delta[idx,0],
                                    rms_shift=amp[idx],growth_shift=growth[idx],signed_fraction_of_rms_shift=amp[idx]/amp.sum(),
                                    signed_fraction_of_growth_shift=growth[idx]/growth.sum()))
        for wave in (.01,.03,.075,.12,.255,.5,1.,5.):
            coordinate=np.log(wave)
            samples.append(dict(z=redshift,k=wave,corrected_heavy_over_cold_power=np.exp(2*(transforms['corrected'][0](coordinate)-transforms['cold'][0](coordinate))),
                   old_heavy_over_cold_power=np.exp(2*(transforms['old'][0](coordinate)-transforms['cold'][0](coordinate)))))
    table('scale-budget.csv',details);table('scale-response.csv',samples)
    print([(row['k'],row['corrected_heavy_over_cold_power']) for row in samples if row['z']==0])
    print([(row['lower'],row['upper'],row['signed_fraction_of_rms_shift']) for row in details if row['z']==0 and row['comparison']=='corrected_minus_cold'])


if __name__=='__main__':compute_budget()
