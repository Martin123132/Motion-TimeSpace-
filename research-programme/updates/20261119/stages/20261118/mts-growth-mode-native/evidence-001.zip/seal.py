from native_test import *
from datetime import datetime,timezone


def seal():
    guard()
    for name in ('input-lock.json','integral-lock.json'):
        assert all(digest(path)==value for path,value in read(ROOT/name)['inputs'].items())
    assert digest(ROOT/'matched-rsa.dll')==read(ROOT/'input-lock.json')['patched_library']
    full=read(ROOT/'full-validation.json')
    assert (full['modes'],full['epochs'],len(full['packets']))==(399,61,100)
    assert all(digest(ROOT/'full-grid'/path)==expected for path,expected in full['packets'].items())
    assert read(ROOT/'cross-check.json')['independent_whitened_scores_checked']==35
    assert all(not list(ROOT.rglob(pattern)) for pattern in ('*.partial','__pycache__','view-*'))
    required=['RESULTS.md','scale-budget.csv','scale-response.csv','validation.json','growth-screen.csv','integral-precision.csv',
              'all-observables.csv','switches.csv','cross-check.json','per-mode-precision.csv','paired-native.csv']
    assert all((ROOT/name).is_file() for name in required)
    items={path.relative_to(ROOT).as_posix():dict(bytes=path.stat().st_size,sha256=digest(path)) for path in sorted(ROOT.rglob('*')) if path.is_file() and path!=ROOT/'closeout.json'}
    receipt=ROOT/'closeout.json'
    if receipt.exists():assert read(receipt)['files']==items
    else:save('closeout.json',dict(previous=SEAL,utc=datetime.now(timezone.utc).isoformat(),files=items,
                                  nfiles=len(items),total_bytes=sum(value['bytes'] for value in items.values())))
    print('Verified',len(items),'files',digest(receipt))


if __name__=='__main__':seal()
