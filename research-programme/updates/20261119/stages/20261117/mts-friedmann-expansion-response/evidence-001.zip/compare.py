import csv
import json
import math
from decimal import Decimal,localcontext

from response import ROOT,PREVIOUS,POST,bank,slip,np,require,guard,as_decimal,densities

RUN=ROOT/'isolated'


def peak(values):
    return float(np.max(np.abs(values)))


def alternate(constants,native,implemented,measured):
    with localcontext() as context:
        context.prec=75
        params=list(map(as_decimal,constants))
        old=list(map(as_decimal,native))
        new=list(map(as_decimal,implemented))
        left,right=old[0],new[0]
        alpha=(right-left)/left
        inverse=1/(1+alpha)
        sq=alpha*(2+alpha)
        amount=[-params[index]/left*alpha*inverse for index in (0,1)]
        amount.extend(-params[index]/left**2*sq*inverse**2 for index in (2,3))
        nu=Decimal(0)
        for index in range(int(params[4])):
            arg=left*params[8+index]
            last=right*params[8+index]
            require((arg<Decimal('.01'))==(last<Decimal('.01')),'same retained neutrino region on this interval')
            delta=-sq*inverse**2
            if arg>=Decimal('.01'):
                delta+=arg**4*(sq*(Decimal('.01099926669')*arg.ln()-Decimal('.003492416767'))+
                      (1+alpha)**2*Decimal('.01099926669')*(1+alpha).ln()-
                      Decimal('.005866275571')*arg*alpha*(3+3*alpha+alpha**2))
            nu+=params[14+index]*delta/left**2
        amount.append(nu)
        for index,(before,after) in enumerate(zip(old[1::2],new[1::2])):
            mass=params[6+index]
            vel,vel1=old[2+2*index],new[2+2*index]
            du=mass*(left*(after-before)+(right-left)*after)
            amount.append(((vel1-vel)*(vel1+vel)+du*(2*left*mass*before+du))/2)
        if len(amount)==6:
            amount.append(Decimal(0))
        density0,density1=sum(densities(params,old)),sum(densities(params,new))
        predicted=sum(amount)/(3*((density0/3).sqrt()+(density1/3).sqrt()))
        h0,h1=map(as_decimal,measured)
        residual0,residual1=3*h0*h0-density0,3*h1*h1-density1
        reconstructed=(sum(amount)+residual1-residual0)/(3*(h0+h1))
        require(abs(reconstructed-(h1-h0))<Decimal('1e-60'),'defect bookkeeping identity')
        return float(predicted),float((residual1-residual0)/(3*(h0+h1)))


def check_case(label,index,steps):
    case,mode=label.split('_')
    prefix=f'{case}-{steps}-{mode}-{index}'
    prediction=RUN/(prefix+'-prediction.npz')
    freeze=bank.read(RUN/(prefix+'-freeze.json'))
    require(bank.digest(prediction)==freeze['prediction_sha256'] and bank.digest(ROOT/'response_v2.py')==freeze['program'] and bank.digest(ROOT/'response.py')==freeze['helpers'] and bank.digest(ROOT/'METHOD.md')==freeze['protocol'],'frozen before score')
    with np.load(prediction) as data, np.load(RUN/(prefix+'-reference.npz')) as ref:
        rates,aux,times,constants,inputs=(data[key] for key in ('components','aux','time','constants','primitive'))
        routes=data['routes'].tolist()
        measured,forces,gauss=(ref[key] for key in ('metric','forces','integrals'))
        require(np.array_equal(times,ref['time']) and rates.shape==(257,5,10),'paired shape')
    if (ROOT/(prefix+'-prediction.npz')).exists():
        for suffix in ('-prediction.npz','-reference.npz'):
            with np.load(ROOT/(prefix+suffix)) as first,np.load(RUN/(prefix+suffix)) as replay:
                require(set(first.files)==set(replay.files) and all(np.array_equal(first[key],replay[key]) for key in first.files),'isolated replay of partial first run')
    delta_h=measured[:,1]-measured[:,0]
    hscale=peak(delta_h)
    require(hscale>0 and np.array_equal(-delta_h*aux[:,0],forces[:,2]),'true expansion term')
    rmscale=np.maximum(abs(forces[0,-2:]),abs(forces[-1,-2:]))
    scale=np.r_[rmscale,abs(gauss[-1])]
    target=np.r_[forces[-1,-2:],gauss[-1]]
    species_check=peak(np.sum(rates[:,:,1:8],axis=2)-rates[:,:,0])/hscale
    require(species_check<=bank.ALG,'finite species sum')
    factored=[]
    defects=[]
    for pos in range(0,257,16):
        pred,residual=alternate(constants,inputs[pos,0],inputs[pos,4],measured[pos,:2])
        factored.append(pred-rates[pos,2,0])
        defects.append(residual)
    require(peak(factored)<=bank.ALG*hscale,'independent factored species calculation')
    columns=['cdm','baryons','photons','massless_nu','massive_nu','slow','heavy']
    width=times[-1]-times[0]
    all_forces=np.repeat(forces[None,:,:9],len(routes)+1+len(columns),axis=0)
    for num,_ in enumerate(routes):
        all_forces[num,:,2]=-rates[:,num,0]*aux[:,0]
    chord=np.arange(257)/256
    for num,column in enumerate(columns):
        term=rates[:,2,1+num]
        straight=term[0]+chord*(term[-1]-term[0])
        all_forces[len(routes)+1+num,:,2]=all_forces[2,:,2]-(straight-term)*aux[:,0]
    original,changed=forces[0,-2:]
    fine=slip.propagate(all_forces,original,changed,width,2)
    middle=slip.propagate(all_forces,original,changed,width,1)
    coarse=slip.propagate(all_forces[:,::2,:],original,changed,width,2)
    working=abs(fine-middle)+abs(coarse-fine)
    working[:,2]+=sum(abs(np.diff(gauss)))
    diagnostics={name:dict(H_error=peak(rates[:,num,0]-delta_h)/hscale,H_endpoint=abs(rates[-1,num,0]-delta_h[-1])/hscale,
                      maximum_absolute_H_error=peak(rates[:,num,0]-delta_h),source_error=float((fine[num,2]-gauss[-1])/abs(gauss[-1])),
                      slip_error=((fine[num,:2]-target[:2])/scale[:2]).tolist()) for num,name in enumerate(routes)}
    straightening=(fine[len(routes)+1:,2]-fine[2,2])/abs(gauss[-1])
    species_scale={name:peak(rates[:,2,num+1])/hscale for num,name in enumerate(columns)}
    record=dict(label=label,index=index,steps=steps,new=freeze['new_cell'],peak_delta_H=hscale,control_native_root_relative=peak((rates[:,2,8:10]-measured[:,:2])/measured[:,:2]),
          sampled_constraint_remainder_relative=peak(defects)/hscale,represented_owner_response_parity=peak(rates[:,0,0]-aux[:,1])/hscale,
          max_abs_constraint_remainder_sampled=peak(defects),max_abs_native_packet_constraint=peak(measured[:,2:4]),
          inherited_native_source_control=float((fine[len(routes),2]-gauss[-1])/abs(gauss[-1])),
          range_32_64_is_not_precision=True,derivation_routes=diagnostics,relative_peak_species_terms=species_scale,
          individual_chord_effect_on_integral=dict(zip(columns,straightening.tolist())),numerical_substeps=freeze['native_steps'],background_only_steps=freeze['autonomous_steps'])
    return record,(rates,delta_h,hscale,scale,target,fine[:len(routes)],working[:len(routes)],routes)


def main():
    guard()
    tables={}
    pairs=[]
    for label in bank.LABELS:
        cold=label.startswith('cold')
        for index in ([892,3112,1204,2409] if cold else [96,5264,2618,5236]):
            records,values=zip(*(check_case(label,index,steps) for steps in (32,64)))
            for record in records:
                tables[f"{label}-{index}-{record['steps']}"]=record
            low,high=values
            for route_num,route in enumerate(high[-1]):
                hscale=high[2]
                herror=peak(low[0][:,route_num,0]-low[1])+peak(high[0][:,route_num,0]-high[1])+peak(low[1]-high[1])
                source=(abs(low[4]-high[4])+abs(low[5][route_num]-low[4])+abs(high[5][route_num]-high[4])+
                        low[6][route_num]+high[6][route_num])/high[3]
                pairs.append(dict(branch=label,index=index,fresh=records[0]['new'],route=route,H_budget=herror/hscale,
                     old_slip_budget=source[0],changed_slip_budget=source[1],integral_budget=source[2],
                     H_pass=herror/hscale<=bank.TOL,response_pass=bool(max(source)<=bank.TOL),both_pass=bool(max(herror/hscale,*source)<=bank.TOL)))
    bank.save(ROOT/'comparison.json',tables)
    with (ROOT/'paired.csv').open('x',encoding='utf-8',newline='') as stream:
        out=csv.DictWriter(stream,fieldnames=pairs[0])
        out.writeheader()
        out.writerows(pairs)
    for row in pairs:
        if row['route']=='autonomous_implemented':
            print(row['branch'],row['index'],row['H_budget'],row['integral_budget'],row['both_pass'])


if __name__=='__main__':
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/'score-start.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    try:
        main()
    finally:
        bank.save(ROOT/'score-end.json',dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
