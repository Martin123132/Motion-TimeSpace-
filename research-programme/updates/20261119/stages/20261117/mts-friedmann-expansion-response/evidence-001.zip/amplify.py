import argparse
import math
from pathlib import Path
from response import ROOT,POST,PREVIOUS,bank,np,require,guard

RUN=ROOT/'isolated'
OUT=ROOT/'secant'


def bound(params,initial,delta,amplitude,old_rate,temperature):
    finish=initial+amplitude*delta
    if min(initial[0],finish[0])<=0 or abs(amplitude*delta[0])>.005*initial[0]:
        return None
    amin,amax=sorted((initial[0],finish[0]))
    if not (3500<temperature/(2.7255*amax)-1 and temperature/(2.7255*amin)-1<5000):
        return None
    matter,radiation=sum(params[:2]),sum(params[2:4])
    hmin=math.sqrt((matter/amax+radiation/amax**2)/3)
    first=matter/amin**2+2*radiation/amin**3
    second=2*matter/amin**3+6*radiation/amin**4
    for idx in range(int(params[4])):
        mass,weight=params[8+idx],params[14+idx]
        low,high=mass*amin,mass*amax
        if low<=0 or high>.3+70/1399*1.01 or (low<.01)!=(high<.01):
            return None
        first+=2*weight/amin**3
        second+=6*weight/amin**4
        if low>=.01:
            lead=.01099926669
            term=lead*max(abs(math.log(low)),abs(math.log(high)))+.003492416767
            factor=weight*mass**4
            first+=factor*(2*amax*term+lead*amax+3*.005866275571*mass*amax**2)
            second+=factor*(2*term+3*lead+6*.005866275571*mass*amax)
    first,second=first*abs(delta[0]),second*delta[0]**2
    for idx in range((len(initial)-1)//2):
        offset=1+2*idx
        mass=params[6+idx]
        field,velocity=initial[offset:offset+2]
        df,dv=delta[offset:offset+2]
        if amplitude*math.hypot(mass*amax*df,dv)>.05*math.hypot(mass*initial[0]*field,velocity):
            return None
        fm=max(abs(field),abs(finish[offset]))
        vm=max(abs(velocity),abs(finish[offset+1]))
        potential=mass*amax*fm
        slope=mass*(abs(delta[0])*fm+amax*abs(df))
        first+=vm*abs(dv)+potential*slope
        second+=dv**2+slope**2+potential*2*mass*abs(delta[0]*df)
    hmax=math.sqrt(old_rate**2+amplitude*first/3)
    trunc=(amplitude-1)/2*(second/(6*hmin)+first**2/(36*hmin**3))
    arithmetic=128*np.finfo(float).eps*hmax/amplitude
    return (trunc*(1+1e-12),arithmetic*(1+1e-12))


def make_plan(case,steps):
    mode='parent' if case=='heavy' else 'baseline'
    indices=[96,5264,2618,5236] if case=='heavy' else [892,3112,1204,2409]
    plans=[]
    for index in indices:
        tag=f'{case}-{steps}-{mode}-{index}'
        with np.load(RUN/(tag+'-prediction.npz')) as packet:
            stored=packet['primitive']
            params=packet['constants']
            time=packet['time']
            old_rates=packet['components'][:,2,8]
        if case=='heavy':
            with np.load(RUN/(tag.replace('parent','approximate')+'-prediction.npz')) as match:
                require(np.array_equal(stored,match['primitive']),'shared physical backgrounds')
        for node in range(0,257,16):
            native,rep,physical,_,actual,_=stored[node]
            for route in ('ideal','implemented'):
                if route=='ideal':
                    addition=physical.copy()
                    addition[0]*=rep[0]
                    diff=np.array([math.fsum((r-n,d)) for r,n,d in zip(rep,native,addition)])
                else:
                    diff=actual-native
                options={}
                for power in range(33):
                    amp=2**power
                    item=bound(params,native,diff,amp,old_rates[node],2.7255)
                    if item is None:
                        break
                    options[amp]=item
                require(2 in options,'at least two lawful secant scales')
                amplitude=min((amp for amp in options if amp>=2),key=lambda amp:sum(options[amp])+sum(options[amp//2]))
                plans.append(dict(index=index,node=node,time=time[node],route=route,delta=diff.tolist(),native=native.tolist(),actual=actual.tolist(),
                        amplitude=amplitude,bound=list(options[amplitude]),half_bound=list(options[amplitude//2])))
    return plans


def main(case,steps):
    guard()
    bank.check_seals()
    tag=f'{case}-{steps}'
    plans=make_plan(case,steps)
    bank.save(OUT/(tag+'-plan.json'),dict(code=bank.digest(Path(__file__)),method=bank.digest(ROOT/'SECANT.md'),rows=plans))
    bank.ROOT=OUT
    live,context=bank.native_setup(case,steps,tag)
    mode='parent' if case=='heavy' else 'baseline'
    results=[]
    with context as (capture,metadata,sample):
        original=capture['reference'][0].copy()
        require(np.array_equal(capture['signature'],live.load(Path(live.CONFIG['capture_authority'])/(case+'-preflight-capture.npz'))['signature']),'same hierarchy')
        for index in sorted({row['index'] for row in plans}):
            label=f'{tag}-{mode}-{index}'
            with np.load(RUN/(label+'-reference.npz')) as ref,np.load(RUN/(label+'-prediction.npz')) as pred:
                metric=ref['metric']
                predictions=pred['components']
                hscale=max(abs(metric[:,1]-metric[:,0]))
            for row in [item for item in plans if item['index']==index]:
                node=row['node']
                place=1 if row['route']=='ideal' else 2
                expected=predictions[node,place,0]
                initial=np.array(row['native'])
                diff=np.array(row['delta'])
                time=row['time']
                empty=np.zeros(5)
                _,original_obs,extra=sample(time,original,empty,False)
                require(extra[5]==2.7255,'same native temperature')
                h0=original_obs[28]
                require(h0==metric[node,0],'same native initial rate')
                empty[:len(initial)]=row['actual']
                require(sample(time,original,empty,True)[1][28]==metric[node,1],'unperturbed reference vector independent of stored matter perturbations')
                rates=[]
                for amp,key in ((row['amplitude'],'bound'),(row['amplitude']//2,'half_bound')):
                    empty[:len(initial)]=initial+amp*diff
                    observed=sample(time,original,empty,True)[1][28]
                    secant=(observed-h0)/amp
                    rates.append([amp,secant,*row[key]])
                results.append(dict(index=index,node=node,route=row['route'],hscale=hscale,physical=expected,secants=rates,
                    worst_abs_error=max(abs(item[1]-expected) for item in rates),
                    working=max(abs(item[1]-expected)+item[2]+item[3] for item in rates)+abs(rates[0][1]-rates[1][1]),
                    consistent=all(abs(item[1]-expected)<=item[2]+item[3] for item in rates)))
    bank.save(OUT/(tag+'-check.json'),dict(rows=results))
    print(tag,'secants checked',len(results),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=('cold','heavy'))
    parser.add_argument('steps',type=int,choices=(32,64))
    args=parser.parse_args()
    OUT.mkdir(exist_ok=True)
    tag=f'{args.case}-{args.steps}'
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(OUT/(tag+'-start.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    try:
        main(args.case,args.steps)
    finally:
        bank.save(OUT/(tag+'-end.json'),dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
