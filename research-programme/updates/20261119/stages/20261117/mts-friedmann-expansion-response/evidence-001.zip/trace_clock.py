from response import ROOT,bank,np,require,guard


def main():
    guard()
    bank.check_seals()
    report={}
    for label in ('cold_baseline','heavy_parent'):
        with np.load(bank.source_path(label,32)) as low,np.load(bank.source_path(label,64)) as high:
            require(np.array_equal(low['time'],high['time']),'same physical clock')
            lowalpha,highalpha,times=low['alpha'],high['alpha'],high['time']
        differences=np.abs(highalpha-lowalpha)
        norm=np.max(abs(highalpha))
        hits=np.flatnonzero(differences>bank.TOL*norm)
        first=int(hits[0]) if len(hits) else None
        report[label]=dict(first_time=times[0],last_time=times[-1],first_alpha32=lowalpha[0],first_alpha64=highalpha[0],
             whole_saved_peak_alpha=norm,maximum_refinement_difference=np.max(differences),relative_to_full_peak=np.max(differences)/norm,
             first_index_beyond_full_peak_tolerance=first,first_beyond_time=times[first] if first is not None else None,
             preceding_index=(first-1 if first is not None and first>0 else None),fail_count=len(hits),samples=len(times))
    bank.save(ROOT/'clock-history.json',dict(scope='Scale variable only; threshold uses FULL saved peak, not a per-knot physical error bound. No new evolution.',cases=report))
    print(report)


if __name__=='__main__':
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/'trace-start.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    try:
        main()
    finally:
        bank.save(ROOT/'trace-end.json',dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
