from response import (argparse, Path, ROOT, POST, PREVIOUS, bank, slip, np, solve_ivp, require, guard,
                      jet_reader, stable_cases, branch_state, gauss_source)

RUN=ROOT/'isolated'

def worker(case,steps):
    guard()
    bank.check_seals()
    require(bank.digest(PREVIOUS/'closeout.json')=='5b80cfbb551cef1bdf23bb6962e7534946cdd5a4375e3b755dfd818645a508bb','previous stage seal')
    seal=bank.read(PREVIOUS/'closeout.json')['files']
    for filename in ('interval_probe.py','interior_forcing.py','verification.json'):
        require(bank.digest(PREVIOUS/filename)==seal[filename]['sha256'],'frozen upstream code or results')
    bank.ROOT = RUN
    with np.load(bank.source_path(case+('_parent' if case=='heavy' else '_baseline'),steps)) as source:
        clock=source['time']
    previous=[96,5264] if case=='heavy' else [892,3112]
    cells=[*previous,(len(clock)-1)//3,2*(len(clock)-1)//3]
    prior_probes=bank.read(PREVIOUS/'selection.json')['selected'][case]
    require(all(all(not left<=index<right for left,right in prior_probes) for index in cells[2:]),'new cells excluded from all development probes')
    pairs=bank.selected_rows(case,steps,set(cells),clock)
    schema=bank.read(POST/'mts-coupled-metric-consistency-20261117/packet-schema.json')
    columns={name:84+idx for idx,name in enumerate(schema['global_columns'])}
    tag=f'{case}-{steps}'
    live,native=bank.native_setup(case,steps,tag)
    with native as (capture,metadata,sample):
        prepared,_,background,_,_=live.EX.problem(case)
        frozen=live.load(Path(live.CONFIG['capture_authority'])/(case+'-preflight-capture.npz'))
        require(all(np.array_equal(value,frozen[name]) for name,value in capture.items()),'unchanged complete bank')
        direct=live.MetricCoupled(case,prepared,background,live.prefix(capture,case),metadata,sample)
        model=direct.model
        jets_at=jet_reader(model.count)
        photon=int(capture['signature'][0,3])
        wave=float(prepared['wave'][0])
        options=dict(method='DOP853',rtol=live.CONFIG['rtol'],atol=live.CONFIG['normalized_atol'],max_step=float(prepared['elapsed'][8])/steps,dense_output=True)
        for index in cells:
            guard()
            states,path=pairs[index]
            direct=live.MetricCoupled(case,prepared,background,live.prefix(capture,case),metadata,sample)
            system=None
            if case=='heavy':
                system=live.worklib.Carried(direct,live.worklib.LiveSecond(case,prepared,background,live.prefix(capture,case),metadata,sample))
                if bank.BUDGET in path.parents or 'photon-difference-replay-v2' in path.parts:
                    live.operator_repair.install(system)
            left,right=clock[index:index+2]
            solution=solve_ivp(system.rhs if system else direct.rhs,(left,right),states[0].copy(),**options)
            require(solution.success and np.array_equal(solution.y[:,-1],states[1]),'identical full-state right restart')
            times=np.linspace(left,right,257)
            vectors=solution.sol(times).T
            initial=branch_state(direct,system,states[0],'baseline' if case=='cold' else 'parent')[2]/direct.background_units
            def bg_rhs(time,normalized):
                original=model.represented(time)
                physical=normalized*direct.background_units
                flow=model.difference_flow(original,physical,False)
                fd=original['field_first']-original['velocity']
                vd=original['velocity_first']+2*original['hubble']*original['velocity']+original['mass']*original['field']
                return model.pack(flow[0]/original['scale']-original['rate']*physical[0]+original['hubble']-original['rate'],flow[1::2]-fd,flow[2::2]-vd)/direct.background_units
            independent=solve_ivp(bg_rhs,(left,right),initial,**options)
            require(independent.success,'autonomous background')
            auto=independent.sol(times).T*direct.background_units
            modes=('parent','approximate') if case=='heavy' else ('baseline',)
            for mode in modes:
                prefix=f'{tag}-{mode}-{index}'
                rates=[]
                raw=[]
                native_inputs=[]
                for time,state,autodelta in zip(times,vectors,auto):
                    old,_,physical,_,_=branch_state(direct,system,state,mode)
                    original=model.represented(time)
                    original_scale=sample(time,old,np.zeros(5),False)[2][0]
                    jets=jets_at(time,old)
                    require(np.array_equal(jets[:,4],(original_scale*model.constants[6:6+model.count])**2),'native mass convention')
                    direct_base=model.pack(original_scale,jets[:,0],jets[:,1])
                    represented=model.pack(original['scale'],original['field'],original['velocity'])
                    actual=represented+physical
                    actual[0]=represented[0]*(1+physical[0])
                    autonomous=represented+autodelta
                    autonomous[0]=represented[0]*(1+autodelta[0])
                    rates.append(stable_cases(model.constants,direct_base,represented,physical,autodelta,actual,autonomous))
                    raw.append([old[3],model.correction_geometry(original,physical,False)[0]])
                    native_inputs.append([direct_base,represented,physical,autodelta,actual,autonomous])
                predpath=RUN/(prefix+'-prediction.npz')
                with predpath.open('xb') as stream:
                    np.savez_compressed(stream,time=times,components=rates,primitive=native_inputs,aux=raw,constants=model.constants,
                        routes=['represented','native_ideal','native_implemented','autonomous_implemented','autonomous_ideal'],
                        columns=['delta_H','CDM','baryon','photon','massless_nu','massive_nu','slow','heavy','H0','H1'])
                bank.save(RUN/(prefix+'-freeze.json'),dict(prediction_sha256=bank.digest(predpath),protocol=bank.digest(ROOT/'METHOD.md'),
                  program=bank.digest(Path(__file__)),helpers=bank.digest(ROOT/'response.py'),restart=str(path),cell=index,new_cell=index not in previous,autonomous_steps=len(independent.t)-1,native_steps=len(solution.t)-1))
                readings=[]
                references=[]
                for time,state,packed in zip(times,vectors,native_inputs):
                    old,change,_,_,_=branch_state(direct,system,state,mode)
                    full=np.zeros(5)
                    full[:direct.width]=packed[4]
                    metric0=direct.read_metric(time,old,full,False)
                    metric1=direct.read_metric(time,old+change,full,True)
                    references.append([metric0[columns['hubble']],metric1[columns['hubble']],metric0[columns['friedmann_constraint']],metric1[columns['friedmann_constraint']],*metric0[:84:12],*metric1[:84:12]])
                    readings.append(slip.physical_sample(direct,system,time,state,mode,photon,wave,columns))
                readings=np.array(readings)
                integrals=gauss_source(direct,system,solution,mode,photon)
                if index in previous:
                    oldtag=f'interior-{case}-{steps}-{mode}-{index}'
                    with np.load(PREVIOUS/(oldtag+'.npz')) as retained:
                        require(np.array_equal(readings,retained['values']) and np.array_equal(times,retained['time']),'unchanged prior dense probe')
                    require(integrals[-1]==bank.read(PREVIOUS/(oldtag+'.json'))['direct_gauss7'],'unchanged original integral')
                with (RUN/(prefix+'-reference.npz')).open('xb') as stream:
                    np.savez_compressed(stream,time=times,metric=references,forces=readings,integrals=integrals)
                print(prefix,'saved',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=('heavy','cold'))
    parser.add_argument('steps',type=int,choices=(32,64))
    args=parser.parse_args()
    tag=f'{args.case}-{args.steps}'
    RUN.mkdir(exist_ok=True)
    process=bank.psutil.Process()
    process.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([4])
    bank.save(RUN/(tag+'-start.json'),dict(pid=process.pid,created=process.create_time(),command=process.cmdline(),affinity=process.cpu_affinity()))
    try:
        worker(args.case,args.steps)
    finally:
        bank.save(RUN/(tag+'-end.json'),dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
