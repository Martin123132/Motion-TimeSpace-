import json
from response import ROOT,POST,bank,require,guard


def main():
    guard()
    trace=bank.read(ROOT/'clock-history.json')['cases']
    require(trace['cold_baseline']['first_index_beyond_full_peak_tolerance']==0 and trace['heavy_parent']['first_index_beyond_full_peak_tolerance'] is None,'trace provenance')
    require(len(bank.read(ROOT/'clock-split.json'))==8 and bank.read(ROOT/'verification.json')['upstream_stage_hashes']==137,'replay provenance')
    receipts=[]
    for path in sorted(ROOT.rglob('*-start.json')):
        record=bank.read(path)
        require(path.with_name(path.name.replace('-start','-end')).exists(),'worker end receipt')
        try:
            proc=bank.psutil.Process(record['pid'])
            require(abs(proc.create_time()-record['created'])>.01,'worker still present: '+str(path))
            status='PID reused, left untouched'
        except bank.psutil.NoSuchProcess:
            status='exited'
        receipts.append(dict(start=path.relative_to(ROOT).as_posix(),pid=record['pid'],created=record['created'],status=status))
    releases=sorted(ROOT.rglob('*-owner-release.json'))
    require(len(releases)==9 and all(all(bank.read(path).get(key) is True for key in ('cleared','native_reference_released')) for path in releases),'all native owners released')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode cache')
    current=bank.psutil.Process()
    bank.save(ROOT/'cleanup.json',dict(workers=receipts,releases=[path.relative_to(ROOT).as_posix() for path in releases],
            closer=dict(pid=current.pid,created=current.create_time(),command=current.cmdline()),stopped_processes=[]))
    inventory={path.relative_to(ROOT).as_posix():dict(sha256=bank.digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file()}
    bank.save(ROOT/'closeout.json',dict(finished=bank.datetime.now(bank.timezone.utc).isoformat(),files=inventory,scope='Private local stage; previous physical checkpoint unchanged.'))
    print('sealed',len(inventory),'files;',len(receipts),'completed workers;',len(releases),'native releases;',bank.digest(ROOT/'closeout.json'))


if __name__=='__main__':
    owner=bank.psutil.Process()
    owner.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    owner.cpu_affinity([4])
    main()
