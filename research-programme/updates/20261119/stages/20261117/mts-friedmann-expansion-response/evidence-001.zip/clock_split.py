from decimal import localcontext
from response import ROOT,bank,np,require,guard,as_decimal,raw_changed,prediction


def main():
    guard()
    records={}
    for case,mode,indices in (('cold','baseline',[892,3112,1204,2409]),('heavy','parent',[96,5264,2618,5236])):
        for index in indices:
            with np.load(ROOT/f'isolated/{case}-32-{mode}-{index}-prediction.npz') as lower,np.load(ROOT/f'isolated/{case}-64-{mode}-{index}-prediction.npz') as higher:
                coarse,fine=lower['primitive'],higher['primitive']
                actual=lower['components'][:,1,0]-higher['components'][:,1,0]
                peak=max(abs(higher['components'][:,1,0]))
                constants=list(map(as_decimal,higher['constants']))
                require(np.array_equal(coarse[:,:2],fine[:,:2]),'identical original background at identical times')
            shares=[]
            with localcontext() as context:
                context.prec=55
                for first,last in zip(coarse,fine):
                    original,represented=[list(map(as_decimal,row)) for row in first[:2]]
                    lo,hi=[list(map(as_decimal,row)) for row in (first[2],last[2])]
                    def rate(delta):
                        return prediction(constants,original,raw_changed(represented,delta))[0]
                    base=rate(hi)
                    both=rate(lo)
                    only_scale=rate([lo[0],*hi[1:]])
                    only_fields=rate([hi[0],*lo[1:]])
                    shares.append([.5*((only_scale-base)+(both-only_fields)),.5*((only_fields-base)+(both-only_scale))])
            shares=np.array(shares)
            require(max(abs(np.sum(shares,axis=1)-actual))<=bank.ALG*peak,'both swap orders averaged; exact sum')
            total=max(abs(actual))
            records[f'{case}:{index}']=dict(peak_physical=peak,fractional_resolution_spread=total/peak,
                    left_endpoint_as_fraction_of_max=abs(actual[0])/total,
                    scale_component_max_fraction=max(abs(shares[:,0]))/total,field_velocity_component_max_fraction=max(abs(shares[:,1]))/total,
                    spread_change_from_left_fraction=max(abs(actual-actual[0]))/total)
    bank.save(ROOT/'clock-split.json',records)
    print(records)


if __name__=='__main__':
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/'clock-start.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    try:
        main()
    finally:
        bank.save(ROOT/'clock-end.json',dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
