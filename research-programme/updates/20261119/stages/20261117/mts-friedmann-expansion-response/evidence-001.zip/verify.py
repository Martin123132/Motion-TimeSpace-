import csv
import math
from pathlib import Path
from response import ROOT,PREVIOUS,bank,np,require,guard


def maximum(values):
    return float(np.max(abs(np.asarray(values))))


def main():
    guard()
    bank.check_seals()
    upstream=bank.read(PREVIOUS/'closeout.json')['files']
    for name,item in upstream.items():
        require(bank.digest(PREVIOUS/name)==item['sha256'],'upstream stage preserved: '+name)
    frozen=bank.read(bank.SOURCE/'inputs.json')
    for name,expected in frozen.items():
        require(bank.digest(Path(name))==expected,'frozen physical source')
    with (ROOT/'paired.csv').open() as stream:
        paired=list(csv.DictReader(stream))
    require(len(paired)==60 and len({(row['branch'],row['index'],row['route']) for row in paired})==60,'five routes times twelve comparisons')
    report=bank.read(ROOT/'comparison.json')
    summaries={}
    results={}
    for case,kind,new,dev in [('cold','baseline',[1204,2409],[892,3112]),('heavy','parent',[2618,5236],[96,5264])]:
        results[case]={}
        layer={}
        for steps in (32,64):
            tag=f'{case}-{steps}'
            trial=bank.read(ROOT/f'secant/{tag}-check.json')['rows']
            plan=bank.read(ROOT/f'secant/{tag}-plan.json')
            require(plan['code']==bank.digest(ROOT/'amplify.py') and plan['method']==bank.digest(ROOT/'SECANT.md'),'frozen choice rule')
            require(len(trial)==len(plan['rows'])==136,'complete native secants')
            key_fields=('index','node','route')
            specs={tuple(spec[key] for key in key_fields):spec for spec in plan['rows']}
            require(len(specs)==len({tuple(row[key] for key in key_fields) for row in trial})==len(trial),'unique plan and reference keys')
            for check in trial:
                spec=specs[tuple(check[key] for key in key_fields)]
                require(all(check[key]==spec[key] for key in ('route','index','node')) and check['secants'][0][0]==spec['amplitude'] and check['secants'][1][0]*2==spec['amplitude'],'no reselection')
                require(all(math.isfinite(value) for row in check['secants'] for value in row) and check['consistent']==all(abs(row[1]-check['physical'])<=row[2]+row[3] for row in check['secants']),'allowances verified')
                layer[steps,spec['index'],spec['route'],spec['node']]=check
        for index in dev+new:
            item={}
            for route in ('ideal','implemented'):
                choose=lambda steps:[layer[steps,index,route,node] for node in range(0,257,16)]
                low,high=choose(32),choose(64)
                scale=maximum([entry['physical'] for entry in high])
                gap=maximum([left['physical']-right['physical'] for left,right in zip(low,high)])
                envelopes=[max(entry['working'] for entry in group) for group in (low,high)]
                combined=(sum(envelopes)+gap)/scale
                item[route]=dict(peak=scale,worst_same_input=max(envelopes)/scale,
                    actual_32_64_spread=gap/scale,paired=combined,same_input_pass=max(envelopes)/scale<=bank.TOL,
                    paired_pass=combined<=bank.TOL,all_consistent=all(entry['consistent'] for entry in [*low,*high]),
                    amplitudes=sorted({entry['secants'][0][0] for entry in [*low,*high]}))
            comparison=maximum([layer[64,index,'ideal',pos]['physical']-layer[64,index,'implemented',pos]['physical'] for pos in range(0,257,16)])
            item['ideal_vs_rounded_inputs_64']=comparison/item['ideal']['peak']
            results[case][str(index)]=item
        for mode in ([kind] if case=='cold' else ['parent','approximate']):
            label=f'{case}_{mode}'
            checks=[row for row in paired if row['branch']==label and row['route']=='autonomous_implemented']
            require({int(row['index']) for row in checks}==set(dev+new),'all physical cells checked')
            for row in checks:
                require((row['fresh']=='True')==(int(row['index']) in new) and (row['both_pass']=='True')==(max(float(row[name]) for name in ('H_budget','old_slip_budget','changed_slip_budget','integral_budget'))<=bank.TOL),'unchanged working decision')
            summaries[label]=dict(passed=sum(row['both_pass']=='True' for row in checks),fresh_passed=sum(row['both_pass']=='True' and row['fresh']=='True' for row in checks),
                largest_H=max(float(row['H_budget']) for row in checks),largest_energy=max(float(row['integral_budget']) for row in checks),
                worst_fresh_energy=max(float(row['integral_budget']) for row in checks if row['fresh']=='True'))
    require(len(report)==24,'two native resolutions')
    bank.save(ROOT/'verification.json',dict(upstream_stage_hashes=len(upstream),frozen_source_hashes=len(frozen),final_cases=summaries,
             secant_geometry_only=results,native_shifted_root_evaluations=1088,heldout_is_numerical_not_observational=True))
    for case,data in results.items():
        print(case,[(index,{k:tuple(round(v[key],10) for key in ('worst_same_input','actual_32_64_spread','paired')) for k,v in item.items() if isinstance(v,dict)},item['ideal_vs_rounded_inputs_64']) for index,item in data.items()])


if __name__=='__main__':
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/'verify-v2-start.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    try:
        main()
    finally:
        bank.save(ROOT/'verify-v2-end.json',dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
