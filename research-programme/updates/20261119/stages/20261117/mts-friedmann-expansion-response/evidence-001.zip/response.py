import argparse
import ctypes
import math
import sys
from decimal import Decimal, localcontext
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST/'mts-elastic-source-interval-quadrature-20261117'
sys.path.insert(0,str(PREVIOUS))
import interval_probe as bank
import interior_forcing as slip
import numpy as np
from scipy.integrate import solve_ivp


def require(value, label):
    if not value:
        raise RuntimeError(label)


def guard():
    bank.guard()
    require(not (ROOT/'STOP-REQUESTED').exists(),'owner hold')


def as_decimal(value):
    return Decimal.from_float(float(value))


def densities(constants, state):
    scale, fields, velocities = state[0], state[1::2], state[2::2]
    square = scale**2
    result = [constants[0]/scale,constants[1]/scale,constants[2]/square,constants[3]/square]
    massive = Decimal(0)
    coefficient = Decimal(5)/(7*as_decimal(math.pi)**2)
    for index in range(int(constants[4])):
        argument = scale*constants[8+index]
        require(0<argument<=Decimal('.3')+Decimal(70)*Decimal('1.01')/1399,'retained thermal domain')
        rho = 1+coefficient*argument**2
        if argument>=Decimal('.01'):
            rho += argument**4*(Decimal('.01099926669')*argument.ln()-Decimal('.003492416767')-Decimal('.005866275571')*argument)
        massive += constants[14+index]*rho/square
    result.append(massive)
    result.extend((velocity**2+(scale*constants[6+index]*field)**2)/2 for index,(field,velocity) in enumerate(zip(fields,velocities)))
    if len(fields)==1:
        result.append(Decimal(0))
    return result


def prediction(constants, original, corrected):
    low,high = densities(constants,original),densities(constants,corrected)
    roots = [(sum(values)/3).sqrt() for values in (low,high)]
    difference = [after-before for before,after in zip(low,high)]
    response = sum(difference)/(3*sum(roots))
    return [float(response),*(float(term/(3*sum(roots))) for term in difference),*(float(value) for value in roots)]


def raw_changed(original,delta):
    return [original[0]*(1+delta[0]),*(first+second for first,second in zip(original[1:],delta[1:]))]


def stable_cases(constants,native,represented,physical,independent,implemented,autonomous):
    with localcontext() as context:
        context.prec = 55
        params = list(map(as_decimal,constants))
        first,second = [list(map(as_decimal,row)) for row in (native,represented)]
        high = raw_changed(second,list(map(as_decimal,physical)))
        auto = raw_changed(second,list(map(as_decimal,independent)))
        rows = [prediction(params,second,high),prediction(params,first,high),
                prediction(params,first,list(map(as_decimal,implemented))),
                prediction(params,first,list(map(as_decimal,autonomous))),prediction(params,first,auto)]
    return rows


def jet_reader(count):
    library = ctypes.CDLL(str(POST/'mts-coupled-metric-consistency-20261117/native/camb/cambdll.dll'))
    status = ctypes.c_int.in_dll(library,'mts_phase_status')
    if status.value!=1:
        require(status.value==0,'phase reader not idle')
        init = library.mts_phase_init
        init.argtypes,init.restype = [],None
        init()
    require(status.value==1 and ctypes.c_int.in_dll(library,'mts_phase_fields').value==count,'native phase initialized')
    dimension = ctypes.c_int.in_dll(library,'mts_phase_dimension').value
    pack = library.mts_phase_pack
    pack.argtypes,pack.restype = [ctypes.c_double,ctypes.c_int,*([ctypes.c_void_p]*3)],None
    def read(time,old):
        vector = np.ascontiguousarray(old)
        packed,jets = np.zeros(dimension),np.zeros((2,6))
        pack(time,dimension,vector.ctypes.data,packed.ctypes.data,jets.ctypes.data)
        require(status.value==1 and np.all(np.isfinite(jets)),'valid native FieldJet')
        return jets[:count]
    return read


def branch_state(direct,system,state,mode):
    if mode=='baseline':
        return direct.unpack(state)
    if mode=='parent':
        return direct.unpack(system.core.unpack(state[:system.core_size])[1])
    return direct.unpack(state[:system.core.native_size])


def gauss_source(direct,system,solution,mode,photon):
    model = direct.model
    integrals = []
    for order in (3,5,7):
        abscissas,weights = np.polynomial.legendre.leggauss(order)
        pieces = []
        for left,right in zip(solution.t[:-1],solution.t[1:]):
            half = (right-left)/2
            times = left+(1+abscissas)*half
            rates = []
            for time,state in zip(times,solution.sol(times).T):
                old,change,physical,_,_ = branch_state(direct,system,state,mode)
                alpha = physical[0]
                # The uncorrected native opacity depends only on time.
                opacity = direct.sample(float(time),old,np.zeros(5),False)[2][2]
                original = old[3]-.75*old[photon]
                delta = change[3]-.75*change[photon]
                factor = (1+alpha)**-2
                rates.append(4/3*opacity*(-alpha*(2+alpha)*factor*original**2+factor*delta*(2*original+delta)))
            pieces.append(half*math.fsum(weights*rates))
        integrals.append(math.fsum(pieces))
    return integrals


def worker(case,steps):
    guard()
    bank.check_seals()
    require(bank.digest(PREVIOUS/'closeout.json')=='5b80cfbb551cef1bdf23bb6962e7534946cdd5a4375e3b755dfd818645a508bb','previous stage seal')
    seal=bank.read(PREVIOUS/'closeout.json')['files']
    for filename in ('interval_probe.py','interior_forcing.py','verification.json'):
        require(bank.digest(PREVIOUS/filename)==seal[filename]['sha256'],'frozen upstream code or results')
    bank.ROOT = ROOT
    with np.load(bank.source_path(case+('_parent' if case=='heavy' else '_baseline'),steps)) as source:
        clock=source['time']
    previous=[96,5264] if case=='heavy' else [892,3112]
    cells=[*previous,(len(clock)-1)//3,2*(len(clock)-1)//3]
    prior_probes=bank.read(PREVIOUS/'selection.json')['selected'][case]
    require(all(all(not left<=index<right for left,right in prior_probes) for index in cells[2:]),'new cells excluded from all development probes')
    pairs=bank.selected_rows(case,steps,set(cells),clock)
    schema=bank.read(POST/'mts-coupled-metric-consistency-20261117/packet-schema.json')
    columns={name:84+idx for idx,name in enumerate(schema['global_columns'])}
    tag=f'{case}-{steps}'
    live,native=bank.native_setup(case,steps,tag)
    with native as (capture,metadata,sample):
        prepared,_,background,_,_=live.EX.problem(case)
        frozen=live.load(Path(live.CONFIG['capture_authority'])/(case+'-preflight-capture.npz'))
        require(all(np.array_equal(value,frozen[name]) for name,value in capture.items()),'unchanged complete bank')
        direct=live.MetricCoupled(case,prepared,background,live.prefix(capture,case),metadata,sample)
        model=direct.model
        jets_at=jet_reader(model.count)
        photon=int(capture['signature'][0,3])
        wave=float(prepared['wave'][0])
        options=dict(method='DOP853',rtol=live.CONFIG['rtol'],atol=live.CONFIG['normalized_atol'],max_step=float(prepared['elapsed'][8])/steps,dense_output=True)
        for index in cells:
            guard()
            states,path=pairs[index]
            system=None
            if case=='heavy':
                system=live.worklib.Carried(direct,live.worklib.LiveSecond(case,prepared,background,live.prefix(capture,case),metadata,sample))
                if bank.BUDGET in path.parents or 'photon-difference-replay-v2' in path.parts:
                    live.operator_repair.install(system)
            left,right=clock[index:index+2]
            solution=solve_ivp(system.rhs if system else direct.rhs,(left,right),states[0].copy(),**options)
            require(solution.success and np.array_equal(solution.y[:,-1],states[1]),'identical full-state right restart')
            times=np.linspace(left,right,257)
            vectors=solution.sol(times).T
            initial=branch_state(direct,system,states[0],'baseline' if case=='cold' else 'parent')[2]/direct.background_units
            def bg_rhs(time,normalized):
                original=model.represented(time)
                physical=normalized*direct.background_units
                flow=model.difference_flow(original,physical,False)
                fd=original['field_first']-original['velocity']
                vd=original['velocity_first']+2*original['hubble']*original['velocity']+original['mass']*original['field']
                return model.pack(flow[0]/original['scale']-original['rate']*physical[0]+original['hubble']-original['rate'],flow[1::2]-fd,flow[2::2]-vd)/direct.background_units
            independent=solve_ivp(bg_rhs,(left,right),initial,**options)
            require(independent.success,'autonomous background')
            auto=independent.sol(times).T*direct.background_units
            modes=('parent','approximate') if case=='heavy' else ('baseline',)
            for mode in modes:
                prefix=f'{tag}-{mode}-{index}'
                rates=[]
                raw=[]
                native_inputs=[]
                for time,state,autodelta in zip(times,vectors,auto):
                    old,_,physical,_,_=branch_state(direct,system,state,mode)
                    original=model.represented(time)
                    original_scale=sample(time,old,np.zeros(5),False)[2][0]
                    jets=jets_at(time,old)
                    require(np.array_equal(jets[:,4],(original_scale*model.constants[6:6+model.count])**2),'native mass convention')
                    direct_base=model.pack(original_scale,jets[:,0],jets[:,1])
                    represented=model.pack(original['scale'],original['field'],original['velocity'])
                    actual=represented+physical
                    actual[0]=represented[0]*(1+physical[0])
                    autonomous=represented+autodelta
                    autonomous[0]=represented[0]*(1+autodelta[0])
                    rates.append(stable_cases(model.constants,direct_base,represented,physical,autodelta,actual,autonomous))
                    raw.append([old[3],model.correction_geometry(original,physical,False)[0]])
                    native_inputs.append([direct_base,represented,physical,autodelta,actual,autonomous])
                predpath=ROOT/(prefix+'-prediction.npz')
                with predpath.open('xb') as stream:
                    np.savez_compressed(stream,time=times,components=rates,primitive=native_inputs,aux=raw,constants=model.constants,
                        routes=['represented','native_ideal','native_implemented','autonomous_implemented','autonomous_ideal'],
                        columns=['delta_H','CDM','baryon','photon','massless_nu','massive_nu','slow','heavy','H0','H1'])
                bank.save(ROOT/(prefix+'-freeze.json'),dict(prediction_sha256=bank.digest(predpath),protocol=bank.digest(ROOT/'METHOD.md'),
                  program=bank.digest(Path(__file__)),cell=index,new_cell=index not in previous,autonomous_steps=len(independent.t)-1,native_steps=len(solution.t)-1))
                readings=[]
                references=[]
                for time,state,packed in zip(times,vectors,native_inputs):
                    old,change,_,_,_=branch_state(direct,system,state,mode)
                    full=np.zeros(5)
                    full[:direct.width]=packed[4]
                    metric0=direct.read_metric(time,old,full,False)
                    metric1=direct.read_metric(time,old+change,full,True)
                    references.append([metric0[columns['hubble']],metric1[columns['hubble']],metric0[columns['friedmann_constraint']],metric1[columns['friedmann_constraint']],*metric0[:84:12],*metric1[:84:12]])
                    readings.append(slip.physical_sample(direct,system,time,state,mode,photon,wave,columns))
                readings=np.array(readings)
                integrals=gauss_source(direct,system,solution,mode,photon)
                if index in previous:
                    oldtag=f'interior-{case}-{steps}-{mode}-{index}'
                    with np.load(PREVIOUS/(oldtag+'.npz')) as retained:
                        require(np.array_equal(readings,retained['values']) and np.array_equal(times,retained['time']),'unchanged prior dense probe')
                    require(integrals[-1]==bank.read(PREVIOUS/(oldtag+'.json'))['direct_gauss7'],'unchanged original integral')
                with (ROOT/(prefix+'-reference.npz')).open('xb') as stream:
                    np.savez_compressed(stream,time=times,metric=references,forces=readings,integrals=integrals)
                print(prefix,'saved',flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('case',choices=('heavy','cold'))
    parser.add_argument('steps',type=int,choices=(32,64))
    args=parser.parse_args()
    tag=f'{args.case}-{args.steps}'
    process=bank.psutil.Process()
    process.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([4])
    bank.save(ROOT/(tag+'-start.json'),dict(pid=process.pid,created=process.create_time(),command=process.cmdline(),affinity=process.cpu_affinity()))
    try:
        worker(args.case,args.steps)
    finally:
        bank.save(ROOT/(tag+'-end.json'),dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
