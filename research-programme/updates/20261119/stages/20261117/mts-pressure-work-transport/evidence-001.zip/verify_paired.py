from paired_work import *
import paired_work as paired
import work_transport as implementation
paired.original=implementation


if __name__=='__main__':
    with worker('verify-paired'):
        inputs()
        check_inputs(read(ROOT/'paired-inputs.json'))
        check_inputs(read(ROOT/'paired-score-recovery-inputs.json'))
        result=score_paired()
        checks={'paired_score_replay':ordinary(result)==read(ROOT/'paired-science-score.json'),'paired_polynomial_replay':controls()==read(ROOT/'paired-polynomial-checks.json'),'endpoints_preserved':all(value['passed'] for value in read(ROOT/'paired-endpoint-checks.json').values()),'initial_failed_score_preserved':not read(ROOT/'science-score.json')['all_identity_checks_pass'],'initial_no_physical_evolution':not read(ROOT/'science-score.json')['physical_state_advanced'],'original_tolerances':CONFIG['numerical_tolerance']==2e-5 and CONFIG['algebra_tolerance']==1e-10}
        for steps in CONFIG['steps']:
            data=load(ROOT/('paired-quadrature-'+str(steps)+'.npz'))
            original_data=load(ROOT/('quadrature-'+str(steps)+'.npz'))
            checks[str(steps)+'_same_clock']=np.array_equal(data['endpoint_time'],original_data['endpoint_time'])
            checks[str(steps)+'_eighteen_trials']=len(data)==19
            checks[str(steps)+'_finite']=all(np.isfinite(value).all() for value in data.values())
            checks[str(steps)+'_zero_start']=all(np.all(value[0]==0) for name,value in data.items() if name!='endpoint_time')
            checks[str(steps)+'_nondecreasing_integral_envelopes']=all(np.all(np.diff(value[:,9:12],axis=0)>=0) for name,value in data.items() if name!='endpoint_time')
            checks[str(steps)+'_shape']=all(value.shape==(4,15) for name,value in data.items() if name!='endpoint_time')
        best=load(ROOT/'paired-quadrature-64.npz')['stride1_order7_nodes4']
        for branch,(name,value) in enumerate(result['branches'].items()):
            checks[name+'_split_defect_added']=value['working_envelope_with_split_defect']['error']>=value['working_envelope']['error']
            expected=ratio(maximum(best[:,branch]+best[:,3+branch]-best[:,6+branch]),maximum(best[:,6+branch]),CONFIG['algebra_tolerance'])
            checks[name+'_raw_zero_test_recomputed']=value['split_identity']==expected
        freeze=(ROOT/'paired-inputs.json').stat().st_mtime
        checks['source_freeze_before_evaluation']=datetime.fromisoformat(read(ROOT/'paired-experiment-start.json')['utc']).timestamp()<=freeze<=min((ROOT/('paired-quadrature-'+str(steps)+'.npz')).stat().st_mtime for steps in CONFIG['steps'])
        checks['namespace_failure_preserved']=read(ROOT/'paired-experiment-failure.json')['error']=="AttributeError(\"'str' object has no attribute 'load'\")" and read(ROOT/'paired-score-recovery-receipt.json')['quadrature_repeated'] is False
        checks['no_bytecode']=not list(ROOT.rglob('__pycache__'))
        saved={'checks':checks,'passed':all(checks.values()),'count':len(checks),'defect_accounted_controls_pass':result['all_defect_accounted_controls_pass'],'work_scale_comparisons_pass':result['all_work_scale_comparisons_pass'],'all_error_predictions_resolved':result['all_error_predictions_resolved']}
        save_result(ROOT/'paired-verification.json',saved)
        require(saved['passed'],'paired technical verification failed: '+str([name for name,value in checks.items() if not value]))
        print(json.dumps({name:value for name,value in saved.items() if name!='checks'}),flush=True)
