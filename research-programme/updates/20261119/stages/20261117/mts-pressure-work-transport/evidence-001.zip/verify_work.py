from work_transport import *


if __name__=='__main__':
    with worker('verify'):
        inputs()
        result=score()
        checks={'science_replay':ordinary(result)==read(ROOT/'science-score.json'),'manufactured_polynomial_replay':polynomial_checks()==read(ROOT/'polynomial-checks.json')}
        for steps in CONFIG['steps']:
            label='jets-'+str(steps)
            jet=load(ROOT/(label+'.npz'))
            data=history('heavy',steps)
            checks[label+'_values_exact']=np.array_equal(jet['values'],data['extended'][:,jet['indices']]*jet['units'])
            checks[label+'_clocks_exact']=np.array_equal(jet['time'],data['time'])
            checks[label+'_all_checks']=all(read(ROOT/(label+'-result.json'))['checks'].values())
            checks[label+'_owner_release']=read(ROOT/(label+'-owner-release.json'))['cleared']
            output=load(ROOT/('quadrature-'+str(steps)+'.npz'))
            checks[label+'_quadrature_finite']=all(np.isfinite(value).all() for value in output.values())
            checks[label+'_same_jet_hash']=read(ROOT/('quadrature-'+str(steps)+'-result.json'))['jets_hash']==digest(ROOT/(label+'.npz'))
            checks[label+'_quadrature_initial_zero']=all(np.all(value[0]==0) for name,value in output.items() if name!='endpoint_time')
            for suffix in ('jets','quadrature'):
                start=read(ROOT/(suffix+'-'+str(steps)+'-start.json'))
                checks[label+'_'+suffix+'_frozen_first']=datetime.fromisoformat(start['utc']).timestamp()>=(ROOT/'inputs.json').stat().st_mtime
        checks['original_failed_slip_retained']=not read(PRIOR/'cumulative-score-physical.json')['approximation_vs_parent']['velocity_slip_response']['passed']
        checks['baseline_tiny_signal_unresolved_retained']=not read(PRIOR/'slip-check.json')['results']['cold_baseline']['precision']['passed']
        checks['no_bytecode']=not list(ROOT.rglob('__pycache__'))
        for path in ROOT.glob('*.py'):
            compile(path.read_text(encoding='utf-8'),str(path),'exec')
        saved={'checks':checks,'passed':all(checks.values()),'count':len(checks),'all_science_identities_pass':result['all_identity_checks_pass'],'all_work_scale_comparisons_pass':result['all_work_scale_comparisons_pass']}
        save_result(ROOT/'verification.json',saved)
        require(saved['passed'],'technical checks failed: '+str([name for name,value in checks.items() if not value]))
        inputs()
        print(json.dumps({name:value for name,value in saved.items() if name!='checks'}),flush=True)
