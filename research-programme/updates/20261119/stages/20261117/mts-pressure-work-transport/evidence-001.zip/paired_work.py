import math
import work_transport as original
from work_transport import *


def weights_at(nodes,clock):
    width=nodes[-1]-nodes[0]
    positions=(nodes-nodes[0])/width
    current=(clock-nodes[0])/width
    value_weights,derivative_weights=[],[]
    for index,position in enumerate(positions):
        others=np.delete(positions,index)
        square=np.prod((current-others)/(position-others))**2
        slope=np.sum(1/(position-others))
        value_weights.append((1-2*(current-position)*slope)*square)
        derivative_weights.append((current-position)*square*width)
    return np.array(value_weights),np.array(derivative_weights)


def centered_background(nodes,values,derivatives,reference,reference_derivative,local,clock):
    value_weights,derivative_weights=weights_at(nodes,clock)
    change=values[:,:5].copy()
    change_derivative=derivatives[:,:5].copy()
    change[:,0]=reference[:,0]*values[:,0]
    change_derivative[:,0]=reference[:,0]*derivatives[:,0]+reference_derivative[:,0]*values[:,0]
    output=np.array([math.fsum([*(value_weights*(reference[:,component]-local[component]+change[:,component])),*(derivative_weights*(reference_derivative[:,component]+change_derivative[:,component]))]) for component in range(5)])
    output[0]/=local[0]
    return output


def represented_vector(model,clock):
    base=model.represented(float(clock))
    return model.pack(base['scale'],base['field'],base['velocity']),model.pack(base['scale']*base['rate'],base['field_first'],base['velocity_first'])


def controls():
    checks={}
    for count in (3,4):
        nodes=np.array([-.7,.1,.6,1.3])[:count]
        reference=np.stack([3+np.sin(nodes+component/5) for component in range(5)],axis=1)
        derivative=np.stack([np.cos(nodes+component/5) for component in range(5)],axis=1)
        for degree in range(2*count):
            physical=np.stack([4+(component+1)*nodes**degree/10 for component in range(5)],axis=1)
            physical_prime=np.stack([(component+1)*degree*nodes**(degree-1)/10 if degree else np.zeros(count) for component in range(5)],axis=1)
            delta=physical-reference
            delta_prime=physical_prime-derivative
            alpha=delta[:,0]/reference[:,0]
            delta_prime[:,0]=(delta_prime[:,0]-derivative[:,0]*alpha)/reference[:,0]
            delta[:,0]=alpha
            errors=[]
            for clock in np.linspace(nodes[0],nodes[-1],11):
                local=np.array([3+np.sin(clock+component/5) for component in range(5)])
                expected=np.array([4+(component+1)*clock**degree/10 for component in range(5)])-local
                expected[0]/=local[0]
                actual=centered_background(nodes,delta,delta_prime,reference,derivative,local,float(clock))
                errors.append(maximum(actual-expected))
            checks[str(count)+'_'+str(degree)]=max(errors)<=CONFIG['algebra_tolerance']
    return checks


def quadrature_paired(steps):
    jet=load(ROOT/('jets-'+str(steps)+'.npz'))
    prepared,_,background,_,_=EX.problem('heavy')
    model=retained_run.BG.Model(background,float(prepared['times'][0]))
    clocks,values,derivatives=jet['time'],jet['values'],jet['derivatives']
    anchors=jet['endpoint_indices']
    reference,reference_derivative=map(np.array,zip(*(represented_vector(model,clock) for clock in clocks)))
    endpoint_error=0.
    results={}
    for count in (3,4):
        for stride in CONFIG['integration_strides']:
            for order in CONFIG['integration_orders']:
                nodes,weights=np.polynomial.legendre.leggauss(order)
                cumulative=np.zeros(15)
                endings=[cumulative.copy()]
                for first,last in zip(anchors[:-1],anchors[1:]):
                    knots=np.unique(np.r_[np.arange(first,last,stride),last])
                    for position in range(len(knots)-1):
                        guard()
                        start=max(0,min(position-1,len(knots)-count))
                        selected=knots[start:start+count]
                        left,right=clocks[knots[position]],clocks[knots[position+1]]
                        half=(right-left)/2
                        if order==3 and stride==1:
                            recovered=centered_background(clocks[selected],values[selected],derivatives[selected],reference[selected],reference_derivative[selected],reference[knots[position]],float(left))
                            endpoint_error=max(endpoint_error,maximum(recovered-values[knots[position],:5]))
                        for node,weight in zip(nodes,weights):
                            clock=float((right+left)/2+half*node)
                            vector=interpolate(clocks[selected],values[selected],derivatives[selected],clock)
                            local,_=represented_vector(model,clock)
                            vector[:5]=centered_background(clocks[selected],values[selected],derivatives[selected],reference[selected],reference_derivative[selected],local,clock)
                            rate,_=pressure_rates(model,prepared,clock,vector)
                            defect=vector.copy()
                            defect[5:13]=0
                            defect[13:17]=[math.fsum((vector[13+component],-vector[5+component],-vector[9+component])) for component in range(4)]
                            defect_rate=pressure_rates(model,prepared,clock,defect)[0][6:9]
                            cumulative+=half*weight*np.r_[rate,defect_rate]
                    endings.append(cumulative.copy())
                label='stride'+str(stride)+'_order'+str(order)+'_nodes'+str(count)
                results[label]=np.array(endings)
                print(json.dumps({'paired_steps':steps,'trial':label}),flush=True)
    np.savez_compressed(ROOT/('paired-quadrature-'+str(steps)+'.npz'),endpoint_time=clocks[anchors],**results)
    return {'endpoint_error':endpoint_error,'endpoint_maximum_scale':maximum(values[:,:5]),'passed':endpoint_error<=CONFIG['algebra_tolerance']*maximum(values[:,:5]),'trials':len(results)}


def score_paired():
    supplied={}
    for steps in CONFIG['steps']:
        data=load(ROOT/('paired-quadrature-'+str(steps)+'.npz'))
        supplied['quadrature-'+str(steps)+'.npz']={'endpoint_time':data['endpoint_time'],**{name.replace('_nodes4','_nodes3'):value[:,:12] for name,value in data.items() if name.endswith('_nodes4')}}
        supplied['quadrature-'+str(steps)+'.npz']['stride1_order7_nodes2']=load(ROOT/('quadrature-'+str(steps)+'.npz'))['stride1_order7_nodes2']
    old_load=original.load
    try:
        original.load=lambda path:supplied[Path(path).name] if Path(path).name in supplied else old_load(path)
        result=original.score()
    finally:
        original.load=old_load
    fine=load(ROOT/'paired-quadrature-64.npz')
    best=fine['stride1_order7_nodes4']
    degree5=fine['stride1_order7_nodes3']
    defect_checks={}
    for branch,name in enumerate(('old','coherent','coherent_minus_original')):
        raw=best[:,6+branch]-best[:,branch]-best[:,3+branch]
        defect=best[:,12+branch]
        primitive=maximum(abs(best[:,6+branch])+abs(best[:,branch])+abs(best[:,3+branch]))
        accounted=ratio(maximum(raw-defect),maximum(best[:,6+branch]),CONFIG['algebra_tolerance'])
        extra=maximum(defect)
        detail=result['branches'][name]
        detail['independent_split_defect_final']=float(defect[-1])
        detail['defect_accounted_split']=accounted
        detail['degree5_degree7_difference']=maximum((best[:,branch]+best[:,3+branch])-(degree5[:,branch]+degree5[:,3+branch]))
        detail['working_envelope_with_split_defect']=ratio(detail['working_envelope']['error']+extra,detail['working_envelope']['scale'])
        detail['split_primitive_rounding']=64*np.finfo(float).eps*primitive
        defect_checks[name]=accounted['passed']
    result['scheme']='four-node physical-background Hermite minus exact retained reference; immutable old score formulas'
    result['raw_zero_split_failures_preserved']=True
    result['defect_accounted_split_pass']=all(defect_checks.values())
    result['all_defect_accounted_controls_pass']=result['defect_accounted_split_pass'] and all(value for name,value in result['checks'].items() if not name.endswith('_transport_split'))
    result['initial_results_unchanged']=digest(ROOT/'science-score.json')==read(ROOT/'paired-inputs.json')[str(ROOT/'science-score.json')]
    return result


if __name__=='__main__':
    with worker('paired-experiment'):
        inputs()
        mapping={str(path):digest(path) for path in (ROOT/'paired_work.py',ROOT/'PAIRED-BACKGROUND.md',ROOT/'science-score.json',ROOT/'jets-32.npz',ROOT/'jets-64.npz',ROOT/'quadrature-32.npz',ROOT/'quadrature-64.npz')}
        write(ROOT/'paired-inputs.json',mapping)
        test=controls()
        require(all(test.values()),'manufactured paired-background controls')
        save_result(ROOT/'paired-polynomial-checks.json',test)
        endpoints={str(steps):quadrature_paired(steps) for steps in CONFIG['steps']}
        save_result(ROOT/'paired-endpoint-checks.json',endpoints)
        require(all(value['passed'] for value in endpoints.values()),'same saved endpoints')
        result=score_paired()
        save_result(ROOT/'paired-science-score.json',result)
        check_inputs(mapping)
        inputs()
        print(json.dumps({name:value for name,value in result.items() if name.startswith('all_') or name=='defect_accounted_split_pass'}),flush=True)
