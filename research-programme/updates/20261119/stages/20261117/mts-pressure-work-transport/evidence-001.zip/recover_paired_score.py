import paired_work as paired
import work_transport as implementation
from restart_support import *


if __name__=='__main__':
    with worker('paired-score-recovery'):
        failure=read(ROOT/'paired-experiment-failure.json')
        require(failure['error']=="AttributeError(\"'str' object has no attribute 'load'\")",'inspected namespace-only scoring failure')
        require(exited(failure)['exited'],'original paired worker exited')
        check_inputs(read(ROOT/'paired-inputs.json'))
        require(all(value['passed'] for value in read(ROOT/'paired-endpoint-checks.json').values()),'both completed cached integrations passed endpoint recovery')
        mapping={str(path):digest(path) for path in (ROOT/'recover_paired_score.py',ROOT/'paired-quadrature-32.npz',ROOT/'paired-quadrature-64.npz')}
        write(ROOT/'paired-score-recovery-inputs.json',mapping)
        require(isinstance(paired.original,str),'wildcard-import alias collision confirmed')
        paired.original=implementation
        result=paired.score_paired()
        implementation.save_result(ROOT/'paired-science-score.json',result)
        write(ROOT/'paired-score-recovery-receipt.json',{'failure_retained':True,'worker_identity':failure,'cause':'A wildcard import overwrote the module alias original with the retained context replacement string. Rebind the module explicitly for scoring only.','numerical_formulas_changed':False,'quadrature_repeated':False,'physical_evolution_started':False})
        check_inputs(mapping)
        implementation.inputs()
        print(json.dumps({name:value for name,value in result.items() if name.startswith('all_') or name=='defect_accounted_split_pass'}),flush=True)
