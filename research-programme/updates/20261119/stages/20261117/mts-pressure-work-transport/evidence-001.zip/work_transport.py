from restart_bridge import *
import argparse
from decimal import Decimal, localcontext

PRIOR = Path(CONFIG['prior_directory'])
CARRY = Path(CONFIG['carry_directory'])
sys.path.insert(0,str(CARRY))
from carry import Carried, LiveSecond
from live_phase import Pair
sys.path.insert(0,str(PRIOR))
from score_two import concatenate
from score_phase import conservative


def ordinary(value):
    if isinstance(value,dict):
        return {name:ordinary(item) for name,item in value.items()}
    if isinstance(value,(list,tuple)):
        return [ordinary(item) for item in value]
    if isinstance(value,np.generic):
        return value.item()
    return value


def save_result(path,value):
    write(path,ordinary(value))


def history(case,steps):
    directories = [CARRY,PRIOR/'epoch3043',PRIOR/'epoch3044']
    parts = [load(directory/(case+'-'+str(steps)+'.npz')) for directory in directories]
    return concatenate(parts)


def endpoint_indices(data):
    return data['native_indices'].astype(int)


def interpolate(nodes,values,derivatives,clock):
    width = nodes[-1]-nodes[0]
    positions = (nodes-nodes[0])/width
    current = (clock-nodes[0])/width
    result = np.zeros(values.shape[1:])
    for index,position in enumerate(positions):
        others = np.delete(positions,index)
        lagrange = np.prod((current-others)/(position-others))
        slope = np.sum(1/(position-others))
        square = lagrange**2
        result += (1-2*(current-position)*slope)*square*values[index]+(current-position)*square*width*derivatives[index]
    return result


def polynomial_checks():
    checks = {}
    for count in (2,3):
        nodes = np.array([-.7,.2,1.4])[:count]
        for degree in range(2*count):
            values = (nodes**degree)[:,None]
            derivatives = (degree*nodes**(degree-1) if degree else np.zeros(count))[:,None]
            error = max(abs(float(interpolate(nodes,values,derivatives,float(clock))[0])-clock**degree) for clock in np.linspace(nodes[0],nodes[-1],17))
            checks[str(count)+'_'+str(degree)] = error<=CONFIG['algebra_tolerance']
    return checks


def make_system(captured,metadata,sample):
    known = load(PRIOR/'heavy-preflight-capture.npz')
    require(all(np.array_equal(value,known[name]) for name,value in captured.items()),'known1054 capture exact')
    prepared,_,background,_,_ = EX.problem('heavy')
    direct = MetricCoupled('heavy',prepared,background,prefix(captured,'heavy'),metadata,sample)
    reduced = LiveSecond('heavy',prepared,background,prefix(captured,'heavy'),metadata,sample)
    return direct,Carried(direct,reduced)


def pressure_rates(model,prepared,clock,vector):
    base = model.represented(clock)
    alpha,fields,velocities = model.unpack(vector[:5])
    hubble_delta,_ = model.correction_geometry(base,vector[:5],False)
    hubble = Pair(base['hubble'],hubble_delta)
    scale = Pair(base['scale'],base['scale']*alpha)
    phi,velocity = Pair(base['field'][1],fields[1]),Pair(base['velocity'][1],velocities[1])
    mass2 = (scale*model.constants[7])**2
    beta = scale/float(prepared['density0'])
    pressures = []
    for start in (5,9,13):
        displacement = Pair(vector[start],vector[start+2])
        speed = Pair(vector[start+1],vector[start+3])
        pressures.append(beta*(velocity*speed-mass2*phi*displacement))
    rates = []
    for pressure in pressures:
        rate = -3*hubble*pressure
        rates.extend((rate.base,rate.base+rate.change,rate.change))
    inherited,generated = pressures[:2]
    bounds = [3*abs(hubble.base)*(abs(inherited.base)+abs(generated.base)),3*abs(hubble.base+hubble.change)*(abs(inherited.base+inherited.change)+abs(generated.base+generated.change)),3*(abs(hubble.base)*(abs(inherited.change)+abs(generated.change))+abs(hubble.change)*(abs(inherited.base+inherited.change)+abs(generated.base+generated.change)))]
    return np.r_[rates,bounds], np.array([[value.base,value.change] for value in pressures])


def prepare():
    require(digest(PRIOR/'closeout.json')==CONFIG['prior_seal'],'verified preceding seal')
    require(read(PRIOR/'verification.json')['passed'] and read(PRIOR/'cumulative-score.json')['continuation_gate_pass'],'preceding completed physical gates')
    mapping = read(PRIOR/'inputs.json')
    mapping[str(PRIOR/'closeout.json')] = CONFIG['prior_seal']
    mapping.update({str(PRIOR/name):value['sha256'] for name,value in read(PRIOR/'closeout.json')['artifacts'].items()})
    check_inputs(mapping)
    save_result(ROOT/'frozen-norms.json',read(PRIOR/'frozen-norms.json'))
    checks = polynomial_checks()
    require(all(checks.values()),'Hermite manufactured controls')
    save_result(ROOT/'polynomial-checks.json',checks)
    for path in ROOT.iterdir():
        if path.is_file() and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix=='.py':
                compile(path.read_text(encoding='utf-8'),str(path),'exec')
            mapping[str(path)] = digest(path)
    write(ROOT/'inputs.json',mapping)
    print(json.dumps({'frozen_inputs':len(mapping),'polynomial_checks':len(checks)}),flush=True)


def jets(steps):
    inputs()
    data = history('heavy',steps)
    label = 'jets-'+str(steps)
    with native_context('heavy',label) as (captured,metadata,sample):
        direct,system = make_system(captured,metadata,sample)
        active,selected = direct.active,system.reduced.selected
        indices = list(range(2*active,2*active+direct.width))
        units = list(direct.background_units)
        for start in (system.core_size,system.core_size+2*active,system.core_size-2*active):
            indices.extend(start+np.r_[selected,active+selected])
            units.extend(np.r_[system.core.error_units[selected],system.core.error_change_units[selected]])
        indices,units = np.array(indices,dtype=int),np.array(units)
        require(len(indices)==17 and direct.width==5,'derived physical jet layout')
        values = data['extended'][:,indices]*units
        derivatives = np.empty_like(values)
        rates = np.empty((len(values),12))
        pressure_error = np.zeros((3,2))
        pressure_scale = np.zeros((3,2))
        for index,clock in enumerate(data['time']):
            guard()
            actual = system.rhs(float(clock),data['extended'][index])
            derivatives[index] = actual[indices]*units
            rates[index],pressure = pressure_rates(direct.model,direct.prepared,float(clock),values[index])
            expected = np.stack([data[name+'_source'][index,:,2] for name in ('carry','fresh','error')])
            pressure_error = np.maximum(pressure_error,abs(pressure-expected))
            pressure_scale = np.maximum(pressure_scale,abs(expected))
            if index%256==0:
                print(json.dumps({'label':label,'node':index,'total':len(values)}),flush=True)
        final = load(PRIOR/'epoch3044'/('heavy-'+str(steps)+'-terminal.npz'))
        require(np.array_equal(data['extended'][-1],final['normalized']),'complete final state exact')
        require(np.array_equal(actual,final['actual_rhs']),'complete final actual RHS exact')
        restore(direct,PRIOR/'epoch3044'/('heavy-'+str(steps)+'-parent-terminal.npz'))
        checks = {'final_actual_rhs_exact':True,'all_pressure_reconstructions':bool(np.all(pressure_error<=CONFIG['algebra_tolerance']*pressure_scale)),'finite_jets':bool(np.isfinite(derivatives).all() and np.isfinite(values).all()),'positive_time':bool(np.all(np.diff(data['time'])>0))}
        require(all(checks.values()),'jet reconstruction: '+str(checks))
        np.savez_compressed(ROOT/(label+'.npz'),time=data['time'],values=values,derivatives=derivatives,endpoint_indices=endpoint_indices(data),rates=rates,indices=indices,units=units)
        save_result(ROOT/(label+'-result.json'),{'checks':checks,'pressure_error':pressure_error.tolist(),'pressure_scale':pressure_scale.tolist(),'nodes':len(values),'no_physical_evolution':True})
    inputs()


def quadrature(steps):
    inputs()
    prepared,_,background,_,_ = EX.problem('heavy')
    model = retained_run.BG.Model(background,float(prepared['times'][0]))
    jet = load(ROOT/('jets-'+str(steps)+'.npz'))
    clocks,values,derivatives = jet['time'],jet['values'],jet['derivatives']
    anchors = jet['endpoint_indices']
    results = {}
    choices = [(stride,order,3) for stride in CONFIG['integration_strides'] for order in CONFIG['integration_orders']]+[(1,7,2)]
    for stride,order,count in choices:
        nodes,weights = np.polynomial.legendre.leggauss(order)
        cumulative = np.zeros(12)
        endings = [cumulative.copy()]
        for first,last in zip(anchors[:-1],anchors[1:]):
            knots = np.unique(np.r_[np.arange(first,last,stride),last])
            for position in range(len(knots)-1):
                guard()
                selected = knots[position:position+2] if count==2 else knots[max(0,min(position-1,len(knots)-3)):max(0,min(position-1,len(knots)-3))+3]
                left,right = clocks[knots[position]],clocks[knots[position+1]]
                half = (right-left)/2
                for node,weight in zip(nodes,weights):
                    clock = (right+left)/2+half*node
                    state = interpolate(clocks[selected],values[selected],derivatives[selected],float(clock))
                    rate,_ = pressure_rates(model,prepared,float(clock),state)
                    cumulative += half*weight*rate
            endings.append(cumulative.copy())
        name = 'stride'+str(stride)+'_order'+str(order)+'_nodes'+str(count)
        results[name] = np.array(endings)
        print(json.dumps({'steps':steps,'quadrature':name,'complete':True}),flush=True)
    np.savez_compressed(ROOT/('quadrature-'+str(steps)+'.npz'),endpoint_time=clocks[anchors],**results)
    save_result(ROOT/('quadrature-'+str(steps)+'-result.json'),{'no_physical_evolution':True,'trials':len(choices),'original_anchors':anchors.tolist(),'jets_hash':digest(ROOT/('jets-'+str(steps)+'.npz'))})
    inputs()


def score():
    inputs()
    fine,coarse = load(ROOT/'quadrature-64.npz'),load(ROOT/'quadrature-32.npz')
    target,target_low = history('heavy',64),history('heavy',32)
    anchors = endpoint_indices(target)
    choose = lambda data,stride,order:data['stride'+str(stride)+'_order'+str(order)+'_nodes3']
    best,low = choose(fine,1,7),choose(coarse,1,7)
    interpolation = np.max(abs(best-choose(fine,2,7)),axis=0)
    old_interpolation = np.max(abs(choose(fine,2,7)-choose(fine,4,7)),axis=0)
    quadrature_error = np.max(abs(best-choose(fine,1,5)),axis=0)
    old_quadrature = np.max(abs(choose(fine,1,5)-choose(fine,1,3)),axis=0)
    step = np.max(abs(best-low),axis=0)
    numerical = interpolation+quadrature_error+step+64*np.finfo(float).eps*np.max(abs(best),axis=0)
    checks = {'hermite_controls':all(read(ROOT/'polynomial-checks.json').values()),'same_quadrature_endpoints':np.array_equal(fine['endpoint_time'],coarse['endpoint_time'])}
    branches = {}
    for branch,name in enumerate(('old','coherent','coherent_minus_original')):
        def work(data,prefix):
            ordinary_work = data[prefix+'work'][:,0]
            change = data[prefix+'work_change'][:,0]
            chosen = ordinary_work if branch==0 else ordinary_work+change if branch==1 else change
            return chosen,chosen-chosen[0]
        approximate,increment = work(target,'')
        parent,parent_increment = work(target,'parent_')
        _,increment_low = work(target_low,'')
        _,parent_increment_low = work(target_low,'parent_')
        observed = increment-parent_increment
        observed_low = increment_low-parent_increment_low
        predicted = best[:,branch]+best[:,3+branch]
        independent = best[:,6+branch]
        physical_step = maximum(increment-increment_low)+maximum(parent_increment-parent_increment_low)
        physical_rounding = 64*np.finfo(float).eps*maximum(abs(approximate)+abs(approximate[0])+abs(parent)+abs(parent[0]))
        reconstruction = maximum(predicted-observed[anchors])
        uncertainty = numerical[branch]+numerical[3+branch]
        triangle = best[:,9+branch]+numerical[9+branch]+physical_step+physical_rounding
        split = ratio(maximum(predicted-independent),maximum(independent),CONFIG['algebra_tolerance'])
        checks[name+'_transport_split'] = split['passed']
        checks[name+'_triangle_covers_signed'] = bool(np.all(abs(predicted)<=best[:,9+branch]+numerical[9+branch]+uncertainty))
        checks[name+'_triangle_covers_direct'] = bool(np.all(abs(observed[anchors])<=triangle))
        scale = maximum(parent_increment)
        branches[name] = {'predicted_final':float(predicted[-1]),'observed_final':float(observed[-1]),'inherited_final':float(best[-1,branch]),'generated_final':float(best[-1,3+branch]),'envelope_final':float(best[-1,9+branch]),'working_envelope':ratio(maximum(triangle),scale),'signed_prediction_resolution':ratio(float(uncertainty),maximum(predicted)),'envelope_resolution':ratio(float(numerical[9+branch]),maximum(best[:,9+branch])),'direct_comparison':ratio(reconstruction+float(uncertainty)+physical_step+physical_rounding,scale),'error_relative_direct_comparison':ratio(reconstruction+float(uncertainty)+physical_step+physical_rounding,maximum(predicted)),'split_identity':split,'direct_work_refinement':physical_step,'direct_work_rounding':physical_rounding,'interpolation_new':float(interpolation[branch]+interpolation[3+branch]),'interpolation_previous':float(old_interpolation[branch]+old_interpolation[3+branch]),'quadrature_new':float(quadrature_error[branch]+quadrature_error[3+branch]),'quadrature_previous':float(old_quadrature[branch]+old_quadrature[3+branch]),'step_contribution':float(step[branch]+step[3+branch]),'cubic_control_difference':maximum(predicted-(fine['stride1_order7_nodes2'][:,branch]+fine['stride1_order7_nodes2'][:,3+branch]))}
    for steps in CONFIG['steps']:
        baseline = history('cold',steps)
        checks['baseline_'+str(steps)+'_owned_pressure_zero'] = bool(np.all(baseline['source'][:,2]==0) and np.all(baseline['source_change'][:,2]==0))
        checks['baseline_'+str(steps)+'_owned_work_zero'] = bool(np.all(baseline['work'][:,0]==0) and np.all(baseline['work_change'][:,0]==0))
    result = {'scope':'derived finite-history pressure-work transport; diagnostic interpolation, not a new physical run or certified continuum bound','branches':branches,'checks':checks,'all_identity_checks_pass':all(checks.values()),'all_work_scale_comparisons_pass':all(value['direct_comparison']['passed'] and value['working_envelope']['passed'] for value in branches.values()),'all_error_predictions_resolved':all(value['signed_prediction_resolution']['passed'] for value in branches.values()),'all_envelopes_resolved':all(value['envelope_resolution']['passed'] for value in branches.values()),'all_tiny_direct_errors_resolved':all(value['error_relative_direct_comparison']['passed'] for value in branches.values()),'baseline_pressure_zero_is_structural':True,'new_fitted_parameters':0,'physical_state_advanced':False,'certified_continuum_bound':False}
    return result


if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command',choices=('prepare','jets','quadrature','score'))
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=64)
    arguments = parser.parse_args()
    label = arguments.command+('-'+str(arguments.steps) if arguments.command in ('jets','quadrature') else '')
    with worker(label):
        if arguments.command=='prepare':prepare()
        elif arguments.command=='jets':jets(arguments.steps)
        elif arguments.command=='quadrature':quadrature(arguments.steps)
        else:
            result=score()
            save_result(ROOT/'science-score.json',result)
            print(json.dumps({name:value for name,value in result.items() if name.startswith('all_')}),flush=True)
