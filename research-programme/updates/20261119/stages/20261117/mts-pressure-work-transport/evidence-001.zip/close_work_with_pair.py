from restart_support import *
import importlib.metadata


if __name__=='__main__':
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed=process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    check_inputs(read(ROOT/'inputs.json'))
    verification=read(ROOT/'verification.json')
    require(verification['passed'],'verified diagnostic stage')
    paired=read(ROOT/'paired-verification.json')
    require(paired['passed'],'verified physical-background diagnostic')
    expected={'prepare','jets-32','jets-64','quadrature-32','quadrature-64','score','verify','paired-experiment','verify-paired','paired-score-recovery'}
    workers={path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    require(set(workers)=={label+'-start.json' for label in expected},'exact worker ownership')
    require(all(value['exited'] for value in workers.values()),'all worker identities exited')
    for label in expected:
        if label=='paired-experiment':
            start,failure=read(ROOT/(label+'-start.json')),read(ROOT/(label+'-failure.json'))
            require(all(start[name]==failure[name] for name in ('pid','created','command')) and failure['error']=="AttributeError(\"'str' object has no attribute 'load'\")",'preserved namespace-only score failure')
            require(read(ROOT/'paired-score-recovery-receipt.json')['quadrature_repeated'] is False,'cached scoring recovery only')
            continue
        start,end=read(ROOT/(label+'-start.json')),read(ROOT/(label+'-end.json'))
        require(end['completed'] and all(start[name]==end[name] for name in ('pid','created','command')),'matching completion identity')
    owners={path.name:read(path) for path in ROOT.glob('*-owner-release.json')}
    require(len(owners)==2 and all(value['cleared'] for value in owners.values()),'two native owners released')
    require({path.name for path in ROOT.glob('*-failure.json')}=={'paired-experiment-failure.json'},'no unaccounted failure')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    require(all((ROOT/name).is_file() for name in ('DERIVATION.md','RESULTS.md','NEXT.md')),'scientific handoff complete')
    closer=identity(process)
    write(ROOT/'cleanup.json',{'workers':workers,'native_owners':owners,'closer_identity':closer,'closer_exit_check_required':True,'other_processes_changed':False,'temporary_tools':[],'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','psutil')}})
    artifacts={str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    result={'stage':'Accumulated pressure-work transport from saved coupled fields','utc':datetime.now(timezone.utc).isoformat(),'artifacts':artifacts,'workers_exited':len(workers),'native_owners_released':len(owners),'technical_checks':verification['count']+paired['count'],'verification_passed':True,'physical_state_advanced':False,'last_physical_epoch':3044,'new_fitted_parameters':0,'certified_continuum_bound':False,'github':False}
    result['paired_diagnostic_controls_pass']=paired['defect_accounted_controls_pass']
    result['initial_failed_diagnostics_preserved']=True
    result['accounted_nonphysical_failure']='Paired integrations complete; module alias overwritten by wildcard import at score stage. Preserved original source/receipt and recovered cached scoring only.'
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),'bytes':sum(value['bytes'] for value in artifacts.values()),'workers_exited':len(workers),'closer':closer}),flush=True)
