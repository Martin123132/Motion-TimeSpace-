from defect_budget import *
from fractions import Fraction


def manufactured():
    checks={}
    for index,offset in enumerate((Fraction(1,7),Fraction(-2,13),Fraction(5,11))):
        matrix=((Fraction(2,3),offset),(Fraction(-1,5),Fraction(4,9)))
        inherited=(Fraction(3,7),Fraction(-5,8))
        generated=(Fraction(1,3),Fraction(7,10))
        defect=(offset,Fraction(3,17))
        total=tuple(inherited[position]+generated[position]+defect[position] for position in range(2))
        residual=(Fraction(2,19),Fraction(-1,23))
        def multiply(vector):
            return tuple(sum(matrix[row][column]*vector[column] for column in range(2)) for row in range(2))
        total_rhs=tuple(value-residual[position] for position,value in enumerate(multiply(total)))
        generated_rhs=tuple(value-residual[position] for position,value in enumerate(multiply(generated)))
        inherited_rhs=multiply(inherited)
        checks[str(index)+"_transport"]=tuple(total_rhs[position]-inherited_rhs[position]-generated_rhs[position] for position in range(2))==multiply(defect)
        projection=(Fraction(7,4),Fraction(2,5))
        def applied(vector):
            return sum(projection[position]*vector[position] for position in range(2))
        checks[str(index)+"_projection"]=applied(total)==applied(inherited)+applied(generated)+applied(defect)
        checks[str(index)+"_nonzero_error_not_removed"]=applied(defect)!=0
        checks[str(index)+"_work"]=-3*offset*applied(total)==sum(-3*offset*applied(vector) for vector in (inherited,generated,defect))
    return checks


def verify():
    inputs()
    epochs=[epoch for epoch in CONFIG["checkpoint_epochs"] if (ROOT/("epoch"+str(epoch)+"-gate.json")).exists()]
    require(epochs==CONFIG["checkpoint_epochs"][:len(epochs)],"contiguous completed batches")
    checks=manufactured()
    checks["old4249_raw_failure_preserved"]=not read(TAIL/"epoch4249-gate.json")["passed"] and not read(CANDIDATE/"epoch4249-gate.json")["passed"]
    for key in ("algebra_tolerance","numerical_tolerance","rtol","normalized_atol","error_fraction","retained_comoving_wave","amplifications","signs"):
        checks[key+"_unchanged"]=CONFIG[key]==read(TAIL/"protocol.json")[key]
    checks["frozen_norms_unchanged"]=read(ROOT/"frozen-norms.json")==read(TAIL/"frozen-norms.json")
    for epoch in [4249]+epochs:
        label="bridge" if epoch==4249 else "epoch"+str(epoch)
        results=scored(epoch)
        for name,result in zip(("raw-physics","work","slip","gate"),results):
            checks[label+"_"+name+"_exact_replay"]=worklib.ordinary(result)==read(ROOT/(label+"-"+name+".json"))
        checks[label+"_new_criterion_pass"]=results[-1]["passed"]
        if epoch==4249:continue
        for case in CONFIG["cases"]:
            checks[case+"_preflight"]=read(ROOT/(case+"-preflight-result.json"))["passed"]
            for steps in CONFIG["steps"]:
                short=case+"-"+str(steps)
                worker_name=case+"-"+str(epoch)+"-"+str(steps)
                data=load(folder(epoch)/(short+".npz"))
                begin=load(inherited(epoch)/(short+"-terminal.npz"))
                end=load(folder(epoch)/(short+"-terminal.npz"))
                work=load(folder(epoch)/(short+"-work-history.npz"))
                work_begin=initial_diagnostics(case,steps,epoch)
                work_end=load(folder(epoch)/(short+"-work-terminal.npz"))
                clocks=load(folder(epoch)/(case+"-clock.npz"))
                checks[worker_name+"_physical_start_exact"]=np.array_equal(data["extended"][0],begin["normalized"])
                checks[worker_name+"_physical_end_exact"]=np.array_equal(data["extended"][-1],end["normalized"])
                checks[worker_name+"_original_clocks"]=np.array_equal(data["time"][data["native_indices"]],clocks["native_time"])
                checks[worker_name+"_finite"]=all(np.isfinite(value).all() for value in data.values()) and all(np.isfinite(value).all() for value in work.values())
                checks[worker_name+"_work_start_exact"]=all(np.array_equal(work[name][0],value) for name,value in work_begin.items())
                checks[worker_name+"_work_end_exact"]=all(np.array_equal(work[name][-1],value) for name,value in work_end.items())
                for name in ("inherited_allowance","quadrature_75","quadrature_53","rounding","accepted_steps"):
                    checks[worker_name+"_"+name+"_monotone"]=bool(np.all(np.diff(work[name],axis=0)>=0))
                earlier=ROOT/("bridge-gate.json" if epoch==CONFIG["checkpoint_epochs"][0] else "epoch"+str(prior_epoch(epoch))+"-gate.json")
                checks[worker_name+"_gate_before_launch"]=read(earlier)["passed"] and datetime.fromisoformat(read(ROOT/(worker_name+"-start.json"))["utc"]).timestamp()>=earlier.stat().st_mtime
                checks[worker_name+"_owner_released"]=read(ROOT/(worker_name+"-owner-release.json"))["cleared"]
                for path in folder(epoch).glob(short+"-boundary*.npz"):
                    saved=load(path)
                    index=int(saved["completed"])
                    checks[str(path.relative_to(ROOT))+"_exact"]=np.array_equal(saved["normalized"],data["extended"][index]) and all(np.array_equal(saved["work_"+name],work[name][index]) for name in work_begin)
                if case=="heavy":
                    predicted=load(defects_path(steps,epoch))
                    previous=load(defects_path(steps,4249 if epoch==CONFIG["checkpoint_epochs"][0] else prior_epoch(epoch)))
                    for name in ("fine","coarse"):
                        checks[worker_name+"_"+name+"_predictor_continuous"]=np.array_equal(predicted[name][0],previous[name][-1])
                    checks[worker_name+"_predictor_owner_released"]=read(ROOT/("predict-"+str(epoch)+"-"+str(steps)+"-owner-release.json"))["cleared"]
    last=epochs[-1] if epochs else 4249
    final_folder=interval_folder(last)
    for case in CONFIG["cases"]:
        with native_context(case,"verify-"+case) as (captured,metadata,sample):
            for steps in CONFIG["steps"]:
                direct,system,_=native_for(case,captured,metadata,sample,steps)
                saved=load(final_folder/(case+"-"+str(steps)+"-terminal.npz"))
                if system:
                    checks[case+"_"+str(steps)+"_actual_final_rhs"]=np.array_equal(system.rhs(float(saved["tau"]),saved["normalized"]),saved["actual_rhs"])
                    for mode in ("parent","approximate"):restore(direct,final_folder/(case+"-"+str(steps)+"-"+mode+"-terminal.npz"))
                else:restore(direct,final_folder/(case+"-"+str(steps)+"-terminal.npz"))
                checks[case+"_"+str(steps)+"_fresh_restore"]=True
        checks[case+"_verification_owner_release"]=read(ROOT/("verify-"+case+"-owner-release.json"))["cleared"]
    checks["no_bytecode"]=not list(ROOT.rglob("__pycache__"))
    for path in ROOT.glob("*.py"):compile(path.read_text(encoding="utf-8"),str(path),"exec")
    result={"passed":all(checks.values()),"checks":checks,"count":len(checks),"completed_epochs":epochs,"last_accounted_epoch":last,
        "criterion":"nonzero-inherited-defect-v1","old_raw_gates_not_rewritten":True}
    save(ROOT/"verification.json",result)
    require(result["passed"],"verification failures:"+str([key for key,value in checks.items() if not value]))
    inputs()
    print(json.dumps({key:value for key,value in result.items() if key!="checks"}),flush=True)


if __name__=="__main__":
    with worker("verify"):verify()

