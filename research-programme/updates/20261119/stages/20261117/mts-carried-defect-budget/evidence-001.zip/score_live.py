from live_work import *
from score_phase import conservative


def folder(epoch):
    return AUTHORITY/('epoch'+str(epoch)) if epoch==CONFIG['start_index'] else ROOT/('epoch'+str(epoch))


def work_history(case,steps,epoch):
    values=None
    directories=[Path(value) for value in CONFIG['work_history_directories']]
    directories.extend(folder(current) for current in CONFIG['checkpoint_epochs'] if current<=epoch)
    for directory in directories:
        following=load(directory/(case+'-'+str(steps)+'-work-history.npz'))
        if values is None:values=following
        else:
            require(set(values)==set(following),'same diagnostic history fields')
            for name in values:
                require(np.array_equal(values[name][-1],following[name][0]),'diagnostic restart exact: '+name)
                values[name]=np.concatenate((values[name],following[name][1:]),axis=0)
    return values

def calculate(epoch):
    data={case+'-'+str(steps)+'.npz':previous_history(case,steps,epoch) for case in CONFIG['cases'] for steps in CONFIG['steps']}
    physics=retained_score.identical_score(data,epoch,True)
    fine,coarse=(work_history('heavy',steps,epoch) for steps in (64,32))
    target,target_low=data['heavy-64.npz'],data['heavy-32.npz']
    locations=np.searchsorted(target['time'],fine['time'])
    require(np.array_equal(target['time'][locations],fine['time']) and np.array_equal(fine['time'],coarse['time']),'identical work and physics clocks')
    best,low=fine['orders'][:,2,:],coarse['orders'][:,2,:]
    allowance=sum(fine[name]+coarse[name] for name in ('inherited_allowance','quadrature_75','quadrature_53','rounding'))+np.max(abs(best-low),axis=0)
    checks={}
    branches={}
    for branch,name in enumerate(('old','coherent','coherent_minus_original')):
        def selected(values,prefix):
            old=values[prefix+'work'][:,0]
            change=values[prefix+'work_change'][:,0]
            work=old if branch==0 else old+change if branch==1 else change
            return work,work-work[0]
        approximate,approx_increment=selected(target,'')
        parent,parent_increment=selected(target,'parent_')
        _,approx_low=selected(target_low,'')
        _,parent_low=selected(target_low,'parent_')
        observed=(approx_increment-parent_increment)[locations]
        predicted=best[:,branch]+best[:,3+branch]
        independent,defect=best[:,6+branch],best[:,12+branch]
        physical_step=maximum(approx_increment-approx_low)+maximum(parent_increment-parent_low)
        physical_rounding=64*np.finfo(float).eps*maximum(abs(approximate)+abs(approximate[0])+abs(parent)+abs(parent[0]))
        signed_numerical=allowance[:,branch]+allowance[:,3+branch]+abs(defect)+allowance[:,12+branch]
        working_bound=best[:,9+branch]+allowance[:,9+branch]+abs(defect)+allowance[:,12+branch]+physical_step+physical_rounding
        scale=maximum(parent_increment)
        comparison=ratio(maximum(abs(predicted-observed)+signed_numerical)+physical_step+physical_rounding,scale)
        raw_split=ratio(maximum(independent-predicted),maximum(independent),CONFIG['algebra_tolerance'])
        accounted=ratio(maximum(independent-predicted-defect),maximum(independent),CONFIG['algebra_tolerance'])
        checks[name+'_split_accounted']=accounted['passed']
        checks[name+'_covers_signed']=bool(np.all(abs(predicted)<=working_bound+signed_numerical))
        checks[name+'_covers_direct']=bool(np.all(abs(observed)<=working_bound))
        branches[name]={'predicted_final':float(predicted[-1]),'observed_final':float(observed[-1]),'inherited_final':float(best[-1,branch]),'generated_final':float(best[-1,3+branch]),'working_budget':ratio(maximum(working_bound),scale),'independent_comparison':comparison,'prediction_own_precision':ratio(maximum(signed_numerical),maximum(predicted)),'raw_split':raw_split,'defect_accounted_split':accounted,'inherited_allowance':maximum(fine['inherited_allowance'][:,branch]+fine['inherited_allowance'][:,3+branch]),'local_quadrature_75':maximum(fine['quadrature_75'][:,branch]+fine['quadrature_75'][:,3+branch]),'local_quadrature_53':maximum(fine['quadrature_53'][:,branch]+fine['quadrature_53'][:,3+branch]),'new_local_rounding':maximum(fine['rounding'][:,branch]+fine['rounding'][:,3+branch]),'physical_work_refinement':physical_step,'physical_work_rounding':physical_rounding,'total_split_defect':float(defect[-1])}
    for steps in CONFIG['steps']:
        cold=data['cold-'+str(steps)+'.npz']
        diagnostic=work_history('cold',steps,epoch)
        checks['cold_'+str(steps)+'_owned_pressure_work_zero']=bool(np.all(cold['source'][:,2]==0) and np.all(cold['source_change'][:,2]==0) and np.all(cold['work'][:,0]==0) and np.all(cold['work_change'][:,0]==0))
        checks['cold_'+str(steps)+'_work_diagnostic_zero']=all(np.all(value==0) for name,value in diagnostic.items() if name not in ('time','accepted_steps'))
    result={'last_epoch':epoch,'diagnostic_history_anchor':3041,'all_controls_pass':all(checks.values()),'all_physical_work_budgets_pass':all(value['working_budget']['passed'] and value['independent_comparison']['passed'] for value in branches.values()),'all_tiny_predictions_resolved':all(value['prediction_own_precision']['passed'] for value in branches.values()),'branches':branches,'checks':checks,'accepted_dense_steps_64':int(fine['accepted_steps'][-1]),'diagnostics_in_physical_error_controller':False,'certified_continuum_bound':False}
    slip={}
    for case in CONFIG['cases']:
        for mode in (('parent','approximate') if case=='heavy' else ('baseline',)):
            values,primitives={},{}
            for steps in CONFIG['steps']:
                suffix='-'+mode if case=='heavy' else ''
                terminal=load(folder(epoch)/(case+'-'+str(steps)+suffix+'-terminal.npz'))
                values[steps],primitives[steps],_=retained_slip.extract(data[case+'-'+str(steps)+'.npz'],terminal,mode)
            slip[case+'_'+mode]={'amplitude':maximum(values[64]),'precision':conservative(0.,maximum(values[64]-values[32]),maximum(values[64]),maximum(primitives[64]+primitives[32]))}
    gate={'epoch':epoch,'physical_gate':physics['continuation_gate_pass'],'inverse_safety':physics['maximum_inverse_bound']<1,'work_controls':result['all_controls_pass'],'physical_work_budget':result['all_physical_work_budgets_pass'],'passed':physics['maximum_inverse_bound']<1 and physics['continuation_gate_pass'] and result['all_controls_pass'] and result['all_physical_work_budgets_pass'],'tiny_error_resolution_is_separate':True}
    return physics,result,slip,gate


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('epoch',type=int,choices=CONFIG['checkpoint_epochs'])
    args=parser.parse_args()
    with worker('score-'+str(args.epoch)):
        inputs()
        physics,work,slip,gate=calculate(args.epoch)
        for name,value in (('physics',physics),('work',work),('slip',slip),('gate',gate)):
            save(ROOT/('epoch'+str(args.epoch)+'-'+name+'.json'),value)
        inputs()
        print(json.dumps(gate),flush=True)

