from defect_budget import *


def stopped(saved):
    try:
        process=psutil.Process(saved["pid"])
        if abs(process.create_time()-saved["created"])>=.01:
            return {"exited":True,"reason":"PID reused; command not read; untouched"}
        same=process.cmdline()==saved["command"]
        return {"exited":not same,"reason":"original active" if same else "different identity; untouched"}
    except psutil.NoSuchProcess:
        return {"exited":True,"reason":"PID absent"}


def run():
    inputs()
    verification=read(ROOT/"verification.json")
    photon_checks=read(ROOT/"photon-energy-verification.json")
    require(verification["passed"] and photon_checks["passed"],"verified numerical history and derived readouts")
    epoch=verification["last_accounted_epoch"]
    gate=read(ROOT/("bridge-gate.json" if epoch==4249 else "epoch"+str(epoch)+"-gate.json"))
    work=read(ROOT/("bridge-work.json" if epoch==4249 else "epoch"+str(epoch)+"-work.json"))
    raw=read(ROOT/("bridge-raw-physics.json" if epoch==4249 else "epoch"+str(epoch)+"-raw-physics.json"))
    momentum=read(ROOT/"photon-exchange-result.json")
    energy=read(ROOT/"photon-energy-result.json")
    require(gate["passed"],"accounted criterion passes")
    identities={}
    for path in sorted(ROOT.glob("*-start.json")):
        saved=read(path)
        label=path.name.removesuffix("-start.json")
        require((ROOT/(label+"-end.json")).exists(),"completed owned worker:"+label)
        identities[path.name]={"identity":saved,"status":stopped(saved)}
    require(all(value["status"]["exited"] for value in identities.values()),"no task-owned worker remains")
    releases={str(path.relative_to(ROOT)):read(path)["cleared"] for path in sorted(ROOT.rglob("*-owner-release.json"))}
    require(releases and all(releases.values()),"all native owners released")
    require(not list(ROOT.rglob("*-failure.json")) and not list(ROOT.rglob("__pycache__")),"no unresolved worker failure or bytecode")
    save(ROOT/"cleanup.json",{"workers":identities,"native_releases":releases,"all_workers_exited":True,
        "no_kill":True,"temporary_browser_server_subagent_count":0,"other_chats_and_app_services_untouched":True,
        "no_RAM_recovery_claim":True,"pre_freeze_import_failure":"carry module not yet imported; fixed import ordering before any worker/preparation freeze"})
    physical={}
    for case in CONFIG["cases"]:
        data=all_history(case,64,epoch)
        prefix_name="parent_" if case=="heavy" else ""
        physical[case]={"final_time_Mpc":float(data["time"][-1]),"history_time_start_Mpc":float(data["time"][0]),
            "final_source_change":data[prefix_name+"source_change"][-1].tolist(),
            "final_pressure_work_change_from_history_start":float(data[prefix_name+"work_change"][-1,0]-data[prefix_name+"work_change"][0,0]),
            "same_complete_data_reused":True,"scope":"coherent-minus-original within branch, not MTS-minus-baseline observations"}
    save(ROOT/"physical-endpoint.json",physical)
    worst_envelope=max(value["relative"] for value in gate["enlarged_working_envelopes"].values())
    worst_work=max(value["working_budget"]["relative"] for value in work["branches"].values())
    worst_state=max(value["state"]["relative"] for value in gate["transport"].values())
    worst_rhs=max(value["rhs"]["relative"] for value in gate["transport"].values())
    text="# Carried-defect budget and photon exchange results\n\n"
    text+=f"Last independently verified accounted endpoint: {epoch}. New endpoints: {verification['completed_epochs']}. Criterion nonzero-inherited-defect-v1; old raw gates are retained, not rewritten. No fit, bank/grid/normalization change, error reset, GitHub action or quantum-measure claim.\n\n"
    text+="## Derived correction to the bookkeeping\n\n"
    text+="e'=Ae-r, h'=Ah, f'=Af-r imply d'=Ad with the ACTUAL nonzero initial d=e-h-f. Carry this independent prediction and require the remaining discrepancy to meet the original algebra tolerance. For each source/metric projection use Le=Lh+Lf+Ld and ADD |Ld| plus its refinement/rounding allowances to the existing envelope. Existing pressure-work integrates the actual defect separately, with inherited offsets and allowances retained. This strengthens the physical uncertainty budget rather than erasing a failing component.\n\n"
    text+=f"The exposed4249 engineering bridge passed before new evolution. Each subsequent batch gated before the next. Final worst carried-state consistency {worst_state:.12g}; RHS consistency {worst_rhs:.12g}, both compared with1e-10. Largest enlarged observable envelope {worst_envelope:.12g}; largest physical pressure-work budget {worst_work:.12g}, both compared with2e-5. Maximum inverse expression {raw['maximum_inverse_bound']:.12g}<1. The old raw continuation gate at this endpoint is {raw['continuation_gate_pass']}; its zero-inherited-defect assumption is not silently reused.\n\n"
    text+="## Numerical controls\n\n"
    text+=f"{verification['count']} independent technical/manufactured/replay/restore checks pass. Baseline and MTS have unchanged32/64 physical resolutions, original source knots,934 normalization, and complete native/K/error/h/f/probes/work restarts. Each physical seed carries BOTH independent predictor resolutions from3940; differences between different initial seeds are not called same-seed convergence. The predictor does not feed the physical solver. These are finite numerical working budgets, not certified continuum bounds.\n\n"
    text+="## Photon/baryon bridge and collision energy\n\n"
    text+="The retained common-metric momentum transfer is J=(4/3)B_gamma*chi*(v_b-3q_gamma/4). It is equal/opposite in the two momentum equations. On the fixed-ionization branch its coefficient scales as a^-4. Cross section and gravitational normalization remain retained inputs, not newly derived constants.\n\n"
    text+="From those equations the collision-only bulk quantity K=(1/2)B_b*v_b^2+(3/8)B_gamma*q_gamma^2 satisfies K'_coll=-A*(v_b-3q_gamma/4)^2<=0. The exact finite correction retains all Delta-a/Delta-slip cross terms and uses cancellation-safe arithmetic. This derives bulk kinetic damping, NOT its final allocation between gas heat and photon redistribution, full second-order gravitational conservation or an observed spectral distortion. Real-mode normalization is explicit; quantum measure remains separate.\n\n"
    text+=f"Momentum checks: {photon_checks['momentum_symbolic']} exact algebra and {photon_checks['momentum_native']} native equations. Energy checks: {photon_checks['energy_symbolic']} exact algebra and {photon_checks['energy_controls']} controls. Both readouts replay exactly.\n\n"
    for title,result,key in (("Momentum",momentum,"approximation_vs_parent"),("Bulk damping",energy,"approximate_parent_comparison")):
        text+=f"### {title}\n\n"
        text+=f"Parent/approximate comparison: {result[key]['relative']:.12g}, pass={result[key]['passed']}, tolerance2e-5.\n\n"
        for label,value in result["responses"].items():
            final=value.get("final_delta_J",value.get("final_change"))
            text+=f"- {label}: final coherent-minus-original response {final:.12g}; own-response precision {value['precision']['relative']:.12g}; resolved={value['precision']['passed']}.\n"
        text+="\n"
    text+="Tiny baseline responses marked unresolved remain unresolved, not zero or a detection. All quoted corrections are within-branch coherent-minus-original, not an MTS-minus-baseline data preference. Physical endpoint source changes and pressure work are recorded in physical-endpoint.json.\n\n"
    text+=f"## Cleanup\n\n{len(identities)} task workers exited;{len(releases)} native releases verified. All original artifacts remain. No unrelated process was inspected or stopped; no browser/server/subagent created. Read cleanup.json and closeout.json for exact identities and hashes.\n"
    with (ROOT/"RESULTS.md").open("x",encoding="utf-8") as stream:stream.write(text)
    next_text="# Next stage\n\n"
    if epoch<4252:
        next_text+=f"Continue the remaining original endpoints after{epoch}, requiring each frozen accounted gate. Use complete physical/work and both independent predictor histories; do not return to a zero-defect assumption or reset anything.\n\n"
    else:
        next_text+="The saved retained history now reaches4252 under the explicitly derived defect-aware criterion. Do not rerun this history merely to rename checkpoints.\n\n"
    next_text+="Use the checked photon momentum and collision-only bulk damping as inputs to the existing microscopic ENERGY collision/redistribution equations. Derive where the lost bulk energy goes before calling it gas heating. Match the corrected source and its full inherited uncertainty into the saved radiation/gas response, treating baseline and MTS identically. Reuse the original bank, histories and code; do not add a fitted transfer coefficient or arbitrary cutoff. Preserve the unresolved tiny-baseline precision flag. Prioritize an observable source/spectrum consequence over another isolated numerical identity.\n\n"
    next_text+=f"New accounted physical restart: epoch{epoch}/complete cold/heavy32/64 terminals and work terminals (or prior candidate4249 if no new endpoint). Independent predictors: heavy32/64-defect.npz fine/coarse last full states; preserve their original3940 seed and all projection/work histories. Separate native parent/approximation terminals are controls only. Use history_directories/work_history_directories plus this stage's completed epochs. The old3940 authority and raw failed4249 candidates remain unchanged for comparison. Native binary/bank and fixed hierarchy are the same.\n\n"
    next_text+="Source paths for existing saved physical histories:\n"
    for case in CONFIG["cases"]:next_text+=f"- {case}: {retained_score.source_paths(case)}\n"
    next_text+="\nNo GitHub. One numerical worker/thread; next turn gets a fresh bounded check-in cutoff only after checking owner instructions and actual process state.\n"
    with (ROOT/"NEXT.md").open("x",encoding="utf-8") as stream:stream.write(next_text)
    entries={str(path.relative_to(ROOT)):{"bytes":path.stat().st_size,"sha256":digest(path)} for path in sorted(ROOT.rglob("*")) if path.is_file()}
    result={"last_accounted_epoch":epoch,"criterion":"nonzero-inherited-defect-v1","completed_epochs":verification["completed_epochs"],
        "full_saved_source_tail_complete":epoch==4252,"old_raw_gates_preserved":True,"new_physical_authority":epoch>4249,
        "files":entries,"count":len(entries),"bytes":sum(value["bytes"] for value in entries.values()),
        "closer_identity":identity(psutil.Process()),"closed_utc":datetime.now(timezone.utc).isoformat(),"goal_complete":False,"github":False}
    save(ROOT/"closeout.json",result)
    print(json.dumps({name:value for name,value in result.items() if name!="files"}),flush=True)
    print("seal="+digest(ROOT/"closeout.json"),flush=True)


if __name__=="__main__":run()

