from score_live import *
import shutil
import importlib.util

TAIL=Path(CONFIG["research_authority"])
CANDIDATE=Path(CONFIG["authority_directory"])
FORECAST=TAIL/"split-defect-transport"
SPLIT_SOURCE=TAIL/"split_transport.py"


def interval_folder(epoch):
    return CANDIDATE/"epoch4249" if epoch==4249 else folder(epoch)


def all_history(case,steps,epoch):
    return previous_history(case,steps,epoch)


def native_for(case,captured,metadata,sample,steps=64):
    return build(case,CONFIG["checkpoint_epochs"][0],steps,captured,metadata,sample)


def background_equation(direct,clock,normalized):
    base=direct.model.represented(clock)
    physical=normalized*direct.background_units
    alpha,fields,velocities=direct.model.unpack(physical)
    difference=direct.model.difference_flow(base,physical,False)
    field_defect=base["field_first"]-base["velocity"]
    velocity_defect=base["velocity_first"]+2*base["hubble"]*base["velocity"]+base["mass"]*base["field"]
    derivative=direct.model.pack(difference[0]/base["scale"]-base["rate"]*alpha+base["hubble"]-base["rate"],
        difference[1::2]-field_defect,difference[2::2]-velocity_defect)/direct.background_units
    packet=np.zeros(5)
    packet[:direct.width]=direct.model.pack(base["scale"]*(1+alpha),base["field"]+fields,base["velocity"]+velocities)
    return derivative,packet


def forecast_rhs(direct,system,clock,state):
    derivative,packet=background_equation(direct,clock,state[:direct.width])
    return np.r_[derivative,system.linear_rhs(clock,state[direct.width:],packet)]


def prepare_stage():
    require(digest(TAIL/"closeout.json")==CONFIG["authority_seal"],"previous research seal")
    require(not read(TAIL/"epoch4249-gate.json")["passed"] and not read(CANDIDATE/"epoch4249-gate.json")["passed"],"old raw failures preserved")
    mapping=read(TAIL/"inputs.json")
    mapping[str(TAIL/"closeout.json")]=CONFIG["authority_seal"]
    for name,value in read(TAIL/"closeout.json")["files"].items():
        mapping[str(TAIL/name)]=value["sha256"]
    check_inputs(mapping)
    for epoch in CONFIG["checkpoint_epochs"]:
        folder(epoch).mkdir()
        for case in CONFIG["cases"]:
            source=TAIL/("epoch"+str(epoch))/(case+"-clock.npz")
            shutil.copy2(source,folder(epoch)/source.name)
    save(ROOT/"frozen-norms.json",read(TAIL/"frozen-norms.json"))
    for case in CONFIG["cases"]:
        for steps in CONFIG["steps"]:
            np.savez_compressed(ROOT/(case+"-"+str(steps)+"-initial-work.npz"),**load(CANDIDATE/"epoch4249"/(case+"-"+str(steps)+"-work-terminal.npz")))
    for path in ROOT.rglob("*"):
        if path.is_file() and not path.name.endswith(("-start.json","-end.json","-failure.json")):
            if path.suffix==".py":compile(path.read_text(encoding="utf-8"),str(path),"exec")
            mapping[str(path)]=digest(path)
    write(ROOT/"inputs.json",mapping)
    print(json.dumps({"frozen":True,"inputs":len(mapping),"new_epochs":CONFIG["checkpoint_epochs"],"old_raw_gate_unchanged":True}),flush=True)


def defects_path(steps,epoch):
    return ROOT/("bridge-defect-"+str(steps)+".npz") if epoch==4249 else folder(epoch)/("heavy-"+str(steps)+"-defect.npz")


def defects(steps,epoch):
    parts=[load(defects_path(steps,4249))]
    parts.extend(load(defects_path(steps,value)) for value in CONFIG["checkpoint_epochs"] if value<=epoch)
    names=("time","actual","source","source_primitive","readout","readout_primitive","work_rate_error","work_rate_scale")
    result={name:parts[0][name].copy() for name in names}
    forecast_names=("forecast_time","fine","coarse","forecast_actual","forecast_rhs_actual","forecast_rhs_predicted","forecast_background_actual")
    result.update({name:parts[0][name].copy() for name in forecast_names})
    for following in parts[1:]:
        for name in names:
            require(np.array_equal(result[name][-1],following[name][0]),"complete defect projection join:"+name)
            result[name]=np.concatenate((result[name],following[name][1:]),axis=0)
        for name in forecast_names:
            require(np.array_equal(result[name][-1],following[name][0]),"independent predictor join:"+name)
            result[name]=np.concatenate((result[name],following[name][1:]),axis=0)
    return result


def project(direct,system,data):
    outputs={name:[] for name in ("actual","source","source_primitive","readout","readout_primitive","work_rate_error","work_rate_scale")}
    indices,units=coordinates(direct,system)
    for index,clock in enumerate(data["time"]):
        guard()
        state=data["extended"][index]
        actual=state[system.core_size-system.pair_size:system.core_size]-state[system.core_size:system.core_size+system.pair_size]-state[system.core_size+system.pair_size:system.core_size+2*system.pair_size]
        require(np.array_equal(actual,data["split_state_residual"][index]),"actual inherited defect retained")
        parent=system.core.unpack(state[:system.core_size])[1]
        values=operator_repair.carry.linear_values(direct,system.reduced.selected,float(clock),parent,*system.vectors(actual))
        outputs["actual"].append(actual)
        for name,value in values.items():outputs[name].append(value)
        vector=state[indices]*units
        rates=rate_at(direct,float(clock),vector)
        background=direct.unpack(parent)[2]
        base=direct.model.represented(float(clock))
        delta_hubble=direct.model.correction_geometry(base,background,False)[0]
        old,change=values["source"][:,2]
        expected=-3*np.array([base["hubble"]*old,(base["hubble"]+delta_hubble)*(old+change),
            base["hubble"]*change+delta_hubble*(old+change)])
        outputs["work_rate_error"].append(rates[12:15]-expected)
        outputs["work_rate_scale"].append(abs(rates[0:3])+abs(rates[3:6])+abs(rates[6:9])+abs(expected))
    return dict(time=data["time"],**{name:np.asarray(value) for name,value in outputs.items()})


def forecast_outputs(direct,system,data,fine,coarse):
    require(len(fine)==len(data["time"])==len(coarse),"predictor coverage")
    predicted_rhs=np.array([forecast_rhs(direct,system,float(clock),state)[direct.width:] for clock,state in zip(data["time"],fine)])
    actual_background=data["extended"][:,2*direct.active:2*direct.active+direct.width]
    return {"forecast_time":data["time"],"fine":fine,"coarse":coarse,
        "forecast_actual":data["split_state_residual"],"forecast_rhs_actual":data["split_rhs_residual"],
        "forecast_rhs_predicted":predicted_rhs,"forecast_background_actual":actual_background}


def bridge_projection():
    inputs()
    with native_context("heavy","bridge-project") as (captured,metadata,sample):
        for steps in CONFIG["steps"]:
            direct,system,_=native_for("heavy",captured,metadata,sample,steps)
            data=all_history("heavy",steps,4249)
            values=project(direct,system,data)
            tail=load(CANDIDATE/"epoch4249"/("heavy-"+str(steps)+".npz"))
            fine=load(FORECAST/("seed"+str(steps)+"-steps64.npz"))
            coarse=load(FORECAST/("seed"+str(steps)+"-steps32.npz"))
            require(np.array_equal(fine["time"],tail["time"]) and np.array_equal(coarse["time"],tail["time"]),"existing forecast clocks")
            values.update(forecast_outputs(direct,system,tail,fine["evolved"],coarse["evolved"]))
            np.savez_compressed(defects_path(steps,4249),**values)
    inputs()


def predict_epoch(epoch,steps):
    inputs()
    require(read(ROOT/"bridge-gate.json")["passed"],"derived bridge required")
    data=load(folder(epoch)/("heavy-"+str(steps)+".npz"))
    predecessor=4249 if epoch==CONFIG["checkpoint_epochs"][0] else prior_epoch(epoch)
    saved=load(defects_path(steps,predecessor))
    with native_context("heavy","predict-"+str(epoch)+"-"+str(steps)) as (captured,metadata,sample):
        direct,system,_=native_for("heavy",captured,metadata,sample,steps)
        histories={}
        for rule,solve_steps in (("coarse",32),("fine",64)):
            current=saved[rule][-1].copy()
            require(saved["forecast_time"][-1]==data["time"][0],"continuous independent predictor")
            states=[current.copy()]
            for position,(left,right) in enumerate(zip(data["time"][:-1],data["time"][1:])):
                guard()
                solution=solve_ivp(lambda clock,state:forecast_rhs(direct,system,clock,state),
                    (float(left),float(right)),current,method="DOP853",rtol=CONFIG["rtol"],atol=CONFIG["normalized_atol"],
                    max_step=float(direct.prepared["elapsed"][8])/solve_steps)
                require(solution.success,"independent predictor integration")
                current=solution.y[:,-1]
                states.append(current.copy())
            histories[rule]=np.asarray(states)
        values=project(direct,system,data)
        values.update(forecast_outputs(direct,system,data,histories["fine"],histories["coarse"]))
        np.savez_compressed(defects_path(steps,epoch),**values)
    inputs()


def scored(epoch):
    data={case+"-"+str(steps):all_history(case,steps,epoch) for case in CONFIG["cases"] for steps in CONFIG["steps"]}
    raw,work,slip,raw_gate=calculate(epoch)
    projection={steps:defects(steps,epoch) for steps in CONFIG["steps"]}
    high,low=data["heavy-64"],data["heavy-32"]
    fine,coarse=projection[64],projection[32]
    require(np.array_equal(fine["time"],high["time"]) and np.array_equal(coarse["time"],low["time"]),"complete physical/projection coverage")
    identities,envelopes={},{}
    for branch,branch_name in enumerate(("old","coherent")):
        for family in ("source","readout"):
            names=("density","current","pressure") if family=="source" else ("native_velocity","native_weyl","photon_density","relative_density","velocity_slip")
            def selected(values):
                return values[family][:,0]+(values[family][:,1] if branch else 0) if family=="source" else values[family][:,branch]
            projected,projected_low=selected(fine),selected(coarse)
            primitive=fine[family+"_primitive"][:,branch]+coarse[family+"_primitive"][:,branch]
            for component,name in enumerate(names):
                key=branch_name+"_"+name
                base=raw["working_envelopes"][key]
                added=maximum(projected[:,component])+maximum(projected[:,component]-projected_low[:,component])+64*np.finfo(float).eps*maximum(primitive[:,component])
                bounded=ratio(base["error"]+added,base["scale"])
                bounded.update(original_budget=base["error"],actual_defect_amplitude=maximum(projected[:,component]),
                    defect_added_allowance=added,observed_covered=base["observed_discrepancy"]<=base["error"]+added,
                    signed_error_covered=base["signed_error_amplitude"]<=base["error"]+added)
                envelopes[key]=bounded
                for steps,physical_data,defect_data in ((64,high,fine),(32,low,coarse)):
                    def response(role):
                        value=physical_data[role+"_"+family]
                        return value[:,0]+(value[:,1] if branch else 0) if family=="source" else value[:,branch]
                    residual=response("error")-response("carry")-response("fresh")-selected(defect_data)
                    scale=sum(physical_data[role+"_"+family+"_primitive"][:,branch] for role in ("error","carry","fresh"))+defect_data[family+"_primitive"][:,branch]
                    identities[key+"_"+str(steps)]=ratio(maximum(residual[:,component]),maximum(scale[:,component]),CONFIG["algebra_tolerance"])
    transport={}
    for steps,value in projection.items():
        width=5
        predicted=value["fine"][:,width:]
        lower=value["coarse"][:,width:]
        remaining=value["forecast_actual"]-predicted
        forecast_error=maximum(predicted-lower)
        background=ratio(maximum(value["fine"][:,:width]-value["forecast_background_actual"]),maximum(value["forecast_background_actual"]))
        transport[str(steps)]={"state":ratio(maximum(remaining)+forecast_error,raw["split_state"]["scale"],CONFIG["algebra_tolerance"]),
            "rhs":ratio(maximum(value["forecast_rhs_actual"]-value["forecast_rhs_predicted"]),raw["split_rhs"]["scale"],CONFIG["algebra_tolerance"]),
            "background":background,"same_seed_forecast_difference":forecast_error,
            "actual_defect_max":maximum(value["actual"]),"predicted_max":maximum(predicted),
            "work_rate":ratio(maximum(value["work_rate_error"]),maximum(value["work_rate_scale"]),CONFIG["algebra_tolerance"])}
    physical=raw["physical_checks_pass"] and raw["defect_accounting_pass"] and raw["signed_precision_pass"] and raw["maximum_inverse_bound"]<1
    pass_transport=all(item[name]["passed"] for item in transport.values() for name in ("state","rhs","background","work_rate"))
    pass_projection=all(value["passed"] for value in identities.values())
    pass_envelope=all(value["passed"] and value["observed_covered"] and value["signed_error_covered"] for value in envelopes.values())
    pass_work=work["all_controls_pass"] and work["all_physical_work_budgets_pass"]
    report={"epoch":epoch,"criterion":"nonzero-inherited-defect-v1","raw_gate":raw_gate,
        "transport":transport,"projection_identities":identities,"enlarged_working_envelopes":envelopes,
        "existing_physical_checks":physical,"transport_pass":pass_transport,"projection_pass":pass_projection,
        "enlarged_envelopes_pass":pass_envelope,"work_pass":pass_work,
        "passed":bool(physical and pass_transport and pass_projection and pass_envelope and pass_work),
        "unchanged_tolerances":True,"no_error_reset":True,"certified_continuum_bound":False,
        "exposed_engineering_bridge":epoch==4249}
    return raw,work,slip,report


def score_stage(epoch):
    inputs()
    raw,work,slip,report=scored(epoch)
    for name,value in (("raw-physics",raw),("work",work),("slip",slip),("gate",report)):
        save(ROOT/(("bridge" if epoch==4249 else "epoch"+str(epoch))+"-"+name+".json"),value)
    inputs()
    print(json.dumps({key:report[key] for key in ("epoch","passed","existing_physical_checks","transport_pass","projection_pass","enlarged_envelopes_pass","work_pass","raw_gate")}),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("prepare","bridge","predict","score"))
    parser.add_argument("--epoch",type=int,choices=(4249,4250,4251,4252),default=4249)
    parser.add_argument("--steps",type=int,choices=(32,64),default=64)
    args=parser.parse_args()
    label=args.command+("-"+str(args.epoch) if args.command in ("predict","score") else "")+("-"+str(args.steps) if args.command=="predict" else "")
    with worker(label):
        if args.command=="prepare":prepare_stage()
        elif args.command=="bridge":bridge_projection()
        elif args.command=="predict":predict_epoch(args.epoch,args.steps)
        else:score_stage(args.epoch)

