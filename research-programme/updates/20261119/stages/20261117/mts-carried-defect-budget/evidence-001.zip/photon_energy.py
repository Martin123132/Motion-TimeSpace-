from defect_budget import *
from fractions import Fraction

spec=importlib.util.spec_from_file_location("retained_photon_exchange",TAIL/"photon_exchange.py")
exchange=importlib.util.module_from_spec(spec)
spec.loader.exec_module(exchange)


def damping(data,terminal,mode):
    state=retained_slip.native_state(data,terminal,mode)
    active=int(terminal["dimensions"][1])
    indices=[3,int(terminal["signature"][3])]
    old=state[:,indices]*terminal["state_units"][indices]
    change=state[:,[active+index for index in indices]]*terminal["delta_units"][indices]
    slip=old[:,0]-.75*old[:,1]
    slip_change=change[:,0]-.75*change[:,1]
    packet=data[("parent_" if mode=="parent" else "")+"metric"]
    species=packet[...,:84].reshape(len(packet),2,7,12)
    alpha=state[:,2*active]*terminal["background_units"][0]
    factor=(1+alpha)**-4
    factor_change=-alpha*(4+6*alpha+4*alpha**2+alpha**3)/(1+alpha)**4
    coefficient=(4./3)*species[:,0,2,0]*field(packet,"opacity")[:,0]
    original=coefficient*slip**2
    coherent=coefficient*factor*(slip+slip_change)**2
    difference=coefficient*(factor_change*slip**2+factor*slip_change*(2*slip+slip_change))
    old_size=abs(old[:,0])+.75*abs(old[:,1])
    change_size=abs(change[:,0])+.75*abs(change[:,1])
    primitive=abs(coefficient)*(abs(factor_change)*old_size**2+abs(factor)*change_size*(2*old_size+change_size))
    hubble,rate=field(packet,"hubble"),field(packet,"rate")
    wave=CONFIG["retained_comoving_wave"]
    gas=-species[:,:,1,8]-(hubble+rate)*species[:,:,1,4]+wave*species[:,:,1,5]
    photons=species[:,:,2,8]+2*rate*species[:,:,2,4]-wave*(species[:,:,2,5]-2*species[:,:,2,6]/3)
    gas_scale=abs(species[:,:,1,8])+abs((hubble+rate)*species[:,:,1,4])+abs(wave*species[:,:,1,5])
    photon_scale=abs(species[:,:,2,8])+2*abs(rate*species[:,:,2,4])+abs(wave*species[:,:,2,5])+2*abs(wave*species[:,:,2,6])/3
    velocity=np.stack((old,old+change),axis=1)
    kinetic_collision=-velocity[:,:,0]*gas+.75*velocity[:,:,1]*photons
    dissipated=np.column_stack((original,coherent))
    rhs_primitive=abs(velocity[:,:,0])*gas_scale+.75*abs(velocity[:,:,1])*photon_scale+abs(dissipated)
    controls={"nonnegative_coefficient":bool(np.all(coefficient>=0) and np.all(factor>0)),
        "nonnegative_damping":bool(np.all(dissipated>=0)),
        "collision_energy_identity":ratio(maximum(kinetic_collision+dissipated),maximum(rhs_primitive),CONFIG["algebra_tolerance"]),
        "finite_response":ratio(maximum(coherent-original-difference),maximum(abs(original)+abs(coherent)),CONFIG["algebra_tolerance"])}
    return {"time":data["time"],"old":original,"coherent":coherent,"change":difference,"primitive":primitive},controls


def symbolic_damping():
    checks={}
    for index,alpha in enumerate((Fraction(-1,100),Fraction(-1,10**12),Fraction(0),Fraction(1,10**16),Fraction(1,100))):
        coefficient=Fraction(3,11)
        velocity,flux=Fraction(7,9),Fraction(2,5)
        slip=velocity-Fraction(3,4)*flux
        transfer=coefficient*slip
        checks[str(index)+"_bulk_loss"]=-velocity*transfer+Fraction(3,4)*flux*transfer==-coefficient*slip**2
        change=Fraction(5,17)
        factor=(1+alpha)**-4
        checks[str(index)+"_finite_change"]=coefficient*(factor*(slip+change)**2-slip**2)==coefficient*((factor-1)*slip**2+factor*change*(2*slip+change))
    return checks


def run():
    inputs()
    verification=read(ROOT/"verification.json")
    require(verification["passed"],"verified accounted physical history")
    epoch=verification["last_accounted_epoch"]
    require(read(ROOT/("bridge-gate.json" if epoch==4249 else "epoch"+str(epoch)+"-gate.json"))["passed"],"accepted accounted endpoint")
    manifest={str(path):digest(path) for path in (Path(__file__),ROOT/"PHOTON-ENERGY-DERIVATION.md",TAIL/"photon_exchange.py")}
    save(ROOT/"photon-energy-inputs.json",manifest)
    momentum,arrays=exchange.calculate(epoch)
    repeated,_=exchange.calculate(epoch)
    require(worklib.ordinary(momentum)==worklib.ordinary(repeated),"momentum exact replay")
    save(ROOT/"photon-exchange-result.json",momentum)
    energy,identities,values={},{},{}
    for case in CONFIG["cases"]:
        histories={steps:all_history(case,steps,epoch) for steps in CONFIG["steps"]}
        for mode in (("parent","approximate") if case=="heavy" else ("baseline",)):
            label=case+"_"+mode
            for steps in CONFIG["steps"]:
                suffix="" if case=="cold" else "-"+mode
                terminal=load(interval_folder(epoch)/(case+"-"+str(steps)+suffix+"-terminal.npz"))
                value,checks=damping(histories[steps],terminal,mode)
                repeated_value,repeated_checks=damping(histories[steps],terminal,mode)
                require(all(np.array_equal(value[name],repeated_value[name]) for name in value) and worklib.ordinary(checks)==worklib.ordinary(repeated_checks),"energy readout exact replay")
                values[label,steps]=value
                identities[label+"_"+str(steps)]=checks
                np.savez_compressed(ROOT/("damping-"+label+"-"+str(steps)+".npz"),**value)
            high,low=values[label,64],values[label,32]
            energy[label]={"final_change":float(high["change"][-1]),"amplitude":maximum(high["change"]),
                "precision":conservative(0.,maximum(high["change"]-low["change"]),maximum(high["change"]),maximum(high["primitive"]+low["primitive"]))}
    high,low=values["heavy_approximate",64],values["heavy_approximate",32]
    parent,parent_low=values["heavy_parent",64],values["heavy_parent",32]
    comparison=conservative(maximum(high["change"]-parent["change"]),maximum(high["change"]-low["change"])+maximum(parent["change"]-parent_low["change"]),
        maximum(parent["change"]),maximum(high["primitive"]+low["primitive"]+parent["primitive"]+parent_low["primitive"]))
    algebra=symbolic_damping()
    passed=all(algebra.values()) and all(check if isinstance(check,bool) else check["passed"] for group in identities.values() for check in group.values())
    result={"last_epoch":epoch,"scope":"Collision-only quadratic bulk kinetic damping of real perturbation amplitudes; not full second-order stress-energy, thermodynamic heat allocation, a Compton redistribution kernel or an observed spectrum.",
        "units":"native rescaled bulk damping Mpc^-3; spatial phase averaging factor not applied",
        "symbolic_checks":algebra,"identities":identities,"identities_pass":passed,"responses":energy,"approximate_parent_comparison":comparison,
        "new_fitted_parameters":0,"quantum_measure_separate":True}
    save(ROOT/"photon-energy-result.json",result)
    save(ROOT/"photon-energy-verification.json",{"passed":passed and momentum["identities_pass"],"exact_replay":True,
        "momentum_symbolic":len(momentum["symbolic_checks"]),"momentum_native":sum(len(value) for value in momentum["rhs_identities"].values()),
        "energy_symbolic":len(algebra),"energy_controls":sum(len(value) for value in identities.values()),"new_evolution":False})
    check_inputs(manifest)
    inputs()
    print(json.dumps({"epoch":epoch,"identities_pass":passed,"momentum":momentum["responses"],"energy":energy,"energy_comparison":comparison}),flush=True)
    require(passed and momentum["identities_pass"],"derived collision identities")


if __name__=="__main__":
    with worker("photon-energy"):run()

