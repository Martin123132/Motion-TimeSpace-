from restart_support import *


def joined(parts):
    result={name:value.copy() for name,value in parts[0].items()}
    for following in parts[1:]:
        require(set(result)==set(following),"same complete physical history")
        count=len(result["time"])
        require(result["time"][-1]==following["time"][0],"same clock")
        require(np.array_equal(result["native_control"][-1],following["native_control"][0]),"native boundary exact")
        for name in result:
            if name in ("native_indices","native_control"):continue
            require(len(result[name])==count and len(following[name])==len(following["time"]),"time-indexed history")
            if name not in ("split_rhs_residual","split_rhs_scale"):
                require(np.array_equal(result[name][-1],following[name][0]),"physical boundary exact:"+name)
            result[name]=np.concatenate((result[name],following[name][1:]),axis=0)
        result["native_indices"]=np.r_[result["native_indices"],following["native_indices"][1:]+count-1]
        result["native_control"]=np.concatenate((result["native_control"],following["native_control"][1:]),axis=0)
    return result

