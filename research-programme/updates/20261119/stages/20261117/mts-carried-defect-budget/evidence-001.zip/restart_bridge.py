from restart_support import *
PHASE = Path(CONFIG["phase_directory"])
GAP = Path(CONFIG["gap_directory"])
exec(compile((PHASE / "restart_bridge.py").read_text(encoding="utf-8"), str(PHASE / "restart_bridge.py"), "exec"), globals())
sys.path.insert(0, str(PHASE))
import run_phase as phase
from run_phase import field, COLUMNS

