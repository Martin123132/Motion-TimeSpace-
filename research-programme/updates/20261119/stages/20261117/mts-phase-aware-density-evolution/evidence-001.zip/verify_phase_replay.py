from score_replay import *
from prepare_phase import prove


def verify():
    inputs()
    science = read(ROOT/'science-score.json')
    checks = {'exact_score_replay':calculate()==science,'symbolic_replay':prove()==read(ROOT/'symbolic.json')['checks']}
    for branch in ('old','coherent'):
        for steps,stride in ((32,1),(64,1),(64,2),(64,4)):
            name = 'heavy-'+str(steps)+'-'+branch+'-stride'+str(stride)
            data = history('heavy',steps,branch,stride)
            receipt = read(ROOT/(name+'-result.json'))
            checks[name+'_matrix_identity'] = receipt['matrix_identity_passed']
            checks[name+'_regular_coordinates'] = receipt['maximum_kappa_over_mu']<1 and receipt['minimum_determinant_margin']>0
            checks[name+'_finite_outputs'] = all(bool(np.isfinite(value).all()) for value in data.values())
            for key,value in receipt['native_checks'].items():
                checks[name+'_'+key] = value['passed']
            paths = sorted(ROOT.glob(name+'-batch*.npz'))
            checks[name+'_last_checkpoint'] = bool(paths) and np.array_equal(load(paths[-1])['normalized'],data['normalized'][-1])
            checks[name+'_initial_exactly_matched'] = np.array_equal(data['fields'][0],data['reference_fields'][0]) or maximum(
                data['fields'][0]-data['reference_fields'][0])<=CONFIG['algebra_tolerance']*maximum(data['reference_fields'][0])
        report = science['heavy'][branch]
        for component,value in report['sources'].items():
            checks[branch+'_'+component+'_coordinate_equivalence'] = value['direct_coordinate_equivalence']['passed']
        checks[branch+'_physical_exchange'] = report['physical_exchange']['passed']
        checks[branch+'_cold_structural_zero'] = science['cold'][branch]['pressure_current_structural_zero']
    profile = Profile('heavy',64,1)
    original = Forcing(profile,1)
    middle = float((profile.times[11]+profile.times[12])/2)
    expected = original.at(middle)
    profile.vector[1:,profile.width:profile.width+2*profile.count] *= 1234567.
    profile.derivative[1:,profile.width:profile.width+2*profile.count] *= -7654321.
    profile.perturbation[1:] *= 1000000.
    mutated = Forcing(profile,1)
    checks['future_scalar_cannot_drive_replay'] = mutated.at(middle)==expected
    for name,condition in checks.items():
        require(bool(condition),name)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    require(not (ROOT/'__pycache__').exists(),'no bytecode')
    write(ROOT/'verification.json',{'checks':checks,'count':len(checks),'passed':True,
        'physics_gate_status_separate':science['all_replay_budgets_pass']})
    print(json.dumps({'checks':len(checks),'passed':True,'all_replay_budgets_pass':science['all_replay_budgets_pass']}),flush=True)


if __name__=='__main__':
    with worker('verify'):
        verify()
