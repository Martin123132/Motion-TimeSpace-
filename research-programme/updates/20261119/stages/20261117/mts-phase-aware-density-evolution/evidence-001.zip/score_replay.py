from phase_math import *


def history(case,steps,branch,stride):
    return load(ROOT/(case+'-'+str(steps)+'-'+branch+'-stride'+str(stride)+'.npz'))


def calculate():
    result = {'heavy':{},'cold':{},'future_forcing_conditional_replay':True,'parameters_fitted':0}
    norms = np.array(read(ROOT/'frozen-norms.json')['heavy']['scalar_source_norms'][1])
    field_units = np.array(read(ROOT/'frozen-evolution.json')['metadata']['heavy']['field_units'])
    for branch in ('old','coherent'):
        fine = history('heavy',64,branch,1)
        coarse = history('heavy',32,branch,1)
        sparse2 = history('heavy',64,branch,2)
        sparse4 = history('heavy',64,branch,4)
        for alternate in (coarse,sparse2,sparse4):
            require(np.array_equal(fine['time'],alternate['time']), 'same immutable comparison clocks')
        selected = fine['native_indices']
        reports = {}
        for column,name in enumerate(('density','current','pressure')):
            difference = maximum(fine['physical'][selected,column]-fine['reference_source'][:,column])
            primitive = maximum(fine['physical'][:,column]-fine['direct_physical'][:,column])
            direct_saved = maximum(fine['direct_physical'][selected,column]-fine['reference_source'][:,column])
            paired = maximum(fine['physical'][:,column]-coarse['physical'][:,column])+maximum(fine['reference_source'][:,column]-coarse['reference_source'][:,column])
            sample12 = maximum(fine['physical'][:,column]-sparse2['physical'][:,column])
            sample24 = maximum(sparse2['physical'][:,column]-sparse4['physical'][:,column])
            rounding = 256*np.finfo(float).eps*max(maximum(fine['physical'][:,column]),maximum(fine['reference_source'][:,column]))
            gate = ratio(difference+paired+max(sample12,sample24)+rounding,norms[column])
            gate.update(saved_history_residual=difference,paired_steps=paired,sampling12=sample12,sampling24=sample24,rounding=rounding)
            reports[name] = {'full_budget':gate,'direct_coordinate_equivalence':ratio(primitive+rounding,norms[column]),
                'direct_primitive_vs_saved':ratio(direct_saved+paired+max(sample12,sample24)+rounding,norms[column]),
                'deliberately_unmatched':ratio(maximum(fine['bad_physical'][selected,column]-fine['reference_source'][:,column]),norms[column]),
                'source_sampling_shrinks':bool(sample12<=sample24+rounding)}
        field_checks = {name:ratio(maximum(fine['fields'][selected,column]-fine['reference_fields'][:,column]),field_units[column])
            for column,name in enumerate(('field','velocity'))}
        integral = fine['integrated_work'][selected,0]
        pressure_error = maximum(integral-fine['reference_pressure_work'])
        pressure_steps = maximum(integral-coarse['integrated_work'][selected,0])+maximum(fine['reference_pressure_work']-coarse['reference_pressure_work'])
        pressure_sampling = max(maximum(integral-sparse2['integrated_work'][selected,0]),
            maximum(sparse2['integrated_work'][selected,0]-sparse4['integrated_work'][selected,0]))
        pressure_rounding = 256*np.finfo(float).eps*maximum(fine['integrated_work'])
        pressure_budget = ratio(pressure_error+pressure_steps+pressure_sampling+pressure_rounding,norms[0])
        work = fine['integrated_work']
        density_change = -3*work[:,0]+np.sum(work[:,1:],axis=1)
        exchange = ratio(maximum(fine['physical'][:,0]-fine['physical'][0,0]-density_change)+pressure_rounding,norms[0])
        cycle_limits = read(CYCLE/'window-frozen.json')['windows']['cycles']
        positions = np.searchsorted(fine['time'],cycle_limits)
        cycle_pressure = float(fine['integrated_work'][positions[1],0]-fine['integrated_work'][positions[0],0])
        previous = read(CYCLE/'science-score.json')['reports'][branch]['cycles']['final_reference']
        result['heavy'][branch] = {'sources':reports,'fields':field_checks,'pressure_work_budget':pressure_budget,
            'pressure_work_parts':{'residual':pressure_error,'steps':pressure_steps,'sampling':pressure_sampling,'rounding':pressure_rounding},
            'physical_exchange':exchange,'cycle_pressure_work':cycle_pressure,'previous_cycle_pressure_work':previous,
            'cycle_difference':cycle_pressure-previous,
            'coordinate_minimum_margin':float(np.min(fine['conditioning'][:,1])),
            'maximum_balanced_condition_number':float(np.max(fine['conditioning'][:,0])),
            'coherent_interpolation_or_old_contacts_maximum':np.max(abs(fine['contacts']),axis=0).tolist()}
    cold_norm = read(ROOT/'frozen-evolution.json')['metadata']['cold']['cold_density_norm']
    for branch in ('old','coherent'):
        fine = history('cold',64,branch,1)
        coarse = history('cold',32,branch,1)
        sparse2 = history('cold',64,branch,2)
        sparse4 = history('cold',64,branch,4)
        error = maximum(fine['physical'][:,0]-fine['reference_source'][:,0])
        paired = maximum(fine['physical'][:,0]-coarse['physical'][:,0])+maximum(fine['reference_source'][:,0]-coarse['reference_source'][:,0])
        sample12 = maximum(fine['physical'][:,0]-sparse2['physical'][:,0])
        sample24 = maximum(sparse2['physical'][:,0]-sparse4['physical'][:,0])
        rounding = 256*np.finfo(float).eps*maximum(fine['physical'])
        gate = ratio(error+paired+max(sample12,sample24)+rounding,cold_norm)
        gate.update(residual=error,steps=paired,sampling12=sample12,sampling24=sample24,rounding=rounding)
        result['cold'][branch] = {'density':gate,'pressure_current_structural_zero':bool(np.all(fine['physical'][:,1:]==0)),
            'sampling_shrinks':bool(sample12<=sample24+rounding)}
    result['all_replay_budgets_pass'] = all(item['full_budget']['passed'] for report in result['heavy'].values() for item in report['sources'].values()) and all(
        report['density']['passed'] for report in result['cold'].values()) and all(report['pressure_work_budget']['passed'] and report['physical_exchange']['passed'] for report in result['heavy'].values())
    result['numerical_estimates_not_rigorous_continuum_bounds'] = True
    result['earlier_coefficient_only_closures_still_rejected'] = True
    return result


if __name__=='__main__':
    with worker('score'):
        inputs()
        result = calculate()
        write(ROOT/'science-score.json',result)
        print(json.dumps(result),flush=True)
