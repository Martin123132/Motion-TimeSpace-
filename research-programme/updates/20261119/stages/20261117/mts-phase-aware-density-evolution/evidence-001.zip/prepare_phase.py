from phase_math import *
import sympy as symbolic


def prove():
    phi,velocity,displacement,speed,beta,mu,hubble,rate,wave,metric,field_contact,velocity_contact,hubble_prime = symbolic.symbols(
        'Phi V f g beta mu H r k z F G Hp',real=True)
    mass2 = mu**2
    s_value = 4*mass2/(4*mass2+wave**2)
    coefficient = 1-s_value
    kappa = symbolic.Rational(3,2)*hubble*s_value
    density = beta*(velocity*speed+mass2*phi*displacement)
    pressure = beta*(velocity*speed-mass2*phi*displacement)
    current = beta*wave*velocity*displacement
    phase = velocity*displacement+phi*speed
    dressed = density+beta*kappa*phase
    wronskian = beta*mu*(velocity*displacement-phi*speed)
    derivatives = {phi:velocity+field_contact,velocity:-2*hubble*velocity-mass2*phi+velocity_contact,
        displacement:speed,speed:-2*hubble*speed-(wave**2+mass2)*displacement-wave*velocity*metric,
        beta:rate*beta,mu:rate*mu,hubble:hubble_prime}
    def derivative(expression):
        return sum(symbolic.diff(expression,variable)*value for variable,value in derivatives.items())
    expansion = beta*(s_value*(2*hubble**2-hubble_prime-hubble*rate)-2*hubble*rate*s_value*coefficient)*phase/2
    forcing = beta*hubble*s_value*wave*phi*velocity*metric/2
    contact = -beta*hubble*s_value*(velocity_contact*displacement+field_contact*speed)/2
    expected_dressed = -3*hubble*coefficient*density-wave*current-wave*beta*velocity**2*metric-3*(expansion+forcing+contact)+(
        rate-hubble)*(2*density-pressure)+beta*(velocity_contact*speed+mass2*field_contact*displacement)
    expected_phase = 2*(rate-hubble)*wronskian+beta*mu*(wave**2*phi*displacement+wave*phi*velocity*metric+
        velocity_contact*displacement-field_contact*speed)
    transform = symbolic.Matrix([[symbolic.diff(dressed,displacement),symbolic.diff(dressed,speed)],
                                 [symbolic.diff(wronskian,displacement),symbolic.diff(wronskian,speed)]])
    delta = velocity**2+mass2*phi**2+2*kappa*phi*velocity
    inverse_displacement = (phi*dressed/beta+(velocity+kappa*phi)*wronskian/(beta*mu))/delta
    inverse_speed = (velocity*dressed/beta-(mass2*phi+kappa*velocity)*wronskian/(beta*mu))/delta
    checks = {
        'matched_density_derivative':symbolic.simplify(derivative(dressed)-expected_dressed)==0,
        'relative_phase_derivative':symbolic.simplify(derivative(wronskian)-expected_phase)==0,
        'determinant':symbolic.simplify(transform.det()+beta**2*mu*delta)==0,
        'inverse_field':symbolic.simplify(inverse_displacement-displacement)==0,
        'inverse_velocity':symbolic.simplify(inverse_speed-speed)==0,
        'positive_square_plus':symbolic.expand(velocity**2+mass2*phi**2-2*mu*phi*velocity-(velocity-mu*phi)**2)==0,
        'positive_square_minus':symbolic.expand(velocity**2+mass2*phi**2+2*mu*phi*velocity-(velocity+mu*phi)**2)==0,
        'uniform_kappa_bound_identity':symbolic.simplify(symbolic.Rational(3,2)*hubble/wave-kappa/mu-
            3*hubble*(2*mu-wave)**2/(2*wave*(4*mu**2+wave**2)))==0,
    }
    require(all(checks.values()),'exact phase-aware algebra')
    return {name:bool(value) for name,value in checks.items()}


def prepare():
    require(digest(CYCLE/'closeout.json')==CONFIG['cycle_seal'],'accepted previous stage')
    mapping = read(CYCLE/'inputs.json')
    mapping[str(CYCLE/'closeout.json')] = CONFIG['cycle_seal']
    for name,entry in read(CYCLE/'closeout.json')['artifacts'].items():
        mapping[str(CYCLE/name)] = entry['sha256']
    check_inputs(mapping)
    write(ROOT/'frozen-norms.json',read(PRESSURE/'frozen-norms.json'))
    write(ROOT/'symbolic.json',{'checks':prove(),'passed':True})
    metadata = {}
    for case in CONFIG['cases']:
        prepared,_,background,_,_ = EX.problem(case)
        metadata[case] = {'max_step32':float(prepared['elapsed'][8])/32,'max_step64':float(prepared['elapsed'][8])/64,
            'cold_normalization':float(prepared['cold_normalization'])}
        reference = load(METRIC/(case+'-reference-metric.npz'))['packet']
        material = reference[:,:84].reshape(len(reference),7,12)
        beta = field(reference,'scale')/float(prepared['density0'])
        if case=='cold':
            metadata[case]['cold_density_norm'] = maximum(beta*material[:,0,3])
        else:
            state = load(GAP/'heavy-live-64-terminal.npz')
            first = int(state['dimensions'][3])+2
            metadata[case]['field_units'] = state['state_units'][first:first+2].tolist()
        require(metadata[case]['max_step64']>0,'retained positive steps')
    write(ROOT/'frozen-evolution.json',{'utc':datetime.now(timezone.utc).isoformat(),'metadata':metadata,
        'runs':{'heavy':['32 stride1','64 stride1','64 stride2','64 stride4'],'cold':'32/64 and stride1/2/4 exact metric antiderivative'},
        'source_scope':'saved future metric/background only; initial scalar once, future scalar used for score only',
        'density_phase_evolution_units':'both original934 heavy density norm; physical f/g use retained state_units',
        'numerical_norms_frozen_before_replay':True})
    for path in sorted(ROOT.iterdir()):
        if path.suffix in ('.py','.json','.md') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix=='.py':
                compile(path.read_text(encoding='utf-8'),str(path),'exec')
            mapping[str(path)] = digest(path)
    write(ROOT/'inputs.json',mapping)
    check_inputs(mapping)
    print(json.dumps({'frozen_inputs':len(mapping),'metadata':metadata,'algebra':True}),flush=True)


if __name__=='__main__':
    with worker('prepare'):
        prepare()
