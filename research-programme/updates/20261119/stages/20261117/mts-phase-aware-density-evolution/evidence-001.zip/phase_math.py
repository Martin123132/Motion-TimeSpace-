from restart_bridge import *
PRESSURE = Path(CONFIG['pressure_directory'])
CYCLE = Path(CONFIG['cycle_directory'])
sys.path.insert(0,str(PRESSURE))
from pressure_math import Profile, background_values
from scipy.interpolate import CubicHermiteSpline


class Forcing:
    def __init__(self,profile,stride):
        self.branch = profile.branch
        self.model, self.background = profile.model, profile.background
        self.rho0 = float(profile.prepared['density0'])
        self.width = profile.width
        indices = np.unique(np.r_[np.arange(0,len(profile.times),stride),len(profile.times)-1])
        columns = list(range(profile.width))+[profile.vector.shape[1]-1]
        self.times = profile.times.copy()
        self.source = CubicHermiteSpline(profile.times[indices],profile.vector[indices][:,columns],
            profile.derivative[indices][:,columns],axis=0,extrapolate=False)
        self.selected = indices

    def values(self,clock):
        times = np.atleast_1d(clock).astype(float)
        source = self.source(times)
        actual = self.source(times,1)
        values = background_values(times,source[:,:self.width],self.branch,self.background,self.model)
        if self.branch:
            scale = values['scale']
            rate = actual[:,0]/scale
            phi_prime,velocity_prime = actual[:,1:self.width:2],actual[:,2:self.width:2]
            external = np.array([self.model.external(float(item))[1] for item in scale])
            density_prime = rate*external+np.sum(values['velocity']*velocity_prime+rate[:,None]*values['mass']*values['phi']**2+
                values['mass']*values['phi']*phi_prime,axis=1)
            values.update(rate=rate,hubble_prime=density_prime/(6*values['hubble']),
                field_defect=phi_prime-values['velocity'],velocity_defect=velocity_prime+2*values['hubble'][:,None]*values['velocity']+values['mass']*values['phi'])
            values['derivative'] = actual[:,:self.width]
        values['metric'] = source[:,-1]
        return values

    def at(self,clock):
        values = self.values(clock)
        scalar = 1
        result = {name:float(values[name][0]) for name in ('scale','hubble','hubble_prime','rate','metric')}
        result.update(phi=float(values['phi'][0,scalar]),velocity=float(values['velocity'][0,scalar]),
            mass2=float(values['mass'][0,scalar]),field_contact=float(values['field_defect'][0,scalar]),
            velocity_contact=float(values['velocity_defect'][0,scalar]),beta=float(values['scale'][0]/self.rho0))
        result['mu'] = np.sqrt(result['mass2'])
        result['s'] = 4*result['mass2']/(4*result['mass2']+CONFIG['retained_comoving_wave']**2)
        result['c'] = 1-result['s']
        result['kappa'] = 1.5*result['hubble']*result['s']
        result['energy'] = result['velocity']**2+result['mass2']*result['phi']**2
        result['delta'] = result['energy']+2*result['kappa']*result['phi']*result['velocity']
        require(result['mu']>0 and result['energy']>0 and abs(result['kappa'])/result['mu']<1 and result['delta']>0,'regular phase transformation')
        return result


def stress(values,fields):
    phi,velocity,mass2,beta = (values[name] for name in ('phi','velocity','mass2','beta'))
    displacement,speed = fields
    return beta*np.array([velocity*speed+mass2*phi*displacement,
        CONFIG['retained_comoving_wave']*velocity*displacement,velocity*speed-mass2*phi*displacement])


def forward(values,fields):
    phi,velocity,mass2,beta,mu,kappa = (values[name] for name in ('phi','velocity','mass2','beta','mu','kappa'))
    displacement,speed = fields
    return beta*np.array([(mass2*phi+kappa*velocity)*displacement+(velocity+kappa*phi)*speed,
                         mu*(velocity*displacement-phi*speed)])


def inverse(values,coordinates):
    phi,velocity,mass2,beta,mu,kappa,delta = (values[name] for name in ('phi','velocity','mass2','beta','mu','kappa','delta'))
    dressed = coordinates[0]/beta
    wronskian = coordinates[1]/(beta*mu)
    return np.array([(phi*dressed+(velocity+kappa*phi)*wronskian)/delta,
                     (velocity*dressed-(mass2*phi+kappa*velocity)*wronskian)/delta])


def field_rhs(values,fields):
    displacement,speed = fields
    wave = CONFIG['retained_comoving_wave']
    return np.array([speed,-2*values['hubble']*speed-(wave**2+values['mass2'])*displacement-wave*values['velocity']*values['metric']])


def transformed_rhs(values,coordinates):
    displacement,speed = inverse(values,coordinates)
    phi,velocity,mass2,beta,mu,hubble,rate,metric,s_value,coefficient,field_contact,velocity_contact,hubble_prime = (
        values[name] for name in ('phi','velocity','mass2','beta','mu','hubble','rate','metric','s','c','field_contact','velocity_contact','hubble_prime'))
    wave = CONFIG['retained_comoving_wave']
    density,current,pressure = stress(values,(displacement,speed))
    phase_current = velocity*displacement+phi*speed
    s_prime = 2*rate*s_value*coefficient
    expansion = .5*beta*(s_value*(2*hubble**2-hubble_prime-hubble*rate)-hubble*s_prime)*phase_current
    forcing = .5*beta*hubble*s_value*wave*phi*velocity*metric
    contact = -.5*beta*hubble*s_value*(velocity_contact*displacement+field_contact*speed)
    density_contact = (rate-hubble)*(2*density-pressure)+beta*(velocity_contact*speed+mass2*field_contact*displacement)
    dressed_prime = -3*hubble*coefficient*density-wave*current-wave*beta*velocity**2*metric-3*(expansion+forcing+contact)+density_contact
    phase_prime = 2*(rate-hubble)*coordinates[1]+beta*mu*(wave**2*phi*displacement+wave*phi*velocity*metric+
                                                      velocity_contact*displacement-field_contact*speed)
    return np.array([dressed_prime,phase_prime]),np.array([hubble*pressure,-wave*current,-wave*beta*velocity**2*metric,density_contact])


def matrix_identity(values,fields):
    phi,velocity,mass2,beta,mu,hubble,rate,kappa,s_value,coefficient = (
        values[name] for name in ('phi','velocity','mass2','beta','mu','hubble','rate','kappa','s','c'))
    phi_prime = velocity+values['field_contact']
    velocity_prime = -2*hubble*velocity-mass2*phi+values['velocity_contact']
    kappa_prime = 1.5*(values['hubble_prime']*s_value+2*hubble*rate*s_value*coefficient)
    first = mass2*phi+kappa*velocity
    second = velocity+kappa*phi
    first_prime = 2*rate*mass2*phi+mass2*phi_prime+kappa_prime*velocity+kappa*velocity_prime
    second_prime = velocity_prime+kappa_prime*phi+kappa*phi_prime
    transform = beta*np.array([[first,second],[mu*velocity,-mu*phi]])
    derivative = beta*np.array([[rate*first+first_prime,rate*second+second_prime],
                               [mu*(2*rate*velocity+velocity_prime),-mu*(2*rate*phi+phi_prime)]])
    return derivative@fields+transform@field_rhs(values,fields),transform,derivative
