from restart_support import *
import importlib.metadata


if __name__=='__main__':
    check_inputs(read(ROOT/'inputs.json'))
    science = read(ROOT/'science-score.json')
    verification = read(ROOT/'verification.json')
    require(science['all_replay_budgets_pass'] and verification['passed'],'verified conditional phase replay')
    require(all(item['passed'] for report in science['heavy'].values() for item in report['fields'].values()),'physical field reconstructions pass')
    require(all(not item['deliberately_unmatched']['passed'] for report in science['heavy'].values() for item in report['sources'].values()),'initial-state negative controls fail')
    workers = {path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    require(all(item['exited'] for item in workers.values()),'exact worker identities exited')
    require(not list(ROOT.glob('*-failure.json')),'no omitted failed worker')
    require(not (ROOT/'__pycache__').exists(),'no bytecode')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write(ROOT/'cleanup.json',{'workers':workers,'all_exited':True,'native_owners_started':0,'temporary_tools':[],
        'other_processes_changed':False,'python':sys.version,'foreground_preflight_exited':True,
        'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','sympy','psutil')}})
    artifacts = {str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size}
        for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    result = {'stage':'Regular phase-aware density evolution','utc':datetime.now(timezone.utc).isoformat(),
        'completed':True,'technical_checks':verification['count'],'verification_passed':True,'all_replay_budgets_pass':True,
        'conditional_replay_not_forward_forecast':True,'new_native_hierarchy_evolution':False,'parameters_fitted':0,
        'deliberate_initial_mismatch_detected':True,'earlier_failures_preserved':True,
        'frozen_inputs':len(read(ROOT/'inputs.json')),'workers_exited':len(workers),'github':False,'artifacts':artifacts}
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),'bytes':sum(item['bytes'] for item in artifacts.values()),
        'workers_exited':len(workers),'closer':identity(psutil.Process())}),flush=True)
