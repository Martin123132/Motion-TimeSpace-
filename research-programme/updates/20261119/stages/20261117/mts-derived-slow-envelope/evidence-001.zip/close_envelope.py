from restart_support import *
import importlib.metadata


if __name__ == '__main__':
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    check_inputs(read(ROOT/'inputs.json'))
    score = read(ROOT/'science-score.json')
    verification = read(ROOT/'verification.json')
    require(verification['passed'], 'technical verification passed')
    combined = read(ROOT/'combined-budget.json')
    require(combined['passed'] and combined['accepted_orders']==score['accepted_orders'], 'combined source budgets')
    workers = {path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    expected = {'prepare','prepare-resume','cold','score','verify','combined-budget'}
    expected.update(window+'-'+branch+'-'+str(steps)+'-stride'+str(stride)
        for window in CONFIG['windows'] for branch in ('old','coherent')
        for steps,stride in ((32,1),(64,1),(64,2),(64,4)))
    require(set(workers)=={label+'-start.json' for label in expected},'complete task worker inventory')
    require(all(item['exited'] for item in workers.values()),'all exact task workers exited')
    for label in expected-{'prepare'}:
        start, end = read(ROOT/(label+'-start.json')), read(ROOT/(label+'-end.json'))
        require(end['completed'] and all(start[key]==end[key] for key in ('pid','created','command')), 'successful identity-matched receipt: '+label)
    failures = {path.name:read(path) for path in ROOT.glob('*-failure.json')}
    require(set(failures)=={'prepare-failure.json'},'only documented preparation failure')
    require('not JSON serializable' in failures['prepare-failure.json']['error'],'documented report-serialization failure')
    require(not list(ROOT.glob('*-owner-release.json')),'no new native owner created')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    for name in ('DERIVATION.md','RESULTS.md','NEXT.md','PREPARATION-REPAIR.md'):
        require((ROOT/name).is_file(),'saved explanation: '+name)
    closer = identity(process)
    write(ROOT/'cleanup.json',{'workers':workers,'all_exited':True,'preserved_failures':failures,
        'native_owners_created':0,'temporary_tools':[],'other_processes_changed':False,
        'closer_identity':closer,'closer_exit_verification':'required after foreground command returns',
        'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','sympy','psutil')}})
    artifacts = {str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size}
        for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    result = {'stage':'Derived slow envelope with controlled phase corrections','utc':datetime.now(timezone.utc).isoformat(),
        'completed':True,'technical_checks':verification['count'],'verification_passed':True,
        'exact_controls_pass':score['exact_controls_pass'],'baseline_pass':score['baseline_pass'],
        'accepted_orders':score['accepted_orders'],'conditional_replay_not_live_forecast':True,
        'new_native_hierarchy_evolution':False,'parameters_fitted':0,'earlier_failures_preserved':True,
        'frozen_inputs':len(read(ROOT/'inputs.json')),'workers_exited':len(workers),
        'github':False,'artifacts':artifacts}
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),
        'bytes':sum(item['bytes'] for item in artifacts.values()),'workers_exited':len(workers),
        'accepted_orders':score['accepted_orders'],'closer':closer}),flush=True)
