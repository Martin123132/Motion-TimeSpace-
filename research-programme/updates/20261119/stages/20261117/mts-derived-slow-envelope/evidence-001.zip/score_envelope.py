from envelope_math import *
import math
MODES = ('primitive','exact_envelope','bare_envelope','first_correction','second_correction')


def budget(residual, step, sampling, reference, amplitude, norm):
    rounding = 64*np.finfo(float).eps*float(amplitude)
    result = ratio(float(residual+step+sampling+reference+rounding), float(norm))
    result.update(residual=float(residual),step=float(step),sampling=float(sampling),reference=float(reference),rounding=rounding)
    return result


def calculate():
    report = {'windows':{}, 'future_forcing_conditional_replay':True}
    for window in CONFIG['windows']:
        report['windows'][window] = {}
        for branch in ('old','coherent'):
            def read_run(steps, stride):
                return load(ROOT/(window+'-'+branch+'-'+str(steps)+'-stride'+str(stride)+'.npz'))
            high, low, sparse, sparse_more = read_run(64,1), read_run(32,1), read_run(64,2), read_run(64,4)
            require(all(np.array_equal(high['time'],item['time']) for item in (low,sparse,sparse_more)), 'unchanged shared clocks')
            norms = read(ROOT/'full-norms.json')['heavy']['source_norm']
            modes = {}
            for mode, name in enumerate(MODES):
                checks = {}
                for component, source in enumerate(('density','current','pressure')):
                    checks[source] = budget(maximum(high['physical'][:,mode,component]-high['reference_source'][:,component]),
                        maximum(high['physical'][:,mode,component]-low['physical'][:,mode,component]),
                        max(maximum(high['physical'][:,mode,component]-sparse['physical'][:,mode,component]),
                            maximum(sparse['physical'][:,mode,component]-sparse_more['physical'][:,mode,component])),
                        maximum(high['reference_source'][:,component]-low['reference_source'][:,component]),
                        maximum(high['rounding_envelope'][:,mode,component]+low['rounding_envelope'][:,mode,component]),norms[component])
                checks['pressure_work'] = budget(maximum(high['pressure_work'][:,mode]-high['reference_pressure']),
                    maximum(high['pressure_work'][:,mode]-low['pressure_work'][:,mode]),
                    max(maximum(high['pressure_work'][:,mode]-sparse['pressure_work'][:,mode]),
                        maximum(sparse['pressure_work'][:,mode]-sparse_more['pressure_work'][:,mode])),
                    maximum(high['reference_pressure']-low['reference_pressure']),
                    maximum(abs(high['pressure_work'][:,mode])+abs(high['reference_pressure'])),norms[0])
                modes[name] = {'checks':checks,'passed':all(item['passed'] for item in checks.values())}
            conditional = {}
            envelope_norm = maximum(high['normalized'][:,2:4])
            for order in CONFIG['orders']:
                source_bounds = {}
                for component, source in enumerate(('density','current','pressure')):
                    source_bounds[source] = budget(maximum(high['source_bound'][:,order,component]),
                        maximum(high['source_bound'][:,order,component]-low['source_bound'][:,order,component]),
                        max(maximum(high['source_bound'][:,order,component]-sparse['source_bound'][:,order,component]),
                            maximum(sparse['source_bound'][:,order,component]-sparse_more['source_bound'][:,order,component])),
                        0.,maximum(high['rounding_envelope'][:,order+2,component]),norms[component])
                excess = max(0.,float(np.max(high['envelope_error'][:,order]-high['envelope_bound'][:,order])))
                bound_test = ratio(excess,envelope_norm,CONFIG['algebra_tolerance'])
                conditional[str(order)] = {'source_bounds':source_bounds,'source_bound_below_gate':all(item['passed'] for item in source_bounds.values()),
                    'observed_error_within_evaluated_bound':bound_test,
                    'max_observed_envelope_error':maximum(high['envelope_error'][:,order]),
                    'max_evaluated_envelope_bound':maximum(high['envelope_bound'][:,order])}
            equivalence = [budget(maximum(high['physical'][:,0,component]-high['physical'][:,1,component]),
                maximum((high['physical'][:,0,component]-high['physical'][:,1,component])-(low['physical'][:,0,component]-low['physical'][:,1,component])),
                0.,0.,maximum(high['rounding_envelope'][:,0,component]+high['rounding_envelope'][:,1,component]),norms[component]) for component in range(3)]
            coefficient_integral = high['coefficient_integral']
            operator_checks = [ratio(max(0.,float(np.max(high['operator_norm'][:,index]-coefficient_integral**(index+1)/math.factorial(index+1)))),1.,CONFIG['algebra_tolerance']) for index in range(2)]
            report['windows'][window][branch] = {'modes':modes,'conditional_remainder':conditional,
                'coordinate_equivalence':equivalence,'operator_bound_checks':operator_checks,
                'max_coefficient_integral':float(np.max(coefficient_integral)),
                'max_actual_K1':maximum(high['operator_norm'][:,0]),'max_actual_K2':maximum(high['operator_norm'][:,1])}
        cold = {}
        for branch in ('old','coherent'):
            def cold_run(steps,stride):
                return load(ROOT/(window+'-cold-'+branch+'-'+str(steps)+'-stride'+str(stride)+'.npz'))
            high,low,sparse,sparse_more = cold_run(64,1),cold_run(32,1),cold_run(64,2),cold_run(64,4)
            norm = read(ROOT/'full-norms.json')['cold']['source_norm'][0]
            cold[branch] = budget(maximum(high['physical'][:,0]-high['reference_source'][:,0]),
                maximum(high['physical'][:,0]-low['physical'][:,0]),
                max(maximum(high['physical'][:,0]-sparse['physical'][:,0]),maximum(sparse['physical'][:,0]-sparse_more['physical'][:,0])),
                maximum(high['reference_source'][:,0]-low['reference_source'][:,0]),
                maximum(abs(high['physical'][:,0])+abs(high['reference_source'][:,0])),norm)
        report['windows'][window]['cold'] = cold
    branches = [report['windows'][window][branch] for window in CONFIG['windows'] for branch in ('old','coherent')]
    report['exact_controls_pass'] = all(item['modes'][mode]['passed'] for item in branches for mode in ('primitive','exact_envelope'))
    report['baseline_pass'] = all(item['passed'] for window in report['windows'].values() for item in window['cold'].values())
    report['accepted_orders'] = [order for order in CONFIG['orders'] if report['exact_controls_pass'] and report['baseline_pass'] and
        all(item['modes'][MODES[order+2]]['passed'] and item['conditional_remainder'][str(order)]['source_bound_below_gate'] and
            item['conditional_remainder'][str(order)]['observed_error_within_evaluated_bound']['passed'] for item in branches)]
    return report


if __name__ == '__main__':
    with worker('score'):
        inputs()
        result = calculate()
        write(ROOT/'science-score.json',result)
        print(json.dumps({'exact_controls_pass':result['exact_controls_pass'],'baseline_pass':result['baseline_pass'],'accepted_orders':result['accepted_orders']}),flush=True)
