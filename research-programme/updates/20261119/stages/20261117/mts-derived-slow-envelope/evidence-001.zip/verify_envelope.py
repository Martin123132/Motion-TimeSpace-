from score_envelope import *


def verify():
    inputs()
    result = read(ROOT/'science-score.json')
    checks = {'score_replay':calculate()==result, 'algebra_controls':read(ROOT/'algebra-controls.json')['passed']}
    for window in CONFIG['windows']:
        for branch in ('old','coherent'):
            for steps,stride in ((32,1),(64,1),(64,2),(64,4)):
                label = window+'-'+branch+'-'+str(steps)+'-stride'+str(stride)
                data = load(ROOT/(label+'.npz'))
                checks[label+'_finite'] = all(bool(np.isfinite(value).all()) for value in data.values())
                checks[label+'_report_complete'] = read(ROOT/(label+'-result.json'))['completed']
                checks[label+'_no_initial_memory'] = bool(np.all(data['normalized'][0,10:22] == 0))
                checks[label+'_initial_envelope_matched'] = all(np.array_equal(data['normalized'][0,2:4],data['normalized'][0,offset:offset+2]) for offset in (4,6,8))
                checks[label+'_positive_error_allowance'] = float(np.min(data['envelope_bound'])) >= -1e-12
                checks[label+'_inverse_guarantee'] = float(np.max(data['coefficient_integral']+.5*data['coefficient_integral']**2)) < 1
                checks[label+'_known_clock'] = np.array_equal(data['time'],load(paths(window,'heavy',steps)[0])['time'])
                for checkpoint_path in ROOT.glob(label+'-batch*.npz'):
                    checkpoint_value = load(checkpoint_path)
                    index = int(checkpoint_value['completed_segments'])
                    checks[checkpoint_path.stem+'_state'] = np.array_equal(checkpoint_value['normalized'],data['normalized'][index])
                    checks[checkpoint_path.stem+'_input'] = str(checkpoint_value['known_input_sha']) == digest(paths(window,'heavy',steps)[0])
            item = result['windows'][window][branch]
            checks[window+'_'+branch+'_coordinate_equivalence'] = all(value['passed'] for value in item['coordinate_equivalence'])
            checks[window+'_'+branch+'_coefficient_bounds'] = all(value['passed'] for value in item['operator_bound_checks'])
            for order in CONFIG['orders']:
                checks[window+'_'+branch+'_error_bound'+str(order)] = item['conditional_remainder'][str(order)]['observed_error_within_evaluated_bound']['passed']
            for steps in CONFIG['steps']:
                for stride in CONFIG['strides']:
                    label = window+'-cold-'+branch+'-'+str(steps)+'-stride'+str(stride)
                    data = load(ROOT/(label+'.npz'))
                    checks[label+'_finite'] = all(bool(np.isfinite(value).all()) for value in data.values())
                    checks[label+'_zero_owned_pressure_current'] = bool(np.all(data['physical'][:,1:] == 0))
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['no_bytecode'] = not list(ROOT.rglob('__pycache__'))
    passed = all(checks.values())
    write(ROOT/'verification.json',{'passed':passed,'count':len(checks),'checks':checks,
        'exact_controls_pass':result['exact_controls_pass'],'baseline_pass':result['baseline_pass'],'accepted_orders':result['accepted_orders']})
    require(passed,'technical verification: '+str([name for name,value in checks.items() if not value]))
    print(json.dumps({'checks':len(checks),'passed':passed,'accepted_orders':result['accepted_orders']}),flush=True)


if __name__ == '__main__':
    with worker('verify'):
        verify()
