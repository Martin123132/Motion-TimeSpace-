from score_envelope import *


if __name__ == '__main__':
    with worker('combined-budget'):
        inputs()
        score = read(ROOT/'science-score.json')
        combined, scales = {}, {}
        checks = {}
        for window in CONFIG['windows']:
            combined[window], scales[window] = {}, {}
            for branch, name in enumerate(('old','coherent')):
                case = score['windows'][window][name]
                combined[window][name] = {}
                for order in CONFIG['orders']:
                    components = {}
                    for component in ('density','current','pressure'):
                        exact = case['modes']['exact_envelope']['checks'][component]
                        remainder = case['conditional_remainder'][str(order)]['source_bounds'][component]
                        require(exact['scale'] == remainder['scale'], 'same original source norm')
                        value = ratio(exact['error']+remainder['error'],exact['scale'])
                        value.update(exact_replay_error=exact['error'],conditional_truncation_bound=remainder['error'])
                        components[component] = value
                    combined[window][name][str(order)] = components
                saved = profile(window,'heavy',64,branch)
                forcing = Forcing(saved,1)
                values = [forcing.at(float(clock)) for clock in saved.times]
                terms = [coefficients(item) for item in values]
                scales[window][name] = {
                    'mu_range_Mpc_inverse':[min(item['mu'] for item in values),max(item['mu'] for item in values)],
                    'beat_range_Mpc_inverse':[min(item['beat'] for item in terms),max(item['beat'] for item in terms)],
                    'max_abs_H_over_mu':max(abs(item['hubble'])/item['mu'] for item in values),
                    'max_k_over_mu':max(CONFIG['retained_comoving_wave']/item['mu'] for item in values),
                    'max_beat_over_mu':max(item['beat']/value['mu'] for item,value in zip(terms,values)),
                    'max_abs_phase_contact_over_mu':max(abs(item['contact'])/value['mu'] for item,value in zip(terms,values)),
                    'minimum_theta_prime_Mpc_inverse':min(item['theta_prime'] for item in terms)}
        accepted = [order for order in CONFIG['orders'] if order in score['accepted_orders'] and
            all(item['passed'] for window in combined.values() for branch in window.values() for item in branch[str(order)].values())]
        checks['combined_acceptance_preserves_scored_orders'] = accepted == score['accepted_orders']
        checks['positive_frequency_support'] = all(item['mu_range_Mpc_inverse'][0]>0 and item['minimum_theta_prime_Mpc_inverse']>0 for window in scales.values() for item in window.values())
        write(ROOT/'combined-budget.json',{'checks':checks,'passed':all(checks.values()),'accepted_orders':accepted,
            'source_budgets':combined,'scale_diagnostics':scales,
            'scope':'Exact conditional replay budget plus derived conditional truncation bound; numerical estimates, not rigorous continuum enclosures.'})
        require(all(checks.values()),'combined source-budget audit')
        print(json.dumps({'accepted_orders':accepted,'scales':scales,
            'worst_second_order_combined_ratio':max(item['relative'] for window in combined.values() for branch in window.values() for item in branch['2'].values())}),flush=True)
