from envelope_math import *
import argparse
import sympy as symbolic


def algebra_controls():
    checks = {}
    slow = symbolic.Matrix(2, 2, symbolic.symbols('a0:4'))
    fast = symbolic.Matrix(2, 2, symbolic.symbols('c0:4'))
    first = symbolic.Matrix(2, 2, symbolic.symbols('b0:4'))
    second = symbolic.Matrix(2, 2, symbolic.symbols('d0:4'))
    vector = symbolic.Matrix(symbolic.symbols('v0:2'))
    forcing = symbolic.Matrix(symbolic.symbols('j0:2'))
    identity = symbolic.eye(2)
    for order, matrix, derivative, highest in (
            (0, identity, symbolic.zeros(2), identity),
            (1, identity+first, slow*first-first*slow+fast, first),
            (2, identity+first+second, slow*(first+second)-(first+second)*slow+fast*(identity+first), second)):
        actual = derivative*vector+matrix*slow*vector+forcing
        expected = (slow+fast)*matrix*vector+forcing-fast*highest*vector
        checks['order'+str(order)+'_exact_defect'] = all(symbolic.expand(item) == 0 for item in actual-expected)
    generator = np.random.default_rng(20261117)
    residuals = []
    for sample in range(40):
        values = dict(mu=float(generator.uniform(.2, 50)), hubble=float(generator.uniform(0, .07)),
            rate=float(generator.uniform(-.01, .08)), phi=float(generator.uniform(-2, 2)),
            velocity=float(generator.uniform(-3, 3)), field_contact=float(generator.uniform(-.01, .01)),
            velocity_contact=float(generator.uniform(-.01, .01)), metric=float(generator.uniform(-.3, .3)), beta=2.3)
        values['mass2'] = values['mu']**2
        terms = coefficients(values)
        native_matrix = np.array([[0., 1.], [-terms['omega']**2, -2*values['hubble']]])
        actual = (terms['slow']+terms['fast'])@terms['transform']
        expected = terms['transform_prime']+terms['transform']@native_matrix
        residuals.append(ratio(maximum(actual-expected), maximum(abs(actual)+abs(expected)), CONFIG['algebra_tolerance']))
        checks['inverse'+str(sample)] = maximum(terms['transform']@terms['inverse']-IDENTITY) < CONFIG['algebra_tolerance']
        checks['log_norm'+str(sample)] = abs(np.max(np.linalg.eigvalsh((terms['slow']+terms['fast']+(terms['slow']+terms['fast']).T)/2))-terms['gamma']) < CONFIG['algebra_tolerance']
        checks['fast_norm'+str(sample)] = abs(np.linalg.norm(terms['fast'], 2)-terms['fast_norm']) < CONFIG['algebra_tolerance']
    checks['rotating_generator'] = all(item['passed'] for item in residuals)
    free = []
    for mu in (.3, 2., 30., 300.):
        values = dict(mu=mu, mass2=mu*mu, hubble=0., rate=0., phi=1.7*np.cos(.37),
            velocity=-mu*1.7*np.sin(.37), field_contact=0., velocity_contact=0., metric=0., beta=2.3)
        initial = np.array([.17, -.09])
        initial_terms = coefficients(values)
        envelope = initial_terms['transform']@initial
        omega, beat = initial_terms['omega'], initial_terms['beat']
        for elapsed in (0., .031, .17, 1.3, 3.7):
            values['phi'] = 1.7*np.cos(mu*elapsed+.37)
            values['velocity'] = -mu*1.7*np.sin(mu*elapsed+.37)
            terms = coefficients(values)
            rotated = (np.cos(beat*elapsed)*IDENTITY+np.sin(beat*elapsed)*ROTATION)@envelope
            actual = terms['inverse']@rotated
            exact = np.array([initial[0]*np.cos(omega*elapsed)+initial[1]/omega*np.sin(omega*elapsed),
                -omega*initial[0]*np.sin(omega*elapsed)+initial[1]*np.cos(omega*elapsed)])
            check = ratio(maximum(actual-exact), maximum(abs(actual)+abs(exact)), CONFIG['algebra_tolerance'])
            source_check = ratio(maximum(terms['physical']@rotated-stress(values, exact)), maximum(abs(stress(values, exact))), CONFIG['algebra_tolerance'])
            free.append({'mu':mu, 'elapsed':elapsed, 'fields':check, 'source':source_check,
                'beat':beat, 'leading_beat':CONFIG['retained_comoving_wave']**2/(2*mu)})
    checks['exact_free_fields_sources'] = all(item['fields']['passed'] and item['source']['passed'] for item in free)
    require(all(checks.values()), 'analytic and algebra controls')
    return {'checks':checks, 'free':free, 'generator_residuals':residuals, 'passed':True}


def prepare():
    prior = Path(CONFIG['live_directory'])
    require(digest(prior/'closeout.json') == CONFIG['live_seal'], 'accepted live stage seal')
    mapping = read(prior/'inputs.json')
    mapping[str(prior/'closeout.json')] = CONFIG['live_seal']
    for name, item in read(prior/'closeout.json')['artifacts'].items():
        mapping[str(prior/name)] = item['sha256']
    check_inputs(mapping)
    write(ROOT/'full-norms.json', read(prior/'frozen-norms.json'))
    write(ROOT/'frozen-norms.json', read(PHASE_STATE/'frozen-norms.json'))
    write(ROOT/'algebra-controls.json', algebra_controls())
    metadata = {}
    for window in CONFIG['windows']:
        metadata[window] = {}
        for case in CONFIG['cases']:
            saved = profile(window, case, 64, 0)
            result = {'samples':len(saved.times), 'time':[float(saved.times[0]), float(saved.times[-1])],
                'cold_normalization':float(saved.prepared['cold_normalization']), 'checks':saved.checks}
            if case == 'heavy':
                values = Forcing(saved, 1).at(float(saved.times[0]))
                terms = coefficients(values)
                units = saved.terminal['state_units'][saved.first+2:saved.first+4]
                result['field_units'] = units.tolist()
                result['envelope_unit'] = float(max(np.sqrt(terms['omega'])*units[0], units[1]/np.sqrt(terms['omega'])))
            metadata[window][case] = result
    write(ROOT/'frozen-evolution.json', {'utc':datetime.now(timezone.utc).isoformat(), 'metadata':metadata,
        'orders':[0,1,2], 'before_comparison':True, 'future_forcing_conditional_replay':True,
        'error_gate':'original934 source norm2e-5; unchanged1e-10 algebra; no fitted coefficient',
        'runs':'32/64 stride1 plus64 stride2/4, both windows and branches; same baseline discipline'})
    for path in sorted(ROOT.iterdir()):
        if path.suffix in ('.py', '.json', '.md') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix == '.py':
                compile(path.read_text(encoding='utf-8'), str(path), 'exec')
            mapping[str(path)] = digest(path)
    write(ROOT/'inputs.json', mapping)
    inputs()
    print(json.dumps({'prepared':True,'algebra_checks':len(read(ROOT/'algebra-controls.json')['checks']), 'frozen_inputs':len(mapping)}), flush=True)


def run(window, branch, steps, stride):
    inputs()
    label = window+'-'+('old','coherent')[branch]+'-'+str(steps)+'-stride'+str(stride)
    saved = profile(window, 'heavy', steps, branch)
    forcing = Forcing(saved, stride)
    metadata = read(ROOT/'frozen-evolution.json')['metadata'][window]['heavy']
    field_units = np.array(metadata['field_units'])
    envelope_unit = metadata['envelope_unit']
    density_unit = read(ROOT/'full-norms.json')['heavy']['source_norm'][0]
    initial_fields = saved.perturbation[0, 1]
    initial_terms = coefficients(forcing.at(float(saved.times[0])))
    initial_envelope = initial_terms['transform']@initial_fields/envelope_unit
    current = np.zeros(27)
    current[:2] = initial_fields/field_units
    for offset in (2,4,6,8):
        current[offset:offset+2] = initial_envelope
    states = np.empty((len(saved.times), len(current)))
    states[0] = current
    calls = 0
    def rhs(clock, state):
        nonlocal calls
        calls += 1
        if calls % 128 == 0:
            guard()
        return dynamics(forcing.at(clock), state, field_units, envelope_unit, density_unit)
    for position, (left, right) in enumerate(zip(saved.times[:-1], saved.times[1:])):
        guard()
        solution = solve_ivp(rhs, (float(left),float(right)), current, method='DOP853', t_eval=[right],
            max_step=float(saved.prepared['elapsed'][8])/steps, rtol=CONFIG['rtol'], atol=CONFIG['normalized_atol'])
        require(solution.success, 'derived envelope solve')
        current = solution.y[:, -1]
        states[position+1] = current
        if (position+1)%CONFIG['batch_boundaries'] == 0 or position == len(saved.times)-2:
            np.savez_compressed(ROOT/(label+'-batch'+str(position+1)+'.npz'), tau=np.array(right), normalized=current,
                completed_segments=np.array(position+1), known_input_sha=np.array(digest(paths(window,'heavy',steps)[0])))
    physical = np.empty((len(saved.times), 5, 3))
    rounding_envelope = np.empty_like(physical)
    fields = np.empty((len(saved.times), 5, 2))
    bound = np.empty((len(saved.times), 3, 3))
    envelope_error = np.empty((len(saved.times), 3))
    bound_operator = np.empty((len(saved.times), 2))
    identities = []
    for position, (clock, row) in enumerate(zip(saved.times, states)):
        values = forcing.at(float(clock))
        terms = coefficients(values)
        first, second = row[10:14].reshape(2,2), row[14:18].reshape(2,2)
        vectors = [terms['transform']@(row[:2]*field_units), row[2:4]*envelope_unit]
        vectors.extend(matrix@row[4+2*order:6+2*order]*envelope_unit for order, matrix in enumerate((IDENTITY, IDENTITY+first, IDENTITY+first+second)))
        for mode, vector in enumerate(vectors):
            physical[position, mode] = terms['physical']@vector
            fields[position, mode] = terms['inverse']@vector
            displacement, velocity = fields[position, mode]
            first_term = abs(values['velocity']*velocity)
            second_term = abs(values['mass2']*values['phi']*displacement)
            rounding_envelope[position, mode] = values['beta']*np.array([first_term+second_term,
                abs(CONFIG['retained_comoving_wave']*values['velocity']*displacement),first_term+second_term])
        for order in range(3):
            bound[position, order] = np.linalg.norm(terms['physical'], axis=1)*max(row[18+order], 0.)*envelope_unit
            envelope_error[position, order] = np.linalg.norm(vectors[1]-vectors[2+order])/envelope_unit
        bound_operator[position] = [np.linalg.norm(first, 2), np.linalg.norm(second, 2)]
        native_matrix = np.array([[0.,1.],[-terms['omega']**2,-2*values['hubble']]])
        expected = terms['transform_prime']+terms['transform']@native_matrix
        actual = (terms['slow']+terms['fast'])@terms['transform']
        identities.append(ratio(maximum(actual-expected), maximum(abs(expected)+abs(actual)), CONFIG['algebra_tolerance']))
    require(all(item['passed'] for item in identities), 'actual-background generator identity')
    source = saved.data['source']+(saved.data['source_change'] if branch else 0.)
    work = saved.data['work']+(saved.data['work_change'] if branch else 0.)
    np.savez_compressed(ROOT/(label+'.npz'), time=saved.times, normalized=states, physical=physical, fields=fields,
        rounding_envelope=rounding_envelope,
        reference_source=source, reference_fields=saved.perturbation[:,1],
        reference_pressure=-(work[:,0]-work[0,0])/3, pressure_work=states[:,22:27]*density_unit,
        source_bound=bound, envelope_error=envelope_error, operator_norm=bound_operator,
        envelope_bound=states[:,18:21], coefficient_integral=states[:,21])
    require(float(np.max(states[:,21]+.5*states[:,21]**2))<1, 'conservative inverse bound')
    write(ROOT/(label+'-result.json'), {'completed':True,'calls':calls,'segments':len(saved.times)-1,
        'native_profile_checks':saved.checks,'generator_identity_max':max(item['relative'] for item in identities),
        'max_inverse_bound':float(np.max(states[:,21]+.5*states[:,21]**2)),
        'future_forcing_conditional_replay':True,'orders':[0,1,2]})
    inputs()
    print(json.dumps({'label':label,'calls':calls,'complete':True}),flush=True)


def cold():
    inputs()
    for window in CONFIG['windows']:
        for steps in CONFIG['steps']:
            for branch, name in enumerate(('old','coherent')):
                saved = profile(window, 'cold', steps, branch)
                reference = saved.data['source']+(saved.data['source_change'] if branch else 0.)
                require(bool(np.all(reference[:,1:] == 0)), 'owned baseline current and pressure zero')
                normalization = float(saved.prepared['cold_normalization'])
                for stride in CONFIG['strides']:
                    forcing = Forcing(saved, stride)
                    primitive = forcing.source.antiderivative()
                    integral = (primitive(saved.times)-primitive(saved.times[0]))[:,-1]
                    physical = np.zeros_like(reference)
                    physical[:,0] = reference[0,0]-CONFIG['retained_comoving_wave']*normalization*integral
                    label = window+'-cold-'+name+'-'+str(steps)+'-stride'+str(stride)
                    np.savez_compressed(ROOT/(label+'.npz'),time=saved.times,physical=physical,reference_source=reference)
    write(ROOT/'cold-result.json',{'completed':True,'replays':24,'future_forcing_conditional_replay':True})
    inputs()
    print(json.dumps({'cold_replays':24,'complete':True}),flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=('prepare','heavy','cold'))
    parser.add_argument('--window', choices=CONFIG['windows'], default='gap')
    parser.add_argument('--branch', type=int, choices=(0,1), default=1)
    parser.add_argument('--steps', type=int, choices=CONFIG['steps'], default=64)
    parser.add_argument('--stride', type=int, choices=CONFIG['strides'], default=1)
    arguments = parser.parse_args()
    label = arguments.command if arguments.command != 'heavy' else arguments.window+'-'+('old','coherent')[arguments.branch]+'-'+str(arguments.steps)+'-stride'+str(arguments.stride)
    with worker(label):
        if arguments.command == 'prepare':
            prepare()
        elif arguments.command == 'cold':
            cold()
        else:
            run(arguments.window, arguments.branch, arguments.steps, arguments.stride)
