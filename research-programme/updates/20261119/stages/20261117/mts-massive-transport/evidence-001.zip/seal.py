from datetime import datetime, timezone
from bridge import HERE, digest, guard, need, read, save


def finish():
    guard()
    need((HERE/'RESULTS.md').is_file() and (HERE/'verification.json').is_file(),'verified report first')
    files={item.name:dict(bytes=item.stat().st_size,sha256=digest(item)) for item in sorted(HERE.iterdir()) if item.is_file() and item.name!='closeout.json'}
    save(HERE/'closeout.json',dict(time=datetime.now(timezone.utc).isoformat(),files=files))
    recorded=read(HERE/'closeout.json')['files']
    need(all(digest(HERE/key)==item['sha256'] for key,item in recorded.items()),'independent manifest reread')
    print(len(files),sum(item['bytes'] for item in files.values()),digest(HERE/'closeout.json'))


if __name__=='__main__':
    finish()
