from bridge import HERE, OLD, NAMES, TOL, digest, guard, np, read, save
from compare import SOURCES, WINDOW, forecast, integral
from pathlib import Path


def main():
    guard()
    budget=read(HERE/'transport-budget.json')
    bounds=np.log(budget['common_scale_bounds'])
    result={}
    for tag in ('light','fixed','lift','testg','native5'):
        totals={}
        offsets={}
        for case in ('cold','heavy'):
            selected=forecast(case,tag+'-raw')
            main=forecast(case,'reference-raw')
            clocks=main['x'][WINDOW]
            indices=np.searchsorted(selected['x'],clocks)
            need_match=np.array_equal(selected['x'][indices],clocks)
            if not need_match:
                raise ValueError('not same saved clocks')
            keys=['a','H','delta_cdm','delta_baryon','delta_photon','delta_neutrino','delta_nu','slip','pi_photon','mts_dp_s']
            if case=='heavy':
                keys.append('mts_dp_h')
            offsets[case]={key:float(selected[key][indices[0]]/main[key][1991]-1) for key in keys}
            totals[case]={key:integral({k:selected[k][indices] for k in ('a','H',key)},key,bounds)[0] for key in SOURCES}
        changes={}
        for key in SOURCES:
            contrast=totals['heavy'][key]-totals['cold'][key]
            changes[key]=contrast/budget['radiation'][key]['paired']['reference']-1
        result[tag]=dict(event_change_vs_reference=offsets,fixed_scale_integrals=totals,change_over_reference_contrast=changes)
    save(HERE/'physical-controls.json',dict(source=digest(Path(__file__)),tolerance=TOL,controls=result))


if __name__=='__main__':
    main()
