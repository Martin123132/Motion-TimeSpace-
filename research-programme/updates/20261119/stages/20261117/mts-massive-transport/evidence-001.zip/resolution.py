from pathlib import Path
import sys
import bridge
from bridge import HERE, SCANS, digest, evolve, save
from exact_run import model_library, raw_thermal


def run(case, tag):
    bridge.thermal=raw_thermal
    bridge.SOLVE=model_library()
    cap={'quarter':.0025,'eighth':.00125}[tag]
    SCANS[tag]=(24,272,16,cap,'table',True,0,False)
    evolve(case,tag,suffix='-raw')
    save(HERE/(case+'-'+tag+'-raw-engine.json'),dict(actual_dll=digest(HERE/'transport_exact.dll'),actual_source=digest(HERE/'transport_exact.c'),driver=digest(Path(__file__)),thermal=digest(HERE/'thermal_exact.inc')))


if __name__=='__main__':
    for item in sys.argv[1:]:
        run(*item.split(':'))
