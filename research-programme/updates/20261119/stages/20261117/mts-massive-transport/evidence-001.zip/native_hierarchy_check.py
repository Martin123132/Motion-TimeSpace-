from pathlib import Path
from bridge import HERE, POST, PRIOR, TOL, digest, guard, need, np, save
from scipy.interpolate import CubicHermiteSpline, PchipInterpolator
from scipy.special import roots_legendre


def verify(case):
    source=PRIOR/(case+'-physical-roots-capture.npz')
    with np.load(source) as data:
        state=data['reference']
        slopes=data['derivative_reference']/5
        signature=data['signature']
        clock=5*data['clock']
    mask=(signature[:,12]==1)&(signature[:,13]==0)
    need(mask[:9].all(),'actual material hierarchy uses high-k closure on both tested branches')
    ids=np.flatnonzero(mask)
    loc=signature[ids,4]-1
    density,flux,shear=(state[ids,loc+shift] for shift in (0,1,2))
    change,vdot,pidot=(slopes[ids,loc+shift] for shift in (0,1,2))
    cdm=slopes[ids,1]
    results={}
    for key,deriv,pred in [('density',change,4*cdm/3-flux),('momentum',vdot,(density-2*shear)/3),('fluid_shear',pidot,-3*shear/clock[ids]-change)]:
        diff=abs(deriv-pred)
        results[key]=dict(material_error_over_peak=max(diff[:9])/max(abs(deriv[:9])),full_error_over_peak=max(diff)/max(abs(deriv)),
                          material_passes=int(sum(diff[:9]<=TOL*abs(deriv[:9]))),rows_pass=int(sum(diff<=TOL*abs(deriv))))
    end=int(np.flatnonzero(~mask)[0]) if not mask.all() else len(mask)
    tau=clock[:end]
    need(np.all(np.diff(tau)>0),'ordered native fluid window')
    center=np.diff(tau)/2
    roots,weights=roots_legendre(4)
    samples=tau[:-1,None]+center[:,None]*(1+roots)
    predictions={}
    for label,interp in [('source_slope',CubicHermiteSpline(tau,density[:end],change[:end])),('density_only',PchipInterpolator(tau,density[:end]))]:
        cell=center*((samples**2*interp(samples))@weights)
        predictions[label]=-density[:end]+((shear[0]+density[0])*tau[0]**3+3*np.r_[0.,np.cumsum(cell)])/tau**3
    diff=abs(predictions['source_slope']-shear[:end])
    unc=abs(predictions['source_slope']-predictions['density_only'])
    results['one_initial_shear_then_density_only']=dict(material_forecasts=8,material_passes=int(sum((diff+unc)[1:9]<=TOL*abs(shear[1:9]))),
        full_forecasts=end-1,full_passes=int(sum((diff+unc)[1:]<=TOL*abs(shear[1:end]))),
        error_over_peak=max(diff)/max(abs(shear[:end])),interpolation_over_peak=max(unc)/max(abs(shear[:end])))
    return dict(capture=digest(source),points=len(clock),active=len(ids),material_configuration=dict(
        massless_configured_ell=int(signature[0,8]),massless_evolved_moments_on_active_UFA=3,
        massive_q=int(signature[0,30]),massive_ell=int(signature[0,40]),massive_truncated_fluid=bool(signature[0,70])),
        checks=results)


if __name__=='__main__':
    guard()
    sr=POST/'mts-integrated-defect-20261112/native/fortran'
    save(HERE/'native-hierarchy.json',dict(script=digest(Path(__file__)),layout_source=digest(sr/'camb_python.f90'),equations=digest(sr/'equations.f90'),tolerance=TOL,
         cases={case:verify(case) for case in ('cold','heavy')}))
