from bridge import HERE, NAMES, TOL, digest, guard, inputs, np, need, save
from compare import WINDOW, forecast, preparation
from scipy.interpolate import CubicSpline
from pathlib import Path


def experiment(case):
    config,native,field,_=preparation(case)
    shadow=forecast(case,'sharp-shadow')
    xs=shadow['x']
    with np.load(config['ref']) as source:
        mode=np.flatnonzero(source['modes']==5)[0]
        names=source['names'].tolist()
        full=source['values'][mode,:len(xs)]
        need(np.array_equal(5*source['conformal_time'][:len(xs)],xs),'exact history clocks')
    def get(key):
        return full[:,names.index(key)]
    wave=5.
    mscale=config['masses'][0]/wave
    aval=get('a')
    hub=get('H')/wave
    dc=get('delta_cdm')-shadow['delta_cdm']
    deta=(get('etak')-shadow['etak'])/wave
    dshear=-hub*get('v_newtonian_cdm')-shadow['geometry_shear']
    diff_hub=hub-shadow['H']/wave
    diff_w=(aval-shadow['a'])*(aval+shadow['a'])*mscale**2
    norm=abs(native['mts_dphi_s'][0])
    velocity=field[1](np.log(aval))/wave
    diff_vel=velocity-shadow['archived_velocity']/wave
    point=np.array([shadow['cdm_x'],velocity/norm,diff_vel/norm,hub,1+(aval*mscale)**2,
                    diff_hub,diff_w,shadow['shadow_dphi']/norm,shadow['shadow_dphidot']/wave/norm,dshear]).T
    initial=np.array([get('mts_dphi_s')[0]-shadow['shadow_dphi'][0],(get('mts_dphidot_s')[0]-shadow['shadow_dphidot'][0])/wave])/norm
    expected=native['mts_dp_s']
    event_a=aval[WINDOW]
    pot=(wave*mscale*event_a)**2*field[0](np.log(event_a))
    vel=wave*field[1](np.log(event_a))
    base=vel*shadow['shadow_dphidot'][WINDOW]/wave-pot*shadow['shadow_dphi'][WINDOW]
    results={}
    for tag,stride,cap in [('main',1,.12),('fine',1,.06),('even',2,.06),('odd',-2,.06)]:
        interior=np.arange(0 if stride>0 else 1,len(xs),abs(stride))
        slots=np.unique(np.r_[0,interior,np.arange(1991,2000)])
        nodes=xs[slots]
        vals=CubicSpline(nodes,point[slots])
        deriv=CubicSpline(nodes,np.column_stack((dc[slots],deta[slots]))).derivative()
        pieces=np.maximum(1,np.ceil(np.diff(nodes)/cap).astype(int))
        coords=np.r_[np.concatenate([np.linspace(left,right,count,endpoint=False) for left,right,count in zip(nodes[:-1],nodes[1:],pieces)]),nodes[-1]]
        delta=np.diff(coords)
        mid=coords[:-1]+delta/2
        def coeffs(at):
            cprime,bn,db,hn,wn,dh,dw,uu,ux,shear=vals(at).T
            derivative_c,derivative_eta=deriv(at).T
            common=db*cprime-2*dh*ux-dw*uu
            return np.array([-wn,-2*hn,bn*derivative_c+common,bn*(-shear+3*derivative_eta)+common]).T
        coeff=coeffs(coords)
        center=coeffs(mid)
        forecasts=np.zeros((len(coords),2,3))
        forecasts[0,:,2]=initial
        def rhs(state,mat):
            return np.array([state[1],mat[0]*state[0]+mat[1]*state[1]+np.array([mat[2],mat[3],0.])])
        for idx,step in enumerate(delta):
            state=forecasts[idx]
            one=rhs(state,coeff[idx])
            two=rhs(state+.5*step*one,center[idx])
            three=rhs(state+.5*step*two,center[idx])
            four=rhs(state+step*three,coeff[idx+1])
            forecasts[idx+1]=state+step*(one+2*two+2*three+four)/6
        indices=np.searchsorted(coords,xs[WINDOW])
        need(np.array_equal(coords[indices],xs[WINDOW]),'all native checkpoints, no output interpolation')
        correction=norm*(vel[:,None]*forecasts[indices,1]-pot[:,None]*forecasts[indices,0])
        estimates=(base[:,None]+correction[:,:2])/expected[:,None]-1
        actual_derivative=native['cdm_x']-shadow['cdm_x'][WINDOW]
        craw,eraw=deriv(xs[WINDOW]).T
        results[tag]=dict(residual=estimates.tolist(),original_seed_pressure_over_native=(correction[:,2]/expected).tolist(),steps=len(delta),
            endpoint_delta_c_x=dict(native_minus_physical=actual_derivative.tolist(),from_density=craw.tolist(),from_shear_and_eta=(-dshear[WINDOW]+3*eraw).tolist()))
    central=np.array(results['fine']['residual'])
    spread=sum(abs(central-np.array(results[tag]['residual'])) for tag in ('main','even','odd'))
    spread+=np.abs(central[:,0]-central[:,1])[:,None]
    return dict(test=digest(HERE/'METRIC-ATTRIBUTION.md'),source=digest(config['ref']),derivations=['cdm_density_slope','shear_and_eta'],variants=results,
        common_seed=np.array(initial).tolist(),zero_seed_assumption='measured homogeneous sensitivity reported separately',
        initial_readout_residual=(base/expected-1).tolist(),all_nine_pass=[bool(np.all(abs(central[:,idx])+spread[:,idx]+abs(np.array(results['fine']['original_seed_pressure_over_native']))<=TOL)) for idx in range(2)],
        peak_spread=spread.max(axis=0).tolist(),largest_input_gap_x=np.max(np.diff(xs)),largest_gap_endpoints=xs[np.argmax(np.diff(xs)):np.argmax(np.diff(xs))+2].tolist())


if __name__=='__main__':
    guard()
    save(HERE/'metric-attribution.json',dict(source=digest(Path(__file__)),tolerance=TOL,cases={case:experiment(case) for case in ('cold','heavy')}))
