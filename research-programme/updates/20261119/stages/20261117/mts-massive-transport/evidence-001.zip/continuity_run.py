from ctypes import CDLL, byref, c_longlong
import sys
import bridge
from bridge import HERE, NAMES, OLD, digest, guard, need, np, save
from exact_run import raw_thermal


def run(case,label):
    guard()
    mode={'trace':1,'balancedconstraint':2,'balancedtrace':3,'q32trace':1,'finetrace':3,'fineconstraint':2,'extratrace':3,'extraconstraint':2}[label]
    cap=.0025 if 'extra' in label else .005 if 'fine' in label else .01
    count=32 if label=='q32trace' else 24
    bridge.thermal=raw_thermal
    cfg,xs,state,args,thermal=bridge.setup(case,(count,272,16,cap,'table',True,0,False))
    args=(*args[:5],mode,*args[6:])
    state=np.r_[state,0.]
    solver=CDLL(str(HERE/'transport_continuity.dll')).propagate2
    solver.argtypes=bridge.SOLVE.argtypes
    solver.restype=bridge.SOLVE.restype
    names=NAMES+['integrated_defect','relative_enthalpy_defect','continuity_error','active_cdm_x']
    rows=np.zeros((len(xs),len(names)))
    num=c_longlong()
    need(solver(*args,state,xs[:1],1,cap,rows[:1],byref(num))==1,'initial trace')
    state[2]=rows[0,35]
    cuts=np.unique(np.r_[0,np.arange(64,len(xs),64),len(xs)-1])
    nsteps=0
    for left,right in zip(cuts[:-1],cuts[1:]):
        guard()
        chunk=xs[left:right+1]
        values=np.zeros((len(chunk),len(names)))
        need(solver(*args,state,chunk,len(chunk),cap,values,byref(num))==1 and np.isfinite(values).all() and np.isfinite(state).all(),'fresh finite closure run')
        rows[left+int(left>0):right+1]=values[int(left>0):]
        nsteps+=num.value
    target=HERE/(case+'-'+label+'-continuity.npz')
    with target.open('xb') as handle:
        np.savez_compressed(handle,forecast=rows,x=xs,names=names)
    save(target.with_suffix('.json'),dict(prediction=digest(target),mode=mode,cap=cap,count=count,steps=nsteps,
        source=digest(HERE/'transport_continuity.c'),include=digest(HERE/'continuity.inc'),thermal_include=digest(HERE/'thermal_exact.inc'),
        driver=digest(HERE/'continuity_run.py'),dll=digest(HERE/'transport_continuity.dll'),method=digest(HERE/'DISCRETE-CONTINUITY.md'),
        original=digest(OLD/(case+'-origin-physical.npz')),thermal=thermal['sha']))
    print(case,label,nsteps,flush=True)


if __name__=='__main__':
    for label in sys.argv[1:]:
        for case in ('cold','heavy'):
            run(case,label)
