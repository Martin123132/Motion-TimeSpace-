from bridge import HERE, PRIOR, TOL, digest, guard, need, np, read, save, inputs
from compare import WINDOW, forecast
from scipy.interpolate import CubicSpline, PchipInterpolator
from scipy.special import roots_laguerre
from pathlib import Path


def check(case,tag):
    out=forecast(case,tag+'-continuity')
    meta=read(HERE/(case+'-'+tag+'-continuity.json'))
    nodes,weight=roots_laguerre(meta['count'])
    w=weight*nodes**4/(4*(7*np.pi**4/120)*(1+np.exp(-nodes))**2)
    other,weight=roots_laguerre(32)
    bg=weight*other**3/((7*np.pi**4/120)*(1+np.exp(-other)))
    with np.load(HERE/(case+'-reference-raw.npz')) as input_packet:
        mass=input_packet['parameters'][4]
    grid=out['x'][WINDOW]
    aval=out['a'][WINDOW]
    gamma=np.hypot(1,aval[:,None]*mass/nodes)
    gm=np.hypot(1,aval[:,None]*mass/other)
    stable=(aval[:,None]*mass/other)**2/(1+gm)
    enthalpy=4/3+(stable*(1-1/(3*gm)))@bg
    source=(4/3)*(gamma@w)
    need(np.max(abs((source/enthalpy-1)-out['relative_enthalpy_defect'][WINDOW]))<3e-15,'independent enthalpy')
    density=(out['delta_nu']*out['massive_bg_ratio'])[WINDOW]
    vel=out['massive_flux_moment'][WINDOW]
    pressure=out['massive_pressure_moment'][WINDOW]
    shear=out['massive_shear_moment'][WINDOW]
    drive=out['active_cdm_x'][WINDOW]
    common=-vel+out['H'][WINDOW]/5*(density-pressure)
    tests={}
    for key,lhs,rhs in [('density_implemented',density,(enthalpy if meta['mode']&2 else source)*drive+common),
                         ('density_physical',density,enthalpy*drive+common),('momentum',vel,(pressure-2*shear)/3)]:
        true=np.diff(lhs)
        variants=[]
        for interp in (CubicSpline,PchipInterpolator):
            field=interp(grid-grid[0],rhs)
            variants.append(np.array([field.integrate(left-grid[0],right-grid[0]) for left,right in zip(grid[:-1],grid[1:])]))
        err=abs(variants[0]-true)
        unc=abs(variants[1]-variants[0])
        tests[key]=dict(cells=int(np.sum(err+unc<=TOL*abs(true))),total_cells=len(true),
            max_error_over_peak_increment=max(err)/max(abs(true)),interpolation_difference_over_peak=max(unc)/max(abs(true)),
            integrated_relative=(variants[0].sum()-true.sum())/abs(true.sum()))
    return tests


if __name__=='__main__':
    guard()
    save(HERE/'moment-laws.json',dict(script=digest(Path(__file__)),method=digest(HERE/'MOMENT-LAW.md'),tolerance=TOL,
          cases={case:{tag:check(case,tag) for tag in ('trace','balancedtrace','q32trace','extratrace','extraconstraint')} for case in ('cold','heavy')}))
