from bridge import HERE, TOL, digest, guard, np, need, save
from compare import forecast, preparation
from pathlib import Path
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from scipy.special import roots_legendre


def estimate(case, refine):
    cfg,native,field,_=preparation(case)
    physical=forecast(case,'sharp-shadow')
    xs=physical['x']
    with np.load(cfg['ref']) as packet:
        mode=np.flatnonzero(packet['modes']==5)[0]
        names=list(packet['names'])
        vals=packet['values'][mode,:len(xs)]
        cdm=vals[:,names.index('delta_cdm')]
        aval=vals[:,names.index('a')]
        hub=vals[:,names.index('H')]/5
    small=cdm.astype(np.float32)
    need(np.array_equal(cdm,small.astype(float)),'binary32 CDM representation')
    lower=(np.nextafter(small,-np.inf,dtype=np.float32).astype(float)-cdm)/2
    upper=(np.nextafter(small,np.inf,dtype=np.float32).astype(float)-cdm)/2
    mass=cfg['masses'][0]
    knots=CubicSpline(xs,np.array([1+(aval*mass/5)**2,hub,field[1](np.log(aval))/5]).T)
    first,last=xs[0],xs[1991]
    truth=native['mts_dp_s'][0]
    weight=np.array([-(aval[1991]*mass)**2*field[0](np.log(aval[1991])),5*field[1](np.log(aval[1991]))])
    scale=max(abs(weight))
    def adj(t,vec):
        squared,hubble,_=knots(t)
        return (squared*vec[1],-vec[0]+2*hubble*vec[1])
    sol=solve_ivp(adj,(last,first),weight/scale,method='DOP853',rtol=2e-12,atol=2e-13,max_step=.17 if refine else .32,dense_output=True)
    need(sol.success,'adjoint solved')
    nodes,weights=roots_legendre(6 if refine else 4)
    cuts=np.array([first,*np.concatenate([np.linspace(left,right,max(1,int(np.ceil((right-left)/.4)))+1)[1:] for left,right in zip(xs[:1991],xs[1:1992])])])
    half=np.diff(cuts)/2
    pts=cuts[:-1,None]+(1+nodes)*half[:,None]
    at=pts.ravel()
    integral=(weights*half[:,None]).ravel()*knots(at)[:,2]*sol.sol(at)[1]*scale/truth
    cardinal=np.zeros(len(xs))
    for start in range(0,len(xs),24):
        stop=min(len(xs),start+24)
        unit=np.zeros((len(xs),stop-start))
        unit[np.arange(start,stop),np.arange(stop-start)]=1
        deriv=CubicSpline(xs,unit,axis=0).derivative()(at)
        cardinal[start:stop]=integral@deriv
    positive=np.where(cardinal>0,upper,lower)
    negative=np.where(cardinal>0,lower,upper)
    hi=float(cardinal@positive)
    lo=float(cardinal@negative)
    maxbin=np.argmax(np.maximum(abs(cardinal*positive),abs(cardinal*negative)))
    need(abs(sum(cardinal))<2e-10*sum(abs(cardinal)),'constant CDM perturbation does not source pressure')
    check=None
    if refine:
        test=.99*positive
        need(np.array_equal((cdm+test).astype(np.float32),small),'synthetic alternative rounds to identical archived CDM entries')
        drive=CubicSpline(xs,test).derivative()
        norm=abs(native['mts_dphi_s'][0])
        def rhs(t,vec):
            squared,hubble,vel=knots(t)
            return (vec[1],-squared*vec[0]-2*hubble*vec[1]+vel*drive(t)/norm)
        mesh=np.r_[cuts[::8],cuts[-1]]
        mesh=np.unique(mesh)
        state=np.zeros(2)
        for left,right in zip(mesh[:-1],mesh[1:]):
            exact=solve_ivp(rhs,(left,right),state,method='DOP853',rtol=2e-10,atol=1e-13,max_step=min(.08,(right-left)/6))
            need(exact.success,'forward rounding witness')
            state=exact.y[:,-1]
        measured=float((weight@state)*norm/truth)
        check={'forward_over_native':measured,'adjoint_over_native':.99*hi,'relative_difference':abs(measured/(.99*hi)-1)}
    return dict(lower_pressure_change_over_native=lo,upper_pressure_change_over_native=hi,worst_single_knot=int(maxbin),
                worst_knot_x=xs[maxbin],initial_x=first,material_x=last,forward_witness=check)


if __name__=='__main__':
    guard()
    out={}
    for case in ('cold','heavy'):
        main=estimate(case,False)
        fine=estimate(case,True)
        out[case]=dict(main=main,refined=fine,relative_change=max(abs(main[key]/fine[key]-1) for key in ('lower_pressure_change_over_native','upper_pressure_change_over_native')))
    save(HERE/'cdm-rounding-response.json',dict(script=digest(Path(__file__)),tolerance=TOL,cases=out,
         interpretation='Linear sensitivity at fixed native geometry and velocity spline, conditional on not-a-knot cubic CDM interpolation. Extreme independently allowed rounding errors are existence witnesses, not a noise model or a self-consistent cosmology.'))
