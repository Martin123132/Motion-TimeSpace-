from bridge import HERE, TOL, digest, guard, need, np, read, save
from compare import SOURCES, WINDOW, forecast, integral
from pathlib import Path


TAGS=('trace','balancedtrace','balancedconstraint','q32trace','finetrace','fineconstraint','extratrace','extraconstraint')


def evaluate():
    guard()
    base=read(HERE/'transport-budget.json')
    bounds=np.log(base['common_scale_bounds'])
    result={}
    for tag in TAGS:
        cases={}
        for case in ('cold','heavy'):
            data=forecast(case,tag+'-continuity')
            mode=read(HERE/(case+'-'+tag+'-continuity.json'))['mode']
            clock=data['x']
            hub=data['H']/5
            extra=data['integrated_defect']
            drift=hub*data['trace_constraint'] if mode&1 else data['trace_constraint']
            defect=data['relative_enthalpy_defect']
            scales={key:integral({k:data[k][WINDOW] for k in ('a','H',key)},key,bounds)[0] for key in SOURCES}
            rows={}
            for key in ('mts_dp_s','slip','pi_photon','delta_neutrino','delta_nu','cdm_x','active_cdm_x'):
                rows[key]=float(data[key][1991])
            peak=max(abs(drift))
            cases[case]=dict(integrals=scales,event=rows,raw_enthalpy_defect_at_start=defect[0],
                raw_enthalpy_defect_max=max(abs(defect)),einstein_velocity_fraction_at_event=data['trace_constraint'][1991]/data['cdm_x'][1991],
                einstein_velocity_fraction_worst=max(abs(data['trace_constraint']/data['cdm_x'])),start_invariant=drift[0],
                event_invariant=drift[1991],integrated_source_event=extra[1991],unexplained_event=drift[1991]-drift[0]-extra[1991],
                invariant_max_abs=peak,unexplained_peak_change=max(abs(drift-drift[0]-extra)))
            need(np.all(np.diff(clock)>0) and max(abs(data['relative_enthalpy_defect']))<.001,'regular momentum quadrature')
        contrast={key:cases['heavy']['integrals'][key]-cases['cold']['integrals'][key] for key in SOURCES}
        result[tag]=dict(cases=cases,contrast=contrast)
    status={}
    controls=read(HERE/'physical-controls.json')['controls']
    for key in SOURCES:
        anchor=base['radiation'][key]['paired']['reference']
        central=base['radiation'][key]['paired']['quarter']
        corrected=result['extraconstraint']['contrast'][key]
        gap=result['extratrace']['contrast'][key]-corrected
        tests={'base_resolution':base['radiation'][key]['budget_over_contrast']*abs(central),
               'balanced_trace_vs_constraint':abs(gap),'time_balanced_trace':abs(result['extratrace']['contrast'][key]-result['finetrace']['contrast'][key]),
               'time_balanced_constraint':abs(corrected-result['fineconstraint']['contrast'][key]),
               'change_to_balanced_quadrature':abs(corrected-central),
               'restart_endpoint':abs(controls['lift']['change_over_reference_contrast'][key]*anchor)}
        status[key]=dict(contrast_by_tag_over_reference={tag:item['contrast'][key]/anchor-1 for tag,item in result.items()},
                 original_mixed_trace_change=controls['testg']['change_over_reference_contrast'][key],
                 coarse_to_middle={form:abs(result['fine'+form]['contrast'][key]-result['balanced'+form]['contrast'][key])/abs(central) for form in ('trace','constraint')},
                 budget_terms_absolute=tests,error_budget_over_original_contrast=sum(tests.values())/abs(central),
                 passes_including_geometry=sum(tests.values())<=TOL*abs(central),paired_change_vs_native=central/base['radiation'][key]['paired']['native']-1)
    save(HERE/'continuity-budget.json',dict(script=digest(Path(__file__)),tolerance=TOL,trials=result,gate=status))


if __name__=='__main__':
    evaluate()
