import os
import sys
from pathlib import Path
from ctypes import CDLL,byref,c_double,c_int,c_longlong,POINTER
for setting in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[setting]='1'
HERE=Path(__file__).resolve().parent
POST=HERE.parent
OLD=POST/'mts-native-seed-origin-20261117'
sys.path.insert(0,str(OLD))
from kinetic import Collision
from first_output import PRIOR, inputs, np, read, save, need, digest, TOL
from scipy.interpolate import CubicHermiteSpline, PchipInterpolator
from scipy.special import roots_laguerre
import math
import time

NAMES=['a','H','etak','delta_cdm','delta_baryon','delta_photon','delta_neutrino','delta_nu','v_photon','v_neutrino','v_baryon_cdm','pi_photon','E_2','slip','opacity','sound','drag_rate_x','angular_rate_x','trace_constraint']
for field in ('s','h'):
    NAMES.extend('mts_'+key+'_'+field for key in ('dphi','dphidot','drho','dp','q'))
NAMES+=['cell_drag','cell_angular','massive_bg_ratio','massive_pressure_moment','massive_flux_moment','massive_shear_moment','cdm_x','geometry_shear']
PTR=np.ctypeslib.ndpointer(dtype=np.float64,flags=('C_CONTIGUOUS','ALIGNED'))
SOLVE=CDLL(str(HERE/'transport_kernel.dll')).propagate
SOLVE.argtypes=[c_int]*6+[PTR]*6+[c_int,c_double,PTR,POINTER(c_longlong)]
SOLVE.restype=c_int
SEAL='2bc56bf5214de12c1c06b881a01500a81b55a06783c779b7ab367d06267066a6'


def guard():
    need(digest(OLD/'closeout.json')==SEAL,'preserve prior seal')
    for folder in (HERE,OLD,POST,POST/'condensate-origin-20261003',POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner stop')


def thermal(case,config,mode):
    source=POST/'mts-cold-full-metric-envelope-20261108/balanced/full-01'/(case+'-thermal.npz')
    with np.load(source) as table:
        coefficients=table['values']
        initial,spacing=table['metadata']
    minlog,maxlog=np.log([1.9e-10,.00026])
    total=8193
    grid=np.linspace(minlog,maxlog,total)
    diff=grid[1]-grid[0]
    index=np.arange(coefficients.shape[1])
    clocks=initial*np.exp(index*spacing)
    scale=clocks*coefficients[0]
    limit=int(np.searchsorted(scale,.00027))
    scale=scale[:limit]
    need(np.all(np.diff(scale)>0),'monotone native thermal chart')
    def direct(query):
        pos=np.clip(np.searchsorted(scale,query)-1,0,len(scale)-2)
        frac=np.clip((query-scale[pos])/(scale[pos+1]-scale[pos]),0,1)
        def pair(offset):
            left=coefficients[offset,pos]; right=coefficients[offset,pos+1]
            first=coefficients[offset+1,pos]; last=coefficients[offset+1,pos+1]
            quad=3*(right-left)-2*first-last
            cubic=first+last-2*(right-left)
            return left+frac*(first+frac*(quad+frac*cubic)),first+frac*(2*quad+3*frac*cubic)
        valid=query>=scale[0]
        for _ in range(3):
            val,slope=pair(0)
            clock=clocks[pos]*np.exp(frac*spacing)
            frac-=np.where(valid,(clock*val-query)/(clock*(slope+spacing*val)),0.)
        val,_=pair(0)
        need(np.max(abs((clocks[pos]*np.exp(frac*spacing)*val/query-1)[valid]))<1e-12,'invert thermal scale')
        sound=pair(2)[0]*query
        opacity=pair(4)[0]*query**2
        sound[~valid]=coefficients[2,0]*scale[0]
        opacity[~valid]=coefficients[4,0]*scale[0]**2
        return opacity,sound
    op,snd=direct(np.exp(grid))
    if mode=='ideal':
        from transport import plasma
        old=plasma(config)
        op[:]=old['opacity_a2'];snd[:]=old['sound_a']
    packed=np.zeros((total,4))
    for slot,column in ((0,op),(2,snd)):
        packed[:,slot]=column
        packed[:,slot+1]=PchipInterpolator(grid,column).derivative()(grid)*diff
    checks={}
    if mode!='ideal':
        mid=(grid[1:]+grid[:-1])/2
        truth=direct(np.exp(mid))
        for idx,key in enumerate(('opacity','sound')):
            pred=CubicHermiteSpline(grid,packed[:,2*idx],packed[:,2*idx+1]/diff)(mid)
            checks[key]=max(abs(pred/truth[idx]-1))
    qbg,wbg=roots_laguerre(32)
    fermi=7*np.pi**4/120
    wbg=wbg*qbg**3/(1+np.exp(-qbg))/fermi
    return np.r_[packed.ravel(),np.c_[qbg,wbg].ravel()],total,minlog,diff,dict(path=str(source),sha=digest(source),inverse_checks=checks,
        minimum_table_scale=scale[0],subtable='fixed a*cs2 and a^2*opacity below first archived thermal knot only')


def quadrature(count):
    fermi=7*np.pi**4/120
    if count==5:
        return np.array([.583165,2.,4.,7.26582,13.]),np.array([.0081201,.689407,2.8063,2.05156,.126817])/fermi
    nodes,weights=roots_laguerre(count)
    kernel=weights*nodes**4/(4*fermi*(1+np.exp(-nodes))**2)
    return nodes,kernel


SCANS={
    'control':(16,80,7,.016,'ideal',False,0,False),
    'ideal':(16,256,16,.020,'ideal',False,0,False),
    'thermal':(16,256,16,.020,'table',False,0,False),
    'native5':(5,256,16,.020,'table',True,0,False),
    'primary':(16,256,16,.020,'table',True,0,False),
    'time':(16,256,16,.010,'table',True,0,False),
    'moment':(16,320,20,.010,'table',True,0,False),
    'fine':(32,320,20,.010,'table',True,0,False),
    'restart':(16,256,16,.020,'table',True,407,False),
    'trace':(16,256,16,.020,'table',True,0,True),
}


def setup(case,settings):
    count,limit,polar,step,mode,include,origin,trace=settings
    cfg=inputs(case)
    model=Collision(cfg,48,7)
    ref=cfg['ref']
    with np.load(ref) as data:
        times=data['conformal_time'][origin:2000].copy()
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as capture:
        need(capture['clock'][0]==times[1991-origin],'actual saved matter event')
    old=OLD/(case+'-origin-physical.npz')
    with np.load(old) as saved:
        state_old=saved['states'][origin]
        need(saved['times'][origin]==times[0],'matched retained start')
    with np.load(POST/'mts-integrated-defect-20261112'/(case+'-native-clock.npz')) as packet:
        const=packet['constants']
    massive_fraction=const[14]/(3*cfg['alpha']**2)
    thermo,nth,minlog,delta,thermal_meta=thermal(case,cfg,mode)
    params=np.zeros(12)
    params[:6]=[cfg['alpha'],cfg['omega']/5,cfg['fraction']-massive_fraction,massive_fraction,const[8] if include else 0.,cfg['baryon']]
    params[6:6+len(cfg['fields'])]=model.base.parameters
    params[8:8+len(cfg['fields'])]=model.base.origin
    params[10:]=[minlog,delta]
    nodes,weight=quadrature(count)
    photo=18+(count+1)*(limit+2)
    state=np.zeros(photo+2*(polar-1))
    state[:8]=np.r_[state_old[:5],state_old[6],state_old[model.count:model.count+2]]
    fields=len(cfg['fields'])
    state[10:10+4*fields]=state_old[model.base.first+1:model.count]
    for index in range(count+1):
        offset=18+index*(limit+2)
        state[offset:offset+3]=[state_old[5],4*state_old[7]/3,2*state_old[8]]
        state[offset+3:offset+49]=state_old[9:55]
        state[offset+limit+1]=5*times[0]
    for block in range(2):
        state[photo+block*(polar-1):photo+block*(polar-1)+6]=state_old[model.count+2+block*6:model.count+2+(block+1)*6]
    return cfg,times*5,state,(count,limit,polar,fields,nth,int(trace),params,nodes,weight,thermo),thermal_meta


def evolve(case,tag,end=1999,suffix=''):
    guard()
    cfg,times,state,arguments,thermal_info=setup(case,SCANS[tag])
    count,limit,polar,step,mode,include,origin,trace=SCANS[tag]
    end=407 if tag=='control' else end
    xs=times[:end-origin+1]
    need(len(xs)>1,'nonempty path')
    output=np.zeros((len(xs),len(NAMES)))
    steps=c_longlong()
    before=time.monotonic()
    initial=state.copy()
    clock0=np.ascontiguousarray(xs[:1]);initial_obs=np.zeros((1,len(NAMES)))
    need(SOLVE(*arguments,state,clock0,1,step,initial_obs,byref(steps))==1,'initial physical readout')
    if trace:
        state[2]=initial_obs[0,NAMES.index('cdm_x')]
    boundaries=np.unique(np.r_[0,np.arange(64,len(xs),64),len(xs)-1])
    total=0
    for first,last in zip(boundaries[:-1],boundaries[1:]):
        guard()
        block=xs[first:last+1]
        rows=np.zeros((len(block),len(NAMES)))
        status=SOLVE(*arguments,state,block,len(block),step,rows,byref(steps))
        need(status==1 and np.isfinite(rows).all() and np.isfinite(state).all(),'finite trajectory at archived boundary '+str((first,last,status)))
        output[first+(first>0):last+1]=rows[int(first>0):]
        total+=steps.value
    label=case+'-'+tag+suffix
    path=HERE/(label+'.npz')
    with path.open('xb') as file:
        np.savez_compressed(file,x=xs,names=NAMES,forecast=output,initial=initial,terminal=state,parameters=arguments[6],
            q=arguments[7],weights=arguments[8],source_sha=digest(cfg['ref']),parent_sha=digest(OLD/(case+'-origin-physical.npz')),
            implementation=digest(HERE/'transport_kernel.c'),library=digest(HERE/'transport_kernel.dll'),driver=digest(Path(__file__)))
    saved=dict(seconds=time.monotonic()-before,steps=total,thermal=thermal_info,settings=SCANS[tag],end=end,
        prediction_sha=digest(path),reference=str(cfg['ref']),method=digest(HERE/'METHOD.md'))
    save(HERE/(label+'.json'),saved)
    print(label,'done',end,total,round(saved['seconds'],2),'thermal check',thermal_info['inverse_checks'],flush=True)


if __name__=='__main__':
    for tag in sys.argv[1:]:
        for case in ('cold','heavy'):
            evolve(case,tag)
