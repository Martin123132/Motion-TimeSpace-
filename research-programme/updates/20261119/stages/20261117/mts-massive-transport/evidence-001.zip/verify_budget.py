from pathlib import Path
from bridge import HERE, OLD, PRIOR, TOL, SEAL, digest, guard, inputs, need, np, read, save
from compare import WINDOW, forecast, preparation
from continuity_score import TAGS


def main():
    guard()
    seal=read(OLD/'closeout.json')['files']
    for name,item in seal.items():
        path=OLD/name
        need(path.stat().st_size==item['bytes'] and digest(path)==item['sha256'],'original artifact '+name)
    budgets={key:read(HERE/name) for key,name in [('base','transport-budget.json'),('continuity','continuity-budget.json'),('metric','metric-attribution.json'),('control','physical-controls.json'),('round','cdm-rounding-response.json'),('moments','moment-laws.json')]}
    need(all(budgets[key]['tolerance']==TOL for key in budgets),'unchanged common tolerance')
    for key,file in [('base','compare.py'),('continuity','continuity_score.py'),('metric','metric_history.py'),('control','controls.py'),('round','rounding_response.py'),('moments','moment_law.py')]:
        result=budgets[key]
        need(result.get('script',result.get('source'))==digest(HERE/file),'budget script '+key)
    checks={}
    original_hierarchy=read(HERE/'native-hierarchy.json')
    need(original_hierarchy['script']==digest(HERE/'native_hierarchy_check.py'),'native layout and callback audit version')
    for case in ('cold','heavy'):
        cfg,native,_,_=preparation(case)
        origin=digest(OLD/(case+'-origin-physical.npz'))
        source=digest(cfg['ref'])
        count=0
        for path in sorted(HERE.glob(case+'-*.npz')):
            label=path.stem
            info=read(path.with_suffix('.json'))
            need(info.get('prediction_sha',info.get('prediction'))==digest(path),'complete packet '+label)
            with np.load(path) as data:
                field=data['forecast']
                need(field.shape==(len(data['x']),len(data['names'])) and np.isfinite(field).all() and len(set(data['names']))==field.shape[1],'finite unique columns '+label)
                if 'source_sha' in data:
                    need(str(data['source_sha'])==source and str(data['parent_sha'])==origin,'original sources '+label)
                if label.endswith('-raw'):
                    engine=read(HERE/(label+'-engine.json'))
                    need(engine['actual_dll']==digest(HERE/'transport_exact.dll') and engine['actual_source']==digest(HERE/'transport_exact.c'),'actual exact engine')
                if label.endswith('-shadow'):
                    need(info['preparation']==origin and info['method']==digest(HERE/'SHADOW-METHOD.md') and info['dll']==digest(HERE/'transport_shadow.dll'),'spectator input identity')
                if label.endswith('-continuity'):
                    need(info['original']==origin and info['method']==digest(HERE/'DISCRETE-CONTINUITY.md') and info['dll']==digest(HERE/'transport_continuity.dll'),'continuity input identity')
            count+=1
        independent=forecast(case,'sharp-shadow')
        baseline=forecast(case,'sharp-raw')
        correct=forecast(case,'quarter-raw')
        tr=forecast(case,'extratrace-continuity')
        balanced=forecast(case,'extraconstraint-continuity')
        for branch,label in [(tr,'extratrace'),(balanced,'extraconstraint')]:
            need(np.array_equal(branch['x'],correct['x']),'identical geometry-control clock')
            need(np.max(abs(branch['integrated_defect']))<1e-13,'balanced integrated discrete source vanishes to roundoff')
            need(np.max(abs(branch['active_cdm_x'][WINDOW]-(branch['cdm_x'][WINDOW]+(branch['trace_constraint'][WINDOW] if label=='extratrace' else 0))))<1e-14,'trace source equals actual metric driver')
        geometry=budgets['continuity']['trials']
        need(abs(geometry['q32trace']['cases'][case]['raw_enthalpy_defect_at_start'])<abs(geometry['trace']['cases'][case]['raw_enthalpy_defect_at_start']),'independent momentum refinement approaches continuum identity')
        mass=cfg['masses'][0]
        press=independent['archived_velocity']*independent['shadow_dphidot']-(independent['a']*mass)**2*independent['archived_phi']*independent['shadow_dphi']
        diff=max(abs(press[WINDOW]/independent['both_archive'][WINDOW]-1))
        need(diff<2e-13,'four-way pressure readout verified independently')
        actual=native['mts_dp_s']
        original=independent['mts_dp_s'][WINDOW]/actual-1
        remainder=press[WINDOW]/actual-1
        branch=budgets['base']['branches'][case]
        need(max(abs(remainder-branch['pressure']['remaining_miss']))<2e-13 and np.sum(abs(remainder)>TOL)==branch['pressure']['still_fails'],'failures retained')
        need(max(abs(independent['mts_dp_s']-baseline['mts_dp_s']))/max(abs(baseline['mts_dp_s']))<TOL,'passive perturbation control')
        need(branch['local_replay']['native_control_worst']+branch['local_replay']['interpolation_solver_worst']<TOL and branch['local_replay']['physical_control_worst']<TOL,'within-window native and spectator controls')
        witness=budgets['round']['cases'][case]['refined']['forward_witness']
        need(witness['relative_difference']<TOL and witness['forward_over_native']>max(abs(remainder)),'independent binary32 witness')
        need(not any(budgets['metric']['cases'][case]['all_nine_pass']),'uncertified past forcing is not promoted')
        need(np.max(abs(correct['a'][WINDOW]/native['a']-1))<TOL,'matched late scale')
        tested=original_hierarchy['cases'][case]
        need(tested['active']==tested['points'] and tested['checks']['fluid_shear']['rows_pass']==tested['points'] and tested['checks']['one_initial_shear_then_density_only']['material_passes']==8,'actual native closure and finite-window shear replay')
        checks[case]=dict(packets=count,observed_rows=9,physical_slow_event_error=original[0],remaining_slow_event_error=remainder[0],
            remaining_failures=int(sum(abs(remainder)>TOL)),independent_pressure_algebra_error=diff,native_source_hash=source,origin_hash=origin,
            material_capture_hash=digest(PRIOR/(case+'-physical-roots-capture.npz')))
    for key,status in budgets['continuity']['gate'].items():
        base=budgets['base']['radiation'][key]
        need(abs(sum(status['budget_terms_absolute'].values())/abs(base['paired']['quarter'])-status['error_budget_over_original_contrast'])<1e-13 and
            status['passes_including_geometry']==(status['error_budget_over_original_contrast']<=TOL),'source verdict without relaxed threshold')
    save(HERE/'verification.json',dict(previous_seal=SEAL,previous_artifacts_rehashed=len(seal),script=digest(Path(__file__)),tolerance=TOL,branches=checks))


if __name__=='__main__':
    main()
