import sys
from ctypes import CDLL
from pathlib import Path
import bridge
from bridge import HERE, POST, OLD, SCANS, digest, evolve, guard, need, np, read, roots_laguerre, save


def raw_thermal(case,config,mode):
    family='half' if mode=='independent' else 'balanced'
    source=POST/'mts-cold-full-metric-envelope-20261108'/family/'full-01'/(case+'-thermal.npz')
    with np.load(source) as packet:
        table=packet['values']
        initial,step=packet['metadata']
    clock=initial*np.exp(step*np.arange(table.shape[1]))
    scale=table[0]*clock
    count=np.searchsorted(scale,.00026)+3
    vals=np.column_stack((scale[:count],clock[:count],table[:6,:count].T)).copy()
    if mode=='ideal':
        from transport import plasma
        phys=plasma(config)
        deriv=step+vals[:,3]/vals[:,2]
        vals[:,4]=phys['sound_a']/vals[:,0];vals[:,5]=-deriv*vals[:,4]
        vals[:,6]=phys['opacity_a2']/vals[:,0]**2;vals[:,7]=-2*deriv*vals[:,6]
    need(np.all(np.diff(vals[:,0])>0) and np.all(vals[:,[4,6]]>0),'unmodified, positive native thermal support')
    nodes,weights=roots_laguerre(32)
    weight=weights*nodes**3/(1+np.exp(-nodes))/(7*np.pi**4/120)
    return np.r_[vals.ravel(),np.c_[nodes,weight].ravel()],count,0.,step,dict(path=str(source),sha=digest(source),inverse_checks={'raw_Hermite_no_resampling':True},
        min_scale=scale[0],max_scale=scale[count-1],start=initial,dlntau=step)


def model_library():
    lib=CDLL(str(HERE/'transport_exact.dll'))
    solver=lib.propagate2
    solver.argtypes=bridge.SOLVE.argtypes
    solver.restype=bridge.SOLVE.restype
    return solver


def start():
    bridge.thermal=raw_thermal
    bridge.SOLVE=model_library()
    SCANS.update(native5=(5,256,16,.012,'table',True,0,False),reference=(24,272,16,.010,'table',True,0,False),
        independent=(24,272,16,.010,'independent',True,0,False),sharp=(24,272,16,.005,'table',True,0,False),
        testq=(32,272,16,.010,'table',True,0,False),testl=(24,320,20,.010,'table',True,0,False),
        testg=(24,272,16,.010,'table',True,0,True),lift=(24,272,16,.010,'table',True,407,False),
        light=(24,272,16,.010,'table',False,0,False),fixed=(24,272,16,.010,'ideal',True,0,False))
    for tag in sys.argv[1:]:
        for case in ('cold','heavy'):
            evolve(case,tag,suffix='-raw')
            save(HERE/(case+'-'+tag+'-raw-engine.json'),dict(actual_dll=digest(HERE/'transport_exact.dll'),actual_source=digest(HERE/'transport_exact.c'),
                driver=digest(Path(__file__)),includes=[digest(HERE/'thermal_exact.inc'),digest(HERE/'transport_v2.c'),digest(HERE/'transport_kernel.c')]))


if __name__=='__main__':
    start()
