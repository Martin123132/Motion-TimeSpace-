from ctypes import CDLL, byref, c_longlong
import sys
import bridge
from bridge import HERE, NAMES, OLD, digest, guard, need, np, save
from exact_run import raw_thermal
from first_output import COMMON
from scipy.interpolate import CubicSpline


EXTRA=['archived_velocity','archived_phi','shadow_dphi','shadow_dphidot','physical_state_archive_readout','archive_state_physical_readout','both_archive','physical_velocity','physical_phi']


def run(case, label, cap):
    guard()
    settings=(24,272,16,cap,'table',True,0,False)
    bridge.thermal=raw_thermal
    cfg,targets,state,original,thermal=bridge.setup(case,settings)
    source=COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    with np.load(source) as packet:
        grid=packet['efold']
        field=packet['phi_s']
        vel=packet['phidot_s']
    packed=np.column_stack((grid[:-1],CubicSpline(grid,vel,bc_type='natural').c.T,CubicSpline(grid,field,bc_type='natural').c.T))
    packed=np.vstack((packed,[grid[-1],0,0,0,vel[-1],0,0,0,field[-1]]))
    args=(*original[:-1],np.r_[original[-1],len(grid),packed.ravel()])
    state=np.r_[state,state[12:14]]
    solver=CDLL(str(HERE/'transport_shadow.dll')).propagate2
    solver.argtypes=bridge.SOLVE.argtypes
    solver.restype=bridge.SOLVE.restype
    names=NAMES+EXTRA
    output=np.empty((len(targets),len(names)))
    cuts=np.unique(np.r_[0,np.arange(64,len(targets),64),len(targets)-1])
    steps=c_longlong()
    total=0
    for left,right in zip(cuts[:-1],cuts[1:]):
        guard()
        clocks=targets[left:right+1]
        rows=np.zeros((len(clocks),len(names)))
        need(solver(*args,state,clocks,len(clocks),cap,rows,byref(steps))==1 and np.isfinite(rows).all() and np.isfinite(state).all(),'finite spectator and physical path')
        output[left+int(left>0):right+1]=rows[int(left>0):]
        total+=steps.value
    path=HERE/(case+'-'+label+'-shadow.npz')
    with path.open('xb') as handle:
        np.savez_compressed(handle,x=targets,names=names,forecast=output,terminal=state)
    save(path.with_suffix('.json'),dict(prediction=digest(path),driver=digest(HERE/'shadow_run.py'),model=digest(HERE/'transport_shadow.c'),include=digest(HERE/'shadow_eval.inc'),thermal_include=digest(HERE/'thermal_exact.inc'),dll=digest(HERE/'transport_shadow.dll'),preparation=digest(OLD/(case+'-origin-physical.npz')),archive=digest(source),thermal=thermal['sha'],settings=settings,steps=total,method=digest(HERE/'SHADOW-METHOD.md')))
    print(case,label,total,flush=True)


if __name__=='__main__':
    for label in sys.argv[1:]:
        for case in ('cold','heavy'):
            run(case,label,{'reference':.010,'sharp':.005}[label])
