import sys
from ctypes import CDLL
import bridge
from bridge import HERE, SCANS, TOL, digest, evolve, guard, need, np, save

def main():
    improved=CDLL(str(HERE/'transport_v2.dll')).propagate2
    improved.argtypes=bridge.SOLVE.argtypes
    improved.restype=bridge.SOLVE.restype
    bridge.SOLVE=improved
    for tag in sys.argv[1:]:
        for case in ('cold','heavy'):
            evolve(case,tag,suffix='-ii')
            save(HERE/(case+'-'+tag+'-ii-engine.json'),dict(method='stiffly accurate full ESDIRK with iterated explicit remainder; v1 additive control kept',
                source=digest(HERE/'transport_v2.c'),includes=digest(HERE/'transport_kernel.c'),dll=digest(HERE/'transport_v2.dll'),entry=digest(HERE/'implicit_run.py')))

if __name__=='__main__':
    main()
