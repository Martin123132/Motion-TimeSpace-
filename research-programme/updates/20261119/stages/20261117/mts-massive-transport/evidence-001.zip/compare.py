from pathlib import Path
from bridge import HERE, OLD, PRIOR, TOL, NAMES, digest, guard, inputs, need, np, read, save
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline, PchipInterpolator
from first_output import COMMON
from exact_run import raw_thermal
from shadow_run import EXTRA


WINDOW=slice(1991,2000)
TAGS=('reference','sharp','quarter','testq','testl','independent')
SOURCES=('drag_rate_x','angular_rate_x')


def forecast(case,label):
    path=HERE/(case+'-'+label+'.npz')
    meta=read(path.with_suffix('.json'))
    need(digest(path)==meta.get('prediction_sha',meta.get('prediction')),'prediction digest')
    with np.load(path) as packet:
        result=dict(zip(packet['names'].tolist(),packet['forecast'].T.copy()))
        result['x']=packet['x'].copy()
    return result


def preparation(case):
    config=inputs(case)
    source=COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    with np.load(source) as data:
        splines=[CubicSpline(data['efold'],data[key],bc_type='natural') for key in ('phi_s','phidot_s')]
    with np.load(config['ref']) as ref:
        rows=np.flatnonzero(ref['modes']==5)
        need(len(rows)==1,'unique mode')
        native=dict(zip(ref['names'].tolist(),ref['values'][rows[0],WINDOW].T.copy()))
        native['x']=5*ref['conformal_time'][WINDOW].copy()
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as packet:
        physical=packet['packet']
        signature=packet['signature'][:9]
        state=packet['reference'][:9]
        derivative=packet['derivative_reference'][:9]
        need(np.array_equal(native['x'],5*packet['clock'][:9]) and np.all(signature==signature[0]),'original matched times and layout')
    gix,pix,limit,plimit=signature[0,[3,5,6,7]]
    need(limit==plimit and abs(state[:,gix]/native['v_photon']-1).max()<TOL and abs(state[:,gix+1]/native['pi_photon']-1).max()<TOL and abs(state[:,pix+1]/native['E_2']-1).max()<TOL,'native intensity and polarization offsets')
    need(np.max(abs(physical[:9,2]/native['H']-1))<TOL and np.max(abs(state[:,1]/native['delta_cdm']-1))<TOL,'native CDM and expansion identities')
    native['cdm_x']=derivative[:,1]/5
    dc=(np.diff(state[:,1])/np.diff(native['x']))
    need(np.max(abs(dc/((native['cdm_x'][1:]+native['cdm_x'][:-1])/2)-1))<TOL,'independent finite CDM displacement')
    native['slip']=state[:,3]-.75*state[:,gix]
    native['opacity']=physical[:9,174]
    native['sound']=physical[:9,172]
    rate=native['opacity']/5
    native['drag_rate_x']=rate*native['slip']**2
    weight=6*15/16
    pi=state[:,gix+1]
    pol=state[:,pix+1]
    ang=(15/16)*(.75*pi**2+2.4*(pol-.25*pi)**2)
    for ell in range(3,limit+1):
        prev=ell-1
        weight*=((prev+3)*(prev-1)/((prev+1)*(2*prev+1)))/(ell/(2*ell+1))
        ang+=3*(2*ell+1)/16*state[:,gix+ell-1]**2+weight*state[:,pix+ell-1]**2
    native['angular_rate_x']=rate*ang
    return config,native,splines,physical


def thermal_fixed(case,config,physical):
    output={}
    for family in ('table','independent'):
        raw,count,_,step,_=raw_thermal(case,config,family)
        data=raw[:8*count].reshape(-1,8)
        supported=(physical[:,1]>data[0,0])&(physical[:,1]<data[-1,0])
        need(supported[:9].all(),'full test window has thermal support')
        target=physical[supported,1]
        slots=np.searchsorted(data[:,0],target)-1
        left,right=data[slots],data[slots+1]
        def pair(frac,pos):
            delta=right[:,pos]-left[:,pos]
            quad=3*delta-2*left[:,pos+1]-right[:,pos+1]
            cubic=left[:,pos+1]+right[:,pos+1]-2*delta
            return left[:,pos]+frac*(left[:,pos+1]+frac*(quad+frac*cubic))
        lower=np.zeros(len(target))
        upper=np.ones(len(target))
        for _ in range(45):
            center=(lower+upper)/2
            scale=left[:,1]*np.exp(step*center)*pair(center,2)
            lower=np.where(scale<=target,center,lower)
            upper=np.where(scale>target,center,upper)
        center=(lower+upper)/2
        need(np.max(abs(left[:,1]*np.exp(step*center)*pair(center,2)/target-1))<2e-14,'independent bisection in raw table')
        output[family]=dict(rows_supported=int(supported.sum()),event_and_eight={key:np.max(abs(pair(center,offset)[:9]/physical[:9,slot]-1)) for key,offset,slot in [('sound',4,172),('opacity',6,174)]},
            supported_worst={key:np.max(abs(pair(center,offset)/physical[supported,slot]-1)) for key,offset,slot in [('sound',4,172),('opacity',6,174)]})
    return dict(capture_size=len(physical),comparisons=output)


def local_memory(case,native,model,splines,mass):
    xs=native['x']-native['x'][0]
    config={}
    for key in ('x','a','H','cdm_x'):
        config[key]=model[key][WINDOW]
    norm=abs(native['mts_dphi_s'][0])
    initial={'N':np.array([native['mts_dphi_s'][0],native['mts_dphidot_s'][0]/5])/norm,
             'S':np.array([model['shadow_dphi'][1991],model['shadow_dphidot'][1991]/5])/norm}
    trial={}
    for method,interp,cap in [('main',CubicSpline,.012),('refined',PchipInterpolator,.003)]:
        pressures={}
        for label,source in [('SS',config),('SN',native),('NN',native)]:
            curves=interp(xs,np.array([source[k] for k in ('a','H','cdm_x')]).T)
            def rhs(coord,state):
                aval,hub,drive=curves(coord)
                return (state[1],-2*hub/5*state[1]-(1+(aval*mass/5)**2)*state[0]+drive*splines[1](np.log(aval))/(5*norm))
            sol=solve_ivp(rhs,(0.,xs[-1]),initial[label[0]],t_eval=xs,method='DOP853',rtol=2e-12,atol=1e-14,max_step=cap)
            need(sol.success and np.isfinite(sol.y).all(),'local pressure replay')
            aval=source['a']
            pressure=norm*(5*splines[1](np.log(aval))*sol.y[1]-(aval*mass)**2*splines[0](np.log(aval))*sol.y[0])
            pressures[label]=pressure
        trial[method]=pressures
    actual=native['mts_dp_s']
    ss,sn,nn=(trial['main'][key] for key in ('SS','SN','NN'))
    gap=ss-actual
    parts=np.array([ss-sn,sn-nn,nn-actual])
    need(np.max(abs((parts.sum(0)-gap)/actual))<1e-13,'pressure partition')
    return dict(labels=['local_geometry_and_readout','inherited_state','native_replay_defect'],last_signed_parts_over_native=(parts[:,-1]/actual[-1]).tolist(),
                last_parts_over_remaining_gap=(parts[:,-1]/gap[-1]).tolist(),gap_over_native=(gap/actual).tolist(),
                native_control_worst=max(abs(nn/actual-1)),physical_control_worst=max(abs(ss/model['both_archive'][WINDOW]-1)),
                interpolation_solver_worst=max(np.max(abs((trial['main'][k]-trial['refined'][k])/actual)) for k in trial['main']))


def side(case):
    config,native,splines,packet=preparation(case)
    scans={tag:forecast(case,tag+'-raw') for tag in TAGS}
    fine=scans['quarter']
    sh={tag:forecast(case,tag+'-shadow') for tag in ('reference','sharp')}
    need(all(np.array_equal(row['x'][WINDOW],native['x']) for row in [*scans.values(),*sh.values()]),'unchanged clocks')
    valid=[key for key in NAMES if key in native and (case=='heavy' or not key.endswith('_h'))]
    comparison={}
    for key in valid:
        truth=native[key]
        calc=fine[key][WINDOW]
        sensitivities={tag:np.abs((scans[tag][key]-scans['reference'][key])[WINDOW]) for tag in ('testq','testl','independent')}
        sensitivities['time']=abs(calc-scans['sharp'][key][WINDOW])
        budget=sum(sensitivities.values())
        comparison[key]=dict(native_event=truth[0],physical_event=calc[0],event_fraction=calc[0]/truth[0]-1,
            maximum_fraction=np.max(abs(calc/truth-1)),error_over_window_peak=max(abs(calc-truth))/max(abs(truth)),
            budget_over_peak=max(budget)/max(abs(truth)),native_passed=int(np.sum(abs(calc-truth)+budget<=TOL*abs(truth))),
            converged_epochs=int(np.sum(budget<=TOL*abs(calc))))
    spectator=sh['sharp']
    mass=config['masses'][0]
    phi_native=(native['mts_drho_s']-native['mts_dp_s'])/(2*(mass*native['a'])**2*native['mts_dphi_s'])
    vel_native=native['mts_q_s']/(5*native['mts_dphi_s'])
    spline_errors=[max(abs(splines[index](np.log(native['a']))/truth-1)) for index,truth in enumerate((phi_native,vel_native))]
    need(max(spline_errors)<TOL,'archived homogeneous quantities reconstructed independently')
    pstar=native['mts_dp_s']
    keys=('mts_dp_s','physical_state_archive_readout','archive_state_physical_readout','both_archive')
    physical,readout,forcing,both=(spectator[key][WINDOW] for key in keys)
    interaction=both-forcing-readout+physical
    need(np.max(abs(readout-physical+forcing-physical+interaction-(both-physical))/abs(pstar))<1e-13,'factorial decomposition')
    residual=pstar-physical
    differences=np.stack([readout-physical,forcing-physical,interaction,pstar-both])
    pressure=dict(native_homogeneous_reconstruction=spline_errors,
        event_errors_over_native={key:spectator[key][1991]/pstar[0]-1 for key in keys},
        labels=['homogeneous_readout','accumulated_forcing','interaction','unexplained'],event_fraction_of_original_gap=(differences[:,0]/residual[0]).tolist(),
        original_miss=(physical/pstar-1).tolist(),remaining_miss=(both/pstar-1).tolist(),
        crossed_step_error_over_native=max(max(abs((sh['sharp'][key][WINDOW]-sh['reference'][key][WINDOW])/pstar)) for key in keys),
        shadow_feedback_over_channel_peak={key:max(abs(spectator[key]-scans['sharp'][key]))/max(abs(scans['sharp'][key])) for key in valid},
        still_fails=int(np.sum(abs(both/pstar-1)>TOL)))
    replay=local_memory(case,native,spectator,splines,mass)
    early=forecast(case,'control-ii')
    with np.load(OLD/(case+'-origin-differences.npz')) as source:
        old=dict(zip(source['physical_names'].tolist(),source['physical_readout'].T))
    early_errors={key:max(abs(early[key]-old[key]))/max(abs(old[key])) for key in ('slip','pi_photon','E_2','mts_dp_s')}
    if case=='heavy':
        early_errors['mts_dp_h']=max(abs(early['mts_dp_h']-old['mts_dp_h']))/max(abs(old['mts_dp_h']))
    return dict(pressure=pressure,source_readouts=comparison,local_replay=replay,thermal=thermal_fixed(case,config,packet),early_overlap=early_errors),native,scans


def integral(row,key,bounds):
    aval=row['a']
    coord=np.log(aval/np.exp(bounds[0]))
    rate=row[key]*5/row['H']
    end=bounds[1]-bounds[0]
    need(coord[0]<0<end<coord[-1] and np.all(np.diff(coord)>0),'no extrapolation in common scale window')
    actual=PchipInterpolator(coord,rate).integrate(0.,end)
    nodes=np.r_[0,coord[(coord>0)&(coord<end)],end]
    linear=np.trapezoid(np.interp(nodes,coord,rate),nodes)
    return actual,linear


def main():
    guard()
    result={'tolerance':TOL,'rows':[1991,1999],'source':digest(Path(__file__)),'branches':{}}
    natives={}
    models={}
    for case in ('cold','heavy'):
        result['branches'][case],natives[case],models[case]=side(case)
    bounds=(max(np.log(row['a'][1]) for row in natives.values()),min(np.log(row['a'][-2]) for row in natives.values()))
    result['common_scale_bounds']=list(np.exp(bounds))
    result['radiation']={}
    for key in SOURCES:
        runs={}
        diffs={}
        lins={}
        for tag in (*TAGS,'native'):
            runs[tag]={}
            lins[tag]={}
            for case in ('cold','heavy'):
                row=natives[case] if tag=='native' else {k:models[case][tag][k][WINDOW] for k in ('a','H',key)}
                runs[tag][case],lins[tag][case]=integral(row,key,bounds)
            diffs[tag]=runs[tag]['heavy']-runs[tag]['cold']
        budget=sum(abs(diffs[tag]-diffs['reference']) for tag in ('testq','testl','independent'))+abs(diffs['quarter']-diffs['sharp'])
        budget+=abs(lins['quarter']['heavy']-lins['quarter']['cold']-diffs['quarter'])
        result['radiation'][key]=dict(integrals=runs,paired=diffs,budget_over_contrast=budget/abs(diffs['quarter']),relative_MTS_minus_baseline=diffs['quarter']/runs['quarter']['cold'],
            native_relative_MTS_minus_baseline=diffs['native']/runs['native']['cold'],native_contrast_relative_error=diffs['quarter']/diffs['native']-1)
    save(HERE/'transport-budget.json',result)


if __name__=='__main__':
    main()
