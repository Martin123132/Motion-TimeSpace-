from stage_support import *

with worker("dimensions"):
    dimensions = dict(tau=1, scale=0, k=-1, H=-1, eta=-1, z=0, sigma=0,
        B=-2, P=-2, D=-2, T=-2, Q=-2, Pi=-2, EB=-3, ED=-3, EQ=-3,
        Eeta=-2, C00=-1, F=-2, field=0, velocity=-1, M=-2, fb=-1, fv=-2)
    checks = {
        "density_constraint": len({dimensions["H"]+dimensions["z"], dimensions["D"]-dimensions["k"], dimensions["eta"]}) == 1,
        "shear_definition": dimensions["sigma"] == dimensions["z"] == dimensions["Q"]-2*dimensions["k"],
        "eta_evolution": dimensions["eta"]-1 == dimensions["Q"],
        "background_balance": dimensions["B"]-1 == dimensions["H"]+dimensions["B"] == dimensions["EB"],
        "density_balance": dimensions["D"]-1 == dimensions["H"]+dimensions["T"] == dimensions["k"]+dimensions["Q"] == dimensions["k"]+dimensions["z"]+dimensions["B"] == dimensions["ED"],
        "current_balance": dimensions["Q"]-1 == dimensions["H"]+dimensions["Q"] == dimensions["k"]+dimensions["T"] == dimensions["EQ"],
        "trace_equation": dimensions["z"]-1 == dimensions["H"]+dimensions["z"] == dimensions["eta"] == dimensions["T"]-dimensions["k"],
        "trace_contacts": dimensions["ED"]-dimensions["k"]-dimensions["H"] == dimensions["z"]+dimensions["EB"]-2*dimensions["H"] == dimensions["Eeta"]-dimensions["H"] == dimensions["C00"] == dimensions["z"]+dimensions["F"]-dimensions["H"] == -1,
        "shear_contacts": dimensions["EQ"]-2*dimensions["k"] == dimensions["sigma"]-1 == dimensions["Pi"]-dimensions["k"] == -1,
        "scalar_enthalpy": 2*dimensions["velocity"] == dimensions["M"]+2*dimensions["field"] == dimensions["B"],
        "scalar_background_contacts": dimensions["H"]+dimensions["M"]+2*dimensions["field"] == dimensions["velocity"]+dimensions["fv"] == dimensions["M"]+dimensions["field"]+dimensions["fb"] == dimensions["EB"],
    }
    write(ROOT / "dimensional-result.json", {"passed": all(checks.values()), "checks": checks, "length_powers": dimensions,
        "clarifies_frozen_document": "DIMENSIONAL-CLARIFICATION.md", "no_equation_or_numerical_change": True})
    require(all(checks.values()), "retained equation units")
    print(json.dumps({"passed": True, "checks": len(checks)}))
