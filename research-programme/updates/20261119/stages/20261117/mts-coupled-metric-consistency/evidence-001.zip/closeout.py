from stage_support import *

guard()
process = psutil.Process()
process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
allowed = process.cpu_affinity()
process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
report = read(ROOT / "metric-result.json")
verification = read(ROOT / "verification.json")
require(verification["verified"], "completed verification")
require(exited(read(ROOT / "CLEANUP-VERIFIED.json")["foreground_checker"])["exited"], "verification process exited")
array_checks = {}
for case in CONFIG["cases"]:
    for steps in CONFIG["steps"]:
        old = load(PREVIOUS / (case + "-coupled-" + str(steps) + ".npz"))
        new = load(ROOT / (case + "-metric-" + str(steps) + ".npz"))
        for name, expected in old.items():
            actual = new[name]
            array_checks[case + "_" + str(steps) + "_" + name] = bool(
                expected.dtype == actual.dtype and expected.shape == actual.shape and expected.tobytes() == actual.tobytes())
require(all(array_checks.values()), "bitwise original arrays, including signed zero")
require(not list(ROOT.rglob("__pycache__")), "no bytecode")
artifacts = {}
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name != "closeout.json":
        guard()
        artifacts[path.relative_to(ROOT).as_posix()] = {"sha256": digest(path), "bytes": path.stat().st_size}
output = {
    "stage": "Common-metric pressure consistency on coupled cosmological histories",
    "utc": datetime.now(timezone.utc).isoformat(),
    "completed": True, "verification_passed": True,
    "physical_metric_gates_pass_both_cases": all(item["coherent_raw_metric_gate_passed"] for item in report["cases"].values()),
    "strict_original_aggregate": report["metric_stage_passed"],
    "strict_aggregate_limitation": "Baseline pressure omission lies within broad2e-5 physical budget; not relabelled as detected.",
    "post_result_identity_controls_pass": read(ROOT / "control-identity-result.json")["identity_controls_passed"],
    "all_scientific_checks_passed": False,
    "inherited_baseline_response_failures": report["cases"]["cold"]["inherited_scientific_failures"],
    "inherited_baseline_background_relative_failures": 4,
    "bitwise_original_output_arrays": array_checks,
    "full_mts_pressure_gate_fraction": report["cases"]["heavy"]["inherited_full_preparation"]["components"]["pressure"]["gate_consumption_fraction"],
    "frozen_paths_verified": verification["frozen_paths"],
    "previous_stage_artifacts_verified": verification["previous_stage_artifacts_checked"],
    "original_bank_grids_parameters_tolerances_unchanged": True,
    "full_corrected_native_restart_saved": False,
    "quantum_measure_included": False, "github_actions": False,
    "owner_goal_last_observed": "active via get_goal in this turn; not changed by this stage",
    "no_continuing_worker": True,
    "foreground_checker": identity(process),
    "foreground_exit_verified_by": "terminal completion outside this receipt",
    "authoritative_results": ["metric-result.json", "control-identity-result.json", "verification.json", "RESULTS.md"],
    "artifact_count": len(artifacts), "artifacts": artifacts,
}
write(ROOT / "closeout.json", output)
print(json.dumps({"completed": True, "sha256": digest(ROOT / "closeout.json"), "artifacts": len(artifacts),
                  "bitwise_array_checks": len(array_checks), "physical_metric_pass": output["physical_metric_gates_pass_both_cases"],
                  "strict_original_aggregate": output["strict_original_aggregate"], "frozen_paths": output["frozen_paths_verified"]}))

