from metric_stable import *
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("--replay", action="store_true")
args = parser.parse_args()
label = "control-identity-replay" if args.replay else "control-identity"
with worker(label):
    if args.replay:
        inputs = read(ROOT / "control-identity-inputs.json")
        check_inputs(inputs)
    else:
        extra = ["check_negative_controls.py", "metric_stable.py", "metric-result.json", "CONTROL-INTERPRETATION.md"]
        extra += [case + suffix for case in CONFIG["cases"] for suffix in ("-metric-64.npz", "-reference-metric.npz")]
        inputs = freeze(label, tuple(extra))
    cases = {}
    for case in CONFIG["cases"]:
        packet = load(ROOT / (case + "-metric-64.npz"))["metric"][:, :, 1]
        norms = load(ROOT / (case + "-reference-metric.npz"))["norms"]
        wave = CONFIG["retained_comoving_wave"]
        trace_identity = field(packet, "trace_residual") - field(packet, "predicted_trace_residual")
        shear_identity = field(packet, "shear_residual") - field(packet, "predicted_shear_residual")
        cases[case] = {}
        for name, identity_error, omitted, norm in (
            ("pressure", trace_identity, 3*field(packet, "pressure")/(2*wave), norms[3]),
            ("anisotropic_stress", shear_identity, field(packet, "anisotropic_stress")/wave, norms[4])):
            correct = ratio(maximum(identity_error), norm, CONFIG["algebra_tolerance"])
            removed = ratio(maximum(identity_error-omitted), norm, CONFIG["algebra_tolerance"])
            cases[case][name] = {
                "correct_identity": correct, "omitted_identity": removed,
                "omission_rejected_by_existing_identity_gate": not removed["passed"],
                "original_physical_gate_result": read(ROOT / "metric-result.json")["cases"][case]["negative_controls"][
                    "trace_without_pressure" if name == "pressure" else "shear_without_anisotropic_stress"],
            }
    result = {
        "cases": cases,
        "identity_controls_passed": all(item["correct_identity"]["passed"] and item["omission_rejected_by_existing_identity_gate"]
                                       for data in cases.values() for item in data.values()),
        "post_result_supplement": True,
        "original_strict_stage_flag_unchanged": read(ROOT / "metric-result.json")["metric_stage_passed"],
        "no_numerical_tolerance_or_norm_changed": True,
        "interpretation": "Physical closeness and equation-accounting sensitivity are different tests. Baseline pressure omission is below the broad physical budget but above the already-established algebra tolerance. Original weak control remains reported.",
    }
    check_inputs(inputs)
    if args.replay:
        require(result == read(ROOT / "control-identity-result.json"), "exact cached control supplement")
        write(ROOT / "control-identity-replay.json", {"exact": True})
    else:
        write(ROOT / "control-identity-result.json", result)
    require(result["identity_controls_passed"], "retained identity negative controls")
    print(json.dumps(result))

