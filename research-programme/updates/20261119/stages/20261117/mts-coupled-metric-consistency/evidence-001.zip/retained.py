from stage_support import *
import importlib

sys.path.insert(0, str(PREVIOUS))
import run_coupled as previous_run
import native_context as previous_context
previous_support = importlib.import_module("support")
previous_support.guard = guard
previous_run.guard = guard
previous_context.guard = guard
previous_context.BG.guard = guard
previous_run.ROOT = ROOT
previous_context.ROOT = ROOT
previous_run.CONFIG = CONFIG
previous_context.CONFIG = CONFIG
EX = previous_run.EX
BG = previous_run.BG
native_context = previous_context.native_context
Coupled = previous_run.Coupled
sys.path.remove(str(PREVIOUS))

