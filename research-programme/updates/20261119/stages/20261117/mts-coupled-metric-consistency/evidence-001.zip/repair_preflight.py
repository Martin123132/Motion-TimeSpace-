from metric_stable import *

with worker("stable-preflight"):
    inputs = freeze("stable-preflight", ("metric_stable.py", "repair_preflight.py",
        "cold-reference-metric.npz", "heavy-reference-metric.npz",
        "cold-preflight-capture.npz", "heavy-preflight-capture.npz",
        "cold-metric-preflight.json", "heavy-metric-preflight.json"))
    results = {}
    for case in CONFIG["cases"]:
        saved = load(ROOT / (case + "-reference-metric.npz"))
        capture = load(ROOT / (case + "-preflight-capture.npz"))
        packets = saved["packet"]
        species = packets[:, :84].reshape((-1, 7, 12))
        velocities = capture["packet"][:, [21, 33]].copy()
        if case == "cold":
            velocities[:, 1] = 0
        measured = stable_species_residuals(packets, velocities)
        output = read(ROOT / (case + "-metric-preflight.json"))
        checks = output["checks"].copy()
        for component, name in enumerate(SCHEMA["species"]):
            for column, equation in enumerate(("background", "density", "current")):
                checks[name + "_" + equation + "_contact"] = ratio(
                    maximum(measured[:, component, column] - species[:, component, 9 + column]),
                    saved["component_norms"][component, column], CONFIG["algebra_tolerance"])
        output.update(checks=checks, passed=all(item["passed"] for item in checks.values()),
            repair="Only scalar enthalpy evaluation B+P=v^2; original packets, failed receipts, norms and tolerances unchanged.",
            corrected_evolution_tested=False, raw_metrics_are_separate_acceptance_tests=True)
        write(ROOT / (case + "-stable-preflight.json"), output)
        results[case] = {"passed": output["passed"], "checks": len(checks),
            "slow_scalar_density_contact": checks["slow_scalar_density_contact"],
            "original_failed_worker_exited": exited(read(ROOT / (case + "-preflight-start.json")))}
        require(output["passed"], case + " stable readout preflight")
    check_inputs(inputs)
    write(ROOT / "stable-preflight-result.json", results)
    print(json.dumps(results))

