from metric_stable import *
import argparse

def summarize(case):
    reference = load(ROOT / (case + "-reference-metric.npz"))
    norms, component_norms = reference["norms"], reference["component_norms"]
    fine = load(ROOT / (case + "-metric-64.npz"))
    coarse = load(ROOT / (case + "-metric-32.npz"))
    packets, coarse_packets = fine["metric"], coarse["metric"]
    residual, coarse_residual = raw_residuals(packets), raw_residuals(coarse_packets)
    contacts = independent_contacts(packets)
    species = packets[..., :84].reshape((*packets.shape[:-1], 7, 12))
    component_residual = stable_species_residuals(packets, fine["metric_scalar_velocities"])
    algebra, refinement, raw, anatomy = {}, {}, {}, {}
    for branch, label in enumerate(("interpolated", "coherent")):
        raw[label] = {}
        for column, name in enumerate(EQUATIONS):
            values = residual[:, :, branch, column]
            step = values - coarse_residual[:, :, branch, column]
            raw[label][name] = {
                "raw": ratio(maximum(values), norms[column]),
                "step": ratio(maximum(step), norms[column]),
                "raw_plus_measured_refinement": ratio(maximum(abs(values)+abs(step)), norms[column]),
                "worst_report_node": list(map(int, np.unravel_index(np.argmax(abs(values)), values.shape))),
            }
            refinement[label + "_" + name] = raw[label][name]["step"]
            if column < 5:
                algebra[label + "_" + name + "_contacts"] = ratio(
                    maximum(values - contacts[:, :, branch, column]), norms[column], CONFIG["algebra_tolerance"])
            else:
                algebra[label + "_" + name + "_constraint"] = ratio(maximum(values), norms[column], CONFIG["algebra_tolerance"])
        for component, name in enumerate(SCHEMA["species"]):
            anatomy[label + "_" + name] = {}
            for column, equation in enumerate(("background", "density", "current")):
                measured = component_residual[:, :, branch, component, column]
                predicted = species[:, :, branch, component, 9 + column]
                algebra[label + "_" + name + "_" + equation] = ratio(
                    maximum(measured - predicted), component_norms[component, column], CONFIG["algebra_tolerance"])
                anatomy[label + "_" + name][equation] = {
                    "actual_absolute_maximum": maximum(measured), "predicted_absolute_maximum": maximum(predicted),
                    "on_original_component_scale": ratio(maximum(measured), component_norms[component, column]),
                }
        for name, reference_name in (("background_density_parity", "background_density"), ("background_pressure_parity", "background_density"),
            ("density_parity", "density"), ("current_parity", "current"), ("anisotropic_parity", "anisotropic_stress"),
            ("scalar_density_parity", "density"), ("scalar_pressure_parity", "pressure"), ("scalar_current_parity", "current")):
            algebra[label + "_" + name] = ratio(
                maximum(field(packets[:, :, branch], name)), maximum(field(reference["packet"], reference_name)), CONFIG["algebra_tolerance"])
        algebra[label + "_native_spatial_derivative_identity"] = ratio(
            maximum(field(packets[:, :, branch], "sigma_prime") - field(packets[:, :, branch], "native_sigma_prime") - field(packets[:, :, branch], "shear_residual")),
            norms[4], CONFIG["algebra_tolerance"])
    packet = packets[:, :, 1]
    wave = CONFIG["retained_comoving_wave"]
    negative = {
        "trace_without_pressure": ratio(maximum(field(packet, "trace_residual") - 3*field(packet, "pressure")/(2*wave)), norms[3]),
        "shear_without_anisotropic_stress": ratio(maximum(field(packet, "shear_residual") - field(packet, "anisotropic_stress")/wave), norms[4]),
    }
    exact = {}
    for steps in CONFIG["steps"]:
        run = fine if steps == 64 else coarse
        previous = load(PREVIOUS / (case + "-coupled-" + str(steps) + ".npz"))
        exact[str(steps)] = {name: bool(np.array_equal(value, run[name])) for name, value in previous.items()}
    budget = read(PREVIOUS / "preparation-result.json")["cases"][case]
    history_checks = read(PREVIOUS / "closeout.json")["scientific"][case]
    return {
        "original_arrays_exact": exact,
        "all_original_arrays_exact": all(all(items.values()) for items in exact.values()),
        "algebra_checks": algebra, "algebra_passed": all(item["passed"] for item in algebra.values()),
        "refinement_checks": refinement, "refinement_passed": all(item["passed"] for item in refinement.values()),
        "raw_metrics": raw,
        "coherent_raw_metric_gate_passed": all(item["raw_plus_measured_refinement"]["passed"] for item in raw["coherent"].values()),
        "interpolated_raw_metric_gate_passed": all(item["raw_plus_measured_refinement"]["passed"] for item in raw["interpolated"].values()),
        "negative_controls": negative, "omitted_terms_detected": all(not item["passed"] for item in negative.values()),
        "component_contact_anatomy": anatomy,
        "inherited_full_preparation": budget,
        "inherited_scientific_failures": history_checks["failures"],
        "metric_queries": int(np.prod(packets.shape[:2])), "branches": 2,
        "retained_regime": {
            name: np.unique(field(packets, name)).tolist()
            for name in ("tail_count", "nq_max", "massless_ufa")
        },
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    label = "metric-score-replay" if args.replay else "metric-score"
    with worker(label):
        if args.replay:
            inputs = read(ROOT / "metric-score-inputs.json")
            check_inputs(inputs)
        else:
            extra = ["metric_stable.py", "score_metric.py", "DERIVATION.md", "symbolic-result.json",
                     "DIMENSIONAL-CLARIFICATION.md", "check_dimensions.py", "dimensional-result.json"]
            for case in CONFIG["cases"]:
                extra += [case + "-reference-metric.npz", case + "-stable-preflight.json"]
                for steps in CONFIG["steps"]:
                    extra += [case + "-metric-" + str(steps) + ".npz", case + "-metric-" + str(steps) + "-result.json"]
            inputs = freeze(label, tuple(extra))
        cases = {case: summarize(case) for case in CONFIG["cases"]}
        report = {
            "cases": cases,
            "metric_stage_passed": all(item["all_original_arrays_exact"] and item["algebra_passed"] and item["refinement_passed"]
                                      and item["coherent_raw_metric_gate_passed"] and item["omitted_terms_detected"] for item in cases.values()),
            "inherited_baseline_tiny_response_failures_remain": True,
            "inherited_baseline_background_relative_failures": 4,
            "normalization": "Unchanged maximum equation-term sum over original934 states, frozen before corrected evolution",
            "refinement_estimates_not_rigorous_error_bounds": True,
            "quantum_measure_included": False, "new_fit_or_new_source_bank": False,
        }
        check_inputs(inputs)
        if args.replay:
            require(report == read(ROOT / "metric-result.json"), "exact cached metric report reproduction")
            write(ROOT / "metric-score-replay.json", {"exact": True})
        else:
            write(ROOT / "metric-result.json", report)
        print(json.dumps({"passed": report["metric_stage_passed"], "cases": {
            case: {"algebra_failed": {name: item for name, item in result["algebra_checks"].items() if not item["passed"]},
                   "raw": result["raw_metrics"], "negative": result["negative_controls"], "exact": result["all_original_arrays_exact"]}
            for case, result in cases.items()}}))

if __name__ == "__main__":
    main()

