from metric_math import *

def stable_species_residuals(packet, velocities):
    species = packet[..., :84].reshape((*packet.shape[:-1], 7, 12))
    hubble = field(packet, "hubble")[..., None]
    force = field(packet, "z")[..., None]
    enthalpy = (species[..., 0] + species[..., 1]).copy()
    require(velocities.shape == (*packet.shape[:-1], 2), "scalar primitive velocity shape")
    enthalpy[..., 5:7] = velocities**2
    wave = CONFIG["retained_comoving_wave"]
    background = species[..., 2] + hubble * (species[..., 0] + 3 * species[..., 1])
    density = species[..., 7] + hubble * (species[..., 3] + 3 * species[..., 5]) + wave * species[..., 4] + wave * force * enthalpy
    current = species[..., 8] + 2 * hubble * species[..., 4] - wave * (species[..., 5] - 2 * species[..., 6] / 3)
    return np.stack((background, density, current), axis=-1)

