from retained import *
import ctypes

SCHEMA = read(ROOT / "packet-schema.json")
COLUMNS = {name: 84 + index for index,name in enumerate(SCHEMA["global_columns"])}
EQUATIONS = ("background", "density", "current", "trace", "shear", "eta", "constraint", "friedmann")

def metric_reader():
    library = ctypes.CDLL(str(ROOT / "native/camb/cambdll.dll"))
    evaluate = library.mts_metric_packet
    evaluate.argtypes = [ctypes.c_double, ctypes.c_int, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
    evaluate.restype = None
    status = ctypes.c_int.in_dll(library, "mts_metric_status")
    def read_metric(tau, vector, background, corrected):
        state = np.ascontiguousarray(vector, dtype=np.float64)
        values = np.ascontiguousarray(background, dtype=np.float64)
        packet = np.zeros(128)
        evaluate(float(tau), len(state), ctypes.c_void_p(state.ctypes.data),
                 ctypes.c_void_p(values.ctypes.data), int(corrected), ctypes.c_void_p(packet.ctypes.data))
        require(status.value == 1 and np.all(np.isfinite(packet)), "finite metric readout")
        return packet
    return read_metric

def field(packet, name):
    return packet[..., COLUMNS[name]]

def scales(packet):
    hubble = field(packet,"hubble")
    density = field(packet,"density")
    pressure = field(packet,"pressure")
    current = field(packet,"current")
    background = field(packet,"background_density")
    background_pressure = field(packet,"background_pressure")
    force = field(packet,"z")
    shear = field(packet,"sigma")
    eta = field(packet,"eta_k")
    anisotropic = field(packet,"anisotropic_stress")
    wave = CONFIG["retained_comoving_wave"]
    species = packet[...,:84].reshape((*packet.shape[:-1],7,12))
    derivative_density = np.sum(species[...,7],axis=-1)
    derivative_current = np.sum(species[...,8],axis=-1)
    derivative_background = np.sum(species[...,2],axis=-1)
    terms = [
        abs(derivative_background)+abs(hubble*(background+3*background_pressure)),
        abs(derivative_density)+abs(hubble*(density+3*pressure))+abs(wave*current)+abs(wave*force*(background+background_pressure)),
        abs(derivative_current)+abs(2*hubble*current)+abs(wave*pressure)+abs(2*wave*anisotropic/3),
        abs(field(packet,"z_prime"))+abs(2*hubble*force)+abs(eta)+abs(3*pressure/(2*wave)),
        abs(field(packet,"sigma_prime"))+abs(2*hubble*shear)+abs(eta)+abs(anisotropic/wave),
        abs(field(packet,"eta_k_prime"))+abs(current/2),
        abs(hubble*force)+abs(density/(2*wave))+abs(eta),
        abs(3*hubble**2)+abs(background),
    ]
    return np.stack(terms,axis=-1)

def raw_residuals(packet):
    return np.stack([field(packet,name) for name in (
        "background_defect","density_defect","current_defect","trace_residual","shear_residual",
        "eta_residual","density_constraint","friedmann_constraint")],axis=-1)

def independent_contacts(packet):
    return np.stack([field(packet,name) for name in (
        "predicted_background_defect","predicted_density_defect","predicted_current_defect",
        "predicted_trace_residual","predicted_shear_residual")],axis=-1)

def species_residuals(packet):
    species = packet[...,:84].reshape((*packet.shape[:-1],7,12))
    hubble = field(packet,"hubble")[...,None]
    force = field(packet,"z")[...,None]
    wave = CONFIG["retained_comoving_wave"]
    background = species[...,2]+hubble*(species[...,0]+3*species[...,1])
    density = species[...,7]+hubble*(species[...,3]+3*species[...,5])+wave*species[...,4]+wave*force*(species[...,0]+species[...,1])
    current = species[...,8]+2*hubble*species[...,4]-wave*(species[...,5]-2*species[...,6]/3)
    return np.stack((background,density,current),axis=-1)

def species_scales(packet):
    species = packet[...,:84].reshape((*packet.shape[:-1],7,12))
    hubble = field(packet,"hubble")[...,None]
    force = field(packet,"z")[...,None]
    wave = CONFIG["retained_comoving_wave"]
    return np.stack((
        abs(species[...,2])+abs(hubble*(species[...,0]+3*species[...,1])),
        abs(species[...,7])+abs(hubble*(species[...,3]+3*species[...,5]))+abs(wave*species[...,4])+abs(wave*force*(species[...,0]+species[...,1])),
        abs(species[...,8])+abs(2*hubble*species[...,4])+abs(wave*species[...,5])+abs(2*wave*species[...,6]/3)),axis=-1)

def freeze(label, extra=()):
    mapping = read(ROOT / "inputs.json").copy()
    mapping.update(read(ROOT / "native-build-full-frozen.json"))
    for name in ("protocol.json","stage_support.py","retained.py","metric_math.py","packet-schema.json",
                 "native-build-full-result.json","native/camb/cambdll.dll",*extra):
        mapping[str(ROOT/name)] = digest(ROOT/name)
    check_inputs(mapping)
    write(ROOT/(label+"-inputs.json"),mapping)
    return mapping

