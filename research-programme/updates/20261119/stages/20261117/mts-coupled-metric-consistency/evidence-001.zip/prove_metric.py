from stage_support import *
import sympy as symbolic

def main():
    with worker("symbolic"):
        hubble, wave = symbolic.symbols("H k", nonzero=True)
        density, pressure, current, anisotropic, background, background_pressure = symbolic.symbols("D T Q Pi B P")
        force, eta, defect_b, defect_d, defect_q, defect_eta = symbolic.symbols("z eta EB ED EQ Eeta")
        density_prime = defect_d - hubble*(density+3*pressure) - wave*current - wave*force*(background+background_pressure)
        background_prime = defect_b - hubble*(background+3*background_pressure)
        current_prime = defect_q - 2*hubble*current + wave*(pressure-2*anisotropic/3)
        eta_prime = current/2 + defect_eta
        force_prime = (density_prime/(2*wave)+eta_prime-force*background_prime/(6*hubble))/hubble
        constraint = hubble*force-density/(2*wave)-eta
        friedmann = 3*hubble**2-background
        trace = force_prime+2*hubble*force-eta+3*pressure/(2*wave)
        predicted_trace = defect_d/(2*wave*hubble)-force*defect_b/(6*hubble**2)+defect_eta/hubble+constraint+force*friedmann/(3*hubble)
        shear = force+3*current/(2*wave**2)
        shear_prime = force_prime+3*current_prime/(2*wave**2)
        identities = {
            "trace_constraint_propagation": trace-predicted_trace,
            "shear_constraint_propagation": shear_prime+2*hubble*shear-eta+anisotropic/wave-trace-3*defect_q/(2*wave**2),
        }
        scalar, velocity, displacement, speed, mass, rate, field_contact, velocity_contact = symbolic.symbols("b v u w M r fb fv")
        scalar_prime = velocity+field_contact
        velocity_prime = -2*hubble*velocity-mass*scalar+velocity_contact
        speed_prime = -2*hubble*speed-(wave**2+mass)*displacement-wave*force*velocity
        scalar_background = (velocity**2+mass*scalar**2)/2
        scalar_pressure = (velocity**2-mass*scalar**2)/2
        scalar_density = velocity*speed+mass*scalar*displacement
        scalar_delta_pressure = velocity*speed-mass*scalar*displacement
        scalar_current = wave*velocity*displacement
        scalar_background_prime = velocity*velocity_prime+rate*mass*scalar**2+mass*scalar*scalar_prime
        scalar_density_prime = velocity_prime*speed+velocity*speed_prime+2*rate*mass*scalar*displacement+mass*(scalar_prime*displacement+scalar*speed)
        scalar_current_prime = wave*(velocity_prime*displacement+velocity*speed)
        identities.update({
            "primitive_scalar_enthalpy": scalar_background+scalar_pressure-velocity**2,
            "scalar_background_contact": scalar_background_prime+hubble*(scalar_background+3*scalar_pressure)-((rate-hubble)*mass*scalar**2+velocity*velocity_contact+mass*scalar*field_contact),
            "scalar_density_contact": scalar_density_prime+hubble*(scalar_density+3*scalar_delta_pressure)+wave*scalar_current+wave*force*velocity**2-(2*(rate-hubble)*mass*scalar*displacement+velocity_contact*speed+mass*field_contact*displacement),
            "scalar_current_contact": scalar_current_prime+2*hubble*scalar_current-wave*scalar_delta_pressure-wave*velocity_contact*displacement,
        })
        baryon, photon, delta_b, delta_g, velocity_b, flux_g, stress_g, sound, opacity = symbolic.symbols("Bb Bg db dg vb qg pig cs2 opacity")
        drag = photon*opacity*(4*velocity_b/3-flux_g)
        delta_b_prime = -wave*(force+velocity_b)
        velocity_b_prime = -hubble*velocity_b+wave*sound*delta_b-drag/baryon
        delta_g_prime = -wave*(4*force/3+flux_g)
        flux_g_prime = wave*(delta_g-2*stress_g)/3+drag/photon
        identities.update({
            "baryon_thermal_density_contact": baryon*(delta_b_prime-rate*delta_b)+hubble*baryon*(delta_b+3*sound*delta_b)+wave*baryon*velocity_b+wave*force*baryon-((hubble-rate)*baryon*delta_b+3*hubble*baryon*sound*delta_b),
            "baryon_drag": baryon*(velocity_b_prime-rate*velocity_b)+2*hubble*baryon*velocity_b-wave*baryon*sound*delta_b-((hubble-rate)*baryon*velocity_b-drag),
            "photon_density_contact": photon*(delta_g_prime-2*rate*delta_g)+2*hubble*photon*delta_g+wave*photon*flux_g+4*wave*force*photon/3-2*(hubble-rate)*photon*delta_g,
            "photon_drag": photon*(flux_g_prime-2*rate*flux_g)+2*hubble*photon*flux_g-wave*photon*(delta_g-2*stress_g)/3-(2*(hubble-rate)*photon*flux_g+drag),
            "internal_drag_cancellation": -drag+drag,
        })
        factor, rho, gas_pressure, rho_n = symbolic.symbols("f rho p rho_n")
        identities["neutrino_background_contact"] = factor*rate*(rho_n-2*rho)+hubble*factor*(rho+3*gas_pressure)-factor*((hubble-rate)*(rho+3*gas_pressure)+rate*(rho_n-rho+3*gas_pressure))
        particle_speed, weight, monopole, dipole, quadrupole = symbolic.symbols("vq W F0 F1 F2", nonzero=True)
        mono_prime = -wave*(particle_speed*dipole+4*force/3)
        dipole_prime = wave*particle_speed*(monopole-2*quadrupole)/3
        mode_density = weight*monopole/particle_speed
        mode_pressure = weight*particle_speed*monopole/3
        mode_current = weight*dipole
        mode_shear = weight*particle_speed*quadrupole
        identities.update({
            "neutrino_full_density_contact": weight*mono_prime/particle_speed-rate*(mode_density+3*mode_pressure)+hubble*(mode_density+3*mode_pressure)+wave*mode_current-((hubble-rate)*(mode_density+3*mode_pressure)-4*wave*force*weight/(3*particle_speed)),
            "neutrino_full_current_contact": weight*dipole_prime-2*rate*mode_current+2*hubble*mode_current-wave*(mode_pressure-2*mode_shear/3)-2*(hubble-rate)*mode_current,
        })
        tail_scale, scale, radiation_flux, tail_flux, radiation_source, tail_source = symbolic.symbols("s a qr qt Sr St")
        represented_mono_prime = -wave*(radiation_flux+4*force/3)+tail_scale*wave*(scale**2*radiation_flux-tail_flux)
        full_mono_prime = -wave*(particle_speed*(radiation_flux+tail_scale*tail_flux)+4*force/3)
        represented_dipole_prime = radiation_source+tail_scale*(tail_source-scale**2*radiation_source)
        full_dipole_prime = particle_speed*(radiation_source+tail_scale*tail_source)
        identities.update({
            "neutrino_tail_density_contact": represented_mono_prime-full_mono_prime-wave*((particle_speed-1+tail_scale*scale**2)*radiation_flux+tail_scale*(particle_speed-1)*tail_flux),
            "neutrino_tail_current_contact": represented_dipole_prime-full_dipole_prime-((1-tail_scale*scale**2-particle_speed)*radiation_source+tail_scale*(1-particle_speed)*tail_source),
        })
        simplified = {name: symbolic.simplify(value) for name, value in identities.items()}
        checks = {name: bool(value == 0) for name, value in simplified.items()}
        checks["omitted_baryon_thermal_contact_not_identity"] = bool(symbolic.simplify(3*hubble*baryon*sound*delta_b) != 0)
        checks["omitted_background_contact_not_identity"] = bool(symbolic.simplify(force*defect_b/(6*hubble**2)) != 0)
        checks["omitted_momentum_contact_not_identity"] = bool(symbolic.simplify(3*defect_q/(2*wave**2)) != 0)
        result = {"passed": all(checks.values()), "checks": checks,
            "identity_count": len(identities), "negative_controls": 3,
            "note": "Exact algebra within retained flat linear scalar equations; physical raw residual acceptance is a separate numerical test.",
            "source_sha256": digest(ROOT / "prove_metric.py")}
        write(ROOT / "symbolic-result.json", result)
        require(result["passed"], "metric derivation")
        print(json.dumps(result))

if __name__ == "__main__":
    main()

