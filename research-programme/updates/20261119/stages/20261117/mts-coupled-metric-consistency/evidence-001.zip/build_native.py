from stage_support import *
import ctypes
import subprocess

def drive_target(drive):
    buffer = ctypes.create_unicode_buffer(32768)
    return buffer.value if ctypes.windll.kernel32.QueryDosDeviceW(drive, buffer, len(buffer)) else None

with worker("build-native-full"):
    bootstrap = read(ROOT / "bootstrap.json")
    originals = {str(NATIVE / path): checksum for path, checksum in bootstrap["copied"].items()}
    check_inputs(originals)
    expected_changes = {"fortran/camb_python.f90"}
    changed = {path for path, checksum in bootstrap["copied"].items() if Path(path).suffix in (".f90", ".py", ".inc") and digest(ROOT / "native" / path) != checksum}
    require(changed == expected_changes, "declared private native edits")
    sources = {str(path): digest(path) for path in (ROOT / "native").rglob("*")
               if path.is_file() and path.suffix in (".f90", ".inc", ".py")}
    write(ROOT / "native-build-full-frozen.json", sources)
    drive = next((letter + ":" for letter in ("Z", "Y", "X", "W", "V") if drive_target(letter + ":") is None and not Path(letter + ":/").exists()), None)
    require(drive is not None, "temporary short-path drive available")
    commands, identities = [], {}
    mapped = False
    def capture(process):
        saved = identity(process)
        identities[(saved["pid"], saved["created"])] = saved
        return saved
    def run(command, log, cwd=None, environment=None, cleanup=False):
        if not cleanup:
            guard()
        process = subprocess.Popen(command, cwd=cwd, env=environment, stdout=log, stderr=log, creationflags=subprocess.CREATE_NO_WINDOW)
        row = {"command": command, "pid": process.pid}
        commands.append(row)
        try:
            row["identity"] = capture(psutil.Process(process.pid))
        except psutil.NoSuchProcess:
            row["exited_before_inspection"] = True
        try:
            while process.poll() is None:
                if not cleanup:
                    guard()
                try:
                    owner = psutil.Process(process.pid)
                    if "identity" in row and abs(owner.create_time() - row["identity"]["created"]) < .01:
                        for child in owner.children(recursive=True):
                            try:
                                capture(child)
                            except psutil.NoSuchProcess:
                                pass
                except psutil.NoSuchProcess:
                    pass
                time.sleep(.1)
            row["returncode"] = process.wait()
            require(row["returncode"] == 0, "native build command")
        except BaseException:
            for saved in reversed(list(identities.values())):
                if not exited(saved)["exited"]:
                    psutil.Process(saved["pid"]).terminate()
            process.wait(timeout=15)
            raise
    result = {"commands": commands, "state": "started"}
    try:
        with (ROOT / "native-build-full-log.txt").open("x") as log:
            run(["subst", drive, str(POST)], log)
            require(drive_target(drive).casefold() == ("\\??\\" + str(POST)).casefold(), "owned mapping")
            mapped = True
            alias = Path(drive + "/")
            chain = alias / "condensate-origin-20261003/native-two-field-transfer-20261007/toolchain/mingw64"
            native = alias / ROOT.name / "native"
            compiler = str(chain / "bin/gfortran.exe")
            environment = dict(os.environ, PATH=str(chain / "bin") + ";" + os.environ["PATH"])
            old = read(PREVIOUS / "native-build-full-result.json")
            old_commands = old["commands"]
            flags = ["-B" + (chain / suffix).as_posix() + "/" for suffix in (
                "libexec/gcc/x86_64-w64-mingw32/14.2.0", "lib", "bin",
                "lib/gcc/x86_64-w64-mingw32/14.2.0", "x86_64-w64-mingw32/lib")]
            flags += ["-L" + (chain / suffix).as_posix() + "/" for suffix in (
                "lib", "lib/gcc/x86_64-w64-mingw32/14.2.0", "x86_64-w64-mingw32/lib")]
            flags += ["-shared", "-static", "-cpp", "-fopenmp", "-O2", "-fcheck=bounds", "-fmax-errors=4", "-ffree-line-length-none"]
            (ROOT / "native/fortran/WinMetric").mkdir(exist_ok=False)
            objects = []
            for row in old_commands:
                command = row["command"]
                if "-c" not in command:
                    continue
                file = command[command.index("-c") - 1]
                target = "WinMetric/" + Path(file).stem + ".o"
                objects.append(target)
                run([compiler, *flags, file, "-c", "-o", target, "-JWinMetric"], log, native / "fortran", environment)
            run([compiler, *flags, *objects, "-o", "../camb/cambdll.dll", "-JWinMetric"], log, native / "fortran", environment)
            result.update(state="completed", dll_sha256=digest(ROOT / "native/camb/cambdll.dll"),
                          compiler_sha256=digest(POST / "condensate-origin-20261003/native-two-field-transfer-20261007/toolchain/mingw64/bin/gfortran.exe"),
                          objects=len(objects), recompiled="all retained source units; fresh module directory")
    except BaseException as error:
        result.update(state="failed", error=repr(error))
        raise
    finally:
        if mapped and drive_target(drive) == "\\??\\" + str(POST):
            with (ROOT / "native-full-unmap-log.txt").open("x") as log:
                run(["subst", drive, "/D"], log, cleanup=True)
        result["mapping_removed"] = drive_target(drive) is None
        result["children"] = [{"identity": saved, "outcome": exited(saved)} for saved in identities.values()]
        write(ROOT / "native-build-full-result.json", result)
    require(result["mapping_removed"] and all(row["outcome"]["exited"] for row in result["children"]), "build cleanup")
    check_inputs(sources)
    print(json.dumps({key: value for key, value in result.items() if key not in ("commands", "children")}))


