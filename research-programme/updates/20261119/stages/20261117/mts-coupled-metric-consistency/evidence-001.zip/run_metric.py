from metric_stable import *
import argparse

class MetricCoupled(Coupled):
    def __init__(self, *args):
        super().__init__(*args)
        self.read_metric = metric_reader()

    def rhs(self, tau, normalized):
        self.calls += 1
        if self.calls % 128 == 0:
            guard()
        return Coupled.evaluate(self, tau, normalized)[0]

    def evaluate(self, tau, normalized):
        rhs, values = Coupled.evaluate(self, tau, normalized)
        old, change, physical, work, work_change = self.unpack(normalized)
        background_packet = np.zeros(5)
        background_packet[:self.width] = values["background"]
        base = self.model.represented(tau)
        old_velocity = np.zeros(2)
        old_velocity[:len(base["velocity"])] = base["velocity"]
        values["metric"] = np.stack((self.read_metric(tau, old, background_packet, False),
                                    self.read_metric(tau, old + change, background_packet, True)))
        values["metric_scalar_velocities"] = np.stack((old_velocity, background_packet[[2, 4]]))
        return rhs, values

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("case", choices=CONFIG["cases"])
    parser.add_argument("steps", type=int, choices=CONFIG["steps"])
    args = parser.parse_args()
    case, steps = args.case, args.steps
    label = case + "-metric-" + str(steps)
    with worker(label):
        inputs = freeze(label, ("metric_stable.py", "run_metric.py",
            case + "-stable-preflight.json", "DERIVATION.md", "symbolic-result.json"))
        require(read(ROOT / (case + "-stable-preflight.json"))["passed"], "stable preflight")
        require(read(ROOT / "symbolic-result.json")["passed"], "derived metric identities")
        prepared, _, background, _, _ = EX.problem(case)
        with native_context(case, label) as (captured, metadata, sample):
            reference = load(ROOT / (case + "-preflight-capture.npz"))
            require(all(np.array_equal(value, reference[name]) for name, value in captured.items()), "original full state capture parity")
            system = MetricCoupled(case, prepared, background, captured, metadata, sample)
            outputs, integration = system.solve(steps)
            np.savez_compressed(ROOT / (label + ".npz"), **outputs)
            prior = load(PREVIOUS / (case + "-coupled-" + str(steps) + ".npz"))
            parity = {name: bool(np.array_equal(value, outputs[name])) for name, value in prior.items()}
            result = {"case": case, "steps": steps, "integration": integration,
                "original_output_arrays_exact": parity, "all_original_arrays_exact": all(parity.values()),
                "metric_shape": list(outputs["metric"].shape), "matched_once": True,
                "new_evolution_equations": False, "new_epochs": False}
            write(ROOT / (label + "-result.json"), result)
            check_inputs(inputs)
            print(json.dumps(result), flush=True)
            require(result["all_original_arrays_exact"], "readout restart preserves accepted source/response arrays exactly")

if __name__ == "__main__":
    main()

