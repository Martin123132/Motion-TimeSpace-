from stage_support import *
import shutil

with worker("bootstrap"):
    require(digest(PREVIOUS / "closeout.json") == CONFIG["previous_seal"], "accepted parent seal")
    seal = read(PREVIOUS / "closeout.json")
    frozen = {str(PREVIOUS / name): item["sha256"] for name,item in seal["artifacts"].items()}
    frozen[str(PREVIOUS / "closeout.json")] = CONFIG["previous_seal"]
    for name in ("score-inputs.json", "preparation-inputs.json"):
        for path, expected in read(PREVIOUS / name).items():
            require(path not in frozen or frozen[path] == expected, "consistent provenance")
            frozen[path] = expected
    for item in read(PREVIOUS / "verification-v2.json")["supplementary_provenance"]:
        frozen[item["path"]] = item["sha256"]
    check_inputs(frozen)
    target = ROOT / "native"
    require(not target.exists(), "fresh private native")
    shutil.copytree(NATIVE, target, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    copied = {path.relative_to(NATIVE).as_posix(): digest(path) for path in NATIVE.rglob("*")
              if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"}
    for name, expected in copied.items():
        require(digest(target / name) == expected, "exact private native copy")
    write(ROOT / "inputs.json", frozen)
    write(ROOT / "bootstrap.json", {"completed": True, "copied": copied, "frozen_paths": len(frozen)})
    print(json.dumps({"copied": len(copied), "frozen_paths": len(frozen)}))

