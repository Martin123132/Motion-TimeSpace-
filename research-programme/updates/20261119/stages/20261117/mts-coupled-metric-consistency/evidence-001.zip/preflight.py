from metric_math import *
import argparse
parser=argparse.ArgumentParser()
parser.add_argument("case",choices=CONFIG["cases"])
args=parser.parse_args()
case,label=args.case,args.case+"-preflight"
with worker(label):
    inputs=freeze(label,("preflight.py",))
    prepared,_,background,_,_=EX.problem(case)
    model=BG.Model(background,float(prepared["times"][0]))
    with native_context(case,label) as (captured,metadata,sample):
        saved=load(PREVIOUS/(case+"-preflight-capture.npz"))
        require(all(np.array_equal(value,saved[name]) for name,value in captured.items()),"complete saved capture preserved")
        metric=metric_reader()
        packets=[]
        for index,tau in enumerate(captured["clock"]):
            if index%64==0: guard()
            base=model.represented(float(tau))
            background_packet=np.zeros(5)
            background_packet[:len(model.norm)]=model.pack(base["scale"],base["field"],base["velocity"])
            packets.append(metric(tau,captured["reference"][index],background_packet,False))
        packets=np.array(packets)
        norms=np.max(scales(packets),axis=0)
        component_norms=np.max(species_scales(packets),axis=0)
        residual=raw_residuals(packets)
        contacts=independent_contacts(packets)
        checks={}
        for index,name in enumerate(EQUATIONS[:5]):
            checks[name+"_predicted_contacts"]=ratio(maximum(residual[:,index]-contacts[:,index]),norms[index],CONFIG["algebra_tolerance"])
        species=packets[:,:84].reshape((-1,7,12))
        measured=species_residuals(packets)
        for component,name in enumerate(SCHEMA["species"]):
            for column,label_name in enumerate(("background","density","current")):
                checks[name+"_"+label_name+"_contact"]=ratio(
                    maximum(measured[:,component,column]-species[:,component,9+column]),
                    component_norms[component,column],CONFIG["algebra_tolerance"])
        for column,name in enumerate(EQUATIONS[5:],start=5):
            checks[name+"_native_constraint"]=ratio(maximum(residual[:,column]),norms[column],CONFIG["algebra_tolerance"])
        for name,reference_name in (("background_density_parity","background_density"),("background_pressure_parity","background_density"),
            ("density_parity","density"),("current_parity","current"),("anisotropic_parity","anisotropic_stress"),
            ("scalar_density_parity","density"),("scalar_pressure_parity","pressure"),("scalar_current_parity","current")):
            checks[name]=ratio(maximum(field(packets,name)),maximum(field(packets,reference_name)),CONFIG["algebra_tolerance"])
        checks["native_spatial_sigma_identity"]=ratio(
            maximum(field(packets,"sigma_prime")-field(packets,"native_sigma_prime")-field(packets,"shear_residual")),
            norms[4],CONFIG["algebra_tolerance"])
        output={"passed":all(item["passed"] for item in checks.values()),"checks":checks,
                "norms":dict(zip(EQUATIONS,norms.tolist())),"component_norms":component_norms.tolist(),
                "raw":{name:ratio(maximum(residual[:,column]),norms[column]) for column,name in enumerate(EQUATIONS)},
                "normalization_frozen_before_corrected_test":True}
        np.savez_compressed(ROOT/(case+"-reference-metric.npz"),packet=packets,norms=norms,component_norms=component_norms)
        write(ROOT/(case+"-metric-preflight.json"),output)
        check_inputs(inputs)
        print(json.dumps({"case":case,"passed":output["passed"],"failed":{name:item for name,item in checks.items() if not item["passed"]},"raw":output["raw"]}))
        require(output["passed"],"native metric preflight")

