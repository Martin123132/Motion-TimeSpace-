from metric_stable import *
import ast
import subprocess

def remember(value, identities):
    if isinstance(value, dict):
        if all(name in value for name in ("pid", "created", "command")):
            identities[(value["pid"], value["created"])] = {name: value[name] for name in ("pid", "created", "command")}
        for item in value.values():
            remember(item, identities)
    elif isinstance(value, list):
        for item in value:
            remember(item, identities)

def main():
    guard()
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    checker = identity(process)
    report = read(ROOT / "metric-result.json")
    checks = {
        "private_scope": ROOT.resolve().is_relative_to(POST.resolve()),
        "previous_seal_unchanged": digest(PREVIOUS / "closeout.json") == CONFIG["previous_seal"],
        "symbolic_identities": read(ROOT / "symbolic-result.json")["passed"],
        "dimensional_clarification_checked": read(ROOT / "dimensional-result.json")["passed"],
        "exact_cached_replay": read(ROOT / "metric-score-replay.json")["exact"],
        "original_failed_receipts_preserved": all(not read(ROOT / (case + "-metric-preflight.json"))["passed"] for case in CONFIG["cases"]),
        "stable_readout_preflights_pass": all(read(ROOT / (case + "-stable-preflight.json"))["passed"] for case in CONFIG["cases"]),
        "strict_aggregate_failure_preserved": report["metric_stage_passed"] is False,
        "supplementary_identity_controls": read(ROOT / "control-identity-result.json")["identity_controls_passed"],
        "supplementary_control_replay_exact": read(ROOT / "control-identity-replay.json")["exact"],
        "inherited_failures_not_erased": bool(report["cases"]["cold"]["inherited_scientific_failures"]),
    }
    frozen = {}
    manifests = ["inputs.json", "native-build-full-frozen.json", "stable-preflight-inputs.json", "metric-score-inputs.json", "control-identity-inputs.json"]
    manifests += [case + "-preflight-inputs.json" for case in CONFIG["cases"]]
    manifests += [case + "-metric-" + str(steps) + "-inputs.json" for case in CONFIG["cases"] for steps in CONFIG["steps"]]
    for name in manifests:
        mapping = read(ROOT / name)
        check_inputs(mapping)
        for path, expected in mapping.items():
            require(path not in frozen or frozen[path] == expected, "consistent frozen provenance")
            frozen[path] = expected
    checks["all_frozen_paths_unchanged"] = True
    prior = read(PREVIOUS / "closeout.json")
    for relative, receipt in prior["artifacts"].items():
        path = PREVIOUS / relative
        require(path.is_file() and path.stat().st_size == receipt["bytes"] and digest(path) == receipt["sha256"], "previous sealed artifact unchanged")
    checks["previous_stage_all_artifacts_unchanged"] = True
    for case in CONFIG["cases"]:
        for steps in CONFIG["steps"]:
            prefix = case + "-metric-" + str(steps)
            checks[prefix + "_completed"] = read(ROOT / (prefix + "-end.json"))["completed"]
            checks[prefix + "_original_arrays_exact"] = read(ROOT / (prefix + "-result.json"))["all_original_arrays_exact"]
        result = report["cases"][case]
        checks[case + "_frozen_norms_exact"] = read(ROOT / (case + "-metric-preflight.json"))["norms"] == read(ROOT / (case + "-stable-preflight.json"))["norms"]
        checks[case + "_component_norms_exact"] = read(ROOT / (case + "-metric-preflight.json"))["component_norms"] == read(ROOT / (case + "-stable-preflight.json"))["component_norms"]
        checks[case + "_raw_metric_gate"] = result["coherent_raw_metric_gate_passed"]
        checks[case + "_negative_controls_honestly_classified"] = result["omitted_terms_detected"] == (case == "heavy")
    for path in ROOT.glob("*.py"):
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    checks["python_compiles"] = True
    checks["no_bytecode"] = not list(ROOT.rglob("__pycache__"))
    checks["no_stage_hold"] = not (ROOT / "STOP-REQUESTED").exists()
    checks["native_owners_released"] = all(read(path)["cleared"] and read(path)["native_reference_released"] for path in ROOT.glob("*-owner-release.json"))
    identities = {}
    for path in ROOT.glob("*-start.json"):
        remember(read(path), identities)
    remember(read(ROOT / "native-build-full-result.json"), identities)
    cleanup = [{"identity": saved, "outcome": exited(saved)} for saved in identities.values()]
    checks["recorded_workers_exited"] = all(item["outcome"]["exited"] for item in cleanup)
    mappings = subprocess.run(["subst"], capture_output=True, text=True, creationflags=subprocess.CREATE_NO_WINDOW, check=True).stdout
    checks["temporary_drive_mapping_removed"] = str(POST).replace("/", "\\").lower() not in mappings.lower()
    require(all(checks.values()), "verification failed: " + repr([name for name, passed in checks.items() if not passed]))
    write(ROOT / "verification.json", {"verified": True, "checks": checks, "frozen_paths": len(frozen),
        "previous_stage_artifacts_checked": len(prior["artifacts"]),
        "all_mathematical_and_numerical_claims_scoped_to_retained_interval": True,
        "inherited_baseline_failures": report["cases"]["cold"]["inherited_scientific_failures"],
        "inherited_background_failures": report["inherited_baseline_background_relative_failures"]})
    write(ROOT / "CLEANUP-VERIFIED.json", {"completed": True, "processes": cleanup, "count": len(cleanup),
        "foreground_checker": checker, "foreground_exit_verified_by": "terminal command completion outside receipt",
        "drive_mappings": mappings, "native_owners_released": True, "no_bytecode": True,
        "no_browsers_servers_or_subagents_started": True, "no_other_chat_processes_changed": True,
        "no_continuing_workers": True, "github_actions": False})
    print(json.dumps({"verified": True, "checks": len(checks), "frozen_paths": len(frozen), "previous_artifacts": len(prior["artifacts"]), "exited_identities": len(cleanup)}))

if __name__ == "__main__":
    main()

