from score_transport import *


def verify():
    inputs()
    replay = read(ROOT/'replay-score.json')
    checks = {'replay_score_repeat':score('replay') == replay}
    if (ROOT/'amplified-score.json').is_file():
        import amplified_control
        check_inputs(read(ROOT/'amplified-frozen.json')['files'])
        checks['amplified_score_repeat'] = amplified_control.score_amplified() == read(ROOT/'amplified-score.json')
        checks['original_failed_gate_preserved'] = not read(ROOT/'amplified-score.json')['original_replay_primary_gate']
        frozen = datetime.fromisoformat(read(ROOT/'amplified-frozen.json')['utc'])
        for steps in CONFIG['steps']:
            label = 'amplified-'+str(steps)
            data = load(ROOT/(label+'.npz'))
            terminal = load(ROOT/(label+'-terminal.npz'))
            checks[label+'_finite'] = all(np.isfinite(value).all() for value in data.values())
            checks[label+'_terminal_exact'] = np.array_equal(data['extended'][-1],terminal['normalized'])
            checks[label+'_owner_released'] = read(ROOT/(label+'-owner-release.json'))['cleared']
            checks[label+'_frozen_first'] = frozen < datetime.fromisoformat(read(ROOT/(label+'-start.json'))['utc'])
            core_size = int(terminal['core_size'])
            active = int(load(ROOT/('heavy-replay-'+str(steps)+'-parent-terminal.npz'))['dimensions'][1])
            probes = data['extended'][0,core_size:].reshape(4,2*active)
            checks[label+'_four_probes_same_start'] = all(np.array_equal(probe,data['extended'][0,:2*active]) for probe in probes)
            for path in ROOT.glob(label+'-boundary*.npz'):
                saved_batch = load(path)
                checks[path.stem+'_state_exact'] = np.array_equal(saved_batch['normalized'],data['extended'][int(saved_batch['completed'])])
    has_extension = (ROOT/'extension-score.json').is_file()
    checks['extension_only_after_gate'] = not has_extension or replay['primary_gate_pass']
    if has_extension:
        checks['extension_score_repeat'] = score('extension') == read(ROOT/'extension-score.json')
    for case in CONFIG['cases']:
        checks[case+'_preflight'] = read(ROOT/(case+'-preflight-result.json'))['passed']
    planned = [('heavy','replay')]
    if has_extension:
        planned.extend([('heavy','extension'),('cold','extension')])
    freeze_time = datetime.fromisoformat(read(ROOT/'prepare-end.json')['utc'])
    for case,segment in planned:
        for steps in CONFIG['steps']:
            label = case+'-'+segment+'-'+str(steps)
            data = load(ROOT/(label+'.npz'))
            checks[label+'_finite'] = all(np.isfinite(value).all() for value in data.values())
            checks[label+'_positive_clocks'] = bool(np.all(np.diff(data['time']) > 0))
            checks[label+'_owner_released'] = read(ROOT/(label+'-owner-release.json'))['cleared']
            checks[label+'_frozen_before_start'] = freeze_time < datetime.fromisoformat(read(ROOT/(label+'-start.json'))['utc'])
            for path in ROOT.glob(label+'-boundary*.npz'):
                saved_batch = load(path)
                index = int(saved_batch['completed'])
                checks[path.stem+'_state_exact'] = np.array_equal(saved_batch['normalized'],data['extended'][index])
                checks[path.stem+'_clock_exact'] = saved_batch['tau'] == data['time'][index]
            if case == 'heavy':
                terminal = load(ROOT/(label+'-transport-terminal.npz'))
                parent = load(ROOT/(label+'-parent-terminal.npz'))
                approximate = load(ROOT/(label+'-approximate-terminal.npz'))
                size,indices = int(terminal['native_size']),terminal['parent_indices']
                checks[label+'_full_terminal'] = np.array_equal(terminal['normalized'],data['extended'][-1])
                checks[label+'_approximate_terminal'] = np.array_equal(approximate['normalized'],data['extended'][-1,:size])
                checks[label+'_parent_terminal'] = np.array_equal(parent['normalized'][indices],data['extended'][-1,size+22:size+22+len(indices)])
                checks[label+'_same_units'] = np.array_equal(parent['units'],load(saved(case))['units']) and np.array_equal(approximate['units'],parent['units'])
                active,width = int(parent['dimensions'][1]),int(parent['dimensions'][2])
                background_slice = slice(2*active,2*active+width)
                checks[label+'_shared_background'] = np.array_equal(parent['normalized'][background_slice],approximate['normalized'][background_slice])
                checks[label+'_inverse_bound'] = bool(np.max(data['coefficient_integral']+.5*data['coefficient_integral']**2) < 1)
                checks[label+'_selected_regime'] = bool(np.all(data['extended'][:,int(parent['dimensions'][3])+4] == 0))
                if segment == 'replay':
                    checks[label+'_matched3040'] = np.array_equal(data['extended'][0,:size],load(saved(case))['normalized'])
                    checks[label+'_initial_errors_zero'] = bool(np.all(data['error_state'][0] == 0))
                    checks[label+'_initial_memory_zero'] = bool(np.all(data['coefficient_matrices'][0] == 0))
                else:
                    previous = load(ROOT/('heavy-replay-'+str(steps)+'-transport-terminal.npz'))
                    checks[label+'_all_memory_carried'] = np.array_equal(data['extended'][0],previous['normalized'])
                    checks[label+'_nonzero_memory_retained'] = bool(np.any(data['coefficient_matrices'][0] != 0) and np.any(data['error_state'][0] != 0))
            else:
                initial = load(SECOND/'cold-direct-64-terminal.npz')
                terminal = load(ROOT/(label+'-terminal.npz'))
                checks[label+'_same_initial'] = np.array_equal(data['extended'][0],initial['normalized'])
                checks[label+'_same_terminal'] = np.array_equal(data['extended'][-1],terminal['normalized'])
                checks[label+'_same_units'] = np.array_equal(terminal['units'],initial['units'])
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['no_bytecode'] = not list(ROOT.rglob('__pycache__'))
    result = {'checks':{name:bool(value) for name,value in checks.items()},'count':len(checks),'passed':all(checks.values()),'replay_primary_gate':replay['primary_gate_pass'],'extension_present':has_extension,'amplified_present':(ROOT/'amplified-score.json').is_file()}
    write(ROOT/'verification.json',result)
    print(json.dumps({name:result[name] for name in ('count','passed','replay_primary_gate','extension_present')}),flush=True)
    require(result['passed'],'technical checks: '+str([key for key,value in checks.items() if not value]))


if __name__ == '__main__':
    with worker('verify'):
        verify()
