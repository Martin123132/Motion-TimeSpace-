from amplified_control import *


if __name__ == '__main__':
    with worker('error-parity'):
        inputs()
        check_inputs(read(ROOT/'amplified-frozen.json')['files'])
        high,low = [load(ROOT/('amplified-'+str(steps)+'.npz')) for steps in (64,32)]
        saved_high,saved_low = [load(ROOT/('heavy-replay-'+str(steps)+'.npz')) for steps in (64,32)]
        checks = {}
        for branch,branch_name in enumerate(('old','coherent')):
            for family in ('source','readout'):
                if family == 'source':
                    current = high['error_source'][:,0]+(high['error_source'][:,1] if branch else 0.)
                    previous = low['error_source'][:,0]+(low['error_source'][:,1] if branch else 0.)
                    reference = saved_high['error_source'][:,0]+(saved_high['error_source'][:,1] if branch else 0.)
                    reference_low = saved_low['error_source'][:,0]+(saved_low['error_source'][:,1] if branch else 0.)
                    names = ('density','current','pressure')
                else:
                    current,previous = high['error_readout'][:,branch],low['error_readout'][:,branch]
                    reference,reference_low = saved_high['error_readout'][:,branch],saved_low['error_readout'][:,branch]
                    names = NAMES
                for component,name in enumerate(names):
                    checks[branch_name+'_'+name] = conservative(maximum(current[:,component]-reference[:,component]),maximum(current[:,component]-previous[:,component])+maximum(reference[:,component]-reference_low[:,component]),maximum(reference[:,component]),maximum(high['error_'+family+'_primitive'][:,branch,component])*2)
        result = {'checks':checks,'all_passed':all(value['passed'] for value in checks.values()),'scope':'scaled controls validate same transported error as original unamplified restart, on error-relative scale'}
        write(ROOT/'error-parity.json',result)
        require(result['all_passed'],'error prediction unchanged by independent probes')
        print(json.dumps({'all_passed':True,'count':len(checks),'maximum_relative_budget':max(value['relative'] for value in checks.values())}),flush=True)
