from restart_bridge import *
SECOND = Path(CONFIG['second_directory'])
sys.path.insert(0, str(SECOND))
from live_second import LiveSecond, coefficients, multiply
from run_phase import source_paths, readouts


def background_packet(system, clock, normalized):
    physical = system.unpack(normalized)[2]
    base = system.model.represented(clock)
    alpha, fields, velocities = system.model.unpack(physical)
    packet = np.zeros(5)
    packet[:system.width] = system.model.pack(base['scale']*(1+alpha), base['field']+fields, base['velocity']+velocities)
    return packet


class Transport:
    def __init__(self, direct, reduced):
        self.direct, self.reduced = direct, reduced
        self.native_size = len(direct.initial)
        self.approx_size = self.native_size+22
        self.active = direct.active
        self.background_slice = slice(2*self.active, 2*self.active+direct.width)
        self.parent_indices = np.r_[np.arange(2*self.active), np.arange(2*self.active+direct.width, self.native_size)]
        self.parent_size = len(self.parent_indices)
        self.error_units = direct.state_units*CONFIG['error_fraction']
        self.error_change_units = direct.delta_units*CONFIG['error_fraction']
        self.calls = 0

    def encode(self, native):
        return np.r_[self.reduced.encode(native), native[self.parent_indices], np.zeros(2*self.active)]

    def unpack(self, state):
        approximate = state[:self.approx_size]
        parent = approximate[:self.native_size].copy()
        begin = self.approx_size
        parent[self.parent_indices] = state[begin:begin+self.parent_size]
        errors = state[begin+self.parent_size:]
        old, change = np.zeros(self.direct.allocated), np.zeros(self.direct.allocated)
        old[:self.active] = errors[:self.active]*self.error_units
        change[:self.active] = errors[self.active:]*self.error_change_units
        return approximate, parent, old, change

    def calculate(self, clock, state, diagnostics):
        approximate, parent, old, change = self.unpack(state)
        approx_rhs, approx_values = self.reduced.calculate(clock, approximate, diagnostics)
        parent_rhs, parent_values = (self.direct.evaluate(clock, parent) if diagnostics else retained_run.Coupled.evaluate(self.direct, clock, parent))
        require(np.array_equal(approx_rhs[self.background_slice], parent_rhs[self.background_slice]), 'same independent background equation')
        packet = background_packet(self.direct, clock, parent)
        old_rhs = self.direct.sample(clock, old, packet, False)[0]
        new_old_rhs = self.direct.sample(clock, old, packet, True)[0]
        change_rhs = self.direct.sample(clock, change, packet, True)[0]
        delta_rhs = new_old_rhs-old_rhs+change_rhs
        residual = approx_values['field_truncation']
        old_rhs[self.reduced.selected] -= residual[0]
        delta_rhs[self.reduced.selected] -= residual[1]
        output = np.r_[approx_rhs, parent_rhs[self.parent_indices], old_rhs[:self.active]/self.error_units, delta_rhs[:self.active]/self.error_change_units]
        if not diagnostics:
            return output, None
        values = dict(approx_values)
        values.update({'parent_'+name: value for name, value in parent_values.items()})
        values['error_state'] = np.stack((old[:self.active], change[:self.active]))
        values['error_readout'] = np.stack((readouts(self.direct.read_metric(clock, old, packet, False)), readouts(self.direct.read_metric(clock, old+change, packet, True))))
        terms = coefficients(self.direct.model, self.direct.prepared, clock, self.direct.unpack(parent)[2])
        source = multiply(terms['source_matrix'], (old[self.reduced.selected], change[self.reduced.selected]))
        beta = terms['beta']
        density_current = (beta.base*source[0], (beta.base+beta.change)*source[1]+beta.change*source[0])
        phi, velocity, mu = (terms['raw'][name] for name in ('phi','velocity','mu'))
        pressure_old = velocity.base*old[self.reduced.selected[1]]-mu.base**2*phi.base*old[self.reduced.selected[0]]
        potential = mu**2*phi
        pressure_delta = (velocity.base+velocity.change)*change[self.reduced.selected[1]]+velocity.change*old[self.reduced.selected[1]]-(potential.base+potential.change)*change[self.reduced.selected[0]]-potential.change*old[self.reduced.selected[0]]
        values['error_source'] = np.stack((np.r_[density_current[0], beta.base*pressure_old], np.r_[density_current[1], (beta.base+beta.change)*pressure_delta+beta.change*pressure_old]))
        return output, values

    def rhs(self, clock, state):
        self.calls += 1
        if self.calls % 128 == 0:
            guard()
        return self.calculate(clock, state, False)[0]
