from restart_support import *
import importlib.metadata


if __name__ == '__main__':
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    available = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in available else available[-1]])
    mapping = read(ROOT/'inputs.json')
    check_inputs(mapping)
    verification = read(ROOT/'verification.json')
    require(verification['passed'],'technical verification')
    replay = read(ROOT/'replay-score.json')
    extension = read(ROOT/'extension-score.json') if verification['extension_present'] else None
    expected = {'prepare','cold-preflight','heavy-preflight','heavy-replay-32','heavy-replay-64','replay-score','verify'}
    if extension is not None:
        expected.update({'heavy-extension-32','heavy-extension-64','cold-extension-32','cold-extension-64','extension-score'})
    amplified = read(ROOT/'amplified-score.json') if verification['amplified_present'] else None
    if amplified is not None:
        expected.update({'amplified-freeze','amplified-32','amplified-64','amplified-score','error-parity'})
        check_inputs(read(ROOT/'amplified-frozen.json')['files'])
        require(read(ROOT/'error-parity.json')['all_passed'],'unamplified error prediction preserved')
    workers = {path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    require(set(workers) == {label+'-start.json' for label in expected},'exact task worker inventory')
    require(all(value['exited'] for value in workers.values()),'all exact task identities exited')
    for label in expected:
        begin,end = read(ROOT/(label+'-start.json')),read(ROOT/(label+'-end.json'))
        require(end['completed'] and all(begin[key] == end[key] for key in ('pid','created','command')),'identity-matched completed receipt')
    releases = {path.name:read(path) for path in ROOT.glob('*-owner-release.json')}
    require(len(releases) == (8 if extension is not None else 4)+(2 if amplified is not None else 0) and all(value['cleared'] for value in releases.values()),'native owners released')
    require(not list(ROOT.glob('*-failure.json')),'no hidden failed runs')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    for name in ('DERIVATION.md','RESULTS.md','NEXT.md'):
        require((ROOT/name).is_file(),'scientific handoff retained: '+name)
    closer = identity(process)
    write(ROOT/'cleanup.json',{'workers':workers,'all_exited':True,'native_owner_releases':releases,'closer_identity':closer,'closer_exit_verification':'after foreground returns','other_processes_changed':False,'temporary_tools':[],'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','psutil')}})
    artifacts = {str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name != 'closeout.json'}
    result = {'stage':'Coupled error transport with carried second-order memory','utc':datetime.now(timezone.utc).isoformat(),'completed':True,'verification_passed':True,'technical_checks':verification['count'],'replay_primary_gate_pass':replay['primary_gate_pass'],'extension_primary_gate_pass':extension['primary_gate_pass'] if extension is not None else None,'last_epoch':3042 if extension is not None else 3041,'future_source_metric_forcing':False,'certified_global_error_bound':False,'new_fitted_parameters':0,'frozen_inputs':len(mapping),'workers_exited':len(workers),'native_owners_released':len(releases),'github':False,'artifacts':artifacts}
    result['amplified_control_pass'] = amplified['all_passed'] if amplified is not None else None
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),'bytes':sum(value['bytes'] for value in artifacts.values()),'workers_exited':len(workers),'closer':closer}),flush=True)
