from transport import *
import argparse


def saved(case):
    return Path(CONFIG['live_directory'])/(case+('-phase-' if case=='heavy' else '-direct-')+'64-terminal.npz')


def prepare():
    require(digest(SECOND/'closeout.json') == CONFIG['second_seal'], 'retained second-order seal')
    mapping = read(SECOND/'inputs.json')
    mapping[str(SECOND/'closeout.json')] = CONFIG['second_seal']
    for name, entry in read(SECOND/'closeout.json')['artifacts'].items():
        mapping[str(SECOND/name)] = entry['sha256']
    check_inputs(mapping)
    cases = {}
    for case in CONFIG['cases']:
        path = source_paths(case)
        with np.load(path, allow_pickle=False) as archive:
            clocks = archive['conformal_time'][3040:3043]
        prepared, _, background, _, _ = EX.problem(case)
        require(len(clocks) == 3 and clocks[0] == float(load(saved(case))['tau']), 'saved3040 and two original intervals')
        cases[case] = {}
        for segment, begin, end in (('replay', clocks[0], clocks[1]), ('extension', clocks[1], clocks[2])):
            times = np.unique(np.r_[begin, background.boundaries(float(begin), float(end)), end])
            background.evaluate(times)
            require(np.all(np.diff(times)>0), 'unchanged positive support')
            np.savez_compressed(ROOT/(case+'-'+segment+'-clock.npz'), time=times, native_time=np.array([begin,end]), native_indices=np.array([0,len(times)-1]))
            cases[case][segment] = {'samples':len(times), 'elapsed_Mpc':float(end-begin)}
        mapping[str(path)] = digest(path)
    write(ROOT/'frozen-norms.json', read(SECOND/'frozen-norms.json'))
    write(ROOT/'preparation.json', {'before_evolution':True, 'cases':cases, 'rtol':CONFIG['rtol'], 'normalized_atol':CONFIG['normalized_atol'], 'future_source_metric_forcing':False})
    for path in sorted(ROOT.iterdir()):
        if path.suffix in ('.py','.json','.md','.npz') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix == '.py':
                compile(path.read_text(encoding='utf-8'), str(path), 'exec')
            mapping[str(path)] = digest(path)
    write(ROOT/'inputs.json', mapping)
    inputs()
    print(json.dumps(cases), flush=True)


def systems(case, captured, metadata, sample):
    previous = load(SECOND/(case+'-direct-64-capture.npz'))
    for name, value in captured.items():
        require(np.array_equal(value[:1051], previous[name]), 'known1051 capture exact: '+name)
    prepared, _, background, _, _ = EX.problem(case)
    initial = prefix(captured, case)
    direct = MetricCoupled(case, prepared, background, initial, metadata, sample)
    state = restore(direct, saved(case))
    restore(direct, SECOND/(case+'-direct-64-terminal.npz'))
    reduced = LiveSecond(case, prepared, background, initial, metadata, sample) if case == 'heavy' else None
    return direct, reduced, state


def preflight(case):
    inputs()
    label = case+'-preflight'
    with native_context(case, label) as (captured, metadata, sample):
        direct, reduced, state = systems(case, captured, metadata, sample)
        data = load(SECOND/(case+'-direct-64.npz'))
        random = np.random.default_rng(20261117)
        checks, offsets = {}, {}
        for location in (0,len(data['time'])//2,len(data['time'])-1):
            clock = float(data['time'][location])
            native = data['normalized'][location]
            packet = background_packet(direct, clock, native)
            old, _, _, _, _ = direct.unpack(native)
            trial = np.zeros(direct.allocated)
            trial[:direct.active] = random.normal(size=direct.active)*direct.state_units*.001
            if case == 'heavy':
                require(old[direct.first+4] == 0, 'retained zero selector; not a perturbation')
                trial[direct.first+4] = 0
            zero = np.zeros(direct.allocated)
            inactive = old.copy()
            inactive[:direct.active] = 0
            for corrected in (False,True):
                key = str(location)+'_'+str(corrected)
                zero_rhs = sample(clock, zero, packet, corrected)[0]
                checks[key+'_zero_rhs_exact'] = bool(np.all(zero_rhs == 0))
                zero_read = readouts(direct.read_metric(clock, zero, packet, corrected))
                checks[key+'_zero_readout_exact'] = bool(np.all(zero_read == 0))
                original = sample(clock, old, packet, corrected)[0]
                perturbation = sample(clock, trial, packet, corrected)[0]
                combined = sample(clock, old+trial, packet, corrected)[0]
                doubled = sample(clock, -2.5*trial, packet, corrected)[0]
                scale = max(maximum(original[:direct.active]/direct.state_units), maximum(perturbation[:direct.active]/direct.state_units))
                checks[key+'_additivity'] = ratio(maximum((combined-original-perturbation)[:direct.active]/direct.state_units), scale, CONFIG['algebra_tolerance'])['passed']
                checks[key+'_homogeneity'] = ratio(maximum((doubled+2.5*perturbation)[:direct.active]/direct.state_units), scale, CONFIG['algebra_tolerance'])['passed']
                offset = sample(clock, inactive, packet, corrected)[0]
                active_only = old-inactive
                active_rhs = sample(clock, active_only, packet, corrected)[0]
                checks[key+'_inactive_affine_cancels'] = ratio(maximum((original-active_rhs-offset)[:direct.active]/direct.state_units), scale, CONFIG['algebra_tolerance'])['passed']
                offsets[key] = maximum(offset[:direct.active]/direct.state_units)
        if case == 'heavy':
            system = Transport(direct,reduced)
            initial = system.encode(state['normalized'])
            initial_rhs, values = system.calculate(float(state['tau']),initial,True)
            checks['initial_error_rhs_zero'] = bool(np.all(initial_rhs[-2*direct.active:] == 0))
            checks['initial_sources_equal'] = np.array_equal(values['source'],values['parent_source'])
            trial = initial.copy()
            delta_old = random.normal(size=direct.active)*1e-7
            delta_change = random.normal(size=direct.active)*1e-7
            delta_old[direct.first+4] = delta_change[direct.first+4] = 0
            trial[:direct.active] += delta_old
            trial[direct.active:2*direct.active] += delta_change
            trial[-2*direct.active:-direct.active] = delta_old/CONFIG['error_fraction']
            trial[-direct.active:] = delta_change/CONFIG['error_fraction']
            trial[system.native_size:system.native_size+16] = random.normal(size=16)*.02
            rhs, values = system.calculate(float(state['tau']),trial,True)
            parent_rhs = np.zeros(system.native_size)
            parent_rhs[system.parent_indices] = rhs[system.approx_size:system.approx_size+system.parent_size]
            predicted = np.r_[rhs[-2*direct.active:-direct.active]*CONFIG['error_fraction'],rhs[-direct.active:]*CONFIG['error_fraction']]
            measured = rhs[:2*direct.active]-parent_rhs[:2*direct.active]
            checks['nonzero_residual_transport_identity'] = ratio(maximum(predicted-measured),max(maximum(rhs[:2*direct.active]),1.),CONFIG['algebra_tolerance'])['passed']
            for branch in (0,1):
                observed = values['source']+(values['source_change'] if branch else 0.)-values['parent_source']-(values['parent_source_change'] if branch else 0.)
                predicted = values['error_source'][0]+(values['error_source'][1] if branch else 0.)
                checks['nonzero_source_map_'+str(branch)] = maximum((observed-predicted)/np.array(read(ROOT/'frozen-norms.json')[case]['source_norm'])) < CONFIG['algebra_tolerance']
        result = {'passed':all(checks.values()),'checks':{name:bool(value) for name,value in checks.items()},'inactive_affine_rhs_norm':offsets,'known1051_prefix_exact':True,'scope':'fixed selector and native regime; sampled operators, not global proof'}
        write(ROOT/(label+'-result.json'),result)
        require(result['passed'], 'preflight: '+str([key for key,value in checks.items() if not value]))
        print(json.dumps({'case':case,'checks':len(checks),'passed':True}),flush=True)
    inputs()


def run(case, segment, steps):
    inputs()
    require(read(ROOT/(case+'-preflight-result.json'))['passed'],'preflight required')
    require(case == 'heavy' or segment == 'extension','new cold control only; saved replay controls retained')
    if segment == 'extension':
        require(read(ROOT/'replay-score.json')['primary_gate_pass'],'transport replay gates before extension')
    label = case+'-'+segment+'-'+str(steps)
    with native_context(case,label) as (captured,metadata,sample):
        direct,reduced,state = systems(case,captured,metadata,sample)
        clocks = load(ROOT/(case+'-'+segment+'-clock.npz'))
        times = clocks['time']
        if case == 'heavy':
            system = Transport(direct,reduced)
            if segment == 'replay':
                current = system.encode(state['normalized'])
            else:
                prior = load(ROOT/('heavy-replay-'+str(steps)+'-transport-terminal.npz'))
                require(float(prior['tau']) == times[0], 'continuous carried clock')
                current = prior['normalized'].copy()
                require(np.array_equal(system.rhs(float(times[0]),current),prior['actual_rhs']), 'carried error/K/state RHS exact')
            evaluate = lambda clock,vector: system.calculate(clock,vector,True)[1]
            rhs = system.rhs
        else:
            system = direct
            state = restore(direct,SECOND/'cold-direct-64-terminal.npz')
            current = state['normalized'].copy()
            require(float(state['tau']) == times[0], 'cold3041 restart exact')
            evaluate = lambda clock,vector: direct.evaluate(clock,vector)[1]
            rhs = direct.rhs
        states = [current.copy()]
        initial_values = evaluate(float(times[0]),current)
        observed = {name:np.empty((len(times),*np.asarray(value).shape)) for name,value in initial_values.items()}
        for name,value in initial_values.items():
            observed[name][0] = value
        evaluations = 0
        for position,(left,right) in enumerate(zip(times[:-1],times[1:])):
            guard()
            solution = solve_ivp(rhs,(float(left),float(right)),current,method='DOP853',t_eval=[right],rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(direct.prepared['elapsed'][8])/steps)
            require(solution.success,'coupled error/parent continuation')
            current = solution.y[:,-1]
            evaluations += solution.nfev
            states.append(current.copy())
            for name,value in evaluate(float(right),current).items():
                observed[name][position+1] = value
            if (position+1)%CONFIG['batch_boundaries'] == 0 or position == len(times)-2:
                np.savez_compressed(ROOT/(label+'-boundary'+str(position+1)+'.npz'),tau=np.array(right),normalized=current,actual_rhs=rhs(float(right),current),completed=np.array(position+1))
                print(json.dumps({'label':label,'boundary':position+1,'total':len(times)-1}),flush=True)
        rows = slice(-3,-1) if segment == 'replay' else slice(-2,None)
        require(np.array_equal(captured['clock'][rows],clocks['native_time']),'original endpoint clocks unchanged')
        reference = captured['observation_reference'][rows]
        control = np.column_stack((-CONFIG['retained_comoving_wave']*(reference[:,26]+reference[:,5])/reference[:,28],reference[:,9],reference[:,21],reference[:,20]-.75*reference[:,21],reference[:,26]-.75*reference[:,24]))
        np.savez_compressed(ROOT/(label+'.npz'),time=times,extended=np.array(states),native_indices=clocks['native_indices'],native_control=control,**observed)
        if case == 'heavy':
            approximate,parent,old_error,change_error = system.unpack(current)
            checkpoint(direct,float(times[-1]),parent,ROOT/(label+'-parent-terminal.npz'))
            checkpoint(direct,float(times[-1]),approximate[:system.native_size],ROOT/(label+'-approximate-terminal.npz'))
            np.savez_compressed(ROOT/(label+'-transport-terminal.npz'),tau=np.array(times[-1]),normalized=current,actual_rhs=rhs(float(times[-1]),current),parent_indices=system.parent_indices,error_units=system.error_units,error_change_units=system.error_change_units,native_size=np.array(system.native_size))
        else:
            checkpoint(direct,float(times[-1]),current,ROOT/(label+'-terminal.npz'))
        write(ROOT/(label+'-result.json'),{'completed':True,'case':case,'segment':segment,'steps':steps,'samples':len(times),'evaluations':evaluations,'last_epoch':3041 if segment=='replay' else 3042,'future_source_metric_forcing':False,'shared_background_equation':True,'independent_parent_perturbations':True,'coefficient_memory_reset':False})
    inputs()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command',choices=('prepare','preflight','run'))
    parser.add_argument('--case',choices=CONFIG['cases'],default='heavy')
    parser.add_argument('--segment',choices=('replay','extension'),default='replay')
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=32)
    arguments = parser.parse_args()
    label = 'prepare' if arguments.command == 'prepare' else arguments.case+'-'+('preflight' if arguments.command == 'preflight' else arguments.segment+'-'+str(arguments.steps))
    with worker(label):
        if arguments.command == 'prepare': prepare()
        elif arguments.command == 'preflight': preflight(arguments.case)
        else: run(arguments.case,arguments.segment,arguments.steps)
