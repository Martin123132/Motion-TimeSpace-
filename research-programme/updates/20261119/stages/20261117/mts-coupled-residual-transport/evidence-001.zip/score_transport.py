from run_transport import *
from score_phase import conservative
from verify_phase import primitive_envelope
NAMES = ('native_velocity','native_weyl','photon_density','relative_density','velocity_slip')


def physical(data, branch, prefix=''):
    return data[prefix+'source']+(data[prefix+'source_change'] if branch else 0.)


def ordinary(data, coarse, case, prefix=''):
    norms = read(ROOT/'frozen-norms.json')[case]
    high, low = readouts(data[prefix+'metric']),readouts(coarse[prefix+'metric'])
    envelopes = primitive_envelope(data[prefix+'metric'])+primitive_envelope(coarse[prefix+'metric'])
    checks, independent, accounted = {}, {}, {}
    for branch, name in enumerate(('old','coherent')):
        for component, quantity in enumerate(NAMES):
            step = maximum(high[:,branch,component]-low[:,branch,component])
            checks[name+'_'+quantity] = conservative(0.,step,norms['readout_norm'][component],maximum(envelopes[:,branch,component]))
            if branch == 0:
                independent[quantity] = conservative(maximum(high[data['native_indices'],branch,component]-data['native_control'][:,component]),step,norms['readout_norm'][component],maximum(envelopes[:,branch,component]))
        source, previous = physical(data,branch,prefix),physical(coarse,branch,prefix)
        work = data[prefix+'work']+(data[prefix+'work_change'] if branch else 0.)
        work_low = coarse[prefix+'work']+(coarse[prefix+'work_change'] if branch else 0.)
        for component, quantity in enumerate(('density','current','pressure')):
            checks[name+'_'+quantity] = conservative(0.,maximum(source[:,component]-previous[:,component]),norms['source_norm'][component],maximum(abs(source[:,component])+abs(previous[:,component])))
        for component, section in ((0,slice(0,6)),(1,slice(6,9))):
            residual = source[:,component]-source[0,component]-np.sum(work[:,section]-work[0,section],axis=1)
            lower = previous[:,component]-previous[0,component]-np.sum(work_low[:,section]-work_low[0,section],axis=1)
            amplitude = maximum(abs(source[:,component])+np.sum(abs(work[:,section]),axis=1))
            checks[name+'_raw_exchange_'+str(component)] = conservative(maximum(residual),maximum(residual-lower),norms['source_norm'][component],amplitude)
            if not prefix and 'truncation_work' in data:
                defect = data['truncation_work'][:,0,component]+(data['truncation_work'][:,1,component] if branch else 0.)
                defect_low = coarse['truncation_work'][:,0,component]+(coarse['truncation_work'][:,1,component] if branch else 0.)
                corrected = residual-(defect-defect[0])
                corrected_low = lower-(defect_low-defect_low[0])
                accounted[name+'_'+str(component)] = conservative(maximum(corrected),maximum(corrected-corrected_low),norms['source_norm'][component],amplitude+maximum(defect))
    for name,index in (('trace_residual',3),('shear_residual',4),('eta_residual',5),('density_constraint',6),('friedmann_constraint',7)):
        values,previous = field(data[prefix+'metric'][:,1],name),field(coarse[prefix+'metric'][:,1],name)
        checks['coherent_'+name] = conservative(maximum(values),maximum(values-previous),norms['metric_norm'][index],norms['metric_norm'][index])
    response = high[:,1,0]-high[:,0,0]
    small = conservative(0.,maximum(response-(low[:,1,0]-low[:,0,0])),maximum(response),maximum(envelopes[:,0,0]+envelopes[:,1,0]))
    return {'checks':checks,'passed':all(value['passed'] for value in checks.values()),'independent_native':independent,'independent_native_passed':all(value['passed'] for value in independent.values()),'defect_accounted':accounted,'small_response_precision':small,'response_amplitude':maximum(response),'final_response':float(response[-1])}


def score(segment):
    fine,coarse = [load(ROOT/('heavy-'+segment+'-'+str(steps)+'.npz')) for steps in (64,32)]
    require(np.array_equal(fine['time'],coarse['time']),'fixed diagnostic clocks')
    norms = read(ROOT/'frozen-norms.json')['heavy']
    approximate = ordinary(fine,coarse,'heavy')
    parent = ordinary(fine,coarse,'heavy','parent_')
    full, relative, discrepancy = {}, {}, {}
    for branch,name in enumerate(('old','coherent')):
        for family in ('source','readout'):
            if family == 'source':
                measured = physical(fine,branch)-physical(fine,branch,'parent_')
                measured_low = physical(coarse,branch)-physical(coarse,branch,'parent_')
                predicted = fine['error_source'][:,0]+(fine['error_source'][:,1] if branch else 0.)
                predicted_low = coarse['error_source'][:,0]+(coarse['error_source'][:,1] if branch else 0.)
                amplitude = abs(physical(fine,branch))+abs(physical(fine,branch,'parent_'))
                names, units = ('density','current','pressure'),norms['source_norm']
            else:
                measured = readouts(fine['metric'])[:,branch]-readouts(fine['parent_metric'])[:,branch]
                measured_low = readouts(coarse['metric'])[:,branch]-readouts(coarse['parent_metric'])[:,branch]
                predicted,predicted_low = fine['error_readout'][:,branch],coarse['error_readout'][:,branch]
                amplitude = primitive_envelope(fine['metric'])[:,branch]+primitive_envelope(fine['parent_metric'])[:,branch]
                names, units = NAMES,norms['readout_norm']
            for component,quantity in enumerate(names):
                key = name+'_'+quantity
                residual = maximum(predicted[:,component]-measured[:,component])
                step = maximum(predicted[:,component]-predicted_low[:,component])+maximum(measured[:,component]-measured_low[:,component])
                rounding_amplitude = maximum(amplitude[:,component])+maximum(abs(predicted[:,component]))
                full[key] = conservative(residual,step,units[component],rounding_amplitude)
                relative[key] = conservative(residual,step,maximum(predicted[:,component]),rounding_amplitude)
                discrepancy[key] = {'predicted_amplitude':maximum(predicted[:,component]),'measured_amplitude':maximum(measured[:,component]),'final_predicted':float(predicted[-1,component]),'final_measured':float(measured[-1,component]),'parent_comparison':conservative(maximum(measured[:,component]),step,units[component],rounding_amplitude)}
    saved_checks = {}
    if segment == 'replay':
        for mode,prefix_name in (('direct','parent_'),('order2','')):
            saved_high,saved_low = [load(SECOND/('heavy-'+mode+'-'+str(steps)+'.npz')) for steps in (64,32)]
            require(np.array_equal(fine['time'],saved_high['time']),'same saved window')
            for branch in (0,1):
                for component,quantity in enumerate(('density','current','pressure')):
                    current,previous = physical(fine,branch,prefix_name),physical(coarse,branch,prefix_name)
                    saved_current,saved_previous = physical(saved_high,branch),physical(saved_low,branch)
                    saved_checks[mode+'_'+str(branch)+'_'+quantity] = conservative(maximum(current[:,component]-saved_current[:,component]),maximum(current[:,component]-previous[:,component])+maximum(saved_current[:,component]-saved_previous[:,component]),norms['source_norm'][component],maximum(abs(current[:,component])+abs(saved_current[:,component])))
            bg_error = maximum(fine[prefix_name+'background_change']-saved_high['background_change'])
            saved_checks[mode+'_background_difference'] = {'measured_max_absolute':bg_error,'note':'reported, not assumed identical across independent integrations'}
    else:
        cold_high,cold_low = [load(ROOT/('cold-extension-'+str(steps)+'.npz')) for steps in (64,32)]
        saved_checks['cold'] = ordinary(cold_high,cold_low,'cold')
    required_relative = [name+'_'+quantity for name in ('old','coherent') for quantity in ('density','current','pressure','native_velocity')]
    relative_pass = all(relative[key]['passed'] for key in required_relative)
    raw_pass = approximate['passed'] and parent['passed'] and approximate['independent_native_passed'] and parent['independent_native_passed']
    comparison_pass = all(value['parent_comparison']['passed'] for value in discrepancy.values())
    saved_pass = all(value['passed'] for value in saved_checks.values() if 'passed' in value) if segment=='replay' else saved_checks['cold']['passed'] and saved_checks['cold']['independent_native_passed']
    result = {'segment':segment,'approximate':approximate,'parent':parent,'prediction_full_norm':full,'prediction_error_relative':relative,'prediction_discrepancies':discrepancy,'required_error_relative':required_relative,'required_error_relative_pass':relative_pass,'all_error_relative_pass':all(value['passed'] for value in relative.values()),'saved_controls':saved_checks,'primary_gate_pass':bool(raw_pass and comparison_pass and saved_pass and all(value['passed'] for value in full.values()) and relative_pass),'maximum_inverse_bound':float(np.max(fine['coefficient_integral']+.5*fine['coefficient_integral']**2)),'new_error_fit_parameters':0,'certified_global_error_bound':False}
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('segment',choices=('replay','extension'))
    arguments = parser.parse_args()
    with worker(arguments.segment+'-score'):
        inputs()
        result = score(arguments.segment)
        write(ROOT/(arguments.segment+'-score.json'),result)
        print(json.dumps({key:result[key] for key in ('segment','primary_gate_pass','required_error_relative_pass','all_error_relative_pass','maximum_inverse_bound')}),flush=True)
