from score_transport import *
AMPLITUDES = (16384.,65536.)
SIGNS = (1.,-1.)


class Amplified:
    def __init__(self,transport):
        self.transport = transport
        self.direct = transport.direct
        self.active = self.direct.active
        self.core_size = transport.approx_size+transport.parent_size+2*self.active
        self.calls = 0

    def encode(self,native):
        return np.r_[self.transport.encode(native),np.tile(native[:2*self.active],4)]

    def calculate(self,clock,state,diagnostics):
        core = state[:self.core_size]
        core_rhs,values = self.transport.calculate(clock,core,diagnostics)
        approximate,parent,_,_ = self.transport.unpack(core)
        packet = background_packet(self.direct,clock,parent)
        if diagnostics:
            residual = values['field_truncation']
        else:
            residual = self.transport.reduced.calculate(clock,approximate,False)[1]['field_truncation']
        probes = state[self.core_size:].reshape(2,2,2*self.active)
        output = []
        observations = []
        for amplitude_index,amplitude in enumerate(AMPLITUDES):
            for sign_index,sign in enumerate(SIGNS):
                native = parent.copy()
                native[:2*self.active] = probes[amplitude_index,sign_index]
                old,change,_,_,_ = self.direct.unpack(native)
                old_rhs = self.direct.sample(clock,old,packet,False)[0]
                new_old_rhs = self.direct.sample(clock,old,packet,True)[0]
                change_rhs = self.direct.sample(clock,change,packet,True)[0]
                delta_rhs = new_old_rhs-old_rhs+change_rhs
                old_rhs[self.transport.reduced.selected] -= sign*amplitude*residual[0]
                delta_rhs[self.transport.reduced.selected] -= sign*amplitude*residual[1]
                output.extend([old_rhs[:self.active]/self.direct.state_units,delta_rhs[:self.active]/self.direct.delta_units])
                if diagnostics:
                    observations.append(self.direct.evaluate(clock,native)[1])
        if diagnostics:
            for name in ('source','source_change','metric'):
                array = np.stack([item[name] for item in observations])
                values['probe_'+name] = array.reshape((2,2,*array.shape[1:]))
            _,_,error_old,error_change = self.transport.unpack(core)
            error_metrics = np.stack((self.direct.read_metric(clock,error_old,packet,False),self.direct.read_metric(clock,error_old+error_change,packet,True)))
            values['error_readout_primitive'] = primitive_envelope(error_metrics)
            terms = coefficients(self.direct.model,self.direct.prepared,clock,self.direct.unpack(parent)[2])
            primitives = []
            for branch in (0,1):
                phi,velocity,mu,beta = [terms['raw'][name].base+(terms['raw'][name].change if branch else 0.) for name in ('phi','velocity','mu','beta')]
                error_fields = (error_old+(error_change if branch else 0.))[self.transport.reduced.selected]
                density_pressure = abs(beta)*(abs(mu**2*phi*error_fields[0])+abs(velocity*error_fields[1]))
                primitives.append([density_pressure,abs(beta*CONFIG['retained_comoving_wave']*velocity*error_fields[0]),density_pressure])
            values['error_source_primitive'] = np.array(primitives)
        return np.r_[core_rhs,*output],values

    def rhs(self,clock,state):
        self.calls += 1
        if self.calls%128 == 0:
            guard()
        return self.calculate(clock,state,False)[0]


def freeze():
    inputs()
    require(not read(ROOT/'replay-score.json')['primary_gate_pass'],'preserve failed original precision gate')
    require(not any((ROOT/('amplified-'+str(steps)+'-start.json')).exists() for steps in CONFIG['steps']),'controls frozen before runs')
    mapping = {str(ROOT/name):digest(ROOT/name) for name in ('amplified_control.py','AMPLIFIED-CONTROL.md','replay-score.json','heavy-replay-32.npz','heavy-replay-64.npz')}
    write(ROOT/'amplified-frozen.json',{'files':mapping,'amplitudes':AMPLITUDES,'signs':SIGNS,'rtol':CONFIG['rtol'],'atol':CONFIG['normalized_atol'],'numerical_tolerance':CONFIG['numerical_tolerance'],'physical_parameters_changed':False,'utc':datetime.now(timezone.utc).isoformat()})


def run(steps):
    inputs()
    check_inputs(read(ROOT/'amplified-frozen.json')['files'])
    label = 'amplified-'+str(steps)
    with native_context('heavy',label) as (captured,metadata,sample):
        direct,reduced,state = systems('heavy',captured,metadata,sample)
        system = Amplified(Transport(direct,reduced))
        current = system.encode(state['normalized'])
        times = load(ROOT/'heavy-replay-clock.npz')['time']
        states = [current.copy()]
        initial = system.calculate(float(times[0]),current,True)[1]
        observed = {name:np.empty((len(times),*np.asarray(value).shape)) for name,value in initial.items()}
        for name,value in initial.items():
            observed[name][0] = value
        evaluations = 0
        for position,(left,right) in enumerate(zip(times[:-1],times[1:])):
            guard()
            solution = solve_ivp(system.rhs,(float(left),float(right)),current,method='DOP853',t_eval=[right],rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(direct.prepared['elapsed'][8])/steps)
            require(solution.success,'independent amplified controls')
            current = solution.y[:,-1]
            states.append(current.copy())
            evaluations += solution.nfev
            for name,value in system.calculate(float(right),current,True)[1].items():
                observed[name][position+1] = value
            if (position+1)%CONFIG['batch_boundaries'] == 0 or position == len(times)-2:
                np.savez_compressed(ROOT/(label+'-boundary'+str(position+1)+'.npz'),tau=np.array(right),normalized=current,completed=np.array(position+1))
                print(json.dumps({'label':label,'boundary':position+1,'total':len(times)-1}),flush=True)
        np.savez_compressed(ROOT/(label+'.npz'),time=times,extended=np.array(states),**observed)
        np.savez_compressed(ROOT/(label+'-terminal.npz'),tau=np.array(times[-1]),normalized=current,actual_rhs=system.rhs(float(times[-1]),current),core_size=np.array(system.core_size))
        write(ROOT/(label+'-result.json'),{'completed':True,'steps':steps,'samples':len(times),'evaluations':evaluations,'amplitudes':AMPLITUDES,'signs':SIGNS,'independently_integrated':True,'new_physical_prediction':False,'original_precision_gate_unchanged':True})
    inputs()
    check_inputs(read(ROOT/'amplified-frozen.json')['files'])


def score_amplified():
    fine,coarse = [load(ROOT/('amplified-'+str(steps)+'.npz')) for steps in (64,32)]
    norms = read(ROOT/'frozen-norms.json')['heavy']
    gates,center,stable,cross = {},{},{},{}
    for branch,branch_name in enumerate(('old','coherent')):
        for family in ('source','readout'):
            if family == 'source':
                probes = fine['probe_source']+(fine['probe_source_change'] if branch else 0.)
                lower = coarse['probe_source']+(coarse['probe_source_change'] if branch else 0.)
                predicted = fine['error_source'][:,0]+(fine['error_source'][:,1] if branch else 0.)
                predicted_low = coarse['error_source'][:,0]+(coarse['error_source'][:,1] if branch else 0.)
                parent,parent_low = physical(fine,branch,'parent_'),physical(coarse,branch,'parent_')
                amplitude = abs(probes)
                error_amplitude = fine['error_source_primitive'][:,branch]
                names,units = ('density','current','pressure'),norms['source_norm']
            else:
                probes = readouts(fine['probe_metric'])[...,branch,:]
                lower = readouts(coarse['probe_metric'])[...,branch,:]
                predicted,predicted_low = fine['error_readout'][:,branch],coarse['error_readout'][:,branch]
                parent,parent_low = readouts(fine['parent_metric'])[:,branch],readouts(coarse['parent_metric'])[:,branch]
                amplitude = primitive_envelope(fine['probe_metric'])[...,branch,:]
                error_amplitude = fine['error_readout_primitive'][:,branch]
                names,units = NAMES,norms['readout_norm']
            normalized = (probes[:,:,0]-probes[:,:,1])/(2*np.array(AMPLITUDES)[None,:,None])
            normalized_low = (lower[:,:,0]-lower[:,:,1])/(2*np.array(AMPLITUDES)[None,:,None])
            rounding = (amplitude[:,:,0]+amplitude[:,:,1])/(2*np.array(AMPLITUDES)[None,:,None])
            for component,quantity in enumerate(names):
                key = branch_name+'_'+quantity
                for index,amplification in enumerate(AMPLITUDES):
                    comparison = normalized[:,index,component]
                    low = normalized_low[:,index,component]
                    step = maximum(comparison-low)+maximum(predicted[:,component]-predicted_low[:,component])
                    gates[key+'_'+str(int(amplification))] = conservative(maximum(comparison-predicted[:,component]),step,maximum(predicted[:,component]),maximum(rounding[:,index,component]+error_amplitude[:,component]))
                    central = .5*(probes[:,index,0,component]+probes[:,index,1,component])-parent[:,component]
                    central_low = .5*(lower[:,index,0,component]+lower[:,index,1,component])-parent_low[:,component]
                    center[key+'_'+str(int(amplification))] = conservative(maximum(central),maximum(central-central_low),units[component],maximum(amplitude[:,index,0,component]+amplitude[:,index,1,component]+abs(parent[:,component])))
                cross[key] = conservative(maximum(normalized[:,0,component]-normalized[:,1,component]),maximum(normalized[:,0,component]-normalized_low[:,0,component])+maximum(normalized[:,1,component]-normalized_low[:,1,component]),maximum(predicted[:,component]),maximum(rounding[:,0,component]+rounding[:,1,component]))
    saved_fine,saved_low = [load(ROOT/('heavy-replay-'+str(steps)+'.npz')) for steps in (64,32)]
    for prefix_name in ('','parent_'):
        for branch in (0,1):
            for component,quantity in enumerate(NAMES):
                actual,reference = readouts(fine[prefix_name+'metric'])[:,branch,component],readouts(saved_fine[prefix_name+'metric'])[:,branch,component]
                actual_low,reference_low = readouts(coarse[prefix_name+'metric'])[:,branch,component],readouts(saved_low[prefix_name+'metric'])[:,branch,component]
                stable[prefix_name+str(branch)+'_'+quantity] = conservative(maximum(actual-reference),maximum(actual-actual_low)+maximum(reference-reference_low),norms['readout_norm'][component],maximum(primitive_envelope(fine[prefix_name+'metric'])[:,branch,component]+primitive_envelope(saved_fine[prefix_name+'metric'])[:,branch,component]))
    return {'relative_checks':gates,'center_parent_checks':center,'amplitude_agreement':cross,'unamplified_solution_checks':stable,'all_passed':all(value['passed'] for group in (gates,center,cross,stable) for value in group.values()),'original_replay_primary_gate':read(ROOT/'replay-score.json')['primary_gate_pass'],'new_epoch':False,'new_fitted_parameters':0,'scope':'forced linear transport control; not a certified full physical error bound'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command',choices=('freeze','run','score'))
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=32)
    arguments = parser.parse_args()
    label = 'amplified-freeze' if arguments.command == 'freeze' else 'amplified-score' if arguments.command == 'score' else 'amplified-'+str(arguments.steps)
    with worker(label):
        if arguments.command == 'freeze': freeze()
        elif arguments.command == 'run': run(arguments.steps)
        else:
            inputs()
            check_inputs(read(ROOT/'amplified-frozen.json')['files'])
            result = score_amplified()
            write(ROOT/'amplified-score.json',result)
            print(json.dumps({'all_passed':result['all_passed'],'original_replay_primary_gate':result['original_replay_primary_gate']}),flush=True)
