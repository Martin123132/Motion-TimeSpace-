from restart_bridge import *
import argparse

def prepare():
    pins = [(METRIC, CONFIG["previous_seal"]), (Path(CONFIG["force_directory"]), CONFIG["force_seal"])]
    mapping = {}
    for directory, pin in pins:
        require(digest(directory / "closeout.json") == pin, "parent seal")
        mapping[str(directory / "closeout.json")] = pin
        for name, entry in read(directory / "closeout.json")["artifacts"].items():
            mapping[str(directory / name)] = entry["sha256"]
    mapping.update(read(Path(CONFIG["force_directory"]) / "inputs.json"))
    for name in ("protocol.json", "restart_support.py", "restart_bridge.py", "run_restart.py", "CONTRACT.md"):
        mapping[str(ROOT / name)] = digest(ROOT / name)
    write(ROOT / "inputs.json", mapping)
    inputs()
    print(json.dumps({"frozen_inputs": len(mapping), "capture_first": CONFIG["first_index"], "capture_last": CONFIG["last_index"]}))

def full(case):
    inputs()
    label = case + "-full"
    prepared, _, background, _, _ = EX.problem(case)
    with native_context(case, label) as (captured, metadata, sample):
        original = prefix(captured, case)
        system = MetricCoupled(case, prepared, background, original, metadata, sample)
        queries = prepared["times"][None, :] + prepared["elapsed"][:, None]
        times, inverse = np.unique(queries.ravel(), return_inverse=True)
        output, states, integration = integrate(system, float(times[0]), float(times[-1]), system.initial, times, 64, label)
        reconstructed = {name: values[inverse].reshape((*queries.shape, *values.shape[1:])) for name, values in output.items()}
        reconstructed.update(queries=queries, state_units=system.state_units, background_units=system.background_units)
        for name in ("source", "source_change", "work", "work_change"):
            reconstructed[name + "_increment"] = weighted(prepared["weights"], reconstructed[name])
        own, work = reconstructed["source_increment"], reconstructed["work_increment"]
        change, change_work = reconstructed["source_change_increment"], reconstructed["work_change_increment"]
        reconstructed["balance"] = np.column_stack((own[:, 0] - np.sum(work[:, :6], axis=1), own[:, 1] - np.sum(work[:, 6:], axis=1)))
        reconstructed["change_balance"] = np.column_stack((change[:, 0] - np.sum(change_work[:, :6], axis=1), change[:, 1] - np.sum(change_work[:, 6:], axis=1)))
        previous = load(METRIC / (case + "-metric-64.npz"))
        parity = {name: bool(np.array_equal(value, reconstructed[name])) for name, value in previous.items()}
        np.savez_compressed(ROOT / (case + "-complete-history.npz"), time=times, normalized=states, units=normalized_units(system), **output)
        for index in (CONFIG["restart_index"], CONFIG["accepted_last_index"]):
            target = float(queries[index - 2892, -1])
            position = int(np.searchsorted(times, target))
            require(times[position] == target, "exact saved checkpoint query")
            checkpoint(system, target, states[position], ROOT / (case + "-epoch" + str(index) + ".npz"))
        report = {"case": case, "integration": integration, "full_shape": list(states.shape),
                  "all_previous_arrays_exact": all(parity.values()), "array_parity": parity,
                  "capture942_prefix934_exact": True, "checkpoints": [CONFIG["restart_index"], CONFIG["accepted_last_index"]]}
        write(ROOT / (label + "-result.json"), report)
        print(json.dumps(report), flush=True)
        require(report["all_previous_arrays_exact"], "complete-state capture does not change accepted evolution")
    inputs()

def readouts(packet):
    material = packet[..., :84].reshape((*packet.shape[:-1], 7, 12))
    baryon, photon = material[..., 1, :], material[..., 2, :]
    field = lambda name: packet[..., 84 + read(METRIC / "packet-schema.json")["global_columns"].index(name)]
    wave = CONFIG["retained_comoving_wave"]
    hubble, sigma = field("hubble"), field("sigma")
    velocity = baryon[..., 4] / baryon[..., 0]
    flux = photon[..., 4] / photon[..., 0]
    return np.stack((-wave * (velocity + sigma) / hubble,
                     -(field("density") + 3 * hubble * field("current") / wave + field("anisotropic_stress")) / (2 * wave**2),
                     photon[..., 3] / photon[..., 0],
                     baryon[..., 3] / baryon[..., 0] - .75 * photon[..., 3] / photon[..., 0],
                     velocity - .75 * flux), axis=-1)

def norms(case):
    reference = load(METRIC / (case + "-reference-metric.npz"))["packet"]
    return np.max(abs(readouts(reference)), axis=0)

def restart(case):
    inputs()
    require(read(ROOT / (case + "-full-result.json"))["all_previous_arrays_exact"], "accepted full replay")
    label = case + "-restart"
    prepared, _, background, _, _ = EX.problem(case)
    complete = load(ROOT / (case + "-complete-history.npz"))
    with native_context(case, label) as (captured, metadata, sample):
        original = prefix(captured, case)
        system = MetricCoupled(case, prepared, background, original, metadata, sample)
        checkpoint_path = ROOT / (case + "-epoch" + str(CONFIG["restart_index"]) + ".npz")
        saved = restore(system, checkpoint_path)
        selected = np.flatnonzero(complete["time"] >= saved["tau"])
        times = complete["time"][selected]
        require(times[0] == float(saved["tau"]), "restart time exact")
        output, states, integration = integrate(system, float(times[0]), float(times[-1]), saved["normalized"], times, 64, label)
        expected = complete["normalized"][selected]
        active, width = system.active, system.width
        difference = states - expected
        checks = {
            "full_old_native": ratio(maximum(difference[:, :active]), 1.),
            "full_coherent_native": ratio(maximum(difference[:, :active] + difference[:, active:2*active] * 1e-5), 1.),
            "background_full_units": ratio(maximum(difference[:, 2*active:2*active+width] * 1e-7), 1.),
            "work_old_units": ratio(maximum(difference[:, 2*active+width:2*active+width+9]), 1.),
            "work_coherent_units": ratio(maximum(difference[:, 2*active+width:2*active+width+9] + difference[:, 2*active+width+9:] * 1e-5), 1.)
        }
        observed, baseline = readouts(output["metric"]), readouts(complete["metric"][selected])
        references = norms(case)
        for branch, branch_name in enumerate(("old", "coherent")):
            for column, name in enumerate(("native_velocity", "native_weyl", "photon_density", "relative_density", "velocity_slip")):
                checks[branch_name + "_" + name] = ratio(maximum(observed[:, branch, column] - baseline[:, branch, column]), references[column])
        response_size = maximum((expected[:, active:2*active] * system.delta_units) / system.state_units)
        response_error = maximum(difference[:, active:2*active] * 1e-5)
        report = {"case": case, "integration": integration, "queries": len(times), "checks": checks,
                  "passed": all(item["passed"] for item in checks.values()), "initial_reload_bitwise_exact": True,
                  "response_relative_separate": ratio(response_error, response_size)}
        np.savez_compressed(ROOT / (case + "-restart-history.npz"), time=times, normalized=states, **output)
        checkpoint(system, float(times[-1]), states[-1], ROOT / (case + "-restart-terminal.npz"))
        write(ROOT / (label + "-result.json"), report)
        print(json.dumps(report), flush=True)
        require(report["passed"], "restart passes before extension")
    inputs()

def extend(case, steps):
    inputs()
    require(all(read(ROOT / (name + "-restart-result.json"))["passed"] for name in CONFIG["cases"]), "paired restart gate")
    label = case + "-extension-" + str(steps)
    prepared, _, background, _, _ = EX.problem(case)
    with native_context(case, label) as (captured, metadata, sample):
        original = prefix(captured, case)
        system = MetricCoupled(case, prepared, background, original, metadata, sample)
        saved = restore(system, ROOT / (case + "-epoch" + str(CONFIG["accepted_last_index"]) + ".npz"))
        extra = captured["clock"][CONFIG["accepted_last_index"] - CONFIG["first_index"] + 1:]
        times = np.concatenate(([float(saved["tau"])], extra))
        require(len(times) == 9 and np.all(np.diff(times) > 0), "exact eight new physical epochs")
        background.evaluate(times)
        output, states, integration = integrate(system, float(times[0]), float(times[-1]), saved["normalized"], times, steps, label)
        np.savez_compressed(ROOT / (label + ".npz"), time=times, normalized=states, **output)
        checkpoint(system, float(times[-1]), states[-1], ROOT / (label + "-terminal.npz"))
        write(ROOT / (label + "-result.json"), {"case": case, "steps": steps, "integration": integration,
              "epoch_indices": list(range(CONFIG["accepted_last_index"], CONFIG["last_index"] + 1)),
              "initial_reload_bitwise_exact": True, "same_native_regime": True})
    inputs()

def score_extension():
    inputs()
    results = {}
    columns = {name: 84 + index for index, name in enumerate(read(METRIC / "packet-schema.json")["global_columns"])}
    for case in CONFIG["cases"]:
        fine = load(ROOT / (case + "-extension-64.npz"))
        coarse = load(ROOT / (case + "-extension-32.npz"))
        require(np.array_equal(fine["time"], coarse["time"]), "identical new clocks")
        reference_norms = norms(case)
        checks = {}
        high, low = readouts(fine["metric"]), readouts(coarse["metric"])
        for branch, branch_name in enumerate(("old", "coherent")):
            for column, name in enumerate(("native_velocity", "native_weyl", "photon_density", "relative_density", "velocity_slip")):
                checks[branch_name + "_" + name + "_refinement"] = ratio(maximum(high[:, branch, column] - low[:, branch, column]), reference_norms[column])
        metric_norm = load(METRIC / (case + "-reference-metric.npz"))["norms"]
        for name, index in (("trace_residual", 3), ("shear_residual", 4), ("eta_residual", 5), ("density_constraint", 6), ("friedmann_constraint", 7)):
            checks["coherent_" + name] = ratio(maximum(fine["metric"][:, 1, columns[name]]), metric_norm[index])
        complete = load(ROOT / (case + "-complete-history.npz"))
        for branch, source_name, work_name in (("old", "source", "work"), ("correction", "source_change", "work_change")):
            change = fine[source_name] - fine[source_name][0]
            work = fine[work_name] - fine[work_name][0]
            for component, section in ((0, slice(0, 6)), (1, slice(6, 9))):
                scale = maximum(complete["source"][:, component])
                error = maximum(change[:, component] - np.sum(work[:, section], axis=1))
                checks[branch + "_exchange_" + str(component)] = ratio(error, scale)
        source = fine["source"] + fine["source_change"]
        coarse_source = coarse["source"] + coarse["source_change"]
        pressure_norm = maximum(complete["source"][:, 2])
        checks["coherent_pressure_refinement"] = ratio(maximum(source[:, 2] - coarse_source[:, 2]), pressure_norm)
        results[case] = {"checks": checks, "passed": all(value["passed"] for value in checks.values()),
                         "begin_end_tau": fine["time"][[0, -1]].tolist(),
                         "scale_coherent": fine["metric"][:, 1, columns["scale"]].tolist(),
                         "redshift_coherent": (1/fine["metric"][:, 1, columns["scale"]]-1).tolist(),
                         "final_readouts_old_coherent": high[-1].tolist(),
                         "final_source_old_correction": [fine["source"][-1].tolist(), fine["source_change"][-1].tolist()],
                         "no_new_902_window_projection": True}
    write(ROOT / "extension-score.json", {"cases": results, "passed": all(report["passed"] for report in results.values())})
    print(json.dumps(results), flush=True)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "full", "restart", "extend", "score"))
    parser.add_argument("--case", choices=CONFIG["cases"])
    parser.add_argument("--steps", type=int, choices=CONFIG["steps"], default=64)
    args = parser.parse_args()
    label = args.mode if args.mode in ("prepare", "score") else args.case + "-" + args.mode + ("-" + str(args.steps) if args.mode == "extend" else "")
    with worker(label):
        if args.mode == "prepare":
            prepare()
        elif args.mode == "full":
            full(args.case)
        elif args.mode == "restart":
            restart(args.case)
        elif args.mode == "extend":
            extend(args.case, args.steps)
        else:
            score_extension()

if __name__ == "__main__":
    main()

