from restart_support import *
import argparse

def freeze_states():
    mapping = {}
    for case in CONFIG["cases"]:
        require(read(ROOT / (case + "-full-result.json"))["all_previous_arrays_exact"], "full replay exact")
        for suffix in ("-complete-history.npz", "-epoch2916.npz", "-epoch2924.npz",
                       "-full-result.json", "-full-capture.json", "-full-capture.npz"):
            path = ROOT / (case + suffix)
            mapping[str(path)] = digest(path)
    for name in ("verify_restart.py", "run_checked.py"):
        mapping[str(ROOT / name)] = digest(ROOT / name)
    write(ROOT / "state-manifest.json", mapping)
    print(json.dumps({"full_state_files_frozen": len(mapping)}))

def verify():
    from restart_bridge import retained_run
    from run_restart import readouts, norms
    check_inputs(read(ROOT / "inputs.json"))
    check_inputs(read(ROOT / "state-manifest.json"))
    score = read(ROOT / "extension-score.json")
    checks, summary = {}, {}
    for case in CONFIG["cases"]:
        full = read(ROOT / (case + "-full-result.json"))
        restart = read(ROOT / (case + "-restart-result.json"))
        checks[case + "_original_arrays_exact"] = full["all_previous_arrays_exact"]
        checks[case + "_fresh_process_restart"] = restart["passed"] and restart["initial_reload_bitwise_exact"]
        checks[case + "_eight_epoch_checks"] = score["cases"][case]["passed"]
        full_receipt, restart_receipt = read(ROOT / (case + "-full-start.json")), read(ROOT / (case + "-restart-start.json"))
        checks[case + "_different_process_identity"] = (full_receipt["pid"], full_receipt["created"]) != (restart_receipt["pid"], restart_receipt["created"])
        terminal = load(ROOT / (case + "-epoch2924.npz"))
        active, allocated = int(terminal["dimensions"][1]), int(terminal["dimensions"][0])
        checks[case + "_complete_allocated_vectors"] = all(terminal[name].shape == (allocated,) for name in ("native_old", "native_change", "native_coherent", "seed"))
        checks[case + "_native_coherent_exact_sum"] = np.array_equal(terminal["native_coherent"], terminal["native_old"] + terminal["native_change"])
        checks[case + "_complete_normalized_dimensions"] = len(terminal["normalized"]) == 2 * active + int(terminal["dimensions"][2]) + 18
        high = load(ROOT / (case + "-extension-64.npz"))
        low = load(ROOT / (case + "-extension-32.npz"))
        end = load(ROOT / (case + "-extension-64-terminal.npz"))
        checks[case + "_extension_initial_state_exact"] = np.array_equal(high["normalized"][0], terminal["normalized"]) and np.array_equal(low["normalized"][0], terminal["normalized"])
        checks[case + "_extension_terminal_state_exact"] = np.array_equal(high["normalized"][-1], end["normalized"])
        checks[case + "_extension_layout_preserved"] = np.array_equal(end["signature"], terminal["signature"])
        checks[case + "_finite_complete_states"] = np.isfinite(high["normalized"]).all() and np.isfinite(low["normalized"]).all()
        history = load(ROOT / (case + "-complete-history.npz"))
        new_source = high["source"] + high["source_change"]
        new_work = high["work"] + high["work_change"]
        exchange = {}
        for component, section in ((0, slice(0, 6)), (1, slice(6, 9))):
            difference = new_source[:, component] - new_source[0, component] - np.sum(new_work[:, section] - new_work[0, section], axis=1)
            scale = maximum(history["source"][:, component])
            result = ratio(maximum(difference), scale)
            exchange[str(component)] = result
            checks[case + "_coherent_exchange_" + str(component)] = result["passed"]
        initial_output = readouts(high["metric"])[0]
        final_output = readouts(high["metric"])[-1]
        native_norms = norms(case)
        checks[case + "_new_clock_strictly_forward"] = len(high["time"]) == 9 and np.all(np.diff(high["time"]) > 0)
        checks[case + "_32_64_clocks_equal"] = np.array_equal(high["time"], low["time"])
        summary[case] = {"restart_worst_full_native": max(restart["checks"]["full_old_native"]["relative"], restart["checks"]["full_coherent_native"]["relative"]),
                         "restart_tiny_response": restart["response_relative_separate"],
                         "coherent_exchange": exchange,
                         "final_correction_native_velocity": float(final_output[1, 0] - final_output[0, 0]),
                         "initial_correction_native_velocity": float(initial_output[1, 0] - initial_output[0, 0]),
                         "final_correction_fraction_of_old_reference": float((final_output[1, 0] - final_output[0, 0]) / native_norms[0]),
                         "late_native_velocity_change_within_branch": (final_output[:, 0] - initial_output[:, 0]).tolist()}
    for path in ROOT.glob("*-owner-release.json"):
        checks[path.stem] = read(path)["cleared"]
    checks["task_workers_exited"] = all(exited(read(path))["exited"] for path in ROOT.glob("*-start.json") if path.name != "verify-start.json")
    checks["no_bytecode"] = not (ROOT / "__pycache__").exists()
    checks["all_frozen_inputs_unchanged"] = True
    result = {"passed": all(bool(value) for value in checks.values()),
              "checks": {key: bool(value) for key, value in checks.items()}, "count": len(checks), "summary": summary,
              "inherited_correction_relative_failures_not_promoted": True,
              "new_projected_source_budget_claim": False, "native_binary_rebuilt": False}
    write(ROOT / "verification.json", result)
    print(json.dumps(result), flush=True)
    require(result["passed"], "verification")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("freeze", "verify"))
    args = parser.parse_args()
    with worker(args.mode):
        freeze_states() if args.mode == "freeze" else verify()

