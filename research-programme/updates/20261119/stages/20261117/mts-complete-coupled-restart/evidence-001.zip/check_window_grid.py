from restart_support import *

if __name__ == "__main__":
    with worker("window-grid-check"):
        proposal = read(ROOT / "next-window.json")
        period = proposal["local_period_mpc"]
        result = {"supersedes": "next-window.json endpoint proposal only; frequency derivation retained",
                  "selection": "Largest existing native epoch not after one local principal period; no new output grid, no future response inspected.",
                  "cases": {}}
        for case, choice in proposal["cases"].items():
            path = Path(choice["clock_source"])
            require(digest(path) == choice["source_sha256"], "same native clock source")
            with np.load(path) as archive:
                clock = archive["conformal_time"]
            target = choice["start_tau"] + period
            lower = int(np.searchsorted(clock, target, side="right") - 1)
            upper = lower + 1
            require(lower > choice["start_epoch"], "nonempty next block")
            result["cases"][case] = {
                "begin_epoch": choice["start_epoch"], "end_epoch": lower, "new_epochs": lower - choice["start_epoch"],
                "begin_tau": choice["start_tau"], "end_tau": float(clock[lower]),
                "duration_mpc": float(clock[lower] - choice["start_tau"]),
                "fraction_local_principal_period": float((clock[lower] - choice["start_tau"]) / period),
                "rejected_first_after_epoch": upper, "first_after_tau": float(clock[upper]),
                "first_after_period_count": float((clock[upper] - choice["start_tau"]) / period),
                "native_gap_after_block_mpc": float(clock[upper] - clock[lower]),
                "no_claim_complete_cycle": True, "native_regime_and_background_checks_required": True}
        require(result["cases"]["cold"]["end_epoch"] == result["cases"]["heavy"]["end_epoch"], "paired common endpoint")
        write(ROOT / "next-window-grid-check.json", result)
        print(json.dumps(result), flush=True)

