import run_restart
from restart_support import ROOT, read, check_inputs, require

original_inputs = run_restart.inputs

def frozen_inputs():
    original_inputs()
    require((ROOT / "state-manifest.json").is_file(), "frozen full restart states required")
    check_inputs(read(ROOT / "state-manifest.json"))

run_restart.inputs = frozen_inputs

if __name__ == "__main__":
    run_restart.main()

