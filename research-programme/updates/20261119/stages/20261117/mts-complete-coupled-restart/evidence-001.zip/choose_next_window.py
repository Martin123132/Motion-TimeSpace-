from restart_bridge import *
import math

if __name__ == "__main__":
    with worker("next-window"):
        check_inputs(read(ROOT / "inputs.json"))
        check_inputs(read(ROOT / "state-manifest.json"))
        require(read(ROOT / "verification.json")["passed"], "verified continuation")
        heavy = load(ROOT / "heavy-extension-64-terminal.npz")
        clock_source = POST / "mts-integrated-defect-20261112/heavy-native-clock.npz"
        constants = load(clock_source)["constants"]
        scale = float(heavy["background"][0])
        mass = float(constants[7])
        wave = CONFIG["retained_comoving_wave"]
        omega = math.hypot(wave, scale * mass)
        period = 2 * math.pi / omega
        start = float(heavy["tau"])
        paths = {"heavy": EX.SPECTRUM / "runs/exact-grid/chunk-0384.npz",
                 "cold": EX.EARLY / "runs/final-bg8-start/cold.npz"}
        with np.load(paths["heavy"]) as archive:
            clocks = archive["conformal_time"]
            end_index = int(np.searchsorted(clocks, start + period))
            require(end_index < len(clocks), "one-cycle requested clock exists")
        choices = {}
        for case, path in paths.items():
            with np.load(path) as archive:
                clock = archive["conformal_time"]
                requested = archive["requested_scale"]
            current = load(ROOT / (case + "-extension-64-terminal.npz"))
            choices[case] = {"clock_source": str(path), "source_sha256": digest(path),
                             "start_epoch": 2932, "end_epoch": end_index, "new_epochs": end_index - 2932,
                             "start_tau": float(current["tau"]), "end_tau": float(clock[end_index]),
                             "requested_end_scale": float(requested[end_index]),
                             "native_signature_gate_still_required": True,
                             "corrected_background_support_gate_still_required": True}
        history = load(ROOT / "heavy-complete-history.npz")
        active = int(heavy["dimensions"][1])
        relative = abs(history["normalized"][:, active:2*active] * 1e-5)
        location = np.unravel_index(np.argmax(relative), relative.shape)
        native_index = int(location[1])
        state = history["normalized"][location[0]]
        old = state[native_index] * heavy["state_units"][native_index]
        change = state[active + native_index] * heavy["delta_units"][native_index]
        first = int(heavy["dimensions"][3])
        names = {first: "slow_scalar_perturbation", first+1: "slow_scalar_perturbation_derivative",
                 first+2: "heavy_scalar_perturbation", first+3: "heavy_scalar_perturbation_derivative",
                 first+4: "heavy_selector"}
        output = {"selection_only_no_future_response_scored": True,
                  "derivation": "Local principal heavy-field frequency omega=sqrt(k^2+a^2*m_h^2), not the complete forced/gravitating-system eigenfrequency.",
                  "mass_inverse_mpc": mass, "wave_inverse_mpc": wave, "scale": scale,
                  "omega_inverse_mpc": omega, "local_period_mpc": period, "cases": choices,
                  "interpretation": "A physically motivated duration, not a claim of exact sinusoidal evolution. Same epoch endpoint in both cases. Freeze predictions and native regime before continuation.",
                  "native_correction_normalization_note": {
                      "maximum_over_complete_history": float(relative[location]),
                      "component_python_index": native_index, "component_name": names.get(native_index, "other_native_component"),
                      "old_component": float(old), "change_component": float(change),
                      "normalization": float(heavy["state_units"][native_index]),
                      "not_velocity_or_spectrum_relative_precision": True}}
        write(ROOT / "next-window.json", output)
        print(json.dumps(output), flush=True)

