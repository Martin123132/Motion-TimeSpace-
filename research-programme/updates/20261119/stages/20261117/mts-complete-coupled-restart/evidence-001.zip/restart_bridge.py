from restart_support import *
import ast
import importlib
import inspect

METRIC = PREVIOUS
sys.path.insert(0, str(METRIC))
import run_metric as retained_run
import native_context as retained_context
from scipy.integrate import solve_ivp

for module in (retained_run, retained_run.previous_run, retained_context, retained_run.BG):
    module.guard = guard
retained_run.previous_run.CONFIG = CONFIG
EX = retained_run.EX
MetricCoupled = retained_run.MetricCoupled
weighted = retained_run.previous_run.weighted

source_path = POST / "mts-coupled-preparation-response-20261116/native_context.py"
source = source_path.read_text()
node = next(item for item in ast.parse(source).body if isinstance(item, ast.FunctionDef) and item.name == "native_context")
context_source = "@contextmanager\n" + ast.get_source_segment(source, node)
replacements = {
    'build = read(ROOT / "native-build-full-result.json")': 'build = read(METRIC / "native-build-full-result.json")',
    'local = ROOT / "native"': 'local = METRIC / "native"',
    'require(np.array_equal(packet, old_packet), "disabled hook leaves934 saved packets byte-identical")':
    'require(np.array_equal(packet[:len(old_packet)], old_packet), "disabled hook leaves934 saved packets byte-identical")'
}
for original, replacement in replacements.items():
    require(context_source.count(original) == 1, "unique retained context adaptation")
    context_source = context_source.replace(original, replacement)
namespace = vars(retained_context).copy()
namespace.update(ROOT=ROOT, METRIC=METRIC, POST=POST, CONFIG=CONFIG, guard=guard, write=write, read=read, require=require)
exec(compile(context_source, str(source_path) + ":read-only-context-adaptation", "exec"), namespace)
native_context = namespace["native_context"]

def inputs():
    mapping = read(ROOT / "inputs.json")
    check_inputs(mapping)
    return mapping

def prefix(captured, case):
    original = load(METRIC / (case + "-preflight-capture.npz"))
    count = CONFIG["accepted_last_index"] - CONFIG["first_index"] + 1
    for name, values in captured.items():
        require(np.array_equal(values[:count], original[name]), "original capture prefix exact: " + name)
    require(len(captured["clock"]) == CONFIG["last_index"] - CONFIG["first_index"] + 1, "full continuation context")
    return {name: values[:count].copy() for name, values in captured.items()}

def normalized_units(system):
    return np.concatenate((system.state_units, system.delta_units, system.background_units,
                           system.work_units, system.delta_work_units))

def checkpoint(system, tau, normalized, path, mode="x"):
    old, change, background_change, work, work_change = system.unpack(normalized)
    rhs, observed = system.evaluate(float(tau), normalized)
    state = dict(tau=np.array(tau), normalized=normalized.copy(), normalized_rhs=rhs,
                 units=normalized_units(system), state_units=system.state_units, delta_units=system.delta_units,
                 background_units=system.background_units, work_units=system.work_units,
                 delta_work_units=system.delta_work_units, seed=system.captured["reference"][0],
                 native_old=old, native_change=change, native_coherent=old+change,
                 background=observed["background"], background_change=background_change,
                 work=work, work_change=work_change,
                 signature=system.captured["signature"][0], seed_cache=system.captured["cache_reference"][0],
                 seed_cache_mask=system.captured["cache_mask"][0],
                 dimensions=np.array([system.allocated, system.active, system.width, system.first]),
                 metric=observed["metric"], scalar_velocities=observed["metric_scalar_velocities"])
    if mode == "x":
        require(not path.exists(), "new immutable checkpoint")
        np.savez_compressed(path, **state)
    else:
        temporary = path.with_name(path.stem + "-temporary.npz")
        np.savez_compressed(temporary, **state)
        temporary.replace(path)
    return state

def restore(system, path):
    state = load(path)
    require(np.array_equal(state["units"], normalized_units(system)), "identical normalization on reload")
    require(np.array_equal(state["seed"], system.captured["reference"][0]), "inactive seed preserved")
    require(np.array_equal(state["signature"], system.captured["signature"][0]), "active layout preserved")
    require(np.array_equal(state["seed_cache"], system.captured["cache_reference"][0]), "owner seed cache exact")
    require(np.array_equal(state["seed_cache_mask"], system.captured["cache_mask"][0]), "owner cache mask exact")
    require(np.array_equal(state["dimensions"], [system.allocated, system.active, system.width, system.first]), "complete state dimensions")
    actual, values = system.evaluate(float(state["tau"]), state["normalized"])
    require(np.array_equal(actual, state["normalized_rhs"]), "fresh-owner initial derivative bitwise exact")
    require(np.array_equal(values["metric"], state["metric"]), "fresh-owner metric readout bitwise exact")
    for name, value in zip(("native_old", "native_change", "background_change", "work", "work_change"), system.unpack(state["normalized"])):
        require(np.array_equal(value, state[name]), "physical state reconstructs exactly: " + name)
    return state

def integrate(system, begin, finish, initial, queries, steps, label, cursor=True):
    require(queries[0] == begin and queries[-1] == finish and np.all(np.diff(queries) > 0), "query support")
    divisions = np.concatenate(([begin], system.background.boundaries(begin, finish), [finish]))
    current = initial.copy()
    items = {}
    states = np.empty((len(queries), len(initial)))
    states[0] = current
    for name, value in system.evaluate(begin, current)[1].items():
        items[name] = np.empty((len(queries), *np.asarray(value).shape))
        items[name][0] = value
    maximum_step = float(system.prepared["elapsed"][8]) / steps
    evaluations = 0
    for segment, (left, right) in enumerate(zip(divisions[:-1], divisions[1:])):
        guard()
        selected = np.flatnonzero((queries > left) & (queries <= right))
        samples = np.unique(np.concatenate((queries[selected], [right])))
        solution = solve_ivp(system.rhs, (float(left), float(right)), current, method="DOP853",
                             rtol=CONFIG["rtol"], atol=CONFIG["normalized_atol"], max_step=maximum_step, t_eval=samples)
        require(solution.success, "coupled segment")
        evaluations += solution.nfev
        for index, position in zip(selected, np.searchsorted(samples, queries[selected])):
            states[index] = solution.y[:, position]
            for name, value in system.evaluate(float(queries[index]), solution.y[:, position])[1].items():
                items[name][index] = value
        current = solution.y[:, -1]
        if cursor:
            checkpoint(system, float(right), current, ROOT / (label + "-latest.npz"), "replace")
        if segment % 100 == 0:
            print(json.dumps({"label": label, "segment": segment, "total": len(divisions)-1, "evaluations": evaluations}), flush=True)
    return items, states, {"evaluations": evaluations, "segments": len(divisions)-1, "maximum_physical_step": maximum_step}

