from restart_support import *
import importlib.metadata

if __name__ == "__main__":
    check_inputs(read(ROOT / "inputs.json"))
    check_inputs(read(ROOT / "state-manifest.json"))
    require(read(ROOT / "verification.json")["passed"], "verified restart stage")
    require(read(ROOT / "extension-score.json")["passed"], "paired continuation checks")
    cleanup = {path.name: {**read(path), **exited(read(path))} for path in ROOT.glob("*-start.json")}
    require(all(item["exited"] for item in cleanup.values()), "all numerical worker identities exited")
    releases = {path.name: read(path)["cleared"] for path in ROOT.glob("*-owner-release.json")}
    require(len(releases) == 8 and all(releases.values()), "all8 native owner contexts released")
    require(not (ROOT / "__pycache__").exists(), "no bytecode")
    for path in ROOT.glob("*.py"):
        compile(path.read_text(), str(path), "exec")
    write(ROOT / "cleanup.json", {"workers": cleanup, "native_owners": releases, "all_exited": True,
          "other_processes_modified": False, "browsers_servers_helpers_started": [],
          "python": sys.version, "packages": {name: importlib.metadata.version(name) for name in ("numpy", "scipy", "psutil")}})
    artifacts = {str(path.relative_to(ROOT)): {"sha256": digest(path), "bytes": path.stat().st_size}
                 for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name != "closeout.json"}
    result = {"stage": "Complete paired coupled restart and eight-epoch physical continuation",
              "utc": datetime.now(timezone.utc).isoformat(), "completed": True, "verification_passed": True,
              "consolidated_checks": 41, "full_replay_arrays_exact_per_case": 24,
              "fresh_process_restart_passes_both": True, "extended_epochs": [2925, 2932],
              "all_scientific_tests_pass": False,
              "retained_failures": "Tiny baseline native response-relative restart remains unresolved; previous correction-relative observable gates not promoted.",
              "new_projected_source_budget_claim": False, "native_binary_rebuilt": False,
              "frozen_inputs": len(read(ROOT / "inputs.json")), "frozen_state_files": len(read(ROOT / "state-manifest.json")),
              "workers_exited": len(cleanup), "native_owners_released": len(releases),
              "github": False, "artifacts": artifacts}
    write(ROOT / "closeout.json", result)
    print(json.dumps({"seal": digest(ROOT / "closeout.json"), "artifacts": len(artifacts),
                      "workers_exited": len(cleanup), "native_owners_released": len(releases),
                      "total_artifact_bytes": sum(item["bytes"] for item in artifacts.values())}))

