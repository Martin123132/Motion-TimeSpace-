from pathlib import Path
from dense_power import Collision, COMMON, POST, ROOT, TOL, digest, need, np, probe, save, solve_ivp, target, weights
from transport import Transport
from mode_check import read


def primordial(model,kind):
    base=model.base
    material=base.initialize('native' if kind=='native' else 'regular')
    closure=Transport.__new__(Transport)
    closure.base=base
    closure.order=1
    closure.gas=model.driver.gas
    _,_,_,_,_,stress,slip,_=closure.terms(np.r_[material,0.])
    angular=np.zeros((2,model.photon-1))
    if kind=='native':
        slip=0.
    else:
        angular[:,0]=[stress,stress/4]
    return np.r_[material,0.,slip,angular.flatten()]


def run(case,config,limits,label):
    refined=label!='BDF'
    local=dict(config)
    if label=='half':
        local['start']=config['start']/2
    solver=Collision(local,48 if refined else 34,7 if refined else 4)
    init=primordial(solver,'native' if label=='native' else 'regular')
    start=5*local['start']
    stop=5*local['times'][-1]
    form='constraint' if refined else 'trace'
    with np.load(config['ref']) as archive:
        times=archive['conformal_time'][:np.searchsorted(archive['conformal_time'],config['times'][-1])+1]
    elapsed_eval=5*times-start
    method='Radau' if refined else 'BDF'
    solve=solve_ivp(lambda t,y:solver.rhs(start+t,y,form),(0.,stop-start),init,method=method,
        rtol=8e-11 if refined else 1.5e-10,atol=1e-19,max_step=.06 if refined else .075,dense_output=True)
    need(solve.success and solve.t[-1]==stop-start,'origin integration: '+solve.message)
    system_state=solve.sol(elapsed_eval).T
    need(np.isfinite(system_state).all(),'full finite solution')
    factors=weights(solver.photon)
    edges=np.r_[limits[0],5*config['times'][(5*config['times']>limits[0])&(5*config['times']<limits[1])],limits[1]]
    mid=(edges[1:]+edges[:-1])/2
    half=np.diff(edges)/2
    results={}
    for order in (4,8):
        offsets,ws=np.polynomial.legendre.leggauss(order)
        coords=(mid[:,None]+half[:,None]*offsets).ravel()
        quadrature=(half[:,None]*ws).ravel()
        states=solve.sol(coords-start).T
        power=np.array([probe(solver,row,form,coord,factors) for coord,row in zip(coords,states)])
        accum=np.sum((power*quadrature[:,None]).astype(np.longdouble),axis=0).astype(float)
        endpoints=[probe(solver,solve.sol(x-start),form,x,factors)[-1] for x in limits]
        storage=endpoints[1]-endpoints[0]
        results[str(order)]=dict(angular=accum[1]+accum[2],dipole=accum[3],higher=accum[2],stored=storage,supply=accum[0],
            balance_error_over_storage=abs((accum[0]-accum[1]-accum[2])/storage-1),integrated_storage_error=abs(accum[4]/storage-1))
    with (ROOT/(case+'-origin-'+label+'.npz')).open('xb') as file:
        np.savez_compressed(file,states=system_state,times=times,initial=init,x_init=start,
            acceptance_tolerance=TOL,method=digest(ROOT/'ORIGIN-TRANSPORT.md'),code=digest(Path(__file__)),
            original=digest(config['ref']),nu=solver.base.last,photons=solver.photon)
    save(ROOT/(case+'-origin-'+label+'.json'),dict(quadratures=results,calls=solve.nfev,linear_solves=solve.nlu,common_x=limits))
    print(case,label,solve.nfev,results['8'],flush=True)


def complete():
    summary={}
    rows={case:{label:read(ROOT/(case+'-origin-'+label+'.json'))['quadratures']
        for label in ('BDF','physical','native','half')} for case in ('cold','heavy')}
    for key in ('dipole','angular','higher','stored','supply'):
        error={}
        for case,table in rows.items():
            central=table['physical']['8'][key]
            error[case]={kind:abs(table[label][order][key]-central) for kind,label,order in [
                ('quadrature','physical','4'),('solver','BDF','8'),('native_start_state','native','8'),('half_start','half','8')]}
        baseline=rows['cold']['physical']['8'][key]
        heavy=rows['heavy']['physical']['8'][key]
        diff=heavy-baseline
        summary[key]=dict(baseline=baseline,mts=heavy,fractional_contrast=diff/baseline,absolute_contrast=diff,
            branch_budgets={case:sum(terms.values())/abs(rows[case]['physical']['8'][key]) for case,terms in error.items()},
            paired_budget=sum(sum(parts.values()) for parts in error.values())/abs(diff),
            paired_breakdown={name:sum(parts[name] for parts in error.values())/abs(diff) for name in error['cold']})
    save(ROOT/'origin-budget.json',dict(tolerance=TOL,code=digest(Path(__file__)),method=digest(ROOT/'ORIGIN-TRANSPORT.md'),summary=summary))
    print('budgets',summary,flush=True)


if __name__=='__main__':
    import sys
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    configs={case:target(case) for case in ('cold','heavy')}
    limits=[max(5*cfg['times'][1] for cfg in configs.values()),min(5*cfg['times'][-1] for cfg in configs.values())]
    if sys.argv[1]=='run':
        for label in ('physical','BDF','native','half'):
            for case,config in configs.items():
                run(case,config,limits,label)
        complete()
