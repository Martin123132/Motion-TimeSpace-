from pathlib import Path
import sys
from first_output import ROOT, TOL, EarlySystem, digest, inputs, need, np, read, save


def setup(case):
    config=inputs(case)
    with np.load(config['ref']) as archive:
        all_times=archive['conformal_time']
        count=np.searchsorted(5*all_times,12.)+1
        config['times']=all_times[:count]
        need(5*config['times'][-2]<12<=5*config['times'][-1] and np.all(np.diff(config['times'])>0),'locked coverage')
    return config


def freeze(case):
    config=setup(case)
    data={}
    for order,cap,form in ((24,.060,'trace'),(32,.030,'constraint')):
        model=EarlySystem(config,order)
        result=model.solve('regular',form,cap)
        keys=list(result['rows'][0])
        data[form]=np.array([[row[key] for key in keys] for row in result['rows']])
        data[form+'_residual']=result['constraint_residual']
        data[form+'_max_field_fraction']=result['scalar_energy_fraction_max']
    with (ROOT/(case+'-horizon-prediction.npz')).open('xb') as file:
        np.savez_compressed(file,**data,times=config['times'],names=keys,code=digest(Path(__file__)),
            physics=digest(ROOT/'first_output.py'),method=digest(ROOT/'HORIZON.md'),ref_sha=digest(config['ref']))


def score(case):
    config=setup(case)
    path=ROOT/(case+'-horizon-prediction.npz')
    with np.load(path) as packet:
        need(str(packet['code'])==digest(Path(__file__)) and str(packet['physics'])==digest(ROOT/'first_output.py') and
            str(packet['method'])==digest(ROOT/'HORIZON.md') and str(packet['ref_sha'])==digest(config['ref']),'frozen inputs')
        times=packet['times']
        keys=packet['names'].tolist()
        primary=packet['constraint']
        secondary=packet['trace']
        constraints=[float(packet[method+'_residual']) for method in ('trace','constraint')]
        need(max(constraints)<TOL,'independent constraint and trace')
    with np.load(config['ref']) as archive:
        mode=int(np.flatnonzero(archive['modes']==5)[0])
        saved=archive['values'][mode,:len(times)][:,[archive['names'].tolist().index(key) for key in keys]]
        need(np.array_equal(archive['conformal_time'][:len(times)],times),'exact existing grid')
    signed=primary-saved
    difference=abs(primary-secondary)
    budget=np.full_like(signed,np.inf)
    np.divide(abs(signed)+difference,abs(saved),out=budget,where=saved!=0)
    passed=budget<=TOL
    records={}
    axis=5*times
    for column,key in enumerate(keys):
        actual=saved[:,column]
        failed=np.flatnonzero(~passed[:,column])
        first=int(failed[0]) if len(failed) else None
        worst=int(np.argmax(budget[:,column]))
        records[key]=dict(passed=int(passed[:,column].sum()),first_failure=first,
            first_failure_x=None if first is None else axis[first],worst_row=worst,
            max_relative_budget=None if actual[worst]==0 else budget[worst,column],
            max_abs_error_over_peak_saved=max(abs(signed[:,column]))/max(abs(actual)),
            max_refinement_over_peak_saved=max(difference[:,column])/max(abs(actual)),
            exact_zero_reference=int((actual==0).sum()))
    scale=primary[:,keys.index('a')]
    hubble=primary[:,keys.index('H')]
    transitions={}
    ratios={'horizon':5/hubble}
    if case=='heavy':
        ratios['heavy_mass']=config['masses'][1]*scale/hubble
    for label,ratio in ratios.items():
        cross=int(np.flatnonzero(ratio>=1)[0])
        need(0<cross<len(times) and ratio[cross-1]<1,'first crossing with both sides saved')
        transitions[label]=dict(rows=[cross-1,cross],x=axis[cross-1:cross+1].tolist(),ratio=ratio[cross-1:cross+1].tolist(),
            failures={key:[bool(not passed[row,column]) for row in (cross-1,cross)] for column,key in enumerate(keys) if not passed[cross-1:cross+1,column].all()})
    with (ROOT/(case+'-horizon-differences.npz')).open('xb') as file:
        np.savez_compressed(file,names=keys,times=times,signed_prediction_minus_saved=signed,abs_refinement=difference,passed=passed)
    complete=np.flatnonzero(~np.all(passed,axis=1))
    output=dict(reference=str(config['ref']),prediction_sha=digest(path),rows=len(times),relative_tolerance=TOL,
                first_any_failure=int(complete[0]) if len(complete) else None,comparisons=records,transitions=transitions,
                constraints=constraints,x_range=axis[[0,-1]].tolist())
    save(ROOT/(case+'-horizon-score.json'),output)
    print(case,output['rows'],transitions,[(key,item['passed'],item['first_failure_x']) for key,item in records.items()],flush=True)


if __name__=='__main__':
    from mode_check import COMMON, POST
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    if sys.argv[1]=='freeze':
        for branch in ('cold','heavy'):
            freeze(branch)
    elif sys.argv[1]=='score':
        need(all((ROOT/(branch+'-horizon-prediction.npz')).exists() for branch in ('cold','heavy')),'both forecasts saved')
        for branch in ('cold','heavy'):
            score(branch)
