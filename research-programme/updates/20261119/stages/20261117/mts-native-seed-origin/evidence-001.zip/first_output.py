import sys
from pathlib import Path
from mode_check import ROOT,POST,COMMON,COLD,HEAVY,PRIOR,NORMAL,TOL,math,np,solve_ivp,hierarchy,read,save,need,digest


def inputs(case):
    info=read(ROOT/'mode-result.json')['physical'][case]
    ref=COLD/'cold.npz' if case=='cold' else HEAVY/'chunk-0384.npz'
    with np.load(ref) as data:
        modes=data['modes']
        times=data['conformal_time'][:8]
    clock=POST/'mts-integrated-defect-20261112'/(case+'-native-clock.npz')
    with np.load(clock) as data:
        lower=data['metadata'][0]
        const=data['constants']
    prepared=POST/'mts-matched-clock-precision-20261117'/(case+'-prepared.npz')
    with np.load(prepared) as data:
        need(np.array_equal(const,data['constants']),'native constants identical')
    table=COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    with np.load(table) as data:
        names=['s'] if case=='cold' else ['s','h']
        first_fields=np.array([data['phi_'+key][0] for key in names])
    radiation=const[2]+const[3]+sum(const[14:14+int(const[4])])
    alpha=math.sqrt(radiation/3)
    omega=sum(const[:2])/(3*alpha)
    cap=.001/(alpha*max(const[8:8+int(const[4])]))
    batch=min(times[0],.001/max(modes),.1,cap)
    factor=lower/(.95*batch)
    need(abs(factor-.5)<1e-12 and np.count_nonzero(modes==5)==1,'factor independently identified by runtime thermal clock')
    start=(.001/5)*factor
    need(abs(start/info['tau']-1)<1e-12,'per-mode start verified by two routes')
    return dict(ref=ref,times=times,names=names,fields=first_fields,masses=const[6:6+len(names)],alpha=alpha,omega=omega,
                fraction=info['neutrino_fraction'],baryon=const[1]/sum(const[:2]),start=start,table_age=info['table_age'],
                thermal=dict(archive=str(clock),hash=digest(clock),tauminn=lower,maximum_mode=max(modes),inferred_factor=factor,
                        individual_start=start,first_requested_time=times[0],selected_mode=5.))


class EarlySystem:
    def __init__(self,inputs,last_moment):
        self.inputs=inputs
        self.wave=5.
        self.last=last_moment
        self.first=8+last_moment-2
        self.radiation=inputs['fraction']
        self.baryon=inputs['baryon']
        self.matter=inputs['omega']/self.wave
        self.parameters=(inputs['masses']*inputs['alpha']/self.wave**2)**2
        self.origin=[]
        self.initial=[]
        points=self.wave*np.array([inputs['start'],inputs['table_age']])
        for field,parameter in zip(inputs['fields'],self.parameters):
            both=hierarchy(self.radiation,self.baryon,self.matter,parameter,points,1e-10,.15,last_moment)
            self.origin.append(field/(1+parameter*points[1]**4*both[1,7]))
            self.initial.append(both[0])
        self.origin=np.array(self.origin)

    def initialize(self,kind):
        x=self.wave*self.inputs['start']
        square=x*x
        load=self.matter*x
        scale=x*(1+load/4)
        rad=self.radiation
        den=15+4*rad
        material=self.initial[0]
        source=np.r_[scale,square*material[0],0.,-4*NORMAL+square*material[6],
                     square*material[1],square*material[2],x**3*material[3],x**3*material[4],
                     square*material[5],*[x**ell*material[11+ell-3] for ell in range(3,self.last+1)]]
        if kind=='native':
            cdm=NORMAL*square*(1-load/5)
            source[1]=cdm
            source[3]=-1+square/12*(1-10/den)
            source[4:8]=[4*cdm/3,4*cdm/3,cdm*x/9,x**3*(4*rad+23)/(36*den)]
            source[8]=-2*square/(3*den)*(1+load/4*(4*rad-5)/(2*rad+15))
            source[9:]=0
            source[9]=-4*x**3/(21*den)
        need(len(source)==self.first+1,'layout ending with neutrino moments')
        for idx,(row,parameter) in enumerate(zip(self.initial,self.parameters)):
            state=[x**4*row[7],x**3*row[8],x**6*row[9],x**5*row[10]]
            if kind=='native':
                state[2]=-self.inputs['fields'][idx]/self.origin[idx]*(scale*x)**2*source[1]/105
                state[3]=6*state[2]/x
            source=np.r_[source,state]
        source[2]=self.coefficients(source)[4]
        return source

    def coefficients(self,state):
        scale,cdm,_,metric,light,nu,vg,vn=state[:8]
        slow=state[self.first+1:].reshape(-1,4)
        shift,velocity,pert,derivative=slow.T
        par=self.parameters
        denom=scale**2
        phi=1+par*shift
        phi0=self.origin
        ratio=scale*self.matter
        rad=self.radiation
        dust=self.baryon*.75*light+(1-self.baryon)*cdm
        scalar_energy=.5*phi0**2*((par*velocity)**2+par*denom*phi**2)
        expansion=math.sqrt((1+ratio)/denom+sum(scalar_energy)/3)
        kin=phi0**2*par**2*velocity*derivative
        pot=phi0**2*par**2*denom*phi*pert
        current=phi0**2*par**2*velocity*pert
        density=3*((1-rad)*light+rad*nu+ratio*dust)/denom+np.sum(kin+pot)
        pressure=((1-rad)*light+rad*nu)/denom+np.sum(kin-pot)
        momentum=(4*((1-rad)*vg+rad*vn)+3*ratio*self.baryon*vg)/denom+sum(current)
        constraint=-(metric+.5*density)/expansion
        return expansion,density,pressure,momentum,constraint,kin,pot,current,scalar_energy

    def rhs(self,x,state,form):
        scale,_,speed,_,light,nu,vg,vn,stress=state[:9]
        hubble,density,pressure,momentum,constraint,*_=self.coefficients(state)
        cprime=constraint if form=='constraint' else speed
        force=(density+3*pressure)/2-hubble*cprime
        shear_source=momentum/2
        inertia=.75*self.matter*scale*self.baryon/(1-self.radiation)
        out=[scale*hubble,cprime,force,shear_source,4*(cprime-vg)/3,4*(cprime-vn)/3,
             (light/4-hubble*inertia*vg)/(1+inertia),nu/4-stress,4*vn/15-3*state[9]/10-4*cprime/15+4*shear_source/5]
        for ell in range(3,self.last+1):
            pos=9+ell-3
            below=2*stress if ell==3 else state[pos-1]
            above=state[pos+1] if ell<self.last else 0.
            out.append((ell*below-(ell+1)*above)/(2*ell+1))
        for par,(shift,vel,pert,deriv) in zip(self.parameters,state[self.first+1:].reshape(-1,4)):
            out.extend((vel,-2*hubble*vel-scale**2*(1+par*shift),deriv,
                        -2*hubble*deriv-(1+par*scale**2)*pert+cprime*vel))
        return out

    def output(self,state):
        hubble,_,_,_,constraint,kin,pot,current,scalar_energy=self.coefficients(state)
        wave=self.wave
        out=dict(a=self.inputs['alpha']*state[0]/wave,H=wave*hubble,delta_cdm=state[1],delta_baryon=.75*state[4],
            delta_photon=state[4],delta_neutrino=state[5],etak=wave*state[3],v_photon=4*state[6]/3,v_neutrino=4*state[7]/3)
        for idx,key in enumerate(self.inputs['names']):
            first=self.first+1+4*idx
            out.update({'mts_dphi_'+key:self.origin[idx]*self.parameters[idx]*state[first+2],
                'mts_dphidot_'+key:wave*self.origin[idx]*self.parameters[idx]*state[first+3],
                'mts_drho_'+key:wave**2*(kin[idx]+pot[idx]),'mts_dp_'+key:wave**2*(kin[idx]-pot[idx]),'mts_q_'+key:wave**2*current[idx]})
        return out,abs(state[2]/constraint-1),sum(scalar_energy)/(3*hubble**2)

    def solve(self,kind,form,cap):
        points=self.wave*self.inputs['times']
        first=self.initialize(kind)
        sol=solve_ivp(lambda x,values:self.rhs(x,values,form),(self.wave*self.inputs['start'],points[-1]),first,
            method='DOP853',t_eval=points,rtol=3e-13,atol=1e-34,max_step=cap)
        need(sol.success and np.isfinite(sol.y).all(),'first eight complete')
        rows=[self.output(row) for row in sol.y.T]
        return dict(rows=[row[0] for row in rows],constraint_residual=max(row[1] for row in rows),scalar_energy_fraction_max=max(row[2] for row in rows),calls=sol.nfev)


def freeze(case):
    inputs_case=inputs(case)
    curves={}
    for moment,cap,form in ((6,.016,'trace'),(9,.008,'constraint')):
        system=EarlySystem(inputs_case,moment)
        for kind in ('regular','native'):
            curves[kind+'-'+form]=system.solve(kind,form,cap)
    path=ROOT/(case+'-first-eight-prediction.json')
    save(path,dict(curves=curves,thermal=inputs_case['thermal'],times=inputs_case['times'].tolist(),reference_sha=digest(inputs_case['ref']),
        method=digest(ROOT/'FIRST-OUTPUT.md'),code=digest(Path(__file__)),seed_authority=digest(ROOT/'mode-result.json')))


def score(case):
    path=ROOT/(case+'-first-eight-prediction.json')
    frozen=read(path)
    args=inputs(case)
    need(frozen['reference_sha']==digest(args['ref']) and frozen['method']==digest(ROOT/'FIRST-OUTPUT.md') and frozen['code']==digest(Path(__file__)),'predictions not altered')
    with np.load(args['ref']) as data:
        idx=int(np.flatnonzero(data['modes']==5)[0])
        names=data['names'].tolist()
        reference=data['values'][idx,:8]
        need(np.array_equal(data['conformal_time'][:8],frozen['times']),'all original event times')
    output={}
    for kind in ('regular','native'):
        fine=frozen['curves'][kind+'-constraint']
        other=frozen['curves'][kind+'-trace']
        need(max(fine['constraint_residual'],other['constraint_residual'])<TOL,'independent Einstein constraints')
        reports={}
        for key in fine['rows'][0]:
            physical=np.array([row[key] for row in fine['rows']])
            control=np.array([row[key] for row in other['rows']])
            actual=reference[:,names.index(key)]
            need(np.all(actual!=0),'relative comparison ill-defined: '+key)
            discrepancy=(physical-actual)/abs(actual)
            budget=(abs(physical-control)+abs(physical-actual))/abs(actual)
            reports[key]=dict(errors=discrepancy.tolist(),refinement_max=max(abs((physical-control)/actual)),max_budget=max(budget),passes=int(sum(budget<=TOL)))
        output[kind]=reports
        print(case,kind,[(name,round(row['max_budget'],8),row['passes']) for name,row in reports.items()],flush=True)
    save(ROOT/(case+'-first-eight-score.json'),dict(frozen_sha=digest(path),reference=str(args['ref']),reports=output,tolerance=TOL))


if __name__=='__main__':
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    if sys.argv[1]=='freeze':
        for name in ('cold','heavy'):
            freeze(name)
    elif sys.argv[1]=='score':
        for name in ('cold','heavy'):
            score(name)
