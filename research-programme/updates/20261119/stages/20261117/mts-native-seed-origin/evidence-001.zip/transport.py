from pathlib import Path
import sys
from first_output import COMMON, ROOT, POST, TOL, EarlySystem, digest, inputs, math, need, np, read, save, solve_ivp
from horizon import setup
from scipy.interpolate import RectBivariateSpline


def plasma(config):
    native=POST/'mts-coupled-metric-consistency-20261117/native'
    table=native/'camb/PRIMAT_Yp_DH_ErrorMC_2021.dat'
    labels=next(line.lstrip('# ').split() for line in table.read_text().splitlines() if line.startswith('#') and 'ombh2' in line and 'Yp^BBN' in line and 'DeltaN' in line)
    raw=np.loadtxt(table)
    baryons,delta,abundance=[raw[:,labels.index(label)] for label in ('ombh2','DeltaN','Yp^BBN')]
    bx,dx=np.unique(baryons),np.unique(delta)
    data=np.full((len(bx),len(dx)),np.nan)
    data[np.searchsorted(bx,baryons),np.searchsorted(dx,delta)]=abundance
    need(np.isfinite(data).all(),'complete original BBN grid')
    mass_ratio=6.646479073e-27/1.673575e-27
    bn=RectBivariateSpline(bx,dx,data).ev(.02239,0.).item()
    helium=bn*mass_ratio/(bn*mass_ratio+4*(1-bn))
    electrons=1+2*helium/((1-helium)*mass_ratio)
    grav_b=3*config['alpha']*config['omega']*config['baryon']
    light_speed=299792458.
    mpc=3.085677581e22
    need(abs(grav_b/(3*(1e5/light_speed)**2*.02239)-1)<1e-8,'original baryon density in inverse Mpc squared')
    constant=6.6524587321e-29*(1-helium)*grav_b*light_speed**2/(8*math.pi*6.67430e-11*1.673575e-27*mpc)*electrons
    sound=4/3*1.380649e-23*2.7255/(1.67262192369e-27*light_speed**2)*(1-.75*helium+(1-helium)*electrons)
    sources=[table,native/'camb/bbn.py',native/'camb/model.py',native/'fortran/constants.f90',native/'fortran/results.f90',native/'fortran/equations.f90',
        COMMON/'radiation-and-slow-field-transfer-20261007/radiation_common.py']
    return dict(helium=helium,electrons=electrons,opacity_a2=constant,sound_a=sound,files={str(path):digest(path) for path in sources})


class Transport:
    def __init__(self,config,moments,order):
        self.base=EarlySystem(config,moments)
        self.gas=plasma(config)
        self.order=order

    def terms(self,state):
        model=self.base
        values=state[:-1]
        scale,_,_,metric,light,_,bulk,_,nu_stress=values[:9]
        entropy=state[-1]
        hubble,_,_,momentum,constraint,*_=model.coefficients(values)
        inertia=.75*model.matter*scale*model.baryon/(1-model.radiation)
        extra=3*model.matter*model.baryon*entropy/scale
        constraint-=.5*extra/hubble
        physical_scale=model.inputs['alpha']*scale/model.wave
        length=model.wave*physical_scale**2/self.gas['opacity_a2']
        gas=self.gas['sound_a']/physical_scale*(.75*light+entropy)
        geometry=-constraint+1.5*momentum
        potential=geometry+bulk
        stress=32/45*length*potential
        if self.order==2:
            shear_dot=-2*hubble*geometry-3*((1-model.radiation)*stress+model.radiation*2*nu_stress)/scale**2+metric
            bulk_dot=(light/4-stress/2+inertia*(gas-hubble*bulk))/(1+inertia)
            stress-=32/45*11/6*length**2*(2*hubble*potential+shear_dot+bulk_dot)
        slip=length*inertia/(1+inertia)*(gas-hubble*bulk-light/4+stress/2)
        return hubble,extra,constraint,inertia,gas,stress,slip,length

    def rhs(self,coordinate,state,form):
        model=self.base
        values=state[:-1]
        hubble,extra,_,inertia,gas,stress,slip,_=self.terms(state)
        shift=-.5*extra/hubble if form=='constraint' else 0.
        out=model.rhs(coordinate,values,form)
        out[1]+=shift
        out[2]+=.5*extra-hubble*shift
        out[4]+=4/3*(shift+inertia/(1+inertia)*slip)
        out[5]+=4/3*shift
        out[6]+=(inertia*gas-stress/2)/(1+inertia)
        out[8]-=4/15*shift
        for idx in range(len(model.origin)):
            first=model.first+1+4*idx
            out[first+3]+=shift*values[first+1]
        return [*out,-slip]

    def solve(self,form,cap):
        model=self.base
        config=model.inputs
        points=5*config['times']
        seed=np.r_[model.initialize('regular'),0.]
        need(points[0]>5*config['start'],'first original time later than the mode start')
        sol=solve_ivp(lambda time,state:self.rhs(time,state,form),(5*config['start'],points[-1]),seed,t_eval=points,method='DOP853',rtol=3e-13,atol=1e-34,max_step=cap)
        need(sol.success and np.isfinite(sol.y).all(),'all plasma states finite')
        rows=[]
        residual=[]
        for state in sol.y.T:
            row,_,_=model.output(state[:-1])
            _,_,constraint,inertia,_,stress,slip,length=self.terms(state)
            row['delta_baryon']+=state[-1]
            row['v_photon']=4/3*(state[6]-inertia/(1+inertia)*slip)
            row.update(pi_photon=stress,v_baryon_cdm=state[6]+slip/(1+inertia),slip=slip)
            rows.append(row)
            residual.append(abs(state[2]/constraint-1))
        return list(rows[0]),np.array([list(row.values()) for row in rows]),max(residual),length


def freeze(case):
    config=setup(case)
    packet={}
    for order in (1,2):
        for moment,cap,form in ((24,.06,'trace'),(32,.03,'constraint')):
            system=Transport(config,moment,order)
            keys,rows,cons,length=system.solve(form,cap)
            label=form+str(order)
            packet[label]=rows
            packet[label+'_constraint_residual']=cons
            need(cons<TOL,'plasma trace/constraint')
    provenance=plasma(config)
    with (ROOT/(case+'-plasma-prediction.npz')).open('xb') as file:
        np.savez_compressed(file,**packet,names=keys,times=config['times'],source=digest(config['ref']),code=digest(Path(__file__)),method=digest(ROOT/'TRANSPORT.md'),
            ideal=digest(ROOT/(case+'-horizon-prediction.npz')),length_last=length)
    save(ROOT/(case+'-plasma-inputs.json'),provenance)


def score(case):
    config=setup(case)
    path=ROOT/(case+'-plasma-prediction.npz')
    with np.load(path) as file, np.load(config['ref']) as archive:
        need(str(file['source'])==digest(config['ref']) and str(file['code'])==digest(Path(__file__)) and str(file['method'])==digest(ROOT/'TRANSPORT.md') and np.array_equal(file['times'],config['times']),'frozen paired transport')
        names=file['names'].tolist()
        native=archive['names'].tolist()
        data=archive['values'][int(np.flatnonzero(archive['modes']==5)[0]),:len(config['times'])]
        saved=np.stack([data[:,native.index(key)] if key!='slip' else data[:,native.index('v_baryon_cdm')]-.75*data[:,native.index('v_photon')] for key in names],axis=1)
        results={}
        for order in (1,2):
            predicted=file['constraint'+str(order)]
            refinement=abs(predicted-file['trace'+str(order)])
            budgets=np.full_like(saved,np.inf)
            np.divide(abs(predicted-saved)+refinement,abs(saved),out=budgets,where=saved!=0)
            passed=budgets<=TOL
            results[str(order)]={}
            for col,key in enumerate(names):
                failures=np.flatnonzero(~passed[:,col])
                worst=int(np.argmax(budgets[:,col]))
                results[str(order)][key]=dict(passes=int(passed[:,col].sum()),first_fail=int(failures[0]) if len(failures) else None,
                    worst_relative=None if saved[worst,col]==0 else budgets[worst,col],worst_row=worst,
                    absolute_error_over_peak=max(abs(predicted[:,col]-saved[:,col]))/max(abs(saved[:,col])),
                    refinement_over_peak=max(refinement[:,col])/max(abs(saved[:,col])),zero_reference=int((saved[:,col]==0).sum()))
            with (ROOT/(case+'-plasma-differences-'+str(order)+'.npz')).open('xb') as target:
                np.savez_compressed(target,names=names,signed=predicted-saved,refinement=refinement,passed=passed,times=config['times'])
        length=float(file['length_last'])
    save(ROOT/(case+'-plasma-score.json'),dict(reports=results,reference=str(config['ref']),tolerance=TOL,rows=len(config['times']),frozen=digest(path),length_last=length))
    print(case,length,[(key,row['passes'],round(row['absolute_error_over_peak'],8)) for key,row in results['2'].items()],flush=True)


if __name__=='__main__':
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    if sys.argv[1]=='freeze':
        for name in ('cold','heavy'):
            freeze(name)
    elif sys.argv[1]=='score':
        need(all((ROOT/(name+'-plasma-prediction.npz')).exists() for name in ('cold','heavy')),'both frozen')
        for name in ('cold','heavy'):
            score(name)
