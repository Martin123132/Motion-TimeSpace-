from pathlib import Path
from angular_work import ROOT, POST, COMMON, TOL, Collision, digest, need, np, save, target, weights
from kinetic import solve_ivp
from exchange import terms


def probe(solver,state,form,coord,factors):
    intensity,polar=state[solver.count+2:].reshape(2,-1)
    _,_,_,_,_,vg,_,length,geometry,*_=solver.quantities(state)
    a2=factors[0,0]*(.75*intensity[0]**2+2.4*(polar[0]-intensity[0]/4)**2)/length
    high=(factors[0,1:]@intensity[1:]**2+factors[1,1:]@polar[1:]**2)/length
    power=factors[0,0]*8/15*intensity[0]*(vg+geometry)
    energy=(factors[0]@intensity**2+factors[1]@polar**2)/2
    individual=np.array(solver.rhs(coord,state,form))[solver.count+2:].reshape(2,-1)
    storage_rate=factors[0]@(individual[0]*intensity)+factors[1]@(individual[1]*polar)
    return np.array([power,a2,high,terms(solver,state)[0][0],storage_rate,energy])


def integrate_case(config,case,limits):
    packet=ROOT/(case+'-kinetic-prediction.npz')
    epoch=5*config['times'][1:]
    edges=np.r_[limits[0],epoch[(epoch>limits[0])&(epoch<limits[1])],limits[1]]
    mid=(edges[1:]+edges[:-1])/2
    half=np.diff(edges)/2
    trials={}
    with np.load(packet) as old:
        for label,nnu,nphot,method,form,cap,rtol in (('BDF_base',34,4,'BDF','trace',.07,1e-10),('Radau_base',48,7,'Radau','constraint',.05,1e-10),('Radau_erased',48,7,'Radau','constraint',.05,1e-10)):
            model=Collision(config,nnu,nphot)
            sol=solve_ivp(lambda x,y:model.rhs(x,y,form),(epoch[0],limits[1]),old[label+'_states'][1],method=method,rtol=rtol,atol=1e-17,max_step=cap,dense_output=True)
            need(sol.success,'dense kinetic states')
            factors=weights(nphot)
            values=[probe(model,sol.sol(bound),form,bound,factors)[-1] for bound in limits]
            store_change=values[1]-values[0]
            for degree in (4,8):
                tmp,ws=np.polynomial.legendre.leggauss(degree)
                nodes=(mid[:,None]+half[:,None]*tmp).ravel()
                factors_integral=(half[:,None]*ws).ravel()
                hist=sol.sol(nodes)
                vals=np.array([probe(model,state,form,coord,factors) for coord,state in zip(nodes,hist.T)])
                accum=np.array([np.sum((vals[:,col]*factors_integral).astype(np.longdouble),dtype=np.longdouble) for col in range(5)],float)
                supply,quadr,high,drag,rate=accum
                total=quadr+high
                trials[f'{label}-{degree}']=dict(supply=supply,quadrupole=quadr,higher=high,angular=total,dipole=drag,stored=store_change,
                    stored_rate=rate,closure_over_supply=abs((supply-total)-store_change)/abs(supply),
                    closure_over_storage=abs((supply-total)/store_change-1),storage_derivative_error=abs(rate/store_change-1),
                    ratio_to_dipole=total/drag)
            print(case,label,trials[label+'-8'],flush=True)
    return trials


def main():
    configs={case:target(case) for case in ('cold','heavy')}
    limits=[max(5*cfg['times'][1] for cfg in configs.values()),min(5*cfg['times'][-1] for cfg in configs.values())]
    runs={case:integrate_case(cfg,case,limits) for case,cfg in configs.items()}
    summary={}
    for key in ('angular','dipole','stored','supply','higher'):
        error={}
        for case,trials in runs.items():
            central=trials['Radau_base-8'][key]
            error[case]={label:abs(trials[idname][key]-central) for label,idname in [('quadrature','Radau_base-4'),('solver','BDF_base-8'),('startup','Radau_erased-8')]}
        cold=runs['cold']['Radau_base-8'][key]
        heavy=runs['heavy']['Radau_base-8'][key]
        diff=heavy-cold
        summary[key]=dict(per_branch={case:sum(parts.values())/abs(runs[case]['Radau_base-8'][key]) for case,parts in error.items()},
            fractional_contrast=diff/cold,paired_difference=diff,difference_budget=sum(sum(vals.values()) for vals in error.values())/abs(diff),
            difference_budget_breakdown={label:sum(parts[label] for parts in error.values())/abs(diff) for label in ('quadrature','solver','startup')})
    save(ROOT/'dense-power.json',dict(tolerance=TOL,common_x=limits,method=digest(ROOT/'DENSE.md'),code=digest(Path(__file__)),runs=runs,summary=summary,
        sources={case:digest(ROOT/(case+'-kinetic-prediction.npz')) for case in configs}))
    print(summary,flush=True)


if __name__=='__main__':
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    main()
