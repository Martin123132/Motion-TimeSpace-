from pathlib import Path
from kinetic import ROOT, POST, COMMON, TOL, Collision, digest, need, np, save, solve_ivp, target


def terms(system,state):
    hubble,_,_,inertia,gas,_,vb,length,_,_,slip_dot,_,_=system.quantities(state)
    slip=state[system.count+1]
    shear=state[system.count+2]
    reduced=inertia/(1+inertia)
    reduced_dot=hubble*reduced/(1+inertia)
    driving=gas-hubble*vb-state[4]/4+shear/2
    work=reduced*slip*driving+.5*reduced_dot*slip**2
    heat=slip**2/length
    stored=reduced*slip**2/2
    storage_rate=reduced*slip*slip_dot+.5*reduced_dot*slip**2
    return np.array([heat,work,storage_rate]),stored


def evolve(case,cfg,limits):
    source=ROOT/(case+'-kinetic-prediction.npz')
    with np.load(source) as packet:
        rows={}
        for label,nu,phot,method,form,cap,rtol in [('BDF_base',34,4,'BDF','trace',.08,1e-10),
                ('Radau_base',48,7,'Radau','constraint',.05,1e-10),('Radau_erased',48,7,'Radau','constraint',.05,1e-10)]:
            initial=packet[label+'_states'][1].copy()
            time_start=5*cfg['times'][1]
            model=Collision(cfg,nu,phot)
            _,initial_storage=terms(model,initial)
            start_rates,_=terms(model,initial)
            energy_scale=start_rates[0]*(limits[1]-limits[0])
            scales=np.array([energy_scale,energy_scale,initial_storage])
            def equation(x,state):
                actual=state[:-3]
                rates,_=terms(model,actual)
                return np.r_[model.rhs(x,actual,form),rates/scales]
            output=solve_ivp(lambda elapsed,state:equation(time_start+elapsed,state),(0.,limits[1]-time_start),np.r_[initial,0.,0.,0.],
                t_eval=np.asarray(limits)-time_start,method=method,rtol=rtol,atol=1e-17,max_step=cap)
            need(output.success and np.isfinite(output.y).all(),'complete integral: '+output.message)
            totals=np.diff(output.y[-3:],axis=1)[:,0]*scales
            boundary=[terms(model,state[:-3])[1] for state in output.y.T]
            change=boundary[1]-boundary[0]
            residual=float(np.longdouble(totals[1])-np.longdouble(totals[0])-np.longdouble(change))
            need(totals[0]>0 and change!=0,'positive heat and nonzero boundary signal')
            rows[label]=dict(heat=totals[0],work=totals[1],stored_integral=totals[2],storage=change,endpoints=boundary,
                balance_error_over_heat=abs(residual)/totals[0],balance_error_over_storage=abs(residual)/abs(change),
                separate_storage_error=abs(totals[2]/change-1),calls=output.nfev)
            print(case,label,rows[label],flush=True)
    return rows


if __name__=='__main__':
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    configs={case:target(case) for case in ('cold','heavy')}
    lower=max(5*cfg['times'][1] for cfg in configs.values())
    upper=min(5*cfg['times'][-1] for cfg in configs.values())
    radiation=[3*cfg['alpha']**2*(1-cfg['fraction']) for cfg in configs.values()]
    need(radiation[0]==radiation[1],'same photon normalization')
    runs={case:evolve(case,cfg,[lower,upper]) for case,cfg in configs.items()}
    budgets={}
    for key in ('heat','work','storage'):
        errors={case:sum(abs(row[other][key]-row['Radau_base'][key]) for other in ('BDF_base','Radau_erased')) for case,row in runs.items()}
        difference=runs['heavy']['Radau_base'][key]-runs['cold']['Radau_base'][key]
        budgets[key]=dict(per_branch_fractional={case:errors[case]/abs(runs[case]['Radau_base'][key]) for case in runs},
            paired_difference=difference,paired_fraction_of_cold=difference/runs['cold']['Radau_base'][key],
            budget_on_paired_difference=sum(errors.values())/abs(difference))
    save(ROOT/'exchange-score.json',dict(runs=runs,budgets=budgets,common_x=[lower,upper],grhog=radiation[0],tolerance=TOL,
        method=digest(ROOT/'EXCHANGE.md'),code=digest(Path(__file__)),kinetic_sources={case:digest(ROOT/(case+'-kinetic-prediction.npz')) for case in configs}))
    print('paired',budgets,flush=True)
