from fractions import Fraction
from pathlib import Path
from kinetic import COMMON, POST, ROOT, TOL, Collision, digest, need, np, save, target
from scipy.interpolate import make_interp_spline
from exchange import terms


def weights(limit):
    wave=[Fraction(3*(2*ell+1),16) for ell in range(2,limit+1)]
    polar=[6*wave[0]]
    for ell in range(2,limit):
        polar.append(polar[-1]*Fraction((ell+3)*(ell-1)*(2*ell+3),(ell+1)**2*(2*ell+1)))
        need(wave[ell-2]*Fraction(ell+1,2*ell+1)==wave[ell-1]*Fraction(ell+1,2*ell+3),'intensity streaming cancellation')
        need(polar[-2]*Fraction((ell+3)*(ell-1),(ell+1)*(2*ell+1))==polar[-1]*Fraction(ell+1,2*ell+3),'polar streaming cancellation')
    need(6*wave[0]==polar[0],'symmetric cross collision')
    return np.array([wave,polar],dtype=float)


def records(cfg,case):
    output={}
    with np.load(ROOT/(case+'-kinetic-prediction.npz')) as packet:
        for label,nnu,nph,form in (('BDF_base',34,4,'trace'),('Radau_base',48,7,'constraint'),('Radau_erased',48,7,'constraint')):
            solver=Collision(cfg,nnu,nph)
            factors=weights(nph)
            rows=[]
            for coord,state in zip(5*cfg['times'][1:],packet[label+'_states'][1:]):
                moments=state[solver.count+2:].reshape(2,-1)
                rates=np.array(solver.rhs(coord,state,form)[solver.count+2:]).reshape(2,-1)
                _,_,_,_,_,vg,_,length,geometry,*_=solver.quantities(state)
                shear,polar=moments[:,0]
                energy=np.sum(factors*moments**2)/2
                derivative=np.sum(factors*moments*rates)
                quadr=factors[0,0]*(.75*shear**2+2.4*(polar-shear/4)**2)/length
                higher=np.sum(factors[:,1:]*moments[:,1:]**2)/length
                source=factors[0,0]*8/15*shear*(vg+geometry)
                dipole=terms(solver,state)[0][0]
                need(min(quadr,higher,dipole,energy)>=0,'positive component powers')
                rows.append([source,quadr,higher,dipole,energy,derivative])
            output[label]=np.array(rows)
    return output


def integrate(times,rows,limits,degree,step):
    use=np.unique(np.r_[np.arange(0,len(times),step),len(times)-1])
    spline=make_interp_spline(times[use],rows[use],k=degree)
    integrals=spline.integrate(*limits)
    storage=spline(limits[1])[4]-spline(limits[0])[4]
    total=integrals[1]+integrals[2]
    residual=(integrals[0]-total)-storage
    identity=rows[:,0]-rows[:,1]-rows[:,2]-rows[:,5]
    return dict(supply=integrals[0],quadrupole=integrals[1],higher=integrals[2],angular=total,dipole=integrals[3],stored=storage,stored_rate=integrals[5],
        closure_over_storage=abs(residual/storage),closure_over_supply=abs(residual/integrals[0]),integrated_derivative_over_storage=abs(integrals[5]/storage-1),
        max_pointwise_identity_over_power=max(abs(identity)/np.maximum(abs(rows[:,0])+rows[:,1]+rows[:,2],1e-100)),
        angular_to_dipole=total/integrals[3])


def main():
    cfg={case:target(case) for case in ('cold','heavy')}
    limits=[max(5*one['times'][1] for one in cfg.values()),min(5*one['times'][-1] for one in cfg.values())]
    results={}
    paired={}
    for case,config in cfg.items():
        values=records(config,case)
        times=5*config['times'][1:]
        with (ROOT/(case+'-angular-sources.npz')).open('xb') as file:
            np.savez_compressed(file,**values,x=times,names=['supply','D2','Dhigh','dipole','stored','hierarchy_derivative'])
        trials={}
        for label,rows in values.items():
            degrees=[(7,1),(5,1),(7,2)] if label=='Radau_base' else [(7,1)]
            for degree,step in degrees:
                trials[label+f'-{degree}-{step}']=integrate(times,rows,limits,degree,step)
        primary=trials['Radau_base-7-1']
        errors={key:sum(abs(trial[key]-primary[key]) for trial in trials.values()) for key in ('angular','dipole','higher','stored','supply')}
        results[case]=dict(trials=trials,budget={key:val/abs(primary[key]) for key,val in errors.items()},absolute_budget=errors)
        print(case,primary,results[case]['budget'],flush=True)
    for key in ('angular','dipole','stored'):
        cold=results['cold']['trials']['Radau_base-7-1'][key]
        heavy=results['heavy']['trials']['Radau_base-7-1'][key]
        paired[key]=dict(difference=heavy-cold,fraction_of_cold=heavy/cold-1,
            budget_on_difference=sum(item['absolute_budget'][key] for item in results.values())/abs(heavy-cold))
    save(ROOT/'angular-score.json',dict(tolerance=TOL,common_x=limits,source_hashes={case:digest(ROOT/(case+'-kinetic-prediction.npz')) for case in results},
        method=digest(ROOT/'ANGULAR-WORK.md'),code=digest(Path(__file__)),results=results,paired=paired))
    print('paired angular terms',paired,flush=True)


if __name__=='__main__':
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    main()
