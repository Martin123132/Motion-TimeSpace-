from pathlib import Path
import sys
from transport import ROOT, POST, COMMON, EarlySystem, TOL, digest, inputs, need, np, plasma, save, solve_ivp


def extended(case):
    config=inputs(case)
    with np.load(config['ref']) as data:
        times=data['conformal_time']
        config['times']=times[:1+np.searchsorted(5*times,24.)]
    need(5*config['times'][-2]<24<=5*config['times'][-1],'predeclared cutoff')
    return config


class Pair:
    def __init__(self,config,moments,closure):
        self.base=EarlySystem(config,moments)
        self.gas=plasma(config)
        self.closure=closure

    def local(self,state):
        model=self.base
        core=state[:-2]
        entropy,current=state[-2:]
        scale,_,_,metric,light,_,bulk,_,nu=core[:9]
        hubble,_,_,momentum,old,*_=model.coefficients(core)
        inertia=.75*model.matter*scale*model.baryon/(1-model.radiation)
        added=3*model.matter*model.baryon*entropy/scale
        cons=old-.5*added/hubble
        aval=model.inputs['alpha']*scale/model.wave
        length=model.wave*aval**2/self.gas['opacity_a2']
        sound=self.gas['sound_a']/aval
        slip=length*current/(1+inertia)**2
        vb=bulk+slip/(1+inertia)
        vg=bulk-inertia*slip/(1+inertia)
        fields=core[model.first+1:].reshape(-1,4)
        kinetic=(model.parameters*fields[:,1])**2
        potential=model.parameters*scale**2*(1+model.parameters*fields[:,0])**2
        accel=(3*model.matter/scale+np.sum(model.origin**2*(2*potential-kinetic)))/6
        source=-accel*vb-hubble*light/2+sound*(cons-vb)-(cons-vg)/3
        current_dot=inertia*(1+inertia)*source
        slip_dot=2*hubble*slip/(1+inertia)+length*current_dot/(1+inertia)**2
        geometry=-cons+1.5*momentum
        first_pi=32/45*length*(geometry+vb)
        geo_dot=-2*hubble*geometry-3*((1-model.radiation)*first_pi+2*model.radiation*nu)/scale**2+metric
        delta_p=sound*(.75*light+entropy)
        if self.closure=='archive':
            dipole_dot=.75*(light/4-first_pi/2+model.wave/length*slip_dot)
        else:
            dipole_dot=(light/4-first_pi/2+inertia*(delta_p-hubble*bulk))/(1+inertia)
        shear=32/45*length*((geometry+vg)*(1-11/3*length*hubble)-11/6*length*(geo_dot+dipole_dot))
        return hubble,added,cons,inertia,delta_p,shear,slip,vg,vb,current_dot,length

    def rhs(self,coord,state,form):
        core=state[:-2]
        model=self.base
        hubble,added,_,inertia,gas,shear,slip,_,_,current_dot,_=self.local(state)
        shift=-.5*added/hubble if form=='constraint' else 0.
        out=model.rhs(coord,core,form)
        out[1]+=shift
        out[2]+=.5*added-hubble*shift
        out[4]+=4/3*(shift+inertia/(1+inertia)*slip)
        out[5]+=4/3*shift
        out[6]+=(inertia*gas-shear/2)/(1+inertia)
        out[8]-=4/15*shift
        for idx in range(len(model.origin)):
            first=model.first+1+4*idx
            out[first+3]+=shift*core[first+1]
        return [*out,-slip,current_dot]

    def run(self,form,cap):
        model=self.base
        config=model.inputs
        xgrid=model.wave*config['times']
        initial=np.r_[model.initialize('regular'),0.,0.]
        sol=solve_ivp(lambda x,vals:self.rhs(x,vals,form),(model.wave*config['start'],xgrid[-1]),initial,
            t_eval=xgrid,rtol=3e-13,atol=1e-34,method='DOP853',max_step=cap)
        need(sol.success and np.isfinite(sol.y).all(),'independent evolution complete')
        rows=[]
        cons_errors=[]
        for state in sol.y.T:
            result=model.output(state[:-2])[0]
            _,_,cons,_,_,shear,slip,vg,vb,_,length=self.local(state)
            result['delta_baryon']+=state[-2]
            result.update(v_photon=4*vg/3,pi_photon=shear,v_baryon_cdm=vb,slip=slip)
            rows.append(result)
            cons_errors.append(abs(state[2]/cons-1))
        need(max(cons_errors)<TOL,'trace constraint consistency')
        return list(rows[0]),np.array([list(row.values()) for row in rows]),max(cons_errors),length


def freeze(case):
    config=extended(case)
    packet={}
    for closure in ('physical','archive'):
        for order,cap,form in ((40,.06,'trace'),(52,.03,'constraint')):
            solver=Pair(config,order,closure)
            keys,rows,con,length=solver.run(form,cap)
            packet[closure+'_'+form]=rows
            packet[closure+'_'+form+'_constraint']=con
    with (ROOT/(case+'-slip-prediction.npz')).open('xb') as file:
        np.savez_compressed(file,**packet,names=keys,times=config['times'],code=digest(Path(__file__)),method=digest(ROOT/'SLIP.md'),
            source=digest(config['ref']),old=digest(ROOT/(case+'-plasma-prediction.npz')),length_last=length)


def score(case):
    config=extended(case)
    path=ROOT/(case+'-slip-prediction.npz')
    with np.load(path) as packet,np.load(config['ref']) as data:
        times=config['times']
        need(np.array_equal(times,packet['times']) and str(packet['code'])==digest(Path(__file__)) and str(packet['method'])==digest(ROOT/'SLIP.md')
            and str(packet['source'])==digest(config['ref']),'unchanged prediction and source')
        names=packet['names'].tolist()
        native=data['names'].tolist()
        values=data['values'][int(np.flatnonzero(data['modes']==5)[0]),:len(times)]
        vb=values[:,native.index('v_baryon_cdm')]
        vg=.75*values[:,native.index('v_photon')]
        need(np.array_equal(vb,vb.astype(np.float32)),'native float32 baryon word at every epoch')
        stored=vb.astype(np.float32)
        below=np.nextafter(stored,np.float32(-np.inf)).astype(float)
        above=np.nextafter(stored,np.float32(np.inf)).astype(float)
        lower=vb-vg+(below-vb)/2
        upper=vb-vg+(above-vb)/2
        actual=np.stack([values[:,native.index(key)] if key!='slip' else vb-vg for key in names],axis=1)
        outputs={}
        for closure in ('physical','archive'):
            pred=packet[closure+'_constraint']
            steps=abs(pred-packet[closure+'_trace'])
            err=pred-actual
            totals=np.full_like(steps,np.inf)
            np.divide(abs(err)+steps,abs(actual),out=totals,where=actual!=0)
            slip=pred[:,names.index('slip')]
            compat=(slip>=lower)&(slip<=upper)
            resolvable=(upper-lower)/2<=abs(slip)*TOL
            reports={}
            for label,selector in [('all',slice(None)),('earlier',slice(0,327)),('extension',slice(327,None))]:
                selected=totals[selector]
                records={}
                for col,key in enumerate(names):
                    ref=actual[selector,col]
                    budgets=selected[:,col]
                    records[key]=dict(passes=int(np.sum(budgets<=TOL)),worst=None if not np.isfinite(budgets).all() else max(budgets),
                        peak_scaled=max(abs(err[selector,col]))/max(abs(ref)),refinement_over_peak=max(steps[selector,col])/max(abs(ref)))
                reports[label]=dict(count=len(selected),channels=records,word_compatible=int(compat[selector].sum()),slip_resolvable_to_tolerance=int(resolvable[selector].sum()))
            outputs[closure]=reports
            with (ROOT/(case+'-slip-differences-'+closure+'.npz')).open('xb') as file:
                np.savez_compressed(file,names=names,times=times,signed=err,abs_refinement=steps,passed=totals<=TOL,
                    slip_interval=np.c_[lower,upper],compatible=compat,resolvable=resolvable)
            print(case,closure,[(label,row['count'],row['word_compatible'],row['slip_resolvable_to_tolerance'],row['channels']['pi_photon']) for label,row in reports.items()],flush=True)
        save(ROOT/(case+'-slip-score.json'),dict(tolerance=TOL,reference=str(config['ref']),prediction=digest(path),reports=outputs,length_last=float(packet['length_last'])))


if __name__=='__main__':
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    if sys.argv[1]=='freeze':
        for name in ('cold','heavy'):
            freeze(name)
    elif sys.argv[1]=='score':
        need(all((ROOT/(name+'-slip-prediction.npz')).exists() for name in ('cold','heavy')),'paired forecasts')
        for name in ('cold','heavy'):
            score(name)
