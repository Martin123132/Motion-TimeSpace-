from pathlib import Path
import sys
from slip_bridge import COMMON, POST, ROOT, TOL, Pair, digest, extended, need, np, save, solve_ivp
from fractions import Fraction


def target(case):
    cfg=extended(case)
    with np.load(cfg['ref']) as archive:
        times=archive['conformal_time']
        cfg['times']=times[326:np.searchsorted(5*times,32.)+1]
    need(5*cfg['times'][-2]<32<=5*cfg['times'][-1],'frozen extended grid')
    return cfg


class Collision:
    def __init__(self,cfg,nu,photon):
        self.driver=Pair(cfg,nu,'physical')
        self.base=self.driver.base
        self.photon=photon
        self.count=self.base.first+1+4*len(self.base.origin)

    def quantities(self,state):
        model=self.base
        core=state[:self.count]
        entropy,slip=state[self.count:self.count+2]
        scale,_,_,metric,light,_,bulk,_,nu=core[:9]
        hubble,_,_,momentum,old,*_=model.coefficients(core)
        inertia=.75*model.matter*scale*model.baryon/(1-model.radiation)
        extra=3*model.matter*model.baryon*entropy/scale
        cons=old-.5*extra/hubble
        physical=model.inputs['alpha']*scale/model.wave
        length=model.wave*physical**2/self.driver.gas['opacity_a2']
        sound=self.driver.gas['sound_a']/physical
        gas=sound*(.75*light+entropy)
        vb=bulk+slip/(1+inertia)
        vg=bulk-inertia*slip/(1+inertia)
        geometry=-cons+1.5*momentum
        modes=state[self.count+2:].reshape(2,-1)
        shear=modes[0,0]
        bulk_dot=(light/4-shear/2+inertia*(gas-hubble*bulk))/(1+inertia)
        slip_dot=gas-hubble*vb-light/4+shear/2-(1+1/inertia)*slip/length
        shear_dot=-2*hubble*geometry-3*((1-model.radiation)*shear+2*model.radiation*nu)/scale**2+metric
        vg_dot=bulk_dot-inertia/(1+inertia)*slip_dot-hubble*inertia*slip/(1+inertia)**2
        return hubble,extra,cons,inertia,gas,vg,vb,length,geometry,bulk_dot,slip_dot,shear_dot,vg_dot

    def rhs(self,coord,state,form):
        core=state[:self.count]
        model=self.base
        hubble,extra,_,inertia,_,vg,_,length,geometry,bulk_dot,slip_dot,_,_=self.quantities(state)
        slip=state[self.count+1]
        shift=-.5*extra/hubble if form=='constraint' else 0.
        out=model.rhs(coord,core,form)
        out[1]+=shift
        out[2]+=.5*extra-hubble*shift
        out[4]+=4/3*(shift+inertia/(1+inertia)*slip)
        out[5]+=4/3*shift
        out[6]=bulk_dot
        out[8]-=4/15*shift
        for idx in range(len(model.origin)):
            first=model.first+1+4*idx
            out[first+3]+=shift*core[first+1]
        intensity,polar=state[self.count+2:].reshape(2,-1)
        joint=intensity[0]/10+.6*polar[0]
        intensity_dot=[8/15*(vg+geometry)-.6*intensity[1]-(intensity[0]-joint)/length]
        polar_dot=[-polar[1]/3-(polar[0]-joint)/length]
        for ell in range(3,self.photon+1):
            pos=ell-2
            high_int=intensity[pos+1] if ell<self.photon else 0.
            high_pol=polar[pos+1] if ell<self.photon else 0.
            intensity_dot.append((ell*intensity[pos-1]-(ell+1)*high_int)/(2*ell+1)-intensity[pos]/length)
            polar_dot.append((ell*polar[pos-1]-(ell+3)*(ell-1)/(ell+1)*high_pol)/(2*ell+1)-polar[pos]/length)
        return [*out,-slip,slip_dot,*intensity_dot,*polar_dot]

    def start(self,form,cap):
        cfg=self.base.inputs
        init=np.r_[self.base.initialize('regular'),0.,0.]
        x_first=5*cfg['times'][0]
        sol=solve_ivp(lambda x,state:self.driver.rhs(x,state,form),(5*cfg['start'],x_first),init,
            rtol=3e-13,atol=1e-34,method='DOP853',max_step=cap)
        need(sol.success,'coupled preparation to switching surface')
        state=sol.y[:,-1]
        _,_,_,_,_,shear,slip,_,_,_,_=self.driver.local(state)
        moments=np.zeros((2,self.photon-1))
        moments[:,0]=[shear,shear/4]
        return np.r_[state[:-1],slip,moments.flatten()]

    def outputs(self,state):
        core=state[:self.count]
        out=self.base.output(core)[0]
        entropy,slip=state[self.count:self.count+2]
        intens,pol=state[self.count+2:].reshape(2,-1)
        hubble,_,cons,_,_,vg,vb,length,geometry,_,_,geo_dot,vg_dot=self.quantities(state)
        physical=32/45*length*((geometry+vg)*(1-11/3*hubble*length)-11/6*length*(geo_dot+vg_dot))
        aval=out['a']
        inertia=.75*self.base.matter*core[0]*self.base.baryon/(1-self.base.radiation)
        native_state=np.r_[core,entropy,slip*(1+inertia)**2/length]
        archive=self.archive.local(native_state)[5]
        out.update(delta_baryon=out['delta_baryon']+entropy,v_photon=4/3*vg,v_baryon_cdm=vb,slip=slip,pi_photon=intens[0],
            E_2=pol[0],local_physical=physical,local_archive=archive,leading=32/45*length*(geometry+vg))
        return out,abs(core[2]/cons-1)

    def run(self,method,form,initial,cap,rtol):
        self.archive=Pair.__new__(Pair)
        self.archive.base=self.base
        self.archive.gas=self.driver.gas
        self.archive.closure='archive'
        times=5*self.base.inputs['times']
        sol=solve_ivp(lambda x,state:self.rhs(x,state,form),(times[0],times[-1]),initial,t_eval=times,
            method=method,rtol=rtol,atol=1e-17,max_step=cap)
        need(sol.success and np.isfinite(sol.y).all(),'coupled collision history complete')
        rows=[self.outputs(state) for state in sol.y.T]
        need(max(pair[1] for pair in rows)<TOL,'propagated Einstein constraint')
        return list(rows[0][0]),np.array([list(pair[0].values()) for pair in rows]),sol.y.T,sol.nfev


def freeze(case):
    cfg=target(case)
    out={}
    for nu,phot,method,form,cap,rtol in ((34,4,'BDF','trace',.09,3e-10),(48,7,'Radau','constraint',.06,2e-10)):
        model=Collision(cfg,nu,phot)
        prepared=model.start(form,cap)
        for name in (('base',) if form=='trace' else ('base','erased')):
            initial=prepared.copy()
            if name=='erased':
                initial[model.count+1:]=0.
            keys,rows,states,calls=model.run(method,form,initial,cap,rtol)
            label=method+'_'+name
            out[label]=rows
            out[label+'_calls']=calls
            out[label+'_states']=states
            print(case,label,calls,flush=True)
    with (ROOT/(case+'-kinetic-prediction.npz')).open('xb') as file:
        np.savez_compressed(file,**out,names=keys,times=cfg['times'],code=digest(Path(__file__)),method=digest(ROOT/'KINETIC.md'),reference=digest(cfg['ref']),
            previous=digest(ROOT/(case+'-slip-prediction.npz')),state_layout='EarlySystem material and neutrino moments then canonical fields, D,S, F2..Fmax, E2..Emax; x=k*tau, k=5')


def run_score(case):
    cfg=target(case)
    path=ROOT/(case+'-kinetic-prediction.npz')
    with np.load(path) as file,np.load(cfg['ref']) as data:
        need(str(file['code'])==digest(Path(__file__)) and str(file['method'])==digest(ROOT/'KINETIC.md') and str(file['reference'])==digest(cfg['ref']),'forecast intact')
        times=file['times']
        need(np.array_equal(times,cfg['times']),'exact archive times')
        names=file['names'].tolist()
        base=file['Radau_base']
        ref=data['values'][np.flatnonzero(data['modes']==5)[0],326:326+len(times)]
        native=data['names'].tolist()
        actual=np.column_stack([ref[:,native.index(key)] if key in native else ref[:,native.index('v_baryon_cdm')]-.75*ref[:,native.index('v_photon')] if key=='slip' else base[:,names.index('pi_photon')] for key in names])
        refine=abs(base-file['BDF_base'])
        erase=abs(base-file['Radau_erased'])
        error=base-actual
        delta_norm=abs(error)+refine+erase
        shearcol=names.index('pi_photon')
        for key in ('local_physical','local_archive','leading'):
            idx=names.index(key)
            delta_norm[:,idx]=abs(error[:,idx])+abs((base-file['BDF_base'])[:,idx]-(base-file['BDF_base'])[:,shearcol])+abs((base-file['Radau_erased'])[:,idx]-(base-file['Radau_erased'])[:,shearcol])
        budget=np.full_like(base,np.inf)
        np.divide(delta_norm,abs(actual),out=budget,where=actual!=0)
        results={}
        for label,select in [('after_initial',slice(1,None)),('unseen',slice(384-326,None))]:
            channels={}
            for idx,key in enumerate(names):
                targetvals=actual[select,idx]
                amplitude=max(abs(targetvals))
                channels[key]=dict(passed=int(sum(budget[select,idx]<=TOL)),error_over_peak=max(abs(error[select,idx]))/amplitude,
                    solver_over_peak=max(refine[select,idx])/amplitude,erased_seed_over_peak=max(erase[select,idx])/amplitude)
            results[label]=dict(count=len(base[select]),channels=channels)
        vb=ref[:,native.index('v_baryon_cdm')].astype(np.float32)
        need(np.array_equal(vb,ref[:,native.index('v_baryon_cdm')]),'float32 reference')
        lo=(np.nextafter(vb,np.float32(-np.inf)).astype(float)-vb)/2
        hi=(np.nextafter(vb,np.float32(np.inf)).astype(float)-vb)/2
        slipcol=names.index('slip')
        word_fit=(error[:,slipcol]>=lo)&(error[:,slipcol]<=hi)
        pol_identity=ref[:,native.index('E_2')]==ref[:,native.index('pi_photon')]/4
        save(ROOT/(case+'-kinetic-score.json'),dict(prediction=digest(path),reference=str(cfg['ref']),tolerance=TOL,measured=results,
            switch_x=5*times[0],last_x=5*times[-1],slip_compatible_after_switch=int(sum(word_fit[1:])),archive_polarization_exact_quarter=int(sum(pol_identity)),
            convention='for local_* and leading the target is the evolved dynamical quadrupole, not the archive'))
        with (ROOT/(case+'-kinetic-differences.npz')).open('xb') as fp:
            np.savez_compressed(fp,names=names,times=times,signed=error,refinement=refine,erased_initial=erase,passed=budget<=TOL,compatible=word_fit,archive_exact_quarter=pol_identity)
        for key in ('pi_photon','local_physical','local_archive','leading','slip','E_2','mts_dp_s'):
            print(case,key,results['after_initial']['channels'][key],flush=True)


if __name__=='__main__':
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    inverse=(Fraction(4,3),Fraction(2))
    leading=inverse[0]*Fraction(8,15)
    need(leading==Fraction(32,45) and inverse[0]+inverse[1]/4==Fraction(11,6),'polarization relaxation coefficients')
    if sys.argv[1]=='freeze':
        for name in ('cold','heavy'):
            freeze(name)
    elif sys.argv[1]=='score':
        need(all((ROOT/(name+'-kinetic-prediction.npz')).exists() for name in ('cold','heavy')),'both forecasts saved')
        for name in ('cold','heavy'):
            run_score(name)
