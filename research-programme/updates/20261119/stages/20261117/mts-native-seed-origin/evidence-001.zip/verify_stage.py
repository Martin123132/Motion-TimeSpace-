from datetime import datetime,timezone
from pathlib import Path
import sys
from mode_check import ROOT, PRIOR, TOL, algebra, digest, need, np, read, save
from kinetic import target


def verify_case(case,mode):
    config=target(case)
    refpath=config['ref']
    for path,value in mode['physical'][case]['seed_inputs'].items():
        need(digest(Path(path))==value,'seed source: '+path)
    for path,value in read(ROOT/(case+'-plasma-inputs.json'))['files'].items():
        need(digest(Path(path))==value,'plasma source: '+path)
    first=read(ROOT/(case+'-first-eight-prediction.json'))
    need(first['thermal']['inferred_factor']==.5 or abs(first['thermal']['inferred_factor']-.5)<1e-12,'saved thermal origin')
    need(digest(Path(first['thermal']['archive']))==first['thermal']['hash'] and first['reference_sha']==digest(refpath),'runtime inputs')
    need(first['code']==digest(ROOT/'first_output.py') and first['method']==digest(ROOT/'FIRST-OUTPUT.md'),'early authority')
    with np.load(refpath) as archive:
        native=archive['names'].tolist()
        selected=int(np.flatnonzero(archive['modes']==5)[0])
        actual=archive['values'][selected,:408]
        alltimes=archive['conformal_time'][:408]
    early=read(ROOT/(case+'-first-eight-score.json'))
    for kind,summary in early['reports'].items():
        for key,info in summary.items():
            nativecol=actual[:8,native.index(key)]
            primary=np.array([row[key] for row in first['curves'][kind+'-constraint']['rows']])
            control=np.array([row[key] for row in first['curves'][kind+'-trace']['rows']])
            budget=(abs(primary-control)+abs(primary-nativecol))/abs(nativecol)
            need(max(budget)==info['max_budget'] and int(sum(budget<=TOL))==info['passes']==8,'every first output: '+key)
    stages={}
    for checkpoint,method,impl,rows,offset in [('horizon','HORIZON.md','horizon.py',327,0),('plasma','TRANSPORT.md','transport.py',327,0),
            ('slip','SLIP.md','slip_bridge.py',384,0),('kinetic','KINETIC.md','kinetic.py',82,326)]:
        path=ROOT/(case+'-'+checkpoint+'-prediction.npz')
        summary=read(ROOT/(case+'-'+checkpoint+'-score.json'))
        with np.load(path) as archive:
            need(len(archive['times'])==rows and np.array_equal(archive['times'],alltimes[offset:offset+rows]),'exact original epochs')
            need(str(archive['method'])==digest(ROOT/method) and str(archive['code'])==digest(ROOT/impl),'matching process: '+checkpoint)
            names=archive['names'].tolist()
            variants={'horizon':[('constraint','trace','')],'plasma':[('constraint1','trace1','-1'),('constraint2','trace2','-2')],
                'slip':[(v+'_constraint',v+'_trace','-'+v) for v in ('physical','archive')],'kinetic':[('Radau_base','BDF_base','')]}[checkpoint]
            for primary,control,suffix in variants:
                pred=archive[primary]
                ref=actual[offset:offset+rows]
                residual=np.column_stack([ref[:,native.index(key)] if key in native else ref[:,native.index('v_baryon_cdm')]-.75*ref[:,native.index('v_photon')]
                    if key=='slip' else pred[:,names.index('pi_photon')] for key in names])
                signed=pred-residual
                refinement=pred-archive[control]
                total=abs(signed)+abs(refinement)
                if checkpoint=='kinetic':
                    erased=pred-archive['Radau_erased']
                    total+=abs(erased)
                    shear=names.index('pi_photon')
                    for key in ('local_physical','local_archive','leading'):
                        col=names.index(key)
                        total[:,col]=abs(signed[:,col])+abs(refinement[:,col]-refinement[:,shear])+abs(erased[:,col]-erased[:,shear])
                    need(np.isfinite(archive['Radau_base_states']).all() and len(archive['Radau_base_states'])==rows,'full physical restart')
                passed=(residual!=0)&(total<=TOL*abs(residual))
                with np.load(ROOT/(case+'-'+checkpoint+'-differences'+suffix+'.npz')) as errors:
                    need(np.array_equal(errors['passed'],passed),'independent gate: '+checkpoint+suffix)
                    key='signed_prediction_minus_saved' if checkpoint=='horizon' else 'signed'
                    need(np.array_equal(errors[key],signed),'all signed predictions: '+checkpoint+suffix)
                stages[checkpoint+suffix]=dict(epochs=rows,channels=len(names),passes=int(passed.sum()),total=passed.size)
    return stages


def main():
    need(not (ROOT/'__pycache__').exists(),'no task bytecode cache')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    priorhash='cd942033f8f6551f292b44717563c497b554c48d592701000da7e236db3e55de'
    previous=PRIOR/'closeout.json'
    need(digest(previous)==priorhash,'previous seal unchanged')
    retained=read(previous)['files']
    for name,record in retained.items():
        path=PRIOR/name
        need(path.stat().st_size==record['bytes'] and digest(path)==record['sha256'],'sealed previous artifact')
    mode=read(ROOT/'mode-result.json')
    algebra()
    need(mode['method']==digest(ROOT/'GRADIENT.md') and mode['code']==digest(ROOT/'mode_check.py'),'derived seed')
    for path,value in mode['origin']['hashes'].items():
        need(digest(Path(path))==value,'physical mode anchor: '+path)
    reports={case:verify_case(case,mode) for case in ('cold','heavy')}
    energy=read(ROOT/'exchange-score.json')
    need(energy['code']==digest(ROOT/'exchange.py') and energy['method']==digest(ROOT/'EXCHANGE.md'),'work source')
    for case,runs in energy['runs'].items():
        need(energy['kinetic_sources'][case]==digest(ROOT/(case+'-kinetic-prediction.npz')),'restart authority')
        for row in runs.values():
            need(row['heat']>0 and np.isclose(row['endpoints'][1]-row['endpoints'][0],row['storage'],rtol=1e-13,atol=0),'storage/flux reference')
            need(row['balance_error_over_storage']<TOL and row['separate_storage_error']<TOL,'energy closure on storage scale')
    angular=read(ROOT/'angular-score.json')
    dense=read(ROOT/'dense-power.json')
    for record,method,code in [(angular,'ANGULAR-WORK.md','angular_work.py'),(dense,'DENSE.md','dense_power.py')]:
        need(record['method']==digest(ROOT/method) and record['code']==digest(ROOT/code) and record['common_x']==energy['common_x'],'common exposure and method')
    for case in ('cold','heavy'):
        path=ROOT/(case+'-kinetic-prediction.npz')
        need(angular['source_hashes'][case]==dense['sources'][case]==digest(path),'same coupled restart')
        with np.load(ROOT/(case+'-angular-sources.npz')) as packet:
            for label in ('BDF_base','Radau_base','Radau_erased'):
                data=packet[label]
                source,quad,high,drag,_,slope=data.T
                need(min(quad)>=0 and min(high)>=0 and min(drag)>=0,'positive independently split terms')
                need(max(abs(source-quad-high-slope)/(abs(source)+quad+high))<2e-14,'pointwise whole-hierarchy identity')
                direct=dense['runs'][case][label+'-8']
                need(direct['closure_over_storage']<TOL and direct['storage_derivative_error']<TOL,'angular closure at storage scale')
                need(abs(direct['dipole']/energy['runs'][case][label]['heat']-1)<TOL,'two independent heat integrations')
    for key in ('angular','dipole','stored','supply','higher'):
        cold=dense['runs']['cold']['Radau_base-8'][key]
        heavy=dense['runs']['heavy']['Radau_base-8'][key]
        need(heavy-cold==dense['summary'][key]['paired_difference'],'signed paired magnitude')
        need(abs(sum(dense['summary'][key]['difference_budget_breakdown'].values())-dense['summary'][key]['difference_budget'])<1e-12,'conservative difference budget')
    origin=read(ROOT/'origin-budget.json')
    need(origin['method']==digest(ROOT/'ORIGIN-TRANSPORT.md') and origin['code']==digest(ROOT/'origin_transport.py'),'initial-to-final integral authority')
    branch_runs={}
    for case in ('cold','heavy'):
        score=read(ROOT/(case+'-origin-score.json'))
        need(score['code']==digest(ROOT/'origin_score.py') and score['tolerance']==TOL,'origin score authority')
        branch_runs[case]={}
        for label,value in score['sources'].items():
            path=ROOT/(case+'-origin-'+label+'.npz')
            need(digest(path)==value,'full restart hash')
            with np.load(path) as data:
                need(np.isfinite(data['states']).all() and len(data['times'])==len(data['states'])==408,'finite 408-epoch restart')
                need(abs(data['x_init']-(.00025 if label=='half' else .0005))<1e-14,'actual vs diagnostic start')
            integrals=read(ROOT/(case+'-origin-'+label+'.json'))
            need(integrals['common_x']==energy['common_x'],'same physical time interval in all branches')
            branch_runs[case][label]=integrals['quadratures']
            need(branch_runs[case][label]['8']['balance_error_over_storage']<TOL,'origin angular-source balance on net storage scale')
        with np.load(ROOT/(case+'-origin-differences.npz')) as data,np.load(Path(score['reference'])) as source:
            names=data['names'].tolist()
            values=source['values'][int(np.flatnonzero(source['modes']==5)[0]),:408][:,[source['names'].tolist().index(key) for key in names]]
            expected=abs(data['signed'])+data['numerical']<=TOL*abs(values)
            need(np.array_equal(expected,data['passed']),'all final per-channel gates')
            for idx,key in enumerate(names):
                need(int(sum(expected[:,idx]))==score['channels'][key]['passed'],'all final counts: '+key)
                if key.startswith('mts_dp_'):
                    need(expected[:,idx].all(),'signed pressure of each active field')
    for key,item in origin['summary'].items():
        abs_error=0.
        for case,values in branch_runs.items():
            reference=values['physical']['8'][key]
            for label,degree in [('physical','4'),('half','8'),('native','8'),('BDF','8')]:
                abs_error+=abs(values[label][degree][key]-reference)
        delta=branch_runs['heavy']['physical']['8'][key]-branch_runs['cold']['physical']['8'][key]
        need(np.isclose(abs_error/abs(delta),item['paired_budget'],rtol=1e-12,atol=0) and delta==item['absolute_contrast'],'origin contrast budget')
        if key in ('dipole','angular'):
            need(item['paired_budget']<TOL<dense['summary'][key]['difference_budget'],'old failed control and physical-origin improvement')
    save(ROOT/'verification.json',dict(earlier_seal=priorhash,previous_files_rehashed=len(retained),tolerance=TOL,epochs_and_signed_channel_checks=reports,
        error_budgets=energy['budgets'],angular_budgets=dense['summary'],actual_origin=origin['summary'],source='direct reload of archived numerical transfer and all paired forecast packets; failures retained'))


if __name__=='__main__':
    if sys.argv[1]=='verify':
        main()
    elif sys.argv[1]=='seal':
        need((ROOT/'verification.json').is_file() and (ROOT/'RESULTS.md').is_file(),'verification and result required')
        paths=sorted(path for path in ROOT.iterdir() if path.is_file() and path.name!='closeout.json')
        save(ROOT/'closeout.json',dict(time=datetime.now(timezone.utc).isoformat(),files={path.name:dict(bytes=path.stat().st_size,sha256=digest(path)) for path in paths}))
