import ast
import hashlib
import json
import math
import os
import sys
from fractions import Fraction
from pathlib import Path

for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[variable]='1'
import numpy as np
from scipy.integrate import solve_ivp

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PRIOR=POST/'mts-field-shooting-20261117'
METRIC=POST/'mts-coupled-metric-consistency-20261117'
COMMON=POST/'condensate-origin-20261003'
COLD=COMMON/'native-two-field-transfer-20261007/runs/final-bg8-start'
HEAVY=COMMON/'resolved-matter-spectrum-20261007/runs/exact-grid'
FACTORY=COMMON/'native-heavy-matching-20261007/matching_common.py'
TOL=2e-5
NORMAL=.25


def need(condition,message):
    if not condition:
        raise ValueError(message)


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path,data):
    with path.open('x',encoding='utf-8') as stream:
        json.dump(data,stream,indent=2,allow_nan=False,default=lambda value:value.item())
        stream.write('\n')


def check_origin():
    prior=read(PRIOR/'closeout.json')['files']
    need(digest(PRIOR/'REGULAR-SEED.md')==prior['REGULAR-SEED.md']['sha256'],'retained seed derivation')
    run=read(HEAVY/'status.json')
    factory_hash=run['input_hashes'][str(FACTORY)]
    need(run['state']=='complete' and factory_hash==digest(FACTORY),'matching factory in completed heavy grid')
    reference=HEAVY/'chunk-0384.npz'
    need(run['input_hashes'][str(reference)]==digest(reference),'actual heavy reference chunk')
    baseline=read(COLD/'status.json')
    factory=next(fn for fn in ast.parse(FACTORY.read_text()).body if isinstance(fn,ast.FunctionDef) and fn.name=='params_for')
    defaults=dict(zip([arg.arg for arg in factory.args.args][-len(factory.args.defaults):],map(ast.literal_eval,factory.args.defaults)))
    factor=defaults['start_factor']
    need(factor==baseline['initial_time_factor']==.5 and baseline['seed_scale']==1,'original baseline receipt and heavy factory')
    capture=POST/'mts-coupled-preparation-response-20261116/native_context.py'
    adapter=POST/'mts-coupled-phase-interval-20261117/restart_bridge.py'
    native=METRIC/'native/fortran'
    for path,fragments in [(capture,['EX.MATCHING / "matching_common.py"','namespace["params_for"](EX.EARLY / "runs/backgrounds" / (case + ".npz"))','native = camb.get_background(parameters)','final-bg8-start/cold.npz','exact-grid/chunk-0384.npz']),
                          (FACTORY,['model.initial_time_factor = start_factor']),(adapter,['context_source.replace(original, replacement)']),
                          (native/'camb_python.f90',['GetTauStart(min(500._dl,EV%q))','taustart = taustart*dark%initial_time_factor','call initial(EV,y, taustart)']),
                          (native/'cmbmain.f90',['taustart=0.001_dl/q','taustart=min(taustart,0.1_dl)']),
                          (native/'equations.f90',['call dark%SeedFromCold','InitVec = -InitVec','initv(1,i_clxc)=initv(1,i_clxb)']),
                          (native/'MTSTwoField.f90',['seed_scale = 1._dl','exp(3*(loga-first))'])]:
        source=path.read_text()
        need(all(part in source for part in fragments),'source path mismatch: '+str(path))
    dll=METRIC/'native/camb/cambdll.dll'
    captured={case:read(PRIOR/(case+'-physical-roots-capture.json')) for case in ('cold','heavy')}
    need(all(record['native_dll_sha256']==digest(dll) for record in captured.values()),'binary pinned by both native capture receipts')
    paths=[HEAVY/'status.json',COLD/'status.json',FACTORY,capture,adapter,dll,native/'equations.f90',native/'cmbmain.f90',native/'camb_python.f90',native/'MTSTwoField.f90']
    return dict(factor=factor,hashes={str(path):digest(path) for path in paths},direct_initial_callback_saved=False,
                evidence='completed baseline settings; heavy run-pinned factory and matching capture source; exact first call reconstructed, not replayed')


def coefficients(fraction):
    velocity=(15+12*fraction)/(9*(15+4*fraction))
    shear=-8/(3*(15+4*fraction))
    density=-(5+4*fraction)/(36*(15+4*fraction))
    scalar=(84*density-1)/72
    return velocity,shear,density,scalar


def algebra():
    for radiation in map(Fraction,('0','7/17','1')):
        mean,stress,density,scalar=coefficients(radiation)
        photon=Fraction(1,9)
        neutrino=(Fraction(1,3)-stress)/3
        need(mean==(1-radiation)*photon+radiation*neutrino and 2*stress==-Fraction(8,15)+8*mean/5,'Euler, shear and momentum constraint')
        need(16*density==4*density-mean and 4*density==-mean-Fraction(3,2)*(4*density/3-mean/3),'trace and Hamiltonian constraint')
        need(72*scalar+1==84*density,'forced wave coefficient')


def hierarchy(fraction,baryon,matter,mass_parameter,points,start,cap,last_moment):
    velocity,shear,_,_=coefficients(fraction)
    moments=[2*shear*NORMAL]
    for ell in range(3,last_moment+1):
        moments.append(moments[-1]/(2*ell+1))
    seed=[NORMAL,4*NORMAL/3,4*NORMAL/3,NORMAL/9,NORMAL*(1/3-shear)/3,NORMAL*shear,NORMAL*velocity,
          -1/20,-1/5,-NORMAL/105,-6*NORMAL/105,*moments[1:]]
    def rhs(logx,state):
        x=math.exp(logx)
        square=x*x
        cdm,light,nu,flow_light,flow_nu,stress,metric,field_shift,field_speed,pert,speed=state[:11]
        correction=matter*x/4
        scale=1+correction
        expansion=(1+2*correction)/scale
        ratio=4*correction*scale
        inertia=3*baryon*ratio/(4*(1-fraction)) if fraction!=1 else 0.
        density=((1-fraction)*light+fraction*nu+ratio*((1-baryon)*cdm+.75*baryon*light))/(1+ratio)
        momentum=(4*((1-fraction)*flow_light+fraction*flow_nu)/3+ratio*baryon*flow_light)/(1+ratio)
        cprime=-(-4*NORMAL+square*metric)/expansion-1.5*expansion*density
        etaprime=1.5*expansion**2*momentum
        response=[cprime-2*cdm,4*(cprime-square*flow_light)/3-2*light,4*(cprime-square*flow_nu)/3-2*nu,
            (light/4-expansion*inertia*flow_light)/(1+inertia)-3*flow_light,nu/4-stress-3*flow_nu,
            4*square*flow_nu/15-3*square*state[11]/10-4*cprime/15+4*etaprime/5-2*stress,etaprime-2*metric,
            field_speed-4*field_shift,-(3+2*expansion)*field_speed-scale**2*(1+mass_parameter*square**2*field_shift),
            speed-6*pert,cprime*field_speed-(5+2*expansion)*speed-square*(1+mass_parameter*square*scale**2)*pert]
        for ell in range(3,last_moment+1):
            offset=11+ell-3
            below=2*stress if ell==3 else state[offset-1]
            above=0. if ell==last_moment else state[offset+1]
            response.append((ell*below-(ell+1)*square*above)/(2*ell+1)-ell*state[offset])
        return response
    logpoints=np.log(points)
    sol=solve_ivp(rhs,(math.log(start),logpoints[-1]),seed,method='DOP853',t_eval=logpoints,
                  rtol=3e-13,atol=1e-16,max_step=cap)
    need(sol.success and np.isfinite(sol.y).all(),'independent Hamiltonian evolution')
    return sol.y.T


def coefficient_test(fraction):
    _,_,density,scalar=coefficients(fraction)
    truth=np.array([density,scalar,4*scalar/3])
    nodes=np.array([.015,.03,.06])
    outputs=[]
    for start,cap,order in [(1e-7,.22,5),(1e-9,.11,8)]:
        rows=hierarchy(fraction,0.,0.,0.,nodes,start,cap,order)
        scaled=rows[:,[0,9,10]]/np.array([NORMAL,-NORMAL/105,-6*NORMAL/105])
        measured=(scaled-1)/nodes[:,None]**2
        extrap=(4*measured[:-1]-measured[1:])/3
        outputs.append(extrap)
    budget=(abs(outputs[1][0]-truth)+abs(outputs[1][0]-outputs[1][1])+abs(outputs[1][0]-outputs[0][0]))/abs(truth)
    need(max(budget)<TOL,'gradient coefficient, not just leading mode')
    return dict(fraction=fraction,predicted=truth.tolist(),recovered=outputs[1][0].tolist(),relative_budgets=budget.tolist())


def branch(case,factor):
    prepared=POST/'mts-matched-clock-precision-20261117'/(case+'-prepared.npz')
    table=COMMON/'native-two-field-transfer-20261007/runs/backgrounds'/(case+'.npz')
    ref=(COLD/'cold.npz') if case=='cold' else HEAVY/'chunk-0384.npz'
    with np.load(ref) as archive:
        need(np.count_nonzero(archive['modes']==5)==1,'retained wavenumber in reference')
        first_reference_time=float(np.min(archive['conformal_time']))
    with np.load(PRIOR/(case+'-physical-roots-capture.npz')) as archive:
        first_capture=float(archive['clock'][0])
    with np.load(prepared) as archive:
        const=archive['constants']
    with np.load(table) as archive:
        first=archive['scale'][0]
        fields=[(name,archive['phi_'+name][0],archive['phidot_'+name][0]) for name in (('s',) if case=='cold' else ('s','h'))]
    nu=sum(const[14:14+int(const[4])])+const[3]
    rad=nu+const[2]
    fraction=nu/rad
    alpha=math.sqrt(rad/3)
    omega=sum(const[:2])/(3*alpha)
    baryon=const[1]/sum(const[:2])
    k=5.
    tau=factor*min(.001/k,.1,.001/(max(const[8:8+int(const[4])])*alpha))
    need(first_reference_time>tau and first_capture>tau,'late reference distinct from native start')
    start_scale=alpha*tau*(1+omega*tau/4)
    table_time=2*first/alpha/(1+math.sqrt(1+omega*first/alpha))
    x=k*tau
    nodes=np.array([x,k*table_time])
    _,_,density,scalar=coefficients(fraction)
    factor_cdm=1-omega*tau/5
    native_phi=-NORMAL/105*(1+omega*tau/4)**2*factor_cdm
    native=np.array([NORMAL*factor_cdm,native_phi,6*native_phi])
    forecast=np.array([density*x*x/factor_cdm,-23*omega*tau/70+scalar*x*x,-omega*tau/3+4*scalar*x*x/3])
    checks={}
    for index,(name,field,word) in enumerate(fields):
        mass=const[6+index]
        mass_parameter=(mass*alpha/k**2)**2
        trials=[]
        for start,cap,order in [(1e-8,.20,5),(1e-10,.10,8)]:
            values=hierarchy(fraction,baryon,omega/k,mass_parameter,nodes,start,cap,order)
            trials.append(values)
        fine=trials[1]
        comparison=[arr[0,[0,9,10]]/native-1 for arr in trials]
        budget=(abs(comparison[1]-forecast)+abs(comparison[0]-comparison[1]))/abs(forecast)
        need(max(budget)<TOL,'material density and scalar seed corrections on their own scales: '+str(budget))
        physical_initial=field/(1+mass_parameter*nodes[-1]**4*fine[-1,7])
        velocity=physical_initial*k*mass_parameter*nodes**3*fine[:,8]
        native_velocity=word*(start_scale/first)**3
        checks[name]=dict(predicted_over_native_minus_one=forecast.tolist(),resolved_over_native_minus_one=comparison[1].tolist(),
                 fractional_budget_on_correction=budget.tolist(),regular_background_velocity=velocity.tolist(),
                 archive_background_velocity=[native_velocity,word],regular_vs_archive_velocity=(velocity/[native_velocity,word]-1).tolist(),
                 field_seed=float(physical_initial*mass_parameter*x**6*fine[0,9]),velocity_seed=float(physical_initial*k*mass_parameter*x**5*fine[0,10]),
                 homogeneous_field_at_first_word_assumption='regular mode normalized to stored first field position only')
    return dict(tau=tau,scale=start_scale,first_table_scale=first,table_age=table_time,first_capture=first_capture,first_reference_output=first_reference_time,
                neutrino_fraction=fraction,omega_tau=omega*tau,k_tau_squared=x*x,scalar_gradient=scalar,cdm_gradient=density,
                fields=checks,seed_inputs={str(path):digest(path) for path in (ref,table,prepared)})


def main():
    for folder in (ROOT,POST,COMMON,POST/'mts-carried-defect-budget-20261117'):
        need(not (folder/'STOP-REQUESTED').exists(),'owner hold')
    frozen=digest(ROOT/'GRADIENT.md')
    origin=check_origin()
    algebra()
    physical={case:branch(case,origin['factor']) for case in ('cold','heavy')}
    controls=[coefficient_test(value) for value in (0.,physical['cold']['neutrino_fraction'],1.)]
    save(ROOT/'mode-result.json',dict(method=frozen,code=digest(Path(__file__)),origin=origin,physical=physical,gradient_controls=controls,tolerance=TOL))
    for case,row in physical.items():
        print(case,row['tau'],row['scale'],row['neutrino_fraction'],row['cdm_gradient'],row['scalar_gradient'],row['fields']['s'])


if __name__=='__main__':
    main()
