from pathlib import Path
from kinetic import Collision, ROOT, TOL, digest, need, np, save, target
from slip_bridge import Pair
from mode_check import read


def report(case):
    config=target(case)
    result={}
    paths={}
    for label in ('physical','BDF','half','native'):
        path=ROOT/(case+'-origin-'+label+'.npz')
        paths[label]=digest(path)
        with np.load(path) as packet:
            times=packet['times']
            need(len(times)==408 and str(packet['code'])==digest(ROOT/'origin_transport.py') and str(packet['original'])==digest(config['ref']),'complete source to endpoint')
            local=dict(config)
            local['start']=float(packet['x_init'])/5
            model=Collision(local,int(packet['nu']),int(packet['photons']))
            model.archive=Pair.__new__(Pair)
            model.archive.base=model.base
            model.archive.gas=model.driver.gas
            model.archive.closure='archive'
            output=[model.outputs(state) for state in packet['states']]
            keys=list(output[0][0])
            results=np.array([list(row[0].values()) for row in output])
            need(np.isfinite(results).all() and max(row[1] for row in output)<TOL,'trace/Hamiltonian at all original epochs')
            result[label]=results
    with np.load(config['ref']) as original:
        mode=int(np.flatnonzero(original['modes']==5)[0])
        values=original['values'][mode,:len(times)]
        native=original['names'].tolist()
        need(np.array_equal(original['conformal_time'][:len(times)],times),'original times')
    central=result['physical']
    indices={key:keys.index(key) for key in keys if key in native}
    raw=values[:,[native.index(key) for key in indices]]
    main=central[:,list(indices.values())]
    numerical=sum(abs(item[:,list(indices.values())]-main) for key,item in result.items() if key!='physical')
    passed=(abs(raw-main)+numerical)<=TOL*abs(raw)
    channels={key:dict(passed=int(sum(passed[:,col])),epochs=len(times),error_over_peak=max(abs(raw[:,col]-main[:,col]))/max(abs(raw[:,col])),
        budget_over_peak=max(numerical[:,col])/max(abs(raw[:,col])),passes_last_24=int(sum(passed[-24:,col]))) for col,key in enumerate(indices)}
    old_path=ROOT/(case+'-kinetic-prediction.npz')
    with np.load(old_path) as old:
        past=old['Radau_base']
        old_keys=old['names'].tolist()
        comparison={key:max(abs(main[327:,col]-past[1:,old_keys.index(key)]))/max(abs(main[327:,col])) for col,key in enumerate(indices)}
    with (ROOT/(case+'-origin-differences.npz')).open('xb') as file:
        np.savez_compressed(file,names=list(indices),times=times,signed=main-raw,numerical=numerical,passed=passed,physical_readout=central,physical_names=keys)
    save(ROOT/(case+'-origin-score.json'),dict(code=digest(Path(__file__)),sources=paths,reference=str(config['ref']),tolerance=TOL,channels=channels,
        late_switch_max_change_over_peak=comparison))
    print(case,'pressure',[(key,row) for key,row in channels.items() if key.startswith('mts_dp_')],flush=True)


if __name__=='__main__':
    need((ROOT/'origin-budget.json').is_file(),'all forecasts recorded')
    for name in ('cold','heavy'):
        report(name)
