from restart_support import *
import importlib.metadata


if __name__ == '__main__':
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    mapping = read(ROOT/'inputs.json')
    check_inputs(mapping)
    verification = read(ROOT/'verification.json')
    require(verification['passed'],'technical verification passed')
    science = read(ROOT/'science-score.json')
    expected = {'prepare','cold-preflight','heavy-preflight','cold-32','cold-64','heavy-32','heavy-64','score','verify'}
    workers = {path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    require(set(workers) == {label+'-start.json' for label in expected},'complete exact worker inventory')
    require(all(value['exited'] for value in workers.values()),'all original task processes exited')
    for label in expected:
        start,end = read(ROOT/(label+'-start.json')),read(ROOT/(label+'-end.json'))
        require(end['completed'] and all(start[key] == end[key] for key in ('pid','created','command')),'identity-matched completion')
    releases = {path.name:read(path) for path in ROOT.glob('*-owner-release.json')}
    require(len(releases) == 7 and all(value['cleared'] for value in releases.values()),'all native owners released')
    require(not list(ROOT.glob('*-failure.json')),'no omitted failed run')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    for name in ('CONTRACT.md','RESULTS.md','NEXT.md'):
        require((ROOT/name).is_file(),'saved handoff: '+name)
    closer = identity(process)
    write(ROOT/'cleanup.json',{'workers':workers,'all_exited':True,'native_owner_releases':releases,'closer_identity':closer,'closer_exit_verification':'required after foreground completion','temporary_tools':[],'other_processes_changed':False,'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','psutil')}})
    artifacts = {str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name != 'closeout.json'}
    result = {'stage':'Carried coupled-error budget and live3041..3042 continuation','utc':datetime.now(timezone.utc).isoformat(),'completed':True,'verification_passed':True,'technical_checks':verification['count'],'continuation_gate_pass':science['continuation_gate_pass'],'last_epoch':3042,'original_failure_preserved':science['original_prior_gate_unchanged'],'new_fitted_parameters':0,'future_source_metric_forcing':False,'certified_continuum_enclosure':False,'frozen_inputs':len(mapping),'workers_exited':len(workers),'native_owners_released':len(releases),'github':False,'artifacts':artifacts}
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),'bytes':sum(value['bytes'] for value in artifacts.values()),'workers_exited':len(workers),'continuation_gate_pass':science['continuation_gate_pass'],'closer':closer}),flush=True)
