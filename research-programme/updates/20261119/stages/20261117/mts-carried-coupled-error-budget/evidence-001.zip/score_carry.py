from run_carry import *
from score_transport import ordinary
NAMES = ('native_velocity','native_weyl','photon_density','relative_density','velocity_slip')


def values(data,branch,family,role):
    if family == 'source':
        return data[role+'_source'][:,0]+(data[role+'_source'][:,1] if branch else 0.)
    return data[role+'_readout'][:,branch]


def physical(data,branch,family,parent=False):
    prefix_name = 'parent_' if parent else ''
    if family == 'source':
        return data[prefix_name+'source']+(data[prefix_name+'source_change'] if branch else 0.)
    return readouts(data[prefix_name+'metric'])[:,branch]


def physical_primitive(data,branch,family,parent=False):
    prefix_name = 'parent_' if parent else ''
    if family == 'source':
        source = abs(physical(data,branch,family,parent))
        density_pressure = source[:,0]+source[:,2]
        return np.stack((density_pressure,source[:,1],density_pressure),axis=-1)
    return primitive_envelope(data[prefix_name+'metric'])[:,branch]


def score():
    cold,cold_low = [load(ROOT/('cold-'+str(steps)+'.npz')) for steps in (64,32)]
    high,low = [load(ROOT/('heavy-'+str(steps)+'.npz')) for steps in (64,32)]
    cold_report = ordinary(cold,cold_low,'cold')
    parent_report = ordinary(high,low,'heavy','parent_')
    approximate_report = ordinary(high,low,'heavy')
    norms = read(ROOT/'frozen-norms.json')['heavy']
    signed,centers,cross,split,envelopes,subtraction = {},{},{},{},{},{}
    for branch,branch_name in enumerate(('old','coherent')):
        for family in ('source','readout'):
            names,units = (('density','current','pressure'),norms['source_norm']) if family == 'source' else (NAMES,norms['readout_norm'])
            error,error_low = values(high,branch,family,'error'),values(low,branch,family,'error')
            carry,carry_low = values(high,branch,family,'carry'),values(low,branch,family,'carry')
            fresh,fresh_low = values(high,branch,family,'fresh'),values(low,branch,family,'fresh')
            parent,parent_low = physical(high,branch,family,True),physical(low,branch,family,True)
            approximate,approximate_low = physical(high,branch,family),physical(low,branch,family)
            error_primitives = high['error_'+family+'_primitive'][:,branch]
            component_primitives = high['carry_'+family+'_primitive'][:,branch]+high['fresh_'+family+'_primitive'][:,branch]
            physical_primitives = physical_primitive(high,branch,family)+physical_primitive(high,branch,family,True)
            if family == 'source':
                probes = high['probe_source']+(high['probe_source_change'] if branch else 0.)
                probes_low = low['probe_source']+(low['probe_source_change'] if branch else 0.)
                absolute = abs(probes)
                density_pressure = absolute[...,0]+absolute[...,2]
                probe_primitives = np.stack((density_pressure,absolute[...,1],density_pressure),axis=-1)
            else:
                probes = readouts(high['probe_metric'])[...,branch,:]
                probes_low = readouts(low['probe_metric'])[...,branch,:]
                probe_primitives = primitive_envelope(high['probe_metric'])[...,branch,:]
            scales = np.array(CONFIG['amplifications'])[None,:,None]
            measured = (probes[:,:,0]-probes[:,:,1])/(2*scales)
            measured_low = (probes_low[:,:,0]-probes_low[:,:,1])/(2*scales)
            measured_primitives = (probe_primitives[:,:,0]+probe_primitives[:,:,1])/(2*scales)
            for component,quantity in enumerate(names):
                key = branch_name+'_'+quantity
                error_size = maximum(error[:,component])
                for index,amplitude in enumerate(CONFIG['amplifications']):
                    label = key+'_'+str(amplitude)
                    step = maximum(measured[:,index,component]-measured_low[:,index,component])+maximum(error[:,component]-error_low[:,component])
                    signed[label] = conservative(maximum(measured[:,index,component]-error[:,component]),step,error_size,maximum(measured_primitives[:,index,component]+error_primitives[:,component]))
                    center = .5*(probes[:,index,0,component]+probes[:,index,1,component])-parent[:,component]
                    center_low = .5*(probes_low[:,index,0,component]+probes_low[:,index,1,component])-parent_low[:,component]
                    centers[label] = conservative(maximum(center),maximum(center-center_low),units[component],maximum(probe_primitives[:,index,0,component]+probe_primitives[:,index,1,component]+abs(parent[:,component])))
                cross[key] = conservative(maximum(measured[:,0,component]-measured[:,1,component]),maximum(measured[:,0,component]-measured_low[:,0,component])+maximum(measured[:,1,component]-measured_low[:,1,component]),error_size,maximum(measured_primitives[:,0,component]+measured_primitives[:,1,component]))
                split[key] = ratio(maximum(error[:,component]-carry[:,component]-fresh[:,component]),maximum(component_primitives[:,component]+error_primitives[:,component]),CONFIG['algebra_tolerance'])
                triangle = abs(carry[:,component])+abs(fresh[:,component])
                component_step = maximum(carry[:,component]-carry_low[:,component])+maximum(fresh[:,component]-fresh_low[:,component])
                component_rounding = 64*np.finfo(float).eps*maximum(component_primitives[:,component]+error_primitives[:,component])
                physical_step = maximum(approximate[:,component]-approximate_low[:,component])+maximum(parent[:,component]-parent_low[:,component])
                physical_rounding = 64*np.finfo(float).eps*maximum(physical_primitives[:,component])
                validation_allowance = max(signed[key+'_'+str(amplitude)]['error'] for amplitude in CONFIG['amplifications'])
                total = maximum(triangle)+component_step+component_rounding+physical_step+physical_rounding+validation_allowance
                envelope = ratio(total,units[component])
                discrepancy = approximate[:,component]-parent[:,component]
                envelope.update(triangle_amplitude=maximum(triangle),signed_error_amplitude=error_size,carry_amplitude=maximum(carry[:,component]),fresh_amplitude=maximum(fresh[:,component]),final_carry=float(carry[-1,component]),final_fresh=float(fresh[-1,component]),final_signed_error=float(error[-1,component]),component_step=component_step,component_rounding=component_rounding,physical_step=physical_step,physical_rounding=physical_rounding,validation_allowance=validation_allowance,observed_discrepancy=maximum(discrepancy),observed_covered=bool(maximum(discrepancy)<=total),triangle_to_signed_ratio=maximum(triangle)/error_size if error_size else None)
                envelopes[key] = envelope
                subtraction[key] = conservative(maximum(discrepancy-error[:,component]),maximum(discrepancy-(approximate_low[:,component]-parent_low[:,component]))+maximum(error[:,component]-error_low[:,component]),error_size,maximum(physical_primitives[:,component]+error_primitives[:,component]))
    initial_core = load(input_terminal('heavy',64))
    core_size = len(initial_core['normalized'])
    active = len(initial_core['error_units'])
    state_split = ratio(maximum(high['split_state_residual']),maximum(high['extended'][:,core_size-2*active:core_size]),CONFIG['algebra_tolerance'])
    rhs_split = ratio(maximum(high['split_rhs_residual']),maximum(high['split_rhs_scale']),CONFIG['algebra_tolerance'])
    physical_pass = all(report['passed'] and report['independent_native_passed'] for report in (cold_report,parent_report,approximate_report))
    defect_pass = all(value['passed'] for value in approximate_report['defect_accounted'].values())
    precision_pass = all(value['passed'] for group in (signed,centers,cross) for value in group.values())
    split_pass = all(value['passed'] for value in split.values()) and state_split['passed'] and rhs_split['passed']
    envelope_pass = all(value['passed'] and value['observed_covered'] for value in envelopes.values())
    result = {'cold':cold_report,'parent':parent_report,'approximate':approximate_report,'signed_controls':signed,'probe_centers':centers,'amplitude_agreement':cross,'split_readouts':split,'split_state':state_split,'split_rhs':rhs_split,'working_envelopes':envelopes,'raw_subtraction_precision':subtraction,'physical_checks_pass':physical_pass,'defect_accounting_pass':defect_pass,'signed_precision_pass':precision_pass,'split_identity_pass':split_pass,'working_envelope_pass':envelope_pass,'continuation_gate_pass':bool(physical_pass and defect_pass and precision_pass and split_pass and envelope_pass),'all_raw_subtraction_precision_pass':all(value['passed'] for value in subtraction.values()),'maximum_inverse_bound':float(np.max(high['coefficient_integral']+.5*high['coefficient_integral']**2)),'last_epoch':3042,'original_prior_gate_unchanged':not read(PRIOR/'replay-score.json')['primary_gate_pass'],'certified_continuum_enclosure':False,'retained_errors_outside_this_approximation':'separate prior native, source/spectrum, slow-sector and tiny-baseline limits'}
    return result


if __name__ == '__main__':
    with worker('score'):
        inputs()
        result = score()
        write(ROOT/'science-score.json',result)
        print(json.dumps({key:result[key] for key in ('continuation_gate_pass','physical_checks_pass','signed_precision_pass','split_identity_pass','working_envelope_pass','all_raw_subtraction_precision_pass','maximum_inverse_bound')}),flush=True)
