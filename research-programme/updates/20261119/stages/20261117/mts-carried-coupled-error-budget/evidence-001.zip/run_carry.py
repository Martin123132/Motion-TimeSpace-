from carry import *
import argparse
from score_phase import conservative


def input_terminal(case,steps):
    return (PRIOR/('heavy-replay-'+str(steps)+'-transport-terminal.npz') if case == 'heavy' else Path(CONFIG['second_directory'])/('cold-direct-'+str(steps)+'-terminal.npz'))


def prepare():
    require(digest(PRIOR/'closeout.json') == CONFIG['transport_seal'],'retained transport seal')
    require(read(PRIOR/'amplified-score.json')['all_passed'] and read(PRIOR/'error-parity.json')['all_passed'],'independent error validation')
    require(not read(PRIOR/'replay-score.json')['primary_gate_pass'],'original subtraction failure preserved')
    mapping = read(PRIOR/'inputs.json')
    mapping.update(read(PRIOR/'amplified-frozen.json')['files'])
    mapping[str(PRIOR/'closeout.json')] = CONFIG['transport_seal']
    for name,entry in read(PRIOR/'closeout.json')['artifacts'].items():
        mapping[str(PRIOR/name)] = entry['sha256']
    check_inputs(mapping)
    report = {}
    for case in CONFIG['cases']:
        path = source_paths(case)
        with np.load(path,allow_pickle=False) as archive:
            native_times = archive['conformal_time'][3041:3043]
        prepared,_,background,_,_ = EX.problem(case)
        times = np.unique(np.r_[native_times[0],background.boundaries(float(native_times[0]),float(native_times[-1])),native_times[-1]])
        retained = load(PRIOR/(case+'-extension-clock.npz'))
        require(np.array_equal(times,retained['time']) and np.array_equal(native_times,retained['native_time']),'unchanged planned original grid')
        for steps in CONFIG['steps']:
            require(float(load(input_terminal(case,steps))['tau']) == times[0],'same matched3041 restart')
        background.evaluate(times)
        np.savez_compressed(ROOT/(case+'-clock.npz'),time=times,native_time=native_times,native_indices=retained['native_indices'])
        mapping[str(path)] = digest(path)
        report[case] = {'samples':len(times),'elapsed_Mpc':float(times[-1]-times[0]),'paired_prior_states_carried':True}
    write(ROOT/'frozen-norms.json',read(PRIOR/'frozen-norms.json'))
    write(ROOT/'preparation.json',{'cases':report,'before_evolution':True,'earlier_subtraction_gate':False,'replacement_validation':'two-amplitude signed native controls; unchanged tolerances','new_epoch':3042})
    for path in sorted(ROOT.iterdir()):
        if path.suffix in ('.py','.md','.json','.npz') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix == '.py':
                compile(path.read_text(encoding='utf-8'),str(path),'exec')
            mapping[str(path)] = digest(path)
    write(ROOT/'inputs.json',mapping)
    inputs()
    print(json.dumps(report),flush=True)


def systems(case,steps,captured,metadata,sample):
    old_capture = load(PRIOR/(case+'-preflight-capture.npz'))
    for name,value in captured.items():
        require(np.array_equal(value,old_capture[name]),'known1052 owner capture exact: '+name)
    prepared,_,background,_,_ = EX.problem(case)
    seed = prefix(captured,case)
    direct = MetricCoupled(case,prepared,background,seed,metadata,sample)
    saved = load(input_terminal(case,steps))
    if case == 'cold':
        state = restore(direct,input_terminal(case,steps))
        return direct,None,state['normalized']
    reduced = LiveSecond(case,prepared,background,seed,metadata,sample)
    system = Carried(direct,reduced)
    restore(direct,PRIOR/('heavy-replay-'+str(steps)+'-parent-terminal.npz'))
    restore(direct,PRIOR/('heavy-replay-'+str(steps)+'-approximate-terminal.npz'))
    require(np.array_equal(system.core.rhs(float(saved['tau']),saved['normalized']),saved['actual_rhs']),'complete carried actual RHS exact')
    require(np.array_equal(system.core.error_units,saved['error_units']) and np.array_equal(system.core.error_change_units,saved['error_change_units']),'same error units')
    return direct,system,system.encode(saved['normalized'])


def preflight(case):
    inputs()
    label = case+'-preflight'
    checks = {}
    with native_context(case,label) as (captured,metadata,sample):
        for steps in CONFIG['steps']:
            direct,system,state = systems(case,steps,captured,metadata,sample)
            clock = float(load(input_terminal(case,steps))['tau'])
            native = state[:len(direct.initial)]
            packet = background_packet(direct,clock,native)
            zero = np.zeros(direct.allocated)
            for corrected in (False,True):
                checks[str(steps)+'_'+str(corrected)+'_zero_rhs'] = bool(np.all(sample(clock,zero,packet,corrected)[0] == 0))
                checks[str(steps)+'_'+str(corrected)+'_zero_readout'] = bool(np.all(readouts(direct.read_metric(clock,zero,packet,corrected)) == 0))
            if case == 'heavy':
                rhs,values = system.calculate(clock,state,True)
                checks[str(steps)+'_split_state_exact'] = bool(np.all(values['split_state_residual'] == 0))
                checks[str(steps)+'_split_rhs'] = maximum(values['split_rhs_residual']) <= CONFIG['algebra_tolerance']*float(values['split_rhs_scale'])
                checks[str(steps)+'_fresh_zero'] = bool(np.all(values['fresh_source'] == 0) and np.all(values['fresh_readout'] == 0))
                checks[str(steps)+'_carry_source_exact'] = np.array_equal(values['carry_source'],values['error_source'])
                checks[str(steps)+'_carry_readout_exact'] = np.array_equal(values['carry_readout'],values['error_readout'])
                for branch in (0,1):
                    for family in ('source','readout'):
                        if family == 'source':
                            probes = values['probe_source']+(values['probe_source_change'] if branch else 0.)
                            expected = values['error_source'][0]+(values['error_source'][1] if branch else 0.)
                            amplitude = abs(probes)
                        else:
                            probes = readouts(values['probe_metric'])[...,branch,:]
                            expected = values['error_readout'][branch]
                            amplitude = primitive_envelope(values['probe_metric'])[...,branch,:]
                        for index,scale in enumerate(CONFIG['amplifications']):
                            result = (probes[index,0]-probes[index,1])/(2*scale)
                            checks[str(steps)+'_'+str(branch)+'_'+family+'_'+str(scale)+'_initial_probe'] = conservative(maximum(result-expected),0.,maximum(expected),maximum(amplitude[index,0]+amplitude[index,1])/(2*scale))['passed']
        write(ROOT/(label+'-result.json'),{'checks':{name:bool(value) for name,value in checks.items()},'passed':all(checks.values()),'captured1052_exact':True,'respective_prior32_64_restarts':True})
        require(all(checks.values()),'carried preflight: '+str([name for name,value in checks.items() if not value]))
        print(json.dumps({'case':case,'checks':len(checks),'passed':True}),flush=True)
    inputs()


def run(case,steps):
    inputs()
    require(read(ROOT/(case+'-preflight-result.json'))['passed'],'matched restart gate')
    label = case+'-'+str(steps)
    with native_context(case,label) as (captured,metadata,sample):
        direct,system,current = systems(case,steps,captured,metadata,sample)
        clocks = load(ROOT/(case+'-clock.npz'))
        times = clocks['time']
        require(np.array_equal(captured['clock'][-2:],clocks['native_time']),'original report clocks unchanged')
        if case == 'heavy':
            rhs = system.rhs
            evaluate = lambda clock,vector:system.calculate(clock,vector,True)[1]
        else:
            rhs = direct.rhs
            evaluate = lambda clock,vector:direct.evaluate(clock,vector)[1]
        states = [current.copy()]
        initial = evaluate(float(times[0]),current)
        observed = {name:np.empty((len(times),*np.asarray(value).shape)) for name,value in initial.items()}
        for name,value in initial.items():
            observed[name][0] = value
        evaluations = 0
        for position,(left,right) in enumerate(zip(times[:-1],times[1:])):
            guard()
            solution = solve_ivp(rhs,(float(left),float(right)),current,method='DOP853',t_eval=[right],rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(direct.prepared['elapsed'][8])/steps)
            require(solution.success,'carried live continuation')
            current = solution.y[:,-1]
            evaluations += solution.nfev
            states.append(current.copy())
            for name,value in evaluate(float(right),current).items():
                observed[name][position+1] = value
            if (position+1)%CONFIG['batch_boundaries'] == 0 or position == len(times)-2:
                np.savez_compressed(ROOT/(label+'-boundary'+str(position+1)+'.npz'),tau=np.array(right),normalized=current,actual_rhs=rhs(float(right),current),completed=np.array(position+1))
                print(json.dumps({'label':label,'boundary':position+1,'total':len(times)-1}),flush=True)
        reference = captured['observation_reference'][-2:]
        control = np.column_stack((-CONFIG['retained_comoving_wave']*(reference[:,26]+reference[:,5])/reference[:,28],reference[:,9],reference[:,21],reference[:,20]-.75*reference[:,21],reference[:,26]-.75*reference[:,24]))
        np.savez_compressed(ROOT/(label+'.npz'),time=times,extended=np.array(states),native_indices=clocks['native_indices'],native_control=control,**observed)
        if case == 'heavy':
            core = current[:system.core_size]
            approximate,parent,_,_ = system.core.unpack(core)
            checkpoint(direct,float(times[-1]),parent,ROOT/(label+'-parent-terminal.npz'))
            checkpoint(direct,float(times[-1]),approximate[:system.core.native_size],ROOT/(label+'-approximate-terminal.npz'))
            np.savez_compressed(ROOT/(label+'-terminal.npz'),tau=np.array(times[-1]),normalized=current,actual_rhs=rhs(float(times[-1]),current),core_size=np.array(system.core_size),native_size=np.array(system.core.native_size),parent_indices=system.core.parent_indices,error_units=system.core.error_units,error_change_units=system.core.error_change_units)
            np.savez_compressed(ROOT/(label+'-transport-terminal.npz'),tau=np.array(times[-1]),normalized=core,actual_rhs=system.core.rhs(float(times[-1]),core),native_size=np.array(system.core.native_size),parent_indices=system.core.parent_indices,error_units=system.core.error_units,error_change_units=system.core.error_change_units)
        else:
            checkpoint(direct,float(times[-1]),current,ROOT/(label+'-terminal.npz'))
        write(ROOT/(label+'-result.json'),{'completed':True,'case':case,'steps':steps,'samples':len(times),'evaluations':evaluations,'last_epoch':3042,'prior32_64_differences_carried':True,'original_bank_grids_tolerances':True,'future_source_metric_forcing':False,'physical_state_rematched':False})
    inputs()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command',choices=('prepare','preflight','run'))
    parser.add_argument('--case',choices=CONFIG['cases'],default='heavy')
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=32)
    arguments = parser.parse_args()
    label = 'prepare' if arguments.command == 'prepare' else arguments.case+'-'+('preflight' if arguments.command == 'preflight' else str(arguments.steps))
    with worker(label):
        if arguments.command == 'prepare':prepare()
        elif arguments.command == 'preflight':preflight(arguments.case)
        else:run(arguments.case,arguments.steps)
