from score_carry import *


def verify():
    inputs()
    science = read(ROOT/'science-score.json')
    checks = {'score_repeat':score() == science,'prior_failure_preserved':not read(PRIOR/'replay-score.json')['primary_gate_pass']}
    frozen = datetime.fromisoformat(read(ROOT/'prepare-end.json')['utc'])
    for case in CONFIG['cases']:
        checks[case+'_preflight'] = read(ROOT/(case+'-preflight-result.json'))['passed']
        for steps in CONFIG['steps']:
            label = case+'-'+str(steps)
            data = load(ROOT/(label+'.npz'))
            terminal = load(ROOT/(label+'-terminal.npz'))
            initial = load(input_terminal(case,steps))
            checks[label+'_finite'] = all(np.isfinite(value).all() for value in data.values())
            checks[label+'_terminal_exact'] = np.array_equal(terminal['normalized'],data['extended'][-1])
            checks[label+'_clock_match'] = terminal['tau'] == data['time'][-1] and initial['tau'] == data['time'][0]
            checks[label+'_strict_clock'] = bool(np.all(np.diff(data['time']) > 0))
            checks[label+'_owner_released'] = read(ROOT/(label+'-owner-release.json'))['cleared']
            checks[label+'_frozen_before_start'] = frozen < datetime.fromisoformat(read(ROOT/(label+'-start.json'))['utc'])
            for path in ROOT.glob(label+'-boundary*.npz'):
                batch = load(path)
                index = int(batch['completed'])
                checks[path.stem+'_state_exact'] = np.array_equal(batch['normalized'],data['extended'][index])
                checks[path.stem+'_clock_exact'] = batch['tau'] == data['time'][index]
            if case == 'cold':
                checks[label+'_carried_respective_initial'] = np.array_equal(data['extended'][0],initial['normalized'])
                checks[label+'_units'] = np.array_equal(terminal['units'],initial['units'])
            else:
                core_size,native_size = int(terminal['core_size']),int(terminal['native_size'])
                transport = load(ROOT/(label+'-transport-terminal.npz'))
                parent = load(ROOT/(label+'-parent-terminal.npz'))
                approximate = load(ROOT/(label+'-approximate-terminal.npz'))
                active,width = int(parent['dimensions'][1]),int(parent['dimensions'][2])
                checks[label+'_carried_respective_core'] = np.array_equal(data['extended'][0,:core_size],initial['normalized'])
                checks[label+'_initial_carry_equals_error'] = np.array_equal(data['extended'][0,core_size:core_size+2*active],initial['normalized'][-2*active:])
                checks[label+'_fresh_zero'] = bool(np.all(data['extended'][0,core_size+2*active:core_size+4*active] == 0))
                checks[label+'_K_not_reset'] = bool(np.any(data['coefficient_matrices'][0] != 0))
                checks[label+'_error_not_reset'] = bool(np.any(data['error_state'][0] != 0))
                checks[label+'_core_terminal'] = np.array_equal(transport['normalized'],terminal['normalized'][:core_size])
                checks[label+'_approximate_terminal'] = np.array_equal(approximate['normalized'],terminal['normalized'][:native_size])
                indices = terminal['parent_indices']
                checks[label+'_parent_terminal'] = np.array_equal(parent['normalized'][indices],terminal['normalized'][native_size+22:native_size+22+len(indices)])
                checks[label+'_same_background'] = np.array_equal(parent['normalized'][2*active:2*active+width],approximate['normalized'][2*active:2*active+width])
                prior_parent = load(PRIOR/('heavy-replay-'+str(steps)+'-parent-terminal.npz'))
                checks[label+'_units'] = np.array_equal(parent['units'],prior_parent['units']) and np.array_equal(parent['units'],approximate['units'])
                checks[label+'_inverse_bound'] = bool(np.max(data['coefficient_integral']+.5*data['coefficient_integral']**2) < 1)
                packet = data['metric']
                species = packet[...,:84].reshape(len(data['time']),2,7,12)
                wave = CONFIG['retained_comoving_wave']
                force_prime = (np.sum(species[...,7],axis=-1)/(2*wave)+field(packet,'eta_k_prime')-field(packet,'hubble_prime')*field(packet,'z'))/field(packet,'hubble')
                shear_prime = force_prime+3*np.sum(species[...,8],axis=-1)/(2*wave**2)
                norms = read(ROOT/'frozen-norms.json')['heavy']
                checks[label+'_actual_metric_derivative'] = maximum(force_prime-field(packet,'z_prime')) <= CONFIG['algebra_tolerance']*norms['metric_norm'][3]
                checks[label+'_actual_shear_derivative'] = maximum(shear_prime-field(packet,'sigma_prime')) <= CONFIG['algebra_tolerance']*norms['metric_norm'][4]
    with native_context('heavy','verify-owner') as (captured,metadata,sample):
        direct,system,_ = systems('heavy',64,captured,metadata,sample)
        terminal = load(ROOT/'heavy-64-terminal.npz')
        actual = system.rhs(float(terminal['tau']),terminal['normalized'])
        checks['fresh_owner_final_full_rhs_exact'] = np.array_equal(actual,terminal['actual_rhs'])
        core = load(ROOT/'heavy-64-transport-terminal.npz')
        checks['fresh_owner_final_core_rhs_exact'] = np.array_equal(system.core.rhs(float(core['tau']),core['normalized']),core['actual_rhs'])
        restore(direct,ROOT/'heavy-64-parent-terminal.npz')
        restore(direct,ROOT/'heavy-64-approximate-terminal.npz')
        checks['fresh_owner_final_native_sources_exact'] = True
    checks['verification_owner_released'] = read(ROOT/'verify-owner-owner-release.json')['cleared']
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['no_bytecode'] = not list(ROOT.rglob('__pycache__'))
    result = {'checks':{name:bool(value) for name,value in checks.items()},'count':len(checks),'passed':all(checks.values()),'continuation_gate_pass':science['continuation_gate_pass']}
    write(ROOT/'verification.json',result)
    require(result['passed'],'technical verification: '+str([name for name,value in checks.items() if not value]))
    inputs()
    print(json.dumps({key:result[key] for key in ('count','passed','continuation_gate_pass')}),flush=True)


if __name__ == '__main__':
    with worker('verify'):
        verify()
