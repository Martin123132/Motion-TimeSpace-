from restart_bridge import *
PRIOR = Path(CONFIG['transport_directory'])
sys.path.insert(0,str(PRIOR))
from transport import Transport, background_packet
from live_second import LiveSecond, coefficients, multiply, recurrence_and_residual
from run_phase import source_paths, readouts
from verify_phase import primitive_envelope


def residual_at(system,clock,approximate):
    native = approximate[:system.native_size]
    extra = approximate[system.native_size:]
    old,change,physical,_,_ = system.unpack(native)
    terms = coefficients(system.model,system.prepared,clock,physical)
    matrices = (extra[:8]*system.matrix_units).reshape(2,2,2)
    changes = (extra[8:16]*system.matrix_change_units).reshape(2,2,2)
    return recurrence_and_residual(terms,(old[system.selected],change[system.selected]),(matrices[0],changes[0]),(matrices[1],changes[1]))[2]


def linear_values(direct,selected,clock,parent,old,change):
    packet = background_packet(direct,clock,parent)
    metrics = np.stack((direct.read_metric(clock,old,packet,False),direct.read_metric(clock,old+change,packet,True)))
    terms = coefficients(direct.model,direct.prepared,clock,direct.unpack(parent)[2])
    pair_source = multiply(terms['source_matrix'],(old[selected],change[selected]))
    beta = terms['beta']
    density_current = (beta.base*pair_source[0],(beta.base+beta.change)*pair_source[1]+beta.change*pair_source[0])
    phi,velocity,mu = [terms['raw'][name] for name in ('phi','velocity','mu')]
    potential = mu**2*phi
    pressure_old = velocity.base*old[selected[1]]-potential.base*old[selected[0]]
    pressure_delta = (velocity.base+velocity.change)*change[selected[1]]+velocity.change*old[selected[1]]-(potential.base+potential.change)*change[selected[0]]-potential.change*old[selected[0]]
    sources = np.stack((np.r_[density_current[0],beta.base*pressure_old],np.r_[density_current[1],(beta.base+beta.change)*pressure_delta+beta.change*pressure_old]))
    primitives = []
    for branch in (0,1):
        field_value,velocity_value,mass_value,weight = [value.base+(value.change if branch else 0.) for value in (phi,velocity,mu,beta)]
        perturbation = (old+(change if branch else 0.))[selected]
        density_pressure = abs(weight)*(abs(mass_value**2*field_value*perturbation[0])+abs(velocity_value*perturbation[1]))
        primitives.append([density_pressure,abs(weight*CONFIG['retained_comoving_wave']*velocity_value*perturbation[0]),density_pressure])
    return {'source':sources,'readout':readouts(metrics),'source_primitive':np.array(primitives),'readout_primitive':primitive_envelope(metrics)}


class Carried:
    def __init__(self,direct,reduced):
        self.core = Transport(direct,reduced)
        self.direct,self.reduced = direct,reduced
        self.active = direct.active
        self.core_size = self.core.approx_size+self.core.parent_size+2*self.active
        self.pair_size = 2*self.active
        self.calls = 0

    def encode(self,core_state):
        require(len(core_state) == self.core_size,'complete inherited state')
        _,parent,_,_ = self.core.unpack(core_state)
        error = core_state[-self.pair_size:]
        probes = [parent[:self.pair_size]+sign*amplitude*CONFIG['error_fraction']*error for amplitude in CONFIG['amplifications'] for sign in CONFIG['signs']]
        return np.r_[core_state,error,np.zeros(self.pair_size),*probes]

    def vectors(self,normalized):
        old,change = np.zeros(self.direct.allocated),np.zeros(self.direct.allocated)
        old[:self.active] = normalized[:self.active]*self.core.error_units
        change[:self.active] = normalized[self.active:]*self.core.error_change_units
        return old,change

    def linear_rhs(self,clock,normalized,packet,residual=None):
        old,change = self.vectors(normalized)
        old_rhs = self.direct.sample(clock,old,packet,False)[0]
        new_old_rhs = self.direct.sample(clock,old,packet,True)[0]
        change_rhs = self.direct.sample(clock,change,packet,True)[0]
        delta_rhs = new_old_rhs-old_rhs+change_rhs
        if residual is not None:
            old_rhs[self.reduced.selected] -= residual[0]
            delta_rhs[self.reduced.selected] -= residual[1]
        return np.r_[old_rhs[:self.active]/self.core.error_units,delta_rhs[:self.active]/self.core.error_change_units]

    def calculate(self,clock,state,diagnostics):
        core = state[:self.core_size]
        core_rhs,values = self.core.calculate(clock,core,diagnostics)
        approximate,parent,error_old,error_change = self.core.unpack(core)
        residual = values['field_truncation'] if diagnostics else residual_at(self.reduced,clock,approximate)
        packet = background_packet(self.direct,clock,parent)
        carry = state[self.core_size:self.core_size+self.pair_size]
        fresh = state[self.core_size+self.pair_size:self.core_size+2*self.pair_size]
        carry_rhs = self.linear_rhs(clock,carry,packet)
        fresh_rhs = self.linear_rhs(clock,fresh,packet,residual)
        probes = state[self.core_size+2*self.pair_size:].reshape(2,2,self.pair_size)
        probe_rhs,probe_values = [],[]
        for amplitude_index,amplitude in enumerate(CONFIG['amplifications']):
            for sign_index,sign in enumerate(CONFIG['signs']):
                native = parent.copy()
                native[:self.pair_size] = probes[amplitude_index,sign_index]
                old,change,_,_,_ = self.direct.unpack(native)
                old_rhs = self.direct.sample(clock,old,packet,False)[0]
                new_old_rhs = self.direct.sample(clock,old,packet,True)[0]
                change_rhs = self.direct.sample(clock,change,packet,True)[0]
                delta_rhs = new_old_rhs-old_rhs+change_rhs
                old_rhs[self.reduced.selected] -= sign*amplitude*residual[0]
                delta_rhs[self.reduced.selected] -= sign*amplitude*residual[1]
                probe_rhs.extend((old_rhs[:self.active]/self.direct.state_units,delta_rhs[:self.active]/self.direct.delta_units))
                if diagnostics:
                    probe_values.append(self.direct.evaluate(clock,native)[1])
        if diagnostics:
            for name,pair in (('carry',self.vectors(carry)),('fresh',self.vectors(fresh)),('error',(error_old,error_change))):
                values.update({name+'_'+key:value for key,value in linear_values(self.direct,self.reduced.selected,clock,parent,*pair).items()})
            values['split_state_residual'] = core[-self.pair_size:]-carry-fresh
            values['split_rhs_residual'] = core_rhs[-self.pair_size:]-carry_rhs-fresh_rhs
            values['split_rhs_scale'] = np.array(maximum(core_rhs[-self.pair_size:])+maximum(carry_rhs)+maximum(fresh_rhs))
            for name in ('source','source_change','metric'):
                array = np.stack([item[name] for item in probe_values])
                values['probe_'+name] = array.reshape(2,2,*array.shape[1:])
        return np.r_[core_rhs,carry_rhs,fresh_rhs,*probe_rhs],values

    def rhs(self,clock,state):
        self.calls += 1
        if self.calls%128 == 0:
            guard()
        return self.calculate(clock,state,False)[0]
