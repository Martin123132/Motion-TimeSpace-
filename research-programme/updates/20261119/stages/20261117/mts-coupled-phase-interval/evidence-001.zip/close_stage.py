from restart_support import *
import importlib.metadata

if __name__ == "__main__":
    check_inputs(read(ROOT / "inputs.json"))
    check_inputs(read(ROOT / "predictions-frozen.json")["files"])
    check_inputs(read(ROOT / "score-plan.json")["files"])
    verification = read(ROOT / "verification.json")
    require(verification["passed"] and verification["main_physical_passed"] and verification["independent_controls_passed"], "verified physical advance")
    workers = {path.name: {**read(path), **exited(read(path))} for path in ROOT.glob("*-start.json")}
    require(all(item["exited"] for item in workers.values()), "all worker identities exited")
    releases = {path.name: read(path)["cleared"] for path in ROOT.glob("*-owner-release.json")}
    require(len(releases) == 4 and all(releases.values()), "four native owners released")
    require(not (ROOT / "__pycache__").exists(), "no bytecode")
    for path in ROOT.glob("*.py"):
        compile(path.read_text(), str(path), "exec")
    write(ROOT / "cleanup.json", {"workers": workers, "native_releases": releases, "all_exited": True,
          "other_processes_changed": False, "temporary_tools": [], "python": sys.version,
          "packages": {name: importlib.metadata.version(name) for name in ("numpy","scipy","sympy","psutil")}})
    artifacts = {str(path.relative_to(ROOT)): {"sha256": digest(path), "bytes": path.stat().st_size}
                 for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name != "closeout.json"}
    result = {"stage": "Coupled106-epoch phase interval and frozen local source forecasts",
              "utc": datetime.now(timezone.utc).isoformat(), "completed": True, "verification_passed": True,
              "consolidated_checks": verification["count"], "main_physical_passed_both": True,
              "independent_native_controls_passed_both": True, "new_epochs": [2933,3038],
              "derived_linear_forecast_passes_both": True, "constant_MTS_density_forecast_passes": False,
              "all_scientific_tests_pass": False, "baseline_response_unresolved": True,
              "frozen_inputs": len(read(ROOT / "inputs.json")), "frozen_forecast_files":16,
              "workers_exited":len(workers), "native_owners_released":4,
              "driver_failure_preserved":True, "native_binary_rebuilt":False, "github":False,
              "artifacts":artifacts}
    write(ROOT / "closeout.json", result)
    print(json.dumps({"seal":digest(ROOT / "closeout.json"), "artifacts":len(artifacts),
                      "workers_exited":len(workers), "bytes":sum(item["bytes"] for item in artifacts.values())}))

