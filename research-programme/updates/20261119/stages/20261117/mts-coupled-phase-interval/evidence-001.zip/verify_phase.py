from run_phase import *

def primitive_envelope(packet):
    material = packet[..., :84].reshape((*packet.shape[:-1], 7, 12))
    baryon, photon = material[..., 1, :], material[..., 2, :]
    wave = CONFIG["retained_comoving_wave"]
    hubble, sigma = field(packet, "hubble"), field(packet, "sigma")
    vb, qg = baryon[..., 4] / baryon[..., 0], photon[..., 4] / photon[..., 0]
    db, dg = baryon[..., 3] / baryon[..., 0], photon[..., 3] / photon[..., 0]
    density, current, shear = [np.sum(abs(material[..., column]), axis=-1) for column in (3, 4, 6)]
    return np.stack((wave * (abs(vb)+abs(sigma)) / hubble,
                     (density+3*hubble*current/wave+shear)/(2*wave**2),
                     abs(dg), abs(db)+.75*abs(dg), abs(vb)+.75*abs(qg)), axis=-1)

def verify():
    inputs()
    check_inputs(read(ROOT / "predictions-frozen.json")["files"])
    check_inputs(read(ROOT / "score-plan.json")["files"])
    science = read(ROOT / "science-score.json")
    checks, rounding = {}, {}
    freeze_time = datetime.fromisoformat(read(ROOT / "predictions-frozen.json")["utc"])
    score_time = datetime.fromisoformat(read(ROOT / "score-plan.json")["utc"])
    for case in CONFIG["cases"]:
        original = saved_state(case)
        for steps in CONFIG["steps"]:
            label = case + "-live-" + str(steps)
            start = read(ROOT / (label + "-start.json"))
            checks[label + "_prediction_and_gates_frozen_first"] = freeze_time < datetime.fromisoformat(start["utc"]) and score_time < datetime.fromisoformat(start["utc"])
            data = load(ROOT / (label + ".npz"))
            current = original["normalized"]
            begin = 0
            endings = list(range(CONFIG["batch_epochs"], len(data["time"])-1, CONFIG["batch_epochs"])) + [len(data["time"])-1]
            for end in endings:
                batch = label + "-epoch" + str(CONFIG["start_index"] + end)
                saved = load(ROOT / (batch + "-history.npz"))
                terminal = load(ROOT / (batch + "-terminal.npz"))
                checks[batch + "_state_continuity"] = np.array_equal(saved["normalized"][0], current)
                checks[batch + "_history_and_terminal"] = (
                    np.array_equal(saved["normalized"], data["normalized"][begin:end+1]) and
                    np.array_equal(terminal["normalized"], saved["normalized"][-1]) and
                    np.array_equal(terminal["native_coherent"], terminal["native_old"]+terminal["native_change"]))
                current = terminal["normalized"]
                begin = end
            terminal = load(ROOT / (label + "-terminal.npz"))
            checks[label + "_final_layout"] = np.array_equal(terminal["signature"], original["signature"])
            checks[label + "_finite_complete_history"] = all(np.isfinite(value).all() for value in data.values())
            checks[label + "_release"] = read(ROOT / (label + "-owner-release.json"))["cleared"]
            checks[label + "_106_epochs"] = len(data["time"]) == 107 and np.all(np.diff(data["time"]) > 0)
        high, low = load(ROOT / (case+"-live-64.npz")), load(ROOT / (case+"-live-32.npz"))
        values, coarse = readouts(high["metric"]), readouts(low["metric"])
        amplitude = primitive_envelope(high["metric"]) + primitive_envelope(low["metric"])
        norm = read(ROOT / "frozen-norms.json")[case]["readout_norm"]
        refined, controls = {}, {}
        for branch, branch_name in enumerate(("old", "coherent")):
            for column, name in enumerate(("native_velocity", "native_weyl", "photon_density", "relative_density", "velocity_slip")):
                allowance = 64*np.finfo(float).eps*maximum(amplitude[:, branch, column])
                error = maximum(values[:, branch, column]-coarse[:, branch, column])
                refined[branch_name+"_"+name] = ratio(error+allowance, norm[column])
                if branch == 0:
                    controls[name] = ratio(maximum(values[:, 0, column]-high["native_control"][:, column])+error+allowance, norm[column])
        response = values[:, 1, 0]-values[:, 0, 0]
        response_step = maximum((values[:, 1, 0]-coarse[:, 1, 0])-(values[:, 0, 0]-coarse[:, 0, 0]))
        response_round = 64*np.finfo(float).eps*maximum(amplitude[:, 0, 0]+amplitude[:, 1, 0])
        rounding[case] = {"full_refinement": refined, "original_controls": controls,
                          "full_refinement_passed": all(item["passed"] for item in refined.values()),
                          "controls_passed": all(item["passed"] for item in controls.values()),
                          "response": ratio(response_step+response_round, maximum(response)),
                          "response_rounding_estimate": response_round,
                          "working_estimate_not_rigorous_bound": True}
        for mode in ("constant", "linear"):
            for steps in CONFIG["steps"]:
                report = read(ROOT / (case+"-"+mode+"-"+str(steps)+"-prediction.json"))
                checks[case+"_"+mode+"_"+str(steps)+"_initial_rhs"] = report["passed"] and report["no_future_live_source_read"]
    checks["symbolic_derivation"] = read(ROOT / "symbolic-result.json")["passed"]
    checks["driver_failure_preserved"] = (ROOT / "heavy-constant-predict-64-failure.json").is_file() and read(ROOT / "driver-fix.json")["no_forecast_preceded_fix"]
    checks["all_owned_workers_exited"] = all(exited(read(path))["exited"] for path in ROOT.glob("*-start.json") if path.name != "verify-start.json")
    checks["no_bytecode"] = not (ROOT / "__pycache__").exists()
    checks["frozen_sources_preserved"] = True
    for path in ROOT.glob("*.py"):
        compile(path.read_text(), str(path), "exec")
    checks["all_new_code_compiles"] = True
    result = {"passed": all(bool(value) for value in checks.values()),
              "count": len(checks), "checks": {key: bool(value) for key, value in checks.items()},
              "primitive_rounding_supplement": rounding,
              "main_physical_passed": science["main_passed"] and all(item["full_refinement_passed"] for item in rounding.values()),
              "independent_controls_passed": science["independent_controls_passed"] and all(item["controls_passed"] for item in rounding.values()),
              "forecast_failures_preserved": {case: {mode: report["failed"] for mode, report in science["cases"][case]["forecasts"].items()} for case in CONFIG["cases"]}}
    write(ROOT / "verification.json", result)
    print(json.dumps({key: result[key] for key in ("passed","count","main_physical_passed","independent_controls_passed","forecast_failures_preserved")}), flush=True)
    require(result["passed"], "technical verification")

if __name__ == "__main__":
    with worker("verify"):
        verify()

