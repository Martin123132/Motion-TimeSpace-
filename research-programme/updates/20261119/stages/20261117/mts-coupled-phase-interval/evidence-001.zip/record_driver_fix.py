from restart_support import *

if __name__ == "__main__":
    original = read(ROOT / "inputs.json")
    require(read(ROOT / "heavy-constant-predict-64-failure.json")["error"] == 'NameError("name \'BG\' is not defined")', "identified driver error")
    require(not any(ROOT.glob("*-prediction.npz")), "no forecasts generated before driver fix")
    write(ROOT / "inputs-before-driver-fix.json", original)
    changed = original.copy()
    key = str(ROOT / "run_phase.py")
    changed[key] = digest(ROOT / "run_phase.py")
    check_inputs(changed)
    write(ROOT / "inputs-repaired.json", changed)
    (ROOT / "inputs-repaired.json").replace(ROOT / "inputs.json")
    write(ROOT / "driver-fix.json", {"cause": "Unbound BG name; use retained_run.BG.Model already imported by the bridge", "physics_or_tolerance_changed": False, "no_forecast_preceded_fix": True, "old_hash": original[key], "new_hash": changed[key], "failed_receipts_preserved": True, "retry_requires_explicit_receipt_tag": True})
