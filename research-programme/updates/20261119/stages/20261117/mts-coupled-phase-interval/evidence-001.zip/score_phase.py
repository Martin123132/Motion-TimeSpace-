from run_phase import *
import sys

def conservative(error, refinement, scale, amplitude):
    rounding = 64 * np.finfo(float).eps * amplitude
    result = ratio(error + refinement + rounding, scale)
    result.update(residual=float(error), refinement=float(refinement), rounding=float(rounding))
    return result

def freeze_score():
    require(not any(ROOT.glob("*-live-*-start.json")), "score definition precedes live test")
    write(ROOT / "score-plan.json", {"utc": datetime.now(timezone.utc).isoformat(),
          "files": {str(ROOT / "score_phase.py"): digest(ROOT / "score_phase.py")},
          "full_checks": "Original2e-5 full reference norms; residual +32/64 difference +64epsilon scale.",
          "predictor_checks": "Same bound, own state and source; failed closures remain approximate failures.",
          "independent_control": "Old native readout versus CAMB original observer, same reference norms."})

def score():
    inputs()
    plan = read(ROOT / "score-plan.json")
    check_inputs(plan["files"])
    check_inputs(read(ROOT / "predictions-frozen.json")["files"])
    reports = {}
    for case in CONFIG["cases"]:
        fine = load(ROOT / (case + "-live-64.npz"))
        coarse = load(ROOT / (case + "-live-32.npz"))
        norm = read(ROOT / "frozen-norms.json")[case]
        checks, controls, forecasts = {}, {}, {}
        require(np.array_equal(fine["time"], coarse["time"]), "common physical clocks")
        high, low = readouts(fine["metric"]), readouts(coarse["metric"])
        for branch, branch_name in enumerate(("old", "coherent")):
            for component, name in enumerate(("native_velocity", "native_weyl", "photon_density", "relative_density", "velocity_slip")):
                checks[branch_name + "_" + name] = conservative(0., maximum(high[:, branch, component] - low[:, branch, component]),
                    norm["readout_norm"][component], maximum(abs(high[:, branch, component]) + abs(low[:, branch, component])))
                if branch == 0:
                    controls[name] = conservative(maximum(high[:, branch, component] - fine["native_control"][:, component]),
                        maximum(high[:, branch, component] - low[:, branch, component]),
                        norm["readout_norm"][component], maximum(abs(high[:, branch, component]) + abs(fine["native_control"][:, component])))
        for name, index in (("trace_residual", 3), ("shear_residual", 4), ("eta_residual", 5), ("density_constraint", 6), ("friedmann_constraint", 7)):
            values, comparison = fine["metric"][:, 1, COLUMNS[name]], coarse["metric"][:, 1, COLUMNS[name]]
            checks["coherent_" + name] = conservative(maximum(values), maximum(values - comparison), norm["metric_norm"][index], norm["metric_norm"][index])
        for branch, source, work, other_source, other_work in (
            ("old", fine["source"], fine["work"], coarse["source"], coarse["work"]),
            ("coherent", fine["source"]+fine["source_change"], fine["work"]+fine["work_change"],
             coarse["source"]+coarse["source_change"], coarse["work"]+coarse["work_change"])):
            for component, section in ((0, slice(0, 6)), (1, slice(6, 9))):
                residual = source[:, component] - source[0, component] - np.sum(work[:, section] - work[0, section], axis=1)
                previous = other_source[:, component] - other_source[0, component] - np.sum(other_work[:, section] - other_work[0, section], axis=1)
                amplitude = maximum(abs(source[:, component]) + np.sum(abs(work[:, section]), axis=1))
                checks[branch + "_exchange_" + str(component)] = conservative(maximum(residual), maximum(residual - previous), norm["source_norm"][component], amplitude)
            checks[branch + "_pressure_refinement"] = conservative(0., maximum(source[:, 2] - other_source[:, 2]),
                                                                norm["source_norm"][2], maximum(abs(source[:, 2]) + abs(other_source[:, 2])))
        actual_states = np.stack((fine["own_state"], fine["own_state"]+fine["own_state_change"]), axis=1)
        actual_sources = np.stack((fine["source"], fine["source"]+fine["source_change"]), axis=1)
        coarse_states = np.stack((coarse["own_state"], coarse["own_state"]+coarse["own_state_change"]), axis=1)
        coarse_sources = np.stack((coarse["source"], coarse["source"]+coarse["source_change"]), axis=1)
        for mode in ("constant", "linear"):
            predicted = load(ROOT / (case + "-" + mode + "-64-prediction.npz"))
            lower = load(ROOT / (case + "-" + mode + "-32-prediction.npz"))
            require(np.array_equal(predicted["time"], fine["time"]), "frozen prediction clocks")
            prediction_checks = {}
            for branch, branch_name in enumerate(("old", "coherent")):
                for key, actual, actual_coarse, scale in (("state", actual_states, coarse_states, norm["own_state_norm"]),
                                                          ("source", actual_sources, coarse_sources, norm["source_norm"])):
                    for component in range(actual.shape[-1]):
                        error = maximum(predicted[key][:, branch, component] - actual[:, branch, component])
                        refinement = maximum(predicted[key][:, branch, component] - lower[key][:, branch, component])
                        refinement += maximum(actual[:, branch, component] - actual_coarse[:, branch, component])
                        amplitude = maximum(abs(predicted[key][:, branch, component]) + abs(actual[:, branch, component]))
                        prediction_checks[branch_name + "_" + key + "_" + str(component)] = conservative(error, refinement, scale[component], amplitude)
            forecasts[mode] = {"checks": prediction_checks, "passed": all(item["passed"] for item in prediction_checks.values()),
                               "failed": [name for name, item in prediction_checks.items() if not item["passed"]]}
        scalar_count = 2 if case == "heavy" else 1
        saved = saved_state(case)
        active, width = int(saved["dimensions"][1]), int(saved["dimensions"][2])
        bg_difference = maximum((fine["normalized"][:, 2*active:2*active+width] - coarse["normalized"][:, 2*active:2*active+width]) * 1e-7)
        checks["background_full_units"] = ratio(bg_difference, 1.)
        correction = high[:, 1, 0] - high[:, 0, 0]
        correction_step = (high[:, 1, 0]-low[:, 1, 0]) - (high[:, 0, 0]-low[:, 0, 0])
        response_check = conservative(0., maximum(correction_step), maximum(correction), maximum(abs(high[:, 1, 0])+abs(high[:, 0, 0])))
        material = fine["metric"][..., :84].reshape(len(fine["time"]), 2, 7, 12)
        owned = 0 if case == "cold" else 6
        actual_external = np.sum(material[..., [index for index in range(7) if index != owned], :][..., [3, 4]], axis=-2)
        initial, slope = external_from_packet(fine["metric"][0], case)
        external_norm = np.max(abs(actual_external), axis=0)
        environment = {}
        for mode in ("constant", "linear"):
            expectation = initial[None, :, :] + ((fine["time"]-fine["time"][0])[:, None, None] * slope[None, :, :] if mode == "linear" else 0.)
            environment[mode] = [[ratio(maximum(actual_external[:, branch, component]-expectation[:, branch, component]),
                                        float(external_norm[branch, component]))
                                  for component in range(2)] for branch in range(2)]
        reports[case] = {"main_checks": checks, "main_passed": all(item["passed"] for item in checks.values()),
                         "independent_original_control": controls, "independent_control_passed": all(item["passed"] for item in controls.values()),
                         "forecasts": forecasts, "surrounding_source_discrepancy": environment,
                         "native_velocity_response_relative_refinement": response_check,
                         "native_velocity_correction_range": [float(np.min(correction)), float(np.max(correction))],
                         "initial_final_native_velocity": high[[0, -1], :, 0].tolist(),
                         "final_old_coherent_source": actual_sources[-1].tolist(),
                         "new_clock_epochs": [CONFIG["start_index"]+1, CONFIG["last_index"]],
                         "no_902_projection_or_observational_fit": True}
    result = {"cases": reports, "main_passed": all(item["main_passed"] for item in reports.values()),
              "independent_controls_passed": all(item["independent_control_passed"] for item in reports.values()),
              "all_scientific_tests_pass": all(item["main_passed"] and item["independent_control_passed"] and
                  item["native_velocity_response_relative_refinement"]["passed"] and
                  all(prediction["passed"] for prediction in item["forecasts"].values()) for item in reports.values())}
    write(ROOT / "science-score.json", result)
    print(json.dumps({case: {"main_passed": report["main_passed"], "controls_passed": report["independent_control_passed"],
          "forecasts_passed": {mode: item["passed"] for mode, item in report["forecasts"].items()},
          "forecast_failures": {mode: item["failed"] for mode, item in report["forecasts"].items()},
          "velocity_correction_range": report["native_velocity_correction_range"],
          "response_refinement": report["native_velocity_response_relative_refinement"]} for case, report in reports.items()}), flush=True)

if __name__ == "__main__":
    with worker("freeze-score" if sys.argv[1] == "freeze" else "score"):
        freeze_score() if sys.argv[1] == "freeze" else score()

