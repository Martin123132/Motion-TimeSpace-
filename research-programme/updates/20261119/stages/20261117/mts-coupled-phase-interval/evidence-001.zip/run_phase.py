from restart_bridge import *
import argparse
import math
import sympy as symbolic

STATE = Path(CONFIG["state_directory"])
sys.path.insert(0, str(STATE))
from run_restart import readouts, norms

SCHEMA = read(METRIC / "packet-schema.json")
COLUMNS = {name: 84 + index for index, name in enumerate(SCHEMA["global_columns"])}

def field(packet, name):
    return packet[..., COLUMNS[name]]

def source_paths(case):
    return EX.SPECTRUM / "runs/exact-grid/chunk-0384.npz" if case == "heavy" else EX.EARLY / "runs/final-bg8-start/cold.npz"

def saved_state(case):
    return load(STATE / (case + "-extension-64-terminal.npz"))

def coordinates(case, saved):
    first = int(saved["dimensions"][3])
    return [1, 0] if case == "cold" else [first + 2, first + 3, 0]

def own_source(case, state, background, model, prepared):
    if case == "cold":
        return np.array([float(prepared["cold_normalization"]) * state[0], 0., 0.])
    scale, field_value, velocity = model.unpack(background)
    mass = (scale * model.constants[7])**2
    perturbation, speed = state[:2]
    beta = scale / float(prepared["density0"])
    return beta * np.array([velocity[1] * speed + mass * field_value[1] * perturbation,
                           CONFIG["retained_comoving_wave"] * velocity[1] * perturbation,
                           velocity[1] * speed - mass * field_value[1] * perturbation])

def local_equation(case, model, background, external):
    scale, fields, velocity = model.unpack(background)
    hubble, masses = model.absolute_hubble(background)
    wave = CONFIG["retained_comoving_wave"]
    if case == "cold":
        matrix = np.array([[-model.constants[0] / (2 * scale * hubble), -wave / hubble], [0., 0.]])
        forcing = np.array([-external[0] / (2 * hubble), external[1] / 2])
    else:
        field_value, speed, mass = fields[1], velocity[1], masses[1]
        matrix = np.array([[0., 1., 0.],
                           [-(wave**2 + mass + speed * mass * field_value / (2 * hubble)),
                            -(2 * hubble + speed**2 / (2 * hubble)), -wave * speed / hubble],
                           [wave * speed / 2, 0., 0.]])
        forcing = np.array([0., -speed * external[0] / (2 * hubble), external[1] / 2])
    return matrix, forcing

def background_at(model, tau, physical):
    base = model.represented(tau)
    alpha, field_delta, velocity_delta = model.unpack(physical)
    old = model.pack(base["scale"], base["field"], base["velocity"])
    new = model.pack(base["scale"] * (1 + alpha), base["field"] + field_delta, base["velocity"] + velocity_delta)
    difference = model.difference_flow(base, physical, False)
    field_defect = base["field_first"] - base["velocity"]
    velocity_defect = base["velocity_first"] + 2 * base["hubble"] * base["velocity"] + base["mass"] * base["field"]
    rhs = model.pack(difference[0] / base["scale"] - base["rate"] * alpha + base["hubble"] - base["rate"],
                     difference[1::2] - field_defect, difference[2::2] - velocity_defect)
    return old, new, rhs

def external_from_packet(packet, case):
    material = packet[..., :84].reshape((*packet.shape[:-1], 7, 12))
    owned = 0 if case == "cold" else 6
    selected = [index for index in range(7) if index != owned]
    value = np.sum(material[..., selected, :][..., [3, 4]], axis=-2)
    slope = np.sum(material[..., selected, :][..., [7, 8]], axis=-2)
    return value, slope

def prepare():
    require(digest(STATE / "closeout.json") == CONFIG["state_seal"], "accepted restart seal")
    mapping = read(STATE / "inputs.json")
    mapping.update(read(STATE / "state-manifest.json"))
    mapping[str(STATE / "closeout.json")] = CONFIG["state_seal"]
    for name, item in read(STATE / "closeout.json")["artifacts"].items():
        mapping[str(STATE / name)] = item["sha256"]
    frozen = {}
    for case in CONFIG["cases"]:
        saved = saved_state(case)
        path = source_paths(case)
        with np.load(path) as archive:
            clock = archive["conformal_time"]
            requested = archive["requested_scale"]
        times = np.concatenate(([float(saved["tau"])], clock[CONFIG["start_index"]+1:CONFIG["last_index"]+1]))
        require(len(times) == 107 and np.all(np.diff(times) > 0), "106 original epochs")
        np.savez_compressed(ROOT / (case + "-clock.npz"), time=times,
                            requested_scale=requested[CONFIG["start_index"]:CONFIG["last_index"]+1])
        history = load(STATE / (case + "-complete-history.npz"))
        frozen[case] = {"source_norm": np.max(abs(history["source"]), axis=0).tolist(),
                        "readout_norm": norms(case).tolist(),
                        "metric_norm": load(METRIC / (case + "-reference-metric.npz"))["norms"].tolist(),
                        "own_state_norm": saved["state_units"][coordinates(case, saved)].tolist()}
        mapping[str(path)] = digest(path)
        mapping[str(ROOT / (case + "-clock.npz"))] = digest(ROOT / (case + "-clock.npz"))
    for path in ROOT.glob("*.py"):
        mapping[str(path)] = digest(path)
        compile(path.read_text(), str(path), "exec")
    for name in ("protocol.json", "DERIVATION.md"):
        mapping[str(ROOT / name)] = digest(ROOT / name)
    write(ROOT / "frozen-norms.json", frozen)
    mapping[str(ROOT / "frozen-norms.json")] = digest(ROOT / "frozen-norms.json")
    write(ROOT / "inputs.json", mapping)
    inputs()
    phi, speed, mass, wave, hubble, displacement, perturb_speed, eta, other_density, other_current = symbolic.symbols("Phi V mu2 k H f g eta D_other Q_other")
    density = speed * perturb_speed + mass * phi * displacement
    force = (density / (2 * wave) + other_density / (2 * wave) + eta) / hubble
    native = -2 * hubble * perturb_speed - (wave**2 + mass) * displacement - wave * speed * force
    reduced = -(wave**2 + mass + speed * mass * phi / (2 * hubble)) * displacement - (2 * hubble + speed**2 / (2 * hubble)) * perturb_speed - wave * speed * eta / hubble - speed * other_density / (2 * hubble)
    proof = {"heavy_self_gravity_elimination": symbolic.simplify(native - reduced) == 0,
             "eta_equation": symbolic.simplify((wave * speed * displacement + other_current) / 2 - (wave * speed * displacement / 2 + other_current / 2)) == 0}
    write(ROOT / "symbolic-result.json", {"checks": proof, "passed": all(proof.values())})
    require(all(proof.values()), "derived local generator")
    print(json.dumps({"frozen_inputs": len(mapping), "symbolic": proof}))

def predict(case, mode, steps):
    inputs()
    label = case + "-" + mode + "-" + str(steps)
    saved = saved_state(case)
    prepared, _, background, _, _ = EX.problem(case)
    model = retained_run.BG.Model(background, float(prepared["times"][0]))
    times = load(ROOT / (case + "-clock.npz"))["time"]
    selected = coordinates(case, saved)
    component_norm = saved["state_units"][selected]
    bg_units = saved["background_units"]
    width, count = len(bg_units), len(selected)
    old_initial, new_initial = saved["native_old"][selected], saved["native_coherent"][selected]
    initial = np.concatenate((saved["background_change"] / bg_units, old_initial / component_norm, new_initial / component_norm))
    external, slope = external_from_packet(saved["metric"], case)
    old_background, new_background, _ = background_at(model, float(times[0]), saved["background_change"])
    active = int(saved["dimensions"][1])
    native_old_rhs = saved["normalized_rhs"][:active] * saved["state_units"]
    native_new_rhs = native_old_rhs + saved["normalized_rhs"][active:2*active] * saved["delta_units"]
    checks = {}
    for branch, state, backdrop, expected in ((0, old_initial, old_background, native_old_rhs[selected]),
                                              (1, new_initial, new_background, native_new_rhs[selected])):
        matrix, forcing = local_equation(case, model, backdrop, external[branch])
        error = matrix @ state + forcing - expected
        scale = np.max(abs(matrix) @ abs(state) + abs(forcing) + abs(expected))
        checks["branch" + str(branch) + "_endpoint_rhs"] = ratio(maximum(error), scale, CONFIG["algebra_tolerance"])
    require(all(item["passed"] for item in checks.values()), "local equation exactly matches saved native endpoint")
    def rhs(tau, vector):
        old_background, new_background, background_rhs = background_at(model, tau, vector[:width] * bg_units)
        result = [background_rhs / bg_units]
        offset = tau - times[0] if mode == "linear" else 0.
        for branch, backdrop in enumerate((old_background, new_background)):
            own = vector[width+branch*count:width+(branch+1)*count] * component_norm
            matrix, forcing = local_equation(case, model, backdrop, external[branch] + offset * slope[branch])
            result.append((matrix @ own + forcing) / component_norm)
        return np.concatenate(result)
    divisions = np.concatenate(([times[0]], background.boundaries(float(times[0]), float(times[-1])), [times[-1]]))
    current = initial.copy()
    output = np.empty((len(times), len(initial)))
    output[0] = current
    evaluations = 0
    for left, right in zip(divisions[:-1], divisions[1:]):
        guard()
        selected_times = np.flatnonzero((times > left) & (times <= right))
        samples = np.unique(np.concatenate((times[selected_times], [right])))
        solution = solve_ivp(rhs, (float(left), float(right)), current, method="DOP853", rtol=CONFIG["rtol"],
                             atol=CONFIG["normalized_atol"], max_step=float(prepared["elapsed"][8]) / steps, t_eval=samples)
        require(solution.success, "frozen source predictor solve")
        output[selected_times] = solution.y[:, np.searchsorted(samples, times[selected_times])].T
        current = solution.y[:, -1]
        evaluations += solution.nfev
    sources = np.empty((len(times), 2, 3))
    backgrounds = np.empty((len(times), 2, width))
    states = np.empty((len(times), 2, count))
    for position, tau in enumerate(times):
        old_background, new_background, _ = background_at(model, float(tau), output[position, :width] * bg_units)
        for branch, backdrop in enumerate((old_background, new_background)):
            own = output[position, width+branch*count:width+(branch+1)*count] * component_norm
            states[position, branch] = own
            backgrounds[position, branch] = backdrop
            sources[position, branch] = own_source(case, own, backdrop, model, prepared)
    np.savez_compressed(ROOT / (label + "-prediction.npz"), time=times, state=states, source=sources,
                        background=backgrounds, external=external, slope=slope, normalized=output)
    report = {"case": case, "mode": mode, "steps": steps, "checks": checks, "evaluations": evaluations,
              "passed": all(item["passed"] for item in checks.values()), "no_future_live_source_read": True}
    write(ROOT / (label + "-prediction.json"), report)
    print(json.dumps(report), flush=True)
    inputs()

def freeze_predictions():
    inputs()
    mapping = {}
    for case in CONFIG["cases"]:
        for mode in ("constant", "linear"):
            for steps in CONFIG["steps"]:
                label = case + "-" + mode + "-" + str(steps)
                for suffix in ("-prediction.npz", "-prediction.json"):
                    path = ROOT / (label + suffix)
                    mapping[str(path)] = digest(path)
                require(read(ROOT / (label + "-prediction.json"))["passed"], "initial local identity")
    write(ROOT / "predictions-frozen.json", {"utc": datetime.now(timezone.utc).isoformat(), "files": mapping,
          "future_native_evolution_not_started": not any(ROOT.glob("*-live-*-start.json"))})
    print(json.dumps({"frozen_prediction_files": len(mapping)}))

def live(case, steps):
    inputs()
    frozen = read(ROOT / "predictions-frozen.json")
    require(frozen["future_native_evolution_not_started"], "prediction precedes live test")
    check_inputs(frozen["files"])
    label = case + "-live-" + str(steps)
    prepared, _, background, _, _ = EX.problem(case)
    with native_context(case, label) as (captured, metadata, sample):
        original = prefix(captured, case)
        previous = load(STATE / (case + "-full-capture.npz"))
        for name, values in captured.items():
            require(np.array_equal(values[:942], previous[name]), "previous942 owner prefix exact")
        system = MetricCoupled(case, prepared, background, original, metadata, sample)
        saved = restore(system, STATE / (case + "-extension-64-terminal.npz"))
        times = load(ROOT / (case + "-clock.npz"))["time"]
        require(np.array_equal(times[1:], captured["clock"][CONFIG["start_index"]-CONFIG["first_index"]+1:]), "native new clocks unchanged")
        current = saved["normalized"]
        records, states, evaluations = [], [], 0
        ends = list(range(CONFIG["batch_epochs"], len(times)-1, CONFIG["batch_epochs"])) + [len(times)-1]
        begin = 0
        for end in ends:
            batch_times = times[begin:end+1]
            chunk_label = label + "-epoch" + str(CONFIG["start_index"] + end)
            output, normalized, integration = integrate(system, float(batch_times[0]), float(batch_times[-1]),
                                                        current, batch_times, steps, chunk_label, cursor=False)
            current = normalized[-1]
            np.savez_compressed(ROOT / (chunk_label + "-history.npz"), time=batch_times, normalized=normalized, **output)
            checkpoint(system, float(batch_times[-1]), current, ROOT / (chunk_label + "-terminal.npz"))
            records.append({name: values if begin == 0 else values[1:] for name, values in output.items()})
            states.append(normalized if begin == 0 else normalized[1:])
            evaluations += integration["evaluations"]
            print(json.dumps({"case": case, "steps": steps, "saved_epoch": CONFIG["start_index"]+end}), flush=True)
            begin = end
        output = {name: np.concatenate([item[name] for item in records]) for name in records[0]}
        state = np.concatenate(states)
        observer = captured["observation_reference"][CONFIG["start_index"]-CONFIG["first_index"]:]
        native_control = np.column_stack((-CONFIG["retained_comoving_wave"] * (observer[:, 26] + observer[:, 5]) / observer[:, 28],
                                         observer[:, 9], observer[:, 21], observer[:, 20] - .75 * observer[:, 21],
                                         observer[:, 26] - .75 * observer[:, 24]))
        np.savez_compressed(ROOT / (label + ".npz"), time=times, normalized=state, native_control=native_control, **output)
        checkpoint(system, float(times[-1]), state[-1], ROOT / (label + "-terminal.npz"))
        write(ROOT / (label + "-result.json"), {"case": case, "steps": steps, "evaluations": evaluations, "batches": len(ends),
              "last_epoch": CONFIG["last_index"], "fresh_initial_rhs_exact": True, "prefix942_exact": True,
              "complete_terminal_saved": True})
    inputs()
    check_inputs(frozen["files"])

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "predict", "freeze", "live"))
    parser.add_argument("--case", choices=CONFIG["cases"])
    parser.add_argument("--mode", choices=("constant", "linear"), default="linear")
    parser.add_argument("--steps", type=int, choices=CONFIG["steps"], default=64)
    parser.add_argument("--receipt-tag", default="")
    args = parser.parse_args()
    label = args.command if args.command in ("prepare", "freeze") else args.case + "-" + (args.mode + "-predict" if args.command == "predict" else "live") + "-" + str(args.steps)
    with worker(label + args.receipt_tag):
        if args.command == "prepare":
            prepare()
        elif args.command == "predict":
            predict(args.case, args.mode, args.steps)
        elif args.command == "freeze":
            freeze_predictions()
        else:
            live(args.case, args.steps)

if __name__ == "__main__":
    main()

