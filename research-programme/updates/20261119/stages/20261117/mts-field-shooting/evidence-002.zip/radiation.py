import sys
from types import FunctionType
from finite import ROOT,EARLIER,CLOCK,Response,prepare,localcontext,bank,require,np
sys.path.insert(0,str(EARLIER))
from preparation_split import Consistent,Metric
from reversal import measure


class Test(Consistent):
    def configure_shot(self,model,amplitude):
        self.start=float(self.clock['bounds'][0])
        self.model=model
        self.real=self.native
        self.direct=Metric(self.direct,self)
        self.native=self.paired_sample
        self.lookup={}
        self.factor=amplitude

    def at(self,time,smooth):
        require(smooth,'explicit source')
        if time not in self.lookup:
            base,delta,dh=self.model.at(time-self.start)
            self.lookup[time]=(time,base,delta,dh)
        return self.lookup[time]

    def oldpacket(self,time):
        base=self.at(time,True)[1]
        packet=np.zeros(5)
        packet[:len(base)]=base
        return packet

    def amplification(self,base,delta):
        return self.factor*super().amplification(base,delta)


def run(case):
    bank.guard()
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/(case+'-radiation-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),
                method=bank.digest(ROOT/'TRANSFER.md'),code=bank.digest(ROOT/'radiation.py'),background=bank.digest(ROOT/'finite.py')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,case+'-radiation')
    with np.load(EARLIER/(case+'-clock.npz')) as data:
        clock={k:data[k] for k in ('bounds','width')}
    width=clock['bounds'][-1]-clock['bounds'][0]
    event=bank.read(EARLIER/'reversal-frozen.json')['window']
    original=Consistent.adaptive
    integrate=FunctionType(original.__code__,dict(original.__globals__,ROOT=ROOT),original.__name__,original.__defaults__,original.__closure__)
    with context as (capture,meta,sample):
        with np.load(EARLIER/(case+'-capture.npz')) as retained:
            require(all(np.array_equal(capture[key],retained[key]) for key in capture),'original native capture')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        for side in ('forward','backward'):
            for kind in ('smooth','binary'):
                with localcontext() as ctx:
                    ctx.prec=65
                    old,new,params=prepare(case,side,kind)
                    model=Response(old,new,params,width,64)
                for amplitude,steps in ((1.,32),(1.,64),(.5,64)):
                    tag=f'{case}-{side}-{kind}-amp{amplitude:g}'
                    test=Test(case,direct,clock,capture,None)
                    test.configure_shot(model,amplitude)
                    test.case=tag
                    integrate(test,steps,True)
                    if kind=='smooth' and amplitude==1:
                        result=measure(test,event,steps)
                        bank.save(ROOT/f'{tag}-{steps}-early-event.json',result)
                print(case,side,kind,'complete',flush=True)


if __name__=='__main__':
    run(sys.argv[1])
