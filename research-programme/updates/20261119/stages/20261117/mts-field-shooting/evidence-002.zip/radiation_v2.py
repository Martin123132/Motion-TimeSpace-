import sys
from types import FunctionType
from scipy.integrate import solve_ivp
from radiation import Test, Metric, Consistent, bank, require, np, ROOT, EARLIER, prepare, Response, localcontext, measure


def short_response(problem,extent,steps):
    start=problem.start
    initial=problem.initial
    bg=problem.at(start,True)
    flow=problem.flow(bg,initial,1.)
    slip=initial[3]-.75*initial[problem.photon]
    coefficient=-2*bg[3]*(1+initial[3]/slip)
    require(bg[2][0]==0 and flow[-2]==0 and coefficient!=0,'exact matching of initial scale and material state')
    units=np.r_[problem.direct.state_units,problem.direct.delta_units,flow[-3]*extent,flow[-3]*extent*1e-5]
    stop=start+extent
    step=(stop-start)/steps
    def rhs(time,coords):
        return problem.flow(problem.at(time,True),np.r_[coords*units,0.],1.)[:-1]/units
    sol=solve_ivp(rhs,(start,stop),initial[:-1]/units,method='DOP853',rtol=1e-10,atol=1e-12,first_step=step,max_step=step,dense_output=True)
    require(sol.success,'resolved early evolution')
    rows=[]
    for divisor in (512,256,128,64,32,16,8,4,2,1):
        time=start+(stop-start)/divisor
        state=sol.sol(time)*units
        rate=problem.source(time,state,True)
        t=time-start
        rows.append(dict(elapsed=t,rate=rate,net=state[-1],relative_rate_slope=rate/(flow[-3]*t),relative_net_slope=2*state[-1]/(flow[-3]*t*t)))
    return dict(predicted_relative_rate_slope=coefficient,delta_hubble=bg[3],original_rate=flow[-3],samples=rows)


def main(case):
    bank.guard()
    require(case in ('cold','heavy'),'known model')
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    tag=case+'-radiation-v2'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),
        code=bank.digest(ROOT/'radiation_v2.py'),source=bank.digest(ROOT/'radiation.py'),background=bank.digest(ROOT/'finite.py'),method=bank.digest(ROOT/'TRANSFER.md')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(EARLIER/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in ('bounds','width','constants')}
    bounds=clock['bounds']
    width=bounds[-1]-bounds[0]
    event=bank.read(EARLIER/'reversal-frozen.json')['window']
    fn=Consistent.adaptive
    integrate=FunctionType(fn.__code__,dict(fn.__globals__,ROOT=ROOT),fn.__name__,fn.__defaults__,fn.__closure__)
    with context as (capture,meta,sample):
        with np.load(EARLIER/(case+'-capture.npz')) as retained:
            require(set(capture)==set(retained.files) and all(np.array_equal(capture[key],retained[key]) for key in capture),'identical full physical capture')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        for side in ('forward','backward'):
            for kind in ('smooth','binary'):
                with localcontext() as ctx:
                    ctx.prec=65
                    old,new,params=prepare(case,side,kind)
                    model=Response(old,new,params,width,64)
                for amplitude,steps in ((1.,32),(1.,64),(.5,64)):
                    label=f'{case}-{side}-{kind}-amp{amplitude:g}'
                    test=Test(case,direct,clock,capture,None)
                    test.configure_shot(model,amplitude)
                    test.grid=bounds
                    test.case=label
                    integrate(test,steps,True)
                    if kind=='smooth' and amplitude==1:
                        bank.save(ROOT/f'{label}-{steps}-early-event.json',measure(test,event,steps))
                        bank.save(ROOT/f'{label}-{steps}-early-slopes.json',short_response(test,event,steps))


if __name__=='__main__':
    main(sys.argv[1])
