from fractions import Fraction
from shoot import ROOT,CLOCK,bank,np,require


def check():
    bank.guard()
    owner=bank.psutil.Process()
    bank.save(ROOT/'seed-series-owner.json',dict(pid=owner.pid,created=owner.create_time(),command=owner.cmdline()))
    coefficient=Fraction(11,14)/4-Fraction(9,8)/5
    native=Fraction(2,4)-Fraction(1,5)
    require(coefficient==-Fraction(1,35) and coefficient-native==-Fraction(23,70) and 7*coefficient/6-native==-Fraction(1,3),'exact regular coefficients')
    def solve(load,order):
        roots,weights=np.polynomial.legendre.leggauss(order)
        def integ(fun,last):
            return .5*last*sum(w*fun(.5*last*(1+x)) for x,w in zip(roots,weights))
        scale=lambda time:time*(1+load*time/4)
        velocity=lambda time:-integ(lambda t:scale(t)**4,time)/scale(time)**2
        cprime=lambda time:2*time-3*load*time*time/5
        delta_v=lambda time:integ(lambda t:scale(t)**2*cprime(t)*velocity(t),time)/scale(time)**2
        direct=np.array([integ(delta_v,1.),delta_v(1.)])
        raw=-(1+load/4)**2*(1-load/5)/105*np.array([1.,6.])
        return direct/raw
    trials=[]
    for load in (.002,.001,.0005):
        first=(solve(load,8)-solve(-load,8))/(2*load)
        second=(solve(load,14)-solve(-load,14))/(2*load)
        target=np.array([-23/70,-1/3])
        error=max((abs(second-target)+abs(first-second))/abs(target))
        require(error<bank.TOL,'independent integral coefficient')
        trials.append(dict(matter_loading=load,slopes=second.tolist(),error=error))
    sources={}
    for case in ('cold','heavy'):
        with np.load(CLOCK/(case+'-prepared.npz')) as packet:
            const=packet['constants']
        begin=float(bank.read(ROOT/(case+'-primordial-frozen.json'))['initial'][0])
        early=ROOT.parent/'mts-live-metric-state-20261112'/(case+'-initial-state.npz')
        with np.load(early) as f:
            wave=f['wave'][0]
        rad=sum(const[2:4])+sum(const[14:14+int(const[4])])
        om=sum(const[:2])/np.sqrt(3*rad)
        alpha=np.sqrt(rad/3)
        time=2*begin/alpha/(1+np.sqrt(1+om*begin/alpha))
        sources[case]=dict(earliest_background_scale=begin,approximate_conformal_age=time,omega_tau=om*time,
                   k_tau_squared=(wave*time)**2,largest_am_tau_squared=(begin*max(const[6:7 if case=='cold' else 8])*time)**2,
                   native_start_verified=False)
    bank.save(ROOT/'regular-seed-verification.json',dict(code=bank.digest(ROOT/'regular_seed.py'),derivation=bank.digest(ROOT/'REGULAR-SEED.md'),
                  tests=trials,physical_scales=sources,scope='first matter-loading term only; k-dependent next order not supplied'))
    print(trials[-1],sources)


if __name__=='__main__':
    check()
