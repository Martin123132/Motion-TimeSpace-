import sys
from datetime import datetime,timezone
from shoot import ROOT,EARLIER,CLOCK,Path,np,bank,require


def evidence(path):
    return dict(bytes=path.stat().st_size,sha256=bank.digest(path))


def compare(case,prefix,bounds,active):
    curves=[]
    for amp,steps in ((1,32),(1,64),(.5,64)):
        name=f'{case}-{prefix}-amp{amp:g}-smooth-{steps}-adaptive'
        row=bank.read(ROOT/(name+'.json'))
        with np.load(ROOT/(name+'.npz')) as data:
            require(all(np.all(np.isfinite(data[key])) for key in data.files),'finite saved arrays')
            require(row['status']=='complete' and row['last']==data['last_time']==bounds[-1] and row['reached_fraction']==1,'physical endpoint')
            require(np.array_equal(data['bounds'],bounds) and np.all(np.diff(data['accepted_ends'])>0),'all original times in order')
            require(not np.any(data['states'][0,active:]) and row['signed']==data['states'][-1,-1]==data['last_state'][-1],'true initial and terminal states')
            old=data['states'][-1,-2]
        q=row['readout']
        require(q['crossings4']==q['crossings8'] and q['variation8']>=abs(row['signed'])*(1-1e-12),'consistent crossing and variation')
        err=sum(abs(q[key]-q['variation8']) for key in ('variation4','absolute_gauss3','absolute_gauss7'))+abs(q['signed_gauss7']-row['signed'])
        curves.append((row['signed'],q['variation8'],err))
    low,fine,half=curves
    parts=[(abs(t[0]-fine[0])+abs(t[1]-fine[1]))/abs(fine[0]) for t in (low,half)]
    parts.append(sum(t[2] for t in curves)/abs(fine[0]))
    return dict(signed=fine[0],variant=half[0],relative_to_original=fine[0]/old,parts=parts,budget=sum(parts),
                arithmetic_pass=sum(parts)<=bank.TOL)


def verify(case):
    with np.load(EARLIER/(case+'-clock.npz')) as clock,np.load(EARLIER/(case+'-capture.npz')) as data:
        active=int(data['signature'][0,1])
        bounds=clock['bounds']
    raws=bank.read(ROOT/(case+'-score.json'))
    require(raws['frozen_sha256']==bank.digest(ROOT/(case+'-frozen.json')),'directional predictions hash')
    holdouts={}
    for key,rows in raws['results'].items():
        require(len({row['index'] for row in rows})==len(rows)==18 and all(r['passes'] for r in rows) and sum(r['scope']=='outside_previous' for r in rows)==7,'genuine directional tests')
        holdouts[key]=dict(knots=18,outside=7,amp=max(r['field_amp_budget'] for r in rows),velocity=max(r['velocity_own_budget'] for r in rows),
                           largest_word_error=max(abs(r['field_word_error']) for r in rows))
    names=[x+'-'+y for x in ('forward','backward') for y in ('smooth','binary')]
    for pre in ('','probe-'):
        names.extend(pre+post for post in ('scale06-smooth','time06-smooth','scale06-binary'))
    names.append('probe-normalized-smooth')
    curves={name:compare(case,name,bounds,active) for name in names}
    main=curves['probe-scale06-smooth']
    separate=curves['probe-time06-smooth']
    source=bank.read(ROOT/(case+'-seed-refinement.json'))
    require(source['frozen']==bank.digest(ROOT/(case+'-seed-refined-frozen.json')) and all(item['passed'] for item in source['tests'].values()),'qualified primordial source')
    independent=abs(separate['signed']/main['signed']-1)
    final_error=main['budget']+separate['budget']+independent
    require(final_error<bank.TOL,'two independent global preparations and two full perturbation resolutions')
    check=bank.read(ROOT/(case+'-energy-probe-fixtures.json'))
    require(len(check)==6 and max(item['error'] for item in check)<bank.TOL,'literal native tests')
    roots=bank.read(ROOT/(case+'-physical-roots.json'))
    root_fine=roots['rows'][case+'-probe-scale06-smooth-amp1-smooth-64-adaptive']
    errors={}
    for key,reference in root_fine['roots'].items():
        main_time=reference[0]
        trials={label:abs(row['roots'][key][0]/main_time-1) for label,row in roots['rows'].items()}
        numerical=sum(err for label,err in trials.items() if 'normalized' not in label)
        errors[key]=dict(time=main_time,numerical_spread_sum=numerical,passes=numerical<bank.TOL,initial_representation=trials[case+'-probe-normalized-smooth-amp1-smooth-64-adaptive'])
    require(len(roots['rows'])==9 and root_fine['original_sign']==(1 if case=='cold' else -1),'both baseline and MTS represented')
    event=bank.read(ROOT/(case+'-scale06-smooth-amp1-64-early-slopes.json'))
    onset=event['predicted_relative_rate_slope']
    short=event['samples'][0]
    relative=max(abs(short[key]/onset-1) for key in ('relative_rate_slope','relative_net_slope'))
    current=bank.read(ROOT/(case+'-slow-current.json'))
    require(all(row['resolved_against_primordial'] for row in current['checks'].values()) and current['quadrature_max']<=bank.TOL,'current reproduces both launches and the matter event')
    replay=bank.read(ROOT/(case+'-slow-replay.json'))['trials']
    require(all(max(abs(float(value)) for value in replay[label]['error_over_current'])<=bank.TOL for label in ('phase_only','combined08','combined04','sparse_combined04','velocity_tolerance_only')),'resolved independent field equations')
    require(abs(replay['retained_style']['error_over_archive'][1])<bank.TOL,'original-style conditional replay of archived velocity')
    return dict(forecasts=holdouts,response=curves,combined_arithmetic_budget=final_error,coordinate_spread=independent,
              representation_spread=abs(curves['probe-normalized-smooth']['signed']/main['signed']-1),
              binary_geometry_spread=abs(curves['probe-scale06-binary']['signed']/main['signed']-1),
              local_launch_spread=abs(curves['backward-smooth']['signed']/curves['forward-smooth']['signed']-1),
              earlier_representation=bank.read(EARLIER/(case+'-paired-smooth-smooth-64-adaptive.json'))['signed'],
              roots=errors,initial_onset=onset,smallest_time_fractional_slope_error=relative,fixture_max=max(item['error'] for item in check),
              normalized_current=current['checks']['event'],delta_h_by_field=current['scalar_contributions'],initial_sign=root_fine['original_sign'])


def check():
    bank.guard()
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    bank.save(ROOT/'verification-owner.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    bank.check_seals()
    earlier=bank.read(EARLIER/'closeout.json')['files']
    require(bank.digest(EARLIER/'closeout.json')=='1de083ef739d9fa44bb1cfb7bc45121900d506b44f6bbcd4c3a7d8ae259e12d3','prior stage retained')
    for name,item in earlier.items():
        require(evidence(EARLIER/name)==item,'full prior stage intact')
    physical=bank.read(bank.SOURCE/'inputs.json')
    for name,expected in physical.items():
        require(bank.digest(Path(name))==expected,'physical historical input unchanged')
    for path in sorted(ROOT.glob('*.py')):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    for case in ('cold','heavy'):
        for name,expected in bank.read(CLOCK/(case+'-input.json'))['files'].items():
            require(bank.digest(Path(name))==expected,'original native source clock')
    absolute=bank.read(ROOT/'absolute-background-verification.json')['rows']
    require(len(absolute)==8 and all(row['passes'] for row in absolute.values()),'eight independent absolute field evolutions')
    reports={case:verify(case) for case in ('cold','heavy')}
    require(all(len([path for path in ROOT.glob('*-adaptive.'+ext) if '-sector-' not in path.name])==66 for ext in ('json','npz')),'all and only main radiation comparisons excluding the separate sector experiment')
    bank.save(ROOT/'verification.json',dict(cases=reports,tolerance=bank.TOL,algebra_tolerance=bank.ALG,complete_native_trials=66,upstream_hashes=len(physical),
                  predecessor_artifacts=len(earlier),scope='private early-interval physical comparison conditional on cosmological and material preparations'))
    for name,row in reports.items():
        print(name,{k:row[k] for k in ('combined_arithmetic_budget','representation_spread','binary_geometry_spread','local_launch_spread','roots','smallest_time_fractional_slope_error')})


def close():
    bank.guard()
    require(all((ROOT/name).exists() for name in ('verification.json','sector-verification.json','RESULTS.md','SLOW-CURRENT.md','OPERATOR.md')),'verified and documented')
    require(not list(ROOT.rglob('__pycache__')),'no temporary interpreter cache')
    owners=[]
    for path in sorted(ROOT.glob('*-owner.json')):
        row=bank.read(path)
        try:
            other=bank.psutil.Process(row['pid'])
            require(abs(other.create_time()-row['created'])>.01,'recorded stage worker still present: '+path.name)
        except bank.psutil.NoSuchProcess:
            pass
        owners.append(dict(receipt=path.name,pid=row['pid'],created=row['created'],command=row['command'],exited=True))
    for path in ROOT.glob('*-capture.npz'):
        item=bank.read(ROOT/(path.name.replace('-capture.npz','-owner-release.json')))
        require(item['cleared'] and item['native_reference_released'],'all native contexts released')
    closer=bank.psutil.Process()
    bank.save(ROOT/'cleanup.json',dict(owners=owners,closer=dict(pid=closer.pid,created=closer.create_time(),command=closer.cmdline()),compiler='Temporary Q: compiler alias verified against its exact target before removal, absence checked by creating shell. First two compiler commands exited without producing the DLL.',continuing_jobs=[]))
    inventory={path.name:evidence(path) for path in sorted(ROOT.iterdir()) if path.is_file()}
    bank.save(ROOT/'closeout.json',dict(finished=datetime.now(timezone.utc).isoformat(),files=inventory,scope='conditional early radiation and physical scalar background replay; no public or final-spectrum claim'))
    print('sealed',len(inventory),'files',sum(item['bytes'] for item in inventory.values()),bank.digest(ROOT/'closeout.json'))


if __name__=='__main__':
    if sys.argv[1]=='verify':
        check()
    elif sys.argv[1]=='close':
        close()
