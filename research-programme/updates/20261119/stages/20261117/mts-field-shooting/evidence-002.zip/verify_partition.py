from verify_stage import compare,ROOT,EARLIER,np,bank,require


def main():
    bank.guard()
    proc=bank.psutil.Process()
    bank.save(ROOT/'sector-verification-owner.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    rows={}
    for case in ('cold','heavy'):
        with np.load(EARLIER/(case+'-clock.npz')) as old,np.load(EARLIER/(case+'-capture.npz')) as cap:
            bounds=old['bounds']
            active=int(cap['signature'][0,1])
        require(bank.read(ROOT/(case+'-partition-null.json'))==dict(epochs=len(bounds),active=active,all_zero=True),'null controls at all original event times')
        full=compare(case,'probe-scale06-smooth',bounds,active)
        require(full==bank.read(ROOT/'verification.json')['cases'][case]['response']['probe-scale06-smooth'],'original arithmetic unchanged')
        if case=='cold':
            rows[case]=dict(slow=full,null=0,reused=True)
            continue
        slow,heavy=[compare(case,'sector-'+name,bounds,active) for name in ('slow','heavy')]
        remainder=full['signed']-slow['signed']-heavy['signed']
        budget=sum(abs(item['signed'])*item['budget'] for item in (full,slow,heavy))
        rows[case]=dict(slow=slow,heavy=heavy,full=full,null=0,slow_fraction=slow['signed']/full['signed'],heavy_fraction=heavy['signed']/full['signed'],
            mixed_residual=remainder,mixed_relative=remainder/full['signed'],mixed_numerical_budget=budget,mixed_resolved=abs(remainder)>budget)
    require(len(list(ROOT.glob('*-adaptive.npz')))==72 and len(list(ROOT.glob('*-adaptive.json')))==72,'72 complete native comparisons including 6 distinct component projections')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    bank.save(ROOT/'sector-verification.json',dict(cases=rows,tolerance=bank.TOL))
    print(rows['heavy'])


if __name__=='__main__':
    main()
