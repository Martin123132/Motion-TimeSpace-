import math
from scipy.interpolate import CubicSpline,PchipInterpolator
from shoot import ROOT,CLOCK,Model,bank,np,require,D,exact,localcontext
from background_check import dynamics


def current(grid,field,expansion,seed_velocity,mass,unit,event,step,shape,order):
    indices=np.unique(np.r_[np.arange(0,len(grid),step),len(grid)-1])
    nodes=grid[indices]
    interpolator=CubicSpline if shape=='cubic' else PchipInterpolator
    position=interpolator(nodes,field[indices])
    log_h=interpolator(nodes,np.log(expansion[indices]))
    edges=np.unique(np.r_[nodes[nodes<=max(event)],event])
    begin=edges[:-1]
    half=np.diff(edges)/2
    roots,weights=np.polynomial.legendre.leggauss(order)
    samples=begin[:,None]+half[:,None]*(roots+1)
    integrand=np.exp(3*samples-.5*log_h(samples))*position(samples)*(mass**2/unit)
    cells=half*(integrand@weights)
    cumulative=np.r_[0.,np.cumsum(cells)]
    vel=(np.exp(2*grid[0])*seed_velocity-cumulative[np.searchsorted(edges,event)])/np.exp(2*event)
    require(np.isfinite(vel).all(),'finite current predicted from expansion and field')
    return vel


def run(case):
    model=Model(case)
    unit=70/299792.458
    with np.load(model.table) as data:
        grid,fields,expansion,speeds=[data[name] for name in ('efold','phi_s','expansion2','phidot_s')]
    event=float(model.event)
    seeds=[float(min(model.knots.values())),event,float(max(model.knots.values()))]
    cut=np.searchsorted(grid,max(seeds))+4
    grid,fields,expansion,speeds=[array[:cut] for array in (grid,fields,expansion,speeds)]
    probes=np.linspace(grid[0],event,26)[1:]
    targets=np.unique(np.r_[probes,seeds])
    mass=float(model.masses[0])
    result={}
    for tag,step,shape,order in (('primary',1,'cubic',8),('sparse',2,'cubic',8),('pchip',1,'pchip',8),('lower',1,'cubic',4)):
        result[tag]=current(grid,fields,expansion,speeds[0],mass,unit,targets,step,shape,order)
    hypothesis=result['primary']
    error=sum(abs(value-hypothesis) for label,value in result.items() if label!='primary')/abs(hypothesis)
    analytic=current(grid,np.ones_like(fields),np.exp(-4*grid),0.,1.,1.,targets,1,'cubic',4)
    truth=-(np.exp(5*targets)-np.exp(5*grid[0]))/(5*np.exp(2*targets))
    control=float(max(abs(analytic/truth-1)))
    require(control<bank.ALG and max(error)<bank.TOL,'closed form and numerical quadrature')
    archived=CubicSpline(grid,speeds)(targets)
    extension=bank.read(ROOT/(case+'-seed-refinement.json'))
    with np.load(CLOCK/(case+'-prepared.npz')) as packet:
        smooth=[exact(one)+exact(two) for one,two in zip(packet['smooth_high'][0],packet['smooth_low'][0])]
    archive_event=float(smooth[2])
    archive_native_sample=archived[np.searchsorted(targets,event)]
    archived[np.searchsorted(targets,event)]=archive_event
    joined={}
    for point,label in zip(seeds,('forward_seed','event','backward_seed')):
        index=np.searchsorted(targets,point)
        chosen=list(map(D,extension['states'][label]['scale06']))
        inferred=float(chosen[2])
        joined[label]=dict(predicted=hypothesis[index],archived=archived[index],primordial=inferred,
            predicted_minus_archived_over_archive=(hypothesis[index]-archived[index])/abs(archived[index]),
            predicted_minus_primordial_over_primordial=(hypothesis[index]-inferred)/abs(inferred),
            relative_numerical_budget=error[index],resolved_against_primordial=abs(hypothesis[index]/inferred-1)+error[index]<bank.TOL)
    idx=np.searchsorted(targets,probes)
    survey=[dict(scale=math.exp(point),predicted=hypothesis[index],archived=archived[index],relative=(hypothesis[index]-archived[index])/abs(archived[index]),budget=error[index]) for point,index in zip(probes,idx)]
    chosen=list(map(D,extension['states']['event']['scale06']))
    _,hs,source=dynamics(chosen,model.const)
    _,hq,comparison=dynamics(smooth,model.const)
    parts=[float((new-old)/(3*(hs+hq))) for old,new in zip(source,comparison)]
    require(abs(sum(parts)/float(hq-hs)-1)<bank.ALG,'signed partition of independent total energy at fixed scale')
    bank.save(ROOT/(case+'-slow-current.json'),dict(method=bank.digest(ROOT/'SLOW-CURRENT.md'),code=bank.digest(ROOT/'slow_current.py'),source=bank.digest(model.table),
               analytic_relative_max=control,quadrature_max=float(max(error)),event_velocity_native_cubic=archive_native_sample,
               checks=joined,screen=survey,initial_hubble_difference=float(hq-hs),scalar_contributions=parts))
    print(case,joined['event'],'delta H by scalar',parts,flush=True)


if __name__=='__main__':
    bank.guard()
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    bank.save(ROOT/'current-owner.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    with localcontext() as ctx:
        ctx.prec=72
        for branch in ('cold','heavy'):
            run(branch)
