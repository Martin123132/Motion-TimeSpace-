import math
from scipy.integrate import solve_ivp
from scipy.interpolate import CubicSpline
from shoot import ROOT,Model,np,bank,require,localcontext


def run(case):
    model=Model(case)
    unit=70/299792.458
    mass=float(model.masses[0])/unit
    root6=math.sqrt(6.)
    with np.load(model.table) as archive:
        grid=archive['efold']
        expansion=archive['expansion2']
        phi=archive['phi_s'][0]
        vel=archive['phidot_s'][0]
    targets=np.array([float(min(model.knots.values())),float(model.event),float(max(model.knots.values()))])
    limit=targets[-1]+.045
    last=np.searchsorted(grid,limit)+4
    grid,expansion=grid[:last],expansion[:last]
    saved=bank.read(ROOT/(case+'-slow-current.json'))['checks']
    keys=('forward_seed','event','backward_seed')
    truth=np.array([saved[name]['predicted'] for name in keys])
    original=np.array([saved[name]['archived'] for name in keys])
    output={}
    for mode,tolerance,phase,stride in [('retained_style',1e-13,None,1),('velocity_tolerance_only',1e-25,None,1),('phase_only',1e-13,.4,1),
                                  ('combined08',1e-25,.8,1),('combined04',1e-25,.4,1),('sparse_combined04',1e-25,.4,2)]:
        bank.guard()
        indices=np.unique(np.r_[np.arange(0,len(grid),stride),len(grid)-1])
        interp=CubicSpline(grid[indices],.5*np.log(expansion[indices]))
        def func(efold,state):
            loge=float(interp(efold))
            friction=3+float(interp(efold,1))
            return [state[1],-friction*state[1]-mass**2*math.exp(-2*loge)*state[0]]
        start=grid[0]
        initial=np.array([phi/root6,vel/(root6*unit*math.exp(start)*math.sqrt(expansion[0]))])
        edges=np.r_[start,limit] if phase is None or case=='cold' else np.r_[np.arange(start,limit,.5),limit]
        predictions=np.full(3,np.nan)
        calls=0
        maxphase=0.
        for left,right in zip(edges,edges[1:]):
            bank.guard()
            cap=.04
            if phase and case=='heavy':
                samples=np.r_[left,grid[(grid>left)&(grid<right)],right]
                omega=float(model.masses[1])/unit*np.exp(-interp(samples))
                cap=min(cap,phase/(1.1*max(omega)))
            sol=solve_ivp(func,(left,right),initial,method='DOP853',rtol=3e-11,atol=np.array([1e-13,tolerance]),max_step=cap,dense_output=True)
            require(sol.success,'original variable evolution')
            calls+=sol.nfev
            if case=='heavy':
                maxphase=max(maxphase,max(np.diff(sol.t)*float(model.masses[1])/unit*np.exp(-interp((sol.t[1:]+sol.t[:-1])/2))))
            mask=(targets>=left)&(targets<=right)
            if any(mask):
                predictions[mask]=root6*unit*np.exp(targets[mask]+interp(targets[mask]))*sol.sol(targets[mask])[1]
            initial=sol.y[:,-1]
        require(np.isfinite(predictions).all(),'three target velocities returned')
        output[mode]=dict(velocity=predictions.tolist(),error_over_current=((predictions-truth)/abs(truth)).tolist(),
                          error_over_archive=((predictions-original)/abs(original)).tolist(),rhs_calls=calls,largest_sampled_phase=maxphase)
        print(case,mode,'event vs current',output[mode]['error_over_current'][1], 'event vs archive',output[mode]['error_over_archive'][1],flush=True)
    bank.save(ROOT/(case+'-slow-replay.json'),dict(method=bank.digest(ROOT/'REPLAY.md'),code=bank.digest(ROOT/'slow_replay.py'),
              input_sha=bank.digest(model.table),targets=targets.tolist(),trials=output))


if __name__=='__main__':
    import sys
    bank.guard()
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    bank.save(ROOT/(sys.argv[1]+'-slow-replay-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    with localcontext() as ctx:
        ctx.prec=65
        run(sys.argv[1])
