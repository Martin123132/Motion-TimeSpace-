import json
import math
import os
import sys
from decimal import Decimal as D,localcontext
from functools import lru_cache
from pathlib import Path
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
CLOCK=POST/'mts-matched-clock-precision-20261117'
EARLIER=POST/'mts-common-continuity-20261117'
sys.path.insert(0,str(POST/'mts-elastic-source-interval-quadrature-20261117'))
import interval_probe as bank
from interval_probe import np,require
from scipy.integrate import solve_ivp
from scipy.optimize import brentq


def exact(x):
    return D.from_float(float(x))


def words(x):
    return tuple((exact(x)+exact(np.nextafter(float(x),side)))/2 for side in (-np.inf,np.inf))


class Model:
    def __init__(self,case):
        self.case=case
        source=bank.read(CLOCK/f'{case}-input.json')
        self.table=next(Path(f) for f in source['files'] if Path(f).name==case+'.npz')
        self.raw=next(Path(f) for f in source['files'] if f.endswith(case+'-native-clock.npz'))
        for f in (self.table,self.raw):
            require(bank.digest(f)==source['files'][str(f)],'archived source hash')
        with np.load(self.raw) as d:
            self.const=list(map(exact,d['constants']))
        self.num=1 if case=='cold' else 2
        with np.load(CLOCK/f'{case}-prepared.npz') as data:
            self.event=(exact(data['smooth_high'][0,0])+exact(data['smooth_low'][0,0])).ln()
        with np.load(self.table) as data:
            grid=data['efold' if case=='cold' else 'heavy_efold']
            self.index=int(np.searchsorted(grid,float(self.event))-1)
            self.knots={i:exact(grid[i]) for i in range(self.index-5,self.index+14)}
            self.seeds={}
            for index in (self.index-5,self.index+13):
                sample=[]
                for suffix in ('s',) if case=='cold' else ('s','h'):
                    selected=int(np.searchsorted(data['efold'],grid[index])) if suffix=='s' else index
                    require((data['efold'] if suffix=='s' else grid)[selected]==grid[index],'coincident original seed knot, no interpolated field')
                    sample.extend([exact(data['phi_'+suffix][selected]),exact(data['phidot_'+suffix][selected])])
                self.seeds[index]=sample
        self.masses=self.const[6:6+self.num]
        self.thermal=D(5)/(7*exact(math.pi)**2)

    @lru_cache(maxsize=60000)
    def environment(self,n):
        a=n.exp()
        matter=(self.const[0]+self.const[1])/a
        radiation=(self.const[2]+self.const[3])/a**2
        for j in range(int(self.const[4])):
            x=a*self.const[8+j]
            require(0<x<D('.3')+70*D('1.01')/1399,'thermal branch')
            rho=1+self.thermal*x*x
            if x>=D('.01'):
                rho+=x**4*(D('.01099926669')*x.ln()-D('.003492416767')-D('.005866275571')*x)
            radiation+=self.const[14+j]*rho/a**2
        return a,matter+radiation,[(a*mass)**2 for mass in self.masses]

    def physical(self,seed,n0,n,y,form):
        a,standard,m2=self.environment(n)
        fields=[old+delta for old,delta in zip(seed[::2],y[1::2])]
        v=[(self.environment(n0)[0]**2*old+d)/a**2 if form=='momentum' else old+d for old,d in zip(seed[1::2],y[2::2])]
        H=((standard+sum((speed**2+m*field**2)/2 for speed,m,field in zip(v,m2,fields)))/3).sqrt()
        return a,fields,v,m2,H

    def step(self,left,right,y,seed,n0,form,levels):
        span=right-left
        def rhs(n,state):
            a,fields,v,m2,h=self.physical(seed,n0,n,state,form)
            flux=[1/h]
            for f,speed,m in zip(fields,v,m2):
                flux.extend((speed/h,-a*a*m*f/h if form=='momentum' else -2*speed-m*f/h))
            return flux
        base=rhs(left,y)
        rows=[]
        for j in range(1,levels+1):
            count=2*j
            h=span/count
            last=y
            curr=[a+h*b for a,b in zip(y,base)]
            for m in range(1,count):
                last,curr=curr,[a+2*h*b for a,b in zip(last,rhs(left+m*h,curr))]
            row=[[(a+b+h*d)/2 for a,b,d in zip(curr,last,rhs(right,curr))]]
            for order in range(1,j):
                ratio=(D(j)/(j-order))**2-1
                row.append([x+(x-z)/ratio for x,z in zip(row[-1],rows[-1][order-1])])
            rows.append(row)
        return rows[-1][-1]

    def solve(self,idx,seed,form,sub,levels):
        n0=self.knots[idx]
        labels=dict(self.knots,event=self.event)
        sequence=sorted(labels,key=labels.get,reverse=idx==max(self.knots))
        require(sequence[0]==idx,'outside launch')
        last=n0
        state=[D(0)]*(1+len(seed))
        output={}
        for label in sequence:
            n=labels[label]
            if n!=last:
                for i in range(sub):
                    state=self.step(last+(n-last)*i/sub,last+(n-last)*(i+1)/sub,state,seed,n0,form,levels)
            a,fields,v,_,h=self.physical(seed,n0,n,state,form)
            output[str(label)]=[state[0],a,*[value for pair in zip(fields,v) for value in pair],h]
            last=n
        return output

    def time_test(self,idx,reference):
        n0=self.knots[idx]
        seed=self.seeds[idx]
        keys=list(reference)
        sign=1 if idx==min(self.knots) else -1
        horizon=1.07*abs(float(reference[keys[-1]][0]))
        params=np.array(self.const,float)
        masses=np.asarray(self.masses,float)
        initial=np.asarray(seed,float)
        base=float(n0.exp())
        delta_n=abs(float(self.knots[int(keys[-1])]-n0))
        amp=np.hypot(initial[::2],initial[1::2]/(base*masses))
        bounds=np.zeros(1+len(seed))
        bounds[0]=delta_n
        bounds[1::2]=np.maximum(np.abs(initial[1::2])*horizon,amp*np.minimum((horizon*base*masses)**2,1.))
        bounds[2::2]=np.maximum(amp*(base*masses)**2*horizon, np.abs(initial[1::2])*delta_n)
        def rhs(elapsed,normalized):
            offset=normalized*bounds
            a=base*math.exp(offset[0])
            f,v=(initial+offset[1:]).reshape(-1,2).T
            m2=(a*masses)**2
            rest=sum(params[:2])/a+sum(params[2:4])/a**2
            for j in range(int(params[4])):
                x=a*params[8+j]
                rho=1+5/(7*math.pi**2)*x**2
                if x>=.01:
                    rho+=x**4*(.01099926669*math.log(x)-.003492416767-.005866275571*x)
                rest+=params[14+j]*rho/a**2
            H=math.sqrt((rest+sum(v*v+m2*f*f)/2)/3)
            return np.r_[H,np.column_stack((v,-2*H*v-m2*f)).ravel()]/bounds
        sol=solve_ivp(rhs,(0,sign*horizon),np.zeros_like(bounds),method='DOP853',rtol=1e-10,atol=1e-12,max_step=horizon/128,dense_output=True)
        require(sol.success,'independent conformal-time integration')
        rows={}
        for key in keys[1:]:
            coord=self.event if key=='event' else self.knots[int(key)]
            target=float(coord-n0)
            t=brentq(lambda t:sol.sol(t)[0]*bounds[0]-target,*sorted((0.,sign*horizon)),xtol=1e-16)
            values=sol.sol(t)*bounds
            ref=reference[key]
            err=np.abs(values[1:]-np.array([float(val-initialval) for val,initialval in zip(ref[2:-1],seed)]))
            rows[key]=dict(clock=abs(t/float(ref[0])-1),field=float(max(err[::2]/amp)),velocity=float(max(err[1::2]/np.maximum(np.abs(np.asarray(ref[3:-1:2],float)),1e-99))))
        return rows


def main(case):
    bank.guard()
    process=bank.psutil.Process()
    process.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([4])
    bank.save(ROOT/(case+'-owner.json'),dict(pid=process.pid,created=process.create_time(),command=process.cmdline()))
    require(bank.digest(EARLIER/'closeout.json')=='1de083ef739d9fa44bb1cfb7bc45121900d506b44f6bbcd4c3a7d8ae259e12d3','last stage')
    with localcontext() as ctx:
        ctx.prec=52
        model=Model(case)
        payload={'case':case,'index':model.index,'efolds':{str(i):str(n) for i,n in model.knots.items()},'event':str(model.event),
                 'method':bank.digest(ROOT/'METHOD.md'),'code':bank.digest(ROOT/'shoot.py'),'table':str(model.table),'table_sha':bank.digest(model.table),'launches':{}}
        for direction,idx in zip(('forward','backward'),model.seeds):
            seed=model.seeds[idx]
            ref=model.solve(idx,seed,'momentum',3,5)
            coarse=model.solve(idx,seed,'momentum',2,4)
            direct=model.solve(idx,seed,'velocity',3,5)
            tests=model.time_test(idx,ref)
            corners=[]
            for pos in words(seed[-2]):
                for vel in words(seed[-1]):
                    alternate=model.solve(idx,seed[:-2]+[pos,vel],'momentum',3,5)
                    corners.append({k:[str(u-v) for u,v in zip(alternate[k],row)] for k,row in ref.items()})
            payload['launches'][direction]=dict(seed=idx,prediction={k:list(map(str,row)) for k,row in ref.items()},corner_changes=corners,
                       refinement={k:[float(abs(x-y)+abs(z-y)) for x,y,z in zip(coarse[k],row,direct[k])] for k,row in ref.items()},conformal_test=tests)
        bank.save(ROOT/(case+'-frozen.json'),payload)
        print(case,'two full shots frozen, independent time and velocity controls, eight seed-word corners',flush=True)


if __name__=='__main__':
    main(sys.argv[1])
