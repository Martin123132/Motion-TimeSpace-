import sys
from types import FunctionType
from radiation_v3 import Test,Consistent,short_response,measure,bank,np,require,localcontext,ROOT,EARLIER,Response
from shoot import D,exact,CLOCK


def run(case):
    bank.guard()
    receipt=bank.read(ROOT/(case+'-seed-refinement.json'))
    require(receipt['frozen']==bank.digest(ROOT/(case+'-seed-refined-frozen.json')) and all(item['passed'] for item in receipt['tests'].values()),'resolved independent global sources')
    owner=bank.psutil.Process()
    owner.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    owner.cpu_affinity([4])
    tag=case+'-primordial-radiation'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=owner.pid,created=owner.create_time(),command=owner.cmdline(),protocol=bank.digest(ROOT/'PRECISION.md'),
             code=bank.digest(ROOT/'primordial_radiation.py'),input_sha256=bank.digest(ROOT/(case+'-seed-refinement.json'))))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(EARLIER/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in ('bounds','constants','width')}
    with np.load(CLOCK/(case+'-prepared.npz')) as data, localcontext() as ctx:
        ctx.prec=72
        smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
        binary=list(map(exact,data['represented'][0]))
    bounds=clock['bounds']
    event=bank.read(EARLIER/'reversal-frozen.json')['window']
    original=Consistent.adaptive
    integrate=FunctionType(original.__code__,dict(original.__globals__,ROOT=ROOT),original.__name__,original.__defaults__,original.__closure__)
    with context as (capture,meta,sample):
        with np.load(EARLIER/(case+'-capture.npz')) as retained,np.load(ROOT/(tag+'-capture.npz')) as full:
            require(set(full.files)==set(retained.files) and all(np.array_equal(full[key],retained[key]) for key in full.files),'unchanged archive')
            require(set(capture)<=set(retained.files) and all(np.array_equal(capture[key],retained[key]) for key in capture),'unchanged live science arrays')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        for route,kind in (('scale06','smooth'),('time06','smooth'),('scale06','binary')):
            with localcontext() as ctx:
                ctx.prec=72
                before=list(map(D,receipt['states']['event'][route]))
                require(abs(before[0]/smooth[0]-1)<D('1e-48'),'same event scale')
                before[0]=smooth[0]
                model=Response(before,smooth if kind=='smooth' else binary,clock['constants'],bounds[-1]-bounds[0],64)
            for amplitude,steps in ((1.,32),(1.,64),(.5,64)):
                label=f'{case}-{route}-{kind}-amp{amplitude:g}'
                test=Test(case,direct,clock,capture,None)
                test.configure_shot(model,amplitude)
                test.grid=bounds
                test.case=label
                integrate(test,steps,True)
                if kind=='smooth' and amplitude==1:
                    bank.save(ROOT/f'{label}-{steps}-early-event.json',measure(test,event,steps))
                    bank.save(ROOT/f'{label}-{steps}-early-slopes.json',short_response(test,event,steps))


if __name__=='__main__':
    run(sys.argv[1])
