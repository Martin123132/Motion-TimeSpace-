import ctypes
import sys
from primordial import ROOT,Model,quad,np,bank,require,D,exact,localcontext
from primordial_score import CLOCK,register,dynamics


def scale_run(model,initial,targets,params,phase,cap):
    function=ctypes.CDLL(str(ROOT/'scale_fields.dll')).advance_scales
    pointer=ctypes.c_void_p
    function.argtypes=[ctypes.c_int]*3+[pointer]*4+[ctypes.POINTER(ctypes.c_double)]*2+[pointer]*4
    function.restype=None
    coord=[scale.ln() for scale in [initial[0],*[value for _,value in targets]]]
    upper=np.array(coord,float)
    lower=np.array([float(one-exact(two)) for one,two in zip(coord,upper)])
    seed=np.pad(np.array(initial,float),(0,5-len(initial)))
    top,bottom=np.zeros((5,6)),np.zeros((5,6))
    steps,status=ctypes.c_int(),ctypes.c_int(-1)
    function(5,model.num,6,*(arr.ctypes.data for arr in (params,upper,lower,seed)),ctypes.byref(ctypes.c_double(phase)),
             ctypes.byref(ctypes.c_double(cap)),top.ctypes.data,bottom.ctypes.data,ctypes.byref(steps),ctypes.byref(status))
    require(status.value==0 and np.isfinite(top).all() and np.isfinite(bottom).all() and 0<steps.value<300000,'finite independent scale solver')
    result={}
    for idx,(label,scale) in enumerate(targets,1):
        values=[exact(one)+exact(two) for one,two in zip(top[idx],bottom[idx])]
        result[label]=dict(state=list(map(str,[scale,*values[1:len(initial)]])),elapsed=str(values[0]),hubble=str(values[5]),total_steps=steps.value)
    return result


def run(case):
    bank.guard()
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/(case+'-seed-refinement-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),
              code=bank.digest(ROOT/'refine_seed.py'),solver=bank.digest(ROOT/'scale_fields.dll'),source=bank.digest(ROOT/'scale_fields.f90'),method=bank.digest(ROOT/'PRECISION.md')))
    with localcontext() as ctx:
        ctx.prec=72
        model=Model(case)
        frozen=bank.read(ROOT/(case+'-primordial-frozen.json'))
        require(frozen['source']==bank.digest(model.table) and int(model.const[4])==1,'same seed table and single thermal switch')
        initial=list(map(D,frozen['initial']))
        params=np.asarray(model.const,float)
        targets=[('switch',D('.01')/model.const[8]),('forward_seed',min(model.knots.values()).exp()),('event',model.event.exp()),('backward_seed',max(model.knots.values()).exp())]
        predictions={}
        for label,solver,phase,cap in [('time12','time',.12,.02),('time06','time',.06,.01),('scale12','scale',.12,.02),('scale06','scale',.06,.01)]:
            bank.guard()
            predictions[label]=quad(model,initial,targets,params,6,phase,cap) if solver=='time' else scale_run(model,initial,targets,params,phase,cap)
        bank.save(ROOT/(case+'-seed-refined-frozen.json'),dict(predictions=predictions,previous=bank.digest(ROOT/(case+'-primordial-frozen.json')),
            code=bank.digest(ROOT/'refine_seed.py'),method=bank.digest(ROOT/'PRECISION.md')))
        with np.load(CLOCK/(case+'-prepared.npz')) as data:
            smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
        tests={}
        all_states={}
        for label,scale in targets[1:]:
            states={name:register(rows[label],scale,model.const) for name,rows in predictions.items()}
            original=smooth if label=='event' else [scale,*model.seeds[min(model.seeds) if label=='forward_seed' else max(model.seeds)]]
            href=dynamics(original,model.const)[1]
            changes={name:href-dynamics(state,model.const)[1] for name,state in states.items()}
            comparisons=(('time12','time06'),('scale12','scale06'),('time06','scale06'))
            budget=sum(abs(changes[first]-changes[second]) for first,second in comparisons)/abs(changes['scale06'])
            field_errors=[]
            for idx,mass in enumerate(model.masses):
                pos=1+idx*2
                field,speed=states['scale06'][pos:pos+2]
                amp=(field**2+(speed/(mass*scale))**2).sqrt()
                field_errors.append(max(sum(abs(states[first][pos]-states[second][pos])/amp for first,second in comparisons),
                    sum(abs(states[first][pos+1]-states[second][pos+1])/abs(speed) for first,second in comparisons)))
            elapsed={name:D(row[label]['elapsed']) for name,row in predictions.items()}
            clock=sum(abs(elapsed[first]-elapsed[second]) for first,second in comparisons)/abs(elapsed['scale06'])
            tests[label]=dict(delta_h={tag:float(value) for tag,value in changes.items()},relative_source_budget=float(budget),
                field_velocity_budgets=list(map(float,field_errors)),clock_budget=float(clock),passed=max(budget,clock,*field_errors)<bank.TOL,
                source_comparison_terms=[float(abs(changes[first]-changes[second])/abs(changes['scale06'])) for first,second in comparisons])
            all_states[label]={tag:list(map(str,state)) for tag,state in states.items()}
        bank.save(ROOT/(case+'-seed-refinement.json'),dict(tests=tests,states=all_states,frozen=bank.digest(ROOT/(case+'-seed-refined-frozen.json'))))
        print(case,[(name,data['relative_source_budget'],data['passed']) for name,data in tests.items()],flush=True)


if __name__=='__main__':
    run(sys.argv[1])
