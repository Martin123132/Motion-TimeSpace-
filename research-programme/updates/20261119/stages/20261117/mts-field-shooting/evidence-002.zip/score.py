from shoot import ROOT,EARLIER,CLOCK,bank,np,require,exact,words,D,localcontext,Path


def main(case):
    path=ROOT/(case+'-frozen.json')
    packet=bank.read(path)
    require(bank.digest(ROOT/'shoot.py')==packet['code'] and bank.digest(ROOT/'METHOD.md')==packet['method'],'frozen shooting code')
    table=Path(packet['table'])
    require(bank.digest(table)==packet['table_sha'],'archived target table')
    result={}
    with np.load(table) as data:
        suffix='s' if case=='cold' else 'h'
        orig=data['efold' if case=='cold' else 'heavy_efold']
        fields=data['phi_'+suffix]
        velocities=data['phidot_'+suffix]
        mass=exact(data['slow_mass_mpc' if case=='cold' else 'heavy_mass_mpc'])
    if case=='heavy':
        require((len(orig)-1)%4==0,'generator dense quarters')
        for left in range((packet['index']-5)//4*4,packet['index']+13,4):
            require(np.allclose(orig[left+1:left+4],[(1-w)*orig[left]+w*orig[left+4] for w in (.25,.5,.75)],rtol=0,atol=3e-15),'generator dense labels locally')
    for name,branch in packet['launches'].items():
        seed=branch['seed']
        rows=[]
        for label,state in branch['prediction'].items():
            if label=='event' or int(label)==seed:
                continue
            i=int(label)
            _,a,*rest=map(D,state)
            phi,v,_=rest[-3:]
            f0,v0=exact(fields[i]),exact(velocities[i])
            amp=(f0**2+(v0/(a*mass))**2).sqrt()
            errf,errv=phi-f0,v-v0
            errs=branch['refinement'][label]
            fi,vi=errs[-3:-1]
            independent=branch['conformal_test'][label]
            own=abs(float(errv/v0))+vi/float(abs(v0))+independent['velocity']
            amplitude=max(float(abs(errf)/amp)+fi/float(amp)+independent['field'],(float(abs(errv))+vi)/float(a*mass*amp))
            low,high=words(fields[i])
            offsets=[D(c[label][-3]) for c in branch['corner_changes']]
            lower=phi+min(offsets)
            upper=phi+max(offsets)
            drift=f0-exact(fields[seed])
            rows.append(dict(index=i,scope=('opposite_launch' if i in (packet['index']-5,packet['index']+13) else 'outside_previous' if i>packet['index']+5 else 'development'),
                dense_type=('original_solver_endpoint' if i%4==0 else 'original_dense_quarter') if case=='heavy' else 'original_slow_dense_output',
                field_error=float(errf),velocity_error=float(errv),field_change_error_fraction=None if drift==0 else float(errf/abs(drift)),
                field_word_error=float(errf/(high-low)),target_phi_overlaps_seed_corners=bool(lower<=high and upper>=low),
                field_amp_budget=amplitude,velocity_own_budget=own,passes=max(amplitude,own,independent['clock'])<=bank.TOL))
        result[name]=rows
    bank.save(ROOT/(case+'-score.json'),dict(frozen_sha256=bank.digest(path),results=result))
    for name,rows in result.items():
        print(case,name,'field amp, velocity, word max, passes',max(r['field_amp_budget'] for r in rows),
            max(r['velocity_own_budget'] for r in rows),max(abs(r['field_word_error']) for r in rows),sum(r['passes'] for r in rows),len(rows))


if __name__=='__main__':
    with localcontext() as ctx:
        ctx.prec=52
        for case in ('cold','heavy'):
            main(case)
