from background_check import ROOT,EARLIER,prepare,dynamics,np,require,bank,localcontext,exact,D
from shoot import Model,CLOCK


def register(record,target,constants):
    state=list(map(D,record['state']))
    derivative,hubble,_=dynamics(state,constants)
    shift=target-state[0]
    require(abs(shift/target)<D('1.1e-28'),'only terminal root rounding is corrected')
    elapsed=shift/(state[0]*hubble)
    return [target,*[value+elapsed*change for value,change in zip(state[1:],derivative[1:])]]


def score(case):
    model=Model(case)
    file=ROOT/(case+'-primordial-frozen.json')
    frozen=bank.read(file)
    require(frozen['source']==bank.digest(model.table) and frozen['code']==bank.digest(ROOT/'primordial.py') and frozen['protocol']==bank.digest(ROOT/'PRIMORDIAL.md'),'unchanged frozen forecasts')
    with np.load(CLOCK/(case+'-prepared.npz')) as data:
        smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
    targets={'forward_seed':(min(model.knots.values()).exp(),model.seeds[min(model.seeds)]),'event':(smooth[0],smooth[1:]),'backward_seed':(max(model.knots.values()).exp(),model.seeds[max(model.seeds)])}
    scores={}
    event_state=None
    for label,(scale,archived) in targets.items():
        old=[scale,*archived]
        ref_h=dynamics(old,model.const)[1]
        records={tag:branch[label] for tag,branch in frozen['predictions'].items()}
        states={tag:register(record,scale,model.const) for tag,record in records.items()}
        changes={tag:ref_h-dynamics(state,model.const)[1] for tag,state in states.items()}
        fine=states['fine']
        diffs={tag:[float(one-two) for one,two in zip(state[1:],fine[1:])] for tag,state in states.items() if tag!='fine'}
        development=[]
        machine=[]
        for idx,mass in enumerate(model.masses):
            pos=1+2*idx
            field,vel=old[pos:pos+2]
            amp=(field**2+(vel/(scale*mass))**2).sqrt()
            development.append(dict(field=float((fine[pos]-field)/amp),velocity=float((fine[pos+1]-vel)/abs(vel))))
            machine.append(max(sum(float(abs(state[pos]-fine[pos])/amp) for state in [states['coarse'],states['efold']]),
                sum(float(abs(state[pos+1]-fine[pos+1])/abs(fine[pos+1])) for state in [states['coarse'],states['efold']])))
        h_budget=sum(abs(changes[tag]-changes['fine']) for tag in ('coarse','efold'))/abs(changes['fine'])
        tau_budget=sum(abs(D(records[tag]['elapsed'])/D(records['fine']['elapsed'])-1) for tag in ('coarse','efold'))
        scores[label]=dict(relative_to_archive=development,field_verification=machine,delta_h={tag:float(change) for tag,change in changes.items()},
            delta_h_relative_budget=float(h_budget),clock_budget=float(tau_budget),absolute_numerical_differences=diffs,
            numerical_pass=bool(max(float(h_budget),float(tau_budget),*machine)<=bank.TOL))
        if label=='event':
            event_state=list(map(str,fine))
    result=dict(frozen_sha256=bank.digest(file),absolute_state=event_state,checks=scores,event_pass=scores['event']['numerical_pass'])
    bank.save(ROOT/(case+'-primordial-score.json'),result)
    print(case,[(key,val['numerical_pass'],val['delta_h_relative_budget'],val['delta_h']['fine'],val['relative_to_archive']) for key,val in scores.items()])


if __name__=='__main__':
    with localcontext() as ctx:
        ctx.prec=72
        for name in ('cold','heavy'):
            score(name)
