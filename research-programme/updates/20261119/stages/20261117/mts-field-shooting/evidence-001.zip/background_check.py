import math
from finite import ROOT,EARLIER,prepare,Response,np,require,bank,localcontext,exact,D


def dynamics(state,constants):
    scale=state[0]
    rest=(constants[0]+constants[1])/scale+(constants[2]+constants[3])/scale**2
    for species in range(int(constants[4])):
        mass=constants[8+species]
        thermal=scale*mass
        require(D('.01')<=thermal<=D('.3'),'retained thermal coefficient interval')
        rho=1+D(5)/(7*exact(math.pi)**2)*thermal**2+thermal**4*(D('.01099926669')*thermal.ln()-D('.003492416767')-D('.005866275571')*thermal)
        rest+=constants[14+species]*rho/scale**2
    terms=[(speed**2+(scale*mass*field)**2)/2 for speed,mass,field in zip(state[2::2],constants[6:],state[1::2])]
    hubble=((rest+sum(terms))/3).sqrt()
    out=[scale*hubble]
    for speed,mass,field in zip(state[2::2],constants[6:],state[1::2]):
        out.extend((speed,-2*hubble*speed-(scale*mass)**2*field))
    return out,hubble,terms


def advance(state,step,constants):
    def offset(rate,factor):
        return [value+step*factor*change for value,change in zip(state,rate)]
    first=dynamics(state,constants)[0]
    second=dynamics(offset(first,D('.5')),constants)[0]
    third=dynamics(offset(second,D('.5')),constants)[0]
    fourth=dynamics(offset(third,1),constants)[0]
    return [value+step*(one+2*two+2*three+four)/6 for value,one,two,three,four in zip(state,first,second,third,fourth)]


def reference(old,new,params,width,steps):
    left,right=old[:],new[:]
    constants=list(map(exact,params))
    step=exact(width)/(4*steps)
    rows=[]
    for section in range(5):
        if section:
            for _ in range(steps):
                left,right=advance(left,step,constants),advance(right,step,constants)
        left_h=dynamics(left,constants)[1]
        right_h=dynamics(right,constants)[1]
        rows.append([float(one-two) for one,two in zip(right,left)]+[float(right_h-left_h)])
    return np.array(rows)


def run():
    bank.guard()
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/'background-check-owner.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    result={}
    with localcontext() as context:
        context.prec=78
        for case in ('cold','heavy'):
            with np.load(EARLIER/(case+'-clock.npz')) as data:
                width=float(data['bounds'][-1]-data['bounds'][0])
            for side in ('forward','backward'):
                for kind in ('smooth','binary'):
                    old,new,params=prepare(case,side,kind)
                    times=np.linspace(0,width,5)
                    finite=Response(old,new,params,width,64)
                    zero=Response(old,old,params,width,32)
                    rows=[]
                    for time in times:
                        _,delta,dh=finite.at(time)
                        _,empty,control=zero.at(time)
                        require(not np.any(empty) and control==0,'identical solutions give identically zero finite effect')
                        rows.append([*delta,dh])
                    first,second=[reference(old,new,params,width,count) for count in (8,16)]
                    scales=np.max(abs(second),axis=0)
                    require(np.all(scales>0),'all fields have a resolved difference somewhere in this window')
                    errors=(np.max(abs(rows-second),axis=0)+np.max(abs(first-second),axis=0))/scales
                    const=list(map(exact,params))
                    _,h0,e0=dynamics(old,const)
                    _,h1,e1=dynamics(new,const)
                    terms=[float((one-two)/(3*(h0+h1))) for one,two in zip(e1,e0)]
                    if kind=='smooth':
                        require(abs(sum(terms)/float(h1-h0)-1)<bank.ALG,'independent initial scalar energy sum')
                    result[case+'-'+side+'-'+kind]=dict(peak_errors=errors.tolist(),scales=scales.tolist(),source_initial=rows[0][-1],
                        source_final=rows[-1][-1],initial_scalar_terms=terms,passes=bool(max(errors)<=bank.TOL))
                    print(case,side,kind,'max discrepancy',max(errors),'initial expansion shift',rows[0][-1],flush=True)
    bank.save(ROOT/'absolute-background-verification.json',dict(precision=context.prec,tolerance=bank.TOL,rows=result))
    require(all(row['passes'] for row in result.values()),'paired background against two absolute evolutions')


if __name__=='__main__':
    run()
