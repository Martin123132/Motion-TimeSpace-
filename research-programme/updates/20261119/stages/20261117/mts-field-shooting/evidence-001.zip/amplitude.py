from primordial import ROOT,Model,quad,bank,require,D,exact,localcontext,np
from primordial_score import register,CLOCK,dynamics


def run(case):
    model=Model(case)
    frozen=bank.read(ROOT/(case+'-primordial-frozen.json'))
    status=model.table.parent/'status.json'
    require(bank.digest(status)==frozen['parent'],'original calibration and normalization')
    init=list(map(D,frozen['initial']))
    report=next(row for row in bank.read(status)['branches'] if row['fraction']==(0 if case=='cold' else .5))
    change=init[:]
    for index,label in zip(range(model.num),('slow','heavy')):
        change[1+2*index]=D(6).sqrt()*exact(report[label+'_initial'])
    targets=[('switch',D('.01')/model.const[8]),('forward_seed',min(model.knots.values()).exp()),('event',model.event.exp())]
    params=np.asarray(model.const,float)
    states={}
    for name,cap,expansion in [('time12',.12,.02),('time06',.06,.01)]:
        state=quad(model,change,targets,params,6,cap,expansion)['event']
        states[name]=register(state,model.event.exp(),model.const)
    with np.load(CLOCK/(case+'-prepared.npz')) as data:
        smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
    h0=dynamics(smooth,model.const)[1]
    deltas={key:h0-dynamics(val,model.const)[1] for key,val in states.items()}
    original=bank.read(ROOT/(case+'-seed-refinement.json'))['tests']['event']
    budget=abs(deltas['time12']/deltas['time06']-1)+D(str(original['relative_source_budget']))
    bank.save(ROOT/(case+'-amplitude-result.json'),dict(upstream=bank.digest(status),method=bank.digest(ROOT/'AMPLITUDE.md'),code=bank.digest(ROOT/'amplitude.py'),
              initial_position_shifts=[str(a-b) for a,b in zip(change[1::2],init[1::2])],states={key:list(map(str,val)) for key,val in states.items()},
              source={key:float(val) for key,val in deltas.items()},budget=float(budget),source_relative_change=float(deltas['time06'])/original['delta_h']['time06']-1,passed=bool(budget<bank.TOL)))
    print(case,'source normalization shift',float(deltas['time06'])/original['delta_h']['time06']-1,flush=True)


if __name__=='__main__':
    import sys
    bank.guard()
    owner=bank.psutil.Process()
    owner.cpu_affinity([4])
    owner.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    bank.save(ROOT/(sys.argv[1]+'-amplitude-owner.json'),dict(pid=owner.pid,created=owner.create_time(),command=owner.cmdline()))
    with localcontext() as ctx:
        ctx.prec=72
        run(sys.argv[1])
