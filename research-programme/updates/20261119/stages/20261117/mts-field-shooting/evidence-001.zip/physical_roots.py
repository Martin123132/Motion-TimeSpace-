import math
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
from amplitude_radiation import Projected,ROOT,EARLIER,CLOCK,bank,np,require,localcontext,D,exact,Response


def scan(problem,file,steps):
    with np.load(file) as data:
        bounds=data['bounds']
        states=data['states']
        units=data['units']
    begin=bounds[0]
    old=states[0]
    slip=old[3]-.75*old[problem.photon]
    slope=-2*problem.at(begin,True)[3]*(1+old[3]/slip)
    signs=np.sign([[problem.source(t,state,True),state[-1]] for t,state in zip(bounds,states)])
    require(not np.any(signs[0]) and np.all(signs[1:]!=0),'matched origin and nonzero stored endpoints')
    signs[0]=np.sign(slope)
    roots={}
    checks=[]
    cache={}
    for column,key in enumerate(('rate','integral')):
        found=[]
        for index in np.flatnonzero(signs[1:,column]!=signs[:-1,column]):
            left,right=bounds[index:index+2]
            if index not in cache:
                span=right-left
                cap=min(span,float(problem.clock['width'])/steps)
                def rhs(t,coords):
                    return problem.flow(problem.at(t,True),np.r_[coords*units,0.],1.)[:-1]/units
                sol=solve_ivp(rhs,(left,right),states[index]/units,method='DOP853',first_step=cap,max_step=cap,rtol=1e-10,atol=1e-12,dense_output=True)
                require(sol.success,'bounded saved cell evolution')
                record=abs(sol.y[-1,-1]*units[-1]-states[index+1,-1])/max(abs(states[-1,-1]),abs(states[index+1,-1]))
                require(record<bank.TOL,'same terminal radiation on saved interval')
                checks.append(float(record))
                cache[index]=sol
            sol=cache[index]
            def value(t):
                state=sol.sol(t)*units
                return problem.source(t,state,True) if column==0 else state[-1]
            if index==0:
                left=begin+(right-begin)*1e-5
                require(np.sign(value(left))==np.sign(slope),'derived initial sign')
            require(value(left)*value(right)<0,'bracket includes an actual crossing')
            time=brentq(value,left,right,xtol=2e-14,rtol=1e-15)
            found.append(time-begin)
        roots[key]=found
    total=bank.read(file.with_suffix('.json'))['readout']
    require(total['crossings4']==total['crossings8']==len(roots['rate'])==1 and len(roots['integral'])==1,'full signed-flux scan and saved cell brackets agree')
    return dict(roots=roots,original_sign=int(np.sign(slope)),final_sign=signs[-1].tolist(),restart_error=max(checks),forecast_scope='conditional on original material preparation')


def run(case):
    bank.guard()
    owner=bank.psutil.Process()
    owner.cpu_affinity([4])
    owner.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-physical-roots'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=owner.pid,created=owner.create_time(),command=owner.cmdline(),code=bank.digest(ROOT/'physical_roots.py')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(EARLIER/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in ('bounds','constants','width')}
    with np.load(CLOCK/(case+'-prepared.npz')) as data,localcontext() as ctx:
        ctx.prec=72
        smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
    receipt=bank.read(ROOT/(case+'-seed-refinement.json'))
    alternative=bank.read(ROOT/(case+'-amplitude-result.json'))
    bounds=clock['bounds']
    result={}
    with context as (capture,meta,sample):
        with np.load(ROOT/(tag+'-capture.npz')) as full,np.load(EARLIER/(case+'-capture.npz')) as retained:
            require(set(full.files)==set(retained.files) and all(np.array_equal(full[key],retained[key]) for key in full.files),'held native bank')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        for route in ('scale06','time06','normalized'):
            with localcontext() as ctx:
                ctx.prec=72
                before=list(map(D,alternative['states']['time06'] if route=='normalized' else receipt['states']['event'][route]))
                before[0]=smooth[0]
                model=Response(before,smooth,clock['constants'],bounds[-1]-bounds[0],64)
            for amplitude,steps in ((1.,32),(1.,64),(.5,64)):
                problem=Projected(case,direct,clock,capture,None)
                problem.configure_shot(model,amplitude)
                problem.grid=bounds
                label=f'{case}-probe-{route}-smooth-amp{amplitude:g}-smooth-{steps}-adaptive'
                result[label]=scan(problem,ROOT/(label+'.npz'),steps)
    bank.save(ROOT/(tag+'.json'),dict(rows=result,original_short_window=bank.read(EARLIER/'reversal-frozen.json')['window']))
    print(case,result[f'{case}-probe-scale06-smooth-amp1-smooth-64-adaptive'],flush=True)


if __name__=='__main__':
    import sys
    run(sys.argv[1])
