import math
import sys
from types import FunctionType
from primordial_radiation import Test,Consistent,ROOT,EARLIER,CLOCK,Response,bank,np,require,localcontext,D,exact


class Projected(Test):
    def operator(self,time,old,base,delta):
        if not np.any(delta):
            return np.zeros_like(old)
        h=self.native(time,old,self.packet(base,delta,0.),True)[1][28]
        masses=np.array(self.constants[6:6+self.count],float)
        size=max(abs(delta[0]/base[0]),np.linalg.norm(np.r_[delta[2::2],base[0]*masses*delta[1::2]])/(math.sqrt(6)*h))
        peak=self.factor*2.**math.floor(math.log2(.0025/size))
        require(.5<peak/4 and np.isfinite(peak),'finite resolved scalar and scale probes')
        amplitudes=peak*np.array([1.,.5,.25])
        coordinates=(amplitudes/peak)**2
        target=(.5/peak)**2
        result=np.zeros_like(old)
        for index,(coord,amp) in enumerate(zip(coordinates,amplitudes)):
            others=np.delete(coordinates,index)
            weight=np.prod((target-others)/(coord-others))
            plus=self.packet(base,delta,.5+amp)
            minus=self.packet(base,delta,.5-amp)
            require(min(plus[0],minus[0])>0 and max(abs(plus[0]/base[0]-1),abs(minus[0]/base[0]-1))<.003,'positive nearby scale')
            high,oh,_=self.native(time,old,plus,True)
            low,ol,_=self.native(time,old,minus,True)
            require(min(oh[28],ol[28])>0,'expanding finite native probes')
            result+=weight*(high-low)/(2*amp)
        require(np.isfinite(result).all(),'finite full operator')
        return result

    def flow(self,bg,state,amplitude_factor,inspect=False):
        require(not inspect,'full ordinary coupled hierarchy')
        result=super().flow(bg,state,amplitude_factor)
        time,base,delta,_=bg
        old,change=self.unpack(state)
        prop=self.native(time,change,self.packet(base,delta,1),True)[0]
        repaired=prop+self.operator(time,old,base,delta)
        mask=np.ones(self.active,dtype=bool)
        mask[self.indices]=False
        result[self.active:2*self.active][mask]=repaired[:self.active][mask]
        return result

    def fixture(self):
        records=[]
        for time in self.grid[[0,len(self.grid)//2,-1]]:
            _,base,_,_=self.at(time,True)
            original=self.capture['reference'][int(np.argmin(abs(self.capture['clock']-time)))]
            before=self.native(time,original,self.packet(base,np.zeros_like(base),0.),True)[0]
            require(not np.any(self.operator(time,original,base,np.zeros_like(base))),'zero source')
            for sign in (1.,-1.):
                shift=sign*2e-5*base
                shift[1::2]*=-.45
                shift[2::2]*=.6
                truth=self.native(time,original,self.packet(base,shift,1),True)[0]-before
                predicted=self.operator(time,original,base,shift)
                scale=np.maximum(abs(truth[:self.active]),abs(before[:self.active])*1e-5)
                scale=np.maximum(scale,np.max(abs(truth[:self.active]))*1e-12)
                error=max(abs((truth-predicted)[:self.active])/scale)
                records.append(dict(time=time,sign=sign,error=error))
        return records


def run(case):
    bank.guard()
    owner=bank.psutil.Process()
    owner.cpu_affinity([4])
    owner.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-energy-probe'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=owner.pid,created=owner.create_time(),command=owner.cmdline(),method=bank.digest(ROOT/'OPERATOR.md'),code=bank.digest(ROOT/'operator_check.py')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(EARLIER/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in ('bounds','constants','width')}
    with np.load(CLOCK/(case+'-prepared.npz')) as data,localcontext() as ctx:
        ctx.prec=72
        smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
        binary=list(map(exact,data['represented'][0]))
    receipt=bank.read(ROOT/(case+'-seed-refinement.json'))
    require(receipt['frozen']==bank.digest(ROOT/(case+'-seed-refined-frozen.json')) and receipt['tests']['event']['passed'],'resolved original preparations')
    original=Consistent.adaptive
    integrate=FunctionType(original.__code__,dict(original.__globals__,ROOT=ROOT),original.__name__,original.__defaults__,original.__closure__)
    with context as (capture,meta,sample):
        with np.load(EARLIER/(case+'-capture.npz')) as retained,np.load(ROOT/(tag+'-capture.npz')) as full:
            require(set(full.files)==set(retained.files) and all(np.array_equal(full[key],retained[key]) for key in full.files),'all original arrays')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        bounds=clock['bounds']
        for route,kind in (('scale06','smooth'),('time06','smooth'),('scale06','binary')):
            with localcontext() as ctx:
                ctx.prec=72
                before=list(map(D,receipt['states']['event'][route]))
                before[0]=smooth[0]
                model=Response(before,smooth if kind=='smooth' else binary,clock['constants'],bounds[-1]-bounds[0],64)
            for amplitude,steps in ((1.,32),(1.,64),(.5,64)):
                problem=Projected(case,direct,clock,capture,None)
                problem.configure_shot(model,amplitude)
                problem.grid=bounds
                problem.case=f'{case}-probe-{route}-{kind}-amp{amplitude:g}'
                if route=='scale06' and kind=='smooth' and steps==32:
                    rows=problem.fixture()
                    bank.save(ROOT/(tag+'-fixtures.json'),rows)
                    require(max(row['error'] for row in rows)<bank.TOL,'synthetic native operator gate')
                integrate(problem,steps,True)


if __name__=='__main__':
    run(sys.argv[1])
