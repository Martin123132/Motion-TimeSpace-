from operator_check import Projected,FunctionType,Consistent,ROOT,EARLIER,CLOCK,bank,np,require,localcontext,D,exact,Response


def main(case):
    bank.guard()
    item=bank.read(ROOT/(case+'-amplitude-result.json'))
    require(item['passed'] and item['code']==bank.digest(ROOT/'amplitude.py'),'qualified alternate original normalization')
    owner=bank.psutil.Process()
    owner.cpu_affinity([4])
    owner.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-amplitude-radiation'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=owner.pid,created=owner.create_time(),command=owner.cmdline(),
              code=bank.digest(ROOT/'amplitude_radiation.py'),source=bank.digest(ROOT/(case+'-amplitude-result.json'))))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(EARLIER/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in ('bounds','constants','width')}
    bounds=clock['bounds']
    with np.load(CLOCK/(case+'-prepared.npz')) as data,localcontext() as ctx:
        ctx.prec=72
        smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
        before=list(map(D,item['states']['time06']))
        require(abs(before[0]/smooth[0]-1)<D('1e-48'),'same matter event')
        before[0]=smooth[0]
        model=Response(before,smooth,clock['constants'],bounds[-1]-bounds[0],64)
    original=Consistent.adaptive
    integrate=FunctionType(original.__code__,dict(original.__globals__,ROOT=ROOT),original.__name__,original.__defaults__,original.__closure__)
    with context as (capture,meta,sample):
        with np.load(EARLIER/(case+'-capture.npz')) as retained,np.load(ROOT/(tag+'-capture.npz')) as full:
            require(set(full.files)==set(retained.files) and all(np.array_equal(full[key],retained[key]) for key in full.files),'identical original packets')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        for amplitude,steps in ((1.,32),(1.,64),(.5,64)):
            problem=Projected(case,direct,clock,capture,None)
            problem.configure_shot(model,amplitude)
            problem.grid=bounds
            problem.case=f'{case}-probe-normalized-smooth-amp{amplitude:g}'
            integrate(problem,steps,True)


if __name__=='__main__':
    import sys
    main(sys.argv[1])
