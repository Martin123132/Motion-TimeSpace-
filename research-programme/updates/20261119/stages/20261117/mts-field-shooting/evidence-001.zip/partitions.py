import sys
from amplitude_radiation import Projected,FunctionType,Consistent,ROOT,EARLIER,CLOCK,bank,np,require,localcontext,D,exact,Response


def run(case):
    bank.guard()
    owner=bank.psutil.Process()
    owner.cpu_affinity([4])
    owner.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-partition'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=owner.pid,created=owner.create_time(),command=owner.cmdline(),method=bank.digest(ROOT/'PARTITION.md'),code=bank.digest(ROOT/'partitions.py')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(EARLIER/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in ('bounds','constants','width')}
    bounds=clock['bounds']
    with np.load(CLOCK/(case+'-prepared.npz')) as data,localcontext() as ctx:
        ctx.prec=72
        smooth=[exact(one)+exact(two) for one,two in zip(data['smooth_high'][0],data['smooth_low'][0])]
    before=list(map(D,bank.read(ROOT/(case+'-seed-refinement.json'))['states']['event']['scale06']))
    before[0]=smooth[0]
    fn=Consistent.adaptive
    integrate=FunctionType(fn.__code__,dict(fn.__globals__,ROOT=ROOT),fn.__name__,fn.__defaults__,fn.__closure__)
    with context as (capture,meta,sample):
        with np.load(EARLIER/(case+'-capture.npz')) as held,np.load(ROOT/(tag+'-capture.npz')) as now:
            require(set(now.files)==set(held.files) and all(np.array_equal(now[key],held[key]) for key in now.files),'intact packet bank')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        for selected in (('none',) if case=='cold' else ('none','slow','heavy')):
            after=before[:]
            if selected=='slow':
                after[1:3]=smooth[1:3]
            elif selected=='heavy':
                after[3:5]=smooth[3:5]
            with localcontext() as ctx:
                ctx.prec=72
                model=Response(before,after,clock['constants'],bounds[-1]-bounds[0],64)
            for amp,steps in ((1.,32),(1.,64),(.5,64)):
                probe=Projected(case,direct,clock,capture,None)
                probe.configure_shot(model,amp)
                probe.grid=bounds
                probe.case=f'{case}-sector-{selected}-amp{amp:g}'
                if selected=='none':
                    with np.load(ROOT/f'{case}-probe-scale06-smooth-amp1-smooth-64-adaptive.npz') as saved:
                        require(np.array_equal(saved['bounds'],bounds),'same times')
                        history=saved['states']
                    for time,reference in zip(bounds,history):
                        data=probe.initial
                        data[:probe.active]=reference[:probe.active]
                        packet=probe.at(time,True)
                        require(not np.any(packet[2]) and packet[3]==0,'exact zero gravitational change')
                        response=probe.flow(packet,data,1.)
                        require(not np.any(response[probe.active:2*probe.active]) and not np.any(response[-2:]) and probe.source(time,data,True)==0,'identical complete material response')
                    bank.save(ROOT/(tag+'-null.json'),dict(epochs=len(bounds),active=probe.active,all_zero=True))
                    break
                integrate(probe,steps,True)


if __name__=='__main__':
    run(sys.argv[1])
