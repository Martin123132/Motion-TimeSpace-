import math
import sys
from pathlib import Path
from scipy.integrate import solve_ivp
from shoot import ROOT,EARLIER,CLOCK,Model,D,exact,localcontext,np,bank,require
sys.path.insert(0,str(EARLIER))
from adaptive import retained_clock
from background_check import dynamics


def unpack(high,low,count):
    return [exact(one)+exact(two) for one,two in zip(high[:count],low[:count])]


def quad(model,initial,targets,params,level,cap,exp_cap):
    call,_,step=retained_clock()
    length=len(initial)
    params=np.ascontiguousarray(params)
    top=np.array(initial,float)
    bot=np.array([float(word-exact(high)) for word,high in zip(initial,top)])
    total=D(0)
    history={}
    steps=0
    source_scale=initial[0]
    for label,target in targets:
        banks=0
        while (target-source_scale)/target>D('1e-28'):
            bank.guard()
            if not banks and not history:
                scale=float(source_scale)
                flux=sum(params[:2])/scale+(sum(params[2:4])+sum(params[14:14+int(params[4])]))/scale**2
                hubble=math.sqrt((flux+sum((float(v)**2+(scale*m*float(f))**2)/2 for f,v,m in zip(initial[1::2],initial[2::2],params[6:])))/3)
            dt=min(.18/hubble,float((target-source_scale)/source_scale)*.85/hubble)
            maximum=min(exp_cap/hubble,cap/(1.25*float(source_scale)*max(params[6:6+model.num])))
            upper,lower,count=step(call,params,model.num,level,0,[0.,dt],top,bot,maximum)
            total+=exact(dt)
            steps+=count
            top,bot=upper[-1,:length],lower[-1,:length]
            hubble=upper[-1,5]
            before=source_scale
            source_scale=exact(top[0])+exact(bot[0])
            require(before<source_scale and (source_scale-target)/target<D('1e-28'),'ordered approach to fixed physical scale')
            banks+=1
            require(banks<240,'bounded independent root location')
        history[label]=dict(elapsed=str(total),state=list(map(str,unpack(top,bot,length))),hubble=str(exact(upper[-1,5])+exact(lower[-1,5])),steps=steps,segments=banks)
    return history


def efold(model,initial,targets,params):
    masses=params[6:6+model.num]
    fields=np.array(initial[1::2],float)
    speeds=np.array(initial[2::2],float)
    start=float(initial[0])
    end=float(targets[-1][1])
    displacement=np.where(masses<1.,1e-8,1.)
    velocity=np.where(masses<1.,1e-5,1.)
    base=speeds/(start*masses)
    state=np.r_[np.zeros(model.num),base/velocity,0.]
    def rhs(coord,state):
        scale=math.exp(coord)
        field=fields+state[:model.num]*displacement
        momentum=state[model.num:2*model.num]*velocity
        total=sum(params[:2])/scale+sum(params[2:4])/scale**2
        for pos in range(int(params[4])):
            argument=scale*params[8+pos]
            require(argument<.3,'early thermal branch')
            rho=1+5/(7*math.pi**2)*argument**2
            if argument>=.01:
                rho+=argument**4*(.01099926669*math.log(argument)-.003492416767-.005866275571*argument)
            total+=params[14+pos]*rho/scale**2
        total+=sum((scale*masses)**2*(field**2+momentum**2)/2)
        hubble=math.sqrt(total/3)
        freq=scale*masses/hubble
        return np.r_[freq*momentum/displacement,(-3*momentum-freq*field)/velocity,1/hubble]
    reports={}
    prior=float(initial[0].ln())
    for label,scale in targets:
        end=float(scale.ln())
        sol=solve_ivp(rhs,(prior,end),state,method='DOP853',rtol=2e-13,atol=1e-17,max_step=.025)
        require(sol.success,'efold evolution from primordial state')
        state=sol.y[:,-1]
        field=[seed+exact(delta*unit) for seed,delta,unit in zip(initial[1::2],state[:model.num],displacement)]
        momentum=state[model.num:2*model.num]*velocity
        result=[scale]
        for index,tick in enumerate(field):
            result.extend((tick,scale*exact(masses[index])*exact(momentum[index])))
        reports[label]=dict(state=list(map(str,result)),elapsed=str(exact(state[-1])),calls=sol.nfev)
        prior=end
    return reports


def main(case):
    bank.guard()
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/(case+'-primordial-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),method=bank.digest(ROOT/'PRIMORDIAL.md'),code=bank.digest(ROOT/'primordial.py')))
    with localcontext() as ctx:
        ctx.prec=72
        model=Model(case)
        original=model.table.parent/'status.json'
        dossier=bank.read(original)
        require(dossier['state']=='complete' and dossier['input_hashes'][str(model.table)]==bank.digest(model.table),'original calibrated background')
        details=next(row for row in dossier['branches'] if Path(row['table'])==model.table)
        with np.load(model.table) as data:
            initial=[exact(data['scale'][0])]
            for key in ('s',) if case=='cold' else ('s','h'):
                require(key=='s' or data['heavy_efold'][0]==data['efold'][0],'original common starting epoch')
                initial.extend([exact(data['phi_'+key][0]),exact(data['phidot_'+key][0])])
            require(abs(float(initial[1])-math.sqrt(6)*details['slow_initial'])<1e-14,'saved slow preparation')
            if model.num==2:
                require(abs(float(initial[3])-math.sqrt(6)*details['heavy_initial'])<1e-14,'saved heavy preparation')
        params=np.asarray(model.const,float)
        switch=D('.01')/model.const[8]
        targets=[('switch',switch),('forward_seed',min(model.knots.values()).exp()),('event',model.event.exp()),('backward_seed',max(model.knots.values()).exp())]
        require(all(left<right for left,right in zip([initial[0]]+[value for _,value in targets[:-1]],[value for _,value in targets])),'all events in order')
        results={}
        for label,level,phi,expansion in [('coarse',5,.42,.08),('fine',6,.24,.04)]:
            results[label]=quad(model,initial,targets,params,level,phi,expansion)
        results['efold']=efold(model,initial,targets,params)
        bank.save(ROOT/(case+'-primordial-frozen.json'),dict(case=case,initial=list(map(str,initial)),source=bank.digest(model.table),parent=bank.digest(original),
            protocol=bank.digest(ROOT/'PRIMORDIAL.md'),code=bank.digest(ROOT/'primordial.py'),predictions=results))
        print(case,'independent primordial trajectories frozen',results['fine']['event']['steps'],flush=True)


if __name__=='__main__':
    main(sys.argv[1])
