import math
from shoot import ROOT,CLOCK,EARLIER,bank,np,require,exact,D,localcontext
from scipy.integrate import solve_ivp


def prepare(case,side,kind):
    freeze=bank.read(ROOT/(case+'-frozen.json'))
    require(bank.digest(ROOT/(case+'-frozen.json'))==bank.read(ROOT/(case+'-score.json'))['frozen_sha256'],'identical forecasts')
    require(all(r['passes'] for r in bank.read(ROOT/(case+'-score.json'))['results'][side]),'field authority for a conditional test')
    row=list(map(D,freeze['launches'][side]['prediction']['event']))
    with np.load(CLOCK/f'{case}-prepared.npz') as p:
        old=[exact(a)+exact(b) for a,b in zip(p['smooth_high'][0],p['smooth_low'][0])]
        new=old if kind=='smooth' else list(map(exact,p['represented'][0]))
        params=p['constants'].copy()
    start=[old[0],*row[2:-1]]
    require(abs(row[1]/old[0]-1)<D('1e-48'),'same scale event')
    return start,new,params


class Response:
    def __init__(self,old,new,params,width,steps):
        self.a=float(old[0])
        self.fields=np.array(old[1::2],float)
        self.velocities=np.array(old[2::2],float)
        self.number=len(self.fields)
        self.length=len(old)
        self.mass=params[6:6+self.number]
        self.const=params
        self.coef=5/(7*math.pi**2)
        self.nu_count=int(params[4])
        self.width=width
        self.delta=np.array([float((new[0]/old[0]).ln()),*[float(a-b) for a,b in zip(new[1:],old[1:])]])
        self.initial=np.r_[np.zeros(self.length),self.delta]
        first,_,_=self.evaluate(self.initial)
        second,_,_=self.evaluate(self.initial+.5*width*first)
        self.units=np.maximum.reduce([abs(self.initial),abs(first)*width,abs(second)*width,np.full(len(first),1e-80)])
        self.solution=solve_ivp(lambda t,y:self.evaluate(y*self.units)[0]/self.units,(0,width),
              self.initial/self.units,method='DOP853',rtol=1e-10,atol=1e-12,max_step=width/steps,dense_output=True)
        require(self.solution.success,'finite dynamical background')

    def evaluate(self,state):
        a=self.a*math.exp(state[0])
        f=self.fields+state[1:self.length:2]
        v=self.velocities+state[2:self.length:2]
        gamma=state[self.length]
        df=state[self.length+1::2]
        dv=state[self.length+2::2]
        c=self.const
        linear=math.expm1(gamma)
        double=math.expm1(2*gamma)
        rad=math.expm1(-2*gamma)
        dust=(c[0]+c[1])/a
        free=(c[2]+c[3])/a**2
        standard=dust+free
        shifts=[dust*math.expm1(-gamma),free*rad]
        for j in range(self.nu_count):
            m,weight=c[8+j],c[14+j]
            x=a*m
            require(.01<=x<=.3 and .01<=x*math.exp(gamma)<=.3,'same retained thermal piece')
            tail=.01099926669*math.log(x)-.003492416767-.005866275571*x
            standard+=weight/a**2*(1+self.coef*x*x+x**4*tail)
            shifts.append(weight*(rad/a**2+m**4*a**2*(double*tail+math.exp(2*gamma)*(.01099926669*gamma-.005866275571*x*linear))))
        m2=(a*self.mass)**2
        total=standard+sum((v*v+m2*f*f)/2)
        shifts.extend(.5*(dv*(2*v+dv)+m2*(df*(2*f+df)+double*(f+df)**2)))
        change=math.fsum(shifts)
        h0=math.sqrt(total/3)
        h1=math.sqrt((total+change)/3)
        dh=change/(3*(h1+h0))
        flow=np.r_[h0,np.column_stack((v,-2*h0*v-m2*f)).ravel(),
                    dh,np.column_stack((dv,-2*h1*dv-2*dh*v-m2*(math.exp(2*gamma)*df+double*f))).ravel()]
        return flow,np.r_[a,np.column_stack((f,v)).ravel()],(np.r_[a*linear,np.column_stack((df,dv)).ravel()],dh)

    def at(self,time):
        require(0<=time<=self.width,'no continuation beyond frozen duration')
        _,base,(delta,dh)=self.evaluate(self.solution.sol(time)*self.units)
        return base,delta,dh
