from run_gap import *

if __name__=="__main__":
    with worker("boundary-diagnosis"):
        inputs()
        original=read(ROOT / "heavy-live-32-start.json")
        require(exited(original)["exited"],"failed worker has exited")
        require(read(ROOT / "heavy-live-32-owner-release.json")["cleared"],"failed native owner released")
        require((ROOT / "heavy-live-32-failure.json").is_file(),"failure receipt retained")
        _,_,background,_,_=EX.problem("heavy")
        clock=load(ROOT / "heavy-clock.npz")["time"]
        begin,finish=float(clock[48]),float(clock[64])
        interior=background.boundaries(begin,finish)
        raw=np.concatenate(([begin],interior,[finish]))
        clean=np.unique(raw[(raw>=begin)&(raw<=finish)])
        zero=np.flatnonzero(np.diff(raw)==0)
        outside=raw[(raw<begin)|(raw>finish)]
        record={"begin":begin,"finish":finish,"raw_boundaries":raw.tolist(),
                "duplicate_zero_length_segments":zero.tolist(),"outside_requested_interval":outside.tolist(),
                "clean_boundaries":clean.tolist(),"only_duplicate_endpoints_removed":
                   len(outside)==0 and len(zero)>0 and all(raw[index] in (begin,finish) for index in zero),
                "saved_diagnostic_clock_unchanged":True,
                "last_complete_boundary":48,"failed_worker":{**original,**exited(original)}}
        prepared,_,_,_,_=EX.problem("cold")
        record["cold_density0_present"]="density0" in prepared
        record["cold_normalization"]=float(prepared["cold_normalization"])
        write(ROOT / "boundary-diagnosis.json",record)
        print(json.dumps(record),flush=True)
        require(record["only_duplicate_endpoints_removed"],"proven duplicate endpoint cause")
