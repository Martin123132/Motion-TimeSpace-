from restart_support import *
PHASE = Path(CONFIG["phase_directory"])
exec(compile((PHASE / "restart_bridge.py").read_text(encoding="utf-8"), str(PHASE / "restart_bridge.py"), "exec"), globals())
