from restart_support import *
import importlib.metadata

if __name__=="__main__":
    check_inputs(read(ROOT / "inputs.json"))
    check_inputs(read(ROOT / "predictions-frozen.json")["files"])
    check_inputs(read(ROOT / "score-plan.json")["files"])
    verification=read(ROOT / "verification.json")
    science=read(ROOT / "science-score.json")
    require(verification["passed"],"verified recorded experiment")
    workers={path.name:{**read(path),**exited(read(path))} for path in ROOT.glob("*-start.json")}
    require(all(item["exited"] for item in workers.values()),"all task worker identities exited")
    releases={path.name:read(path)["cleared"] for path in ROOT.glob("*-owner-release.json")}
    require(len(releases)==5 and all(releases.values()),"five native owners including failed attempt released")
    check_inputs(read(ROOT / "repair-plan.json")["files"])
    require(read(ROOT / "pressure-identity.json")["passed"],"derived pressure identity checked")
    require(not (ROOT / "__pycache__").exists(),"no bytecode")
    for path in ROOT.glob("*.py"):
        compile(path.read_text(encoding="utf-8"),str(path),"exec")
    write(ROOT / "cleanup.json",{"workers":workers,"native_releases":releases,"all_exited":True,
          "other_processes_changed":False,"temporary_tools":[],"python":sys.version,
          "packages":{name:importlib.metadata.version(name) for name in ("numpy","scipy","sympy","psutil")}})
    artifacts={str(path.relative_to(ROOT)):{"sha256":digest(path),"bytes":path.stat().st_size}
               for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name!="closeout.json"}
    result={"stage":"Full coupled3038-to3039 coarse native-clock gap","utc":datetime.now(timezone.utc).isoformat(),
            "completed":True,"verification_passed":True,"consolidated_checks":verification["count"],
            "main_physical_passed_both":science["main_passed"],"independent_controls_passed_both":science["independent_controls_passed"],
            "forecasts_passed":{case:{mode:item["passed"] for mode,item in report["forecasts"].items()} for case,report in science["cases"].items()},
            "response_relative_passed":{case:report["response_check"]["passed"] for case,report in science["cases"].items()},
            "all_scientific_tests_pass":science["all_scientific_tests_pass"],"new_native_epoch":3039,
            "frozen_inputs":len(read(ROOT / "inputs.json")),"frozen_forecast_files":len(read(ROOT / "predictions-frozen.json")["files"]),
            "workers_exited":len(workers),"native_owners_released":len(releases),
            "duplicate_boundary_failure_preserved":True,"pressure_identity_symbolically_verified":True,
            "native_binary_rebuilt":False,"github":False,"artifacts":artifacts}
    write(ROOT / "closeout.json",result)
    print(json.dumps({"seal":digest(ROOT / "closeout.json"),"artifacts":len(artifacts),
          "workers_exited":len(workers),"bytes":sum(item["bytes"] for item in artifacts.values())}),flush=True)
