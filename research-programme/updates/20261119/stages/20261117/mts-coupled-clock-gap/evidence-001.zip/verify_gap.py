from run_gap import *

def verify():
    inputs()
    frozen=read(ROOT / "predictions-frozen.json")
    plan=read(ROOT / "score-plan.json")
    check_inputs(frozen["files"])
    check_inputs(plan["files"])
    checks={}
    for case in CONFIG["cases"]:
        original=saved_state(case)
        clock=load(ROOT / (case+"-clock.npz"))
        _,_,background,_,_=EX.problem(case)
        expected=np.concatenate(([clock["native_time"][0]],background.boundaries(*clock["native_time"]),[clock["native_time"][-1]]))
        checks[case+"_original_boundaries_only"]=np.array_equal(clock["time"],expected)
        checks[case+"_original_norms"]=read(ROOT / "frozen-norms.json")[case]==read(PHASE / "frozen-norms.json")[case]
        for steps in CONFIG["steps"]:
            label=case+"-live-"+str(steps)
            data=load(ROOT / (label+".npz"))
            start=read(ROOT / (label+"-start.json"))
            checks[label+"_predictions_frozen_first"]=datetime.fromisoformat(frozen["utc"])<datetime.fromisoformat(start["utc"])
            checks[label+"_score_frozen_first"]=datetime.fromisoformat(plan["utc"])<datetime.fromisoformat(start["utc"])
            checks[label+"_same_diagnostic_clock"]=np.array_equal(clock["time"],data["time"])
            checks[label+"_only_two_native_controls"]=data["native_control"].shape==(2,5)
            checks[label+"_all_finite"]=all(np.isfinite(value).all() for value in data.values())
            terminal=load(ROOT / (label+"-terminal.npz"))
            checks[label+"_full_terminal"]=np.array_equal(terminal["normalized"],data["normalized"][-1])
            checks[label+"_signature"]=np.array_equal(terminal["signature"],original["signature"])
            checks[label+"_all_units_unchanged"]=np.array_equal(terminal["units"],original["units"])
            checks[label+"_owner_released"]=read(ROOT / (label+"-owner-release.json"))["cleared"]
            result=read(ROOT / (label+"-result.json"))
            checks[label+"_restart_exact"]=result["fresh_initial_rhs_exact"] and result["prefix1048_exact"]
            current=original["normalized"]
            for batch in result["batches"]:
                begin,end=batch["begin"],batch["end"]
                batch_label=label+"-boundary"+str(end)
                packet=load(ROOT / (batch_label+"-history.npz"))
                final=load(ROOT / (batch_label+"-terminal.npz"))
                checks[batch_label+"_join"]=np.array_equal(packet["normalized"][0],current)
                checks[batch_label+"_retained"]=all(np.array_equal(value,data[name][begin:end+1]) for name,value in packet.items())
                checks[batch_label+"_checkpoint"]=np.array_equal(final["normalized"],packet["normalized"][-1])
                current=final["normalized"]
            for mode in ("constant","linear"):
                prediction=read(ROOT / (case+"-"+mode+"-"+str(steps)+"-prediction.json"))
                checks[case+"_"+mode+"_"+str(steps)+"_initial_identity"]=prediction["passed"] and prediction["no_future_live_source_read"]
        fine=load(ROOT / (case+"-live-64.npz"))
        for branch,branch_name in enumerate(("old","coherent")):
            expected_own=np.stack((fine["source"],fine["source"]+fine["source_change"]),axis=1)[:,branch]
            material=fine["metric"][:,branch,:84].reshape(len(fine["time"]),7,12)
            owned=0 if case=="cold" else 6
            prepared,_,_,_,_=EX.problem(case)
            beta=field(fine["metric"][:,branch],"scale")/float(prepared["density0"])
            reconstructed=beta[:,None]*material[:,owned][:,[3,4,5]]
            norm=np.asarray(read(ROOT / "frozen-norms.json")[case]["source_norm"])
            normalized=np.divide(abs(reconstructed-expected_own),norm,out=np.zeros_like(expected_own),where=norm!=0)
            exact_zeros=np.all(abs(reconstructed-expected_own)[:,norm==0]==0)
            checks[case+"_"+branch_name+"_stress_readout_parity"]=maximum(normalized)<=CONFIG["algebra_tolerance"] and exact_zeros
    checks["previous_workers_exited"]=all(exited(read(path))["exited"] for path in ROOT.glob("*-start.json") if path.name!="verify-start.json")
    checks["no_bytecode"]=not (ROOT / "__pycache__").exists()
    for path in ROOT.glob("*.py"):
        compile(path.read_text(encoding="utf-8"),str(path),"exec")
    checks["new_scripts_compile"]=True
    science=read(ROOT / "science-score.json")
    result={"passed":all(bool(item) for item in checks.values()),"count":len(checks),
            "checks":{name:bool(value) for name,value in checks.items()},
            "main_physical_passed":science["main_passed"],"independent_controls_passed":science["independent_controls_passed"],
            "failed_scientific_forecasts":{case:{mode:item["failed"] for mode,item in report["forecasts"].items()}
                                         for case,report in science["cases"].items()},
            "all_scientific_tests_pass":science["all_scientific_tests_pass"]}
    write(ROOT / "verification.json",result)
    print(json.dumps({name:value for name,value in result.items() if name!="checks"}),flush=True)
    require(result["passed"],"technical verification")

if __name__=="__main__":
    with worker("verify"):
        verify()
