from run_gap import *

if __name__=="__main__":
    with worker("physical-summary"):
        inputs()
        science=read(ROOT / "science-score.json")
        summaries={}
        for case in CONFIG["cases"]:
            data=load(ROOT / (case+"-live-64.npz"))
            report=science["cases"][case]
            current=readouts(data["metric"])
            correction=current[:,1,0]-current[:,0,0]
            control=report["independent_controls"]["native_velocity"]
            result={"coherent_redshift_endpoints":(1/field(data["metric"][[0,-1],1],"scale")-1).tolist(),
                    "native_control_absolute_velocity_residual":control["residual"],
                    "native_control_residual_over_paired_correction_amplitude":
                       control["residual"]/maximum(correction) if maximum(correction) else None,
                    "control_comparison_is_not_a_rigorous_error_bound":True,
                    "paired_response_refinement_is_not_total_model_uncertainty":True}
            if case=="heavy":
                own=data["own_state"]+data["own_state_change"]
                scalar=data["background"][:,3]
                source=data["source"]+data["source_change"]
                result["sign_changes"]={name:int(np.sum(values[:-1]*values[1:]<0)) for name,values in (
                    ("homogeneous_heavy_field",scalar),("heavy_perturbation",own[:,0]),
                    ("heavy_perturbation_velocity",own[:,1]),("heavy_pressure_source",source[:,2]))}
                result["correction_sampled_turning_points_not_field_cycles"]=len(report["sampled_extrema"])
                result["actual_field_sampled_turning_points"]=int(np.sum(np.diff(own[:,0])[:-1]*np.diff(own[:,0])[1:]<0))
                result["density_forecast_error_improvement_constant_to_linear"]=(
                    report["forecasts"]["constant"]["checks"]["coherent_source_0"]["relative"]/report["forecasts"]["linear"]["checks"]["coherent_source_0"]["relative"])
            summaries[case]=result
        write(ROOT / "physical-summary.json",summaries)
        print(json.dumps(summaries),flush=True)
