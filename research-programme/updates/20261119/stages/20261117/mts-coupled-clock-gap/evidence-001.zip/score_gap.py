from run_gap import *
from score_phase import conservative
from verify_phase import primitive_envelope

NAMES=("native_velocity","native_weyl","photon_density","relative_density","velocity_slip")

def score():
    inputs()
    check_inputs(read(ROOT / "score-plan.json")["files"])
    check_inputs(read(ROOT / "predictions-frozen.json")["files"])
    reports={}
    for case in CONFIG["cases"]:
        fine=load(ROOT / (case+"-live-64.npz"))
        coarse=load(ROOT / (case+"-live-32.npz"))
        require(np.array_equal(fine["time"],coarse["time"]), "same diagnostic times")
        norm=read(ROOT / "frozen-norms.json")[case]
        high,low=readouts(fine["metric"]),readouts(coarse["metric"])
        envelope=primitive_envelope(fine["metric"])+primitive_envelope(coarse["metric"])
        native_indices=fine["native_indices"]
        checks,controls={},{}
        for branch,branch_name in enumerate(("old","coherent")):
            for component,name in enumerate(NAMES):
                refinement=maximum(high[:,branch,component]-low[:,branch,component])
                amplitude=maximum(envelope[:,branch,component])
                checks[branch_name+"_"+name]=conservative(0.,refinement,norm["readout_norm"][component],amplitude)
                if branch==0:
                    controls[name]=conservative(maximum(high[native_indices,0,component]-fine["native_control"][:,component]),
                                                refinement,norm["readout_norm"][component],amplitude)
        for name,index in (("trace_residual",3),("shear_residual",4),("eta_residual",5),("density_constraint",6),("friedmann_constraint",7)):
            values=field(fine["metric"][:,1],name)
            previous=field(coarse["metric"][:,1],name)
            checks["coherent_"+name]=conservative(maximum(values),maximum(values-previous),
                                                 norm["metric_norm"][index],norm["metric_norm"][index])
        actual_states=np.stack((fine["own_state"],fine["own_state"]+fine["own_state_change"]),axis=1)
        actual_sources=np.stack((fine["source"],fine["source"]+fine["source_change"]),axis=1)
        coarse_states=np.stack((coarse["own_state"],coarse["own_state"]+coarse["own_state_change"]),axis=1)
        coarse_sources=np.stack((coarse["source"],coarse["source"]+coarse["source_change"]),axis=1)
        for branch,branch_name in enumerate(("old","coherent")):
            source=actual_sources[:,branch]
            previous=coarse_sources[:,branch]
            work=fine["work"]+(fine["work_change"] if branch else 0.)
            previous_work=coarse["work"]+(coarse["work_change"] if branch else 0.)
            for component,section in ((0,slice(0,6)),(1,slice(6,9))):
                residual=source[:,component]-source[0,component]-np.sum(work[:,section]-work[0,section],axis=1)
                lower=previous[:,component]-previous[0,component]-np.sum(previous_work[:,section]-previous_work[0,section],axis=1)
                amplitude=maximum(abs(source[:,component])+np.sum(abs(work[:,section]),axis=1))
                checks[branch_name+"_exchange_"+str(component)]=conservative(maximum(residual),maximum(residual-lower),
                                                                             norm["source_norm"][component],amplitude)
            checks[branch_name+"_pressure_refinement"]=conservative(0.,maximum(source[:,2]-previous[:,2]),norm["source_norm"][2],
                                                                    maximum(abs(source[:,2])+abs(previous[:,2])))
        forecasts={}
        for mode in ("constant","linear"):
            predicted=load(ROOT / (case+"-"+mode+"-64-prediction.npz"))
            lower=load(ROOT / (case+"-"+mode+"-32-prediction.npz"))
            require(np.array_equal(predicted["time"],fine["time"]),"prediction uses same diagnostics")
            forecast_checks={}
            first_crossing={}
            for branch,branch_name in enumerate(("old","coherent")):
                for key,actual,previous,scales in (("state",actual_states,coarse_states,norm["own_state_norm"]),
                                                  ("source",actual_sources,coarse_sources,norm["source_norm"])):
                    for component,scale in enumerate(scales):
                        difference=abs(predicted[key][:,branch,component]-actual[:,branch,component])
                        refinement=maximum(predicted[key][:,branch,component]-lower[key][:,branch,component])
                        refinement+=maximum(actual[:,branch,component]-previous[:,branch,component])
                        amplitude=maximum(abs(predicted[key][:,branch,component])+abs(actual[:,branch,component]))
                        name=branch_name+"_"+key+"_"+str(component)
                        forecast_checks[name]=conservative(maximum(difference),refinement,scale,amplitude)
                        locations=np.flatnonzero(difference>CONFIG["numerical_tolerance"]*scale)
                        first_crossing[name]=None if not len(locations) else {
                            "diagnostic_index":int(locations[0]),"tau":float(fine["time"][locations[0]]),
                            "elapsed_Mpc":float(fine["time"][locations[0]]-fine["time"][0]),
                            "sampled_crossing_not_exact_root":True}
            forecasts[mode]={"checks":forecast_checks,"passed":all(item["passed"] for item in forecast_checks.values()),
                             "failed":[name for name,item in forecast_checks.items() if not item["passed"]],
                             "first_raw_error_crossings":first_crossing}
        response=high[:,1,0]-high[:,0,0]
        response_step=maximum((high[:,1,0]-low[:,1,0])-(high[:,0,0]-low[:,0,0]))
        response_amplitude=maximum(envelope[:,0,0]+envelope[:,1,0])
        response_check=conservative(0.,response_step,maximum(response),response_amplitude)
        extrema=np.flatnonzero(np.diff(response)[:-1]*np.diff(response)[1:]<0)+1
        sampled_extrema=[{"index":int(index),"tau":float(fine["time"][index]),"correction":float(response[index])}
                         for index in extrema]
        original=saved_state(case)
        active,width=int(original["dimensions"][1]),int(original["dimensions"][2])
        checks["background_full_units"]=ratio(maximum((fine["normalized"][:,2*active:2*active+width]-
                                                       coarse["normalized"][:,2*active:2*active+width])*1e-7),1.)
        initial,slope=external_from_packet(fine["metric"][0],case)
        actual_external,_=external_from_packet(fine["metric"],case)
        external_norm=np.max(abs(actual_external),axis=0)
        environment={}
        for mode in ("constant","linear"):
            expected=initial[None]+((fine["time"]-fine["time"][0])[:,None,None]*slope[None] if mode=="linear" else 0.)
            environment[mode]=[[ratio(maximum(actual_external[:,branch,component]-expected[:,branch,component]),
                                       external_norm[branch,component]) for component in range(2)] for branch in range(2)]
        reports[case]={"main_checks":checks,"main_passed":all(item["passed"] for item in checks.values()),
                      "independent_controls":controls,"independent_controls_passed":all(item["passed"] for item in controls.values()),
                      "independent_control_scope":"two original report times only; not every diagnostic",
                      "forecasts":forecasts,"surrounding_source_discrepancy":environment,
                      "response_check":response_check,"correction_range":[float(np.min(response)),float(np.max(response))],
                      "endpoint_corrections":response[native_indices].tolist(),"sampled_extrema":sampled_extrema,
                      "sampling_scope":"existing table boundaries, not an exact continuous extrema proof",
                      "diagnostic_samples":len(fine["time"]),"original_report_samples":2,
                      "initial_final_native_velocity":high[native_indices,:,0].tolist()}
    result={"cases":reports,"main_passed":all(report["main_passed"] for report in reports.values()),
            "independent_controls_passed":all(report["independent_controls_passed"] for report in reports.values()),
            "all_scientific_tests_pass":all(report["main_passed"] and report["independent_controls_passed"] and
                 report["response_check"]["passed"] and all(item["passed"] for item in report["forecasts"].values()) for report in reports.values()),
            "no_observational_fit_or_quantum_measure_claim":True}
    write(ROOT / "science-score.json",result)
    print(json.dumps({case:{"main":report["main_passed"],"controls":report["independent_controls_passed"],
          "forecast_failures":{mode:item["failed"] for mode,item in report["forecasts"].items()},
          "response":report["response_check"],"extrema_count":len(report["sampled_extrema"]),
          "correction_range":report["correction_range"]} for case,report in reports.items()}),flush=True)

if __name__=="__main__":
    with worker("score"):
        score()
