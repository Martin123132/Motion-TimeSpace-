from restart_bridge import *
import argparse

sys.path.insert(0, str(PHASE))
import run_phase as phase
from run_phase import field, readouts, coordinates, external_from_packet, COLUMNS

def saved_state(case):
    return load(PHASE / (case + "-live-64-terminal.npz"))

phase.saved_state = saved_state

def prepare():
    require(digest(PHASE / "closeout.json") == CONFIG["phase_seal"], "accepted phase seal")
    mapping = read(PHASE / "inputs.json")
    mapping[str(PHASE / "closeout.json")] = CONFIG["phase_seal"]
    for name, entry in read(PHASE / "closeout.json")["artifacts"].items():
        mapping[str(PHASE / name)] = entry["sha256"]
    check_inputs(mapping)
    report = {}
    for case in CONFIG["cases"]:
        saved = saved_state(case)
        source = phase.source_paths(case)
        with np.load(source) as archive:
            original = archive["conformal_time"][CONFIG["start_index"]:CONFIG["last_index"]+1]
            scales = archive["requested_scale"][CONFIG["start_index"]:CONFIG["last_index"]+1]
        require(len(original) == 2 and original[0] == float(saved["tau"]), "complete saved3038 endpoint")
        prepared, _, background, _, _ = EX.problem(case)
        boundaries = background.boundaries(float(original[0]), float(original[-1]))
        queries = np.concatenate(([original[0]], boundaries, [original[-1]]))
        require(np.all(np.diff(queries) > 0), "ordered original background boundaries")
        background.evaluate(queries)
        for field_spline, velocity_spline in background.fields:
            require(np.array_equal(field_spline.x, velocity_spline.x), "field and velocity share table knots")
        maximum_step = float(prepared["elapsed"][8]) / min(CONFIG["steps"])
        np.savez_compressed(ROOT / (case + "-clock.npz"), time=queries, native_time=original,
                            native_indices=np.array([0, len(queries)-1]), requested_scale=scales)
        report[case] = {"native_epochs": [3038,3039], "diagnostic_samples": len(queries),
                        "background_boundaries": len(boundaries), "elapsed_Mpc": float(original[-1]-original[0]),
                        "maximum_diagnostic_gap": float(np.max(np.diff(queries))),
                        "maximum_internal_step_32": maximum_step, "background_support_passed": True}
        if case == "heavy":
            jets = background.evaluate(queries)
            omega = np.sqrt(CONFIG["retained_comoving_wave"]**2 + jets["jets"][1][-1])
            period = 2*np.pi/omega
            report[case].update(minimum_principal_period=float(np.min(period)),
                                largest_diagnostic_gap_in_periods=float(np.max(np.diff(queries))/np.min(period)),
                                largest_internal_step_in_periods=float(maximum_step/np.min(period)))
        mapping[str(source)] = digest(source)
        mapping[str(ROOT / (case + "-clock.npz"))] = digest(ROOT / (case + "-clock.npz"))
    write(ROOT / "frozen-norms.json", read(PHASE / "frozen-norms.json"))
    write(ROOT / "preparation.json", report)
    for path in ROOT.glob("*"):
        if path.suffix in (".py",".md",".json") and not path.name.endswith(("-start.json","-end.json","-failure.json")):
            mapping[str(path)] = digest(path)
            if path.suffix == ".py":
                compile(path.read_text(encoding="utf-8"), str(path), "exec")
    write(ROOT / "inputs.json", mapping)
    write(ROOT / "score-plan.json", {"utc": datetime.now(timezone.utc).isoformat(),
          "files": {str(ROOT / "score_gap.py"): digest(ROOT / "score_gap.py"),
                    str(ROOT / "verify_gap.py"): digest(ROOT / "verify_gap.py")},
          "checks": "Frozen2e-5 original norms,32/64 refinements and primitive rounding. All diagnostic samples; native independent controls only original3038 and3039. Sampled extrema are not a continuous bound."})
    inputs()
    print(json.dumps({"inputs": len(mapping), "preparation": report}), flush=True)

def live(case, steps):
    inputs()
    frozen = read(ROOT / "predictions-frozen.json")
    require(frozen["future_native_evolution_not_started"], "predictions frozen first")
    check_inputs(frozen["files"])
    check_inputs(read(ROOT / "score-plan.json")["files"])
    label = case + "-live-" + str(steps)
    prepared, _, background, _, _ = EX.problem(case)
    with native_context(case, label) as (captured, metadata, sample):
        previous = load(PHASE / (case + "-live-64-capture.npz"))
        for name, values in captured.items():
            require(np.array_equal(values[:1048], previous[name]), "known1048 native owner prefix: " + name)
        system = MetricCoupled(case, prepared, background, prefix(captured, case), metadata, sample)
        saved = restore(system, PHASE / (case + "-live-64-terminal.npz"))
        clock = load(ROOT / (case + "-clock.npz"))
        times = clock["time"]
        require(np.array_equal(clock["native_time"], captured["clock"][-2:]), "same native report clock")
        current = saved["normalized"]
        blocks, states, details = [], [], []
        endings = list(range(CONFIG["batch_boundaries"], len(times)-1, CONFIG["batch_boundaries"])) + [len(times)-1]
        begin = 0
        for end in endings:
            batch_label = label + "-boundary" + str(end)
            queries = times[begin:end+1]
            output, normalized, integration = integrate(system, float(queries[0]), float(queries[-1]),
                                                        current, queries, steps, batch_label, cursor=False)
            current = normalized[-1]
            np.savez_compressed(ROOT / (batch_label + "-history.npz"), time=queries, normalized=normalized, **output)
            checkpoint(system, float(queries[-1]), current, ROOT / (batch_label + "-terminal.npz"))
            blocks.append({name: values if begin == 0 else values[1:] for name,values in output.items()})
            states.append(normalized if begin == 0 else normalized[1:])
            details.append({"begin":begin,"end":end,**integration})
            print(json.dumps({"case":case,"steps":steps,"boundary":end,"of":len(times)-1}), flush=True)
            begin = end
        output = {name: np.concatenate([block[name] for block in blocks]) for name in blocks[0]}
        state = np.concatenate(states)
        observer = captured["observation_reference"][-2:]
        native_control = np.column_stack((-CONFIG["retained_comoving_wave"]*(observer[:,26]+observer[:,5])/observer[:,28],
                                         observer[:,9],observer[:,21],observer[:,20]-.75*observer[:,21],
                                         observer[:,26]-.75*observer[:,24]))
        np.savez_compressed(ROOT / (label+".npz"), time=times, normalized=state,
                            native_indices=clock["native_indices"], native_control=native_control, **output)
        checkpoint(system,float(times[-1]),state[-1],ROOT / (label+"-terminal.npz"))
        write(ROOT / (label+"-result.json"), {"case":case,"steps":steps,"batches":details,
              "last_epoch":3039,"diagnostic_samples":len(times),"original_report_samples":2,
              "fresh_initial_rhs_exact":True,"prefix1048_exact":True,"complete_terminal_saved":True})
    inputs()
    check_inputs(frozen["files"])

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("prepare","predict","freeze","live"))
    parser.add_argument("--case",choices=CONFIG["cases"])
    parser.add_argument("--mode",choices=("constant","linear"),default="linear")
    parser.add_argument("--steps",type=int,choices=CONFIG["steps"],default=64)
    arguments=parser.parse_args()
    label=arguments.command if arguments.command in ("prepare","freeze") else arguments.case+"-"+(
        arguments.mode+"-predict" if arguments.command=="predict" else "live")+"-"+str(arguments.steps)
    with worker(label):
        if arguments.command=="prepare":
            prepare()
        elif arguments.command=="predict":
            phase.predict(arguments.case,arguments.mode,arguments.steps)
        elif arguments.command=="freeze":
            phase.freeze_predictions()
        else:
            live(arguments.case,arguments.steps)

if __name__=="__main__":
    main()
