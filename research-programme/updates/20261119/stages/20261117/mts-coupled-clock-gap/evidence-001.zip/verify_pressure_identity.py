from restart_support import *
import sympy as sp

if __name__=="__main__":
    with worker("pressure-identity"):
        phi,velocity,perturbation,speed,hubble,hubble_prime,rate,mass,wave,metric,field_defect,velocity_defect,beta=sp.symbols(
            "Phi V f g H Hprime r mu2 k z F G beta")
        pressure=velocity*speed-mass*phi*perturbation
        product=phi*perturbation
        current=velocity*perturbation+phi*speed
        flow={phi:velocity+field_defect,velocity:-2*hubble*velocity-mass*phi+velocity_defect,
              perturbation:speed,speed:-2*hubble*speed-(wave**2+mass)*perturbation-wave*velocity*metric,
              hubble:hubble_prime,beta:rate*beta}
        derivative=lambda expression:sum(sp.diff(expression,variable)*value for variable,value in flow.items())
        current_expected=-2*hubble*current+2*pressure-wave**2*product-wave*phi*velocity*metric+velocity_defect*perturbation+field_defect*speed
        boundary=hubble*beta*current/2
        remainder=beta*((2*hubble**2-hubble_prime-hubble*rate)*current+hubble*wave**2*product+
                        hubble*wave*phi*velocity*metric-hubble*(velocity_defect*perturbation+field_defect*speed))/2
        difference=sp.expand(hubble*beta*pressure-derivative(boundary)-remainder)
        coherent={rate:hubble,field_defect:0,velocity_defect:0}
        checks={"product_derivative":sp.simplify(derivative(product)-current-field_defect*perturbation)==0,
                "scalar_pressure_identity":sp.simplify(derivative(current)-current_expected)==0,
                "weighted_pressure_work_identity":sp.simplify(difference)==0,
                "coherent_specialization":sp.simplify(difference.subs(coherent))==0,
                "boundary_cannot_generically_be_removed":sp.simplify(difference+derivative(boundary))!=0,
                "gradient_cannot_generically_be_removed":sp.simplify(difference+beta*hubble*wave**2*product/2)!=0,
                "metric_work_cannot_generically_be_removed":sp.simplify(difference+beta*hubble*wave*phi*velocity*metric/2)!=0,
                "old_representation_contacts_cannot_generically_be_removed":sp.simplify(
                    difference-beta*hubble*(velocity_defect*perturbation+field_defect*speed)/2)!=0}
        result={"passed":all(bool(value) for value in checks.values()),"checks":{name:bool(value) for name,value in checks.items()},
                "document_sha256":digest(ROOT / "PRESSURE-IDENTITY.md"),"numerical_evaluation_performed":False,
                "no_dust_limit_or_closure_assumed":True}
        write(ROOT / "pressure-identity.json",result)
        require(result["passed"],"symbolic pressure identities")
        print(json.dumps(result),flush=True)
