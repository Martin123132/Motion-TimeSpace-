from live_second import *
from audit_second import audit_coefficients,audit_live
from run_phase import source_paths,readouts
import argparse


def saved(case):
    return LIVE/(case+('-phase-' if case=='heavy' else '-direct-')+'64-terminal.npz')


def prepare():
    previous=Path(CONFIG['envelope_directory'])
    require(digest(previous/'closeout.json')==CONFIG['envelope_seal'],'accepted derived-envelope seal')
    mapping=read(previous/'inputs.json')
    mapping[str(previous/'closeout.json')]=CONFIG['envelope_seal']
    for name,item in read(previous/'closeout.json')['artifacts'].items():
        mapping[str(previous/name)]=item['sha256']
    check_inputs(mapping)
    report={}
    for case in CONFIG['cases']:
        state=load(saved(case))
        path=source_paths(case)
        with np.load(path,allow_pickle=False) as archive:
            clocks=archive['conformal_time'][CONFIG['start_index']:CONFIG['last_index']+1]
            scales=archive['requested_scale'][CONFIG['start_index']:CONFIG['last_index']+1]
        require(len(clocks)==2 and clocks[0]==float(state['tau']),'complete3040 to next original3041')
        prepared,_,background,_,_=EX.problem(case)
        times=np.unique(np.r_[clocks[0],background.boundaries(float(clocks[0]),float(clocks[-1])),clocks[-1]])
        require(np.all(np.diff(times)>0),'positive unchanged support')
        background.evaluate(times)
        np.savez_compressed(ROOT/(case+'-clock.npz'),time=times,native_time=clocks,native_indices=np.array([0,len(times)-1]),requested_scale=scales)
        report[case]={'samples':len(times),'elapsed_Mpc':float(clocks[-1]-clocks[0]),'steps32':float(prepared['elapsed'][8])/32,'steps64':float(prepared['elapsed'][8])/64}
        mapping[str(path)]=digest(path)
    write(ROOT/'frozen-norms.json',read(LIVE/'frozen-norms.json'))
    write(ROOT/'preparation.json',{'utc':datetime.now(timezone.utc).isoformat(),'cases':report,'before_evolution':True,'future_source_metric_forcing':False})
    for path in sorted(ROOT.iterdir()):
        if path.suffix in ('.py','.json','.md','.npz') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix=='.py':
                compile(path.read_text(encoding='utf-8'),str(path),'exec')
            mapping[str(path)]=digest(path)
    write(ROOT/'inputs.json',mapping)
    inputs()
    print(json.dumps(report),flush=True)


def systems(case,captured,metadata,sample):
    label=case+('-phase-' if case=='heavy' else '-direct-')+'64-capture.npz'
    previous=load(LIVE/label)
    for name,value in captured.items():
        require(np.array_equal(value[:1050],previous[name]),'known1050 owner prefix: '+name)
    prepared,_,background,_,_=EX.problem(case)
    initial=prefix(captured,case)
    direct=MetricCoupled(case,prepared,background,initial,metadata,sample)
    state=restore(direct,saved(case))
    reduced=LiveSecond(case,prepared,background,initial,metadata,sample) if case=='heavy' else None
    return direct,reduced,state


def preflight(case):
    inputs()
    label=case+'-preflight'
    with native_context(case,label) as (captured,metadata,sample):
        direct,reduced,state=systems(case,captured,metadata,sample)
        result={'passed':True,'original_rhs_restored_exact':True,'known1050_prefix_exact':True}
        if case=='heavy':
            controls=audit_coefficients(direct,float(state['tau']),state['normalized'])
            result=audit_live(reduced,direct,float(state['tau']),state['normalized'])
            write(ROOT/'stable-pair-controls.json',controls)
        write(ROOT/(label+'-result.json'),result)
        print(json.dumps({'case':case,'passed':True}),flush=True)
    inputs()


def run(case,mode,steps):
    inputs()
    require(read(ROOT/(case+'-preflight-result.json'))['passed'],'preflight before live evolution')
    label=case+'-'+mode+'-'+str(steps)
    with native_context(case,label) as (captured,metadata,sample):
        direct,reduced,state=systems(case,captured,metadata,sample)
        system=reduced if mode=='order2' else direct
        require(system is not None,'defined live response')
        clocks=load(ROOT/(case+'-clock.npz'))
        times=clocks['time']
        require(np.array_equal(captured['clock'][-2:],clocks['native_time']),'unchanged original report endpoints')
        current=reduced.encode(state['normalized']) if mode=='order2' else state['normalized'].copy()
        native_size=len(direct.initial)
        states=[current.copy()]
        initial=system.evaluate(float(times[0]),current)[1]
        observed={name:np.empty((len(times),*np.asarray(value).shape)) for name,value in initial.items()}
        for name,value in initial.items():
            observed[name][0]=value
        evaluations=0
        for position,(left,right) in enumerate(zip(times[:-1],times[1:])):
            guard()
            solution=solve_ivp(system.rhs,(float(left),float(right)),current,method='DOP853',t_eval=[right],
                rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(system.prepared['elapsed'][8])/steps)
            require(solution.success,'live parent/control continuation')
            current=solution.y[:,-1]
            evaluations+=solution.nfev
            states.append(current.copy())
            output=system.evaluate(float(right),current)[1]
            for name,value in output.items():
                observed[name][position+1]=value
            if (position+1)%CONFIG['batch_boundaries']==0 or position==len(times)-2:
                batch=label+'-boundary'+str(position+1)
                np.savez_compressed(ROOT/(batch+'-state.npz'),tau=np.array(right),normalized=current,actual_rhs=system.rhs(float(right),current),completed=np.array(position+1))
                print(json.dumps({'label':label,'boundary':position+1,'total':len(times)-1}),flush=True)
        reference=captured['observation_reference'][-2:]
        control=np.column_stack((-CONFIG['retained_comoving_wave']*(reference[:,26]+reference[:,5])/reference[:,28],reference[:,9],reference[:,21],reference[:,20]-.75*reference[:,21],reference[:,26]-.75*reference[:,24]))
        np.savez_compressed(ROOT/(label+'.npz'),time=times,normalized=np.array(states)[:,:native_size],extended=np.array(states),native_indices=clocks['native_indices'],native_control=control,**observed)
        checkpoint(direct,float(times[-1]),current[:native_size],ROOT/(label+'-terminal.npz'))
        if mode=='order2':
            np.savez_compressed(ROOT/(label+'-order2-terminal.npz'),tau=np.array(times[-1]),normalized=current,actual_rhs=system.rhs(float(times[-1]),current),native_size=np.array(native_size),
                matrix_units=reduced.matrix_units,matrix_change_units=reduced.matrix_change_units,defect_units=reduced.defect_units,defect_change_units=reduced.defect_change_units)
        write(ROOT/(label+'-result.json'),{'completed':True,'case':case,'mode':mode,'steps':steps,'last_epoch':3041,'samples':len(times),
            'evaluations':evaluations,'saved_future_forcing_used':False,'actual_metric_derivatives':True,'full_native_control_rhs_saved_separately':mode=='order2'})
    inputs()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=('prepare','preflight','run'))
    parser.add_argument('--case',choices=CONFIG['cases'],default='heavy')
    parser.add_argument('--mode',choices=('direct','order2'),default='order2')
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=32)
    arguments=parser.parse_args()
    label='prepare' if arguments.command=='prepare' else arguments.case+'-'+('preflight' if arguments.command=='preflight' else arguments.mode+'-'+str(arguments.steps))
    with worker(label):
        if arguments.command=='prepare':prepare()
        elif arguments.command=='preflight':preflight(arguments.case)
        else:run(arguments.case,arguments.mode,arguments.steps)
