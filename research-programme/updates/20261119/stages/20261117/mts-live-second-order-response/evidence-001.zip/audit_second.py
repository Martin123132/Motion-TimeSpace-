from live_second import *
import mpmath as mp
mp.mp.dps=80
sys.path.insert(0,str(Path(CONFIG['envelope_directory'])))
from envelope_math import coefficients as independent_coefficients


def reference(raw,branch):
    values={name:mp.mpf(item.base)+(mp.mpf(item.change) if branch else 0) for name,item in raw.items()}
    mu,hubble,rate,phi,velocity=(values[name] for name in ('mu','hubble','rate','phi','velocity'))
    wave=mp.mpf(CONFIG['retained_comoving_wave'])
    omega=mp.sqrt(mu*mu+wave*wave)
    amplitude=mp.sqrt(mu*phi*phi+velocity*velocity/mu)
    cosine,sine=mp.sqrt(mu)*phi/amplitude,-velocity/mp.sqrt(mu)/amplitude
    contact=(-values['velocity_contact']/mp.sqrt(mu)*cosine-mp.sqrt(mu)*values['field_contact']*sine)/amplitude
    beat=wave*wave/(omega+mu)
    zeta=hubble+rate/2
    xi=hubble+rate*mu*mu/(2*omega*omega)
    slow=mp.matrix([[-hubble,-beat+contact],[beat-contact,-hubble]])
    fast=mp.matrix([[xi*(cosine*cosine-sine*sine),-2*xi*cosine*sine-2*zeta*cosine*sine],
                    [-2*xi*cosine*sine+2*zeta*cosine*sine,-xi*(cosine*cosine-sine*sine)]])
    transform=mp.matrix([[cosine*mp.sqrt(omega),-sine/mp.sqrt(omega)],[-sine*mp.sqrt(omega),-cosine/mp.sqrt(omega)]])
    source=mp.matrix([[mu*mu*phi,velocity],[wave*velocity,0]])
    return dict(slow=slow,fast=fast,transform=transform,source_matrix=source,beta=values['beta'])


def mp_array(value):
    return mp.matrix(np.asarray(value).tolist())


def numerical(value):
    return np.array(value.tolist(),dtype=float)


def audit_coefficients(system,clock,state):
    _,_,physical,_,_=system.unpack(state)
    tests={}
    for multiplier in (0.,.001,1.,100.):
        terms=coefficients(system.model,system.prepared,clock,physical*multiplier)
        references=[reference(terms['raw'],branch) for branch in (0,1)]
        for name in ('slow','fast','transform','source_matrix'):
            for branch,label in enumerate(('base','change')):
                target=references[0][name] if branch==0 else references[1][name]-references[0][name]
                expected=numerical(target)
                tests[str(multiplier)+'_'+name+'_'+label]=ratio(maximum(terms[name][branch]-expected),max(maximum(expected),1e-90),CONFIG['algebra_tolerance'])
        fields=(np.array([.13,-.07]),np.array([2e-10,-3e-10]))
        first=(np.array([[3e-4,-2e-4],[4e-4,1e-4]]),np.array([[2e-11,3e-11],[-1e-11,4e-11]]))
        second=(np.array([[5e-6,3e-6],[-2e-6,4e-6]]),np.array([[2e-12,-3e-12],[1e-12,2e-12]]))
        actual=recurrence_and_residual(terms,fields,first,second)
        expected=[]
        for branch in (0,1):
            values=references[branch]
            first_value=mp_array(first[0])+(mp_array(first[1]) if branch else mp.zeros(2))
            second_value=mp_array(second[0])+(mp_array(second[1]) if branch else mp.zeros(2))
            fields_value=mp_array(fields[0])+(mp_array(fields[1]) if branch else mp.zeros(2,1))
            slow,fast,transform=values['slow'],values['fast'],values['transform']
            reduced=(mp.eye(2)+first_value+second_value)**-1*transform*fields_value
            residual=transform**-1*fast*second_value*reduced
            unweighted=-values['source_matrix']*residual
            expected.append([slow*first_value-first_value*slow+fast,
                slow*second_value-second_value*slow+fast*first_value,residual,values['beta']*unweighted,unweighted])
        for index,name in enumerate(('K1prime','K2prime','field_residual','weighted','unweighted')):
            for branch,label in enumerate(('base','change')):
                target=expected[0][index] if branch==0 else expected[1][index]-expected[0][index]
                value=numerical(target)
                if index>=2:
                    value=value.ravel()
                tests[str(multiplier)+'_'+name+'_'+label]=ratio(maximum(actual[index][branch]-value),max(maximum(value),1e-90),CONFIG['algebra_tolerance'])
    require(all(item['passed'] for item in tests.values()),'80-digit factored coefficient/response audit')
    return tests


def audit_live(system,direct,clock,native):
    initial=system.encode(native)
    direct_rhs,direct_output=direct.evaluate(clock,native)
    actual_rhs,output=system.evaluate(clock,initial)
    checks={'initial_native_rhs_exact':np.array_equal(direct_rhs,actual_rhs[:system.native_size]),
        'initial_metric_exact':np.array_equal(direct_output['metric'],output['metric']),
        'initial_source_exact':np.array_equal(direct_output['source'],output['source']),
        'initial_truncation_zero':bool(np.all(output['field_truncation']==0)),
        'fast_rhs_exact':np.array_equal(system.rhs(clock,initial),actual_rhs)}
    manufactured=initial.copy()
    first=np.array([[3e-4,-2e-4],[4e-4,1e-4]])
    second=np.array([[5e-6,3e-6],[-2e-6,4e-6]])
    manufactured[system.native_size:system.native_size+8]=np.stack((first,second)).ravel()/system.matrix_units
    manufactured[system.native_size+8:system.native_size+16]=np.stack((first,second)).ravel()*1e-6/system.matrix_change_units
    rhs,observed=system.evaluate(clock,manufactured)
    old,change,physical,_,_=system.unpack(native)
    terms=coefficients(system.model,system.prepared,clock,physical)
    numeric={}
    wave=CONFIG['retained_comoving_wave']
    for branch in (0,1):
        values={name:item.base+branch*item.change for name,item in terms['raw'].items()}
        values.update(mass2=values['mu']**2,metric=observed['metric_force'][0]+branch*observed['metric_force'][1])
        independent=independent_coefficients(values)
        fields=old[system.selected]+branch*change[system.selected]
        modified_rhs=rhs[system.selected]*system.state_units[system.selected]+branch*rhs[system.active+system.selected]*system.delta_units[system.selected]
        full=np.eye(2)+(first+second)*(1+branch*1e-6)
        first_branch,second_branch=first*(1+branch*1e-6),second*(1+branch*1e-6)
        slow,fast=independent['slow'],independent['fast']
        full_prime=slow@(first_branch+second_branch)-(first_branch+second_branch)@slow+fast@(np.eye(2)+first_branch)
        reduced=np.linalg.solve(full,independent['transform']@fields)
        actual=np.linalg.solve(full,independent['transform_prime']@fields+independent['transform']@modified_rhs-full_prime@reduced)
        expected=slow@reduced+np.linalg.solve(full,independent['force'])
        numeric['branch'+str(branch)+'_normal_form']=ratio(maximum(actual-expected),maximum(abs(actual)+abs(expected)),CONFIG['algebra_tolerance'])
        packet=observed['metric'][branch]
        species=packet[:84].reshape(7,12)
        phi_prime=values['velocity']+values['field_contact']
        velocity_prime=-2*values['hubble']*values['velocity']-values['mass2']*values['phi']+values['velocity_contact']
        pieces=np.array([velocity_prime*fields[1],values['velocity']*modified_rhs[1],2*values['rate']*values['mass2']*values['phi']*fields[0],
            values['mass2']*phi_prime*fields[0],values['mass2']*values['phi']*modified_rhs[0]])
        numeric['branch'+str(branch)+'_actual_Dprime']=ratio(abs(np.sum(pieces)-species[6,7]),float(np.sum(abs(pieces))),CONFIG['algebra_tolerance'])
        current_prime=wave*(velocity_prime*fields[0]+values['velocity']*modified_rhs[0])
        numeric['branch'+str(branch)+'_actual_Qprime']=ratio(abs(current_prime-species[6,8]),abs(wave*velocity_prime*fields[0])+abs(wave*values['velocity']*modified_rhs[0]),CONFIG['algebra_tolerance'])
        hubble=field(packet,'hubble')
        force=field(packet,'z')
        force_prime=(np.sum(species[:,7])/(2*wave)+field(packet,'eta_k_prime')-field(packet,'hubble_prime')*force)/hubble
        shear_prime=force_prime+3*np.sum(species[:,8])/(2*wave**2)
        numeric['branch'+str(branch)+'_actual_zprime']=ratio(abs(force_prime-field(packet,'z_prime')),max(abs(force_prime),1e-30),CONFIG['algebra_tolerance'])
        numeric['branch'+str(branch)+'_actual_sigmaprime']=ratio(abs(shear_prime-field(packet,'sigma_prime')),max(abs(shear_prime),1e-30),CONFIG['algebra_tolerance'])
    checks['nonzero_truncation_tested']=bool(np.max(abs(observed['field_truncation']))>0)
    checks['nonzero_live_and_actual_metric_controls']=all(value['passed'] for value in numeric.values())
    require(all(checks.values()),'actual RHS/source/metric preflight: '+str(checks))
    return {'checks':checks,'numeric':numeric,'passed':True}
