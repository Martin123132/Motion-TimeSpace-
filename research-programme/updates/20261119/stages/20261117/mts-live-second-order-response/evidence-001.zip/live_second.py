from restart_bridge import *
LIVE = Path(CONFIG['live_directory'])
sys.path.insert(0,str(LIVE))
from live_phase import Pair


def square_root(value):
    require(value.base>0 and value.base+value.change>0,'positive pair root')
    base=np.sqrt(value.base)
    return Pair(base,value.change/(base+np.sqrt(value.base+value.change)))


def unpack_matrix(matrix):
    return tuple(np.array([[getattr(value,part) for value in row] for row in matrix]) for part in ('base','change'))


def multiply(left,right):
    return left[0]@right[0],(left[0]+left[1])@right[1]+left[1]@right[0]


def add(left,right):
    return left[0]+right[0],left[1]+right[1]


def subtract(left,right):
    return left[0]-right[0],left[1]-right[1]


def solve(matrix,vector):
    base=np.linalg.solve(matrix[0],vector[0])
    return base,np.linalg.solve(matrix[0]+matrix[1],vector[1]-matrix[1]@base)


def coefficients(model,prepared,clock,physical):
    base=model.represented(clock)
    alpha,field_change,velocity_change=model.unpack(physical)
    hubble_change,_=model.correction_geometry(base,physical,False)
    scale=Pair(base['scale'],base['scale']*alpha)
    hubble=Pair(base['hubble'],hubble_change)
    rate=Pair(base['rate'],hubble_change+(base['hubble']-base['rate']))
    phi=Pair(base['field'][1],field_change[1])
    velocity=Pair(base['velocity'][1],velocity_change[1])
    field_contact=base['field_first'][1]-base['velocity'][1]
    velocity_contact=base['velocity_first'][1]+2*base['hubble']*base['velocity'][1]+base['mass'][1]*base['field'][1]
    contact_field,contact_velocity=Pair(field_contact,-field_contact),Pair(velocity_contact,-velocity_contact)
    wave=CONFIG['retained_comoving_wave']
    mu=scale*model.constants[7]
    mass2=mu**2
    omega=square_root(mass2+wave**2)
    root_mu,root_omega=square_root(mu),square_root(omega)
    background_first,background_second=root_mu*phi,-velocity/root_mu
    amplitude=square_root(background_first**2+background_second**2)
    cosine,sine=background_first/amplitude,background_second/amplitude
    phase_contact=(-contact_velocity/root_mu*cosine-root_mu*contact_field*sine)/amplitude
    beat=wave**2/(omega+mu)
    zeta=hubble+rate/2
    xi=hubble+rate*mass2/(2*omega**2)
    rotating=zeta*2*cosine*sine
    symmetric=xi*(cosine**2-sine**2)
    crossing=-xi*2*cosine*sine
    slow=unpack_matrix([[-hubble,-beat+phase_contact],[beat-phase_contact,-hubble]])
    fast=unpack_matrix([[symmetric,crossing-rotating],[crossing+rotating,-symmetric]])
    transform=unpack_matrix([[cosine*root_omega,-sine/root_omega],[-sine*root_omega,-cosine/root_omega]])
    source_matrix=unpack_matrix([[mass2*phi,velocity],[wave*velocity,Pair(0.)]])
    beta=scale/float(prepared['density0'])
    norm=np.array([abs(rotating.base)+abs(xi.base),abs(rotating.base+rotating.change)+abs(xi.base+xi.change)])
    return dict(slow=slow,fast=fast,transform=transform,source_matrix=source_matrix,beta=beta,norm=norm,
        raw=dict(mu=mu,hubble=hubble,rate=rate,phi=phi,velocity=velocity,field_contact=contact_field,
            velocity_contact=contact_velocity,beta=beta))


def recurrence_and_residual(terms,fields,first,second):
    slow,fast,transform=terms['slow'],terms['fast'],terms['transform']
    first_rhs=add(subtract(multiply(slow,first),multiply(first,slow)),fast)
    second_rhs=add(subtract(multiply(slow,second),multiply(second,slow)),multiply(fast,first))
    full=(np.eye(2)+first[0]+second[0],first[1]+second[1])
    reduced=solve(full,multiply(transform,fields))
    residual=solve(transform,multiply(multiply(fast,second),reduced))
    unweighted=multiply(terms['source_matrix'],residual)
    beta=terms['beta']
    weighted=(-beta.base*unweighted[0],-((beta.base+beta.change)*unweighted[1]+beta.change*unweighted[0]))
    return first_rhs,second_rhs,residual,weighted,(-unweighted[0],-unweighted[1])


def actual_metric(original,extra):
    result=original.copy()
    wave=CONFIG['retained_comoving_wave']
    additions=np.stack((extra[0],extra[0]+extra[1]))
    for branch in (0,1):
        density,current=additions[branch]
        hubble=field(original[branch],'hubble')
        trace=density/(2*wave*hubble)
        shear=trace+3*current/(2*wave**2)
        result[branch,6*12+7]+=density
        result[branch,6*12+8]+=current
        result[branch,6*12+10]+=density
        result[branch,6*12+11]+=current
        for name,value in (('z_prime',trace),('sigma_prime',shear),('density_defect',density),('current_defect',current),
            ('predicted_density_defect',density),('predicted_current_defect',current),('trace_residual',trace),
            ('predicted_trace_residual',trace),('shear_residual',shear),('predicted_shear_residual',shear)):
            result[branch,COLUMNS[name]]+=value
    return result


class LiveSecond(MetricCoupled):
    def __init__(self,*arguments):
        super().__init__(*arguments)
        require(self.case=='heavy','heavy retained scalar only')
        self.native_size=len(self.initial)
        self.selected=np.array([self.first+2,self.first+3])
        self.matrix_units=np.repeat(np.array(CONFIG['matrix_units']),4)
        self.matrix_change_units=self.matrix_units*CONFIG['matrix_change_factor']
        self.defect_units=np.array(read(ROOT/'frozen-norms.json')['heavy']['source_norm'][:2])
        self.defect_change_units=self.defect_units*1e-5

    def encode(self,normalized):
        return np.r_[normalized,np.zeros(22)]

    def calculate(self,clock,state,readout):
        native=state[:self.native_size]
        extra=state[self.native_size:]
        old,change,physical,_,_=self.unpack(native)
        terms=coefficients(self.model,self.prepared,clock,physical)
        old_matrices=(extra[:8]*self.matrix_units).reshape(2,2,2)
        changes=(extra[8:16]*self.matrix_change_units).reshape(2,2,2)
        first=(old_matrices[0],changes[0])
        second=(old_matrices[1],changes[1])
        first_rhs,second_rhs,residual,weighted,unweighted=recurrence_and_residual(terms,(old[self.selected],change[self.selected]),first,second)
        require(np.all(extra[20:22]+.5*extra[20:22]**2<1),'coefficient inverse bound')
        native_rhs,values=super().evaluate(clock,native) if readout else retained_run.Coupled.evaluate(self,clock,native)
        native_rhs[self.selected]-=residual[0]/self.state_units[self.selected]
        native_rhs[self.active+self.selected]-=residual[1]/self.delta_units[self.selected]
        appended=np.r_[np.stack((first_rhs[0],second_rhs[0])).ravel()/self.matrix_units,
            np.stack((first_rhs[1],second_rhs[1])).ravel()/self.matrix_change_units,
            weighted[0]/self.defect_units,weighted[1]/self.defect_change_units,terms['norm']]
        values.update(truncation_rhs=np.stack(weighted),truncation_work=np.stack((extra[16:18]*self.defect_units,extra[18:20]*self.defect_change_units)),
            field_truncation=np.stack(residual),coefficient_matrices=np.stack((old_matrices,old_matrices+changes)),coefficient_integral=extra[20:22].copy())
        if readout:
            values['native_equation_metric']=values['metric'].copy()
            values['metric']=actual_metric(values['metric'],unweighted)
        return np.r_[native_rhs,appended],values

    def evaluate(self,clock,state):
        return self.calculate(clock,state,True)

    def rhs(self,clock,state):
        self.calls+=1
        if self.calls%128==0:
            guard()
        return self.calculate(clock,state,False)[0]
