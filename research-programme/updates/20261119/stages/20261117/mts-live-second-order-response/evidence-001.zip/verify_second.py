from score_second import *


def verify():
    inputs()
    science=read(ROOT/'science-score.json')
    checks={'score_replay':calculate()==science}
    norms=read(ROOT/'frozen-norms.json')
    for case in CONFIG['cases']:
        checks[case+'_preflight']=read(ROOT/(case+'-preflight-result.json'))['passed']
        for mode in (('direct','order2') if case=='heavy' else ('direct',)):
            for steps in CONFIG['steps']:
                label=case+'-'+mode+'-'+str(steps)
                data=load(ROOT/(label+'.npz'))
                terminal=load(ROOT/(label+'-terminal.npz'))
                initial=load(saved(case))
                checks[label+'_finite']=all(bool(np.isfinite(value).all()) for value in data.values())
                checks[label+'_initial_exact']=np.array_equal(data['normalized'][0],initial['normalized'])
                checks[label+'_terminal_exact']=np.array_equal(data['normalized'][-1],terminal['normalized'])
                checks[label+'_units_unchanged']=np.array_equal(terminal['units'],initial['units'])
                checks[label+'_owner_released']=read(ROOT/(label+'-owner-release.json'))['cleared']
                checks[label+'_no_future_forcing']=not read(ROOT/(label+'-result.json'))['saved_future_forcing_used']
                for path in ROOT.glob(label+'-boundary*-state.npz'):
                    batch=load(path)
                    index=int(batch['completed'])
                    checks[path.stem+'_exact']=np.array_equal(batch['normalized'],data['extended'][index])
                if mode=='order2':
                    additional=load(ROOT/(label+'-order2-terminal.npz'))
                    checks[label+'_extended_terminal_exact']=np.array_equal(additional['normalized'],data['extended'][-1])
                    checks[label+'_initial_K_zero']=bool(np.all(data['coefficient_matrices'][0]==0))
                    checks[label+'_inverse_bound']=bool(np.max(data['coefficient_integral']+.5*data['coefficient_integral']**2)<1)
                    packet=data['metric']
                    species=packet[...,:84].reshape(len(data['time']),2,7,12)
                    wave=CONFIG['retained_comoving_wave']
                    hubble=field(packet,'hubble')
                    force_prime=(np.sum(species[...,7],axis=-1)/(2*wave)+field(packet,'eta_k_prime')-field(packet,'hubble_prime')*field(packet,'z'))/hubble
                    shear_prime=force_prime+3*np.sum(species[...,8],axis=-1)/(2*wave**2)
                    checks[label+'_actual_metric_zprime']=maximum(force_prime-field(packet,'z_prime'))<=CONFIG['algebra_tolerance']*norms[case]['metric_norm'][3]
                    checks[label+'_actual_metric_sigmaprime']=maximum(shear_prime-field(packet,'sigma_prime'))<=CONFIG['algebra_tolerance']*norms[case]['metric_norm'][4]
                    checks[label+'_actual_shear_identity']=maximum(field(packet,'sigma_prime')-field(packet,'native_sigma_prime')-field(packet,'shear_residual'))<=CONFIG['algebra_tolerance']*norms[case]['metric_norm'][4]
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['no_bytecode']=not list(ROOT.rglob('__pycache__'))
    result={'checks':{name:bool(value) for name,value in checks.items()},'count':len(checks),'passed':all(checks.values()),
        'direct_controls_pass':science['direct_controls_pass'],'live_order2_full_gate_pass':science['live_order2_full_gate_pass'],'all_small_response_precision_pass':science['all_small_response_precision_pass']}
    write(ROOT/'verification.json',result)
    require(result['passed'],'technical live verification: '+str([name for name,value in checks.items() if not value]))
    print(json.dumps({name:result[name] for name in ('count','passed','live_order2_full_gate_pass','all_small_response_precision_pass')}),flush=True)


if __name__=='__main__':
    with worker('verify'):
        verify()
