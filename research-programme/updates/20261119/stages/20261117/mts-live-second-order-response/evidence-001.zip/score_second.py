from run_second import *
from score_phase import conservative
from verify_phase import primitive_envelope
NAMES=('native_velocity','native_weyl','photon_density','relative_density','velocity_slip')


def calculate():
    report={'cases':{},'new_epoch':3041,'future_source_metric_forcing':False}
    for case in CONFIG['cases']:
        norms=read(ROOT/'frozen-norms.json')[case]
        report['cases'][case]={}
        for mode in (('direct','order2') if case=='heavy' else ('direct',)):
            fine=load(ROOT/(case+'-'+mode+'-64.npz'))
            coarse=load(ROOT/(case+'-'+mode+'-32.npz'))
            require(np.array_equal(fine['time'],coarse['time']),'same fixed clocks')
            high,low=readouts(fine['metric']),readouts(coarse['metric'])
            envelope=primitive_envelope(fine['metric'])+primitive_envelope(coarse['metric'])
            checks,independent,accounted={},{},{}
            for branch,name in enumerate(('old','coherent')):
                for component,quantity in enumerate(NAMES):
                    step=maximum(high[:,branch,component]-low[:,branch,component])
                    checks[name+'_'+quantity]=conservative(0.,step,norms['readout_norm'][component],maximum(envelope[:,branch,component]))
                    if branch==0:
                        independent[quantity]=conservative(maximum(high[fine['native_indices'],branch,component]-fine['native_control'][:,component]),step,norms['readout_norm'][component],maximum(envelope[:,branch,component]))
                source=fine['source']+(fine['source_change'] if branch else 0.)
                previous=coarse['source']+(coarse['source_change'] if branch else 0.)
                work=fine['work']+(fine['work_change'] if branch else 0.)
                previous_work=coarse['work']+(coarse['work_change'] if branch else 0.)
                for component,section in ((0,slice(0,6)),(1,slice(6,9))):
                    residual=source[:,component]-source[0,component]-np.sum(work[:,section]-work[0,section],axis=1)
                    lower=previous[:,component]-previous[0,component]-np.sum(previous_work[:,section]-previous_work[0,section],axis=1)
                    amplitude=maximum(abs(source[:,component])+np.sum(abs(work[:,section]),axis=1))
                    checks[name+'_raw_exchange_'+str(component)]=conservative(maximum(residual),maximum(residual-lower),norms['source_norm'][component],amplitude)
                    if mode=='order2':
                        defect=fine['truncation_work'][:,0,component]+(fine['truncation_work'][:,1,component] if branch else 0.)
                        defect_low=coarse['truncation_work'][:,0,component]+(coarse['truncation_work'][:,1,component] if branch else 0.)
                        remainder=residual-(defect-defect[0])
                        remainder_low=lower-(defect_low-defect_low[0])
                        accounted[name+'_'+str(component)]=conservative(maximum(remainder),maximum(remainder-remainder_low),norms['source_norm'][component],amplitude+maximum(defect))
                for component,quantity in enumerate(('density','current','pressure')):
                    checks[name+'_'+quantity+'_refinement']=conservative(0.,maximum(source[:,component]-previous[:,component]),norms['source_norm'][component],maximum(abs(source[:,component])+abs(previous[:,component])))
            for name,index in (('trace_residual',3),('shear_residual',4),('eta_residual',5),('density_constraint',6),('friedmann_constraint',7)):
                values=field(fine['metric'][:,1],name)
                previous=field(coarse['metric'][:,1],name)
                checks['coherent_actual_'+name]=conservative(maximum(values),maximum(values-previous),norms['metric_norm'][index],norms['metric_norm'][index])
            response=high[:,1,0]-high[:,0,0]
            response_step=maximum(response-(low[:,1,0]-low[:,0,0]))
            result={'checks':checks,'raw_main_passed':all(value['passed'] for value in checks.values()),
                'independent_native':independent,'independent_native_passed':all(value['passed'] for value in independent.values()),
                'independent_control_scope':'two original report endpoints',
                'small_response_precision':conservative(0.,response_step,maximum(response),maximum(envelope[:,0,0]+envelope[:,1,0])),
                'response_range':[float(np.min(response)),float(np.max(response))], 'final_response':float(response[-1]),
                'defect_accounted_exchange':accounted,'samples':len(fine['time'])}
            if mode=='order2':
                exact=load(ROOT/'heavy-direct-64.npz')
                exact_low=load(ROOT/'heavy-direct-32.npz')
                exact_read,exact_read_low=readouts(exact['metric']),readouts(exact_low['metric'])
                comparison={}
                for branch,name in enumerate(('old','coherent')):
                    for component,quantity in enumerate(NAMES):
                        comparison[name+'_'+quantity]=conservative(maximum(high[:,branch,component]-exact_read[:,branch,component]),
                            maximum(high[:,branch,component]-low[:,branch,component])+maximum(exact_read[:,branch,component]-exact_read_low[:,branch,component]),
                            norms['readout_norm'][component],maximum(envelope[:,branch,component]+primitive_envelope(exact['metric'])[:,branch,component]))
                    approximate=fine['source']+(fine['source_change'] if branch else 0.)
                    approximate_low=coarse['source']+(coarse['source_change'] if branch else 0.)
                    parent=exact['source']+(exact['source_change'] if branch else 0.)
                    parent_low=exact_low['source']+(exact_low['source_change'] if branch else 0.)
                    for component,quantity in enumerate(('density','current','pressure')):
                        comparison[name+'_'+quantity]=conservative(maximum(approximate[:,component]-parent[:,component]),
                            maximum(approximate[:,component]-approximate_low[:,component])+maximum(parent[:,component]-parent_low[:,component]),
                            norms['source_norm'][component],maximum(abs(approximate[:,component])+abs(parent[:,component])))
                exact_response=exact_read[:,1,0]-exact_read[:,0,0]
                response_difference=conservative(maximum(response-exact_response),response_step+
                    maximum(exact_response-(exact_read_low[:,1,0]-exact_read_low[:,0,0])),maximum(exact_response),
                    maximum(envelope[:,0,0]+envelope[:,1,0]+np.sum(primitive_envelope(exact['metric'])[:,:,0],axis=1)))
                result.update(parent_comparison=comparison,parent_comparison_passed=all(value['passed'] for value in comparison.values()),
                    small_response_parent_comparison=response_difference,maximum_inverse_bound=float(np.max(fine['coefficient_integral']+.5*fine['coefficient_integral']**2)),
                    max_actual_minus_native_trace=float(np.max(abs(field(fine['metric'],'trace_residual')-field(fine['native_equation_metric'],'trace_residual')))))
            report['cases'][case][mode]=result
    direct_pass=all(report['cases'][case]['direct']['raw_main_passed'] and report['cases'][case]['direct']['independent_native_passed'] for case in CONFIG['cases'])
    order=report['cases']['heavy']['order2']
    report['direct_controls_pass']=direct_pass
    report['live_order2_full_gate_pass']=bool(direct_pass and order['raw_main_passed'] and order['parent_comparison_passed'] and order['independent_native_passed'] and all(item['passed'] for item in order['defect_accounted_exchange'].values()))
    report['all_small_response_precision_pass']=all(item['small_response_precision']['passed'] for case in report['cases'].values() for item in case.values()) and order['small_response_parent_comparison']['passed']
    return report


if __name__=='__main__':
    with worker('score'):
        inputs()
        result=calculate()
        write(ROOT/'science-score.json',result)
        print(json.dumps({'direct_controls_pass':result['direct_controls_pass'],'live_order2_full_gate_pass':result['live_order2_full_gate_pass'],'all_small_response_precision_pass':result['all_small_response_precision_pass']}),flush=True)
