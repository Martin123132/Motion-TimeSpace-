import interval_probe as base
from pathlib import Path
import numpy as np


def main():
    base.check_seals();base.guard()
    consumed=base.read(base.SOURCE/'inputs.json');dirs=base.read(base.SOURCE/'protocol.json')['directories']
    schema=base.read(base.POST/'mts-coupled-metric-consistency-20261117/packet-schema.json'); columns={name:84+index for index,name in enumerate(schema['global_columns'])}
    wave=base.read(base.BUDGET/'protocol.json')['retained_comoving_wave']; reports={}
    for label in base.LABELS:
        case,mode=label.split('_');suffix='-'+mode if case=='heavy' else ''
        for steps in (32,64):
            path=base.BUDGET/f'epoch4252/{case}-{steps}{suffix}-terminal.npz'; base.require(base.digest(path)==consumed[str(path)],'terminal frozen')
            with np.load(path) as terminal:
                active=int(terminal['dimensions'][1]); size=len(terminal['normalized']); width=int(terminal['dimensions'][2]); photon=int(terminal['signature'][3]); ix=np.array([3,2,photon-1,photon+1]); units=terminal['state_units'][ix]; small_units=terminal['delta_units'][ix]; bgunit=terminal['background_units'][0]
                rawn=terminal['normalized_rhs']; vd=rawn[active+3]*terminal['delta_units'][3]; qd=rawn[active+photon]*terminal['delta_units'][photon]; native=vd-.75*qd
            records=[]; worst=0.; exposure=0.; count=0
            for directory in map(Path,dirs):
                base.guard(); path=directory/f'{case}-{steps}.npz';base.require(base.digest(path)==consumed[str(path)],'history frozen')
                with np.load(path) as f:
                    packet=f[('parent_' if mode=='parent' else '')+'metric']; state=f['extended']; clock=f['time']
                if count:
                    state=state[1:]; packet=packet[1:]; clock=clock[1:]
                count+=len(clock); begin=size+22 if mode=='parent' else 0
                old=(state[:,begin+ix]*units).T; change=(state[:,begin+active+ix]*small_units).T; alpha=state[:,2*active]*bgunit
                with np.load(base.source_path(label,steps)) as retained:
                    sl=slice(count-len(clock),count);s0=retained['slip'][sl];delta=retained['slip_change'][sl];base.require(np.array_equal(clock,retained['time'][sl]),'saved source clock')
                species=packet[...,:84].reshape(len(packet),2,7,12); cs2=packet[...,columns['sound_speed_squared']];hubble=packet[...,columns['hubble']];chi=packet[...,columns['opacity']];weight=(4./3)*species[:,:,2,0]/species[:,:,1,0]
                vel,density,photon_density,quad=old; dvel,ddensity,dphoton,dquad=change
                g=1/(1+alpha); gm=-alpha*g; hubble_delta=hubble[:,1]-hubble[:,0]
                force=-hubble[:,0]*vel+wave*cs2[:,0]*density-wave*photon_density/4+wave*quad/2
                lam=chi[:,0]*(1+weight[:,0]);lam1=chi[:,0]*g**2*(1+weight[:,0]*g)
                dlam=chi[:,0]*gm*((1+g)+weight[:,0]*(1+g+g**2))
                force_terms=np.array([-hubble[:,1]*dvel,-hubble_delta*vel,wave*cs2[:,0]*g*ddensity,wave*cs2[:,0]*gm*density,-wave*dphoton/4,wave*dquad/2])
                small=np.sum(force_terms,axis=0)-dlam*s0-lam1*delta
                old_rhs=force-lam*s0
                def primitive_rhs(index):
                    sp=species[:,:,index,:];return (sp[:,:,8]-(sp[:,:,4]/sp[:,:,0])*sp[:,:,2])/sp[:,:,0]
                independent=primitive_rhs(1)-.75*primitive_rhs(2)
                primitive=abs(hubble[:,0]*vel)+abs(wave*cs2[:,0]*density)+abs(wave*photon_density/4)+abs(wave*quad/2)+abs(lam*s0)
                check=np.maximum(abs(old_rhs-independent[:,0]),abs(old_rhs+small-independent[:,1]))/np.maximum(primitive,1e-300)
                worst=max(worst,float(np.max(check)));exposure=max(exposure,float(np.max(abs(independent[:,1]-independent[:,0]-small))))
                records.append(np.column_stack((clock,small,independent[:,1]-independent[:,0],np.sum(abs(force_terms),axis=0)+abs(dlam*s0)+abs(lam1*delta))))
            records=np.concatenate(records); own_scale=max(abs(vd)+.75*abs(qd),1e-300)
            with (base.ROOT/f'paired-euler-{label}-{steps}.npz').open('xb') as stream: np.savez_compressed(stream,time=records[:,0],rearranged=records[:,1],packet_difference=records[:,2],term_scale=records[:,3])
            reports[f'{label}_{steps}']=dict(count=count,primitive_max_relative=worst,primitive_pass=worst<=base.ALG,native_terminal_slope=native,paired_terminal_slope=records[-1,1],packet_terminal_slope=records[-1,2],
                paired_terminal_relative_to_native_components=abs(records[-1,1]-native)/own_scale,packet_terminal_relative_to_native_components=abs(records[-1,2]-native)/own_scale,
                max_packet_minus_paired_absolute=exposure,paired_own_precision_not_asserted=True)
    base.save(base.ROOT/'paired-euler.json',dict(branches=reports,source=str(base.POST/'mts-coupled-metric-consistency-20261117/native/fortran/equations.f90'),new_evolution=False))
    print({label:(item['primitive_max_relative'],item['paired_terminal_relative_to_native_components']) for label,item in reports.items()},flush=True)


if __name__=='__main__':
    worker=base.psutil.Process();worker.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS);worker.cpu_affinity([4]);base.save(base.ROOT/'euler-start.json',dict(pid=worker.pid,created=worker.create_time(),command=worker.cmdline(),affinity=worker.cpu_affinity()))
    try:main()
    finally:base.save(base.ROOT/'euler-end.json',dict(finished=base.datetime.now(base.timezone.utc).isoformat()))
