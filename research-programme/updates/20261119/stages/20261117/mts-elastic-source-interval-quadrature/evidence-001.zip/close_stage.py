import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import psutil


ROOT = Path(__file__).resolve().parent


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(name,value):
    with (ROOT/name).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,allow_nan=False,indent=2)
        stream.write('\n')


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def exited(record):
    try:
        candidate = psutil.Process(record['pid'])
        if abs(candidate.create_time()-record['created']) < .01:
            raise RuntimeError('Recorded worker still present: '+str((candidate.pid,candidate.cmdline())))
        return 'pid-reused; not touched'
    except psutil.NoSuchProcess:
        return 'exited'


def main():
    worker = psutil.Process()
    worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    worker.cpu_affinity([4])
    identities = []
    for path in sorted(ROOT.glob('*-start.json')):
        start = read(path)
        end = read(path.with_name(path.name.replace('-start.json','-end.json')))
        if end.get('failed',False):
            raise RuntimeError(f'Failed primary probe: {path}')
        identities.append(dict(receipt=path.name,pid=start['pid'],created=start['created'],status=exited(start)))
    for pid,birth in [(5396,1794940763.7611213),(11620,1794940788.2774367)]:
        record=dict(pid=pid,created=birth)
        identities.append(dict(receipt='foreground exploration',**record,status=exited(record)))
    releases = sorted(ROOT.glob('*-owner-release.json'))
    if len(releases)!=8 or any(not all(read(path).get(key) is True for key in ('cleared','native_reference_released')) for path in releases):
        raise ValueError('Incomplete release receipts')
    if list(ROOT.rglob('__pycache__')) or not (ROOT/'verification.json').is_file():
        raise ValueError('Unexpected stage state')
    for file in ('RESULTS.md','FRIEDMANN-SOURCE.md','SLIP-EQUATION.md'):
        if not (ROOT/file).is_file():
            raise ValueError('Missing closeout document: '+file)
    save('cleanup.json',dict(workers=identities,releases=[path.name for path in releases],
        closer=dict(pid=worker.pid,created=worker.create_time(),command=worker.cmdline()),
        note='Initial manufactured check stopped before physical tests; later refinement retained. No processes terminated or app services changed.'))
    inventory = {path.relative_to(ROOT).as_posix():dict(bytes=path.stat().st_size,sha256=digest(path))
                 for path in sorted(ROOT.rglob('*')) if path.is_file()}
    save('closeout.json',dict(finished=datetime.now(timezone.utc).isoformat(),files=inventory,physical_restart='epoch4252 unchanged'))
    print('Files sealed:',len(inventory),'Bytes:',sum(item['bytes'] for item in inventory.values()),'SHA256:',digest(ROOT/'closeout.json'))


if __name__=='__main__':
    main()
