import argparse
import math
from pathlib import Path

import interval_probe as base
import numpy as np
from scipy.integrate import solve_ivp


FIELDS = ('F0','expansion_times_dv','delta_expansion_times_v','pressure','photon_density','quadrupole','opacity','inertia','alpha')


def physical_sample(direct, system, time, state, mode, photon, wave, columns):
    if mode == 'baseline':
        native = state
    elif mode == 'parent':
        native = system.core.unpack(state[:system.core_size])[1]
    else:
        native = state[:system.core.native_size]
    old, change, physical, _, _ = direct.unpack(native)
    original = direct.model.represented(float(time))
    alpha, fields, velocities = direct.model.unpack(physical)
    background = np.zeros(5)
    background[:direct.width] = direct.model.pack(original['scale']*(1+alpha),original['field']+fields,original['velocity']+velocities)
    metric0 = direct.read_metric(float(time),old,background,False)
    metric1 = direct.read_metric(float(time),old+change,background,True)
    hubble, corrected = metric0[columns['hubble']], metric1[columns['hubble']]
    pressure = wave*metric0[columns['sound_speed_squared']]
    old_force = -hubble*old[3]+pressure*old[2]-wave*old[photon-1]/4+wave*old[photon+1]/2
    inertia = 4*metric0[24]/(3*metric0[12])
    return [old_force,-corrected*change[3],-(corrected-hubble)*old[3],pressure*(change[2]-alpha*old[2])/(1+alpha),
            -wave*change[photon-1]/4,wave*change[photon+1]/2,metric0[columns['opacity']],inertia,alpha,
            old[3]-.75*old[photon],change[3]-.75*change[photon]]


def propagate(table, old, delta, width, splits):
    cases, nodes, _ = table.shape
    substep = width/((nodes-1)*splits)
    state = np.broadcast_to([old, delta, 0.],(cases,3)).copy()
    def rate(values, current):
        old_slip, change = current[:,:2].T
        opacity, inertia, alpha = values[:,6:9].T
        inverse = 1/(1+alpha)
        gain = (4/3)*opacity*inverse**2*(change*(2*old_slip+change)-alpha*(2+alpha)*old_slip**2)
        change_drag = -opacity*alpha*inverse*(1+inverse+inertia*(1+inverse+inverse**2))
        return np.column_stack((values[:,0]-opacity*(1+inertia)*old_slip,
                np.sum(values[:,1:6],axis=1)-change_drag*old_slip-opacity*inverse**2*(1+inertia*inverse)*change,gain))
    base.require(np.all(np.isfinite(table)) and np.all(table[:,:,6:8]>0) and np.all(1+table[:,:,8]>0), 'physical forcing')
    for node in range(nodes-1):
        start = table[:,node,:]
        difference = table[:,node+1,:]-start
        for inner in range(splits):
            left = rate(start+difference*(inner/splits),state)
            middle = start+difference*((inner+.5)/splits)
            mid1 = rate(middle,state+.5*substep*left)
            mid2 = rate(middle,state+.5*substep*mid1)
            right = rate(start+difference*((inner+1)/splits),state+substep*mid2)
            state += (substep/6)*(left+2*mid1+2*mid2+right)
    return state


def score(samples, width, reference):
    old, delta = samples[0,-2:]
    target = np.r_[samples[-1,-2:], reference]
    scale = np.r_[np.maximum(abs(samples[0,-2:]),abs(samples[-1,-2:])),abs(reference)]
    base.require(np.all(scale>0), 'nonzero comparison')
    values = samples[:,:len(FIELDS)]
    chord = values[0]+np.arange(257)[:,None]*(values[-1]-values[0])/256
    curves = []
    for divisions in (1,4,16,64,128,256):
        result = propagate(values[None,::256//divisions,:],old,delta,width,max(1,32//divisions))[0]
        curves.append(dict(divisions=divisions,relative=((result-target)/scale).tolist()))
    variants = np.broadcast_to(values,(1+len(FIELDS),*values.shape)).copy()
    for column in range(len(FIELDS)):
        variants[1+column,:,column] = chord[:,column]
    refined = propagate(variants,old,delta,width,2)
    previous = propagate(variants[:1],old,delta,width,1)[0]
    return dict(order=['old_slip','changed_slip','source_integral'],scale=scale.tolist(),exact=target.tolist(),
        direct_gauss7=reference,refined=refined[0].tolist(),relative_refined=((refined[0]-target)/scale).tolist(),
        relative_scalar_step= (abs(refined[0]-previous)/scale).tolist(),curves=curves,
        one_input_chord_shift_relative={name:((vector-refined[0])/scale).tolist() for name,vector in zip(FIELDS,refined[1:])})


def main(case, steps):
    base.guard()
    base.check_seals()
    blocks = base.read(base.ROOT/'selection.json')['selected'][case][::2]
    indices = [left for left,_ in blocks]
    modes = ('parent','approximate') if case=='heavy' else ('baseline',)
    schema = base.read(base.POST/'mts-coupled-metric-consistency-20261117/packet-schema.json')
    columns = {name:84+index for index,name in enumerate(schema['global_columns'])}
    wave = base.read(base.BUDGET/'protocol.json')['retained_comoving_wave']
    with np.load(base.source_path(case+'_'+modes[0],steps)) as data:
        clock = data['time']
    pairs = base.selected_rows(case,steps,set(indices),clock)
    tag = f'interior-{case}-{steps}'
    live, context = base.native_setup(case,steps,tag)
    with context as (capture,metadata,sample):
        prepared,_,bg,_,_ = live.EX.problem(case)
        preflight = live.load(Path(live.CONFIG['capture_authority'])/(case+'-preflight-capture.npz'))
        base.require(all(np.array_equal(value,preflight[key]) for key,value in capture.items()),'same capture')
        direct = live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),metadata,sample)
        photon = int(capture['signature'][0,3])
        for index in indices:
            base.guard()
            states, path = pairs[index]
            system = None
            if case=='heavy':
                system = live.worklib.Carried(direct,live.worklib.LiveSecond(case,prepared,bg,live.prefix(capture,case),metadata,sample))
                if base.BUDGET in path.parents or 'photon-difference-replay-v2' in path.parts:
                    live.operator_repair.install(system)
            left,right = clock[index:index+2]
            solution = solve_ivp(system.rhs if system else direct.rhs,(left,right),states[0].copy(),method='DOP853',
              rtol=live.CONFIG['rtol'],atol=live.CONFIG['normalized_atol'],max_step=float(prepared['elapsed'][8])/steps,dense_output=True)
            base.require(solution.success and np.array_equal(solution.y[:,-1],states[1]), 'bitwise identical native endpoint')
            times = np.linspace(left,right,257)
            real_states = solution.sol(times).T
            earlier = base.read(base.ROOT/f'physical-{case}-{steps}-block{index}.json')[0]
            base.require(earlier['index']==index and earlier['accepted_steps']==len(solution.t)-1, 'direct reference')
            for mode in modes:
                readings = np.array([physical_sample(direct,system,time,state,mode,photon,wave,columns) for time,state in zip(times, real_states)])
                first,last = readings[[0,-1]]
                def gain(row):
                    *_,opacity,_,alpha,old,delta = row
                    return (4/3)*opacity/(1+alpha)**2*(delta*(2*old+delta)-alpha*(2+alpha)*old**2)
                with np.load(base.source_path(case+'_'+mode,steps)) as retained:
                    expected = retained['change'][index:index+2]
                    reference_end = np.column_stack((retained['slip'][index:index+2],retained['slip_change'][index:index+2]))
                base.require(np.max(abs(np.array([gain(first),gain(last)])/expected-1))<base.ALG,'same source at both endpoints')
                base.require(np.array_equal(readings[[0,-1],-2:],reference_end),'same physical slip endpoints')
                answer = score(readings,right-left,earlier['modes'][mode]['integrals']['7'])
                answer['native_steps'] = len(solution.t)-1
                answer['source_restart'] = str(path)
                answer['width_Mpc'] = right-left
                with (base.ROOT/f'{tag}-{mode}-{index}.npz').open('xb') as stream:
                    np.savez_compressed(stream,time=times,values=readings,columns=np.array([*FIELDS,'old_slip','changed_slip']))
                base.save(base.ROOT/f'{tag}-{mode}-{index}.json',answer)
                print(tag, mode, index, answer['relative_refined'],flush=True)


if __name__=='__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('case',choices=('heavy','cold'))
    parser.add_argument('steps',type=int,choices=(32,64))
    args = parser.parse_args()
    tag = f'interior-{args.case}-{args.steps}'
    worker = base.psutil.Process()
    worker.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    worker.cpu_affinity([4])
    base.save(base.ROOT/f'{tag}-start.json',dict(pid=worker.pid,created=worker.create_time(),command=worker.cmdline(),affinity=worker.cpu_affinity()))
    try:
        main(args.case,args.steps)
    finally:
        base.save(base.ROOT/f'{tag}-end.json',dict(finished=base.datetime.now(base.timezone.utc).isoformat()))
