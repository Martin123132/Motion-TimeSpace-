import csv
import math
from pathlib import Path

import interval_probe as base
import numpy as np
from scipy.integrate import simpson


def rows(name):
    with (base.ROOT/name).open(newline='') as stream:
        return list(csv.DictReader(stream))


def norm(values):
    return math.fsum(abs(value) for value in values)


def close(left,right):
    return math.isclose(left,right,rel_tol=5e-14,abs_tol=0.)


def verify():
    base.guard()
    base.check_seals()
    inputs = base.read(base.SOURCE/'inputs.json')
    for name, expected in inputs.items():
        base.require(base.digest(Path(name))==expected,'upstream hash: '+name)
    selection = base.read(base.ROOT/'selection.json')
    for key,file in [('algorithm_sha256','interval_probe.py'),('ledger_sha256','block-ledger.csv'),('method_sha256','METHOD.md')]:
        base.require(base.digest(base.ROOT/file)==selection[key],key)
    direct = rows('dense-vs-saved.csv')
    coverage = rows('coverage.csv')
    coverage_summary = base.read(base.ROOT/'coverage.json')['branches']
    slopes = base.read(base.ROOT/'paired-euler.json')['branches']
    forcing = rows('forcing-comparison.csv')
    forcing_report = base.read(base.ROOT/'forcing-result.json')
    base.require(len(direct)==24 and len(forcing)==48 and forcing_report['method_hash']==base.digest(base.ROOT/'FORCING-TEST.md'),'saved tables')
    branches = {}
    interiors = {}
    for label in base.LABELS:
        case,mode = label.split('_')
        chosen = selection['selected'][case]
        total = 3614 if case=='cold' else 7854
        entries = sorted((row for row in coverage if row['branch']==label),key=lambda row:int(row['left']))
        base.require(int(entries[0]['left'])==0 and int(entries[-1]['right'])==total and all(first['right']==second['left'] for first,second in zip(entries,entries[1:])), 'no gap or double counting')
        base.require(coverage_summary[label]['total_intervals']==total and not coverage_summary[label]['complete_dense'],'proper branch coverage')
        counted = 0
        for left,right in chosen:
            reference = {}
            uncertainty = {}
            for steps in (32,64):
                key = label+'_'+str(steps)
                with np.load(base.ROOT/f'paired-euler-{label}-{steps}.npz') as saved, np.load(base.source_path(label,steps)) as source:
                    base.require(np.array_equal(saved['time'],source['time']) and len(saved['time'])==total+1 and np.all(np.isfinite(saved['rearranged'])),'same full clock')
                    base.require(saved['rearranged'][-1]==slopes[key]['paired_terminal_slope'] and slopes[key]['primitive_max_relative']<=base.ALG,'Euler result')
                packet = base.read(base.ROOT/f'physical-{case}-{steps}-block{left}.json')
                base.require([item['index'] for item in packet]==list(range(left,right)) and all(item['endpoint_state_relative']==0 and item['modes'][mode]['endpoint_source_absolute']==0 and item['modes'][mode]['source_replay']==0 for item in packet),'full native endpoints')
                rates = [np.array([item['modes'][mode]['integrals'][str(order)] for item in packet]) for order in (3,5,7)]
                reference[steps] = rates[-1]
                uncertainty[steps] = norm(rates[2]-rates[1])+norm(rates[1]-rates[0])
                occurrence = [row for row in direct if row['branch']==label and int(row['steps'])==steps and int(row['left'])==left]
                base.require(len(occurrence)==1 and float(occurrence[0]['dense_order7'])==math.fsum(rates[-1]),'independent direct readback')
            error=(uncertainty[32]+uncertainty[64]+norm(reference[32]-reference[64]))/norm(reference[64])
            base.require(close(error,float(occurrence[0]['block_dense_working_relative'])),'direct uncertainty')
            actual = next(row for row in entries if int(row['left'])==left)
            base.require((actual['status']=='direct-qualified')==(error<=base.TOL),'no false promotion')
            counted += (right-left) if error<=base.TOL else 0
        base.require(counted==coverage_summary[label]['qualified_intervals'],'qualified count')
        base.require(not any(row['passed']=='True' for row in forcing if row['branch']==label),'endpoint-only forcing independently rejected')
        branches[label] = dict(total=total,qualified=counted,working_integral=math.fsum(float(row['working_integral']) for row in entries))
        base.require(branches[label]['working_integral']==coverage_summary[label]['mixed_diagnostic'],'mixed integral exactly reproduced')
        for left,_ in chosen[::2]:
            result = {}
            fine = {}
            for steps in (32,64):
                tag = f'interior-{case}-{steps}-{mode}-{left}'
                report = base.read(base.ROOT/(tag+'.json'))
                with np.load(base.ROOT/(tag+'.npz')) as packet:
                    times = packet['time']
                    fields = packet['values']
                    base.require(len(times)==257 and fields.shape==(257,11) and np.all(np.diff(times)>0),'physical sampling')
                    opacity,alpha,old,change = fields[:,6],fields[:,8],fields[:,9],fields[:,10]
                    gain = (4/3)*opacity/(1+alpha)**2*(change*(2*old+change)-alpha*(2+alpha)*old**2)
                    from_state = simpson(gain,x=times)
                truth = base.read(base.ROOT/f'physical-{case}-{steps}-block{left}.json')[0]['modes'][mode]['integrals']['7']
                base.require(truth==report['direct_gauss7'] and close(abs((report['refined'][2]-truth)/truth),abs(report['relative_refined'][2])),'independent reference')
                dominant = max(report['one_input_chord_shift_relative'],key=lambda name:abs(report['one_input_chord_shift_relative'][name][2]))
                result[str(steps)] = dict(relative_integral_from_physical_samples=(from_state-truth)/abs(truth),
                        scalar_versus_direct=report['relative_refined'][2],largest_single_input=dominant,
                        relative_integral_shift_on_chord=report['one_input_chord_shift_relative'][dominant][2])
                fine[steps] = report
            scales = np.array(fine[64]['scale'])
            physical_gap = abs(np.array(fine[32]['exact'])-fine[64]['exact'])/scales
            working = physical_gap.copy()
            for report in fine.values():
                limits = (abs(np.array(report['relative_refined']))+np.array(report['relative_scalar_step'])+
                          abs(np.array(report['curves'][-1]['relative'])-report['curves'][-2]['relative']))
                working += np.array(report['scale'])*limits/scales
            result['paired_working_fraction'] = working.tolist()
            result['within_working_tolerance'] = bool(np.all(working<=base.TOL))
            interiors[f'{label}:{left}'] = result
    base.save(base.ROOT/'verification.json',dict(upstream_files_rehashed=len(inputs),sealed_restart=base.BUDGET.name+'/epoch4252',
        branches=branches,interior=interiors,interpretation='Numerical working allowances, not rigorous error enclosures. Interior probes are subsets of existing coverage.'))
    print({key:(value['paired_working_fraction'],value['64']['largest_single_input']) for key,value in interiors.items()})


if __name__=='__main__':
    worker=base.psutil.Process()
    worker.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    worker.cpu_affinity([4])
    base.save(base.ROOT/'verify-start.json',dict(pid=worker.pid,created=worker.create_time(),command=worker.cmdline(),affinity=worker.cpu_affinity()))
    try:
        verify()
    finally:
        base.save(base.ROOT/'verify-end.json',dict(finished=base.datetime.now(base.timezone.utc).isoformat()))
