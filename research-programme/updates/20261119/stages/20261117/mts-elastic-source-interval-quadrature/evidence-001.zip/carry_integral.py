import interval_probe as base
import csv
import math
import numpy as np

ROOT=base.ROOT


def main():
    base.check_seals();base.guard()
    previous=base.read(base.SOURCE/'result-complete.json')['history']
    with (ROOT/'block-ledger.csv').open(encoding='utf-8') as stream:
        saved=list(csv.DictReader(stream))
    with (ROOT/'dense-vs-saved.csv').open(encoding='utf-8') as stream:
        direct={(entry['branch'],int(entry['steps']),int(entry['left'])):entry for entry in csv.DictReader(stream)}
    rows=[]; summaries={}
    for label in base.LABELS:
        coarse={int(entry['left_index']):entry for entry in saved if entry['branch']==label and entry['steps']=='32'}
        fine={int(entry['left_index']):entry for entry in saved if entry['branch']==label and entry['steps']=='64'}
        base.require(coarse.keys()==fine.keys(),'same blocks, both refinements')
        sample=base.read(ROOT/'selection.json')['selected'][label.split('_')[0]]
        pooled=[]
        for left,high in fine.items():
            low=coarse[left]; right=int(high['right_index']); original=float(high['integral_stride1']); other=float(low['integral_stride1'])
            truth=direct.get((label,64,left)); safe=truth is not None and truth['dense_local_resolved']=='True' and direct[label,32,left]['dense_local_resolved']=='True'
            if safe:
                receipt=base.read(ROOT/f'physical-{label.split("_")[0]}-64-block{left}.json'); mode=label.split('_')[1]
                scale=math.fsum(abs(entry['modes'][mode]['integrals']['7']) for entry in receipt)
                value=math.fsum(entry['modes'][mode]['integrals']['7'] for entry in receipt)
                base.require(value==float(truth['dense_order7']),'direct integral readback')
                allowance=scale*float(truth['block_dense_working_relative'])
                state='direct-qualified'
            else:
                value=original
                allowance=float(high['absolute_discrepancy'])+float(low['absolute_discrepancy'])+abs(original-other)
                state='prior-only' if truth is None else 'direct-probed-unresolved'
            pooled.append(dict(branch=label,left=left,right=right,start_Mpc=high['start_Mpc'],end_Mpc=high['end_Mpc'],status=state,original_64=original,working_integral=value,local_allowance=allowance))
        rows.extend(pooled); accepted=[item for item in pooled if item['status']=='direct-qualified']; untested=[item for item in pooled if item['status']=='prior-only']
        accumulated=math.fsum(item['working_integral'] for item in pooled); orig=math.fsum(item['original_64'] for item in pooled)
        physical=previous['summaries'][label+'_64']; base.require(abs(orig-physical['final_integrated_fractional_source'])<=1e-10*abs(orig),'old integral reproduced')
        with np.load(base.source_path(label,64)) as high, np.load(base.source_path(label,32)) as low:
            rounding=64*np.finfo(float).eps*np.max(np.abs(high['integrated_primitive']+low['integrated_primitive']))
        allowance=max(previous['own_precision'][label]['absolute_integral_allowance'],math.fsum(item['local_allowance'] for item in pooled)+rounding)
        summaries[label]=dict(total_blocks=len(pooled),qualified_blocks=len(accepted),total_intervals=sum(item['right']-item['left'] for item in pooled),qualified_intervals=sum(item['right']-item['left'] for item in accepted),
            signed_qualified_contribution=math.fsum(item['working_integral'] for item in accepted),direct_minus_old_on_qualified=math.fsum(item['working_integral']-item['original_64'] for item in accepted),
            mixed_diagnostic=accumulated,full_working_allowance=allowance,full_relative=allowance/abs(accumulated),first_untested=untested[0]['left'],
            complete_dense=False,prior_error_retained=True,original_cumulative_gate_unchanged=True)
    with (ROOT/'coverage.csv').open('x',encoding='utf-8',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    base.save(ROOT/'coverage.json',dict(branches=summaries,scope='Only locally qualified numerical integrals replace the corresponding saved blocks in this diagnostic. Use the CSV for resumable block coverage. Local unsigned refinement allowances are diagnostic, not certified continuum bounds. Prior defect and pressure-work budgets remain separate.'))
    print(summaries,flush=True)


if __name__=='__main__':
    proc=base.psutil.Process();proc.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([4])
    base.save(ROOT/'carry-start.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),affinity=proc.cpu_affinity()))
    try:main()
    finally:base.save(ROOT/'carry-end.json',dict(finished=base.datetime.now(base.timezone.utc).isoformat()))
