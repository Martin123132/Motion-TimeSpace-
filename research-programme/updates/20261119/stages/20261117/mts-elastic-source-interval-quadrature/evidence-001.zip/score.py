import interval_probe as base
import csv
import math
import numpy as np
from pathlib import Path

ROOT=base.ROOT


def norm(values):
    return math.fsum(abs(value) for value in values)


def main():
    base.guard();base.check_seals()
    selection=base.read(ROOT/'selection.json'); reconstruction=base.read(ROOT/'reconstruction.json')['results']; rows=[]; aggregates={}
    with (ROOT/'block-ledger.csv').open(encoding='utf-8') as stream:
        previous={(row['branch'],int(row['steps']),int(row['left_index'])):row for row in csv.DictReader(stream)}
    for label in base.LABELS:
        case,mode=label.split('_');sets=selection['selected'][case];summary=[]
        for steps in (32,64):
            tag=f'physical-{case}-{steps}'
            release=base.read(ROOT/(tag+'-owner-release.json'))
            base.require(release['cleared'] and release['native_reference_released'],'private native owner released')
        for left,right in sets:
            comparisons={}
            for steps in (32,64):
                receipts=base.read(ROOT/f'physical-{case}-{steps}-block{left}.json')
                base.require([entry['index'] for entry in receipts]==list(range(left,right)),'dense coverage')
                old=previous[label,steps,left]
                with np.load(ROOT/f'reconstruction-{label}-{steps}.npz') as data:
                    candidate=data['hermite'][left:right];linear=data['linear'][left:right];quad=data['quadratic_opacity'][left:right]
                values=np.array([[entry['modes'][mode]['integrals'][str(order)] for entry in receipts] for order in base.ORDERS]); exact=values[2];scale=max(norm(exact),1e-300)
                signedsum=math.fsum(exact); endpoint=max(item['endpoint_state_relative'] for item in receipts)
                local_source=max(item['modes'][mode]['endpoint_source_relative'] for item in receipts)
                allowance=norm(values[2]-values[1])+norm(values[1]-values[0]); endpoint_allowance=math.fsum((item['end']-item['begin'])*item['modes'][mode]['endpoint_source_absolute'] for item in receipts)
                comparisons[steps]=(exact,allowance+endpoint_allowance)
                summary.append(dict(left=left,steps=steps,scale=scale,accepted=sum(item['accepted_steps'] for item in receipts),relative_gauss=allowance/scale,relative_Hermite=norm(candidate-exact)/scale))
                rows.append(dict(branch=label,steps=steps,left=left,right=right,start_Mpc=old['start_Mpc'],end_Mpc=old['end_Mpc'],original_stride1=float(old['integral_stride1']),dense_order7=signedsum,
                    old_vs_dense_signed_relative=(float(old['integral_stride1'])-signedsum)/scale,hermite_vs_dense_abs_relative=norm(candidate-exact)/scale,linear_vs_dense_abs_relative=norm(linear-exact)/scale,
                    opacity_sensitivity_relative=norm(quad-candidate)/scale,gauss_357_abs_relative=allowance/scale,endpoint_allowance_relative=endpoint_allowance/scale,
                    full_state_endpoint_relative=endpoint,source_endpoint_relative=local_source,accepted_integrator_steps=sum(item['accepted_steps'] for item in receipts)))
            coarse,coarse_error=comparisons[32];fine,fine_error=comparisons[64]; denominator=max(norm(fine),1e-300)
            working=(norm(fine-coarse)+coarse_error+fine_error)/denominator
            for row in rows[-2:]:
                row['block_dense_working_relative']=working
                row['dense_local_resolved']=working<=base.TOL and row['full_state_endpoint_relative']<=base.ALG and row['source_endpoint_relative']<=base.TOL
                row['hermite_within_tolerance']=working+row['hermite_vs_dense_abs_relative']<=base.TOL and row['dense_local_resolved']
        own=[item for item in rows if item['branch']==label and item['steps']==64]
        old_report=base.read(base.SOURCE/'result-complete.json')['history']['own_precision'][label]
        high=reconstruction[label+'_64']; low=reconstruction[label+'_32']
        aggregates[label]=dict(dense_resolved_blocks=sum(item['dense_local_resolved'] for item in own),candidate_resolved_blocks=sum(item['hermite_within_tolerance'] for item in own),tested_blocks=len(sets),tested_original_intervals=sum(right-left for left,right in sets),
            endpoint_replay_max=max(item['full_state_endpoint_relative'] for item in rows if item['branch']==label),worst_own_source_endpoint=max(item['source_endpoint_relative'] for item in rows if item['branch']==label),
            worst_dense_working_relative=max(item['block_dense_working_relative'] for item in own),worst_hermite_relative=max(item['hermite_vs_dense_abs_relative'] for item in own),
            maximum_saved_stride1_block_discrepancy=max(abs(item['old_vs_dense_signed_relative']) for item in own),source_grid_Hermite_integrals_by_stride=high['strides'],
            probe_confirmed_global_integral=False,prior_integral_precision=old_report['integral_relative'],previous_acceptance_unchanged=True,
            terminal_equation_slope_check=high['terminal_equation_check'],candidate_whole_history_32_64_gap=abs(high['strides']['1']['hermite']-low['strides']['1']['hermite']))
    with (ROOT/'dense-vs-saved.csv').open('x',newline='',encoding='utf-8') as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0]);writer.writeheader();writer.writerows(rows)
    base.save(ROOT/'scores.json',dict(comparison=aggregates,algebra=base.ALG,numerical=base.TOL,new_fit=False,scope='Dense physics from original left states on frozen blocks; not a new complete trajectory. Neither a selected block nor a candidate reconstruction promotes the cumulative integral.'))
    for key,value in aggregates.items():
        print(key,{name:value[name] for name in ('dense_resolved_blocks','candidate_resolved_blocks','endpoint_replay_max','worst_dense_working_relative','worst_hermite_relative','maximum_saved_stride1_block_discrepancy')},flush=True)


if __name__=='__main__':
    proc=base.psutil.Process();proc.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([4])
    base.save(ROOT/'score-start.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),affinity=proc.cpu_affinity()))
    try:main()
    finally:base.save(ROOT/'score-end.json',dict(finished=base.datetime.now(base.timezone.utc).isoformat()))
