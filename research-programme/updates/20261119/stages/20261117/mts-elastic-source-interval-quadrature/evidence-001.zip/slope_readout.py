import interval_probe as base
import csv
import math
import sys
from pathlib import Path
import numpy as np

ROOT,SOURCE,BUDGET,POST=base.ROOT,base.SOURCE,base.BUDGET,base.POST
RULES={order:np.polynomial.legendre.leggauss(order) for order in (3,5,7)}


def hermite(left,right,first,last,width,at):
    return left+(right-left)*at**2*(3-2*at)+width*at*(1-at)*((1-at)*first-at*last)


def maximum(values):
    return float(np.max(np.abs(values)))


def manufacture():
    start,width=-.7,1.4
    target=lambda value: 1.+3.*value-2.*value**2+value**3
    slope=lambda value: 3.-4.*value+3.*value**2
    for degree,(nodes,weights) in RULES.items():
        points=(1+nodes)/2
        curve=hermite(target(start),target(start+width),slope(start),slope(start+width),width,points)
        base.require(maximum(curve-target(start+width*points))<=1e-13,'manufactured cubic source interpolation')
        primitive=lambda value:value+1.5*value**2-(2./3)*value**3+.25*value**4
        base.require(abs(.5*width*np.dot(weights,curve)-(primitive(start+width)-primitive(start)))<=1e-13,'manufactured integral')
        for point in (0.,1.):
            base.require(abs(hermite(1.,2.,-4.,3.,.7,point)-(1.+point))<1e-15,'endpoints')


def archived_slopes(label,steps,source):
    case,mode=label.split('_')
    inputs=base.read(SOURCE/'inputs.json')
    directories=base.read(SOURCE/'protocol.json')['directories']
    schema=base.read(POST/'mts-coupled-metric-consistency-20261117/packet-schema.json')
    columns={name:84+index for index,name in enumerate(schema['global_columns'])}
    offset=0; pieces=[]; raw_error=0.; relative_error=0.
    for directory in map(Path,directories):
        base.guard()
        path=directory/f'{case}-{steps}.npz'
        base.require(base.digest(path)==inputs[str(path)],'metric source hash')
        with np.load(path) as data:
            time=data['time']; packet=data[('parent_' if mode=='parent' else '')+'metric']
        base.require(np.array_equal(time,source['time'][offset:offset+len(time)]),'physical clock exact')
        material=packet[...,:84].reshape(len(time),2,7,12)
        def velocity_derivative(component):
            species=material[:,:,component,:]
            return (species[:,:,8]-(species[:,:,4]/species[:,:,0])*species[:,:,2])/species[:,:,0]
        derivatives=velocity_derivative(1)-.75*velocity_derivative(2)
        alpha=source['alpha'][offset:offset+len(time)]
        alphap=(1+alpha)*(packet[:,1,columns['hubble']]-packet[:,0,columns['rate']])
        piece=np.column_stack((derivatives[:,0],derivatives[:,1]-derivatives[:,0],alphap,packet[:,0,columns['opacity']]))
        if pieces:
            base.require(np.array_equal(pieces[-1][-1],piece[0]),'same equation derivatives at saved joins')
            piece=piece[1:]
        pieces.append(piece)
        offset+=len(time)-1
    data=np.concatenate(pieces)
    suffix='-'+mode if case=='heavy' else ''
    path=BUDGET/f'epoch4252/{case}-{steps}{suffix}-terminal.npz'
    base.require(base.digest(path)==inputs[str(path)],'terminal hash')
    with np.load(path) as terminal:
        derivative=terminal['normalized_rhs']; active=int(terminal['dimensions'][1]); photon=int(terminal['signature'][3]); pick=[3,photon]
        selected=derivative[pick]*terminal['state_units'][pick]
        delta=derivative[active+np.array(pick)]*terminal['delta_units'][pick]
        direct=np.array([selected[0]-.75*selected[1],delta[0]-.75*delta[1],derivative[2*active]*terminal['background_units'][0]])
        scales=np.array([abs(selected[0])+.75*abs(selected[1]),abs(delta[0])+.75*abs(delta[1]),abs(direct[2])])
    difference=np.abs(data[-1,:3]-direct)
    return data,dict(primitive_labels=['old_slip_slope','delta_slip_slope','relative_scale_slope'],packet=data[-1,:3].tolist(),direct=direct.tolist(),absolute=difference.tolist(),relative_to_own_inputs=(difference/np.maximum(scales,1e-300)).tolist())


def reconstruct(source,data,stride,order):
    count=len(data); edges=np.unique(np.r_[np.arange(0,count,stride),count-1]); left,right=edges[:-1],edges[1:]
    clock=source['time']; width=(clock[right]-clock[left])[:,None]; nodes,weights=RULES[order]; at=.5*(1+nodes)[None,:]
    curves={}
    for choice in ('hermite','linear'):
        fields=[]
        for index,key in enumerate(('slip','slip_change','alpha')):
            values=source[key][:,None]
            if choice=='hermite':
                fields.append(hermite(values[left],values[right],data[left,index,None],data[right,index,None],width,at))
            else:
                fields.append(values[left]+(values[right]-values[left])*at)
        slip,change,alpha=fields
        factor=(1+alpha)**-2
        raw=(4./3)*factor*(-alpha*(2+alpha)*slip**2+change*(2*slip+change))
        opacity=data[:,3]; linear=opacity[left,None]+(opacity[right,None]-opacity[left,None])*at
        curves[choice]=.5*width[:,0]*np.sum(weights[None,:]*linear*raw,axis=1)
        if choice=='hermite':
            neighbour=np.where(left>0,left-1,np.minimum(right+1,count-1)); base.require(np.all(neighbour!=right),'distinct opacity control')
            offset=(clock[neighbour]-clock[left])/(clock[right]-clock[left]); bend=((opacity[neighbour]-opacity[left])-offset*(opacity[right]-opacity[left]))/(offset*(offset-1))
            quadratic=linear+bend[:,None]*at*(at-1)
            curves['quadratic_opacity']=.5*width[:,0]*np.sum(weights[None,:]*quadratic*raw,axis=1)
    return edges,curves


def main():
    base.guard(); base.check_seals(); manufacture()
    chosen=base.read(ROOT/'selection.json')['selected']; result={}
    for label in base.LABELS:
        for steps in (32,64):
            with np.load(base.source_path(label,steps)) as saved:
                source={name:saved[name] for name in ('time','change','primitive','slip','slip_change','alpha')}
            data,terminal=archived_slopes(label,steps,source)
            summations={}; probes={}; full={}
            for stride in (1,2,4):
                edges,diagnostic=reconstruct(source,data,stride,7)
                summations[str(stride)]={name:math.fsum(value) for name,value in diagnostic.items()}
                if stride==1:
                    full=diagnostic
            for order in (3,5):
                _,sample=reconstruct(source,data,1,order)
                full['hermite'+str(order)]=sample['hermite']
            for left,right in chosen[label.split('_')[0]]:
                probes[str(left)]={name:math.fsum(value[left:right]) for name,value in full.items()}
            with (ROOT/f'reconstruction-{label}-{steps}.npz').open('xb') as stream:
                np.savez_compressed(stream,**full)
            result[f'{label}_{steps}']=dict(strides=summations,terminal_equation_check=terminal,probes=probes,
                full_abs_75=math.fsum(abs(full['hermite']-full['hermite5'])),full_abs_53=math.fsum(abs(full['hermite5']-full['hermite3'])),
                full_abs_opacity=math.fsum(abs(full['hermite']-full['quadratic_opacity'])),full_abs_linear_difference=math.fsum(abs(full['hermite']-full['linear'])))
    base.save(ROOT/'reconstruction.json',dict(results=result,algorithm_sha256=base.digest(Path(__file__)),method_sha256=base.digest(ROOT/'RECONSTRUCTION.md')))
    print('Six reconstructed histories saved',flush=True)


if __name__=='__main__':
    proc=base.psutil.Process();proc.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS);proc.cpu_affinity([4])
    base.save(ROOT/'slope-start.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),affinity=proc.cpu_affinity()))
    try:main()
    finally:base.save(ROOT/'slope-end.json',dict(finished=base.datetime.now(base.timezone.utc).isoformat()))
