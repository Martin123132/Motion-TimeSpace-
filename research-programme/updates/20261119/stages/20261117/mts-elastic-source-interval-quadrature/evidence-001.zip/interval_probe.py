import os
for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[name]='1'

import argparse
import csv
import hashlib
import json
import math
import sys
import time
import traceback
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from types import FunctionType
import psutil
import numpy as np
from scipy.integrate import cumulative_simpson, solve_ivp

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
SOURCE=POST/'mts-collision-rest-frame-energy-20261117'
BUDGET=POST/'mts-carried-defect-budget-20261117'
SEAL='44cf9d3ccb820c76d62466c5ffe397a5d3527ed4d26718cd4ac2b62d6b587406'
ALG=1e-10
TOL=2e-5
STOP=datetime(2026,11,17,22,25,tzinfo=timezone.utc)
LABELS=('cold_baseline','heavy_parent','heavy_approximate')
ORDERS=(3,5,7)
START=time.monotonic()


def require(condition,message):
    if not condition:
        raise ValueError(message)


def guard():
    require(datetime.now(timezone.utc)<STOP and time.monotonic()-START<3600,'bounded safe checkpoint')
    for directory in (POST,POST/'condensate-origin-20261003',ROOT,BUDGET,SOURCE):
        require(not (directory/'STOP-REQUESTED').exists(),'owner stop: '+str(directory))


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path,value):
    encoded=json.dumps(value,indent=2,allow_nan=False,default=lambda item:item.item())+'\n'
    with path.open('x',encoding='utf-8') as stream:
        stream.write(encoded)


def source_path(label,steps):
    return SOURCE/f'source-{label}-{steps}.npz'


def check_seals():
    require(digest(SOURCE/'closeout.json')==SEAL,'retained source seal')
    seal=read(SOURCE/'closeout.json')['files']
    for path in [SOURCE/'result-complete.json',SOURCE/'verification-v2.json',SOURCE/'protocol.json',SOURCE/'inputs.json',*(source_path(label,steps) for label in LABELS for steps in (32,64))]:
        require(digest(path)==seal[path.name]['sha256'],'consumed source changed: '+str(path))
    require(digest(BUDGET/'closeout.json')=='ffc0253ae94bb6e873f0a25b0d0bcebd75fb4dfbb57baa68eac13f0199390f9e','physical seal')


def totals(clock,source):
    indices=np.arange(len(clock))
    boundaries=np.unique(np.r_[indices[::4],indices[-1]])
    cumulative=[]
    for stride in (1,2,4):
        selected=np.unique(np.r_[indices[::stride],indices[-1]])
        curve=cumulative_simpson(source[selected],x=clock[selected],initial=0.)
        cumulative.append(curve[np.searchsorted(selected,boundaries)])
    return boundaries,np.asarray(cumulative)


def localize():
    check_seals()
    result=read(SOURCE/'result-complete.json')['history']['summaries']
    reports,chosen={},{}
    with (ROOT/'block-ledger.csv').open('x',newline='',encoding='utf-8') as stream:
        output=csv.writer(stream)
        output.writerow(['branch','steps','left_index','right_index','start_Mpc','end_Mpc','integral_stride1','integral_stride2','integral_stride4','signed_1_minus_2','signed_2_minus_4','absolute_discrepancy'])
        for label in LABELS:
            for steps in (32,64):
                guard()
                with np.load(source_path(label,steps)) as data:
                    clock,source=data['time'],data['change']
                edges,cum=totals(clock,source)
                integrals=np.diff(cum,axis=1)
                signed=integrals[:-1]-integrals[1:]
                discrepancy=np.abs(signed).sum(axis=0)
                ranked=np.argsort(-discrepancy,kind='stable')
                n_top=math.ceil(.1*len(ranked))
                for row,(left,right) in enumerate(zip(edges[:-1],edges[1:])):
                    output.writerow([label,steps,left,right,clock[left],clock[right],*integrals[:,row],*signed[:,row],discrepancy[row]])
                old=result[f'{label}_{steps}']['quadrature_strides']
                require(all(cum[index,-1]==old[str(stride)] for index,stride in enumerate((1,2,4))),'all old stride totals exact')
                time_fraction=np.sum(np.diff(clock[edges])[ranked[:n_top]])/(clock[-1]-clock[0])
                reports[f'{label}_{steps}']=dict(samples=len(clock),blocks=len(ranked),top_decile_abs_fraction=sum(discrepancy[ranked[:n_top]])/sum(discrepancy),top_decile_time_fraction=time_fraction,
                    sum_absolute_discrepancy=math.fsum(discrepancy),absolute_of_signed_totals=sum(abs(np.diff(cum[:,-1]))),worst_block_left=int(edges[ranked[0]]),worst_block_time=float(clock[edges[ranked[0]]]),worst_block_absolute=float(discrepancy[ranked[0]]))
                if steps==64 and label!='heavy_approximate':
                    selection=[]
                    for half in np.array_split(np.arange(len(ranked)),2):
                        ranked_half=half[np.argsort(-discrepancy[half],kind='stable')]
                        for item in ranked_half[[0,len(half)//2]]:
                            selection.append([int(edges[item]),int(edges[item+1])])
                    chosen[label.split('_')[0]]=selection
    save(ROOT/'localization.json',reports)
    save(ROOT/'selection.json',dict(selected=chosen,previous_seal=SEAL,algorithm_sha256=digest(Path(__file__)),method_sha256=digest(ROOT/'METHOD.md'),ledger_sha256=digest(ROOT/'block-ledger.csv')))
    print(json.dumps(dict(chosen=chosen,baseline=reports['cold_baseline_64'],parent=reports['heavy_parent_64'])),flush=True)


def selected_rows(case,steps,indices,clock):
    frozen=read(SOURCE/'inputs.json')
    directories=read(SOURCE/'protocol.json')['directories']
    rows={}
    offset=0
    for directory in directories:
        path=Path(directory)/f'{case}-{steps}.npz'
        with np.load(path,allow_pickle=False) as data:
            times=data['time']
            stop=offset+len(times)-1
            require(np.array_equal(times,clock[offset:stop+1]),'all native clocks align')
            needed=[index for index in indices if offset<=index<stop]
            if needed:
                require(digest(path)==frozen[str(path)],'saved complete states hash')
                states=data['extended']
                for index in needed:
                    rows[index]=(states[index-offset:index-offset+2].copy(),path)
            offset=stop
    require(offset==len(clock)-1 and set(rows)==indices,'all selected restart intervals obtained')
    return rows


def native_setup(case,steps,tag):
    sys.path.insert(0,str(BUDGET))
    import live_work as live
    require(Path(live.__file__).resolve().parent==BUDGET and live.ROOT==BUDGET,'retained native authority')
    oldguard=live.guard
    for module in list(sys.modules.values()):
        mapping=getattr(module,'__dict__',{})
        if mapping.get('guard') is oldguard:
            mapping['guard']=guard
    original=live.native_context.__wrapped__
    local_globals=dict(original.__globals__,ROOT=ROOT,guard=guard)
    scoped=contextmanager(FunctionType(original.__code__,local_globals,original.__name__,original.__defaults__,original.__closure__))
    return live,scoped(case,tag)


def probe(case,steps):
    check_seals()
    selection=read(ROOT/'selection.json')
    require(selection['algorithm_sha256']==digest(Path(__file__)) and selection['method_sha256']==digest(ROOT/'METHOD.md'),'unchanged frozen probe')
    blocks=selection['selected'][case]
    modes=('parent','approximate') if case=='heavy' else ('baseline',)
    sources={}
    for mode in modes:
        with np.load(source_path(case+'_'+mode,steps)) as data:
            sources[mode]={name:data[name] for name in ('time','change','original','primitive')}
    clock=sources[modes[0]]['time']
    rows=selected_rows(case,steps,{index for left,right in blocks for index in range(left,right)},clock)
    tag=f'physical-{case}-{steps}'
    live,context=native_setup(case,steps,tag)
    nodes={order:np.polynomial.legendre.leggauss(order) for order in ORDERS}
    with context as (captured,metadata,sample):
        prepared,_,background,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,background,live.prefix(captured,case),metadata,sample)
        if case=='heavy':
            def system_for(repaired):
                system=live.worklib.Carried(direct,live.worklib.LiveSecond(case,prepared,background,live.prefix(captured,case),metadata,sample))
                if repaired:
                    live.operator_repair.install(system)
                return system
            legacy,improved=system_for(False),system_for(True)
        fullcapture=live.load(Path(live.CONFIG['capture_authority'])/(case+'-preflight-capture.npz'))
        require(all(np.array_equal(captured[name],fullcapture[name]) for name in captured),'full native capture parity')
        def rate(tau,state,mode,system):
            if mode=='baseline':
                native=state
            elif mode=='parent':
                native=system.core.unpack(state[:system.core_size])[1]
            else:
                native=state[:system.core.native_size]
            old,delta,physical,_,_=direct.unpack(native)
            base=direct.model.represented(float(tau))
            alpha,fields,velocities=direct.model.unpack(physical)
            packet=np.zeros(5)
            packet[:direct.width]=direct.model.pack(base['scale']*(1+alpha),base['field']+fields,base['velocity']+velocities)
            extra=sample(float(tau),old,packet,False)[2]
            photon=int(captured['signature'][0,3]); slip=old[3]-.75*old[photon]; change=delta[3]-.75*delta[photon]
            factor=(1+alpha)**-2
            return 4./3*extra[2]*(-alpha*(2+alpha)*factor*slip**2+factor*change*(2*slip+change))
        for left,right in blocks:
            cell_rows=[]
            for index in range(left,right):
                guard()
                pair,path=rows[index]
                repaired=BUDGET in path.parents or 'photon-difference-replay-v2' in path.parts
                system=(improved if repaired else legacy) if case=='heavy' else None
                rhs=system.rhs if system else direct.rhs
                begin,end=map(float,clock[index:index+2])
                sol=solve_ivp(rhs,(begin,end),pair[0].copy(),method='DOP853',rtol=live.CONFIG['rtol'],atol=live.CONFIG['normalized_atol'],max_step=float(prepared['elapsed'][8])/steps,dense_output=True)
                require(sol.success,'bounded independent physical integration')
                state_error=np.max(abs(sol.y[:,-1]-pair[1])/np.maximum(1.,abs(pair[1])))
                diagnostics={}
                for mode in modes:
                    source=sources[mode]['change']; amplitude=float(np.max(abs(source)))
                    first=rate(begin,pair[0],mode,system); last=rate(end,pair[1],mode,system)
                    replay=rate(end,sol.y[:,-1],mode,system)
                    scaled_readout=max(abs(first-source[index]),abs(last-source[index+1]))/amplitude
                    require(scaled_readout<=ALG,'same nodal source formula')
                    amounts={}
                    for order,(points,weights) in nodes.items():
                        pieces=[]
                        for low,high in zip(sol.t[:-1],sol.t[1:]):
                            half=(high-low)/2
                            at=low+(1+points)*half
                            interior=sol.sol(at).T
                            pieces.append(half*math.fsum(weight*rate(tau,vector,mode,system) for weight,tau,vector in zip(weights,at,interior)))
                        amounts[str(order)]=math.fsum(pieces)
                    diagnostics[mode]=dict(source_replay=scaled_readout,endpoint_source_absolute=abs(replay-last),endpoint_source_relative=abs(replay-last)/amplitude,integrals=amounts)
                cell_rows.append(dict(index=index,begin=begin,end=end,source_restart=str(path),accepted_steps=len(sol.t)-1,endpoint_state_relative=float(state_error),modes=diagnostics))
            save(ROOT/f'{tag}-block{left}.json',cell_rows)
            print(json.dumps(dict(case=case,steps=steps,block=[left,right],accepted=sum(item['accepted_steps'] for item in cell_rows),max_endpoint=max(item['endpoint_state_relative'] for item in cell_rows))),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('mode',choices=('localize','probe'))
    parser.add_argument('--case',choices=('cold','heavy'))
    parser.add_argument('--steps',type=int,choices=(32,64))
    args=parser.parse_args()
    tag=args.mode if args.mode=='localize' else f'{args.mode}-{args.case}-{args.steps}'
    worker=psutil.Process(); worker.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS); worker.cpu_affinity([4])
    save(ROOT/f'{tag}-start.json',dict(pid=worker.pid,created=worker.create_time(),command=worker.cmdline(),priority=worker.nice(),affinity=worker.cpu_affinity()))
    try:
        guard()
        if args.mode=='localize':localize()
        else:probe(args.case,args.steps)
    except BaseException:
        save(ROOT/f'{tag}-failure.json',dict(traceback=traceback.format_exc()))
        raise
    finally:
        save(ROOT/f'{tag}-end.json',dict(seconds=time.monotonic()-START,finished=datetime.now(timezone.utc).isoformat(),failed=(ROOT/f'{tag}-failure.json').exists()))
