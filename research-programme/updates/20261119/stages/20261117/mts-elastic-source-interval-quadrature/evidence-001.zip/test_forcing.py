import csv
import math
from pathlib import Path

import interval_probe as base
import numpy as np


def inputs(label, steps):
    case, mode = label.split('_')
    sources = base.read(base.SOURCE / 'inputs.json')
    schemas = base.read(base.POST / 'mts-coupled-metric-consistency-20261117/packet-schema.json')
    columns = {name: 84 + index for index, name in enumerate(schemas['global_columns'])}
    suffix = '-' + mode if case == 'heavy' else ''
    terminal_path = base.BUDGET / f'epoch4252/{case}-{steps}{suffix}-terminal.npz'
    base.require(base.digest(terminal_path) == sources[str(terminal_path)], 'terminal changed')
    with np.load(terminal_path) as terminal:
        active = int(terminal['dimensions'][1])
        photon = int(terminal['signature'][3])
        indices = np.array([3, 2, photon-1, photon+1])
        begin = len(terminal['normalized']) + 22 if mode == 'parent' else 0
        units = terminal['state_units'][indices]
        small_units = terminal['delta_units'][indices]
        bg_unit = terminal['background_units'][0]
    wave = base.read(base.BUDGET / 'protocol.json')['retained_comoving_wave']
    with np.load(base.source_path(label, steps)) as retained:
        clock, old_slip, change = (retained[key] for key in ('time', 'slip', 'slip_change'))
    pieces = []
    offset = 0
    for directory in base.read(base.SOURCE / 'protocol.json')['directories']:
        base.guard()
        path = Path(directory) / f'{case}-{steps}.npz'
        base.require(base.digest(path) == sources[str(path)], 'source hash')
        with np.load(path) as packet:
            state = packet['extended']
            metric = packet[('parent_' if mode == 'parent' else '')+'metric']
            time = packet['time']
        base.require(np.array_equal(time, clock[offset:offset+len(time)]), 'same clock')
        velocity, baryon, photons, shear = (state[:,begin+indices]*units).T
        dv, db, dp, dshear = (state[:,begin+active+indices]*small_units).T
        alpha = state[:,2*active]*bg_unit
        inverse = 1/(1+alpha)
        cs2 = metric[:,0,columns['sound_speed_squared']]
        hubble = metric[:,:,columns['hubble']]
        force = -hubble[:,0]*velocity + wave*(cs2*baryon-photons/4+shear/2)
        delta_force = (-hubble[:,1]*dv - (hubble[:,1]-hubble[:,0])*velocity +
                       wave*(cs2*inverse*(db-alpha*baryon)-dp/4+dshear/2))
        species = metric[:,0,:84].reshape(-1,7,12)
        sample = np.column_stack((force, delta_force, metric[:,0,columns['opacity']],
                                  4*species[:,2,0]/(3*species[:,1,0]), alpha))
        if pieces:
            base.require(np.array_equal(sample[0], pieces[-1][-1]), 'same join forcing')
            sample = sample[1:]
        pieces.append(sample)
        offset += len(time)-1
    base.require(offset+1 == len(clock), 'all times')
    return clock, old_slip, change, np.concatenate(pieces)


def solve_nodes(nodes, table, old, delta, widths, subdivisions):
    coefficients = []
    for index in range(nodes.shape[1]):
        others = np.delete(nodes, index, axis=1)
        coefficients.append((others, np.prod(nodes[:,index,None]-others, axis=1)))
    def values(at):
        weights = np.column_stack([np.prod(at-others, axis=1)/den for others,den in coefficients])
        return np.einsum('ij,ijk->ki', weights, table)
    def rhs(source, state):
        force, change_force, opacity, inertia, alpha = source
        base.require(np.all((opacity>0) & (inertia>0) & (1+alpha>0)), 'physical interpolated fields')
        inverse = 1/(1+alpha)
        inverse_change = -alpha*inverse
        old_slip, change, _ = state
        drag = opacity*(1+inertia)
        drag1 = opacity*inverse**2*(1+inertia*inverse)
        drag_change = opacity*inverse_change*(1+inverse+inertia*(1+inverse+inverse**2))
        gain = (4/3)*opacity*inverse**2*(change*(2*old_slip+change)-alpha*(2+alpha)*old_slip**2)
        return widths*np.array([force-drag*old_slip, change_force-drag_change*old_slip-drag1*change, gain])
    state = np.array([old, delta, np.zeros_like(old)])
    step = 1/subdivisions
    for sample in range(subdivisions):
        first, middle, last = (values(at*step) for at in (sample,sample+.5,sample+1))
        first_rate = rhs(first, state)
        next_rate = rhs(middle, state+first_rate*(step/2))
        midpoint_rate = rhs(middle, state+next_rate*(step/2))
        last_rate = rhs(last, state+midpoint_rate*step)
        state += (step/6)*(first_rate+2*next_rate+2*midpoint_rate+last_rate)
    return state


def control():
    width, opacity, inertia = .3, .4, 1.5
    drag = opacity*(1+inertia)
    old, delta = .1, -.023
    expected = [old*math.exp(-width*drag), delta*math.exp(-width*drag),
                (4/3)*opacity*delta*(2*old+delta)*(-math.expm1(-2*width*drag))/(2*drag)]
    errors = []
    for nodes in ([0.,1.],[-3.,0.,1.,2.5]):
        table = np.tile([0.,0.,opacity,inertia,0.],(1,len(nodes),1))
        sweep = {}
        for divisions in (8,16,32,64,128):
            result = solve_nodes(np.array([nodes]), table, np.array([old]), np.array([delta]), np.array([width]), divisions)
            sweep[divisions] = float(np.max(abs(result[:,0]/expected-1)))
        errors.append(sweep)
        base.require(sweep[128]<base.ALG and sweep[8]>10*sweep[16] and sweep[16]>10*sweep[32], 'analytic limit and RK4 refinement')
    return errors


def main():
    base.guard()
    base.check_seals()
    controls = control()
    selection = base.read(base.ROOT/'selection.json')['selected']
    with (base.ROOT/'dense-vs-saved.csv').open() as stream:
        prior = {(row['branch'],int(row['steps']),int(row['left'])):float(row['block_dense_working_relative']) for row in csv.DictReader(stream)}
    records = []
    for label in base.LABELS:
        case, mode = label.split('_')
        for steps in (32,64):
            clock, old, delta, fields = inputs(label, steps)
            blocks = selection[case]
            indices = np.concatenate([np.arange(left,right) for left,right in blocks])
            widths = clock[indices+1]-clock[indices]
            for name, offsets in [('linear',[0,1]),('cubic',[-1,0,1,2])]:
                stencil = indices[:,None]+offsets
                base.require(stencil.min()>=0 and stencil.max()<len(clock), 'physical bracketing clocks')
                nodes = (clock[stencil]-clock[indices,None])/widths[:,None]
                solves = np.array([solve_nodes(nodes,fields[stencil],old[indices],delta[indices],widths,divisions) for divisions in (8,16,32)])
                refinement = np.sum(abs(np.diff(solves, axis=0)),axis=0)
                for left,right in blocks:
                    mask = (indices>=left)&(indices<right)
                    rows = base.read(base.ROOT/f'physical-{case}-{steps}-block{left}.json')
                    truth = np.array([row['modes'][mode]['integrals']['7'] for row in rows])
                    integrals = solves[-1,2,mask]
                    denom = math.fsum(abs(truth))
                    accuracy = math.fsum(abs(integrals-truth))/denom
                    numerical = prior[label,steps,left]+math.fsum(refinement[2,mask])/denom
                    ends = []
                    for index, history in enumerate((old,delta)):
                        scale = np.maximum(abs(history[left:right]),abs(history[left+1:right+1]))
                        base.require(np.all(scale>0), 'resolved normalization')
                        ends.append(float(np.max((abs(solves[-1,index,mask]-history[left+1:right+1])+refinement[index,mask])/scale)))
                    records.append(dict(branch=label,steps=steps,left=left,right=right,forcing=name,
                                        abs_integral_error_relative=accuracy,refinement_plus_reference=numerical,
                                        old_slip_endpoint=ends[0],changed_slip_endpoint=ends[1],
                                        passed=bool(max(accuracy+numerical,*ends)<=base.TOL)))
    with (base.ROOT/'forcing-comparison.csv').open('x',newline='') as stream:
        writer = csv.DictWriter(stream,fieldnames=records[0].keys())
        writer.writeheader()
        writer.writerows(records)
    summary = {}
    for label in base.LABELS:
        summary[label] = {}
        for name in ('linear','cubic'):
            same = [row for row in records if row['branch']==label and row['forcing']==name]
            summary[label][name] = dict(both_pass=sum(all(row['passed'] for row in same if row['left']==left) for left,_ in selection[label.split('_')[0]]),
              largest_integral_error=max(row['abs_integral_error_relative'] for row in same),largest_changed_slip_endpoint=max(row['changed_slip_endpoint'] for row in same))
    base.save(base.ROOT/'forcing-result.json',dict(reference='original dense probes',method_hash=base.digest(base.ROOT/'FORCING-TEST.md'),analytic_control=controls,summary=summary))
    print(summary)


if __name__ == '__main__':
    worker = base.psutil.Process()
    worker.nice(base.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    worker.cpu_affinity([4])
    base.save(base.ROOT/'forcing-v2-start.json',dict(pid=worker.pid,created=worker.create_time(),command=worker.cmdline(),affinity=worker.cpu_affinity()))
    try:
        main()
    finally:
        base.save(base.ROOT/'forcing-v2-end.json',dict(finished=base.datetime.now(base.timezone.utc).isoformat()))
