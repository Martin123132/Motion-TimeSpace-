from run_two import *
import score_carry as retained_score
from score_phase import conservative
NAMES = ('native_velocity','native_weyl','photon_density','relative_density','velocity_slip')


def concatenate(parts):
    result = {name:value.copy() for name,value in parts[0].items()}
    for following in parts[1:]:
        require(set(result) == set(following),'same history fields')
        require(result['time'][-1] == following['time'][0],'same boundary clock')
        count = len(result['time'])
        require(np.array_equal(result['native_control'][-1],following['native_control'][0]),'same independent boundary control')
        for name in result:
            if name in ('native_indices','native_control'):
                continue
            require(len(result[name]) == count and len(following[name]) == len(following['time']),'time-indexed complete field: '+name)
            require(np.array_equal(result[name][-1],following[name][0]),'bitwise history join: '+name)
            result[name] = np.concatenate((result[name],following[name][1:]),axis=0)
        result['native_indices'] = np.r_[result['native_indices'],following['native_indices'][1:]+count-1]
        result['native_control'] = np.concatenate((result['native_control'],following['native_control'][1:]),axis=0)
    return result


def datasets(epoch,cumulative=False):
    sources = [CARRY,*[folder(value) for value in CONFIG['checkpoint_epochs'] if value<=epoch]] if cumulative else [folder(epoch)]
    data,mapping = {},{}
    for case in CONFIG['cases']:
        for steps in CONFIG['steps']:
            name = case+'-'+str(steps)+'.npz'
            paths = [directory/name for directory in sources]
            data[name] = concatenate([load(path) for path in paths])
            mapping.update({str(path):digest(path) for path in paths})
    return data,mapping


def identical_score(data,epoch,cumulative):
    original_root,original_load,original_terminal = retained_score.ROOT,retained_score.load,retained_score.input_terminal
    initial = Path(CONFIG['transport_directory']) if cumulative else inherited(epoch)
    def supplied(path):
        path = Path(path)
        return data[path.name] if path.name in data else original_load(path)
    def initial_core(case,steps):
        if cumulative:
            return initial/('heavy-replay-'+str(steps)+'-transport-terminal.npz')
        return initial/('heavy-'+str(steps)+'-transport-terminal.npz')
    try:
        retained_score.ROOT = ROOT
        retained_score.load = supplied
        retained_score.input_terminal = initial_core
        result = retained_score.score()
    finally:
        retained_score.ROOT,retained_score.load,retained_score.input_terminal = original_root,original_load,original_terminal
    result['last_epoch'] = epoch
    result['history_start'] = 3041 if cumulative else epoch-1
    result['same_sealed_score_formulas'] = True
    result['cumulative_history'] = cumulative
    return result


def projection(data):
    result = {'scope':'retained linear-model history consequences, not observational gains; coherent-minus-original is not an MTS-minus-baseline fit','cases':{}}
    for case in CONFIG['cases']:
        fine,coarse = data[case+'-64.npz'],data[case+'-32.npz']
        norms = read(ROOT/'frozen-norms.json')[case]
        result['cases'][case] = {}
        for mode,prefix_name in ((('parent','parent_'),('approximate','')) if case == 'heavy' else (('baseline',''),)):
            work,work_low = fine[prefix_name+'work'],coarse[prefix_name+'work']
            change,change_low = fine[prefix_name+'work_change'],coarse[prefix_name+'work_change']
            responses = {}
            pressure = {}
            for branch,name in enumerate(('old','coherent')):
                current = work[:,0]+(change[:,0] if branch else 0.)
                previous = work_low[:,0]+(change_low[:,0] if branch else 0.)
                increment = current-current[0]
                increment_low = previous-previous[0]
                pressure[name] = {'final':float(increment[-1]),'amplitude':maximum(increment),'numerical':conservative(0.,maximum(increment-increment_low),norms['source_norm'][0],maximum(abs(current)+abs(current[0])+abs(previous)+abs(previous[0])))}
            pressure_change = change[:,0]-change[0,0]
            pressure_change_low = change_low[:,0]-change_low[0,0]
            pressure['coherent_minus_original'] = {'final':float(pressure_change[-1]),'amplitude':maximum(pressure_change),'precision':conservative(0.,maximum(pressure_change-pressure_change_low),maximum(pressure_change),maximum(abs(change[:,0])+abs(change[0,0])+abs(change_low[:,0])+abs(change_low[0,0]))),'structural_zero':case == 'cold'}
            high_read,low_read = readouts(fine[prefix_name+'metric']),readouts(coarse[prefix_name+'metric'])
            primitives = primitive_envelope(fine[prefix_name+'metric'])+primitive_envelope(coarse[prefix_name+'metric'])
            for component,quantity in enumerate(NAMES):
                response = high_read[:,1,component]-high_read[:,0,component]
                response_low = low_read[:,1,component]-low_read[:,0,component]
                responses[quantity] = {'final':float(response[-1]),'amplitude':maximum(response),'precision':conservative(0.,maximum(response-response_low),maximum(response),maximum(primitives[:,0,component]+primitives[:,1,component]))}
            result['cases'][case][mode] = {'pressure_work':pressure,'value_responses':responses}
    fine,coarse = data['heavy-64.npz'],data['heavy-32.npz']
    comparisons = {}
    for branch,name in enumerate(('old','coherent','coherent_minus_original')):
        def selected(dataset,prefix_name):
            work,change = dataset[prefix_name+'work'][:,0],dataset[prefix_name+'work_change'][:,0]
            return work if branch == 0 else work+change if branch == 1 else change
        approximate,parent = selected(fine,''),selected(fine,'parent_')
        approximate_low,parent_low = selected(coarse,''),selected(coarse,'parent_')
        difference = (approximate-approximate[0])-(parent-parent[0])
        refinement = maximum((approximate-approximate[0])-(approximate_low-approximate_low[0]))+maximum((parent-parent[0])-(parent_low-parent_low[0]))
        amplitude = maximum(abs(approximate)+abs(approximate[0])+abs(parent)+abs(parent[0]))
        physical_scale = read(ROOT/'frozen-norms.json')['heavy']['source_norm'][0]
        comparisons['pressure_work_'+name] = {'final_difference':float(difference[-1]),'maximum_difference':maximum(difference),'full_norm':conservative(maximum(difference),refinement,physical_scale,amplitude),'relative_to_parent_work':conservative(maximum(difference),refinement,maximum(parent-parent[0]),amplitude)}
    approximate,parent = readouts(fine['metric']),readouts(fine['parent_metric'])
    approximate_low,parent_low = readouts(coarse['metric']),readouts(coarse['parent_metric'])
    primitive = primitive_envelope(fine['metric'])+primitive_envelope(fine['parent_metric'])+primitive_envelope(coarse['metric'])+primitive_envelope(coarse['parent_metric'])
    for component,name in enumerate(NAMES):
        response = approximate[:,1,component]-approximate[:,0,component]
        parent_response = parent[:,1,component]-parent[:,0,component]
        response_low = approximate_low[:,1,component]-approximate_low[:,0,component]
        parent_response_low = parent_low[:,1,component]-parent_low[:,0,component]
        comparisons[name+'_response'] = conservative(maximum(response-parent_response),maximum(response-response_low)+maximum(parent_response-parent_response_low),maximum(parent_response),maximum(primitive[:,0,component]+primitive[:,1,component]))
    result['approximation_vs_parent'] = comparisons
    result['new_fitted_parameters'] = 0
    result['finite_endpoint_work_from_ODE'] = True
    result['no_new_time_quadrature'] = True
    return result


def calculate(epoch,cumulative=False):
    data,mapping = datasets(epoch,cumulative)
    result = identical_score(data,epoch,cumulative)
    return result,projection(data),mapping


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('epoch',type=int,choices=CONFIG['checkpoint_epochs'])
    parser.add_argument('--cumulative',action='store_true')
    arguments = parser.parse_args()
    label = 'cumulative-score' if arguments.cumulative else 'epoch'+str(arguments.epoch)+'-score'
    with worker(label):
        inputs()
        result,physical,source_mapping = calculate(arguments.epoch,arguments.cumulative)
        write(ROOT/(label+'.json'),result)
        write(ROOT/(label+'-history-inputs.json'),source_mapping)
        write(ROOT/(label+'-physical.json'),physical)
        print(json.dumps({name:result[name] for name in ('last_epoch','cumulative_history','continuation_gate_pass','physical_checks_pass','signed_precision_pass','working_envelope_pass','maximum_inverse_bound')}),flush=True)
