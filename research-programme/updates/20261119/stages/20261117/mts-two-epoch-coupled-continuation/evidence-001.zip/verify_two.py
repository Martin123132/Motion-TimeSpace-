from score_two import *
from check_slip import calculate_slip


def verify():
    inputs()
    epochs = [epoch for epoch in CONFIG['checkpoint_epochs'] if (ROOT/('epoch'+str(epoch)+'-score.json')).is_file()]
    require(epochs and epochs == CONFIG['checkpoint_epochs'][:len(epochs)],'contiguous completed epoch scores')
    checks = {}
    for epoch in epochs:
        label = 'epoch'+str(epoch)+'-score'
        check_inputs(read(ROOT/(label+'-history-inputs.json')))
        science,physical,_ = calculate(epoch)
        checks[label+'_replay'] = science == read(ROOT/(label+'.json'))
        checks[label+'_physical_replay'] = physical == read(ROOT/(label+'-physical.json'))
    science,physical,_ = calculate(epochs[-1],True)
    check_inputs(read(ROOT/'cumulative-score-history-inputs.json'))
    checks['cumulative_score_replay'] = science == read(ROOT/'cumulative-score.json')
    checks['cumulative_physical_replay'] = physical == read(ROOT/'cumulative-score-physical.json')
    check_inputs(read(ROOT/'slip-check-source-freeze.json'))
    check_inputs(read(ROOT/'slip-check-history-inputs.json'))
    check_inputs(read(ROOT/'slip-serialization-source-freeze.json'))
    slip,_ = calculate_slip(epochs[-1])
    checks['stable_slip_replay'] = slip == read(ROOT/'slip-check.json')
    checks['stable_slip_identities'] = slip['all_identity_checks_pass']
    checks['serialization_failure_preserved'] = read(ROOT/'slip-check-failure.json')['error'] == "TypeError('Object of type bool is not JSON serializable')" and read(ROOT/'slip-serialization-receipt.json')['numerical_formulas_changed'] is False
    freeze = (ROOT/'inputs.json').stat().st_mtime
    for case in CONFIG['cases']:
        checks[case+'_preflight'] = read(ROOT/(case+'-preflight-result.json'))['passed']
        for epoch in epochs:
            for steps in CONFIG['steps']:
                label = case+'-'+str(epoch)+'-'+str(steps)
                short = case+'-'+str(steps)
                data = load(folder(epoch)/(short+'.npz'))
                terminal = load(folder(epoch)/(short+'-terminal.npz'))
                previous = load(inherited(epoch)/(short+'-terminal.npz'))
                checks[label+'_initial_complete_exact'] = np.array_equal(data['extended'][0],previous['normalized'])
                checks[label+'_terminal_complete_exact'] = np.array_equal(data['extended'][-1],terminal['normalized'])
                checks[label+'_finite'] = all(np.isfinite(value).all() for value in data.values())
                checks[label+'_clock_continuity'] = previous['tau'] == data['time'][0] and terminal['tau'] == data['time'][-1] and np.all(np.diff(data['time'])>0)
                checks[label+'_owner_released'] = read(ROOT/(label+'-owner-release.json'))['cleared']
                started = datetime.fromisoformat(read(ROOT/(label+'-start.json'))['utc']).timestamp()
                checks[label+'_frozen_first'] = started >= freeze
                if epoch>epochs[0]:
                    prior_gate = ROOT/('epoch'+str(epoch-1)+'-score.json')
                    checks[label+'_preceding_gate_before_start'] = read(prior_gate)['continuation_gate_pass'] and started >= prior_gate.stat().st_mtime
                for path in folder(epoch).glob(short+'-boundary*.npz'):
                    batch = load(path)
                    index = int(batch['completed'])
                    checks[str(path.relative_to(ROOT))+'_exact'] = np.array_equal(batch['normalized'],data['extended'][index]) and batch['tau'] == data['time'][index]
                if case == 'heavy':
                    core_size,native_size = int(terminal['core_size']),int(terminal['native_size'])
                    core = load(folder(epoch)/(short+'-transport-terminal.npz'))
                    parent = load(folder(epoch)/(short+'-parent-terminal.npz'))
                    approximate = load(folder(epoch)/(short+'-approximate-terminal.npz'))
                    checks[label+'_core_exact'] = np.array_equal(terminal['normalized'][:core_size],core['normalized'])
                    checks[label+'_approximate_exact'] = np.array_equal(terminal['normalized'][:native_size],approximate['normalized'])
                    indices = terminal['parent_indices']
                    checks[label+'_parent_exact'] = np.array_equal(terminal['normalized'][native_size+22:native_size+22+len(indices)],parent['normalized'][indices])
                    checks[label+'_memory_not_reset'] = bool(np.any(data['coefficient_matrices'][0] != 0) and np.any(data['fresh_source'][0] != 0) and np.any(data['carry_source'][0] != 0))
                    checks[label+'_inverse_bound'] = bool(np.max(data['coefficient_integral']+.5*data['coefficient_integral']**2)<1)
                    packet = data['metric']
                    species = packet[...,:84].reshape(len(data['time']),2,7,12)
                    wave = CONFIG['retained_comoving_wave']
                    derivative = (np.sum(species[...,7],axis=-1)/(2*wave)+field(packet,'eta_k_prime')-field(packet,'hubble_prime')*field(packet,'z'))/field(packet,'hubble')
                    shear = derivative+3*np.sum(species[...,8],axis=-1)/(2*wave**2)
                    norms = read(ROOT/'frozen-norms.json')['heavy']
                    checks[label+'_actual_metric_derivative'] = maximum(derivative-field(packet,'z_prime')) <= CONFIG['algebra_tolerance']*norms['metric_norm'][3]
                    checks[label+'_actual_shear_derivative'] = maximum(shear-field(packet,'sigma_prime')) <= CONFIG['algebra_tolerance']*norms['metric_norm'][4]
                else:
                    checks[label+'_same_units'] = np.array_equal(terminal['units'],previous['units'])
    final_epoch = epochs[-1]
    for case in CONFIG['cases']:
        label = 'verify-owner-'+case
        with native_context(case,label) as (captured,metadata,sample):
            direct,system,_ = systems(case,final_epoch,64,captured,metadata,sample)
            terminal = load(folder(final_epoch)/(case+'-64-terminal.npz'))
            if case == 'heavy':
                actual = system.rhs(float(terminal['tau']),terminal['normalized'])
                checks['fresh_final_heavy_actual_rhs'] = np.array_equal(actual,terminal['actual_rhs'])
                core = load(folder(final_epoch)/'heavy-64-transport-terminal.npz')
                checks['fresh_final_heavy_core_rhs'] = np.array_equal(system.core.rhs(float(core['tau']),core['normalized']),core['actual_rhs'])
                restore(direct,folder(final_epoch)/'heavy-64-parent-terminal.npz')
                restore(direct,folder(final_epoch)/'heavy-64-approximate-terminal.npz')
            else:
                restore(direct,folder(final_epoch)/'cold-64-terminal.npz')
            checks['fresh_final_'+case+'_native_sources'] = True
        checks[label+'_released'] = read(ROOT/(label+'-owner-release.json'))['cleared']
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['no_bytecode'] = not list(ROOT.rglob('__pycache__'))
    checks['no_old_failure_relabelled'] = not read(Path(CONFIG['transport_directory'])/'replay-score.json')['primary_gate_pass']
    result = {'checks':{name:bool(value) for name,value in checks.items()},'passed':all(checks.values()),'count':len(checks),'completed_epochs':epochs,'cumulative_gate_pass':science['continuation_gate_pass']}
    write(ROOT/'verification.json',result)
    require(result['passed'],'technical check failure: '+str([name for name,value in checks.items() if not value]))
    inputs()
    print(json.dumps({key:result[key] for key in ('passed','count','completed_epochs','cumulative_gate_pass')}),flush=True)


if __name__ == '__main__':
    with worker('verify'):
        verify()
