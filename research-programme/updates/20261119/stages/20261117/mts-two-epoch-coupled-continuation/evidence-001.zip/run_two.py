from carry_bridge import *
import argparse


def prepare():
    require(digest(CARRY/'closeout.json') == CONFIG['carry_seal'],'retained carried-stage seal')
    require(read(CARRY/'science-score.json')['continuation_gate_pass'] and read(CARRY/'verification.json')['passed'],'verified preceding interval')
    mapping = read(CARRY/'inputs.json')
    mapping[str(CARRY/'closeout.json')] = CONFIG['carry_seal']
    for name,entry in read(CARRY/'closeout.json')['artifacts'].items():
        mapping[str(CARRY/name)] = entry['sha256']
    check_inputs(mapping)
    report = {}
    for epoch in CONFIG['checkpoint_epochs']:
        folder(epoch).mkdir(exist_ok=False)
        report[str(epoch)] = {}
        for case in CONFIG['cases']:
            source = source_paths(case)
            with np.load(source,allow_pickle=False) as archive:
                clocks = archive['conformal_time'][epoch-1:epoch+1]
            require(len(clocks) == 2 and clocks[-1]>clocks[0],'original support')
            prepared,_,background,_,_ = EX.problem(case)
            times = np.unique(np.r_[clocks[0],background.boundaries(float(clocks[0]),float(clocks[-1])),clocks[-1]])
            background.evaluate(times)
            np.savez_compressed(folder(epoch)/(case+'-clock.npz'),time=times,native_time=clocks,native_indices=np.array([0,len(times)-1]))
            mapping[str(source)] = digest(source)
            report[str(epoch)][case] = {'samples':len(times),'elapsed_Mpc':float(times[-1]-times[0])}
    write(ROOT/'frozen-norms.json',read(CARRY/'frozen-norms.json'))
    write(ROOT/'preparation.json',{'before_evolution':True,'intervals':report,'midpoint_gate':3043,'physical_matching':3040,'split_anchor':3041,'respective32_64_histories':True})
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path.suffix in ('.py','.md','.json','.npz') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix == '.py':
                compile(path.read_text(encoding='utf-8'),str(path),'exec')
            mapping[str(path)] = digest(path)
    write(ROOT/'inputs.json',mapping)
    inputs()
    print(json.dumps(report),flush=True)


def preflight(case):
    inputs()
    label = case+'-preflight'
    with native_context(case,label) as (captured,metadata,sample):
        checks = {}
        for steps in CONFIG['steps']:
            direct,system,saved = systems(case,3043,steps,captured,metadata,sample)
            target = load(folder(3043)/(case+'-clock.npz'))
            checks[str(steps)+'_matched_clock'] = saved['tau'] == target['time'][0]
            if case == 'heavy':
                _,observed = system.calculate(float(saved['tau']),saved['normalized'],True)
                prior_data = load(CARRY/('heavy-'+str(steps)+'.npz'))
                for name,value in observed.items():
                    checks[str(steps)+'_initial_'+name] = np.array_equal(value,prior_data[name][-1])
                checks[str(steps)+'_memory_present'] = bool(np.any(observed['coefficient_matrices']!=0) and np.any(observed['fresh_source']!=0) and np.any(observed['carry_source']!=0))
            else:
                _,observed = direct.evaluate(float(saved['tau']),saved['normalized'])
                prior_data = load(CARRY/('cold-'+str(steps)+'.npz'))
                for name,value in observed.items():
                    checks[str(steps)+'_initial_'+name] = np.array_equal(value,prior_data[name][-1])
        result = {'checks':{name:bool(value) for name,value in checks.items()},'passed':all(checks.values()),'native_rows':metadata['count'],'known_prefix':1052}
        write(ROOT/(label+'-result.json'),result)
        require(result['passed'],'unreset preflight: '+str([name for name,value in checks.items() if not value]))
        print(json.dumps({'case':case,'checks':len(checks),'passed':True}),flush=True)
    inputs()


def run(case,epoch,steps):
    inputs()
    require(read(ROOT/(case+'-preflight-result.json'))['passed'],'checked inherited state')
    if epoch > CONFIG['checkpoint_epochs'][0]:
        require(read(ROOT/('epoch'+str(epoch-1)+'-score.json'))['continuation_gate_pass'],'passed previous original epoch before proceeding')
    label = case+'-'+str(epoch)+'-'+str(steps)
    output = folder(epoch)
    short = case+'-'+str(steps)
    with native_context(case,label) as (captured,metadata,sample):
        direct,system,saved = systems(case,epoch,steps,captured,metadata,sample)
        current = saved['normalized'].copy()
        clocks = load(output/(case+'-clock.npz'))
        times = clocks['time']
        require(float(saved['tau']) == times[0],'continuous original clock')
        rhs = system.rhs if case == 'heavy' else direct.rhs
        evaluate = (lambda clock,state:system.calculate(clock,state,True)[1]) if case == 'heavy' else (lambda clock,state:direct.evaluate(clock,state)[1])
        states = [current.copy()]
        initial = evaluate(float(times[0]),current)
        previous_data = load(inherited(epoch)/(short+'.npz'))
        require(all(np.array_equal(value,previous_data[name][-1]) for name,value in initial.items()),'all previous boundary outputs bitwise exact')
        observed = {name:np.empty((len(times),*np.asarray(value).shape)) for name,value in initial.items()}
        for name,value in initial.items():
            observed[name][0] = value
        evaluations = 0
        for position,(left,right) in enumerate(zip(times[:-1],times[1:])):
            guard()
            solution = solve_ivp(rhs,(float(left),float(right)),current,method='DOP853',t_eval=[right],rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(direct.prepared['elapsed'][8])/steps)
            require(solution.success,'longer carried continuation')
            current = solution.y[:,-1]
            evaluations += solution.nfev
            states.append(current.copy())
            for name,value in evaluate(float(right),current).items():
                observed[name][position+1] = value
            if (position+1)%CONFIG['batch_boundaries'] == 0 or position == len(times)-2:
                np.savez_compressed(output/(short+'-boundary'+str(position+1)+'.npz'),tau=np.array(right),normalized=current,actual_rhs=rhs(float(right),current),completed=np.array(position+1))
                print(json.dumps({'label':label,'boundary':position+1,'total':len(times)-1}),flush=True)
        locations = np.array([epoch-1,epoch])-CONFIG['first_index']
        require(np.array_equal(captured['clock'][locations],clocks['native_time']),'native report endpoints unchanged')
        reference = captured['observation_reference'][locations]
        control = np.column_stack((-CONFIG['retained_comoving_wave']*(reference[:,26]+reference[:,5])/reference[:,28],reference[:,9],reference[:,21],reference[:,20]-.75*reference[:,21],reference[:,26]-.75*reference[:,24]))
        np.savez_compressed(output/(short+'.npz'),time=times,extended=np.array(states),native_indices=clocks['native_indices'],native_control=control,**observed)
        if case == 'heavy':
            core = current[:system.core_size]
            approximate,parent,_,_ = system.core.unpack(core)
            checkpoint(direct,float(times[-1]),parent,output/(short+'-parent-terminal.npz'))
            checkpoint(direct,float(times[-1]),approximate[:system.core.native_size],output/(short+'-approximate-terminal.npz'))
            np.savez_compressed(output/(short+'-terminal.npz'),tau=np.array(times[-1]),normalized=current,actual_rhs=rhs(float(times[-1]),current),core_size=np.array(system.core_size),native_size=np.array(system.core.native_size),parent_indices=system.core.parent_indices,error_units=system.core.error_units,error_change_units=system.core.error_change_units)
            np.savez_compressed(output/(short+'-transport-terminal.npz'),tau=np.array(times[-1]),normalized=core,actual_rhs=system.core.rhs(float(times[-1]),core),native_size=np.array(system.core.native_size),parent_indices=system.core.parent_indices,error_units=system.core.error_units,error_change_units=system.core.error_change_units)
        else:
            checkpoint(direct,float(times[-1]),current,output/(short+'-terminal.npz'))
        write(ROOT/(label+'-result.json'),{'completed':True,'case':case,'steps':steps,'epoch':epoch,'samples':len(times),'evaluations':evaluations,'no_encode_or_rematching':True,'all_boundary_outputs_exact':True,'future_source_metric_forcing':False})
    inputs()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('command',choices=('prepare','preflight','run'))
    parser.add_argument('--case',choices=CONFIG['cases'],default='heavy')
    parser.add_argument('--epoch',type=int,choices=CONFIG['checkpoint_epochs'],default=3043)
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=32)
    arguments = parser.parse_args()
    label = 'prepare' if arguments.command == 'prepare' else arguments.case+'-'+('preflight' if arguments.command == 'preflight' else str(arguments.epoch)+'-'+str(arguments.steps))
    with worker(label):
        if arguments.command == 'prepare':prepare()
        elif arguments.command == 'preflight':preflight(arguments.case)
        else:run(arguments.case,arguments.epoch,arguments.steps)
