from restart_support import *
import importlib.metadata


if __name__ == '__main__':
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    mapping = read(ROOT/'inputs.json')
    check_inputs(mapping)
    verification = read(ROOT/'verification.json')
    require(verification['passed'],'technical checks passed')
    epochs = verification['completed_epochs']
    science = read(ROOT/'cumulative-score.json')
    expected = {'prepare','cold-preflight','heavy-preflight','cumulative-score','slip-check','slip-serialization','verify'}
    expected.update('epoch'+str(epoch)+'-score' for epoch in epochs)
    expected.update(case+'-'+str(epoch)+'-'+str(steps) for epoch in epochs for case in CONFIG['cases'] for steps in CONFIG['steps'])
    workers = {path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    require(set(workers) == {label+'-start.json' for label in expected},'exact task worker inventory')
    require(all(value['exited'] for value in workers.values()),'all owned identities exited')
    for label in expected:
        if label == 'slip-check':
            failure = read(ROOT/'slip-check-failure.json')
            start = read(ROOT/'slip-check-start.json')
            require(all(start[key] == failure[key] for key in ('pid','created','command')) and failure['error'] == "TypeError('Object of type bool is not JSON serializable')", 'preserved inspected serialization failure')
            require(read(ROOT/'slip-serialization-receipt.json')['numerical_formulas_changed'] is False, 'only JSON representation repaired')
            continue
        start,end = read(ROOT/(label+'-start.json')),read(ROOT/(label+'-end.json'))
        require(end['completed'] and all(start[key]==end[key] for key in ('pid','created','command')),'identity matched completion: '+label)
    releases = {path.name:read(path) for path in ROOT.glob('*-owner-release.json')}
    require(len(releases)==4+4*len(epochs) and all(value['cleared'] for value in releases.values()),'native owners released')
    require({path.name for path in ROOT.glob('*-failure.json')} == {'slip-check-failure.json'},'no unaccounted run failure')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    for name in ('CONTRACT.md','RESULTS.md','NEXT.md'):
        require((ROOT/name).is_file(),'saved scientific handoff')
    closer = identity(process)
    write(ROOT/'cleanup.json',{'workers':workers,'all_exited':True,'native_owner_releases':releases,'closer_identity':closer,'closer_exit_verification':'required after foreground completes','temporary_tools':[],'other_processes_changed':False,'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','psutil')}})
    artifacts = {str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    result = {'stage':'Two-epoch coupled continuation and finite-history consequences','utc':datetime.now(timezone.utc).isoformat(),'completed_target':epochs==CONFIG['checkpoint_epochs'],'completed_epochs':epochs,'last_epoch':epochs[-1],'cumulative_gate_pass':science['continuation_gate_pass'],'technical_checks':verification['count'],'verification_passed':True,'new_fitted_parameters':0,'future_source_metric_forcing':False,'certified_continuum_bound':False,'github':False,'frozen_inputs':len(mapping),'workers_exited':len(workers),'native_owners_released':len(releases),'artifacts':artifacts}
    result['inspected_nonphysical_failure'] = 'slip-check JSON numpy-bool serialization; original code and failure retained, serialized by unchanged-formula wrapper'
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),'bytes':sum(value['bytes'] for value in artifacts.values()),'workers_exited':len(workers),'last_epoch':epochs[-1],'cumulative_gate_pass':science['continuation_gate_pass'],'closer':closer}),flush=True)
