from restart_bridge import *
CARRY = Path(CONFIG['carry_directory'])
sys.path.insert(0,str(CARRY))
from carry import Carried, LiveSecond
from run_phase import source_paths, readouts
from verify_phase import primitive_envelope


def folder(epoch):
    return ROOT/('epoch'+str(epoch))


def inherited(epoch):
    return CARRY if epoch == CONFIG['checkpoint_epochs'][0] else folder(epoch-1)


def systems(case,epoch,steps,captured,metadata,sample):
    known = load(CARRY/(case+'-preflight-capture.npz'))
    for name,value in captured.items():
        require(np.array_equal(value[:1052],known[name]),'known1052 native prefix exact: '+name)
    prepared,_,background,_,_ = EX.problem(case)
    direct = MetricCoupled(case,prepared,background,prefix(captured,case),metadata,sample)
    source = inherited(epoch)
    saved = load(source/(case+'-'+str(steps)+'-terminal.npz'))
    if case == 'cold':
        checked = restore(direct,source/(case+'-'+str(steps)+'-terminal.npz'))
        return direct,None,checked
    reduced = LiveSecond(case,prepared,background,prefix(captured,case),metadata,sample)
    system = Carried(direct,reduced)
    require(int(saved['core_size']) == system.core_size and int(saved['native_size']) == system.core.native_size,'unchanged complete layout')
    require(np.array_equal(saved['error_units'],system.core.error_units) and np.array_equal(saved['error_change_units'],system.core.error_change_units),'same error units')
    actual = system.rhs(float(saved['tau']),saved['normalized'])
    require(np.array_equal(actual,saved['actual_rhs']),'fresh complete actual RHS exact; no encode/reset')
    restore(direct,source/('heavy-'+str(steps)+'-parent-terminal.npz'))
    restore(direct,source/('heavy-'+str(steps)+'-approximate-terminal.npz'))
    return direct,system,saved
