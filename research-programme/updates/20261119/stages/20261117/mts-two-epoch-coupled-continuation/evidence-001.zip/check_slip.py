from score_two import *
from decimal import Decimal, localcontext


def native_state(data, terminal, mode):
    if mode != 'parent':
        return data['extended'][:, :len(terminal['normalized'])]
    native_size = len(terminal['normalized'])
    state = data['extended'][:, :native_size].copy()
    indices = np.r_[np.arange(2*int(terminal['dimensions'][1])), np.arange(2*int(terminal['dimensions'][1])+int(terminal['dimensions'][2]), native_size)]
    begin = native_size+22
    state[:, indices] = data['extended'][:, begin:begin+len(indices)]
    return state


def extract(data, terminal, mode):
    state = native_state(data, terminal, mode)
    active = int(terminal['dimensions'][1])
    baryon = 3
    photon = int(terminal['signature'][3])
    require(0 <= photon < active and 0 <= baryon < active, 'active velocities from retained signature')
    old = state[:, [baryon, photon]]*terminal['state_units'][[baryon, photon]]
    change = state[:, [active+baryon, active+photon]]*terminal['delta_units'][[baryon, photon]]
    value = change[:, 0]-.75*change[:, 1]
    primitive = abs(change[:, 0])+.75*abs(change[:, 1])
    packet = data[('parent_' if mode == 'parent' else '')+'metric']
    material = packet[..., :84].reshape(len(packet),2,7,12)
    require(np.all(material[..., 1, 0]>0) and np.all(material[..., 2, 0]>0), 'positive baryon/photon densities')
    recovered = np.stack((material[..., 1, 4]/material[..., 1, 0], material[..., 2, 4]/material[..., 2, 0]), axis=-1)
    direct = np.stack((old, old+change), axis=1)
    precision = 64*np.finfo(float).eps*maximum(abs(recovered)+abs(direct))
    packet_slip = readouts(packet)[..., 4]
    packet_delta = packet_slip[:,1]-packet_slip[:,0]
    packet_allowance = 64*np.finfo(float).eps*maximum(np.sum(abs(recovered),axis=(1,2))+primitive)
    exact_error = 0.
    with localcontext() as context:
        context.prec = 80
        quarter = Decimal(3)/Decimal(4)
        units = [Decimal.from_float(float(terminal['delta_units'][index])) for index in (baryon,photon)]
        for index, row in enumerate(state):
            exact = Decimal.from_float(float(row[active+baryon]))*units[0]-quarter*Decimal.from_float(float(row[active+photon]))*units[1]
            exact_error = max(exact_error,float(abs(exact-Decimal.from_float(float(value[index])))))
    arithmetic = conservative(exact_error,0.,maximum(value),maximum(primitive))
    checks = {'native_component_identity':maximum(recovered-direct)<=precision, 'packet_difference_within_rounding':maximum(packet_delta-value)<=packet_allowance, 'decimal_arithmetic':exact_error <= 64*np.finfo(float).eps*maximum(primitive)}
    require(all(checks.values()), 'velocity identity failed: '+str(checks))
    return value, primitive, {'checks':checks, 'sample_count':len(value), 'python_baryon_index':baryon, 'python_photon_flux_index':photon, 'packet_difference_maximum':maximum(packet_delta-value), 'packet_rounding_allowance':packet_allowance, 'decimal_arithmetic':arithmetic, 'terminal_signature':terminal['signature'].tolist()}


def calculate_slip(epoch):
    data, mapping = datasets(epoch, True)
    checks, values, primitives, results = {}, {}, {}, {}
    for case in CONFIG['cases']:
        modes = ('parent','approximate') if case == 'heavy' else ('baseline',)
        for mode in modes:
            key = case+'_'+mode
            for steps in CONFIG['steps']:
                suffix = '-'+mode if case == 'heavy' else ''
                path = folder(epoch)/(case+'-'+str(steps)+suffix+'-terminal.npz')
                mapping[str(path)] = digest(path)
                terminal = load(path)
                value, primitive, diagnostic = extract(data[case+'-'+str(steps)+'.npz'],terminal,mode)
                values[key,steps], primitives[key,steps] = value, primitive
                checks[key+'_'+str(steps)] = diagnostic
            value = values[key,64]
            results[key] = {'final':float(value[-1]),'amplitude':maximum(value),'precision':conservative(0.,maximum(value-values[key,32]),maximum(value),maximum(primitives[key,64]+primitives[key,32])),'zero_signal':maximum(value)==0.}
    approximate,parent = values['heavy_approximate',64],values['heavy_parent',64]
    refinement = maximum(approximate-values['heavy_approximate',32])+maximum(parent-values['heavy_parent',32])
    primitive = sum(primitives[key,steps] for key in ('heavy_approximate','heavy_parent') for steps in CONFIG['steps'])
    comparison = conservative(maximum(approximate-parent),refinement,maximum(parent),maximum(primitive))
    original = read(ROOT/'cumulative-score-physical.json')['approximation_vs_parent']['velocity_slip_response']
    return {'scope':'derived cancellation-safe saved-field readout; no propagation change; decimal checks only arithmetic', 'last_epoch':epoch, 'history_start':3041, 'results':results, 'approximation_vs_parent':comparison, 'original_packet_comparison_unchanged':original, 'identities':checks, 'all_identity_checks_pass':all(all(value['checks'].values()) for value in checks.values()), 'all_signal_precision_pass':all(value['precision']['passed'] for value in results.values()) and comparison['passed'], 'unchanged_numerical_tolerance':CONFIG['numerical_tolerance'], 'new_fitted_parameters':0}, mapping


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('epoch',type=int,choices=CONFIG['checkpoint_epochs'])
    arguments = parser.parse_args()
    with worker('slip-check'):
        inputs()
        source_paths = [ROOT/'check_slip.py',ROOT/'SLIP-READOUT.md',ROOT/'score_two.py',PREVIOUS/'native/fortran/mts_metric_hook.inc',PREVIOUS/'native/fortran/camb_python.f90']
        source_hashes = {str(path):digest(path) for path in source_paths}
        write(ROOT/'slip-check-source-freeze.json',source_hashes)
        result,mapping = calculate_slip(arguments.epoch)
        check_inputs(source_hashes)
        check_inputs(mapping)
        write(ROOT/'slip-check-history-inputs.json',mapping)
        write(ROOT/'slip-check.json',result)
        print(json.dumps({name:result[name] for name in ('last_epoch','all_identity_checks_pass','all_signal_precision_pass','approximation_vs_parent')}),flush=True)
