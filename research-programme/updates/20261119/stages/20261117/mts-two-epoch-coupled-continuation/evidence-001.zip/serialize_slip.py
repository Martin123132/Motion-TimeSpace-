from check_slip import *


def ordinary(value):
    if isinstance(value, dict):
        return {key:ordinary(item) for key,item in value.items()}
    if isinstance(value, list):
        return [ordinary(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


if __name__ == '__main__':
    with worker('slip-serialization'):
        inputs()
        failure = read(ROOT/'slip-check-failure.json')
        require(failure['error'] == "TypeError('Object of type bool is not JSON serializable')", 'only inspected output serialization failure')
        require(exited(failure)['exited'], 'original diagnostic worker exited')
        check_inputs(read(ROOT/'slip-check-source-freeze.json'))
        mapping = read(ROOT/'slip-check-history-inputs.json')
        check_inputs(mapping)
        source = {str(ROOT/'serialize_slip.py'):digest(ROOT/'serialize_slip.py')}
        write(ROOT/'slip-serialization-source-freeze.json',source)
        epoch = read(ROOT/'cumulative-score.json')['last_epoch']
        result,replayed_mapping = calculate_slip(epoch)
        require(mapping == replayed_mapping, 'identical saved inputs; no new propagation')
        result = ordinary(result)
        write(ROOT/'slip-check.json',result)
        write(ROOT/'slip-serialization-receipt.json',{'original_failure_retained':True,'failed_worker':failure,'source_unchanged':True,'history_unchanged':True,'numerical_formulas_changed':False,'repair':'Convert numpy scalar booleans to ordinary JSON-compatible Python scalars; no failed science gate bypassed.'})
        check_inputs(source)
        print(json.dumps({name:result[name] for name in ('last_epoch','all_identity_checks_pass','all_signal_precision_pass','approximation_vs_parent')}),flush=True)
