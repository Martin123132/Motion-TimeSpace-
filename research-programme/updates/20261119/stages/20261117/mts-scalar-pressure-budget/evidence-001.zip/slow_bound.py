from pressure_math import *
from decimal import Decimal,localcontext,ROUND_CEILING,ROUND_FLOOR
import argparse

def exact(value):
    return Decimal.from_float(float(value))

def hermite_bounds(times,values,derivative,stride):
    indices=np.unique(np.concatenate((np.arange(0,len(times),stride),[len(times)-1])))
    upper=Decimal(0)
    lower=None
    for left,right in zip(indices[:-1],indices[1:]):
        width=exact(times[right])-exact(times[left])
        first,last=exact(values[left]),exact(values[right])
        first_slope,last_slope=abs(exact(derivative[left])),abs(exact(derivative[right]))
        upper=max(upper,abs(first)+width*first_slope/3,abs(last)+width*last_slope/3)
        with localcontext() as downward:
            downward.rounding=ROUND_FLOOR
            candidate=min(first-width*first_slope/3,last-width*last_slope/3)
        lower=candidate if lower is None else min(lower,candidate)
    return lower,upper

def represented_scale_bounds(profile):
    background=profile.background
    indices=(np.log(profile.times[[0,-1]]/background.minimum)/background.spacing+1).astype(int)-1
    lower=None
    upper=Decimal(0)
    for index in range(max(0,int(indices[0])-1),min(len(background.clock)-1,int(indices[1])+2)):
        first,slope=map(exact,background.clock[index])
        last,last_slope=map(exact,background.clock[index+1])
        upper=max(upper,first+abs(slope)/3,last+abs(last_slope)/3)
        with localcontext() as downward:
            downward.rounding=ROUND_FLOOR
            candidate=min(first-abs(slope)/3,last-abs(last_slope)/3)
        lower=candidate if lower is None else min(lower,candidate)
    with localcontext() as downward:
        downward.rounding=ROUND_FLOOR
        minimum=lower*exact(profile.times[0])
    maximum_scale=upper*exact(profile.times[-1])
    require(minimum>0,"positive represented scale enclosure")
    return minimum,maximum_scale

def spline_absolute_bound(spline,lower_log,upper_log):
    require(lower_log>=exact(spline.x[0]) and upper_log<=exact(spline.x[-1]),"bounded original spline support")
    bounds=[]
    for index in range(len(spline.x)-1):
        if exact(spline.x[index])>upper_log or exact(spline.x[index+1])<lower_log:
            continue
        width=exact(spline.x[index+1])-exact(spline.x[index])
        coefficients=[abs(exact(value)) for value in spline.c[:,index]]
        bounds.append(coefficients[3]+width*(coefficients[2]+width*(coefficients[1]+width*coefficients[0])))
    require(bool(bounds),"covered original spline cells")
    return max(bounds)

def enclosure(profile,stride):
    if profile.branch==0:
        minimum_scale,maximum_scale=represented_scale_bounds(profile)
        lower_log=minimum_scale.ln().next_minus()
        upper_log=maximum_scale.ln().next_plus()
        field_bounds=[spline_absolute_bound(field_spline,lower_log,upper_log) for field_spline,_ in profile.background.fields]
        velocity_bounds=[spline_absolute_bound(velocity_spline,lower_log,upper_log) for _,velocity_spline in profile.background.fields]
    else:
        minimum_scale,maximum_scale=hermite_bounds(profile.times,profile.vector[:,0],profile.derivative[:,0],stride)
        require(minimum_scale>0,"positive coherent scale enclosure")
        field_bounds=[hermite_bounds(profile.times,profile.vector[:,1+2*index],profile.derivative[:,1+2*index],stride)[1]
                      for index in range(profile.count)]
        velocity_bounds=[hermite_bounds(profile.times,profile.vector[:,2+2*index],profile.derivative[:,2+2*index],stride)[1]
                         for index in range(profile.count)]
    perturbation=hermite_bounds(profile.times,profile.vector[:,profile.width],profile.derivative[:,profile.width],stride)[1]
    speed=hermite_bounds(profile.times,profile.vector[:,profile.width+1],profile.derivative[:,profile.width+1],stride)[1]
    constants=profile.model.constants
    density=(abs(exact(constants[0]))+abs(exact(constants[1])))/minimum_scale
    density+=(abs(exact(constants[2]))+abs(exact(constants[3])))/minimum_scale**2
    coefficient=exact(5/(7*np.pi**2))
    for index in range(int(constants[4])):
        minimum_argument=minimum_scale*abs(exact(constants[8+index]))
        maximum_argument=maximum_scale*abs(exact(constants[8+index]))
        require(minimum_argument>0,"positive massive neutrino argument")
        logarithm_bound=max(maximum_argument,1/minimum_argument)
        rho_bound=(1+coefficient*maximum_argument**2+
                   maximum_argument**4*(exact(.01099926669)*logarithm_bound+exact(.003492416767)+exact(.005866275571)*maximum_argument))
        density+=abs(exact(constants[14+index]))*rho_bound/minimum_scale**2
    for index in range(profile.count):
        mass_square=(maximum_scale*abs(exact(constants[6+index])))**2
        density+=(velocity_bounds[index]**2+mass_square*field_bounds[index]**2)/2
    hubble_bound=(density/3).sqrt().next_plus()
    slow_mass_square=(maximum_scale*abs(exact(constants[6])))**2
    pressure_bound=velocity_bounds[0]*speed+slow_mass_square*field_bounds[0]*perturbation
    interval=exact(profile.times[-1])-exact(profile.times[0])
    weighted_bound=interval*hubble_bound*maximum_scale/exact(profile.prepared["density0"])*pressure_bound
    return {"a_min":minimum_scale,"a_max":maximum_scale,"H_max":hubble_bound,
            "slow_field_max":field_bounds[0],"slow_velocity_max":velocity_bounds[0],
            "slow_perturbation_max":perturbation,"slow_perturbation_velocity_max":speed,
            "raw_slow_pressure_bound":pressure_bound,"weighted_slow_pressure_integral_bound":weighted_bound,
            "density_exchange_contribution_bound":3*weighted_bound}

def prepare():
    inputs()
    norms={}
    for case in CONFIG["cases"]:
        prepared,_,_,_,_=EX.problem(case)
        packet=load(METRIC / (case+"-reference-metric.npz"))["packet"]
        material=packet[:,:84].reshape(len(packet),7,12)
        beta=field(packet,"scale")/float(prepared["density0"])
        norms[case]=float(np.max(beta*np.sum(abs(material[:,:,3]),axis=1)))
    write(ROOT / "slow-bound-plan.json",{"utc":datetime.now(timezone.utc).isoformat(),
          "files":{str(ROOT / "slow_bound.py"):digest(ROOT / "slow_bound.py")},
          "system_density_norms":norms,"norm_scope":"L1 species density-source amplitude over original934 reference states",
          "precision":80,"rounding":"positive arithmetic upwards; scale minima downwards",
          "hypothesis":"continuous represented background and declared Hermite reconstruction, not a rigorous enclosure of unknown ODE trajectory error",
          "original_slow_self_normalized_identity_failures_remain":True})
    print(json.dumps({"system_density_norms":norms}),flush=True)

def run():
    inputs()
    plan=read(ROOT / "slow-bound-plan.json")
    check_inputs(plan["files"])
    reports={}
    with localcontext() as context:
        context.prec=80
        context.rounding=ROUND_CEILING
        for case in CONFIG["cases"]:
            reports[case]={}
            for branch,name in enumerate(("old","coherent")):
                entries={}
                worst=Decimal(0)
                for steps in CONFIG["steps"]:
                    profile=Profile(case,steps,branch)
                    require(all(item["passed"] for item in profile.checks.values()),"retained primitive checks")
                    for stride in CONFIG["strides"]:
                        values=enclosure(profile,stride)
                        worst=max(worst,values["density_exchange_contribution_bound"])
                        entries[str(steps)+"-stride"+str(stride)]={key:str(value) for key,value in values.items()}
                scale=exact(plan["system_density_norms"][case])
                reports[case][name]={"enclosures":entries,"largest_exchange_bound":str(worst),
                    "relative_to_original_system_density":str(worst/scale),
                    "within_system_tolerance":bool(worst<=exact(CONFIG["numerical_tolerance"])*scale),
                    "original_self_normalized_identity_pass":False,
                    "bound_is_conditional_on_reconstructed_profiles":True}
    write(ROOT / "slow-stress-bound.json",reports)
    print(json.dumps({case:{branch:{key:value for key,value in report.items() if key!="enclosures"}
          for branch,report in branches.items()} for case,branches in reports.items()}),flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("prepare","run"))
    arguments=parser.parse_args()
    with worker("slow-bound-"+arguments.command):
        prepare() if arguments.command=="prepare" else run()
