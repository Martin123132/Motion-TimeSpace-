from pressure_math import *
import contextlib
import io

if __name__=="__main__":
    with worker("verify"):
        inputs()
        checks={}
        for case in CONFIG["cases"]:
            for steps in CONFIG["steps"]:
                report=read(ROOT / (case+"-"+str(steps)+"-result.json"))
                original=load(GAP / (case+"-live-"+str(steps)+".npz"))
                for branch in ("old","coherent"):
                    checks[case+"_"+str(steps)+"_"+branch+"_native_checks"]=all(item["passed"] for item in report[branch]["checks"].values())
                    for stride in CONFIG["strides"]:
                        for order in CONFIG["quadrature_orders"]:
                            label=case+"-"+str(steps)+"-"+branch+"-stride"+str(stride)+"-order"+str(order)
                            data=load(ROOT / (label+".npz"))
                            checks[label+"_same_clock"]=np.array_equal(data["time"],original["time"])
                            checks[label+"_finite"]=all(np.isfinite(value).all() for value in data.values())
                            checks[label+"_zero_integral_origin"]=np.all(data["cumulative"][0]==0) and np.all(data["components"][0]==0)
        import score_pressure as scorer
        captured={}
        original_write=scorer.write
        scorer.write=lambda path,value:captured.update({str(path):value})
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                scorer.score()
        finally:
            scorer.write=original_write
        checks["score_replay_exact"]=captured[str(ROOT / "science-score.json")]==read(ROOT / "science-score.json")
        checks["original_symbolic_identity"]=read(GAP / "pressure-identity.json")["passed"]
        checks["manufactured_quadrature_checks"]=read(ROOT / "preparation.json")["passed"]
        checks["previous_workers_exited"]=all(exited(read(path))["exited"] for path in ROOT.glob("*-start.json") if path.name!="verify-start.json")
        checks["no_bytecode"]=not (ROOT / "__pycache__").exists()
        for path in ROOT.glob("*.py"):
            compile(path.read_text(encoding="utf-8"),str(path),"exec")
        checks["scripts_compile"]=True
        science=read(ROOT / "science-score.json")
        result={"passed":all(bool(value) for value in checks.values()),"count":len(checks),
                "checks":{name:bool(value) for name,value in checks.items()},
                "heavy_independent_work_budgets_pass":science["heavy_independent_work_budgets_pass"],
                "all_identity_budgets_pass":science["all_identity_budgets_pass"]}
        write(ROOT / "verification.json",result)
        print(json.dumps({name:value for name,value in result.items() if name!="checks"}),flush=True)
        require(result["passed"],"technical verification")
