from restart_support import *
import importlib.metadata

if __name__=="__main__":
    check_inputs(read(ROOT / "inputs.json"))
    check_inputs(read(ROOT / "slow-bound-plan.json")["files"])
    check_inputs(read(ROOT / "slow-bound-outward-plan.json")["files"])
    verification=read(ROOT / "verification.json")
    bound_verification=read(ROOT / "bound-verification.json")
    science=read(ROOT / "science-score.json")
    require(verification["passed"] and bound_verification["passed"],"verified recorded pressure calculation")
    require(science["heavy_independent_work_budgets_pass"],"heavy pressure identity evaluated")
    workers={path.name:{**read(path),**exited(read(path))} for path in ROOT.glob("*-start.json")}
    require(all(value["exited"] for value in workers.values()),"all worker identities exited")
    require(not (ROOT / "__pycache__").exists(),"no bytecode")
    for path in ROOT.glob("*.py"):
        compile(path.read_text(encoding="utf-8"),str(path),"exec")
    write(ROOT / "cleanup.json",{"workers":workers,"all_exited":True,"native_owners_started":0,
          "temporary_tools":[],"other_processes_changed":False,"python":sys.version,
          "packages":{name:importlib.metadata.version(name) for name in ("numpy","scipy","sympy","psutil")}})
    artifacts={str(path.relative_to(ROOT)):{"sha256":digest(path),"bytes":path.stat().st_size}
               for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name!="closeout.json"}
    result={"stage":"Saved scalar pressure decomposition and conditional slow-stress bound",
            "utc":datetime.now(timezone.utc).isoformat(),"completed":True,"verification_passed":True,
            "main_checks":verification["count"],"bound_checks":bound_verification["count"],
            "heavy_independent_work_budgets_pass":True,"all_identity_budgets_pass":science["all_identity_budgets_pass"],
            "pressureless_substitution_rejected_on_saved_window":True,
            "slow_stress_bound_scope":"conditional declared profiles; not a continuum ODE uncertainty proof",
            "frozen_inputs":len(read(ROOT / "inputs.json")),"workers_exited":len(workers),"new_native_evolution":False,
            "github":False,"artifacts":artifacts}
    write(ROOT / "closeout.json",result)
    print(json.dumps({"seal":digest(ROOT / "closeout.json"),"artifacts":len(artifacts),
          "workers_exited":len(workers),"bytes":sum(value["bytes"] for value in artifacts.values())}),flush=True)
