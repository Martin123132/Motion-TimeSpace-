from pressure_math import *

def history(case,steps,branch,stride=1,order=5):
    return load(ROOT / (case+"-"+str(steps)+"-"+branch+"-stride"+str(stride)+"-order"+str(order)+".npz"))

def score():
    inputs()
    reports={}
    for case in CONFIG["cases"]:
        norms=read(ROOT / "frozen-norms.json")[case]
        reports[case]={}
        for branch in ("old","coherent"):
            fine=history(case,64,branch)
            lower_order=history(case,64,branch,order=3)
            stride_two=history(case,64,branch,stride=2)
            stride_four=history(case,64,branch,stride=4)
            lower_steps=history(case,32,branch)
            own_ref=load(ROOT / (case+"-64-"+branch+"-reference.npz"))
            own_ref_low=load(ROOT / (case+"-32-"+branch+"-reference.npz"))
            for scalar,name in enumerate(norms["scalar_names"]):
                independent=case=="heavy" and name=="heavy"
                scale=norms["scalar_source_norms"][scalar][0]
                reference=own_ref["saved_owned_pressure_work"] if independent else fine["cumulative"][:,scalar,0]
                reference_low=own_ref_low["saved_owned_pressure_work"] if independent else lower_steps["cumulative"][:,scalar,0]
                components=fine["components"][:,scalar]
                residual=np.sum(components,axis=1)-reference
                def difference(other,include_reference):
                    errors=np.sum(abs(components-other["components"][:,scalar]),axis=1)
                    if include_reference:
                        errors=errors+abs(fine["cumulative"][:,scalar,0]-other["cumulative"][:,scalar,0])
                    return maximum(errors)
                quadrature=difference(lower_order,not independent)
                interpolation12=difference(stride_two,not independent)
                interpolation24=maximum(np.sum(abs(stride_two["components"][:,scalar]-stride_four["components"][:,scalar]),axis=1)+
                    (abs(stride_two["cumulative"][:,scalar,0]-stride_four["cumulative"][:,scalar,0]) if not independent else 0.))
                sampling=max(interpolation12,interpolation24)
                step=maximum(np.sum(abs(components-lower_steps["components"][:,scalar]),axis=1)+abs(reference-reference_low))
                amplitude=maximum(abs(fine["boundary"][:,scalar])+abs(fine["boundary"][0,scalar])+
                    np.sum(fine["absolute"][:,scalar,1:5],axis=1)+abs(reference))
                rounding=64*np.finfo(float).eps*amplitude
                allowance=quadrature+sampling+step+rounding
                budget=ratio(maximum(residual)+allowance,scale)
                budget.update(residual=maximum(residual),quadrature=quadrature,sampling=sampling,
                              paired_steps=step,rounding=rounding,working_estimate_not_uniform_bound=True)
                direct=fine["cumulative"][:,scalar,0]
                direct_quad=maximum(direct-lower_order["cumulative"][:,scalar,0])
                direct_sample=max(maximum(direct-stride_two["cumulative"][:,scalar,0]),
                                  maximum(stride_two["cumulative"][:,scalar,0]-stride_four["cumulative"][:,scalar,0]))
                direct_step=maximum(direct-lower_steps["cumulative"][:,scalar,0])+maximum(reference-reference_low)
                direct_budget=ratio(maximum(direct-reference)+direct_quad+direct_sample+direct_step+rounding,scale)
                omission={}
                for column,term in enumerate(("boundary","expansion","gradient","metric","contacts")):
                    omission[term]={"term_final":float(components[-1,column]),"max_cumulative_magnitude":maximum(components[:,column]),
                                    "omission_residual_over_norm":maximum(residual-components[:,column])/scale,
                                    "omission_detected":maximum(residual-components[:,column])>CONFIG["numerical_tolerance"]*scale}
                pressure_deletion=ratio(3*maximum(reference)+3*(maximum(reference-reference_low)+rounding),scale)
                absolute_density=float(fine["absolute"][-1,scalar,5])
                absolute_pressure=float(fine["absolute"][-1,scalar,0])
                reports[case][branch+"_"+name]={"independent_saved_work":independent,
                    "reference_kind":"saved integrated pressure work" if independent else "direct primitive quadrature; no separate saved scalar work accumulator",
                    "identity_budget":budget,"direct_pressure_quadrature_crosscheck":direct_budget,
                    "sampling_differences":[interpolation12,interpolation24],
                    "sampling_difference_shrinks":bool(interpolation12<=interpolation24+rounding),
                    "final_pressure_integral":float(reference[-1]),"final_rhs":float(np.sum(components[-1])),
                    "max_pressure_integral":maximum(reference),"frozen_density_norm":scale,
                    "terms":omission,"pressure_deletion_within_tolerance":pressure_deletion,
                    "signed_pressure_over_absolute_density":float(reference[-1]/absolute_density) if absolute_density else None,
                    "absolute_pressure_over_absolute_density":absolute_pressure/absolute_density if absolute_density else None,
                    "bulk_without_boundary_over_absolute_density":float(np.sum(components[-1,1:])/absolute_density) if absolute_density else None,
                    "no_equation_of_state_fit":True}
        if case=="cold":
            data=load(GAP / "cold-live-64.npz")
            reports[case]["owned_cold_pressure_structural_zero"]=bool(np.all(data["source"][:,2]==0) and np.all(data["source_change"][:,2]==0))
    result={"cases":reports,
            "all_identity_budgets_pass":all(item["identity_budget"]["passed"] for case in reports.values() for item in case.values() if isinstance(item,dict)),
            "heavy_independent_work_budgets_pass":all(reports["heavy"][branch+"_heavy"]["identity_budget"]["passed"] for branch in ("old","coherent")),
            "interpretation":"Finite-window pressure decomposition. Neither a fitted fluid law nor a proof of universally negligible pressure.",
            "numerical_estimates_are_not_rigorous_bounds":True}
    write(ROOT / "science-score.json",result)
    compact={case:{name:{"budget":item["identity_budget"],"pressure_deletion":item["pressure_deletion_within_tolerance"],
                        "final_integral":item["final_pressure_integral"],"terms":{key:value["term_final"] for key,value in item["terms"].items()},
                        "absolute_pressure_over_absolute_density":item["absolute_pressure_over_absolute_density"]}
                   for name,item in report.items() if isinstance(item,dict)} for case,report in reports.items()}
    print(json.dumps(compact),flush=True)

if __name__=="__main__":
    with worker("score"):
        score()
