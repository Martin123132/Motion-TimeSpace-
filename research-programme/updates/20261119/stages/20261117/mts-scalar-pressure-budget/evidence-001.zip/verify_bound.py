from pressure_math import *
import slow_bound_outward as bounds
from decimal import Decimal,localcontext,ROUND_CEILING
from fractions import Fraction
import contextlib
import io

if __name__=="__main__":
    with worker("verify-bound"):
        inputs()
        plan=read(ROOT / "slow-bound-outward-plan.json")
        check_inputs(plan["files"])
        checks={}
        with localcontext() as context:
            context.prec=80
            context.rounding=ROUND_CEILING
            examples=(
                ([0.,.2,.8,1.],[1.,2.,.1,3.],[10.,-8.,7.,-2.]),
                ([0.,.1,.10000001,.9],[-2.,1.,-.1,-3.],[-7.,1.,15.,4.]),
                ([0.,.4,1.],[1e-25,-2e-25,3e-25],[1e-23,-2e-23,1e-23]))
            for example,(times,values,derivative) in enumerate(examples):
                for stride in (1,2):
                    lower,upper=bounds.hermite_bounds(np.array(times),np.array(values),np.array(derivative),stride)
                    indices=np.unique(np.concatenate((np.arange(0,len(times),stride),[len(times)-1])))
                    rational=[]
                    for first,last in zip(indices[:-1],indices[1:]):
                        width=Fraction(times[last])-Fraction(times[first])
                        rational.extend((Fraction(values[first]),Fraction(values[first])+width*Fraction(derivative[first])/3,
                                         Fraction(values[last])-width*Fraction(derivative[last])/3,Fraction(values[last])))
                    checks["rational_lower_"+str(example)+"_"+str(stride)]=Fraction(lower)<=min(rational)
                    checks["rational_upper_"+str(example)+"_"+str(stride)]=Fraction(upper)>=max(abs(item) for item in rational)
            for case in CONFIG["cases"]:
                for branch,name in enumerate(("old","coherent")):
                    profile=Profile(case,64,branch)
                    enclosure=bounds.enclosure(profile,1)
                    for key,values in (("slow_field_max",profile.values["phi"][:,0]),
                                       ("slow_velocity_max",profile.values["velocity"][:,0]),
                                       ("slow_perturbation_max",profile.perturbation[:,0,0]),
                                       ("slow_perturbation_velocity_max",profile.perturbation[:,0,1]),
                                       ("H_max",profile.values["hubble"])):
                        checks[case+"_"+name+"_"+key+"_saved_samples"]=all(abs(bounds.exact(value))<=enclosure[key] for value in values)
                    checks[case+"_"+name+"_scale_range"]=all(enclosure["a_min"]<=bounds.exact(value)<=enclosure["a_max"] for value in profile.values["scale"])
        original=read(ROOT / "slow-stress-outward-bound.json")
        captured={}
        original_write=bounds.write
        bounds.write=lambda path,value:captured.update({str(path):value})
        try:
            with contextlib.redirect_stdout(io.StringIO()):
                bounds.run()
        finally:
            bounds.write=original_write
        checks["outward_bound_replay_exact"]=captured[str(ROOT / "slow-stress-outward-bound.json")]==original
        score=read(ROOT / "science-score.json")
        checks["slow_self_norm_failures_preserved"]=all(not score["cases"][case][branch+"_slow"]["identity_budget"]["passed"]
            for case in CONFIG["cases"] for branch in ("old","coherent"))
        checks["heavy_independent_identity_passes_preserved"]=score["heavy_independent_work_budgets_pass"]
        checks["pressure_deletion_rejection_preserved"]=all(not score["cases"]["heavy"][branch+"_heavy"]["pressure_deletion_within_tolerance"]["passed"] for branch in ("old","coherent"))
        checks["all_prior_workers_exited"]=all(exited(read(path))["exited"] for path in ROOT.glob("*-start.json") if path.name!="verify-bound-start.json")
        checks["no_bytecode"]=not (ROOT / "__pycache__").exists()
        result={"passed":all(bool(value) for value in checks.values()),"count":len(checks),
                "checks":{name:bool(value) for name,value in checks.items()},
                "scope":"conditional reconstructed-profile stress enclosure; original slow self-normalized failures remain"}
        write(ROOT / "bound-verification.json",result)
        print(json.dumps({name:value for name,value in result.items() if name!="checks"}),flush=True)
        require(result["passed"],"outward enclosure and preserved-failure checks")
