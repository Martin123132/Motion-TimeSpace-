from pressure_math import *
import argparse

def prepare():
    for path in ROOT.glob("*.py"):
        compile(path.read_text(encoding="utf-8"),str(path),"exec")
    require(digest(GAP / "closeout.json")==CONFIG["gap_seal"],"accepted coarse-gap seal")
    require(read(GAP / "pressure-identity.json")["passed"],"accepted exact scalar identity")
    mapping=read(GAP / "inputs.json")
    mapping[str(GAP / "closeout.json")]=CONFIG["gap_seal"]
    for name,entry in read(GAP / "closeout.json")["artifacts"].items():
        mapping[str(GAP / name)]=entry["sha256"]
    norms={}
    for case in CONFIG["cases"]:
        prepared,_,background,_,_=EX.problem(case)
        reference=load(METRIC / (case+"-reference-metric.npz"))["packet"]
        count=len(background.fields)
        material=reference[:,:84].reshape(len(reference),7,12)
        beta=field(reference,"scale")/float(prepared["density0"])
        primitive=material[:,5:5+count][:,:,[3,4,5]]*beta[:,None,None]
        frozen=np.max(abs(primitive),axis=0)
        require(np.isfinite(frozen).all() and np.all(frozen[:,0]>0),"nonzero prior density norms")
        norms[case]={"scalar_source_norms":frozen.tolist(),"scalar_names":["slow"]+(["heavy"] if count==2 else []),
                     "source":"original934 native reference, not newly chosen from current residuals",
                     "integrated_work_norm":"density column of scalar_source_norms","rho0":float(prepared["density0"])}
    if (ROOT / "frozen-norms.json").exists():
        require(read(ROOT / "frozen-norms.json")==norms,"previously frozen norms unchanged")
    else:
        write(ROOT / "frozen-norms.json",norms)
    queries=np.array([0.,.1,.4,.400001,.8,1.])
    polynomial=queries**3-2*queries**2+3*queries+1
    derivative=3*queries**2-4*queries+3
    interpolation=CubicHermiteSpline(queries,polynomial,derivative)
    check_points=np.linspace(0,1,31)
    nodes,weights=np.polynomial.legendre.leggauss(5)
    samples=(queries[:-1,None]+queries[1:,None]+np.diff(queries)[:,None]*nodes)/2
    weighted=np.diff(queries)[:,None]*weights/2
    integral=np.sum(weighted*interpolation(samples))
    tests={"hermite_cubic":maximum(interpolation(check_points)-(check_points**3-2*check_points**2+3*check_points+1))<1e-10,
           "gauss_weight_sum":abs(np.sum(weighted)-1)<1e-10,
           "polynomial_integral":abs(integral-(.25-2/3+1.5+1))<1e-10}
    tests={name:bool(value) for name,value in tests.items()}
    require(all(tests.values()),"manufactured interpolation/quadrature controls")
    if (ROOT / "preparation.json").exists():
        require(read(ROOT / "preparation.json")["checks"]==tests and read(ROOT / "preparation.json")["passed"],"unchanged manufactured test receipt")
    else:
        write(ROOT / "preparation.json",{"utc":datetime.now(timezone.utc).isoformat(),"checks":tests,
              "passed":True,"scope":"saved histories only; no native worker or coupled evolution"})
    for path in ROOT.glob("*"):
        if path.suffix in (".py",".md",".json") and not path.name.endswith(("-start.json","-end.json","-failure.json")):
            mapping[str(path)]=digest(path)
            if path.suffix==".py":
                compile(path.read_text(encoding="utf-8"),str(path),"exec")
    write(ROOT / "inputs.json",mapping)
    inputs()
    print(json.dumps({"frozen_inputs":len(mapping),"norms":norms,"controls":tests}),flush=True)

def run(case,steps):
    inputs()
    results={}
    for branch,name in enumerate(("old","coherent")):
        profile=Profile(case,steps,branch)
        require(all(item["passed"] for item in profile.checks.values()),"native primitive and exact field derivative checks")
        for stride in CONFIG["strides"]:
            for order in CONFIG["quadrature_orders"]:
                output=profile.integrate(stride,order)
                label=case+"-"+str(steps)+"-"+name+"-stride"+str(stride)+"-order"+str(order)
                np.savez_compressed(ROOT / (label+".npz"),**output)
        work=profile.data["work"]+(profile.data["work_change"] if branch else 0.)
        reference=-(work[:,0]-work[0,0])/3
        np.savez_compressed(ROOT / (case+"-"+str(steps)+"-"+name+"-reference.npz"),time=profile.times,
                            saved_owned_pressure_work=reference,node_terms=profile.node_terms,primitive=profile.primitive)
        results[name]={"checks":profile.checks,"passed":True,"fields":read(ROOT / "frozen-norms.json")[case]["scalar_names"],
                       "owned_pressure_work_scope":"heavy independent accumulator" if case=="heavy" else "cold structural zero; not slow scalar accumulator"}
    write(ROOT / (case+"-"+str(steps)+"-result.json"),results)
    inputs()
    print(json.dumps({"case":case,"steps":steps,"branches_passed":True}),flush=True)

if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("prepare","run"))
    parser.add_argument("--case",choices=CONFIG["cases"])
    parser.add_argument("--steps",type=int,choices=CONFIG["steps"],default=64)
    parser.add_argument("--receipt-tag",default="")
    arguments=parser.parse_args()
    label="prepare" if arguments.command=="prepare" else arguments.case+"-"+str(arguments.steps)
    with worker(label+arguments.receipt_tag):
        prepare() if arguments.command=="prepare" else run(arguments.case,arguments.steps)
