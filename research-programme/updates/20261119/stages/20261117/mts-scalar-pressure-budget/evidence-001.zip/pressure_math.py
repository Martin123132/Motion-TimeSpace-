from restart_bridge import *
from scipy.interpolate import CubicHermiteSpline

TERM_NAMES=("pressure_direct","expansion","gradient","metric","contacts","density_weighted")

def background_values(times,state,branch,background,model):
    if branch==0:
        represented=background.evaluate(times)
        scale=represented["scale"]
        phi=np.column_stack([item[0] for item in represented["jets"]])
        velocity=np.column_stack([item[1] for item in represented["jets"]])
        phi_prime=np.column_stack([item[2] for item in represented["jets"]])
        velocity_prime=np.column_stack([item[3] for item in represented["jets"]])
        hubble=represented["hubble"]
        rate=represented["rate"]
    else:
        scale,phi,velocity=state[:,0],state[:,1::2],state[:,2::2]
        hubble=np.array([model.absolute_hubble(row)[0] for row in state])
        rate=hubble.copy()
        phi_prime=velocity.copy()
        mass=(scale[:,None]*model.constants[None,6:6+model.count])**2
        velocity_prime=-2*hubble[:,None]*velocity-mass*phi
    mass=(scale[:,None]*model.constants[None,6:6+model.count])**2
    external_derivative=np.array([model.external(float(value))[1] for value in scale])
    density_prime=rate*external_derivative+np.sum(velocity*velocity_prime+rate[:,None]*mass*phi**2+
                                                mass*phi*phi_prime,axis=1)
    hubble_prime=density_prime/(6*hubble)
    field_defect=phi_prime-velocity
    velocity_defect=velocity_prime+2*hubble[:,None]*velocity+mass*phi
    if branch==1:
        field_defect=np.zeros_like(phi)
        velocity_defect=np.zeros_like(velocity)
    packed=np.empty((len(times),1+2*model.count))
    packed[:,0],packed[:,1::2],packed[:,2::2]=scale,phi,velocity
    derivative=np.empty_like(packed)
    derivative[:,0],derivative[:,1::2],derivative[:,2::2]=scale*rate,phi_prime,velocity_prime
    return dict(state=packed,derivative=derivative,scale=scale,phi=phi,velocity=velocity,mass=mass,
                hubble=hubble,hubble_prime=hubble_prime,rate=rate,field_defect=field_defect,velocity_defect=velocity_defect)

def expressions(values,perturbation,metric,beta):
    phi,velocity=values["phi"],values["velocity"]
    displacement,speed=perturbation[...,0],perturbation[...,1]
    hubble=values["hubble"][:,None]
    rate=values["rate"][:,None]
    hubble_prime=values["hubble_prime"][:,None]
    field_defect,velocity_defect=values["field_defect"],values["velocity_defect"]
    wave=CONFIG["retained_comoving_wave"]
    current=velocity*displacement+phi*speed
    product=phi*displacement
    density=velocity*speed+values["mass"]*product
    pressure=velocity*speed-values["mass"]*product
    flow=wave*velocity*displacement
    boundary=.5*hubble*beta[:,None]*current
    terms=np.stack((hubble*beta[:,None]*pressure,
                    .5*beta[:,None]*(2*hubble**2-hubble_prime-hubble*rate)*current,
                    .5*beta[:,None]*hubble*wave**2*product,
                    .5*beta[:,None]*hubble*wave*phi*velocity*metric[:,None],
                    -.5*beta[:,None]*hubble*(velocity_defect*displacement+field_defect*speed),
                    hubble*beta[:,None]*density),axis=-1)
    primitive=np.stack((density,flow,pressure),axis=-1)*beta[:,None,None]
    return boundary,terms,primitive

class Profile:
    def __init__(self,case,steps,branch):
        self.case,self.steps,self.branch=case,steps,branch
        self.data=load(GAP / (case+"-live-"+str(steps)+".npz"))
        self.terminal=load(GAP / (case+"-live-"+str(steps)+"-terminal.npz"))
        self.prepared,_,self.background,_,_=EX.problem(case)
        self.model=retained_run.BG.Model(self.background,float(self.prepared["times"][0]))
        self.times=self.data["time"]
        self.width=len(self.model.norm)
        self.count=self.model.count
        active=int(self.terminal["dimensions"][1])
        first=int(self.terminal["dimensions"][3])
        old=self.data["normalized"][:,:active]*self.terminal["state_units"]
        change=self.data["normalized"][:,active:2*active]*self.terminal["delta_units"]
        native=old+(change if branch else 0.)
        self.perturbation=native[:,first:first+2*self.count].reshape(len(self.times),self.count,2)
        packet=self.data["metric"][:,branch]
        self.metric=field(packet,"z")
        self.values=background_values(self.times,self.data["background"],branch,self.background,self.model)
        acceleration=(-2*self.values["hubble"][:,None]*self.perturbation[...,1]-
                      (CONFIG["retained_comoving_wave"]**2+self.values["mass"])*self.perturbation[...,0]-
                      CONFIG["retained_comoving_wave"]*self.values["velocity"]*self.metric[:,None])
        perturbation_derivative=np.stack((self.perturbation[...,1],acceleration),axis=-1)
        self.vector=np.concatenate((self.values["state"],self.perturbation.reshape(len(self.times),-1),self.metric[:,None]),axis=1)
        self.derivative=np.concatenate((self.values["derivative"],perturbation_derivative.reshape(len(self.times),-1),
                                        field(packet,"z_prime")[:,None]),axis=1)
        beta=self.values["scale"]/float(self.prepared["density0"])
        self.boundary,self.node_terms,self.primitive=expressions(self.values,self.perturbation,self.metric,beta)
        material=packet[:,:84].reshape(len(self.times),7,12)
        expected=material[:,5:5+self.count][:,:,[3,4,5]]*beta[:,None,None]
        norms=np.asarray(read(ROOT / "frozen-norms.json")[case]["scalar_source_norms"])
        self.checks={}
        for component,name in enumerate(("density","current","pressure")):
            for scalar in range(self.count):
                self.checks["scalar"+str(scalar)+"_"+name+"_native_parity"]=ratio(
                    maximum(self.primitive[:,scalar,component]-expected[:,scalar,component]),norms[scalar,component],CONFIG["algebra_tolerance"])
        self.checks["hubble_native_parity"]=ratio(maximum(self.values["hubble"]-field(packet,"hubble")),
                                                  maximum(self.values["hubble"]),CONFIG["algebra_tolerance"])
        if branch==0:
            expected_hubble_prime=self.background.evaluate(self.times)["hubble_prime"]
            self.checks["hubble_chain_rule"]=ratio(maximum(self.values["hubble_prime"]-expected_hubble_prime),
                                                    maximum(expected_hubble_prime),CONFIG["algebra_tolerance"])
        for endpoint,state in ((0,load(PHASE / (case+"-live-64-terminal.npz"))),(-1,self.terminal)):
            native_rhs=state["normalized_rhs"][:active]*state["state_units"]
            if branch:
                native_rhs=native_rhs+state["normalized_rhs"][active:2*active]*state["delta_units"]
            expected_rhs=native_rhs[first:first+2*self.count]
            actual_rhs=perturbation_derivative[endpoint].ravel()
            self.checks["endpoint"+str(endpoint)+"_field_rhs"]=ratio(maximum(actual_rhs-expected_rhs),
                maximum(abs(actual_rhs)+abs(expected_rhs)),CONFIG["algebra_tolerance"])

    def integrate(self,stride,order):
        guard()
        indices=np.unique(np.concatenate((np.arange(0,len(self.times),stride),[len(self.times)-1])))
        interpolation=CubicHermiteSpline(self.times[indices],self.vector[indices],self.derivative[indices],axis=0)
        nodes,weights=np.polynomial.legendre.leggauss(order)
        left,right=self.times[:-1],self.times[1:]
        queries=(left[:,None]+right[:,None]+(right-left)[:,None]*nodes)/2
        quadrature_weights=(right-left)[:,None]*weights/2
        flat=queries.ravel()
        vector=interpolation(flat)
        values=background_values(flat,vector[:,:self.width],self.branch,self.background,self.model)
        perturbation=vector[:,self.width:self.width+2*self.count].reshape(len(flat),self.count,2)
        _,terms,_=expressions(values,perturbation,vector[:,-1],values["scale"]/float(self.prepared["density0"]))
        cells=np.sum(quadrature_weights[:,:,None,None]*terms.reshape(len(left),order,self.count,len(TERM_NAMES)),axis=1)
        absolute_cells=np.sum(quadrature_weights[:,:,None,None]*abs(terms).reshape(len(left),order,self.count,len(TERM_NAMES)),axis=1)
        cumulative=np.concatenate((np.zeros((1,self.count,len(TERM_NAMES))),np.cumsum(cells,axis=0)))
        absolute=np.concatenate((np.zeros((1,self.count,len(TERM_NAMES))),np.cumsum(absolute_cells,axis=0)))
        components=np.concatenate(((self.boundary-self.boundary[0])[...,None],cumulative[...,1:5]),axis=-1)
        require(np.isfinite(components).all() and np.isfinite(cumulative).all(),"finite pressure quadrature")
        return dict(time=self.times,cumulative=cumulative,absolute=absolute,components=components,
                    boundary=self.boundary,nodes_used=np.array(len(indices)),order=np.array(order),stride=np.array(stride))
