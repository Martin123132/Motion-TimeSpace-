from restart_bridge import *
PRESSURE = Path(CONFIG['pressure_directory'])
sys.path.insert(0, str(PRESSURE))
from pressure_math import Profile, background_values
from scipy.interpolate import CubicHermiteSpline

TERM_NAMES = ('direct_pressure','leading','virial','free_control','expansion','metric','contacts','weighted_density')
COMPONENT_NAMES = ('virial','boundary','expansion','metric','contacts')


def terms(values, perturbation, metric, rho0):
    scalar = 1
    phi, velocity = values['phi'][:,scalar], values['velocity'][:,scalar]
    displacement, speed = perturbation[:,scalar,0], perturbation[:,scalar,1]
    hubble, rate, hubble_prime = values['hubble'], values['rate'], values['hubble_prime']
    mass2, beta = values['mass'][:,scalar], values['scale']/rho0
    wave = CONFIG['retained_comoving_wave']
    density = velocity*speed + mass2*phi*displacement
    pressure = velocity*speed - mass2*phi*displacement
    current = velocity*displacement + phi*speed
    leading = wave**2/(4*mass2)
    virial = leading/(1+leading)
    complement = 1/(1+leading)
    free = wave**2/(np.sqrt(mass2+wave**2)+np.sqrt(mass2))**2
    complement_prime = 2*rate*complement*virial
    boundary = hubble*beta*complement*current/2
    all_terms = np.column_stack((hubble*beta*pressure, hubble*beta*leading*density, hubble*beta*virial*density,
        hubble*beta*free*density, beta*(complement*(2*hubble**2-hubble_prime-hubble*rate)-hubble*complement_prime)*current/2,
        beta*hubble*complement*wave*phi*velocity*metric/2,
        -beta*hubble*complement*(values['velocity_defect'][:,scalar]*displacement+values['field_defect'][:,scalar]*speed)/2,
        hubble*beta*density))
    diagnostics = np.column_stack((hubble/np.sqrt(mass2), wave/np.sqrt(mass2), leading, virial, free,
                                  phi,velocity,displacement,speed,current,beta*density,beta*pressure))
    return boundary, all_terms, diagnostics


class Window:
    def __init__(self, profile, stride):
        self.profile = profile
        indices = np.unique(np.r_[np.arange(0,len(profile.times),stride), len(profile.times)-1])
        self.interpolation = CubicHermiteSpline(profile.times[indices], profile.vector[indices], profile.derivative[indices], axis=0, extrapolate=False)
        self.indices = indices
        work = profile.data['work'][:,0] + (profile.data['work_change'][:,0] if profile.branch else 0)
        reference = -(work-work[0])/3
        self.reference = CubicHermiteSpline(profile.times[indices],reference[indices],profile.node_terms[indices,1,0],extrapolate=False)

    def evaluate(self, queries):
        profile = self.profile
        vector = self.interpolation(queries)
        values = background_values(queries,vector[:,:profile.width],profile.branch,profile.background,profile.model)
        perturbation = vector[:,profile.width:profile.width+2*profile.count].reshape(len(queries),profile.count,2)
        return terms(values,perturbation,vector[:,-1],float(profile.prepared['density0']))

    def integrate(self, begin, finish, order):
        guard()
        times = self.profile.times
        require(times[0] <= begin < finish <= times[-1], 'window within saved support')
        grid = np.r_[begin,times[(times>begin)&(times<finish)],finish]
        nodes,weights = np.polynomial.legendre.leggauss(order)
        half = np.diff(grid)/2
        queries = grid[:-1,None] + half[:,None]*(nodes+1)
        weights = half[:,None]*weights
        _,integrands,_ = self.evaluate(queries.ravel())
        integrands = integrands.reshape(len(half),order,len(TERM_NAMES))
        cells = np.sum(weights[:,:,None]*integrands,axis=1)
        absolute_cells = np.sum(weights[:,:,None]*abs(integrands),axis=1)
        cumulative = np.vstack((np.zeros(len(TERM_NAMES)),np.cumsum(cells,axis=0)))
        absolute = np.vstack((np.zeros(len(TERM_NAMES)),np.cumsum(absolute_cells,axis=0)))
        boundary,node_terms,diagnostics = self.evaluate(grid)
        components = np.column_stack((cumulative[:,2], boundary-boundary[0],cumulative[:,4:7]))
        reference = self.reference(grid)-self.reference(begin)
        require(np.isfinite(components).all() and np.isfinite(reference).all(), 'finite window outputs')
        return dict(time=grid,cumulative=cumulative,absolute=absolute,boundary=boundary,components=components,
                    reference=reference,node_terms=node_terms,diagnostics=diagnostics)


def history(steps, branch, window, stride=1, order=5):
    return load(ROOT/(str(steps)+'-'+branch+'-'+window+'-stride'+str(stride)+'-order'+str(order)+'.npz'))
