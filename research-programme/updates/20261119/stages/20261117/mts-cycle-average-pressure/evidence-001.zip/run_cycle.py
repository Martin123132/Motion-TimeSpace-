from cycle_math import *
import argparse


def run(steps):
    inputs()
    frozen = read(ROOT/'window-frozen.json')
    output = {}
    for branch,name in enumerate(('old','coherent')):
        profile = Profile('heavy',steps,branch)
        require(all(item['passed'] for item in profile.checks.values()), 'retained primitive and field equation checks')
        for stride in CONFIG['strides']:
            interpolation = Window(profile,stride)
            for window,endpoints in frozen['windows'].items():
                for order in CONFIG['quadrature_orders']:
                    value = interpolation.integrate(*endpoints,order)
                    path = ROOT/(str(steps)+'-'+name+'-'+window+'-stride'+str(stride)+'-order'+str(order)+'.npz')
                    require(not path.exists(),'new immutable quadrature')
                    np.savez_compressed(path,**value)
        if steps == 64:
            interpolation = Window(profile,1)
            variants = {}
            standard = frozen['windows']['cycles']
            for label,variant in frozen['variants'].items():
                endpoints = [variant['roots'][0],variant['roots'][-1]]
                value = interpolation.integrate(*endpoints,5)
                shifted = {}
                for position in (0,1):
                    left,right = sorted((standard[position],endpoints[position]))
                    if left < right:
                        segment = interpolation.integrate(left,right,5)
                        shifted[str(position)] = {'components_l1':float(np.sum(abs(segment['components'][-1]))),
                            'reference':abs(float(segment['reference'][-1])),
                            'prediction_l1':abs(segment['cumulative'][-1,:4]).tolist()}
                    else:
                        shifted[str(position)] = {'components_l1':0.,'reference':0.,'prediction_l1':[0.,0.,0.,0.]}
                variants[label] = {'endpoints':endpoints,'components':value['components'][-1].tolist(),
                    'reference':float(value['reference'][-1]),'cumulative':value['cumulative'][-1].tolist(), 'endpoint_shift':shifted}
            write(ROOT/(name+'-root-variants.json'),variants)
        output[name] = profile.checks
    for case in CONFIG['cases']:
        baseline = Profile(case,steps,0)
        coherent = Profile(case,steps,1)
        require(all(item['passed'] for profile in (baseline,coherent) for item in profile.checks.values()),'shared baseline/MTS native checks')
        if case == 'cold':
            require(bool(np.all(baseline.data['source'][:,2]==0) and np.all(baseline.data['source_change'][:,2]==0)), 'cold owned pressure structural zero')
        output[case+'_shared_checks'] = {'old':baseline.checks,'coherent':coherent.checks}
    write(ROOT/('run-'+str(steps)+'-result.json'),output)
    inputs()
    print(json.dumps({'steps':steps,'saved':True,'native_evolution_started':False}),flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],required=True)
    arguments = parser.parse_args()
    with worker('run-'+str(arguments.steps)):
        run(arguments.steps)
