from cycle_math import *


def calculate():
    reports = {}
    norm = read(ROOT/'frozen-norms.json')['heavy']['scalar_source_norms'][1][0]
    for branch in ('old','coherent'):
        reports[branch] = {}
        root_variants = read(ROOT/(branch+'-root-variants.json'))
        for window in ('full','cycles'):
            fine = history(64,branch,window)
            order3 = history(64,branch,window,order=3)
            stride2 = history(64,branch,window,stride=2)
            stride4 = history(64,branch,window,stride=4)
            steps32 = history(32,branch,window)
            def components_difference(first,second):
                require(np.array_equal(first['time'],second['time']), 'identical fixed query clocks')
                return maximum(np.sum(abs(first['components']-second['components']),axis=1)+abs(first['reference']-second['reference']))
            quadrature = components_difference(fine,order3)
            sampling12 = components_difference(fine,stride2)
            sampling24 = components_difference(stride2,stride4)
            sampling = max(sampling12,sampling24)
            paired_steps = components_difference(fine,steps32)
            root_allowance = max(sum(value['components_l1']+value['reference'] for value in variant['endpoint_shift'].values()) for variant in root_variants.values()) if window=='cycles' else 0.
            rounding = 128*np.finfo(float).eps*maximum(abs(fine['boundary'])+abs(fine['boundary'][0])+
                       np.sum(fine['absolute'][:,[2,4,5,6]],axis=1)+abs(fine['reference']))
            residual = np.sum(fine['components'],axis=1)-fine['reference']
            allowance = quadrature+sampling+paired_steps+root_allowance+rounding
            budget = ratio(maximum(residual)+allowance,norm)
            budget.update(residual=maximum(residual),quadrature=quadrature,sampling=sampling,paired_steps=paired_steps,
                          root_variation=root_allowance,rounding=rounding,working_estimate_not_rigorous_bound=True)
            closures = {}
            for label,column in (('zero',None),('leading',1),('virial',2),('free_control',3),('direct_crosscheck',0)):
                def prediction(value):
                    return np.zeros(len(value['time'])) if column is None else value['cumulative'][:,column]
                predicted = prediction(fine)
                def closure_difference(first,second):
                    return abs(prediction(first)-prediction(second))+abs(first['reference']-second['reference'])
                closure_quad = closure_difference(fine,order3)
                closure_sample = np.maximum(closure_difference(fine,stride2),closure_difference(stride2,stride4))
                closure_steps = closure_difference(fine,steps32)
                closure_root = max(sum(value['reference']+(value['prediction_l1'][column] if column is not None else 0.)
                    for value in variant['endpoint_shift'].values()) for variant in root_variants.values()) if window=='cycles' else 0.
                total_error = abs(predicted-fine['reference'])+closure_quad+closure_sample+closure_steps+closure_root+rounding
                final = ratio(float(total_error[-1]),norm)
                prefix = ratio(maximum(total_error),norm)
                final.update(prediction=float(predicted[-1]),reference=float(fine['reference'][-1]),
                    signed_residual=float(predicted[-1]-fine['reference'][-1]),quadrature=float(closure_quad[-1]),
                    sampling=float(closure_sample[-1]),paired_steps=float(closure_steps[-1]),root_variation=closure_root)
                closures[label] = {'final_complete_window':final,'all_prefixes':prefix}
            terms_report = {name:float(fine['components'][-1,index]) for index,name in enumerate(COMPONENT_NAMES)}
            density_weight = float(fine['absolute'][-1,7])
            endpoint_fields = {name:[float(fine['diagnostics'][0,index]),float(fine['diagnostics'][-1,index])]
                for index,name in enumerate(('H_over_am','k_over_am','leading','virial','free_control','Phi','V','f','g','J','beta_D','beta_P'))}
            omitted = {name:ratio(maximum(residual-fine['components'][:,index])+allowance,norm)
                for index,name in enumerate(COMPONENT_NAMES)}
            reports[branch][window] = {'identity':budget,'closures':closures,'final_terms':terms_report,
                'final_reference':float(fine['reference'][-1]),'final_rhs':float(np.sum(fine['components'][-1])),
                'omitted_term_identity_budgets':omitted,'sampling_differences':[sampling12,sampling24],
                'sampling_shrinks':bool(sampling12<=sampling24+rounding),'norm':norm,
                'absolute_density_weight':density_weight,'pressure_over_absolute_density_weight':float(fine['reference'][-1]/density_weight),
                'remainder_over_absolute_density_weight':float(np.sum(fine['components'][-1,1:])/density_weight),
                'boundary_endpoint_values':fine['boundary'][[0,-1]].tolist(),'endpoint_diagnostics':endpoint_fields}
    prior = read(PRESSURE/'science-score.json')
    result = {'reports':reports,'heavy_identity_all_windows_pass':all(value['identity']['passed'] for branch in reports.values() for value in branch.values()),
        'cold_owned_pressure_structural_zero':prior['cases']['cold']['owned_cold_pressure_structural_zero'],
        'slow_self_normalized_failures_preserved':all(not prior['cases'][case][branch+'_slow']['identity_budget']['passed'] for case in CONFIG['cases'] for branch in ('old','coherent')),
        'slow_stress_bounds_inherited_within_original_support_only':str(PRESSURE/'slow-stress-outward-bound.json'),
        'window_frozen_sha256':digest(ROOT/'window-frozen.json'),'no_fit':True,
        'scope':'Fixed finite-window scalar perturbation weighted pressure, not a universal or gauge-independent sound speed.'}
    return result


if __name__ == '__main__':
    with worker('score'):
        inputs()
        result = calculate()
        write(ROOT/'science-score.json',result)
        print(json.dumps(result),flush=True)
