from restart_support import *
import importlib.metadata


if __name__ == '__main__':
    check_inputs(read(ROOT/'inputs.json'))
    check_inputs(read(ROOT/'matching-plan.json')['files'])
    verification = read(ROOT/'verification.json')
    matching = read(ROOT/'matching-verification.json')
    science = read(ROOT/'science-score.json')
    require(verification['passed'] and matching['passed'], 'technical and exact-replay checks')
    require(science['heavy_identity_all_windows_pass'], 'checked phase-aware pressure identity')
    workers = {path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    require(all(value['exited'] for value in workers.values()), 'all exact task worker identities exited')
    require(not list(ROOT.glob('*-failure.json')), 'no failed worker omitted')
    require(not (ROOT/'__pycache__').exists(), 'no bytecode')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    write(ROOT/'cleanup.json',{'workers':workers,'all_exited':True,'native_owners_started':0,
        'temporary_tools':[],'other_processes_changed':False,'python':sys.version,
        'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','sympy','psutil')}})
    artifacts = {str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size}
                 for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    result = {'stage':'Frozen complete-cycle pressure and matched auxiliary density','utc':datetime.now(timezone.utc).isoformat(),
        'completed':True,'verification_passed':True,'main_checks':verification['count'],'matching_checks':matching['count'],
        'complete_cycles':read(ROOT/'window-frozen.json')['complete_cycles'],'heavy_identity_all_windows_pass':True,
        'approximate_closures_pass':False,'slow_self_normalized_failures_preserved':True,
        'initial_match_identity_derived':True,'new_transformed_evolution_performed':False,
        'frozen_inputs':len(read(ROOT/'inputs.json')),'workers_exited':len(workers),'new_native_evolution':False,
        'github':False,'artifacts':artifacts}
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),'bytes':sum(value['bytes'] for value in artifacts.values()),
        'workers_exited':len(workers),'checks':verification['count']+matching['count'],'closer':identity(psutil.Process())}),flush=True)
