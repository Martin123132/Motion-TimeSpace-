from cycle_math import *
from score_cycle import calculate
from prepare_cycle import roots, algebra


def verify():
    inputs()
    science = read(ROOT/'science-score.json')
    frozen = read(ROOT/'window-frozen.json')
    checks = {}
    def record(name, condition):
        checks[name] = bool(condition)
        require(checks[name],name)
    record('exact_score_replay',calculate()==science)
    record('algebra_replay',algebra()==frozen['algebra_controls'])
    for label,value in frozen['variants'].items():
        record('phase_root_replay_'+label,roots(value['steps'],value['stride'])==value)
    record('positive_complete_cycles',frozen['complete_cycles']>=1)
    record('independent_pressure_free_phase_selection',frozen['no_perturbation_or_pressure_used_in_selection'])
    record('primitive_checks_before_pressure',datetime.fromisoformat(frozen['utc']) < datetime.fromisoformat(read(ROOT/'run-32-start.json')['utc']))
    for steps in CONFIG['steps']:
        result = read(ROOT/('run-'+str(steps)+'-result.json'))
        for branch in ('old','coherent'):
            for name,item in result[branch].items():
                record(str(steps)+'_'+branch+'_'+name,item['passed'])
        for case in CONFIG['cases']:
            for branch,items in result[case+'_shared_checks'].items():
                for name,item in items.items():
                    record(str(steps)+'_'+case+'_'+branch+'_'+name,item['passed'])
    for branch in ('old','coherent'):
        for window,report in science['reports'][branch].items():
            record(branch+'_'+window+'_identity',report['identity']['passed'])
            record(branch+'_'+window+'_direct_pressure_crosscheck',report['closures']['direct_crosscheck']['all_prefixes']['passed'])
            record(branch+'_'+window+'_fixed_norm',report['norm']==read(ROOT/'frozen-norms.json')['heavy']['scalar_source_norms'][1][0])
            fine = history(64,branch,window)
            record(branch+'_'+window+'_frozen_endpoints',fine['time'][[0,-1]].tolist()==frozen['windows'][window])
            record(branch+'_'+window+'_positive_times',np.all(np.diff(fine['time'])>0))
            for steps in CONFIG['steps']:
                for stride in CONFIG['strides']:
                    for order in CONFIG['quadrature_orders']:
                        current = history(steps,branch,window,stride,order)
                        record(str(steps)+'_'+branch+'_'+window+'_'+str(stride)+'_'+str(order)+'_finite',all(np.isfinite(value).all() for value in current.values()))
    record('cold_owned_structural_zero',science['cold_owned_pressure_structural_zero'])
    record('all_four_slow_failures_preserved',science['slow_self_normalized_failures_preserved'])
    record('same_unchanged_norms',read(ROOT/'frozen-norms.json')==read(PRESSURE/'frozen-norms.json'))
    record('no_bytecode',not (ROOT/'__pycache__').exists())
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    result = {'checks':checks,'count':len(checks),'passed':all(checks.values()),
              'scope':'technical and exact-identity verification; approximate closure outcomes remain in science-score.json'}
    write(ROOT/'verification.json',result)
    print(json.dumps({'checks':len(checks),'passed':True}),flush=True)


if __name__ == '__main__':
    with worker('verify'):
        verify()
