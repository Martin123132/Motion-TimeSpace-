from restart_support import *
from scipy.interpolate import CubicHermiteSpline
import sympy as symbolic


def roots(steps, stride):
    path = Path(CONFIG['gap_directory']) / ('heavy-live-' + str(steps) + '.npz')
    with np.load(path, allow_pickle=False) as archive:
        times = archive['time']
        background = archive['background']
    indices = np.unique(np.r_[np.arange(0, len(times), stride), len(times)-1])
    spline = CubicHermiteSpline(times[indices], background[indices, 3], background[indices, 4], extrapolate=False)
    zeros = spline.roots(extrapolate=False)
    zeros = zeros[np.isfinite(zeros) & (zeros > times[0]) & (zeros < times[-1])]
    zeros = zeros[spline(zeros, 1) > 0]
    require(len(zeros) >= 2 and np.all(np.diff(zeros) > 0), 'ordered positive-going background crossings')
    return {'steps': steps, 'stride': stride, 'roots': zeros.tolist(), 'source': str(path),
            'source_sha256': digest(path), 'slopes': spline(zeros, 1).tolist(),
            'support': [float(times[0]), float(times[-1])]}


def algebra():
    phi, velocity, displacement, speed, mass2, wave, hubble, metric, field_contact, velocity_contact = symbolic.symbols(
        'phi velocity displacement speed mass2 wave hubble metric field_contact velocity_contact', real=True)
    density = velocity*speed + mass2*phi*displacement
    pressure = velocity*speed - mass2*phi*displacement
    current = velocity*displacement + phi*speed
    current_prime = (-2*hubble*velocity-mass2*phi+velocity_contact)*displacement + velocity*speed + (
        velocity+field_contact)*speed + phi*(-2*hubble*speed-(wave**2+mass2)*displacement-wave*velocity*metric)
    coefficient = wave**2/(4*mass2+wave**2)
    complement = 1-coefficient
    exact = coefficient*density+complement*(current_prime+2*hubble*current+wave*phi*velocity*metric-
                                          velocity_contact*displacement-field_contact*speed)/2
    rate, beta, hubble_prime, current_symbol, current_derivative = symbolic.symbols('rate beta hubble_prime current current_derivative')
    complement_prime = symbolic.diff(complement, mass2)*2*rate*mass2
    endpoint_prime = beta*(hubble_prime*complement*current_symbol + hubble*rate*complement*current_symbol +
                           hubble*complement_prime*current_symbol+hubble*complement*current_derivative)/2
    integrated = endpoint_prime + beta*(complement*(2*hubble**2-hubble_prime-hubble*rate)-hubble*complement_prime)*current_symbol/2
    mu, omega, amplitude, perturb_amplitude, difference_cos, sum_cos = symbolic.symbols('mu omega amplitude perturb_amplitude difference_cos sum_cos', positive=True)
    free_density = amplitude*perturb_amplitude*mu*((omega+mu)*difference_cos+(mu-omega)*sum_cos)/2
    free_pressure = amplitude*perturb_amplitude*mu*((omega-mu)*difference_cos-(omega+mu)*sum_cos)/2
    free_coefficient = (omega-mu)/(omega+mu)
    gradient = symbolic.symbols('gradient', positive=True)
    free_series = (symbolic.sqrt(1+4*gradient)-1)/(symbolic.sqrt(1+4*gradient)+1)
    checks = {
        'exact_resummed_field_identity': symbolic.simplify(exact-pressure) == 0,
        'coefficient_derivative': symbolic.simplify(complement_prime-2*rate*complement*coefficient) == 0,
        'integration_by_parts': symbolic.simplify(integrated-beta*hubble*complement*(current_derivative+2*hubble*current_symbol)/2) == 0,
        'free_fast_remainder': symbolic.simplify(free_pressure-free_coefficient*free_density+
            2*amplitude*perturb_amplitude*mu**2*omega/(omega+mu)*sum_cos) == 0,
        'free_gradient_form': symbolic.simplify((free_coefficient-wave**2/(omega+mu)**2).subs(wave**2,omega**2-mu**2)) == 0,
        'virial_series': symbolic.series(gradient/(1+gradient),gradient,0,3).removeO() == gradient-gradient**2,
        'free_series': symbolic.series(free_series,gradient,0,3).removeO() == gradient-2*gradient**2,
        'nonzero_boundary_not_identity': symbolic.simplify(exact-pressure-complement*current_prime/2) != 0,
    }
    require(all(checks.values()), 'independent algebra controls')
    return {name: bool(value) for name, value in checks.items()}


def prepare():
    pressure = Path(CONFIG['pressure_directory'])
    require(digest(pressure/'closeout.json') == CONFIG['pressure_seal'], 'accepted pressure seal')
    mapping = read(pressure/'inputs.json')
    mapping[str(pressure/'closeout.json')] = CONFIG['pressure_seal']
    for name, entry in read(pressure/'closeout.json')['artifacts'].items():
        mapping[str(pressure/name)] = entry['sha256']
    check_inputs(mapping)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'), str(path), 'exec')
    variants = {str(steps)+'-stride'+str(stride): roots(steps,stride) for steps in CONFIG['steps'] for stride in CONFIG['strides']}
    reference = variants['64-stride1']
    require(all(len(item['roots']) == len(reference['roots']) for item in variants.values()), 'same background crossing topology')
    endpoints = [reference['roots'][0], reference['roots'][-1]]
    cold = load(Path(CONFIG['gap_directory'])/'cold-live-64.npz')['time']
    require(cold[0] <= endpoints[0] < endpoints[1] <= cold[-1], 'common baseline/MTS supported interval')
    frozen = {'utc': datetime.now(timezone.utc).isoformat(), 'selection': 'first/last positive-going homogeneous heavy zero; no pressure inspection',
              'windows': {'cycles': endpoints, 'full': reference['support']}, 'complete_cycles': len(reference['roots'])-1,
              'variants': variants, 'maximum_endpoint_spread': [max(abs(item['roots'][position]-reference['roots'][position]) for item in variants.values()) for position in (0,-1)],
              'root_spread_scope': 'working representation/step comparison, not a rigorous ODE root enclosure',
              'baseline_support': [float(cold[0]),float(cold[-1])], 'algebra_controls': algebra(),
              'no_perturbation_or_pressure_used_in_selection': True}
    write(ROOT/'window-frozen.json', frozen)
    write(ROOT/'frozen-norms.json', read(pressure/'frozen-norms.json'))
    for path in sorted(ROOT.iterdir()):
        if path.suffix in ('.py','.json','.md') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            mapping[str(path)] = digest(path)
    write(ROOT/'inputs.json', mapping)
    check_inputs(mapping)
    print(json.dumps({'windows': frozen['windows'], 'complete_cycles': frozen['complete_cycles'],
          'root_spread': frozen['maximum_endpoint_spread'], 'frozen_inputs': len(mapping), 'algebra': frozen['algebra_controls']}),flush=True)


if __name__ == '__main__':
    with worker('prepare'):
        prepare()
