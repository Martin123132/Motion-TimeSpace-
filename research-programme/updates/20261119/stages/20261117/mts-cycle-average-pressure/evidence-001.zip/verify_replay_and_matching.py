from cycle_math import *
import sympy as symbolic


def matching_controls():
    phi, velocity, displacement, speed, mass2, wave, hubble, metric, field_contact, velocity_contact, rate, beta = symbolic.symbols(
        'phi velocity displacement speed mass2 wave hubble metric field_contact velocity_contact rate beta')
    density = velocity*speed+mass2*phi*displacement
    pressure = velocity*speed-mass2*phi*displacement
    current = wave*velocity*displacement
    density_prime = (-2*hubble*velocity-mass2*phi+velocity_contact)*speed + velocity*(
        -2*hubble*speed-(wave**2+mass2)*displacement-wave*velocity*metric) + 2*rate*mass2*phi*displacement + mass2*(
        velocity+field_contact)*displacement+mass2*phi*speed
    expected = 2*(rate-hubble)*beta*density-(2*hubble+rate)*beta*pressure-wave*beta*current-wave*beta*velocity**2*metric + beta*(
        velocity_contact*speed+mass2*field_contact*displacement)
    checks = {'raw_density_exchange':symbolic.simplify(beta*(density_prime+rate*density)-expected)==0}
    dressed, boundary_prime, expansion, forcing, contact, coefficient = symbolic.symbols('dressed boundary_prime expansion forcing contact coefficient')
    work = hubble*coefficient*beta*density+boundary_prime+expansion+forcing+contact
    transformed = -3*work + (rate-hubble)*(2*beta*density-beta*pressure)-wave*beta*current-wave*beta*velocity**2*metric + beta*(
        velocity_contact*speed+mass2*field_contact*displacement)+3*boundary_prime
    predicted = -3*hubble*coefficient*beta*density-3*(expansion+forcing+contact)+(rate-hubble)*(2*beta*density-beta*pressure)-wave*beta*current-wave*beta*velocity**2*metric+beta*(
        velocity_contact*speed+mass2*field_contact*displacement)
    checks['matched_auxiliary_equation'] = symbolic.simplify(transformed-predicted)==0
    checks['coherent_density_equation'] = symbolic.simplify((expected+3*hubble*beta*pressure+wave*beta*current+wave*beta*velocity**2*metric).subs({rate:hubble,field_contact:0,velocity_contact:0}))==0
    initial_boundary, final_boundary, initial_density, final_density = symbolic.symbols('initial_boundary final_boundary initial_density final_density')
    reconstructed_change = (final_density+3*final_boundary)-(initial_density+3*initial_boundary)-3*(final_boundary-initial_boundary)
    checks['exact_initial_final_matching'] = symbolic.simplify(reconstructed_change-(final_density-initial_density))==0
    checks['omitting_initial_match_is_not_identity'] = symbolic.simplify(reconstructed_change+3*initial_boundary-(final_density-initial_density))!=0
    return {name:bool(value) for name,value in checks.items()}


def verify():
    inputs()
    supplemental = {str(ROOT/name):digest(ROOT/name) for name in ('MATCHED-DENSITY.md','verify_replay_and_matching.py')}
    write(ROOT/'matching-plan.json',{'utc':datetime.now(timezone.utc).isoformat(),'files':supplemental,
        'scope':'exact change of variable and saved quadrature replay, no new fitted closure or evolution'})
    checks = matching_controls()
    frozen = read(ROOT/'window-frozen.json')
    for branch,name in enumerate(('old','coherent')):
        profile = Profile('heavy',64,branch)
        for stride,order in ((1,5),(4,3)):
            reconstruction = Window(profile,stride)
            for window,endpoints in frozen['windows'].items():
                actual = reconstruction.integrate(*endpoints,order)
                expected = history(64,name,window,stride,order)
                for key in expected:
                    checks[name+'_'+window+'_'+str(stride)+'_'+str(order)+'_'+key+'_replay'] = bool(np.array_equal(expected[key],actual[key]))
    for index,(mu,wave,duration,phase) in enumerate(((1.,.2,3.,.1),(2.,1.,10.,2.),(.5,3.,.7,-1.),(3.,0.,4.,.2))):
        omega = np.sqrt(mu**2+wave**2)
        amplitude = -2*mu**2*omega/(omega+mu)
        exact_mean = amplitude*(np.sin((omega+mu)*duration+phase)-np.sin(phase))/((omega+mu)*duration)
        bound = 4*mu**2*omega/((omega+mu)**2*duration)
        checks['free_finite_interval_bound_'+str(index)] = bool(abs(exact_mean)<=bound*(1+CONFIG['algebra_tolerance']))
        checks['free_coefficient_rewrite_'+str(index)] = bool(abs((omega-mu)/(omega+mu)-wave**2/(omega+mu)**2)<CONFIG['algebra_tolerance'])
    require(all(checks.values()),'exact matching algebra and numerical replay')
    check_inputs(supplemental)
    inputs()
    write(ROOT/'matching-verification.json',{'checks':checks,'count':len(checks),'passed':True,
        'new_evolution':False,'new_closure_promoted':False})
    print(json.dumps({'checks':len(checks),'passed':True}),flush=True)


if __name__ == '__main__':
    with worker('matching-verify'):
        verify()
