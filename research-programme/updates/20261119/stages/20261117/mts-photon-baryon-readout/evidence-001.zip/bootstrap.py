from readout_math import *

with worker("bootstrap"):
    require(digest(PREVIOUS / "closeout.json") == CONFIG["previous_seal"], "previous sealed stage")
    previous = read(PREVIOUS / "closeout.json")
    mapping = {str(PREVIOUS / "closeout.json"): CONFIG["previous_seal"]}
    for name, item in previous["artifacts"].items():
        path = PREVIOUS / name
        require(path.is_file() and path.stat().st_size == item["bytes"], "sealed artifact available")
        mapping[str(path)] = item["sha256"]
    for case in CONFIG["cases"]:
        path = Path(CONFIG["preparation_directory"]) / (case+"-initial-state.npz")
        mapping[str(path)] = digest(path)
    path = Path(CONFIG["response_directory"]) / "preparation-result.json"
    mapping[str(path)] = digest(path)
    check_inputs(mapping)
    write(ROOT / "inputs.json",mapping)
    references = {}
    for case in CONFIG["cases"]:
        packet = load(PREVIOUS / (case+"-reference-metric.npz"))["packet"]
        values,magnitudes = readout(packet)
        actual,expected,terms = kinetic_checks(packet)
        norms = np.max(abs(values),axis=0)
        term_norms = np.max(magnitudes,axis=0)
        kinetic_norms = np.max(terms,axis=0)
        require(bool(np.all(norms>0)), "nonzero original readout scales")
        checks={name:ratio(maximum(actual[:,column]-expected[:,column]),kinetic_norms[column],CONFIG["algebra_tolerance"])
                for column,name in enumerate(KINETIC_NAMES)}
        require(all(item["passed"] for item in checks.values()), "retained species equation map")
        np.savez_compressed(ROOT/(case+"-frozen-reference.npz"),values=values,magnitudes=magnitudes,
            norms=norms,term_norms=term_norms,kinetic_norms=kinetic_norms)
        references[case]={"norms":dict(zip(NAMES,norms.tolist())),"checks":checks,
            "rows":len(values),"before_corrected_readout_test":True}
    write(ROOT / "frozen-reference.json",references)
    print(json.dumps({"frozen_paths":len(mapping),"reference_states_per_case":934,"cases":references}))

