from support import *
import sympy as sp
import importlib.util

with worker("proof"):
    source = PREVIOUS / "native/camb/symbolic.py"
    specification = importlib.util.spec_from_file_location("retained_camb_symbolic_readout", source)
    native = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(native)
    checks = {}
    targets = {
        "photon_frame": (native.Delta_g, native.Delta_g-4*native.H*native.sigma/native.k),
        "baryon_frame": (native.Delta_b, native.Delta_b-3*native.H*native.sigma/native.k),
        "baryon_velocity_frame": (native.v_b, native.v_b+native.sigma),
        "relative_density_frame": (native.Delta_b-3*native.Delta_g/4, native.Delta_b-3*native.Delta_g/4),
        "relative_velocity_frame": (native.v_b-3*native.q_g/4, native.v_b-3*native.q_g/4),
    }
    for name,(original,expected) in targets.items():
        transformed = native.make_frame_invariant(original, "Newtonian").subs(native.p_b,0)
        checks[name] = bool(sp.simplify(transformed-expected) == 0)
    wave, rate, hubble, sigma, sigma_prime, eta = sp.symbols("k r H sigma sigma_prime eta", nonzero=True)
    phi = eta/wave-rate*sigma/wave
    psi = (sigma_prime+rate*sigma)/wave
    checks["weyl_kinematic_cancellation"] = bool(sp.simplify((phi+psi)/2-(eta+sigma_prime)/(2*wave)) == 0)
    delta_b,delta_g,velocity_b,flux_g,pi_g,force,sound,opacity,baryon,photon = sp.symbols("db dg vb qg pig z cs2 opacity Bb Bg")
    drag = photon*opacity*(4*velocity_b/3-flux_g)
    delta_b_prime = -wave*(force+velocity_b)
    delta_g_prime = -wave*(4*force/3+flux_g)
    velocity_b_prime = -hubble*velocity_b+wave*sound*delta_b-drag/baryon
    flux_g_prime = wave*(delta_g-2*pi_g)/3+drag/photon
    slip = velocity_b-3*flux_g/4
    slip_rate = -hubble*velocity_b+wave*sound*delta_b-wave*delta_g/4+wave*pi_g/2-opacity*(1+4*photon/(3*baryon))*slip
    checks["relative_density_evolution"] = bool(sp.simplify(delta_b_prime-3*delta_g_prime/4+wave*slip) == 0)
    checks["derived_drag_rate"] = bool(sp.simplify(velocity_b_prime-3*flux_g_prime/4-slip_rate) == 0)
    numerator,denominator,delta_n,delta_d = sp.symbols("num den dnum dden")
    exact_ratio=(numerator+delta_n)/(denominator+delta_d)-numerator/denominator
    stable_ratio=(delta_n-(numerator/denominator)*delta_d)/(denominator+delta_d)
    checks["exact_quotient_response"] = bool(sp.simplify(exact_ratio-stable_ratio) == 0)
    alpha=sp.symbols("alpha")
    checks["background_temperature_response"] = bool(sp.simplify(1/(1+alpha)-1+alpha/(1+alpha)) == 0)
    checks["opacity_response"] = bool(sp.simplify(1/(1+alpha)**2-1+alpha*(2+alpha)/(1+alpha)**2) == 0)
    checks["metric_forcing_not_collision_injection"] = bool(sp.simplify(delta_b_prime-3*delta_g_prime/4).diff(force) == 0)
    result={"passed":all(checks.values()),"checks":checks,"native_symbolic_source":str(source),"native_symbolic_sha256":digest(source),
            "standard_gauge_map_not_new_mts_derivation":True,"pressureless_baryon_background_order":True}
    write(ROOT/"proof-result.json",result)
    require(result["passed"],"derived radiation/gas interface")
    print(json.dumps(result))

