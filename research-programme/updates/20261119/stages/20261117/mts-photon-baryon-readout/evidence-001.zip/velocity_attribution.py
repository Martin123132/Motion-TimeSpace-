from readout_math import *
from native_transfer import native_values, native_difference
import argparse

parser=argparse.ArgumentParser()
parser.add_argument("--replay",action="store_true")
args=parser.parse_args()
label="velocity-attribution-replay" if args.replay else "velocity-attribution"
with worker(label):
    if args.replay:
        inputs=read(ROOT/"velocity-attribution-inputs.json")
        check_inputs(inputs)
    else:
        inputs=freeze(label,("velocity_attribution.py","native_transfer.py","native-reference.json","native-transfer-result.json"))
    cases={}
    for case in CONFIG["cases"]:
        packet=load(PREVIOUS/(case+"-metric-64.npz"))["metric"]
        old,new=packet[:,:,0],packet[:,:,1]
        baryon_old,baryon_new=species(old)[...,1,:],species(new)[...,1,:]
        delta_vb=ratio_difference(baryon_old[...,4],baryon_new[...,4],baryon_old[...,0],baryon_new[...,0])
        delta_sigma=field(new,"sigma")-field(old,"sigma")
        delta_hubble=field(new,"hubble")-field(old,"hubble")
        old_native=native_values(old)[0][...,4]
        hubble=field(new,"hubble")
        terms=np.stack((-5*delta_vb/hubble,-5*delta_sigma/hubble,-old_native*delta_hubble/hubble),axis=-1)
        actual=native_difference(old,new)[...,4]
        norm=read(ROOT/"native-reference.json")[case]["norms"][4]
        identity=ratio(maximum(np.sum(terms,axis=-1)-actual),norm,CONFIG["algebra_tolerance"])
        worst=np.unravel_index(np.argmax(abs(actual)),actual.shape)
        cases[case]={"identity":identity,"term_names":["baryon_fluid_velocity","metric_shear","H_normalization"],
            "final_terms":terms[-1,-1].tolist(),"final_total":float(actual[-1,-1]),
            "maximum_change_location":list(map(int,worst)),"terms_at_maximum":terms[worst].tolist(),
            "total_at_maximum":float(actual[worst]),"component_maxima":np.max(abs(terms),axis=(0,1)).tolist(),
            "signed_components_not_probabilities":True}
        path=ROOT/(case+"-velocity-attribution.npz")
        if args.replay:
            saved=load(path)
            require(terms.tobytes()==saved["terms"].tobytes() and actual.tobytes()==saved["actual"].tobytes(),"exact attribution replay")
        else:
            require(not path.exists(),"new attribution output")
            np.savez_compressed(path,terms=terms,actual=actual)
    result={"cases":cases,"identities_passed":all(item["identity"]["passed"] for item in cases.values()),
        "formula":"Delta[-k(vb+sigma)/H] = -k Delta(vb)/Hnew - k Delta(sigma)/Hnew - Vold Delta(H)/Hnew",
        "derived_finite_difference_not_a_fit":True}
    check_inputs(inputs)
    if args.replay:
        require(result==read(ROOT/"velocity-attribution-result.json"),"exact attribution report")
        write(ROOT/"velocity-attribution-replay.json",{"exact":True})
    else:
        write(ROOT/"velocity-attribution-result.json",result)
    require(result["identities_passed"],"velocity source split")
    print(json.dumps(result))

