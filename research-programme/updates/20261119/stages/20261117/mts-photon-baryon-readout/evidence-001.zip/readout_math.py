from support import *
import math

SCHEMA = read(PREVIOUS / "packet-schema.json")
COLUMNS = {name: 84+index for index,name in enumerate(SCHEMA["global_columns"])}
NAMES = ("photon_delta_sync", "baryon_delta_sync", "photon_theta_N", "baryon_delta_N",
         "baryon_velocity_N", "entropy_b_gamma", "velocity_slip", "phi_N", "psi_N", "weyl",
         "baryon_pressure_fraction_sync")
KINETIC_NAMES = ("baryon_density", "photon_density", "relative_entropy", "velocity_slip")

def field(packet, name):
    return packet[..., COLUMNS[name]]

def species(packet):
    return packet[..., :84].reshape((*packet.shape[:-1], 7, 12))

def ingredients(packet):
    material = species(packet)
    baryon, photon = material[..., 1, :], material[..., 2, :]
    require(bool(np.all(baryon[...,0] > 0) and np.all(photon[...,0] > 0)), "positive inherited species normalizations")
    return baryon, photon, baryon[...,3]/baryon[...,0], photon[...,3]/photon[...,0], baryon[...,4]/baryon[...,0], photon[...,4]/photon[...,0]

def readout(packet):
    baryon, photon, delta_b, delta_g, velocity_b, flux_g = ingredients(packet)
    wave = CONFIG["retained_comoving_wave"]
    sigma, rate = field(packet,"sigma"), field(packet,"rate")
    clock = rate*sigma/wave
    curvature = field(packet,"eta_k")/wave
    acceleration = field(packet,"sigma_prime")/wave
    values = np.stack((delta_g, delta_b, delta_g/4-clock, delta_b-3*clock,
        velocity_b+sigma, delta_b-3*delta_g/4, velocity_b-3*flux_g/4,
        curvature-clock, acceleration+clock, (curvature+acceleration)/2,
        baryon[...,5]/baryon[...,0]), axis=-1)
    magnitudes = np.stack((abs(delta_g), abs(delta_b), abs(delta_g)/4+abs(clock), abs(delta_b)+3*abs(clock),
        abs(velocity_b)+abs(sigma), abs(delta_b)+3*abs(delta_g)/4, abs(velocity_b)+3*abs(flux_g)/4,
        abs(curvature)+abs(clock), abs(acceleration)+abs(clock), (abs(curvature)+abs(acceleration))/2,
        abs(baryon[...,5]/baryon[...,0])), axis=-1)
    return values, magnitudes

def ratio_difference(old_numerator, new_numerator, old_denominator, new_denominator):
    original = old_numerator/old_denominator
    return ((new_numerator-old_numerator)-original*(new_denominator-old_denominator))/new_denominator

def stable_difference(old, new):
    old_b, old_g, old_db, old_dg, old_vb, old_qg = ingredients(old)
    new_b, new_g, new_db, new_dg, new_vb, new_qg = ingredients(new)
    changes = []
    for component, column in ((1,3),(2,3),(1,4),(2,4),(1,5)):
        earlier = old_b if component == 1 else old_g
        later = new_b if component == 1 else new_g
        changes.append(ratio_difference(earlier[...,column],later[...,column],earlier[...,0],later[...,0]))
    delta_b, delta_g, velocity_b, flux_g, pressure_b = changes
    wave = CONFIG["retained_comoving_wave"]
    sigma = field(new,"sigma")-field(old,"sigma")
    rate = field(new,"rate")-field(old,"rate")
    clock = (rate*field(old,"sigma")+field(new,"rate")*sigma)/wave
    curvature = (field(new,"eta_k")-field(old,"eta_k"))/wave
    acceleration = (field(new,"sigma_prime")-field(old,"sigma_prime"))/wave
    return np.stack((delta_g,delta_b,delta_g/4-clock,delta_b-3*clock,velocity_b+sigma,
        delta_b-3*delta_g/4,velocity_b-3*flux_g/4,curvature-clock,acceleration+clock,
        (curvature+acceleration)/2,pressure_b),axis=-1)

def kinetic_checks(packet):
    baryon, photon, delta_b, delta_g, velocity_b, flux_g = ingredients(packet)
    rate, hubble, force = [field(packet,name) for name in ("rate","hubble","z")]
    wave = CONFIG["retained_comoving_wave"]
    delta_b_prime = (baryon[...,7]+rate*baryon[...,3])/baryon[...,0]
    delta_g_prime = (photon[...,7]+2*rate*photon[...,3])/photon[...,0]
    velocity_b_prime = (baryon[...,8]+rate*baryon[...,4])/baryon[...,0]
    flux_g_prime = (photon[...,8]+2*rate*photon[...,4])/photon[...,0]
    slip = velocity_b-3*flux_g/4
    drag_rate = field(packet,"opacity")*(1+4*photon[...,0]/(3*baryon[...,0]))
    thermal = wave*field(packet,"sound_speed_squared")*delta_b
    stress = wave*photon[...,6]/(2*photon[...,0])
    slip_force = -hubble*velocity_b+thermal-wave*delta_g/4+stress-drag_rate*slip
    actual = np.stack((delta_b_prime,delta_g_prime,delta_b_prime-3*delta_g_prime/4,velocity_b_prime-3*flux_g_prime/4),axis=-1)
    expected = np.stack((-wave*(force+velocity_b),-wave*(4*force/3+flux_g),-wave*slip,slip_force),axis=-1)
    terms = np.stack((abs(delta_b_prime)+wave*(abs(force)+abs(velocity_b)),
        abs(delta_g_prime)+wave*(4*abs(force)/3+abs(flux_g)),
        abs(delta_b_prime)+3*abs(delta_g_prime)/4+wave*(abs(velocity_b)+3*abs(flux_g)/4),
        abs(velocity_b_prime)+3*abs(flux_g_prime)/4+abs(hubble*velocity_b)+abs(thermal)+wave*abs(delta_g)/4+abs(stress)+abs(drag_rate*slip)),axis=-1)
    return actual,expected,terms

def projection(weights, values):
    return np.array([[math.fsum(float(weight)*float(value) for weight,value in zip(weights, row[:,column]))
                      for column in range(values.shape[-1])] for row in values])

def freeze(label, extra=()):
    mapping = read(ROOT / "inputs.json").copy()
    for name in ("support.py","protocol.json","readout_math.py",*extra):
        mapping[str(ROOT / name)] = digest(ROOT / name)
    check_inputs(mapping)
    write(ROOT / (label+"-inputs.json"),mapping)
    return mapping

