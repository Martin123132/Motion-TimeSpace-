from readout_math import *
import csv

guard()
process=psutil.Process()
process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
allowed=process.cpu_affinity()
process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
result=read(ROOT/"readout-result.json")
native=read(ROOT/"native-transfer-result.json")
checks={
    "previous_seal":digest(PREVIOUS/"closeout.json")==CONFIG["previous_seal"],
    "symbolic_mapping":read(ROOT/"proof-result.json")["passed"],
    "readout_and_refinement":result["readout_implementation_and_full_output_refinement_passed"],
    "actual_native_conventions":native["native_convention_checks_passed"],
    "attribution_identity":read(ROOT/"velocity-attribution-result.json")["identities_passed"],
    "readout_replay":all(read(ROOT/"readout-replay.json").values()),
    "native_replay":all(read(ROOT/"native-transfer-replay.json").values()),
    "attribution_replay":read(ROOT/"velocity-attribution-replay.json")["exact"],
    "failed_old_envelopes_preserved":not result["all_old_prediction_envelopes_preserved"],
    "unresolved_small_changes_preserved":not result["all_response_relative_tests_passed"],
    "no_collision_source_invented":result["new_collision_source"] is False,
    "no_new_evolution":result["new_evolution"] is False,
    "no_frequency_spectrum_invented":result["frequency_resolved_distortion_prediction_available"] is False,
    "no_gas_temperature_mode_invented":result["independent_gas_temperature_perturbation_available"] is False,
}
frozen={}
for name in ("inputs.json","readout-inputs.json","native-transfer-inputs.json","velocity-attribution-inputs.json"):
    mapping=read(ROOT/name)
    check_inputs(mapping)
    for path,expected in mapping.items():
        require(path not in frozen or frozen[path]==expected,"consistent input provenance")
        frozen[path]=expected
checks["all_frozen_paths_unchanged"]=True
with (ROOT/"readout-summary.csv").open(newline="",encoding="utf-8") as stream:
    rows=list(csv.DictReader(stream))
checks["csv_22_rows_valid"]=len(rows)==22 and all(None not in row and all(value is not None for value in row.values()) for row in rows)
for row in rows:
    for name in ("reference_norm","maximum_change","final_change","final_change_uncertainty"):
        require(math.isfinite(float(row[name])),"numeric CSV")
checks["csv_numeric_finite"]=True
for case in CONFIG["cases"]:
    reference=load(ROOT/(case+"-frozen-reference.npz"))
    original=load(PREVIOUS/(case+"-reference-metric.npz"))["packet"]
    values,magnitudes=readout(original)
    actual,expected,terms=kinetic_checks(original)
    reformed=dict(values=values,magnitudes=magnitudes,norms=np.max(abs(values),axis=0),
        term_norms=np.max(magnitudes,axis=0),kinetic_norms=np.max(terms,axis=0))
    checks[case+"_original_norms_bitwise_reproduced"]=all(value.tobytes()==reference[name].tobytes() for name,value in reformed.items())
    for name,item in native["cases"][case]["outputs"].items():
        checks[case+"_"+name+"_full_refinement"]=item["coherent_output_refinement"]["passed"] and item["change_uncertainty_on_original_scale"]["passed"]
    for name,item in native["cases"][case]["metric_bridge"].items():
        checks[case+"_"+name+"_coherent_metric_bridge"]=item["coherent_bridge_size_on_native_scale"]["passed"]
    checks[case+"_observer_provenance"]=all(item["passed"] for item in read(ROOT/"native-reference.json")[case]["observer_checks"].values())
checks["old_full_pressure_budget_preserved"]=result["old_source_pressure_budget"]==read(Path(CONFIG["response_directory"])/"preparation-result.json")["cases"]["heavy"]["components"]["pressure"]
for path in ROOT.glob("*.py"):
    compile(path.read_text(encoding="utf-8"),str(path),"exec")
checks["python_compiles"]=True
checks["no_bytecode"]=not list(ROOT.rglob("__pycache__"))
workers=[]
for path in ROOT.glob("*-start.json"):
    saved=read(path)
    workers.append({"identity":saved,"outcome":exited(saved)})
checks["owned_workers_exited"]=all(item["outcome"]["exited"] for item in workers)
require(all(checks.values()),"verification failure: "+repr([name for name,passed in checks.items() if not passed]))
write(ROOT/"verification.json",{"verified":True,"checks":checks,"frozen_paths":len(frozen),"previous_artifacts":read(PREVIOUS/"closeout.json")["artifact_count"],
    "scientific_qualifications":{"all_tiny_response_tests_passed":False,"all_old_prediction_envelopes_preserved":False,
        "true_sky_or_distortion_prediction":False,"full_corrected_native_state_restart":False}})
write(ROOT/"CLEANUP-VERIFIED.json",{"completed":True,"workers":workers,"count":len(workers),"foreground_checker":identity(process),
    "foreground_exit_checked_by":"terminal completion outside receipt","no_continuing_jobs":True,
    "no_new_browsers_servers_subagents":True,"no_other_chat_process_action":True,"github_action":False,"no_bytecode":True})
print(json.dumps({"verified":True,"checks":len(checks),"frozen_paths":len(frozen),"exited_workers":len(workers)}))

