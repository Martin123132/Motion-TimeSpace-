from readout_math import *
import argparse
import mpmath as mp
import csv
import io

def precise_values(packet):
    values = [mp.mpf(float(value)) for value in packet]
    wave = mp.mpf(CONFIG["retained_comoving_wave"])
    delta_b, delta_g = values[15]/values[12], values[27]/values[24]
    velocity_b, flux_g = values[16]/values[12], values[28]/values[24]
    sigma = values[COLUMNS["sigma"]]
    clock = values[COLUMNS["rate"]]*sigma/wave
    curvature, acceleration = values[COLUMNS["eta_k"]]/wave, values[COLUMNS["sigma_prime"]]/wave
    return [delta_g,delta_b,delta_g/4-clock,delta_b-3*clock,velocity_b+sigma,
            delta_b-3*delta_g/4,velocity_b-3*flux_g/4,curvature-clock,acceleration+clock,
            (curvature+acceleration)/2,values[17]/values[12]]

def compute_case(case, replay):
    reference = load(ROOT/(case+"-frozen-reference.npz"))
    norms, term_norms = reference["norms"],reference["term_norms"]
    prepared = load(Path(CONFIG["preparation_directory"])/(case+"-initial-state.npz"))
    weights = prepared["weights"]
    arrays, checks = {}, {}
    for steps in CONFIG["steps"]:
        saved = load(PREVIOUS/(case+"-metric-"+str(steps)+".npz"))
        packets = saved["metric"]
        require(bool(np.array_equal(field(packets[:,:,0],"tau"),saved["queries"])), "same physical queries")
        old, magnitude_old = readout(packets[:,:,0])
        new, magnitude_new = readout(packets[:,:,1])
        change = stable_difference(packets[:,:,0],packets[:,:,1])
        roundoff = 64*np.finfo(float).eps*(magnitude_old+magnitude_new)
        for column,name in enumerate(NAMES):
            checks[str(steps)+"_"+name+"_stable_difference"] = ratio(
                maximum(old[:,:,column]+change[:,:,column]-new[:,:,column]),term_norms[column],CONFIG["algebra_tolerance"])
        actual,expected,terms = kinetic_checks(packets)
        for column,name in enumerate(KINETIC_NAMES):
            for branch,label in enumerate(("original","coherent")):
                checks[str(steps)+"_"+label+"_"+name] = ratio(
                    maximum(actual[:,:,branch,column]-expected[:,:,branch,column]),
                    reference["kinetic_norms"][column],CONFIG["algebra_tolerance"])
        alpha = saved["background_change"][:,:,0]
        thermal = np.stack((-alpha/(1+alpha),-alpha*(2+alpha)/(1+alpha)**2),axis=-1)
        native_thermal = np.stack((
            field(packets[:,:,1],"sound_speed_squared")/field(packets[:,:,0],"sound_speed_squared")-1,
            field(packets[:,:,1],"opacity")/field(packets[:,:,0],"opacity")-1),axis=-1)
        checks[str(steps)+"_thermal_map"] = ratio(maximum(native_thermal-thermal),1,CONFIG["algebra_tolerance"])
        projected = projection(weights,change)
        increments = projection(weights,change-change[0])
        projected_roundoff = projection(abs(weights),roundoff)
        checks[str(steps)+"_complete_preparation_projection"] = ratio(
            maximum((projected-projected[0]-increments)/norms),1,CONFIG["algebra_tolerance"])
        mp.mp.dps = 80
        precise_error = np.zeros(len(NAMES))
        for report in (0,16,32):
            for node in (0,450,901):
                earlier, later = precise_values(packets[report,node,0]),precise_values(packets[report,node,1])
                for column in range(len(NAMES)):
                    error = abs(mp.mpf(float(change[report,node,column]))-(later[column]-earlier[column]))
                    precise_error[column] = max(precise_error[column],float(error))
        for column,name in enumerate(NAMES):
            checks[str(steps)+"_"+name+"_80digit_input_control"] = ratio(
                precise_error[column],term_norms[column],CONFIG["algebra_tolerance"])
        output = dict(old=old,coherent=new,change=change,roundoff=roundoff,thermal=thermal,
            projected_change=projected,projected_increment=increments,projected_roundoff=projected_roundoff,
            queries=saved["queries"],precise_error=precise_error)
        target = ROOT/(case+"-readout-"+str(steps)+".npz")
        if replay:
            archived=load(target)
            require(all(value.dtype==archived[name].dtype and value.shape==archived[name].shape and value.tobytes()==archived[name].tobytes()
                        for name,value in output.items()), "bitwise cached readout replay")
        else:
            require(not target.exists(),"new output only")
            np.savez_compressed(target,**output)
        arrays[steps] = output
    fine,coarse = arrays[64],arrays[32]
    outputs={}
    for column,name in enumerate(NAMES):
        change=fine["change"][:,:,column]
        difference=change-coarse["change"][:,:,column]
        arithmetic=fine["roundoff"][:,:,column]+coarse["roundoff"][:,:,column]
        uncertainty=abs(difference)+arithmetic
        change_max=maximum(change)
        projected_step=fine["projected_change"][:,column]-coarse["projected_change"][:,column]
        projected_allowance=abs(projected_step)+fine["projected_roundoff"][:,column]+coarse["projected_roundoff"][:,column]
        outputs[name]={
            "original_reference_norm":float(norms[column]),
            "old_maximum":maximum(fine["old"][:,:,column]),"coherent_maximum":maximum(fine["coherent"][:,:,column]),
            "maximum_change":change_max,
            "final_actual_mode_old":float(fine["old"][-1,-1,column]),
            "final_actual_mode_coherent":float(fine["coherent"][-1,-1,column]),
            "final_actual_mode_change":float(change[-1,-1]),
            "final_actual_mode_change_uncertainty":float(uncertainty[-1,-1]),
            "response_step_absolute_maximum":maximum(difference),"roundoff_envelope_maximum":maximum(arithmetic),
            "coherent_output_refinement":ratio(maximum(fine["coherent"][:,:,column]-coarse["coherent"][:,:,column]),norms[column]),
            "response_refinement_on_original_scale":ratio(maximum(uncertainty),norms[column]),
            "response_relative_resolution":ratio(maximum(uncertainty),change_max),
            "repair_size_vs_original_envelope":ratio(maximum(abs(change)+uncertainty),norms[column]),
            "signed_projection_initial_change":float(fine["projected_change"][0,column]),
            "signed_projection_final_change":float(fine["projected_change"][-1,column]),
            "signed_projection_final_increment":float(fine["projected_increment"][-1,column]),
            "signed_projection_final_allowance":float(projected_allowance[-1]),
        }
    thermal_checks={name:ratio(maximum(fine["thermal"][:,:,column]-coarse["thermal"][:,:,column]),
        maximum(fine["thermal"][:,:,column])) for column,name in enumerate(("background_Tm","opacity"))}
    thermal_result={name:{"final_fractional_response":float(fine["thermal"][-1,-1,column]),
        "maximum_fractional_response":maximum(fine["thermal"][:,:,column]),"relative_refinement":thermal_checks[name]}
        for column,name in enumerate(("background_Tm","opacity"))}
    result={"case":case,"checks":checks,"identities_passed":all(item["passed"] for item in checks.values()),
        "outputs":outputs,"thermal":thermal_result,
        "all_full_output_refinements_passed":all(item["coherent_output_refinement"]["passed"] and item["response_refinement_on_original_scale"]["passed"] for item in outputs.values()),
        "all_response_relative_tests_passed":all(item["response_relative_resolution"]["passed"] for item in outputs.values()),
        "all_old_prediction_envelopes_preserved":all(item["repair_size_vs_original_envelope"]["passed"] for item in outputs.values()),
        "projection_is_not_an_observational_kernel":True,
        "endpoint_conformal_time_Mpc":float(fine["queries"][-1,-1]),"query_shape":list(fine["queries"].shape),
        "weights_sum":float(math.fsum(map(float,weights))),"weights_absolute_sum":float(math.fsum(map(float,abs(weights))))}
    return result

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--replay",action="store_true")
    args=parser.parse_args()
    label="readout-replay" if args.replay else "readout"
    with worker(label):
        if args.replay:
            inputs=read(ROOT/"readout-inputs.json")
            check_inputs(inputs)
        else:
            extra=["run_readouts.py","DERIVATION.md","prove_readout.py","proof-result.json","frozen-reference.json"]
            extra += [case+"-frozen-reference.npz" for case in CONFIG["cases"]]
            inputs=freeze(label,tuple(extra))
        require(read(ROOT/"proof-result.json")["passed"],"verified mapping")
        cases={case:compute_case(case,args.replay) for case in CONFIG["cases"]}
        result={"cases":cases,
            "readout_implementation_and_full_output_refinement_passed":all(item["identities_passed"] and item["all_full_output_refinements_passed"] for item in cases.values()),
            "all_response_relative_tests_passed":all(item["all_response_relative_tests_passed"] for item in cases.values()),
            "all_old_prediction_envelopes_preserved":all(item["all_old_prediction_envelopes_preserved"] for item in cases.values()),
            "new_evolution":False,"new_collision_source":False,"new_fit":False,
            "frequency_resolved_distortion_prediction_available":False,"independent_gas_temperature_perturbation_available":False,
            "old_source_pressure_budget":read(Path(CONFIG["response_directory"])/"preparation-result.json")["cases"]["heavy"]["components"]["pressure"],
            "metric_stage_control_limitation_preserved":not read(PREVIOUS/"metric-result.json")["metric_stage_passed"],
            "inherited_baseline_response_failures_remain":True}
        stream=io.StringIO(newline="")
        writer=csv.writer(stream,lineterminator="\n")
        writer.writerow(["case","output","reference_norm","maximum_change","final_change","final_change_uncertainty","full_output_refinement_passed","response_relative_resolved","old_envelope_preserved"])
        for case,data in cases.items():
            for name,item in data["outputs"].items():
                writer.writerow([case,name,item["original_reference_norm"],item["maximum_change"],item["final_actual_mode_change"],
                    item["final_actual_mode_change_uncertainty"],item["coherent_output_refinement"]["passed"],
                    item["response_relative_resolution"]["passed"],item["repair_size_vs_original_envelope"]["passed"]])
        check_inputs(inputs)
        if args.replay:
            require(result==read(ROOT/"readout-result.json"),"exact cached readout report")
            require(stream.getvalue()==(ROOT/"readout-summary.csv").read_text(),"exact summary CSV")
            write(ROOT/"readout-replay.json",{"exact_arrays":True,"exact_result":True,"exact_csv":True})
        else:
            write(ROOT/"readout-result.json",result)
            with (ROOT/"readout-summary.csv").open("x",encoding="utf-8",newline="") as handle:
                handle.write(stream.getvalue())
        print(json.dumps({"implementation_and_refinement":result["readout_implementation_and_full_output_refinement_passed"],
            "old_envelopes_preserved":result["all_old_prediction_envelopes_preserved"],
            "cases":{case:{"identity_failures":{name:item for name,item in data["checks"].items() if not item["passed"]},
                "relative_unresolved":[name for name,item in data["outputs"].items() if not item["response_relative_resolution"]["passed"]],
                "old_envelope_exceeded":[name for name,item in data["outputs"].items() if not item["repair_size_vs_original_envelope"]["passed"]]}
                for case,data in cases.items()}}))

if __name__=="__main__":
    main()

