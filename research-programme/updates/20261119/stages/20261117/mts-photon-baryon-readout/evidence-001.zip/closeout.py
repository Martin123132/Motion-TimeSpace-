from support import *

guard()
process=psutil.Process()
process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
allowed=process.cpu_affinity()
process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
verification=read(ROOT/"verification.json")
require(verification["verified"],"verified readout")
cleanup=read(ROOT/"CLEANUP-VERIFIED.json")
require(exited(cleanup["foreground_checker"])["exited"],"foreground verifier exited")
for entry in cleanup["workers"]:
    require(exited(entry["identity"])["exited"],"task worker remains exited")
for name in ("readout-inputs.json","native-transfer-inputs.json","velocity-attribution-inputs.json"):
    check_inputs(read(ROOT/name))
require(not list(ROOT.rglob("__pycache__")),"no bytecode")
result=read(ROOT/"readout-result.json")
native=read(ROOT/"native-transfer-result.json")
artifacts={}
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name!="closeout.json":
        artifacts[path.relative_to(ROOT).as_posix()]={"sha256":digest(path),"bytes":path.stat().st_size}
output={
    "stage":"Actual photon/baryon and native-transfer response of the coherent source repair",
    "utc":datetime.now(timezone.utc).isoformat(),"completed":True,"verification_passed":True,
    "previous_goal_turn_classification":"verified progress",
    "this_goal_turn_classification":"verified progress: new paired output readouts, native convention bridge and velocity attribution",
    "full_output_refinements_pass":result["readout_implementation_and_full_output_refinement_passed"],
    "all_old_prediction_envelopes_preserved":False,"all_tiny_response_tests_pass":False,
    "all_scientific_checks_passed":False,
    "MTS_native_velocity_change_on_original_scale":native["cases"]["heavy"]["outputs"]["native_velocity_b"]["maximum_change"]/native["cases"]["heavy"]["outputs"]["native_velocity_b"]["reference_norm"],
    "MTS_native_Weyl_change_on_original_scale":native["cases"]["heavy"]["outputs"]["native_weyl"]["maximum_change"]/native["cases"]["heavy"]["outputs"]["native_weyl"]["reference_norm"],
    "new_evolution":False,"new_collision_source":False,"new_frequency_spectrum":False,
    "native_initial_mode_normalization_inherited":True,"full_native_restart_saved":False,
    "bank_grids_tolerances_unchanged":True,"quantum_measure_separate":True,
    "frozen_paths":verification["frozen_paths"],"previous_artifacts_preserved":verification["previous_artifacts"],
    "task_workers_exited":cleanup["count"],"foreground_checker":identity(process),
    "foreground_exit_verified_by":"terminal command completion outside receipt",
    "goal_last_observed_active_no_goal_status_change":True,
    "github_actions":False,"no_other_chat_process_actions":True,
    "authoritative":["RESULTS.md","readout-result.json","native-transfer-result.json","velocity-attribution-result.json","verification.json"],
    "artifact_count":len(artifacts),"artifacts":artifacts,
}
write(ROOT/"closeout.json",output)
print(json.dumps({"completed":True,"sha256":digest(ROOT/"closeout.json"),"artifacts":len(artifacts),
    "frozen_paths":output["frozen_paths"],"worker_count":cleanup["count"],
    "velocity_normalized_change":output["MTS_native_velocity_change_on_original_scale"],
    "Weyl_normalized_change":output["MTS_native_Weyl_change_on_original_scale"]}))

