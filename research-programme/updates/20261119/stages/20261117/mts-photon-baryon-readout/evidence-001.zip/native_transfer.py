from readout_math import *
import argparse
import sympy as sp

NATIVE_NAMES=("native_weyl","native_phi","native_psi","native_k2_weyl","native_velocity_b")

def native_values(packet):
    baryon,photon,delta_b,delta_g,velocity_b,flux_g=ingredients(packet)
    wave=CONFIG["retained_comoving_wave"]
    density,current,hubble,stress=[field(packet,name) for name in ("density","current","hubble","anisotropic_stress")]
    phi=-(density+3*hubble*current/wave)/(2*wave**2)
    weyl=phi-stress/(2*wave**2)
    psi=phi-stress/wave**2
    velocity=-wave*(velocity_b+field(packet,"sigma"))/hubble
    values=np.stack((weyl,phi,psi,wave**2*weyl,velocity),axis=-1)
    magnitude=(abs(density)+3*abs(hubble*current/wave))/(2*wave**2)
    terms=np.stack((magnitude+abs(stress)/(2*wave**2),magnitude,magnitude+abs(stress)/wave**2,
        wave**2*magnitude+abs(stress)/2,wave*(abs(velocity_b)+abs(field(packet,"sigma")))/abs(hubble)),axis=-1)
    return values,terms

def native_difference(old,new):
    wave=CONFIG["retained_comoving_wave"]
    earlier,_=native_values(old)
    delta_density=field(new,"density")-field(old,"density")
    delta_current=field(new,"current")-field(old,"current")
    delta_hubble=field(new,"hubble")-field(old,"hubble")
    delta_stress=field(new,"anisotropic_stress")-field(old,"anisotropic_stress")
    phi=-(delta_density+3*(delta_hubble*field(old,"current")+field(new,"hubble")*delta_current)/wave)/(2*wave**2)
    weyl=phi-delta_stress/(2*wave**2)
    psi=phi-delta_stress/wave**2
    baryon_old,baryon_new=species(old)[...,1,:],species(new)[...,1,:]
    delta_velocity=ratio_difference(baryon_old[...,4],baryon_new[...,4],baryon_old[...,0],baryon_new[...,0])
    delta_velocity+=field(new,"sigma")-field(old,"sigma")
    velocity=(-wave*delta_velocity-earlier[...,4]*delta_hubble)/field(new,"hubble")
    return np.stack((weyl,phi,psi,wave**2*weyl,velocity),axis=-1)

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--replay",action="store_true")
    args=parser.parse_args()
    label="native-transfer-replay" if args.replay else "native-transfer"
    with worker(label):
        if args.replay:
            inputs=read(ROOT/"native-transfer-inputs.json")
            check_inputs(inputs)
        else:
            inputs=freeze(label,("native_transfer.py","TRANSFER-CONVENTIONS.md","DERIVATION.md",
                str(POST/"mts-metric-feedback-20261107/observer.f90")))
        references={}
        for case in CONFIG["cases"]:
            packet=load(PREVIOUS/(case+"-reference-metric.npz"))["packet"]
            original,_=native_values(packet)
            norms=np.max(abs(original),axis=0)
            observed=load(PREVIOUS/(case+"-preflight-capture.npz"))["observation_reference"]
            checks={
                "actual_native_weyl_observer":ratio(maximum(original[:,0]-observed[:,9]),norms[0],CONFIG["algebra_tolerance"]),
                "actual_native_velocity_transfer":ratio(maximum(original[:,4]+5*(observed[:,26]+observed[:,5])/observed[:,28]),norms[4],CONFIG["algebra_tolerance"]),
            }
            references[case]={"norms":norms.tolist(),"observer_checks":checks}
        if args.replay:
            require(references==read(ROOT/"native-reference.json"),"unchanged native norm and observer controls")
        else:
            write(ROOT/"native-reference.json",references)
        cases={}
        for case in CONFIG["cases"]:
            norms=np.array(references[case]["norms"])
            checks=dict(references[case]["observer_checks"])
            runs={}
            bridge_summary={}
            for steps in CONFIG["steps"]:
                packets=load(PREVIOUS/(case+"-metric-"+str(steps)+".npz"))["metric"]
                old,old_terms=native_values(packets[:,:,0])
                new,new_terms=native_values(packets[:,:,1])
                change=native_difference(packets[:,:,0],packets[:,:,1])
                rounding=64*np.finfo(float).eps*(old_terms+new_terms)
                for column,name in enumerate(NATIVE_NAMES):
                    checks[str(steps)+"_"+name+"_difference_identity"]=ratio(maximum(old[:,:,column]+change[:,:,column]-new[:,:,column]),norms[column],CONFIG["algebra_tolerance"])
                kin,_=readout(packets)
                actual=np.stack((kin[...,9]-np.stack((old[:,:,0],new[:,:,0]),axis=-1),
                    kin[...,7]-np.stack((old[:,:,1],new[:,:,1]),axis=-1),
                    kin[...,8]-np.stack((old[:,:,2],new[:,:,2]),axis=-1)),axis=-1)
                wave=CONFIG["retained_comoving_wave"]
                residue, constraint=field(packets,"shear_residual"),field(packets,"density_constraint")
                geometry=(field(packets,"hubble")-field(packets,"rate"))*field(packets,"sigma")/wave
                predicted=np.stack((residue/(2*wave)-constraint/wave,geometry-constraint/wave,
                    residue/wave-geometry-constraint/wave),axis=-1)
                for column,name in enumerate(("weyl","phi","psi")):
                    checks[str(steps)+"_"+name+"_metric_bridge"]=ratio(maximum(actual[...,column]-predicted[...,column]),norms[column],CONFIG["algebra_tolerance"])
                if steps==64:
                    bridge_summary={name:{
                        "interpolated_maximum_difference":maximum(actual[:,:,0,column]),
                        "coherent_maximum_difference":maximum(actual[:,:,1,column]),
                        "coherent_bridge_size_on_native_scale":ratio(maximum(actual[:,:,1,column]),norms[column])}
                        for column,name in enumerate(("weyl","phi","psi"))}
                output=dict(old=old,coherent=new,change=change,rounding=rounding,bridge=actual,predicted_bridge=predicted)
                path=ROOT/(case+"-native-transfer-"+str(steps)+".npz")
                if args.replay:
                    saved=load(path)
                    require(all(value.dtype==saved[name].dtype and value.shape==saved[name].shape and value.tobytes()==saved[name].tobytes()
                                for name,value in output.items()),"bitwise native readout replay")
                else:
                    require(not path.exists(),"new native output")
                    np.savez_compressed(path,**output)
                runs[steps]=output
            fine,coarse=runs[64],runs[32]
            outputs={}
            for column,name in enumerate(NATIVE_NAMES):
                change=fine["change"][:,:,column]
                allowance=abs(change-coarse["change"][:,:,column])+fine["rounding"][:,:,column]+coarse["rounding"][:,:,column]
                outputs[name]={"maximum_change":maximum(change),"reference_norm":float(norms[column]),
                    "final_change":float(change[-1,-1]),"final_allowance":float(allowance[-1,-1]),
                    "coherent_output_refinement":ratio(maximum(fine["coherent"][:,:,column]-coarse["coherent"][:,:,column]),norms[column]),
                    "change_uncertainty_on_original_scale":ratio(maximum(allowance),norms[column]),
                    "relative_response_resolution":ratio(maximum(allowance),maximum(change)),
                    "repair_size_vs_original_envelope":ratio(maximum(abs(change)+allowance),norms[column])}
            cases[case]={"checks":checks,"checks_passed":all(item["passed"] for item in checks.values()),"outputs":outputs,"metric_bridge":bridge_summary}
        result={"cases":cases,"native_convention_checks_passed":all(item["checks_passed"] for item in cases.values()),
            "post_kinematic_readout_source_audit":True,"no_old_failures_relabelled":True}
        check_inputs(inputs)
        if args.replay:
            require(result==read(ROOT/"native-transfer-result.json"),"exact native transfer report")
            write(ROOT/"native-transfer-replay.json",{"exact_arrays":True,"exact_result":True})
        else:
            write(ROOT/"native-transfer-result.json",result)
        print(json.dumps({"checks_passed":result["native_convention_checks_passed"],"cases":{
            case:{"failures":{name:item for name,item in data["checks"].items() if not item["passed"]},
                "outputs":data["outputs"],"bridge":data["metric_bridge"]} for case,data in cases.items()}}))

if __name__=="__main__":
    main()

