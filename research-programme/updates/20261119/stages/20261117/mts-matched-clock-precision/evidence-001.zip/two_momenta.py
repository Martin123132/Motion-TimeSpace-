import math
from matched import ROOT,PREV,bank,np,require,receipt,finish,guard


def evolve(table,starts,width,subdiv,coordinates):
    state=np.zeros((len(starts),5))
    state[:,:4]=starts
    if coordinates=='slip':
        state[:,1]=starts[:,0]-starts[:,1]
        state[:,3]=starts[:,2]-starts[:,3]
    cancel=0.
    def flow(source,current):
        nonlocal cancel
        hubble,dh,pressure,dp,force,dj,opacity,weight,alpha=source
        inverse=1/(1+alpha)
        sq=inverse**2
        sqchange=-alpha*(2+alpha)*sq
        cubechange=-alpha*inverse*(1+inverse+sq)
        old,deltav=current[:,0],current[:,2]
        slip=current[:,1] if coordinates=='slip' else old-current[:,1]
        difference=current[:,3] if coordinates=='slip' else deltav-current[:,3]
        drag=-weight*opacity*slip
        gain=opacity*slip
        ddrag=-weight*opacity*(inverse**3*difference+cubechange*slip)
        dgamma=opacity*(sq*difference+sqchange*slip)
        final_weight=weight*inverse
        interaction=ddrag+final_weight*dgamma-weight*alpha*inverse*gain
        primitive=np.abs(ddrag)+abs(final_weight*dgamma)+abs(weight*alpha*inverse*gain)
        cancel=max(cancel,float(np.max(abs(interaction)/np.maximum(primitive,1e-300))))
        baryon=-hubble*old+pressure+drag
        photon=force+gain
        dbaryon=-(hubble+dh)*deltav-dh*old+dp+ddrag
        dphoton=dj+dgamma
        radiation=(4/3)*opacity*sq*(difference*(2*slip+difference)-alpha*(2+alpha)*slip**2)
        return np.column_stack((baryon,baryon-photon if coordinates=='slip' else photon,
                            dbaryon,dbaryon-dphoton if coordinates=='slip' else dphoton,radiation))
    step=width/((len(table)-1)*subdiv)
    for first,last in zip(table[:-1],table[1:]):
        delta=last-first
        for sub in range(subdiv):
            left=flow(first+(sub/subdiv)*delta,state)
            mid=first+((sub+.5)/subdiv)*delta
            middle=flow(mid,state+(step/2)*left)
            middle2=flow(mid,state+(step/2)*middle)
            right=flow(first+((sub+1)/subdiv)*delta,state+step*middle2)
            state+=(step/6)*(left+2*middle+2*middle2+right)
    if coordinates=='slip':
        state[:,1]=state[:,0]-state[:,1]
        state[:,3]=state[:,2]-state[:,3]
    return state,cancel


def read(label,cell,steps):
    case,mode=label.split('_')
    tag=f'{case}-{steps}-{mode}-{cell}'
    with np.load(ROOT/f'matter/{tag}.npz') as material,np.load(PREV/f'isolated/{tag}-reference.npz') as reference,np.load(ROOT/(tag+'-conditional.npz')) as packet:
        times=material['time']
        old=reference['forces']
        matched=packet['forces'][list(packet['tags']).index('log64')]
        expansion=packet['delta_H'][list(packet['rate_tags']).index('log64')]
        h0=reference['metric'][:,0]
        baryon,_,vel,dvel,cs,alpha=material['primitive'].T
        pressure=baryon*float(material['wave'])*cs
        force=pressure-h0*vel-old[:,0]
        initial=np.array([vel[0],vel[0]-old[0,-2],dvel[0],dvel[0]-old[0,-1]])
        endpoint=np.array([vel[-1],vel[-1]-old[-1,-2],dvel[-1],dvel[-1]-old[-1,-1],reference['integrals'][-1]])
        table=np.column_stack((h0,expansion,pressure,matched[:,3],force,-matched[:,4]-matched[:,5],*matched[:,6:9].T))
        require(np.max(abs(matched[:,1]+(h0+expansion)*dvel))<=bank.ALG*np.max(abs(matched[:,1])),'recovered coherent H')
        return initial,endpoint,table,times[-1]-times[0],sum(abs(np.diff(reference['integrals'])))


def main():
    guard()
    result={}
    for label in bank.LABELS:
        case,mode=label.split('_')
        result[label]={}
        for cell in bank.read(ROOT/f'{case}-input.json')['cells']:
            runs=[read(label,cell,steps) for steps in (32,64)]
            original=np.asarray([group[0] for group in runs])
            offset=original[0]-original[1]
            reports=[]
            for num,(initial,target,table,width,reference_error) in enumerate(runs):
                weight,alpha=table[0,-2:]
                final_weight=weight/(1+alpha)
                common=(offset[0]+weight*offset[1])/(1+weight)
                dcommon=(offset[2]+final_weight*offset[3]-final_weight*alpha*(offset[1]-common))/(1+final_weight)
                center=np.array([common,common,dcommon,dcommon])
                seeds=np.vstack((original,original[1]+center,original[1]+(offset-center)))
                prim,err=evolve(table,seeds,width,2,'direct')
                finer,err2=evolve(table,seeds,width,4,'direct')
                independent,err3=evolve(table,seeds,width,2,'slip')
                require(max(err,err2,err3)<=bank.ALG,'finite collision momentum cancels')
                coarse,err4=evolve(table[::2],seeds,width,2,'direct')
                allowance=abs(finer[num]-prim[num])+abs(prim[num]-independent[num])+abs(coarse[num]-prim[num])
                allowance[-1]+=reference_error
                integral=finer[:,-1]
                cpart=((integral[2]-integral[1])+(integral[0]-integral[3]))/2
                spart=((integral[3]-integral[1])+(integral[0]-integral[2]))/2
                require(abs(cpart+spart-integral[0]+integral[1])<=bank.ALG*abs(target[-1]),'memory split')
                reports.append(dict(value=finer[num],allowance=allowance,weighted_identity=max(err,err2,err3,err4),
                        coord_disagreement=abs(independent[num]-prim[num]),center=cpart,slip=spart,allseed=integral[0]-integral[1]))
            fine=reports[1]['value']
            high=runs[1][1]
            scale=np.r_[np.maximum(abs(original[1]),abs(high[:4])),abs(high[4])]
            working=(abs(fine-reports[0]['value'])+sum(row['allowance'] for row in reports))/scale
            residual=(abs(high-runs[0][1])+abs(fine-high)+abs(reports[0]['value']-runs[0][1]))/scale
            center=np.mean([row['center'] for row in reports])
            slip_part=np.mean([row['slip'] for row in reports])
            result[label][str(cell)]=dict(order=['v_b','3q_gamma/4','D_v_b','3D_q_gamma/4','radiation_integral'],
                   integral=fine[4],direct_native=high[4],internal_working=working.tolist(),
                   native_comparison=(working+residual).tolist(),max_collision_residual=max(row['weighted_identity'] for row in reports),
                   largest_coordinate_disagreement=max(np.max(row['coord_disagreement']/scale) for row in reports),
                   center_mode_energy_shift=center/abs(fine[4]),relative_mode_energy_shift=slip_part/abs(fine[4]),
                   center_share_of_seed_shift=(center/(center+slip_part)) if center+slip_part!=0 else None,
                   internal_pass=bool(np.all(working<=bank.TOL)),reference_pass=bool(np.all(working+residual<=bank.TOL)))
    bank.save(ROOT/'two-momenta.json',result)
    for label,rows in result.items():
        print(label,[(key,row['internal_working'][-1],row['center_share_of_seed_shift'],row['reference_pass']) for key,row in rows.items()])


if __name__=='__main__':
    receipt('momenta')
    try:
        main()
    finally:
        finish('momenta')
