from matched import ROOT,PREV,bank,np,receipt,finish,guard,require
from two_momenta import read


def evolve(table,seed,width,refine,wave,density,baryon_left):
    state=np.r_[seed,0.,0.]
    step=width/((len(table)-1)*refine)
    def rhs(values,vector):
        old,photon,dv,dp,integral,_=vector
        hubble,dh,press,dpress,source,dquad,opacity,weight,alpha,baryon=values
        slip=old-photon
        change=dv-dp
        inverse=1/(1+alpha)
        sq=inverse**2
        dsq=-alpha*(2+alpha)*sq
        dcube=-alpha*inverse*(1+inverse+sq)
        dgamma=density+4/3*((baryon-baryon_left)+wave*integral)
        dphoton=wave/4*dgamma-dquad+opacity*(sq*change+dsq*slip)
        return np.array([-hubble*old+press-weight*opacity*slip,source+opacity*slip,
             -(hubble+dh)*dv-dh*old+dpress-weight*opacity*(inverse**3*change+dcube*slip),
             dphoton,change,(4/3)*opacity*sq*(change*(2*slip+change)-alpha*(2+alpha)*slip**2)])
    for start,stop in zip(table[:-1],table[1:]):
        delta=stop-start
        for inner in range(refine):
            mid=start+(inner+.5)/refine*delta
            first=rhs(start+inner/refine*delta,state)
            second=rhs(mid,state+step*first/2)
            third=rhs(mid,state+step*second/2)
            last=rhs(start+(inner+1)/refine*delta,state+step*third)
            state+=(step/6)*(first+2*second+2*third+last)
    return np.r_[state[:4],state[5],density+4/3*((table[-1,-1]-baryon_left)+wave*state[4])]


def main():
    guard()
    result={}
    for label in bank.LABELS:
        case,mode=label.split('_')
        for cell in bank.read(ROOT/f'{case}-input.json')['cells']:
            answers=[]
            for steps in (32,64):
                tag=f'{case}-{steps}-{mode}-{cell}'
                start,target,table,width,quadrature=read(label,cell,steps)
                with np.load(ROOT/f'matter/{tag}.npz') as matter,np.load(PREV/f'isolated/{tag}-reference.npz') as reference:
                    wave=float(matter['wave'])
                    baryon=matter['primitive'][:,1]
                    forces=reference['forces']
                    gamma=-4*forces[:,4]/wave
                    table[:,5]=forces[:,5]
                table=np.column_stack((table,baryon))
                solve=lambda stride,refine:evolve(table[::stride],start,width,refine,wave,gamma[0],baryon[0])
                value=solve(1,4)
                fine=solve(1,2)
                coarse=solve(2,2)
                error=abs(value-fine)+abs(fine-coarse)
                error[4]+=quadrature
                answers.append((value,np.r_[target,gamma[-1]],error,np.r_[np.maximum(abs(target[:4]),abs(start)),abs(target[4]),max(abs(gamma))]))
            low,high=answers
            allowance=(abs(low[0]-high[0])+low[2]+high[2])/high[3]
            native=(abs(low[1]-high[1])+abs(low[1]-low[0])+abs(high[0]-high[1]))/high[3]+allowance
            result[label+':'+str(cell)]=dict(order=['v_b','3q_gamma/4','D_v_b','3D_q_gamma/4','radiation','D_delta_gamma'],
                internal_working=allowance.tolist(),native_budget=native.tolist(),integral=high[0][4],
                conditional_monopole_relative=(high[0][-1]-high[1][-1])/high[3][-1],
                test_pass=bool(np.all(native<=bank.TOL)),integral_reference_pass=bool(native[4]<=bank.TOL))
    bank.save(ROOT/'monopole-result.json',result)
    for label,row in result.items():
        print(label,row['native_budget'][4],row['conditional_monopole_relative'],row['test_pass'])


if __name__=='__main__':
    receipt('monopole')
    try:
        main()
    finally:
        finish('monopole')
