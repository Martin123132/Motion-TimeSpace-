import os
import sys
import ctypes
import time
from decimal import Decimal, localcontext
from pathlib import Path

for name in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[name]='1'
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PREV=POST/'mts-friedmann-expansion-response-20261117'
sys.path.insert(0,str(PREV))
from response import bank,np,require,as_decimal
sys.path.insert(0,str(POST/'mts-coupled-background-defect-response-20261116'))
import run_response as owner


def guard():
    bank.guard()
    require(not (ROOT/'STOP-REQUESTED').exists(),'owner hold')


def receipt(tag):
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/(tag+'-start.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),priority=proc.nice(),affinity=proc.cpu_affinity()))


def finish(tag):
    bank.save(ROOT/(tag+'-end.json'),dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))


def clock_words(background,times):
    with localcontext() as context:
        context.prec=55
        minimum,spacing=map(as_decimal,(background.minimum,background.spacing))
        smooth=[]
        for time_value in times:
            moment=as_decimal(time_value)
            position=(moment/minimum).ln()/spacing
            index=int(position)
            fraction=position-index
            value,slope=map(as_decimal,background.clock[index])
            next_value,next_slope=map(as_decimal,background.clock[index+1])
            quadratic=3*(next_value-value)-2*slope-next_slope
            cubic=slope+next_slope+2*(value-next_value)
            scale=moment*(value+fraction*(slope+fraction*(quadratic+fraction*cubic)))
            efold=scale.ln()
            row=[scale]
            for pair in background.fields:
                for spline in pair:
                    idx=int(np.searchsorted(spline.x,float(efold),side='right')-1)
                    idx=min(len(spline.x)-2,max(0,idx))
                    if efold<as_decimal(spline.x[idx]) and idx>0:
                        idx-=1
                    if efold>as_decimal(spline.x[idx+1]) and idx<len(spline.x)-2:
                        idx+=1
                    require(as_decimal(spline.x[idx])<=efold<=as_decimal(spline.x[idx+1]),'actual field cell')
                    offset=efold-as_decimal(spline.x[idx])
                    coefficients=list(map(as_decimal,spline.c[:,idx]))
                    row.append(((coefficients[0]*offset+coefficients[1])*offset+coefficients[2])*offset+coefficients[3])
            smooth.append(row)
        high=np.array([[float(value) for value in row] for row in smooth])
        low=np.array([[float(value-as_decimal(upper)) for value,upper in zip(row,uppers)] for row,uppers in zip(smooth,high)])
    return high,low


def library():
    handle=ctypes.CDLL(str(ROOT/'clock_quad.dll'))
    call=handle.advance_clock
    call.argtypes=[ctypes.c_int]*4+[ctypes.c_void_p]*11
    call.restype=None
    return call


def integrate(call,constants,fields,levels,coordinate,times,seed_hi,seed_lo,maximum_step):
    pack=lambda values:np.ascontiguousarray(values,dtype=np.float64)
    initial_high=pack(np.pad(seed_hi,(0,5-len(seed_hi))))
    initial_low=pack(np.pad(seed_lo,(0,5-len(seed_lo))))
    scale=pack([initial_high[0]])
    low_scale=pack([initial_low[0]])
    step=pack([maximum_step])
    hi,lo=np.zeros((len(times),6)),np.zeros((len(times),6))
    current_hi,current_lo=initial_high.copy(),initial_low.copy()
    count_steps=0
    for begin in range(0,len(times)-1,768):
        guard()
        end=min(begin+769,len(times))
        ticks=pack(times[begin:end])
        top=np.zeros((len(ticks),6))
        bottom=np.zeros_like(top)
        count,status=ctypes.c_int(),ctypes.c_int(-1)
        arrays=(constants,ticks,scale,low_scale,current_hi,current_lo,step,top,bottom)
        call(len(ticks),fields,levels,coordinate,*(value.ctypes.data for value in arrays),ctypes.byref(count),ctypes.byref(status))
        require(status.value==0 and count.value>=len(ticks)-1 and np.all(np.isfinite(top)) and np.all(np.isfinite(bottom)),'positive finite quad evolution')
        count_steps+=count.value
        if begin:
            require(np.array_equal(top[0],hi[begin]) and np.max(abs(bottom[0]-lo[begin]))<1e-26,'high/low continuation')
        hi[begin:end],lo[begin:end]=top,bottom
        current_hi,current_lo=pack(top[-1,:5]),pack(bottom[-1,:5])
    return hi,lo,count_steps


def prepare(case):
    guard()
    require(bank.digest(PREV/'closeout.json')=='837f28a25057131d541f0ec41db6d259c5e60e818ebfdad2d3aa074429766647','previous seal')
    bank.check_seals()
    prepared,_,background,_,_=owner.EX.problem(case)
    start=float(np.min(prepared['times'])+np.min(prepared['elapsed']))
    with np.load(bank.source_path('cold_baseline' if case=='cold' else 'heavy_parent',64)) as retained:
        saved=retained['time']
    cells=[892,3112,1204,2409] if case=='cold' else [96,5264,2618,5236]
    label='baseline' if case=='cold' else 'parent'
    probes=[]
    deps=[owner.EX.PREVIOUS/(case+'-initial-state.npz'),owner.EX.ROOT/(case+'-extension-plan.npz'),
          owner.EX.SOURCE/(case+'-native-clock.npz'),owner.EX.EARLY/'runs/backgrounds'/(case+'.npz'),
          POST/'mts-integrated-defect-20261112/integrated_math.py',POST/'mts-coupled-preparation-response-20261116/run_coupled.py',
          ROOT/'clock_quad.dll',ROOT/'clock_quad.f90',ROOT/'matched.py',ROOT/'CONTRACT.md',PREV/'closeout.json',
          bank.source_path('cold_baseline' if case=='cold' else 'heavy_parent',64)]
    for index in cells:
        path=PREV/f'isolated/{case}-64-{label}-{index}-prediction.npz'
        with np.load(path) as data:
            probes.append(data['time'])
        deps.append(path)
    boundaries=background.boundaries(start,saved[-1])
    grid=np.unique(np.r_[start,boundaries,saved,*probes])
    require(grid[0]==start and grid[-1]==saved[-1] and start<saved[0],'true earlier preparation')
    query=np.unique(np.r_[start,saved,*probes])
    smooth_hi,smooth_lo=clock_words(background,query)
    evaluated=background.evaluate(query)
    represented=np.column_stack([evaluated['scale'],*(component for item in evaluated['jets'] for component in item[:2])])
    seed=owner.Model(background,start).initial
    original=np.array([seed['scale'],*(number for pair in zip(seed['field'],seed['velocity']) for number in pair)])
    require(np.array_equal(original,represented[0]),'actual binary matching')
    bank.save(ROOT/f'{case}-input.json',dict(files={str(path):bank.digest(path) for path in deps},anchor=start,clock_first=saved[0],
        clock_last=saved[-1],boundaries=len(boundaries),outputs=len(grid),cells=cells,base_step=float(prepared['elapsed'][8])))
    with (ROOT/f'{case}-prepared.npz').open('xb') as stream:
        np.savez_compressed(stream,grid=grid,query=query,source_time=saved,query_on_grid=np.searchsorted(grid,query),
            smooth_high=smooth_hi,smooth_low=smooth_lo,represented=represented,constants=background.constants)
    return grid,query,original,smooth_hi[0],smooth_lo[0],float(prepared['elapsed'][8]),background.constants


def control(call):
    params=np.zeros(20)
    params[0],params[2]=1.27e-8,3.64e-12
    ticks=np.linspace(0,13,48)
    original=1.913e-4
    results=[]
    with localcontext() as context:
        context.prec=65
        amount=as_decimal(params[0])
        start=as_decimal(original)
        speed=((amount*start+as_decimal(params[2]))/3).sqrt()
        for logmode in (0,1):
            high,low,_=integrate(call,params,0,4,logmode,ticks,np.array([original]),np.zeros(1),.011)
            errors=[]
            for moment,top,bottom in zip(ticks,high[:,0],low[:,0]):
                elapsed=as_decimal(moment)
                exact=start+speed*elapsed+amount*elapsed**2/12
                errors.append(float(abs((as_decimal(top)+as_decimal(bottom)-exact)/exact)))
            require(max(errors)<1e-25,'analytic dust+radiation matched scale')
            results.append(max(errors))
    return results


def execute(case):
    call=library()
    tests=control(call)
    grid,query,matched,alt_hi,alt_lo,step,constants=prepare(case)
    selection=np.searchsorted(grid,query)
    summary={}
    for tag,steps,levels,coordinate,smooth in [('scale32',32,4,0,False),('scale64',64,4,0,False),('log64',64,5,1,False),('smooth64',64,5,1,True)]:
        begun=time.monotonic()
        seed,low=(alt_hi,alt_lo) if smooth else (matched,np.zeros_like(matched))
        high,bottom,iterations=integrate(call,constants,(len(matched)-1)//2,levels,coordinate,grid,seed,low,step/steps)
        with (ROOT/f'{case}-{tag}.npz').open('xb') as stream:
            np.savez_compressed(stream,time=query,high=high[selection],low=bottom[selection])
        summary[tag]=dict(seconds=time.monotonic()-begun,steps=iterations,order=2*levels,coordinate='log' if coordinate else 'scale')
        print(case,tag,iterations,round(time.monotonic()-begun,1),flush=True)
    bank.save(ROOT/f'{case}-integration.json',dict(manufactured_dust_radiation=tests,runs=summary))


if __name__=='__main__':
    case=sys.argv[1]
    require(case in ('cold','heavy'),'recognized case')
    receipt(case)
    try:
        execute(case)
    finally:
        finish(case)
