import math
from scipy.integrate import simpson
from matched import ROOT,PREV,bank,np,require,receipt,finish,guard


def balance(times,baryon,gamma,slip,wave):
    entropy=np.array([math.fsum((float(photon),-float(matter),-float(matter)/3)) for photon,matter in zip(gamma,baryon)])
    increments=[math.fsum((float(gamma[-1]-gamma[0]),-float(baryon[-1]-baryon[0]),-float(baryon[-1]-baryon[0])/3))]
    require(abs(increments[0]-(entropy[-1]-entropy[0]))<=16*np.finfo(float).eps*(np.max(abs(gamma))+np.max(abs(baryon))),'equivalent entropy increment')
    integrals=[4*wave/3*simpson(slip[::stride],x=times[::stride]) for stride in (4,2,1)]
    scale=4*wave/3*simpson(abs(slip),x=times)
    require(scale>0,'own integrated slip norm')
    rounding=16*np.finfo(float).eps*(np.max(abs(gamma))+4/3*np.max(abs(baryon)))
    allowance=sum(abs(np.diff(integrals)))+rounding
    return dict(increment=increments[0],integrated=integrals[-1],scale=scale,rounding=rounding,
             relative_mismatch=abs(increments[0]-integrals[-1])/scale,relative_allowance=allowance/scale,
             passes=bool((abs(increments[0]-integrals[-1])+allowance)/scale<=bank.TOL))


def main():
    guard()
    report={}
    for label in bank.LABELS:
        case,mode=label.split('_')
        for cell in bank.read(ROOT/f'{case}-input.json')['cells']:
            rows=[]
            for steps in (32,64):
                name=f'{case}-{steps}-{mode}-{cell}'
                with np.load(ROOT/f'matter/{name}.npz') as material,np.load(PREV/f'isolated/{name}-reference.npz') as ref:
                    wave=float(material['wave'])
                    times=ref['time']
                    baryon=material['primitive'][:,1]
                    gamma=-4*ref['forces'][:,4]/wave
                    motion=ref['forces'][:,-1]
                rows.append(np.array([baryon,gamma,motion]))
                report[name]=balance(times,baryon,gamma,motion,wave)
            report[f'{label}:{cell}:resolution']=balance(times,*(rows[0]-rows[1]),wave)
    bank.save(ROOT/'relative-entropy.json',report)
    for name,row in report.items():
        if '-64-' in name or ('cold' in name and 'resolution' in name):
            print(name,row['relative_mismatch'],row['relative_allowance'],row['passes'])


if __name__=='__main__':
    receipt('entropy')
    try:
        main()
    finally:
        finish('entropy')
