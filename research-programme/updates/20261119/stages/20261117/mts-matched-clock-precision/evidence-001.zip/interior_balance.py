from decimal import Decimal, localcontext
from matched import ROOT, PREV, bank, np, guard, receipt, finish, require


def word(value):
    return Decimal.from_float(float(value))


def integrate(clock, values, stride):
    current = Decimal(0)
    result = {}
    for left in range(0, len(clock) - 1, 2 * stride):
        middle, right = left + stride, left + 2 * stride
        first, second = clock[middle] - clock[left], clock[right] - clock[middle]
        span = first + second
        current += span / 6 * ((2 - second / first) * values[left]
                               + span ** 2 / (first * second) * values[middle]
                               + (2 - first / second) * values[right])
        result[right] = current
    return result


def evaluate(tag, ledger):
    with np.load(ROOT / 'matter' / (tag + '.npz')) as material, np.load(PREV / 'isolated' / (tag + '-reference.npz')) as ref:
        require(np.array_equal(ref['time'], material['time']), 'identical clocks')
        times = list(map(word, ref['time']))
        baryons = list(map(word, material['primitive'][:, 1]))
        wave = word(material['wave'])
        forces = ref['forces']
        photons = [-4 * word(force) / wave for force in forces[:, 4]]
        velocities = list(map(word, forces[:, -1]))
    signed = [integrate(times, velocities, stride) for stride in (1, 2, 4)]
    absolute = integrate(times, [abs(value) for value in velocities], 1)
    records = []
    for right in sorted(signed[-1]):
        factor = 4 * wave / 3
        observed = photons[right] - photons[0] - 4 * (baryons[right] - baryons[0]) / 3
        norms = factor * absolute[right]
        prediction = factor * signed[0][right]
        rounding = 16 * word(np.finfo(float).eps) * (max(map(abs, photons[:right + 1]))
                                                    + 4 * max(map(abs, baryons[:right + 1])) / 3)
        allowance = factor * sum(abs(fine[right] - coarse[right]) for fine, coarse in zip(signed, signed[1:])) + rounding
        records.append(dict(node=right, signed=float((observed - prediction) / norms),
                            allowance=float(allowance / norms), passed=abs(observed - prediction) + allowance <= word(bank.TOL) * norms))
    endpoint = records[-1]
    original = ledger[tag]
    require(abs(abs(endpoint['signed']) - original['relative_mismatch']) <= original['relative_allowance'], 'independent endpoint replay')
    require(endpoint['passed'] == original['passes'], 'independent endpoint decision')
    return dict(prefixes=records, passes=sum(row['passed'] for row in records), total=len(records))


def main():
    guard()
    ledger = bank.read(ROOT / 'relative-entropy.json')
    with localcontext() as context:
        context.prec = 65
        results = {tag: evaluate(tag, ledger) for tag in ledger if ':' not in tag}
    require(len(results) == 24 and all(row['total'] == 32 for row in results.values()), 'complete paired panel')
    bank.save(ROOT / 'interior-balance.json', results)
    for tag, result in results.items():
        print(tag, result['passes'], '/', result['total'], 'first fraction', result['prefixes'][0]['signed'])


if __name__ == '__main__':
    receipt('interior')
    try:
        main()
    finally:
        finish('interior')
