import csv
import math
from decimal import localcontext
from matched import ROOT,PREV,bank,np,require,as_decimal,receipt,finish,guard
from response import densities,slip


TAGS=('scale32','scale64','log64','smooth64')


def peak(array):
    return float(np.max(np.abs(array)))


def tiny_difference(high,low,other_high,other_low):
    return (high-other_high)+(low-other_low)


def sample_case(case):
    with np.load(ROOT/f'{case}-prepared.npz') as data:
        query,saved,smooth_hi,smooth_lo,represented,params=(data[key] for key in ('query','source_time','smooth_high','smooth_low','represented','constants'))
    trajectories={}
    for tag in TAGS:
        with np.load(ROOT/f'{case}-{tag}.npz') as data:
            require(np.array_equal(data['time'],query),'identical queries for each refinement')
            trajectories[tag]=data['high'],data['low']
    idx=np.searchsorted(query,saved)
    require(np.array_equal(query[idx],saved),'all saved epochs')
    clock={}
    fractions={}
    for tag,(high,low) in trajectories.items():
        fractions[tag]=dict(smooth=tiny_difference(high[:,0],low[:,0],smooth_hi[:,0],smooth_lo[:,0])/smooth_hi[:,0],
                            binary=tiny_difference(high[:,0],low[:,0],represented[:,0],0)/represented[:,0])
    label='cold_baseline' if case=='cold' else 'heavy_parent'
    with np.load(bank.source_path(label,32)) as low,np.load(bank.source_path(label,64)) as high:
        old_lo,old_hi=low['alpha'],high['alpha']
    for convention in ('binary','smooth'):
        ref=fractions['log64'][convention][idx]
        scale=peak(ref)
        clock[convention]=dict(peak_alpha=scale,first=ref[0],last=ref[-1],
               order8_step_halving=peak((fractions['scale32'][convention]-fractions['scale64'][convention])[idx])/scale,
               coordinate_and_order=peak((fractions['scale64'][convention]-fractions['log64'][convention])[idx])/scale,
               alternative_initialization=peak((fractions['smooth64'][convention]-fractions['log64'][convention])[idx])/scale,
               old32_difference=peak(ref-old_lo)/scale,old64_difference=peak(ref-old_hi)/scale,
               old32_first=old_lo[0],old64_first=old_hi[0])
    clock['smooth_vs_binary_peak_difference_fraction']=peak((fractions['log64']['binary']-fractions['log64']['smooth'])[idx])/peak(fractions['log64']['smooth'][idx])
    require(fractions['log64']['binary'][0]==0 and fractions['smooth64']['smooth'][0]==0,'separate matched anchor conventions')
    with (ROOT/f'{case}-matched-alpha.npz').open('xb') as stream:
        np.savez_compressed(stream,time=query,**{tag+'_'+key:values for tag,keys in fractions.items() for key,values in keys.items()})
    return clock,query,trajectories,params


def readouts(steps,case,mode,cell,query,trajectories,constants):
    label=f'{case}-{steps}-{mode}-{cell}'
    with np.load(PREV/f'isolated/{label}-reference.npz') as ref,np.load(PREV/f'isolated/{label}-prediction.npz') as pred,np.load(ROOT/f'matter/{label}.npz') as dynamic:
        t=ref['time']
        require(np.array_equal(dynamic['time'],t) and np.array_equal(t,pred['time']),'original source grid')
        forces,gauss,metric=ref['forces'],ref['integrals'],ref['metric']
        native=pred['primitive'][:,0]
        raw=dynamic['primitive']
        wave=float(dynamic['wave'])
    positions=np.searchsorted(query,t)
    require(np.array_equal(query[positions],t),'off-grid values are genuine output')
    params=list(map(as_decimal,constants))
    outcomes={}
    tables={}
    rates={}
    scale=np.r_[np.maximum(abs(forces[0,-2:]),abs(forces[-1,-2:])),abs(gauss[-1])]
    target=np.r_[forces[-1,-2:],gauss[-1]]
    shape=len(native[0])
    with localcontext() as ctx:
        ctx.prec=58
        h0=[(sum(densities(params,list(map(as_decimal,point))))/3).sqrt() for point in native]
        for tag,(high,low) in trajectories.items():
            exact_rates=[]
            alpha=[]
            for pos,base,old_rate in zip(positions,native,h0):
                state=[as_decimal(one)+as_decimal(two) for one,two in zip(high[pos,:shape],low[pos,:shape])]
                rate=as_decimal(high[pos,5])+as_decimal(low[pos,5])
                replay=(sum(densities(params,state))/3).sqrt()
                require(abs(rate/replay-1)<as_decimal(1e-27),'quad H versus independent species')
                alpha.append(float((state[0]-as_decimal(base[0]))/as_decimal(base[0])))
                exact_rates.append(float(rate-old_rate))
            alpha=np.array(alpha)
            delta_h=np.asarray(exact_rates)
            force=forces[:,:9].copy()
            baryon,delta,velocity,change,cs2,_=raw.T
            force[:,1]=-high[positions,5]*change
            force[:,2]=-delta_h*velocity
            force[:,3]=wave*cs2*(delta-alpha*baryon)/(1+alpha)
            force[:,8]=alpha
            tables[tag]=force
            rates[tag]=delta_h
    tables['archived']=forces[:,:9].copy()
    tags=list(tables)
    packet=np.array([tables[tag] for tag in tags])
    result=slip.propagate(packet,*forces[0,-2:],t[-1]-t[0],2)
    middle=slip.propagate(packet,*forces[0,-2:],t[-1]-t[0],1)
    coarse=slip.propagate(packet[:,::2,:],*forces[0,-2:],t[-1]-t[0],2)
    for row,tag in enumerate(tags):
        budget=abs(middle[row]-result[row])+abs(coarse[row]-result[row])
        budget[2]+=sum(abs(np.diff(gauss)))
        outcomes[tag]=dict(value=result[row],budget=budget)
    with (ROOT/f'{label}-conditional.npz').open('xb') as stream:
        np.savez_compressed(stream,time=t,tags=tags,rate_tags=list(rates),delta_H=np.array(list(rates.values())),forces=packet,initial=forces[0,-2:],reference=target,
            reference_scale=scale,integrated=result,diagnostic_allowance=np.array([outcomes[tag]['budget'] for tag in tags]))
    return dict(outcomes=outcomes,scale=scale,target=target,initial=forces[0,-2:],width=t[-1]-t[0],rates=rates,tables=tables)


def compare(case,mode,cell,query,trajectories,params):
    low,high=(readouts(steps,case,mode,cell,query,trajectories,params) for steps in (32,64))
    require(low['width']==high['width'],'paired intervals')
    oldscale=high['scale']
    actual=high['target']
    oracle=high['outcomes']['log64']['value']
    ownscale=np.r_[oldscale[:2],abs(oracle[2])]
    delta_h=high['rates']['log64']
    hscale=peak(delta_h)
    geometry=(peak(low['rates']['scale32']-high['rates']['scale64'])+peak(delta_h-high['rates']['scale64']))/hscale
    coarse=low['outcomes']['scale32']
    fine=high['outcomes']['scale64']
    exact=high['outcomes']['log64']
    numerical=coarse['budget']+fine['budget']+exact['budget']+abs(coarse['value']-fine['value'])+abs(fine['value']-exact['value'])
    native_gap=abs(low['target']-actual)+abs(coarse['value']-low['target'])+abs(oracle-actual)
    old_reference=(numerical+native_gap)/oldscale
    clock_only=peak(high['rates']['smooth64']-delta_h)/hscale
    starts=[side['initial'] for side in (low,high)]
    inputs=np.asarray([side['tables']['log64'] for side in (low,high)])
    values=np.array([slip.propagate(inputs,*start,high['width'],2)[:,2] for start in starts])
    spread=values[0,0]-values[1,1]
    seed_part=((values[0,1]-values[1,1])+(values[0,0]-values[1,0]))/2
    force_part=((values[1,0]-values[1,1])+(values[0,0]-values[0,1]))/2
    require(abs(seed_part+force_part-spread)<=bank.ALG*abs(oracle[2]),'conditional seed/forcing finite split')
    old=high['outcomes']['archived']['value'][2]
    return dict(branch=case+'_'+mode,cell=cell,H_peak=hscale,H_budget=geometry,H_pass=geometry<=bank.TOL,
           H_initial_convention=clock_only,corrected_source=float(oracle[2]),original_direct=actual[2],
           replaced_minus_archived_same_scalar=(oracle[2]-old)/abs(actual[2]),corrected_vs_direct=(oracle[2]-actual[2])/abs(actual[2]),
           corrected_source_working=numerical[2]/ownscale[2],corrected_slip_working=max(numerical[:2]/ownscale[:2]),native_comparison_budget=old_reference[2],
           source_pass=bool(max(numerical/ownscale)<=bank.TOL),native_reference_pass=bool(max(old_reference)<=bank.TOL),
           source_initial_convention=(high['outcomes']['smooth64']['value'][2]-oracle[2])/abs(oracle[2]),
           same_clock_32minus64=spread/abs(oracle[2]),inherited_matter_contribution=seed_part/abs(oracle[2]),inside_forcing_contribution=force_part/abs(oracle[2]))


def main():
    guard()
    clocks={}
    results=[]
    for case in ('cold','heavy'):
        clocks[case],query,trajectories,params=sample_case(case)
        for mode in (('baseline',) if case=='cold' else ('parent','approximate')):
            for cell in bank.read(ROOT/f'{case}-input.json')['cells']:
                results.append(compare(case,mode,cell,query,trajectories,params))
    bank.save(ROOT/'clock-precision.json',clocks)
    with (ROOT/'radiation-comparison.csv').open('x',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=results[0])
        writer.writeheader()
        writer.writerows(results)
    for row in results:
        print(row['branch'],row['cell'],row['H_budget'],row['corrected_source_working'],row['native_comparison_budget'],row['inherited_matter_contribution'],row['inside_forcing_contribution'])


if __name__=='__main__':
    receipt('comparison')
    try:
        main()
    finally:
        finish('comparison')
