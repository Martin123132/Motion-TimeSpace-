import csv
import math
from pathlib import Path
from scipy.integrate import cumulative_simpson,cumulative_trapezoid,simpson
from matched import ROOT,POST,bank,np,require,receipt,finish,guard
from response import slip


def coefficients(opacity,weight,alpha):
    inverse=1/(1+alpha)
    return opacity*(1+weight),opacity*inverse**2*(1+weight*inverse),-opacity*alpha*inverse*(1+inverse+weight*(1+inverse+inverse**2))


def drag_history(case,mode,steps,times,scale,scale_low):
    config=bank.read(bank.SOURCE/'protocol.json')
    frozen=bank.read(bank.SOURCE/'inputs.json')
    names=bank.read(POST/'mts-coupled-metric-consistency-20261117/packet-schema.json')['global_columns']
    cols=[84+names.index(key) for key in ('scale','opacity')]
    offset=0
    chunks=[]
    for dirname in config['directories']:
        guard()
        path=Path(dirname)/f'{case}-{steps}.npz'
        require(bank.digest(path)==frozen[str(path)],'unchanged metric sources')
        with np.load(path) as saved:
            packet=saved['parent_metric' if mode=='parent' else 'metric'][:,0,:]
            local=saved['time']
        require(np.array_equal(local,times[offset:offset+len(local)]),'opacity clock')
        native,opacity=packet[:,cols].T
        alpha=((scale[offset:offset+len(local)]-native)+scale_low[offset:offset+len(local)])/native
        vals=np.column_stack(coefficients(opacity,(4/3)*packet[:,24]/packet[:,12],alpha))
        require(np.all(vals[:,:2]>0),'positive drag')
        if chunks:
            require(np.array_equal(chunks[-1][-1],vals[0]),'same drag at join')
            vals=vals[1:]
        chunks.append(vals)
        offset+=len(local)-1
    require(offset+1==len(times),'coverage')
    return np.concatenate(chunks)


def cell_shift(table,initial,swap,width,subdiv):
    num=(len(table)-1)*subdiv
    time=np.linspace(0,width,num+1)
    fraction=np.arange(num+1)/subdiv
    dense=np.stack([np.interp(fraction,np.arange(len(table)),column) for column in table.T],axis=1)
    original=initial.copy()
    states=[original.copy()]
    def rhs(source,values):
        old,delta=values
        L0,L1,DL=coefficients(*source[6:9])
        return np.array([source[0]-L0*old,math.fsum(source[1:6])-DL*old-L1*delta])
    step=width/num
    for start,end in zip(dense[:-1],dense[1:]):
        mid=(start+end)*.5
        first=rhs(start,original)
        second=rhs(mid,original+step*first/2)
        third=rhs(mid,original+step*second/2)
        fourth=rhs(end,original+step*third)
        original=original+step*(first+2*second+2*third+fourth)/6
        states.append(original)
    old,change=np.array(states).T
    opacity,weight,alpha=dense[:,6:9].T
    L0,L1,DL=coefficients(opacity,weight,alpha)
    depth0,depth1,ddepth=(cumulative_simpson(value,x=time,initial=0) for value in (L0,L1,DL))
    shift_old=swap[0]*np.exp(-depth0)
    shift_change=swap[1]*np.exp(-depth1)+shift_old*np.expm1(-ddepth)
    inverse=1/(1+alpha)
    energy=(4/3)*opacity*inverse**2*(-alpha*(2+alpha)*shift_old*(2*old+shift_old)+
            2*shift_change*(old+change+shift_old)+2*shift_old*change+shift_change**2)
    return float(simpson(energy,x=time)),float(depth1[-1])


def main():
    records={}
    for case,mode in [('cold','baseline'),('heavy','parent'),('heavy','approximate')]:
        label=case+'_'+mode
        with np.load(ROOT/f'{case}-prepared.npz') as data,np.load(ROOT/f'{case}-log64.npz') as trajectory:
            times=data['source_time']
            mask=np.searchsorted(trajectory['time'],times)
            high,low=trajectory['high'][mask,0],trajectory['low'][mask,0]
        raw=[]
        integrals=[]
        for steps in (32,64):
            with np.load(bank.source_path(label,steps)) as data:
                raw.append(np.column_stack((data['slip'],data['slip_change'])))
            laws=drag_history(case,mode,steps,times,high,low)
            depths=cumulative_simpson(laws,x=times,axis=0,initial=0)
            trap=cumulative_trapezoid(laws,x=times,axis=0,initial=0)
            integrals.append((depths,trap))
        left=raw[0][0]-raw[1][0]
        depth=integrals[1][0]
        depths=depth[:,1]
        hits=np.flatnonzero(depths>=-math.log(bank.TOL))
        record=dict(final_depth=depths[-1],direct_amplitude_retained=np.exp(-depths[-1]),
            first_below_tolerance_index=int(hits[0]) if len(hits) else None,first_below_tolerance_time=times[hits[0]] if len(hits) else None,
            max_abs_depth_disagreement=max(np.max(abs(depths-local[:,1])) for group in integrals for local in group),cells={})
        for cell in bank.read(ROOT/f'{case}-input.json')['cells']:
            trials=[]
            native_swap=raw[0][cell]-raw[1][cell]
            require(native_swap[1]!=0,'nonzero slip discrepancy')
            inherited=[]
            for steps,group in zip((32,64),integrals):
                for variant in group:
                    old_depth,coherent_depth,delta_depth=variant[cell]
                    inherited.append(left[1]*np.exp(-coherent_depth)+left[0]*np.exp(-old_depth)*np.expm1(-delta_depth))
                with np.load(ROOT/f'{case}-{steps}-{mode}-{cell}-conditional.npz') as data:
                    table=data['forces'][list(data['tags']).index('log64')]
                    width=data['time'][-1]-data['time'][0]
                    require(np.array_equal(data['initial'],raw[0 if steps==32 else 1][cell]),'correct cell left states')
                starts=np.array([item[cell] for item in raw])
                direct=[slip.propagate(table[None,:,:],*value,width,2)[0,2] for value in starts]
                changed=direct[0]-direct[1]
                gain,tau=cell_shift(table,starts[1],native_swap,width,4)
                test,_=cell_shift(table,starts[1],native_swap,width,2)
                require(changed!=0,'nonzero measured seed effect')
                trials.append(dict(steps=steps,cell_depth=tau,shift=gain,swap=changed,relative_difference=(abs(gain-changed)+abs(gain-test))/abs(changed)))
            record['cells'][str(cell)]=dict(depth=float(depths[cell]),native_left_delta_slip_difference=native_swap[1],
                 strongest_direct_survivor_fraction=max(abs(value) for value in inherited)/abs(native_swap[1]),analytic_checks=trials)
        records[label]=record
    bank.save(ROOT/'drag-memory.json',records)
    for label,rec in records.items():
        print(label,rec['final_depth'],rec['first_below_tolerance_index'],[(key,cell['strongest_direct_survivor_fraction'],max(trial['relative_difference'] for trial in cell['analytic_checks'])) for key,cell in rec['cells'].items()])


if __name__=='__main__':
    receipt('memory')
    try:
        main()
    finally:
        finish('memory')
