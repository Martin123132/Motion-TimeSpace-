import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PREV=POST/'mts-friedmann-expansion-response-20261117'
sys.path.insert(0,str(PREV))
from response import bank,np,require,branch_state
from scipy.integrate import solve_ivp


def guard():
    bank.guard()
    require(not (ROOT/'STOP-REQUESTED').exists(),'owner hold')


def main(case,steps):
    guard()
    bank.check_seals()
    out=ROOT/'matter'
    bank.ROOT=out
    tag=f'{case}-{steps}'
    cells=bank.read(ROOT/f'{case}-input.json')['cells']
    with np.load(ROOT/f'{case}-prepared.npz') as data:
        times=data['source_time']
    pairs=bank.selected_rows(case,steps,set(cells),times)
    live,context=bank.native_setup(case,steps,tag)
    with context as (capture,meta,sample):
        original=live.load(Path(live.CONFIG['capture_authority'])/(case+'-preflight-capture.npz'))
        require(all(np.array_equal(value,original[key]) for key,value in capture.items()),'identical original native capture')
        prepared,_,back,_,_=live.EX.problem(case)
        for cell in cells:
            guard()
            states,path=pairs[cell]
            direct=live.MetricCoupled(case,prepared,back,live.prefix(capture,case),meta,sample)
            system=None
            if case=='heavy':
                system=live.worklib.Carried(direct,live.worklib.LiveSecond(case,prepared,back,live.prefix(capture,case),meta,sample))
                if bank.BUDGET in path.parents or 'photon-difference-replay-v2' in path.parts:
                    live.operator_repair.install(system)
            bounds=times[cell:cell+2]
            solution=solve_ivp(system.rhs if system else direct.rhs,tuple(bounds),states[0].copy(),method='DOP853',rtol=live.CONFIG['rtol'],
                        atol=live.CONFIG['normalized_atol'],max_step=float(prepared['elapsed'][8])/steps,dense_output=True)
            require(solution.success and np.array_equal(solution.y[:,-1],states[1]),'same full native state')
            for mode in (('baseline',) if case=='cold' else ('parent','approximate')):
                label=f'{case}-{steps}-{mode}-{cell}'
                with np.load(PREV/f'isolated/{label}-reference.npz') as ref:
                    grid=ref['time']
                    force=ref['forces']
                rows=[]
                for moment,state in zip(grid,solution.sol(grid).T):
                    old,change,physical,_,_=branch_state(direct,system,state,mode)
                    cs2=sample(float(moment),old,np.zeros(5),False)[2][1]
                    rows.append([old[2],change[2],old[3],change[3],cs2,physical[0]])
                rows=np.array(rows)
                baryon,delta,_,_,cs2,alpha=rows.T
                replay=float(prepared['wave'][0])*cs2*(delta-alpha*baryon)/(1+alpha)
                require(np.max(abs(replay-force[:,3]))<=bank.ALG*np.max(abs(force[:,3])),'original baryon pressure re-read')
                with (out/(label+'.npz')).open('xb') as stream:
                    np.savez_compressed(stream,time=grid,primitive=rows,wave=prepared['wave'][0],columns=['b0','db','v0','dv','cs2','alpha'])


if __name__=='__main__':
    case=sys.argv[1]
    steps=int(sys.argv[2])
    require(case in ('cold','heavy') and steps in (32,64),'physical pair')
    (ROOT/'matter').mkdir(exist_ok=True)
    tag=f'matter-v2-{case}-{steps}'
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/(tag+'-start.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    try:
        main(case,steps)
    finally:
        bank.save(ROOT/(tag+'-end.json'),dict(time=bank.datetime.now(bank.timezone.utc).isoformat()))
