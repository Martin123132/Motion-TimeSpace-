import csv
from decimal import Decimal, localcontext
from pathlib import Path
from matched import ROOT, PREV, bank, np, guard, receipt, finish, require, control, library


def clock_checks(case, count):
    spec = bank.read(ROOT / (case + '-input.json'))
    for name, expected in spec['files'].items():
        require(bank.digest(Path(name)) == expected, 'changed physical dependency: ' + name)
    with np.load(ROOT / (case + '-prepared.npz')) as prepared, np.load(ROOT / (case + '-matched-alpha.npz')) as alpha:
        query = prepared['query']
        original = prepared['source_time']
        with np.load(bank.source_path('cold_baseline' if case == 'cold' else 'heavy_parent', 64)) as source:
            require(np.array_equal(original, source['time']), 'source times changed')
        require(len(original) == count and original[0] > query[0] == spec['anchor'], 'actual earlier anchor')
        require(np.all(np.diff(query) > 0) and np.array_equal(query, prepared['grid'][prepared['query_on_grid']]), 'clock queries')
        require(np.array_equal(query, alpha['time']) and alpha['log64_binary'][0] == 0, 'matched perturbation')
        require(np.array_equal(query[np.searchsorted(query, original)], original), 'complete saved history')
        for tag in ('scale32', 'scale64', 'log64', 'smooth64'):
            with np.load(ROOT / f'{case}-{tag}.npz') as data:
                require(np.array_equal(query, data['time']), 'trajectory sample times')
                high, low = data['high'], data['low']
                require(high.shape == low.shape == (len(query), 6) and np.isfinite(high).all() and np.isfinite(low).all(), 'finite states')
                require(np.all(high[:, 0] > 0) and np.all(high[:, 5] > 0), 'expanding positive branch')
                with localcontext() as ctx:
                    ctx.prec = 65
                    for index in np.unique(np.r_[0, np.searchsorted(query, original[[0, count//2, -1]])]):
                        old = Decimal.from_float(prepared['represented'][index, 0])
                        current = Decimal.from_float(high[index, 0]) + Decimal.from_float(low[index, 0])
                        exact = float((current - old) / old)
                        reading = alpha[tag + '_binary'][index]
                        require(abs(reading - exact) <= 2e-16 * abs(exact) + 1e-60, 'finite scale directly from physical words')
    return spec['cells']


def verify():
    guard()
    require(not (ROOT/'closeout.json').exists(), 'never replace a seal')
    bank.check_seals()
    named = bank.read(PREV / 'closeout.json')['files']
    require(bank.digest(PREV/'closeout.json') == '837f28a25057131d541f0ec41db6d259c5e60e818ebfdad2d3aa074429766647', 'retained previous seal')
    require({path.relative_to(PREV).as_posix() for path in PREV.rglob('*') if path.is_file() and path != PREV/'closeout.json'} == {Path(key).as_posix() for key in named}, 'previous exact inventory')
    for key, value in named.items():
        path = PREV / key
        require(path.stat().st_size == value['bytes'] and bank.digest(path) == value['sha256'], 'previous artifact changed: '+key)
    original = bank.read(bank.SOURCE/'inputs.json')
    for key, expected in original.items():
        require(bank.digest(Path(key)) == expected, 'source manifest input changed: '+key)
    manufactured = control(library())
    require(max(manufactured) < 6e-33, 'independent analytic native control rerun')
    cells = {case: clock_checks(case, count) for case, count in [('cold', 3615), ('heavy', 7855)]}
    with (ROOT / 'radiation-comparison.csv').open(newline='') as stream:
        radiation = {(row['branch'], int(row['cell'])): row for row in csv.DictReader(stream)}
    expected = {(label, cell) for label in bank.LABELS for cell in cells[label.split('_')[0]]}
    require(set(radiation) == expected, 'all original branch comparisons')
    monopole = bank.read(ROOT/'monopole-result.json')
    momenta = bank.read(ROOT/'two-momenta.json')
    prefixes = bank.read(ROOT/'interior-balance.json')
    summary = {}
    tags = []
    for label in bank.LABELS:
        case, mode = label.split('_')
        energy_passes = partials = total = 0
        for cell in cells[case]:
            key = label + ':' + str(cell)
            row, repaired = radiation[label, cell], monopole[key]
            gate = bank.TOL
            require(float(row['H_budget']) <= gate and row['H_pass'] == 'True', 'matched expansion')
            require((row['source_pass']=='True') == (max(float(row['corrected_source_working']),float(row['corrected_slip_working'])) <= gate), 'own signal gate')
            require(repaired['test_pass'] == (max(repaired['native_budget']) <= gate), 'all finite repaired comparisons')
            require(repaired['integral_reference_pass'] == (repaired['native_budget'][4] <= gate), 'radiation reference budget')
            require(np.isfinite(repaired['native_budget']).all() and min(repaired['native_budget']) >= 0, 'proper allowances')
            require(momenta[label][str(cell)]['max_collision_residual'] <= bank.ALG, 'collision momentum balance')
            energy_passes += int(repaired['integral_reference_pass'])
            for steps in (32,64):
                tag = f'{case}-{steps}-{mode}-{cell}'
                tags.append(tag)
                with np.load(ROOT/(tag+'-conditional.npz')) as packet, np.load(ROOT/'matter'/(tag+'.npz')) as matter, np.load(PREV/'isolated'/(tag+'-reference.npz')) as ref:
                    require(len(ref['time'])==257 and np.array_equal(packet['time'],ref['time']) and np.array_equal(matter['time'],ref['time']), 'same 257 evaluation times')
                    require(np.isfinite(matter['primitive']).all() and np.isfinite(packet['forces']).all() and np.isfinite(packet['integrated']).all(), 'finite response packet')
                records = prefixes[tag]['prefixes']
                require([record['node'] for record in records] == list(range(8,257,8)), 'all interior prefix controls')
                for record in records:
                    require(record['passed'] == (abs(record['signed'])+record['allowance'] <= gate), 'unchanged interior test')
                partials += sum(record['passed'] for record in records)
                total += len(records)
        summary[label] = dict(radiation_passed=energy_passes, cells=len(cells[case]), continuity_passed=partials, nested_probes=total)
    require(len(set(tags)) == len(list(ROOT.glob('*-conditional.npz'))) == 24 and set(prefixes) == set(tags),'complete paired sample')
    require(all(summary[label]['radiation_passed'] == (0 if label=='cold_baseline' else 4) for label in bank.LABELS), 'negative baseline result preserved')
    require(all(summary[label]['continuity_passed'] == (0 if label=='cold_baseline' else 256) for label in bank.LABELS), 'continuity findings reproducible')
    releases = sorted((ROOT/'matter').glob('*-owner-release.json'))
    require(len(releases) == 4 and all(bank.read(path)==dict(cleared=True,native_reference_released=True) for path in releases),'four native releases')
    bank.save(ROOT/'verification.json',dict(previous_verified=len(named),physical_inputs_verified=len(original),matched_probes=len(tags),
              source_knots_unchanged=True,quadrature_dust_radiation=manufactured,original_tolerance=gate,results=summary,native_releases=len(releases)))


def seal():
    guard()
    require((ROOT/'verification.json').is_file() and not (ROOT/'closeout.json').exists(),'verified new stage')
    owners = []
    for path in sorted(ROOT.glob('*-start.json')):
        name = path.name[:-11]
        process = bank.read(path)
        require(path.with_name(name+'-end.json').is_file(),'missing process end: '+name)
        try:
            alive = bank.psutil.Process(process['pid'])
            require(abs(alive.create_time()-process['created']) > .01, 'earlier stage owner still running: '+name)
        except bank.psutil.NoSuchProcess:
            pass
        owners.append(dict(tag=name,pid=process['pid'],created=process['created'],command=process['command'],original_process_exited=True))
    require(not list(ROOT.rglob('__pycache__')), 'no runtime cache')
    closer = bank.psutil.Process()
    bank.save(ROOT/'cleanup.json',dict(workers=owners,closer=dict(pid=closer.pid,created=closer.create_time(),command=closer.cmdline()),
              native_releases=4,early_matter_import_failure='matter-cold-32; superseded by scoped v2 captures',temporary_build_alias='removed',processes_killed=0))
    files = {path.relative_to(ROOT).as_posix():dict(bytes=path.stat().st_size,sha256=bank.digest(path)) for path in sorted(ROOT.rglob('*')) if path.is_file()}
    bank.save(ROOT/'closeout.json',dict(finished=bank.datetime.now(bank.timezone.utc).isoformat(), files=files,
              scope='Matched clock and conditional radiation probes; physical restart remains 4252.'))
    print(len(files), 'artifacts;',len(owners),'recorded workers exited; closer', closer.pid, flush=True)


if __name__ == '__main__':
    import sys
    if sys.argv[1:] == ['verify']:
        receipt('verify')
        try:
            verify()
        finally:
            finish('verify')
    elif sys.argv[1:] == ['seal']:
        seal()
    else:
        raise SystemExit('choose verify or seal')
