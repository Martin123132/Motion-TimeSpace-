import math
from scipy.integrate import cumulative_simpson,simpson
from matched import ROOT,PREV,bank,np,receipt,finish,guard,require
from memory import coefficients


def measure(times,force,observed,stride):
    times=times[::stride]-times[0]
    force=force[::stride]
    observed=observed[::stride]
    L0,L1,DL=coefficients(*force[:,6:9].T)
    depth=cumulative_simpson(L1,x=times,initial=0)
    weight=np.exp(depth-depth[-1])
    slip,change=observed.T
    driving=np.column_stack((force[:,1:6],-DL*slip))
    amounts=simpson(weight[:,None]*driving,x=times,axis=0)
    required=math.fsum([change[-1],-change[0],-math.expm1(-depth[-1])*change[0]])
    inherited=math.exp(-depth[-1])*change[0]
    return np.r_[required,inherited,amounts]


def main():
    guard()
    results={}
    for label in bank.LABELS:
        case,mode=label.split('_')
        for cell in bank.read(ROOT/f'{case}-input.json')['cells']:
            history={}
            for steps in (32,64):
                tag=f'{case}-{steps}-{mode}-{cell}'
                with np.load(PREV/f'isolated/{tag}-reference.npz') as ref,np.load(ROOT/(tag+'-conditional.npz')) as physical:
                    times=ref['time']
                    observed=ref['forces'][:,-2:]
                    for law in ['archived','log64']:
                        table=physical['forces'][physical['tags'].tolist().index(law)]
                        history[steps,law]=[measure(times,table,observed,check) for check in (4,2,1)],observed[:,1].copy()
            for law in ('archived','log64'):
                left,right=(history[steps,law] for steps in (32,64))
                resolution_signal=np.max(abs(left[1]-right[1]))
                physical_signal=np.max(abs(right[1]))
                require(resolution_signal>0 and physical_signal>0,'nonzero signal')
                paired=np.array(left[0])-np.array(right[0])
                required=paired[-1,0]
                amounts=paired[-1,2:]
                residual=required-math.fsum(amounts)
                local=np.sum(abs(np.diff(paired[:,np.r_[0,2:8]],axis=0)))
                fine=right[0][-1]
                own=fine[0]-math.fsum(fine[2:])
                results[f'{label}:{cell}:{law}']=dict(component_order=['expansion_dv','delta_expansion_v','pressure','photon_density','quadrupole','inertia_change'],
                    required_new_32minus64=required,component_integrals=amounts.tolist(),unaccounted=residual,
                    scale_observed_resolution=resolution_signal,scale_physical_response=physical_signal,paired_quadrature_allowance=local,
                    paired_mismatch_over_resolution=abs(residual)/resolution_signal,
                    quadrature_over_resolution=local/resolution_signal,own_mismatch_over_physical=abs(own)/physical_signal,
                    discrepancy_larger_than_quadrature=bool(abs(residual)>local),required_over_resolution=required/resolution_signal)
    bank.save(ROOT/'drive-balance.json',results)
    for key,row in results.items():
        if key.endswith('archived'):
            print(key,row['required_over_resolution'],row['paired_mismatch_over_resolution'],row['quadrature_over_resolution'],row['own_mismatch_over_physical'])


if __name__=='__main__':
    receipt('drive')
    try:
        main()
    finally:
        finish('drive')
