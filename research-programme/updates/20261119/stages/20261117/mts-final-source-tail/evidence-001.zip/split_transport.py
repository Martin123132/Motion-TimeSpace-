from repair_completion import *
from fractions import Fraction

OUTPUT=ORIGINAL/"split-defect-transport"


def background_rhs(direct,clock,normalized):
    base=direct.model.represented(clock)
    physical=normalized*direct.background_units
    alpha,fields,velocities=direct.model.unpack(physical)
    difference=direct.model.difference_flow(base,physical,False)
    field_defect=base["field_first"]-base["velocity"]
    velocity_defect=base["velocity_first"]+2*base["hubble"]*base["velocity"]+base["mass"]*base["field"]
    derivative=direct.model.pack(difference[0]/base["scale"]-base["rate"]*alpha+base["hubble"]-base["rate"],
        difference[1::2]-field_defect,difference[2::2]-velocity_defect)/direct.background_units
    packet=np.zeros(5)
    packet[:direct.width]=direct.model.pack(base["scale"]*(1+alpha),base["field"]+fields,base["velocity"]+velocities)
    return derivative,packet


def run():
    repair_inputs()
    require(read(REPLAY/"verification.json")["passed"],"verified unchanged replay input")
    require(not OUTPUT.exists(),"new independent defect transport")
    OUTPUT.mkdir()
    manifest={str(Path(__file__)):digest(Path(__file__)),str(ORIGINAL/"SPLIT-DEFECT-TRANSPORT.md"):digest(ORIGINAL/"SPLIT-DEFECT-TRANSPORT.md")}
    for steps in CONFIG["steps"]:
        for directory in (AUTHORITY/"epoch3940",destination(4249)):
            for suffix in (".npz","-terminal.npz"):
                path=directory/("heavy-"+str(steps)+suffix)
                manifest[str(path)]=digest(path)
    save(OUTPUT/"inputs.json",manifest)
    checks={}
    reports={}
    saved_arrays={}
    with context()("heavy","split-defect-owner") as (captured,metadata,sample):
        for seed_steps in CONFIG["steps"]:
            direct,system,saved=original.build("heavy",4249,seed_steps,captured,metadata,sample)
            repair.install(system)
            data=load(destination(4249)/("heavy-"+str(seed_steps)+".npz"))
            observed=data["split_state_residual"]
            parent=system.core.unpack(saved["normalized"][:system.core_size])[1]
            initial_background=parent[2*direct.active:2*direct.active+direct.width]
            initial=np.r_[initial_background,observed[0]]
            checks[str(seed_steps)+"_initial_defect_exact"]=np.array_equal(observed[0],saved["normalized"][system.core_size-system.pair_size:system.core_size]-saved["normalized"][system.core_size:system.core_size+system.pair_size]-saved["normalized"][system.core_size+system.pair_size:system.core_size+2*system.pair_size])
            for position in np.unique(np.linspace(0,len(data["time"])-1,9,dtype=int)):
                native=system.core.unpack(data["extended"][position,:system.core_size])[1]
                clock=float(data["time"][position])
                normalized=native[2*direct.active:2*direct.active+direct.width]
                derivative,packet=background_rhs(direct,clock,normalized)
                expected=direct.evaluate(clock,native)[0][2*direct.active:2*direct.active+direct.width]
                checks[str(seed_steps)+"_"+str(position)+"_background_rhs_exact"]=np.array_equal(derivative,expected)
            def rhs(clock,state):
                derivative,packet=background_rhs(direct,clock,state[:direct.width])
                return np.r_[derivative,system.linear_rhs(clock,state[direct.width:],packet)]
            for solve_steps in CONFIG["steps"]:
                current=initial.copy()
                states=[current.copy()]
                count=0
                for position,(left,right) in enumerate(zip(data["time"][:-1],data["time"][1:])):
                    guard()
                    solution=solve_ivp(rhs,(float(left),float(right)),current,method="DOP853",rtol=CONFIG["rtol"],atol=CONFIG["normalized_atol"],
                        max_step=float(direct.prepared["elapsed"][8])/solve_steps)
                    require(solution.success,"independent homogeneous defect evolution")
                    current=solution.y[:,-1]
                    count+=solution.nfev
                    states.append(current.copy())
                    if (position+1)%256==0:
                        print(json.dumps({"seed":seed_steps,"steps":solve_steps,"boundary":position+1,"total":len(data["time"])-1}),flush=True)
                states=np.asarray(states)
                predicted=states[:,direct.width:]
                background=data["extended"][:,2*direct.active:2*direct.active+direct.width]
                residual=observed-predicted
                scale=read(REPLAY/"epoch4249-physics.json")["split_state"]["scale"]
                key="seed"+str(seed_steps)+"-steps"+str(solve_steps)
                checks[key+"_initial_state_exact"]=np.array_equal(states[0],initial)
                checks[key+"_background_agreement"]=ratio(maximum(states[:,:direct.width]-background),maximum(background))["passed"]
                checks[key+"_finite"]=bool(np.isfinite(states).all())
                reports[key]={"evaluations":count,"initial_defect":maximum(observed[0]),"observed_max":maximum(observed),
                    "predicted_inherited_max":maximum(predicted),"unaccounted_max":maximum(residual),
                    "unaccounted_relative_to_original_gate":ratio(maximum(residual),scale,CONFIG["algebra_tolerance"]),
                    "background_agreement":ratio(maximum(states[:,:direct.width]-background),maximum(background)),
                    "observed_final_peak_component":int(np.argmax(abs(observed[-1]))),
                    "inherited_at_observed_final_peak":float(predicted[-1,np.argmax(abs(observed[-1]))]),
                    "observed_at_final_peak":float(observed[-1,np.argmax(abs(observed[-1]))])}
                np.savez_compressed(OUTPUT/(key+".npz"),time=data["time"],evolved=states,predicted=predicted,observed=observed,residual=residual)
                saved_arrays[key]=states
            refined=saved_arrays["seed"+str(seed_steps)+"-steps64"]
            coarse=saved_arrays["seed"+str(seed_steps)+"-steps32"]
            reports["seed"+str(seed_steps)+"_same_seed_refinement"]=ratio(maximum(refined[:,direct.width:]-coarse[:,direct.width:]),maximum(refined[:,direct.width:]))
    checks["owner_released"]=read(REPLAY/"split-defect-owner-owner-release.json")["cleared"]
    check_inputs(manifest)
    result={"checks":checks,"technical_pass":all(checks.values()),"reports":reports,
        "original_gate_remains_false":not read(ORIGINAL/"epoch4249-gate.json")["passed"],
        "repaired_raw_gate_remains_false":not read(REPLAY/"epoch4249-gate.json")["passed"],
        "scope":"Independent propagation of carried nonzero d=e-h-f; not a reset, modified acceptance gate, new physical evolution or certified continuum bound",
        "same_seed_refinement_required":True,"baseline":"Original cold physical controls reused unchanged; this heavy auxiliary partition has no cold analogue"}
    save(OUTPUT/"result.json",result)
    repair_inputs()
    print(json.dumps(result),flush=True)
    require(result["technical_pass"],"independent defect transport checks")


if __name__=="__main__":
    with worker("split-defect-transport"):
        run()

