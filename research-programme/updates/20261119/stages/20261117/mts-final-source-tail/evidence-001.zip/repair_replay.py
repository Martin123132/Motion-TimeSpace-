from live_work import *
import live_work as original
import score_live as scoring
import operator_repair as repair
import types
import inspect
import textwrap
import shutil

REPLAY=ROOT/"photon-difference-replay"
ORIGINAL=ROOT
IGNORED_DIAGNOSTICS=("split_rhs_residual","split_rhs_scale")


def repair_inputs():
    inputs()
    check_inputs(read(ORIGINAL/"repair-contract.json")["sources"])
    check_inputs(read(REPLAY/"inputs.json"))
    require(read(ORIGINAL/"repair-probe-result.json")["passed"],"saved-state analytic preflight passed")
    require(not (REPLAY/"STOP-REQUESTED").exists(),"repair owner hold")


def destination(epoch):
    require(epoch==4249,"only diagnosed interval may replay")
    return REPLAY/"epoch4249"


def restored(case,epoch,steps,captured,metadata,sample):
    direct,system,saved=original.build(case,epoch,steps,captured,metadata,sample)
    if system:
        before=system.calculate(float(saved["tau"]),saved["normalized"],True)
        repair.install(system)
        after=system.calculate(float(saved["tau"]),saved["normalized"],True)
        require(all(np.array_equal(value,after[1][name]) for name,value in before[1].items() if name not in IGNORED_DIAGNOSTICS),"physical restart readouts exact")
        save(REPLAY/("join-"+str(steps)+".json"),{
            "initial_state_unchanged":True,"original_actual_rhs_verified_first":True,
            "initial_split_state_max":maximum(before[1]["split_state_residual"]),
            "old_split_rhs":before[1]["split_rhs_residual"],"new_split_rhs":after[1]["split_rhs_residual"],
            "old_split_rhs_scale":before[1]["split_rhs_scale"],"new_split_rhs_scale":after[1]["split_rhs_scale"],
            "only_arithmetic_rhs_diagnostics_may_change":list(IGNORED_DIAGNOSTICS)})
    return direct,system,saved


def joined(parts):
    result={name:value.copy() for name,value in parts[0].items()}
    for following in parts[1:]:
        require(set(result)==set(following),"same full replay fields")
        count=len(result["time"])
        require(result["time"][-1]==following["time"][0],"continuous replay clock")
        require(np.array_equal(result["native_control"][-1],following["native_control"][0]),"native boundary exact")
        for name in result:
            if name in ("native_indices","native_control"):continue
            require(len(result[name])==count and len(following[name])==len(following["time"]),"complete time history")
            if name not in IGNORED_DIAGNOSTICS:
                require(np.array_equal(result[name][-1],following[name][0]),"same carried physical history:"+name)
            result[name]=np.concatenate((result[name],following[name][1:]),axis=0)
        result["native_indices"]=np.r_[result["native_indices"],following["native_indices"][1:]+count-1]
        result["native_control"]=np.concatenate((result["native_control"],following["native_control"][1:]),axis=0)
    return result


def history(case,steps,epoch):
    directories=[Path(value) for value in CONFIG["history_directories"]]+[destination(epoch)]
    return joined([load(directory/(case+"-"+str(steps)+".npz")) for directory in directories])


def context():
    original_context=native_context.__wrapped__
    namespace=dict(original_context.__globals__,ROOT=REPLAY)
    changed=types.FunctionType(original_context.__code__,namespace,original_context.__name__,original_context.__defaults__,original_context.__closure__)
    return contextmanager(changed)


def make_runner():
    source=textwrap.dedent(inspect.getsource(original.run))
    old="all(np.array_equal(value,previous[name][-1]) for name,value in initial.items())"
    new="all(np.array_equal(value,previous[name][-1]) for name,value in initial.items() if name not in IGNORED_DIAGNOSTICS)"
    require(source.count(old)==1,"only documented boundary RHS diagnostic adaptation")
    source=source.replace(old,new)
    namespace=dict(original.run.__globals__,ROOT=REPLAY,folder=destination,build=restored,native_context=context(),inputs=repair_inputs,IGNORED_DIAGNOSTICS=IGNORED_DIAGNOSTICS)
    exec(compile(source,str(ORIGINAL/"live_work.py")+":isolated-arithmetic-replay","exec"),namespace)
    return namespace["run"]


def score():
    repair_inputs()
    work_namespace=dict(scoring.work_history.__globals__,ROOT=REPLAY,folder=destination)
    work_function=types.FunctionType(scoring.work_history.__code__,work_namespace)
    namespace=dict(scoring.calculate.__globals__,ROOT=REPLAY,folder=destination,previous_history=history,work_history=work_function)
    calculate=types.FunctionType(scoring.calculate.__code__,namespace)
    results=calculate(4249)
    for name,value in zip(("physics","work","slip","gate"),results):
        save(REPLAY/("epoch4249-"+name+".json"),value)
    comparison={}
    for steps in CONFIG["steps"]:
        previous=load(ORIGINAL/"epoch4249"/("heavy-"+str(steps)+".npz"))
        current=load(destination(4249)/("heavy-"+str(steps)+".npz"))
        require(np.array_equal(previous["time"],current["time"]),"unchanged original and repaired clocks")
        comparison[str(steps)]={}
        for name in ("source","source_change","parent_source","parent_source_change","work","work_change","parent_work","parent_work_change","metric","parent_metric"):
            error=maximum(current[name]-previous[name])
            scale=maximum(previous[name])
            comparison[str(steps)][name]=ratio(error,scale)
    save(REPLAY/"physical-representation-comparison.json",comparison)
    repair_inputs()
    print(json.dumps({"gate":results[-1],"physical_comparison_pass":all(value["passed"] for branch in comparison.values() for value in branch.values())}),flush=True)


def prepare():
    require(not REPLAY.exists(),"new isolated repair output")
    require(read(ORIGINAL/"repair-probe-result.json")["passed"],"probe first")
    REPLAY.mkdir()
    destination(4249).mkdir()
    mapping={str(ORIGINAL/"repair-contract.json"):digest(ORIGINAL/"repair-contract.json"),
             str(ORIGINAL/"repair-probe-result.json"):digest(ORIGINAL/"repair-probe-result.json"),
             str(Path(__file__).resolve()):digest(Path(__file__).resolve())}
    for case in CONFIG["cases"]:
        for name in (case+"-preflight-result.json",):
            shutil.copy2(ORIGINAL/name,REPLAY/name)
            mapping[str(ORIGINAL/name)]=digest(ORIGINAL/name)
            mapping[str(REPLAY/name)]=digest(REPLAY/name)
        source=ORIGINAL/"epoch4249"/(case+"-clock.npz")
        shutil.copy2(source,destination(4249)/source.name)
        mapping[str(source)]=digest(source)
        mapping[str(destination(4249)/source.name)]=digest(source)
    controls=[]
    for source in sorted((ORIGINAL/"epoch4249").glob("cold-*.npz")):
        if "-boundary" in source.name:continue
        shutil.copy2(source,destination(4249)/source.name)
        mapping[str(source)]=digest(source)
        mapping[str(destination(4249)/source.name)]=digest(source)
        controls.append(str(source))
    for path in (ORIGINAL/"epoch4249").glob("heavy-*.npz"):
        if "-boundary" not in path.name:mapping[str(path)]=digest(path)
    save(REPLAY/"contract.json",{"unchanged_baseline_reused":controls,"endpoint":4249,"no_later_epoch_authorized":True,
        "initial_state_authority":str(AUTHORITY/"epoch3940"),"original_failure_preserved":True,
        "changed_only":"84 high-photon/polarization rows of auxiliary error/probes; no physical RHS change",
        "boundary_diagnostic_switch":list(IGNORED_DIAGNOSTICS),"algebra_tolerance":CONFIG["algebra_tolerance"],
        "numerical_tolerance":CONFIG["numerical_tolerance"],"no_initial_error_reset":True})
    mapping[str(REPLAY/"contract.json")]=digest(REPLAY/"contract.json")
    save(REPLAY/"inputs.json",mapping)
    repair_inputs()
    print(json.dumps({"prepared":True,"baseline_files_reused":len(controls)}),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("prepare","run","score"))
    parser.add_argument("--steps",type=int,choices=(32,64),default=64)
    args=parser.parse_args()
    label="repair-"+args.command+("-"+str(args.steps) if args.command=="run" else "")
    with worker(label):
        if args.command=="prepare":prepare()
        elif args.command=="run":make_runner()("heavy",4249,args.steps)
        else:score()

