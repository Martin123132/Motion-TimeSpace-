from repair_completion import *


def verify():
    repair_inputs()
    checks={}
    technical=read(ORIGINAL/"verification.json")
    checks["original_candidate_technical_verification"]=technical["passed"]
    checks["failed_original_gate_preserved"]=not read(ORIGINAL/"epoch4249-gate.json")["passed"]
    namespace=dict(scoring.work_history.__globals__,ROOT=REPLAY,folder=destination)
    work_function=types.FunctionType(scoring.work_history.__code__,namespace)
    namespace=dict(scoring.calculate.__globals__,ROOT=REPLAY,folder=destination,previous_history=history,work_history=work_function)
    calculate=types.FunctionType(scoring.calculate.__code__,namespace)
    for name,value in zip(("physics","work","slip","gate"),calculate(4249)):
        checks[name+"_exact_score_replay"]=worklib.ordinary(value)==read(REPLAY/("epoch4249-"+name+".json"))
    for case in CONFIG["cases"]:
        for steps in CONFIG["steps"]:
            short=case+"-"+str(steps)
            data=load(destination(4249)/(short+".npz"))
            terminal=load(destination(4249)/(short+"-terminal.npz"))
            beginning=load(AUTHORITY/"epoch3940"/(short+"-terminal.npz"))
            work=load(destination(4249)/(short+"-work-history.npz"))
            initial_work=initial_diagnostics(case,steps,4249)
            checks[short+"_initial_full_state_exact"]=np.array_equal(data["extended"][0],beginning["normalized"])
            checks[short+"_final_full_state_exact"]=np.array_equal(data["extended"][-1],terminal["normalized"])
            checks[short+"_original_clocks_exact"]=np.array_equal(data["time"],load(ORIGINAL/"epoch4249"/(short+".npz"))["time"])
            checks[short+"_work_not_reset"]=all(np.array_equal(work[name][0],value) for name,value in initial_work.items())
            checks[short+"_finite"]=all(np.isfinite(value).all() for value in data.values()) and all(np.isfinite(value).all() for value in work.values())
            final_work=load(destination(4249)/(short+"-work-terminal.npz"))
            checks[short+"_work_final_exact"]=all(np.array_equal(work[name][-1],value) for name,value in final_work.items())
            for name in ("inherited_allowance","quadrature_75","quadrature_53","rounding","accepted_steps"):
                checks[short+"_"+name+"_monotone"]=bool(np.all(np.diff(work[name],axis=0)>=0))
            if case=="heavy":
                for path in destination(4249).glob(short+"-boundary*.npz"):
                    boundary=load(path)
                    index=int(boundary["completed"])
                    checks[path.name+"_exact"]=np.array_equal(boundary["normalized"],data["extended"][index]) and all(np.array_equal(boundary["work_"+name],work[name][index]) for name in initial_work)
                checks[short+"_native_owner_released"]=read(REPLAY/(case+"-4249-"+str(steps)+"-owner-release.json"))["cleared"]
                join=read(REPLAY/("join-"+str(steps)+".json"))
                checks[short+"_initial_defect_not_reset"]=join["initial_split_state_max"]==maximum(data["split_state_residual"][0])
    with context()("heavy","repair-verify-owner") as (captured,metadata,sample):
        for steps in CONFIG["steps"]:
            direct,system,_=original.build("heavy",4249,steps,captured,metadata,sample)
            repair.install(system)
            saved=load(destination(4249)/("heavy-"+str(steps)+"-terminal.npz"))
            checks["heavy_"+str(steps)+"_fresh_owner_actual_rhs"]=np.array_equal(system.rhs(float(saved["tau"]),saved["normalized"]),saved["actual_rhs"])
            for mode in ("parent","approximate"):
                restore(direct,destination(4249)/("heavy-"+str(steps)+"-"+mode+"-terminal.npz"))
                checks["heavy_"+str(steps)+"_"+mode+"_restore"]=True
    checks["fresh_owner_released"]=read(REPLAY/"repair-verify-owner-owner-release.json")["cleared"]
    for path in ORIGINAL.glob("*.py"):
        compile(path.read_text(encoding="utf-8"),str(path),"exec")
    checks["no_bytecode"]=not list(ORIGINAL.rglob("__pycache__"))
    comparison=read(REPLAY/"physical-representation-comparison.json")
    checks["physical_replay_agrees_with_original"]=all(value["passed"] for branch in comparison.values() for value in branch.values())
    outcome={"checks":checks,"passed":all(checks.values()),"count":len(checks),
        "scientific_gate_pass":read(REPLAY/"epoch4249-gate.json")["passed"],
        "completed_epochs":[4249],"original_failed_candidate_preserved":True,
        "scientific_acceptance_distinct_from_artifact_integrity":True}
    save(REPLAY/"verification.json",outcome)
    repair_inputs()
    print(json.dumps({key:value for key,value in outcome.items() if key!="checks"}),flush=True)
    require(outcome["passed"],"repair artifact verification")


def photon():
    repair_inputs()
    require(read(REPLAY/"verification.json")["passed"],"technical verification first")
    require(read(REPLAY/"epoch4249-gate.json")["passed"],"physical continuation gate before repaired readout")
    sources={str(ORIGINAL/name):digest(ORIGINAL/name) for name in ("photon_exchange.py","PHOTON-EXCHANGE-DERIVATION.md","repair_validate.py")}
    for mode in ("baseline","parent","approximate"):
        case="cold" if mode=="baseline" else "heavy"
        for steps in CONFIG["steps"]:
            suffix="" if mode=="baseline" else "-"+mode
            for directory in [Path(value) for value in CONFIG["history_directories"]]+[destination(4249)]:
                path=directory/(case+"-"+str(steps)+".npz")
                sources[str(path)]=digest(path)
            path=destination(4249)/(case+"-"+str(steps)+suffix+"-terminal.npz")
            sources[str(path)]=digest(path)
    save(REPLAY/"photon-exchange-inputs.json",sources)
    namespace=dict(exchange.calculate.__globals__,ROOT=REPLAY,folder=destination,previous_history=history)
    calculate=types.FunctionType(exchange.calculate.__code__,namespace)
    result,arrays=calculate(4249)
    repeated,_=calculate(4249)
    require(worklib.ordinary(result)==worklib.ordinary(repeated),"exchange exact replay")
    save(REPLAY/"photon-exchange-result.json",result)
    for (label,steps),values in arrays.items():
        np.savez_compressed(REPLAY/("exchange-"+label+"-"+str(steps)+".npz"),**values)
    check_inputs(sources)
    save(REPLAY/"photon-exchange-verification.json",{"passed":result["identities_pass"],"replay_exact":True,
        "symbolic_controls":len(result["symbolic_checks"]),"rhs_checks":sum(len(values) for values in result["rhs_identities"].values()),
        "new_evolution":False})
    repair_inputs()
    print(json.dumps({"identities_pass":result["identities_pass"],"comparison":result["approximation_vs_parent"],"responses":result["responses"]}),flush=True)
    require(result["identities_pass"],"derived exchange identity")


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("verify","photon"))
    args=parser.parse_args()
    with worker("repair-v2-"+args.command):
        if args.command=="verify":verify()
        else:photon()

