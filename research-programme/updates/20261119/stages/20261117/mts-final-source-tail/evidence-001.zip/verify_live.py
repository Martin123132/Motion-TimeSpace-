from score_live import *


if __name__=='__main__':
    with worker('verify'):
        inputs()
        epochs=[epoch for epoch in CONFIG['checkpoint_epochs'] if (ROOT/('epoch'+str(epoch)+'-gate.json')).is_file()]
        require(epochs==CONFIG['checkpoint_epochs'][:len(epochs)] and epochs,'contiguous finished epochs')
        checks={}
        for epoch in epochs:
            for name,value in zip(('physics','work','slip','gate'),calculate(epoch)):
                checks[str(epoch)+'_'+name+'_replay']=worklib.ordinary(value)==read(ROOT/('epoch'+str(epoch)+'-'+name+'.json'))
            for case in CONFIG['cases']:
                checks[case+'_preflight']=read(ROOT/(case+'-preflight-result.json'))['passed']
                for steps in CONFIG['steps']:
                    short=case+'-'+str(steps)
                    label=case+'-'+str(epoch)+'-'+str(steps)
                    data=load(folder(epoch)/(short+'.npz'))
                    work=load(folder(epoch)/(short+'-work-history.npz'))
                    saved=load(folder(epoch)/(short+'-terminal.npz'))
                    initial=load(inherited(epoch)/(short+'-terminal.npz'))
                    initial_work=initial_diagnostics(case,steps,epoch)
                    final_work=load(folder(epoch)/(short+'-work-terminal.npz'))
                    checks[label+'_initial_physics_exact']=np.array_equal(data['extended'][0],initial['normalized'])
                    checks[label+'_final_physics_exact']=np.array_equal(data['extended'][-1],saved['normalized'])
                    checks[label+'_same_clocks']=np.array_equal(work['time'],data['time'])
                    checks[label+'_finite']=all(np.isfinite(value).all() for value in data.values()) and all(np.isfinite(value).all() for value in work.values())
                    checks[label+'_work_not_reset']=all(np.array_equal(work[name][0],value) for name,value in initial_work.items())
                    checks[label+'_work_terminal_exact']=all(np.array_equal(work[name][-1],value) for name,value in final_work.items())
                    checks[label+'_positive_clock']=bool(np.all(np.diff(data['time'])>0))
                    original=load(folder(epoch)/(case+'-clock.npz'))
                    checks[label+'_every_original_clock_retained']=np.array_equal(data['time'][data['native_indices']],original['native_time']) and len(original['native_time'])==epoch-prior_epoch(epoch)+1
                    checks[label+'_owner_released']=read(ROOT/(label+'-owner-release.json'))['cleared']
                    started=datetime.fromisoformat(read(ROOT/(label+'-start.json'))['utc']).timestamp()
                    checks[label+'_frozen_first']=started>=(ROOT/'inputs.json').stat().st_mtime
                    if epoch>epochs[0]:
                        path=ROOT/('epoch'+str(prior_epoch(epoch))+'-gate.json')
                        checks[label+'_earlier_gate_before_launch']=read(path)['passed'] and started>=path.stat().st_mtime
                    for name in ('inherited_allowance','quadrature_75','quadrature_53','rounding','accepted_steps'):
                        checks[label+'_'+name+'_monotone']=bool(np.all(np.diff(work[name],axis=0)>=0))
                    for path in folder(epoch).glob(short+'-boundary*.npz'):
                        batch=load(path)
                        index=int(batch['completed'])
                        checks[str(path.relative_to(ROOT))+'_exact']=np.array_equal(batch['normalized'],data['extended'][index]) and all(np.array_equal(batch['work_'+name],work[name][index]) for name in initial_work)
                    if case=='heavy':
                        checks[label+'_memory_preserved']=bool(np.any(data['coefficient_matrices'][0]!=0) and np.any(data['fresh_source'][0]!=0))
                        checks[label+'_inverse_safety']=bool(np.max(data['coefficient_integral']+.5*data['coefficient_integral']**2)<1)
        for case in CONFIG['cases']:
            with native_context(case,'verify-owner-'+case) as (captured,metadata,sample):
                direct,system,_=build(case,epochs[-1],64,captured,metadata,sample)
                final=load(folder(epochs[-1])/(case+'-64-terminal.npz'))
                if system:
                    checks['final_actual_heavy_rhs']=np.array_equal(system.rhs(float(final['tau']),final['normalized']),final['actual_rhs'])
                    restore(direct,folder(epochs[-1])/'heavy-64-parent-terminal.npz')
                    restore(direct,folder(epochs[-1])/'heavy-64-approximate-terminal.npz')
                else:restore(direct,folder(epochs[-1])/'cold-64-terminal.npz')
                checks['final_'+case+'_native_restore']=True
            checks['final_'+case+'_owner_release']=read(ROOT/('verify-owner-'+case+'-owner-release.json'))['cleared']
        checks['old_failed_diagnostics_preserved']=not read(DIAGNOSTIC/'science-score.json')['all_identity_checks_pass'] and not read(DIAGNOSTIC/'paired-science-score.json')['all_error_predictions_resolved']
        checks['no_bytecode']=not list(ROOT.rglob('__pycache__'))
        for path in ROOT.glob('*.py'):compile(path.read_text(encoding='utf-8'),str(path),'exec')
        result={'checks':checks,'passed':all(checks.values()),'count':len(checks),'completed_epochs':epochs}
        save(ROOT/'verification.json',result)
        require(result['passed'],'technical verification failure: '+str([name for name,value in checks.items() if not value]))
        inputs()
        print(json.dumps({name:value for name,value in result.items() if name!='checks'}),flush=True)
