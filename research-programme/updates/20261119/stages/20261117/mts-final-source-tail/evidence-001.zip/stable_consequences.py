from score_live import *


def calculate():
    epoch=read(ROOT/"verification.json")["completed_epochs"][-1]
    data={case+"-"+str(steps)+".npz":previous_history(case,steps,epoch) for case in CONFIG["cases"] for steps in CONFIG["steps"]}
    values,primitives,results,identities={},{},{},{}
    for case in CONFIG["cases"]:
        modes=("parent","approximate") if case=="heavy" else ("baseline",)
        for mode in modes:
            key=case+"_"+mode
            for steps in CONFIG["steps"]:
                suffix="-"+mode if case=="heavy" else ""
                terminal=load(folder(epoch)/(case+"-"+str(steps)+suffix+"-terminal.npz"))
                value,primitive,diagnostic=retained_slip.extract(data[case+"-"+str(steps)+".npz"],terminal,mode)
                values[key,steps],primitives[key,steps]=value,primitive
                identities[key+"_"+str(steps)]=diagnostic
            results[key]={"final":float(values[key,64][-1]),"amplitude":maximum(values[key,64]),"precision":conservative(0.,maximum(values[key,64]-values[key,32]),maximum(values[key,64]),maximum(primitives[key,64]+primitives[key,32]))}
    parent=values["heavy_parent",64]
    approximate=values["heavy_approximate",64]
    refinement=maximum(parent-values["heavy_parent",32])+maximum(approximate-values["heavy_approximate",32])
    primitive=sum(primitives[key,steps] for key in ("heavy_parent","heavy_approximate") for steps in CONFIG["steps"])
    comparison=conservative(maximum(approximate-parent),refinement,maximum(parent),maximum(primitive))
    checks={}
    for steps in CONFIG["steps"]:
        cold=data["cold-"+str(steps)+".npz"]
        checks["cold_owned_pressure_current_work_structural_zero_"+str(steps)]=bool(np.all(cold["source"][:,1:]==0) and np.all(cold["source_change"][:,1:]==0) and np.all(cold["work"][:,0]==0) and np.all(cold["work_change"][:,0]==0))
    checks["all_saved_field_identities"]=all(all(diagnostic["checks"].values()) for diagnostic in identities.values())
    require(all(checks.values()),"retained structural/readout identity")
    saved=read(ROOT/("epoch"+str(epoch)+"-slip.json"))
    checks["prior_stable_precision_exact"]=all(results[key]["precision"]==saved[key]["precision"] for key in results)
    require(all(checks.values()),"same established stable readout")
    raw=read(ROOT/"physical-consequences.json")
    return {"last_epoch":epoch,"formula":"Delta(v_b - 3 q_gamma/4) = delta_v_b - 3 delta_q_gamma/4; same retained native normalization and signature","scope":"reuse existing derived readout, not new evolution or a changed gate","results":results,"approximation_vs_parent":comparison,"identities":identities,"checks":checks,"checks_pass":all(checks.values()),"raw_packet_comparison_preserved":raw["cumulative_physical_projection"]["approximation_vs_parent"]["velocity_slip_response"],"cold_generic_pressure_bound_preserved":raw["stable_paired_source_response"]["cold"]["baseline"]["pressure"],"cold_pressure_interpretation":"Owned cold pressure/current/work channel is structurally zero. The generic density-plus-pressure rounding bound is deliberately overinclusive here and is not evidence of nonzero cold pressure.","tiny_baseline_slip_resolved":results["cold_baseline"]["precision"]["passed"]}


if __name__=="__main__":
    with worker("stable-consequences"):
        inputs()
        check_inputs(read(ROOT/"consequences-inputs.json"))
        epoch=read(ROOT/"verification.json")["completed_epochs"][-1]
        manifest={str(ROOT/name):digest(ROOT/name) for name in ("stable_consequences.py","physical-consequences.json","epoch"+str(epoch)+"-slip.json")}
        for case in CONFIG["cases"]:
            for steps in CONFIG["steps"]:
                modes=("parent","approximate") if case=="heavy" else ("baseline",)
                for mode in modes:
                    suffix="-"+mode if case=="heavy" else ""
                    path=folder(epoch)/(case+"-"+str(steps)+suffix+"-terminal.npz")
                    manifest[str(path)]=digest(path)
        save(ROOT/"stable-consequences-inputs.json",manifest)
        result=calculate()
        replay=calculate()
        require(worklib.ordinary(result)==worklib.ordinary(replay),"stable saved readout replay")
        check_inputs(manifest)
        save(ROOT/"stable-consequences.json",result)
        save(ROOT/"stable-consequences-verification.json",{"passed":result["checks_pass"],"replay_exact":True,"new_evolution":False,"original_generic_report_preserved":True})
        inputs()
        print(json.dumps({"checks_pass":result["checks_pass"],"comparison":result["approximation_vs_parent"],"baseline_tiny_slip_resolved":result["tiny_baseline_slip_resolved"]}),flush=True)
