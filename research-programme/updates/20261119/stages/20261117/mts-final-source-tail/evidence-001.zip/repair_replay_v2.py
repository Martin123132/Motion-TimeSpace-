from pathlib import Path
import hashlib
original = Path(__file__).with_name("repair_replay.py")
expected = "f5cf647ef84e6dda8102bb8d6ed14a6d60dc32e4470c886df948bab8208c4202"
if hashlib.sha256(original.read_bytes()).hexdigest() != expected:
    raise RuntimeError("Original failed-launch source changed")
source = original.read_text(encoding="utf-8")
changes = {
    'REPLAY=ROOT/"photon-difference-replay"': 'REPLAY=ROOT/"photon-difference-replay-v2"',
    '"old_split_rhs":before[1]["split_rhs_residual"],"new_split_rhs":after[1]["split_rhs_residual"]': '"old_split_rhs":before[1]["split_rhs_residual"].tolist(),"new_split_rhs":after[1]["split_rhs_residual"].tolist()',
    '"old_split_rhs_scale":before[1]["split_rhs_scale"],"new_split_rhs_scale":after[1]["split_rhs_scale"]': '"old_split_rhs_scale":float(before[1]["split_rhs_scale"]),"new_split_rhs_scale":float(after[1]["split_rhs_scale"])',
    'label="repair-"+args.command': 'label="repair-v2-"+args.command',
}
for before, after in changes.items():
    if source.count(before) != 1:
        raise RuntimeError("Unique serialization/isolated receipt adaptation")
    source = source.replace(before, after)
exec(compile(source,str(original)+":v2-serialization-fix","exec"),globals())

