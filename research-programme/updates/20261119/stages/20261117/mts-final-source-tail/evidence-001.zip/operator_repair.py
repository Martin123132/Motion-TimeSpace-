import ast
import inspect
import textwrap
import types
from decimal import Decimal, localcontext
from restart_bridge import *
import carry
import transport


def photon_rows(direct):
    signature = np.asarray(direct.captured["signature"][0], dtype=int)
    require(signature[:8].tolist() == [400, 185, 96, 5, 93, 48, 44, 44], "retained heavy photon layout")
    photon = np.arange(signature[3]+2, signature[3]+signature[6])
    polarization = np.arange(signature[5]+2, signature[5]+signature[7])
    rows = np.r_[photon, polarization]
    require(len(rows) == 84 and len(np.unique(rows)) == 84, "disjoint ell3..44 rows")
    require(np.all(rows < direct.active), "active linear photon rows")
    return rows


def opacity_difference(scale_old, scale_new, opacity_old):
    fraction = (scale_new-scale_old)/scale_old
    require(scale_old > 0 and scale_new > 0, "positive represented scales")
    return -opacity_old*fraction*(2+fraction)/(1+fraction)**2


def stable_delta(direct, old, packet, old_extra, old_rhs, new_old_rhs, change_rhs):
    result = new_old_rhs-old_rhs+change_rhs
    rows = direct._stable_photon_rows
    difference = opacity_difference(float(old_extra[0]), float(packet[0]), float(old_extra[2]))
    result[rows] = change_rhs[rows]-difference*old[rows]
    return result


def replacement(method):
    original = textwrap.dedent(inspect.getsource(method))
    tree = ast.parse(original)
    old_count = 0
    delta_count = 0
    class Transform(ast.NodeTransformer):
        def visit_Assign(self, node):
            nonlocal old_count, delta_count
            if len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                name = node.targets[0].id
                if name == "old_rhs" and ast.unparse(node.value) == "self.direct.sample(clock, old, packet, False)[0]":
                    old_count += 1
                    node.targets = [ast.Tuple(elts=[ast.Name(id=value, ctx=ast.Store()) for value in ("old_rhs", "old_observed_unused", "old_extra")], ctx=ast.Store())]
                    node.value = node.value.value
                if name == "delta_rhs" and ast.unparse(node.value) == "new_old_rhs - old_rhs + change_rhs":
                    delta_count += 1
                    node.value = ast.parse("stable_delta(self.direct, old, packet, old_extra, old_rhs, new_old_rhs, change_rhs)", mode="eval").body
            return self.generic_visit(node)
    tree = Transform().visit(tree)
    require(old_count == delta_count == 1, "exact one derived difference replacement in "+method.__qualname__)
    ast.fix_missing_locations(tree)
    namespace = dict(method.__globals__, stable_delta=stable_delta)
    exec(compile(tree, inspect.getfile(method)+":stable-photon-difference", "exec"), namespace)
    return namespace[method.__name__]


def install(system):
    require(not hasattr(system.direct, "_stable_photon_rows"), "install once")
    system.direct._stable_photon_rows = photon_rows(system.direct)
    system.core.calculate = types.MethodType(replacement(transport.Transport.calculate), system.core)
    system.linear_rhs = types.MethodType(replacement(carry.Carried.linear_rhs), system)
    system.calculate = types.MethodType(replacement(carry.Carried.calculate), system)


def decimal_difference(scale_old, scale_new, opacity_old):
    with localcontext() as context:
        context.prec = 80
        before, after, opacity = map(Decimal.from_float, (float(scale_old), float(scale_new), float(opacity_old)))
        return float(opacity*((before/after)**2-1))

