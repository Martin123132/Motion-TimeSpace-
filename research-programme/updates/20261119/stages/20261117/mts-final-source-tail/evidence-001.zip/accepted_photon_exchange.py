from repair_completion import *

OUTPUT=ORIGINAL/"accepted-photon-exchange"


def accepted_folder(epoch):
    require(epoch==3940,"only last accepted physical authority")
    return AUTHORITY/"epoch3940"


def run():
    inputs()
    require(digest(AUTHORITY/"closeout.json")==CONFIG["authority_seal"],"accepted authority seal")
    require(not OUTPUT.exists(),"new accepted readout")
    OUTPUT.mkdir()
    sources={str(Path(__file__)):digest(Path(__file__)),
        str(ORIGINAL/"photon_exchange.py"):digest(ORIGINAL/"photon_exchange.py"),
        str(ORIGINAL/"PHOTON-EXCHANGE-DERIVATION.md"):digest(ORIGINAL/"PHOTON-EXCHANGE-DERIVATION.md"),
        str(AUTHORITY/"closeout.json"):digest(AUTHORITY/"closeout.json")}
    for directory in map(Path,CONFIG["history_directories"]):
        for case in CONFIG["cases"]:
            for steps in CONFIG["steps"]:
                path=directory/(case+"-"+str(steps)+".npz")
                sources[str(path)]=digest(path)
    for case in CONFIG["cases"]:
        for steps in CONFIG["steps"]:
            for mode in (("parent","approximate") if case=="heavy" else ("baseline",)):
                suffix="" if case=="cold" else "-"+mode
                path=accepted_folder(3940)/(case+"-"+str(steps)+suffix+"-terminal.npz")
                sources[str(path)]=digest(path)
    for name in ("mts_metric_hook.inc","mts_response_hook.inc"):
        path=PREVIOUS/"native/fortran"/name
        sources[str(path)]=digest(path)
    save(OUTPUT/"inputs.json",sources)
    namespace=dict(exchange.calculate.__globals__,folder=accepted_folder,previous_history=original.previous_history)
    calculate=types.FunctionType(exchange.calculate.__code__,namespace)
    result,arrays=calculate(3940)
    repeated,_=calculate(3940)
    exact=worklib.ordinary(result)==worklib.ordinary(repeated)
    result["accepted_physical_authority"]=str(AUTHORITY)
    result["failed_4249_not_used"]=True
    save(OUTPUT/"result.json",result)
    for (label,steps),values in arrays.items():
        np.savez_compressed(OUTPUT/(label+"-"+str(steps)+".npz"),**values)
    verification={"passed":exact and result["identities_pass"],"replay_exact":exact,
        "symbolic_checks":len(result["symbolic_checks"]),
        "native_rhs_checks":sum(len(values) for values in result["rhs_identities"].values()),
        "new_evolution":False,"source_gate":read(AUTHORITY/"epoch3940-gate.json")["passed"]}
    save(OUTPUT/"verification.json",verification)
    check_inputs(sources)
    inputs()
    print(json.dumps({"verification":verification,"responses":result["responses"],"comparison":result["approximation_vs_parent"],
        "failed_identities":[label+":"+name for label,values in result["rhs_identities"].items() for name,value in values.items() if not value["passed"]]}),flush=True)
    require(verification["passed"] and verification["source_gate"],"accepted-state exchange identity")


if __name__=="__main__":
    with worker("accepted-photon-exchange"):
        run()

