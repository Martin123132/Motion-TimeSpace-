from repair_completion import *

def original_exited(saved):
    try:
        process=psutil.Process(saved["pid"])
        if abs(process.create_time()-saved["created"])>=.01:
            return {"exited":True,"reason":"PID reused; command not inspected; untouched"}
        command=process.cmdline()
        return {"exited":command!=saved["command"],"reason":"original still active" if command==saved["command"] else "command identity changed; untouched"}
    except psutil.NoSuchProcess:
        return {"exited":True,"reason":"PID absent"}


def close():
    repair_inputs()
    check_inputs(read(ORIGINAL/"accepted-photon-exchange/inputs.json"))
    check_inputs(read(ORIGINAL/"split-defect-transport/inputs.json"))
    require(digest(AUTHORITY/"closeout.json")==CONFIG["authority_seal"],"physical authority unchanged")
    checks={
        "original_technical":read(ORIGINAL/"verification.json")["passed"],
        "repair_preflight":read(ORIGINAL/"repair-probe-result.json")["passed"],
        "repaired_technical":read(REPLAY/"verification.json")["passed"],
        "accepted_photon_identities":read(ORIGINAL/"accepted-photon-exchange/verification.json")["passed"],
        "defect_technical":read(ORIGINAL/"split-defect-transport/result.json")["technical_pass"],
        "original_physical_gate_stays_false":not read(ORIGINAL/"epoch4249-gate.json")["passed"],
        "repaired_physical_gate_stays_false":not read(REPLAY/"epoch4249-gate.json")["passed"],
        "accepted3940_gate":read(AUTHORITY/"epoch3940-gate.json")["passed"],
        "no_bytecode":not list(ORIGINAL.rglob("__pycache__")),
    }
    prediction=read(ORIGINAL/"split-defect-transport/result.json")
    scale=read(REPLAY/"epoch4249-physics.json")["split_state"]["scale"]
    for seed in CONFIG["steps"]:
        original_data=load(REPLAY/"epoch4249"/("heavy-"+str(seed)+".npz"))
        arrays={}
        for steps in CONFIG["steps"]:
            key="seed"+str(seed)+"-steps"+str(steps)
            values=load(ORIGINAL/"split-defect-transport"/(key+".npz"))
            arrays[steps]=values
            expected=prediction["reports"][key]
            checks[key+"_clocks"]=np.array_equal(values["time"],original_data["time"])
            checks[key+"_observed"]=np.array_equal(values["observed"],original_data["split_state_residual"])
            checks[key+"_residual_exact"]=np.array_equal(values["residual"],values["observed"]-values["predicted"])
            checks[key+"_maxima"]=maximum(values["predicted"])==expected["predicted_inherited_max"] and maximum(values["residual"])==expected["unaccounted_max"]
            checks[key+"_gate_scale_unchanged"]=expected["unaccounted_relative_to_original_gate"]==ratio(maximum(values["residual"]),scale,CONFIG["algebra_tolerance"])
        checks[str(seed)+"_refinement_replay"]=ratio(maximum(arrays[64]["predicted"]-arrays[32]["predicted"]),maximum(arrays[64]["predicted"]))==prediction["reports"]["seed"+str(seed)+"_same_seed_refinement"]
    for epoch in (4250,4251,4252):
        checks[str(epoch)+"_not_evolved"]=not list((ORIGINAL/("epoch"+str(epoch))).glob("*-terminal.npz"))
    checks["first_logging_failure_no_heavy_evolution"]=not list((ORIGINAL/"photon-difference-replay/epoch4249").glob("heavy*-terminal.npz"))
    failures=sorted(str(path.relative_to(ORIGINAL)) for path in ORIGINAL.rglob("*-failure.json"))
    checks["only_documented_code_failures"]=failures==["repair-run-32-failure.json","repair-v2-score-failure.json"]
    workers={}
    for path in sorted(ORIGINAL.glob("*-start.json")):
        saved=read(path)
        workers[path.name]={"identity":saved,"status":original_exited(saved)}
        label=path.name.removesuffix("-start.json")
        checks[label+"_terminal_receipt"]=(ORIGINAL/(label+"-end.json")).is_file() or (ORIGINAL/(label+"-failure.json")).is_file()
    checks["all_stage_workers_exited"]=all(value["status"]["exited"] for value in workers.values())
    owners={}
    for path in sorted(ORIGINAL.rglob("*-owner-release.json")):
        owners[str(path.relative_to(ORIGINAL))]=read(path)["cleared"]
    checks["all_native_owners_released"]=bool(owners) and all(owners.values())
    for path in ORIGINAL.glob("*.py"):compile(path.read_text(encoding="utf-8"),str(path),"exec")
    save(ORIGINAL/"cleanup.json",{"workers":workers,"native_releases":owners,"failures_preserved":failures,
        "all_workers_exited":checks["all_stage_workers_exited"],"no_kill_performed":True,
        "temporary_browser_server_subagent_count":0,"other_chats_preserved":True,
        "git_status_note":"Parent research tree is not a git repository; no fabricated git-based changed-file count.",
        "memory_recovery_claim":False})
    save(ORIGINAL/"final-verification.json",{"passed":all(checks.values()),"checks":checks,"count":len(checks),
        "last_accepted_epoch":3940,"latest_tested_candidate":4249,"candidate_raw_gate_pass":False,
        "new_photon_exchange_uses_accepted_history_only":True})
    require(all(checks.values()),"closeout checks failed:"+str([name for name,value in checks.items() if not value]))
    entries={}
    for path in sorted(ORIGINAL.rglob("*")):
        if path.is_file():
            entries[str(path.relative_to(ORIGINAL))]={"bytes":path.stat().st_size,"sha256":digest(path)}
    saved={"research_stage_complete":True,"physical_tail_complete":False,"last_accepted_epoch":3940,"latest_tested_candidate":4249,
        "physical_authority":str(AUTHORITY),"physical_authority_seal":CONFIG["authority_seal"],
        "files":entries,"count":len(entries),"bytes":sum(value["bytes"] for value in entries.values()),
        "closed_utc":datetime.now(timezone.utc).isoformat(),"closer_identity":identity(psutil.Process()),
        "next":"Prospectively derive a defect-aware invariant/budget or rebuild auxiliary split from its defining anchor; no resetting.",
        "github":False}
    save(ORIGINAL/"closeout.json",saved)
    print(json.dumps({key:value for key,value in saved.items() if key!="files"}),flush=True)
    print("seal="+digest(ORIGINAL/"closeout.json"),flush=True)


if __name__=="__main__":
    close()

