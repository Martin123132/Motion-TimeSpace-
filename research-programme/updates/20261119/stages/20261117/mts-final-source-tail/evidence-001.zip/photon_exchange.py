from score_live import *
from fractions import Fraction


def algebra():
    checks={}
    for index,value in enumerate((Fraction(-1,1000),Fraction(-1,10**12),Fraction(0),Fraction(1,10**16),Fraction(1,10**12),Fraction(1,1000),Fraction(1,10))):
        factor=(1+value)**-4
        change=-value*(4+6*value+4*value**2+value**3)/(1+value)**4
        old,delta=Fraction(7,13),Fraction(-3,19)
        checks["coefficient_"+str(index)]=change==factor-1
        checks["finite_response_"+str(index)]=factor*delta+change*old==factor*(old+delta)-old
    return checks


def extract(data,terminal,mode):
    state=retained_slip.native_state(data,terminal,mode)
    active=int(terminal["dimensions"][1])
    indices=[3,int(terminal["signature"][3])]
    old=state[:,indices]*terminal["state_units"][indices]
    delta=state[:,[active+index for index in indices]]*terminal["delta_units"][indices]
    slip=old[:,0]-.75*old[:,1]
    slip_delta=delta[:,0]-.75*delta[:,1]
    packet=data[("parent_" if mode=="parent" else "")+"metric"]
    species=packet[...,:84].reshape(len(packet),2,7,12)
    scales=field(packet,"scale")
    fraction=state[:,2*active]*terminal["background_units"][0]
    delta_scale=scales[:,0]*fraction
    require(np.all(1+fraction>0),"positive scale")
    factor=(1+fraction)**-4
    factor_delta=-fraction*(4+6*fraction+4*fraction**2+fraction**3)/(1+fraction)**4
    coefficient=(4./3)*species[:,:,2,0]*field(packet,"opacity")
    velocity_term=coefficient[:,0]*factor*slip_delta
    background_term=coefficient[:,0]*factor_delta*slip
    predicted=velocity_term+background_term
    primitive=abs(coefficient[:,0])*(abs(factor)*(abs(delta[:,0])+.75*abs(delta[:,1]))+abs(factor_delta)*(abs(old[:,0])+.75*abs(old[:,1])))
    direct=np.column_stack((coefficient[:,0]*slip,coefficient[:,0]*factor*(slip+slip_delta)))
    hubble,rate=field(packet,"hubble"),field(packet,"rate")
    wave=CONFIG["retained_comoving_wave"]
    gas=-species[:,:,1,8]-(hubble+rate)*species[:,:,1,4]+wave*species[:,:,1,5]
    photons=species[:,:,2,8]+2*rate*species[:,:,2,4]-wave*(species[:,:,2,5]-2*species[:,:,2,6]/3)
    gas_scale=abs(species[:,:,1,8])+abs((hubble+rate)*species[:,:,1,4])+abs(wave*species[:,:,1,5])
    photon_scale=abs(species[:,:,2,8])+2*abs(rate*species[:,:,2,4])+abs(wave*species[:,:,2,5])+2*abs(wave*species[:,:,2,6])/3
    raw=photons[:,1]-photons[:,0]
    controls={
        "background_reconstruction":(maximum(scales[:,1]-(scales[:,0]+delta_scale)),maximum(scales)),
        "coefficient_a_minus_four":(maximum(coefficient[:,1]-coefficient[:,0]*factor),maximum(coefficient)),
        "baryon_rhs":(maximum(gas-direct),maximum(gas_scale+abs(direct))),
        "photon_rhs":(maximum(photons-direct),maximum(photon_scale+abs(direct))),
        "internal_cancellation":(maximum(gas-photons),maximum(gas_scale+photon_scale)),
        "finite_change_rhs":(maximum(raw-predicted),maximum(photon_scale))}
    return {"time":data["time"],"predicted":predicted,"primitive":primitive,"velocity_term":velocity_term,"background_term":background_term,"raw_change":raw},{name:ratio(error,scale,CONFIG["algebra_tolerance"]) for name,(error,scale) in controls.items()}


def calculate(epoch):
    values,identities,report={},{},{}
    for case in CONFIG["cases"]:
        histories={steps:previous_history(case,steps,epoch) for steps in CONFIG["steps"]}
        for mode in (("parent","approximate") if case=="heavy" else ("baseline",)):
            label=case+"_"+mode
            for steps in CONFIG["steps"]:
                suffix="-"+mode if case=="heavy" else ""
                terminal=load(folder(epoch)/(case+"-"+str(steps)+suffix+"-terminal.npz"))
                values[label,steps],identities[label+"_"+str(steps)]=extract(histories[steps],terminal,mode)
            high,low=values[label,64],values[label,32]
            report[label]={"final_delta_J":float(high["predicted"][-1]),"amplitude_delta_J":maximum(high["predicted"]),"final_slip_term":float(high["velocity_term"][-1]),"final_background_term":float(high["background_term"][-1]),"precision":conservative(0.,maximum(high["predicted"]-low["predicted"]),maximum(high["predicted"]),maximum(high["primitive"]+low["primitive"]))}
    high,low=values["heavy_approximate",64],values["heavy_approximate",32]
    parent,parent_low=values["heavy_parent",64],values["heavy_parent",32]
    comparison=conservative(maximum(high["predicted"]-parent["predicted"]),maximum(high["predicted"]-low["predicted"])+maximum(parent["predicted"]-parent_low["predicted"]),maximum(parent["predicted"]),maximum(high["primitive"]+low["primitive"]+parent["primitive"]+parent_low["primitive"]))
    symbolic=algebra()
    return {"last_epoch":epoch,"units":"native rescaled momentum-transfer J, Mpc^-3","scope":"coherent-minus-original within each branch; exact represented fixed-ionization response, not an energy-heating law or new fundamental coupling","symbolic_checks":symbolic,"rhs_identities":identities,"identities_pass":all(symbolic.values()) and all(value["passed"] for checks in identities.values() for value in checks.values()),"responses":report,"approximation_vs_parent":comparison,"new_fitted_parameters":0},values


if __name__=="__main__":
    with worker("photon-exchange"):
        inputs()
        epoch=read(ROOT/"verification.json")["completed_epochs"][-1]
        manifest={str(ROOT/name):digest(ROOT/name) for name in ("photon_exchange.py","PHOTON-EXCHANGE-DERIVATION.md")}
        for name in ("mts_metric_hook.inc","mts_response_hook.inc"):
            path=PREVIOUS/"native/fortran"/name
            manifest[str(path)]=digest(path)
        for directory in [Path(value) for value in CONFIG["history_directories"]]+[folder(value) for value in CONFIG["checkpoint_epochs"] if value<=epoch]:
            for case in CONFIG["cases"]:
                for steps in CONFIG["steps"]:
                    path=directory/(case+"-"+str(steps)+".npz")
                    manifest[str(path)]=digest(path)
        for case in CONFIG["cases"]:
            for steps in CONFIG["steps"]:
                for mode in (("parent","approximate") if case=="heavy" else ("baseline",)):
                    suffix="-"+mode if case=="heavy" else ""
                    path=folder(epoch)/(case+"-"+str(steps)+suffix+"-terminal.npz")
                    manifest[str(path)]=digest(path)
        save(ROOT/"photon-exchange-inputs.json",manifest)
        result,arrays=calculate(epoch)
        replay,_=calculate(epoch)
        require(worklib.ordinary(result)==worklib.ordinary(replay),"exchange readout replay")
        save(ROOT/"photon-exchange-result.json",result)
        for (label,steps),values in arrays.items():np.savez_compressed(ROOT/("exchange-"+label+"-"+str(steps)+".npz"),**values)
        check_inputs(manifest)
        save(ROOT/"photon-exchange-verification.json",{"passed":result["identities_pass"],"replay_exact":True,"symbolic_controls":len(result["symbolic_checks"]),"rhs_checks":sum(len(values) for values in result["rhs_identities"].values()),"new_evolution":False})
        require(result["identities_pass"],"derived exchange identity failed: retain and inspect")
        inputs()
        print(json.dumps({"identities_pass":result["identities_pass"],"comparison":result["approximation_vs_parent"],"responses":result["responses"]}),flush=True)
