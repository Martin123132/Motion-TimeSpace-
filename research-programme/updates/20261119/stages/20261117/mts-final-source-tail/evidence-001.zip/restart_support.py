import os
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "1"
import sys
sys.dont_write_bytecode = True
import json
import hashlib
import time
from pathlib import Path
from datetime import datetime, timezone
from contextlib import contextmanager
import numpy as np
import psutil

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "protocol.json").read_text())
POST = Path(CONFIG["post_directory"])
PREVIOUS = Path(CONFIG["previous_directory"])
NATIVE = PREVIOUS / "native"
START = time.monotonic()

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def write(path, value):
    encoded = json.dumps(value, indent=2, allow_nan=False) + "\n"
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(encoded)

def load(path):
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def guard():
    require(time.monotonic() - START < CONFIG["maximum_worker_seconds"], "bounded worker")
    require(datetime.now(timezone.utc) < datetime.fromisoformat(CONFIG["turn_stop_utc"]), "safe four-hour checkpoint")
    for directory in (ROOT, POST, PREVIOUS, POST / "condensate-origin-20261003"):
        require(not (directory / "STOP-REQUESTED").exists(), "owner hold: " + str(directory))

def check_inputs(mapping):
    for path, expected in mapping.items():
        guard()
        require(Path(path).is_file() and digest(path) == expected, "unchanged source: " + path)

def identity(process):
    return {"pid": process.pid, "created": process.create_time(), "command": process.cmdline()}

def exited(saved):
    try:
        process = psutil.Process(saved["pid"])
        same = abs(process.create_time()-saved["created"]) < .01 and process.cmdline() == saved["command"]
    except psutil.NoSuchProcess:
        return {"exited": True, "reason": "PID absent"}
    return {"exited": not same, "reason": "original active" if same else "PID reused; untouched"}

@contextmanager
def worker(label):
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    saved = {**identity(process), "utc": datetime.now(timezone.utc).isoformat(), "threads": 1}
    write(ROOT / (label+"-start.json"), saved)
    try:
        guard()
        yield
    except BaseException as error:
        write(ROOT / (label+"-failure.json"), {**saved, "error": repr(error), "seconds": time.monotonic()-START})
        raise
    else:
        write(ROOT / (label+"-end.json"), {**saved, "completed": True, "seconds": time.monotonic()-START})

def ratio(error, scale, tolerance=None):
    error, scale = float(error), float(scale)
    tolerance = CONFIG["numerical_tolerance"] if tolerance is None else tolerance
    return {"error": error, "scale": scale, "relative": error/scale if scale else None,
            "tolerance": tolerance, "passed": bool(np.isfinite(error) and error <= tolerance*scale)}

def maximum(value):
    return float(np.max(abs(value)))
