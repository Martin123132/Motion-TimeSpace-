from restart_support import *
import importlib.metadata


if __name__=='__main__':
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed=process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    check_inputs(read(ROOT/'inputs.json'))
    check_inputs(read(ROOT/'consequences-inputs.json'))
    check_inputs(read(ROOT/'stable-consequences-inputs.json'))
    require(read(ROOT/'stable-consequences-verification.json')['passed'],'retained stable readout identities verified')
    require(read(ROOT/'consequences-verification.json')['passed'],'saved physical consequences replay verified')
    check_inputs(read(ROOT/'photon-exchange-inputs.json'))
    require(read(ROOT/'photon-exchange-verification.json')['passed'],'derived photon/baryon exchange verified')
    verification=read(ROOT/'verification.json')
    require(verification['passed'],'technical verification passed')
    epochs=verification['completed_epochs']
    expected={'regime-prepare','cold-regime','heavy-regime','prepare','cold-preflight','heavy-preflight','verify','consequences','stable-consequences','photon-exchange'}
    expected.update('score-'+str(epoch) for epoch in epochs)
    expected.update(case+'-'+str(epoch)+'-'+str(steps) for epoch in epochs for case in CONFIG['cases'] for steps in CONFIG['steps'])
    workers={path.name:{**read(path),**exited(read(path))} for path in ROOT.glob('*-start.json')}
    require(set(workers)=={name+'-start.json' for name in expected} and all(value['exited'] for value in workers.values()),'all exact task workers exited')
    for label in expected:
        first,last=read(ROOT/(label+'-start.json')),read(ROOT/(label+'-end.json'))
        require(last['completed'] and all(first[name]==last[name] for name in ('pid','created','command')),'matching completed receipt')
    owners={path.name:read(path) for path in ROOT.glob('*-owner-release.json')}
    require(len(owners)==6+4*len(epochs) and all(value['cleared'] for value in owners.values()),'all native owners cleared')
    require(not list(ROOT.glob('*-failure.json')),'no failed worker')
    require(not list(ROOT.rglob('__pycache__')),'no bytecode')
    require(all((ROOT/name).is_file() for name in ('CONTRACT.md','RESULTS.md','NEXT.md')),'handoff complete')
    closer=identity(process)
    write(ROOT/'cleanup.json',{'workers':workers,'native_owners':owners,'closer_identity':closer,'closer_exit_check_required':True,'temporary_tools':[],'other_processes_changed':False,'python':sys.version,'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','psutil')}})
    artifacts={str(path.relative_to(ROOT)):{'sha256':digest(path),'bytes':path.stat().st_size} for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name!='closeout.json'}
    result={'stage':CONFIG['stage'],'utc':datetime.now(timezone.utc).isoformat(),'artifacts':artifacts,'completed_epochs':epochs,'last_epoch':epochs[-1],'completed_target':epochs==CONFIG['checkpoint_epochs'],'final_gate':read(ROOT/('epoch'+str(epochs[-1])+'-gate.json')),'verification_passed':True,'technical_checks':verification['count'],'workers_exited':len(workers),'native_owners_released':len(owners),'new_fitted_parameters':0,'github':False}
    result['physical_consequences_verified']=True
    result['full_scope_objective_completed']=False
    write(ROOT/'closeout.json',result)
    print(json.dumps({'seal':digest(ROOT/'closeout.json'),'artifacts':len(artifacts),'bytes':sum(value['bytes'] for value in artifacts.values()),'workers_exited':len(workers),'last_epoch':epochs[-1],'closer':closer}),flush=True)
