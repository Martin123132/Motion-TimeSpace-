from restart_bridge import *
import argparse
import math

PRIOR=Path(CONFIG['prior_directory'])
DIAGNOSTIC=Path(CONFIG['diagnostic_directory'])
AUTHORITY=Path(CONFIG['authority_directory'])
sys.path.insert(0,str(DIAGNOSTIC))
import work_transport as worklib
sys.path.insert(0,str(PRIOR))
import score_two as retained_score
import check_slip as retained_slip


def save(path,value):
    write(path,worklib.ordinary(value))


def folder(epoch):
    return ROOT/('epoch'+str(epoch))


def prior_epoch(epoch):
    position=CONFIG['checkpoint_epochs'].index(epoch)
    return CONFIG['start_index'] if position==0 else CONFIG['checkpoint_epochs'][position-1]


def inherited(epoch):
    return AUTHORITY/('epoch'+str(CONFIG['start_index'])) if epoch==CONFIG['checkpoint_epochs'][0] else folder(prior_epoch(epoch))

def previous_history(case,steps,epoch):
    directories=[Path(value) for value in CONFIG['history_directories']]
    directories.extend(folder(value) for value in CONFIG['checkpoint_epochs'] if value<=epoch)
    return retained_score.concatenate([load(directory/(case+'-'+str(steps)+'.npz')) for directory in directories])


def build(case,epoch,steps,captured,metadata,sample):
    known=load(AUTHORITY/(case+'-preflight-capture.npz'))
    require(all(np.array_equal(value[:CONFIG['native_prefix_replay']],known[name]) for name,value in captured.items()),'known1950 capture exact')
    prepared,_,background,_,_=EX.problem(case)
    direct=MetricCoupled(case,prepared,background,prefix(captured,case),metadata,sample)
    source=inherited(epoch)
    short=case+'-'+str(steps)
    saved=load(source/(short+'-terminal.npz'))
    if case=='cold':
        restore(direct,source/(short+'-terminal.npz'))
        return direct,None,saved
    system=worklib.Carried(direct,worklib.LiveSecond(case,prepared,background,prefix(captured,case),metadata,sample))
    require(int(saved['core_size'])==system.core_size and int(saved['native_size'])==system.core.native_size,'same complete native layout')
    require(np.array_equal(system.rhs(float(saved['tau']),saved['normalized']),saved['actual_rhs']),'complete inherited actual RHS exact')
    restore(direct,source/(short+'-parent-terminal.npz'))
    restore(direct,source/(short+'-approximate-terminal.npz'))
    return direct,system,saved


def coordinates(direct,system):
    active,selected=direct.active,system.reduced.selected
    indices=list(range(2*active,2*active+direct.width))
    units=list(direct.background_units)
    for begin in (system.core_size,system.core_size+2*active,system.core_size-2*active):
        indices.extend(begin+np.r_[selected,active+selected])
        units.extend(np.r_[system.core.error_units[selected],system.core.error_change_units[selected]])
    indices,units=np.array(indices,dtype=int),np.array(units)
    known=load(DIAGNOSTIC/'jets-64.npz')
    require(np.array_equal(indices,known['indices']) and np.array_equal(units,known['units']),'unchanged physical work coordinates')
    return indices,units


def rate_at(direct,clock,vector):
    result,_=worklib.pressure_rates(direct.model,direct.prepared,float(clock),vector)
    defect=vector.copy()
    defect[5:13]=0
    defect[13:17]=[math.fsum((vector[13+component],-vector[5+component],-vector[9+component])) for component in range(4)]
    defect_rate=worklib.pressure_rates(direct.model,direct.prepared,float(clock),defect)[0][6:9]
    return np.r_[result,defect_rate]


def initial_diagnostics(case,steps,epoch):
    return load(inherited(epoch)/(case+'-'+str(steps)+'-work-terminal.npz'))

def dense_quadrature(direct,solution,indices,units,diagnostic):
    rules=[np.polynomial.legendre.leggauss(order) for order in CONFIG['integration_orders']]
    nodes=np.unique(np.concatenate([rule[0] for rule in rules]))
    positions=[np.searchsorted(nodes,rule[0]) for rule in rules]
    for left,right in zip(solution.t[:-1],solution.t[1:]):
        guard()
        half=(right-left)/2
        clocks=(left+right)/2+half*nodes
        vectors=solution.sol(clocks)[indices,:].T*units
        rates=np.array([rate_at(direct,clock,vector) for clock,vector in zip(clocks,vectors)])
        integrals=np.array([half*np.sum(rule[1][:,None]*rates[selected],axis=0) for rule,selected in zip(rules,positions)])
        diagnostic['orders']+=integrals
        diagnostic['quadrature_75']+=abs(integrals[2]-integrals[1])
        diagnostic['quadrature_53']+=abs(integrals[1]-integrals[0])
        diagnostic['rounding']+=64*np.finfo(float).eps*half*np.sum(rules[2][1][:,None]*abs(rates[positions[2]]),axis=0)
        diagnostic['accepted_steps']+=1


def prepare():
    require(digest(AUTHORITY/'closeout.json')==CONFIG['authority_seal'],'physical/work authority seal')
    mapping=read(ROOT/'regime-inputs.json')
    for case in CONFIG['cases']:
        require(read(ROOT/(case+'-regime-result.json'))['passed'],'prospective regime check passed')
        mapping[str(ROOT/(case+'-regime-result.json'))]=digest(ROOT/(case+'-regime-result.json'))
        mapping[str(ROOT/(case+'-regime-capture.npz'))]=digest(ROOT/(case+'-regime-capture.npz'))
    check_inputs(mapping)
    report={}
    for epoch in CONFIG['checkpoint_epochs']:
        require(not folder(epoch).exists(),'new grouped batch folder')
        folder(epoch).mkdir()
        report[str(epoch)]={}
        for case in CONFIG['cases']:
            source=retained_score.source_paths(case)
            with np.load(source,allow_pickle=False) as archive:
                clocks=archive['conformal_time'][prior_epoch(epoch):epoch+1]
            require(len(clocks)==epoch-prior_epoch(epoch)+1 and np.all(np.diff(clocks)>0),'all original clocks retained')
            prepared,_,background,_,_=EX.problem(case)
            times=np.unique(np.r_[clocks,background.boundaries(float(clocks[0]),float(clocks[-1]))])
            background.evaluate(times)
            locations=np.searchsorted(times,clocks)
            require(np.array_equal(times[locations],clocks),'original/native clock mapping')
            np.savez_compressed(folder(epoch)/(case+'-clock.npz'),time=times,native_time=clocks,native_indices=locations,original_indices=np.arange(prior_epoch(epoch),epoch+1))
            report[str(epoch)][case]={'samples':len(times),'original_intervals':len(clocks)-1,'elapsed_Mpc':float(times[-1]-times[0])}
    save(ROOT/'frozen-norms.json',read(AUTHORITY/'frozen-norms.json'))
    for case in CONFIG['cases']:
        for steps in CONFIG['steps']:
            values=initial_diagnostics(case,steps,CONFIG['checkpoint_epochs'][0])
            np.savez_compressed(ROOT/(case+'-'+str(steps)+'-initial-work.npz'),**values)
    save(ROOT/'preparation.json',{'before_new_physics':True,'intervals':report,'diagnostic_anchor':3041,'physical_matching':3040,'initial_uncertainty_not_reset':True,'no_physical_error_norm_change':True,'elapsed_time_endpoint_chosen_before_physics':True})
    for path in ROOT.rglob('*'):
        if path.is_file() and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix=='.py':compile(path.read_text(encoding='utf-8'),str(path),'exec')
            mapping[str(path)]=digest(path)
    write(ROOT/'inputs.json',mapping)
    print(json.dumps(report),flush=True)

def preflight(case):
    inputs()
    label=case+'-preflight'
    checks={}
    with native_context(case,label) as (captured,metadata,sample):
        for steps in CONFIG['steps']:
            direct,system,saved=build(case,CONFIG['checkpoint_epochs'][0],steps,captured,metadata,sample)
            rhs=system.rhs if system else direct.rhs
            data=load(folder(CONFIG['checkpoint_epochs'][0])/(case+'-clock.npz'))
            left,right=map(float,data['time'][:2])
            require(left==float(saved['tau']),'saved start time')
            kwargs=dict(method='DOP853',rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(direct.prepared['elapsed'][8])/steps)
            plain=solve_ivp(rhs,(left,right),saved['normalized'].copy(),dense_output=False,**kwargs)
            dense=solve_ivp(rhs,(left,right),saved['normalized'].copy(),dense_output=True,**kwargs)
            checks[str(steps)+'_both_success']=plain.success and dense.success
            checks[str(steps)+'_accepted_times_exact']=np.array_equal(plain.t,dense.t)
            checks[str(steps)+'_physical_states_exact']=np.array_equal(plain.y,dense.y)
            scale=np.maximum(np.max(abs(dense.y),axis=1),1.)
            checks[str(steps)+'_dense_nodes']=bool(np.max(abs(dense.sol(dense.t)-dense.y)/scale[:,None])<=CONFIG['algebra_tolerance'])
            saved_rhs=saved['actual_rhs'] if system else saved['normalized_rhs']
            checks[str(steps)+'_initial_rhs_unchanged']=np.array_equal(rhs(left,saved['normalized']),saved_rhs)
            values=system.calculate(left,saved['normalized'],True)[1] if system else direct.evaluate(left,saved['normalized'])[1]
            previous=load(AUTHORITY/('epoch'+str(CONFIG['start_index']))/(case+'-'+str(steps)+'.npz'))
            checks[str(steps)+'_all_initial_outputs_exact']=all(np.array_equal(value,previous[name][-1]) for name,value in values.items())
            if system:
                indices,units=coordinates(direct,system)
                rate=rate_at(direct,left,saved['normalized'][indices]*units)
                checks[str(steps)+'_derived_initial_rate_finite']=bool(np.isfinite(rate).all())
                diagnostic=load(ROOT/(case+'-'+str(steps)+'-initial-work.npz'))
                dense_quadrature(direct,dense,indices,units,diagnostic)
                checks[str(steps)+'_dense_work_finite']=bool(all(np.isfinite(value).all() for value in diagnostic.values()))
        saved={'checks':checks,'passed':all(checks.values()),'case':case,'new_physical_states_retained':False,'native_rows':metadata['count']}
        save(ROOT/(label+'-result.json'),saved)
        require(saved['passed'],'non-invasive dense preflight failed: '+str([key for key,value in checks.items() if not value]))
    inputs()
    print(json.dumps({'case':case,'passed':True,'checks':len(checks)}),flush=True)


def run(case,epoch,steps):
    inputs()
    require(read(ROOT/(case+'-preflight-result.json'))['passed'],'dense preflight passed')
    if epoch!=CONFIG['checkpoint_epochs'][0]:
        require(read(ROOT/('epoch'+str(prior_epoch(epoch))+'-gate.json'))['passed'],'preceding cumulative physical/work gate passed')
    label=case+'-'+str(epoch)+'-'+str(steps)
    short=case+'-'+str(steps)
    with native_context(case,label) as (captured,metadata,sample):
        direct,system,saved=build(case,epoch,steps,captured,metadata,sample)
        clocks=load(folder(epoch)/(case+'-clock.npz'))
        times=clocks['time']
        current=saved['normalized'].copy()
        require(times[0]==float(saved['tau']),'continuous physical state')
        diagnostic=initial_diagnostics(case,steps,epoch)
        rhs=system.rhs if system else direct.rhs
        evaluate=(lambda clock,state:system.calculate(clock,state,True)[1]) if system else (lambda clock,state:direct.evaluate(clock,state)[1])
        if system:indices,units=coordinates(direct,system)
        initial=evaluate(float(times[0]),current)
        previous=load(inherited(epoch)/(short+'.npz'))
        require(all(np.array_equal(value,previous[name][-1]) for name,value in initial.items()),'all original boundary outputs exact')
        observed={name:np.empty((len(times),*np.asarray(value).shape)) for name,value in initial.items()}
        states=[current.copy()]
        work_history={name:[value.copy()] for name,value in diagnostic.items()}
        for name,value in initial.items():observed[name][0]=value
        evaluations=0
        accepted=0
        for position,(left,right) in enumerate(zip(times[:-1],times[1:])):
            guard()
            solution=solve_ivp(rhs,(float(left),float(right)),current,method='DOP853',rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(direct.prepared['elapsed'][8])/steps,dense_output=bool(system))
            require(solution.success,'unchanged live coupled evolution')
            current=solution.y[:,-1]
            if system:dense_quadrature(direct,solution,indices,units,diagnostic)
            else:diagnostic['accepted_steps']+=len(solution.t)-1
            evaluations+=solution.nfev
            accepted+=len(solution.t)-1
            states.append(current.copy())
            for name,value in evaluate(float(right),current).items():observed[name][position+1]=value
            for name,value in diagnostic.items():work_history[name].append(value.copy())
            if (position+1)%CONFIG['batch_boundaries']==0 or position==len(times)-2:
                np.savez_compressed(folder(epoch)/(short+'-boundary'+str(position+1)+'.npz'),tau=np.array(right),normalized=current,actual_rhs=rhs(float(right),current),completed=np.array(position+1),**{'work_'+name:value for name,value in diagnostic.items()})
                print(json.dumps({'label':label,'boundary':position+1,'total':len(times)-1,'accepted_steps':accepted}),flush=True)
        locations=clocks['original_indices']-CONFIG['first_index']
        require(np.array_equal(captured['clock'][locations],clocks['native_time']),'original native endpoints')
        reference=captured['observation_reference'][locations]
        control=np.column_stack((-CONFIG['retained_comoving_wave']*(reference[:,26]+reference[:,5])/reference[:,28],reference[:,9],reference[:,21],reference[:,20]-.75*reference[:,21],reference[:,26]-.75*reference[:,24]))
        np.savez_compressed(folder(epoch)/(short+'.npz'),time=times,extended=np.array(states),native_indices=clocks['native_indices'],native_control=control,**observed)
        np.savez_compressed(folder(epoch)/(short+'-work-history.npz'),time=times,**{name:np.array(value) for name,value in work_history.items()})
        np.savez_compressed(folder(epoch)/(short+'-work-terminal.npz'),**diagnostic)
        if system:
            core=current[:system.core_size]
            approximate,parent,_,_=system.core.unpack(core)
            checkpoint(direct,float(times[-1]),parent,folder(epoch)/(short+'-parent-terminal.npz'))
            checkpoint(direct,float(times[-1]),approximate[:system.core.native_size],folder(epoch)/(short+'-approximate-terminal.npz'))
            np.savez_compressed(folder(epoch)/(short+'-terminal.npz'),tau=np.array(times[-1]),normalized=current,actual_rhs=rhs(float(times[-1]),current),core_size=np.array(system.core_size),native_size=np.array(system.core.native_size),parent_indices=system.core.parent_indices,error_units=system.core.error_units,error_change_units=system.core.error_change_units)
            np.savez_compressed(folder(epoch)/(short+'-transport-terminal.npz'),tau=np.array(times[-1]),normalized=core,actual_rhs=system.core.rhs(float(times[-1]),core),native_size=np.array(system.core.native_size),parent_indices=system.core.parent_indices,error_units=system.core.error_units,error_change_units=system.core.error_change_units)
        else:checkpoint(direct,float(times[-1]),current,folder(epoch)/(short+'-terminal.npz'))
        save(ROOT/(label+'-result.json'),{'completed':True,'epoch':epoch,'case':case,'steps':steps,'samples':len(times),'evaluations':evaluations,'accepted_steps':accepted,'diagnostic_feedback':False,'no_memory_reset':True})
    inputs()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=('prepare','preflight','run'))
    parser.add_argument('--case',choices=CONFIG['cases'],default='heavy')
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=64)
    parser.add_argument('--epoch',type=int,choices=CONFIG['checkpoint_epochs'],default=CONFIG['checkpoint_epochs'][0])
    args=parser.parse_args()
    label='prepare' if args.command=='prepare' else args.case+'-'+('preflight' if args.command=='preflight' else str(args.epoch)+'-'+str(args.steps))
    with worker(label):
        if args.command=='prepare':prepare()
        elif args.command=='preflight':preflight(args.case)
        else:run(args.case,args.epoch,args.steps)
