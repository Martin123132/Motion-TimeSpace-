from live_work import *
import operator_repair as repair


def probe():
    inputs()
    source_map = read(ROOT/"repair-contract.json")["sources"]
    check_inputs(source_map)
    report = {"checks": {}, "samples": [], "original_gate_preserved": read(ROOT/"epoch4249-gate.json"), "replay_authorized_by_this_file": False}
    with native_context("heavy", "repair-probe") as (captured, metadata, sample):
        for steps in CONFIG["steps"]:
            direct, system, saved = build("heavy", 4249, steps, captured, metadata, sample)
            data = load(folder(4249)/("heavy-"+str(steps)+".npz"))
            positions = np.unique(np.linspace(0, len(data["time"])-1, 9, dtype=int))
            before = [system.calculate(float(data["time"][position]), data["extended"][position], True) for position in positions]
            require(np.array_equal(system.rhs(float(saved["tau"]),saved["normalized"]),saved["actual_rhs"]), "old authority restore before repair")
            repair.install(system)
            selected = direct._stable_photon_rows
            allowed = np.zeros(len(saved["normalized"]), dtype=bool)
            starts = [system.core_size-system.pair_size,system.core_size,system.core_size+system.pair_size]
            starts.extend(system.core_size+2*system.pair_size+index*system.pair_size for index in range(4))
            for start in starts:
                allowed[start+direct.active+selected] = True
            for position, (old_rhs, old_values) in zip(positions, before):
                clock = float(data["time"][position])
                state = data["extended"][position]
                new_rhs, new_values = system.calculate(clock, state, True)
                parent = system.core.unpack(state[:system.core_size])[1]
                packet = repair.transport.background_packet(direct,clock,parent)
                old, change = system.vectors(state[system.core_size:system.core_size+system.pair_size])
                first, _, extra = sample(clock,old,packet,False)
                second = sample(clock,old,packet,True)[0]
                change_rhs = sample(clock,change,packet,True)[0]
                analytic = repair.opacity_difference(float(extra[0]),float(packet[0]),float(extra[2]))
                decimal = repair.decimal_difference(extra[0],packet[0],extra[2])
                primitive = np.maximum(abs(first[selected])+abs(second[selected])+abs(extra[2]*old[selected]),np.finfo(float).tiny)
                operator_error = float(np.max(abs(second[selected]-first[selected]+analytic*old[selected])/primitive))
                tolerance = CONFIG["algebra_tolerance"]
                checks = {
                    "unmodified_rhs_rows_exact": np.array_equal(old_rhs[~allowed],new_rhs[~allowed]),
                    "all_physical_readouts_exact": all(np.array_equal(value,new_values[name]) for name,value in old_values.items() if name not in ("split_rhs_residual","split_rhs_scale")),
                    "opacity_decimal_agreement": abs(analytic-decimal) <= tolerance*max(abs(decimal),np.finfo(float).tiny),
                    "native_operator_equivalence": operator_error <= tolerance,
                    "finite_rhs": bool(np.isfinite(new_rhs).all()),
                }
                row = {"steps":steps,"position":int(position),"clock":clock,"native_operator_relative_error":operator_error,"opacity_delta":analytic,
                       "decimal_opacity_delta":decimal,"old_split_rhs_relative":maximum(old_values["split_rhs_residual"])/float(old_values["split_rhs_scale"]),
                       "new_split_rhs_relative":maximum(new_values["split_rhs_residual"])/float(new_values["split_rhs_scale"]),
                       "checks":checks}
                report["samples"].append(row)
                report["checks"].update({str(steps)+"_"+str(position)+"_"+name:bool(value) for name,value in checks.items()})
    report["checks"]["failed_original_gate_unchanged"] = not report["original_gate_preserved"]["passed"]
    report["checks"]["owner_released"] = read(ROOT/"repair-probe-owner-release.json")["cleared"]
    report["passed"] = all(report["checks"].values())
    report["check_count"] = len(report["checks"])
    save(ROOT/"repair-probe-result.json",report)
    inputs()
    check_inputs(source_map)
    print(json.dumps({"passed":report["passed"],"checks":report["check_count"],
        "worst_old_split_rhs":max(item["old_split_rhs_relative"] for item in report["samples"]),
        "worst_new_split_rhs":max(item["new_split_rhs_relative"] for item in report["samples"]),
        "failed_checks":[name for name,value in report["checks"].items() if not value]}),flush=True)
    require(report["passed"],"stable operator preflight")

if __name__ == "__main__":
    with worker("repair-probe"):
        probe()

