import importlib.util
import sys
import repair_replay_v2 as replay
from repair_replay_v2 import *


def explicit_module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    require(Path(module.__file__).resolve()==Path(path).resolve(),"explicit stage module")
    return module


scoring=explicit_module("tail_scoring_explicit",ORIGINAL/"score_live.py")
replay.scoring=scoring
saved_scoring=sys.modules.get("score_live")
sys.modules["score_live"]=scoring
try:
    exchange=explicit_module("tail_exchange_explicit",ORIGINAL/"photon_exchange.py")
finally:
    if saved_scoring is None:sys.modules.pop("score_live",None)
    else:sys.modules["score_live"]=saved_scoring


if __name__=="__main__":
    with worker("repair-v2-score-explicit"):
        save(REPLAY/"scoring-module-receipt.json",{
            "reason":"Repeated historical score_live module names plus inherited sys.path ordering selected the older phase scorer",
            "correct_file":str(ORIGINAL/"score_live.py"),"sha256":digest(ORIGINAL/"score_live.py"),
            "new_physical_evolution":False,"completed_32_64_reused":True,
            "frozen_completion_source":digest(Path(__file__))})
        replay.score()

