import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
original = root / 'verify_energy.py'
source = original.read_text(encoding='utf-8')
before = "or name.split(':')[0].endswith('_low')"
after = "or name.split(':')[0] not in ('finite', 'logarithm', 'total')"
if source.count(before) != 1:
    raise RuntimeError('Packet-selector boundary changed')
source = source.replace(before, after)
for name in ('verification-start.json', 'verification-end.json', 'verification.json'):
    source = source.replace("'" + name + "'", "'" + name.replace('verification', 'verification-v2') + "'")
producer = Path('C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102/final_epoch_real_source.py')
receipt = dict(original_verifier_sha256=hashlib.sha256(original.read_bytes()).hexdigest(), producer=str(producer),
    producer_sha256=hashlib.sha256(producer.read_bytes()).hexdigest(), numerical_arrays_changed=False,
    schema='Producer lines313..325: finite+finite_low; logarithm; total+total_low. rawsum/corr are audit state, not extra physical sources.',
    raw_failures_retained=True, tolerance=1e-10, selector_before=before, selector_after=after)
with (root / 'packet-schema-repair.json').open('x', encoding='utf-8') as stream:
    json.dump(receipt, stream, indent=2)
exec(compile(source, str(original), 'exec'), globals())
