import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
import psutil

ROOT = Path(__file__).resolve().parent
process = psutil.Process()
process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
process.cpu_affinity([4])


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(name, value):
    with (ROOT / name).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)


identity = dict(pid=process.pid, created_time=process.create_time(), command=process.cmdline())
save('close-start.json', identity)
checks = []
receipts = [read(path) for path in ROOT.glob('*-start.json') if path.name != 'close-start.json']
receipts.extend(dict(pid=pid, created_time=created, command=None) for pid, created in ((2136, 1794939468.543258), (22164, 1794940036.677909)))
for saved in receipts:
    try:
        candidate = psutil.Process(saved['pid'])
        same_birth = abs(candidate.create_time() - saved['created_time']) < .01
        if same_birth:
            command = candidate.cmdline()
            raise RuntimeError('Task-owned process still active: ' + str(saved['pid']) + ' ' + str(command))
        checks.append(dict(pid=saved['pid'], exited=True, reason='PID reused; command not inspected and process untouched'))
    except psutil.NoSuchProcess:
        checks.append(dict(pid=saved['pid'], exited=True, reason='PID absent'))
for path, expected in read(ROOT / 'inputs.json').items():
    if digest(Path(path)) != expected:
        raise RuntimeError('Frozen input changed: ' + path)
verification = read(ROOT / 'verification-v2.json')
if not verification['passed']:
    raise RuntimeError('Technical verification not passed')
for name, item in verification['output_histories'].items():
    if digest(ROOT / name) != item['sha256']:
        raise RuntimeError('Output history changed')
for path in ROOT.glob('*.py'):
    compile(path.read_text(encoding='utf-8'), str(path), 'exec')
if any(ROOT.rglob('__pycache__')):
    raise RuntimeError('Unexpected bytecode cache')
save('cleanup.json', dict(processes=checks, no_processes_killed=True, no_other_chats_touched=True,
    closer=identity, closer_exit_requires_foreground_return=True, goal_paused_for_model_switch=True))
inventory = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size) for path in ROOT.rglob('*') if path.is_file()}
save('closeout.json', dict(finished=datetime.now(timezone.utc).isoformat(), files=inventory, artifact_count=len(inventory),
    verified_technical_checks=len(verification['checks']), cumulative_source_integral_accepted=False,
    authoritative_verification='verification-v2.json', result='result-complete.json', physical_restart_replaced=False))
print(json.dumps(dict(closed=True, seal=digest(ROOT / 'closeout.json'), artifacts=len(inventory), closer=identity)), flush=True)
