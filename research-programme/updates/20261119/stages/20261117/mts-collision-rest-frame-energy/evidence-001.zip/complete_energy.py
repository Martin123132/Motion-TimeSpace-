import ast
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('retained_energy', ROOT / 'run_energy.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def serializable(value):
    if isinstance(value, module.np.generic):
        return value.item()
    raise TypeError(type(value).__name__)


def save(path, value):
    path = Path(path)
    if path.name == 'result.json':
        path = ROOT / 'result-complete.json'
    encoded = json.dumps(value, indent=2, allow_nan=False, default=serializable) + '\n'
    with path.open('x', encoding='utf-8') as stream:
        stream.write(encoded)


def compare_saved_source(label, steps, source):
    path = ROOT / f'source-{label}-{steps}.npz'
    before = module.digest(path)
    with module.np.load(path, allow_pickle=False) as saved:
        if set(saved.files) != set(source) or not all(module.np.array_equal(saved[name], value) for name, value in source.items()):
            raise RuntimeError('Saved numerical result differs: ' + str(path))
    if module.digest(path) != before:
        raise RuntimeError('Numerical result changed during readback')


tree = ast.parse((ROOT / 'run_energy.py').read_text(encoding='utf-8'))
function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'energy_history')
replaced = []
for node in ast.walk(function):
    if isinstance(node, ast.For):
        for index, statement in enumerate(node.body):
            if isinstance(statement, ast.With) and 'np.savez_compressed(stream, **source)' in ast.unparse(statement):
                replaced.append(ast.unparse(statement))
                node.body[index] = ast.parse('compare_saved_source(label, steps, source)').body[0]
if len(replaced) != 1:
    raise RuntimeError('Expected exactly one output-only boundary')
module.compare_saved_source = compare_saved_source
module.save = save
exec(compile(ast.fix_missing_locations(ast.Module(body=[function], type_ignores=[])), str(ROOT / 'run_energy.py'), 'exec'), module.__dict__)
process = module.psutil.Process()
process.nice(module.psutil.BELOW_NORMAL_PRIORITY_CLASS)
process.cpu_affinity([4])
receipt = dict(pid=process.pid, created_time=process.create_time(), command=process.cmdline(), threads=1, affinity=process.cpu_affinity())
save(ROOT / 'complete-start.json', receipt)
save(ROOT / 'serialization-repair.json', dict(reason='numpy boolean in summary was not JSON serializable; original partial result and failure retained',
    original_code_sha256=module.digest(ROOT / 'run_energy.py'), repair_sha256=module.digest(Path(__file__)),
    replaced_output_statement=replaced, numerical_algorithm_changed=False, reused_arrays=6,
    verification='Recompute only cheap saved-history readouts and check exact equality with all six saved arrays; no physical evolution'))
try:
    module.run()
    original_read = module.read
    def read_complete(path):
        return original_read(ROOT / 'result-complete.json' if Path(path).name == 'result.json' else path)
    module.read = read_complete
    module.verify()
finally:
    save(ROOT / 'complete-end.json', dict(process=receipt, finished=module.datetime.now(module.timezone.utc).isoformat(), seconds=module.time.monotonic()-module.START))
