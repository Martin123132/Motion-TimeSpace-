import importlib.util
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('energy_check', ROOT / 'run_energy.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
process = module.psutil.Process()
process.nice(module.psutil.BELOW_NORMAL_PRIORITY_CLASS)
process.cpu_affinity([4])
module.save(ROOT / 'verification-start.json', dict(pid=process.pid, created_time=process.create_time(), command=process.cmdline(), threads=1))
try:
    for path, expected in module.read(ROOT / 'inputs.json').items():
        module.guard()
        if module.digest(path) != expected:
            raise RuntimeError('Changed source: ' + path)
    result = module.read(ROOT / 'result-complete.json')
    inherited = [entry for entry in result['checks'] if entry['name'] not in ('radial18_all_gas_photon_pairs', 'radial26_all_gas_photon_pairs')]
    checks, reports = list(inherited), []
    for order in (18, 26):
        path = module.MICRO / f'final-epoch-real-v2-ray000/order-{order}/complete.npz'
        pairs, count, worst, worst_name = 0, 0, 0., ''
        with module.np.load(path, allow_pickle=False) as archive:
            for name in archive.files:
                if (':l0:' not in name and ':l1:' not in name) or name.split(':')[0].endswith('_low'):
                    continue
                values = archive[name]
                prefix, rest = name.split(':', 1)
                low_name = prefix + '_low:' + rest
                low = archive[low_name] if low_name in archive else module.np.zeros_like(values)
                if name.endswith(':actions'):
                    columns = (values[:, 0, :], values[:, -1, :], low[:, 0, :], low[:, -1, :])
                elif values.shape == (98,):
                    columns = (values[0], values[-1], low[0], low[-1])
                else:
                    continue
                for first, last, low_first, low_last in zip(*(module.np.asarray(value).ravel() for value in columns)):
                    numerator = abs(math.fsum((first, last, low_first, low_last)))
                    denominator = abs(math.fsum((first, low_first))) + abs(math.fsum((last, low_last)))
                    error = numerator / max(denominator, 1e-300)
                    if error > worst:
                        worst, worst_name = error, name
                    count += 1
                pairs += int(low_name in archive)
        checks.append(dict(name=f'radial{order}_compensated_energy_momentum_pairs', relative=worst, limit=module.ALGEBRA, passed=worst <= module.ALGEBRA))
        reports.append(dict(order=order, paired_high_low_blocks=pairs, scalar_tests=count, worst_relative=worst, worst_name=worst_name))
    outputs = {str(path.relative_to(ROOT)): dict(sha256=module.digest(path), bytes=path.stat().st_size) for path in ROOT.glob('source-*.npz')}
    checks.append(dict(name='six_retained_source_histories', passed=len(outputs) == 6))
    passed = all(item['passed'] for item in checks)
    module.save(ROOT / 'verification.json', dict(passed=passed, checks=checks, output_histories=outputs, corrected_packet_checks=reports,
        result_authority='result-complete.json for history readouts; this verification for compensated microscopic check',
        result_sha256=module.digest(ROOT / 'result-complete.json'), verifier_sha256=module.digest(Path(__file__)),
        old_raw_check_preserved=True, original_tolerances_unchanged=True,
        repair='Low floating-point residual limbs are not independent physical sources. Verify high+low together with compensated sums, retaining both limbs and original 1e-10 gate.',
        output_note='First serializer failed on numpy bool; complete summary saved by explicit scalar conversion. A later console-only print failed after complete file was written. Both receipts retained.',
        tiny_baseline_resolved=False, accumulated_integral_resolved=False, spectrum_claim=False, late_full_energy_moment_available=False))
    print(module.json.dumps(dict(passed=passed, checks=len(checks), compensated=reports, failed=[entry for entry in checks if not entry['passed']]), indent=2), flush=True)
    if not passed:
        raise RuntimeError('Verification failed; no promotion')
finally:
    module.save(ROOT / 'verification-end.json', dict(finished=module.datetime.now(module.timezone.utc).isoformat(), seconds=module.time.monotonic()-module.START))
