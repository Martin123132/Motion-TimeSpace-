import os
for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[variable] = '1'
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'

import ast
import gc
import hashlib
import json
import sys
import time
import traceback
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from types import SimpleNamespace
import psutil
import mpmath as mp
import numpy as np
from scipy.integrate import cumulative_simpson
from scipy.constants import Boltzmann, electron_mass, speed_of_light

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-carried-defect-budget-20261117'
MICRO = Path('C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102')
SEAL = 'ffc0253ae94bb6e873f0a25b0d0bcebd75fb4dfbb57baa68eac13f0199390f9e'
ALGEBRA = 1e-10
NUMERICAL = 2e-5
START = time.monotonic()
INPUTS = {}
CHECKS = []


def guard():
    if time.monotonic() - START > 1800 or datetime.now(timezone.utc) >= datetime(2026, 11, 17, 22, tzinfo=timezone.utc):
        raise RuntimeError('Current-turn bounded checkpoint reached')
    for directory in (ROOT, POST, POST / 'condensate-origin-20261003', MICRO, MICRO.parent):
        if (directory / 'STOP-REQUESTED').exists():
            raise RuntimeError('Owner hold: ' + str(directory))


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def tracked(path):
    path = Path(path)
    if digest(path) != INPUTS[str(path)]:
        raise RuntimeError('Changed frozen input: ' + str(path))
    return path


def maximum(values):
    return float(np.max(np.abs(values)))


def check(name, residual, scale=1., tolerance=ALGEBRA):
    error = float(abs(residual)) / max(float(abs(scale)), 1e-300)
    entry = dict(name=name, relative=error, limit=tolerance, passed=error <= tolerance)
    CHECKS.append(entry)
    return entry


def boolean(name, value):
    CHECKS.append(dict(name=name, passed=bool(value)))


def load(path, names=None):
    with np.load(tracked(path), allow_pickle=False) as data:
        return {name: data[name] for name in (data.files if names is None else names)}


def retained_function(path, function, owner=None, namespace=None):
    tree = ast.parse(tracked(path).read_text(encoding='utf-8'))
    statements = tree.body if owner is None else next(node.body for node in tree.body if isinstance(node, ast.ClassDef) and node.name == owner)
    node = next(node for node in statements if isinstance(node, ast.FunctionDef) and node.name == function)
    context = dict(namespace or {})
    exec(compile(ast.Module(body=[node], type_ignores=[]), str(path), 'exec'), context)
    return context[function]


def freeze():
    if digest(PREVIOUS / 'closeout.json') != SEAL or not read(PREVIOUS / 'verification.json')['passed']:
        raise RuntimeError('Previous complete physical authority differs')
    protocol = read(PREVIOUS / 'protocol.json')
    paths = [Path(__file__), ROOT / 'CONTRACT.md', ROOT / 'DERIVATION.md']
    paths.extend(PREVIOUS / name for name in ('closeout.json', 'inputs.json', 'protocol.json', 'verification.json', 'photon-energy-result.json', 'photon-exchange-result.json', 'PHOTON-ENERGY-DERIVATION.md', 'photon_energy.py', 'physical-endpoint.json'))
    paths.extend([POST / 'mts-two-epoch-coupled-continuation-20261117/check_slip.py', POST / 'mts-coupled-metric-consistency-20261117/packet-schema.json'])
    paths.extend(POST / 'mts-coupled-metric-consistency-20261117/native/fortran' / name for name in ('mts_metric_hook.inc', 'mts_response_hook.inc'))
    paths.append(POST / 'condensate-origin-20261003/finite-real-mixed-source-20261026/density236.py')
    paths.extend(MICRO / name for name in ('full_tail_action.py', 'exact_kinematic_cache.py', 'final-epoch-real-source-ray000/protocol.json', 'final-stable-real-batch-rays037-038/common-coverage.json'))
    for ray in (0, 11, 38):
        paths.append(MICRO / f'final-epoch-kinematic-bank/ray-{ray:03d}-kernel.json')
    for order in (18, 26):
        paths.append(MICRO / f'final-epoch-real-v2-ray000/order-{order}/complete.npz')
    directories = [Path(value) for value in protocol['history_directories']]
    directories.extend(PREVIOUS / f'epoch{epoch}' for epoch in protocol['checkpoint_epochs'])
    for case in ('cold', 'heavy'):
        for steps in (32, 64):
            paths.extend(directory / f'{case}-{steps}.npz' for directory in directories)
            for mode in (('baseline',) if case == 'cold' else ('parent', 'approximate')):
                suffix = '' if case == 'cold' else '-' + mode
                paths.append(PREVIOUS / f'epoch4252/{case}-{steps}{suffix}-terminal.npz')
                paths.append(PREVIOUS / f'damping-{case}_{mode}-{steps}.npz')
    inherited = read(PREVIOUS / 'inputs.json')
    inherited.update({str(PREVIOUS / name): item['sha256'] for name, item in read(PREVIOUS / 'closeout.json')['files'].items()})
    mapping = {}
    for path in dict.fromkeys(paths):
        guard()
        current = digest(path)
        known = inherited.get(str(path)) or inherited.get(str(path).replace('\\', '/'))
        if known and current != known:
            raise RuntimeError('Consumed authority differs: ' + str(path))
        mapping[str(path)] = current
    save(ROOT / 'inputs.json', mapping)
    save(ROOT / 'protocol.json', dict(previous_seal=SEAL, directories=list(map(str, directories)), algebra_tolerance=ALGEBRA,
        numerical_tolerance=NUMERICAL, quadrature_strides=[1, 2, 4], cases=['cold', 'heavy'], steps=[32, 64],
        physical_reintegration=False, fitted_parameters=0, quantum_measure_separate=True,
        source_scope='Elastic slip photon-rest energy only; independent non-elastic energy moment still required',
        micro_scope='Original warm packets, rays0/11/38 kinematics and radial ray0; no temperature transplantation'))
    print(json.dumps(dict(frozen=len(mapping), history_blocks=len(directories))), flush=True)


def identities():
    for index, alpha in enumerate(map(Fraction, ('-0.1', '-0.000000000001', '0', '0.0000000000000001', '0.1'))):
        baryon, photon, force, rest_heat = map(Fraction, ('0.03', '-0.01', '0.2', '-0.07'))
        lab = rest_heat + baryon * force
        photon_heat = -lab + photon * force
        boolean(f'partition{index}', rest_heat + photon_heat == (photon - baryon) * force)
        boolean(f'lab_cancellation{index}', lab + (-lab) == 0)
        slip, delta = Fraction(7, 13), Fraction(-3, 19)
        factor = (1 + alpha) ** -2
        change = -alpha * (2 + alpha) / (1 + alpha) ** 2
        boolean(f'denominator_response{index}', change == factor - 1)
        boolean(f'finite_source{index}', factor * (slip + delta) ** 2 - slip ** 2 == change * slip ** 2 + factor * delta * (2 * slip + delta))
    for energy in map(mp.mpf, ('0.001', '0.000001', '0.000000001')):
        cosine = mp.mpf('.3')
        recoil = energy ** 2 * (1 - cosine) / (1 + energy * (1 - cosine))
        check('Born_recoil_' + str(energy), energy - energy / (1 + energy * (1 - cosine)) - recoil, energy)
        check('Thomson_recoil_scaling_' + str(energy), recoil / energy - energy * (1 - cosine) / (1 + energy * (1 - cosine)))
        boolean('positive_recoil_' + str(energy), recoil > 0)


def histories(case, steps, directories):
    names = ['time', 'extended', 'metric'] + (['parent_metric'] if case == 'heavy' else [])
    parts = []
    for directory in directories:
        guard()
        piece = load(Path(directory) / f'{case}-{steps}.npz', names)
        if parts:
            for name in names:
                if not np.array_equal(parts[-1][name][-1], piece[name][0]):
                    raise RuntimeError('History join differs: ' + name)
            piece = {name: value[1:] for name, value in piece.items()}
        parts.append(piece)
    data = {name: np.concatenate([piece[name] for piece in parts]) for name in names}
    if not np.all(np.diff(data['time']) > 0):
        raise RuntimeError('Non-increasing saved clocks')
    return data


def read_source(data, terminal, mode, columns, native_state):
    state = native_state(data, terminal, mode)
    active = int(terminal['dimensions'][1])
    indices = [3, int(terminal['signature'][3])]
    old = state[:, indices] * terminal['state_units'][indices]
    change = state[:, [active + index for index in indices]] * terminal['delta_units'][indices]
    slip = old[:, 0] - .75 * old[:, 1]
    slip_change = change[:, 0] - .75 * change[:, 1]
    alpha = state[:, 2 * active] * terminal['background_units'][0]
    packet = data[('parent_' if mode == 'parent' else '') + 'metric']
    species = packet[..., :84].reshape(len(packet), 2, 7, 12)
    photon_weight = species[:, :, 2, 0]
    opacity = packet[..., columns['opacity']]
    coefficient = (4 / 3) * opacity[:, 0]
    factor = (1 + alpha) ** -2
    factor_change = -alpha * (2 + alpha) / (1 + alpha) ** 2
    original = coefficient * slip ** 2
    coherent = coefficient * factor * (slip + slip_change) ** 2
    delta = coefficient * (factor_change * slip ** 2 + factor * slip_change * (2 * slip + slip_change))
    old_size = abs(old[:, 0]) + .75 * abs(old[:, 1])
    change_size = abs(change[:, 0]) + .75 * abs(change[:, 1])
    primitive = abs(coefficient) * (abs(factor_change) * old_size ** 2 + abs(factor) * change_size * (2 * old_size + change_size))
    return dict(time=data['time'], original=original, coherent=coherent, change=delta, primitive=primitive,
        photon_weight=photon_weight, alpha=alpha, slip=slip, slip_change=slip_change, scale=packet[..., columns['scale']])


def energy_history():
    protocol = read(ROOT / 'protocol.json')
    columns = {name: 84 + index for index, name in enumerate(read(tracked(POST / 'mts-coupled-metric-consistency-20261117/packet-schema.json'))['global_columns'])}
    native_state = retained_function(POST / 'mts-two-epoch-coupled-continuation-20261117/check_slip.py', 'native_state', namespace={'np': np})
    values, summaries = {}, {}
    for case in ('cold', 'heavy'):
        for steps in (32, 64):
            data = histories(case, steps, protocol['directories'])
            for mode in (('baseline',) if case == 'cold' else ('parent', 'approximate')):
                label = case + '_' + mode
                suffix = '' if case == 'cold' else '-' + mode
                terminal = load(PREVIOUS / f'epoch4252/{case}-{steps}{suffix}-terminal.npz')
                source = read_source(data, terminal, mode, columns, native_state)
                replay = read_source(data, terminal, mode, columns, native_state)
                boolean(f'{label}{steps}_exact_replay', all(np.array_equal(source[key], replay[key]) for key in source))
                damping = load(PREVIOUS / f'damping-{label}-{steps}.npz')
                boolean(f'{label}{steps}_same_times', np.array_equal(source['time'], damping['time']))
                boolean(f'{label}{steps}_positive_Thomson_heating', np.all(source['original'] >= 0) and np.all(source['coherent'] >= 0))
                check(f'{label}{steps}_old_D_over_B', maximum(source['original'] - damping['old'] / source['photon_weight'][:, 0]), maximum(source['original']))
                check(f'{label}{steps}_coherent_D_over_B', maximum(source['coherent'] - damping['coherent'] / source['photon_weight'][:, 1]), maximum(source['coherent']))
                stable_from_damping = (1 + source['alpha']) ** 2 * damping['change'] / source['photon_weight'][:, 0] + source['original'] * source['alpha'] * (2 + source['alpha'])
                check(f'{label}{steps}_independent_stable_denominator', maximum(source['change'] - stable_from_damping), maximum(source['primitive']))
                check(f'{label}{steps}_direct_difference', maximum(source['coherent'] - source['original'] - source['change']), maximum(source['original'] + source['coherent']))
                integrals = {}
                for stride in (1, 2, 4):
                    indices = np.unique(np.r_[np.arange(0, len(source['time']), stride), len(source['time']) - 1])
                    integrals[stride] = float(cumulative_simpson(source['change'][indices], x=source['time'][indices], initial=0)[-1])
                source['integrated_change'] = cumulative_simpson(source['change'], x=source['time'], initial=0)
                source['integrated_primitive'] = cumulative_simpson(source['primitive'], x=source['time'], initial=0)
                quadrature = abs(integrals[1] - integrals[2]) + abs(integrals[2] - integrals[4])
                numerical = dict(final_fractional_source_per_Mpc=float(source['change'][-1]), final_integrated_fractional_source=integrals[1],
                    quadrature_estimate=quadrature, quadrature_strides=integrals, samples=len(source['time']),
                    start_Mpc=float(source['time'][0]), end_Mpc=float(source['time'][-1]),
                    maximum_unweighted_denominator_omission=float(maximum(source['change'] - damping['change'] / source['photon_weight'][:, 0])))
                summaries[f'{label}_{steps}'] = numerical
                with (ROOT / f'source-{label}-{steps}.npz').open('xb') as stream:
                    np.savez_compressed(stream, **source)
                values[label, steps] = source
            del data
            gc.collect()
    precision = {}
    for label in ('cold_baseline', 'heavy_parent', 'heavy_approximate'):
        high, low = values[label, 64], values[label, 32]
        boolean(label + '_comparison_same_clocks', np.array_equal(high['time'], low['time']))
        rounding = 64 * np.finfo(float).eps * maximum(high['primitive'] + low['primitive'])
        ratio = (maximum(high['change'] - low['change']) + rounding) / max(maximum(high['change']), 1e-300)
        integral_error = abs(high['integrated_change'][-1] - low['integrated_change'][-1])
        integral_error += sum(summaries[f'{label}_{steps}']['quadrature_estimate'] for steps in (32, 64))
        integral_error += 64 * np.finfo(float).eps * maximum(high['integrated_primitive'] + low['integrated_primitive'])
        integral_ratio = integral_error / max(abs(high['integrated_change'][-1]), 1e-300)
        precision[label] = dict(source_relative=ratio, source_resolved=ratio <= NUMERICAL, integral_relative=float(integral_ratio),
            integral_resolved=integral_ratio <= NUMERICAL, absolute_integral_allowance=float(integral_error), tolerance=NUMERICAL)
    parent, approx = values['heavy_parent', 64], values['heavy_approximate', 64]
    allowance = maximum(parent['change'] - values['heavy_parent', 32]['change']) + maximum(approx['change'] - values['heavy_approximate', 32]['change'])
    allowance += 64 * np.finfo(float).eps * maximum(parent['primitive'] + approx['primitive'])
    comparison = (maximum(parent['change'] - approx['change']) + allowance) / max(maximum(parent['change']), 1e-300)
    return dict(summaries=summaries, own_precision=precision, approximate_parent_relative=comparison,
        approximate_parent_pass=comparison <= NUMERICAL, units='source Mpc^-1; integral dimensionless; stored real mode without phase/power normalization',
        interpretation='Elastic slip rest-energy source diagnostic, not full spectrum, all-channel gas heat or observed evidence',
        inherited_budgets=str(PREVIOUS / 'verification.json'), inherited_tiny_baseline_flag_retained=True)


def minkowski(left, right):
    return -left[0] * right[0] + mp.fsum(left[index] * right[index] for index in (1, 2, 3))


def boost(velocity):
    squared = mp.fsum(value ** 2 for value in velocity)
    gamma = 1 / mp.sqrt(1 - squared)
    matrix = mp.eye(4)
    matrix[0, 0] = gamma
    for index in range(3):
        matrix[0, index + 1] = matrix[index + 1, 0] = gamma * velocity[index]
        for other in range(3):
            matrix[index + 1, other + 1] += gamma ** 2 * velocity[index] * velocity[other] / (gamma + 1)
    return matrix


def event_projection():
    event_function = retained_function(POST / 'condensate-origin-20261003/finite-real-mixed-source-20261026/density236.py', 'event', owner='Direction', namespace={'mp': mp, 'scalar': mp.mpf})
    records = []
    with mp.workdps(80):
        observer = boost(list(map(mp.mpf, ('.003', '.002', '-.001'))))
        unit = mp.matrix([1, 0, 0, 0])
        for ray in (0, 11, 38):
            cached = read(tracked(MICRO / f'final-epoch-kinematic-bank/ray-{ray:03d}-kernel.json'))['identity']
            transform = mp.matrix(cached['transform'])
            owner = SimpleNamespace(**{name: mp.mpf(cached[name]) for name in ('energy', 'cosine', 'hard0', 'final0', 'temperature', 'doppler')})
            owner.direction = mp.matrix(cached['direction'])
            owner.recoil0 = mp.matrix(cached['recoil0'])
            owner.hard_direction = mp.matrix([mp.sqrt(1 - owner.cosine ** 2), 0, owner.cosine])
            bath = mp.matrix(cached['bath'])
            check(f'ray{ray}_bath_to_bulk_rest', mp.norm(transform * bath - unit))
            metric = mp.diag([-1, 1, 1, 1])
            check(f'ray{ray}_Lorentz', mp.norm(transform.T * metric * transform - metric))
            for frequency in map(mp.mpf, ('0.000001', '.01', '1', '3')):
                for sign in (-1, 1):
                    guard()
                    event = event_function(owner, sign * frequency * owner.temperature / owner.doppler)
                    gas = transform * mp.matrix([event['kinetic'], *event['recoil']])
                    photons = transform * mp.matrix([event['hard'] + event['soft'] - owner.energy, *(-event['recoil'])])
                    label = f'ray{ray}_x{frequency}_sign{sign}'
                    check(label + '_event_conservation', mp.norm(gas + photons), mp.norm(gas) + mp.norm(photons))
                    heat = -minkowski(unit, gas)
                    check(label + '_thermal_bulk_projection', heat + minkowski(bath, mp.matrix([event['kinetic'], *event['recoil']])), mp.norm(gas))
                    moved_gas, moved_bath = observer * gas, observer * unit
                    moved_heat = -minkowski(moved_bath, moved_gas)
                    check(label + '_observer_invariance', moved_heat - heat, mp.norm(gas))
                    work = mp.fsum(moved_bath[index] * moved_gas[index] / moved_bath[0] for index in (1, 2, 3))
                    check(label + '_work_heat_split', moved_gas[0] - work - heat / moved_bath[0], mp.norm(gas))
                    records.append(dict(ray=ray, frequency=float(frequency), sign=sign, individual_electron_rest_recoil=float(event['kinetic']), bulk_gas_rest_energy=float(heat),
                        lab_photon_energy=float(photons[0]), units='electron rest energy per event; no occupation/rate/ensemble weights'))
    return records


def saved_micro_exchange():
    report = []
    for order in (18, 26):
        path = tracked(MICRO / f'final-epoch-real-v2-ray000/order-{order}/complete.npz')
        blocks, comparisons, worst = 0, 0, 0.
        with np.load(path, allow_pickle=False) as data:
            for name in data.files:
                if ':l0:' not in name and ':l1:' not in name:
                    continue
                values = data[name]
                if name.endswith(':actions'):
                    first, last = values[:, 0, :], values[:, -1, :]
                elif values.shape == (98,):
                    first, last = values[0], values[-1]
                else:
                    continue
                residual = np.abs(first + last) / np.maximum(np.abs(first) + np.abs(last), 1e-300)
                worst = max(worst, maximum(residual))
                comparisons += int(np.size(residual))
                blocks += 1
            for case in ('cold', 'heavy'):
                boolean(f'radial{order}_{case}_present', any(f':{case}-s1:' in name for name in data.files))
        check(f'radial{order}_all_gas_photon_pairs', worst)
        report.append(dict(order=order, blocks=blocks, paired_entries=comparisons, maximum_relative=worst,
            scope='Original warm ray0 radial/separator source only, both baseline/MTS, all retained components'))
    coverage = read(tracked(MICRO / 'final-stable-real-batch-rays037-038/common-coverage.json'))
    warm = read(tracked(MICRO / 'final-epoch-real-source-ray000/protocol.json'))['theta']
    native = np.array([3501., 5001.]) * 2.7255 * Boltzmann / (electron_mass * speed_of_light ** 2)
    return dict(radial_checks=report, real_angular_coverage=[coverage['individually_verified'], coverage['grid_directions']],
        warm_theta=warm, native_theta_range=native.tolist(), warm_over_native_range=(warm / native[::-1]).tolist(),
        late_numeric_micro_transfer_authorized=False, reason='Different temperature and incomplete event/angular coverage; no inferred late spectral distribution')


def run():
    global INPUTS
    INPUTS = read(ROOT / 'inputs.json')
    for path in INPUTS:
        guard()
        tracked(path)
    identities()
    history = energy_history()
    events = event_projection()
    microscopic = saved_micro_exchange()
    for path in INPUTS:
        guard()
        tracked(path)
    passed = all(item['passed'] for item in CHECKS)
    save(ROOT / 'result.json', dict(checks=CHECKS, technical_pass=passed, history=history, event_projections=events,
        microscopic=microscopic, new_fitted_parameters=0, physical_history_reintegrated=False, quantum_measure_separate=True))
    print(json.dumps(dict(checks=len(CHECKS), failed=[item for item in CHECKS if not item['passed']], source=history['own_precision'],
        approximate_parent=history['approximate_parent_relative'], microscopic=microscopic)), flush=True)
    if not passed:
        raise RuntimeError('Technical gate failed; preserve and inspect')


def verify():
    for path, expected in read(ROOT / 'inputs.json').items():
        guard()
        if digest(path) != expected:
            raise RuntimeError('Input changed after calculation: ' + path)
    result = read(ROOT / 'result.json')
    if not result['technical_pass'] or not all(item['passed'] for item in result['checks']):
        raise RuntimeError('Technical verification failed')
    outputs = {str(path.relative_to(ROOT)): dict(sha256=digest(path), bytes=path.stat().st_size) for path in ROOT.glob('source-*.npz')}
    if len(outputs) != 6:
        raise RuntimeError('Missing paired source histories')
    save(ROOT / 'verification.json', dict(passed=True, checks=len(result['checks']), unchanged_inputs=len(read(ROOT / 'inputs.json')),
        output_histories=outputs, tiny_baseline_resolved=result['history']['own_precision']['cold_baseline']['source_resolved'],
        spectrum_claim=False, late_full_energy_moment_available=False))
    print(json.dumps(dict(verified=True, checks=len(result['checks']), unchanged_inputs=len(read(ROOT / 'inputs.json')))), flush=True)


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode not in ('freeze', 'run', 'verify'):
        raise ValueError('freeze, run or verify required')
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    receipt = dict(pid=process.pid, created_time=process.create_time(), command=process.cmdline(), affinity=process.cpu_affinity(), priority=process.nice(), threads=1)
    save(ROOT / (mode + '-start.json'), receipt)
    try:
        guard()
        globals()[mode]()
    except BaseException as error:
        save(ROOT / (mode + '-failure.json'), dict(error=str(error), traceback=traceback.format_exc()))
        raise
    finally:
        save(ROOT / (mode + '-end.json'), dict(process=receipt, seconds=time.monotonic()-START, finished=datetime.now(timezone.utc).isoformat(), failure=(ROOT / (mode + '-failure.json')).exists()))
