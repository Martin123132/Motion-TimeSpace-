from score_live import *


def new_work_increment(epoch):
    result={}
    first=CONFIG["start_index"]
    for case in CONFIG["cases"]:
        work={steps:work_history(case,steps,epoch) for steps in CONFIG["steps"]}
        clock=load(AUTHORITY/"epoch3046"/(case+"-64-terminal.npz"))["tau"]
        locations={steps:int(np.flatnonzero(values["time"]==clock)[0]) for steps,values in work.items()}
        require(np.array_equal(work[32]["time"],work[64]["time"]),"paired work clocks")
        result[case]={}
        for component,name in enumerate(("old","coherent","coherent_minus_original")):
            fine=work[64]["orders"][:,2,component]+work[64]["orders"][:,2,3+component]
            coarse=work[32]["orders"][:,2,component]+work[32]["orders"][:,2,3+component]
            location=locations[64]
            high_increment=fine[location:]-fine[location]
            low_increment=coarse[location:]-coarse[location]
            allowance=0.
            for steps in CONFIG["steps"]:
                for family in ("quadrature_75","quadrature_53","rounding"):
                    values=work[steps][family]
                    increase=values[-1,component]+values[-1,3+component]-values[location,component]-values[location,3+component]
                    require(increase>=-np.finfo(float).eps*maximum(values),"nondecreasing carried allowance")
                    allowance+=max(0.,float(increase))
            subtraction=64*np.finfo(float).eps*maximum(abs(fine[location:])+abs(fine[location])+abs(coarse[location:])+abs(coarse[location]))
            resolution=maximum(high_increment-low_increment)
            result[case][name]={"start_epoch":first,"end_epoch":epoch,"increment_final":float(high_increment[-1]),"amplitude":maximum(high_increment),"paired_step_difference":resolution,"local_quadrature_rounding":allowance,"subtraction_rounding":subtraction,"increment_numerical_comparison":ratio(resolution+allowance+subtraction,maximum(high_increment)),"inherited_state_uncertainty_removed":False}
    return result


def calculate_consequences(epoch):
    data={case+"-"+str(steps)+".npz":previous_history(case,steps,epoch) for case in CONFIG["cases"] for steps in CONFIG["steps"]}
    projection=retained_score.projection(data)
    clock_support={}
    for case in CONFIG['cases']:
        path=retained_score.source_paths(case)
        with np.load(path,allow_pickle=False) as archive:
            clocks=archive['conformal_time']
            scales=archive['requested_scale']
        start=CONFIG['start_index']
        clock_support[case]={'source':str(path),'start_index':start,'end_index':epoch,'reference_scale_start':float(scales[start]),'reference_scale_end':float(scales[epoch]),'reference_redshift_start':float(1/scales[start]-1),'reference_redshift_end':float(1/scales[epoch]-1),'conformal_time_start_Mpc':float(clocks[start]),'conformal_time_end_Mpc':float(clocks[epoch]),'last_available_index':len(clocks)-1,'last_available_conformal_time_Mpc':float(clocks[-1]),'last_available_reference_redshift':float(1/scales[-1]-1),'reference_labels_are_not_a_new_observation_mapping':True}
    source={}
    for case in CONFIG["cases"]:
        source[case]={}
        high,low=data[case+"-64.npz"],data[case+"-32.npz"]
        for mode,prefix_name in ((("parent","parent_"),("approximate","")) if case=="heavy" else (("baseline",""),)):
            change=high[prefix_name+"source_change"]
            change_low=low[prefix_name+"source_change"]
            source[case][mode]={}
            for index,name in enumerate(("density","current","pressure")):
                primitive=abs(high[prefix_name+"source"])+abs(change)+abs(low[prefix_name+"source"])+abs(change_low)
                if index in (0,2):
                    scale=maximum(primitive[:,0]+primitive[:,2])
                else:
                    scale=maximum(primitive[:,index])
                source[case][mode][name]={"final":float(change[-1,index]),"amplitude":maximum(change[:,index]),"precision":conservative(0.,maximum(change[:,index]-change_low[:,index]),maximum(change[:,index]),scale)}
    return {"last_epoch":epoch,"scope":"Retained coherent-minus-original response within each baseline/MTS branch; not an MTS-minus-baseline observational fit or a common-redshift cross-model statistic.","reference_clock_support":clock_support,"cumulative_physical_projection":projection,"stable_paired_source_response":source,"new_window_work_increment":new_work_increment(epoch),"tiny_total_work_error_is_separate":True,"new_fitted_parameters":0}


if __name__=="__main__":
    with worker("consequences"):
        inputs()
        epoch=CONFIG["checkpoint_epochs"][-1]
        require(read(ROOT/("epoch"+str(epoch)+"-gate.json"))["passed"],"full prospective window gate")
        manifest={str(ROOT/name):digest(ROOT/name) for name in ("consequences.py","ANALYSIS-CONTRACT.md")}
        for current in CONFIG["checkpoint_epochs"]:
            for case in CONFIG["cases"]:
                for steps in CONFIG["steps"]:
                    for suffix in (".npz","-work-history.npz"):
                        path=folder(current)/(case+"-"+str(steps)+suffix)
                        manifest[str(path)]=digest(path)
        save(ROOT/"consequences-inputs.json",manifest)
        first=calculate_consequences(epoch)
        second=calculate_consequences(epoch)
        require(worklib.ordinary(first)==worklib.ordinary(second),"physical readout reproducible")
        check_inputs(manifest)
        save(ROOT/"physical-consequences.json",first)
        save(ROOT/"consequences-verification.json",{"replay_exact":True,"frozen_source_hashes_unchanged":True,"no_new_evolution_or_fit":True,"passed":True})
        inputs()
        print(json.dumps({"last_epoch":epoch,"replay_exact":True,"no_new_evolution_or_fit":True}),flush=True)
