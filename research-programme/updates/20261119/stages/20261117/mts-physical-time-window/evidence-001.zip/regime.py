from restart_bridge import *
import argparse

AUTHORITY = Path(CONFIG["authority_directory"])


def prepare():
    require(digest(AUTHORITY/"closeout.json") == CONFIG["authority_seal"], "authority seal")
    closure = read(AUTHORITY/"closeout.json")
    require(closure["last_epoch"] == 3046 and closure["final_gate"]["passed"], "verified physical authority")
    mapping = read(AUTHORITY/"inputs.json")
    mapping[str(AUTHORITY/"closeout.json")] = CONFIG["authority_seal"]
    mapping.update({str(AUTHORITY/name):entry["sha256"] for name,entry in closure["artifacts"].items()})
    check_inputs(mapping)
    source_paths = {
        "cold": POST/"condensate-origin-20261003/native-two-field-transfer-20261007/runs/final-bg8-start/cold.npz",
        "heavy": POST/"condensate-origin-20261003/resolved-matter-spectrum-20261007/runs/exact-grid/chunk-0384.npz"
    }
    batches = {}
    for case,path in source_paths.items():
        source = load(path)
        clocks = source["conformal_time"]
        first = CONFIG["start_index"]
        target = int(np.flatnonzero(clocks >= clocks[first]+1.)[0])
        require(target == CONFIG["last_index"], "prospective one-Mpc endpoint")
        batches[case] = {"start":first,"last":target,"elapsed_Mpc":float(clocks[target]-clocks[first]),"source":str(path),"ends":CONFIG["checkpoint_epochs"]}
        previous = first
        for end in CONFIG["checkpoint_epochs"]:
            require(0 < end-previous <= 128, "bounded original-interval grouping")
            require(np.all(np.diff(clocks[previous:end+1])>0), "ordered original clocks")
            previous=end
        require(previous==target, "complete candidate window")
        mapping[str(path)] = digest(path)
    write(ROOT/"clock-plan.json",batches)
    for name in ("restart_support.py","restart_bridge.py","protocol.json","regime.py","REGIME-CONTRACT.md","clock-plan.json"):
        path=ROOT/name
        if path.suffix==".py":compile(path.read_text(encoding="utf-8"),str(path),"exec")
        mapping[str(path)] = digest(path)
    write(ROOT/"regime-inputs.json",mapping)
    print(json.dumps(batches),flush=True)


def inspect_case(case):
    mapping=read(ROOT/"regime-inputs.json")
    check_inputs(mapping)
    label=case+"-regime"
    with native_context(case,label) as (captured,metadata,sample):
        known=load(AUTHORITY/(case+"-preflight-capture.npz"))
        checks={name:bool(np.array_equal(values[:CONFIG["native_prefix_replay"]],known[name])) for name,values in captured.items()}
        checks["full_candidate_count"]=metadata["count"]==CONFIG["last_index"]-CONFIG["first_index"]+1
        checks["same_full_signature"]=bool(np.all(captured["signature"]==captured["signature"][0]))
        checks["no_new_native_layout"]=metadata["signature"]==read(AUTHORITY/(case+"-preflight-capture.json"))["signature"]
        require(all(checks.values()), "candidate prefix or regime mismatch")
        prepared,_,background,_,_=EX.problem(case)
        direct=MetricCoupled(case,prepared,background,prefix(captured,case),metadata,sample)
        for steps in CONFIG["steps"]:
            terminal=AUTHORITY/"epoch3046"/(case+"-"+str(steps)+("-parent" if case=="heavy" else "")+"-terminal.npz")
            restore(direct,terminal)
            checks["fresh_owner_restore_"+str(steps)]=True
        write(ROOT/(label+"-result.json"),{"case":case,"checks":checks,"passed":all(checks.values()),"count":metadata["count"],"physical_evolution_started":False,"fixed_regime_supported_on_saved_native_grid":True})
    check_inputs(mapping)
    print(json.dumps({"case":case,"passed":True,"checks":len(checks),"native_count":metadata["count"]}),flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("command",choices=("prepare","inspect"))
    parser.add_argument("--case",choices=CONFIG["cases"],default="heavy")
    args=parser.parse_args()
    with worker("regime-prepare" if args.command=="prepare" else args.case+"-regime"):
        if args.command=="prepare":prepare()
        else:inspect_case(args.case)
