from field_control import Dataset,ROOT,bank,np,as_decimal,Decimal,localcontext,geometry,interp,require
import math


def wordrange(value):
    center=as_decimal(value)
    return ((center+as_decimal(np.nextafter(float(value),-np.inf)))/2,
            (center+as_decimal(np.nextafter(float(value),np.inf)))/2)


def checked(data):
    rules={order:[(as_decimal(n),as_decimal(w)) for n,w in zip(*np.polynomial.legendre.leggauss(order))] for order in (4,8,16)}
    positions=[]
    totals=Decimal(0)
    error=Decimal(0)
    begin=data.idx-4
    anchor=data.knot(begin)[1]
    rows=[]
    bounds=[]
    for index in range(begin,begin+10):
        t0,f0,_,_=data.knot(index)
        low,high=wordrange(f0)
        bounds.append((low-anchor-totals,high-anchor-totals,error))
        if index==begin+9:
            break
        t1,f1,_,_=data.knot(index+1)
        minimum,spacing=map(as_decimal,(data.bg.minimum,data.bg.spacing))
        i0=int((t0/minimum).ln()/spacing)
        i1=int((t1/minimum).ln()/spacing)
        ticks=[t0,*[minimum*(i*spacing).exp() for i in range(i0+1,i1+1)],t1]
        values=[]
        absolute=Decimal(0)
        for order,rule in rules.items():
            integrated=Decimal(0)
            for left,right in zip(ticks,ticks[1:]):
                for node,weight in rule:
                    t=left+(right-left)*(1+node)/2
                    scale,_=geometry(data.bg,t)
                    vel=interp(data.splines[1],scale.ln())[0]
                    term=(right-left)*weight*vel/2
                    integrated+=term
                    if order==16:
                        absolute+=abs(term)
            values.append(integrated)
        allowance=abs(values[2]-values[1])+abs(values[1]-values[0])+64*as_decimal(np.finfo(float).eps)*absolute
        low1,high1=wordrange(f1)
        observed=f1-f0
        frac=max(high1-f1+f0-low,high-f0+f1-low1)
        rows.append(dict(index=index,duration=float(t1-t0),velocity_integral=float(values[-1]),
                         observed_increment=float(observed),mismatch=float(observed-values[-1]),word_allowance=float(frac),
                         quadrature_allowance=float(allowance),over_word_allowance=float(abs(observed-values[-1])/frac)))
        totals+=values[-1]
        error+=allowance
    lower=max(lo for lo,hi,err in bounds)
    upper=min(hi for lo,hi,err in bounds)
    wide=min(hi+err for lo,hi,err in bounds)-max(lo-err for lo,hi,err in bounds)
    narrow=min(hi-err for lo,hi,err in bounds)-max(lo+err for lo,hi,err in bounds)
    require(narrow<=upper-lower<=wide,'ordered uncertainty strips')
    return dict(intervals=rows,intersection_width=float(upper-lower),expanded_width=float(wide),contracted_width=float(narrow),
                actual_anchor_word_width=float(bounds[0][1]-bounds[0][0]),comparison=('compatible' if narrow>0 else 'incompatible' if wide<0 else 'unresolved'))


if __name__=='__main__':
    bank.guard()
    proc=bank.psutil.Process()
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    proc.cpu_affinity([4])
    bank.save(ROOT/'compatibility-process.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),
                 method=bank.digest(ROOT/'KNOT-COMPATIBILITY.md'),code=bank.digest(ROOT/'compatibility.py')))
    with localcontext() as context:
        context.prec=60
        for case in ('cold','heavy'):
            report=checked(Dataset(case))
            bank.save(ROOT/(case+'-knot-compatibility.json'),report)
            print(case,report['comparison'],report['expanded_width'],report['contracted_width'],report['actual_anchor_word_width'],flush=True)
