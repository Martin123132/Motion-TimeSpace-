import math
from onset import ROOT,Path,Consistent,bank,np,require,jet_reader,sys,dec,Decimal,localcontext,densities,predict,evolve


def analytic_hprime(params,scale,fields,rate,derivatives):
    hubble=(sum(densities(params,[scale,*fields]))/3).sqrt()
    rhop=-rate*((params[0]+params[1])/scale+2*(params[2]+params[3])/scale**2)
    coef=Decimal(5)/(7*dec(math.pi)**2)
    for idx in range(int(params[4])):
        am=scale*params[8+idx]
        f=1+coef*am**2
        fn=2*coef*am**2
        if am>=Decimal('.01'):
            term=Decimal('.01099926669')*am.ln()-Decimal('.003492416767')-Decimal('.005866275571')*am
            f+=am**4*term
            fn+=am**4*(4*term+Decimal('.01099926669')-Decimal('.005866275571')*am)
        rhop+=params[14+idx]/scale**2*rate*(fn-2*f)
    for idx,(field,velocity,df,dv) in enumerate(zip(fields[::2],fields[1::2],derivatives[::2],derivatives[1::2])):
        mass2=(scale*params[6+idx])**2
        rhop+=velocity*dv+mass2*field*(rate*field+df)
    return rhop/(6*hubble)


def coefficient(prob):
    forecast=predict(prob)
    start=forecast['start']
    raw=prob.direct.background
    t=dec(start)
    spacing=dec(raw.spacing)
    position=(t/dec(raw.minimum)).ln()/spacing
    idx=int(position)
    x=position-idx
    v,g=map(dec,raw.clock[idx])
    w,h=map(dec,raw.clock[idx+1])
    b=3*(w-v)-2*g-h
    c=g+h+2*(v-w)
    poly=v+x*(g+x*(b+x*c))
    first=g+x*(2*b+3*c*x)
    second=2*b+6*c*x
    scale=t*poly
    rate=(poly+first/spacing)/scale
    rprime=(first/spacing+second/spacing**2)/(t*scale)-rate**2
    oldhi,oldlo=prob.old(start)
    old=[dec(one)+dec(two) for one,two in zip(oldhi,oldlo)]
    new=[dec(one)+dec(two) for one,two in zip(prob.Qhigh[0,:len(old)],prob.Qlow[0,:len(old)])]
    h0=(sum(densities(prob.constants,old))/3).sqrt()
    h1=(sum(densities(prob.constants,new))/3).sqrt()
    efold=scale.ln()
    physical=[]
    polynomial=[]
    for i,pair in enumerate(raw.fields):
        mass2=(new[0]*prob.constants[6+i])**2
        field,vel=new[1+2*i:3+2*i]
        physical.extend((vel,-2*h1*vel-mass2*field))
        for spline in pair:
            pos=int(np.searchsorted(spline.x,float(efold),side='right')-1)
            pos=min(len(spline.x)-2,max(0,pos))
            require(dec(spline.x[pos])<=efold<=dec(spline.x[pos+1]),'field knot')
            arg=efold-dec(spline.x[pos])
            cubic,quad,linear=map(dec,spline.c[:3,pos])
            polynomial.append(rate*(linear+arg*(2*quad+3*cubic*arg)))
    hp1=analytic_hprime(prob.constants,new[0],new[1:],h1,physical)
    hp0=analytic_hprime(prob.constants,old[0],old[1:],rate,polynomial)
    vec,_=prob.unpack(prob.initial)
    dtlog=(1-x)*spacing
    def thermal_slope(n):
        step=dtlog/n
        times=[float(t*(i*step).exp()) for i in range(4)]
        points=[prob.real(time,vec,prob.empty,False)[2][1:3] for time in times]
        return [sum(dec(value)*weight for value,weight in zip(col,(-11,18,-9,2)))/(6*step*t) for col in zip(*points)]
    slope1=thermal_slope(4)
    slope2=thermal_slope(8)
    bg=prob.at(start,True)
    result,control=prob.flow(bg,prob.initial,1.,True)
    change=result[prob.active:2*prob.active]
    orig,_,thermal=prob.native(start,vec,prob.empty,False)
    wave=dec(prob.wave)
    sound,chi=map(dec,thermal[1:3])
    sounddot,chidot=slope2
    weight=Decimal(4)*prob.constants[2]/(3*prob.constants[1]*scale)
    vb,db=map(dec,(vec[3],vec[2]))
    slip=vb-Decimal('.75')*dec(vec[prob.photon])
    slip0prime=dec(orig[3])-Decimal('.75')*dec(orig[prob.photon])
    ratio=new[0]/scale
    inv=1/ratio
    eps=h1-rate
    invp=-eps*inv
    collision=weight*inv**3+inv**2
    coeff=weight*(inv**3-1)+(inv**2-1)
    coeffp=-rate*weight*(inv**3-1)+(3*weight*inv**2+2*inv)*invp
    dslip=dec(forecast['kinetic_slip_rate_over_slip'])*slip
    dcdot=dec(change[1])
    dbdot=dcdot+dec(change[2])
    dgdot=4*dcdot/3+dec(change[prob.photon-1])
    ddslip=(-h1*dec(change[3])-(hp1-hp0)*vb-(h1-h0)*dec(orig[3])
           +wave*(sound*(inv*dbdot+(inv-1)*dec(orig[2])+invp*db)+sounddot*(inv-1)*db)
           -wave*dgdot/4+wave*dec(change[prob.photon+1])/2
           -chi*collision*dslip-(chidot*coeff+chi*coeffp)*slip-chi*coeff*slip0prime)
    if prob.kind=='smooth':
        independent=-(hp1-hp0)*vb-wave*sound*eps*db+chi*slip*(3*weight+2)*eps
        require(abs(ddslip-independent)<Decimal('1e-27')*max(abs(independent),Decimal('1e-30')),'zero-mismatch slip curvature')
    lp=dslip/slip-eps
    lpp=ddslip/slip-2*dslip*slip0prime/slip**2-(dslip/slip)**2-(hp1-rprime)
    u2=inv**2*(4*lp**2+2*lpp)
    weightp=chidot/chi+2*slip0prime/slip
    curvature=u2/6+weightp*dec(forecast['slope'])/12
    forecast.update(curvature=float(curvature),relative_rate_second=float(u2),log_weight_derivative=float(weightp),
                    clock_acceleration_difference=float(hp1-rprime),metric_hprime_difference=float(hp1-hp0),
                    thermal_derivative_refinement=[float(abs(a-b)/max(abs(b),Decimal('1e-60'))) for a,b in zip(slope1,slope2)])
    forecast['times']=[start+(prob.clock['bounds'][1]-start)/div for div in (20,80,320,1280,5120)]
    return forecast


def test(forecast,rows):
    for row in rows:
        elapsed=row['elapsed']
        lead=forecast['slope']*elapsed/2
        quad=forecast['curvature']*elapsed**2
        error=abs((row['fine']-forecast['intercept'])-lead-quad)/abs(lead)
        row['curvature_fractional_discrepancy']=error
        row['curved_pass']=bool(error+row['resolution']<=bank.TOL)
    return rows


def main(case):
    bank.guard()
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-curvature'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),
               code=bank.digest(ROOT/'curvature.py'),protocol=bank.digest(ROOT/'CURVATURE.md')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(ROOT/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in data}
    with context as (capture,meta,sample):
        with np.load(ROOT/(case+'-capture.npz')) as frozen:
            require(all(np.array_equal(capture[key],frozen[key]) for key in capture),'same fixed hierarchy')
        prepared,_,background,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,background,live.prefix(capture,case),meta,sample)
        jobs=[]
        for kind in ('binary','smooth'):
            prob=Consistent(case,direct,clock,capture,jet_reader(direct.model.count))
            prob.configure(kind)
            with localcontext() as context:
                context.prec=60
                forecast=coefficient(prob)
            path=ROOT/(tag+'-'+kind+'-frozen.json')
            bank.save(path,forecast)
            jobs.append((prob,forecast,path,bank.digest(path)))
        for prob,forecast,path,seal in jobs:
            rows=test(forecast,evolve(prob,forecast))
            exposed=test(forecast,bank.read(ROOT/(case+'-onset-'+prob.kind+'-test.json'))['rows'])
            require(bank.digest(path)==seal,'frozen coefficients')
            bank.save(ROOT/(tag+'-'+prob.kind+'-test.json'),dict(forecast_sha256=seal,unseen=rows,exposed=exposed))
            print(case,prob.kind,forecast['curvature'],[float(row['curvature_fractional_discrepancy']) for row in rows],flush=True)


if __name__=='__main__':
    main(sys.argv[1])
