from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from preparation_split import Consistent,ROOT,Path,bank,np,require,jet_reader,sys


def freeze():
    specs={}
    for case in ('cold','heavy'):
        path=ROOT/(case+'-curvature-v2-smooth-frozen.json')
        forecast=bank.read(path)
        with np.load(ROOT/(case+'-clock.npz')) as clock:
            first=clock['bounds'][1]-clock['bounds'][0]
        rate=-2*forecast['slope']/forecast['relative_rate_second']
        net=-forecast['slope']/(2*forecast['curvature'])
        specs[case]=dict(rate=rate,net=net,first=first,eligible=bool(0<rate<net and 1.4*net<first),
                         curvature_sha256=bank.digest(path))
    require(sum(trial['eligible'] for trial in specs.values())==1,'one common same-time experiment')
    bank.save(ROOT/'reversal-frozen.json',dict(specs=specs,window=max(1.4*row['net'] for row in specs.values() if row['eligible']),
              protocol=bank.digest(ROOT/'REVERSAL.md'),code=bank.digest(ROOT/'reversal.py')))


def measure(prob,extent,resolution):
    start=prob.grid[0]
    end=start+extent
    width=prob.active
    oldrate=prob.flow(prob.at(start,True),prob.initial,1.)[-3]
    units=np.r_[prob.direct.state_units,prob.direct.delta_units,oldrate*extent,oldrate*extent*1e-5]
    def rhs(time,coords):
        return prob.flow(prob.at(time,True),np.r_[coords*units,0.],1.)[:-1]/units
    cap=(end-start)/resolution
    sol=solve_ivp(rhs,(start,end),prob.initial[:-1]/units,method='DOP853',rtol=1e-10,atol=1e-12,first_step=cap,max_step=cap,dense_output=True)
    require(sol.success,'same physical evolution')
    def read(fraction):
        time=min(end,start+fraction*(end-start))
        state=sol.sol(time)*units
        return prob.source(time,state,True),state[-1]
    report={}
    for probes in (64,128):
        grid=np.arange(1,probes+1)/probes
        values=np.array([read(fraction) for fraction in grid])
        crossings=[]
        for idx in range(2):
            roots=[]
            for left in np.flatnonzero(np.sign(values[1:,idx])!=np.sign(values[:-1,idx])):
                pos=brentq(lambda fraction:read(fraction)[idx],grid[left],grid[left+1],xtol=1e-12)
                roots.append(float(pos*(end-start)))
            crossings.append(roots)
        report[str(probes)]=dict(rate=crossings[0],net=crossings[1],start_sign=np.sign(values[0]).tolist(),end_sign=np.sign(values[-1]).tolist())
    return report


def main(case):
    bank.guard()
    path=ROOT/'reversal-frozen.json'
    spec=bank.read(path)
    require(bank.digest(ROOT/'reversal.py')==spec['code'],'unchanged forecasting code')
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-reversal'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),forecast=bank.digest(path)))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(ROOT/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in data}
    with context as (capture,meta,sample):
        with np.load(ROOT/(case+'-capture.npz')) as frozen:
            require(all(np.array_equal(capture[key],frozen[key]) for key in capture),'same complete hierarchy')
        prepared,_,bg,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,bg,live.prefix(capture,case),meta,sample)
        prob=Consistent(case,direct,clock,capture,jet_reader(direct.model.count))
        prob.configure('smooth')
        rows={str(steps):measure(prob,spec['window'],steps) for steps in (32,64)}
        bank.save(ROOT/(tag+'-result.json'),rows)
        print(case,rows['64']['128'],flush=True)


if __name__=='__main__':
    if sys.argv[1]=='freeze':
        freeze()
    else:
        main(sys.argv[1])
