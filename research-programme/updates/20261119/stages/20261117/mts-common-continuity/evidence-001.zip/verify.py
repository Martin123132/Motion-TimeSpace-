import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/'mts-matched-clock-precision-20261117'
sys.path.insert(0,str(ROOT.parent/'mts-elastic-source-interval-quadrature-20261117'))
import interval_probe as bank
from interval_probe import np,require


def report(case):
    result={}
    inputs=bank.read(ROOT/(case+'-inputs.json'))
    for path,expected in inputs.items():
        require(bank.digest(Path(path))==expected,'same original files')
    with np.load(ROOT/(case+'-capture.npz')) as capture, np.load(PREV/('matter/'+case+'-64-capture.npz')) as previous:
        require(all(np.array_equal(array,previous[key]) for key,array in capture.items()),'entire native hierarchy preserved')
        clock=capture['clock']
        reference=capture['reference']
        pindex=int(capture['signature'][0,3])
        active=int(capture['signature'][0,1])
    with np.load(ROOT/(case+'-clock.npz')) as clockpack:
        bounds=clockpack['bounds']
        exact_times=clockpack['clocks']
        require(np.array_equal(clockpack['grid64'][:-1],exact_times[clockpack['index64'][:,0]]),'all 64-step starts')
        require(np.max(clockpack['analytic_control'])<6e-33,'analytic clock control')
    require(bounds[0]==clock[0],'true original start')
    mask=clock<=bounds[-1]
    experiments={}
    for route in ('native','smooth'):
        curves=[]
        for steps in (32,64,128):
            with np.load(ROOT/f'{case}-{route}-{steps}-amp1.npz') as data:
                ticks=data['time']
                states=data['states']
                require(np.isfinite(states).all() and not np.any(states[0,active:]),'finite and genuinely initially matched')
                idx=np.searchsorted(ticks,clock[mask])
                require(np.array_equal(ticks[idx],clock[mask]),'unshifted native clocks')
                parity=np.max(abs(states[idx,:active]-reference[mask,:active])/data['scales'][:active])
                require(parity<bank.TOL,'independent original native perturbation replay')
                curves.append((states[-1,-2],float(max(data['embedded'])),parity))
        with np.load(ROOT/f'{case}-{route}-128-amp0.5.npz') as half:
            sensitivity=abs(half['states'][-1,-2]/curves[-1][0]-1)
        experiments[route]=dict(fixed_step_energy=[row[0] for row in curves],embedded_max=[row[1] for row in curves],
             carrier_max_normalized_error=max(row[2] for row in curves),fixed_finest_amplification_sensitivity=sensitivity)
    result['fixed_step']=experiments
    entries={}
    for route in ('native','smooth','paired-binary-smooth','paired-smooth-smooth'):
        summaries=[]
        for steps in (32,64):
            name=f'{case}-{route}-{steps}-adaptive'
            item=bank.read(ROOT/(name+'.json'))
            with np.load(ROOT/(name+'.npz')) as data:
                require(np.isfinite(data['states']).all() and np.all(np.diff(data['accepted_ends'])>0),'finite accepted sequence')
                require(data['last_time']==item['last'] and data['last_state'][-1]==item['signed'],'terminal receipt agrees')
                require(np.all(data['states'][0,active:]==0),'zero initial response from preparation')
                if item['status']!='complete':
                    require(item['status']=='bounded adaptive trial' and item['last']<bounds[-1] and not item['readout'],'no invented native endpoint')
                    summaries.append(dict(fraction=item['reached_fraction']))
                    continue
                require(np.array_equal(data['bounds'],bounds),'all original event boundaries')
                q=item['readout']
                require(q['crossings4']==q['crossings8'] and q['variation8']>=abs(item['signed'])*(1-1e-12),'absolute energy and root stability')
                error=sum(abs(q[k]-q['variation8']) for k in ('variation4','absolute_gauss3','absolute_gauss7'))+abs(q['signed_gauss7']-item['signed'])
                summaries.append(dict(signed=item['signed'],abs_flux=q['variation8'],den=data['states'][-1,-2],quadrature_budget=error))
        if route=='native':
            entries[route]=summaries
        else:
            coarse,fine=summaries
            work=(abs(coarse['signed']-fine['signed'])+abs(coarse['abs_flux']-fine['abs_flux'])+
                  coarse['quadrature_budget']+fine['quadrature_budget'])/abs(fine['signed'])
            require(work<bank.TOL,'complete smooth radiation checks')
            entries[route]=dict(fine=fine,budget=work,relative_to_original=fine['signed']/fine['den'])
    result['adaptive']=entries
    orig=entries['paired-binary-smooth']['fine']['signed']
    rematched=entries['paired-smooth-smooth']['fine']['signed']
    result['initial_sensitivity_over_binary']=abs(rematched/orig-1)
    result['common_operator_control']=abs(entries['smooth']['fine']['signed']/orig-1)
    trial=bank.read(ROOT/(case+'-fixtures.json'))
    require(len(trial)==6 and len({(row['time'],row['sign']) for row in trial})==6,'native finite comparisons at genuine states')
    result['native_fixture_max']=max(max(max(row['row_relative']),row['source_relative']) for row in trial)
    require(result['native_fixture_max']<bank.TOL,'direct native fixtures')
    checks={}
    for kind in ('binary','smooth'):
        label=case+'-curvature-v2-'+kind
        curve=bank.read(ROOT/(label+'-frozen.json'))
        check=bank.read(ROOT/(label+'-test.json'))
        require(check['forecast_sha256']==bank.digest(ROOT/(label+'-frozen.json')),'intact curvature forecast')
        initial=case+'-onset-'+kind
        exposed=bank.read(ROOT/(initial+'-test.json'))
        leading=bank.read(ROOT/(initial+'-frozen.json'))
        require(exposed['forecast_sha256']==bank.digest(ROOT/(initial+'-frozen.json')) and not set(curve['times'])&set(leading['times']),'independently sampled new times')
        require(curve['slope']==leading['slope'] and curve['intercept']==leading['intercept'],'leading coefficients unchanged')
        for number,(target,row) in enumerate(zip(curve['times'],check['unseen'])):
            width=target-curve['start']
            amount=curve['slope']*width/2
            discrepancy=(abs((row['fine']-curve['intercept'])-amount-curve['curvature']*width**2)+abs(row['coarse']-row['fine']))/abs(amount)
            require(bool(discrepancy<=bank.TOL)==row['curved_pass'],'budget on original slope scale')
        require(len(check['unseen'])==len(check['exposed'])==5,'five new and five exposed')
        checks[kind]=dict(leading_pass=sum(q['passes'] for q in exposed['rows']),curved_new_pass=sum(q['curved_pass'] for q in check['unseen']),
                         new_budgets=[q['curvature_fractional_discrepancy']+q['resolution'] for q in check['unseen']])
    result['onset']=checks
    forecasts=bank.read(ROOT/'reversal-frozen.json')
    require(forecasts['code']==bank.digest(ROOT/'reversal.py') and forecasts['protocol']==bank.digest(ROOT/'REVERSAL.md'),'event protocol and method')
    require(forecasts['specs'][case]['curvature_sha256']==bank.digest(ROOT/(case+'-curvature-v2-smooth-frozen.json')),'unchanged event coefficients')
    events=bank.read(ROOT/(case+'-reversal-result.json'))
    timing={}
    for key in ('rate','net'):
        predictions=forecasts['specs'][case]
        observed=[events[steps][count][key] for steps in ('32','64') for count in ('64','128')]
        if predictions['eligible']:
            require(all(len(row)==1 for row in observed),'unambiguous positive sign transition')
            fine=observed[-1][0]
            error=abs(predictions[key]/fine-1)
            resolution=max(abs(row[0]/fine-1) for row in observed)
            timing[key]=dict(predicted=predictions[key],observed=fine,relative_error=error,resolution=resolution,passes=error+resolution<=bank.TOL)
        else:
            require(not any(observed),'control has no resolved crossing on matched time span')
            timing[key]=dict(predicted_in_domain=False,resolved_crossings=0)
    result['timing']=timing
    split=bank.read(ROOT/'mechanism.json')[case]
    f=bank.read(ROOT/(case+'-curvature-v2-smooth-frozen.json'))
    require(abs(sum(split['derivative_by_species'].values())/f['metric_hprime_difference']-1)<bank.ALG,'independent species sum')
    result['heavy_field_derivative_curvature_share']=split['energy_curvature_by_metric_term'].get('heavy_field_jet',0.)/f['curvature']
    result['signed_velocity_slip_ratio']=split['velocity_over_slip']
    return result


def main():
    bank.guard()
    bank.check_seals()
    old=bank.read(PREV/'closeout.json')['files']
    require(bank.digest(PREV/'closeout.json')=='7d787ffe267c9c7594d22266f3e1fb62df6b8db50628043ef6a0d8adbd306993','immutable previous seal')
    for name,obj in old.items():
        require(bank.digest(PREV/name)==obj['sha256'],'unchanged earlier diagnostic')
    previous=bank.read(bank.SOURCE/'inputs.json')
    for name,digest in previous.items():
        require(bank.digest(Path(name))==digest,'original history input preserved')
    summaries={case:report(case) for case in ('cold','heavy')}
    require(bank.digest(ROOT/'curvature-attempt1.py')==bank.read(ROOT/'cold-curvature-owner.json')['code'],'initial failed checker retained')
    for owner in ROOT.glob('*-owner.json'):
        packet=bank.read(owner)
        release=owner.with_name(owner.name.replace('-owner.json','-owner-release.json'))
        if owner.name!='clock-owner.json':
            require(bank.read(release)==dict(cleared=True,native_reference_released=True),'native release')
    bank.save(ROOT/'verification.json',dict(summaries=summaries,original_tolerance=bank.TOL,previous_artifacts=len(old),
                    physical_hashes=len(previous),native_releases=len(list(ROOT.glob('*-owner-release.json')))))
    print({name:row['timing'] for name,row in summaries.items()})


def close():
    require(all((ROOT/name).is_file() for name in ('verification.json','field-verification.json','RESULTS.md')),'verified and documented')
    workers=[]
    for path in sorted([*ROOT.glob('*-owner.json'),*ROOT.glob('*-process.json')]):
        item=bank.read(path)
        try:
            candidate=bank.psutil.Process(item['pid'])
            require(abs(candidate.create_time()-item['created'])>.01,'recorded stage owner still present: '+path.name)
        except bank.psutil.NoSuchProcess:
            pass
        workers.append(dict(receipt=path.name,pid=item['pid'],created=item['created'],command=item['command'],exited=True))
    require(not list(ROOT.rglob('__pycache__')),'no temporary interpreter cache')
    closer=bank.psutil.Process()
    bank.save(ROOT/'cleanup.json',dict(workers=workers,closer=dict(pid=closer.pid,created=closer.create_time(),command=closer.cmdline()),
                  scoped_shell_session_61287='errant read-only ancestor listing interrupted through its own session; exited 1; no file changes',other_processes_altered=0))
    inventory={path.relative_to(ROOT).as_posix():dict(bytes=path.stat().st_size,sha256=bank.digest(path)) for path in sorted(ROOT.rglob('*')) if path.is_file()}
    bank.save(ROOT/'closeout.json',dict(finished=bank.datetime.now(bank.timezone.utc).isoformat(),files=inventory,physical_restart=4252,
                  scope='Conditional early common-continuity, radiation onset and derivative sensitivity; native binary comparison remains open.'))
    print('Stage sealed',len(inventory),'artifacts')


if __name__=='__main__':
    if sys.argv[1]=='verify':
        main()
    elif sys.argv[1]=='close':
        close()
