import csv
import math
import sys
from decimal import Decimal,localcontext
from pathlib import Path
ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PREV=POST/'mts-matched-clock-precision-20261117'
sys.path.insert(0,str(POST/'mts-friedmann-expansion-response-20261117'))
from response import bank,np,require,jet_reader,densities
from scipy.integrate._ivp.rk import DOP853


def dec(value):
    return Decimal.from_float(float(value))


def add(*items):
    return math.fsum(items)


def finite_expansion(constants,base,direction):
    with localcontext() as context:
        context.prec=55
        before=list(map(dec,base))
        after=[one+dec(delta) for one,delta in zip(before,direction)]
        old=(sum(densities(constants,before))/3).sqrt()
        new=(sum(densities(constants,after))/3).sqrt()
        return float(new-old)


class Problem:
    def __init__(self,case,direct,clock,capture,jet):
        self.case,self.direct,self.clock,self.capture,self.jet=case,direct,clock,capture,jet
        self.active=direct.active
        self.photon=int(capture['signature'][0,3])
        self.indices=np.array([1,2,self.photon-1,3,self.photon])
        self.wave=float(direct.prepared['wave'][0])
        self.native=direct.sample
        self.oldblank=capture['reference'][0].copy()
        self.changedblank=np.zeros_like(self.oldblank)
        self.empty=np.zeros(5)
        self.count=direct.model.count
        self.constants=list(map(dec,clock['constants']))
        self.cache={}
        self.record={}

    def background(self,idx,smooth):
        key=(idx,smooth)
        if key in self.cache:
            return self.cache[key]
        time=self.clock['clocks'][idx]
        _,_,extra=self.native(time,self.oldblank,self.empty,False)
        jets=self.jet(time,self.oldblank)
        native=np.r_[extra[0],jets[:,:2].ravel()]
        hi,lo=self.clock['high'][idx,:len(native)],self.clock['low'][idx,:len(native)]
        if smooth:
            base=self.clock['smooth'][idx]
            lower=self.clock['remainder'][idx]
        else:
            base=native
            lower=np.zeros_like(base)
        diff=(hi-base)+(lo-lower)
        dh=finite_expansion(self.constants,base,diff)
        item=(time,native,diff,dh)
        self.cache[key]=item
        return item

    def packet(self,base,delta,amp):
        result=np.zeros(5)
        result[:len(base)]=base+amp*delta
        return result

    def amplification(self,base,delta):
        scales=[base[0]]
        for idx in range(self.count):
            mass=base[0]*float(self.constants[6+idx])
            norm=math.hypot(base[1+2*idx],base[2+2*idx]/mass)
            scales.extend([norm,norm*mass])
        excursion=max((abs(value)/max(scale,1e-300) for value,scale in zip(delta,scales)),default=0.)
        return 2.**min(50,math.floor(math.log2(1e-4/max(excursion,1e-200))))

    def unpack(self,state):
        width=self.active
        old,change=self.oldblank.copy(),self.changedblank.copy()
        old[:width]=state[:width]
        change[:width]=state[width:2*width]
        change[2]+=change[1]
        change[self.photon-1]+=4/3*change[1]
        return old,change

    def flow(self,bg,state,amplitude_factor,inspect=False):
        time,base,delta,dh=bg
        old,change=self.unpack(state)
        wave=self.wave
        photon=self.photon
        corrected=self.packet(base,delta,1.)
        alpha=delta[0]/base[0]
        eta=math.log1p(alpha)
        inv=1/(1+alpha)
        orig,obs,extra=self.native(time,old,self.empty,False)
        prop,observed,_=self.native(time,change,corrected,True)
        pm=self.direct.read_metric(time,old,self.empty,False)[:84].reshape(7,12)
        at_end=self.direct.read_metric(time,old,corrected,True)[48:60]
        half=self.direct.read_metric(time,old,self.packet(base,delta,math.expm1(eta/2)/alpha if alpha else .5),True)[48:60]
        nu=lambda terms: -(terms[3]+3*terms[5])
        nu_delta=eta*(nu(pm[4])+4*nu(half)+nu(at_end))/6
        dust=-alpha*inv
        rad=-alpha*(2+alpha)*inv**2
        scalar=[]
        for idx in range(self.count):
            first=self.direct.first+2*idx
            scale=base[0]*float(self.constants[6+idx])
            field,shift=base[1+2*idx],delta[1+2*idx]
            potential=scale**2*(shift+alpha*(2+alpha)*(field+shift))
            scalar.append(add(delta[2+2*idx]*old[first+1],potential*old[first]))
        dsource=add(observed[2],dust*pm[0,3],dust*pm[1,3],rad*pm[2,3],rad*pm[3,3],nu_delta,*scalar)
        z0=extra[9]
        dz=add(dsource/(2*wave),change[0],-z0*dh)/(obs[28]+dh)
        amp=amplitude_factor*self.amplification(base,delta)
        plus,op,_=self.native(time,old,self.packet(base,delta,.5+amp),True)
        minus,om,_=self.native(time,old,self.packet(base,delta,.5-amp),True)
        derivative=prop+(plus-minus)/(2*amp)
        secant=(plus-minus)/(2*amp)+prop
        dv=change[3]
        old_slip=old[3]-.75*old[photon]
        new_slip=dv-.75*change[photon]
        drag=extra[2]
        weight=4/3*pm[2,0]/pm[1,0]
        pressure=wave*extra[1]*inv*(change[2]-alpha*old[2])
        dcube=-alpha*inv*(1+inv+inv**2)
        collb=-weight*drag*(inv**3*new_slip+dcube*old_slip)
        collp=drag*(inv**2*new_slip+rad*old_slip)
        vb=add(-(obs[28]+dh)*dv,-dh*old[3],pressure,collb)
        qp=4/3*add(wave*change[photon-1]/4,-wave*change[photon+1]/2,collp)
        physical=np.array([-wave*dz,-wave*(dz+dv),-wave*(4/3*dz+change[photon]),vb,qp])
        derivative[self.indices]=[-wave*dz,-wave*dv,-wave*change[photon],vb,qp]
        energy0=4/3*drag*old_slip**2
        energy=4/3*drag*inv**2*(new_slip*(2*old_slip+new_slip)-alpha*(2+alpha)*old_slip**2)
        output=np.r_[orig[:self.active],derivative[:self.active],energy0,energy,abs(energy)]
        if not inspect:
            return output
        actual,ao,_=self.native(time,old+change,corrected,True)
        raw=actual[self.indices]-orig[self.indices]
        return output,dict(pred=physical,raw=raw,secant=secant[self.indices],dsource=dsource,
                raw_source=ao[2]-obs[2],secant_source=(op[2]-om[2])/(2*amp)+observed[2],original=orig[self.indices],
                coll_error=abs(add(collb,weight*inv*collp,-weight*alpha*inv*drag*old_slip)),
                coll_scale=abs(collb)+abs(weight*inv*collp)+abs(weight*alpha*inv*drag*old_slip),
                quadrature=abs(nu_delta-eta*(nu(pm[4])+nu(at_end))/2),amp=amp,baseline_density=obs[2])

    def fixture(self):
        rows=[]
        idxs=[0,len(self.clock['clocks'])//2,-1]
        for index in idxs:
            time,base,_,_=self.background(index,False)
            for sign in (-1.,1.):
                oldloc=int(np.argmin(abs(self.capture['clock']-time)))
                state=self.initial.copy()
                state[:self.active]=self.capture['reference'][oldloc,:self.active]
                state[self.active:2*self.active]=sign*2.7e-5*state[:self.active]
                state[self.active+2]-=state[self.active+1]
                state[self.active+self.photon-1]-=4/3*state[self.active+1]
                delta=sign*1.3e-5*base
                delta[1::2]*=-.6
                delta[2::2]*=.31
                _,trial=self.flow((time,base,delta,finite_expansion(self.constants,base,delta)),state,.5,True)
                mag=np.maximum(abs(trial['pred']),np.abs(trial['original'])*1e-5)
                error=abs(trial['pred']-trial['raw'])/np.maximum(mag,1e-300)
                require(np.max(error)<=bank.TOL,'independent native direct finite fixture '+str(error))
                source_error=abs(trial['dsource']-trial['raw_source'])/max(abs(trial['dsource']),abs(trial['baseline_density'])*1e-5)
                require(source_error<=bank.TOL and trial['coll_error']<=bank.ALG*trial['coll_scale'],'finite source and paired momentum')
                rows.append(dict(time=time,sign=sign,row_relative=error.tolist(),source_relative=source_error))
        return rows

    @property
    def initial(self):
        width=self.active
        return np.r_[self.direct.initial[:width]*self.direct.state_units,np.zeros(width+3)]

    def solve(self,steps,convention,amp_factor):
        grid=self.clock['grid'+str(steps)]
        indices=self.clock['index'+str(steps)]
        state=self.initial
        states=[state.copy()]
        errors=[]
        oldrate=self.flow(self.background(0,False),state,1.)[-3]
        energy_scale=abs(oldrate)*self.clock['width']
        scales=np.r_[self.direct.state_units,self.direct.delta_units,energy_scale,energy_scale*1e-5,energy_scale*1e-5]
        require(np.min(scales)>0,'retained normalized units')
        for begin,end,nodes in zip(grid,grid[1:],indices):
            bank.guard()
            step=end-begin
            rates=np.empty((13,len(state)))
            for stage in range(12):
                trial=state if stage==0 else state+step*(DOP853.A[stage,:stage]@rates[:stage])
                rates[stage]=self.flow(self.background(int(nodes[stage]),convention=='smooth'),trial,amp_factor)
            updated=state+step*(DOP853.B@rates[:12])
            rates[12]=self.flow(self.background(int(nodes[-1]),convention=='smooth'),updated,amp_factor)
            units=1e-12*scales+1e-10*np.maximum(abs(state),abs(updated))
            fifth=(DOP853.E5@rates)/units
            third=(DOP853.E3@rates)/units
            denom=np.linalg.norm(fifth)**2+.01*np.linalg.norm(third)**2
            errors.append(0. if denom==0 else step*np.linalg.norm(fifth)**2/math.sqrt(len(state)*denom))
            require(np.isfinite(updated).all(),'finite whole coupled hierarchy')
            state=updated
            states.append(state.copy())
        matrix=np.asarray(states)
        tag=f'{self.case}-{convention}-{steps}-amp{amp_factor:g}'
        with (ROOT/(tag+'.npz')).open('xb') as stream:
            np.savez_compressed(stream,time=grid,states=matrix,embedded=errors,scales=scales,indices=self.indices)
        print(tag,'energy',state[-2],'abs integral',state[-1],'embedded',max(errors),flush=True)


def main(case):
    bank.guard()
    bank.check_seals()
    bank.ROOT=ROOT
    bank.save(ROOT/(case+'-inputs.json'),{str(path):bank.digest(path) for path in [PREV/'closeout.json', ROOT/'METHOD.md',ROOT/'coupled.py',ROOT/'prepare_clock.py',ROOT/(case+'-clock.npz')]})
    live,context=bank.native_setup(case,64,case)
    with np.load(ROOT/(case+'-clock.npz')) as stored:
        clock={name:stored[name] for name in stored}
    with context as (capture,meta,sample):
        frozen=live.load(Path(live.CONFIG['capture_authority'])/(case+'-preflight-capture.npz'))
        require(all(np.array_equal(array,frozen[name]) for name,array in capture.items()),'original full native capture')
        prepared,_,background,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,background,live.prefix(capture,case),meta,sample)
        require(float(clock['clocks'][0])==float(capture['clock'][0]),'original perturbation start')
        problem=Problem(case,direct,clock,capture,jet_reader(direct.model.count))
        bank.save(ROOT/(case+'-fixtures.json'),problem.fixture())
        for convention in ('native','smooth'):
            for steps in (32,64,128):
                problem.solve(steps,convention,1.)
            problem.solve(128,convention,.5)


if __name__=='__main__':
    case=sys.argv[1]
    require(case in ('cold','heavy'),'retained branch')
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    bank.save(ROOT/(case+'-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    main(case)
