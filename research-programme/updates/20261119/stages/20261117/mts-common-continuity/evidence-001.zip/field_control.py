from mechanism import ROOT,PREV,owner,bank,np,require,as_decimal,localcontext,densities,Decimal


def geometry(bg,t):
    spacing=as_decimal(bg.spacing)
    location=(t/as_decimal(bg.minimum)).ln()/spacing
    idx=int(location)
    require(0<=idx<len(bg.clock)-1,'native clock domain')
    x=location-idx
    a,b=map(as_decimal,bg.clock[idx])
    c,d=map(as_decimal,bg.clock[idx+1])
    q=3*(c-a)-2*b-d
    k=b+d+2*(a-c)
    value=a+x*(b+x*(q+x*k))
    scale=t*value
    rate=(value+(b+x*(2*q+3*k*x))/spacing)/scale
    return scale,rate


def invert(bg,n,start):
    t=start
    for _ in range(20):
        scale,rate=geometry(bg,t)
        delta=(scale.ln()-n)/rate
        t-=delta
        if abs(delta)<Decimal('1e-40'):
            return t
    raise ValueError('clock inversion did not converge')


def interp(spline,n):
    idx=min(len(spline.x)-2,max(0,int(np.searchsorted(spline.x,float(n),side='right')-1)))
    if n<as_decimal(spline.x[idx]) and idx:
        idx-=1
    if n>as_decimal(spline.x[idx+1]) and idx<len(spline.x)-2:
        idx+=1
    require(as_decimal(spline.x[idx])<=n<=as_decimal(spline.x[idx+1]),'scalar domain')
    x=n-as_decimal(spline.x[idx])
    cubic,quad,linear,fixed=map(as_decimal,spline.c[:,idx])
    return ((cubic*x+quad)*x+linear)*x+fixed,(3*cubic*x+2*quad)*x+linear


class Dataset:
    def __init__(self,case):
        _,_,self.bg,_,_=owner.EX.problem(case)
        self.params=list(map(as_decimal,self.bg.constants))
        self.which=len(self.bg.fields)-1
        self.mass=self.params[6+self.which]
        self.ts=as_decimal(bank.read(PREV/(case+'-input.json'))['anchor'])
        self.scale,self.rate=geometry(self.bg,self.ts)
        self.splines=self.bg.fields[self.which]
        self.knots=self.splines[0].x
        self.idx=int(np.searchsorted(self.knots,float(self.scale.ln()))-1)
        self.saved={}

    def state(self,n):
        return [n.exp(),*(interp(spl,n)[0] for pair in self.bg.fields for spl in pair)]

    def knot(self,index):
        if index not in self.saved:
            n=as_decimal(self.knots[index])
            t=invert(self.bg,n,self.ts)
            s=self.state(n)
            f,v=(as_decimal(spline.c[3,index]) for spline in self.splines)
            require([+f,+v]==s[-2:],'knot uses only its own tabulated values at working precision')
            s[-2:]=[f,v]
            h=(sum(densities(self.params,s))/3).sqrt()
            acc=-2*h*v-(s[0]*self.mass)**2*f
            self.saved[index]=t,f,v,acc
        return self.saved[index]

    def polynomial(self,left,right,degree,t):
        t0,f0,v0,acc0=self.knot(left)
        t1,f1,v1,acc1=self.knot(right)
        span=t1-t0
        x=(t-t0)/span
        require(0<x<1,'interior evaluation')
        c0,c1=f0,v0*span
        if degree==3:
            co=[c0,c1,3*(f1-f0)-span*(2*v0+v1),2*(f0-f1)+span*(v0+v1)]
        else:
            c2=acc0*span**2/2
            d0=f1-c0-c1-c2
            d1=v1*span-c1-2*c2
            d2=acc1*span**2-2*c2
            co=[c0,c1,c2,10*d0-4*d1+d2/2,-15*d0+7*d1-d2,6*d0-3*d1+d2/2]
        field=sum(c*x**i for i,c in enumerate(co))
        vel=sum(i*c*x**(i-1) for i,c in enumerate(co[1:],1))/span
        acc=sum(i*(i-1)*c*x**(i-2) for i,c in enumerate(co[2:],2))/span**2
        return field,vel,acc

    def diagnostic(self,degree):
        held=[]
        for i in range(self.idx-4,self.idx+5):
            t,f,v,_=self.knot(i)
            field,velocity,_=self.polynomial(i-1,i+1,degree,t)
            mass=as_decimal(self.knots[i]).exp()*self.mass
            amp=(f**2+(v/mass)**2).sqrt()
            held.append(dict(knot=i,field_amp=float(abs(field-f)/amp),velocity_amp=float(abs(velocity-v)/(mass*amp)),velocity_own=float(abs((velocity-v)/v))))
        begin=self.knot(self.idx)[0]
        stop=self.knot(self.idx+1)[0]
        interior=[]
        for time in [self.ts,*[begin+(stop-begin)*Decimal(i)/8 for i in (1,2,4,6,7)]]:
            scale,rate=geometry(self.bg,time)
            n=scale.ln()
            old=self.state(n)
            fld,vel=old[-2:]
            hp=(sum(densities(self.params,old))/3).sqrt()
            mass2=(scale*self.mass)**2
            f,v,acc=self.polynomial(self.idx,self.idx+1,degree,time)
            new=old[:-2]+[f,v]
            h=(sum(densities(self.params,new))/3).sqrt()
            raw_acc=rate*interp(self.splines[1],n)[1]
            raw_fdot=rate*interp(self.splines[0],n)[1]
            force=2*h*v+mass2*f
            scale_force=2*abs(h*v)+abs(mass2*f)
            interior.append(dict(time=float(time),raw_position_rate_defect=float(raw_fdot-vel),raw_acceleration_defect=float(raw_acc+2*hp*vel+mass2*fld),
                  raw_acceleration_relative=float(abs(raw_acc+2*hp*vel+mass2*fld)/(abs(2*hp*vel)+abs(mass2*fld))),
                  joint_acceleration_defect=float(acc+force),joint_acceleration_relative=float(abs(acc+force)/scale_force),
                  fractional_H_change=float(h/hp-1),field_change=float(f-fld),velocity_change=float(v-vel)))
        return dict(held=held,interior=interior,held_pass=sum(max(row['field_amp'],row['velocity_amp'])<=bank.TOL for row in held),
                    interior_pass=sum(row['joint_acceleration_relative']<=bank.TOL for row in interior))


if __name__=='__main__':
    bank.guard()
    process=bank.psutil.Process()
    process.cpu_affinity([4])
    process.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    bank.save(ROOT/'field-control-v2-process.json',dict(pid=process.pid,created=process.create_time(),command=process.cmdline(),
                   method=bank.digest(ROOT/'FIELD-CONTROL.md'),code=bank.digest(ROOT/'field_control.py')))
    with localcontext() as ctx:
        ctx.prec=60
        for case in ('cold','heavy'):
            dataset=Dataset(case)
            report={str(degree):dataset.diagnostic(degree) for degree in (3,5)}
            bank.save(ROOT/(case+'-joint-field.json'),report)
            print(case,[(k,v['held_pass'],v['interior_pass'],v['interior'][0]) for k,v in report.items()],flush=True)
