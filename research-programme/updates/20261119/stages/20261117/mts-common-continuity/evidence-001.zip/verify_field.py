import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT.parent/'mts-elastic-source-interval-quadrature-20261117'))
import interval_probe as bank
from decimal import Decimal,localcontext
from interval_probe import require
import math


def main():
    bank.guard()
    for path in ROOT.glob('*.py'):
        compile(path.read_bytes(),str(path),'exec')
    results={}
    with localcontext() as context:
        context.prec=55
        from field_control import Dataset
        for degree in (3,5):
            co=[Decimal(x) for x in (3,-7,2,4,-1,2)[:degree+1]]
            def direct(moment,order):
                return sum(term*(moment**(i-order) if i>order else Decimal(1))*math.factorial(i)/math.factorial(i-order) for i,term in enumerate(co) if i>=order)
            class Fixture:
                def knot(self,index):
                    time=Decimal(index)
                    return (time,*(direct(time,order) for order in (0,1,2)))
            for index in (1,3,7):
                time=Decimal(index)/8
                measured=Dataset.polynomial(Fixture(),0,1,degree,time)
                require(all(abs(value-direct(time,order))<Decimal('1e-45') for order,value in enumerate(measured)),'polynomial reproduces value, velocity and acceleration')
    for case in ('cold','heavy'):
        result=bank.read(ROOT/(case+'-joint-field.json'))
        for value in result.values():
            held,inside=value['held'],value['interior']
            require(len(held)==len({row['knot'] for row in held})==9 and len({row['time'] for row in inside})==6,'retained field cells')
            require(sum(max(row['field_amp'],row['velocity_amp'])<=bank.TOL for row in held)==value['held_pass'],'same knot budget')
            require(sum(row['joint_acceleration_relative']<=bank.TOL for row in inside)==value['interior_pass'],'independent acceleration gate')
        test=bank.read(ROOT/(case+'-knot-compatibility.json'))
        require(len(test['intervals'])==9 and test['contracted_width']<=test['intersection_width']<=test['expanded_width']<0,'no common initial value within rounded positions')
        for row in test['intervals']:
            rounding=8*math.ulp(row['velocity_integral'])+8*math.ulp(row['observed_increment'])
            require(abs(row['mismatch']-(row['observed_increment']-row['velocity_integral']))<=rounding,'reported knot discrepancy')
        results[case]=dict(held_and_acceleration={k:[v['held_pass'],v['interior_pass']] for k,v in result.items()},
                            incompatibility_in_initial_position_words=-test['expanded_width']/test['actual_anchor_word_width'])
    require(bank.digest(ROOT/'field-control-attempt1.py')==bank.read(ROOT/'field-control-process.json')['code'],'first precision diagnostic preserved')
    for filename,script,method in [('compatibility-process.json','compatibility.py','KNOT-COMPATIBILITY.md'),('field-control-v2-process.json','field_control.py','FIELD-CONTROL.md')]:
        check=bank.read(ROOT/filename)
        require(check['code']==bank.digest(ROOT/script) and check['method']==bank.digest(ROOT/method),'input procedures unchanged')
    bank.save(ROOT/'field-verification.json',dict(results=results,native_bank_modified=False,manufactured_checks=18))
    print(results)


if __name__=='__main__':
    main()
