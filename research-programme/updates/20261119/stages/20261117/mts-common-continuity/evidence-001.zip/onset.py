from preparation_split import Consistent,ROOT,Path,bank,np,require,jet_reader,sys,dec,localcontext,densities
from scipy.integrate import solve_ivp
from decimal import Decimal


def predict(prob):
    start=prob.grid[0]
    old,lo=prob.old(start)
    full=[dec(hi)+dec(low) for hi,low in zip(prob.Qhigh[0,:len(old)],prob.Qlow[0,:len(old)])]
    width=prob.clock['bounds'][1]-start
    background=prob.direct.background
    clock=dec(start)
    spacing=dec(background.spacing)
    position=(clock/dec(background.minimum)).ln()/spacing
    idx=int(position)
    fraction=position-idx
    val,grad=map(dec,background.clock[idx])
    nxt,nxtgrad=map(dec,background.clock[idx+1])
    quadratic=3*(nxt-val)-2*grad-nxtgrad
    cubic=grad+nxtgrad+2*(val-nxt)
    signal=val+fraction*(grad+fraction*(quadratic+fraction*cubic))
    derivative=grad+fraction*(2*quadratic+3*fraction*cubic)
    rate=(signal+derivative/spacing)/(clock*signal)
    reference=[dec(x)+dec(y) for x,y in zip(old,lo)]
    require(abs((clock*signal)/reference[0]-1)<Decimal('1e-30'),'actual smooth scale')
    hnew=(sum(densities(prob.constants,full))/3).sqrt()
    h0=(sum(densities(prob.constants,reference))/3).sqrt()
    alpha=full[0]/reference[0]-1
    inverse=1/(1+alpha)
    vector=prob.initial[:prob.active]
    original=prob.unpack(prob.initial)[0]
    _,_,thermo=prob.native(start,original,prob.empty,False)
    wave=dec(prob.wave)
    sound,opacity=map(dec,thermo[1:3])
    inertia=Decimal(4)*prob.constants[2]/(3*prob.constants[1]*reference[0])
    slip=dec(vector[3])-Decimal('.75')*dec(vector[prob.photon])
    slipdot=(-(hnew-h0)*dec(vector[3])+wave*sound*(inverse-1)*dec(vector[2])
             -opacity*slip*(inertia*(inverse**3-1)+(inverse**2-1)))
    intercept=-alpha*(2+alpha)*inverse**2
    slope=2*inverse**2*(slipdot/slip-(hnew-rate))
    ticks=np.array([start+width/(2**power) for power in (3,5,7,9,11)])
    require(slip!=0 and slope!=0 and np.all(ticks>start),'nondegenerate onset')
    return dict(times=ticks.tolist(),start=start,alpha=float(alpha),intercept=float(intercept),slope=float(slope),
                kinetic_slip_rate_over_slip=float(slipdot/slip),expansion_minus_reference=float(hnew-rate),
                original_rate=float(Decimal(4)/3*opacity*slip**2),kind=prob.kind)


def evolve(prob,forecast):
    ticks=np.array(forecast['times'])
    anchor=forecast['start']
    stops=np.r_[anchor,ticks[::-1]]
    width=prob.active
    units=np.r_[prob.direct.state_units,prob.direct.delta_units,forecast['original_rate']*(stops[-1]-anchor),
                1e-5*forecast['original_rate']*(stops[-1]-anchor)]
    forecasts=[]
    for subdivisions in (2,4):
        vector=prob.initial[:-1]/units
        fractions=[]
        for left,right in zip(stops,stops[1:]):
            def rhs(time,state):
                return prob.flow(prob.at(time,True),np.r_[state*units,0.],1.)[:-1]/units
            sol=solve_ivp(rhs,(left,right),vector,method='DOP853',first_step=(right-left)/subdivisions,
                          max_step=(right-left)/subdivisions,rtol=1e-10,atol=1e-12)
            require(sol.success,'short physical evolution')
            vector=sol.y[:,-1]
            fractions.append(vector[-1]*units[-1]/(vector[-2]*units[-2]))
        forecasts.append(fractions[::-1])
    report=[]
    for time,coarse,fine in zip(ticks,*forecasts):
        change=(time-anchor)*forecast['slope']/2
        error=abs((fine-forecast['intercept'])-change)/abs(change)
        resolution=abs(fine-coarse)/abs(change)
        report.append(dict(elapsed=time-anchor,coarse=coarse,fine=fine,predicted=forecast['intercept']+change,
                           slope_fractional_discrepancy=error,resolution=resolution,passes=bool(error+resolution<=bank.TOL)))
    return report


def main(case):
    bank.guard()
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-onset'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),
              code=bank.digest(ROOT/'onset.py'),protocol=bank.digest(ROOT/'ONSET.md')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(ROOT/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in data}
    with context as (capture,meta,sample):
        with np.load(ROOT/(case+'-capture.npz')) as frozen:
            require(all(np.array_equal(capture[key],frozen[key]) for key in capture),'complete native capture')
        prepared,_,background,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,background,live.prefix(capture,case),meta,sample)
        jobs=[]
        for kind in ('binary','smooth'):
            prob=Consistent(case,direct,clock,capture,jet_reader(direct.model.count))
            prob.configure(kind)
            with localcontext() as context:
                context.prec=65
                forecast=predict(prob)
            path=ROOT/(tag+'-'+kind+'-frozen.json')
            bank.save(path,forecast)
            jobs.append((prob,forecast,path,bank.digest(path)))
        for prob,forecast,path,seal in jobs:
            rows=evolve(prob,forecast)
            require(bank.digest(path)==seal,'forecast unchanged')
            bank.save(ROOT/(tag+'-'+prob.kind+'-test.json'),dict(forecast_sha256=seal,rows=rows))
            print(case,prob.kind,forecast['slope'],[round(row['slope_fractional_discrepancy'],8) for row in rows],flush=True)


if __name__=='__main__':
    main(sys.argv[1])
