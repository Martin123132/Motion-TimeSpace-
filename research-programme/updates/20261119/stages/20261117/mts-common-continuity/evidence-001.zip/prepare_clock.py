import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
PREV = ROOT.parent/'mts-matched-clock-precision-20261117'
sys.path.insert(0,str(PREV))
from matched import bank, np, owner, require, control, integrate, library, clock_words
from scipy.integrate._ivp.rk import DOP853


def main(case):
    bank.guard()
    spec = bank.read(PREV/f'{case}-input.json')
    prepared, _, background, _, _ = owner.EX.problem(case)
    begin = spec['anchor']
    width = spec['base_step']
    end = begin + width
    observations = np.unique(prepared['times'][None,:] + prepared['elapsed'][:,None])
    bounds = np.unique(np.r_[begin, observations[(observations>begin)&(observations<end)],
                             background.boundaries(begin,end), end])
    require(bounds[0]==begin and bounds[-1]==end, 'original interval')
    blocks, queries = {}, []
    for steps in (32,64,128):
        grid = np.concatenate([np.linspace(left,right,1+int(np.ceil((right-left)/(width/steps))))[:-1] for left,right in zip(bounds,bounds[1:])] + [[end]])
        raw = grid[:-1,None] + (grid[1:]-grid[:-1])[:,None]*np.r_[DOP853.C,1]
        raw[:,-2:] = grid[1:,None]
        blocks[str(steps)] = (grid,raw)
        queries.append(raw.ravel())
    clocks = np.unique(np.concatenate(queries))
    require(clocks[0]==begin and clocks[-1]==end,'all original clock nodes')
    with np.load(PREV/f'{case}-prepared.npz') as packet:
        seed = packet['represented'][0]
        constants = packet['constants']
    smooth, remainder = clock_words(background,clocks)
    call = library()
    high, low, _ = integrate(call, constants,(len(seed)-1)//2,5,1,clocks,seed,np.zeros_like(seed),width/128)
    other, otherlow, _ = integrate(call, constants,(len(seed)-1)//2,4,0,clocks,seed,np.zeros_like(seed),width/64)
    require(np.max(np.abs(((high-other)+(low-otherlow))[:,0])) < 1e-28,'early clock coordinates')
    data = dict(clocks=clocks, high=high, low=low, smooth=smooth, remainder=remainder, constants=constants,
                bounds=bounds, width=width, analytic_control=control(call))
    for steps,(grid,raw) in blocks.items():
        mapped = np.searchsorted(clocks,raw)
        require(np.array_equal(clocks[mapped],raw),'exact RK stage times')
        data['grid'+steps],data['index'+steps] = grid,mapped
    with (ROOT/(case+'-clock.npz')).open('xb') as stream:
        np.savez_compressed(stream,**data)
    print(case,len(clocks),'stage times',len(bounds),'original knots',flush=True)


if __name__=='__main__':
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    require(bank.digest(PREV/'closeout.json')=='7d787ffe267c9c7594d22266f3e1fb62df6b8db50628043ef6a0d8adbd306993','previous clock sealed')
    bank.save(ROOT/'clock-owner.json',dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline()))
    for case in ('cold','heavy'):
        main(case)
