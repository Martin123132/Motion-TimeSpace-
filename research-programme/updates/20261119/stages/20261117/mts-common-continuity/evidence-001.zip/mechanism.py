from decimal import Decimal,localcontext
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parent
PREV=ROOT.parent/'mts-matched-clock-precision-20261117'
sys.path.insert(0,str(PREV))
from matched import owner,bank,np,require,as_decimal
from response import densities
import math


def split(case):
    params,_,bg,_,_=owner.EX.problem(case)
    constants=list(map(as_decimal,bg.constants))
    forecast=bank.read(ROOT/(case+'-curvature-v2-smooth-frozen.json'))
    with np.load(ROOT/(case+'-clock.npz')) as packet,np.load(ROOT/(case+'-capture.npz')) as capture:
        state=[as_decimal(a)+as_decimal(b) for a,b in zip(packet['smooth'][0],packet['remainder'][0])]
        direct=capture['reference'][0]
        ratio=as_decimal(direct[3])/(as_decimal(direct[3])-Decimal('.75')*as_decimal(direct[int(capture['signature'][0,3])]))
    scale=state[0]
    efold=scale.ln()
    rho=densities(constants,state)
    hubble=(sum(rho)/3).sqrt()
    eps=as_decimal(forecast['expansion_minus_reference'])
    rate=hubble-eps
    pieces=dict(dust=-eps*(rho[0]+rho[1]),massless_radiation=-2*eps*(rho[2]+rho[3]))
    nu=Decimal(0)
    coef=Decimal(5)/(7*as_decimal(math.pi)**2)
    for i in range(int(constants[4])):
        am=scale*constants[8+i]
        shape=1+coef*am**2
        slope=2*coef*am**2
        if am>=Decimal('.01'):
            term=Decimal('.01099926669')*am.ln()-Decimal('.003492416767')-Decimal('.005866275571')*am
            shape+=am**4*term
            slope+=am**4*(4*term+Decimal('.01099926669')-Decimal('.005866275571')*am)
        nu+=constants[14+i]*eps*(slope-2*shape)/scale**2
    pieces['massive_neutrino']=nu
    for i,pair in enumerate(bg.fields):
        ph,vel=state[1+2*i:3+2*i]
        mass2=(scale*constants[6+i])**2
        slopes=[]
        for spline in pair:
            loc=int(np.searchsorted(spline.x,float(efold),side='right')-1)
            off=efold-as_decimal(spline.x[loc])
            cubic,quad,linear=map(as_decimal,spline.c[:3,loc])
            slopes.append(rate*((3*cubic*off+2*quad)*off+linear))
        name=('slow','heavy')[i]
        pieces[name+'_clock']=mass2*ph**2*eps
        pieces[name+'_field_jet']=mass2*ph*(vel-slopes[0])
        pieces[name+'_velocity_jet']=vel*(-2*hubble*vel-mass2*ph-slopes[1])
    metric={key:val/(6*hubble) for key,val in pieces.items()}
    total=sum(metric.values())
    require(abs(float(total)/forecast['metric_hprime_difference']-1)<bank.ALG,'metric derivative from separate species')
    curve={key:float(-ratio*val/3) for key,val in metric.items()}
    driven=sum(curve.values())
    return dict(derivative_by_species={k:float(v) for k,v in metric.items()},
                energy_curvature_by_metric_term=curve,metric_piece=driven,total=forecast['curvature'],
                all_nonmetric_terms=forecast['curvature']-driven,velocity_over_slip=float(ratio))


if __name__=='__main__':
    bank.guard()
    with localcontext() as ctx:
        ctx.prec=65
        results={case:split(case) for case in ('cold','heavy')}
    bank.save(ROOT/'mechanism.json',results)
    for case,row in results.items():
        print(case,{k:round(v/row['total'],8) for k,v in row['energy_curvature_by_metric_term'].items()},
              'other',row['all_nonmetric_terms']/row['total'])
