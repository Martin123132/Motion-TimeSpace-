import math
from adaptive import ROOT,PREV,Path,Problem,Continuous,bank,np,require,jet_reader,sys,dec,localcontext
from response import densities


class Metric:
    def __init__(self,direct,owner):
        self.real=direct
        self.owner=owner

    def __getattr__(self,name):
        return getattr(self.real,name)

    def read_metric(self,time,vector,background,corrected):
        packet=background if corrected else self.owner.oldpacket(time)
        return self.real.read_metric(time,vector,packet,True)


class Consistent(Continuous):
    def configure(self,kind):
        self.bind()
        self.kind=kind
        self.real=self.native
        self.direct=Metric(self.direct,self)
        self.native=self.paired_sample
        self.oldwords={}
        grid=self.clock['clocks']
        self.holds,self.lows=self.words(self.direct.background,grid)
        width=self.direct.width
        if kind=='smooth':
            self.Qhigh,self.Qlow,_=self.advance(self.library,self.clock['constants'],self.count,5,1,grid,
                  self.holds[0],self.lows[0],self.clock['width']/128)
        else:
            self.Qhigh,self.Qlow=self.clock['high'],self.clock['low']
        require(len(self.holds[0])==width,'all geometric primitives')
        self.case=self.case+'-paired-'+kind

    def old(self,time):
        if time not in self.oldwords:
            idx=np.searchsorted(self.grid,time)
            if idx<len(self.grid) and self.grid[idx]==time:
                result=self.holds[idx],self.lows[idx]
            else:
                tops,bots=self.words(self.direct.background,np.array([time]))
                result=tops[0],bots[0]
            self.oldwords[time]=result
        return self.oldwords[time]

    def oldpacket(self,time):
        packet=np.zeros(5)
        packet[:self.direct.width]=self.old(time)[0]
        return packet

    def paired_sample(self,time,vec,background,corrected):
        if corrected:
            return self.real(time,vec,background,True)
        packet=self.oldpacket(time)
        derivative,obs,extra=self.real(time,vec,packet,True)
        ratio=extra[0]/packet[0]
        extra[0]=packet[0]
        extra[1]*=ratio
        extra[2]*=ratio**2
        return derivative,obs,extra

    def at(self,time,smooth):
        require(smooth,'fully paired continuous convention only')
        if time in self.lookup:
            return self.lookup[time]
        idx=np.searchsorted(self.grid,time,side='right')-1
        require(0<=idx and time<=self.grid[-1],'no clock extrapolation')
        width=self.direct.width
        high,low=self.Qhigh[idx,:width],self.Qlow[idx,:width]
        if self.grid[idx]!=time:
            upper,lower,_=self.advance(self.library,self.clock['constants'],self.count,5,1,np.array([self.grid[idx],time]),
                                      high,low,self.clock['width']/128)
            high,low=upper[-1,:width],lower[-1,:width]
        top,bot=self.old(time)
        with localcontext() as context:
            context.prec=60
            before=[dec(v)+dec(w) for v,w in zip(top,bot)]
            after=[dec(v)+dec(w) for v,w in zip(high,low)]
            h0=(sum(densities(self.constants,before))/3).sqrt()
            h1=(sum(densities(self.constants,after))/3).sqrt()
            delta=np.array([float(right-left) for left,right in zip(before,after)])
            hubble=float(h1-h0)
        result=time,top,delta,hubble
        self.lookup[time]=result
        return result


def main(case):
    bank.guard()
    proc=bank.psutil.Process()
    proc.cpu_affinity([4])
    proc.nice(bank.psutil.BELOW_NORMAL_PRIORITY_CLASS)
    tag=case+'-paired'
    bank.save(ROOT/(tag+'-owner.json'),dict(pid=proc.pid,created=proc.create_time(),command=proc.cmdline(),
                  method=bank.digest(ROOT/'PREPARATION-SPLIT.md'),code=bank.digest(ROOT/'preparation_split.py')))
    bank.ROOT=ROOT
    live,context=bank.native_setup(case,64,tag)
    with np.load(ROOT/(case+'-clock.npz')) as data:
        clock={key:data[key] for key in data}
    with context as (capture,meta,sample):
        with np.load(ROOT/(case+'-capture.npz')) as frozen:
            require(all(np.array_equal(capture[key],frozen[key]) for key in capture),'same complete native capture')
        prepared,_,background,_,_=live.EX.problem(case)
        direct=live.MetricCoupled(case,prepared,background,live.prefix(capture,case),meta,sample)
        for kind in ('binary','smooth'):
            problem=Consistent(case,direct,clock,capture,jet_reader(direct.model.count))
            problem.configure(kind)
            check=[]
            for index in (0,len(clock['clocks'])//2,-1):
                bg=problem.at(clock['clocks'][index],True)
                zero=problem.flow((bg[0],bg[1],np.zeros_like(bg[2]),0.),problem.initial,1.)
                require(np.all(zero[problem.active:2*problem.active]==0) and np.all(zero[-2:]==0),'identical operators give zero response')
                if kind=='smooth' and index==0:
                    require(np.all(bg[2]==0) and bg[3]==0,'fully matched preparation')
                check.append(dict(time=bg[0],alpha=bg[2][0]/bg[1][0],delta_hubble=bg[3],zero_rows=problem.active))
            bank.save(ROOT/(problem.case+'-zero.json'),check)
            for steps in (32,64):
                problem.adaptive(steps,True)


if __name__=='__main__':
    main(sys.argv[1])
