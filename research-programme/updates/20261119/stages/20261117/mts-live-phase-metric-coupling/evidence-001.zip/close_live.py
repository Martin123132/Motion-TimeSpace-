from restart_support import *
import importlib.metadata


if __name__ == '__main__':
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    mapping = read(ROOT / 'inputs.json')
    check_inputs(mapping)
    science = read(ROOT / 'science-score.json')
    verification = read(ROOT / 'verification.json')
    require(verification['passed'] and all(verification['checks'].values()), 'verified continuation')
    require(science['main_passed'] and science['independent_native_passed'], 'full budgets and native controls')
    require(science['implementation_equivalence_passed'], 'coordinate equivalence')
    require(not science['all_precision_checks_pass'], 'preserved unresolved baseline response')
    require(not science['cases']['cold']['direct']['small_response_precision']['passed'], 'baseline limitation retained')
    workers = {path.name: {**read(path), **exited(read(path))} for path in ROOT.glob('*-start.json')}
    expected = {'prepare', 'cold-preflight', 'heavy-preflight', 'score', 'verify'}
    expected.update(case + '-' + mode + '-' + str(steps)
                    for case, mode in (('cold', 'direct'), ('heavy', 'direct'), ('heavy', 'phase'))
                    for steps in CONFIG['steps'])
    require(set(workers) == {label + '-start.json' for label in expected}, 'complete owned worker inventory')
    require(all(item['exited'] for item in workers.values()), 'all exact worker identities exited')
    for label in expected:
        start = read(ROOT / (label + '-start.json'))
        end = read(ROOT / (label + '-end.json'))
        require(end['completed'] and all(start[key] == end[key] for key in ('pid', 'created', 'command')), 'successful matching receipt: ' + label)
    releases = {path.name: read(path) for path in ROOT.glob('*-owner-release.json')}
    require(len(releases) == 8 and all(item['cleared'] for item in releases.values()), 'all eight native owners released')
    require(not list(ROOT.glob('*-failure.json')), 'no omitted failed workers')
    require(not list(ROOT.rglob('__pycache__')), 'no bytecode')
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'), str(path), 'exec')
    for name in ('RESULTS.md', 'NEXT.md', 'DERIVATION.md', 'CONTRACT.md'):
        require((ROOT / name).is_file(), 'saved explanation: ' + name)
    closer = identity(process)
    write(ROOT / 'cleanup.json', {'workers': workers, 'all_exited': True,
        'native_owner_releases': releases, 'native_owners_released': 8,
        'closer_identity': closer, 'closer_exit_verification': 'required after foreground command returns',
        'temporary_tools': [], 'other_processes_changed': False, 'python': sys.version,
        'packages': {name: importlib.metadata.version(name) for name in ('numpy', 'scipy', 'mpmath', 'psutil')}})
    artifacts = {str(path.relative_to(ROOT)): {'sha256': digest(path), 'bytes': path.stat().st_size}
                 for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name != 'closeout.json'}
    result = {'stage': 'Live phase-aware common-metric coupling',
        'utc': datetime.now(timezone.utc).isoformat(), 'completed': True,
        'technical_checks': verification['count'], 'verification_passed': True,
        'main_passed': science['main_passed'], 'independent_native_passed': science['independent_native_passed'],
        'implementation_equivalence_passed': science['implementation_equivalence_passed'],
        'all_precision_checks_pass': science['all_precision_checks_pass'],
        'new_epoch': 3040, 'future_source_metric_forcing_used': False,
        'retained_background_tables_used': True, 'parameters_fitted': 0,
        'earlier_failures_preserved': True, 'frozen_inputs': len(mapping),
        'workers_exited': len(workers), 'native_owners_released': len(releases),
        'github': False, 'artifacts': artifacts}
    write(ROOT / 'closeout.json', result)
    print(json.dumps({'seal': digest(ROOT / 'closeout.json'), 'artifacts': len(artifacts),
        'bytes': sum(item['bytes'] for item in artifacts.values()), 'workers_exited': len(workers),
        'frozen_inputs': len(mapping), 'closer': closer}), flush=True)
