from restart_bridge import *
import math


class Pair:
    def __init__(self,base,change=0.):
        self.base,self.change=float(base),float(change)
    @staticmethod
    def of(value):
        return value if isinstance(value,Pair) else Pair(value)
    def __add__(self,other):
        other=Pair.of(other)
        return Pair(self.base+other.base,self.change+other.change)
    __radd__=__add__
    def __neg__(self):
        return Pair(-self.base,-self.change)
    def __sub__(self,other):
        return self+-Pair.of(other)
    def __rsub__(self,other):
        return Pair.of(other)+-self
    def __mul__(self,other):
        other=Pair.of(other)
        return Pair(self.base*other.base,math.fsum((self.base*other.change,self.change*other.base,self.change*other.change)))
    __rmul__=__mul__
    def inverse(self):
        require(self.base!=0 and self.base+self.change!=0,'nonzero pair denominator')
        return Pair(1/self.base,-self.change/(self.base*(self.base+self.change)))
    def __truediv__(self,other):
        return self*Pair.of(other).inverse()
    def __rtruediv__(self,other):
        return Pair.of(other)*self.inverse()
    def __pow__(self,power):
        require(isinstance(power,int) and power>=0,'nonnegative integer pair power')
        result=Pair(1.)
        for _ in range(power):
            result=result*self
        return result
    def log(self):
        require(self.base>0 and self.base+self.change>0,'positive logarithm')
        return Pair(math.log(self.base),math.log1p(self.change/self.base))


def external_derivative(constants,scale):
    result=-(constants[0]+constants[1])/scale-2*(constants[2]+constants[3])/scale**2
    for index in range(int(constants[4])):
        argument=scale*constants[8+index]
        require(0<argument.base<=.3+70/1399*1.01 and 0<argument.base+argument.change<=.3+70/1399*1.01,'retained neutrino support')
        require((argument.base<.01)==(argument.base+argument.change<.01),'same neutrino branch')
        quadratic=5/(7*np.pi**2)*argument**2
        density=1+quadratic
        slope=2*quadratic
        if argument.base>=.01:
            logarithm=argument.log()
            density=density+argument**4*(.01099926669*logarithm-.003492416767-.005866275571*argument)
            slope=slope+argument**4*(.01099926669*(4*logarithm+1)-4*.003492416767-5*.005866275571*argument)
        result=result+constants[14+index]/scale**2*(slope-2*density)
    return result


def matrices(model,prepared,clock,physical):
    base=model.represented(clock)
    alpha,field_change,velocity_change=model.unpack(physical)
    hubble_change,_=model.correction_geometry(base,physical,False)
    scale=Pair(base['scale'],base['scale']*alpha)
    hubble=Pair(base['hubble'],hubble_change)
    rate=Pair(base['rate'],hubble_change+(base['hubble']-base['rate']))
    fields=[Pair(value,delta) for value,delta in zip(base['field'],field_change)]
    velocities=[Pair(value,delta) for value,delta in zip(base['velocity'],velocity_change)]
    masses=[(scale*model.constants[6+index])**2 for index in range(model.count)]
    field_primes=[Pair(value,velocity_change[index]-(value-base['velocity'][index])) for index,value in enumerate(base['field_first'])]
    velocity_primes=[]
    for index,value in enumerate(base['velocity_first']):
        physical_acceleration=-2*hubble*velocities[index]-masses[index]*fields[index]
        contact=value-physical_acceleration.base
        velocity_primes.append(Pair(value,physical_acceleration.change-contact))
    density_prime=rate*external_derivative(model.constants,scale)
    for phi,velocity,mass2,phi_prime,velocity_prime in zip(fields,velocities,masses,field_primes,velocity_primes):
        density_prime=density_prime+velocity*velocity_prime+rate*mass2*phi**2+mass2*phi*phi_prime
    hubble_prime=density_prime/(6*hubble)
    scalar=1
    phi,velocity,mass2,phi_prime,velocity_prime=(items[scalar] for items in (fields,velocities,masses,field_primes,velocity_primes))
    mu=scale*model.constants[7]
    beta=scale/float(prepared['density0'])
    wave=CONFIG['retained_comoving_wave']
    fraction=4*mass2/(4*mass2+wave**2)
    fraction_prime=2*rate*fraction*(1-fraction)
    kappa=1.5*hubble*fraction
    kappa_prime=1.5*(hubble_prime*fraction+hubble*fraction_prime)
    first=mass2*phi+kappa*velocity
    second=velocity+kappa*phi
    first_prime=2*rate*mass2*phi+mass2*phi_prime+kappa_prime*velocity+kappa*velocity_prime
    second_prime=velocity_prime+kappa_prime*phi+kappa*phi_prime
    transform=[[beta*first,beta*second],[beta*mu*velocity,-beta*mu*phi]]
    derivative=[[beta*(rate*first+first_prime),beta*(rate*second+second_prime)],
                [beta*mu*(2*rate*velocity+velocity_prime),-beta*mu*(2*rate*phi+phi_prime)]]
    result=[]
    for matrix in (transform,derivative):
        result.extend([np.array([[getattr(value,part) for value in row] for row in matrix]) for part in ('base','change')])
    require(all(np.isfinite(item).all() for item in result),'finite phase matrices')
    margins=[]
    for branch in (0,1):
        getter=lambda value:value.base+branch*value.change
        energy=getter(velocity)**2+getter(mass2)*getter(phi)**2
        relative=abs(getter(kappa))/getter(mu)
        require(energy>0 and relative<1,'live invertible phase coordinates')
        margins.append(relative)
    raw={'scale':scale,'hubble':hubble,'rate':rate,'phi':phi,'velocity':velocity,'mass2':mass2,'mu':mu,'beta':beta,
         'phi_prime':phi_prime,'velocity_prime':velocity_prime,'hubble_prime':hubble_prime}
    return (*result,np.array(margins),raw)


class LivePhase(MetricCoupled):
    def __init__(self,*arguments):
        super().__init__(*arguments)
        self.phase_indices=np.array([self.first+2,self.first+3])
        self.phase_norm=float(read(ROOT/'coordinate-norms.json')['heavy']['scalar_source_norms'][1][0])
        self.phase_delta_norm=self.phase_norm*1e-5

    def transforms(self,clock,normalized):
        physical=normalized[2*self.active:2*self.active+self.width]*self.background_units
        return matrices(self.model,self.prepared,clock,physical)

    def encode(self,clock,native):
        transform,change,_,_,_,_=self.transforms(clock,native)
        fields=native[self.phase_indices]*self.state_units[self.phase_indices]
        correction=native[self.active+self.phase_indices]*self.delta_units[self.phase_indices]
        result=native.copy()
        result[self.phase_indices]=(transform@fields)/self.phase_norm
        result[self.active+self.phase_indices]=((transform+change)@correction+change@fields)/self.phase_delta_norm
        return result

    def decode(self,clock,normalized,matrices_value=None):
        transform,change,_,_,_,_=self.transforms(clock,normalized) if matrices_value is None else matrices_value
        fields=np.linalg.solve(transform,normalized[self.phase_indices]*self.phase_norm)
        correction=np.linalg.solve(transform+change,normalized[self.active+self.phase_indices]*self.phase_delta_norm-change@fields)
        result=normalized.copy()
        result[self.phase_indices]=fields/self.state_units[self.phase_indices]
        result[self.active+self.phase_indices]=correction/self.delta_units[self.phase_indices]
        return result

    def calculate(self,clock,normalized,readout):
        matrix_values=self.transforms(clock,normalized)
        transform,change,derivative,derivative_change,margin,_=matrix_values
        native=self.decode(clock,normalized,matrix_values)
        rhs,values=super().evaluate(clock,native) if readout else retained_run.Coupled.evaluate(self,clock,native)
        fields=native[self.phase_indices]*self.state_units[self.phase_indices]
        correction=native[self.active+self.phase_indices]*self.delta_units[self.phase_indices]
        field_rhs=rhs[self.phase_indices]*self.state_units[self.phase_indices]
        correction_rhs=rhs[self.active+self.phase_indices]*self.delta_units[self.phase_indices]
        result=rhs.copy()
        result[self.phase_indices]=(transform@field_rhs+derivative@fields)/self.phase_norm
        result[self.active+self.phase_indices]=((transform+change)@correction_rhs+change@field_rhs+
            (derivative+derivative_change)@correction+derivative_change@fields)/self.phase_delta_norm
        values['phase_margin']=margin
        return result,values

    def evaluate(self,clock,normalized):
        return self.calculate(clock,normalized,True)

    def rhs(self,clock,normalized):
        self.calls+=1
        if self.calls%128==0:
            guard()
        return self.calculate(clock,normalized,False)[0]

    def native_derivative(self,clock,normalized,phase_rhs):
        transform,change,derivative,derivative_change,_,_=self.transforms(clock,normalized)
        native=self.decode(clock,normalized)
        fields=native[self.phase_indices]*self.state_units[self.phase_indices]
        correction=native[self.active+self.phase_indices]*self.delta_units[self.phase_indices]
        old_rhs=np.linalg.solve(transform,phase_rhs[self.phase_indices]*self.phase_norm-derivative@fields)
        delta_rhs=np.linalg.solve(transform+change,phase_rhs[self.active+self.phase_indices]*self.phase_delta_norm-
            change@old_rhs-(derivative+derivative_change)@correction-derivative_change@fields)
        result=phase_rhs.copy()
        result[self.phase_indices]=old_rhs/self.state_units[self.phase_indices]
        result[self.active+self.phase_indices]=delta_rhs/self.delta_units[self.phase_indices]
        return result
