from score_live import *


def verify():
    inputs()
    science=read(ROOT/'science-score.json')
    checks={'exact_score_replay':calculate()==science}
    for case in CONFIG['cases']:
        checks[case+'_preflight']=read(ROOT/(case+'-preflight-result.json'))['passed']
        modes=('direct','phase') if case=='heavy' else ('direct',)
        for mode in modes:
            for steps in CONFIG['steps']:
                label=case+'-'+mode+'-'+str(steps)
                data=load(ROOT/(label+'.npz'))
                initial=load(saved(case))
                terminal=load(ROOT/(label+'-terminal.npz'))
                checks[label+'_finite']=all(bool(np.isfinite(value).all()) for value in data.values())
                checks[label+'_native_terminal_exact']=np.array_equal(terminal['normalized'],data['normalized'][-1])
                checks[label+'_immutable_units']=np.array_equal(terminal['units'],initial['units'])
                checks[label+'_new_epoch']=read(ROOT/(label+'-result.json'))['last_epoch']==3040
                checks[label+'_no_future_forcing']=not read(ROOT/(label+'-result.json'))['saved_future_forcing_used']
                checks[label+'_owner_released']=read(ROOT/(label+'-owner-release.json'))['cleared']
                for path in sorted(ROOT.glob(label+'-boundary*-history.npz')):
                    batch=load(path)
                    count=len(batch['time'])
                    checks[path.stem+'_state_exact']=np.array_equal(batch['normalized'],data['normalized'][:count])
                    checks[path.stem+'_encoded_exact']=np.array_equal(batch['encoded'],data['encoded'][:count])
                if mode=='phase':
                    phase_terminal=load(ROOT/(label+'-phase-terminal.npz'))
                    checks[label+'_encoded_terminal_exact']=np.array_equal(phase_terminal['encoded'],data['encoded'][-1])
                    checks[label+'_regular']=bool(np.max(data['phase_margin'])<1)
        checks[case+'_main']=all(report['main_passed'] for report in science['cases'][case].values())
    checks['phase_direct_implementation_equivalence']=science['implementation_equivalence_passed']
    for name,value in checks.items():
        require(bool(value),name)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    require(not (ROOT/'__pycache__').exists(),'no bytecode')
    write(ROOT/'verification.json',{'checks':checks,'count':len(checks),'passed':True,
        'independent_native_status':science['independent_native_passed'],'all_precision_status':science['all_precision_checks_pass']})
    print(json.dumps({'checks':len(checks),'passed':True,'independent_native_status':science['independent_native_passed'],'all_precision_status':science['all_precision_checks_pass']}),flush=True)


if __name__=='__main__':
    with worker('verify'):
        verify()
