from live_phase import *
import mpmath as mp


def high_precision_matrix(raw,branch):
    get=lambda name:mp.mpf(raw[name].base)+branch*mp.mpf(raw[name].change)
    scale,hubble,rate,phi,velocity,mass2,mu,beta,phi_prime,velocity_prime,hubble_prime=(get(name) for name in
        ('scale','hubble','rate','phi','velocity','mass2','mu','beta','phi_prime','velocity_prime','hubble_prime'))
    wave=mp.mpf(CONFIG['retained_comoving_wave'])
    fraction=4*mass2/(4*mass2+wave**2)
    fraction_prime=2*rate*fraction*(1-fraction)
    kappa=mp.mpf('1.5')*hubble*fraction
    kappa_prime=mp.mpf('1.5')*(hubble_prime*fraction+hubble*fraction_prime)
    first,second=mass2*phi+kappa*velocity,velocity+kappa*phi
    first_prime=2*rate*mass2*phi+mass2*phi_prime+kappa_prime*velocity+kappa*velocity_prime
    second_prime=velocity_prime+kappa_prime*phi+kappa*phi_prime
    return mp.matrix([[beta*first,beta*second],[beta*mu*velocity,-beta*mu*phi]]),mp.matrix([
        [beta*(rate*first+first_prime),beta*(rate*second+second_prime)],
        [beta*mu*(2*rate*velocity+velocity_prime),-beta*mu*(2*rate*phi+phi_prime)]])


def audit(model,prepared,clock,physical):
    checks={}
    with mp.workdps(80):
        for multiplier in (0.,.001,1.,100.):
            transform,change,derivative,derivative_change,_,raw=matrices(model,prepared,clock,physical*multiplier)
            old=high_precision_matrix(raw,0)
            new=high_precision_matrix(raw,1)
            for name,actual,expected in (('matrix',transform,old[0]),('matrix_change',change,new[0]-old[0]),
                ('derivative',derivative,old[1]),('derivative_change',derivative_change,new[1]-old[1])):
                reference=np.array(expected.tolist(),dtype=float)
                scale=max(maximum(reference),np.finfo(float).tiny)
                checks[str(multiplier)+'_'+name]=ratio(maximum(actual-reference),scale,CONFIG['algebra_tolerance'])
        constants=[mp.mpf(float(value)) for value in model.constants]
        def density(scale):
            result=(constants[0]+constants[1])/scale+(constants[2]+constants[3])/scale**2
            for index in range(int(constants[4])):
                argument=scale*constants[8+index]
                value=1+mp.mpf(float(5/(7*np.pi**2)))*argument**2
                if argument>=mp.mpf('.01'):
                    value+=argument**4*(mp.mpf(float(.01099926669))*mp.log(argument)-mp.mpf(float(.003492416767))-
                                       mp.mpf(float(.005866275571))*argument)
                result+=constants[14+index]/scale**2*value
            return result
        base=model.represented(clock)['scale']
        for alpha in (0.,1e-15,-1e-12,1e-7):
            scale=Pair(base,base*alpha)
            actual=external_derivative(model.constants,scale)
            initial=mp.mpf(scale.base)
            changed=initial+mp.mpf(scale.change)
            old=initial*mp.diff(density,initial)
            new=changed*mp.diff(density,changed)
            for name,observed,expected in (('base',actual.base,old),('change',actual.change,new-old)):
                reference=float(expected)
                checks['external_'+str(alpha)+'_'+name]=ratio(abs(observed-reference),max(abs(reference),np.finfo(float).tiny),CONFIG['algebra_tolerance'])
    return checks
