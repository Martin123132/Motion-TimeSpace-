from live_phase import *
from audit_pairs import audit
from run_phase import source_paths,readouts
import argparse


def saved(case):
    return GAP/(case+'-live-64-terminal.npz')


def prepare():
    previous=Path(CONFIG['phase_state_directory'])
    require(digest(previous/'closeout.json')==CONFIG['phase_state_seal'],'accepted phase-aware seal')
    mapping=read(previous/'inputs.json')
    mapping[str(previous/'closeout.json')]=CONFIG['phase_state_seal']
    for name,item in read(previous/'closeout.json')['artifacts'].items():
        mapping[str(previous/name)]=item['sha256']
    check_inputs(mapping)
    report={}
    for case in CONFIG['cases']:
        state=load(saved(case))
        path=source_paths(case)
        with np.load(path,allow_pickle=False) as archive:
            clocks=archive['conformal_time'][CONFIG['start_index']:CONFIG['last_index']+1]
            scales=archive['requested_scale'][CONFIG['start_index']:CONFIG['last_index']+1]
        require(len(clocks)==2 and clocks[0]==float(state['tau']),'same3039 initial state and fixed next original epoch')
        prepared,_,background,_,_=EX.problem(case)
        boundaries=background.boundaries(float(clocks[0]),float(clocks[-1]))
        times=np.unique(np.r_[clocks[0],boundaries,clocks[-1]])
        require(times[0]==clocks[0] and times[-1]==clocks[-1] and np.all(np.diff(times)>0),'positive unchanged integration support')
        background.evaluate(times)
        np.savez_compressed(ROOT/(case+'-clock.npz'),time=times,native_time=clocks,native_indices=np.array([0,len(times)-1]),requested_scale=scales)
        report[case]={'native_epochs':[3039,3040],'samples':len(times),'elapsed_Mpc':float(clocks[-1]-clocks[0]),
            'steps32':float(prepared['elapsed'][8])/32,'steps64':float(prepared['elapsed'][8])/64}
        mapping[str(path)]=digest(path)
    write(ROOT/'frozen-norms.json',read(GAP/'frozen-norms.json'))
    write(ROOT/'coordinate-norms.json',read(previous/'frozen-norms.json'))
    write(ROOT/'preparation.json',{'utc':datetime.now(timezone.utc).isoformat(),'cases':report,
        'before_new_coupled_evolution':True,'future_source_not_used':True})
    for path in sorted(ROOT.iterdir()):
        if path.suffix in ('.py','.json','.md','.npz') and not path.name.endswith(('-start.json','-end.json','-failure.json')):
            if path.suffix=='.py':
                compile(path.read_text(encoding='utf-8'),str(path),'exec')
            mapping[str(path)]=digest(path)
    write(ROOT/'inputs.json',mapping)
    inputs()
    print(json.dumps(report),flush=True)


def owner_system(case,label):
    return native_context(case,label)


def systems(case,captured,metadata,sample):
    previous=load(GAP/(case+'-live-64-capture.npz'))
    for name,value in captured.items():
        require(np.array_equal(value[:1049],previous[name]),'known1049 owner prefix: '+name)
    prepared,_,background,_,_=EX.problem(case)
    initial=prefix(captured,case)
    direct=MetricCoupled(case,prepared,background,initial,metadata,sample)
    state=restore(direct,saved(case))
    phase_system=LivePhase(case,prepared,background,initial,metadata,sample) if case=='heavy' else None
    return direct,phase_system,state


def preflight(case):
    inputs()
    label=case+'-preflight'
    with owner_system(case,label) as (captured,metadata,sample):
        direct,phase_system,state=systems(case,captured,metadata,sample)
        checks={'original_initial_rhs_exact':True,'known1049_prefix_exact':True}
        if case=='heavy':
            clock=float(state['tau'])
            native=state['normalized']
            encoded=phase_system.encode(clock,native)
            decoded=phase_system.decode(clock,encoded)
            original_rhs,original_readout=direct.evaluate(clock,native)
            phase_rhs,phase_readout=phase_system.evaluate(clock,encoded)
            restored_rhs=phase_system.native_derivative(clock,encoded,phase_rhs)
            selected=phase_system.phase_indices
            remaining=np.ones(len(native),dtype=bool)
            remaining[selected]=False
            remaining[phase_system.active+selected]=False
            checks['unaffected_state_exact']=bool(np.array_equal(native[remaining],decoded[remaining]))
            checks['rhs_fast_and_readout_exact']=bool(np.array_equal(phase_system.rhs(clock,encoded),phase_rhs))
            numeric={}
            for block,indices in (('old',selected),('change',phase_system.active+selected)):
                numeric[block+'_state_roundtrip']=ratio(maximum(native[indices]-decoded[indices]),max(maximum(native[indices]),np.finfo(float).tiny),CONFIG['algebra_tolerance'])
                numeric[block+'_rhs_roundtrip']=ratio(maximum(original_rhs[indices]-restored_rhs[indices]),maximum(abs(original_rhs[indices])+abs(restored_rhs[indices])),CONFIG['algebra_tolerance'])
            for name in ('metric','source','source_change','work','work_change','live_balance_rhs'):
                numeric[name+'_readout']=ratio(maximum(phase_readout[name]-original_readout[name]),max(maximum(original_readout[name]),np.finfo(float).tiny),CONFIG['algebra_tolerance'])
            stable=audit(direct.model,direct.prepared,clock,state['background_change'])
            checks['stable_pair_80digit_controls']=all(item['passed'] for item in stable.values())
            checks['native_state_rhs_readout_controls']=all(item['passed'] for item in numeric.values())
            write(ROOT/'heavy-stable-pair-controls.json',stable)
            write(ROOT/'heavy-initial-mapping-checks.json',numeric)
            np.savez_compressed(ROOT/'heavy-encoded-initial.npz',tau=np.array(clock),encoded=encoded,native=native,decoded=decoded,
                                phase_rhs=phase_rhs,native_rhs=original_rhs)
        require(all(checks.values()),'live coupling preflight: '+str(checks))
        write(ROOT/(label+'-result.json'),{'checks':checks,'passed':True})
        print(json.dumps({'case':case,'preflight':checks}),flush=True)
    inputs()


def run(case,mode,steps):
    inputs()
    require(read(ROOT/(case+'-preflight-result.json'))['passed'],'preflight before new evolution')
    label=case+'-'+mode+'-'+str(steps)
    with owner_system(case,label) as (captured,metadata,sample):
        direct,phase_system,state=systems(case,captured,metadata,sample)
        system=phase_system if mode=='phase' else direct
        require(system is not None,'defined phase branch')
        clock=load(ROOT/(case+'-clock.npz'))
        times=clock['time']
        require(np.array_equal(captured['clock'][-2:],clock['native_time']),'same original report clocks')
        current=phase_system.encode(float(times[0]),state['normalized']) if mode=='phase' else state['normalized'].copy()
        native_states,encoded_states=[],[]
        observed={}
        initial_observation=system.evaluate(float(times[0]),current)[1]
        for name,value in initial_observation.items():
            observed[name]=np.empty((len(times),*np.asarray(value).shape))
            observed[name][0]=value
        encoded_states.append(current.copy())
        native_states.append(system.decode(float(times[0]),current) if mode=='phase' else current.copy())
        evaluations=0
        for segment,(left,right) in enumerate(zip(times[:-1],times[1:])):
            guard()
            solution=solve_ivp(system.rhs,(float(left),float(right)),current,method='DOP853',t_eval=[right],
                rtol=CONFIG['rtol'],atol=CONFIG['normalized_atol'],max_step=float(system.prepared['elapsed'][8])/steps)
            require(solution.success,'full coupled continuation')
            current=solution.y[:,-1]
            evaluations+=solution.nfev
            output=system.evaluate(float(right),current)[1]
            for name,value in output.items():
                observed[name][segment+1]=value
            native=system.decode(float(right),current) if mode=='phase' else current.copy()
            native_states.append(native)
            encoded_states.append(current.copy())
            if (segment+1)%CONFIG['batch_boundaries']==0 or segment==len(times)-2:
                position=segment+1
                batch=label+'-boundary'+str(position)
                checkpoint(direct,float(right),native,ROOT/(batch+'-terminal.npz'))
                np.savez_compressed(ROOT/(batch+'-history.npz'),time=times[:position+1],normalized=np.array(native_states),
                    encoded=np.array(encoded_states),**{name:value[:position+1] for name,value in observed.items()})
                print(json.dumps({'label':label,'boundary':position,'total':len(times)-1,'evaluations':evaluations}),flush=True)
        observer=captured['observation_reference'][-2:]
        native_control=np.column_stack((-CONFIG['retained_comoving_wave']*(observer[:,26]+observer[:,5])/observer[:,28],
            observer[:,9],observer[:,21],observer[:,20]-.75*observer[:,21],observer[:,26]-.75*observer[:,24]))
        np.savez_compressed(ROOT/(label+'.npz'),time=times,normalized=np.array(native_states),encoded=np.array(encoded_states),
                            native_indices=clock['native_indices'],native_control=native_control,**observed)
        checkpoint(direct,float(times[-1]),native_states[-1],ROOT/(label+'-terminal.npz'))
        if mode=='phase':
            np.savez_compressed(ROOT/(label+'-phase-terminal.npz'),tau=np.array(times[-1]),encoded=current,encoded_rhs=system.rhs(float(times[-1]),current),
                native_normalized=native_states[-1],phase_norm=np.array(system.phase_norm),phase_delta_norm=np.array(system.phase_delta_norm))
        write(ROOT/(label+'-result.json'),{'case':case,'mode':mode,'steps':steps,'last_epoch':3040,'evaluations':evaluations,
            'samples':len(times),'known1049_prefix_exact':True,'new_epoch_live_surroundings':True,'saved_future_forcing_used':False,
            'complete_terminal_saved':True})
    inputs()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=('prepare','preflight','run'))
    parser.add_argument('--case',choices=CONFIG['cases'],default='heavy')
    parser.add_argument('--mode',choices=('direct','phase'),default='phase')
    parser.add_argument('--steps',type=int,choices=CONFIG['steps'],default=32)
    arguments=parser.parse_args()
    label='prepare' if arguments.command=='prepare' else arguments.case+'-'+('preflight' if arguments.command=='preflight' else arguments.mode+'-'+str(arguments.steps))
    with worker(label):
        if arguments.command=='prepare':
            prepare()
        elif arguments.command=='preflight':
            preflight(arguments.case)
        else:
            run(arguments.case,arguments.mode,arguments.steps)
