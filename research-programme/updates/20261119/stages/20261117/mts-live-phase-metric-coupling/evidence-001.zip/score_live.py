from run_live import *
from score_phase import conservative
from verify_phase import primitive_envelope

NAMES=('native_velocity','native_weyl','photon_density','relative_density','velocity_slip')


def calculate():
    result={'cases':{},'new_epoch':3040,'future_forcing_used':False}
    for case in CONFIG['cases']:
        modes=('direct','phase') if case=='heavy' else ('direct',)
        result['cases'][case]={}
        norms=read(ROOT/'frozen-norms.json')[case]
        for mode in modes:
            fine=load(ROOT/(case+'-'+mode+'-64.npz'))
            coarse=load(ROOT/(case+'-'+mode+'-32.npz'))
            require(np.array_equal(fine['time'],coarse['time']),'same continuation clocks')
            high,low=readouts(fine['metric']),readouts(coarse['metric'])
            envelope=primitive_envelope(fine['metric'])+primitive_envelope(coarse['metric'])
            checks,independent={},{}
            for branch,branch_name in enumerate(('old','coherent')):
                for component,name in enumerate(NAMES):
                    refinement=maximum(high[:,branch,component]-low[:,branch,component])
                    amplitude=maximum(envelope[:,branch,component])
                    checks[branch_name+'_'+name]=conservative(0.,refinement,norms['readout_norm'][component],amplitude)
                    if branch==0:
                        independent[name]=conservative(maximum(high[fine['native_indices'],0,component]-fine['native_control'][:,component]),
                            refinement,norms['readout_norm'][component],amplitude)
                source=fine['source']+(fine['source_change'] if branch else 0.)
                previous=coarse['source']+(coarse['source_change'] if branch else 0.)
                work=fine['work']+(fine['work_change'] if branch else 0.)
                previous_work=coarse['work']+(coarse['work_change'] if branch else 0.)
                for component,section in ((0,slice(0,6)),(1,slice(6,9))):
                    residual=source[:,component]-source[0,component]-np.sum(work[:,section]-work[0,section],axis=1)
                    lower=previous[:,component]-previous[0,component]-np.sum(previous_work[:,section]-previous_work[0,section],axis=1)
                    amplitude=maximum(abs(source[:,component])+np.sum(abs(work[:,section]),axis=1))
                    checks[branch_name+'_exchange_'+str(component)]=conservative(maximum(residual),maximum(residual-lower),norms['source_norm'][component],amplitude)
                for component,name in enumerate(('density','current','pressure')):
                    checks[branch_name+'_'+name+'_refinement']=conservative(0.,maximum(source[:,component]-previous[:,component]),
                        norms['source_norm'][component],maximum(abs(source[:,component])+abs(previous[:,component])))
            for name,index in (('trace_residual',3),('shear_residual',4),('eta_residual',5),('density_constraint',6),('friedmann_constraint',7)):
                values=field(fine['metric'][:,1],name)
                previous=field(coarse['metric'][:,1],name)
                checks['coherent_'+name]=conservative(maximum(values),maximum(values-previous),norms['metric_norm'][index],norms['metric_norm'][index])
            response=high[:,1,0]-high[:,0,0]
            response_step=maximum(response-(low[:,1,0]-low[:,0,0]))
            response_check=conservative(0.,response_step,maximum(response),maximum(envelope[:,0,0]+envelope[:,1,0]))
            report={'checks':checks,'main_passed':all(value['passed'] for value in checks.values()),
                'independent_native_controls':independent,'independent_native_passed':all(value['passed'] for value in independent.values()),
                'independent_control_scope':'two original report times only',
                'small_response_precision':response_check,'response_range':[float(np.min(response)),float(np.max(response))],
                'final_response':float(response[-1]),'final_sources':np.stack((fine['source'][-1],fine['source'][-1]+fine['source_change'][-1])).tolist(),
                'diagnostic_samples':len(fine['time']),'elapsed_Mpc':float(fine['time'][-1]-fine['time'][0])}
            if mode=='phase':
                direct=load(ROOT/'heavy-direct-64.npz')
                direct_low=load(ROOT/'heavy-direct-32.npz')
                direct_read=readouts(direct['metric'])
                direct_read_low=readouts(direct_low['metric'])
                parity={}
                for branch,branch_name in enumerate(('old','coherent')):
                    for component,name in enumerate(NAMES):
                        parity[branch_name+'_'+name]=conservative(maximum(high[:,branch,component]-direct_read[:,branch,component]),
                            maximum(high[:,branch,component]-low[:,branch,component])+maximum(direct_read[:,branch,component]-direct_read_low[:,branch,component]),
                            norms['readout_norm'][component],maximum(envelope[:,branch,component]+primitive_envelope(direct['metric'])[:,branch,component]))
                    actual=fine['source']+(fine['source_change'] if branch else 0)
                    original=direct['source']+(direct['source_change'] if branch else 0)
                    for component,name in enumerate(('density','current','pressure')):
                        parity[branch_name+'_source_'+name]=conservative(maximum(actual[:,component]-original[:,component]),
                            0.,norms['source_norm'][component],maximum(abs(actual[:,component])+abs(original[:,component])))
                correction_difference=maximum(response-(direct_read[:,1,0]-direct_read[:,0,0]))
                report.update(implementation_equivalence=parity,implementation_equivalence_passed=all(value['passed'] for value in parity.values()),
                    small_response_implementation_equivalence=conservative(correction_difference,response_step+
                        maximum((direct_read[:,1,0]-direct_read[:,0,0])-(direct_read_low[:,1,0]-direct_read_low[:,0,0])),
                        maximum(response),maximum(envelope[:,0,0]+envelope[:,1,0]+np.sum(primitive_envelope(direct['metric'])[:,:,0],axis=1))),
                    max_phase_validity_ratio=float(np.max(fine['phase_margin'])))
            result['cases'][case][mode]=report
    result['main_passed']=all(report['main_passed'] for case in result['cases'].values() for report in case.values())
    result['independent_native_passed']=all(report['independent_native_passed'] for case in result['cases'].values() for report in case.values())
    result['implementation_equivalence_passed']=result['cases']['heavy']['phase']['implementation_equivalence_passed']
    result['all_precision_checks_pass']=all(report['small_response_precision']['passed'] for case in result['cases'].values() for report in case.values()) and result['cases']['heavy']['phase']['small_response_implementation_equivalence']['passed']
    return result


if __name__=='__main__':
    with worker('score'):
        inputs()
        result=calculate()
        write(ROOT/'science-score.json',result)
        print(json.dumps(result),flush=True)
