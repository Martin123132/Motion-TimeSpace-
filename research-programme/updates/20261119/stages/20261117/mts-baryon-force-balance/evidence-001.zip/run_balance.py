import os
for variable in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "BLIS_NUM_THREADS"):
    os.environ[variable] = "1"
import sys
sys.dont_write_bytecode = True
import argparse
import hashlib
import importlib.util
import json
import math
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import psutil
from scipy.interpolate import PchipInterpolator

ROOT = Path(__file__).resolve().parent
CONFIG = json.loads((ROOT / "protocol.json").read_text())
POST = Path(CONFIG["post_directory"])
METRIC = Path(CONFIG["metric_directory"])
PREVIOUS = Path(CONFIG["previous_directory"])
START = time.monotonic()
SCHEMA = json.loads((METRIC / "packet-schema.json").read_text())
COLUMNS = {name: 84 + index for index, name in enumerate(SCHEMA["global_columns"])}
WAVE = CONFIG["retained_comoving_wave"]

def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def write(path, value):
    encoded = json.dumps(value, indent=2, allow_nan=False) + "\n"
    with Path(path).open("x", encoding="utf-8") as stream:
        stream.write(encoded)

def digest(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def guard():
    require(time.monotonic() - START < CONFIG["maximum_worker_seconds"], "bounded worker deadline")
    require(datetime.now(timezone.utc) < datetime.fromisoformat(CONFIG["turn_stop_utc"]), "four-hour checkpoint")
    for directory in (ROOT, POST, METRIC, PREVIOUS, POST / "condensate-origin-20261003"):
        require(not (directory / "STOP-REQUESTED").exists(), "owner hold: " + str(directory))

def identity(process):
    return {"pid": process.pid, "created": process.create_time(), "command": process.cmdline()}

def exited(saved):
    try:
        current = psutil.Process(saved["pid"])
        return not (abs(current.create_time() - saved["created"]) < .01 and current.cmdline() == saved["command"])
    except psutil.NoSuchProcess:
        return True

@contextmanager
def worker(label):
    process = psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    allowed = process.cpu_affinity()
    process.cpu_affinity([4 if 4 in allowed else allowed[-1]])
    saved = identity(process)
    write(ROOT / (label + "-start.json"), {**saved, "utc": datetime.now(timezone.utc).isoformat(), "threads": 1})
    try:
        guard()
        yield
    except BaseException as error:
        write(ROOT / (label + "-failure.json"), {**saved, "error": repr(error)})
        raise
    else:
        write(ROOT / (label + "-end.json"), {**saved, "completed": True, "seconds": time.monotonic() - START})

def load(path):
    with np.load(path, allow_pickle=False) as archive:
        return {name: archive[name] for name in archive.files}

def field(packet, name):
    return packet[..., COLUMNS[name]]

def maximum(values):
    return float(np.max(np.abs(values)))

def check(error, scale, tolerance=None):
    tolerance = CONFIG["numerical_tolerance"] if tolerance is None else tolerance
    return {"error": float(error), "scale": float(scale), "relative": float(error / scale) if scale else None,
            "tolerance": tolerance, "passed": bool(np.isfinite(error) and error <= tolerance * scale)}

def check_inputs():
    for path, expected in read(ROOT / "inputs.json").items():
        guard()
        require(Path(path).is_file() and digest(path) == expected, "unchanged input: " + path)

def terms(packet):
    material = packet[..., :84].reshape((*packet.shape[:-1], 7, 12))
    baryon, photon = material[..., 1, :], material[..., 2, :]
    require(np.all(baryon[..., 0] > 0) and np.all(photon[..., 0] > 0), "positive backgrounds")
    scale, rate, hubble, sigma, opacity = [field(packet, name) for name in ("scale", "rate", "hubble", "sigma", "opacity")]
    velocity, flux = baryon[..., 4] / baryon[..., 0], photon[..., 4] / photon[..., 0]
    pressure = baryon[..., 5] / baryon[..., 0]
    gamma = 4 * photon[..., 0] * opacity / (3 * baryon[..., 0])
    slip = velocity - .75 * flux
    values = np.stack((scale * WAVE * pressure, -scale * gamma * slip, scale * (rate - hubble) * velocity), axis=-1)
    envelope = np.stack((abs(values[..., 0]), scale * abs(gamma) * (abs(velocity) + .75 * abs(flux)),
                         scale * (abs(rate) + abs(hubble)) * abs(velocity)), axis=-1)
    derivative = scale * (baryon[..., 8] / baryon[..., 0] + 2 * rate * velocity)
    return {"values": values, "envelope": envelope, "actual": derivative, "scale": scale,
            "rate": rate, "hubble": hubble, "sigma": sigma, "velocity": velocity, "flux": flux,
            "pressure": pressure, "gamma": gamma, "slip": slip, "baryon": baryon, "photon": photon}

def ratio_change(old_num, new_num, old_den, new_den):
    return ((new_num - old_num) - (old_num / old_den) * (new_den - old_den)) / new_den

def paired_terms(packet, old, new):
    delta_velocity = ratio_change(old["baryon"][..., 4], new["baryon"][..., 4], old["baryon"][..., 0], new["baryon"][..., 0])
    delta_flux = ratio_change(old["photon"][..., 4], new["photon"][..., 4], old["photon"][..., 0], new["photon"][..., 0])
    delta_pressure = ratio_change(old["baryon"][..., 5], new["baryon"][..., 5], old["baryon"][..., 0], new["baryon"][..., 0])
    delta_scale = new["scale"] - old["scale"]
    delta_agamma = new["scale"] * (new["gamma"] - old["gamma"]) + delta_scale * old["gamma"]
    old_contact, new_contact = old["rate"] - old["hubble"], new["rate"] - new["hubble"]
    delta_contact = new["scale"] * (new_contact - old_contact) + delta_scale * old_contact
    values = np.stack((WAVE * (new["scale"] * delta_pressure + delta_scale * old["pressure"]),
                       -(new["scale"] * new["gamma"] * (delta_velocity - .75 * delta_flux) + delta_agamma * old["slip"]),
                       new["scale"] * new_contact * delta_velocity + delta_contact * old["velocity"]), axis=-1)
    delta_u = delta_velocity + new["sigma"] - old["sigma"]
    original_transfer = -WAVE * (old["velocity"] + old["sigma"]) / old["hubble"]
    transfer_change = -WAVE * delta_u / new["hubble"] - original_transfer * (new["hubble"] - old["hubble"]) / new["hubble"]
    return values, transfer_change

def prepare():
    mapping = {}
    for directory, pin in ((PREVIOUS, CONFIG["previous_seal"]), (METRIC, CONFIG["metric_seal"])):
        require(digest(directory / "closeout.json") == pin, "expected previous seal")
        mapping[str(directory / "closeout.json")] = pin
        for name, item in read(directory / "closeout.json")["artifacts"].items():
            mapping[str(directory / name)] = item["sha256"]
    background_file = POST / "mts-integrated-defect-20261112/integrated_math.py"
    spec = importlib.util.spec_from_file_location("retained_force_background", background_file)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    mapping[str(background_file)] = digest(background_file)
    prepared = {}
    for case in CONFIG["cases"]:
        reference_path = METRIC / (case + "-reference-metric.npz")
        native_path = PREVIOUS / "native-reference.json"
        clock_path = POST / "mts-integrated-defect-20261112" / (case + "-native-clock.npz")
        background_path = POST / "condensate-origin-20261003/native-two-field-transfer-20261007/runs/backgrounds" / (case + ".npz")
        for path in (reference_path, native_path, clock_path, background_path):
            mapping[str(path)] = digest(path)
        with np.load(METRIC / (case + "-metric-64.npz")) as archive:
            queries = archive["queries"]
        unique = np.unique(queries)
        background = module.Background(load(clock_path), load(background_path))
        boundaries = background.boundaries(float(unique[0]), float(unique[-1]))
        fixed = {0, len(unique) - 1}
        for index in np.searchsorted(unique, boundaries):
            fixed.update(range(max(0, index - 2), min(len(unique), index + 2)))
        selections = {str(stride): np.union1d(np.arange(0, len(unique), stride), sorted(fixed)).astype(int) for stride in (4, 2, 1)}
        reference = terms(load(reference_path)["packet"])
        norms = {"native_transfer": read(native_path)[case]["norms"][4],
                 "force": maximum(np.sum(reference["envelope"], axis=-1) + abs(reference["actual"])),
                 "a_velocity": maximum(reference["scale"] * reference["velocity"])}
        np.savez_compressed(ROOT / (case + "-frozen-support.npz"), time=unique, boundaries=boundaries, **{"stride" + key: value for key, value in selections.items()})
        mapping[str(ROOT / (case + "-frozen-support.npz"))] = digest(ROOT / (case + "-frozen-support.npz"))
        prepared[case] = {"begin": float(unique[0]), "end": float(unique[-1]), "count": len(unique),
                          "corner_count": len(boundaries), "selection_counts": {key: len(value) for key, value in selections.items()},
                          "largest_gap_mpc": float(np.max(np.diff(unique))), "norms": norms}
    for name in ("run_balance.py", "protocol.json", "DERIVATION.md"):
        mapping[str(ROOT / name)] = digest(ROOT / name)
    write(ROOT / "frozen-reference.json", prepared)
    mapping[str(ROOT / "frozen-reference.json")] = digest(ROOT / "frozen-reference.json")
    write(ROOT / "inputs.json", mapping)
    check_inputs()
    print(json.dumps(prepared), flush=True)

def integrated(clock, values, corners, selected, method):
    nodes, samples = clock[selected], values[selected]
    region = np.searchsorted(corners, nodes, side="right")
    breaks = np.r_[0, np.flatnonzero(np.diff(region)) + 1, len(nodes)]
    cells = np.diff(nodes)[:, None] * (samples[1:] + samples[:-1]) / 2
    if method == "pchip":
        for begin, end in zip(breaks[:-1], breaks[1:]):
            if end - begin >= 2:
                primitive = PchipInterpolator(nodes[begin:end], samples[begin:end], axis=0).antiderivative()
                cells[begin:end-1] = np.diff(primitive(nodes[begin:end]), axis=0)
    cumulative = np.vstack((np.zeros(samples.shape[1]), np.cumsum(cells, axis=0)))
    final = np.array([math.fsum(cells[:, component]) for component in range(cells.shape[1])])
    cumulative[-1] = final
    bridge = region[1:] != region[:-1]
    return cumulative, {"bridges": int(np.sum(bridge)), "bridge_duration_mpc": float(np.sum(np.diff(nodes)[bridge])),
                        "largest_bridge_mpc": float(np.max(np.diff(nodes)[bridge])) if np.any(bridge) else 0,
                        "absolute_component_work": np.sum(abs(cells), axis=0).tolist()}

def calculate(case, replay=False):
    check_inputs()
    support = load(ROOT / (case + "-frozen-support.npz"))
    clock, corners = support["time"], support["boundaries"]
    frozen = read(ROOT / "frozen-reference.json")[case]
    norm = frozen["norms"]["native_transfer"]
    results, saved, runs = {}, {}, {}
    epsilon = np.finfo(float).eps
    for steps in CONFIG["steps"]:
        with np.load(METRIC / (case + "-metric-" + str(steps) + ".npz")) as archive:
            queries, packets = archive["queries"], archive["metric"]
        order = np.argsort(queries.ravel())
        require(np.array_equal(queries.ravel()[order], clock), "unchanged sorted saved support")
        packet = packets.reshape(-1, 2, 128)[order]
        old, new = terms(packet[:, 0]), terms(packet[:, 1])
        delta, delta_transfer = paired_terms(packet, old, new)
        actual_old = -WAVE * (old["velocity"] + old["sigma"]) / old["hubble"]
        actual_new = -WAVE * (new["velocity"] + new["sigma"]) / new["hubble"]
        all_values = np.concatenate((old["values"], new["values"], delta), axis=-1)
        branch_results = {}
        for stride in (4, 2, 1):
            selected = support["stride" + str(stride)]
            work, bridges = integrated(clock, all_values, corners, selected, "pchip")
            old_initial = old["scale"][0] * old["velocity"][0]
            new_initial = new["scale"][0] * new["velocity"][0]
            old_fluid = (old_initial + np.sum(work[:, :3], axis=-1)) / old["scale"][selected]
            new_fluid = (new_initial + np.sum(work[:, 3:6], axis=-1)) / new["scale"][selected]
            delta_initial = new_initial - old_initial
            delta_fluid = (delta_initial + np.sum(work[:, 6:9], axis=-1) - old_fluid * (new["scale"][selected] - old["scale"][selected])) / new["scale"][selected]
            old_prediction = -WAVE * (old_fluid + old["sigma"][selected]) / old["hubble"][selected]
            new_prediction = -WAVE * (new_fluid + new["sigma"][selected]) / new["hubble"][selected]
            prediction_change = -WAVE * (delta_fluid + new["sigma"][selected] - old["sigma"][selected]) / new["hubble"][selected] - old_prediction * (new["hubble"][selected] - old["hubble"][selected]) / new["hubble"][selected]
            branch_results[stride] = {"prediction": np.column_stack((old_prediction, new_prediction, prediction_change)),
                                     "work": work, "bridges": bridges}
        trapezoid, _ = integrated(clock, all_values, corners, support["stride1"], "trapezoid")
        scale_factors = WAVE / np.column_stack((old["scale"] * old["hubble"], new["scale"] * new["hubble"], new["scale"] * new["hubble"]))
        trap_error = abs(np.sum((trapezoid - branch_results[1]["work"]).reshape(-1, 3, 3), axis=-1)) * scale_factors
        sampling = trap_error.copy()
        for coarse, fine in ((4, 2), (2, 1)):
            selected = support["stride" + str(coarse)]
            positions = np.searchsorted(support["stride" + str(fine)], selected)
            difference = abs(branch_results[coarse]["prediction"] - branch_results[fine]["prediction"][positions])
            sampling = np.maximum(sampling, np.max(difference, axis=0))
        source_round = 64 * epsilon * np.column_stack((np.sum(old["envelope"], axis=-1), np.sum(new["envelope"], axis=-1), np.sum(old["envelope"] + new["envelope"], axis=-1)))
        rounding = (clock - clock[0])[:, None] * np.max(source_round, axis=0) * scale_factors
        rounding += 64 * epsilon * np.column_stack((abs(actual_old), abs(actual_new), abs(actual_old) + abs(actual_new)))
        actual = np.column_stack((actual_old, actual_new, delta_transfer))
        checks = {}
        for branch, values in (("old", old), ("coherent", new)):
            checks[branch + "_euler_identity"] = check(maximum(values["actual"] - np.sum(values["values"], axis=-1)), frozen["norms"]["force"], CONFIG["algebra_tolerance"])
        checks["paired_source_algebra"] = check(maximum(delta - (new["values"] - old["values"])), frozen["norms"]["force"], CONFIG["algebra_tolerance"])
        checks["paired_transfer_algebra"] = check(maximum(delta_transfer - (actual_new - actual_old)), norm, CONFIG["algebra_tolerance"])
        runs[steps] = {"actual": actual, "prediction": branch_results[1]["prediction"], "sampling": sampling, "rounding": rounding}
        saved.update({str(steps) + "_" + key: value for key, value in runs[steps].items()})
        saved[str(steps) + "_work"] = branch_results[1]["work"]
        branch_results[1]["bridges"]["source_terms"] = ["pressure", "photon_drag", "background_contact"]
        results[str(steps)] = {"identity_checks": checks, "integration": branch_results[1]["bridges"],
                              "final_work_old_coherent_change": branch_results[1]["work"][-1].reshape(3, 3).tolist(),
                              "final_a_sigma_old_coherent": [float(values["scale"][-1] * values["sigma"][-1] - values["scale"][0] * values["sigma"][0]) for values in (old, new)],
                              "final_initial_a_v": [float(values["scale"][0] * values["velocity"][0]) for values in (old, new)]}
        guard()
    fine, coarse = runs[64], runs[32]
    refinement = abs(fine["prediction"] - coarse["prediction"]) + abs(fine["actual"] - coarse["actual"])
    allowance = fine["sampling"] + fine["rounding"] + refinement
    residual = abs(fine["prediction"] - fine["actual"])
    acceptance = {}
    for column, name in enumerate(("old_full", "coherent_full", "correction_absolute")):
        acceptance[name] = check(maximum(residual[:, column] + allowance[:, column]), norm)
    acceptance["correction_relative"] = check(maximum(residual[:, 2] + allowance[:, 2]), maximum(fine["actual"][:, 2]))
    identity_passed = all(value["passed"] for report in results.values() for value in report["identity_checks"].values())
    omitted = {}
    work = saved["64_work"]
    for component, name in enumerate(("pressure", "photon_drag", "background_contact")):
        change = WAVE * work[:, 3 + component] / (new["scale"] * new["hubble"])
        omitted[name] = check(maximum(abs(fine["prediction"][:, 1] + change - fine["actual"][:, 1]) + allowance[:, 1]), norm)
    report = {"case": case, "reference": frozen, "steps": results, "acceptance": acceptance,
              "all_identities_pass": identity_passed, "full_balance_passes": acceptance["old_full"]["passed"] and acceptance["coherent_full"]["passed"],
              "response_resolved": acceptance["correction_relative"]["passed"],
              "max_residual": np.max(residual, axis=0).tolist(), "max_sampling": np.max(fine["sampling"], axis=0).tolist(),
              "max_rounding": np.max(fine["rounding"], axis=0).tolist(), "max_step_refinement": np.max(refinement, axis=0).tolist(),
              "final_actual": fine["actual"][-1].tolist(), "final_prediction": fine["prediction"][-1].tolist(),
              "coherent_omission_balance_checks": omitted, "not_uniform_continuum_bound": True}
    saved.update(time=clock, residual=residual, allowance=allowance)
    if replay:
        require(read(ROOT / (case + "-result.json")) == report, "deterministic report replay")
        previous = load(ROOT / (case + "-balance.npz"))
        require(previous.keys() == saved.keys() and all(np.array_equal(value, previous[name]) for name, value in saved.items()), "exact array replay")
        write(ROOT / (case + "-replay.json"), {"report_exact": True, "arrays_exact": True})
    else:
        write(ROOT / (case + "-result.json"), report)
        np.savez_compressed(ROOT / (case + "-balance.npz"), **saved)
    check_inputs()
    print(json.dumps({key: report[key] for key in ("case", "acceptance", "max_residual", "max_sampling", "max_rounding", "max_step_refinement", "final_actual", "final_prediction")}), flush=True)
    require(identity_passed, "all algebra identities pass; numerical failures retained, not retried")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "cold", "heavy"))
    parser.add_argument("--replay", action="store_true")
    args = parser.parse_args()
    with worker(args.mode + ("-replay" if args.replay else "")):
        if args.mode == "prepare":
            prepare()
        else:
            calculate(args.mode, args.replay)

if __name__ == "__main__":
    main()

