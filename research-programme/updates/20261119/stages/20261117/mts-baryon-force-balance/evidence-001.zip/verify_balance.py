from run_balance import *
import sympy as symbolic

def validate():
    checks = {}
    scale, rate, hubble, velocity, shear, shear_prime, wave, pressure, gamma, flux = symbolic.symbols(
        "a r H vb sigma sigma_prime k pi_b Gamma_b q_gamma", real=True)
    slip = velocity - symbolic.Rational(3, 4) * flux
    velocity_prime = -hubble * velocity + wave * pressure - gamma * slip
    potential = (shear_prime + rate * shear) / wave
    derivative = scale * rate * (velocity + shear) + scale * (velocity_prime + shear_prime)
    predicted = scale * (wave * potential + wave * pressure - gamma * slip + (rate - hubble) * velocity)
    checks["integrating_factor_identity"] = symbolic.simplify(derivative - predicted) == 0
    checks["metric_endpoint_identity"] = symbolic.simplify(scale * wave * potential - scale * (shear_prime + rate * shear)) == 0
    checks["fluid_identity"] = symbolic.simplify(derivative - scale * (shear_prime + rate * shear) -
        scale * (wave * pressure - gamma * slip + (rate - hubble) * velocity)) == 0
    baryon, photon, opacity = symbolic.symbols("B_b B_gamma opacity", positive=True)
    checks["thomson_momentum_exchange"] = symbolic.simplify(
        -baryon * (4 * photon * opacity / (3 * baryon)) * slip + photon * opacity * (4 * velocity / 3 - flux)) == 0
    test_time = np.array([0., .001, .17, .3, .49, .51, .73, 1.])
    selected = np.arange(len(test_time))
    test_values = np.column_stack((np.ones(len(test_time)), 2 * test_time - 3))
    expected = np.column_stack((test_time, test_time ** 2 - 3 * test_time))
    for method in ("pchip", "trapezoid"):
        for label, corners in (("smooth", np.array([])), ("corner", np.array([.5]))):
            output, bridge = integrated(test_time, test_values, corners, selected, method)
            checks[method + "_" + label + "_linear"] = check(maximum(output - expected), 2., CONFIG["algebra_tolerance"])["passed"]
            checks[method + "_" + label + "_bridges"] = bridge["bridges"] == (0 if label == "smooth" else 1)
    zero, _ = integrated(test_time, np.zeros((len(test_time), 3)), np.array([.5]), selected, "pchip")
    checks["zero_force_constant_initial_momentum"] = bool(np.all(zero == 0))
    checks["compile_without_bytecode"] = True
    for name in ("run_balance.py", "verify_balance.py"):
        compile((ROOT / name).read_text(), str(ROOT / name), "exec")
    attribution = {}
    for case in CONFIG["cases"]:
        report = read(ROOT / (case + "-result.json"))
        arrays = load(ROOT / (case + "-balance.npz"))
        support = load(ROOT / (case + "-frozen-support.npz"))
        reference = read(ROOT / "frozen-reference.json")[case]
        norm = reference["norms"]["native_transfer"]
        checks[case + "_all_algebra_identities"] = report["all_identities_pass"]
        checks[case + "_full_balance"] = report["full_balance_passes"]
        checks[case + "_tiny_response_failure_preserved"] = not report["response_resolved"]
        checks[case + "_drag_omission_detected"] = not report["coherent_omission_balance_checks"]["photon_drag"]["passed"]
        checks[case + "_both_replays_exact"] = all(read(ROOT / (case + "-replay.json")).values())
        checks[case + "_nested_decimation"] = all(np.isin(support["stride4"], support["stride2"])) and all(np.isin(support["stride2"], support["stride1"]))
        checks[case + "_finite_outputs"] = all(np.isfinite(value).all() for value in arrays.values())
        checks[case + "_correction_magnitude_preserved"] = check(
            report["acceptance"]["correction_relative"]["scale"] - maximum(arrays["64_actual"][:, 2]),
            norm, CONFIG["algebra_tolerance"])["passed"]
        with np.load(METRIC / (case + "-metric-64.npz")) as archive:
            queries = archive["queries"]
            order = np.argsort(queries.ravel())
            packet = archive["metric"].reshape(-1, 2, 128)[order]
        old, new = terms(packet[:, 0]), terms(packet[:, 1])
        delta_values, _ = paired_terms(packet, old, new)
        canonical = load(PREVIOUS / (case + "-native-transfer-64.npz"))["change"][..., 4].ravel()[order]
        readout_error = maximum(canonical - arrays["64_actual"][:, 2])
        checks[case + "_canonical_transfer_within_rounding"] = readout_error <= report["max_rounding"][2]
        initial_old = old["scale"][0] * old["velocity"][0]
        initial_new = new["scale"][0] * new["velocity"][0]
        old_final_momentum = initial_old + math.fsum(arrays["64_work"][-1, :3])
        old_final_velocity = old_final_momentum / old["scale"][-1]
        multiplier = -WAVE / (new["scale"][-1] * new["hubble"][-1])
        contributions = {
            "pressure_integral": multiplier * arrays["64_work"][-1, 6],
            "photon_drag_integral": multiplier * arrays["64_work"][-1, 7],
            "background_contact_integral": multiplier * arrays["64_work"][-1, 8],
            "matched_initial_momentum": multiplier * (initial_new - initial_old),
            "scale_normalization": -multiplier * old_final_velocity * (new["scale"][-1] - old["scale"][-1]),
            "metric_endpoint": -WAVE * (new["sigma"][-1] - old["sigma"][-1]) / new["hubble"][-1],
            "H_normalization": -arrays["64_prediction"][-1, 0] * (new["hubble"][-1] - old["hubble"][-1]) / new["hubble"][-1]
        }
        predicted_sum = math.fsum(contributions.values())
        checks[case + "_response_attribution_identity"] = check(
            abs(predicted_sum - arrays["64_prediction"][-1, 2]), norm, CONFIG["algebra_tolerance"])["passed"]
        omission_initial = WAVE * initial_new / (new["scale"] * new["hubble"])
        checks[case + "_initial_matching_omission_detected"] = maximum(omission_initial) > CONFIG["numerical_tolerance"] * norm
        omission_metric = WAVE * (new["scale"] * new["sigma"] - new["scale"][0] * new["sigma"][0]) / (new["scale"] * new["hubble"])
        checks[case + "_metric_endpoint_omission_detected"] = maximum(omission_metric) > CONFIG["numerical_tolerance"] * norm
        all_values = np.concatenate((old["values"], new["values"], delta_values), axis=-1)
        trap, _ = integrated(support["time"], all_values, support["boundaries"], support["stride1"], "trapezoid")
        trap_old = (initial_old + np.sum(trap[:, :3], axis=-1)) / old["scale"]
        trap_delta = ((initial_new - initial_old) + np.sum(trap[:, 6:9], axis=-1) -
                      trap_old * (new["scale"] - old["scale"])) / new["scale"]
        trap_old_transfer = -WAVE * (trap_old + old["sigma"]) / old["hubble"]
        trap_delta_transfer = -WAVE * (trap_delta + (new["sigma"] - old["sigma"])) / new["hubble"] - trap_old_transfer * (new["hubble"] - old["hubble"]) / new["hubble"]
        trap_delta_error = maximum(trap_delta_transfer - arrays["64_prediction"][:, 2])
        checks[case + "_exact_trapezoid_map_covered"] = trap_delta_error <= report["max_sampling"][2] + report["max_rounding"][2]
        covered_canonical_residual = maximum(abs(arrays["64_prediction"][:, 2] - canonical) + arrays["allowance"][:, 2])
        checks[case + "_canonical_scoring_same_classification"] = (
            check(covered_canonical_residual, maximum(canonical))["passed"] == report["response_resolved"] and
            check(covered_canonical_residual, norm)["passed"] == report["acceptance"]["correction_absolute"]["passed"])
        attribution[case] = {"final_transfer_contributions": {key: float(value) for key, value in contributions.items()},
                             "sum": predicted_sum, "canonical_final_response": float(canonical[-1]),
                             "final_difference_from_canonical": predicted_sum - float(canonical[-1]),
                             "canonical_rounding_difference_max": readout_error,
                             "exact_trapezoid_correction_difference_max": trap_delta_error,
                             "canonical_residual_plus_allowance_max": covered_canonical_residual,
                             "corner_bridge_fraction": report["steps"]["64"]["integration"]["bridge_duration_mpc"] / (reference["end"] - reference["begin"])}
    check_inputs()
    checks["all_frozen_inputs_unchanged"] = True
    prior_workers = list(ROOT.glob("*-start.json"))
    checks["all_prior_workers_exited"] = all(exited(read(path)) for path in prior_workers if path.name != "verify-start.json")
    checks["no_bytecode"] = not (ROOT / "__pycache__").exists()
    outcome = {"checks": checks, "passed": all(checks.values()), "count": len(checks),
               "failed": [key for key, passed in checks.items() if not passed],
               "attribution": attribution, "full_output_passes_both": True, "all_scientific_tests_pass": False,
               "limitations": ["Both tiny correction-relative acceptance gates remain false.",
                               "Corner bridging and step estimates are not rigorous continuous error bounds.",
                               "These are conditional velocity histories, not a full observed sky."]}
    write(ROOT / "verification.json", outcome)
    print(json.dumps(outcome), flush=True)
    require(outcome["passed"], "verification checks")

if __name__ == "__main__":
    with worker("verify"):
        validate()

