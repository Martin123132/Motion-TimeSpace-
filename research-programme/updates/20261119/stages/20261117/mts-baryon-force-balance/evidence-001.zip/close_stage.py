from run_balance import *

if __name__ == "__main__":
    check_inputs()
    verification = read(ROOT / "verification.json")
    require(verification["passed"], "verified stage")
    cleanup = {path.name: {**read(path), "exited": exited(read(path))} for path in ROOT.glob("*-start.json")}
    require(all(item["exited"] for item in cleanup.values()), "every owned numerical worker exited")
    require(not (ROOT / "__pycache__").exists(), "no bytecode")
    write(ROOT / "cleanup.json", {"workers": cleanup, "all_exited": True,
          "other_processes_changed": False, "previews_servers_browsers": [],
          "note": "Foreground diagnostic shell/Python calls returned exit0; no background task was launched."})
    artifacts = {str(path.relative_to(ROOT)): {"sha256": digest(path), "bytes": path.stat().st_size}
                 for path in sorted(ROOT.rglob("*")) if path.is_file() and path.name != "closeout.json"}
    closeout = {"stage": "Accumulated baryon force balance on saved paired histories",
                "utc": datetime.now(timezone.utc).isoformat(), "completed": True,
                "verification_passed": True, "verification_count": verification["count"],
                "full_balance_passes_both_cases": True, "all_scientific_tests_pass": False,
                "correction_relative_passes": {case: read(ROOT / (case + "-result.json"))["response_resolved"] for case in CONFIG["cases"]},
                "frozen_input_count": len(read(ROOT / "inputs.json")), "task_workers_exited": len(cleanup),
                "new_evolution": False, "github": False, "artifacts": artifacts}
    write(ROOT / "closeout.json", closeout)
    print(json.dumps({"seal": digest(ROOT / "closeout.json"), "artifacts": len(artifacts),
                      "frozen_inputs": closeout["frozen_input_count"], "workers_exited": len(cleanup)}))

