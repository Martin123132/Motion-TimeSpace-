from support import *
import mpmath as mp

with worker('jet-identities'):
    mp.mp.dps=80
    checks={}
    def check(name,actual,expected):
        scale=max(abs(expected),mp.mpf('1e-60'))
        relative=abs(actual-expected)/scale
        checks[name]=dict(relative=float(relative),passed=bool(relative<=mp.mpf(str(ALGEBRA))))
    rate,rate_prime=mp.mpf('.017'),mp.mpf('-.0003')
    scale=lambda offset:mp.exp(rate*offset+rate_prime*offset**2/2)
    density=lambda offset:mp.mpf('.13')+mp.mpf('-.27')*offset+mp.mpf('.11')*offset**2/2
    for momentum in (mp.mpf('.02'),mp.mpf('.7'),mp.mpf('8')):
        speed=1/mp.sqrt(1+momentum**2)
        log_weight=-rate*(1+speed**2)
        log_weight_prime=-rate_prime*(1+speed**2)+2*rate**2*speed**2*(1-speed**2)
        value=lambda offset:density(offset)*mp.sqrt(1+(momentum*scale(offset))**2)/scale(offset)**2
        expected=(mp.mpf('.11')+2*log_weight*mp.mpf('-.27')+(log_weight**2+log_weight_prime)*mp.mpf('.13'))/speed
        check('massive_moment_'+str(momentum),mp.diff(value,0,2),expected)
    const2=mp.mpf(5)/7/mp.pi**2
    for am in (mp.mpf('.003'),mp.mpf('.03'),mp.mpf('.2')):
        def rho(value):
            extra=value**4*(mp.mpf('.01099926669')*mp.log(value)-mp.mpf('.003492416767')-mp.mpf('.005866275571')*value) if am>=mp.mpf('.01') else 0
            return 1+const2*value**2+extra
        rho_n=2*const2*am**2
        rho_nn=4*const2*am**2
        if am>=mp.mpf('.01'):
            rho_n+=am**4*(mp.mpf('.01099926669')*(4*mp.log(am)+1)-4*mp.mpf('.003492416767')-5*mp.mpf('.005866275571')*am)
            rho_nn+=am**4*(mp.mpf('.01099926669')*(16*mp.log(am)+8)-16*mp.mpf('.003492416767')-25*mp.mpf('.005866275571')*am)
        check('neutrino_rho_NN_'+str(am),mp.diff(lambda offset:rho(am*mp.exp(offset)),0,2),rho_nn)
        expected=rate**2*(rho_nn-4*rho_n+4*rho(am))+rate_prime*(rho_n-2*rho(am))
        check('neutrino_background_'+str(am),mp.diff(lambda offset:rho(am*scale(offset))/scale(offset)**2,0,2),expected)
    field=lambda offset:mp.mpf('.2')+mp.mpf('.3')*offset+mp.mpf('-.4')*offset**2/2
    velocity=lambda offset:mp.mpf('-.5')+mp.mpf('.7')*offset+mp.mpf('.2')*offset**2/2
    perturbation=lambda offset:mp.mpf('.11')+mp.mpf('-.2')*offset+mp.mpf('.4')*offset**2/2
    speed=lambda offset:mp.mpf('-.2')+mp.mpf('.4')*offset+mp.mpf('-.6')*offset**2/2
    mass2,mass_prime,mass_second=mp.mpf(3),6*rate,3*(2*rate_prime+4*rate**2)
    expected=mp.mpf('.2')*mp.mpf('-.2')+2*mp.mpf('.7')*mp.mpf('.4')+mp.mpf('-.5')*mp.mpf('-.6')+mass_second*mp.mpf('.2')*mp.mpf('.11')+2*mass_prime*(mp.mpf('.3')*mp.mpf('.11')+mp.mpf('.2')*mp.mpf('-.2'))+mass2*(mp.mpf('-.4')*mp.mpf('.11')+2*mp.mpf('.3')*mp.mpf('-.2')+mp.mpf('.2')*mp.mpf('.4'))
    check('scalar_Dsecond',mp.diff(lambda offset:velocity(offset)*speed(offset)+mass2*scale(offset)**2*field(offset)*perturbation(offset),0,2),expected)
    hubble=lambda offset:mp.mpf('.02')+mp.mpf('-.001')*offset+mp.mpf('.0004')*offset**2/2
    numerator=lambda offset:mp.mpf('.003')+mp.mpf('.0002')*offset+mp.mpf('-.00001')*offset**2/2
    rest=numerator(0)/hubble(0)
    first=mp.diff(numerator,0)/hubble(0)-mp.diff(hubble,0)/hubble(0)*rest
    second=mp.diff(numerator,0,2)/hubble(0)-2*mp.diff(hubble,0)/hubble(0)*first-mp.diff(hubble,0,2)/hubble(0)*rest
    check('constraint_quotient_second',mp.diff(lambda offset:numerator(offset)/hubble(offset),0,2),second)
    require(all(row['passed'] for row in checks.values()),'independent high precision identities')
    write('jet-identities.json',dict(passed=True,checks=checks,precision_digits=80,tolerance=ALGEBRA,synthetic_identity_controls_not_observations=True))
    print(json.dumps(dict(passed=True,checks=len(checks),max_relative=max(row['relative'] for row in checks.values()))),flush=True)
