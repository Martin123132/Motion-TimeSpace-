from support import *
import argparse
import numpy as np
from scipy.integrate import solve_ivp

primitive=sealed_module('retained_primitive',PREVIOUS,'primitive_math.py')
parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case

with worker(case+'-quadratic'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    freeze=read(ROOT/(case+'-curvature-freeze.json'))
    require(freeze['passed'] and not freeze['quadratic_coefficient_fitted'],'equation-derived coefficient frozen')
    require(exited(read(ROOT/(case+'-capture-start.json')))['exited'],'capture exited')
    check_hashes(freeze['hashes'])
    write(case+'-evolution-code.json',{str(path):digest(path) for path in (ROOT/'run_quadratic.py',ROOT/'support.py',ROOT/'PROTOCOL.md')})
    prepared=load(PREVIOUS/(case+'-initial-state.npz'))
    curvature=load(ROOT/(case+'-frozen-curvature.npz'))
    require(np.array_equal(curvature['times'],prepared['times']) and np.array_equal(curvature['weights'],prepared['weights']),'same preparation and weights')
    background=primitive.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
    elapsed,norm=prepared['elapsed'],prepared['norm']
    initial=prepared['state']/norm
    def rhs(offset,flat):
        guard()
        state=flat.reshape(initial.shape)*norm
        result=primitive.right_hand_side(case,offset,state,prepared,background,True)
        forcing=.5*offset**2*curvature['rest_second']
        if case=='heavy':
            velocity=background.evaluate(prepared['times']+offset)['jets'][1][1]
            result[:,1]-=prepared['wave']*velocity*forcing
        else:
            result[:,0]-=prepared['wave']*forcing
        return (result/norm).ravel()
    runs={}
    for steps in (32,64):
        solution=solve_ivp(rhs,(0,float(elapsed[-1])),initial.ravel(),method='DOP853',t_eval=elapsed,rtol=1e-10,atol=1e-12,max_step=float(elapsed[-1])/steps)
        require(solution.success and solution.y.shape==(initial.size,len(elapsed)),'quadratic evolution completed')
        states=solution.y.T.reshape(len(elapsed),*initial.shape)*norm[None,:,:]
        sources=np.array([primitive.readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed,states)])
        prediction=prepared['initial_weighted_source']+np.array([primitive.weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
        direct=np.array([primitive.weighted(prepared['weights'],row) for row in sources])
        arithmetic=abs(prediction-(prepared['initial_weighted_source']+direct-direct[0]))
        require(np.isfinite(states).all() and np.isfinite(prediction).all(),'finite quadratic result')
        filename=case+'-quadratic-'+str(steps)+'.npz'
        np.savez_compressed(ROOT/filename,state=states,node_source=sources,prediction=prediction,arithmetic_difference=arithmetic,elapsed=elapsed,weights=prepared['weights'],rest_degree=2,steps=steps)
        runs[filename]=digest(ROOT/filename)
        print(json.dumps(dict(case=case,steps=steps,evaluations=solution.nfev)),flush=True)
    write(case+'-quadratic-freeze.json',dict(passed=True,hashes={str(ROOT/name):value for name,value in runs.items()},target_readout_loaded=False,coefficients_fitted=False,rest_degree=2,solver_rtol=1e-10,solver_atol=1e-12))
    check_hashes(read(ROOT/(case+'-evolution-code.json')))
    check_hashes(read(ROOT/'frozen-inputs.json'))
