from support import *

with worker('seal-stage'):
    require(read(ROOT/'validation.json')['passed'],'validation completed')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'native-build-frozen.json'))
    outcomes=[]
    for directory in (ROOT,ROOT/'attempt-01'):
        for path in directory.glob('*-start.json'):
            if directory==ROOT and path.name=='seal-stage-start.json':
                continue
            identity=read(path)
            outcome=exited(identity)
            require(outcome['exited'],'worker finished '+str(path))
            end=read(path.with_name(path.name.replace('-start.json','-end.json')))
            require(end['state']=='completed' or (directory.name=='attempt-01' and path.name=='heavy-capture-start.json'),'only retained diagnosed failure')
            outcomes.append(dict(receipt=str(path),identity=identity,outcome=outcome,state=end['state']))
        build=read(directory/'native-build-result.json')
        require(build['state']=='completed' and build['temporary_mapping_removed'],'build mapping removed')
        for row in build['children']:
            require(exited(row['identity'])['exited'],'build child exited')
    write('preseal-validation.json',dict(passed=True,workers=outcomes,final_verification=read(ROOT/'validation.json')['passed'],preserved_first_attempt=True,goal_left_paused=True))

artifacts={}
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json'):
        artifacts[path.relative_to(ROOT).as_posix()]=dict(sha256=digest(path),bytes=path.stat().st_size)
write('closeout.json',dict(stage='derived-rest-curvature',date='2026-11-12',completed=True,previous=str(PREVIOUS),previous_closeout_sha256=digest(PREVIOUS/'closeout.json'),artifacts=artifacts,frozen_inputs=read(ROOT/'frozen-inputs.json'),validation_passed=True,result=read(ROOT/'result.json'),rest_curvature_derived=True,uniform_pressure_sufficiency_gate_closed=False,paired_quadratic_numerical_pass=True,next='Evolve eta_k alongside heavy primitives / baseline CDM; freeze and test other-sector source continuation',goal_left_paused=True,github_action=False,cleanup_receipt='CLEANUP-VERIFIED.json'))
print(json.dumps(dict(completed=True,artifacts=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'))),flush=True)
