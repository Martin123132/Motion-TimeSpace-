from support import *
import numpy as np

primitive=sealed_module('retained_primitive',PREVIOUS,'primitive_math.py')
comparison,weighted=primitive.comparison,primitive.weighted

with worker('score-rest'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    reports={}
    for case in ('cold','heavy'):
        freeze=read(ROOT/(case+'-quadratic-freeze.json'))
        require(freeze['passed'] and not freeze['target_readout_loaded'] and not freeze['coefficients_fitted'],'prediction frozen without target')
        require(exited(read(ROOT/(case+'-quadratic-start.json')))['exited'],'evolution exited before scoring')
        check_hashes(freeze['hashes'])
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        readout=load(ROOT/(case+'-rest-readout.npz'))
        packet,terms=readout['packet'],readout['terms']
        curvature=load(ROOT/(case+'-frozen-curvature.npz'))['rest_second']
        fine=load(ROOT/(case+'-quadratic-64.npz'))
        coarse=load(ROOT/(case+'-quadratic-32.npz'))
        linear=load(PREVIOUS/(case+'-linear-64.npz'))
        linear_coarse=load(PREVIOUS/(case+'-linear-32.npz'))
        target=load(MIDPOINT/(case+'-tested-readout.npz'))
        expected=target['corrected_readout']
        scale=np.max(abs(expected),axis=0)
        require(np.array_equal(fine['elapsed'],target['current_time']-target['current_time'][0]),'unchanged reporting grid')
        weights=prepared['weights']
        numerical=np.array([weighted(abs(weights),abs(row)) for row in fine['node_source']-coarse['node_source']])
        linear_numerical=np.array([weighted(abs(weights),abs(row)) for row in linear['node_source']-linear_coarse['node_source']])
        numerical_budget=target['updated_working_budget']+abs(prepared['initial_recapture_difference'])[None,:]+numerical+fine['arithmetic_difference']
        residual=fine['prediction']-expected
        correction=fine['prediction']-linear['prediction']
        gain=load(PREVIOUS/(case+'-response-gain.npz'))
        response=read(PREVIOUS/(case+'-response-result.json'))
        signed_prediction=weighted(weights,gain['node_signed_gain']*curvature[:,None])
        absolute_quadratic_envelope=weighted(abs(weights),gain['node_absolute_gain']*abs(curvature[:,None]))
        duality_error=abs(correction[-1]-signed_prediction)
        duality_allowance=GATE*absolute_quadratic_envelope+numerical[-1]+linear_numerical[-1]+fine['arithmetic_difference'][-1]+linear['arithmetic_difference'][-1]+64*np.finfo(float).eps*scale
        uniform_ceiling=response['conditional_uniform_rest_curvature_ceiling']
        maximum=float(np.max(abs(curvature)))
        ceiling_tests=[dict(available=ceiling is not None,ceiling=ceiling,sampled_max=maximum,sampled_max_within_ceiling=bool(maximum<=ceiling) if ceiling is not None else None,ratio=maximum/ceiling if ceiling is not None else None) for ceiling in uniform_ceiling]
        rest_component=terms[:,:,0].copy()
        rest_first_component=terms[:,:,1].copy()
        rest_second_component=terms[:,:,2].copy()
        selected=6 if case=='heavy' else 0
        rest_component[:,selected]=rest_first_component[:,selected]=rest_second_component[:,selected]=0
        hubble,hubble_prime,wave=packet[:,4],packet[:,5],packet[:,14]
        rest,rest_prime=packet[:,156],packet[:,157]
        numerator_second=rest_second_component.sum(axis=1)/(2*wave)+terms[:,:,4].sum(axis=1)/2
        density_curvature=rest_second_component/(2*wave[:,None]*hubble[:,None])
        current_curvature=terms[:,:,4]/(2*hubble[:,None])
        background_curvature=-rest[:,None]*terms[:,:,7]/(6*hubble[:,None]**2)
        quotient_terms=np.column_stack([-2*hubble_prime/hubble*rest_prime,rest*(hubble_prime/hubble)**2])
        reconstructed=density_curvature.sum(axis=1)+current_curvature.sum(axis=1)+background_curvature.sum(axis=1)+quotient_terms.sum(axis=1)
        algebra={
            'rest_curvature_decomposition':comparison(reconstructed,packet[:,158],ALGEBRA),
            'initial_state':comparison(fine['state'][0],prepared['state'],ALGEBRA),
            'normalized_state_refinement':comparison((fine['state']-coarse['state'])/prepared['norm'][None,:,:],0,scale=1.),
        }
        names=('density','current','pressure')
        raw={name:comparison(fine['prediction'][:,column],expected[:,column]) for column,name in enumerate(names)}
        numerical_checks={name:comparison(abs(residual[:,column])+numerical_budget[:,column],0,scale=scale[column]) for column,name in enumerate(names)}
        duality={name:dict(error=float(duality_error[column]),allowance=float(duality_allowance[column]),passed=bool(duality_error[column]<=duality_allowance[column])) for column,name in enumerate(names)}
        maximum_index=int(np.argmax(abs(curvature)))
        maximum_components=dict(density=density_curvature[maximum_index].tolist(),current=current_curvature[maximum_index].tolist(),background=background_curvature[maximum_index].tolist(),quotient=quotient_terms[maximum_index].tolist())
        np.savez_compressed(ROOT/(case+'-comparison.npz'),residual=residual,numerical_budget=numerical_budget,numerical_refinement=numerical,linear_refinement=linear_numerical,correction=correction,signed_adjoint_prediction=signed_prediction,absolute_quadratic_envelope=absolute_quadratic_envelope,duality_error=duality_error,duality_allowance=duality_allowance,reference_scale=scale,density_curvature=density_curvature,current_curvature=current_curvature,background_curvature=background_curvature,quotient_terms=quotient_terms,numerator_second=numerator_second)
        report=dict(completed=True,raw_passed=all(row['passed'] for row in raw.values()),numerical_passed=all(row['passed'] for row in numerical_checks.values()),algebra_passed=all(row['passed'] for row in algebra.values()),duality_passed=all(row['passed'] for row in duality.values()),raw=raw,residual_plus_numerical_allowance=numerical_checks,algebra=algebra,duality=duality,final_prediction=fine['prediction'][-1].tolist(),final_residual=residual[-1].tolist(),final_quadratic_minus_linear=correction[-1].tolist(),signed_adjoint_prediction=signed_prediction.tolist(),absolute_quadratic_envelope=absolute_quadratic_envelope.tolist(),ceiling_tests=ceiling_tests,maximum_curvature_preparation_index=int(curvature.size and readout['indices'][maximum_index]),maximum_curvature_time=float(packet[maximum_index,0]),maximum_curvature_components=maximum_components,max_abs_numerator_second=float(np.max(abs(numerator_second[:902]))),late_boundary_curvature=packet[901:,158].tolist(),numerical_epoch_pass=np.all(abs(residual)+numerical_budget<=GATE*scale[None,:],axis=1).tolist(),uniform_bound_established=False,sampled_ceiling_test_not_continuous_bound=True,quadratic_model_test_not_full_hierarchy=True,curvature_units='rest variable per native conformal Mpc squared',tolerances_unchanged=True,goal_left_paused=True)
        write(case+'-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,raw=raw,numeric=numerical_checks,algebra=report['algebra_passed'],duality=report['duality_passed'],max_curvature=maximum,threshold=ceiling_tests,correction=correction[-1].tolist(),max_components=maximum_components,max_abs_numerator_second=report['max_abs_numerator_second'])),flush=True)
    require(all(row['algebra_passed'] and row['duality_passed'] for row in reports.values()),'paired independent reconstruction and response checks')
    write('result.json',dict(completed=True,paired_raw_passed=all(row['raw_passed'] for row in reports.values()),paired_numerical_passed=all(row['numerical_passed'] for row in reports.values()),paired_algebra_and_response_passed=True,uniform_bound_established=False,goal_left_paused=True))
    check_hashes(read(ROOT/'frozen-inputs.json'))
