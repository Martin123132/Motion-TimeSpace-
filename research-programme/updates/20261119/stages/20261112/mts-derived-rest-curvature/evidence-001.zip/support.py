import hashlib
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PREVIOUS=POST/'mts-coherent-primitive-20261112'
SOURCE=POST/'mts-integrated-defect-20261112'
NATIVE=SOURCE/'native'
NATIVE_STAGE=POST/'mts-native-right-edge-memory-20261111'
MIDPOINT=POST/'mts-boundary-midpoint-check-20261112'
MATCH=POST/'mts-canonical-matching-state-20261111'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

assert digest(PREVIOUS/'closeout.json')=='660a9a0cfd213f7f6df7f019c402b59c77ae97da5a4fa31b523417f7ebf22138'
assert digest(SOURCE/'closeout.json')=='cb7439e9daf488bc24cfbca2ca7df6ed0a5676d5cbfde5ef138bdeb107b59e11'
previous_seal=json.loads((PREVIOUS/'closeout.json').read_text())
source_seal=json.loads((SOURCE/'closeout.json').read_text())
native_seal=json.loads((NATIVE_STAGE/'closeout.json').read_text())
assert digest(NATIVE_STAGE/'support.py')==native_seal['artifacts']['support.py']['sha256']
spec=importlib.util.spec_from_file_location('retained_support',NATIVE_STAGE/'support.py')
base=importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT,base.PREVIOUS=ROOT,PREVIOUS
EARLY,SPECTRUM,BRANCH,MATCHING=base.EARLY,base.SPECTRUM,base.BRANCH,base.MATCHING
require,read,write,guard=base.require,base.read,base.write,base.guard
worker,exited,check_hashes=base.worker,base.exited,base.check_hashes
GATE,ALGEBRA=base.GATE,base.ALGEBRA
os,sys,time,psutil=base.os,base.sys,base.time,base.psutil

def load(path):
    import numpy as np
    with np.load(path,allow_pickle=False) as packet:
        return {name:packet[name].copy() for name in packet.files}

def sealed_module(name,directory,filename):
    seal=read(directory/'closeout.json')
    path=directory/filename
    require(digest(path)==seal['artifacts'][filename]['sha256'],'sealed helper '+filename)
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def retained_module(name,filename):
    return sealed_module(name,SOURCE,filename)
