from support import *
import argparse
import ast
import ctypes
import numpy as np

maths=retained_module('retained_curvature','curvature_math.py')
comparison=maths.comparison
parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case

with worker(case+'-capture'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    build=read(ROOT/'native-build-result.json')
    require(build['state']=='completed' and build['temporary_mapping_removed'],'private build completed')
    require(all(exited(row['identity'])['exited'] for row in build['children']),'compilers exited')
    check_hashes(read(ROOT/'native-build-frozen.json'))
    local=ROOT/'native'
    require(digest(local/'camb/cambdll.dll')==build['dll_sha256'],'frozen DLL')
    write(case+'-capture-code.json',{str(path):digest(path) for path in (ROOT/'capture_rest.py',ROOT/'support.py',ROOT/'PROTOCOL.md',local/'camb/cambdll.dll')})
    sys.path.insert(0,str(local))
    import camb
    from camb.mts import MTSTwoField
    sys.path.append(str(BRANCH/'radiation-and-slow-field-transfer-20261007'))
    import radiation_common
    factory_path=MATCHING/'matching_common.py'
    factory=next(node for node in ast.parse(factory_path.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='params_for')
    namespace=dict(np=np,previous=radiation_common,MTSTwoField=MTSTwoField)
    exec(compile(ast.Module(body=[factory],type_ignores=[]),str(factory_path),'exec'),namespace)
    params=namespace['params_for'](EARLY/'runs/backgrounds'/(case+'.npz'))
    saved=load(SPECTRUM/'runs/exact-grid/chunk-0384.npz' if case=='heavy' else EARLY/'runs/final-bg8-start/cold.npz')
    prepared=load(PREVIOUS/(case+'-initial-state.npz'))
    indices=np.arange(1991,2901)
    observer=ctypes.CDLL(str(POST/'mts-metric-feedback-20261107/observer.dll'))
    callback=ctypes.cast(observer.source_func_,ctypes.c_void_p)
    library=ctypes.CDLL(str(local/'camb/cambdll.dll'))
    reset,copy=library.mts_curv_reset,library.mts_rest_copy
    reset.restype=copy.restype=None
    reset.argtypes=[]
    copy.argtypes=[ctypes.c_int,ctypes.c_void_p]
    scalar=lambda name:ctypes.c_int.in_dll(library,'mts_curv_'+name)
    native=camb.get_background(params)
    try:
        clock=np.ascontiguousarray(native.conformal_time(1/saved['requested_scale']-1,tol=1e-10))
        require(np.array_equal(clock,saved['conformal_time']),'original full native clock')
        modes=np.ascontiguousarray(saved['modes'])
        selected=int(np.flatnonzero(modes==5.)[0])
        names=list(camb.model.evolve_names)
        native.Params.Accuracy.IntTolBoost=6
        native.Params.Accuracy.lAccuracyBoost=4
        output=np.zeros((len(modes),len(clock),len(names)+30))
        reset()
        scalar('begin').value=int(indices[0])+1
        scalar('end').value=int(indices[-1])+1
        scalar('target').value=selected+1
        code=camb.results.CAMB_TimeEvolution(ctypes.byref(native),ctypes.byref(ctypes.c_int(len(modes))),modes,ctypes.byref(ctypes.c_int(len(clock))),clock,ctypes.byref(ctypes.c_int(output.shape[-1])),output,ctypes.byref(ctypes.c_int(30)),ctypes.byref(callback))
        status=dict(code=int(code),count=scalar('count').value,status=scalar('status').value)
        write(case+'-native-status.json',status)
        require(code==0 and status['status']==2 and status['count']==len(indices),'readout completed')
        packet=np.zeros((len(indices),160))
        copy(len(indices),ctypes.c_void_p(packet.ctypes.data))
        require(scalar('status').value==2 and np.isfinite(packet).all(),'finite readout')
        original=load(SOURCE/(case+'-remainder-readout.npz'))['packet']
        require(np.array_equal(packet[:,:96],original),'all original 910 packets byte-identical')
        terms=packet[:,96:152].reshape(len(indices),7,8)
        checks={}
        for mode in range(len(modes)):
            for column,name in enumerate(saved['names']):
                checks['original_'+str(mode)+'_'+str(name)]=comparison(output[mode,:,names.index(str(name))],saved['values'][mode,:,column])
        for label,column,target in (('D',0,8),('Dprime',1,9),('Q',3,47),('R',5,12),('Rprime',6,13)):
            checks['component_sum_'+label]=comparison(terms[:,:,column].sum(axis=1),packet[:,target],ALGEBRA)
        checks['eta_prime']=comparison(.5*terms[:,:,3].sum(axis=1),packet[:,11],ALGEBRA)
        checks['continuity_rhs']=comparison(packet[:,159],0,ALGEBRA,scale=1.)
        checks['rest_initial']=comparison(packet[:902,156],prepared['rest'],ALGEBRA)
        checks['rest_initial_prime']=comparison(packet[:902,157],prepared['rest_prime'],ALGEBRA)
        for component in range(1 if case=='cold' else 2):
            source=maths.field_sources(packet[:,:96],float(prepared['density0']),component=component)
            beta=packet[:,1]/float(prepared['density0'])
            recovered=source['second'][:,0]/beta-2*packet[:,2]*terms[:,component+5,1]-(packet[:,3]+packet[:,2]**2)*terms[:,component+5,0]
            checks['scalar_Dsecond_'+str(component)]=comparison(terms[:,component+5,2],recovered,ALGEBRA)
        require(all(row['passed'] for row in checks.values()),'component/retained checks '+str({name:row for name,row in checks.items() if not row['passed']}))
        np.savez_compressed(ROOT/(case+'-rest-readout.npz'),packet=packet,terms=terms,indices=indices,weights=prepared['weights'])
        np.savez_compressed(ROOT/(case+'-frozen-curvature.npz'),rest_second=packet[:902,158],times=packet[:902,0],weights=prepared['weights'],indices=indices[:902])
        report=dict(passed=True,checks=checks,original_packets_byte_identical=True,original_evolution_source_unchanged=True,quadratic_coefficient_fitted=False,target_readout_loaded=False,curvature_source='native coupled equations at original preparation nodes',hashes={str(ROOT/(case+'-frozen-curvature.npz')):digest(ROOT/(case+'-frozen-curvature.npz'))})
        write(case+'-curvature-freeze.json',report)
        print(json.dumps(dict(case=case,checks=len(checks),max_initial_abs_rest_second=float(np.max(abs(packet[:902,158]))),late_boundary_rest_second=packet[901:,158].tolist(),passed=True)),flush=True)
        check_hashes(read(ROOT/(case+'-capture-code.json')))
        check_hashes(read(ROOT/'frozen-inputs.json'))
    finally:
        reset()
        cleared=scalar('count').value==0 and scalar('status').value==0
        del native
        write(case+'-owner-release.json',dict(cleared=cleared,native_reference_released=True))
        require(cleared,'native capture released')
