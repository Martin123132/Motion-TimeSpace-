from support import *
import shutil

with worker('bootstrap'):
    require(not (ROOT/'native').exists(),'fresh private directory')
    relatives=read(SOURCE/'native-bootstrap-result.json')['copied_source_hashes']
    copied={}
    for relative in relatives:
        source=NATIVE/relative
        require(digest(source)==source_seal['artifacts']['native/'+relative.replace('\\','/')]['sha256'],'sealed native source')
        destination=ROOT/'native'/relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,destination)
        copied[relative]=digest(source)
    files=[PREVIOUS/name for name in ('closeout.json','primitive_math.py','cold-initial-state.npz','heavy-initial-state.npz','cold-linear-32.npz','cold-linear-64.npz','heavy-linear-32.npz','heavy-linear-64.npz','cold-response-gain.npz','heavy-response-gain.npz','cold-response-result.json','heavy-response-result.json','cold-comparison-budget.npz','heavy-comparison-budget.npz')]
    files += [SOURCE/name for name in ('closeout.json','integrated_math.py','curvature_math.py','cold-native-clock.npz','heavy-native-clock.npz','cold-remainder-readout.npz','heavy-remainder-readout.npz')]
    files += [EARLY/'runs/backgrounds'/name for name in ('cold.npz','heavy.npz')]
    files += [MATCH/'matching-state.npz',MATCH/'matching-validation.json',SPECTRUM/'runs/exact-grid/chunk-0384.npz',EARLY/'runs/final-bg8-start/cold.npz',MATCHING/'matching_common.py',POST/'mts-metric-feedback-20261107/observer.dll']
    files += [MIDPOINT/name for name in ('closeout.json','cold-tested-readout.npz','heavy-tested-readout.npz')]
    write('frozen-inputs.json',{str(path):digest(path) for path in files})
    write('native-bootstrap-result.json',dict(completed=True,original=str(NATIVE),copied_source_hashes=copied))
    shutil.copy2(ROOT/'rest-readout.inc',ROOT/'native/fortran/mts_curvature_hook.inc')
    print(json.dumps(dict(copied=len(copied),inputs=len(files))),flush=True)
