from support import *
import numpy as np

primitive=sealed_module('retained_primitive',PREVIOUS,'primitive_math.py')
comparison=primitive.comparison
with worker('verify-stage'):
    checks={}
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'native-build-frozen.json'))
    for relative,checksum in read(ROOT/'native-bootstrap-result.json')['copied_source_hashes'].items():
        require(digest(NATIVE/relative)==checksum,'original native source preserved')
        if relative.replace('\\','/')!='fortran/mts_curvature_hook.inc':
            require(digest(ROOT/'native'/relative)==checksum,'evolution source unchanged')
    require(digest(ROOT/'rest-readout.inc')==digest(ROOT/'native/fortran/mts_curvature_hook.inc'),'candidate export matches frozen native source')
    for case in ('cold','heavy'):
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        readout=load(ROOT/(case+'-rest-readout.npz'))
        packet,terms=readout['packet'],readout['terms']
        old=load(SOURCE/(case+'-remainder-readout.npz'))['packet']
        checks[case+'_retained_packet_bytes']=dict(passed=np.array_equal(packet[:,:96],old))
        checks[case+'_902_preparation_nodes']=dict(passed=np.array_equal(readout['indices'][:902],np.arange(1991,2893)))
        checks[case+'_weights']=dict(passed=np.array_equal(readout['weights'],prepared['weights']))
        selected=6 if case=='heavy' else 0
        other_density=terms[:,:,0].copy()
        other_current=terms[:,:,3].copy()
        other_density[:,selected]=other_current[:,selected]=0
        other_density=other_density.sum(axis=1)
        other_current=other_current.sum(axis=1)
        hubble,wave,eta=packet[:,4],packet[:,14],packet[:,10]
        if case=='heavy':
            field,velocity,mass2=packet[:,32],packet[:,33],packet[:,38]
            perturbation,speed=packet[:,39],packet[:,40]
            rhs=-(mass2+wave**2+velocity*mass2*field/(2*hubble))*perturbation-(2*hubble+velocity**2/(2*hubble))*speed-wave*velocity/hubble*(other_density/(2*wave)+eta)
            checks[case+'_enlarged_field_rhs']=comparison(rhs,packet[:,42],ALGEBRA)
            eta_rhs=(wave*velocity*perturbation+other_current)/2
        else:
            rhs=-(terms[:,selected,0]+other_density)/(2*hubble)-wave*eta/hubble
            checks[case+'_enlarged_density_rhs']=comparison(rhs,-wave*packet[:,17],ALGEBRA)
            eta_rhs=other_current/2
        checks[case+'_enlarged_eta_rhs']=comparison(eta_rhs,packet[:,11],ALGEBRA)
        background=primitive.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        for steps in (32,64):
            saved=load(ROOT/(case+'-quadratic-'+str(steps)+'.npz'))
            sources=np.array([primitive.readout(case,float(offset),state,prepared,background) for offset,state in zip(saved['elapsed'],saved['state'])])
            predicted=prepared['initial_weighted_source']+np.array([primitive.weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
            checks[case+'_source_'+str(steps)]=comparison(sources,saved['node_source'],ALGEBRA)
            checks[case+'_weighted_'+str(steps)]=comparison(predicted,saved['prediction'],ALGEBRA)
            checks[case+'_unchanged_epochs_'+str(steps)]=dict(passed=np.array_equal(saved['elapsed'],prepared['elapsed']))
        result=read(ROOT/(case+'-result.json'))
        comparison_packet=load(ROOT/(case+'-comparison.npz'))
        actual_pass=np.all(abs(comparison_packet['residual'])+comparison_packet['numerical_budget']<=GATE*comparison_packet['reference_scale'][None,:],axis=1)
        checks[case+'_reported_verdict']=dict(passed=bool(actual_pass.all() and actual_pass.tolist()==result['numerical_epoch_pass']))
        checks[case+'_no_uniform_bound_claim']=dict(passed=result['uniform_bound_established'] is False)
        if case=='heavy':
            checks['pressure_ceiling_failure_retained']=dict(passed=result['ceiling_tests'][2]['sampled_max_within_ceiling'] is False)
        for name in ('curvature-freeze','quadratic-freeze','capture-code','evolution-code'):
            value=read(ROOT/(case+'-'+name+'.json'))
            check_hashes(value['hashes'] if 'hashes' in value else value if name.endswith('code') else {})
    checks['independent_identities']=dict(passed=read(ROOT/'jet-identities.json')['passed'])
    checks['failed_attempt_preserved']=dict(passed=read(ROOT/'attempt-01/heavy-capture-end.json')['state']=='failed')
    checks['cold_early_calculation_preserved']=dict(passed=np.array_equal(load(ROOT/'attempt-01/cold-rest-readout.npz')['packet'][:,:159],load(ROOT/'cold-rest-readout.npz')['packet'][:,:159]))
    for script in ROOT.glob('*.py'):
        compile(script.read_text(),str(script),'exec')
    checks['no_bytecode_created']=dict(passed=not any(ROOT.rglob('__pycache__')))
    failures={name:row for name,row in checks.items() if not row['passed']}
    write('validation.json',dict(passed=not failures,checks=checks,failed=failures,original_native_source_files_preserved=110,unchanged_numeric_gate=GATE,unchanged_algebra_gate=ALGEBRA,goal_left_paused=True))
    require(not failures,'validation '+str(failures))
    print(json.dumps(dict(passed=True,checks=len(checks))),flush=True)
