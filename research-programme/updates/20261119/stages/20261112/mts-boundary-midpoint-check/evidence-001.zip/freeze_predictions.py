from support import *
import numpy as np
from scipy.interpolate import CubicHermiteSpline

def main():
    with worker('freeze'):
        files = [PREVIOUS / 'closeout.json', PREVIOUS / 'history_math.py', PREVIOUS / 'validation.json', NATIVE_STAGE / 'closeout.json', NATIVE_STAGE / 'run_right_edge.py', NATIVE_STAGE / 'native/camb/cambdll.dll']
        for case in ('cold', 'heavy'):
            path = PREVIOUS / (case + '-readout.npz')
            require(digest(path) == previous_seal['artifacts'][path.name]['sha256'], 'sealed historical readout')
            saved = np.load(path, allow_pickle=False)
            times = saved['current_time']
            midpoints = (times[1:] + times[:-1]) / 2
            lag_times, epochs, nodes = [], [], []
            for epoch, now in enumerate(times):
                query = now - saved['lags']
                recent = np.flatnonzero(query > times[0])
                lag_times.extend(query[recent])
                epochs.extend([epoch] * len(recent))
                nodes.extend(recent)
            query_times = np.unique(np.r_[midpoints, lag_times])
            prediction = CubicHermiteSpline(times, saved['current_source'], saved['current_rate'], extrapolate=False)(query_times)
            require(np.isfinite(prediction).all(), 'finite frozen predictions')
            np.savez_compressed(ROOT / (case + '-frozen-predictions.npz'), query_times=query_times, predicted=prediction, midpoint_indices=np.searchsorted(query_times, midpoints), lag_indices=np.searchsorted(query_times, lag_times), lag_epoch=np.array(epochs), lag_node=np.array(nodes), weights=saved['weights'], original_times=times)
            files += [path, ROOT / (case + '-frozen-predictions.npz')]
        files += [ROOT / name for name in ('support.py', 'PROTOCOL.md', 'freeze_predictions.py', 'run_dense.py')]
        write('frozen-inputs.json', {str(path): digest(path) for path in files})
        print('Both branches: predictions frozen before new source evaluation.', flush=True)

if __name__ == '__main__':
    main()
