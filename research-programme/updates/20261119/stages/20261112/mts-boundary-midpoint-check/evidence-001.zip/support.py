import importlib.util
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-causal-history-readout-20261112'
NATIVE_STAGE = POST / 'mts-native-right-edge-memory-20261111'
EXPECTED = 'e4a2bb857908259060991b9e0f5fd47a790209b4d88fdf81ff066774cc1a2221'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

if digest(PREVIOUS / 'closeout.json') != EXPECTED:
    raise ValueError('Previous checkpoint changed')
previous_seal = json.loads((PREVIOUS / 'closeout.json').read_text())
if digest(NATIVE_STAGE / 'closeout.json') != '0180bb3143a7171f40deda4999dcb609cf720b514a95e4141a9e65e596f59267':
    raise ValueError('Native checkpoint changed')
native_seal = json.loads((NATIVE_STAGE / 'closeout.json').read_text())
if digest(NATIVE_STAGE / 'support.py') != native_seal['artifacts']['support.py']['sha256']:
    raise ValueError('Native support changed')
spec = importlib.util.spec_from_file_location('retained_support', NATIVE_STAGE / 'support.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT, base.PREVIOUS = ROOT, PREVIOUS
os, sys = base.os, base.sys
BRANCH, EARLY, MATCHING, SPECTRUM = base.BRANCH, base.EARLY, base.MATCHING, base.SPECTRUM
require, read, write, guard = base.require, base.read, base.write, base.guard
worker, exited, check_hashes = base.worker, base.exited, base.check_hashes
comparison, GATE, ALGEBRA = base.comparison, base.GATE, base.ALGEBRA

def history_module():
    path = PREVIOUS / 'history_math.py'
    require(digest(path) == previous_seal['artifacts'][path.name]['sha256'], 'saved readout implementation')
    specification = importlib.util.spec_from_file_location('retained_history', path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module
