from support import *
import numpy as np

def load(path):
    with np.load(path, allow_pickle=False) as packet:
        return {name: packet[name].copy() for name in packet.files}

def check(actual, expected, tolerance=GATE, scale=None):
    difference = float(np.max(abs(np.asarray(actual) - expected)))
    scale = float(np.max(abs(expected))) if scale is None else float(scale)
    return dict(error=difference, scale=scale, relative=difference / scale if scale else None, tolerance=tolerance, passed=bool(difference <= tolerance * scale))

def components(actual, expected, tolerance=GATE):
    return {name: check(actual[:, index], expected[:, index], tolerance) for index, name in enumerate(('density', 'current', 'pressure'))}

def project_residual(frozen, residual, absolute=False):
    weighted = frozen['weights'][frozen['lag_node'], None] * residual[frozen['lag_indices']]
    if absolute:
        weighted = abs(weighted)
    result = np.zeros((len(frozen['original_times']), 3))
    np.add.at(result, frozen['lag_epoch'], weighted)
    return result

def main():
    with worker('midpoint-check') as identity:
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        results = {}
        for case in ('cold', 'heavy'):
            require(read(ROOT / (case + '-right-edge-result.json'))['passed'], 'native continuation gates')
            require(read(ROOT / (case + '-right-edge-owner-release.json'))['cleared'], 'native owner released')
            require(exited(read(ROOT / (case + '-right-edge-start.json')))['exited'], 'numerical worker exited')
            require(read(ROOT / 'freeze-end.json')['created'] < read(ROOT / (case + '-right-edge-start.json'))['created'], 'predictions frozen before evaluation')
            frozen = load(ROOT / (case + '-frozen-predictions.npz'))
            refined = load(ROOT / (case + '-dense128.npz'))
            coarse = load(ROOT / (case + '-dense64.npz'))
            saved = load(PREVIOUS / (case + '-readout.npz'))
            old_budget = load(PREVIOUS / (case + '-numerical-budget.npz'))
            require(np.array_equal(refined['query_times'], frozen['query_times']) and np.array_equal(coarse['query_times'], frozen['query_times']), 'frozen query times')
            midpoints = frozen['midpoint_indices']
            all_checks = dict(midpoint_prediction=components(frozen['predicted'][midpoints], refined['source'][midpoints]), all_query_prediction=components(frozen['predicted'], refined['source']), dense_step_refinement=components(coarse['source'], refined['source']), same_frozen_readout_nodes=components(frozen['predicted'][frozen['lag_indices']], saved['nodes_degree5'][frozen['lag_epoch'], frozen['lag_node']], ALGEBRA))
            prior_run = load(NATIVE_STAGE / (case + '-right-edge-steps64.npz'))
            rerun = load(ROOT / (case + '-right-edge-steps64.npz'))
            replay = {name:dict(bit_identical=bool(np.array_equal(rerun[name], prior_run[name])), **check(rerun[name], prior_run[name])) for name in ('clock', 'state', 'vector', 'observation', 'derivative', 'jets', 'extra')}
            all_checks['original64_replay'] = replay
            correction = project_residual(frozen, refined['source'] - frozen['predicted'])
            absolute_correction = project_residual(frozen, refined['source'] - frozen['predicted'], absolute=True)
            refinement_error = project_residual(frozen, refined['source'] - coarse['source'], absolute=True)
            direct = saved['degree5'] + correction
            updated_budget = old_budget['past_degree_discrepancy'] + absolute_correction + old_budget['seam_allowance'] + old_budget['ode_difference'] + refinement_error
            all_checks['projected_change'] = components(direct, saved['degree5'])
            all_checks['updated_working_budget'] = {name:check(updated_budget[:, index], np.zeros(len(updated_budget)), scale=np.max(abs(saved['degree7'][:, index]))) for index,name in enumerate(('density', 'current', 'pressure'))}
            all_checks['initial_history_retained'] = {name:check(direct[0, index], saved['degree5'][0, index], ALGEBRA) for index,name in enumerate(('density', 'current', 'pressure'))}
            report = dict(passed=all(row['passed'] for group in all_checks.values() for row in group.values()), checks=all_checks, frozen_midpoints=len(midpoints), total_source_queries=len(frozen['query_times']), actual_recent_node_queries=len(frozen['lag_indices']), corrected_final=direct[-1].tolist(), final_correction=correction[-1].tolist(), old_working_pressure_relative=float(np.max(old_budget['combined'][:, 2]) / np.max(abs(saved['degree7'][:, 2]))) if case == 'heavy' else 0., new_working_pressure_relative=all_checks['updated_working_budget']['pressure']['relative'], uncertainty_scope='Direct evaluated residuals at the frozen queries, plus retained historical discrepancy, seam and ODE allowances; not a rigorous bound between those queries or against common systematic error', compression_test_performed=False)
            np.savez_compressed(ROOT / (case + '-tested-readout.npz'), current_time=saved['current_time'], old_readout=saved['degree5'], corrected_readout=direct, signed_current_correction=correction, absolute_current_correction=absolute_correction, dense_refinement_envelope=refinement_error, updated_working_budget=updated_budget, old_working_budget=old_budget['combined'])
            write(case + '-midpoint-result.json', report)
            results[case] = report
            print(json.dumps(dict(case=case, passed=report['passed'], midpoint_prediction=all_checks['midpoint_prediction'], old_pressure_budget=report['old_working_pressure_relative'], new_pressure_budget=report['new_working_pressure_relative'], correction=report['final_correction'], replay_bit_identical=all(row['bit_identical'] for row in replay.values()))), flush=True)
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        for path in ROOT.glob('*.py'):
            compile(path.read_text(), str(path), 'exec')
        require(not list(ROOT.rglob('__pycache__')), 'no caches')
        write('validation.json', dict(passed=all(report['passed'] for report in results.values()), cases={case:report['passed'] for case,report in results.items()}, checker_identity=identity, original_gates=True, goal_left_paused=True))

if __name__ == '__main__':
    main()
