from support import *
import ast
import numpy as np

def capture_dense(case, steps, solution, normalization, sample, times, kept, fields, first, captured):
    frozen = np.load(ROOT / (case + '-frozen-predictions.npz'), allow_pickle=False)
    queries = frozen['query_times']
    state = solution.sol(queries).T * normalization
    records = [sample(tau, row) for tau, row in zip(queries, state)]
    sampled = {name: np.array([row[name] for row in records]) for name in records[0]}
    sampled['clock'] = queries
    matching = POST / 'mts-canonical-matching-state-20261111'
    density0 = float(np.load(matching / 'matching-state.npz')['density0'])
    cold_normalization = read(matching / 'matching-validation.json')['cold']['normalization']
    source, rate = history_module().source_series(case, sampled, captured, density0, cold_normalization)
    np.savez_compressed(ROOT / (case + '-dense' + str(steps) + '.npz'), query_times=queries, source=source, source_rate=rate, state=state, **sampled)
    print(json.dumps(dict(case=case, dense_steps=steps, new_queries=len(queries))), flush=True)

def main():
    source = NATIVE_STAGE / 'run_right_edge.py'
    require(digest(source) == native_seal['artifacts'][source.name]['sha256'], 'sealed driver')
    check_hashes(read(ROOT / 'frozen-inputs.json'))
    changes = []

    class Adapt(ast.NodeTransformer):
        def visit_Assign(self, node):
            names = [target.id for target in node.targets if isinstance(target, ast.Name)]
            if names == ['build']:
                node.value = ast.parse("read(NATIVE_STAGE / 'native-build-result.json')", mode='eval').body
                changes.append('retained_build')
            if names == ['local']:
                node.value = ast.parse("NATIVE_STAGE / 'native'", mode='eval').body
                changes.append('retained_native')
            if names == ['refinement']:
                node.value = ast.parse("dict(source=columns(states[64]['observation'], states[128]['observation']), state=columns(states[64]['vector'][:, :active], states[128]['vector'][:, :active]), derivative=columns(states[64]['derivative'][:, :active], states[128]['derivative'][:, :active]))", mode='eval').body
                changes.append('refinement64_128')
            for target in node.targets:
                if isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name) and target.value.id == 'states' and isinstance(target.slice, ast.Name) and target.slice.id == 'steps':
                    changes.append('capture_dense')
                    return [node, ast.parse('capture_dense(args.case, steps, solution, normalization, sample, times, kept, fields, first, captured)').body[0]]
            return self.generic_visit(node)

        def visit_For(self, node):
            if isinstance(node.target, ast.Name) and node.target.id == 'steps':
                node.iter = ast.parse('(64,128)', mode='eval').body
                changes.append('steps64_128')
            return self.generic_visit(node)

        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id == 'solve_ivp':
                node.keywords.append(ast.keyword(arg='dense_output', value=ast.Constant(True)))
                changes.append('dense_output')
            return self.generic_visit(node)

    tree = Adapt().visit(ast.parse(source.read_text()))
    require(changes == ['retained_build', 'retained_native', 'steps64_128', 'dense_output', 'capture_dense', 'refinement64_128'], 'bounded dense-output adapter')
    namespace = dict(__file__=str(source), __name__='dense_native_check', capture_dense=capture_dense)
    exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'), namespace)
    namespace['main']()

if __name__ == '__main__':
    main()
