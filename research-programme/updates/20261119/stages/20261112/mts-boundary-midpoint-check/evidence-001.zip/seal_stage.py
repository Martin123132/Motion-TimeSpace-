from support import *
from datetime import datetime, timezone
import numpy as np

def main():
    with worker('seal'):
        require(read(ROOT / 'validation.json')['passed'], 'midpoint comparison passed')
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        physicality = {}
        query_distance = {}
        for case in ('cold', 'heavy'):
            layout = read(ROOT / (case + '-right-edge-result.json'))
            capture = np.load(ROOT / (case + '-right-edge-capture.npz'), allow_pickle=False)
            first = int(capture['signature'][0, 2]) - 1
            for steps in (64, 128):
                packet = np.load(ROOT / (case + '-dense' + str(steps) + '.npz'), allow_pickle=False)
                for component in range(layout['fields']):
                    omega = packet['jets'][:, component, 5]
                    background = np.column_stack([packet['jets'][:, component, 0], packet['jets'][:, component, 1] / omega])
                    primitive = np.column_stack([packet['vector'][:, first + 2 * component], packet['vector'][:, first + 2 * component + 1] / omega])
                    recovered = (background[:, :, None] * primitive[:, None, :]).reshape(-1, 4)
                    section = packet['state'][:, layout['kept'] + 4 * component:layout['kept'] + 4 * component + 4]
                    for entry in range(4):
                        physicality[case + '_' + str(steps) + '_' + str(component) + '_' + str(entry)] = comparison(section[:, entry], recovered[:, entry])
            frozen = np.load(ROOT / (case + '-frozen-predictions.npz'), allow_pickle=False)
            lag_queries = frozen['query_times'][frozen['lag_indices']]
            query_distance[case] = float(np.max(np.min(abs(lag_queries[:, None] - frozen['original_times'][None, :]), axis=1)))
            require(read(ROOT / (case + '-right-edge-owner-release.json'))['cleared'], 'native owner released')
        require(all(row['passed'] for row in physicality.values()), 'coherent-subspace dense states')
        write('dense-physicality.json', dict(passed=True, checks=physicality, actual_lag_query_max_distance_from_reporting_knot=query_distance))
        for path in ROOT.glob('*-start.json'):
            if path.name == 'seal-start.json':
                continue
            require(exited(read(path))['exited'], 'task worker exited')
            require(read(ROOT / path.name.replace('-start.json', '-end.json'))['state'] == 'completed', 'task worker completed')
        for path in ROOT.glob('*.py'):
            compile(path.read_text(), str(path), 'exec')
        require(not list(ROOT.rglob('__pycache__')), 'no caches')
    artifacts = {path.name:dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('closeout.json', 'CLEANUP-VERIFIED.json')}
    write('closeout.json', dict(state='complete', utc=datetime.now(timezone.utc).isoformat(), artifacts=artifacts, input_hashes=read(ROOT / 'frozen-inputs.json'), previous_closeout_sha256=EXPECTED, goal_left_paused=True, next='Frozen equation-derived short-time memory prediction against checked history; manual authorization required'))
    print(json.dumps(dict(sealed=len(artifacts), sha256=digest(ROOT / 'closeout.json'), dense_physicality_checks=len(physicality), all_passed=True)), flush=True)

if __name__ == '__main__':
    main()
