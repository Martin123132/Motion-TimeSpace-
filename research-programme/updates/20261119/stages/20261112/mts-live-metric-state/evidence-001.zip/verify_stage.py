from metric_math import *

with worker('verify-stage'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'frozen-code.json'))
    check_hashes(read(ROOT/'initial-state-freeze.json'))
    previous_seal=read(PREVIOUS/'closeout.json')
    for relative,row in previous_seal['artifacts'].items():
        require(digest(PREVIOUS/relative)==row['sha256'],'previous artifact preserved '+relative)
    checks={}
    for case in ('cold','heavy'):
        prepared=load(ROOT/(case+'-initial-state.npz'))
        original=load(ORIGIN/(case+'-initial-state.npz'))
        background=Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        freeze=read(ROOT/(case+'-run-freeze.json'))
        check_hashes(freeze['hashes'])
        checks[case+'_not_fitted']=dict(passed=freeze['coefficients_fitted'] is False and freeze['target_values_loaded'] is False and freeze['primary']=='linear')
        for name in ('weights','times','wave','indices','elapsed','node_initial_sources','initial_weighted_source'):
            checks[case+'_original_'+name]=dict(passed=np.array_equal(prepared[name],original[name]))
        checks[case+'_primitive_initial_state']=dict(passed=np.array_equal(prepared['state'][:,:-1],original['state']))
        report=read(ROOT/(case+'-result.json'))
        for mode in ('constant','linear','density-quadratic'):
            for steps in (32,64):
                saved=load(ROOT/(case+'-'+mode+'-'+str(steps)+'.npz'))
                tag=case+'_'+mode+'_'+str(steps)
                sources=np.array([readout(case,float(offset),state,prepared,background) for offset,state in zip(saved['elapsed'],saved['state'])])
                prediction=prepared['initial_weighted_source']+np.array([weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
                checks[tag+'_sources']=comparison(sources,saved['node_source'],ALGEBRA)
                checks[tag+'_weighted_source']=comparison(prediction,saved['prediction'],ALGEBRA)
                checks[tag+'_initial_state']=comparison(saved['state'][0],prepared['state'],ALGEBRA)
                mapping=np.array([terminal_map(case,float(offset),prepared,background) for offset in saved['elapsed']])
                mapped=np.einsum('tnci,tni->tnc',mapping,saved['state']/prepared['norm'][None,:,:])
                checks[tag+'_response_readout_map']=comparison(mapped,sources,ALGEBRA)
            budget=load(ROOT/(case+'-'+mode+'-budget.npz'))
            actual=np.all(abs(budget['residual'])+budget['numerical_budget']<=GATE*budget['reference_scale'][None,:],axis=1)
            checks[case+'_'+mode+'_verdict']=dict(passed=actual.tolist()==report['modes'][mode]['epoch_pass'] and bool(actual.all())==report['modes'][mode]['numerical_passed'])
        checks[case+'_primary_pass']=dict(passed=report['primary_numerical_passed'] and report['primary_boundary_passed'])
        response=read(ROOT/(case+'-external-response.json'))
        checks[case+'_response_controls']=dict(passed=response['passed'] and all(row['passed'] for row in response['checks'].values()))
        checks[case+'_no_uniform_bound_claim']=dict(passed=response['uniform_bounds_established'] is False and response['Q_second_not_derived'] and report['uniform_error_bound_established'] is False)
    heavy=read(ROOT/'heavy-result.json')
    cold=read(ROOT/'cold-result.json')
    checks['failed_heavy_constant_control_retained']=dict(passed=not heavy['modes']['constant']['numerical_passed'] and not heavy['modes']['constant']['boundary_passed'])
    checks['source_diagnostic_failures_retained']=dict(passed=not heavy['modes']['linear']['boundary_other_source_prediction']['Q_other']['passed'] and not cold['modes']['linear']['boundary_other_source_prediction']['D_other']['passed'])
    checks['no_bytecode']=dict(passed=not any(ROOT.rglob('__pycache__')))
    for script in ROOT.glob('*.py'):
        compile(script.read_text(),str(script),'exec')
    failures={name:row for name,row in checks.items() if not row['passed']}
    write('validation.json',dict(passed=not failures,checks=checks,failed=failures,previous_artifacts_preserved=len(previous_seal['artifacts']),numeric_gate=GATE,algebra_gate=ALGEBRA,goal_left_paused=True))
    require(not failures,'validation '+str(failures))
    print(json.dumps(dict(passed=True,checks=len(checks),previous_artifacts_preserved=len(previous_seal['artifacts']))),flush=True)
