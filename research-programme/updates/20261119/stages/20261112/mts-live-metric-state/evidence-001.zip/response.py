from metric_math import *

def response_gains(case,prepared,background,steps):
    duration=float(prepared['elapsed'][-1])
    count,dimension=prepared['state'].shape
    mapping=terminal_map(case,duration,prepared,background)
    map_scale=np.max(abs(mapping),axis=2)
    map_scale[map_scale==0]=1
    initial=np.zeros((count,3,dimension+4))
    initial[:,:,:dimension]=mapping/map_scale[:,:,None]
    values=background.evaluate(prepared['times'])
    force_scale=np.zeros((count,2))
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
        force_scale[:,0]=np.sqrt(velocity**2+mass2*field**2)/(2*values['hubble']*prepared['norm'][:,1])
    else:
        force_scale[:,0]=1/(2*values['hubble']*prepared['norm'][:,0])
    force_scale[:,1]=.5/prepared['norm'][:,-1]
    require(np.all(force_scale>0),'two-channel response normalization')
    def backward_rhs(fraction,flat):
        guard()
        state=flat.reshape(initial.shape)
        matrix,forcing=normalized_geometry(case,duration*fraction,prepared,background)
        result=np.zeros_like(state)
        result[:,:,:dimension]=-duration*np.einsum('nji,ncj->nci',matrix,state[:,:,:dimension])
        projection=np.einsum('nci,nik->nck',state[:,:,:dimension],forcing)/force_scale[:,None,:]
        result[:,:,dimension:dimension+2]=-.5*fraction**2*abs(projection)
        result[:,:,dimension+2:]=-.5*fraction**2*projection
        return result.ravel()
    backward=solve_ivp(backward_rhs,(1.,0.),initial.ravel(),method='DOP853',rtol=1e-10,atol=1e-12,max_step=1/steps)
    require(backward.success,'adjoint solve completed')
    final=backward.y[:,-1].reshape(initial.shape)
    factor=map_scale[:,:,None]*force_scale[:,None,:]*duration**3
    absolute=final[:,:,dimension:dimension+2]*factor
    signed=final[:,:,dimension+2:]*factor
    def forward_rhs(fraction,flat):
        guard()
        state=flat.reshape(count,dimension,2)
        matrix,forcing=normalized_geometry(case,duration*fraction,prepared,background)
        return (duration*np.einsum('nij,njk->nik',matrix,state)+.5*fraction**2*forcing/force_scale[:,None,:]).ravel()
    forward=solve_ivp(forward_rhs,(0.,1.),np.zeros(count*dimension*2),method='DOP853',rtol=1e-10,atol=1e-12,max_step=1/steps)
    require(forward.success,'forward response completed')
    response=forward.y[:,-1].reshape(count,dimension,2)*force_scale[:,None,:]*duration**3
    direct=np.einsum('nci,nik->nck',mapping,response)
    return absolute,signed,direct,backward.nfev+forward.nfev

if __name__=='__main__':
    with worker('external-response'):
        check_hashes(read(ROOT/'frozen-inputs.json'))
        reports={}
        for case in ('cold','heavy'):
            prepared=load(ROOT/(case+'-initial-state.npz'))
            background=Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
            checks={}
            runs={}
            for steps in (32,64):
                absolute,signed,direct,evaluations=response_gains(case,prepared,background,steps)
                require(np.min(absolute)>=0,'nonnegative absolute response')
                for output,name in enumerate(('density','current','pressure')):
                    for channel,source in enumerate(('D','Q')):
                        key=str(steps)+'_'+name+'_'+source
                        checks[key+'_duality']=comparison(signed[:,output,channel],direct[:,output,channel])
                        checks[key+'_envelope']=dict(passed=bool(np.all(abs(signed[:,output,channel])<=absolute[:,output,channel]+GATE*np.max(absolute[:,output,channel]))))
                runs[steps]=dict(absolute=absolute,signed=signed,direct=direct)
                print(json.dumps(dict(case=case,steps=steps,evaluations=evaluations)),flush=True)
            weights=prepared['weights']
            gain=np.array([weighted(abs(weights),runs[64]['absolute'][:,:,channel]) for channel in (0,1)]).T
            refinement=np.array([weighted(abs(weights),abs(runs[64]['absolute'][:,:,channel]-runs[32]['absolute'][:,:,channel])) for channel in (0,1)]).T
            for output,name in enumerate(('density','current','pressure')):
                for channel,source in enumerate(('D','Q')):
                    checks[name+'_'+source+'_refinement']=comparison(refinement[output,channel],0,scale=gain[output,channel])
            primary=load(ROOT/(case+'-linear-64.npz'))
            diagnostic=load(ROOT/(case+'-density-quadratic-64.npz'))
            budget=load(ROOT/(case+'-linear-budget.npz'))
            diagnostic_budget=load(ROOT/(case+'-density-quadratic-budget.npz'))
            signed_effect=weighted(weights,runs[64]['signed'][:,:,0]*prepared['other_density_second'][:,None])
            direct_effect=diagnostic['prediction'][-1]-primary['prediction'][-1]
            absolute_effect=weighted(abs(weights),runs[64]['absolute'][:,:,0]*abs(prepared['other_density_second'][:,None]))
            allowance=GATE*absolute_effect+budget['numerical_refinement'][-1]+diagnostic_budget['numerical_refinement'][-1]+primary['arithmetic_difference'][-1]+diagnostic['arithmetic_difference'][-1]+64*np.finfo(float).eps*budget['reference_scale']
            for output,name in enumerate(('density','current','pressure')):
                checks[name+'_density_jet_effect']=dict(error=float(abs(signed_effect[output]-direct_effect[output])),allowance=float(allowance[output]),passed=bool(abs(signed_effect[output]-direct_effect[output])<=allowance[output]))
            margin=GATE*budget['reference_scale']-abs(budget['residual'][-1])-budget['numerical_budget'][-1]
            conditional=[]
            for output,name in enumerate(('density','current','pressure')):
                coefficients=gain[output]+refinement[output]
                conditional.append(dict(output=name,density_coefficient=float(coefficients[0]),current_coefficient=float(coefficients[1]),margin=float(margin[output]),density_ceiling_if_current_curvature_zero=float(margin[output]/coefficients[0]) if margin[output]>0 and coefficients[0]>0 else None,current_ceiling_if_density_curvature_zero=float(margin[output]/coefficients[1]) if margin[output]>0 and coefficients[1]>0 else None))
            np.savez_compressed(ROOT/(case+'-external-response.npz'),node_absolute_gain=runs[64]['absolute'],node_signed_gain=runs[64]['signed'],node_forward_gain=runs[64]['direct'],gain=gain,gain_refinement=refinement,margin=margin,density_jet_adjoint_effect=signed_effect,density_jet_direct_effect=direct_effect,density_jet_absolute_envelope=absolute_effect)
            passed=all(row['passed'] for row in checks.values())
            report=dict(passed=passed,checks=checks,conditional_final_epoch_requirements=conditional,formula='G_D K_D + G_Q K_Q <= remaining margin; uniform bounds for both source curvatures required',sampled_initial_D_second_max=float(np.max(abs(prepared['other_density_second']))),Q_second_not_derived=True,uniform_bounds_established=False,final_epoch_only=True,numerical_gains_not_interval_certified=True,predictions_not_changed=True)
            write(case+'-external-response.json',report)
            reports[case]=report
            print(json.dumps(dict(case=case,passed=passed,conditional=conditional,failed={name:row for name,row in checks.items() if not row['passed']})),flush=True)
        write('response-validation.json',dict(passed=all(row['passed'] for row in reports.values()),goal_left_paused=True))
        require(all(row['passed'] for row in reports.values()),'response validation')
        check_hashes(read(ROOT/'frozen-inputs.json'))
