from metric_math import *
import argparse

parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case
with worker(case+'-evolve'):
    require(read(ROOT/'initial-validation.json')['passed'],'initial identities passed')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'frozen-code.json'))
    check_hashes(read(ROOT/'initial-state-freeze.json'))
    prepared=load(ROOT/(case+'-initial-state.npz'))
    background=Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
    norm=prepared['norm']
    initial=prepared['state']/norm
    elapsed=prepared['elapsed']
    runs={}
    for mode in ('constant','linear','density-quadratic'):
        for steps in (32,64):
            def derivative(offset,flat):
                guard()
                return (rhs(case,offset,flat.reshape(initial.shape)*norm,prepared,background,mode)/norm).ravel()
            solution=solve_ivp(derivative,(0,float(elapsed[-1])),initial.ravel(),method='DOP853',t_eval=elapsed,rtol=1e-10,atol=1e-12,max_step=float(elapsed[-1])/steps)
            require(solution.success and solution.y.shape==(initial.size,len(elapsed)),'live metric evolution completed')
            states=solution.y.T.reshape(len(elapsed),*initial.shape)*norm[None,:,:]
            sources=np.array([readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed,states)])
            prediction=prepared['initial_weighted_source']+np.array([weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
            direct=np.array([weighted(prepared['weights'],row) for row in sources])
            arithmetic=abs(prediction-(prepared['initial_weighted_source']+direct-direct[0]))
            force=np.array([metric_force(case,float(offset),state,prepared,background,mode) for offset,state in zip(elapsed,states)])
            require(np.isfinite(states).all() and np.isfinite(prediction).all() and np.isfinite(force).all(),'finite prediction')
            filename=case+'-'+mode+'-'+str(steps)+'.npz'
            np.savez_compressed(ROOT/filename,state=states,node_source=sources,prediction=prediction,metric_force=force,arithmetic_difference=arithmetic,elapsed=elapsed,weights=prepared['weights'],steps=steps)
            runs[filename]=digest(ROOT/filename)
            print(json.dumps(dict(case=case,mode=mode,steps=steps,evaluations=solution.nfev)),flush=True)
    write(case+'-run-freeze.json',dict(passed=True,hashes={str(ROOT/name):value for name,value in runs.items()},target_values_loaded=False,coefficients_fitted=False,primary='linear',rtol=1e-10,normalized_atol=1e-12))
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'frozen-code.json'))
