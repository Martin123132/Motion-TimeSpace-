from metric_math import *

with worker('score-metric'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'frozen-code.json'))
    reports={}
    for case in ('cold','heavy'):
        freeze=read(ROOT/(case+'-run-freeze.json'))
        require(freeze['passed'] and not freeze['target_values_loaded'] and not freeze['coefficients_fitted'],'predictions frozen before target')
        require(exited(read(ROOT/(case+'-evolve-start.json')))['exited'],'worker exited')
        check_hashes(freeze['hashes'])
        prepared=load(ROOT/(case+'-initial-state.npz'))
        target=load(MIDPOINT/(case+'-tested-readout.npz'))
        expected=target['corrected_readout']
        scale=np.max(abs(expected),axis=0)
        reference=load(PREVIOUS/(case+'-rest-readout.npz'))
        native=reference['packet'][901:]
        native_state=np.column_stack([native[:,39:41] if case=='heavy' else native[:,63:64],native[:,10]])
        other_terms=reference['terms'][901:].copy()
        other_terms[:,6 if case=='heavy' else 0,:]=0
        native_other=other_terms.sum(axis=1)[:,[0,3]]
        results={}
        names=('density','current','pressure')
        for mode in ('constant','linear','density-quadratic'):
            fine=load(ROOT/(case+'-'+mode+'-64.npz'))
            coarse=load(ROOT/(case+'-'+mode+'-32.npz'))
            require(np.array_equal(fine['elapsed'],target['current_time']-target['current_time'][0]),'same reporting epochs')
            numerical=np.array([weighted(abs(prepared['weights']),abs(row)) for row in fine['node_source']-coarse['node_source']])
            budget=target['updated_working_budget']+abs(prepared['initial_recapture_difference'])[None,:]+numerical+fine['arithmetic_difference']
            residual=fine['prediction']-expected
            raw={name:comparison(fine['prediction'][:,column],expected[:,column]) for column,name in enumerate(names)}
            numeric={name:comparison(abs(residual[:,column])+budget[:,column],0,scale=scale[column]) for column,name in enumerate(names)}
            boundary={str(column):comparison(fine['state'][:,-1,column],native_state[:,column]) for column in range(native_state.shape[1])}
            boundary['metric_force']=comparison(fine['metric_force'][:,-1],native[:,6])
            extrapolated=np.array([other_sources(float(offset),prepared,mode)[-1] for offset in fine['elapsed']])
            external={name:comparison(extrapolated[:,column],native_other[:,column]) for column,name in enumerate(('D_other','Q_other'))}
            state_refinement=comparison((fine['state']-coarse['state'])/prepared['norm'][None,:,:],0,scale=1.)
            result=dict(raw_passed=all(row['passed'] for row in raw.values()),numerical_passed=all(row['passed'] for row in numeric.values()),raw=raw,residual_plus_numerical_allowance=numeric,normalized_state_refinement=state_refinement,boundary_state=boundary,boundary_passed=all(row['passed'] for row in boundary.values()),boundary_other_source_prediction=external,boundary_only_not_all_node_history=True,final_prediction=fine['prediction'][-1].tolist(),final_residual=residual[-1].tolist(),epoch_pass=np.all(abs(residual)+budget<=GATE*scale[None,:],axis=1).tolist(),max_absolute_weighted_refinement=np.max(numerical,axis=0).tolist())
            np.savez_compressed(ROOT/(case+'-'+mode+'-budget.npz'),residual=residual,numerical_budget=budget,numerical_refinement=numerical,reference_scale=scale,boundary_external_prediction=extrapolated,boundary_external_reference=native_other)
            results[mode]=result
        primary=load(ROOT/(case+'-linear-64.npz'))
        diagnostic=load(ROOT/(case+'-density-quadratic-64.npz'))
        old_linear=load(ORIGIN/(case+'-linear-64.npz'))
        old_quadratic=load(PREVIOUS/(case+'-quadratic-64.npz'))
        np.savez_compressed(ROOT/(case+'-method-comparison.npz'),live_minus_old_linear=primary['prediction']-old_linear['prediction'],live_minus_old_quadratic=primary['prediction']-old_quadratic['prediction'],density_curvature_effect=diagnostic['prediction']-primary['prediction'],reference_scale=scale)
        report=dict(completed=True,primary='linear',modes=results,primary_numerical_passed=results['linear']['numerical_passed'],primary_boundary_passed=results['linear']['boundary_passed'],diagnostic_not_postselected=True,all_prepared_nodes=902,original_reports=9,external_sources_exact=False,uniform_error_bound_established=False,tolerances_unchanged=True,goal_left_paused=True)
        write(case+'-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,results={mode:dict(raw={name:row['relative'] for name,row in result['raw'].items()},numeric={name:row['relative'] for name,row in result['residual_plus_numerical_allowance'].items()},boundary=result['boundary_passed'],external={name:row['relative'] for name,row in result['boundary_other_source_prediction'].items()}) for mode,result in results.items()})),flush=True)
    write('result.json',dict(completed=True,paired_primary_numerical_passed=all(row['primary_numerical_passed'] for row in reports.values()),paired_primary_boundary_passed=all(row['primary_boundary_passed'] for row in reports.values()),primary='linear',no_model_or_tolerance_tuning=True,goal_left_paused=True))
    check_hashes(read(ROOT/'frozen-inputs.json'))
