from support import *

with worker('seal-stage'):
    require(read(ROOT/'validation.json')['passed'],'stage validation')
    require(read(ROOT/'response-validation.json')['passed'],'response validation')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'frozen-code.json'))
    outcomes=[]
    for path in ROOT.glob('*-start.json'):
        if path.name=='seal-stage-start.json':
            continue
        identity=read(path)
        outcome=exited(identity)
        require(outcome['exited'],'worker exit '+path.name)
        require(read(path.with_name(path.name.replace('-start.json','-end.json')))['state']=='completed','worker completed')
        outcomes.append(dict(receipt=path.name,identity=identity,outcome=outcome))
    write('preseal-validation.json',dict(passed=True,workers=outcomes,goal_left_paused=True,no_native_rebuild=True))

artifacts={path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(stage='live-metric-state',date='2026-11-12',completed=True,previous=str(PREVIOUS),previous_closeout_sha256=digest(PREVIOUS/'closeout.json'),artifacts=artifacts,frozen_inputs=read(ROOT/'frozen-inputs.json'),validation_passed=True,result=read(ROOT/'result.json'),response_validation_passed=True,uniform_external_error_bound_established=False,next='Derive other-sector current curvature and establish source-error allowance before extending window',goal_left_paused=True,github_action=False,continuing_jobs=[],cleanup_receipt='CLEANUP-VERIFIED.json'))
print(json.dumps(dict(completed=True,artifacts=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'))),flush=True)
