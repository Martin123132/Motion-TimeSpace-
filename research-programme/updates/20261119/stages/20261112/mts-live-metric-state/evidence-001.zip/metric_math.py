from support import *
import numpy as np
from scipy.integrate import solve_ivp

primitive=sealed_module('retained_primitive',ORIGIN,'primitive_math.py')
Background,weighted,comparison=primitive.Background,primitive.weighted,primitive.comparison

def geometry(case,offset,prepared,background):
    values=background.evaluate(prepared['times']+offset)
    hubble=values['hubble']
    hubble_prime=values['hubble_prime']
    wave=prepared['wave']
    count=len(wave)
    dimension=3 if case=='heavy' else 2
    matrix=np.zeros((count,dimension,dimension))
    derivative=np.zeros_like(matrix)
    forcing=np.zeros((count,dimension,2))
    forcing_prime=np.zeros_like(forcing)
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
        mass_prime=2*values['rate']*mass2
        matrix[:,0,1]=1
        matrix[:,1,0]=-(mass2+wave**2+velocity*mass2*field/(2*hubble))
        matrix[:,1,1]=-(2*hubble+velocity**2/(2*hubble))
        matrix[:,1,2]=-wave*velocity/hubble
        matrix[:,2,0]=wave*velocity/2
        derivative[:,1,0]=-mass_prime-(velocity_prime*mass2*field+velocity*mass_prime*field+velocity*mass2*field_prime)/(2*hubble)+velocity*mass2*field*hubble_prime/(2*hubble**2)
        derivative[:,1,1]=-2*hubble_prime-velocity*velocity_prime/hubble+velocity**2*hubble_prime/(2*hubble**2)
        derivative[:,1,2]=-wave*(velocity_prime/hubble-velocity*hubble_prime/hubble**2)
        derivative[:,2,0]=wave*velocity_prime/2
        forcing[:,1,0]=-velocity/(2*hubble)
        forcing_prime[:,1,0]=-velocity_prime/(2*hubble)+velocity*hubble_prime/(2*hubble**2)
        forcing[:,2,1]=.5
    else:
        density_factor=background.constants[0]/values['scale']
        matrix[:,0,0]=-density_factor/(2*hubble)
        matrix[:,0,1]=-wave/hubble
        derivative[:,0,0]=matrix[:,0,0]*(-values['rate']-hubble_prime/hubble)
        derivative[:,0,1]=wave*hubble_prime/hubble**2
        forcing[:,0,0]=-1/(2*hubble)
        forcing_prime[:,0,0]=hubble_prime/(2*hubble**2)
        forcing[:,1,1]=.5
    return matrix,derivative,forcing,forcing_prime

def other_sources(offset,prepared,mode):
    source=prepared['other0'].copy()
    if mode!='constant':
        source+=offset*prepared['other1']
    if mode=='density-quadratic':
        source[:,0]+=.5*offset**2*prepared['other_density_second']
    return source

def rhs(case,offset,state,prepared,background,mode):
    matrix,derivative,forcing,forcing_prime=geometry(case,offset,prepared,background)
    return np.einsum('nij,nj->ni',matrix,state)+np.einsum('nij,nj->ni',forcing,other_sources(offset,prepared,mode))

def readout(case,offset,state,prepared,background):
    return primitive.readout(case,offset,state[:,:-1],prepared,background)

def metric_force(case,offset,state,prepared,background,mode):
    values=background.evaluate(prepared['times']+offset)
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
        own_density=velocity*state[:,1]+mass2*field*state[:,0]
    else:
        own_density=background.constants[0]/values['scale']*state[:,0]
    return ((own_density+other_sources(offset,prepared,mode)[:,0])/(2*prepared['wave'])+state[:,-1])/values['hubble']

def terminal_map(case,offset,prepared,background):
    values=background.evaluate(prepared['times']+offset)
    count,dimension=prepared['state'].shape
    mapping=np.zeros((count,3,dimension))
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
        beta=values['scale']/prepared['density0']
        mapping[:,0,0],mapping[:,0,1]=beta*mass2*field,beta*velocity
        mapping[:,1,0]=beta*prepared['wave']*velocity
        mapping[:,2,0],mapping[:,2,1]=-beta*mass2*field,beta*velocity
    else:
        mapping[:,0,0]=prepared['cold_normalization']
    return mapping*prepared['norm'][:,None,:]

def normalized_geometry(case,offset,prepared,background):
    matrix,derivative,forcing,forcing_prime=geometry(case,offset,prepared,background)
    norm=prepared['norm']
    return matrix*norm[:,None,:]/norm[:,:,None],forcing/norm[:,:,None]
