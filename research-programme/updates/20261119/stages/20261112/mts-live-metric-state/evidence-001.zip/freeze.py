from metric_math import *
from scipy.linalg import expm

with worker('freeze-inputs'):
    cleanup=read(PREVIOUS/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['external_checker_exit_verified'],'previous stage cleaned up')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'],'previous worker remains exited')
    files=[NATIVE_STAGE/'support.py',PREVIOUS/'closeout.json',ORIGIN/'closeout.json',SOURCE/'closeout.json',MIDPOINT/'closeout.json']
    for directory,names in (
        (PREVIOUS,['cold-rest-readout.npz','heavy-rest-readout.npz','cold-quadratic-32.npz','cold-quadratic-64.npz','heavy-quadratic-32.npz','heavy-quadratic-64.npz','cold-result.json','heavy-result.json','DERIVATION.md','NEXT.md']),
        (ORIGIN,['primitive_math.py','cold-initial-state.npz','heavy-initial-state.npz','cold-linear-32.npz','cold-linear-64.npz','heavy-linear-32.npz','heavy-linear-64.npz']),
        (SOURCE,['integrated_math.py','curvature_math.py','cold-native-clock.npz','heavy-native-clock.npz']),
        (MIDPOINT,['cold-tested-readout.npz','heavy-tested-readout.npz'])):
        seal=read(directory/'closeout.json')
        for name in names:
            path=directory/name
            require(digest(path)==seal['artifacts'][name]['sha256'],'sealed input '+name)
            files.append(path)
    files += [EARLY/'runs/backgrounds'/name for name in ('cold.npz','heavy.npz')]
    prior=read(PREVIOUS/'frozen-inputs.json')
    for path in files[-2:]:
        require(digest(path)==prior[str(path)],'original field table')
    write('frozen-inputs.json',{str(path):digest(path) for path in files})
    write('frozen-code.json',{str(ROOT/name):digest(ROOT/name) for name in ('support.py','metric_math.py','freeze.py','run_metric.py','PROTOCOL.md')})
    checks={}
    for case in ('cold','heavy'):
        saved=load(ORIGIN/(case+'-initial-state.npz'))
        reference=load(PREVIOUS/(case+'-rest-readout.npz'))
        packet,terms=reference['packet'][:902],reference['terms'][:902]
        require(np.array_equal(packet[:,0],saved['times']),'same preparation clock')
        require(np.array_equal(reference['weights'],saved['weights']),'same signed weights')
        selected=6 if case=='heavy' else 0
        other=terms.copy()
        other[:,selected,:]=0
        summed=other.sum(axis=1)
        state=np.column_stack([saved['state'],packet[:,10]])
        eta_scale=np.sqrt(packet[:,10]**2+(summed[:,0]/(2*saved['wave']))**2+(terms[:,selected,0]/(2*saved['wave']))**2+(saved['elapsed'][-1]*packet[:,11])**2)
        require(np.all(eta_scale>0),'positive natural metric-state normalization')
        prepared=dict(saved,state=state,norm=np.column_stack([saved['norm'],eta_scale]),other0=summed[:,[0,3]],other1=summed[:,[1,4]],other_density_second=summed[:,2],eta_initial_prime=packet[:,11],eta_initial_second=packet[:,153]/2)
        background=Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        first=rhs(case,0.,state,prepared,background,'linear')
        matrix,derivative,forcing,forcing_prime=geometry(case,0.,prepared,background)
        second=np.einsum('nij,nj->ni',derivative,state)+np.einsum('nij,nj->ni',matrix,first)+np.einsum('nij,nj->ni',forcing_prime,prepared['other0'])+np.einsum('nij,nj->ni',forcing,prepared['other1'])
        first_reference=np.column_stack([saved['reference_first'],packet[:,11]])
        second_reference=np.column_stack([saved['reference_second'],packet[:,153]/2])
        for column in range(state.shape[1]):
            checks[case+'_initial_first_'+str(column)]=comparison(first[:,column],first_reference[:,column],ALGEBRA)
            checks[case+'_initial_second_'+str(column)]=comparison(second[:,column],second_reference[:,column],ALGEBRA)
        checks[case+'_metric_constraint']=comparison(metric_force(case,0.,state,prepared,background,'linear'),packet[:,6],ALGEBRA)
        checks[case+'_initial_sources']=comparison(readout(case,0.,state,prepared,background),saved['node_initial_sources'],ALGEBRA)
        normalized_matrix,normalized_forcing=normalized_geometry(case,0.,prepared,background)
        for index in (0,451,901):
            duration=float(prepared['elapsed'][-1])
            initial=state[index]/prepared['norm'][index]
            constant_force=normalized_forcing[index]@prepared['other0'][index]
            augmented=np.zeros((len(initial)+1,len(initial)+1))
            augmented[:-1,:-1]=normalized_matrix[index]
            augmented[:-1,-1]=constant_force
            exact=(expm(duration*augmented)@np.append(initial,1))[:-1]
            numerical=solve_ivp(lambda offset,value:normalized_matrix[index]@value+constant_force,(0,duration),initial,method='DOP853',rtol=1e-10,atol=1e-12,max_step=duration/32)
            require(numerical.success,'constant-coefficient control completed')
            checks[case+'_exponential_control_'+str(index)]=comparison(numerical.y[:,-1],exact,ALGEBRA)
        np.savez_compressed(ROOT/(case+'-initial-state.npz'),**prepared)
    passed=all(row['passed'] for row in checks.values())
    write('initial-validation.json',dict(passed=passed,checks=checks,target_values_loaded=False,parameters_fitted=False,modes=['constant','linear','density-quadratic'],primary='linear'))
    require(passed,'initial validation '+str({name:row for name,row in checks.items() if not row['passed']}))
    write('initial-state-freeze.json',{str(ROOT/(case+'-initial-state.npz')):digest(ROOT/(case+'-initial-state.npz')) for case in ('cold','heavy')})
    check_hashes(read(ROOT/'frozen-inputs.json'))
    print(json.dumps(dict(passed=True,checks=len(checks))),flush=True)
