from support import *
import ast
import ctypes
import numpy as np

maths = retained_module('probe_comparison_math', 'curvature_math.py')

def setup_probes(case, library):
    freeze = read(ROOT / (case + '-probe-freeze.json'))
    require(freeze['passed'] and digest(ROOT / (case + '-probe-plan.npz')) == freeze['plan_sha256'], 'plan frozen before probe')
    times = np.ascontiguousarray(load(ROOT / (case + '-probe-plan.npz'))['plan'][:, 0])
    setup = library.mts_probe_setup
    setup.restype = None
    setup.argtypes = [ctypes.c_int, ctypes.c_void_p]
    setup(len(times), ctypes.c_void_p(times.ctypes.data))
    require(ctypes.c_int.in_dll(library, 'mts_probe_status').value == 1, 'probe setup')

def finish_capture(case, packet, indices, prepared, output, names, saved, library):
    comparison = maths.comparison
    old = load(LATEST / (case + '-current-readout.npz'))['packet']
    require(np.array_equal(packet, old), 'original 224-column packets byte-identical')
    plan = load(ROOT / (case + '-probe-plan.npz'))['plan']
    count = ctypes.c_int.in_dll(library, 'mts_probe_count').value
    require(count == len(plan) and ctypes.c_int.in_dll(library, 'mts_probe_status').value == 2, 'all probes complete')
    probes = np.zeros((count, 224))
    copy = library.mts_probe_copy
    copy.restype = None
    copy.argtypes = [ctypes.c_int, ctypes.c_void_p]
    copy(count, ctypes.c_void_p(probes.ctypes.data))
    require(np.isfinite(probes).all() and np.array_equal(probes[:, 0], plan[:, 0]), 'finite probes at frozen times')
    checks = {}
    for mode in range(len(saved['modes'])):
        for column, name in enumerate(saved['names']):
            checks['original_' + str(mode) + '_' + str(name)] = comparison(output[mode, :, names.index(str(name))], saved['values'][mode, :, column])
    checks['same_regime'] = dict(passed=bool(np.all(probes[:, 199] == 1) and np.all(probes[:, 170:172] == 0)))
    checks['same_clock'] = comparison(probes[:, 190], 0, ALGEBRA, scale=1.)
    checks['collision_cancellation'] = comparison(probes[:, 167], probes[:, 161] + probes[:, 162], ALGEBRA)
    terms = probes[:, 96:152].reshape(count, 7, 8)
    checks['density_sum'] = comparison(terms[:, :, 0].sum(axis=1), probes[:, 8], ALGEBRA)
    checks['current_sum'] = comparison(terms[:, :, 3].sum(axis=1), probes[:, 47], ALGEBRA)
    endpoint = probes[plan[:, 4] == 2]
    require(len(endpoint) == len(packet)-1, 'each saved gap independently restarted')
    for column in (8, 9, 47, 152, 153, 168):
        checks['endpoint_' + str(column)] = comparison(endpoint[:, column], packet[1:, column])
    np.savez_compressed(ROOT / (case + '-probe-readout.npz'), packet=probes, plan=plan, original_indices=indices)
    report = dict(passed=all(row['passed'] for row in checks.values()), checks=checks, original_packets_byte_identical=True, probes=count, independent_saved_gap_restarts=len(endpoint), original_bank_grids_tolerances_unchanged=True, coefficients_fitted=False)
    write(case + '-capture-validation.json', report)
    require(report['passed'], 'probe validation ' + str({name: row for name, row in checks.items() if not row['passed']}))
    check_hashes(read(ROOT / (case + '-capture-code.json')))
    check_hashes(read(ROOT / 'frozen-inputs.json'))
    print(json.dumps(dict(case=case, probes=count, checks=len(checks), passed=True)), flush=True)

source = REST / 'capture_rest.py'
require(digest(source) == read(REST / 'closeout.json')['artifacts']['capture_rest.py']['sha256'], 'sealed capture driver')
changes = []

class Adapt(ast.NodeTransformer):
    def visit_Constant(self, node):
        if node.value == 'capture_rest.py':
            changes.append('code_name')
            return ast.Constant('capture_probes.py')
        if node.value == 160:
            changes.append('packet_width')
            return ast.Constant(224)
        return node

    def visit_Attribute(self, node):
        if node.attr == 'mts_rest_copy':
            node.attr = 'mts_current_copy'
            changes.append('export')
        return self.generic_visit(node)

    def visit_Assign(self, node):
        if any(isinstance(target, ast.Name) and target.id == 'code' for target in node.targets):
            changes.append('setup')
            return ast.parse('setup_probes(case,library)').body + [self.generic_visit(node)]
        return self.generic_visit(node)

    def visit_Try(self, node):
        positions = [index for index, statement in enumerate(node.body) if isinstance(statement, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'terms' for target in statement.targets)]
        if positions:
            require(len(positions) == 1, 'one capture boundary')
            node.body = node.body[:positions[0]] + ast.parse('finish_capture(case,packet,indices,prepared,output,names,saved,library)').body
            changes.append('probe_validation')
        return self.generic_visit(node)

tree = Adapt().visit(ast.parse(source.read_text()))
require(sorted(changes) == sorted(['code_name', 'export', 'probe_validation', 'packet_width', 'setup']), 'bounded capture adaptation ' + str(changes))
namespace = dict(__file__=__file__, __name__='probe_capture', finish_capture=finish_capture, setup_probes=setup_probes)
exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'), namespace)
