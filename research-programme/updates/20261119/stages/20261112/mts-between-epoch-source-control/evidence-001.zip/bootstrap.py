from support import *
import shutil
import numpy as np

maths = sealed_module('saved_integrated_math', SOURCE, 'integrated_math.py')
with worker('bootstrap'):
    cleanup = read(LATEST / 'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['external_checker_exit_verified'], 'previous cleanup')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'], 'previous worker exited')
    copied = {}
    seal = read(LATEST / 'closeout.json')
    for relative in read(LATEST / 'native-bootstrap-result.json')['copied_source_hashes']:
        source = NATIVE / relative
        require(digest(source) == seal['artifacts']['native/' + relative.replace('\\', '/')]['sha256'], 'sealed native source')
        destination = ROOT / 'native' / relative
        require(not destination.exists(), 'new destination')
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied[relative] = digest(source)
    write('native-bootstrap-result.json', dict(completed=True, original=str(NATIVE), copied_source_hashes=copied))
    frozen = read(LATEST / 'frozen-inputs.json')
    for filename, entry in seal['artifacts'].items():
        if filename.endswith('.npz') or filename in ('support.py', 'score_current.py', 'RESULTS.md', 'NEXT.md'):
            path = LATEST / filename
            require(digest(path) == entry['sha256'], 'sealed latest input')
            frozen[str(path)] = entry['sha256']
    frozen[str(LATEST / 'closeout.json')] = digest(LATEST / 'closeout.json')
    for case in ('cold', 'heavy'):
        packet = load(LATEST / (case + '-current-readout.npz'))['packet']
        clock = packet[:, 0]
        background = maths.Background(load(SOURCE / (case + '-native-clock.npz')), load(EARLY / 'runs/backgrounds' / (case + '.npz')))
        boundaries = np.asarray(background.boundaries(float(clock[0]), float(clock[-1])))
        boundaries = boundaries[(boundaries > clock[0]) & (boundaries < clock[-1])]
        rows = []
        for gap, (left, right) in enumerate(zip(clock[:-1], clock[1:])):
            guard()
            corners = boundaries[(boundaries > left) & (boundaries < right)]
            splits = np.concatenate(([left], corners, [right]))
            for cell, (begin, end) in enumerate(zip(splits[:-1], splits[1:])):
                for fraction in (.25, .5, .75):
                    rows.append((begin + fraction * (end - begin), gap, cell, fraction, 0))
                if end < right:
                    epsilon = min(1e-7 * min(end - begin, right - end), 1e-10)
                    rows.extend(((end - epsilon, gap, cell, 1., -1), (end + epsilon, gap, cell + 1, 0., 1)))
            rows.append((right, gap, len(splits) - 2, 1., 2))
        plan = np.asarray(sorted(rows), dtype=float)
        require(np.all(np.diff(plan[:, 0]) > 0), 'strict probe ordering')
        np.savez_compressed(ROOT / (case + '-probe-plan.npz'), plan=plan, boundaries=boundaries, clock=clock)
        write(case + '-probe-freeze.json', dict(passed=True, probes=len(plan), corners=len(boundaries), original_gaps=len(clock)-1, plan_sha256=digest(ROOT / (case + '-probe-plan.npz')), original_packet_sha256=digest(LATEST / (case + '-current-readout.npz')), gate=GATE, algebra=ALGEBRA, targets_loaded=False))
        print(json.dumps(dict(case=case, probes=len(plan), corners=len(boundaries))), flush=True)
    check_hashes(frozen)
    write('frozen-inputs.json', frozen)
