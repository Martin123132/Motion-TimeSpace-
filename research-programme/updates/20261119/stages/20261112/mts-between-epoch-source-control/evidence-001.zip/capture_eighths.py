from support import *
import argparse
import ast
import ctypes
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case
comparison=retained_module('eighth_comparison','curvature_math.py').comparison

with worker(case+'-eighth-capture'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    freeze=read(ROOT/(case+'-cell-control-freeze.json'))
    require(freeze['passed'] and not freeze['new_targets_loaded'],'predictions frozen before new probes')
    require(digest(ROOT/(case+'-cell-control-frozen.npz'))==freeze['sha256'],'unchanged frozen predictions')
    check_hashes(freeze['source_inputs'])
    build=read(ROOT/'native-build-result.json')
    require(build['state']=='completed' and build['temporary_mapping_removed'],'retained private build')
    check_hashes(read(ROOT/'native-build-frozen.json'))
    local=ROOT/'native'
    require(digest(local/'camb/cambdll.dll')==build['dll_sha256'],'same native DLL')
    write(case+'-eighth-code.json',{str(ROOT/name):digest(ROOT/name) for name in ('capture_eighths.py','support.py')})
    sys.path.insert(0,str(local))
    import camb
    from camb.mts import MTSTwoField
    sys.path.append(str(BRANCH/'radiation-and-slow-field-transfer-20261007'))
    import radiation_common
    factory_path=MATCHING/'matching_common.py'
    factory=next(node for node in ast.parse(factory_path.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='params_for')
    namespace=dict(np=np,previous=radiation_common,MTSTwoField=MTSTwoField)
    exec(compile(ast.Module(body=[factory],type_ignores=[]),str(factory_path),'exec'),namespace)
    params=namespace['params_for'](EARLY/'runs/backgrounds'/(case+'.npz'))
    saved=load(SPECTRUM/'runs/exact-grid/chunk-0384.npz' if case=='heavy' else EARLY/'runs/final-bg8-start/cold.npz')
    requests=load(ROOT/(case+'-cell-control-frozen.npz'))['requests']
    probe_times=np.ascontiguousarray(requests[:,0])
    observer=ctypes.CDLL(str(POST/'mts-metric-feedback-20261107/observer.dll'))
    callback=ctypes.cast(observer.source_func_,ctypes.c_void_p)
    library=ctypes.CDLL(str(local/'camb/cambdll.dll'))
    reset,copy,setup,probe_copy=library.mts_curv_reset,library.mts_current_copy,library.mts_probe_setup,library.mts_probe_copy
    for routine in (reset,copy,setup,probe_copy):
        routine.restype=None
    reset.argtypes=[]
    copy.argtypes=setup.argtypes=probe_copy.argtypes=[ctypes.c_int,ctypes.c_void_p]
    scalar=lambda name:ctypes.c_int.in_dll(library,'mts_curv_'+name)
    native=camb.get_background(params)
    try:
        clock=np.ascontiguousarray(native.conformal_time(1/saved['requested_scale']-1,tol=1e-10))
        require(np.array_equal(clock,saved['conformal_time']),'original clock')
        modes=np.ascontiguousarray(saved['modes'])
        selected=int(np.flatnonzero(modes==5.)[0])
        names=list(camb.model.evolve_names)
        native.Params.Accuracy.IntTolBoost=6
        native.Params.Accuracy.lAccuracyBoost=4
        output=np.zeros((len(modes),len(clock),len(names)+30))
        reset()
        scalar('begin').value=1992
        scalar('end').value=2901
        scalar('target').value=selected+1
        setup(len(probe_times),ctypes.c_void_p(probe_times.ctypes.data))
        code=camb.results.CAMB_TimeEvolution(ctypes.byref(native),ctypes.byref(ctypes.c_int(len(modes))),modes,ctypes.byref(ctypes.c_int(len(clock))),clock,ctypes.byref(ctypes.c_int(output.shape[-1])),output,ctypes.byref(ctypes.c_int(30)),ctypes.byref(callback))
        require(code==0 and scalar('status').value==2 and scalar('count').value==910,'original capture complete')
        require(ctypes.c_int.in_dll(library,'mts_probe_status').value==2 and ctypes.c_int.in_dll(library,'mts_probe_count').value==len(probe_times),'eighth probes complete')
        packet=np.zeros((910,224))
        copy(910,ctypes.c_void_p(packet.ctypes.data))
        require(np.array_equal(packet,load(LATEST/(case+'-current-readout.npz'))['packet']),'original packets byte-identical')
        probes=np.zeros((len(probe_times),224))
        probe_copy(len(probe_times),ctypes.c_void_p(probes.ctypes.data))
        require(np.array_equal(probes[:,0],probe_times) and np.isfinite(probes).all(),'correct finite probes')
        checks={}
        for mode in range(len(saved['modes'])):
            for column,name in enumerate(saved['names']):
                checks['original_'+str(mode)+'_'+str(name)]=comparison(output[mode,:,names.index(str(name))],saved['values'][mode,:,column])
        checks['same_regime']=dict(passed=bool(np.all(probes[:,199]==1) and np.all(probes[:,170:172]==0)))
        checks['collision_cancellation']=comparison(probes[:,167],probes[:,161]+probes[:,162],ALGEBRA)
        np.savez_compressed(ROOT/(case+'-eighth-readout.npz'),packet=probes,requests=requests)
        write(case+'-eighth-validation.json',dict(passed=all(row['passed'] for row in checks.values()),checks=checks,original_packets_byte_identical=True,probes=len(probes),frozen_prediction_sha256=freeze['sha256']))
        require(all(row['passed'] for row in checks.values()),'eighth validation')
        check_hashes(read(ROOT/(case+'-eighth-code.json')))
        check_hashes(read(ROOT/'frozen-inputs.json'))
        print(json.dumps(dict(case=case,probes=len(probes),passed=True)),flush=True)
    finally:
        reset()
        cleared=scalar('count').value==0 and ctypes.c_int.in_dll(library,'mts_probe_count').value==0
        del native
        write(case+'-eighth-owner-release.json',dict(cleared=cleared,native_reference_released=True))
        require(cleared,'probe owner release')
