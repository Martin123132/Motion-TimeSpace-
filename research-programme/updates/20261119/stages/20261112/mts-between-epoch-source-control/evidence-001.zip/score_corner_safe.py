from support import *
import ast

source=ROOT/'score_cell_control.py'
require(digest(source)==read(ROOT/'cell-analysis-freeze.json')[str(source)],'retained scoring equations')
replacements={'score-cell-control':'score-corner-safe','cell-analysis-freeze.json':'corner-safe-analysis-freeze.json','score_cell_control.py':'score_corner_safe.py','cell-integral-controls.json':'corner-safe-integral-controls.json','-eighth-validation.json':'-sixth-validation.json','-eighth-capture-start.json':'-sixth-capture-start.json','-cell-control-freeze.json':'-corner-safe-control-freeze.json','-cell-control-frozen.npz':'-corner-safe-control-frozen.npz','-eighth-readout.npz':'-sixth-readout.npz','_new_eighth_prediction':'_new_sixth_prediction','-cell-result.json':'-corner-safe-result.json','-cell-budget.npz':'-corner-safe-budget.npz','cell-result.json':'corner-safe-result.json'}

class Adapt(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str) and node.value in replacements:
            return ast.Constant(replacements[node.value])
        return node

tree=Adapt().visit(ast.parse(source.read_text()))
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),dict(__file__=__file__,__name__='corner_safe_score'))
