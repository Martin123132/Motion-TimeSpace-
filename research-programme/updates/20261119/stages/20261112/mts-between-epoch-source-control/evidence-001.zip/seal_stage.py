from support import *

with worker('seal-stage'):
    require(read(ROOT/'validation.json')['passed'],'validated stage')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'native-build-frozen.json'))
    outcomes=[]
    for path in ROOT.glob('*-start.json'):
        if path.name=='seal-stage-start.json':
            continue
        identity=read(path)
        outcome=exited(identity)
        require(outcome['exited'],'worker exited '+path.name)
        end=read(path.with_name(path.name.replace('-start.json','-end.json')))
        diagnosed=path.name=='score-variation-start.json' and end['state']=='failed' and 'TypeError' in end['error']
        require(end['state']=='completed' or diagnosed,'worker completed or preserved diagnosed failure')
        outcomes.append(dict(receipt=path.name,identity=identity,outcome=outcome,diagnosed_failure=diagnosed))
    build=read(ROOT/'native-build-result.json')
    require(build['temporary_mapping_removed'],'owned build drive removed')
    for row in build['children']:
        require(exited(row['identity'])['exited'],'compiler exited')
    write('preseal-validation.json',dict(passed=True,workers=outcomes,compiler_children_exited=len(build['children']),temporary_mapping_removed=True))

artifacts={path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(stage='between-epoch-source-control',date='2026-11-12',completed=True,previous=str(LATEST),previous_closeout_sha256=digest(LATEST/'closeout.json'),artifacts=artifacts,frozen_inputs=read(ROOT/'frozen-inputs.json'),validation_passed=True,result=read(ROOT/'corner-safe-result.json'),continuous_remainder_bound_established=False,next='Propagate corner-safe source integrals in retained coupled field/metric evolution and test direct changes against saved gains',goal_left_paused=True,github_action=False,continuing_jobs=[],cleanup_receipt='CLEANUP-VERIFIED.json'))
print(json.dumps(dict(completed=True,artifacts=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'))),flush=True)
