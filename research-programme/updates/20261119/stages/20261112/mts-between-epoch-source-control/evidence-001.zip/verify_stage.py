from support import *
import numpy as np

with worker('verify-stage'):
    checks={}
    for path in ROOT.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    checks['all_python_compiles']=True
    check_hashes(read(ROOT/'frozen-inputs.json'))
    checks['frozen_inputs_unchanged']=True
    for relative,entry in read(LATEST/'closeout.json')['artifacts'].items():
        require(digest(LATEST/relative)==entry['sha256'],'previous sealed artifact unchanged '+relative)
    checks['previous_260_artifacts_unchanged']=True
    check_hashes(read(ROOT/'native-build-frozen.json'))
    build=read(ROOT/'native-build-result.json')
    checks['build_finished']=build['state']=='completed' and build['temporary_mapping_removed']
    checks['compiler_children_exited']=all(exited(row['identity'])['exited'] for row in build['children'])
    checks['no_pycache']=not any(ROOT.rglob('__pycache__'))
    for name in ('integral-controls.json','cell-integral-controls.json','corner-safe-integral-controls.json'):
        checks[name]=read(ROOT/name)['passed']
    final=read(ROOT/'corner-safe-result.json')
    checks['paired_numerical_controls']=final['paired_numerical_controls_passed']
    checks['paired_working_budget']=final['paired_working_budget_passed']
    checks['no_uniform_proof_overclaim']=not final['uniform_physical_bound_proved']
    checks['prior_failures_retained']=not read(ROOT/'result.json')['paired_numerical_controls_passed'] and not read(ROOT/'cell-result.json')['paired_numerical_controls_passed']
    checks['diagnosed_type_error_retained']=read(ROOT/'score-variation-end.json')['state']=='failed' and digest(ROOT/'score_variation-attempt01.py')==read(ROOT/'analysis-freeze.json')['hashes'][str(ROOT/'score_variation.py')]
    for case in ('cold','heavy'):
        for kind in ('capture-validation','eighth-validation','sixth-validation'):
            validation=read(ROOT/(case+'-'+kind+'.json'))
            checks[case+'_'+kind]=validation['passed'] and validation['original_packets_byte_identical']
        for kind in ('owner-release','eighth-owner-release','sixth-owner-release'):
            release=read(ROOT/(case+'-'+kind+'.json'))
            checks[case+'_'+kind]=release['cleared'] and release['native_reference_released']
        freeze=read(ROOT/(case+'-corner-safe-control-freeze.json'))
        checks[case+'_freeze_intact']=digest(ROOT/(case+'-corner-safe-control-frozen.npz'))==freeze['sha256'] and not freeze['new_targets_loaded']
        checks[case+'_correct_side']=all(row['passed'] for row in freeze['checks'].values())
        prediction=load(ROOT/(case+'-corner-safe-control-frozen.npz'))
        actual=load(ROOT/(case+'-sixth-readout.npz'))
        checks[case+'_fresh_times']=np.array_equal(prediction['requests'],actual['requests']) and not np.any(np.isin(actual['packet'][:,0],load(ROOT/(case+'-probe-readout.npz'))['packet'][:,0])) and not np.any(np.isin(actual['packet'][:,0],load(ROOT/(case+'-eighth-readout.npz'))['packet'][:,0]))
        budget=load(ROOT/(case+'-corner-safe-budget.npz'))
        checks[case+'_nonnegative_envelope']=bool(np.all(budget['node_variation_bound']>=0) and np.all(budget['remaining_margin']>=0))
    require(all(checks.values()),'final checks '+str({name:passed for name,passed in checks.items() if not passed}))
    write('validation.json',dict(passed=True,checks=checks,check_count=len(checks),goal_left_paused=True,prior_physical_checkpoints_unchanged=True))
    print(json.dumps(dict(passed=True,checks=len(checks))),flush=True)
