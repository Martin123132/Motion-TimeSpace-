from support import *
import ast

source=ROOT/'capture_eighths.py'
require(digest(source)==read(ROOT/'heavy-eighth-code.json')[str(source)],'retained native capture')
replacements={'-cell-control-freeze.json':'-corner-safe-control-freeze.json','-cell-control-frozen.npz':'-corner-safe-control-frozen.npz','-eighth-capture':'-sixth-capture','-eighth-code.json':'-sixth-code.json','-eighth-readout.npz':'-sixth-readout.npz','-eighth-validation.json':'-sixth-validation.json','-eighth-owner-release.json':'-sixth-owner-release.json','capture_eighths.py':'capture_sixths.py'}

class Adapt(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str) and node.value in replacements:
            return ast.Constant(replacements[node.value])
        return node

tree=Adapt().visit(ast.parse(source.read_text()))
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),dict(__file__=__file__,__name__='sixth_capture'))
