from support import *
import math
import numpy as np
from variation_math import source_jet

with worker('freeze-cell-control'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    for case in ('cold','heavy'):
        capture = load(ROOT/(case+'-probe-readout.npz'))
        plan, probes = capture['plan'], capture['packet']
        original = load(LATEST/(case+'-current-readout.npz'))['packet']
        boundaries = load(ROOT/(case+'-probe-plan.npz'))['boundaries']
        original_jet, probe_jet = source_jet(original,case),source_jet(probes,case)
        cells, coefficients, requests = [], [], []
        for gap,(left,right) in enumerate(zip(original[:-1,0],original[1:,0])):
            splits = np.concatenate(([left],boundaries[(boundaries>left)&(boundaries<right)],[right]))
            for cell,(begin,end) in enumerate(zip(splits[:-1],splits[1:])):
                guard()
                interior = (plan[:,1]==gap)&(plan[:,2]==cell)&(plan[:,4]==0)
                require(np.count_nonzero(interior)==3,'same three quarter/midpoint samples')
                if begin==left:
                    first = original_jet[gap,2]
                else:
                    first = probe_jet[(plan[:,1]==gap)&(plan[:,2]==cell)&(plan[:,4]==1),2][0]
                if end==right:
                    last = original_jet[gap+1,2]
                else:
                    last = probe_jet[(plan[:,1]==gap)&(plan[:,2]==cell)&(plan[:,4]==-1),2][0]
                abscissa = np.concatenate(([0.],(plan[interior,0]-begin)/(end-begin),[1.]))
                samples = np.vstack((first,probe_jet[interior,2],last))
                power = np.linalg.solve(np.polynomial.polynomial.polyvander(abscissa,4),samples)
                coefficients.append(power)
                cell_index = len(cells)
                cells.append((begin,end,gap,cell))
                for fraction in (.125,.375,.625,.875):
                    requests.append((begin+fraction*(end-begin),cell_index,fraction))
        coefficients, cells, requests = np.array(coefficients),np.array(cells),np.array(requests)
        predictions = np.array([np.polynomial.polynomial.polyval(row[2],coefficients[int(row[1])]) for row in requests])
        bernstein = np.zeros_like(coefficients)
        for index in range(5):
            for power in range(index+1):
                bernstein[:,index,:] += coefficients[:,power,:]*math.comb(index,power)/math.comb(4,power)
        np.savez_compressed(ROOT/(case+'-cell-control-frozen.npz'),cells=cells,power=coefficients,bernstein=bernstein,requests=requests,prediction=predictions)
        inputs = {str(ROOT/(case+'-probe-readout.npz')):digest(ROOT/(case+'-probe-readout.npz')),str(LATEST/(case+'-current-readout.npz')):digest(LATEST/(case+'-current-readout.npz'))}
        write(case+'-cell-control-freeze.json',dict(passed=True,source_inputs=inputs,sha256=digest(ROOT/(case+'-cell-control-frozen.npz')),cells=len(cells),new_eighth_probes=len(requests),physics_parameters_changed=False,previous_failed_linear_curvature_check_preserved=True,new_targets_loaded=False,interpretation='Local numerical curvature reconstruction only, not a new source law; one-sided endpoint probes represent each side of a known corner'))
        print(json.dumps(dict(case=case,cells=len(cells),new_probes=len(requests))),flush=True)
    write('cell-control-code-freeze.json',{str(ROOT/name):digest(ROOT/name) for name in ('freeze_cell_control.py','variation_math.py','support.py')})
