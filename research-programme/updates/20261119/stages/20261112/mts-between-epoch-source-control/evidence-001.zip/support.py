import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
LATEST = POST / 'mts-external-current-curvature-20261112'
assert hashlib.sha256((LATEST / 'closeout.json').read_bytes()).hexdigest() == 'c4ab559f4f61128f670ec6bd65a5b86215e71f36ef184168640587097034817b'
assert hashlib.sha256((LATEST / 'support.py').read_bytes()).hexdigest() == json.loads((LATEST / 'closeout.json').read_text())['artifacts']['support.py']['sha256']
spec = importlib.util.spec_from_file_location('sealed_current_support', LATEST / 'support.py')
retained = importlib.util.module_from_spec(spec)
spec.loader.exec_module(retained)
retained.base.ROOT = ROOT
PREVIOUS, REST, ORIGIN, SOURCE = retained.PREVIOUS, retained.REST, retained.ORIGIN, retained.SOURCE
NATIVE, NATIVE_STAGE, MIDPOINT = LATEST / 'native', retained.NATIVE_STAGE, retained.MIDPOINT
EARLY, BRANCH, SPECTRUM, MATCHING = retained.EARLY, retained.BRANCH, retained.SPECTRUM, retained.MATCHING
require, read, write, guard = retained.require, retained.read, retained.write, retained.guard
worker, exited, check_hashes = retained.worker, retained.exited, retained.check_hashes
digest, load = retained.digest, retained.load
sealed_module, retained_module = retained.sealed_module, retained.retained_module
GATE, ALGEBRA = retained.GATE, retained.ALGEBRA
os, sys, time, psutil = retained.os, retained.sys, retained.time, retained.psutil
