from support import *
import numpy as np
from variation_math import source_jet
from cell_math import bernstein_coefficients,clipped_power,cell_variation,cell_integral

metric=sealed_module('cell_metric',PREVIOUS,'metric_math.py')
weighted=metric.weighted

def comparison(actual,expected,tolerance=GATE,scale=None):
    return metric.comparison(np.asarray(actual),np.asarray(expected),tolerance,scale=scale)

with worker('score-cell-control'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    write('cell-analysis-freeze.json',{str(ROOT/name):digest(ROOT/name) for name in ('cell_math.py','score_cell_control.py')})
    synthetic=np.array([[2.,7.],[3.,-2.],[0.,0.],[0.,0.],[0.,0.]])
    controls={}
    controls['affine_integral']=comparison(cell_integral(np.array([[0.,1.]]),synthetic[None,:,:],0.,1.),[1.5,19/6],ALGEBRA)
    controls['clipped_integral']=comparison(cell_integral(np.array([[0.,1.]]),synthetic[None,:,:],.2,.6),[.24,38/75],ALGEBRA)
    controls['curvature_variation_integral']=comparison(cell_integral(np.array([[0.,1.]]),synthetic[None,:,:],0.,1.,synthetic[0]),[.5,-1/3],ALGEBRA)
    controls['clipped_enclosure']=comparison(cell_variation(np.array([[0.,1.]]),synthetic[None,:,:],.2,.6,np.array([2.6,6.6])),[1.2,.8],ALGEBRA)
    jump_power=np.zeros((2,5,2))
    jump_power[0,0]=[2.,2.]
    jump_power[1,0]=[4.,4.]
    controls['finite_curvature_jump_integral']=comparison(cell_integral(np.array([[0.,.5],[.5,1.]]),jump_power,0.,1.),[1.25,1.25],ALGEBRA)
    quartic=np.array([[2.,-1.],[3.,2.],[-5.,4.],[7.,-6.],[11.,3.]])
    controls['quartic_exact_integral']=comparison(cell_integral(np.array([[0.,1.]]),quartic[None,:,:],0.,1.),np.sum([quartic[index]/((index+1)*(index+2)) for index in range(5)],axis=0),ALGEBRA)
    restricted=clipped_power(quartic,.2,.7)
    grid=np.linspace(0,1,101)
    controls['clipped_polynomial_identity']=comparison(np.polynomial.polynomial.polyval(grid,restricted),np.polynomial.polynomial.polyval(.2+.5*grid,quartic),ALGEBRA)
    coefficients=bernstein_coefficients(quartic)
    samples=np.polynomial.polynomial.polyval(grid,quartic).T
    controls['bernstein_enclosure']=dict(passed=bool(np.all(samples>=np.min(coefficients,axis=0)-ALGEBRA) and np.all(samples<=np.max(coefficients,axis=0)+ALGEBRA)))
    write('cell-integral-controls.json',dict(passed=all(row['passed'] for row in controls.values()),checks=controls))
    require(all(row['passed'] for row in controls.values()),'cell algebra tests '+str(controls))
    reports={}
    for case in ('cold','heavy'):
        require(read(ROOT/(case+'-eighth-validation.json'))['passed'],'new native probes validated')
        require(exited(read(ROOT/(case+'-eighth-capture-start.json')))['exited'],'probe worker exited')
        freeze=read(ROOT/(case+'-cell-control-freeze.json'))
        require(digest(ROOT/(case+'-cell-control-frozen.npz'))==freeze['sha256'],'frozen predictor untouched')
        frozen=load(ROOT/(case+'-cell-control-frozen.npz'))
        new=load(ROOT/(case+'-eighth-readout.npz'))
        actual=source_jet(new['packet'],case)[:,2]
        error=frozen['prediction']-actual
        initial_packet=load(LATEST/(case+'-current-readout.npz'))['packet']
        initial_jet=source_jet(initial_packet,case)
        previous=read(ROOT/(case+'-result.json'))
        curvature_scale=np.maximum(previous['curvature_scale'],np.max(abs(actual),axis=0))
        interpolation_error=np.max(abs(error),axis=0)
        endpoint_error=np.array(previous['restart_curvature_error'])
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        duration=float(prepared['elapsed'][-1])
        variations=np.array([cell_variation(frozen['cells'],frozen['power'],float(begin),float(begin+duration),initial) for begin,initial in zip(prepared['times'],initial_jet[:902,2])])
        gain=load(PREVIOUS/(case+'-external-response.npz'))
        envelope=weighted(abs(prepared['weights']),np.sum(gain['node_absolute_gain']*variations[:,None,:],axis=2))+gain['gain_refinement']@np.max(variations,axis=0)
        working=(gain['gain']+gain['gain_refinement'])@(interpolation_error+endpoint_error)
        saved=load(LATEST/(case+'-comparison.npz'))
        margin=GATE*saved['reference_scale']-abs(saved['residual'][-1])-saved['numerical_budget'][-1]
        remaining=margin-envelope-working
        budget={}
        for output,name in enumerate(('density','current','pressure')):
            budget[name]=dict(saved_margin=float(margin[output]),bernstein_variation_envelope=float(envelope[output]),observed_interpolation_restart_allowance=float(working[output]),remaining_margin=float(remaining[output]),fraction_used=float((envelope[output]+working[output])/margin[output]) if margin[output]>0 else None,working_passed=bool(remaining[output]>=0),uniform_residual_coefficients=(gain['gain'][output]+gain['gain_refinement'][output]).tolist())
        begin=float(prepared['times'][-1])
        integrals=np.array([cell_integral(frozen['cells'],frozen['power'],begin,begin+float(offset),initial_jet[901,2]) for offset in prepared['elapsed']])
        elapsed=prepared['elapsed'].astype(np.longdouble)[:,None]
        quadratic=initial_jet[901,0].astype(np.longdouble)+elapsed*initial_jet[901,1]+elapsed**2*initial_jet[901,2]/2
        boundary=np.asarray(quadratic+integrals,dtype=float)
        checks={}
        for channel,name in enumerate(('D','Q')):
            checks[name+'_new_eighth_prediction']=comparison(error[:,channel],0,scale=curvature_scale[channel])
            checks[name+'_boundary_integral']=comparison(boundary[:,channel],initial_jet[901:,0,channel])
        write(case+'-cell-result.json',dict(completed=True,checks=checks,numerical_controls_passed=all(row['passed'] for row in checks.values()),working_budget_passed=bool(np.all(remaining>=0)),budget=budget,new_probe_count=len(actual),error_scale=curvature_scale.tolist(),new_prediction_errors=interpolation_error.tolist(),previous_linear_error=previous['refined_independent_error'],uniform_physical_bound_proved=False,unresolved='A supremum for true curvature minus the numerical cell polynomial still needs an analytic or validated-numerics enclosure; finite probe residuals are not that enclosure',original_prediction_bank_grids_tolerances_unchanged=True,goal_left_paused=True))
        np.savez_compressed(ROOT/(case+'-cell-budget.npz'),independent_error=error,node_variation_bound=variations,variation_envelope=envelope,observed_error_envelope=working,remaining_margin=remaining,boundary_prediction=boundary,boundary_integral=integrals.astype(float),boundary_reference=initial_jet[901:,0])
        reports[case]=dict(controls=all(row['passed'] for row in checks.values()),budget=bool(np.all(remaining>=0)))
        print(json.dumps(dict(case=case,checks=checks,budget=budget)),flush=True)
    write('cell-result.json',dict(completed=True,paired_numerical_controls_passed=all(row['controls'] for row in reports.values()),paired_working_budget_passed=all(row['budget'] for row in reports.values()),previous_coarse_failure_preserved=True,uniform_physical_bound_proved=False,goal_left_paused=True))
    check_hashes(read(ROOT/'cell-analysis-freeze.json'))
    check_hashes(read(ROOT/'frozen-inputs.json'))
