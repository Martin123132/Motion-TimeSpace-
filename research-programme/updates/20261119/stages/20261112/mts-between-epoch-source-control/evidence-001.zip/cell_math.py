import math
import numpy as np

def bernstein_coefficients(power):
    result=np.zeros_like(power)
    degree=len(power)-1
    for index in range(degree+1):
        for exponent in range(index+1):
            result[index]+=power[exponent]*math.comb(index,exponent)/math.comb(degree,exponent)
    return result

def clipped_power(power,lower,upper):
    result=np.zeros_like(power)
    for index in range(len(power)):
        for exponent in range(index,len(power)):
            result[index]+=power[exponent]*math.comb(exponent,index)*lower**(exponent-index)*(upper-lower)**index
    return result

def cell_variation(cells,power,begin,end,initial):
    selected=np.flatnonzero((cells[:,0]<end)&(cells[:,1]>begin))
    maximum=np.zeros(2)
    for index in selected:
        left,right=cells[index,:2]
        lower=(max(begin,left)-left)/(right-left)
        upper=(min(end,right)-left)/(right-left)
        restricted=clipped_power(power[index],lower,upper)
        coefficients=bernstein_coefficients(restricted)-initial
        maximum=np.maximum(maximum,np.max(abs(coefficients),axis=0))
    return maximum

def cell_integral(cells,power,begin,end,initial=None):
    selected=np.flatnonzero((cells[:,0]<end)&(cells[:,1]>begin))
    result=np.zeros(2,dtype=np.longdouble)
    for index in selected:
        left,right=cells[index,:2].astype(np.longdouble)
        width=right-left
        lower=(max(np.longdouble(begin),left)-left)/width
        upper=(min(np.longdouble(end),right)-left)/width
        local=power[index].astype(np.longdouble).copy()
        if initial is not None:
            local[0]-=initial
        for exponent in range(len(local)):
            integral=(upper**(exponent+1)-lower**(exponent+1))/(exponent+1)
            moment=(upper**(exponent+2)-lower**(exponent+2))/(exponent+2)
            result+=local[exponent]*width*((np.longdouble(end)-left)*integral-width*moment)
    return result
