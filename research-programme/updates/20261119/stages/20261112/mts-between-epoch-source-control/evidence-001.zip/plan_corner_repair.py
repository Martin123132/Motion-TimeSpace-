from support import *
import numpy as np

with worker('plan-corner-repair'):
    reports={}
    for case in ('cold','heavy'):
        capture=load(ROOT/(case+'-probe-readout.npz'))
        plan,packet=capture['plan'],capture['packet']
        clock=load(SOURCE/(case+'-native-clock.npz'))
        minimum,spacing=clock['metadata']
        boundaries=load(ROOT/(case+'-probe-plan.npz'))['boundaries']
        defects,requests=[],[]
        for left_row in np.flatnonzero(plan[:,4]==-1):
            right_row=left_row+1
            require(plan[right_row,4]==1,'paired one-sided probe')
            boundary=(plan[left_row,0]+plan[right_row,0])/2
            position=np.log(boundary/minimum)/spacing+1
            nearest=int(round(position))
            thermal=abs(position-nearest)<1e-7
            if thermal and not (int(packet[left_row,18])==nearest-1 and int(packet[right_row,18])==nearest):
                offset=1e-10
                require(np.min(abs(boundaries-boundary)[abs(boundaries-boundary)>1e-12],initial=1.)>4*offset,'repair does not cross another corner')
                index=len(defects)
                defects.append(dict(boundary=float(boundary),left_row=int(left_row),right_row=int(right_row),expected_left=nearest-1,expected_right=nearest,observed_left=int(packet[left_row,18]),observed_right=int(packet[right_row,18]),old_offset=float((plan[right_row,0]-plan[left_row,0])/2),new_offset=offset))
                requests.extend(((boundary-offset,index,-1),(boundary+offset,index,1)))
        reports[case]=defects
        if requests:
            requests=np.array(requests)
            require(np.all(np.diff(requests[:,0])>0),'ordered targeted requests')
            np.savez_compressed(ROOT/(case+'-corner-repair-plan.npz'),requests=requests)
            write(case+'-corner-repair-freeze.json',dict(passed=True,new_targets_loaded=False,sha256=digest(ROOT/(case+'-corner-repair-plan.npz')),source_inputs={str(ROOT/(case+'-probe-readout.npz')):digest(ROOT/(case+'-probe-readout.npz'))},defects=defects))
    write('corner-repair-diagnosis.json',dict(completed=True,diagnosis='Tiny offsets rounded to the wrong thermal interpolation cell; certify side identity from native packet column 18, not from the requested sign alone',cases=reports,original_evolution_unchanged=True))
    print(json.dumps(reports),flush=True)
