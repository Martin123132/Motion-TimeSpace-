from support import *
import numpy as np
from variation_math import source_jet, interpolate, variation_maximum, weighted_integral, unweighted_integral

metric = sealed_module('variation_metric', PREVIOUS, 'metric_math.py')
comparison, weighted = metric.comparison, metric.weighted

with worker('score-variation'):
    check_hashes(read(ROOT / 'frozen-inputs.json'))
    write('analysis-freeze.json', dict(hashes={str(ROOT/name):digest(ROOT/name) for name in ('score_variation.py','variation_math.py','PROTOCOL.md')}, formulas_frozen_before_analysis=True, numerical_allowance_rule='quarter curvature discrepancy plus restarted-endpoint curvature discrepancy; diagnostic, not rigorous supremum'))
    controls = {}
    control_times = np.array([0., .2, .6, 1.])
    control_values = np.column_stack((2 + 3*control_times, 7 - 2*control_times))
    controls['linear_curvature_integral'] = comparison(weighted_integral(control_times, control_values, 0., 1.), [1.5, 19/6], ALGEBRA)
    controls['linear_curvature_variation_integral'] = comparison(weighted_integral(control_times, control_values, 0., 1., control_values[0]), [.5, -1/3], ALGEBRA)
    controls['constant_curvature_zero_remainder'] = comparison(weighted_integral(control_times, np.ones((4,2)), .2, .8, [1.,1.]), [0.,0.], ALGEBRA)
    controls['piecewise_corner_integral'] = comparison(weighted_integral(np.array([0.,.5,1.]), np.array([[0.],[1.],[0.]]), 0., 1.), [.25], ALGEBRA)
    controls['exact_piecewise_linear_maximum'] = comparison(variation_maximum(np.array([0.,.5,1.]), np.array([[0.],[1.],[0.]]), .1, .9, [.2]), [.8], ALGEBRA)
    controls['clipped_interval_integral'] = comparison(weighted_integral(control_times, control_values, .2, .6), [.24, 38/75], ALGEBRA)
    write('integral-controls.json', dict(passed=all(row['passed'] for row in controls.values()), checks=controls))
    require(all(row['passed'] for row in controls.values()), 'analytic integral controls ' + str(controls))
    reports = {}
    for case in ('cold', 'heavy'):
        require(read(ROOT/(case+'-capture-validation.json'))['passed'], 'validated native probes')
        require(exited(read(ROOT/(case+'-capture-start.json')))['exited'], 'capture exited')
        packet = load(LATEST/(case+'-current-readout.npz'))['packet']
        capture = load(ROOT/(case+'-probe-readout.npz'))
        probes, plan = capture['packet'], capture['plan']
        original_jet, probe_jet = source_jet(packet, case), source_jet(probes, case)
        original_times = packet[:,0]
        corner = abs(plan[:,4]) == 1
        midpoint = (plan[:,4] == 0) & (plan[:,3] == .5)
        quarters = (plan[:,4] == 0) & (plan[:,3] != .5)
        reconstructed = {}
        for name, mask in (('coarse',corner), ('refined',corner|midpoint)):
            sample_times = np.concatenate((original_times, plan[mask,0]))
            curvatures = np.concatenate((original_jet[:,2], probe_jet[mask,2]))
            order = np.argsort(sample_times)
            reconstructed[name] = (sample_times[order], curvatures[order])
            require(np.all(np.diff(sample_times[order]) > 0), 'unique split reconstruction')
        coarse_times, coarse = reconstructed['coarse']
        fine_times, fine = reconstructed['refined']
        independent_times = plan[quarters,0]
        coarse_error = interpolate(coarse_times, coarse, independent_times) - probe_jet[quarters,2]
        fine_error = interpolate(fine_times, fine, independent_times) - probe_jet[quarters,2]
        curvature_scale = np.max(abs(np.vstack((original_jet[:,2],probe_jet[:,2]))),axis=0)
        quarter_uncertainty = np.max(abs(fine_error),axis=0)
        restart_uncertainty = np.max(abs(probe_jet[plan[:,4]==2,2]-original_jet[1:,2]),axis=0)
        working_curvature_uncertainty = quarter_uncertainty + restart_uncertainty
        prepared = load(PREVIOUS/(case+'-initial-state.npz'))
        duration = float(prepared['elapsed'][-1])
        require(np.array_equal(prepared['times'],original_times[:902]), 'saved preparation times')
        require(np.max(prepared['times']+duration) <= fine_times[-1], 'all future windows covered')
        variations = {}
        for name, (times, values) in reconstructed.items():
            variations[name] = np.array([variation_maximum(times,values,float(begin),float(begin+duration),initial) for begin,initial in zip(prepared['times'],original_jet[:902,2])])
        gain = load(PREVIOUS/(case+'-external-response.npz'))
        envelopes = {}
        for name, variation in variations.items():
            node_terms = np.sum(gain['node_absolute_gain']*variation[:,None,:],axis=2)
            envelopes[name] = weighted(abs(prepared['weights']),node_terms) + gain['gain_refinement'] @ np.max(variation,axis=0)
        unresolved_working_envelope = (gain['gain']+gain['gain_refinement']) @ working_curvature_uncertainty
        saved = load(LATEST/(case+'-comparison.npz'))
        margin = GATE*saved['reference_scale'] - abs(saved['residual'][-1]) - saved['numerical_budget'][-1]
        remaining = margin - envelopes['refined'] - unresolved_working_envelope
        names = ('density','current','pressure')
        budget = {}
        for output,name in enumerate(names):
            budget[name] = dict(saved_margin=float(margin[output]),coarse_variation_envelope=float(envelopes['coarse'][output]),refined_variation_envelope=float(envelopes['refined'][output]),observed_interpolation_restart_allowance=float(unresolved_working_envelope[output]),remaining_margin=float(remaining[output]),fraction_used=float((envelopes['refined'][output]+unresolved_working_envelope[output])/margin[output]) if margin[output]>0 else None,working_budget_passed=bool(remaining[output]>=0),additional_uniform_remainder_coefficients=(gain['gain'][output]+gain['gain_refinement'][output]).tolist())
        boundary_predictions, boundary_integrals = {}, {}
        begin = float(prepared['times'][-1])
        for name,(times,values) in reconstructed.items():
            integrals = np.array([weighted_integral(times,values,begin,float(begin+offset),original_jet[901,2]) if offset else np.zeros(2,dtype=np.longdouble) for offset in prepared['elapsed']])
            duration_array = prepared['elapsed'].astype(np.longdouble)[:,None]
            quadratic = original_jet[901,0].astype(np.longdouble) + duration_array*original_jet[901,1] + duration_array**2*original_jet[901,2]/2
            boundary_predictions[name] = np.asarray(quadratic+integrals,dtype=float)
            boundary_integrals[name] = np.asarray(integrals,dtype=float)
        checks = {}
        for channel,label in enumerate(('D','Q')):
            checks[label+'_independent_curvature'] = comparison(fine_error[:,channel],0,scale=curvature_scale[channel])
            checks[label+'_refinement_shrinks'] = dict(passed=bool(np.max(abs(fine_error[:,channel])) <= np.max(abs(coarse_error[:,channel])) + restart_uncertainty[channel]))
            checks[label+'_boundary_integral'] = comparison(boundary_predictions['refined'][:,channel],original_jet[901:,0,channel])
        gap_value_error, gap_derivative_error = [], []
        for index,(begin,end) in enumerate(zip(original_times[:-1],original_times[1:])):
            guard()
            value_integral = weighted_integral(fine_times,fine,float(begin),float(end))
            derivative_integral = unweighted_integral(fine_times,fine,float(begin),float(end))
            gap_value_error.append(np.asarray(original_jet[index,0].astype(np.longdouble)+(end-begin)*original_jet[index,1]+value_integral-original_jet[index+1,0],dtype=float))
            gap_derivative_error.append(np.asarray(original_jet[index,1].astype(np.longdouble)+derivative_integral-original_jet[index+1,1],dtype=float))
        gap_value_error, gap_derivative_error = np.array(gap_value_error),np.array(gap_derivative_error)
        for channel,label in enumerate(('D','Q')):
            checks[label+'_all_gap_value_integrals'] = comparison(gap_value_error[:,channel],0,scale=np.max(abs(original_jet[:,0,channel])))
            checks[label+'_all_gap_derivative_integrals'] = comparison(gap_derivative_error[:,channel],0,scale=np.max(abs(original_jet[:,1,channel])))
        report = dict(completed=True,checks=checks,paired_channels_tested=['D','Q'],original_gaps=len(original_times)-1,corner_probes=int(np.count_nonzero(corner)),independent_quarter_probes=int(np.count_nonzero(quarters)),coarse_independent_error=np.max(abs(coarse_error),axis=0).tolist(),refined_independent_error=quarter_uncertainty.tolist(),curvature_scale=curvature_scale.tolist(),restart_curvature_error=restart_uncertainty.tolist(),maximum_nodewise_curvature_change=np.max(variations['refined'],axis=0).tolist(),budget=budget,numerical_controls_passed=all(row['passed'] for row in checks.values()),working_budget_passed=bool(np.all(remaining>=0)),uniform_physical_bound_proved=False,interpretation='Exact envelope of the numerical piecewise-linear curvature reconstruction; observed probe errors are working allowances, not proven suprema',previous_prediction_unchanged=True,original_bank_grids_tolerances_unchanged=True,goal_left_paused=True)
        np.savez_compressed(ROOT/(case+'-variation-budget.npz'),fine_times=fine_times,fine_curvature=fine,coarse_times=coarse_times,coarse_curvature=coarse,independent_times=independent_times,coarse_error=coarse_error,fine_error=fine_error,node_variation=variations['refined'],coarse_node_variation=variations['coarse'],variation_envelope=envelopes['refined'],observed_uncertainty_envelope=unresolved_working_envelope,remaining_margin=remaining,boundary_integral=boundary_integrals['refined'],boundary_prediction=boundary_predictions['refined'],boundary_reference=original_jet[901:,0],gap_value_error=gap_value_error,gap_derivative_error=gap_derivative_error)
        write(case+'-result.json',report)
        reports[case] = report
        print(json.dumps(dict(case=case,budget=budget,checks=checks)),flush=True)
    write('result.json',dict(completed=True,paired_numerical_controls_passed=all(row['numerical_controls_passed'] for row in reports.values()),paired_working_budget_passed=all(row['working_budget_passed'] for row in reports.values()),uniform_physical_bound_proved=False,goal_left_paused=True))
    check_hashes(read(ROOT/'analysis-freeze.json')['hashes'])
    check_hashes(read(ROOT/'frozen-inputs.json'))
