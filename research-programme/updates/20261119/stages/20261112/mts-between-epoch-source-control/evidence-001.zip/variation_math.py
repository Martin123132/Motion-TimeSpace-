import numpy as np

def source_jet(packet, case):
    terms = packet[:, 96:152].reshape(len(packet), 7, 8).copy()
    terms[:, 6 if case == 'heavy' else 0, :] = 0
    total = terms.sum(axis=1)
    return np.stack((total[:, [0, 3]], total[:, [1, 4]], np.column_stack((total[:, 2], packet[:, 168]))), axis=1)

def interpolate(times, values, query):
    return np.column_stack([np.interp(query, times, values[:, channel]) for channel in range(values.shape[1])])

def segment_values(times, values, begin, end):
    first = np.searchsorted(times, begin, side='right')
    last = np.searchsorted(times, end, side='left')
    points = np.concatenate(([begin], times[first:last], [end]))
    samples = np.vstack((interpolate(times, values, [begin]), values[first:last], interpolate(times, values, [end])))
    return points, samples

def variation_maximum(times, values, begin, end, initial):
    points, samples = segment_values(times, values, begin, end)
    return np.max(abs(samples - initial), axis=0)

def weighted_integral(times, values, begin, end, initial=None):
    points, samples = segment_values(times, values, begin, end)
    points, samples = points.astype(np.longdouble), samples.astype(np.longdouble)
    if initial is not None:
        samples = samples - np.asarray(initial, dtype=np.longdouble)
    widths = np.diff(points)[:, None]
    slopes = np.diff(samples, axis=0) / widths
    distance = (np.longdouble(end) - points[:-1])[:, None]
    pieces = distance * (samples[:-1]*widths + slopes*widths**2/2) - samples[:-1]*widths**2/2 - slopes*widths**3/3
    return np.sum(pieces, axis=0, dtype=np.longdouble)

def unweighted_integral(times, values, begin, end):
    points, samples = segment_values(times, values, begin, end)
    return np.sum(np.diff(points).astype(np.longdouble)[:, None] * (samples[:-1].astype(np.longdouble) + samples[1:].astype(np.longdouble))/2, axis=0)
