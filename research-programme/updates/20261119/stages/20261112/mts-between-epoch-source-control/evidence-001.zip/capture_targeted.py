from support import *
import ast

source=ROOT/'capture_eighths.py'
require(digest(source)==read(ROOT/'heavy-eighth-code.json')[str(source)],'retained native capture')
replacements={'-cell-control-freeze.json':'-corner-repair-freeze.json','-cell-control-frozen.npz':'-corner-repair-plan.npz','-eighth-capture':'-corner-repair-capture','-eighth-code.json':'-corner-repair-code.json','-eighth-readout.npz':'-corner-repair-readout.npz','-eighth-validation.json':'-corner-repair-validation.json','-eighth-owner-release.json':'-corner-repair-owner-release.json','capture_eighths.py':'capture_targeted.py'}

class Adapt(ast.NodeTransformer):
    def visit_Constant(self,node):
        if isinstance(node.value,str) and node.value in replacements:
            return ast.Constant(replacements[node.value])
        return node

tree=Adapt().visit(ast.parse(source.read_text()))
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),dict(__file__=__file__,__name__='targeted_capture'))
