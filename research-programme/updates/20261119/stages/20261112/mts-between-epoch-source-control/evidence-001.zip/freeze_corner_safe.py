from support import *
import numpy as np
from variation_math import source_jet
from cell_math import bernstein_coefficients

with worker('freeze-corner-safe'):
    diagnosis=read(ROOT/'corner-repair-diagnosis.json')
    for case in ('cold','heavy'):
        capture=load(ROOT/(case+'-probe-readout.npz'))
        plan,probes=capture['plan'].copy(),capture['packet'].copy()
        defects=diagnosis['cases'][case]
        checks={}
        if defects:
            require(read(ROOT/(case+'-corner-repair-validation.json'))['passed'],'targeted samples validated')
            require(exited(read(ROOT/(case+'-corner-repair-capture-start.json')))['exited'],'targeted worker exited')
            repair=load(ROOT/(case+'-corner-repair-readout.npz'))
            for index,defect in enumerate(defects):
                for side,label in ((-1,'left'),(1,'right')):
                    selected=(repair['requests'][:,1]==index)&(repair['requests'][:,2]==side)
                    new=repair['packet'][selected][0]
                    checks[str(index)+'_'+label]=dict(passed=bool(int(new[18])==defect['expected_'+label]),observed=int(new[18]),expected=defect['expected_'+label])
                    require(checks[str(index)+'_'+label]['passed'],'correct native one-sided branch')
                    row=defect[label+'_row']
                    probes[row]=new
                    plan[row,0]=new[0]
        original=load(LATEST/(case+'-current-readout.npz'))['packet']
        original_jet,probe_jet=source_jet(original,case),source_jet(probes,case)
        old=load(ROOT/(case+'-cell-control-frozen.npz'))
        cells=old['cells']
        coefficients,requests=[],[]
        for cell_index,(begin,end,gap,cell) in enumerate(cells):
            gap,cell=int(gap),int(cell)
            interior=(plan[:,1]==gap)&(plan[:,2]==cell)&(plan[:,4]==0)
            if begin==original[gap,0]:
                first,first_time=original_jet[gap,2],begin
            else:
                row=np.flatnonzero((plan[:,1]==gap)&(plan[:,2]==cell)&(plan[:,4]==1))[0]
                first,first_time=probe_jet[row,2],plan[row,0]
            if end==original[gap+1,0]:
                last,last_time=original_jet[gap+1,2],end
            else:
                row=np.flatnonzero((plan[:,1]==gap)&(plan[:,2]==cell)&(plan[:,4]==-1))[0]
                last,last_time=probe_jet[row,2],plan[row,0]
            abscissa=(np.concatenate(([first_time],plan[interior,0],[last_time]))-begin)/(end-begin)
            samples=np.vstack((first,probe_jet[interior,2],last))
            power=np.linalg.solve(np.polynomial.polynomial.polyvander(abscissa,4),samples)
            coefficients.append(power)
            for fraction in (1/6,5/6):
                requests.append((begin+fraction*(end-begin),cell_index,fraction))
        coefficients,requests=np.array(coefficients),np.array(requests)
        prediction=np.array([np.polynomial.polynomial.polyval(row[2],coefficients[int(row[1])]) for row in requests])
        np.savez_compressed(ROOT/(case+'-corner-safe-control-frozen.npz'),cells=cells,power=coefficients,bernstein=np.array([bernstein_coefficients(row) for row in coefficients]),requests=requests,prediction=prediction)
        inputs={str(ROOT/(case+'-probe-readout.npz')):digest(ROOT/(case+'-probe-readout.npz')),str(ROOT/'corner-repair-diagnosis.json'):digest(ROOT/'corner-repair-diagnosis.json')}
        if defects:
            inputs[str(ROOT/(case+'-corner-repair-readout.npz'))]=digest(ROOT/(case+'-corner-repair-readout.npz'))
        write(case+'-corner-safe-control-freeze.json',dict(passed=True,checks=checks,sha256=digest(ROOT/(case+'-corner-safe-control-frozen.npz')),source_inputs=inputs,new_targets_loaded=False,new_sixth_probes=len(requests),repaired_corners=len(defects),same_original_cells=True,physical_grids_unchanged=True))
        print(json.dumps(dict(case=case,repaired_corners=len(defects),probes=len(requests))),flush=True)
