from support import *
import shutil

with worker('bootstrap'):
    cleanup=read(PREVIOUS/'CLEANUP-VERIFIED.json')
    require(cleanup['passed'] and cleanup['external_checker_exit_verified'],'previous cleanup completed')
    for row in cleanup['workers']:
        require(exited(row['identity'])['exited'],'previous worker exited')
    require(not (ROOT/'native').exists(),'fresh native readout destination')
    copied={}
    seal=read(REST/'closeout.json')
    for relative in read(REST/'native-bootstrap-result.json')['copied_source_hashes']:
        source=NATIVE/relative
        require(digest(source)==seal['artifacts']['native/'+relative.replace('\\','/')]['sha256'],'sealed source')
        destination=ROOT/'native'/relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,destination)
        copied[relative]=digest(source)
    write('native-bootstrap-result.json',dict(completed=True,original=str(NATIVE),copied_source_hashes=copied))
    files={}
    for directory in (PREVIOUS,REST):
        files.update(read(directory/'frozen-inputs.json'))
    for directory,names in (
        (PREVIOUS,['closeout.json','metric_math.py','cold-initial-state.npz','heavy-initial-state.npz','cold-linear-32.npz','cold-linear-64.npz','heavy-linear-32.npz','heavy-linear-64.npz','cold-density-quadratic-32.npz','cold-density-quadratic-64.npz','heavy-density-quadratic-32.npz','heavy-density-quadratic-64.npz','cold-external-response.npz','heavy-external-response.npz','cold-linear-budget.npz','heavy-linear-budget.npz']),
        (REST,['closeout.json','cold-rest-readout.npz','heavy-rest-readout.npz','build_native.py'])):
        seal=read(directory/'closeout.json')
        for name in names:
            path=directory/name
            if name!='closeout.json':
                require(digest(path)==seal['artifacts'][name]['sha256'],'sealed stage input')
            files[str(path)]=digest(path)
    check_hashes(files)
    write('frozen-inputs.json',files)
    print(json.dumps(dict(copied=len(copied),inputs=len(files))),flush=True)
