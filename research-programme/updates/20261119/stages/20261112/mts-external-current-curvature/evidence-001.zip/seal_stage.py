from support import *

with worker('seal-stage'):
    require(read(ROOT/'validation.json')['passed'],'final validation')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'native-build-frozen.json'))
    outcomes=[]
    for path in ROOT.glob('*-start.json'):
        if path.name=='seal-stage-start.json':
            continue
        identity=read(path)
        outcome=exited(identity)
        require(outcome['exited'],'worker exited '+path.name)
        require(read(path.with_name(path.name.replace('-start.json','-end.json')))['state']=='completed','worker completed')
        outcomes.append(dict(receipt=path.name,identity=identity,outcome=outcome))
    build=read(ROOT/'native-build-result.json')
    require(build['state']=='completed' and build['temporary_mapping_removed'],'native build released')
    for row in build['children']:
        require(exited(row['identity'])['exited'],'compiler child exited')
    write('preseal-validation.json',dict(passed=True,workers=outcomes,compiler_children_exited=len(build['children']),temporary_mapping_removed=True,goal_left_paused=True))

artifacts={path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(stage='external-current-curvature',date='2026-11-12',completed=True,previous=str(PREVIOUS),previous_closeout_sha256=digest(PREVIOUS/'closeout.json'),artifacts=artifacts,frozen_inputs=read(ROOT/'frozen-inputs.json'),validation_passed=True,result=read(ROOT/'result.json'),current_curvature_derived=True,continuous_remainder_bound_established=False,next='Control between-epoch density/current variation with integral remainder and saved response gains',goal_left_paused=True,github_action=False,continuing_jobs=[],cleanup_receipt='CLEANUP-VERIFIED.json'))
print(json.dumps(dict(completed=True,artifacts=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'))),flush=True)
