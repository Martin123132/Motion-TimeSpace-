from support import *
import argparse
import numpy as np
from scipy.integrate import solve_ivp

metric=sealed_module('retained_metric',PREVIOUS,'metric_math.py')
parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
case=parser.parse_args().case
with worker(case+'-evolve'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    freeze=read(ROOT/(case+'-coefficient-freeze.json'))
    require(freeze['passed'] and not freeze['coefficients_fitted'],'current coefficient frozen')
    require(exited(read(ROOT/(case+'-capture-start.json')))['exited'],'capture exited')
    check_hashes(freeze['hashes'])
    write(case+'-evolution-code.json',{str(ROOT/name):digest(ROOT/name) for name in ('run_current.py','support.py','PROTOCOL.md')})
    prepared=load(PREVIOUS/(case+'-initial-state.npz'))
    current=load(ROOT/(case+'-frozen-current.npz'))
    require(np.array_equal(current['times'],prepared['times']) and np.array_equal(current['weights'],prepared['weights']),'same preparation')
    background=metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
    norm,elapsed=prepared['norm'],prepared['elapsed']
    initial=prepared['state']/norm
    def derivative(offset,flat):
        guard()
        result=metric.rhs(case,offset,flat.reshape(initial.shape)*norm,prepared,background,'density-quadratic')
        result[:,-1]+=.25*offset**2*current['other_current_second']
        return (result/norm).ravel()
    runs={}
    for steps in (32,64):
        solution=solve_ivp(derivative,(0,float(elapsed[-1])),initial.ravel(),method='DOP853',t_eval=elapsed,rtol=1e-10,atol=1e-12,max_step=float(elapsed[-1])/steps)
        require(solution.success and solution.y.shape==(initial.size,len(elapsed)),'coupled quadratic evolution completed')
        states=solution.y.T.reshape(len(elapsed),*initial.shape)*norm[None,:,:]
        sources=np.array([metric.readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed,states)])
        prediction=prepared['initial_weighted_source']+np.array([metric.weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
        direct=np.array([metric.weighted(prepared['weights'],row) for row in sources])
        arithmetic=abs(prediction-(prepared['initial_weighted_source']+direct-direct[0]))
        force=np.array([metric.metric_force(case,float(offset),state,prepared,background,'density-quadratic') for offset,state in zip(elapsed,states)])
        require(np.isfinite(states).all() and np.isfinite(prediction).all(),'finite prediction')
        filename=case+'-both-quadratic-'+str(steps)+'.npz'
        np.savez_compressed(ROOT/filename,state=states,node_source=sources,prediction=prediction,metric_force=force,arithmetic_difference=arithmetic,elapsed=elapsed,weights=prepared['weights'],steps=steps)
        runs[str(ROOT/filename)]=digest(ROOT/filename)
        print(json.dumps(dict(case=case,steps=steps,evaluations=solution.nfev)),flush=True)
    write(case+'-run-freeze.json',dict(passed=True,hashes=runs,target_values_loaded=False,coefficients_fitted=False,other_density_degree=2,other_current_degree=2,rtol=1e-10,normalized_atol=1e-12))
    check_hashes(read(ROOT/(case+'-evolution-code.json')))
    check_hashes(read(ROOT/'frozen-inputs.json'))
