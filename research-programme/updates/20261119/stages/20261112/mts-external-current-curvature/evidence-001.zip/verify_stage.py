from support import *
import numpy as np

metric=sealed_module('retained_metric',PREVIOUS,'metric_math.py')
with worker('verify-stage'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'native-build-frozen.json'))
    for relative,checksum in read(ROOT/'native-bootstrap-result.json')['copied_source_hashes'].items():
        require(digest(NATIVE/relative)==checksum,'old native source preserved')
        if relative.replace('\\','/')!='fortran/mts_curvature_hook.inc':
            require(digest(ROOT/'native'/relative)==checksum,'evolution source unchanged')
    previous_seal=read(PREVIOUS/'closeout.json')
    for relative,row in previous_seal['artifacts'].items():
        require(digest(PREVIOUS/relative)==row['sha256'],'previous stage preserved '+relative)
    checks={}
    for case in ('cold','heavy'):
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        capture=load(ROOT/(case+'-current-readout.npz'))
        old=load(REST/(case+'-rest-readout.npz'))
        checks[case+'_original_packets']=dict(passed=np.array_equal(capture['packet'][:,:160],old['packet']))
        checks[case+'_original_weights']=dict(passed=np.array_equal(capture['weights'],prepared['weights']))
        checks[case+'_native_current_derivatives']=dict(passed=read(ROOT/(case+'-capture-validation.json'))['passed'])
        check_hashes(read(ROOT/(case+'-capture-code.json')))
        check_hashes(read(ROOT/(case+'-evolution-code.json')))
        check_hashes(read(ROOT/(case+'-coefficient-freeze.json'))['hashes'])
        freeze=read(ROOT/(case+'-run-freeze.json'))
        check_hashes(freeze['hashes'])
        checks[case+'_frozen_not_fitted']=dict(passed=not freeze['target_values_loaded'] and not freeze['coefficients_fitted'])
        background=metric.Background(load(SOURCE/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        for steps in (32,64):
            saved=load(ROOT/(case+'-both-quadratic-'+str(steps)+'.npz'))
            tag=case+'_'+str(steps)
            sources=np.array([metric.readout(case,float(offset),state,prepared,background) for offset,state in zip(saved['elapsed'],saved['state'])])
            prediction=prepared['initial_weighted_source']+np.array([metric.weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
            checks[tag+'_source_reconstruction']=metric.comparison(sources,saved['node_source'],ALGEBRA)
            checks[tag+'_weighted_source']=metric.comparison(prediction,saved['prediction'],ALGEBRA)
            checks[tag+'_initial_state']=metric.comparison(saved['state'][0],prepared['state'],ALGEBRA)
            checks[tag+'_original_clock']=dict(passed=np.array_equal(saved['elapsed'],prepared['elapsed']))
        report=read(ROOT/(case+'-result.json'))
        score=load(ROOT/(case+'-comparison.npz'))
        actual=np.all(abs(score['residual'])+score['numerical_budget']<=GATE*score['reference_scale'][None,:],axis=1)
        checks[case+'_verdict']=dict(passed=actual.tolist()==report['epoch_pass'] and bool(actual.all())==report['numerical_passed'])
        checks[case+'_response_checks']=dict(passed=report['response_passed'] and all(row['passed'] for row in report['response_checks'].values()))
        gain=load(PREVIOUS/(case+'-external-response.npz'))
        envelope=(gain['gain']+gain['gain_refinement'])@score['sampled_initial_curvature_maxima']
        checks[case+'_budget_reconstruction']=metric.comparison(envelope,score['frozen_uniform_envelope'],ALGEBRA)
        checks[case+'_no_uniform_claim']=dict(passed=report['uniform_time_bound_established'] is False)
        checks[case+'_current_boundary_pass']=dict(passed=report['boundary_external_sources']['Q_other']['passed'])
    checks['cold_density_exception_preserved']=dict(passed=read(ROOT/'cold-result.json')['boundary_external_sources']['D_other']['passed'] is False)
    checks['high_precision_identities']=dict(passed=read(ROOT/'independent-identities.json')['passed'])
    checks['no_bytecode']=dict(passed=not any(ROOT.rglob('__pycache__')))
    for script in ROOT.glob('*.py'):
        compile(script.read_text(),str(script),'exec')
    failures={name:row for name,row in checks.items() if not row['passed']}
    write('validation.json',dict(passed=not failures,checks=checks,failed=failures,previous_artifacts_preserved=len(previous_seal['artifacts']),original_native_sources_preserved=110,algebra_gate=ALGEBRA,numerical_gate=GATE,goal_left_paused=True))
    require(not failures,'validation '+str(failures))
    print(json.dumps(dict(passed=True,checks=len(checks),previous_artifacts_preserved=len(previous_seal['artifacts']))),flush=True)
