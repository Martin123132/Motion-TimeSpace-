from support import *
import mpmath as mp

with worker('independent-identities'):
    mp.mp.dps=80
    checks={}
    def check(name,actual,expected):
        relative=abs(actual-expected)/max(abs(expected),mp.mpf('1e-60'))
        checks[name]=dict(relative=float(relative),passed=relative<=mp.mpf(str(ALGEBRA)))
    rate,rate_prime=mp.mpf('.018'),mp.mpf('-.0002')
    scale=lambda offset:mp.exp(rate*offset+rate_prime*offset**2/2)
    flux=lambda offset:mp.mpf('.12')-mp.mpf('.08')*offset+mp.mpf('.17')*offset**2/2
    for power in (1,2):
        expected=mp.mpf('.17')-2*power*rate*mp.mpf('-.08')+(power**2*rate**2-power*rate_prime)*mp.mpf('.12')
        check('weighted_current_'+str(power),mp.diff(lambda offset:flux(offset)/scale(offset)**power,0,2),expected)
    coefficient1,coefficient2=mp.mpf(5)/3,mp.mpf(10)/3
    monopole=lambda offset:mp.mpf('.13')+mp.mpf('.21')*offset
    quadrupole=lambda offset:mp.mpf('-.09')+mp.mpf('.17')*offset
    for am in (mp.mpf('.03'),mp.mpf('.7')):
        speed=lambda offset:1/mp.sqrt(1+(am*scale(offset))**2)
        velocity=speed(0)
        expected=-rate*velocity*(1-velocity**2)*(coefficient1*monopole(0)-coefficient2*quadrupole(0))+velocity*(coefficient1*mp.diff(monopole,0)-coefficient2*mp.diff(quadrupole,0))
        check('massive_dipole_'+str(am),mp.diff(lambda offset:speed(offset)*(coefficient1*monopole(offset)-coefficient2*quadrupole(offset)),0),expected)
    corrected_monopole=lambda offset:mp.mpf('.003')+mp.mpf('.0004')*offset
    corrected_quadrupole=lambda offset:mp.mpf('.005')-mp.mpf('.0006')*offset
    expected=-(2*rate*(coefficient1*monopole(0)-coefficient2*quadrupole(0))+coefficient1*mp.diff(monopole,0)-coefficient2*mp.diff(quadrupole,0))+coefficient1*mp.diff(corrected_monopole,0)-coefficient2*mp.diff(corrected_quadrupole,0)
    check('relativistic_tail_dipole',mp.diff(lambda offset:-scale(offset)**2*(coefficient1*monopole(offset)-coefficient2*quadrupole(offset))+coefficient1*corrected_monopole(offset)-coefficient2*corrected_quadrupole(offset),0),expected)
    velocity=lambda offset:mp.mpf('.4')+mp.mpf('.2')*offset-mp.mpf('.7')*offset**2/2
    perturbation=lambda offset:mp.mpf('.3')-mp.mpf('.1')*offset+mp.mpf('.8')*offset**2/2
    expected=5*(mp.mpf('-.7')*mp.mpf('.3')+2*mp.mpf('.2')*mp.mpf('-.1')+mp.mpf('.4')*mp.mpf('.8'))
    check('scalar_current_curvature',mp.diff(lambda offset:5*velocity(offset)*perturbation(offset),0,2),expected)
    for drag in (mp.mpf('.3'),mp.mpf('50')):
        hubble=lambda offset:mp.mpf('.02')-mp.mpf('.0003')*offset
        pressure=lambda offset:mp.mpf('.00004')+mp.mpf('.00002')*offset
        opacity=lambda offset:drag+mp.mpf('.15')*offset
        ratio=lambda offset:mp.mpf(2)/scale(offset)
        baryon0,photon0=mp.mpf('.3'),mp.mpf('.37')
        slip0=4*baryon0/3-photon0
        baryon_first=-hubble(0)*baryon0+5*pressure(0)-ratio(0)*opacity(0)*slip0
        photon_first=coefficient1*monopole(0)-coefficient2*quadrupole(0)+opacity(0)*slip0
        baryon=lambda offset:baryon0+baryon_first*offset
        photon=lambda offset:photon0+photon_first*offset
        baryon_rhs=lambda offset:-hubble(offset)*baryon(offset)+5*pressure(offset)-ratio(offset)*opacity(offset)*(4*baryon(offset)/3-photon(offset))
        photon_rhs=lambda offset:coefficient1*monopole(offset)-coefficient2*quadrupole(offset)+opacity(offset)*(4*baryon(offset)/3-photon(offset))
        second_separate=mp.diff(baryon_rhs,0)-2*rate*baryon_first+(rate**2-rate_prime)*baryon0+2*(mp.diff(photon_rhs,0)-4*rate*photon_first+(4*rate**2-2*rate_prime)*photon0)
        reduced=lambda offset:(-(hubble(offset)+rate+rate_prime*offset)*baryon(offset)+5*pressure(offset))/scale(offset)+2*(coefficient1*monopole(offset)-coefficient2*quadrupole(offset)-2*(rate+rate_prime*offset)*photon(offset))/scale(offset)**2
        check('paired_collision_cancellation_'+str(drag),mp.diff(reduced,0),second_separate)
    passed=all(row['passed'] for row in checks.values())
    write('independent-identities.json',dict(passed=passed,checks=checks,precision_digits=80,algebra_gate=ALGEBRA))
    require(passed,'independent current identities')
    print(json.dumps(dict(passed=True,checks=len(checks),max_relative=max(row['relative'] for row in checks.values()))),flush=True)
