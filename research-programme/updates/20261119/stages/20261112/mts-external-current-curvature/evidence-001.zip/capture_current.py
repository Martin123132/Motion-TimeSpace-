from support import *
import ast
import numpy as np

maths=retained_module('current_check_math','curvature_math.py')

def finish_capture(case,packet,indices,prepared,output,names,saved):
    comparison=maths.comparison
    old=load(REST/(case+'-rest-readout.npz'))
    require(np.array_equal(packet[:,:160],old['packet']),'all original 160-column packets byte-identical')
    extra=packet[:,160:]
    checks={}
    for mode in range(len(saved['modes'])):
        for column,name in enumerate(saved['names']):
            checks['original_'+str(mode)+'_'+str(name)]=comparison(output[mode,:,names.index(str(name))],saved['values'][mode,:,column])
    checks['supported_regime']=dict(passed=bool(np.all(extra[:,39]==1) and np.all(extra[:,10:12]==0)))
    checks['same_thermal_clock']=comparison(extra[:,30],0,ALGEBRA,scale=1.)
    checks['baryon_rhs']=comparison(extra[:,32],extra[:,17],ALGEBRA)
    checks['photon_rhs']=comparison(extra[:,33],extra[:,19],ALGEBRA)
    checks['massless_neutrino_rhs']=comparison(extra[:,35],extra[:,21],ALGEBRA)
    checks['massive_neutrino_rhs']=comparison(extra[:,28],0,ALGEBRA,scale=float(np.max(extra[:,29])))
    checks['photon_second_two_forms']=comparison(extra[:,34],extra[:,20],ALGEBRA)
    checks['analytic_collision_cancellation']=comparison(extra[:,7],extra[:,1]+extra[:,2],ALGEBRA)
    selected=6 if case=='heavy' else 0
    others=extra[:,:7].copy()
    others[:,selected]=0
    checks['other_current_sum']=comparison(extra[:,8],others.sum(axis=1),ALGEBRA)
    checks['total_current_sum']=comparison(extra[:,9],extra[:,:7].sum(axis=1),ALGEBRA)
    for component in range(1 if case=='cold' else 2):
        offset=20+12*component
        velocity=packet[:,offset+1]
        velocity_prime=packet[:,2]*packet[:,offset+3]
        velocity_second=packet[:,3]*packet[:,offset+3]+packet[:,2]**2*packet[:,offset+5]
        expected=packet[:,14]*(velocity_second*packet[:,offset+7]+2*velocity_prime*packet[:,offset+9]+velocity*packet[:,offset+10])
        checks['scalar_current_second_'+str(component)]=comparison(extra[:,component+5],expected,ALGEBRA)
    np.savez_compressed(ROOT/(case+'-current-readout.npz'),packet=packet,indices=indices,weights=prepared['weights'],component_current_second=extra[:,:7],other_current_second=extra[:,8])
    passed=all(row['passed'] for row in checks.values())
    report=dict(passed=passed,checks=checks,original_packets_byte_identical=True,tight_coupling_rows=int(np.count_nonzero(extra[:,10])),evolved_baryon_pressure_rows=int(np.count_nonzero(extra[:,11])),supported_rows=int(np.count_nonzero(extra[:,39])),tail_momentum_count_range=[float(extra[:,31].min()),float(extra[:,31].max())],max_opacity_derivative_representation_difference=float(np.max(abs(extra[:,15]-extra[:,16]))),target_values_loaded=False,coefficients_fitted=False)
    write(case+'-capture-validation.json',report)
    require(passed,'capture validation '+str({key:value for key,value in checks.items() if not value['passed']}))
    require(np.array_equal(indices[:902],prepared['indices']) and np.array_equal(packet[:902,0],prepared['times']),'same 902 prepared nodes')
    np.savez_compressed(ROOT/(case+'-frozen-current.npz'),other_current_second=extra[:902,8],times=packet[:902,0],indices=indices[:902],weights=prepared['weights'])
    write(case+'-coefficient-freeze.json',dict(passed=True,hashes={str(ROOT/(case+'-frozen-current.npz')):digest(ROOT/(case+'-frozen-current.npz'))},target_values_loaded=False,coefficients_fitted=False))
    check_hashes(read(ROOT/(case+'-capture-code.json')))
    check_hashes(read(ROOT/'frozen-inputs.json'))
    print(json.dumps(dict(case=case,passed=passed,checks=len(checks),maximum_initial_current_curvature=float(np.max(abs(extra[:902,8]))),tail_count_range=report['tail_momentum_count_range'])),flush=True)

source=REST/'capture_rest.py'
require(digest(source)==read(REST/'closeout.json')['artifacts']['capture_rest.py']['sha256'],'sealed original capture driver')
changes=[]

class Adapt(ast.NodeTransformer):
    def visit_Constant(self,node):
        if node.value=='capture_rest.py':
            changes.append('code_name')
            return ast.Constant('capture_current.py')
        if node.value==160:
            changes.append('packet_width')
            return ast.Constant(224)
        return node

    def visit_Attribute(self,node):
        if node.attr=='mts_rest_copy':
            node.attr='mts_current_copy'
            changes.append('export')
        return self.generic_visit(node)

    def visit_Try(self,node):
        positions=[index for index,statement in enumerate(node.body) if isinstance(statement,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='terms' for target in statement.targets)]
        if positions:
            require(len(positions)==1,'one capture boundary')
            node.body=node.body[:positions[0]]+ast.parse('finish_capture(case,packet,indices,prepared,output,names,saved)').body
            changes.append('current_validation')
        return self.generic_visit(node)

tree=Adapt().visit(ast.parse(source.read_text()))
require(sorted(changes)==sorted(['code_name','export','current_validation','packet_width']),'bounded capture adaptation '+str(changes))
namespace=dict(__file__=__file__,__name__='current_capture',finish_capture=finish_capture)
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
