from support import *

source=REST/'build_native.py'
require(digest(source)==read(REST/'closeout.json')['artifacts']['build_native.py']['sha256'],'sealed serial readout builder')
exec(compile(source.read_text(),str(source),'exec'),globals())
