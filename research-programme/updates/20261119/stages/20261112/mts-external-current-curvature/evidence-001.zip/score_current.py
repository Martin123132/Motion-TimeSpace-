from support import *
import numpy as np

metric=sealed_module('retained_metric',PREVIOUS,'metric_math.py')
comparison,weighted=metric.comparison,metric.weighted

with worker('score-current'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    reports={}
    for case in ('cold','heavy'):
        freeze=read(ROOT/(case+'-run-freeze.json'))
        require(freeze['passed'] and not freeze['target_values_loaded'] and not freeze['coefficients_fitted'],'predictions frozen before scoring')
        require(exited(read(ROOT/(case+'-evolve-start.json')))['exited'],'prediction worker exited')
        check_hashes(freeze['hashes'])
        prepared=load(PREVIOUS/(case+'-initial-state.npz'))
        current=load(ROOT/(case+'-frozen-current.npz'))['other_current_second']
        readout=load(ROOT/(case+'-current-readout.npz'))
        packet=readout['packet']
        fine=load(ROOT/(case+'-both-quadratic-64.npz'))
        coarse=load(ROOT/(case+'-both-quadratic-32.npz'))
        linear=load(PREVIOUS/(case+'-linear-64.npz'))
        linear_coarse=load(PREVIOUS/(case+'-linear-32.npz'))
        density=load(PREVIOUS/(case+'-density-quadratic-64.npz'))
        density_coarse=load(PREVIOUS/(case+'-density-quadratic-32.npz'))
        target=load(MIDPOINT/(case+'-tested-readout.npz'))
        expected=target['corrected_readout']
        scale=np.max(abs(expected),axis=0)
        require(np.array_equal(fine['elapsed'],target['current_time']-target['current_time'][0]),'same reporting epochs')
        weights=prepared['weights']
        numerical=np.array([weighted(abs(weights),abs(row)) for row in fine['node_source']-coarse['node_source']])
        linear_numeric=np.array([weighted(abs(weights),abs(row)) for row in linear['node_source']-linear_coarse['node_source']])
        density_numeric=np.array([weighted(abs(weights),abs(row)) for row in density['node_source']-density_coarse['node_source']])
        budget=target['updated_working_budget']+abs(prepared['initial_recapture_difference'])[None,:]+numerical+fine['arithmetic_difference']
        residual=fine['prediction']-expected
        gain=load(PREVIOUS/(case+'-external-response.npz'))
        curvatures=np.column_stack([prepared['other_density_second'],current])
        predicted_channels=np.array([weighted(weights,gain['node_signed_gain'][:,:,channel]*curvatures[:,channel,None]) for channel in (0,1)]).T
        predicted_total=predicted_channels.sum(axis=1)
        actual_total=fine['prediction'][-1]-linear['prediction'][-1]
        actual_current=fine['prediction'][-1]-density['prediction'][-1]
        envelope_channels=np.array([weighted(abs(weights),gain['node_absolute_gain'][:,:,channel]*abs(curvatures[:,channel,None])) for channel in (0,1)]).T
        envelope=envelope_channels.sum(axis=1)
        rounding=64*np.finfo(float).eps*scale
        total_allowance=GATE*envelope+numerical[-1]+linear_numeric[-1]+fine['arithmetic_difference'][-1]+linear['arithmetic_difference'][-1]+rounding
        current_allowance=GATE*envelope_channels[:,1]+numerical[-1]+density_numeric[-1]+fine['arithmetic_difference'][-1]+density['arithmetic_difference'][-1]+rounding
        sampled_maxima=np.max(abs(curvatures),axis=0)
        frozen_uniform_envelope=(gain['gain']+gain['gain_refinement'])@sampled_maxima
        ratios=[float(frozen_uniform_envelope[column]/gain['margin'][column]) if gain['margin'][column]>0 else None for column in range(3)]
        terms=packet[:,96:152].reshape(len(packet),7,8).copy()
        selected=6 if case=='heavy' else 0
        terms[:,selected,:]=0
        others=terms.sum(axis=1)
        boundary=packet[901:]
        native_state=np.column_stack([boundary[:,39:41] if case=='heavy' else boundary[:,63:64],boundary[:,10]])
        external=np.array([metric.other_sources(float(offset),prepared,'density-quadratic')[-1] for offset in fine['elapsed']])
        external[:,1]+=.5*fine['elapsed']**2*current[-1]
        native_external=others[901:][:,[0,3]]
        names=('density','current','pressure')
        raw={name:comparison(fine['prediction'][:,column],expected[:,column]) for column,name in enumerate(names)}
        numeric={name:comparison(abs(residual[:,column])+budget[:,column],0,scale=scale[column]) for column,name in enumerate(names)}
        response_checks={}
        for column,name in enumerate(names):
            response_checks[name+'_total']=dict(error=float(abs(actual_total[column]-predicted_total[column])),allowance=float(total_allowance[column]),passed=bool(abs(actual_total[column]-predicted_total[column])<=total_allowance[column]))
            response_checks[name+'_current']=dict(error=float(abs(actual_current[column]-predicted_channels[column,1])),allowance=float(current_allowance[column]),passed=bool(abs(actual_current[column]-predicted_channels[column,1])<=current_allowance[column]))
            response_checks[name+'_frozen_envelope']=dict(passed=bool(abs(actual_total[column])<=frozen_uniform_envelope[column]+total_allowance[column]))
        boundary_checks={str(column):comparison(fine['state'][:,-1,column],native_state[:,column]) for column in range(native_state.shape[1])}
        boundary_checks['metric_force']=comparison(fine['metric_force'][:,-1],boundary[:,6])
        external_checks={name:comparison(external[:,column],native_external[:,column]) for column,name in enumerate(('D_other','Q_other'))}
        all_saved_maxima=np.array([np.max(abs(others[:,2])),np.max(abs(readout['other_current_second']))])
        all_saved_envelope=(gain['gain']+gain['gain_refinement'])@all_saved_maxima
        np.savez_compressed(ROOT/(case+'-comparison.npz'),residual=residual,numerical_budget=budget,numerical_refinement=numerical,reference_scale=scale,actual_total_correction=actual_total,actual_current_correction=actual_current,predicted_channel_correction=predicted_channels,channel_absolute_envelope=envelope_channels,frozen_uniform_envelope=frozen_uniform_envelope,sampled_initial_curvature_maxima=sampled_maxima,all_saved_curvature_maxima=all_saved_maxima,all_saved_envelope=all_saved_envelope,remaining_linear_margin=gain['margin'],boundary_external_prediction=external,boundary_external_reference=native_external)
        report=dict(completed=True,raw_passed=all(row['passed'] for row in raw.values()),numerical_passed=all(row['passed'] for row in numeric.values()),boundary_passed=all(row['passed'] for row in boundary_checks.values()),response_passed=all(row['passed'] for row in response_checks.values()),raw=raw,residual_plus_numerical_allowance=numeric,boundary=boundary_checks,boundary_external_sources=external_checks,response_checks=response_checks,final_prediction=fine['prediction'][-1].tolist(),actual_total_correction=actual_total.tolist(),actual_current_correction=actual_current.tolist(),predicted_channel_corrections=predicted_channels.tolist(),sampled_initial_curvature_maxima=sampled_maxima.tolist(),all_saved_curvature_maxima=all_saved_maxima.tolist(),frozen_uniform_envelope=frozen_uniform_envelope.tolist(),frozen_envelope_fraction_of_saved_margin=ratios,frozen_envelope_within_saved_margin=bool(np.all(frozen_uniform_envelope<=gain['margin'])),epoch_pass=np.all(abs(residual)+budget<=GATE*scale[None,:],axis=1).tolist(),current_curvature_derived=True,uniform_time_bound_established=False,remaining_issue='Uniform-in-time remainder control; frozen quadratic effect is tested, sampled maxima are not continuous bounds',original_bank_grids_tolerances_unchanged=True,goal_left_paused=True)
        write(case+'-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,raw={name:row['relative'] for name,row in raw.items()},numeric={name:row['relative'] for name,row in numeric.items()},boundary=report['boundary_passed'],external=external_checks,response=report['response_passed'],curvature_maxima=sampled_maxima.tolist(),budget_fraction=ratios,actual_current_correction=actual_current.tolist(),response_failures={name:row for name,row in response_checks.items() if not row['passed']})),flush=True)
    require(all(row['response_passed'] for row in reports.values()),'independent response checks')
    write('result.json',dict(completed=True,paired_numerical_passed=all(row['numerical_passed'] for row in reports.values()),paired_boundary_passed=all(row['boundary_passed'] for row in reports.values()),paired_frozen_curvature_budget_passed=all(row['frozen_envelope_within_saved_margin'] for row in reports.values()),uniform_time_bound_established=False,goal_left_paused=True))
    check_hashes(read(ROOT/'frozen-inputs.json'))
