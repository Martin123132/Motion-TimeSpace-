import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-equation-curvature-20261112'
NATIVE_STAGE = POST / 'mts-native-right-edge-memory-20261111'
MIDPOINT = POST / 'mts-boundary-midpoint-check-20261112'
MATCH = POST / 'mts-canonical-matching-state-20261111'
EXPECTED = 'ec18109a4b5cf4a07654e406ef2bc34c1d41fe4211caa5b96ca9d28537a97c4f'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()

if digest(PREVIOUS/'closeout.json') != EXPECTED:
    raise ValueError('Previous checkpoint changed')
previous_seal = json.loads((PREVIOUS/'closeout.json').read_text())
native_seal = json.loads((NATIVE_STAGE/'closeout.json').read_text())
if digest(NATIVE_STAGE/'support.py') != native_seal['artifacts']['support.py']['sha256']:
    raise ValueError('Retained support changed')
spec = importlib.util.spec_from_file_location('retained_support',NATIVE_STAGE/'support.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT,base.PREVIOUS = ROOT,PREVIOUS
NATIVE = PREVIOUS/'native'
EARLY,SPECTRUM,BRANCH,MATCHING = base.EARLY,base.SPECTRUM,base.BRANCH,base.MATCHING
require,read,write,guard = base.require,base.read,base.write,base.guard
worker,exited,check_hashes = base.worker,base.exited,base.check_hashes
comparison,GATE,ALGEBRA = base.comparison,base.GATE,base.ALGEBRA
os,sys,time,psutil = base.os,base.sys,base.time,base.psutil

def load(path):
    import numpy as np
    with np.load(path,allow_pickle=False) as packet:
        return {name:packet[name].copy() for name in packet.files}
