from support import *
import numpy as np
from curvature_math import comparison

with worker('score-integrated'):
    freeze=read(ROOT/'integrated-freeze.json')
    require(freeze['numerical_checks_passed'] and not freeze['target_readout_loaded'] and not freeze['coefficients_fitted'],'valid precomparison freeze')
    require(exited(read(ROOT/'freeze-integrated-start.json'))['exited'],'freeze worker exited')
    check_hashes(read(ROOT/'integrated-frozen-inputs.json'))
    results={}
    for case in ('cold','heavy'):
        frozen=load(ROOT/(case+'-integrated-frozen.npz'))
        target_path=MIDPOINT/(case+'-tested-readout.npz')
        require(digest(target_path)==read(MIDPOINT/'closeout.json')['artifacts'][target_path.name]['sha256'],'sealed target')
        target=load(target_path)
        expected=target['corrected_readout']
        elapsed=frozen['elapsed']
        require(np.array_equal(elapsed,target['current_time']-target['current_time'][0]),'unchanged reporting grid')
        prior_budget=target['updated_working_budget']+abs(frozen['initial_recapture_difference'])[None,:]+elapsed[:,None]*abs(frozen['rate_replay_difference'])[None,:]+.5*elapsed[:,None]**2*abs(frozen['sum_roundoff'])[None,:]
        integration_budget=frozen['quadrature_error']+frozen['direct_identity_error']+frozen['coefficient_allowance']
        total_budget=prior_budget+integration_budget+frozen['remainder_allowance']
        residual=frozen['prediction']-expected
        scale=np.max(abs(expected),axis=0)
        checks={name:comparison(frozen['prediction'][:,column],expected[:,column]) for column,name in enumerate(('density','current','pressure'))}
        allowances={name:comparison(abs(residual[:,column])+total_budget[:,column],0,scale=scale[column]) for column,name in enumerate(('density','current','pressure'))}
        refinement={name:comparison(frozen['remainder_discrepancy'][:,column],0,scale=scale[column]) for column,name in enumerate(('density','current','pressure'))}
        diagnostics={str(count):{name:comparison(frozen['variation_prediction'+str(count)][:,column],expected[:,column]) for column,name in enumerate(('density','current','pressure'))} for count in (6,8)}
        epoch_pass=np.all(abs(residual)+total_budget<=GATE*scale[None,:],axis=1)
        passed=all(row['passed'] for group in (checks,allowances,refinement) for row in group.values())
        report=dict(passed=passed,residual=checks,residual_plus_working_allowance=allowances,remainder_refinement=refinement,epoch_pass=epoch_pass.tolist(),final_prediction=frozen['prediction'][-1].tolist(),final_residual=residual[-1].tolist(),final_budget=total_budget[-1].tolist(),remainder_variation_diagnostics=diagnostics,diagnostics_not_promoted=True,certified_bound=False,target_path=str(target_path),target_sha256=digest(target_path),goal_left_paused=True)
        write(case+'-integrated-result.json',report)
        results[case]=report
        print(json.dumps(dict(case=case,**report)),flush=True)
    write('result.json',dict(completed=True,paired_primary_passed=all(row['passed'] for row in results.values()),target_read_after_freeze=True,tolerances_unchanged=True,goal_left_paused=True))
