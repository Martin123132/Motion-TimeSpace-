from support import *
from datetime import datetime,timezone
import numpy as np
from curvature_math import comparison

with worker('verify-seal'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    check_hashes(read(ROOT/'integrated-frozen-inputs.json'))
    build=read(ROOT/'native-build-result.json')
    check_hashes(build['source_hashes'])
    require(build['temporary_mapping_removed'],'temporary mapping removed')
    require(all(exited(row['identity'])['exited'] for row in build['children']),'compiler children exited')
    for relative,checksum in read(ROOT/'native-bootstrap-result.json')['copied_source_hashes'].items():
        require(digest(NATIVE/relative)==checksum,'previous native source intact')
        if relative.replace('\\','/') not in ('fortran/camb_python.f90','fortran/mts_curvature_hook.inc'):
            require(digest(ROOT/'native'/relative)==checksum,'native dynamics unchanged')
    freeze=read(ROOT/'integrated-freeze.json')
    require(freeze['numerical_checks_passed'] and not freeze['target_readout_loaded'] and not freeze['coefficients_fitted'],'frozen provenance')
    controls={}
    for case in ('cold','heavy'):
        for suffix in ('-frozen-code.json','-remainder-frozen-code.json'):
            check_hashes(read(ROOT/(case+suffix)))
        require(read(ROOT/(case+'-prediction-freeze.json'))['passed'],'native preparation checks')
        require(read(ROOT/(case+'-remainder-readout-validation.json'))['passed'],'reference parity checks')
        for suffix in ('-owner-release.json','-remainder-owner-release.json'):
            require(read(ROOT/(case+suffix))['cleared'],'native owner released')
        frozen=load(ROOT/(case+'-integrated-frozen.npz'))
        report=read(ROOT/(case+'-integrated-result.json'))
        require(digest(report['target_path'])==report['target_sha256'],'target unchanged')
        target=load(report['target_path'])
        elapsed=frozen['elapsed']
        reconstructed=frozen['initial']+elapsed[:,None]*frozen['first_rate']+.5*elapsed[:,None]**2*frozen['remainder']+frozen['correction']
        controls[case+'_reconstruction']=dict(passed=bool(np.array_equal(reconstructed,frozen['prediction'])))
        expected=target['corrected_readout']
        scale=np.max(abs(expected),axis=0)
        budget=target['updated_working_budget']+abs(frozen['initial_recapture_difference'])[None,:]+elapsed[:,None]*abs(frozen['rate_replay_difference'])[None,:]+.5*elapsed[:,None]**2*abs(frozen['sum_roundoff'])[None,:]+frozen['quadrature_error']+frozen['direct_identity_error']+frozen['coefficient_allowance']+frozen['remainder_allowance']
        epochs=np.all(abs(reconstructed-expected)+budget<=GATE*scale[None,:],axis=1)
        controls[case+'_epoch_verdict']=dict(passed=epochs.tolist()==report['epoch_pass'])
        calculated=all(row['passed'] for group in ('residual','residual_plus_working_allowance','remainder_refinement') for row in report[group].values())
        controls[case+'_primary_verdict']=dict(passed=calculated==report['passed'])
        controls[case+'_raw_sources_pass']=dict(passed=all(row['passed'] for row in report['residual'].values()))
        diagnostic=read(ROOT/(case+'-remainder-integral-result.json'))
        calculated=all(row['passed'] for row in diagnostic['reference_conditioned_checks'].values())
        controls[case+'_diagnostic_verdict']=dict(passed=calculated==diagnostic['reference_conditioned_passed'])
    require(read(ROOT/'cold-integrated-result.json')['passed'] and not read(ROOT/'heavy-integrated-result.json')['passed'],'retain failed heavy uncertainty gate')
    require(not read(ROOT/'result.json')['paired_primary_passed'],'no paired promotion')
    integral=read(ROOT/'remainder-integral-validation.json')
    require(integral['passed'] and all(row['passed'] for row in integral['polynomial_checks'].values()),'exact integral controls passed')
    require(not integral['paired_reference_conditioned_passed'],'retain failed reference uncertainty gate')
    workers=[]
    for path in ROOT.glob('*-start.json'):
        if path.name=='verify-seal-start.json':
            continue
        identity=read(path)
        require(exited(identity)['exited'],'worker exited')
        end=read(ROOT/path.name.replace('-start.json','-end.json'))
        if path.name=='remainder-integral-start.json':
            require(end['state']=='failed' and 'AttributeError' in end['error'],'preserved known plumbing failure')
        else:
            require(end['state']=='completed','completed stage worker')
        workers.append(path.name)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(),str(path),'exec')
    require(not list(ROOT.rglob('__pycache__')),'no Python caches')
    require(all(row['passed'] for row in controls.values()),'independent validation')
    write('validation.json',dict(passed=True,checks=controls,raw_paired_sources_pass=True,paired_uncertainty_pass=False,diagnostic_uncertainty_pass=False,preserved_failed_worker='remainder-integral',prior_workers_exited=workers,goal_left_paused=True))
artifacts={path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(state='complete',utc=datetime.now(timezone.utc).isoformat(),artifacts=artifacts,input_hashes=read(ROOT/'frozen-inputs.json'),previous_closeout_sha256=EXPECTED,accepted='integrated defect correction, raw paired source discrepancies within unchanged gate',unresolved='remainder variation uncertainty under cancellation',not_promoted='paired prediction error allowance',next='coherent primitive-pair short prediction with live scalar self-gravity and frozen rest expansion',goal_left_paused=True))
print(json.dumps(dict(sealed=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'),validation_passed=True)),flush=True)
