import math
import numpy as np


def weighted(weights, values):
    return np.array([math.fsum(float(weight) * float(value) for weight, value in zip(weights, values[:, column])) for column in range(values.shape[1])])


def field_sources(packet, density0, component=1):
    scale, rate, rate_prime, hubble, hubble_prime, force, force_prime = packet[:, 1:8].T
    wave = packet[:, 14]
    field, velocity, field_n, velocity_n, field_nn, velocity_nn, mass2, perturbation, speed, perturbation_prime, speed_prime, omega = packet[:, 20+12*component:32+12*component].T
    beta = scale / density0
    field_prime, velocity_prime = rate * field_n, rate * velocity_n
    field_second = rate_prime * field_n + rate**2 * field_nn
    velocity_second = rate_prime * velocity_n + rate**2 * velocity_nn
    perturbation_second = speed_prime
    speed_second = -2*hubble_prime*speed - 2*hubble*speed_prime - 2*rate*mass2*perturbation - (mass2+wave**2)*perturbation_prime - wave*(force_prime*velocity+force*velocity_prime)
    mass_prime = 2*rate*mass2
    mass_second = (2*rate_prime+4*rate**2)*mass2
    kinetic = velocity*speed
    kinetic_prime = velocity_prime*speed+velocity*speed_prime
    kinetic_second = velocity_second*speed+2*velocity_prime*speed_prime+velocity*speed_second
    potential = mass2*field*perturbation
    potential_prime = mass_prime*field*perturbation+mass2*(field_prime*perturbation+field*perturbation_prime)
    potential_second = mass_second*field*perturbation+2*mass_prime*(field_prime*perturbation+field*perturbation_prime)+mass2*(field_second*perturbation+2*field_prime*perturbation_prime+field*perturbation_second)
    current = wave*velocity*perturbation
    current_prime = wave*(velocity_prime*perturbation+velocity*perturbation_prime)
    current_second = wave*(velocity_second*perturbation+2*velocity_prime*perturbation_prime+velocity*perturbation_second)
    bare = np.column_stack([kinetic+potential,current,kinetic-potential])
    bare_prime = np.column_stack([kinetic_prime+potential_prime,current_prime,kinetic_prime-potential_prime])
    bare_second = np.column_stack([kinetic_second+potential_second,current_second,kinetic_second-potential_second])
    source = beta[:,None]*bare
    first = beta[:,None]*(bare_prime+rate[:,None]*bare)
    second = beta[:,None]*(bare_second+2*rate[:,None]*bare_prime+(rate_prime+rate**2)[:,None]*bare)
    background = np.column_stack([field,velocity])
    background_prime = np.column_stack([field_prime,velocity_prime])
    background_second = np.column_stack([field_second,velocity_second])
    pert = np.column_stack([perturbation,speed])
    pert_prime = np.column_stack([perturbation_prime,speed_prime])
    pert_second = np.column_stack([perturbation_second,speed_second])
    outer = lambda left,right: np.einsum('ni,nj->nij',left,right).reshape(-1,4)
    moment = beta[:,None]*outer(background,pert)
    moment_prime = rate[:,None]*moment+beta[:,None]*(outer(background_prime,pert)+outer(background,pert_prime))
    moment_second = (rate_prime+rate**2)[:,None]*moment+2*rate[:,None]*beta[:,None]*(outer(background_prime,pert)+outer(background,pert_prime))+beta[:,None]*(outer(background_second,pert)+2*outer(background_prime,pert_prime)+outer(background,pert_second))
    operator = np.zeros((len(packet),3,4))
    operator[:,0,0],operator[:,0,3] = mass2,1
    operator[:,1,2] = wave
    operator[:,2,0],operator[:,2,3] = -mass2,1
    operator_prime = np.zeros_like(operator)
    operator_prime[:,0,0],operator_prime[:,2,0] = mass_prime,-mass_prime
    operator_second = np.zeros_like(operator)
    operator_second[:,0,0],operator_second[:,2,0] = mass_second,-mass_second
    tensor_second = np.einsum('nij,nj->ni',operator_second,moment)+2*np.einsum('nij,nj->ni',operator_prime,moment_prime)+np.einsum('nij,nj->ni',operator,moment_second)
    return dict(source=source,first=first,second=second,tensor_second=tensor_second,field_prime=field_prime,velocity_prime=velocity_prime,field_second=field_second,velocity_second=velocity_second,perturbation_second=perturbation_second,speed_second=speed_second)


def comparison(actual, expected, tolerance=2e-5, scale=None):
    error = float(np.max(abs(np.asarray(actual)-expected)))
    scale = float(np.max(abs(expected))) if scale is None else float(scale)
    return dict(error=error,scale=scale,relative=error/scale if scale else None,tolerance=tolerance,passed=bool(error<=tolerance*scale))
