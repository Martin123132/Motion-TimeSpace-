from support import *
import ast
import numpy as np


def finish_reference(case,packet,checks):
    original=load(ROOT/(case+'-curvature-readout.npz'))['packet']
    checks['original902_unchanged']=dict(passed=bool(np.array_equal(packet[:902],original)))
    passed=all(row['passed'] for row in checks.values())
    write(case+'-remainder-readout-validation.json',dict(passed=passed,checks=checks,reference_only=True,original_reporting_grid=True))
    require(passed,'reference readout validation')
    print(json.dumps(dict(case=case,reference_readout=True,rows=len(packet),checks=len(checks),passed=passed)),flush=True)


source=PREVIOUS/'capture_curvature.py'
require(digest(source)==previous_seal['artifacts'][source.name]['sha256'],'sealed capture driver')
changes=[]

class Adapt(ast.NodeTransformer):
    def visit_Constant(self,node):
        replacements={'-capture-freeze':'-remainder-capture','-frozen-code.json':'-remainder-frozen-code.json','-native-status.json':'-remainder-status.json','-curvature-readout.npz':'-remainder-readout.npz','-owner-release.json':'-remainder-owner-release.json','capture_curvature.py':'capture_remainder.py',2893:2901}
        if node.value in replacements:
            changes.append(str(node.value))
            return ast.Constant(replacements[node.value])
        return node

    def visit_Assign(self,node):
        if isinstance(node.targets[0],ast.Tuple) and ast.unparse(node.targets[0])=='(indices, weights)':
            changes.append('extended_indices')
            return ast.parse("indices,weights=np.arange(1991,2901),matching['weights']").body[0]
        return self.generic_visit(node)

    def visit_Try(self,node):
        cutoff=next((index for index,child in enumerate(node.body) if isinstance(child,ast.Assign) and isinstance(child.targets[0],ast.Name) and child.targets[0].id=='cold'),None)
        if cutoff is not None:
            node.body=node.body[:cutoff]+ast.parse('finish_reference(case,packet,checks)').body
            changes.append('readout_only')
        return self.generic_visit(node)

tree=Adapt().visit(ast.parse(source.read_text()))
require(changes.count('extended_indices')==1 and changes.count('readout_only')==1,'bounded reference adapter')
namespace=dict(__file__=__file__,__name__='remainder_capture',finish_reference=finish_reference)
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
namespace['main']()
