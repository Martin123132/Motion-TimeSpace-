from support import *
import numpy as np
from curvature_math import field_sources,weighted,comparison
from integrated_math import Background,coefficients,integrate_defects


def main():
    with worker('freeze-integrated'):
        check_hashes(read(ROOT/'frozen-inputs.json'))
        rate_math=POST/'mts-memory-source-rate-20261112/source_rate_math.py'
        rate_seal=read(rate_math.parent/'closeout.json')
        require(digest(rate_math)==rate_seal['artifacts'][rate_math.name]['sha256'],'retained derivative controls')
        specification=importlib.util.spec_from_file_location('rate_math',rate_math)
        derivative_tools=importlib.util.module_from_spec(specification)
        specification.loader.exec_module(derivative_tools)
        checks={}
        metadata={}
        paths=[ROOT/name for name in ('support.py','PROTOCOL.md','integrated_math.py','curvature_math.py','freeze_integrated.py','score_integrated.py')]
        paths+=[rate_math]
        density0=float(load(MATCH/'matching-state.npz')['density0'])
        for case in ('cold','heavy'):
            require(read(ROOT/(case+'-prediction-freeze.json'))['passed'],'native derivative readout passed')
            packet=load(ROOT/(case+'-curvature-readout.npz'))
            original=load(PREVIOUS/(case+'-curvature-readout.npz'))
            require(all(np.array_equal(packet[name],original[name]) for name in packet),'readout byte values unchanged')
            prior=load(PREVIOUS/(case+'-frozen-prediction.npz'))
            values,weights=packet['packet'],packet['weights']
            times=values[:,0]
            elapsed=prior['elapsed']
            background=Background(load(ROOT/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
            initial=background.evaluate(times)
            for name,column in (('scale',1),('rate',2),('rate_prime',3),('hubble',4),('hubble_prime',5)):
                checks[case+'_'+name]=comparison(initial[name],values[:,column],ALGEBRA)
            correction8=np.zeros((len(elapsed),3))
            correction16=np.zeros_like(correction8)
            correction_linear=np.zeros_like(correction8)
            direct_error=np.zeros_like(correction8)
            quadrature_error=np.zeros_like(correction8)
            if case=='heavy':
                sources=field_sources(values,density0)
                coefficient=coefficients(values,density0,sources)
                defect_curvature=np.einsum('nij,ni->nj',coefficient[:,0],initial['defect_prime'])
                remainder=sources['second']-defect_curvature
                boundaries=background.boundaries(float(times[0]),float(times[-1]+elapsed[-1]))
                for epoch,offset in enumerate(elapsed):
                    guard()
                    coarse,direct_coarse,segments=integrate_defects(background,times,float(offset),coefficient,2,8,boundaries)
                    fine,direct_fine,unused=integrate_defects(background,times,float(offset),coefficient,2,16,boundaries)
                    linear,direct_linear,unused=integrate_defects(background,times,float(offset),coefficient,1,16,boundaries)
                    correction8[epoch]=weighted(weights,coarse)
                    correction16[epoch]=weighted(weights,fine)
                    correction_linear[epoch]=weighted(weights,linear)
                    quadrature_error[epoch]=weighted(abs(weights),abs(fine-coarse))
                    direct_error[epoch]=weighted(abs(weights),abs(fine-direct_fine))
                    for column,name in enumerate(('density','current','pressure')):
                        checks['ibp_'+str(epoch)+'_'+name]=comparison(direct_error[epoch,column],0,ALGEBRA,scale=abs(prior['initial'][column]))
                        checks['quadrature_'+str(epoch)+'_'+name]=comparison(quadrature_error[epoch,column],0,ALGEBRA,scale=abs(prior['initial'][column]))
                    print(json.dumps(dict(case=case,epoch=epoch,segments=segments,correction=correction16[epoch].tolist())),flush=True)
                np.savez_compressed(ROOT/'heavy-integral-nodes.npz',coefficients=coefficient,remainder=remainder,defect_curvature=defect_curvature,boundaries=boundaries)
                checks['remainder_recombines']=comparison(weighted(weights,remainder)+weighted(weights,defect_curvature),prior['second_rate'],ALGEBRA)
            else:
                remainder=prior['node_second']
                boundaries=np.array([])
            remainder_rate=weighted(weights,remainder)
            variation={}
            for count in (6,8):
                stencil=derivative_tools.derivative_matrix(times,count)
                rate=weighted(weights,derivative_tools.differentiate(remainder,stencil))
                variation[count]=elapsed[:,None]**3*rate/6
            frozen_remainder=prior['initial']+elapsed[:,None]*prior['first_rate']+.5*elapsed[:,None]**2*remainder_rate
            predicted=frozen_remainder+correction16
            coarse_prediction=frozen_remainder+correction8
            linear_prediction=frozen_remainder+correction_linear
            coefficient_allowance=abs(correction16-correction_linear)
            remainder_allowance=np.maximum(abs(variation[6]),abs(variation[8]))
            remainder_discrepancy=abs(variation[6]-variation[8])
            for column,name in enumerate(('density','current','pressure')):
                checks[case+'_remainder_derivative_refinement_'+name]=comparison(remainder_discrepancy[:,column],0,GATE,scale=abs(prior['initial'][column]))
            np.savez_compressed(ROOT/(case+'-integrated-frozen.npz'),elapsed=elapsed,initial=prior['initial'],first_rate=prior['first_rate'],remainder=remainder_rate,prediction=predicted,coarse_prediction=coarse_prediction,linear_prediction=linear_prediction,correction=correction16,quadrature_error=quadrature_error,direct_identity_error=direct_error,coefficient_allowance=coefficient_allowance,remainder_allowance=remainder_allowance,remainder_discrepancy=remainder_discrepancy,remainder_variation6=variation[6],remainder_variation8=variation[8],variation_prediction6=predicted+variation[6],variation_prediction8=predicted+variation[8],initial_recapture_difference=prior['initial_recapture_difference'],rate_replay_difference=prior['rate_replay_difference'],sum_roundoff=prior['sum_roundoff'])
            metadata[case]=dict(final_correction=correction16[-1].tolist(),remainder=remainder_rate.tolist(),final_coefficient_allowance=coefficient_allowance[-1].tolist(),final_remainder_allowance=remainder_allowance[-1].tolist(),final_remainder_refinement=remainder_discrepancy[-1].tolist(),maximum_quadrature_error=np.max(quadrature_error,axis=0).tolist(),maximum_identity_error=np.max(direct_error,axis=0).tolist(),original_history_nodes=len(times),integration_boundaries=len(boundaries))
            paths += [ROOT/(case+suffix) for suffix in ('-curvature-readout.npz','-native-clock.npz','-integrated-frozen.npz')]
        write('integrated-frozen-inputs.json',{str(path):digest(path) for path in paths})
        numerical_checks={key:row for key,row in checks.items() if 'remainder_derivative_refinement' not in key}
        require(all(row['passed'] for row in numerical_checks.values()),'background and quadrature checks')
        write('integrated-freeze.json',dict(completed=True,numerical_checks_passed=True,all_refinement_checks_passed=all(row['passed'] for row in checks.values()),checks=checks,metadata=metadata,target_readout_loaded=False,coefficients_fitted=False,primary='integrated defect, quadratic C, fixed initial remainder',variation_predictions_are_diagnostics=True,goal_left_paused=True))
        print(json.dumps(dict(frozen=True,metadata=metadata,failed={key:row for key,row in checks.items() if not row['passed']})),flush=True)


if __name__=='__main__':
    main()
