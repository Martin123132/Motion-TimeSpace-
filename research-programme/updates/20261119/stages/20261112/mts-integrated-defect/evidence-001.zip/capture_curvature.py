from support import *
import ast
import ctypes
import numpy as np


def save_clock(library,case):
    count=ctypes.c_int.in_dll(library,'mts_curv_clock_count').value
    require(count>2,'native clock populated')
    clock=np.zeros((count,2))
    metadata=np.zeros(2)
    constants=np.zeros(20)
    copy=library.mts_curv_clock_copy
    copy.restype=None
    copy.argtypes=[ctypes.c_int]+[ctypes.c_void_p]*3
    copy(count,*[ctypes.c_void_p(value.ctypes.data) for value in (clock,metadata,constants)])
    require(ctypes.c_int.in_dll(library,'mts_curv_status').value==2,'clock export passed')
    require(np.isfinite(clock).all() and np.isfinite(constants).all(),'finite clock')
    np.savez_compressed(ROOT/(case+'-native-clock.npz'),clock=clock,metadata=metadata,constants=constants)


source=PREVIOUS/'capture_curvature.py'
require(digest(source)==previous_seal['artifacts']['capture_curvature.py']['sha256'],'sealed capture driver')
changes=[]

class Adapt(ast.NodeTransformer):
    def visit_Constant(self,node):
        if node.value=='first_rate8':
            changes.append('new_predecessor_rate')
            return ast.Constant('first_rate')
        return node

    def visit_Expr(self,node):
        if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Attribute) and node.value.func.attr=='savez_compressed' and any(isinstance(part,ast.Constant) and part.value=='-curvature-readout.npz' for part in ast.walk(node)):
            changes.append('clock_export')
            return [node,ast.parse('save_clock(library,case)').body[0]]
        return self.generic_visit(node)

tree=Adapt().visit(ast.parse(source.read_text()))
require(changes.count('clock_export')==1 and changes.count('new_predecessor_rate')==2,'bounded capture adaptation')
namespace=dict(__file__=__file__,__name__='clock_capture',save_clock=save_clock)
exec(compile(ast.fix_missing_locations(tree),str(source),'exec'),namespace)
namespace['main']()
