from support import *
import math
import numpy as np
from scipy.interpolate import CubicSpline,PchipInterpolator,PPoly
from curvature_math import field_sources,weighted,comparison
from integrated_math import Background,coefficients


def integral(poly,begin,end):
    divisions=np.concatenate([[begin],poly.x[(poly.x>begin)&(poly.x<end)],[end]])
    result=np.zeros(poly.c.shape[2:])
    degree=len(poly.c)-1
    for left,right in zip(divisions[:-1],divisions[1:]):
        if left==right:
            continue
        slot=min(max(np.searchsorted(poly.x,left,side='right')-1,0),len(poly.x)-2)
        offset=left-poly.x[slot]
        width=right-left
        for power in range(degree+1):
            shifted=np.zeros_like(result)
            for original in range(power,degree+1):
                shifted+=poly.c[degree-original,slot]*math.comb(original,power)*offset**(original-power)
            result+=shifted*((end-left)*width**(power+1)/(power+1)-width**(power+2)/(power+2))
    return result


with worker('remainder-integral-v2'):
    check_hashes(read(ROOT/'integrated-frozen-inputs.json'))
    controls={}
    knots=np.array([0.,.071,.072,.23,.6,1.])
    for degree in range(4):
        polynomial=np.zeros((4,len(knots)-1,1))
        for power in range(degree+1):
            polynomial[3-power,:,0]=math.comb(degree,power)*knots[:-1]**(degree-power)
        representation=PPoly(polynomial,knots,extrapolate=False)
        for begin,end in ((.013,.221),(.071,.8),(.23,.231)):
            expected=end*(end**(degree+1)-begin**(degree+1))/(degree+1)-(end**(degree+2)-begin**(degree+2))/(degree+2)
            controls['polynomial_'+str(degree)+'_'+str(begin)]=comparison(integral(representation,begin,end),expected,ALGEBRA)
    require(all(row['passed'] for row in controls.values()),'local polynomial integral controls')
    reports={}
    density0=float(load(MATCH/'matching-state.npz')['density0'])
    for case in ('cold','heavy'):
        require(read(ROOT/(case+'-remainder-readout-validation.json'))['passed'],'reference capture passed')
        check_hashes(read(ROOT/(case+'-remainder-frozen-code.json')))
        saved=load(ROOT/(case+'-remainder-readout.npz'))
        packet,weights=saved['packet'],saved['weights']
        times=packet[:,0]
        frozen=load(ROOT/(case+'-integrated-frozen.npz'))
        background=Background(load(ROOT/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        geometry=background.evaluate(times)
        if case=='heavy':
            source=field_sources(packet,density0)
            coefficient=coefficients(packet,density0,source)
            remainder=source['second']-np.einsum('nij,ni->nj',coefficient[:,0],geometry['defect_prime'])
        else:
            normalization=read(MATCH/'matching-validation.json')['cold']['normalization']
            remainder=np.column_stack([-5*normalization*packet[:,7],np.zeros((len(times),2))])
        slopes=np.diff(remainder,axis=0)/np.diff(times)[:,None]
        representations=dict(cubic=CubicSpline(times,remainder,bc_type='natural'),pchip=PchipInterpolator(times,remainder),linear=PPoly(np.stack([slopes,remainder[:-1]]),times,extrapolate=False))
        variations={}
        node_variations={}
        for name,poly in representations.items():
            rows=[]
            for elapsed in frozen['elapsed']:
                guard()
                changes=[]
                for node,start in enumerate(times[:902]):
                    finish=start+elapsed
                    require(finish<=times[-1]+8*np.spacing(times[-1]),'no future extrapolation')
                    finish=min(finish,times[-1])
                    changes.append(integral(poly,start,finish)-.5*elapsed**2*remainder[node])
                rows.append(changes)
            node_variations[name]=np.asarray(rows)
            variations[name]=np.array([weighted(weights,row) for row in node_variations[name]])
        envelope=np.maximum(np.array([weighted(abs(weights),abs(row)) for row in node_variations['cubic']-node_variations['linear']]),np.array([weighted(abs(weights),abs(row)) for row in node_variations['cubic']-node_variations['pchip']]))
        reference=load(MIDPOINT/(case+'-tested-readout.npz'))
        expected=reference['corrected_readout']
        scale=np.max(abs(expected),axis=0)
        elapsed=frozen['elapsed']
        base_budget=reference['updated_working_budget']+abs(frozen['initial_recapture_difference'])[None,:]+elapsed[:,None]*abs(frozen['rate_replay_difference'])[None,:]+.5*elapsed[:,None]**2*abs(frozen['sum_roundoff'])[None,:]+frozen['quadrature_error']+frozen['direct_identity_error']+frozen['coefficient_allowance']
        conditioned=abs(frozen['prediction']-expected)+base_budget+abs(variations['cubic'])+envelope
        variation_checks={name:comparison(variations['cubic'][:,column],0,scale=scale[column]) for column,name in enumerate(('density','current','pressure'))}
        envelope_checks={name:comparison(envelope[:,column],0,scale=scale[column]) for column,name in enumerate(('density','current','pressure'))}
        conditioned_checks={name:comparison(conditioned[:,column],0,scale=scale[column]) for column,name in enumerate(('density','current','pressure'))}
        np.savez_compressed(ROOT/(case+'-remainder-integral.npz'),elapsed=elapsed,cubic=variations['cubic'],pchip=variations['pchip'],linear=variations['linear'],representation_envelope=envelope,remainder=remainder,clock=times)
        report=dict(completed=True,final_variations={name:value[-1].tolist() for name,value in variations.items()},final_envelope=envelope[-1].tolist(),variation_checks=variation_checks,representation_checks=envelope_checks,reference_conditioned_checks=conditioned_checks,reference_conditioned_passed=all(row['passed'] for row in conditioned_checks.values()),existing_primary_verdict_unchanged=True,reference_not_prediction=True,certified_bound=False,history_spacing=dict(minimum=float(np.min(np.diff(times[:902]))),maximum=float(np.max(np.diff(times[:902])))))
        write(case+'-remainder-integral-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,**report)),flush=True)
    write('remainder-integral-validation.json',dict(passed=True,polynomial_checks=controls,paired_reference_conditioned_passed=all(row['reference_conditioned_passed'] for row in reports.values()),primary_results_unchanged=True))
