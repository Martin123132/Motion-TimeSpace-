from support import *
import shutil

with worker('bootstrap'):
    require(not (ROOT/'native').exists(),'new private destination')
    copied = {}
    relatives = list(read(PREVIOUS/'native-bootstrap-result.json')['copied_source_hashes'])+['fortran/mts_curvature_hook.inc']
    for relative in relatives:
        source=NATIVE/relative
        require(digest(source)==previous_seal['artifacts']['native/'+relative.replace('\\','/')]['sha256'],'sealed source')
        destination=ROOT/'native'/relative
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(source,destination)
        copied[relative]=digest(source)
    require(digest(PREVIOUS/'curvature_math.py')==previous_seal['artifacts']['curvature_math.py']['sha256'],'sealed mathematics')
    shutil.copy2(PREVIOUS/'curvature_math.py',ROOT/'curvature_math.py')
    write('native-bootstrap-result.json',dict(completed=True,original=str(NATIVE),copied_source_hashes=copied))
    files=[PREVIOUS/name for name in ('closeout.json','capture_curvature.py','curvature_math.py','cold-curvature-readout.npz','heavy-curvature-readout.npz','cold-frozen-prediction.npz','heavy-frozen-prediction.npz')]
    files += [EARLY/'runs/backgrounds'/name for name in ('cold.npz','heavy.npz')]
    files += [MATCH/'matching-state.npz',MATCH/'matching-validation.json',SPECTRUM/'runs/exact-grid/chunk-0384.npz',EARLY/'runs/final-bg8-start/cold.npz',MATCHING/'matching_common.py',POST/'mts-metric-feedback-20261107/observer.dll']
    write('frozen-inputs.json',{str(path):digest(path) for path in files})
    print(json.dumps(dict(copied=len(copied),inputs=len(files))),flush=True)
