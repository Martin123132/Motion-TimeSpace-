import numpy as np
from scipy.interpolate import CubicSpline
from scipy.optimize import brentq


class Background:
    def __init__(self,clock_packet,table):
        self.clock=clock_packet['clock']
        self.minimum,self.spacing=clock_packet['metadata']
        self.constants=clock_packet['constants']
        self.fields=[]
        for suffix,knots in (('s','efold'),('h','heavy_efold')):
            if suffix=='h' and self.constants[5]==0:
                continue
            self.fields.append((CubicSpline(table[knots],table['phi_'+suffix],bc_type='natural'),CubicSpline(table[knots],table['phidot_'+suffix],bc_type='natural')))

    def geometry(self,times):
        times=np.asarray(times)
        position=np.log(times/self.minimum)/self.spacing+1
        index=position.astype(int)-1
        if np.any(index<0) or np.any(index>=len(self.clock)-1):
            raise ValueError('Outside retained thermo interpolation')
        fraction=position-(index+1)
        value,slope=self.clock[index].T
        next_value,next_slope=self.clock[index+1].T
        quadratic=3*(next_value-value)-2*slope-next_slope
        cubic=slope+next_slope+2*(value-next_value)
        scale=(value+fraction*(slope+fraction*(quadratic+fraction*cubic)))*times
        first=slope+fraction*(2*quadratic+3*fraction*cubic)
        second=2*quadratic+6*fraction*cubic
        rate=(scale/times+first/self.spacing)/scale
        rate_prime=(first/self.spacing+second/self.spacing**2)/(times*scale)-rate**2
        return scale,rate,rate_prime

    def evaluate(self,times):
        scale,rate,rate_prime=self.geometry(times)
        efold=np.log(scale)
        constants=self.constants
        density=(constants[0]+constants[1])/scale+(constants[2]+constants[3])/scale**2
        density_prime=-rate*((constants[0]+constants[1])/scale+2*(constants[2]+constants[3])/scale**2)
        for eigen in range(int(constants[4])):
            am=scale*constants[8+eigen]
            if np.any(am<=0) or np.any(am>0.3+70/1399*1.01):
                raise ValueError('Unsupported neutrino background branch')
            am2=am**2
            constant=5/7/np.pi**2
            rho=np.where(am<.01,1+constant*am2,1+am2*(constant+am2*(.01099926669*np.log(am)-.003492416767-.005866275571*am)))
            rho_n=np.where(am<.01,2*constant*am2,2*constant*am2+am2**2*(.01099926669*(4*np.log(am)+1)-4*.003492416767-5*.005866275571*am))
            factor=constants[14+eigen]/scale**2
            density+=factor*rho
            density_prime+=factor*rate*(rho_n-2*rho)
        jets=[]
        for component,(field_spline,velocity_spline) in enumerate(self.fields):
            if np.any(efold<field_spline.x[0]) or np.any(efold>field_spline.x[-1]):
                raise ValueError('Outside original field table')
            field,velocity=field_spline(efold),velocity_spline(efold)
            field_prime,velocity_prime=rate*field_spline(efold,1),rate*velocity_spline(efold,1)
            field_second=rate_prime*field_spline(efold,1)+rate**2*field_spline(efold,2)
            velocity_second=rate_prime*velocity_spline(efold,1)+rate**2*velocity_spline(efold,2)
            mass2=(scale*constants[6+component])**2
            density+=(velocity**2+mass2*field**2)/2
            density_prime+=velocity*velocity_prime+rate*mass2*field**2+mass2*field*field_prime
            jets.append((field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2))
        hubble=np.sqrt(density/3)
        hubble_prime=density_prime/(6*hubble)
        if len(jets)==2:
            field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=jets[1]
            defects=np.stack([field_prime-velocity,velocity_prime+2*hubble*velocity+mass2*field],axis=-1)
            defect_prime=np.stack([field_second-velocity_prime,velocity_second+2*hubble_prime*velocity+2*hubble*velocity_prime+2*rate*mass2*field+mass2*field_prime],axis=-1)
        else:
            defects=np.zeros((*scale.shape,2))
            defect_prime=np.zeros_like(defects)
        return dict(scale=scale,rate=rate,rate_prime=rate_prime,hubble=hubble,hubble_prime=hubble_prime,defects=defects,defect_prime=defect_prime,jets=jets)

    def boundaries(self,begin,end):
        lower,upper=np.log(self.geometry(np.array([begin,end]))[0])
        knots=np.unique(np.concatenate([field.x[(field.x>lower)&(field.x<upper)] for field,velocity in self.fields]))
        roots=[brentq(lambda clock:float(np.log(self.geometry(np.array([clock]))[0][0])-knot),begin,end,xtol=2e-12,rtol=4*np.finfo(float).eps) for knot in knots]
        indices=np.arange(len(self.clock))
        clocks=self.minimum*np.exp(indices*self.spacing)
        return np.unique(np.concatenate([np.asarray(roots),clocks[(clocks>begin)&(clocks<end)]]))


def coefficients(packet,density0,source):
    beta=packet[:,1]/density0
    rate,rate_prime=packet[:,2],packet[:,3]
    wave=packet[:,14]
    mass2,perturbation,speed,perturbation_prime,speed_prime=packet[:,38:43].T
    perturbation_second,speed_second=source['perturbation_second'],source['speed_second']
    result=np.zeros((len(packet),3,2,3))
    for degree,expression in enumerate((perturbation,3*rate*perturbation+perturbation_prime,(3*rate_prime+9*rate**2)*perturbation+6*rate*perturbation_prime+perturbation_second)):
        result[:,degree,0,0]=beta*mass2*expression
        result[:,degree,0,2]=-beta*mass2*expression
    for degree,speed_expression,field_expression in ((0,speed,perturbation),(1,rate*speed+speed_prime,rate*perturbation+perturbation_prime),(2,(rate_prime+rate**2)*speed+2*rate*speed_prime+speed_second,(rate_prime+rate**2)*perturbation+2*rate*perturbation_prime+perturbation_second)):
        result[:,degree,1,0]=beta*speed_expression
        result[:,degree,1,2]=beta*speed_expression
        result[:,degree,1,1]=beta*wave*field_expression
    return result


def integrate_defects(background,times,elapsed,coefficients,degree,order,boundaries):
    result=np.zeros((len(times),3))
    direct=np.zeros_like(result)
    if elapsed==0:
        return result,direct,0
    starts,ends,owners=[],[],[]
    for node,begin in enumerate(times):
        divisions=np.concatenate([[begin],boundaries[(boundaries>begin)&(boundaries<begin+elapsed)],[begin+elapsed]])
        starts.extend(divisions[:-1])
        ends.extend(divisions[1:])
        owners.extend([node]*(len(divisions)-1))
    starts,ends,owners=np.asarray(starts),np.asarray(ends),np.asarray(owners)
    nodes,weights=np.polynomial.legendre.leggauss(order)
    points=((starts+ends)[:,None]+(ends-starts)[:,None]*nodes)/2
    integration_weights=(ends-starts)[:,None]*weights/2
    owner=np.repeat(owners,order)
    absolute=points.ravel()
    offset=absolute-times[owner]
    evaluated=background.evaluate(absolute)
    coefficient=coefficients[owner,0]+offset[:,None,None]*coefficients[owner,1]
    derivative=coefficients[owner,1].copy()
    if degree==2:
        coefficient+=.5*offset[:,None,None]**2*coefficients[owner,2]
        derivative+=offset[:,None,None]*coefficients[owner,2]
    integrand=np.einsum('nij,ni->nj',coefficient-(elapsed-offset)[:,None,None]*derivative,evaluated['defects'])
    direct_integrand=(elapsed-offset)[:,None]*np.einsum('nij,ni->nj',coefficient,evaluated['defect_prime'])
    segment=np.sum(integration_weights[:,:,None]*integrand.reshape(-1,order,3),axis=1)
    direct_segment=np.sum(integration_weights[:,:,None]*direct_integrand.reshape(-1,order,3),axis=1)
    np.add.at(result,owners,segment)
    np.add.at(direct,owners,direct_segment)
    initial=background.evaluate(times)['defects']
    result-=elapsed*np.einsum('nij,ni->nj',coefficients[:,0],initial)
    return result,direct,len(starts)
