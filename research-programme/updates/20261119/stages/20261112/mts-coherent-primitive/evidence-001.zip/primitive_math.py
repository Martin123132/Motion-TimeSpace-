from support import retained_module,require
import math
import numpy as np
from scipy.integrate import solve_ivp

background_math=retained_module('retained_background','integrated_math.py')
source_math=retained_module('retained_curvature','curvature_math.py')
Background=background_math.Background
field_sources=source_math.field_sources
comparison=source_math.comparison
weighted=source_math.weighted


def prepare(case,packet,background,density0,cold_normalization):
    times=packet[:,0]
    wave=packet[:,14]
    initial_background=background.evaluate(times)
    hubble,hubble_prime=initial_background['hubble'],initial_background['hubble_prime']
    rate=initial_background['rate']
    force,force_prime=packet[:,6],packet[:,7]
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=initial_background['jets'][1]
        state=packet[:,39:41].copy()
        perturbation,speed=state.T
        perturbation_prime,speed_prime=packet[:,41:43].T
        source=field_sources(packet,density0)
        beta=initial_background['scale']/density0
        unscaled_density=source['source'][:,0]/beta
        unscaled_density_prime=source['first'][:,0]/beta-rate*unscaled_density
        rest=force-unscaled_density/(2*wave*hubble)
        rest_prime=force_prime-(unscaled_density_prime-unscaled_density*hubble_prime/hubble)/(2*wave*hubble)
        omega=np.sqrt(mass2+wave**2)
        amplitude=np.sqrt(perturbation**2+(speed/omega)**2)
        require(np.all(amplitude>0),'nonzero prepared pair norms')
        norm=np.column_stack([amplitude,omega*amplitude])
        reference_first=np.column_stack([perturbation_prime,speed_prime])
        reference_second=np.column_stack([source['perturbation_second'],source['speed_second']])
        mass_prime=2*rate*mass2
        stiffness=-(mass2+wave**2+velocity*mass2*field/(2*hubble))
        damping=-(2*hubble+velocity**2/(2*hubble))
        stiffness_prime=-mass_prime-(velocity_prime*mass2*field+velocity*mass_prime*field+velocity*mass2*field_prime)/(2*hubble)+velocity*mass2*field*hubble_prime/(2*hubble**2)
        damping_prime=-2*hubble_prime-velocity*velocity_prime/hubble+velocity**2*hubble_prime/(2*hubble**2)
        first=np.column_stack([speed,stiffness*perturbation+damping*speed-wave*velocity*rest])
        second=np.column_stack([first[:,1],stiffness_prime*perturbation+stiffness*first[:,0]+damping_prime*speed+damping*first[:,1]-wave*(velocity_prime*rest+velocity*rest_prime)])
    else:
        state=packet[:,63:64].copy()
        density_factor=background.constants[0]/initial_background['scale']
        density=state[:,0]
        native_first=-wave*force
        rest=force-density_factor*density/(2*wave*hubble)
        rest_prime=force_prime-density_factor*(native_first-(rate+hubble_prime/hubble)*density)/(2*wave*hubble)
        coefficient=-density_factor/(2*hubble)
        coefficient_prime=coefficient*(-rate-hubble_prime/hubble)
        first=(coefficient*density-wave*rest)[:,None]
        second=(coefficient_prime*density+coefficient*first[:,0]-wave*rest_prime)[:,None]
        reference_first=native_first[:,None]
        reference_second=(-wave*force_prime)[:,None]
        norm=abs(state)
        norm[norm==0]=1
    checks={}
    for column in range(state.shape[1]):
        checks['first_'+str(column)]=comparison(first[:,column],reference_first[:,column],1e-10)
        checks['second_'+str(column)]=comparison(second[:,column],reference_second[:,column],1e-10)
    return dict(times=times,wave=wave,state=state,norm=norm,rest=rest,rest_prime=rest_prime,reference_first=reference_first,reference_second=reference_second,checks=checks,density0=density0,cold_normalization=cold_normalization)


def right_hand_side(case,elapsed,state,prepared,background,linear):
    values=background.evaluate(prepared['times']+elapsed)
    hubble=values['hubble']
    rest=prepared['rest']+(elapsed*prepared['rest_prime'] if linear else 0)
    wave=prepared['wave']
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
        perturbation,speed=state.T
        speed_prime=-(mass2+wave**2+velocity*mass2*field/(2*hubble))*perturbation-(2*hubble+velocity**2/(2*hubble))*speed-wave*velocity*rest
        return np.column_stack([speed,speed_prime])
    density_factor=background.constants[0]/values['scale']
    return (-density_factor*state[:,0]/(2*hubble)-wave*rest)[:,None]


def readout(case,elapsed,state,prepared,background):
    if case=='cold':
        return np.column_stack([prepared['cold_normalization']*state[:,0],np.zeros((len(state),2))])
    values=background.evaluate(prepared['times']+elapsed)
    field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
    perturbation,speed=state.T
    beta=values['scale']/prepared['density0']
    kinetic=velocity*speed
    potential=mass2*field*perturbation
    return beta[:,None]*np.column_stack([kinetic+potential,prepared['wave']*velocity*perturbation,kinetic-potential])


def solve(case,prepared,background,elapsed,steps,linear,guard):
    norm=prepared['norm']
    initial=prepared['state']/norm
    def rhs(offset,flat):
        guard()
        return (right_hand_side(case,offset,flat.reshape(initial.shape)*norm,prepared,background,linear)/norm).ravel()
    solution=solve_ivp(rhs,(0,float(elapsed[-1])),initial.ravel(),method='DOP853',t_eval=elapsed,rtol=1e-10,atol=1e-12,max_step=float(elapsed[-1])/steps)
    require(solution.success and solution.y.shape==(initial.size,len(elapsed)),'primitive evolution completed')
    states=solution.y.T.reshape(len(elapsed),*initial.shape)*norm[None,:,:]
    sources=np.array([readout(case,float(offset),state,prepared,background) for offset,state in zip(elapsed,states)])
    require(np.isfinite(states).all() and np.isfinite(sources).all(),'finite primitive evolution')
    return states,sources,solution.nfev
