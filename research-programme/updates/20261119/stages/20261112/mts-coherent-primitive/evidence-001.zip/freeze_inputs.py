from support import *
from primitive_math import *
from scipy.linalg import expm


with worker('freeze-inputs'):
    paths=[ROOT/name for name in ('support.py','PROTOCOL.md','primitive_math.py','freeze_inputs.py','run_primitive.py','score_primitive.py')]
    paths += [PREVIOUS/name for name in ('closeout.json','integrated_math.py','curvature_math.py')]
    paths += [MATCH/'matching-state.npz',MATCH/'matching-validation.json']
    density0=float(load(MATCH/'matching-state.npz')['density0'])
    cold_normalization=read(MATCH/'matching-validation.json')['cold']['normalization']
    checks={}
    cases={}
    for case in ('cold','heavy'):
        filenames=[case+suffix for suffix in ('-curvature-readout.npz','-native-clock.npz','-integrated-frozen.npz')]
        for filename in filenames:
            require(digest(PREVIOUS/filename)==previous_seal['artifacts'][filename]['sha256'],'sealed input')
        packet=load(PREVIOUS/filenames[0])
        previous=load(PREVIOUS/filenames[2])
        background=Background(load(PREVIOUS/filenames[1]),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        prepared=prepare(case,packet['packet'],background,density0,cold_normalization)
        checks.update({case+'_'+name:value for name,value in prepared['checks'].items()})
        require(np.array_equal(packet['indices'],np.arange(1991,2893)),'original902 nodes')
        require(np.array_equal(packet['weights'],load(MATCH/'matching-state.npz')['weights']),'original signed weights')
        for name,column in (('scale',1),('rate',2),('rate_prime',3),('hubble',4),('hubble_prime',5)):
            checks[case+'_'+name]=comparison(background.evaluate(prepared['times'])[name],packet['packet'][:,column],ALGEBRA)
        checks[case+'_rhs_function']=comparison(right_hand_side(case,0,prepared['state'],prepared,background,True),prepared['reference_first'],ALGEBRA)
        checks[case+'_zero_time_rest_control']=comparison(right_hand_side(case,0,prepared['state'],prepared,background,False),prepared['reference_first'],ALGEBRA)
        initial_sources=readout(case,0,prepared['state'],prepared,background)
        numeric={name:value for name,value in prepared.items() if name!='checks'}
        np.savez_compressed(ROOT/(case+'-initial-state.npz'),**numeric,weights=packet['weights'],indices=packet['indices'],elapsed=previous['elapsed'],initial_weighted_source=previous['initial'],node_initial_sources=initial_sources,initial_recapture_difference=weighted(packet['weights'],initial_sources)-previous['initial'])
        cases[case]=dict(node_count=len(packet['indices']),state_components=prepared['state'].shape[1],maximum_rest=float(np.max(abs(prepared['rest']))),maximum_rest_rate=float(np.max(abs(prepared['rest_prime']))),final_elapsed=float(previous['elapsed'][-1]),initial_source_discrepancy=(weighted(packet['weights'],initial_sources)-previous['initial']).tolist())
        paths += [PREVIOUS/filename for filename in filenames]+[EARLY/'runs/backgrounds'/(case+'.npz'),ROOT/(case+'-initial-state.npz')]
    for index,(stiffness,damping) in enumerate(((25.,.03),(.01,2.),(0.,0.))):
        matrix=np.array([[0.,1.,0.,0.],[-stiffness,-damping,.1,.04],[0.,0.,0.,0.],[0.,0.,1.,0.]])
        initial=np.array([.3,-.2,1.,0.])
        times=np.linspace(0,.03,9)
        numerical=solve_ivp(lambda offset,state:matrix@state,(0,.03),initial,method='DOP853',t_eval=times,rtol=1e-10,atol=1e-12,max_step=.03/32)
        exact=np.array([expm(matrix*offset)@initial for offset in times])
        checks['affine_forcing_exponential_'+str(index)]=comparison(numerical.y.T,exact,ALGEBRA)
    require(all(row['passed'] for row in checks.values()),'initial coupled equations and solver controls')
    write('frozen-inputs.json',{str(path):digest(path) for path in paths})
    write('initial-validation.json',dict(passed=True,checks=checks,cases=cases,target_readout_loaded=False,coefficients_fitted=False,primary_rest_degree=1,control_rest_degree=0,subdivisions=[32,64],rtol=1e-10,normalized_atol=1e-12,goal_left_paused=True))
    print(json.dumps(dict(passed=True,checks=len(checks),cases=cases)),flush=True)
