from support import *
from primitive_math import *
from datetime import datetime,timezone

with worker('verify-seal'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    initial=read(ROOT/'initial-validation.json')
    require(initial['passed'] and all(row['passed'] for row in initial['checks'].values()),'initial controls')
    require(not initial['target_readout_loaded'] and not initial['coefficients_fitted'],'frozen initial provenance')
    checks={}
    for case in ('cold','heavy'):
        prepared=load(ROOT/(case+'-initial-state.npz'))
        background=Background(load(PREVIOUS/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        freeze=read(ROOT/(case+'-run-freeze.json'))
        check_hashes(freeze['hashes'])
        require(not freeze['target_readout_loaded'] and not freeze['coefficients_fitted'],'frozen trajectory provenance')
        report=read(ROOT/(case+'-result.json'))
        require(digest(report['target_path'])==report['target_sha256'],'target hash')
        expected=load(report['target_path'])['corrected_readout']
        for label in ('constant','linear'):
            for steps in (32,64):
                key=case+'_'+label+'_'+str(steps)
                saved=load(ROOT/(case+'-'+label+'-'+str(steps)+'.npz'))
                checks[key+'_initial_state']=comparison(saved['state'][0],prepared['state'],ALGEBRA)
                checks[key+'_clock']=dict(passed=bool(np.array_equal(saved['elapsed'],prepared['elapsed'])))
                sources=np.array([readout(case,float(offset),state,prepared,background) for offset,state in zip(saved['elapsed'],saved['state'])])
                checks[key+'_source_reconstruction']=comparison(sources,saved['node_source'],ALGEBRA)
                reconstructed=prepared['initial_weighted_source']+np.array([weighted(prepared['weights'],row) for row in sources-prepared['node_initial_sources'][None,:,:]])
                checks[key+'_weighted_reconstruction']=comparison(reconstructed,saved['prediction'],ALGEBRA)
                require(int(saved['rest_degree'])==int(label=='linear') and int(saved['steps'])==steps,'correct run labels')
        budget=load(ROOT/(case+'-comparison-budget.npz'))
        fine=load(ROOT/(case+'-linear-64.npz'))
        residual=fine['prediction']-expected
        checks[case+'_residual']=comparison(residual,budget['residual'],ALGEBRA)
        for group,field in (('numerical_budget','numerical_epoch_pass'),('stricter_budget','strict_epoch_pass')):
            epochs=np.all(abs(residual)+budget[group]<=GATE*budget['reference_scale'][None,:],axis=1)
            checks[case+'_'+group+'_verdict']=dict(passed=epochs.tolist()==report[field])
        require(report['numerical_passed'] and report['raw_passed'],'paired source/numerical gate')
        response=read(ROOT/(case+'-response-result.json'))
        require(response['passed'] and all(row['passed'] for row in response['checks'].values()),'response/boundary controls')
        require(not response['uniform_bound_established'] and response['final_epoch_only'],'conditional gain scope')
        require(digest(response['reference_path'])==response['reference_sha256'],'boundary reference unchanged')
        gains=load(ROOT/(case+'-response-gain.npz'))
        checks[case+'_gain_sum']=comparison(weighted(abs(prepared['weights']),gains['node_absolute_gain']),gains['gain'],ALGEBRA)
        for column,ceiling in enumerate(response['conditional_uniform_rest_curvature_ceiling']):
            if ceiling is not None:
                checks[case+'_ceiling_'+str(column)]=comparison(ceiling*(gains['gain'][column]+gains['gain_refinement'][column]),gains['numerical_margin'][column],ALGEBRA)
    require(all(row['passed'] for row in checks.values()),'independent reconstruction and verdicts')
    result=read(ROOT/'result.json')
    require(result['paired_raw_passed'] and result['paired_numerical_passed'] and not result['paired_rest_sensitivity_passed'],'honest separated outcomes')
    require(read(ROOT/'response-validation.json')['passed'],'response validation')
    workers=[]
    for path in ROOT.glob('*-start.json'):
        if path.name=='verify-seal-start.json':
            continue
        require(exited(read(path))['exited'],'task worker exited')
        require(read(ROOT/path.name.replace('-start.json','-end.json'))['state']=='completed','worker completed')
        workers.append(path.name)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(),str(path),'exec')
    require(not list(ROOT.rglob('__pycache__')),'no Python caches')
    write('validation.json',dict(passed=True,checks=checks,initial_checks=len(initial['checks']),paired_numerical_passed=True,constant_rest_pressure_failure_retained=True,uniform_rest_curvature_bound_not_claimed=True,prior_workers_exited=workers,goal_left_paused=True))
artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(state='complete',utc=datetime.now(timezone.utc).isoformat(),artifacts=artifacts,input_hashes=read(ROOT/'frozen-inputs.json'),previous_closeout_sha256=EXPECTED,accepted='paired coherent primitive source prediction with stable numerical allowance across eight intervals',control_failure='constant rest omits important heavy pressure response',conditional_result='final-epoch source gain and required rest-curvature ceiling',next='derive/bound rest curvature from retained coupled equations',goal_left_paused=True))
print(json.dumps(dict(sealed=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'),validation_passed=True,checks=len(checks))),flush=True)
