from support import *
from primitive_math import weighted,comparison
import numpy as np

with worker('score-primitive'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    reports={}
    for case in ('cold','heavy'):
        freeze=read(ROOT/(case+'-run-freeze.json'))
        require(freeze['passed'] and not freeze['target_readout_loaded'] and not freeze['coefficients_fitted'],'predictions frozen')
        require(exited(read(ROOT/(case+'-evolve-start.json')))['exited'],'evolution finished before scoring')
        check_hashes(freeze['hashes'])
        target_path=MIDPOINT/(case+'-tested-readout.npz')
        require(digest(target_path)==read(MIDPOINT/'closeout.json')['artifacts'][target_path.name]['sha256'],'sealed comparison')
        target=load(target_path)
        expected=target['corrected_readout']
        scale=np.max(abs(expected),axis=0)
        prepared=load(ROOT/(case+'-initial-state.npz'))
        fine=load(ROOT/(case+'-linear-64.npz'))
        coarse=load(ROOT/(case+'-linear-32.npz'))
        constant=load(ROOT/(case+'-constant-64.npz'))
        constant_coarse=load(ROOT/(case+'-constant-32.npz'))
        require(np.array_equal(fine['elapsed'],target['current_time']-target['current_time'][0]),'original reporting times')
        numerical=np.array([weighted(abs(prepared['weights']),abs(row)) for row in fine['node_source']-coarse['node_source']])
        constant_numerical=np.array([weighted(abs(prepared['weights']),abs(row)) for row in constant['node_source']-constant_coarse['node_source']])
        rest_sensitivity=abs(fine['prediction']-constant['prediction'])
        residual=fine['prediction']-expected
        arithmetic=np.maximum(fine['arithmetic_difference'],constant['arithmetic_difference'])
        numerical_budget=target['updated_working_budget']+abs(prepared['initial_recapture_difference'])[None,:]+numerical+arithmetic
        stricter_budget=numerical_budget+rest_sensitivity+constant_numerical
        names=('density','current','pressure')
        checks={name:comparison(fine['prediction'][:,column],expected[:,column]) for column,name in enumerate(names)}
        numeric={name:comparison(abs(residual[:,column])+numerical_budget[:,column],0,scale=scale[column]) for column,name in enumerate(names)}
        strict={name:comparison(abs(residual[:,column])+stricter_budget[:,column],0,scale=scale[column]) for column,name in enumerate(names)}
        refinement={name:comparison(numerical[:,column],0,scale=scale[column]) for column,name in enumerate(names)}
        constant_checks={name:comparison(constant['prediction'][:,column],expected[:,column]) for column,name in enumerate(names)}
        np.savez_compressed(ROOT/(case+'-comparison-budget.npz'),residual=residual,numerical_refinement=numerical,constant_refinement=constant_numerical,rest_sensitivity=rest_sensitivity,numerical_budget=numerical_budget,stricter_budget=stricter_budget,reference_scale=scale)
        report=dict(completed=True,raw_passed=all(row['passed'] for row in checks.values()),numerical_passed=all(row['passed'] for row in numeric.values()),rest_sensitivity_passed=all(row['passed'] for row in strict.values()),residual=checks,residual_plus_numerical_allowance=numeric,residual_plus_rest_sensitivity_allowance=strict,step_refinement=refinement,constant_rest_control=constant_checks,final_prediction=fine['prediction'][-1].tolist(),final_residual=residual[-1].tolist(),max_rest_sensitivity=np.max(rest_sensitivity,axis=0).tolist(),max_absolute_weighted_refinement=np.max(numerical,axis=0).tolist(),numerical_epoch_pass=np.all(abs(residual)+numerical_budget<=GATE*scale[None,:],axis=1).tolist(),strict_epoch_pass=np.all(abs(residual)+stricter_budget<=GATE*scale[None,:],axis=1).tolist(),target_path=str(target_path),target_sha256=digest(target_path),approximation='linear rest expansion; live scalar/CDM self-gravity',certified_rest_error_bound=False,full_rest_hierarchy_evolved=False,observational_holdout=False,goal_left_paused=True)
        write(case+'-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,**report)),flush=True)
    write('result.json',dict(completed=True,paired_raw_passed=all(row['raw_passed'] for row in reports.values()),paired_numerical_passed=all(row['numerical_passed'] for row in reports.values()),paired_rest_sensitivity_passed=all(row['rest_sensitivity_passed'] for row in reports.values()),tolerances_unchanged=True,goal_left_paused=True))
