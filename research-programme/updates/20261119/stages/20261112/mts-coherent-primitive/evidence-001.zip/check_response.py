from support import *
from primitive_math import *


def matrix_and_force(case,offset,prepared,background):
    values=background.evaluate(prepared['times']+offset)
    norm=prepared['norm']
    count,dimension=norm.shape
    matrix=np.zeros((count,dimension,dimension))
    forcing=np.zeros((count,dimension))
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
        hubble=values['hubble']
        matrix[:,0,1]=norm[:,1]/norm[:,0]
        matrix[:,1,0]=-(mass2+prepared['wave']**2+velocity*mass2*field/(2*hubble))*norm[:,0]/norm[:,1]
        matrix[:,1,1]=-(2*hubble+velocity**2/(2*hubble))
        forcing[:,1]=-prepared['wave']*velocity/norm[:,1]
    else:
        matrix[:,0,0]=-background.constants[0]/values['scale']/(2*values['hubble'])
        forcing[:,0]=-prepared['wave']/norm[:,0]
    return matrix,forcing


def terminal_map(case,offset,prepared,background):
    values=background.evaluate(prepared['times']+offset)
    norm=prepared['norm']
    mapping=np.zeros((len(norm),3,norm.shape[1]))
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=values['jets'][1]
        beta=values['scale']/prepared['density0']
        mapping[:,0,0],mapping[:,0,1]=beta*mass2*field,beta*velocity
        mapping[:,1,0]=beta*prepared['wave']*velocity
        mapping[:,2,0],mapping[:,2,1]=-beta*mass2*field,beta*velocity
    else:
        mapping[:,0,0]=prepared['cold_normalization']
    return mapping*norm[:,None,:]


def adjoint(case,prepared,background,steps):
    duration=float(prepared['elapsed'][-1])
    count,dimension=prepared['norm'].shape
    mapping=terminal_map(case,duration,prepared,background)
    map_scale=np.max(abs(mapping),axis=2)
    map_scale[map_scale==0]=1
    initial=np.zeros((count,3,dimension+2))
    initial[:,:,:dimension]=mapping/map_scale[:,:,None]
    geometry=background.evaluate(prepared['times'])
    if case=='heavy':
        field,velocity,field_prime,velocity_prime,field_second,velocity_second,mass2=geometry['jets'][1]
        forcing_scale=prepared['wave']*np.sqrt(velocity**2+mass2*field**2)/prepared['norm'][:,1]
    else:
        forcing_scale=abs(prepared['wave']/prepared['norm'][:,0])
    require(np.all(forcing_scale>0),'response normalization')
    def rhs(fraction,flat):
        guard()
        state=flat.reshape(initial.shape)
        matrix,forcing=matrix_and_force(case,duration*fraction,prepared,background)
        result=np.zeros_like(state)
        result[:,:,:dimension]=-duration*np.einsum('nji,ncj->nci',matrix,state[:,:,:dimension])
        projection=np.einsum('nci,ni->nc',state[:,:,:dimension],forcing)/forcing_scale[:,None]
        result[:,:,dimension]=-.5*fraction**2*abs(projection)
        result[:,:,dimension+1]=-.5*fraction**2*projection
        return result.ravel()
    solution=solve_ivp(rhs,(1.,0.),initial.ravel(),method='DOP853',rtol=1e-10,atol=1e-12,max_step=1/steps)
    require(solution.success,'adjoint integration')
    final=solution.y[:,-1].reshape(initial.shape)
    factor=map_scale*forcing_scale[:,None]*duration**3
    absolute_gain=final[:,:,dimension]*factor
    signed_gain=final[:,:,dimension+1]*factor
    require(np.min(absolute_gain)>=0,'nonnegative gain')
    def forward_rhs(fraction,flat):
        guard()
        state=flat.reshape(count,dimension)
        matrix,forcing=matrix_and_force(case,duration*fraction,prepared,background)
        return (duration*np.einsum('nij,nj->ni',matrix,state)+.5*fraction**2*forcing/forcing_scale[:,None]).ravel()
    forward=solve_ivp(forward_rhs,(0.,1.),np.zeros(count*dimension),method='DOP853',rtol=1e-10,atol=1e-12,max_step=1/steps)
    require(forward.success,'forward sensitivity integration')
    response=forward.y[:,-1].reshape(count,dimension)*forcing_scale[:,None]*duration**3
    direct=np.einsum('nci,ni->nc',mapping,response)
    return absolute_gain,signed_gain,direct,solution.nfev+forward.nfev


with worker('response-check'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    reports={}
    for case in ('cold','heavy'):
        prepared=load(ROOT/(case+'-initial-state.npz'))
        background=Background(load(PREVIOUS/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
        reference_path=PREVIOUS/(case+'-remainder-readout.npz')
        require(digest(reference_path)==previous_seal['artifacts'][reference_path.name]['sha256'],'sealed boundary reference')
        reference=load(reference_path)['packet'][901:]
        fine=load(ROOT/(case+'-linear-64.npz'))
        native_state=reference[:,39:41] if case=='heavy' else reference[:,63:64]
        checks={}
        for column in range(native_state.shape[1]):
            checks['boundary_state_'+str(column)]=comparison(fine['state'][:,-1,column],native_state[:,column])
        norms=prepared['norm']
        for label in ('constant','linear'):
            coarse=load(ROOT/(case+'-'+label+'-32.npz'))
            accurate=load(ROOT/(case+'-'+label+'-64.npz'))
            checks[label+'_all_node_state_refinement']=comparison((accurate['state']-coarse['state'])/norms[None,:,:],0,scale=1.)
        results={}
        for steps in (32,64):
            absolute,signed,direct,evaluations=adjoint(case,prepared,background,steps)
            for column,name in enumerate(('density','current','pressure')):
                checks['duality_'+str(steps)+'_'+name]=comparison(signed[:,column],direct[:,column],GATE)
                checks['gain_dominates_signed_'+str(steps)+'_'+name]=dict(passed=bool(np.all(abs(signed[:,column])<=absolute[:,column]+GATE*np.max(absolute[:,column]))))
            results[steps]=dict(absolute=absolute,signed=signed,direct=direct)
            print(json.dumps(dict(case=case,response_steps=steps,evaluations=evaluations)),flush=True)
        gain=weighted(abs(prepared['weights']),results[64]['absolute'])
        gain_refinement=weighted(abs(prepared['weights']),abs(results[64]['absolute']-results[32]['absolute']))
        for column,name in enumerate(('density','current','pressure')):
            checks['gain_refinement_'+name]=comparison(gain_refinement[column],0,GATE,scale=gain[column])
        budget=load(ROOT/(case+'-comparison-budget.npz'))
        margin=GATE*budget['reference_scale']-abs(budget['residual'][-1])-budget['numerical_budget'][-1]
        ceiling=[float(margin[column]/(gain[column]+gain_refinement[column])) if gain[column]>0 and margin[column]>0 else None for column in range(3)]
        np.savez_compressed(ROOT/(case+'-response-gain.npz'),node_absolute_gain=results[64]['absolute'],node_signed_gain=results[64]['signed'],forward_gain=results[64]['direct'],gain=gain,gain_refinement=gain_refinement,numerical_margin=margin)
        passed=all(row['passed'] for row in checks.values())
        report=dict(passed=passed,checks=checks,final_epoch_gain=gain.tolist(),gain_refinement=gain_refinement.tolist(),remaining_numerical_margin=margin.tolist(),conditional_uniform_rest_curvature_ceiling=ceiling,curvature_units='rest variable per native conformal Mpc squared',uniform_bound_established=False,final_epoch_only=True,numerical_gain_not_certified=True,reference_path=str(reference_path),reference_sha256=digest(reference_path),no_prediction_changed=True)
        write(case+'-response-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,passed=passed,gain=gain.tolist(),conditional_ceiling=ceiling,failed={name:row for name,row in checks.items() if not row['passed']})),flush=True)
    write('response-validation.json',dict(completed=True,passed=all(row['passed'] for row in reports.values()),uniform_rest_curvature_bound_established=False,predictions_unchanged=True))
