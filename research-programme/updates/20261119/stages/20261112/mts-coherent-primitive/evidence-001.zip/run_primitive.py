from support import *
from primitive_math import *
import argparse

parser=argparse.ArgumentParser()
parser.add_argument('case',choices=('cold','heavy'))
args=parser.parse_args()
case=args.case
with worker(case+'-evolve'):
    require(read(ROOT/'initial-validation.json')['passed'],'frozen initial state')
    check_hashes(read(ROOT/'frozen-inputs.json'))
    prepared=load(ROOT/(case+'-initial-state.npz'))
    background=Background(load(PREVIOUS/(case+'-native-clock.npz')),load(EARLY/'runs/backgrounds'/(case+'.npz')))
    weights,elapsed=prepared['weights'],prepared['elapsed']
    runs={}
    paths={}
    for linear in (False,True):
        for steps in (32,64):
            guard()
            label=('linear' if linear else 'constant')+'-'+str(steps)
            states,sources,evaluations=solve(case,prepared,background,elapsed,steps,linear,guard)
            increments=sources-prepared['node_initial_sources'][None,:,:]
            prediction=prepared['initial_weighted_source']+np.array([weighted(weights,row) for row in increments])
            direct=np.array([weighted(weights,row) for row in sources])
            arithmetic=abs(prediction-(prepared['initial_weighted_source']+direct-direct[0]))
            filename=case+'-'+label+'.npz'
            np.savez_compressed(ROOT/filename,state=states,node_source=sources,prediction=prediction,raw_weighted_source=direct,arithmetic_difference=arithmetic,elapsed=elapsed,weights=weights,rest_degree=int(linear),steps=steps)
            runs[label]=dict(completed=True,evaluations=evaluations,packet=filename,sha256=digest(ROOT/filename),target_values_loaded=False)
            paths[str(ROOT/filename)]=digest(ROOT/filename)
            print(json.dumps(dict(case=case,run=label,completed=True,evaluations=evaluations)),flush=True)
    write(case+'-run-freeze.json',dict(passed=True,runs=runs,hashes=paths,primary='linear-64',target_readout_loaded=False,coefficients_fitted=False))
    check_hashes(read(ROOT/'frozen-inputs.json'))
