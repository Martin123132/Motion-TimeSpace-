from support import *
import numpy as np
from scipy.interpolate import CubicHermiteSpline
from history_math import local_polynomial, source_series, fixed_lag_readout

def load(path):
    with np.load(path, allow_pickle=False) as packet:
        return {name: packet[name].copy() for name in packet.files}

def compare(actual, reference, tolerance=GATE, scale=None):
    error = float(np.max(abs(np.asarray(actual) - reference)))
    scale = float(np.max(abs(reference))) if scale is None else float(scale)
    return dict(error=error, scale=scale, relative=error / scale if scale else None, passed=bool(error <= tolerance * scale), tolerance=tolerance)

def components(actual, reference, tolerance=GATE):
    return {name: compare(actual[..., index], reference[..., index], tolerance) for index, name in enumerate(('density', 'current', 'pressure'))}

def main():
    with worker('readout'):
        paths = [MEMORY / 'memory-transport.npz', MATCH / 'carrier-initial-state.npz', MATCH / 'matching-state.npz', MATCH / 'matching-validation.json', SPECTRUM / 'runs/exact-grid/chunk-0384.npz', EARLY / 'runs/final-bg8-start/cold.npz']
        paths += [PREVIOUS / (case + '-right-edge-' + suffix) for case in ('cold', 'heavy') for suffix in ('capture.npz', 'steps32.npz', 'steps64.npz', 'result.json')]
        for path in paths:
            if path.parent == PREVIOUS:
                require(digest(path) == seal['artifacts'][path.name]['sha256'], 'sealed saved continuation')
        for parent, names in ((MEMORY, ['memory-transport.npz']), (MATCH, ['carrier-initial-state.npz', 'matching-state.npz', 'matching-validation.json'])):
            old = read(parent / 'closeout.json')
            for name in names:
                require(digest(parent / name) == old['artifacts'][name]['sha256'], 'sealed historical source')
        check_hashes(read(PREVIOUS / 'frozen-inputs.json'))
        paths += [ROOT / name for name in ('PROTOCOL.md', 'support.py', 'history_math.py', 'run_readout.py')]
        write('frozen-inputs.json', {str(path): digest(path) for path in paths})
        memory = load(MEMORY / 'memory-transport.npz')
        carrier = load(MATCH / 'carrier-initial-state.npz')
        matching = load(MATCH / 'matching-state.npz')
        cold = read(MATCH / 'matching-validation.json')['cold']
        indices, weights = memory['indices'], memory['weights']
        density0 = float(matching['density0'])
        reports = {}
        for case in ('cold', 'heavy'):
            guard()
            source_path = SPECTRUM / 'runs/exact-grid/chunk-0384.npz' if case == 'heavy' else EARLY / 'runs/final-bg8-start/cold.npz'
            packet = load(source_path)
            selected = int(np.flatnonzero(packet['modes'] == 5.)[0])
            names = packet['names'].tolist()
            rows = packet['values'][selected, indices]
            history_time = packet['conformal_time'][indices]
            if case == 'heavy':
                beta = rows[:, names.index('a')] / density0
                history_source = beta[:, None] * rows[:, [names.index(name) for name in ('mts_drho_h', 'mts_q_h', 'mts_dp_h')]]
                initial_expected = carrier['full_sources']
            else:
                history_source = np.zeros((len(indices), 3))
                history_source[:, 0] = cold['normalization'] * rows[:, names.index('delta_cdm')]
                initial_expected = np.array([cold['density'], 0., 0.])
            capture = load(PREVIOUS / (case + '-right-edge-capture.npz'))
            fine = load(PREVIOUS / (case + '-right-edge-steps64.npz'))
            coarse = load(PREVIOUS / (case + '-right-edge-steps32.npz'))
            current, rates = source_series(case, fine, capture, density0, cold['normalization'])
            coarse_current, coarse_rates = source_series(case, coarse, capture, density0, cold['normalization'])
            native_current, native_rates = source_series(case, fine, capture, density0, cold['normalization'], native=True)
            totals, nodes = {}, {}
            for count in (4, 6, 8):
                totals[count], nodes[count], future_counts = fixed_lag_readout(history_time, history_source, weights, fine['clock'], current, rates, count)
            native_total, native_nodes, _ = fixed_lag_readout(history_time, history_source, weights, fine['clock'], native_current, native_rates, 6)
            coarse_total, _, _ = fixed_lag_readout(history_time, history_source, weights, fine['clock'], coarse_current, coarse_rates, 6)
            training = np.unique(np.r_[np.arange(0, len(indices), 2), len(indices) - 1])
            withheld = np.setdiff1d(np.arange(len(indices)), training)
            withheld_checks = {}
            for count in (6, 8):
                predicted = local_polynomial(history_time[training], history_source[training], history_time[withheld], count)
                withheld_checks[str(count)] = components(predicted, history_source[withheld])
            short_training = np.arange(0, 9, 2)
            short_withheld = np.arange(1, 9, 2)
            short_prediction = CubicHermiteSpline(fine['clock'][short_training], current[short_training], rates[short_training])(fine['clock'][short_withheld])
            current_withheld = components(short_prediction, current[short_withheld])
            envelope = np.einsum('n,tnc->tc', abs(weights), abs(nodes[6] - nodes[8]))
            envelope_checks = {name: compare(envelope[:, index], np.zeros(len(envelope)), scale=np.max(abs(totals[8][:, index]))) for index, name in enumerate(('density', 'current', 'pressure'))}
            checks = dict(initial=components(totals[6][0], initial_expected, ALGEBRA), join=components(current[0], history_source[-1]), native_comparison=components(totals[6], native_total), time_step=components(totals[6], coarse_total), polynomial_refinement=components(totals[6], totals[8]), absolute_weight_discrepancy=envelope_checks, current_withheld=current_withheld, past_withheld_degree5=withheld_checks['6'], past_withheld_degree7=withheld_checks['8'])
            shifted = packet['values'][selected, indices[:, None] + np.arange(9)[None, :]]
            if case == 'heavy':
                shifted_sources = shifted[:, :, names.index('a'), None] / density0 * shifted[:, :, [names.index(name) for name in ('mts_drho_h', 'mts_q_h', 'mts_dp_h')]]
            else:
                shifted_sources = np.zeros((len(indices), 9, 3))
                shifted_sources[:, :, 0] = cold['normalization'] * shifted[:, :, names.index('delta_cdm')]
            index_shift = np.einsum('n,ntc->tc', weights, shifted_sources)
            source_gap = history_source[-1] - current[0]
            report = dict(passed=all(row['passed'] for group in checks.values() for row in group.values()), checks=checks, initial=totals[6][0].tolist(), final=totals[6][-1].tolist(), change=(totals[6][-1] - totals[6][0]).tolist(), maximum_absolute_weight=float(np.sum(abs(weights))), current_boundary_nodes=future_counts.tolist(), maximum_query_lag=float(history_time[-1] - history_time[0]), interpolation_envelope_kind='degree5-versus7 discrepancy; not a certified error bound', native_comparison_shares_historical_interpolation=True, source_join_difference=source_gap.tolist(), diagnostics=dict(degree3=components(totals[4], totals[8]), frozen_history=components(np.broadcast_to(totals[6][0], totals[6].shape), totals[6]), index_shift=components(index_shift, totals[6])))
            write(case + '-result.json', report)
            np.savez_compressed(ROOT / (case + '-readout.npz'), weights=weights, indices=indices, historical_time=history_time, lags=history_time[-1] - history_time, historical_source=history_source, current_time=fine['clock'], current_source=current, current_rate=rates, degree3=totals[4], degree5=totals[6], degree7=totals[8], native_comparison=native_total, coarse_comparison=coarse_total, nodes_degree5=nodes[6], nodes_degree7=nodes[8], interpolation_discrepancy_envelope=envelope, current_boundary_nodes=future_counts, index_shift=index_shift)
            reports[case] = report
            print(json.dumps(dict(case=case, passed=report['passed'], final=report['final'], checks={group:{name:row['relative'] for name,row in rows.items()} for group, rows in checks.items()})), flush=True)
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        write('result.json', dict(passed=all(report['passed'] for report in reports.values()), cases={case:report['passed'] for case,report in reports.items()}, next='Review saved gates before any memory compression', original_tolerances=True, goal_left_paused=True))

if __name__ == '__main__':
    main()
