import numpy as np
from scipy.interpolate import CubicHermiteSpline

def local_polynomial(times, values, queries, count):
    times, values, queries = np.asarray(times), np.asarray(values), np.asarray(queries)
    if count < 2 or len(times) < count or np.any(np.diff(times) <= 0):
        raise ValueError('Ordered knots and sufficient fixed stencil required')
    if np.any(queries < times[0]) or np.any(queries > times[-1]):
        raise ValueError('No extrapolation outside available history')
    starts = np.clip(np.searchsorted(times, queries) - count // 2, 0, len(times) - count)
    indices = starts[:, None] + np.arange(count)
    nodes = times[indices]
    widths = nodes[:, -1] - nodes[:, 0]
    relative_nodes = (nodes - queries[:, None]) / widths[:, None]
    coefficients = np.ones_like(relative_nodes)
    for slot in range(count):
        for other in range(count):
            if slot != other:
                coefficients[:, slot] *= -relative_nodes[:, other] / (relative_nodes[:, slot] - relative_nodes[:, other])
    result = np.einsum('ij,ijk->ik', coefficients, values[indices])
    nearest = np.argmin(abs(nodes - queries[:, None]), axis=1)
    distances = abs(nodes[np.arange(len(queries)), nearest] - queries)
    exact = distances <= 4 * np.spacing(np.maximum(abs(queries), 1.))
    result[exact] = values[indices[np.arange(len(queries))[exact], nearest[exact]]]
    return result

def source_series(case, run, capture, density0, cold_normalization, native=False):
    values = capture['reference'] if native else run['vector']
    derivatives = capture['derivative_reference'] if native else run['derivative']
    observations = capture['observation_reference'] if native else run['observation']
    result = np.zeros((len(run['clock']), 3))
    rates = result.copy()
    if case == 'cold':
        result[:, 0] = cold_normalization * values[:, 1]
        rates[:, 0] = cold_normalization * derivatives[:, 1]
    else:
        scalar_index = int(capture['signature'][0, 2]) - 1 + 2
        scale, rate = run['extra'][:, 0], run['extra'][:, 1]
        field, velocity = run['jets'][:, 1, 0], run['jets'][:, 1, 1]
        field_rate = rate * run['jets'][:, 1, 2]
        velocity_rate = rate * run['jets'][:, 1, 3]
        mass2 = run['jets'][:, 1, 4]
        perturbation, speed = values[:, scalar_index], values[:, scalar_index + 1]
        perturbation_rate, speed_rate = derivatives[:, scalar_index], derivatives[:, scalar_index + 1]
        beta = scale / density0
        result = beta[:, None] * observations[:, [37, 39, 38]]
        kinetic_rate = velocity_rate * speed + velocity * speed_rate
        potential_rate = mass2 * ((2 * rate * field + field_rate) * perturbation + field * perturbation_rate)
        rates[:, 0] = rate * result[:, 0] + beta * (kinetic_rate + potential_rate)
        rates[:, 1] = rate * result[:, 1] + beta * 5 * (velocity_rate * perturbation + velocity * perturbation_rate)
        rates[:, 2] = rate * result[:, 2] + beta * (kinetic_rate - potential_rate)
    return result, rates

def fixed_lag_readout(history_time, history_source, weights, current_time, current_source, current_rates, count):
    if current_time[0] != history_time[-1]:
        raise ValueError('Causal boundary does not match the branch clock')
    lags = history_time[-1] - history_time
    totals, node_values, future_counts = [], [], []
    for epoch, now in enumerate(current_time):
        query = now - lags
        if epoch == 0:
            query = history_time.copy()
        old = query <= history_time[-1]
        values = np.empty((len(weights), 3))
        values[old] = local_polynomial(history_time, history_source, query[old], count)
        if np.any(~old):
            if epoch == 0:
                raise ValueError('Future source at initial time')
            interpolator = CubicHermiteSpline(current_time[:epoch + 1], current_source[:epoch + 1], current_rates[:epoch + 1], extrapolate=False)
            values[~old] = interpolator(query[~old])
        if not np.isfinite(values).all():
            raise ValueError('Invalid history/current interpolation')
        totals.append(weights @ values)
        node_values.append(values)
        future_counts.append(int(np.sum(~old)))
    return np.array(totals), np.array(node_values), np.array(future_counts)
