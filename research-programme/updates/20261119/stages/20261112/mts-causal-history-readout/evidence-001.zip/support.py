import importlib.util
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREVIOUS = ROOT.parent / 'mts-native-right-edge-memory-20261111'
EXPECTED = '0180bb3143a7171f40deda4999dcb609cf720b514a95e4141a9e65e596f59267'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

if digest(PREVIOUS / 'closeout.json') != EXPECTED:
    raise ValueError('Previous checkpoint changed')
seal = json.loads((PREVIOUS / 'closeout.json').read_text())
if digest(PREVIOUS / 'support.py') != seal['artifacts']['support.py']['sha256']:
    raise ValueError('Retained support changed')
spec = importlib.util.spec_from_file_location('retained_support', PREVIOUS / 'support.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT, base.PREVIOUS = ROOT, PREVIOUS
POST, BRANCH, EARLY, SPECTRUM = base.POST, base.BRANCH, base.EARLY, base.SPECTRUM
require, read, write, guard = base.require, base.read, base.write, base.guard
worker, exited, check_hashes = base.worker, base.exited, base.check_hashes
GATE, ALGEBRA = base.GATE, base.ALGEBRA
MEMORY = POST / 'mts-causal-memory-boundary-20261111'
MATCH = POST / 'mts-canonical-matching-state-20261111'
