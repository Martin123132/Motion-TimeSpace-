from support import *
import numpy as np
from history_math import local_polynomial, fixed_lag_readout

def load(path):
    with np.load(path, allow_pickle=False) as packet:
        return {name: packet[name].copy() for name in packet.files}

def check(actual, expected, tolerance=ALGEBRA, scale=None):
    error = float(np.max(abs(np.asarray(actual) - expected)))
    scale = float(np.max(abs(expected))) if scale is None else float(scale)
    return dict(error=error, scale=scale, relative=error / scale if scale else None, passed=bool(error <= tolerance * scale), tolerance=tolerance)

def main():
    with worker('verify-readout') as identity:
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        require(exited(read(ROOT / 'readout-start.json'))['exited'], 'calculation worker exited')
        controls = {}
        knots = np.linspace(-1., 1., 60) + .003 * np.sin(np.arange(60))
        queries = (knots[:-1] + knots[1:]) / 2
        for count in (4, 6, 8):
            values = np.column_stack([np.ones(len(knots)), knots, knots**(count - 1)])
            expected = np.column_stack([np.ones(len(queries)), queries, queries**(count - 1)])
            controls['polynomial_degree' + str(count - 1)] = check(local_polynomial(knots, values, queries, count), expected)
            controls['knot_reproduction_' + str(count)] = check(local_polynomial(knots, values, knots, count), values)
        try:
            local_polynomial(knots, values, np.array([knots[-1] + .01]), 8)
        except ValueError:
            controls['extrapolation_rejected'] = dict(passed=True)
        else:
            controls['extrapolation_rejected'] = dict(passed=False)
        budgets = {}
        all_case_checks = 0
        for case in ('cold', 'heavy'):
            report = read(ROOT / (case + '-result.json'))
            require(report['passed'] and all(row['passed'] for group in report['checks'].values() for row in group.values()), 'unchanged per-source gates')
            all_case_checks += sum(len(group) for group in report['checks'].values())
            saved = load(ROOT / (case + '-readout.npz'))
            past, now, weights = saved['historical_time'], saved['current_time'], saved['weights']
            require(np.all(np.diff(past) > 0) and np.all(np.diff(now) > 0), 'ordered physical times')
            require(np.array_equal(saved['lags'], past[-1] - past), 'unchanged branch-native lags')
            controls[case + '_weight_sum'] = check(weights.sum(), 1.)
            original, _, _ = fixed_lag_readout(past, saved['historical_source'], weights, now, saved['current_source'], saved['current_rate'], 6)
            controls[case + '_saved_replay'] = check(original, saved['degree5'])
            modified_source, modified_rate = saved['current_source'].copy(), saved['current_rate'].copy()
            modified_source[5:] += 100.
            modified_rate[5:] -= 100.
            modified, _, _ = fixed_lag_readout(past, saved['historical_source'], weights, now, modified_source, modified_rate, 6)
            controls[case + '_no_future_readout_dependency'] = dict(passed=bool(np.array_equal(modified[:5], original[:5])))
            displacement = past - past[0]
            past_polynomial = np.column_stack([np.ones(len(past)), displacement, displacement**3])
            now_displacement = now - past[0]
            current_polynomial = np.column_stack([np.ones(len(now)), now_displacement, now_displacement**3])
            current_rate = np.column_stack([np.zeros(len(now)), np.ones(len(now)), 3 * now_displacement**2])
            transported, _, _ = fixed_lag_readout(past, past_polynomial, weights, now, current_polynomial, current_rate, 6)
            translated = now[:, None] - saved['lags'][None, :] - past[0]
            expected = np.column_stack([np.full(len(now), weights.sum()), translated @ weights, translated**3 @ weights])
            controls[case + '_exact_cubic_delay_transport'] = check(transported, expected)
            active_weight = np.array([np.sum(abs(weights[(epoch - saved['lags']) > past[-1]])) for epoch in now])
            withheld_error = np.array([report['checks']['current_withheld'][name]['error'] for name in ('density', 'current', 'pressure')])
            join_error = abs(saved['current_source'][0] - saved['historical_source'][-1])
            past_error = saved['interpolation_discrepancy_envelope']
            recent_error = active_weight[:, None] * withheld_error[None, :]
            join_allowance = active_weight[:, None] * join_error[None, :]
            ode_error = abs(saved['degree5'] - saved['coarse_comparison'])
            total = past_error + recent_error + join_allowance + ode_error
            component_checks = {name: check(total[:, column], np.zeros(len(now)), GATE, scale=np.max(abs(saved['degree7'][:, column]))) for column, name in enumerate(('density', 'current', 'pressure'))}
            budgets[case] = dict(passed=all(row['passed'] for row in component_checks.values()), checks=component_checks, recent_absolute_weight=active_weight.tolist(), combined_maximum=np.max(total, axis=0).tolist(), interpretation='Working numerical discrepancy budget, not a certified error bound: degree5/7 past discrepancy + absolute-weighted coarse withheld current residual + seam mismatch +32/64 ODE difference. Shared systematic errors are not bounded by this procedure.')
            np.savez_compressed(ROOT / (case + '-numerical-budget.npz'), current_time=now, past_degree_discrepancy=past_error, recent_withheld_allowance=recent_error, seam_allowance=join_allowance, ode_difference=ode_error, combined=total)
        require(all(row['passed'] for row in controls.values()), 'independent polynomial, causal and replay controls')
        overall = all(report['passed'] for report in budgets.values())
        write('validation.json', dict(passed=overall, controls=controls, budgets=budgets, inherited_case_checks=all_case_checks, verifier_identity=identity, mathematical_error_bound_claim=False, compression_test_performed=False))
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        for path in ROOT.glob('*.py'):
            compile(path.read_text(encoding='utf-8'), str(path), 'exec')
        require(not list(ROOT.rglob('__pycache__')), 'no bytecode caches')
        print(json.dumps(dict(passed=overall, controls=len(controls), case_checks=all_case_checks, budgets={case:report['checks'] for case,report in budgets.items()})), flush=True)

if __name__ == '__main__':
    main()
