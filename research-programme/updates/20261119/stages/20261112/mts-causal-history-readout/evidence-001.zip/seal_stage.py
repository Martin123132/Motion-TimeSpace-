from support import *
from datetime import datetime, timezone

def main():
    with worker('seal'):
        require(read(ROOT / 'result.json')['passed'] and read(ROOT / 'validation.json')['passed'], 'readout and validation passed')
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        for name in ('readout', 'verify-readout'):
            require(read(ROOT / (name + '-end.json'))['state'] == 'completed', 'completed worker')
            require(exited(read(ROOT / (name + '-start.json')))['exited'], 'worker exited')
        for path in ROOT.glob('*.py'):
            compile(path.read_text(), str(path), 'exec')
        require(not list(ROOT.rglob('__pycache__')), 'no caches')
    artifacts = {path.name: dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('closeout.json', 'CLEANUP-VERIFIED.json')}
    write('closeout.json', dict(state='complete', utc=datetime.now(timezone.utc).isoformat(), artifacts=artifacts, input_hashes=read(ROOT / 'frozen-inputs.json'), previous_closeout_sha256=EXPECTED, goal_left_paused=True, next_step='Check recent-boundary Hermite interpolation at independent internal times; no automatic run'))
    print(json.dumps(dict(sealed=len(artifacts), sha256=digest(ROOT / 'closeout.json'))), flush=True)

if __name__ == '__main__':
    main()
