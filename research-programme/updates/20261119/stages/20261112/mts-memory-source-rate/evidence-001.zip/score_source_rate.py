from support import *
from source_rate_math import comparison
import numpy as np

def main():
    with worker('score-rate'):
        require(read(ROOT / 'prediction-freeze.json')['passed'], 'predictions frozen')
        require(exited(read(ROOT / 'freeze-rate-start.json'))['exited'], 'freeze completed before scoring')
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        reports = {}
        for case in ('cold', 'heavy'):
            path = PREVIOUS / (case + '-tested-readout.npz')
            require(digest(path) == previous_seal['artifacts'][path.name]['sha256'], 'sealed test readout')
            frozen = np.load(ROOT / (case + '-frozen-prediction.npz'), allow_pickle=False)
            target = np.load(path, allow_pickle=False)
            expected = target['corrected_readout']
            require(np.array_equal(target['current_time'] - target['current_time'][0], frozen['elapsed']), 'unchanged original reporting times')
            orders = {}
            for order, label in ((1, 'first'), (2, 'second')):
                prediction, comparison_prediction = frozen[label + '8'], frozen[label + '6']
                residual = abs(prediction - expected)
                derivative_discrepancy = abs(prediction - comparison_prediction)
                total = residual + target['updated_working_budget'] + derivative_discrepancy
                checks = {name:comparison(prediction[:, index], expected[:, index]) for index,name in enumerate(('density', 'current', 'pressure'))}
                allowance = {name:comparison(total[:, index], np.zeros(len(total)), scale=np.max(abs(expected[:, index]))) for index,name in enumerate(('density', 'current', 'pressure'))}
                derivative_checks = {name:comparison(derivative_discrepancy[:, index], np.zeros(len(total)), scale=np.max(abs(expected[:, index]))) for index,name in enumerate(('density', 'current', 'pressure'))}
                orders[str(order)] = dict(passed=all(row['passed'] for row in checks.values()) and all(row['passed'] for row in allowance.values()), residual=checks, residual_plus_working_allowance=allowance, derivative_refinement=derivative_checks, final_prediction=prediction[-1].tolist(), final_residual=(prediction[-1] - expected[-1]).tolist())
            omitted = {name:comparison(frozen['without_memory_rate'][:, index], expected[:, index]) for index,name in enumerate(('density', 'current', 'pressure'))}
            report = dict(orders=orders, memory_rate_omission=omitted, numerical_allowance_is_certified_bound=False, coefficients_fitted=False, observational_holdout=False, comparison_path=str(path), comparison_sha256=digest(path))
            write(case + '-result.json', report)
            reports[case] = report
            print(json.dumps(dict(case=case, orders=orders, memory_rate_omission=omitted)), flush=True)
        write('result.json', dict(completed=True, first_order_passed=all(report['orders']['1']['passed'] for report in reports.values()), second_order_passed=all(report['orders']['2']['passed'] for report in reports.values()), unchanged_gates=True, goal_left_paused=True))
        check_hashes(read(ROOT / 'frozen-inputs.json'))

if __name__ == '__main__':
    main()
