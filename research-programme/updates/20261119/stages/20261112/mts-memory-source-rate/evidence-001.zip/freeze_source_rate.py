from support import *
from source_rate_math import derivative_matrix, differentiate, comparison
import ast
import numpy as np
from scipy.interpolate import CubicSpline

def load(path):
    with np.load(path, allow_pickle=False) as packet:
        return {name:packet[name].copy() for name in packet.files}

def main():
    with worker('freeze-rate'):
        check_hashes(read(NATIVE_STAGE / 'frozen-inputs.json'))
        files = [MATCH / 'matching-state.npz', MATCH / 'carrier-initial-state.npz', MATCH / 'matching-validation.json', MEMORY / 'run_memory.py', EARLY / 'runs/backgrounds/heavy.npz', SPECTRUM / 'runs/exact-grid/chunk-0384.npz', EARLY / 'runs/final-bg8-start/cold.npz']
        for parent, names in ((MATCH, ['matching-state.npz', 'carrier-initial-state.npz', 'matching-validation.json']), (MEMORY, ['run_memory.py'])):
            old_seal = read(parent / 'closeout.json')
            for name in names:
                require(digest(parent / name) == old_seal['artifacts'][name]['sha256'], 'sealed initial-history input')
        matching, carrier = load(files[0]), load(files[1])
        cold = read(files[2])['cold']
        tree = ast.parse((MEMORY / 'run_memory.py').read_text())
        function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'scalar_block')
        namespace = dict(np=np, CubicSpline=CubicSpline, require=require)
        exec(compile(ast.Module(body=[function], type_ignores=[]), str(MEMORY / 'run_memory.py'), 'exec'), namespace)
        indices, weights = matching['indices'], matching['weights']
        table = load(EARLY / 'runs/backgrounds/heavy.npz')
        controls = {}
        test_times = np.linspace(-1., 1., 50) + .001 * np.sin(np.arange(50))
        for count in (6, 8):
            stencil = derivative_matrix(test_times, count)
            for power in (0, 1, count - 1):
                expected = np.zeros(len(test_times)) if power == 0 else power * test_times**(power - 1)
                controls['polynomial_' + str(count) + '_' + str(power)] = comparison(differentiate(test_times**power, stencil)[:, 0], expected, ALGEBRA)
        require(all(row['passed'] for row in controls.values()), 'derivative polynomial controls')
        metadata = {}
        for case in ('cold', 'heavy'):
            guard()
            packet = load(SPECTRUM / 'runs/exact-grid/chunk-0384.npz' if case == 'heavy' else EARLY / 'runs/final-bg8-start/cold.npz')
            mode = int(np.flatnonzero(packet['modes'] == 5.)[0])
            native_values = packet['values'][mode, indices]
            source = {str(name):native_values[:, column] for column,name in enumerate(packet['names'])}
            times = packet['conformal_time'][indices]
            elapsed = packet['conformal_time'][2892:2901] - times[-1]
            variants = {}
            initial = carrier['full_sources'] if case == 'heavy' else np.array([cold['density'], 0., 0.])
            for count in (6, 8):
                stencil = derivative_matrix(times, count)
                rate = differentiate(np.log(source['a']), stencil)[:, 0]
                if case == 'heavy':
                    block = namespace['scalar_block'](source, table, float(matching['density0']), matching['force'])
                    field_n = CubicSpline(table['heavy_efold'], table['phi_h'], bc_type='natural')(np.log(source['a']), 1)
                    velocity_n = CubicSpline(table['heavy_efold'], table['phidot_h'], bc_type='natural')(np.log(source['a']), 1)
                    perturbations = np.column_stack([block['perturbation'], block['speed']])
                    relative = rate - source['H']
                    correction = relative[:, None] * (block['moments'] + block['beta'][:, None] * np.einsum('ni,nj->nij', np.column_stack([field_n, velocity_n]), perturbations).reshape(-1, 4))
                    moment_rate = np.einsum('nij,nj->ni', block['operator'], block['moments']) + block['forcing'] + correction
                    source_map = block['source_map']
                    map_prime = block['source_map_prime'].copy()
                    map_prime[:, 0, 0] = 2 * rate * block['mass2']
                    map_prime[:, 2, 0] = -2 * rate * block['mass2']
                    node_rate = np.einsum('nij,nj->ni', map_prime, block['moments']) + np.einsum('nij,nj->ni', source_map, moment_rate)
                    direct_moment_rate = block['direct_rate'] + correction
                    controls['product_rule_' + str(count)] = comparison(moment_rate, direct_moment_rate, ALGEBRA)
                    mean = weights @ block['moments']
                    mean_rate = weights @ moment_rate
                    unresolved = block['moments'] - mean
                    unresolved_rate = moment_rate - mean_rate
                    memory_rate = weights @ (np.einsum('nij,nj->ni', map_prime, unresolved) + np.einsum('nij,nj->ni', source_map, unresolved_rate))
                    resolved_rate = np.einsum('n,nij->ij', weights, map_prime) @ mean + np.einsum('n,nij->ij', weights, source_map) @ mean_rate
                    controls['memory_rate_identity_' + str(count)] = comparison(resolved_rate + memory_rate, weights @ node_rate, ALGEBRA)
                else:
                    node_rate = np.zeros((len(times), 3))
                    node_rate[:, 0] = -5 * cold['normalization'] * matching['cold_force']
                    memory_rate = np.zeros(3)
                    resolved_rate = weights @ node_rate
                first_rate = weights @ node_rate
                second_rate = weights @ differentiate(node_rate, stencil)
                first_prediction = initial + elapsed[:, None] * first_rate
                second_prediction = first_prediction + .5 * elapsed[:, None]**2 * second_rate
                variants[count] = dict(clock_rate=rate, node_rate=node_rate, first_rate=first_rate, second_rate=second_rate, memory_rate=memory_rate, resolved_rate=resolved_rate, first_prediction=first_prediction, second_prediction=second_prediction)
            endpoint_path = NATIVE_STAGE / (case + '-right-edge-steps64.npz')
            require(digest(endpoint_path) == native_seal['artifacts'][endpoint_path.name]['sha256'], 'sealed clock reference')
            endpoint = load(endpoint_path)
            for count in (6, 8):
                controls[case + '_clock_endpoint_' + str(count)] = comparison(variants[count]['clock_rate'][-1], endpoint['extra'][0, 1])
            controls[case + '_clock_refinement'] = comparison(variants[6]['clock_rate'], variants[8]['clock_rate'])
            np.savez_compressed(ROOT / (case + '-frozen-prediction.npz'), elapsed=elapsed, initial=initial, weights=weights, indices=indices, initial_times=times, first6=variants[6]['first_prediction'], first8=variants[8]['first_prediction'], second6=variants[6]['second_prediction'], second8=variants[8]['second_prediction'], first_rate6=variants[6]['first_rate'], first_rate8=variants[8]['first_rate'], second_rate6=variants[6]['second_rate'], second_rate8=variants[8]['second_rate'], memory_rate=variants[8]['memory_rate'], resolved_rate=variants[8]['resolved_rate'], without_memory_rate=initial + elapsed[:, None] * variants[8]['resolved_rate'], node_rate6=variants[6]['node_rate'], node_rate8=variants[8]['node_rate'])
            metadata[case] = {name:variants[8][name].tolist() for name in ('first_rate', 'second_rate', 'memory_rate', 'resolved_rate')}
            files += [endpoint_path, ROOT / (case + '-frozen-prediction.npz')]
        require(all(row['passed'] for row in controls.values()), 'initial equation and clock checks')
        files += [ROOT / name for name in ('support.py', 'PROTOCOL.md', 'source_rate_math.py', 'freeze_source_rate.py', 'score_source_rate.py')]
        write('frozen-inputs.json', {str(path):digest(path) for path in files})
        write('prediction-freeze.json', dict(passed=True, checks=controls, coefficients=metadata, target_values_loaded=False, coefficients_fitted=False, frozen_orders=[1,2], derivative_stencils=[6,8]))
        print(json.dumps(dict(passed=True, coefficients=metadata)), flush=True)

if __name__ == '__main__':
    main()
