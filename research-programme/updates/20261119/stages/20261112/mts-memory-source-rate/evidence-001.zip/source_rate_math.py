import numpy as np

def derivative_matrix(times, count):
    times = np.asarray(times)
    if count < 2 or len(times) < count or np.any(np.diff(times) <= 0):
        raise ValueError('Ordered, sufficient source knots required')
    stencils, coefficients = [], []
    for point in range(len(times)):
        start = np.clip(point - count // 2, 0, len(times) - count)
        indices = np.arange(start, start + count)
        width = times[indices[-1]] - times[indices[0]]
        nodes = (times[indices] - times[point]) / width
        row = []
        for slot in range(count):
            others = np.delete(nodes, slot)
            polynomial = np.polynomial.polynomial.polyfromroots(others)
            row.append(polynomial[1] / (np.prod(nodes[slot] - others) * width))
        stencils.append(indices)
        coefficients.append(row)
    return np.array(stencils), np.array(coefficients)

def differentiate(values, stencil):
    values = np.asarray(values)
    if values.ndim == 1:
        values = values[:, None]
    indices, coefficients = stencil
    return np.einsum('ij,ijk->ik', coefficients, values[indices] - values[:, None, :])

def comparison(actual, expected, tolerance=2e-5, scale=None):
    difference = float(np.max(abs(np.asarray(actual) - expected)))
    scale = float(np.max(abs(expected))) if scale is None else float(scale)
    return dict(error=difference, scale=scale, relative=difference / scale if scale else None, tolerance=tolerance, passed=bool(difference <= tolerance * scale))
