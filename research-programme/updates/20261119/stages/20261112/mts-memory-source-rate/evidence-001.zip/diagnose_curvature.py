from support import *
from source_rate_math import derivative_matrix, differentiate, comparison
import numpy as np

def main():
    with worker('curvature-diagnostic'):
        saved = np.load(ROOT / 'heavy-frozen-prediction.npz', allow_pickle=False)
        old_path = MEMORY / 'memory-transport.npz'
        require(digest(old_path) == read(MEMORY / 'closeout.json')['artifacts'][old_path.name]['sha256'], 'sealed equation-owned initial rates')
        old = np.load(old_path, allow_pickle=False)
        require(np.array_equal(old['indices'], saved['indices']), 'same initial nodes')
        moment_rate = np.einsum('nij,nj->ni', old['operator'], old['initial_moments']) + old['forcing']
        hubble_clock_rate = np.einsum('nij,nj->ni', old['source_map_prime'], old['initial_moments']) + np.einsum('nij,nj->ni', old['source_map'], moment_rate)
        variants = {}
        for count in (6, 8):
            stencil = derivative_matrix(saved['initial_times'], count)
            native_rate = saved['node_rate' + str(count)]
            clock_correction = native_rate - hubble_clock_rate
            hubble_curvature = saved['weights'] @ differentiate(hubble_clock_rate, stencil)
            clock_curvature = saved['weights'] @ differentiate(clock_correction, stencil)
            total = saved['weights'] @ differentiate(native_rate, stencil)
            require(comparison(hubble_curvature + clock_curvature, total, ALGEBRA)['passed'], 'curvature decomposition identity')
            rows = saved['weights'][:, None] * differentiate(native_rate, stencil)
            endpoint_mask = np.zeros(len(rows), dtype=bool)
            endpoint_mask[:count] = True
            endpoint_mask[-count:] = True
            variants[str(count)] = dict(total=total.tolist(), hubble_clock_part=hubble_curvature.tolist(), native_clock_correction_part=clock_curvature.tolist(), endpoint_rows=np.sum(rows[endpoint_mask], axis=0).tolist(), interior_rows=np.sum(rows[~endpoint_mask], axis=0).tolist())
        changes = {name:(np.array(variants['8'][name]) - np.array(variants['6'][name])).tolist() for name in ('total', 'hubble_clock_part', 'native_clock_correction_part', 'endpoint_rows', 'interior_rows')}
        write('curvature-diagnostic.json', dict(completed=True, post_result_diagnostic=True, not_a_new_acceptance_gate=True, no_replacement_prediction=True, variants=variants, refinement_changes=changes, original_input_sha256=digest(old_path)))
        print(json.dumps(dict(variants=variants, refinement_changes=changes)), flush=True)

if __name__ == '__main__':
    main()
