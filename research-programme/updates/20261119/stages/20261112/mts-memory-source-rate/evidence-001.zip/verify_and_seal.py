from support import *
from datetime import datetime, timezone
import numpy as np

def main():
    with worker('verify-seal'):
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        freeze = read(ROOT / 'prediction-freeze.json')
        require(freeze['passed'] and not freeze['coefficients_fitted'] and not freeze['target_values_loaded'], 'prediction provenance')
        require(all(row['passed'] for row in freeze['checks'].values()), 'initial equation checks')
        controls = {}
        for case in ('cold', 'heavy'):
            saved = np.load(ROOT / (case + '-frozen-prediction.npz'), allow_pickle=False)
            report = read(ROOT / (case + '-result.json'))
            require(digest(Path(report['comparison_path'])) == report['comparison_sha256'], 'comparison input unchanged')
            for degree, name in ((1,'first'), (2,'second')):
                reconstructed = saved['initial'] + saved['elapsed'][:, None] * saved['first_rate8']
                if degree == 2:
                    reconstructed += .5 * saved['elapsed'][:, None]**2 * saved['second_rate8']
                controls[case + '_' + name + '_reconstruction'] = dict(passed=bool(np.array_equal(reconstructed, saved[name + '8'])))
                rows = report['orders'][str(degree)]
                computed = all(row['passed'] for group in ('residual', 'residual_plus_working_allowance') for row in rows[group].values())
                controls[case + '_' + name + '_verdict'] = dict(passed=computed == rows['passed'])
            controls[case + '_memory_rate_identity'] = comparison(saved['resolved_rate'] + saved['memory_rate'], saved['first_rate8'], ALGEBRA)
        require(all(row['passed'] for row in controls.values()), 'independent reconstruction and honest verdicts')
        result = read(ROOT / 'result.json')
        require(result['first_order_passed'] and not result['second_order_passed'], 'partial outcome retained')
        for path in ROOT.glob('*-start.json'):
            if path.name == 'verify-seal-start.json':
                continue
            require(exited(read(path))['exited'], 'task worker exited')
            require(read(ROOT / path.name.replace('-start.json','-end.json'))['state'] == 'completed', 'completed task worker')
        for path in ROOT.glob('*.py'):
            compile(path.read_text(), str(path), 'exec')
        require(not list(ROOT.rglob('__pycache__')), 'no caches')
        write('validation.json', dict(passed=True, controls=controls, first_order_accepted=True, sampled_quadratic_pressure_rejected=True, rejected_result_preserved=True, goal_left_paused=True))
    artifacts = {path.name:dict(sha256=digest(path), bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
    write('closeout.json', dict(state='complete', utc=datetime.now(timezone.utc).isoformat(), artifacts=artifacts, input_hashes=read(ROOT / 'frozen-inputs.json'), previous_closeout_sha256=EXPECTED, accepted='first-order paired short-time source prediction', rejected='sampled quadratic pressure coefficient', next='derive pressure curvature directly from the coupled equations', goal_left_paused=True))
    print(json.dumps(dict(sealed=len(artifacts), sha256=digest(ROOT / 'closeout.json'), outcome='first order passes; unstable quadratic pressure retained as rejected')), flush=True)

if __name__ == '__main__':
    main()
