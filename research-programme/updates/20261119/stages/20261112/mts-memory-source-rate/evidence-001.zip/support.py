import importlib.util
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-boundary-midpoint-check-20261112'
NATIVE_STAGE = POST / 'mts-native-right-edge-memory-20261111'
MEMORY = POST / 'mts-causal-memory-boundary-20261111'
MATCH = POST / 'mts-canonical-matching-state-20261111'
EXPECTED = '888235f6b9c249bcba572e553212afc4e8dbfef76ef8abe7a0451176715fb5d5'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

if digest(PREVIOUS / 'closeout.json') != EXPECTED:
    raise ValueError('Previous checkpoint changed')
previous_seal = json.loads((PREVIOUS / 'closeout.json').read_text())
native_seal = json.loads((NATIVE_STAGE / 'closeout.json').read_text())
if digest(NATIVE_STAGE / 'closeout.json') != '0180bb3143a7171f40deda4999dcb609cf720b514a95e4141a9e65e596f59267':
    raise ValueError('Native checkpoint changed')
if digest(NATIVE_STAGE / 'support.py') != native_seal['artifacts']['support.py']['sha256']:
    raise ValueError('Retained support changed')
spec = importlib.util.spec_from_file_location('retained_support', NATIVE_STAGE / 'support.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT, base.PREVIOUS = ROOT, PREVIOUS
EARLY, SPECTRUM = base.EARLY, base.SPECTRUM
require, read, write, guard = base.require, base.read, base.write, base.guard
worker, exited, check_hashes = base.worker, base.exited, base.check_hashes
comparison, GATE, ALGEBRA = base.comparison, base.GATE, base.ALGEBRA
