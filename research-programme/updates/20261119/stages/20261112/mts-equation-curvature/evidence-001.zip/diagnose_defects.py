from support import *
import numpy as np
from curvature_math import field_sources,weighted,comparison

with worker('diagnose-defects'):
    packet = load(ROOT/'heavy-curvature-readout.npz')
    values,weights = packet['packet'],packet['weights']
    matching = load(MATCH/'matching-state.npz')
    result = field_sources(values,float(matching['density0']))
    rate,rate_prime,hubble,hubble_prime,force,force_prime = values[:,2:8].T
    field,velocity,field_n,velocity_n,field_nn,velocity_nn,mass2,perturbation,speed,perturbation_prime,speed_prime,omega = values[:,32:44].T
    field_defect = result['field_prime']-velocity
    velocity_defect = result['velocity_prime']+2*hubble*velocity+mass2*field
    field_defect_prime = result['field_second']-result['velocity_prime']
    velocity_defect_prime = result['velocity_second']+2*hubble_prime*velocity+2*hubble*result['velocity_prime']+2*rate*mass2*field+mass2*result['field_prime']
    beta = values[:,1]/float(matching['density0'])
    defect_curvature = beta[:,None]*np.column_stack([velocity_defect_prime*speed+mass2*field_defect_prime*perturbation,values[:,14]*velocity_defect_prime*perturbation,velocity_defect_prime*speed-mass2*field_defect_prime*perturbation])
    remaining = result['second']-defect_curvature
    check = comparison(weighted(weights,remaining)+weighted(weights,defect_curvature),weighted(weights,result['second']),ALGEBRA)
    require(check['passed'],'fixed original partition recombines')
    cuts = (0,8,len(weights)-8,len(weights))
    partitions = []
    for begin,end in zip(cuts[:-1],cuts[1:]):
        partitions.append(dict(begin=begin,end=end,curvature=weighted(weights[begin:end],result['second'][begin:end]).tolist(),defect_derivative=weighted(weights[begin:end],defect_curvature[begin:end]).tolist()))
    frozen = load(ROOT/'heavy-frozen-prediction.npz')
    write('defect-diagnostic.json',dict(passed=True,recombination=check,total=weighted(weights,result['second']).tolist(),background_defect_derivative_contribution=weighted(weights,defect_curvature).tolist(),remainder=weighted(weights,remaining).tolist(),defect_max=[float(np.max(abs(field_defect))),float(np.max(abs(velocity_defect)))],defect_derivative_max=[float(np.max(abs(field_defect_prime))),float(np.max(abs(velocity_defect_prime)))],fixed_partitions=partitions,diagnostic_only=True,defects_removed_from_prediction=False,curvature_discrepancy_previous=[(frozen['second_rate']-load(PREVIOUS/'heavy-frozen-prediction.npz')['second_rate'+str(count)]).tolist() for count in (6,8)]))
    print(json.dumps(read(ROOT/'defect-diagnostic.json')),flush=True)
