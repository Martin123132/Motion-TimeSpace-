from support import *
import numpy as np
from curvature_math import comparison

with worker('score-curvature'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    reports = {}
    for case in ('cold','heavy'):
        freeze = read(ROOT/(case+'-prediction-freeze.json'))
        require(freeze['passed'] and not freeze['target_readout_loaded'] and not freeze['coefficients_fitted'],'accepted freeze before scoring')
        require(exited(read(ROOT/(case+'-capture-freeze-start.json')))['exited'],'capture finished before score')
        check_hashes(read(ROOT/(case+'-frozen-code.json')))
        target_path = MIDPOINT/(case+'-tested-readout.npz')
        target_seal = read(MIDPOINT/'closeout.json')
        require(digest(target_path)==target_seal['artifacts'][target_path.name]['sha256'],'sealed checked target')
        target = load(target_path)
        prediction = load(ROOT/(case+'-frozen-prediction.npz'))
        elapsed,expected = prediction['elapsed'],target['corrected_readout']
        require(np.array_equal(elapsed,target['current_time']-target['current_time'][0]),'same original reporting epochs')
        budget = target['updated_working_budget']+abs(prediction['initial_recapture_difference'])[None,:]+elapsed[:,None]*abs(prediction['rate_replay_difference'])[None,:]+.5*elapsed[:,None]**2*abs(prediction['sum_roundoff'])[None,:]
        scale = np.max(abs(expected),axis=0)
        orders = {}
        for order,label in ((1,'first'),(2,'second')):
            residual = prediction[label]-expected
            total = abs(residual)+budget
            checks = {name:comparison(prediction[label][:,column],expected[:,column]) for column,name in enumerate(('density','current','pressure'))}
            allowances = {name:comparison(total[:,column],np.zeros(len(total)),scale=scale[column]) for column,name in enumerate(('density','current','pressure'))}
            epoch_pass = np.all(total<=GATE*scale[None,:],axis=1)
            first_failure = next((index for index,passed in enumerate(epoch_pass) if not passed),len(epoch_pass))
            orders[str(order)] = dict(passed=all(row['passed'] for row in allowances.values()),residual=checks,residual_plus_working_allowance=allowances,first_failing_epoch=None if first_failure==len(epoch_pass) else first_failure,contiguous_passing_intervals=first_failure-1,epoch_pass=epoch_pass.tolist(),final_residual=residual[-1].tolist(),final_prediction=prediction[label][-1].tolist(),total_by_epoch=total.tolist(),elapsed=elapsed.tolist())
        report = dict(completed=True,orders=orders,target_path=str(target_path),target_sha256=digest(target_path),expected_source_scale=scale.tolist(),new_coefficients_fitted=False,uncertainty_budget_certified=False,goal_left_paused=True)
        write(case+'-result.json',report)
        reports[case]=report
        print(json.dumps(dict(case=case,orders={order:dict(passed=row['passed'],residual=row['residual'],allowance=row['residual_plus_working_allowance'],passing_intervals=row['contiguous_passing_intervals']) for order,row in orders.items()})),flush=True)
    write('result.json',dict(completed=True,first_order_passed=all(row['orders']['1']['passed'] for row in reports.values()),second_order_passed=all(row['orders']['2']['passed'] for row in reports.values()),equation_owned_curvature_derived=True,unchanged_gates=True,goal_left_paused=True))
