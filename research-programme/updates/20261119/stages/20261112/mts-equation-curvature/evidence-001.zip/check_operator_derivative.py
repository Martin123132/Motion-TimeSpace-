from support import *
import numpy as np
import sympy as sp
from curvature_math import field_sources,weighted,comparison


with worker('operator-derivative'):
    saved = load(ROOT/'heavy-curvature-readout.npz')
    packet,weights = saved['packet'],saved['weights']
    density0 = float(load(MATCH/'matching-state.npz')['density0'])
    source = field_sources(packet,density0)
    scale,rate,rate_prime,hubble,hubble_prime,force,force_prime = packet[:,1:8].T
    wave = packet[:,14]
    field,velocity,field_n,velocity_n,field_nn,velocity_nn,mass2,perturbation,speed,perturbation_prime,speed_prime,omega = packet[:,32:44].T
    beta = scale/density0
    mass_prime = 2*rate*mass2
    field_prime,velocity_prime = source['field_prime'],source['velocity_prime']
    field_defect = field_prime-velocity
    velocity_defect = velocity_prime+2*hubble*velocity+mass2*field
    field_defect_prime = source['field_second']-velocity_prime
    velocity_defect_prime = source['velocity_second']+2*hubble_prime*velocity+2*hubble*velocity_prime+mass_prime*field+mass2*field_prime
    norm = field**2+velocity**2/mass2
    norm_prime = 2*field*field_prime+2*velocity*velocity_prime/mass2-velocity**2*mass_prime/mass2**2
    dual = np.column_stack([field,velocity/mass2])/norm[:,None]
    dual_prime = np.column_stack([field_prime,velocity_prime/mass2-velocity*mass_prime/mass2**2])/norm[:,None]-dual*(norm_prime/norm)[:,None]
    select_u = np.zeros((len(packet),4))
    select_w = np.zeros_like(select_u)
    select_u_prime = np.zeros_like(select_u)
    select_w_prime = np.zeros_like(select_u)
    select_u[:,[0,2]],select_w[:,[1,3]] = dual,dual
    select_u_prime[:,[0,2]],select_w_prime[:,[1,3]] = dual_prime,dual_prime
    operator = np.zeros((len(packet),4,4))
    operator_prime = np.zeros_like(operator)
    for diagonal in range(4):
        friction = (0,2,2,4)[diagonal]
        operator[:,diagonal,diagonal] = rate-friction*hubble
        operator_prime[:,diagonal,diagonal] = rate_prime-friction*hubble_prime
    operator[:,0,1]=operator[:,0,2]=operator[:,1,3]=operator[:,2,3]=1
    for row,column,gradient in ((1,0,True),(2,0,False),(3,1,False),(3,2,True)):
        operator[:,row,column] = -mass2-(wave**2 if gradient else 0)
        operator_prime[:,row,column] = -mass_prime
    for row,defect,defect_prime,selector,selector_prime in ((0,field_defect,field_defect_prime,select_u,select_u_prime),(1,field_defect,field_defect_prime,select_w,select_w_prime),(2,velocity_defect,velocity_defect_prime,select_u,select_u_prime),(3,velocity_defect,velocity_defect_prime,select_w,select_w_prime)):
        operator[:,row,:] += defect[:,None]*selector
        operator_prime[:,row,:] += defect_prime[:,None]*selector+defect[:,None]*selector_prime
    gravity = np.column_stack([np.zeros(len(packet)),beta*field*velocity,np.zeros(len(packet)),beta*velocity**2])
    gravity_prime = rate[:,None]*gravity+np.column_stack([np.zeros(len(packet)),beta*(field_prime*velocity+field*velocity_prime),np.zeros(len(packet)),2*beta*velocity*velocity_prime])
    density_map = np.column_stack([mass2,np.zeros((len(packet),2)),np.ones(len(packet))])
    density_map_prime = np.column_stack([mass_prime,np.zeros((len(packet),3))])
    metric_coefficient = 1/(2*hubble*beta)
    metric_coefficient_prime = -metric_coefficient*(hubble_prime/hubble+rate)
    outer = lambda left,right:np.einsum('ni,nj->nij',left,right)
    operator -= metric_coefficient[:,None,None]*outer(gravity,density_map)
    operator_prime -= metric_coefficient_prime[:,None,None]*outer(gravity,density_map)+metric_coefficient[:,None,None]*(outer(gravity_prime,density_map)+outer(gravity,density_map_prime))
    rest = force-source['source'][:,0]/(2*wave*hubble*beta)
    rest_prime = force_prime-(source['first'][:,0]-source['source'][:,0]*(hubble_prime/hubble+rate))/(2*wave*hubble*beta)
    forcing = -wave[:,None]*rest[:,None]*gravity
    forcing_prime = -wave[:,None]*(rest_prime[:,None]*gravity+rest[:,None]*gravity_prime)
    moment = beta[:,None]*outer(np.column_stack([field,velocity]),np.column_stack([perturbation,speed])).reshape(-1,4)
    moment_prime = np.einsum('nij,nj->ni',operator,moment)+forcing
    moment_second = np.einsum('nij,nj->ni',operator_prime+np.einsum('nij,njk->nik',operator,operator),moment)+np.einsum('nij,nj->ni',operator,forcing)+forcing_prime
    mapping = np.zeros((len(packet),3,4))
    mapping[:,0,0],mapping[:,0,3],mapping[:,1,2],mapping[:,2,0],mapping[:,2,3] = mass2,1,wave,-mass2,1
    mapping_prime,mapping_second = np.zeros_like(mapping),np.zeros_like(mapping)
    mapping_prime[:,0,0],mapping_prime[:,2,0] = mass_prime,-mass_prime
    mass_second = (2*rate_prime+4*rate**2)*mass2
    mapping_second[:,0,0],mapping_second[:,2,0] = mass_second,-mass_second
    matrix_first = np.einsum('nij,nj->ni',mapping_prime,moment)+np.einsum('nij,nj->ni',mapping,moment_prime)
    matrix_second = np.einsum('nij,nj->ni',mapping_second,moment)+2*np.einsum('nij,nj->ni',mapping_prime,moment_prime)+np.einsum('nij,nj->ni',mapping,moment_second)
    controls = {}
    for column,label in enumerate(('density','current','pressure')):
        controls[label+'_first'] = comparison(matrix_first[:,column],source['first'][:,column],ALGEBRA)
        controls[label+'_second'] = comparison(matrix_second[:,column],source['second'][:,column],ALGEBRA)
    clock = sp.symbols('clock',real=True)
    beta_fn,rate_fn = sp.Function('beta')(clock),sp.Function('rate')(clock)
    base_fn = sp.Function('bare')(clock)
    identity = sp.diff(beta_fn*base_fn,clock,2).subs({sp.diff(beta_fn,clock,2):(sp.diff(rate_fn,clock)+rate_fn**2)*beta_fn,sp.diff(beta_fn,clock):rate_fn*beta_fn})-beta_fn*(sp.diff(base_fn,clock,2)+2*rate_fn*sp.diff(base_fn,clock)+(sp.diff(rate_fn,clock)+rate_fn**2)*base_fn)
    controls['symbolic_beta_product'] = dict(passed=sp.simplify(identity)==0)
    density_fn,eta_fn,hubble_fn = [sp.Function(name)(clock) for name in ('density','eta','hubble')]
    wavenumber = sp.symbols('wavenumber',nonzero=True)
    metric_fn = (density_fn/(2*wavenumber)+eta_fn)/hubble_fn
    metric_derivative = (sp.diff(density_fn,clock)/(2*wavenumber)+sp.diff(eta_fn,clock))/hubble_fn-metric_fn*sp.diff(hubble_fn,clock)/hubble_fn
    controls['symbolic_metric_constraint'] = dict(passed=sp.simplify(sp.diff(metric_fn,clock)-metric_derivative)==0)
    mass,velocity_symbol,amplitude = sp.symbols('mass velocity amplitude',positive=True)
    nu_density = amplitude*sp.sqrt(1+mass**2)
    nu_pressure = amplitude/(3*sp.sqrt(1+mass**2))
    controls['symbolic_neutrino_scale_derivative'] = dict(passed=sp.simplify(mass*sp.diff(nu_density,mass)-nu_density+3*nu_pressure)==0)
    require(all(row['passed'] for row in controls.values()),'operator and exact identity checks')
    difference = weighted(weights,matrix_second)-weighted(weights,source['second'])
    write('operator-validation.json',dict(passed=True,checks=controls,weighted_curvature=weighted(weights,matrix_second).tolist(),weighted_difference=difference.tolist(),self_gravity_differentiated=True,current_rest_derivative_included=True,rest_derivative_max=float(np.max(abs(rest_prime))),representation_defects_differentiated=True))
    print(json.dumps(dict(passed=True,checks=len(controls),weighted_difference=difference.tolist())),flush=True)
