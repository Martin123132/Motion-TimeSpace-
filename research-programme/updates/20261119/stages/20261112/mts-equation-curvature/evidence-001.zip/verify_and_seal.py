from support import *
from datetime import datetime,timezone
import numpy as np
import sympy as sp
from curvature_math import weighted,comparison

with worker('verify-seal'):
    check_hashes(read(ROOT/'frozen-inputs.json'))
    build = read(ROOT/'native-build-result.json')
    check_hashes(build['source_hashes'])
    require(build['temporary_mapping_removed'],'temporary mapping released')
    require(all(exited(row['identity'])['exited'] for row in build['children']),'compiler children exited')
    for relative,checksum in read(ROOT/'native-bootstrap-result.json')['copied_source_hashes'].items():
        require(digest(NATIVE/relative)==checksum,'retained native original intact')
        if relative.replace('\\','/')!='fortran/camb_python.f90':
            require(digest(ROOT/'native'/relative)==checksum,'no unapproved native edit')
    controls = {}
    counts = {}
    for case in ('cold','heavy'):
        check_hashes(read(ROOT/(case+'-frozen-code.json')))
        freeze = read(ROOT/(case+'-prediction-freeze.json'))
        require(freeze['passed'] and all(row['passed'] for row in freeze['checks'].values()),'freeze controls passed')
        require(not freeze['coefficients_fitted'] and not freeze['target_readout_loaded'],'coefficient provenance')
        counts[case] = len(freeze['checks'])
        frozen = load(ROOT/(case+'-frozen-prediction.npz'))
        report = read(ROOT/(case+'-result.json'))
        target = load(report['target_path'])
        require(digest(report['target_path'])==report['target_sha256'],'comparison unchanged')
        require(read(ROOT/(case+'-owner-release.json'))['cleared'],'native owner released')
        elapsed,expected = frozen['elapsed'],target['corrected_readout']
        for coefficient in ('first','second'):
            controls[case+'_'+coefficient+'_weighted'] = comparison(weighted(frozen['weights'],frozen['node_'+coefficient]),frozen[coefficient+'_rate'],ALGEBRA)
        budget = target['updated_working_budget']+abs(frozen['initial_recapture_difference'])[None,:]+elapsed[:,None]*abs(frozen['rate_replay_difference'])[None,:]+.5*elapsed[:,None]**2*abs(frozen['sum_roundoff'])[None,:]
        for degree,label in ((1,'first'),(2,'second')):
            reconstructed = frozen['initial']+elapsed[:,None]*frozen['first_rate']
            if degree==2:
                reconstructed += .5*elapsed[:,None]**2*frozen['second_rate']
            controls[case+'_'+label+'_reconstruction'] = dict(passed=bool(np.array_equal(reconstructed,frozen[label])))
            acceptance = np.all(abs(reconstructed-expected)+budget<=GATE*np.max(abs(expected),axis=0)[None,:],axis=1)
            controls[case+'_'+label+'_verdict'] = dict(passed=acceptance.tolist()==report['orders'][str(degree)]['epoch_pass'] and bool(np.all(acceptance))==report['orders'][str(degree)]['passed'])
    variable,limit = sp.symbols('variable limit',real=True)
    for index,(coefficient,defect) in enumerate(((1,variable),(1+variable,variable**2),(1+variable+variable**3,2-variable+variable**4),(variable**2,1-variable**3))):
        coefficient,defect = sp.sympify(coefficient),sp.sympify(defect)
        direct = sp.integrate((limit-variable)*coefficient*sp.diff(defect,variable),(variable,0,limit))
        integrated = -limit*coefficient.subs(variable,0)*defect.subs(variable,0)+sp.integrate(coefficient*defect,(variable,0,limit))-sp.integrate((limit-variable)*sp.diff(coefficient,variable)*defect,(variable,0,limit))
        controls['integration_by_parts_'+str(index)] = dict(passed=sp.simplify(direct-integrated)==0)
    operator = read(ROOT/'operator-validation.json')
    require(operator['passed'] and all(row['passed'] for row in operator['checks'].values()),'independent operator checks')
    require(read(ROOT/'defect-diagnostic.json')['passed'],'exact defect partition')
    require(all(row['passed'] for row in controls.values()),'independent final verification')
    result = read(ROOT/'result.json')
    require(result['first_order_passed'] and not result['second_order_passed'],'honest partial prediction outcome')
    workers = []
    for path in ROOT.glob('*-start.json'):
        if path.name=='verify-seal-start.json':
            continue
        require(exited(read(path))['exited'],'stage worker exited')
        require(read(ROOT/path.name.replace('-start.json','-end.json'))['state']=='completed','stage worker completed')
        workers.append(path.name)
    for path in ROOT.glob('*.py'):
        compile(path.read_text(),str(path),'exec')
    require(not list(ROOT.rglob('__pycache__')),'no Python caches')
    write('validation.json',dict(passed=True,checks=controls,preparation_and_derivative_check_counts=counts,operator_checks=len(operator['checks']),prior_workers_exited=workers,unchanged_gates=True,goal_left_paused=True,quadratic_full_span_rejected=True))
artifacts = {path.relative_to(ROOT).as_posix():dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.rglob('*')) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
write('closeout.json',dict(state='complete',utc=datetime.now(timezone.utc).isoformat(),artifacts=artifacts,input_hashes=read(ROOT/'frozen-inputs.json'),previous_closeout_sha256=EXPECTED,accepted='equation-owned coupled source curvature; first-order full-window and quadratic first-five-interval tests',rejected='constant-curvature heavy pressure prediction over all eight intervals',next='integrate representation-defect terms using derived integration-by-parts identity',goal_left_paused=True))
print(json.dumps(dict(sealed=len(artifacts),closeout_sha256=digest(ROOT/'closeout.json'),validation_passed=True,counts=counts)),flush=True)
