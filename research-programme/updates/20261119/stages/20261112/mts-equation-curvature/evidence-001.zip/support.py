import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
PREVIOUS = POST / 'mts-memory-source-rate-20261112'
NATIVE_STAGE = POST / 'mts-native-right-edge-memory-20261111'
MIDPOINT = POST / 'mts-boundary-midpoint-check-20261112'
MATCH = POST / 'mts-canonical-matching-state-20261111'
EXPECTED = '3973b087bfec7beace5af8e71d0d3bbf35794e9dac3bd65c36305c42baec5838'

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

if digest(PREVIOUS / 'closeout.json') != EXPECTED:
    raise ValueError('Previous checkpoint changed')
native_seal = json.loads((NATIVE_STAGE / 'closeout.json').read_text())
if digest(NATIVE_STAGE / 'closeout.json') != '0180bb3143a7171f40deda4999dcb609cf720b514a95e4141a9e65e596f59267':
    raise ValueError('Native checkpoint changed')
if digest(NATIVE_STAGE / 'support.py') != native_seal['artifacts']['support.py']['sha256']:
    raise ValueError('Retained support changed')
spec = importlib.util.spec_from_file_location('retained_support', NATIVE_STAGE / 'support.py')
base = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base)
base.ROOT, base.PREVIOUS = ROOT, PREVIOUS
NATIVE = NATIVE_STAGE / 'native'
EARLY, SPECTRUM, BRANCH, MATCHING = base.EARLY, base.SPECTRUM, base.BRANCH, base.MATCHING
require, read, write, guard = base.require, base.read, base.write, base.guard
worker, exited, check_hashes = base.worker, base.exited, base.check_hashes
comparison, GATE, ALGEBRA = base.comparison, base.GATE, base.ALGEBRA
os, sys, time, psutil = base.os, base.sys, base.time, base.psutil

def load(path):
    import numpy as np
    with np.load(path, allow_pickle=False) as packet:
        return {name: packet[name].copy() for name in packet.files}
