from support import *
import argparse
import ast
import ctypes
import numpy as np
from scipy.interpolate import CubicSpline
from curvature_math import field_sources, weighted, comparison


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case',choices=('cold','heavy'))
    args = parser.parse_args()
    case = args.case
    with worker(case+'-capture-freeze'):
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        build = read(ROOT / 'native-build-result.json')
        require(build['state']=='completed' and build['temporary_mapping_removed'], 'private readout build')
        require(all(exited(row['identity'])['exited'] for row in build['children']), 'compiler exited')
        local = ROOT / 'native'
        require(digest(local/'camb/cambdll.dll')==build['dll_sha256'],'frozen native DLL')
        files = [ROOT/'capture_curvature.py',ROOT/'curvature_math.py',ROOT/'support.py',ROOT/'PROTOCOL.md',local/'fortran/mts_curvature_hook.inc',local/'fortran/camb_python.f90',local/'camb/cambdll.dll']
        write(case+'-frozen-code.json',{str(path):digest(path) for path in files})
        sys.path.insert(0,str(local))
        import camb
        from camb.mts import MTSTwoField
        sys.path.append(str(BRANCH/'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        factory_path = MATCHING/'matching_common.py'
        factory = next(node for node in ast.parse(factory_path.read_text()).body if isinstance(node,ast.FunctionDef) and node.name=='params_for')
        namespace = dict(np=np,previous=radiation_common,MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory],type_ignores=[]),str(factory_path),'exec'),namespace)
        table_path = EARLY/'runs/backgrounds'/(case+'.npz')
        params = namespace['params_for'](table_path)
        saved = load(SPECTRUM/'runs/exact-grid/chunk-0384.npz' if case=='heavy' else EARLY/'runs/final-bg8-start/cold.npz')
        matching = load(MATCH/'matching-state.npz')
        indices,weights = matching['indices'],matching['weights']
        require(np.array_equal(indices,np.arange(1991,2893)), 'original902 preparation indices')
        observer = ctypes.CDLL(str(POST/'mts-metric-feedback-20261107/observer.dll'))
        callback = ctypes.cast(observer.source_func_,ctypes.c_void_p)
        library = ctypes.CDLL(str(local/'camb/cambdll.dll'))
        reset,copy = library.mts_curv_reset,library.mts_curv_copy
        reset.restype=copy.restype=None
        reset.argtypes=[]
        copy.argtypes=[ctypes.c_int,ctypes.c_void_p]
        scalar = lambda name:ctypes.c_int.in_dll(library,'mts_curv_'+name)
        native = camb.get_background(params)
        try:
            clock = np.ascontiguousarray(native.conformal_time(1/saved['requested_scale']-1,tol=1e-10))
            require(np.array_equal(clock,saved['conformal_time']),'original native clock')
            modes = np.ascontiguousarray(saved['modes'])
            selected = int(np.flatnonzero(modes==5.)[0])
            names = list(camb.model.evolve_names)
            native.Params.Accuracy.IntTolBoost=6
            native.Params.Accuracy.lAccuracyBoost=4
            output = np.zeros((len(modes),len(clock),len(names)+30))
            reset()
            scalar('begin').value=int(indices[0])+1
            scalar('end').value=int(indices[-1])+1
            scalar('target').value=selected+1
            code = camb.results.CAMB_TimeEvolution(ctypes.byref(native),ctypes.byref(ctypes.c_int(len(modes))),modes,ctypes.byref(ctypes.c_int(len(clock))),clock,ctypes.byref(ctypes.c_int(output.shape[-1])),output,ctypes.byref(ctypes.c_int(30)),ctypes.byref(callback))
            status = dict(code=int(code),count=scalar('count').value,status=scalar('status').value)
            write(case+'-native-status.json',status)
            require(code==0 and status['status']==2 and status['count']==len(indices),'bounded preparation readout')
            packet = np.zeros((len(indices),96))
            copy(len(indices),ctypes.c_void_p(packet.ctypes.data))
            require(np.isfinite(packet).all(),'finite readout')
            np.savez_compressed(ROOT/(case+'-curvature-readout.npz'),packet=packet,indices=indices,weights=weights)
            checks = {}
            for mode in range(len(modes)):
                for column,name in enumerate(saved['names']):
                    checks['preparation_'+str(mode)+'_'+str(name)] = comparison(output[mode,:,names.index(str(name))],saved['values'][mode,:,column])
            checks['clock'] = comparison(packet[:,0],clock[indices],ALGEBRA)
            checks['density_constraint'] = comparison(packet[:,8],packet[:,46],ALGEBRA)
            checks['background_constraint'] = comparison(packet[:,12],packet[:,44],ALGEBRA)
            checks['force_constraint'] = comparison(packet[:,6],packet[:,17],ALGEBRA)
            checks['friedmann_constraint'] = comparison(3*packet[:,4]**2,packet[:,12],ALGEBRA)
            cold = read(MATCH/'matching-validation.json')['cold']
            elapsed = clock[2892:2901]-clock[indices[-1]]
            previous = load(PREVIOUS/(case+'-frozen-prediction.npz'))
            initial = previous['initial']
            if case=='heavy':
                values = field_sources(packet,float(matching['density0']))
                source,first,second = [values[key] for key in ('source','first','second')]
                beta = packet[:,1]/float(matching['density0'])
                checks['source_native'] = comparison(source,beta[:,None]*packet[:,[81,83,82]],ALGEBRA)
                checks['curvature_product_identity'] = comparison(second,values['tensor_second'],ALGEBRA)
                jet = packet[:,32:44]
                checks['field_rhs'] = comparison(jet[:,9],jet[:,8],ALGEBRA)
                expected_speed = -2*packet[:,4]*jet[:,8]-(jet[:,6]+packet[:,14]**2)*jet[:,7]-packet[:,14]*packet[:,6]*jet[:,1]
                checks['speed_rhs'] = comparison(jet[:,10],expected_speed,ALGEBRA)
                table = load(table_path)
                for field,offset in (('phi_h',0),('phidot_h',1)):
                    spline = CubicSpline(table['heavy_efold'],table[field],bc_type='natural')
                    for order in range(3):
                        checks[field+'_spline_'+str(order)] = comparison(jet[:,offset+2*order],spline(np.log(packet[:,1]),order),ALGEBRA)
            else:
                source = np.column_stack([cold['normalization']*packet[:,63],np.zeros((len(indices),2))])
                first = np.column_stack([-5*cold['normalization']*packet[:,6],np.zeros((len(indices),2))])
                second = np.column_stack([-5*cold['normalization']*packet[:,7],np.zeros((len(indices),2))])
            first_rate,second_rate = weighted(weights,first),weighted(weights,second)
            checks['initial_sources'] = comparison(weighted(weights,source),initial)
            checks['first_rate_replay'] = comparison(first_rate,previous['first_rate8'])
            checks['curvature_sum_roundoff'] = comparison(weights@second,second_rate,ALGEBRA,scale=max(float(np.max(abs(second_rate))),1e-30))
            first_prediction = initial+elapsed[:,None]*first_rate
            second_prediction = first_prediction+.5*elapsed[:,None]**2*second_rate
            np.savez_compressed(ROOT/(case+'-frozen-prediction.npz'),elapsed=elapsed,initial=initial,first_rate=first_rate,second_rate=second_rate,first=first_prediction,second=second_prediction,node_source=source,node_first=first,node_second=second,weights=weights,initial_recapture_difference=weighted(weights,source)-initial,rate_replay_difference=first_rate-previous['first_rate8'],sum_roundoff=weighted(weights,second)-weights@second)
            passed = all(row['passed'] for row in checks.values())
            report = dict(passed=passed,checks=checks,first_rate=first_rate.tolist(),second_rate=second_rate.tolist(),target_readout_loaded=False,coefficients_fitted=False,original_preparation_parity_performed=True,legacy_neutrino_background_derivative_max_difference=float(np.max(abs(packet[:,16]))),original_bank_unchanged=True)
            write(case+'-prediction-freeze.json',report)
            print(json.dumps(dict(case=case,passed=passed,failed={key:value for key,value in checks.items() if not value['passed']},first_rate=first_rate.tolist(),second_rate=second_rate.tolist())),flush=True)
            check_hashes(read(ROOT/(case+'-frozen-code.json')))
            check_hashes(read(ROOT/'frozen-inputs.json'))
        finally:
            reset()
            cleared=scalar('count').value==0 and scalar('status').value==0
            del native
            write(case+'-owner-release.json',dict(cleared=cleared,native_reference_released=True))
            require(cleared,'native readout released')


if __name__=='__main__':
    main()
