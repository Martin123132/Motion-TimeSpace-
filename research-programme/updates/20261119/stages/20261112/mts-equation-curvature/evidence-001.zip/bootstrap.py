from support import *
import shutil

with worker('bootstrap'):
    require(not (ROOT / 'native').exists(), 'new private destination')
    copied = {}
    for relative in read(NATIVE_STAGE / 'native-bootstrap-result.json')['copied_source_hashes']:
        source = NATIVE / relative
        require(digest(source) == native_seal['artifacts']['native/' + relative.replace('\\', '/')]['sha256'], 'sealed native source')
        destination = ROOT / 'native' / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        copied[relative] = digest(source)
    write('native-bootstrap-result.json', dict(completed=True, original=str(NATIVE), copied_source_hashes=copied))
    files = [PREVIOUS / 'closeout.json', NATIVE_STAGE / 'closeout.json', MATCH / 'matching-state.npz', MATCH / 'carrier-initial-state.npz', MATCH / 'matching-validation.json', SPECTRUM / 'runs/exact-grid/chunk-0384.npz', EARLY / 'runs/final-bg8-start/cold.npz', EARLY / 'runs/backgrounds/heavy.npz', EARLY / 'runs/backgrounds/cold.npz', MATCHING / 'matching_common.py', POST / 'mts-metric-feedback-20261107/observer.dll']
    write('frozen-inputs.json', {str(path):digest(path) for path in files})
    print(json.dumps(dict(copied=len(copied), frozen=len(files))), flush=True)
