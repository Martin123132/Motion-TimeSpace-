from common import *
from feedback_support import *
from scipy.integrate import simpson


def relative(actual, expected):
    return float(np.linalg.norm(np.asarray(actual)-np.asarray(expected))
                 / max(np.linalg.norm(expected), np.linalg.norm(actual), 1e-80))


def main():
    modest()
    output = STAGE / 'audit'
    output.mkdir(exist_ok=False)
    inputs = verify_inputs()
    consumed, accepted, verified = {}, {}, {}
    rows, control_rows = [], []
    counts = dict(source_banks=0, forward_responses=0, adjoint_projections=0, physical_channels=0)

    def hashes(records):
        for path, seal in records.items():
            guard()
            if path not in verified:
                require(digest(path) == seal, 'unchanged source ' + path)
                verified[path] = seal
            require(verified[path] == seal, 'consistent source hash')
            consumed[path] = seal

    def accept(path, require_pass=True):
        report = read(path)
        require(report.get('passed') or (not require_pass and report.get('completed')), 'completed report ' + str(path))
        for name in ('inputs', 'sources', 'consumed'):
            hashes(report.get(name, {}))
        accepted[str(path)] = digest(path)
        return report

    for label in ('half', 'balanced', 'double'):
        root = STAGE / label
        prepared = accept(root / 'preparation-01/result.json')
        require(len(prepared['models']) == 2, 'paired source preparation')
        projected_report = accept(root / 'projection-01/result.json')
        comparison = accept(root / 'comparison-01/result.json', False)
        require(len(comparison['records']) == 40 and len(comparison['controls']) == 16, 'paired complete comparisons')
        for model in ('heavy', 'cold'):
            prepared_item = next(item for item in prepared['models'] if item['model'] == model)
            hashes({prepared_item['path']: prepared_item['sha256']})
            prepared_packet = load(prepared_item['path'])
            require(len(prepared_packet['efold']) == 9 and np.all(prepared_packet['normalization'] > 0), 'nine nodes and invertible component scaling')
            require(all(item['maximum_conversion_error'] < ALGEBRA for item in prepared_item['checks']), 'complete real-source conversion')
            counts['source_banks'] += 1
            source_report = read(FEEDBACK_STAGE / label / 'feedback-01/result.json')
            source_nodes = next(item['nodes'] for item in source_report['reports'] if item['model'] == model)
            maximum = np.zeros((2, 2))
            for index, source_node in enumerate(source_nodes):
                source_path = owned(source_node['path'])
                hashes({str(source_path): source_node['sha256']})
                with np.load(source_path) as packet:
                    converted, modes, sine = real_coefficients(packet['feedback_coefficients'])
                    maximum = np.maximum(maximum, np.linalg.norm(packet['feedback'], axis=-1).max(axis=0))
                require(np.array_equal(prepared_packet['modes'], modes) and np.array_equal(prepared_packet['sine'], sine), 'all original harmonics')
                require(relative(prepared_packet['coefficients'][index], converted.reshape(len(modes), -1)) < ALGEBRA, 'unchanged source coefficients')
                require(prepared_packet['efold'][index] == source_node['efold'], 'original source epochs')
            maximum[maximum == 0] = 1.
            require(np.array_equal(maximum, prepared_packet['normalization']), 'normalization derived from all fine nodes')
            forward_report = accept(root / 'forward-01' / model / 'result.json')
            require({item['control'] for item in forward_report['reports']} == {'fine', 'step-coarse', 'source-coarse'}, 'three frozen response controls')
            packets = {}
            for item in forward_report['reports']:
                hashes({item['path']: item['sha256']})
                packet = load(item['path'])
                require(np.all(np.isfinite(packet['response'])) and np.count_nonzero(packet['response'][0]) == 0, 'finite response and unchanged incoming preparation')
                require(np.array_equal(packet['normalization'], prepared_packet['normalization']), 'same scaling for every control')
                require(item['phase_error'] < ALGEBRA and item['successful_execution'], 'same independently calculated phase')
                require(item['steps'] == (2048 if item['control'] == 'step-coarse' else 4096), 'unchanged response step controls')
                require(item['source_nodes'] == (5 if item['control'] == 'source-coarse' else 9), 'unchanged source restriction')
                if model == 'cold':
                    require(np.count_nonzero(packet['response'][:, 0]) == 0, 'exact baseline normal-source control')
                packets[item['control']] = packet
                counts['forward_responses'] += 1
            fine = packets['fine']['response']
            scale = np.maximum(np.linalg.norm(fine, axis=-1).max(axis=0), 1e-80)
            for control in ('step-coarse', 'source-coarse'):
                errors = np.linalg.norm(packets[control]['response']-fine, axis=-1).max(axis=0)/scale
                for component in range(2):
                    for branch, name in enumerate(BRANCHES):
                        entry = next(item for item in comparison['controls'] if item['model'] == model and item['control'] == control
                                     and item['component'] == component and item['branch'] == name)
                        require(abs(errors[component, branch]-entry['feedback_relative']) <= ALGEBRA*max(abs(entry['feedback_relative']), 1e-80), 'independent strict feedback refinement')
                        require(entry['resolved'] == bool(errors[component, branch] < GATE), 'source/control failure not hidden')
            item = next(item for item in projected_report['reports'] if item['model'] == model)
            hashes({item['path']: item['sha256'], item['chunks_path']: item['chunks_sha256']})
            packet, chunks = load(item['path']), load(item['chunks_path'])
            require(len(packet['efold']) == 8193 and np.array_equal(packet['efold'][[0,-1]], packets['fine']['efold'][[0,-1]]), 'same full quadrature interval')
            for control in ('fine', 'source-coarse', 'adjoint-coarse', 'step-coarse'):
                values = packet['projected_'+control]
                require(values.shape == (8193, 2, 2, 10) and np.isfinite(values).all(), 'complete paired physical projection')
                for quadrature, stride in (('fine', 1), ('coarse', 2)):
                    accumulated = dict(signed=[], absolute=[], component_absolute=[], cauchy=[], component_cauchy=[])
                    for begin in range(0, 8192, 128):
                        epochs = packet['efold'][begin:begin+129:stride]
                        current = values[begin:begin+129:stride]
                        combined = current.sum(axis=1)
                        length = epochs[-1]-epochs[0]
                        calculated = dict(signed=simpson(current, x=epochs, axis=0),
                            absolute=simpson(abs(combined), x=epochs, axis=0),
                            component_absolute=simpson(abs(current), x=epochs, axis=0),
                            cauchy=np.sqrt(length*np.maximum(simpson(combined**2, x=epochs, axis=0), 0.)),
                            component_cauchy=np.sqrt(length*np.maximum(simpson(current**2, x=epochs, axis=0), 0.)))
                        for name, value in calculated.items():
                            accumulated[name].append(value)
                    for name, values_list in accumulated.items():
                        key=control+'_'+quadrature+'_'+name
                        require(relative(np.array(values_list), chunks[key]) < ALGEBRA, 'independent chunk quadrature')
                        require(relative(np.sum(values_list, axis=0), packet[key]) < ALGEBRA, 'independent total quadrature')
            counts['adjoint_projections'] += 1
            output_item = comparison['predictions'][model]
            hashes({output_item['path']: output_item['sha256']})
            current = load(output_item['path'])
            require(np.array_equal(current['rows'], packet['rows']), 'same terminal dual')
            physical = np.einsum('obd,cbd->cbo', current['rows'], fine[-1])
            require(relative(physical, current['forward']) < ALGEBRA, 'independent forward physical projection')
            require(relative(current['prior_candidate']+physical.sum(axis=0), current['physical_candidate']) < ALGEBRA, 'no refitted physical prediction')
            for entry in comparison['records']:
                if entry['model'] != model:
                    continue
                branch, column = BRANCHES.index(entry['branch']), NAMES.index(entry['channel'])
                expected_shift = physical[:, branch, column].sum()
                require(abs(expected_shift-entry['feedback_shift']) <= ALGEBRA*max(abs(expected_shift),1e-80), 'reported signed physical response')
                error = abs(current['physical_candidate'][branch,column]-current['reference'][branch,column])/current['reference_scale'][branch,column]
                require(abs(error-entry['new_reference_error']) <= ALGEBRA*max(error,1e-80), 'reported retained physical error')
                require(entry['physical_pass'] == bool(error<GATE), 'physical pass classification')
                numerical = max(entry['identity'], entry['forward_step'], *entry['diagnostics'].values()) < GATE and entry['forward_inside_numerical_budget']
                require(entry['numerical_pass'] == bool(numerical), 'numerical pass classification')
                counts['physical_channels'] += 1
        require(comparison['passed'] == all(item['numerical_pass'] and item['physical_pass'] for item in comparison['records']), 'comparison acceptance matches evidence')
        require(comparison['strict_feedback_source_resolved'] == all(item['resolved'] for item in comparison['controls'] if item['control']=='source-coarse'), 'source interpolation status')
        rows.extend(dict(label=label, **item) for item in comparison['records'])
        control_rows.extend(dict(label=label, **item) for item in comparison['controls'])
    require(counts == dict(source_banks=6, forward_responses=18, adjoint_projections=6, physical_channels=120), 'complete planned propagation matrix')
    for path in STAGE.rglob('freeze.json'):
        freeze=read(path)
        hashes(freeze['sources'])
        hashes(freeze['inputs'])
        hashes(freeze.get('consumed', {}))
    starts=list(STAGE.glob('*.start.json'))
    require(len(starts)==16, 'all expected numerical jobs tracked')
    for path in starts:
        if path.name=='audit-01.start.json':
            continue
        start=read(path)
        end=read(Path(str(path).replace('.start.json','.end.json')))
        require(start['pid']==end['pid'] and start['created']==end['created'] and start['command']==end['command']
                and end['exit_code']==0, 'same successful owned process')
        hashes({start['source_path']:start['source_sha256']})
    require(not list(STAGE.glob('*.not-started.json')), 'no deferred planned job')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')), 'no bytecode residue')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,records=rows,controls=control_rows,failed_attempts_preserved=[],compiler_receipts=[],
        all_numerical_physical_checks=all(item['numerical_pass'] and item['physical_pass'] for item in rows),
        strict_feedback_time_resolved=all(item['resolved'] for item in control_rows if item['control']=='step-coarse'),
        strict_feedback_source_resolved=all(item['resolved'] for item in control_rows if item['control']=='source-coarse'),
        unqualified_results_not_hidden=True,source_self_feedback_still_separate=True,
        original_preparation_preserved=True,original_inputs_and_tolerances_unchanged=True,github_actions=False,
        continuum_certificate=False,total_error_claimed=False))
    print('complete correction-feedback propagation audit',counts,flush=True)


if __name__=='__main__':
    main()

