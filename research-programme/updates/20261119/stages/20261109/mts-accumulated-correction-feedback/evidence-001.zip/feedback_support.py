from common import *
from accumulated_support_v2 import BRANCHES, NAMES, DualOperator
from correlated_source import CorrelatedSource, reconstruct
from real_series import real_coefficients
from scipy.interpolate import CubicSpline, CubicHermiteSpline
import numpy as np


def keep(consumed, path):
    path = owned(path)
    consumed[str(path)] = digest(path)
    return path


def checked_source(model, stride=1):
    report_path = ROOT / 'preparation-01/result.json'
    report = read(report_path)
    require(report['passed'], 'qualified source conversion')
    item = next(item for item in report['models'] if item['model'] == model)
    require(digest(item['path']) == item['sha256'], 'frozen feedback source bank')
    packet = load(item['path'])
    source = FeedbackSource(packet, stride)
    bank_path = owned(COMPLETED / LABEL / 'source-even-01' / f'{model}-bank.npz')
    bank = load(bank_path)
    require(source.epochs[0] == bank['efold'][0] and source.epochs[-1] == bank['efold'][-1], 'same inherited interval')
    consumed = {str(report_path): digest(report_path), item['path']: item['sha256'], str(bank_path): digest(bank_path)}
    return source, bank, consumed


class FeedbackSource:
    def __init__(self, packet, stride=1):
        self.epochs = packet['efold'][::stride]
        self.shape = tuple(int(value) for value in packet['shape'])
        self.modes = packet['modes']
        self.sine = packet['sine']
        self.normalization = packet['normalization']
        self.spline = CubicSpline(self.epochs, packet['coefficients'][::stride])

    def __call__(self, efold, theta):
        require(self.epochs[0]-1e-13 <= efold <= self.epochs[-1]+1e-13, 'source interval')
        angles = 2*self.modes*theta
        weights = np.where(self.sine, np.sin(angles), np.cos(angles))
        return (weights @ self.spline(efold)).reshape(self.shape)


def phase_rate(owner, model, efold, theta):
    if model == 'cold':
        return 0.
    background = owner.saved.mean(efold)
    slow = background['slow'][0]
    external = background['external'][0]
    omega = np.exp(efold)*owner.saved.masses[1]
    physical = reconstruct(float(background['heavy'][0]), float(external[0]), float(external[1]),
                           float(slow[0]), float(slow[1]), omega, theta)
    return omega/float(physical['hubble'])-1.5*np.sin(2*theta)


def build_adjoint(model, control, owner, bank, consumed):
    terminal_path = keep(consumed, ACCUM_STAGE / LABEL / 'preparation-03' / f'{model}-terminal.npz')
    rows = load(terminal_path)['rows']
    folder = ACCUM_STAGE / LABEL / 'adjoint-01' / f'{model}-{control}'
    prediction = load(keep(consumed, folder / 'prediction.npz'))
    row_norm = prediction['row_norm']
    require(np.all(row_norm > 0), 'nonzero original dual rows')
    endpoints = [float(bank['efold'][-1])]
    states = [rows/row_norm[:, :, None]]
    previous = endpoints[0]
    for index in range(64):
        chunk = load(keep(consumed, folder / f'chunk-{index:03d}.npz'))
        require(float(chunk['right']) == previous, 'contiguous saved adjoint endpoints')
        endpoints.append(float(chunk['left']))
        states.append(chunk['lambda_left'])
        previous = endpoints[-1]
    endpoints = np.array(endpoints[::-1])
    states = np.array(states[::-1])
    require(endpoints[0] == bank['efold'][0], 'same adjoint/forcing start')
    operator = DualOperator(owner, bank)
    slopes = []
    for efold, state in zip(endpoints, states):
        matrix, remote = operator.values(float(efold))
        slopes.append(-operator.transpose(state, matrix, remote))
    slopes = np.array(slopes)
    fine = CubicHermiteSpline(endpoints, states, slopes)
    coarse = CubicHermiteSpline(endpoints[::2], states[::2], slopes[::2])
    return endpoints, fine, coarse, rows, row_norm

