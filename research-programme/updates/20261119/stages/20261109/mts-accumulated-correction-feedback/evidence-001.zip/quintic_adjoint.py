from feedback_support import *
from scipy.interpolate import BPoly


def build_adjoint(model, control, owner, bank, consumed):
    terminal_path = keep(consumed, ACCUM_STAGE / LABEL / 'preparation-03' / f'{model}-terminal.npz')
    rows = load(terminal_path)['rows']
    folder = ACCUM_STAGE / LABEL / 'adjoint-01' / f'{model}-{control}'
    prediction = load(keep(consumed, folder / 'prediction.npz'))
    row_norm = prediction['row_norm']
    endpoints, states = [float(bank['efold'][-1])], [rows/row_norm[:, :, None]]
    for index in range(64):
        chunk = load(keep(consumed, folder / f'chunk-{index:03d}.npz'))
        require(float(chunk['right']) == endpoints[-1], 'unchanged contiguous dual path')
        endpoints.append(float(chunk['left']))
        states.append(chunk['lambda_left'])
    endpoints, states = np.array(endpoints[::-1]), np.array(states[::-1])
    require(endpoints[0] == bank['efold'][0], 'same inherited adjoint initial time')
    operator = DualOperator(owner, bank)

    def operator_rate(efold):
        opacity = owner.thermal(float(efold))[0]['opacity']
        compact = operator.noncollision(efold, 1) + opacity['first']*operator.collision(efold)
        compact += opacity['value']*operator.collision(efold, 1)
        return compact, operator.remote(efold, 1)

    slopes, curvature, checks = [], [], []
    for efold, state in zip(endpoints, states):
        matrix, remote = operator.values(float(efold))
        matrix_rate, remote_rate = operator_rate(float(efold))
        slope = -operator.transpose(state, matrix, remote)
        second = -operator.transpose(state, matrix_rate, remote_rate)-operator.transpose(slope, matrix, remote)
        slopes.append(slope)
        curvature.append(second)
    slopes, curvature = np.array(slopes), np.array(curvature)
    width = float(np.min(np.diff(endpoints)))
    for index in (7, 29, 51):
        efold, state = float(endpoints[index]), states[index]
        matrix_rate, remote_rate = operator_rate(efold)
        expected = operator.transpose(state, matrix_rate, remote_rate)
        errors = []
        for step in (width*1e-3, width*5e-4):
            low, low_remote = operator.values(efold-step)
            high, high_remote = operator.values(efold+step)
            observed = operator.transpose(state, (high-low)/(2*step), (high_remote-low_remote)/(2*step))
            error = float(np.linalg.norm(observed-expected)/max(np.linalg.norm(expected),1e-80))
            require(error < GATE, 'independent numerical derivative of retained mean operator')
            errors.append(error)
        checks.append(dict(efold=efold, derivative_errors=errors))
    derivatives = np.stack([states, slopes, curvature], axis=1)
    fine = BPoly.from_derivatives(endpoints, list(derivatives))
    coarse = BPoly.from_derivatives(endpoints[::2], list(derivatives[::2]))
    endpoint_errors = []
    for order, expected, gate in ((0, states, ALGEBRA), (1, slopes, ALGEBRA), (2, curvature, GATE)):
        error = float(np.linalg.norm(fine(endpoints, order)-expected)/max(np.linalg.norm(expected),1e-80))
        require(error < gate, 'derived adjoint endpoint jet reproduced')
        endpoint_errors.append(error)
    target = ROOT/'projection-02'/f'{model}-{control}-adjoint-jets.npz'
    np.savez_compressed(target, efold=endpoints, state=states, first=slopes, second=curvature,
                        rows=rows, row_norm=row_norm)
    write(ROOT/'projection-02'/f'{model}-{control}-adjoint-jets-result.json',
          dict(passed=True, path=str(target), sha256=digest(target), derivative_checks=checks,
               endpoint_errors=endpoint_errors, formula='lambda_NN=-M_N^T lambda-M^T lambda_N',
               no_adjoint_refit=True, no_new_ode_solve=True))
    return endpoints, fine, coarse, rows, row_norm

