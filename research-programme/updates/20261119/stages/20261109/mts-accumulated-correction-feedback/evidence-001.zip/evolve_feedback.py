from common import *
from feedback_support import *
from scipy.integrate import solve_ivp
import time


def run(model):
    modest()
    require(model in ('heavy', 'cold'), 'paired retained model')
    inputs = verify_inputs()
    source, bank, consumed = checked_source(model)
    owner = CorrelatedSource(model)
    consumed.update(owner.consumed)
    operator = DualOperator(owner, bank)
    shape = source.shape
    scale = source.normalization[:, :, None]
    start, stop = bank['efold'][[0, -1]]
    output = ROOT / 'forward-01' / model
    output.mkdir(parents=True, exist_ok=False)
    write(output / 'freeze.json', dict(inputs=inputs, sources=sources(), consumed=consumed, model=model,
                                      algebra=ALGEBRA, gate=GATE, rtol=2e-12, atol=2e-14,
                                      equation='z_N=M z+h; z(initial)=0; separate normal/map sources',
                                      controls=['step-coarse', 'fine', 'source-coarse'],
                                      original_physical_initial_mode_preserved=True,
                                      reference_outputs_not_read=True))
    reports = []
    for control, stride, steps in (('step-coarse', 1, 2048), ('fine', 1, 4096), ('source-coarse', 2, 4096)):
        guard()
        forcing, current_bank, current_paths = checked_source(model, stride)
        consumed.update(current_paths)
        require(np.array_equal(current_bank['efold'], bank['efold']), 'unchanged physical grid')
        initial = np.zeros(1 + int(np.prod(shape)))
        initial[0] = bank['phase'][0]

        def rhs(efold, flat):
            guard()
            theta = flat[0]
            state = flat[1:].reshape(shape)
            matrix, weights = operator.values(float(efold))
            derivative = operator.apply(state, matrix, weights) + forcing(efold, theta)/scale
            return np.concatenate([[phase_rate(owner, model, efold, theta)], derivative.ravel()])

        started = time.monotonic()
        solved = solve_ivp(rhs, (start, stop), initial, method='DOP853', t_eval=bank['efold'],
                           rtol=2e-12, atol=2e-14, max_step=(stop-start)/steps)
        require(solved.success and np.isfinite(solved.y).all(), 'retained full-hierarchy feedback response')
        phase_error = float(np.max(abs(solved.y[0]-bank['phase'])))
        require(phase_error < ALGEBRA, 'original phase reproduced independently')
        response = solved.y[1:].T.reshape(-1, *shape) * scale[None, :, :, :]
        require(np.count_nonzero(response[0]) == 0, 'no replacement of incoming physical mode')
        if model == 'cold':
            require(np.count_nonzero(response[:, 0]) == 0, 'baseline normal source remains exact zero')
        target = output / f'{control}.npz'
        np.savez_compressed(target, efold=bank['efold'], phase=solved.y[0], response=response,
                            normalization=source.normalization)
        record = dict(model=model, control=control, path=str(target), sha256=digest(target), phase_error=phase_error,
                      seconds=time.monotonic()-started, nfev=solved.nfev, steps=steps, source_nodes=len(forcing.epochs),
                      successful_execution=True, convergence_not_assumed=True)
        write(output / f'{control}-result.json', dict(passed=True, **record))
        reports.append(record)
        print(LABEL, model, control, 'feedback response saved', record['seconds'], record['nfev'], flush=True)
    require(all(digest(path) == seal for path, seal in consumed.items()), 'retained inputs unchanged')
    write(output / 'result.json', dict(passed=True, inputs=inputs, sources=sources(), consumed=consumed,
                                      model=model, reports=reports, no_total_error_claim=True))

