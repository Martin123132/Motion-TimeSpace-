from common import *
from feedback_support import *
from integrate_adjoint import integrate_chunk
import time


def main():
    modest()
    inputs = verify_inputs()
    output = ROOT / 'projection-01'
    output.mkdir(exist_ok=False)
    consumed = {}
    reports = []
    write(output / 'freeze.json', dict(inputs=inputs, sources=sources(), quadrature=[8192, 4096],
                                      adjoint_endpoint_interpolation=[64, 32], adjoint_step_controls=[4096, 2048],
                                      gate=GATE, algebra=ALGEBRA, forward_results_not_read=True,
                                      retained_source_independent_adjoints=True))
    for model in ('heavy', 'cold'):
        started = time.monotonic()
        source, bank, paths = checked_source(model)
        coarse_source, _, more_paths = checked_source(model, 2)
        consumed.update(paths)
        consumed.update(more_paths)
        owner = CorrelatedSource(model)
        consumed.update(owner.consumed)
        endpoints, dual, dual_coarse, rows, row_norm = build_adjoint(model, 'fine', owner, bank, consumed)
        other_endpoints, dual_step, _, other_rows, other_norm = build_adjoint(model, 'step-coarse', owner, bank, consumed)
        require(np.array_equal(endpoints, other_endpoints) and np.array_equal(rows, other_rows)
                and np.array_equal(row_norm, other_norm), 'same original physical adjoint preparation')
        path = keep(consumed, ACCUM_STAGE / LABEL / 'residual-path-01' / f'{model}-path.npz')
        phase_path = load(path)
        epochs, phase = phase_path['efold'], phase_path['phase']
        require(len(epochs) == 8193 and epochs[0] == bank['efold'][0]
                and epochs[-1] == bank['efold'][-1], 'complete original phase quadrature path')
        projected = {name: np.empty((len(epochs), 2, 2, len(NAMES)))
                     for name in ('fine', 'source-coarse', 'adjoint-coarse', 'step-coarse')}
        for index, (efold, theta) in enumerate(zip(epochs, phase)):
            guard()
            force = source(float(efold), float(theta))
            source_control = coarse_source(float(efold), float(theta))
            current = dual(efold)
            projected['fine'][index] = np.einsum('cbd,obd->cbo', force, current) * row_norm.T[None, :, :]
            projected['source-coarse'][index] = np.einsum('cbd,obd->cbo', source_control, current) * row_norm.T[None, :, :]
            projected['adjoint-coarse'][index] = np.einsum('cbd,obd->cbo', force, dual_coarse(efold)) * row_norm.T[None, :, :]
            projected['step-coarse'][index] = np.einsum('cbd,obd->cbo', force, dual_step(efold)) * row_norm.T[None, :, :]
            if index % 2048 == 0:
                print(LABEL, model, 'reused adjoint projection', index, 'of8192', flush=True)
        totals = {}
        chunk_arrays = {}
        for name, values in projected.items():
            for quadrature, stride in (('fine', 1), ('coarse', 2)):
                chunks = [integrate_chunk(epochs[start:start+129:stride], values[start:start+129:stride])
                          for start in range(0, 8192, 128)]
                for kind in chunks[0]:
                    collection = np.array([item[kind] for item in chunks])
                    chunk_arrays[name+'_'+quadrature+'_'+kind] = collection
                    totals[name+'_'+quadrature+'_'+kind] = collection.sum(axis=0)
        target = output / f'{model}-prediction.npz'
        np.savez_compressed(target, efold=epochs, phase=phase, rows=rows, row_norm=row_norm,
                            **{'projected_'+name: values for name, values in projected.items()}, **totals)
        chunk_path = output / f'{model}-quadrature-chunks.npz'
        np.savez_compressed(chunk_path, **chunk_arrays)
        reports.append(dict(model=model, path=str(target), sha256=digest(target), chunks_path=str(chunk_path),
                            chunks_sha256=digest(chunk_path), seconds=time.monotonic()-started,
                            original_adjoint_reused=True, interpolation_not_assumed_accurate=True))
        print(LABEL, model, 'independent feedback projections frozen', reports[-1]['seconds'], flush=True)
    require(all(digest(path) == seal for path, seal in consumed.items()), 'reused data unchanged')
    write(output / 'result.json', dict(passed=True, inputs=inputs, sources=sources(), consumed=consumed,
                                      reports=reports, forward_results_not_read=True, continuum_certificate=False))


if __name__ == '__main__':
    main()

