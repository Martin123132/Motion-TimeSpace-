from common import *
from feedback_support import *


def main():
    modest()
    output = ROOT / 'comparison-01'
    output.mkdir(exist_ok=False)
    inputs = verify_inputs()
    consumed = {}
    projection_path = ROOT / 'projection-01/result.json'
    projections = read(projection_path)
    require(projections['passed'], 'completed independent projections')
    consumed[str(projection_path)] = digest(projection_path)
    records, controls, predictions = [], [], {}
    for model in ('heavy', 'cold'):
        path = ROOT / 'forward-01' / model / 'result.json'
        report = read(path)
        require(report['passed'], 'completed original prepared response')
        consumed[str(path)] = digest(path)
        packets = {}
        for run in report['reports']:
            require(digest(run['path']) == run['sha256'], 'frozen response prediction')
            consumed[run['path']] = run['sha256']
            packets[run['control']] = load(run['path'])
        fine = packets['fine']['response']
        require(np.count_nonzero(fine[0]) == 0, 'zero added response, no physical reset')
        response_scale = np.maximum(np.max(np.linalg.norm(fine, axis=-1), axis=0), 1e-80)
        control_rows = {}
        for control in ('step-coarse', 'source-coarse'):
            current = packets[control]
            require(np.array_equal(current['efold'], packets['fine']['efold']), 'same original output grid')
            difference = current['response']-fine
            errors = np.max(np.linalg.norm(difference, axis=-1), axis=0)/response_scale
            control_rows[control] = errors
            for component in range(2):
                for branch, name in enumerate(BRANCHES):
                    controls.append(dict(model=model, control=control, component=component, branch=name,
                                         feedback_relative=float(errors[component, branch]),
                                         resolved=bool(errors[component, branch] < GATE)))
        item = next(item for item in projections['reports'] if item['model'] == model)
        for field, hash_name in (('path', 'sha256'), ('chunks_path', 'chunks_sha256')):
            require(digest(item[field]) == item[hash_name], 'frozen adjoint projection')
            consumed[item[field]] = item[hash_name]
        projected = load(item['path'])
        rows = projected['rows']
        forward = np.einsum('obd,cbd->cbo', rows, fine[-1])
        physical_controls = {control: np.einsum('obd,cbd->cbo', rows, packets[control]['response'][-1]-fine[-1])
                             for control in ('step-coarse', 'source-coarse')}
        signed = projected['fine_fine_signed']
        budget = projected['fine_fine_cauchy']
        component_budget = projected['fine_fine_component_cauchy']
        old_path = keep(consumed, ACCUM_STAGE / LABEL / 'comparison-02' / f'{model}-comparison.npz')
        old = load(old_path)
        require(np.array_equal(rows, old['rows']), 'same original physical terminal rows')
        reference_scale = old['reference_scale']
        physical_shift = forward.sum(axis=0)
        candidate = old['physical_candidate']+physical_shift
        old_error = abs(old['physical_candidate']-old['reference'])/reference_scale
        new_error = abs(candidate-old['reference'])/reference_scale
        for branch, name in enumerate(BRANCHES):
            for column, channel in enumerate(NAMES):
                denominator = np.maximum(component_budget[:, branch, column], 1e-80)
                identity = float(np.max(abs(forward[:, branch, column]-signed[:, branch, column])/denominator))
                numerical = {}
                for label, field in (('quadrature', 'fine_coarse_signed'), ('adjoint_interpolation', 'adjoint-coarse_fine_signed'),
                                     ('adjoint_steps', 'step-coarse_fine_signed')):
                    numerical[label] = float(np.max(abs(signed[:, branch, column]-projected[field][:, branch, column])/denominator))
                current_budget = max(float(budget[branch, column]), 1e-80)
                for label, field in (('budget_quadrature', 'fine_coarse_cauchy'), ('budget_interpolation', 'adjoint-coarse_fine_cauchy'),
                                     ('budget_adjoint_steps', 'step-coarse_fine_cauchy')):
                    numerical[label] = abs(float(budget[branch, column]-projected[field][branch, column]))/current_budget
                forward_step = float(np.max(abs(physical_controls['step-coarse'][:, branch, column])/denominator))
                source_change = float(np.max(abs(physical_controls['source-coarse'][:, branch, column])/denominator))
                inequalities = bool(abs(float(physical_shift[branch, column])) <= current_budget*(1+GATE)+1e-80)
                numerical_pass = bool(max(identity, forward_step, *numerical.values()) < GATE and inequalities)
                physical_pass = bool(new_error[branch, column] < GATE)
                records.append(dict(model=model, branch=name, channel=channel,
                    identity=identity, forward_step=forward_step, source_change_relative_to_budget=source_change,
                    diagnostics=numerical, numerical_pass=numerical_pass, physical_pass=physical_pass,
                    signed_components=signed[:, branch, column].tolist(), forward_components=forward[:, branch, column].tolist(),
                    feedback_shift=float(physical_shift[branch, column]),
                    normalized_feedback=float(abs(physical_shift[branch, column])/reference_scale[branch, column]),
                    cauchy_budget=float(budget[branch, column]),
                    normalized_cauchy_budget=float(budget[branch, column]/reference_scale[branch, column]),
                    prior_omission_budget=float(old['budget'][branch, column]/reference_scale[branch, column]),
                    conditional_two_source_budget=float((old['budget'][branch, column]+budget[branch, column])/reference_scale[branch, column]),
                    old_reference_error=float(old_error[branch, column]), new_reference_error=float(new_error[branch, column]),
                    physical_step_change=float(abs(physical_controls['step-coarse'][:, branch, column].sum())/reference_scale[branch, column]),
                    physical_source_change=float(abs(physical_controls['source-coarse'][:, branch, column].sum())/reference_scale[branch, column]),
                    forward_inside_numerical_budget=inequalities))
        target = output / f'{model}-comparison.npz'
        np.savez_compressed(target, rows=rows, forward=forward, signed=signed, cauchy_budget=budget,
                            component_budget=component_budget, reference_scale=reference_scale, physical_candidate=candidate,
                            prior_candidate=old['physical_candidate'], reference=old['reference'],
                            shift=physical_shift, prior_omission_budget=old['budget'],
                            step_difference=physical_controls['step-coarse'], source_difference=physical_controls['source-coarse'])
        predictions[model] = dict(path=str(target), sha256=digest(target))
        current = [row for row in records if row['model'] == model]
        print(LABEL, model, 'terminal checks', sum(row['numerical_pass'] and row['physical_pass'] for row in current),
              'of20', 'maximum shift', max(row['normalized_feedback'] for row in current), flush=True)
    require(all(digest(path) == seal for path, seal in consumed.items()), 'unchanged predictions and references')
    all_pass = all(row['numerical_pass'] and row['physical_pass'] for row in records)
    write(output / 'result.json', dict(completed=True, passed=all_pass, inputs=inputs, sources=sources(), consumed=consumed,
        records=records, controls=controls, predictions=predictions,
        strict_feedback_time_resolved=all(row['resolved'] for row in controls if row['control'] == 'step-coarse'),
        strict_feedback_source_resolved=all(row['resolved'] for row in controls if row['control'] == 'source-coarse'),
        source_relative_failures_preserved=True, total_error_claimed=False, source_self_feedback_removed=False,
        physical_tolerances_unchanged=True, continuum_certificate=False))


if __name__ == '__main__':
    main()

