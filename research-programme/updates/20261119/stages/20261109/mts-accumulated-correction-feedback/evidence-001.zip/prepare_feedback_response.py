from common import *
from feedback_support import *


def main():
    modest()
    output = ROOT / 'preparation-01'
    output.mkdir(parents=True, exist_ok=False)
    inputs = verify_inputs()
    source_path = owned(FEEDBACK_STAGE / LABEL / 'feedback-01/result.json')
    original = read(source_path)
    require(original['passed'], 'accepted full feedback source')
    consumed = {str(source_path): digest(source_path)}
    write(output / 'freeze.json', dict(inputs=inputs, sources=sources(), algebra=ALGEBRA, gate=GATE,
                                      source_stride=[1, 2], steps=[4096, 2048],
                                      rtol=2e-12, atol=2e-14, no_reference_performance_read=True))
    reports = []
    for model in ('heavy', 'cold'):
        nodes = next(row['nodes'] for row in original['reports'] if row['model'] == model)
        records, checks, epochs = [], [], []
        normalization = np.zeros((2, 2))
        for node in nodes:
            guard()
            path = keep(consumed, node['path'])
            with np.load(path) as packet:
                coefficients = packet['feedback_coefficients']
                samples = packet['feedback']
                angles = packet['angles']
            converted, modes, sine = real_coefficients(coefficients)
            shape = converted.shape[1:]
            records.append(converted.reshape(len(modes), -1))
            epochs.append(node['efold'])
            normalization = np.maximum(normalization, np.max(np.linalg.norm(samples, axis=-1), axis=0))
            scale = np.maximum(np.max(np.linalg.norm(samples, axis=-1), axis=0), 1e-80)
            max_error = 0.
            for theta in (*angles, .213, 1.157, 2.62):
                weights = np.where(sine, np.sin(2*modes*theta), np.cos(2*modes*theta))
                actual = np.tensordot(weights, converted, axes=(0, 0))
                frequencies = np.fft.fftfreq(len(coefficients), d=1/len(coefficients))
                expected = np.tensordot(np.exp(2j*frequencies*theta), coefficients, axes=(0, 0)).real
                error = float(np.max(np.linalg.norm(actual-expected, axis=-1)/scale))
                require(error < ALGEBRA, 'all harmonics preserved in real source conversion')
                max_error = max(max_error, error)
            checks.append(dict(index=node['index'], maximum_conversion_error=max_error))
        normalization[normalization == 0] = 1.
        target = output / f'{model}-source.npz'
        np.savez_compressed(target, efold=np.array(epochs), coefficients=np.array(records), modes=modes,
                            sine=sine, shape=np.array(shape), normalization=normalization)
        packet = load(target)
        test = FeedbackSource(packet)
        for index, efold in enumerate(epochs):
            difference = test.spline(efold)-records[index]
            require(np.linalg.norm(difference)/max(np.linalg.norm(records[index]), 1e-80) < ALGEBRA, 'exact original interpolation nodes')
        reports.append(dict(model=model, path=str(target), sha256=digest(target), nodes=len(nodes),
                            shape=list(shape), normalization=normalization.tolist(), checks=checks))
        print(LABEL, model, 'complete source representation frozen', flush=True)
    require(all(digest(path) == seal for path, seal in consumed.items()), 'unchanged accepted sources')
    write(output / 'result.json', dict(passed=True, inputs=inputs, sources=sources(), consumed=consumed, models=reports,
                                      algebra=ALGEBRA, gate=GATE, feedback_relative_controls_not_assumed=True))


if __name__ == '__main__':
    main()

