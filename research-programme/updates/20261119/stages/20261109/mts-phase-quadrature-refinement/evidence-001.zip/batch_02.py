from run_batch import run

if __name__=='__main__':
    run('batch02',range(257,384,2))
