from run_batch import run

if __name__=='__main__':
    run('batch01',range(129,256,2))
