from common import *
from refinement_support import parent,checked_point


def main():
    modest()
    inputs=verify_inputs()
    old_path=parent(PHASE_RESPONSE/LABEL/'points-01/fine-02-result.json')
    old=read(old_path)
    consumed={str(old_path):digest(old_path)}
    for mode in ('probe','batch00','batch01','batch02','batch03'):
        path=ROOT/'points-01'/(mode+'-result.json')
        require(read(path)['passed'],'completed source batch '+mode)
        consumed[str(path)]=digest(path)
    reports=[]
    for model in ('heavy','cold'):
        previous=next(item for item in old['reports'] if item['model']==model)
        nodes=[]
        controls=[]
        for index in range(513):
            if index%2==0:
                ordinal=index//2
                report=dict(previous['nodes'][ordinal])
                phase=dict(previous['phase_controls'][ordinal])
                require(report['index']==phase['index']==ordinal,'original source index')
                for item in (report,phase):
                    parent(item['path'])
                    consumed[item['path']]=item['sha256']
                    item.update(index=index,parent_index=ordinal,reused_from_parent=True)
            else:
                report,phase=checked_point(model,index)
                for item in (report,phase):
                    consumed[item['path']]=item['sha256']
            nodes.append(report)
            controls.append(phase)
        reports.append(dict(model=model,nodes=nodes,phase_controls=controls))
    write(ROOT/'points-01/fine-03-result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        source_phase_time_control=True,current_phase_cross_term_retained=True,
        original_bank_grids_tolerances_unchanged=True,reused_source_points=514,new_source_points=512))
    print('1026-source paired panel assembled without altering the514 inherited points',flush=True)


if __name__=='__main__':
    main()
