from common import *
from refinement_support import parent
from response_support import original_data,phase_rate
from prepare_grid import PhaseDense
from scipy.optimize import brentq
import numpy as np


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'grid-01'
    output.mkdir(parents=True,exist_ok=False)
    old_report_path=parent(PHASE_RESPONSE/LABEL/'grid-01/result.json')
    old_report=read(old_report_path)
    require(old_report['passed'],'original grid accepted')
    consumed={str(old_report_path):digest(old_report_path)}
    reports=[]
    for model in ('heavy','cold'):
        item=next(row for row in old_report['reports'] if row['model']==model)
        for key in ('path','phase_path'):
            parent(item[key]);consumed[item[key]]=digest(item[key])
        old=load(item['path'])
        polynomial=load(item['phase_path'])
        phase=PhaseDense(polynomial)
        owner,source,bank,leading,slow,response,feedback,drift,kernel,paths=original_data(model)
        consumed.update(paths)
        grid={key:np.empty(513) for key in old}
        for key in old:
            grid[key][::2]=old[key]
        for index in range(1,512,2):
            guard()
            left,right=grid['efold'][index-1],grid['efold'][index+1]
            if model=='heavy':
                theta=grid['phase'][index-1]+(grid['phase'][index+1]-grid['phase'][index-1])/2
                efold=brentq(lambda value:phase(value)-theta,left,right,xtol=5e-324,rtol=4*np.finfo(float).eps)
                speed=phase_rate(owner,model,float(efold),float(theta))
                require(speed>0,'positive sampled physical phase clock')
                values=dict(efold=efold,phase=theta,coordinate=theta,jacobian=1/speed,speed=speed)
            else:
                efold=left+(right-left)/2
                values=dict(efold=efold,phase=0.,coordinate=efold,jacobian=1.,speed=0.)
            for key in grid:
                grid[key][index]=values[key]
        require(all(np.array_equal(grid[key][::2],old[key]) for key in old),'all parent coordinates and measures unchanged bitwise')
        require(np.all(np.diff(grid['efold'])>0),'ordered nested extension')
        error=max(abs(phase(float(efold))-theta) for efold,theta in zip(grid['efold'],grid['phase']))
        require(error<ALGEBRA,'same stored phase polynomial')
        target=output/f'{model}-grid.npz'
        np.savez_compressed(target,**grid)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),phase_path=item['phase_path'],phase_sha256=item['phase_sha256'],
            parent_path=item['path'],parent_sha256=item['sha256'],points=513,new_points=256,phase_error=float(error),
            original_nodes_bitwise_identical=True,start=float(grid['efold'][0]),stop=float(grid['efold'][-1])))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        native_forcing_on_new_points_not_yet_evaluated=True,original_physical_input_grids_unchanged=True,
        quadrature_rule='513/257/129 nested phase or N quadratic rule',frozen_probe_indices=[1,129,257,385]))
    print('paired513-point grid frozen; all514 inherited point coordinates and measures unchanged',flush=True)


if __name__=='__main__':
    main()
