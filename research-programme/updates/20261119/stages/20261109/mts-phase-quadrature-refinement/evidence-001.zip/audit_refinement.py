from common import *
from refinement_support import parent,checked_point
from audit_phase_v2 import check_frame
from response_support import adjoints,NAMES,BRANCHES
from scipy.integrate import simpson
import numpy as np
import psutil


def relative(left,right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.linalg.norm(right),1e-80))


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed,verified,accepted={},{},{}
    def hashes(records):
        for path,seal in records.items():
            guard()
            if path not in verified:
                verified[path]=digest(path)
            require(verified[path]==seal,'immutable consumed evidence '+path)
            consumed[path]=seal
    def take(path):
        value=read(path)
        require(value.get('passed') or value.get('completed'),'completed evidence '+str(path))
        for key in ('inputs','sources','consumed'):
            hashes(value.get(key,{}))
        accepted[str(path)]=digest(path)
        return value
    original=(PHASE_RESPONSE/'sample_sources.py').read_text(encoding='utf-8-sig').split('\ndef run(mode,stride):')[0]
    expected=original.replace("report_path=ROOT/'history-01/result.json'","report_path=PHASE_RESPONSE/LABEL/'history-01/result.json'").replace('if index in (0,256):','if index in (0,512):')
    require((STAGE/'sample_sources.py').read_text(encoding='utf-8-sig')==expected,'only history path and diagnostic endpoint adapted')
    expected=(PHASE_RESPONSE/'controlled_sources.py').read_text(encoding='utf-8-sig').split('\ndef run(mode,stride):')[0]
    require((STAGE/'controlled_sources.py').read_text(encoding='utf-8-sig')==expected,'phase/current cross-control class unchanged')
    expected=(PHASE_RESPONSE/'project_response.py').read_text(encoding='utf-8-sig').replace('selected[-1]==256','selected[-1]==512')
    require((STAGE/'project_response.py').read_text(encoding='utf-8-sig')==expected,'only projected panel endpoint adapted')
    grid_report=take(ROOT/'grid-01/result.json')
    probe=take(ROOT/'probe-verification/result.json')
    source=take(ROOT/'points-01/fine-03-result.json')
    projection=take(ROOT/'projection-fine-03/result.json')
    require(source['reused_source_points']==514 and source['new_source_points']==512,'fixed paired scope')
    require(projection['first_original_cell_only'] and not projection['whole_history_error_claimed'],'same first-cell scope')
    grid_end=read(STAGE/'grid-balanced-01.end.json')
    probe_start=read(STAGE/'probe-balanced-01.start.json')
    require(datetime.fromisoformat(grid_end['finished'])<datetime.fromisoformat(probe_start['created'].replace('Z','+00:00')),'grid frozen before new source samples')
    probe_end=read(STAGE/'verify-probe-01.end.json')
    for number in range(4):
        start=read(STAGE/f'batch{number:02d}-balanced-01.start.json')
        require(datetime.fromisoformat(probe_end['finished'])<datetime.fromisoformat(start['created'].replace('Z','+00:00')),'probe verified before bulk continuation')
        batch=take(ROOT/'points-01'/f'batch{number:02d}-result.json')
        for case in batch['reports']:
            require([row['index'] for row in case['nodes']]==list(range(128*number+1,128*(number+1),2)),'complete bounded batch')
    old_source=read(parent(PHASE_RESPONSE/LABEL/'points-01/fine-02-result.json'))
    old_result=read(parent(PHASE_RESPONSE/LABEL/'projection-fine-02/result.json'))
    counts=dict(reused_points=0,new_points=0,phase_controls=0,projected_channels=0)
    maxima=dict(frame=0.,phase_frame=0.,adjoint_contraction=0.,primitive_refinement=0.,primitive_closure=0.)
    summary=[]
    for model in ('heavy','cold'):
        entry=next(item for item in grid_report['reports'] if item['model']==model)
        hashes({entry['path']:entry['sha256'],entry['phase_path']:entry['phase_sha256']})
        grid=load(entry['path'])
        old_grid=load(parent(entry['parent_path']))
        require(all(np.array_equal(grid[key][::2],old_grid[key]) for key in old_grid),'all old point coordinates and weights retained')
        require(len(grid['efold'])==513 and np.all(np.diff(grid['efold'])>0),'complete ordered513 grid')
        case=next(item for item in source['reports'] if item['model']==model)
        old_case=next(item for item in old_source['reports'] if item['model']==model)
        result=next(item for item in projection['reports'] if item['model']==model)
        hashes({result['path']:result['sha256'],result['clock_path']:result['clock_sha256']})
        projected=load(result['path'])
        old_projected=load(parent(PHASE_RESPONSE/LABEL/'projection-fine-02'/f'{model}-projection.npz'))
        require(np.array_equal(projected['indices'],np.arange(513)),'all513 source indices projected')
        for new_key,old_key in (('coarse_signed','fine_signed'),('coarse_cauchy','fine_cauchy'),('coarser_signed','coarse_signed'),('coarser_cauchy','coarse_cauchy')):
            require(np.array_equal(projected[new_key],old_projected[old_key]),'complete old projected integral reproduced bitwise')
        require(np.array_equal(projected['reference_scale'],old_projected['reference_scale']),'same physical comparison scales')
        curves,row_norm=adjoints(model,consumed)
        require(len(case['nodes'])==len(case['phase_controls'])==513,'complete paired source controls')
        for node,control in zip(case['nodes'],case['phase_controls']):
            index=node['index']
            require(control['index']==index and node['model']==control['model']==model,'paired metadata')
            for item in (node,control):
                hashes({item['path']:item['sha256']})
            packet,phase=load(node['path']),load(control['path'])
            require(float(packet['efold'])==grid['efold'][index] and float(packet['phase'])==grid['phase'][index]
                    and float(packet['jacobian'])==grid['jacobian'][index],'source on frozen physical coordinates')
            require(np.array_equal(projected['projected'][index],packet['projected'])
                    and np.array_equal(projected['phase_projected'][index],phase['projected']),'correct source and phase control projected')
            if index%2==0:
                ordinal=index//2
                for item,original in ((node,old_case['nodes'][ordinal]),(control,old_case['phase_controls'][ordinal])):
                    require(item['parent_index']==ordinal and item['reused_from_parent']
                            and item['path']==original['path'] and item['sha256']==original['sha256'],'parent point reused without rewrite')
                    parent(item['path'])
                counts['reused_points']+=1
            else:
                checked_point(model,index)
                for item in (node,control):
                    hashes(item['sources']);hashes(item['consumed'])
                hashes({control['profile_report']:control['profile_report_sha256']})
                profile=take(control['profile_report'])
                if model=='heavy':
                    hashes({profile['path']:profile['sha256']})
                require(all(np.isfinite(value).all() for value in packet.values()) and all(np.isfinite(value).all() for value in phase.values()),'finite new source packets')
                require(np.array_equal(packet['difference'],packet['reference_rates']-packet['retained_rates']),'native difference sign')
                maxima['frame']=max(maxima['frame'],check_frame(packet,packet['retained_vectors'],packet['native_vectors'],packet['difference'],packet['forcing']))
                if model=='heavy':
                    snapshot={key.removeprefix('map_'):value for key,value in phase.items() if key.startswith('map_')}
                    maxima['phase_frame']=max(maxima['phase_frame'],check_frame(snapshot,packet['retained_vectors'],phase['native_native_vectors'],phase['native_difference'],packet['forcing']+phase['source_change']))
                    require(node['checks']['clock']['minimum_speed']>0 and node['checks']['clock']['contraction_bound']<1,'same physical phase-clock gate')
                else:
                    require(np.all(phase['source_change']==0),'only absent baseline phase control set zero')
                for order,name in enumerate(('fine','interpolation-coarse','step-coarse')):
                    adjoint=curves[name](float(packet['efold']))*row_norm[:,:,None]
                    for actual,forcing in ((packet['projected'][order],packet['forcing']),(phase['projected'][order],phase['source_change'])):
                        expected=np.einsum('obd,bdv->bvo',adjoint,forcing)
                        deviation=relative(expected,actual)
                        require(deviation<ALGEBRA,'new source contraction independently reproduced')
                        maxima['adjoint_contraction']=max(maxima['adjoint_contraction'],deviation)
                for key in ('primitive_refinement','primitive_closure'):
                    require(node['checks'][key]<ALGEBRA,'unchanged phase primitive accuracy')
                    maxima[key]=max(maxima[key],node['checks'][key])
                counts['new_points']+=1
            counts['phase_controls']+=1
        coordinate=projected['coordinate']
        jacobian=projected['jacobian']
        values=projected['projected']
        phases=projected['phase_projected']
        signal=values[:,0,:,0]
        width=float(grid['efold'][-1]-grid['efold'][0])
        for name,stride in (('fine',1),('coarse',2),('coarser',4)):
            signed=simpson(signal[::stride]*jacobian[::stride,None,None],x=coordinate[::stride],axis=0)
            budget=np.sqrt(width*np.maximum(simpson(signal[::stride]**2*jacobian[::stride,None,None],x=coordinate[::stride],axis=0),0.))
            require(np.array_equal(signed,projected[name+'_signed']) and np.array_equal(budget,projected[name+'_cauchy']),'source integral and conditional Cauchy expression')
        changes=dict(current=values[:,0,:,1],phase=phases[:,0,:,0],cross=phases[:,0,:,1],
            adjoint_interpolation=values[:,1,:,0]-signal,adjoint_steps=values[:,2,:,0]-signal)
        changes['current_and_phase']=changes['current']+changes['phase']+changes['cross']
        for name,change in changes.items():
            calculated=simpson(change*jacobian[:,None,None],x=coordinate,axis=0)
            require(np.array_equal(calculated,projected['change_'+name]),'same separate numerical control')
        volume_error=abs(float(projected['fine_volume'])-width)/width
        rows=[row for row in projection['records'] if row['model']==model]
        previous_rows=[row for row in old_result['records'] if row['model']==model]
        trends=[]
        for row in rows:
            branch,column=BRANCHES.index(row['branch']),NAMES.index(row['channel'])
            budget=max(float(projected['fine_cauchy'][branch,column]),1e-80)
            diagnostics=dict(quadrature=abs(projected['fine_signed'][branch,column]-projected['coarse_signed'][branch,column])/budget,
                budget=abs(projected['fine_cauchy'][branch,column]-projected['coarse_cauchy'][branch,column])/budget)
            diagnostics.update({name:abs(projected['change_'+name][branch,column])/budget for name in (*changes,'clock_measure')})
            require(all(abs(float(value)-row['diagnostics'][name])<ALGEBRA*max(abs(value),1e-80) for name,value in diagnostics.items()),'unchanged diagnostic values')
            inside=abs(projected['fine_signed'][branch,column])<=budget*(1+GATE)
            passed=bool(max(diagnostics.values())<GATE and volume_error<GATE and inside)
            require(row['numerical_pass']==passed,'failed numerical flags not promoted')
            prior=next(item for item in previous_rows if item['branch']==row['branch'] and item['channel']==row['channel'])
            last=abs(projected['fine_signed'][branch,column]-projected['coarse_signed'][branch,column])
            previous=abs(projected['coarse_signed'][branch,column]-projected['coarser_signed'][branch,column])
            trends.append(dict(branch=row['branch'],channel=row['channel'],previous_pass=prior['numerical_pass'],new_pass=passed,
                signed_change_ratio=float(last/previous) if previous>0 else None,
                new_quadrature=float(diagnostics['quadrature']),new_budget_change=float(diagnostics['budget']),
                physical_signed_change=float(last/projected['reference_scale'][branch,column])))
            counts['projected_channels']+=1
        summary.append(dict(model=model,passed=sum(row['numerical_pass'] for row in rows),
            previous_passed=sum(row['numerical_pass'] for row in previous_rows),trends=trends,
            largest_physical_contribution=max(abs(row['physical_contribution_fraction']) for row in rows),
            largest_physical_budget=max(row['physical_budget_fraction'] for row in rows),
            diagnostic_maxima={name:max(row['diagnostics'][name] for row in rows) for name in rows[0]['diagnostics']},
            clock=result['clock'],volume_error=volume_error))
    require(counts==dict(reused_points=514,new_points=512,phase_controls=1026,projected_channels=40),'complete one-level paired refinement')
    for path in STAGE.glob('*.start.json'):
        start=read(path)
        hashes({start['source_path']:start['source_sha256']})
        phase=path.name.removesuffix('.start.json')
        if phase=='audit-01':
            require(start['pid']==os.getpid(),'current audit worker')
            continue
        end=read(STAGE/(phase+'.end.json'))
        require(all(start[key]==end[key] for key in ('pid','created','command')) and end['exit_code']==0,'completed owned worker')
        if psutil.pid_exists(start['pid']):
            created=datetime.fromisoformat(start['created'].replace('Z','+00:00')).timestamp()
            require(abs(psutil.Process(start['pid']).create_time()-created)>1,'owned worker exited')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,maxima=maxima,summary=summary,original_bank_grids_tolerances_unchanged=True,
        all_numerical_controls_pass=all(row['passed']==20 for row in summary),
        first_original_cell_only=True,automatic_further_doubling_authorized=False,github_actions=False))
    print(json.dumps(dict(counts=counts,maxima=maxima,summary=summary),indent=2),flush=True)


if __name__=='__main__':
    main()
