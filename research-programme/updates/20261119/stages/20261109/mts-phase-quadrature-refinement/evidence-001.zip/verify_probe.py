from common import *
from refinement_support import checked_point
from audit_phase_v2 import check_frame
import numpy as np


def main():
    modest()
    output=ROOT/'probe-verification'
    output.mkdir(exist_ok=False)
    path=ROOT/'points-01/probe-result.json'
    result=read(path)
    require(result['passed'],'probe completed')
    consumed={str(path):digest(path)}
    records=[]
    for model in ('heavy','cold'):
        for index in (1,129,257,385):
            report,control=checked_point(model,index)
            for entry in (report,control):
                consumed[entry['path']]=entry['sha256']
            packet,phase=load(report['path']),load(control['path'])
            error=check_frame(packet,packet['retained_vectors'],packet['native_vectors'],packet['difference'],packet['forcing'])
            phase_error=0.
            if model=='heavy':
                snapshot={key.removeprefix('map_'):value for key,value in phase.items() if key.startswith('map_')}
                phase_error=check_frame(snapshot,packet['retained_vectors'],phase['native_native_vectors'],phase['native_difference'],packet['forcing']+phase['source_change'])
                require(report['checks']['clock']['minimum_speed']>0 and report['checks']['clock']['contraction_bound']<1,'physical clock qualification')
            require(report['checks']['primitive_refinement']<ALGEBRA and report['checks']['primitive_closure']<ALGEBRA,'original parent primitive accuracy')
            require(np.array_equal(packet['difference'],packet['reference_rates']-packet['retained_rates']),'unchanged native difference')
            records.append(dict(model=model,index=index,frame=error,phase_frame=phase_error))
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,records=records,
        gates_unchanged=True,no_old_point_rerun=True))
    print('eight new paired-model probe points independently verified',flush=True)


if __name__=='__main__':
    main()
