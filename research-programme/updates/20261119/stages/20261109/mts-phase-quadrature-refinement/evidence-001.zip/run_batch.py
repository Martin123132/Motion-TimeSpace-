from common import *
from controlled_sources import ControlledPhaseSource
from refinement_support import checked_point


def run(mode,indices):
    modest()
    inputs=verify_inputs()
    output=ROOT/'points-01'
    output.mkdir(exist_ok=True)
    grid_path=ROOT/'grid-01/result.json'
    grid_report=read(grid_path)
    require(grid_report['passed'] and grid_report['native_forcing_on_new_points_not_yet_evaluated'],'frozen diagnostic grid')
    require(all(index%2==1 and 0<index<512 for index in indices),'new odd points only')
    if mode!='probe':
        require(read(ROOT/'probe-verification/result.json')['passed'],'first new batch independently verified')
    write(output/(mode+'-freeze.json'),dict(inputs=inputs,sources=sources(),grid_path=str(grid_path),grid_sha256=digest(grid_path),
        mode=mode,indices=list(indices),gate=GATE,algebra=ALGEBRA,original_phase_nodes=256))
    reports=[]
    for model in ('heavy','cold'):
        entry=next(item for item in grid_report['reports'] if item['model']==model)
        require(digest(entry['path'])==entry['sha256'],'unchanged frozen grid')
        grid=load(entry['path'])
        case=None
        nodes=[]
        controls=[]
        for index in indices:
            guard()
            path=output/f'{model}-{index:03d}-result.json'
            if path.exists():
                report,phase=checked_point(model,index)
            else:
                require(not (output/f'{model}-{index:03d}.npz').exists() and not (output/f'{model}-{index:03d}-profile.npz').exists(),
                        'partial point requires inspection, not retry')
                if (datetime(2026,11,9,12,0,tzinfo=timezone.utc)-datetime.now(timezone.utc)).total_seconds()<300:
                    write(output/(mode+'-safe-stop.json'),dict(completed=False,model=model,next_index=index,reason='four-hour safe reserve'))
                    return
                if case is None:
                    case=ControlledPhaseSource(model,mode)
                report=case.sample(index,grid,output)
                phase=case.phase_control(index,grid,output,report,True)
                checked_point(model,index)
            nodes.append(report)
            controls.append(phase)
        reports.append(dict(model=model,nodes=nodes,phase_controls=controls))
    write(output/(mode+'-result.json'),dict(passed=True,inputs=inputs,sources=sources(),reports=reports,
        source_phase_time_control=True,current_phase_cross_term_retained=True,original_bank_grids_tolerances_unchanged=True))

