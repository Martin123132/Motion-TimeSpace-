from run_batch import run

if __name__=='__main__':
    run('probe',[1,129,257,385])
