from common import *


PARENT_MANIFEST=None


def parent(path):
    global PARENT_MANIFEST
    if PARENT_MANIFEST is None:
        require(digest(PHASE_RESPONSE/'closeout.json')=='e9605e1c81ad5b48ef790ee5f906cd1c29bf628140cc80f5fdd9b1c6ffbf73d2','phase-response seal')
        PARENT_MANIFEST={str(Path(item['path'])):item['sha256'] for item in read(PHASE_RESPONSE/'closeout.json')['artifacts']}
    key=str(Path(path))
    require(key in PARENT_MANIFEST and digest(path)==PARENT_MANIFEST[key], 'unchanged parent artifact '+key)
    return Path(path)


def checked_point(model,index):
    output=ROOT/'points-01'
    report=read(output/f'{model}-{index:03d}-result.json')
    phase=read(output/f'{model}-{index:03d}-phase-result.json')
    require(report['passed'] and phase['passed'] and report['index']==phase['index']==index
            and report['model']==phase['model']==model,'owned completed source point')
    for item in (report,phase):
        require(digest(item['path'])==item['sha256'],'saved point and control bytes')
    require(digest(phase['profile_report'])==phase['profile_report_sha256'],'profile receipt')
    profile=read(phase['profile_report'])
    require(profile['passed'] and profile['index']==index and profile['model']==model,'qualified profile')
    if model=='heavy':
        require(digest(profile['path'])==profile['sha256'],'original phase profile bytes')
    return report,phase
