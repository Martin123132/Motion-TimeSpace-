from run_batch import run

if __name__=='__main__':
    run('batch03',range(385,512,2))
