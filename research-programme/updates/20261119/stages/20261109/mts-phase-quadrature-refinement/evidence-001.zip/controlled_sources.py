from common import *
import sample_sources as original
from sample_sources import PhaseSource
from native_time import to_native,to_retained,relative
from mean_math import interpolate
import numpy as np


class ControlledPhaseSource(PhaseSource):
    def point_frame(self,efold,theta):
        profile=self.output/f'{self.model}-{self.point_index:03d}-profile.npz'
        require(not profile.exists(),'partial profile requires inspection')
        captured={}
        parent=original.full_average
        def capture(frozen,model,angle,primitive_path=None):
            require(model==self.model and angle==theta and frozen['efold']==efold,'owned profile point')
            answer=parent(frozen,model,angle,primitive_path=profile if model=='heavy' else None)
            captured['mean']=answer
            return answer
        original.full_average=capture
        try:
            frame,snapshot,checks=super().point_frame(efold,theta)
        finally:
            original.full_average=parent
        self.captured_mean=captured['mean']
        self.captured_snapshot=snapshot
        self.captured_frame=frame
        profile_report=dict(passed=True,model=self.model,index=self.point_index,efold=efold,phase=theta,
            path=str(profile) if self.model=='heavy' else None,
            sha256=digest(profile) if self.model=='heavy' else None,
            phase_absent=self.model=='cold',sources=sources(),consumed=self.consumed.copy())
        write(self.output/f'{self.model}-{self.point_index:03d}-profile-result.json',profile_report)
        return frame,snapshot,checks

    def sample(self,index,grid,output):
        self.output,self.point_index=output,index
        return super().sample(index,grid,output)

    def phase_control(self,index,grid,output,report,new):
        target_report=output/f'{self.model}-{index:03d}-phase-result.json'
        if target_report.exists():
            value=read(target_report)
            require(value['passed'] and digest(value['path'])==value['sha256'],'reuse qualified phase control')
            return value
        self.output,self.point_index=output,index
        saved=load(report['path'])
        efold,theta=float(saved['efold']),float(saved['phase'])
        if not new:
            frame,snapshot,checks=self.point_frame(efold,theta)
            require(max(relative(np.asarray(snapshot[key]),saved[key]) for key in snapshot)<ALGEBRA,'rebuilt profile leaves accepted frame unchanged')
        coarse_phase,unused=self.histories['step-coarse'].state(efold)
        source_delta=np.zeros_like(saved['forcing'])
        readout_delta=np.zeros_like(saved['readout_difference'])
        coarse_data={}
        if self.model=='heavy':
            profile_path=output/f'{self.model}-{index:03d}-profile.npz'
            profile=load(profile_path)
            mean=dict(self.captured_mean)
            mean['endpoint']=np.array([interpolate(coefficients,coarse_phase) for coefficients in profile['coefficients']])
            mean['remote_endpoint']=float(interpolate(profile['remote_coefficients'],coarse_phase)[0,0])
            parent=original.full_average
            def replay(frozen,model,angle,primitive_path=None):
                require(model==self.model and angle==coarse_phase and frozen['efold']==efold,'same N and same derived phase profile')
                return mean
            original.full_average=replay
            try:
                coarse_frame,coarse_snapshot,checks=PhaseSource.point_frame(self,efold,coarse_phase)
            finally:
                original.full_average=parent
            vectors=saved['retained_vectors']
            native=np.array([to_native(coarse_frame,item,vectors[branch]) for branch,item in enumerate(coarse_frame['branches'])])
            paired=self.native(efold,coarse_phase,native)
            coarse_source=np.array([to_retained(coarse_frame,item,paired['difference'][branch]) for branch,item in enumerate(coarse_frame['branches'])])
            source_delta=coarse_source-saved['forcing']
            readout_delta=paired['readout_difference']-saved['readout_difference']
            coarse_data={**{'map_'+key:np.asarray(value) for key,value in coarse_snapshot.items()},
                         **{'native_'+key:value for key,value in paired.items()}}
        else:
            require(theta==coarse_phase==0. and not self.owner.layout['heavy'],'baseline phase degree absent, not a zero-background assumption')
        projected=[]
        for control in ('fine','interpolation-coarse','step-coarse'):
            adjoint=self.adjoints[control](efold)*self.row_norm[:,:,None]
            projected.append(np.einsum('obd,bdv->bvo',adjoint,source_delta))
        target=output/f'{self.model}-{index:03d}-phase.npz'
        np.savez_compressed(target,source_change=source_delta,readout_change=readout_delta,projected=projected,
            fine_phase=theta,coarse_phase=coarse_phase,**coarse_data)
        profile_report=output/f'{self.model}-{index:03d}-profile-result.json'
        value=dict(passed=True,model=self.model,index=index,path=str(target),sha256=digest(target),
            fine_source=report['path'],fine_source_sha256=report['sha256'],
            profile_report=str(profile_report),profile_report_sha256=digest(profile_report),
            phase_change=coarse_phase-theta,phase_absent=self.model=='cold',
            includes_cross_term=True,sources=sources(),consumed=self.consumed.copy())
        write(target_report,value)
        print(LABEL,self.model,index,'phase/current cross control saved',flush=True)
        return value


