import common
from full_cell_sources import batch

batch(16)

