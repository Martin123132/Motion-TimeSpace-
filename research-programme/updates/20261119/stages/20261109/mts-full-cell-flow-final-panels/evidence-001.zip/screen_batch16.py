import common
from screen_batch import screen

screen(16)

