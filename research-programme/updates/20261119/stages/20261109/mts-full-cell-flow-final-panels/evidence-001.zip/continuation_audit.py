from common import *
from segment_audit import independent_parts
from exact_interval_weights import independent_moments
from response_support import adjoints
from correlated_source import full_endpoint
from scipy.sparse import block_diag,csc_matrix,diags
from scipy.sparse.linalg import splu
from decimal import Decimal,localcontext
from math import fsum
import numpy as np


def integrate(weights,values):
    shape=values.shape[1:]
    flattened=values.reshape(len(weights),-1)
    return np.array([fsum(float(weight)*float(value) for weight,value in zip(weights,flattened[:,column]))
                     for column in range(flattened.shape[1])]).reshape(shape)


def independently_integrate(weights,values):
    shape=values.shape[1:]
    flattened=values.reshape(len(weights),-1)
    with localcontext() as context:
        context.prec=90
        values=[float(sum(Decimal.from_float(float(weight))*Decimal.from_float(float(value))
                          for weight,value in zip(weights,flattened[:,column])))
                for column in range(flattened.shape[1])]
    return np.array(values).reshape(shape)


def independent_map(source,phase,flow,curves,row_norm):
    maximum=0.
    for phase_index in range(2):
        if phase_index==0:
            packet=source
        else:
            packet={key[4:]:value for key,value in phase.items() if key.startswith('map_')}
            packet['units']=source['units']
        dimension=len(packet['units'])
        compact=packet['inverse'].shape[-1]
        mono,dipole,quad=flow['massless_slots'].astype(int)
        physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
        for branch in range(2):
            inverse=block_diag((csc_matrix(packet['inverse'][branch]),diags(np.ones(dimension-compact))),format='csc')
            endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],
                                   float(packet['remote_endpoint']),dimension)
            native=np.zeros(dimension)
            native[mono]=1
            native[quad]=-packet['units'][mono]/packet['units'][quad]
            retained=splu(endpoint).solve(inverse@(physical@native))
            for adjoint_index,name in enumerate(('fine','interpolation-coarse','step-coarse')):
                adjoint=(curves[name](float(source['efold']))*row_norm[:,:,None])[flow['columns'].astype(int),branch]
                forward=adjoint@retained
                reverse=flow['coefficients'][phase_index,adjoint_index,branch]
                error=float(np.max(abs(forward-reverse)/np.maximum(np.maximum(abs(forward),abs(reverse)),1e-80)))
                require(error<ALGEBRA,'independent current and coarse-phase forward map')
                maximum=max(maximum,error)
    return maximum


def audit(mode):
    modest()
    output=STAGE/(mode+'-audit')
    output.mkdir(exist_ok=False)
    frozen_path=FROZEN_STAGE/LABEL/'freeze-01/result.json'
    frozen=read(frozen_path)
    grid=load(frozen['path'])
    consumed={str(frozen_path):digest(frozen_path),frozen['path']:frozen['sha256']}
    batches=[ROOT/'batches/probe-result.json'] if mode=='probe' else sorted(path for parent in (*INHERITED_BATCH_STAGES,STAGE) for path in (parent/LABEL/'batches').glob('batch*-result.json'))
    require(len(batches)>0,'completed source batch available')
    indexed={}
    for path in batches:
        report=read(path)
        require(report['passed'],'successful source batch')
        consumed[str(path)]=digest(path)
        consumed.update(report['consumed'])
        for segment in report['reports']:
            require(segment['ordinal'] not in indexed,'no duplicate batch segment')
            indexed[segment['ordinal']]=segment['nodes']
    if mode!='probe':
        inherited={row['index']:row for row in frozen['reuse'] if 'flow' in row}
        for segment in frozen['segments']:
            ordinal=segment['ordinal']
            if segment['inherited_33_node_panel'] and ordinal not in indexed:
                indexed[ordinal]=[dict(inherited[index]['flow'],index=index) for index in segment['indices']]
                for index,entry in zip(segment['indices'],indexed[ordinal]):
                    entry['index']=index
    curves,row_norm=adjoints('heavy',consumed)
    original_path=DIRECT_SOURCE/LABEL/'metric-projection-01/heavy-metric-projection.npz'
    original=load(original_path)
    consumed[str(original_path)]=digest(original_path)
    budget=original['budget']
    maximum_scalar=0.
    maximum_map=0.
    maximum_integral=0.
    scalar_cases=0
    node_count=0
    rows=[]
    segment_packets=[]
    for ordinal,entries in sorted(indexed.items()):
        segment=frozen['segments'][ordinal]
        require([entry['index'] for entry in entries]==segment['indices'],'complete frozen segment')
        components=[]
        for local_index,entry in enumerate(entries):
            guard()
            require(digest(entry['path'])==entry['sha256'],'node receipt unchanged')
            consumed[entry['path']]=entry['sha256']
            report=read(entry['path'])
            for path,checksum in report['sources'].items():
                require(digest(path)==checksum,'executed source unchanged')
            for key in ('path','source','phase'):
                checksum=report['sha256' if key=='path' else key+'_sha256']
                require(digest(report[key])==checksum,'source and control bytes')
                consumed[report[key]]=checksum
            flow=load(report['path'])
            require(float(flow['efold'])==float(grid['efold'][entry['index']]),'same frozen N')
            for phase_index,records in enumerate(report['primitive_records']):
                for record in records:
                    expected=np.array(independent_parts(record))
                    actual=np.array(record['parts'][1:3])
                    scale=np.maximum(np.maximum(abs(expected),abs(actual)),1e-80)
                    error=float(np.max(abs(expected-actual)/scale))
                    require(error<ALGEBRA,'independent 90-digit scalar source')
                    maximum_scalar=max(maximum_scalar,error)
                    scalar_cases+=2
                    branch=0 if record['branch']=='gr' else 1
                    for adjoint in range(3):
                        mapped=flow['coefficients'][phase_index,adjoint,branch,:,None]*np.array(record['parts'])[None,:]
                        require(np.array_equal(mapped,flow['components'][phase_index,adjoint,branch,record['column']]),'component binding')
            if mode=='probe' or local_index in (0,len(entries)//2,len(entries)-1):
                maximum_map=max(maximum_map,independent_map(load(report['source']),load(report['phase']),flow,curves,row_norm))
            components.append(flow['components'])
            node_count+=1
        components=np.array(components)
        integrals=[]
        for rule in segment['rules']:
            nodes=grid['efold'][segment['indices']][rule['local_indices']]
            require(independent_moments(nodes,rule['weights'],*segment['range'])<ALGEBRA,'exact interval moment test')
            values=components[rule['local_indices']]
            answer=integrate(rule['weights'],values)
            exact=independently_integrate(rule['weights'],values)
            magnitude=integrate(np.abs(rule['weights']),np.abs(values))
            error=float(np.max(abs(answer-exact)/np.maximum(magnitude,1e-80)))
            require(error<ALGEBRA,'independent integral relative to absolute weighted scale')
            maximum_integral=max(maximum_integral,error)
            integrals.append(answer)
        integrals=np.array(integrals)
        fine=integrals[-1,0,0,:,0,:,2]
        previous=integrals[-2,0,0,:,0,:,2]
        quadrature=fine-previous
        current=integrals[-1,0,0,:,1,:,2]
        phase=integrals[-1,1,0,:,0,:,2]-fine
        cross=integrals[-1,1,0,:,1,:,2]-current
        adjoint_interp=integrals[-1,0,1,:,0,:,2]-fine
        adjoint_step=integrals[-1,0,2,:,0,:,2]-fine
        indicator=abs(quadrature)+abs(current)+abs(phase)+abs(cross)+abs(adjoint_interp)+abs(adjoint_step)
        path=output/f'segment-{ordinal:03d}.npz'
        np.savez_compressed(path,integrals=integrals,orders=[rule['count'] for rule in segment['rules']],
                            fine=fine,quadrature=quadrature,current=current,phase=phase,cross=cross,
                            adjoint_interp=adjoint_interp,adjoint_step=adjoint_step,indicator=indicator,budget=budget)
        segment_packets.append(dict(ordinal=ordinal,path=str(path),sha256=digest(path)))
        rows.append(dict(ordinal=ordinal,segment=segment['segment'],points=len(entries),
                         finest_order=segment['rules'][-1]['count'],
                         fine_over_reference=(fine/original['reference_scale']).tolist(),
                         quadrature_over_budget=(quadrature/budget).tolist(),
                         indicator_over_budget=(indicator/budget).tolist(),
                         comparison_pass=(indicator/budget<GATE).tolist()))
        print(mode,'segment',ordinal,'heavy-flow indicator/budget',float(np.max(indicator/budget)),flush=True)
    totals={}
    for key in ('fine','quadrature','current','phase','cross','adjoint_interp','adjoint_step','indicator'):
        values=np.array([load(entry['path'])[key] for entry in segment_packets])
        totals[key]=integrate(np.ones(len(values)),values)
    accumulated=output/'completed-coverage.npz'
    np.savez_compressed(accumulated,**totals,budget=budget,reference_scale=original['reference_scale'])
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'audited inputs unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,mode=mode,
          completed_ordinals=sorted(indexed),completed_segments=len(indexed),total_segments=158,
          covered_fraction=sum(frozen['segments'][ordinal]['range'][1]-frozen['segments'][ordinal]['range'][0] for ordinal in indexed)/
                           (float(grid['efold'][-1])-float(grid['efold'][0])),
          node_count=node_count,independent_scalar_cases=scalar_cases,scalar_arithmetic_error=maximum_scalar,
          forward_map_error=maximum_map,independent_integral_absolute_scale_error=maximum_integral,
          rows=rows,segment_packets=segment_packets,accumulated=str(accumulated),accumulated_sha256=digest(accumulated),
          aggregate_triangle_indicator_over_budget=(totals['indicator']/budget).tolist(),
          source_qualification=False,no_source_replacement=True,
          baseline_control_source=frozen['baseline_control_source'],unchanged_gates=[ALGEBRA,GATE]))
    print(mode,'audit complete:',len(indexed),'segments;',node_count,'points',flush=True)






