import common
from full_cell_sources import build

build([96], 'probe')

