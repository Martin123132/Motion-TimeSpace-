from common import *
from cell_support import parent
from response_support import original_data,phase_rate
from prepare_grid import PhaseDense
from scipy.optimize import brentq
import numpy as np


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'grid-01'
    output.mkdir(parents=True,exist_ok=False)
    point_output=ROOT/'points-01'
    point_output.mkdir(exist_ok=False)
    old_path=parent(THIRD_CELL/LABEL/'grid-01/result.json')
    source_path=parent(THIRD_CELL/LABEL/'points-01/cell03-result.json')
    history_path=parent(THIRD_CELL/LABEL/'history-02/result.json')
    old_report,previous=read(old_path),read(source_path)
    require(old_report['passed'] and previous['passed'] and read(history_path)['passed'],'accepted parent grid, source and histories')
    consumed={str(path):digest(path) for path in (old_path,source_path,history_path)}
    reports=[]
    for model in ('heavy','cold'):
        item=next(row for row in old_report['reports'] if row['model']==model)
        for key in ('path','phase_path'):
            parent(item[key]);consumed[item[key]]=digest(item[key])
        old=load(item['path'])
        phase=PhaseDense(load(item['phase_path']))
        owner,source,bank,leading,slow,response,feedback,drift,kernel,paths=original_data(model)
        consumed.update(paths)
        intervals=2*(len(old['efold'])-1)
        require(intervals%8==0,'even quarter widths for frozen odd probes')
        grid={key:np.empty(intervals+1) for key in old}
        for key in old:
            grid[key][::2]=old[key]
        for index in range(1,intervals,2):
            guard()
            left,right=grid['efold'][index-1],grid['efold'][index+1]
            if model=='heavy':
                theta=grid['phase'][index-1]+(grid['phase'][index+1]-grid['phase'][index-1])/2
                efold=brentq(lambda value:phase(value)-theta,left,right,xtol=5e-324,rtol=4*np.finfo(float).eps)
                speed=phase_rate(owner,model,float(efold),float(theta))
                require(speed>0,'positive sampled physical clock')
                values=dict(efold=efold,phase=theta,coordinate=theta,jacobian=1/speed,speed=speed)
            else:
                efold=left+(right-left)/2
                values=dict(efold=efold,phase=0.,coordinate=efold,jacobian=1.,speed=0.)
            for key in grid:
                grid[key][index]=values[key]
        require(all(np.array_equal(grid[key][::2],old[key]) for key in old),'all inherited coordinates and measures bitwise identical')
        require(np.all(np.diff(grid['efold'])>0),'ordered nested quadrature')
        error=max(abs(phase(float(efold))-theta) for efold,theta in zip(grid['efold'],grid['phase']))
        require(error<ALGEBRA,'same original saved phase polynomial')
        case=next(row for row in previous['reports'] if row['model']==model)
        require(len(case['nodes'])==len(case['phase_controls'])==len(old['efold']),'complete inherited paired source')
        for ordinal,(node,control) in enumerate(zip(case['nodes'],case['phase_controls'])):
            for original,suffix in ((node,'result'),(control,'phase-result')):
                require(original['index']==ordinal and original['model']==model,'inherited source ordering')
                parent(original['path'])
                require(digest(original['path'])==original['sha256'],'inherited source bytes')
                consumed[original['path']]=original['sha256']
                wrapper=dict(original)
                wrapper.update(parent_index=ordinal,index=2*ordinal,reused_from_parent=True)
                write(point_output/f'{model}-{2*ordinal:03d}-{suffix}.json',wrapper)
        target=output/f'{model}-grid.npz'
        np.savez_compressed(target,**grid)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),phase_path=item['phase_path'],phase_sha256=item['phase_sha256'],
            parent_path=item['path'],parent_sha256=item['sha256'],points=intervals+1,intervals=intervals,
            parent_points=len(old['efold']),new_points=intervals//2,phase_error=float(error),
            probe_indices=[1,intervals//4+1,intervals//2+1,3*intervals//4+1],
            original_nodes_bitwise_identical=True,start=float(grid['efold'][0]),stop=float(grid['efold'][-1])))
        print(model,intervals+1,'refined points frozen;',len(old['efold']),'inherited samples unchanged',flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        parent_source_report=str(source_path),parent_source_report_sha256=digest(source_path),
        native_forcing_on_new_points_not_yet_evaluated=True,original_physical_input_grids_unchanged=True,
        reused_history=str(history_path),reused_history_sha256=digest(history_path),no_history_solve=True))


if __name__=='__main__':
    main()
