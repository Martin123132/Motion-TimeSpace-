from common import *
from cell_support import parent
from response_support import NAMES,BRANCHES
import numpy as np


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'accumulation-01'
    output.mkdir(exist_ok=False)
    prior_path=parent(SECOND_CELL/LABEL/'accumulation-01/result.json')
    current_path=ROOT/'projection-refined-cell03/result.json'
    prior,current=read(prior_path),read(current_path)
    require(prior['completed'] and current['completed'],'both cell projections complete')
    require(current['original_cell_indices']==[8,12] and not current['first_original_cell_only'],'third-cell metadata')
    grids=[read(parent(SECOND_CELL/LABEL/'grid-01/result.json')),read(ROOT/'grid-01/result.json')]
    consumed={str(prior_path):digest(prior_path),str(current_path):digest(current_path)}
    reports=[]
    records=[]
    for model in ('heavy','cold'):
        packets=[]
        cell_grids=[]
        for ordinal,result in enumerate((prior,current)):
            entry=next(item for item in result['reports'] if item['model']==model)
            require(digest(entry['path'])==entry['sha256'],'cell projection bytes')
            consumed[entry['path']]=entry['sha256']
            if ordinal==0:
                parent(entry['path'])
            packets.append(load(entry['path']))
            entry=next(item for item in grids[ordinal]['reports'] if item['model']==model)
            require(digest(entry['path'])==entry['sha256'],'cell physical grid bytes')
            consumed[entry['path']]=entry['sha256']
            cell_grids.append(load(entry['path']))
        first,second=packets
        left_path=parent(SECOND_CELL/LABEL/'projection-cell02'/f'{model}-projection.npz')
        consumed[str(left_path)]=digest(left_path)
        left_projection=load(left_path)
        require(np.array_equal(first['reference_scale'],second['reference_scale']),'same terminal observable scale')
        require(all(cell_grids[0][key][-1]==cell_grids[1][key][0] for key in cell_grids[0]),'adjacent physical phase and measure')
        require(np.array_equal(left_projection['projected'][-1],second['projected'][0])
                and np.array_equal(left_projection['phase_projected'][-1],second['phase_projected'][0]),'same shared source and controls')
        arrays={name:first[name]+second[name] for name in ('fine_signed','coarse_signed','coarser_signed')}
        for name in ('fine','coarse','coarser'):
            arrays[name+'_triangle_budget']=first[name+'_triangle_budget']+second[name+'_cauchy']
        change_names=[name for name in first if name.startswith('change_') and not name.endswith('_absolute_sum')]
        require(change_names==[name for name in second if name.startswith('change_')],'same control definitions')
        for name in change_names:
            arrays[name]=first[name]+second[name]
            arrays[name+'_absolute_sum']=first[name+'_absolute_sum']+abs(second[name])
        arrays['quadrature_absolute_sum']=first['quadrature_absolute_sum']+abs(second['fine_signed']-second['coarse_signed'])
        arrays['budget_change_absolute_sum']=first['budget_change_absolute_sum']+abs(second['fine_cauchy']-second['coarse_cauchy'])
        require(np.array_equal(first['boundaries'][-2:],[cell_grids[0]['efold'][0],cell_grids[0]['efold'][-1]]),'previous cumulative ends on the inherited cell')
        scale=first['reference_scale']
        budget=np.maximum(arrays['fine_triangle_budget'],1e-80)
        local_rows=[]
        for branch,branch_name in enumerate(BRANCHES):
            for column,name in enumerate(NAMES):
                index=(branch,column)
                previous=next(row for row in prior['records'] if row['model']==model and row['branch']==branch_name and row['channel']==name)
                present=next(row for row in current['records'] if row['model']==model and row['branch']==branch_name and row['channel']==name)
                diagnostics=dict(quadrature=float(arrays['quadrature_absolute_sum'][index]/budget[index]),
                    budget=float(arrays['budget_change_absolute_sum'][index]/budget[index]))
                diagnostics.update({key.removeprefix('change_'):float(arrays[key+'_absolute_sum'][index]/budget[index]) for key in change_names})
                cell_passes=previous['cell_numerical_passes']+[present['numerical_pass']]
                inside=bool(abs(arrays['fine_signed'][index])<=budget[index]*(1+GATE))
                passed=bool(previous['numerical_pass'] and all(cell_passes) and max(diagnostics.values())<GATE and inside)
                row=dict(model=model,branch=branch_name,channel=name,cell_numerical_passes=cell_passes,
                    numerical_pass=passed,cauchy_check=inside,diagnostics=diagnostics,
                    signed_contribution=float(arrays['fine_signed'][index]),triangle_budget=float(budget[index]),
                    physical_contribution_fraction=float(arrays['fine_signed'][index]/scale[index]),
                    physical_budget_fraction=float(budget[index]/scale[index]),
                    physical_quadrature_change_allowance=float(arrays['quadrature_absolute_sum'][index]/scale[index]))
                local_rows.append(row)
                records.append(row)
        target=output/f'{model}-accumulation.npz'
        np.savez_compressed(target,reference_scale=scale,
            boundaries=np.r_[first['boundaries'],cell_grids[1]['efold'][-1]],**arrays)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),passed=sum(row['numerical_pass'] for row in local_rows),
            cell_pass_counts=next(item['cell_pass_counts'] for item in prior['reports'] if item['model']==model)+[sum(row['numerical_pass'] for row in current['records'] if row['model']==model)],
            largest_physical_contribution=max(abs(row['physical_contribution_fraction']) for row in local_rows),
            largest_physical_budget=max(row['physical_budget_fraction'] for row in local_rows),
            largest_physical_quadrature_change_allowance=max(row['physical_quadrature_change_allowance'] for row in local_rows)))
        print(model,'three cells',reports[-1]['passed'],'of20 numerical controls; contribution',
            reports[-1]['largest_physical_contribution'],'budget',reports[-1]['largest_physical_budget'],flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'unchanged cell evidence')
    write(output/'result.json',dict(completed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,records=records,
        original_cell_indices=[[0,4],[4,8],[8,12]],same_terminal_adjoint=True,no_response_reset=True,
        cancellation_cannot_mask_failed_cell=True,whole_history_error_claimed=False,
        continuum_budget_certificate=False,all_numerical_controls_pass=all(row['numerical_pass'] for row in records)))


if __name__=='__main__':
    main()
