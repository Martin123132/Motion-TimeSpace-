from run_batch import run

run('batch02',2)
