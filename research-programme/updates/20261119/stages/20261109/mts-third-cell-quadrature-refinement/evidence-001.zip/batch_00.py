from run_batch import run

run('batch00',0)
