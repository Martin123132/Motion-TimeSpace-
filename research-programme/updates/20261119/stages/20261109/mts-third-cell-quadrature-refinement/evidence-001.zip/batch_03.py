from run_batch import run

run('batch03',3)
