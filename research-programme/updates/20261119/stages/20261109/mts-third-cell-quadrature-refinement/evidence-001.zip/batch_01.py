from run_batch import run

run('batch01',1)
