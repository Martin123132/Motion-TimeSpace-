from common import *
from point_support import checked_point


def main():
    modest()
    inputs=verify_inputs()
    grid_path=ROOT/'grid-01/result.json'
    grid=read(grid_path)
    consumed={str(grid_path):digest(grid_path)}
    for mode in ('probe','batch00','batch01','batch02','batch03'):
        path=ROOT/'points-01'/(mode+'-result.json')
        require(read(path)['passed'],'complete odd-source batch '+mode)
        consumed[str(path)]=digest(path)
    reports=[]
    for entry in grid['reports']:
        nodes=[];controls=[]
        for index in range(entry['points']):
            report,phase=checked_point(entry['model'],index)
            nodes.append(report);controls.append(phase)
            for item in (report,phase):
                consumed[item['path']]=item['sha256']
        reports.append(dict(model=entry['model'],nodes=nodes,phase_controls=controls))
    write(ROOT/'points-01/refined-cell03-result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        source_phase_time_control=True,current_phase_cross_term_retained=True,
        reused_source_points=sum(entry['parent_points'] for entry in grid['reports']),
        new_source_points=sum(entry['new_points'] for entry in grid['reports']),
        original_bank_grids_tolerances_unchanged=True,no_history_solve=True))
    print('complete third-cell refinement assembled, including every immutable inherited point',flush=True)


if __name__=='__main__':
    main()
