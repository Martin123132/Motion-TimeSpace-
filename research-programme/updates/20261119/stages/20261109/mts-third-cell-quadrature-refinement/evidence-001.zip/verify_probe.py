from common import *
from point_support import checked_point
from audit_phase_v2 import check_frame
import numpy as np


def main():
    modest()
    output=ROOT/'probe-verification'
    output.mkdir(exist_ok=False)
    grid=read(ROOT/'grid-01/result.json')
    probe_path=ROOT/'points-01/probe-result.json'
    require(read(probe_path)['passed'],'completed frozen odd probes')
    consumed={str(probe_path):digest(probe_path)}
    records=[]
    for entry in grid['reports']:
        model=entry['model']
        for index in entry['probe_indices']:
            report,control=checked_point(model,index)
            for item in (report,control):
                consumed[item['path']]=item['sha256']
            packet,phase=load(report['path']),load(control['path'])
            error=check_frame(packet,packet['retained_vectors'],packet['native_vectors'],packet['difference'],packet['forcing'])
            phase_error=0.
            if model=='heavy':
                snapshot={key.removeprefix('map_'):value for key,value in phase.items() if key.startswith('map_')}
                phase_error=check_frame(snapshot,packet['retained_vectors'],phase['native_native_vectors'],phase['native_difference'],packet['forcing']+phase['source_change'])
                require(report['checks']['clock']['minimum_speed']>0 and report['checks']['clock']['contraction_bound']<1,'positive controlled physical clock')
            require(report['checks']['primitive_refinement']<ALGEBRA and report['checks']['primitive_closure']<ALGEBRA,'unchanged primitive accuracy')
            records.append(dict(model=model,index=index,frame=error,phase_frame=phase_error))
        for endpoint in (0,entry['intervals']):
            report,control=checked_point(model,endpoint)
            require(report['original_map_errors'] is not None and max(report['original_map_errors'])<ALGEBRA,'inherited original source8/12 maps')
    write(output/'result.json',dict(passed=True,consumed=consumed,sources=sources(),records=records,
        original_endpoint_maps_reused=True,original_bank_grids_tolerances_unchanged=True))
    print('eight new odd probes qualified; inherited source8/12 endpoint maps preserved',flush=True)


if __name__=='__main__':
    main()
