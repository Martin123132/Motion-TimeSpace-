from common import *
from response_support import *
from clock_domain import certify
from scipy.integrate import simpson
import numpy as np


def run(mode):
    modest()
    inputs=verify_inputs()
    output=ROOT/('projection-'+mode)
    output.mkdir(exist_ok=False)
    source_path=ROOT/'points-01'/(mode+'-result.json')
    source=read(source_path)
    require(source['passed'] and source['source_phase_time_control'],'complete paired controlled source')
    grid_report=read(ROOT/'grid-01/result.json')
    consumed={str(source_path):digest(source_path),str(ROOT/'grid-01/result.json'):digest(ROOT/'grid-01/result.json')}
    reports=[]
    records=[]
    for model in ('heavy','cold'):
        item=next(item for item in source['reports'] if item['model']==model)
        nodes=item['nodes']
        selected=np.array([node['index'] for node in nodes],dtype=int)
        require(np.all(np.diff(selected)==selected[1]-selected[0]) and selected[0]==0 and selected[-1]==len(nodes)-1,'nested complete quadrature')
        grid_item=next(row for row in grid_report['reports'] if row['model']==model)
        for key,hash_key in (('path','sha256'),('phase_path','phase_sha256')):
            require(digest(grid_item[key])==grid_item[hash_key],'frozen phase grid')
            consumed[grid_item[key]]=grid_item[hash_key]
        grid=load(grid_item['path'])
        certificate,polynomial_jacobian,bounds=certify(load(grid_item['phase_path']),grid,model)
        values=[]
        phase_values=[]
        for node,phase_record in zip(nodes,item['phase_controls']):
            require(node['index']==phase_record['index'],'matched phase control')
            for entry in (node,phase_record):
                require(digest(entry['path'])==entry['sha256'],'saved projected source')
                consumed[entry['path']]=entry['sha256']
            packet=load(node['path'])
            phase_packet=load(phase_record['path'])
            require(float(packet['efold'])==grid['efold'][node['index']] and float(packet['jacobian'])==grid['jacobian'][node['index']],
                    'same phase quadrature and measure')
            values.append(packet['projected'])
            phase_values.append(phase_packet['projected'])
        values=np.array(values)
        phase_values=np.array(phase_values)
        coordinate=grid['coordinate'][selected]
        jacobian=grid['jacobian'][selected]
        width=float(grid['efold'][-1]-grid['efold'][0])
        signals=values[:,0,:,0]
        current_delta=values[:,0,:,1]
        phase_delta=phase_values[:,0,:,0]
        cross_delta=phase_values[:,0,:,1]
        current_and_phase=current_delta+phase_delta+cross_delta
        measures={}
        for name,stride in (('fine',1),('coarse',2),('coarser',4)):
            domain=coordinate[::stride]
            weighted=jacobian[::stride,None,None]
            signal=signals[::stride]
            measures[name+'_signed']=simpson(signal*weighted,x=domain,axis=0)
            measures[name+'_cauchy']=np.sqrt(width*np.maximum(simpson(signal**2*weighted,x=domain,axis=0),0.))
            measures[name+'_volume']=np.array(simpson(jacobian[::stride],x=domain))
        changes={}
        for name,signal in (('current',current_delta),('phase',phase_delta),('cross',cross_delta),
                            ('current_and_phase',current_and_phase),
                            ('adjoint_interpolation',values[:,1,:,0]-signals),
                            ('adjoint_steps',values[:,2,:,0]-signals)):
            changes[name]=simpson(signal*jacobian[:,None,None],x=coordinate,axis=0)
        changes['clock_measure']=simpson(signals*(polynomial_jacobian[selected]-jacobian)[:,None,None],x=coordinate,axis=0)
        reference_path=record(consumed,RESPONSE_STAGE/LABEL/'comparison-02'/f'{model}-comparison.npz')
        reference=load(reference_path)['reference_scale']
        budget=np.maximum(measures['fine_cauchy'],1e-80)
        quadrature=abs(measures['fine_signed']-measures['coarse_signed'])/budget
        budget_change=abs(measures['fine_cauchy']-measures['coarse_cauchy'])/budget
        volume_error=abs(float(measures['fine_volume'])-width)/width
        for branch,branch_name in enumerate(BRANCHES):
            for column,name in enumerate(NAMES):
                diagnostics=dict(quadrature=float(quadrature[branch,column]),budget=float(budget_change[branch,column]),
                    **{key:float(abs(value[branch,column])/budget[branch,column]) for key,value in changes.items()})
                inside=bool(abs(measures['fine_signed'][branch,column])<=budget[branch,column]*(1+GATE))
                passes=bool(max(diagnostics.values())<GATE and volume_error<GATE and inside)
                records.append(dict(model=model,branch=branch_name,channel=name,diagnostics=diagnostics,
                    numerical_pass=passes,cauchy_check=inside,volume_error=volume_error,
                    contribution=float(measures['fine_signed'][branch,column]),cauchy_budget=float(budget[branch,column]),
                    physical_contribution_fraction=float(measures['fine_signed'][branch,column]/reference[branch,column]),
                    physical_budget_fraction=float(budget[branch,column]/reference[branch,column]),
                    physical_control_changes={key:float(value[branch,column]/reference[branch,column]) for key,value in changes.items()}))
        target=output/f'{model}-projection.npz'
        np.savez_compressed(target,indices=selected,coordinate=coordinate,jacobian=jacobian,
            polynomial_jacobian=polynomial_jacobian[selected],projected=values,phase_projected=phase_values,
            clock_bounds=bounds,reference_scale=reference,**measures,**{'change_'+key:value for key,value in changes.items()})
        clock_path=output/f'{model}-clock.json'
        write(clock_path,certificate)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),clock_path=str(clock_path),clock_sha256=digest(clock_path),
            points=len(selected),passed=sum(item['numerical_pass'] for item in records if item['model']==model),
            largest_physical_contribution=max(abs(item['physical_contribution_fraction']) for item in records if item['model']==model),
            largest_physical_budget=max(item['physical_budget_fraction'] for item in records if item['model']==model),
            clock=certificate,volume_error=volume_error))
        print(LABEL,model,len(selected),'points',reports[-1]['passed'],'of20 numerical controls; contribution',
              reports[-1]['largest_physical_contribution'],'budget',reports[-1]['largest_physical_budget'],flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'immutable source evidence')
    write(output/'result.json',dict(completed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,records=records,
        all_numerical_controls_pass=all(item['numerical_pass'] for item in records),
        first_original_cell_only=False,original_cell_indices=[8,12],final_saved_epoch_adjoint_reused=True,
        phase_and_current_cross_term_retained=True,whole_history_error_claimed=False,continuum_budget_certificate=False))
