from common import *
from cell_support import parent


def checked_point(model,index):
    output=ROOT/'points-01'
    report=read(output/f'{model}-{index:03d}-result.json')
    phase=read(output/f'{model}-{index:03d}-phase-result.json')
    require(report['passed'] and phase['passed'] and report['index']==phase['index']==index,'completed paired point')
    for item in (report,phase):
        require(item['model']==model and digest(item['path'])==item['sha256'],'point identity and bytes')
    if index%2==0:
        for item in (report,phase):
            require(item['reused_from_parent'] and item['parent_index']==index//2,'inherited even point')
            parent(item['path'])
    else:
        require(digest(phase['profile_report'])==phase['profile_report_sha256'],'new profile receipt')
        profile=read(phase['profile_report'])
        require(profile['passed'] and profile['index']==index and profile['model']==model,'new odd profile ownership')
        if model=='heavy':
            require(digest(profile['path'])==profile['sha256'],'profile bytes')
    return report,phase
