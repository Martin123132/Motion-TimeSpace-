from common import *
from fractions import Fraction
import math
import numpy as np
from scipy.sparse import block_diag,csc_matrix,diags
from scipy.sparse.linalg import splu
from response_support import adjoints,NAMES,BRANCHES
from correlated_source import full_endpoint


def sum_nodes(weight,values):
    return np.array([[math.fsum(float(weight[node])*float(values[node,branch,column])
        for node in range(len(weight))) for column in range(values.shape[2])]
        for branch in range(values.shape[1])])


def main():
    modest()
    output=ROOT/'massless-identity-01'
    output.mkdir(exist_ok=False)
    consumed={}
    def take(path):
        path=Path(path)
        consumed[str(path)]=digest(path)
        return read(path)
    source=take(ROOT/'points-01/refined-cell03-result.json')
    prior=take(ROOT/'source-attribution-01/result.json')
    require(prior['passed'] and prior['no_accepted_source_replacement'],'accepted saved attribution')
    for path,checksum in prior['consumed'].items():
        require(digest(path)==checksum,'unchanged attribution input')
        consumed[path]=checksum
    for path,checksum in prior['sources'].items():
        require(digest(path)==checksum,'unchanged attribution implementation')
        consumed[path]=checksum
    bridge=take(ADAPTER/'build/build-result.json')
    canonical=take(COLD/'build-canonical-stress/build-result.json')
    thermal=take(FULL/'build-thermal-readout/build-result.json')
    equation=ADAPTER/'build/equations.f90'
    require(digest(equation)==bridge['source_hashes']['equations.f90'],'native source-to-build provenance')
    consumed[str(equation)]=digest(equation)
    equation_text=equation.read_text()
    for expression in ('clxrdot=-k*(4._dl/3._dl*z+qr)',
                       'pirdot= -3*pir*cothxor - clxrdot','cothxor=1._dl/tau'):
        require(expression in equation_text,'retained flat fluid equations')
    bridge_object=ADAPTER/'build/equations.o'
    canonical_object=COLD/'build-canonical-stress/equations.o'
    thermal_object=FULL/'build-thermal-readout/equations.o'
    object_hash=digest(bridge_object)
    require(canonical['reused_bridge_hashes'][str(bridge_object)]==object_hash,'canonical build reused bridge object')
    require(thermal['consumed'][str(canonical_object)]==object_hash,'thermal build reused canonical object')
    for path in (bridge_object,canonical_object,thermal_object):
        require(digest(path)==object_hash,'same compiled equations object')
        consumed[str(path)]=object_hash
    for path in (FULL/'build-thermal-readout/camb_python.f90',SEALED/'rest_operator_v2.py',
                 ORIGINAL_POISSON/'poisson_driver.py',TIME_STAGE/'native_time.py'):
        consumed[str(path)]=digest(path)
    require(digest(FULL/'build-thermal-readout/native/camb/cambdll.dll')==thermal['dll_sha256'],'retained native library')
    consumed[str(FULL/'build-thermal-readout/native/camb/cambdll.dll')]=thermal['dll_sha256']
    write(output/'freeze.json',dict(sources=sources(),equations_sha256=digest(equation),
        inherited_approximation='flat high_ktau_neutrino_approx, not a new MTS law',
        prediction='U0*r0+U2*r2=-3*p/(tau*H); fixed-state difference uses exact reciprocal product difference',
        models=['heavy','cold'],branches=BRANCHES,channels=['Pi','delta_massless'],
        no_new_native_calls=True,no_source_replacement=True,unchanged_gates=[ALGEBRA,GATE]))
    reports=[];records=[];supplement=[]
    for model in ('heavy','cold'):
        attr_row=next(row for row in prior['reports'] if row['model']==model)
        require(digest(attr_row['path'])==attr_row['sha256'],'saved attribution')
        consumed[attr_row['path']]=attr_row['sha256']
        attr=load(attr_row['path'])
        coordinate=attr['coordinate'];jacobian=attr['jacobian']
        widths=np.diff(coordinate)
        independent_weights=np.r_[widths[0]/2,(widths[:-1]+widths[1:])/2,widths[-1]/2]*jacobian
        require(np.array_equal(independent_weights,attr['weights']),'independent trapezoidal weights')
        coarse_widths=np.diff(coordinate[::2])
        coarse_weights=np.zeros(len(coordinate))
        coarse_weights[::2]=np.r_[coarse_widths[0]/2,(coarse_widths[:-1]+coarse_widths[1:])/2,
            coarse_widths[-1]/2]*jacobian[::2]
        refinement_weights=independent_weights-coarse_weights
        require(np.array_equal(refinement_weights,attr['refinement_weights']),'independent nested weights')
        delta=sum_nodes(refinement_weights,attr['original'])
        stable_delta=sum_nodes(refinement_weights,attr['compensated'])
        changes=sum_nodes(independent_weights,attr['compensated']-attr['original'])
        budget=attr['budget']
        audit_error=max(float(np.max(abs(delta-attr['refinement_terms'].sum(axis=-1))/budget)),
            float(np.max(abs(changes-attr['arithmetic_change'])/budget)),
            float(np.max(abs(delta-stable_delta)/budget)))
        require(audit_error<ALGEBRA,'independent attribution integral audit')
        supplement.append(dict(model=model,passed=True,independent_error=audit_error))
        context_path=ROOT/'points-01'/f'contexts-probe-{model}'/f'{model}-balanced/initial-context.npz'
        consumed[str(context_path)]=digest(context_path)
        context=load(context_path)
        require(context['signature'][12]==1 and context['signature'][13]==0,'active massless fluid branch')
        layout_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-00-source.json')
        layout=take(layout_path)['layout']
        mono,dipole,quad=layout['massless_all']
        require(quad==mono+2 and dipole==mono+1,'three massless components, not the massive G192 tail')
        curves,row_norm=adjoints(model,consumed)
        columns=attr['columns'].astype(int)
        require([NAMES[index] for index in columns]==['Pi','delta_massless'],'same observable channels')
        case=next(row for row in source['reports'] if row['model']==model)
        decompositions=[];errors=[];clock_factors=[];inverse_checks=[]
        for node in case['nodes']:
            guard()
            require(digest(node['path'])==node['sha256'],'source packet unchanged')
            consumed[node['path']]=node['sha256']
            packet=load(node['path'])
            units=packet['units'];dimension=len(units)
            require(units[mono]>0 and units[quad]>0,'positive native scaling')
            compact=packet['inverse'].shape[-1]
            physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
            adjoint=(curves['fine'](float(packet['efold']))*row_norm[:,:,None])[columns]
            tau_ref,hubble_ref=map(float,packet['reference_background'][11:13])
            tau_ret,hubble_ret=map(float,packet['retained_background'][11:13])
            require(min(tau_ref,hubble_ref,tau_ret,hubble_ret)>0,'positive proper background factors')
            exact_ref=Fraction(tau_ref)*Fraction(hubble_ref)
            exact_ret=Fraction(tau_ret)*Fraction(hubble_ret)
            reciprocal_delta=float(1/exact_ref-1/exact_ret)
            symmetric_delta=-(((Fraction(tau_ref)+Fraction(tau_ret))/2)*(Fraction(hubble_ref)-Fraction(hubble_ret))
                +((Fraction(hubble_ref)+Fraction(hubble_ret))/2)*(Fraction(tau_ref)-Fraction(tau_ret)))/(exact_ref*exact_ret)
            require(symmetric_delta==1/exact_ref-1/exact_ret,'exact symmetric reciprocal identity')
            clock_factors.append((tau_ref,hubble_ref,tau_ret,hubble_ret,reciprocal_delta))
            branch_parts=[];branch_errors=[]
            for branch in range(2):
                inverse=block_diag((csc_matrix(packet['inverse'][branch]),
                    diags(np.ones(dimension-compact))),format='csc')
                endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],
                    float(packet['remote_endpoint']),dimension)
                covectors=physical.T@(inverse.T@splu(endpoint).solve(adjoint[:,branch,:].T,trans='T'))
                moment=float(units[quad]*packet['native_vectors'][branch,quad,0])
                single_errors=[]
                for side,tau,hubble in (('reference',tau_ref,hubble_ref),('retained',tau_ret,hubble_ret)):
                    rates=packet[side+'_rates'][branch,:,0]
                    terms=[float(units[mono]*rates[mono]),float(units[quad]*rates[quad]),3*moment/(tau*hubble)]
                    single_errors.append(abs(math.fsum(terms))/max(sum(map(abs,terms)),1e-80))
                require(max(single_errors)<ALGEBRA,'flat-fluid sum identity on both saved backgrounds')
                difference=packet['difference'][branch,:,0]
                old_pair=covectors[mono]*difference[mono]+covectors[quad]*difference[quad]
                density=(covectors[mono]-covectors[quad]*units[mono]/units[quad])*difference[mono]
                damping=-3*covectors[quad]*(moment/units[quad])*reciprocal_delta
                residue=old_pair-density-damping
                branch_parts.append(np.stack((old_pair,density,damping,residue),axis=-1))
                branch_errors.append(single_errors)
            decompositions.append(branch_parts);errors.append(branch_errors)
            if node['index']%256==0:
                print(model,node['index'],'source-derived massless sum checked',flush=True)
        parts=np.array(decompositions);errors=np.array(errors)
        integral=np.stack([sum_nodes(independent_weights,parts[:,:,:,part]) for part in range(4)],axis=-1)
        refinement=np.stack([sum_nodes(refinement_weights,parts[:,:,:,part]) for part in range(4)],axis=-1)
        expected_pair=attr['refinement_terms'][:,:,mono]+attr['refinement_terms'][:,:,quad]
        decomposition_error=float(np.max(abs(expected_pair-refinement[:,:,0])/budget))
        require(decomposition_error<ALGEBRA,'independent coordinate attribution reproduced')
        closure_error=float(np.max(abs(refinement[:,:,0]-refinement[:,:,1:].sum(axis=-1))/budget))
        require(closure_error<ALGEBRA,'metric/damping/residual decomposition')
        for branch,name in enumerate(BRANCHES):
            for column,channel in enumerate(('Pi','delta_massless')):
                index=(branch,column)
                records.append(dict(model=model,branch=name,channel=channel,
                    total_refinement=float(delta[index]/budget[index]),
                    pair_refinement=float(refinement[index][0]/budget[index]),
                    monopole_transfer_refinement=float(refinement[index][1]/budget[index]),
                    clock_damping_refinement=float(refinement[index][2]/budget[index]),
                    rate_representation_residual_refinement=float(refinement[index][3]/budget[index]),
                    hypothetical_integral_change=float(-integral[index][3]/budget[index]),
                    hypothetical_physical_change=float(-integral[index][3]/attr['reference_scale'][index]),
                    no_source_replacement=True))
        target=output/f'{model}-massless-identity.npz'
        np.savez_compressed(target,coordinate=coordinate,weights=independent_weights,
            refinement_weights=refinement_weights,parts=parts,rate_identity_errors=errors,
            clock_factors=clock_factors,integral=integral,refinement=refinement,
            budget=budget,reference_scale=attr['reference_scale'],massless_slots=[mono,dipole,quad])
        reports.append(dict(model=model,path=str(target),sha256=digest(target),points=len(coordinate),
            rate_identity_max=float(np.max(errors)),decomposition_error=decomposition_error,
            closure_error=closure_error,signature_high_ktau=1,signature_no_nu=0))
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'all consumed inputs preserved')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,records=records,
        attribution_independent_verification=supplement,inherited_approximation=True,
        flat_fluid_identity_checked=True,no_new_native_calls=True,no_history_solve=True,
        no_source_replacement=True,no_accuracy_pass_claimed=True,
        original_bank_grids_tolerances_unchanged=True,
        literature_url='https://arxiv.org/abs/1104.2933v3',
        literature_scope='origin of inherited approximation; exact tested equations taken from retained compiled-source chain'))
    print('massless-fluid identity and independent attribution checks complete',flush=True)


if __name__=='__main__':
    main()

