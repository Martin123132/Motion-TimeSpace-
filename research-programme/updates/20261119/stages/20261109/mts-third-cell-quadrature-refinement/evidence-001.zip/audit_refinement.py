from common import *
from cell_support import parent
from point_support import checked_point
from audit_phase_v2 import check_frame
from response_support import adjoints,NAMES,BRANCHES
from clock_domain import certify
from scipy.integrate import simpson
import numpy as np
import psutil


def relative(left,right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.linalg.norm(right),1e-80))


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed,verified,accepted={},{},{}
    def hashes(records):
        for path,seal in records.items():
            guard()
            if path not in verified:
                verified[path]=digest(path)
            require(verified[path]==seal,'immutable evidence '+path)
            consumed[path]=seal
    def take(path):
        value=read(path)
        require(value.get('passed') or value.get('completed'),'completed evidence '+str(path))
        for key in ('inputs','sources','consumed'):
            hashes(value.get(key,{}))
        accepted[str(path)]=digest(path)
        return value
    expected=(THIRD_CELL/'sample_sources_v2.py').read_text(encoding='utf-8-sig').replace("report_path=ROOT/'history-02/result.json'","report_path=THIRD_CELL/LABEL/'history-02/result.json'")
    require((STAGE/'sample_sources_v2.py').read_text(encoding='utf-8-sig').rstrip()==expected.rstrip(),'only read-only history location adapted')
    for name in ('controlled_sources_v2.py','project_response.py'):
        require((STAGE/name).read_text(encoding='utf-8-sig').rstrip()==(THIRD_CELL/name).read_text(encoding='utf-8-sig').rstrip(),'unchanged numerical class '+name)
    grid_report=take(ROOT/'grid-01/result.json')
    take(ROOT/'probe-verification/result.json')
    source=take(ROOT/'points-01/refined-cell03-result.json')
    projection=take(ROOT/'projection-refined-cell03/result.json')
    accumulation=take(ROOT/'accumulation-01/result.json')
    diagnosis=take(ROOT/'quadrature-diagnosis-01/result.json')
    history_path=parent(THIRD_CELL/LABEL/'history-02/result.json')
    require(Path(grid_report['reused_history'])==history_path and grid_report['no_history_solve'],'same accepted histories, no new solve')
    histories=read(history_path)
    require(histories['passed'] and len(histories['reports'])==4,'four inherited controls')
    for row in histories['reports']:
        parent(row['index']);hashes({row['index']:row['sha256']})
        for chunk in read(row['index'])['chunks']:
            parent(chunk['path']);hashes({chunk['path']:chunk['sha256']})
    require(not (ROOT/'history-01').exists() and not (ROOT/'history-02').exists(),'no new or reset evolution')
    old_source=read(parent(THIRD_CELL/LABEL/'points-01/cell03-result.json'))
    old_result=read(parent(THIRD_CELL/LABEL/'projection-cell03/result.json'))
    prior_accum=read(parent(SECOND_CELL/LABEL/'accumulation-01/result.json'))
    require(projection['original_cell_indices']==[8,12] and not projection['first_original_cell_only'],'refines only original third cell')
    require(accumulation['original_cell_indices']==[[0,4],[4,8],[8,12]] and not accumulation['continuum_budget_certificate'],'same three-cell scope')
    grid_end=read(STAGE/'grid-balanced-01.end.json')
    probe_start=read(STAGE/'probe-balanced-01.start.json')
    require(datetime.fromisoformat(grid_end['finished'])<datetime.fromisoformat(probe_start['created'].replace('Z','+00:00')),'grid frozen before new source evaluation')
    probe_end=read(STAGE/'verify-probe-01.end.json')
    for number in range(4):
        start=read(STAGE/f'batch{number:02d}-balanced-01.start.json')
        require(datetime.fromisoformat(probe_end['finished'])<datetime.fromisoformat(start['created'].replace('Z','+00:00')),'probe qualified before bulk')
        batch=take(ROOT/'points-01'/f'batch{number:02d}-result.json')
        for case in batch['reports']:
            entry=next(row for row in grid_report['reports'] if row['model']==case['model'])
            intervals=entry['intervals']
            require([row['index'] for row in case['nodes']]==list(range(number*intervals//4+1,(number+1)*intervals//4,2)),'complete new odd quarter')
    counts=dict(reused_histories=4,reused_points=0,new_points=0,phase_controls=0,projected_channels=0,accumulated_channels=0)
    maxima=dict(frame=0.,phase_frame=0.,adjoint_contraction=0.,primitive_refinement=0.,primitive_closure=0.)
    summary=[]
    for model in ('heavy','cold'):
        entry=next(row for row in grid_report['reports'] if row['model']==model)
        hashes({entry['path']:entry['sha256'],entry['phase_path']:entry['phase_sha256']})
        grid=load(entry['path'])
        old_grid=load(parent(entry['parent_path']))
        parent(entry['phase_path'])
        require(all(np.array_equal(grid[key][::2],old_grid[key]) for key in old_grid),'all old physical coordinates and measures retained bitwise')
        points=2*(len(old_grid['efold'])-1)+1
        require(points==entry['points']==len(grid['efold']) and np.all(np.diff(grid['efold'])>0),'complete ordered nested grid')
        case=next(item for item in source['reports'] if item['model']==model)
        old_case=next(item for item in old_source['reports'] if item['model']==model)
        result=next(item for item in projection['reports'] if item['model']==model)
        hashes({result['path']:result['sha256'],result['clock_path']:result['clock_sha256']})
        projected=load(result['path'])
        old_projected=load(parent(THIRD_CELL/LABEL/'projection-cell03'/f'{model}-projection.npz'))
        require(np.array_equal(projected['indices'],np.arange(points)),'complete source projection')
        for new_key,old_key in (('coarse_signed','fine_signed'),('coarse_cauchy','fine_cauchy'),('coarser_signed','coarse_signed'),('coarser_cauchy','coarse_cauchy')):
            require(np.array_equal(projected[new_key],old_projected[old_key]),'old integral and Cauchy expression reproduced BITWISE')
        require(np.array_equal(projected['reference_scale'],old_projected['reference_scale']),'same terminal normalization')
        certificate,clock_measure,clock_bounds=certify(load(entry['phase_path']),grid,model)
        require(certificate==result['clock'] and np.array_equal(clock_measure,projected['polynomial_jacobian'])
                and np.array_equal(clock_bounds,projected['clock_bounds']),'unchanged saved-polynomial clock certificate')
        curves,row_norm=adjoints(model,consumed)
        require(len(case['nodes'])==len(case['phase_controls'])==points,'complete paired source')
        for node,control in zip(case['nodes'],case['phase_controls']):
            index=node['index']
            require(control['index']==index and node['model']==control['model']==model,'paired metadata')
            checked_point(model,index)
            for item in (node,control):
                hashes({item['path']:item['sha256']})
            packet,phase=load(node['path']),load(control['path'])
            require(float(packet['efold'])==grid['efold'][index] and float(packet['phase'])==grid['phase'][index]
                    and float(packet['jacobian'])==grid['jacobian'][index],'source on frozen original coordinates')
            require(np.array_equal(projected['projected'][index],packet['projected'])
                    and np.array_equal(projected['phase_projected'][index],phase['projected']),'same projected packet/control')
            if index%2==0:
                ordinal=index//2
                for item,original in ((node,old_case['nodes'][ordinal]),(control,old_case['phase_controls'][ordinal])):
                    require(item['parent_index']==ordinal and item['reused_from_parent'] and item['path']==original['path']
                            and item['sha256']==original['sha256'],'old source reused without rewrite or recomputation')
                    parent(item['path'])
                counts['reused_points']+=1
            else:
                for item in (node,control):
                    hashes(item['sources']);hashes(item['consumed'])
                hashes({control['profile_report']:control['profile_report_sha256']})
                profile=take(control['profile_report'])
                if model=='heavy':
                    hashes({profile['path']:profile['sha256']})
                require(all(np.isfinite(value).all() for value in packet.values()) and all(np.isfinite(value).all() for value in phase.values()),'finite new native packets')
                require(np.array_equal(packet['difference'],packet['reference_rates']-packet['retained_rates']),'native source sign')
                maxima['frame']=max(maxima['frame'],check_frame(packet,packet['retained_vectors'],packet['native_vectors'],packet['difference'],packet['forcing']))
                if model=='heavy':
                    snapshot={key.removeprefix('map_'):value for key,value in phase.items() if key.startswith('map_')}
                    maxima['phase_frame']=max(maxima['phase_frame'],check_frame(snapshot,packet['retained_vectors'],phase['native_native_vectors'],phase['native_difference'],packet['forcing']+phase['source_change']))
                    require(node['checks']['clock']['minimum_speed']>0 and node['checks']['clock']['contraction_bound']<1,'physical phase clock')
                else:
                    require(np.all(phase['source_change']==0),'only absent baseline phase control is set zero')
                for order,name in enumerate(('fine','interpolation-coarse','step-coarse')):
                    adjoint=curves[name](float(packet['efold']))*row_norm[:,:,None]
                    for actual,forcing in ((packet['projected'][order],packet['forcing']),(phase['projected'][order],phase['source_change'])):
                        expected=np.einsum('obd,bdv->bvo',adjoint,forcing)
                        deviation=relative(expected,actual)
                        require(deviation<ALGEBRA,'independent physical adjoint contraction')
                        maxima['adjoint_contraction']=max(maxima['adjoint_contraction'],deviation)
                for key in ('primitive_refinement','primitive_closure'):
                    require(node['checks'][key]<ALGEBRA,'unchanged phase primitive accuracy')
                    maxima[key]=max(maxima[key],node['checks'][key])
                counts['new_points']+=1
            counts['phase_controls']+=1
        coordinate,jacobian=projected['coordinate'],projected['jacobian']
        values,phases=projected['projected'],projected['phase_projected']
        signal=values[:,0,:,0]
        width=float(grid['efold'][-1]-grid['efold'][0])
        for name,stride in (('fine',1),('coarse',2),('coarser',4)):
            signed=simpson(signal[::stride]*jacobian[::stride,None,None],x=coordinate[::stride],axis=0)
            budget=np.sqrt(width*np.maximum(simpson(signal[::stride]**2*jacobian[::stride,None,None],x=coordinate[::stride],axis=0),0.))
            require(np.array_equal(signed,projected[name+'_signed']) and np.array_equal(budget,projected[name+'_cauchy']),'same integral and conditional Cauchy expression')
        changes=dict(current=values[:,0,:,1],phase=phases[:,0,:,0],cross=phases[:,0,:,1],
            adjoint_interpolation=values[:,1,:,0]-signal,adjoint_steps=values[:,2,:,0]-signal)
        changes['current_and_phase']=changes['current']+changes['phase']+changes['cross']
        for name,change in changes.items():
            require(np.array_equal(simpson(change*jacobian[:,None,None],x=coordinate,axis=0),projected['change_'+name]),'separate numerical control preserved')
        require(np.array_equal(simpson(signal*(clock_measure-jacobian)[:,None,None],x=coordinate,axis=0),projected['change_clock_measure']),'clock-measure control')
        accumulated=next(item for item in accumulation['reports'] if item['model']==model)
        hashes({accumulated['path']:accumulated['sha256']})
        combined=load(accumulated['path'])
        earlier=load(parent(SECOND_CELL/LABEL/'accumulation-01'/f'{model}-accumulation.npz'))
        require(np.array_equal(combined['reference_scale'],projected['reference_scale']),'same cumulative scale')
        require(np.array_equal(combined['boundaries'],np.r_[earlier['boundaries'],grid['efold'][-1]])
                and earlier['boundaries'][-1]==grid['efold'][0],'three cells; no overlap or double count')
        for name in ('fine','coarse','coarser'):
            require(np.array_equal(combined[name+'_signed'],earlier[name+'_signed']+projected[name+'_signed']),'refined third cell added to TWO-cell sum only')
            require(np.array_equal(combined[name+'_triangle_budget'],earlier[name+'_triangle_budget']+projected[name+'_cauchy']),'conditional triangle accumulation')
        control_keys=[key for key in projected if key.startswith('change_')]
        for name in control_keys:
            require(np.array_equal(combined[name],earlier[name]+projected[name])
                    and np.array_equal(combined[name+'_absolute_sum'],earlier[name+'_absolute_sum']+abs(projected[name])),'accumulated signed/absolute controls')
        require(np.array_equal(combined['quadrature_absolute_sum'],earlier['quadrature_absolute_sum']+abs(projected['fine_signed']-projected['coarse_signed'])),'no cancelled refinement errors')
        require(np.array_equal(combined['budget_change_absolute_sum'],earlier['budget_change_absolute_sum']+abs(projected['fine_cauchy']-projected['coarse_cauchy'])),'no cancelled budget errors')
        volume_error=abs(float(projected['fine_volume'])-width)/width
        rows=[row for row in projection['records'] if row['model']==model]
        trends=[]
        require(len(rows)==20,'both branches and ten output channels')
        for row in rows:
            branch,column=BRANCHES.index(row['branch']),NAMES.index(row['channel'])
            index=(branch,column)
            budget=max(float(projected['fine_cauchy'][index]),1e-80)
            diagnostics=dict(quadrature=abs(projected['fine_signed'][index]-projected['coarse_signed'][index])/budget,
                budget=abs(projected['fine_cauchy'][index]-projected['coarse_cauchy'][index])/budget)
            diagnostics.update({key.removeprefix('change_'):abs(projected[key][index])/budget for key in control_keys})
            require(all(float(value)==row['diagnostics'][name] for name,value in diagnostics.items()),'unchanged diagnostic definitions')
            inside=abs(projected['fine_signed'][index])<=budget*(1+GATE)
            passed=bool(max(diagnostics.values())<GATE and volume_error<GATE and inside)
            require(row['numerical_pass']==passed,'failure flags never silently promoted')
            prior=next(item for item in prior_accum['records'] if item['model']==model and item['branch']==row['branch'] and item['channel']==row['channel'])
            total=next(item for item in accumulation['records'] if item['model']==model and item['branch']==row['branch'] and item['channel']==row['channel'])
            total_budget=max(float(combined['fine_triangle_budget'][index]),1e-80)
            total_diagnostics=dict(quadrature=float(combined['quadrature_absolute_sum'][index]/total_budget),
                budget=float(combined['budget_change_absolute_sum'][index]/total_budget))
            total_diagnostics.update({key.removeprefix('change_'):float(combined[key+'_absolute_sum'][index]/total_budget) for key in control_keys})
            total_pass=bool(prior['numerical_pass'] and passed and max(total_diagnostics.values())<GATE
                            and abs(combined['fine_signed'][index])<=total_budget*(1+GATE))
            require(total['diagnostics']==total_diagnostics and total['cell_numerical_passes']==prior['cell_numerical_passes']+[passed]
                    and total['numerical_pass']==total_pass,'all per-cell cumulative flags preserved')
            require(total['physical_contribution_fraction']==float(combined['fine_signed'][index]/combined['reference_scale'][index]),'physical cumulative normalization')
            previous=next(item for item in old_result['records'] if item['model']==model and item['branch']==row['branch'] and item['channel']==row['channel'])
            latest=abs(projected['fine_signed'][index]-projected['coarse_signed'][index])
            earlier_change=abs(projected['coarse_signed'][index]-projected['coarser_signed'][index])
            trends.append(dict(branch=row['branch'],channel=row['channel'],previous_pass=previous['numerical_pass'],new_pass=passed,
                signed_change_ratio=float(latest/earlier_change) if earlier_change else None,
                quadrature=float(diagnostics['quadrature']),budget_change=float(diagnostics['budget']),
                physical_signed_change=float(latest/projected['reference_scale'][index])))
            counts['projected_channels']+=1;counts['accumulated_channels']+=1
        diagnostic=next(item for item in diagnosis['reports'] if item['model']==model)
        hashes({diagnostic['path']:diagnostic['sha256']})
        panels=load(diagnostic['path'])
        require(np.array_equal(panels['coordinate_edges'],coordinate[::4]),'diagnostic panel ownership')
        signed_error=float(np.max(abs(panels['signed_difference'].sum(axis=0)-(projected['fine_signed']-projected['coarse_signed']))/np.maximum(projected['fine_cauchy'],1e-80)))
        moment_error=float(np.max(abs(float(projected['fine_volume'])*panels['second_moment_difference'].sum(axis=0)
            -(projected['fine_cauchy']**2-projected['coarse_cauchy']**2))/np.maximum(projected['fine_cauchy'],1e-80)**2))
        require(signed_error<ALGEBRA and moment_error<ALGEBRA,'saved panel localization reconciled')
        summary.append(dict(model=model,passed=sum(row['numerical_pass'] for row in rows),
            previous_passed=sum(row['numerical_pass'] for row in old_result['records'] if row['model']==model),trends=trends,
            largest_physical_contribution=max(abs(row['physical_contribution_fraction']) for row in rows),
            largest_physical_budget=max(row['physical_budget_fraction'] for row in rows),
            diagnostic_maxima={name:max(row['diagnostics'][name] for row in rows) for name in rows[0]['diagnostics']},
            accumulated=accumulated,clock=certificate,volume_error=volume_error,
            panel_signed_identity=signed_error,panel_moment_identity=moment_error))
    reused=sum(row['parent_points'] for row in grid_report['reports'])
    new=sum(row['new_points'] for row in grid_report['reports'])
    require(counts==dict(reused_histories=4,reused_points=reused,new_points=new,phase_controls=reused+new,projected_channels=40,accumulated_channels=40),'complete paired one-level refinement')
    require(source['reused_source_points']==reused and source['new_source_points']==new,'correct source inventory')
    for path in STAGE.glob('*.start.json'):
        start=read(path)
        hashes({start['source_path']:start['source_sha256']})
        phase=path.name.removesuffix('.start.json')
        if phase=='audit-01':
            require(start['pid']==os.getpid(),'current auditor identity')
            continue
        end=read(STAGE/(phase+'.end.json'))
        require(all(start[key]==end[key] for key in ('pid','created','command')) and end['exit_code']==0,'successful owned worker')
        if psutil.pid_exists(start['pid']):
            created=datetime.fromisoformat(start['created'].replace('Z','+00:00')).timestamp()
            require(abs(psutil.Process(start['pid']).create_time()-created)>1,'owned worker exited')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,maxima=maxima,summary=summary,original_bank_grids_tolerances_unchanged=True,no_history_solve=True,
        all_numerical_controls_pass=all(row['passed']==20 and row['accumulated']['passed']==20 for row in summary),
        original_cell_indices=[8,12],accumulated_cells=[[0,4],[4,8],[8,12]],github_actions=False,
        next_decision=diagnosis['decision']))
    print(json.dumps(dict(counts=counts,maxima=maxima,summary=summary,next_decision=diagnosis['decision']),indent=2),flush=True)


if __name__=='__main__':
    main()
