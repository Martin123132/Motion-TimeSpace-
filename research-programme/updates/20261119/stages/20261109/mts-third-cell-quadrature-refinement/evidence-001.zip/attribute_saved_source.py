from common import *
sys.path.insert(1,str(CONDITION_STAGE))
from condition_source import weights,two_diff,compensated,rational_dot,coordinate_names,relative
from response_support import adjoints,NAMES,BRANCHES
from correlated_source import full_endpoint
from scipy.sparse import block_diag,csc_matrix,diags,eye
from scipy.sparse.linalg import splu
from fractions import Fraction
import math
import numpy as np


def main():
    modest()
    output=ROOT/'source-attribution-01'
    output.mkdir(exist_ok=False)
    target_names=['Pi','delta_massless']
    columns=[NAMES.index(name) for name in target_names]
    source_path=ROOT/'points-01/refined-cell03-result.json'
    projection_path=ROOT/'projection-refined-cell03/result.json'
    source,projection_report=read(source_path),read(projection_path)
    require(source['passed'] and projection_report['completed'],'completed source evidence')
    consumed={str(path):digest(path) for path in (source_path,projection_path,CONDITION_STAGE/'condition_source.py')}
    write(output/'freeze.json',dict(sources=sources(),targets=target_names,branches=BRANCHES,models=['heavy','cold'],
        no_new_native_calls=True,no_history_solve=True,posthoc_diagnostic_not_prediction=True,unchanged_gates=[ALGEBRA,GATE]))
    reports=[];records=[]
    unit=np.finfo(float).eps/2
    for model in ('heavy','cold'):
        result=next(row for row in projection_report['reports'] if row['model']==model)
        require(digest(result['path'])==result['sha256'],'accepted source projection bytes')
        consumed[result['path']]=result['sha256']
        projection=load(result['path'])
        case=next(row for row in source['reports'] if row['model']==model)
        curves,row_norm=adjoints(model,consumed)
        layout_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-00-source.json')
        consumed[str(layout_path)]=digest(layout_path)
        layout=read(layout_path)['layout']
        coordinate=projection['coordinate'];jacobian=projection['jacobian']
        physical_weights=weights(coordinate)*jacobian
        coarse_weights=np.zeros_like(physical_weights)
        coarse_weights[::2]=weights(coordinate[::2])*jacobian[::2]
        refinement_weights=physical_weights-coarse_weights
        exact_indices=set([0,(len(coordinate)-1)//4,(len(coordinate)-1)//2,3*(len(coordinate)-1)//4,len(coordinate)-1])
        stable_values=[];inputs=[];dot_magnitudes=[];subtraction_magnitudes=[]
        errors=[];exact_checks=[]
        low_count=0;underflow_count=0
        refinement_terms=source_terms=input_terms=None
        for node in case['nodes']:
            guard()
            index=node['index']
            require(digest(node['path'])==node['sha256'],'saved native packet')
            consumed[node['path']]=node['sha256']
            packet=load(node['path'])
            require(float(packet['jacobian'])==jacobian[index],'same physical quadrature measure')
            dimension=packet['current'].shape[1]
            compact=packet['forward'].shape[-1]
            physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
            physical_lu=splu(physical)
            require(physical.shape==(dimension,dimension),'native/physical compact layouts remain distinct')
            adjoint=(curves['fine'](float(packet['efold']))*row_norm[:,:,None])[columns]
            if refinement_terms is None:
                refinement_terms=np.zeros((2,len(columns),dimension))
                source_terms=np.zeros_like(refinement_terms);input_terms=np.zeros_like(refinement_terms)
            node_stable=[];node_inputs=[];node_dot=[];node_subtraction=[]
            for branch in range(2):
                forward=block_diag((csc_matrix(packet['forward'][branch]),eye(dimension-compact)),format='csc')
                inverse=block_diag((csc_matrix(packet['inverse'][branch]),eye(dimension-compact)),format='csc')
                endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],float(packet['remote_endpoint']),dimension)
                covectors=physical.T@(inverse.T@splu(endpoint).solve(adjoint[:,branch,:].T,trans='T'))
                recovered=endpoint.T@(forward.T@physical_lu.solve(covectors,trans='T'))
                dual_error=max(relative(recovered[:,column],adjoint[column,branch]) for column in range(len(columns)))
                require(dual_error<ALGEBRA,'dual physical moving-map identity')
                reference=packet['reference_rates'][branch,:,0]
                retained=packet['retained_rates'][branch,:,0]
                high,low=two_diff(reference,retained)
                require(np.array_equal(high,packet['difference'][branch,:,0]),'unchanged native difference')
                low_count+=int(np.count_nonzero(low))
                values=[]
                for column,name in enumerate(target_names):
                    value,underflows=compensated(covectors[:,column],high,low)
                    values.append(value);underflow_count+=underflows
                    if index in exact_indices:
                        exact=rational_dot(covectors[:,column],reference,retained)
                        error=abs(Fraction(value)-exact)
                        allowance=Fraction(math.ulp(float(exact)))+Fraction(4*dimension)*Fraction(float(np.nextafter(0.,1.)))
                        require(error<=allowance,'exact rational contraction spot check')
                        exact_checks.append(dict(index=index,branch=BRANCHES[branch],channel=name,passed=True,error=float(error),allowance=float(allowance)))
                magnitude=abs(covectors).T@(abs(reference)+abs(retained))
                dot_magnitude=abs(covectors).T@abs(high)
                old=packet['projected'][0,branch,0,columns]
                backward=float(np.max(abs(covectors.T@high-old)/np.maximum(dot_magnitude,1e-80)))
                require(backward<ALGEBRA,'native and retained observable contraction agree')
                errors.append((dual_error,backward))
                terms=covectors.T*high[None,:]
                refinement_terms[branch]+=refinement_weights[index]*terms
                source_terms[branch]+=physical_weights[index]*terms
                input_terms[branch]+=physical_weights[index]*(abs(covectors).T*(abs(reference)+abs(retained))[None,:])
                node_stable.append(values);node_inputs.append(magnitude);node_dot.append(dot_magnitude)
                node_subtraction.append(abs(covectors).T@abs(low))
            stable_values.append(node_stable);inputs.append(node_inputs);dot_magnitudes.append(node_dot);subtraction_magnitudes.append(node_subtraction)
            if index%128==0:
                print(model,index,'saved native-coordinate attribution verified',flush=True)
        stable_values=np.array(stable_values);inputs=np.array(inputs)
        dot_magnitudes=np.array(dot_magnitudes);subtraction_magnitudes=np.array(subtraction_magnitudes)
        original=projection['projected'][:,0,:,0][:,:,columns]
        budget=np.maximum(projection['fine_cauchy'][:,columns],1e-80)
        scale=projection['reference_scale'][:,columns]
        integrate=lambda values:np.einsum('n,nbc->bc',physical_weights,values)
        refined_delta=np.einsum('n,nbc->bc',refinement_weights,stable_values)
        expected_delta=(projection['fine_signed']-projection['coarse_signed'])[:,columns]
        attribution_error=float(np.max(abs(refinement_terms.sum(axis=-1)-expected_delta)/budget))
        require(attribution_error<ALGEBRA,'native-coordinate differences reproduce the unresolved integral change')
        arithmetic_change=integrate(stable_values-original)
        input_benchmark=unit*integrate(inputs)/budget
        gamma=(2*dimension+1)*unit/(1-(2*dimension+1)*unit)
        post_estimate=(gamma*integrate(dot_magnitudes)+integrate(subtraction_magnitudes))/budget
        labels=coordinate_names(layout,dimension)
        local=[]
        for branch,branch_name in enumerate(BRANCHES):
            for column,name in enumerate(target_names):
                index=(branch,column)
                order=np.argsort(abs(refinement_terms[index]))[::-1]
                top=order[:12]
                local.append(dict(model=model,branch=branch_name,channel=name,
                    compensated_integral_change=float(arithmetic_change[index]/budget[index]),
                    compensated_physical_change=float(arithmetic_change[index]/scale[index]),
                    original_refinement=float(expected_delta[index]/budget[index]),
                    compensated_refinement=float(refined_delta[index]/budget[index]),
                    unit_roundoff_native_input_sensitivity=float(input_benchmark[index]),
                    post_subtraction_dot_estimate=float(post_estimate[index]),
                    native_rate_error_bounded=False,computed_covector_held_fixed=True,
                    top_refinement_coordinates=[dict(index=int(value),label=labels[value],
                        signed_refinement_fraction=float(refinement_terms[branch,column,value]/budget[index]),
                        unit_roundoff_input_sensitivity=float(unit*input_terms[branch,column,value]/budget[index])) for value in top]))
        records.extend(local)
        target=output/f'{model}-attribution.npz'
        np.savez_compressed(target,columns=columns,coordinate=coordinate,jacobian=jacobian,weights=physical_weights,
            refinement_weights=refinement_weights,original=original,compensated=stable_values,
            refinement_terms=refinement_terms,source_terms=source_terms,input_terms=input_terms,
            input_magnitude=inputs,dot_magnitude=dot_magnitudes,subtraction_magnitude=subtraction_magnitudes,
            budget=budget,reference_scale=scale,arithmetic_change=arithmetic_change,input_benchmark=input_benchmark,
            post_subtraction_estimate=post_estimate,algebra_errors=errors)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),points=len(coordinate),dimension=dimension,
            low_components=low_count,product_underflow_count=underflow_count,exact_checks=exact_checks,
            algebra_max=np.max(errors,axis=0).tolist(),attribution_error=attribution_error))
    require(all(digest(path)==seal for path,seal in consumed.items()),'immutable saved inputs')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,records=records,
        no_new_native_calls=True,no_history_solve=True,posthoc_diagnostic_not_prediction=True,
        native_rate_error_bounded=False,no_accepted_source_replacement=True,original_bank_grids_tolerances_unchanged=True))
    print('paired saved-source cancellation and native-coordinate attribution complete',flush=True)


if __name__=='__main__':
    main()
