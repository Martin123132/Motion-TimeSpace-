from common import *
from fractions import Fraction
import math
import numpy as np
from scipy.sparse import block_diag,csc_matrix,diags
from scipy.sparse.linalg import splu
from response_support import adjoints,NAMES,BRANCHES
from correlated_source import full_endpoint
from monopole_math import direct_source


def integrate(weight,values):
    shape=values.shape[1:]
    flattened=values.reshape(len(weight),-1)
    return np.array([math.fsum(float(amount)*float(value) for amount,value in zip(weight,flattened[:,column]))
        for column in range(flattened.shape[1])]).reshape(shape)


def main():
    modest()
    output=ROOT/'metric-projection-01'
    output.mkdir(exist_ok=False)
    full_path=ROOT/'stress-full-01/result.json'
    full=read(full_path)
    require(full['passed'] and full['no_source_replacement'],'completed diagnostic stress capture')
    frozen=read(ROOT/'full-freeze.json')
    consumed={str(full_path):digest(full_path),str(ROOT/'full-freeze.json'):digest(ROOT/'full-freeze.json')}
    index={(entry['model'],entry['index']):entry for entry in full['reports']}
    require(len(index)==2042,'full saved grid without duplicates')
    reports=[];records=[]
    for selection in frozen['selections']:
        model=selection['model']
        old_path=REFINEMENT/LABEL/'source-attribution-01'/f'{model}-attribution.npz'
        consumed[str(old_path)]=digest(old_path);old=load(old_path)
        prior_report=read(REFINEMENT/LABEL/'source-attribution-01/result.json')
        require(consumed[str(old_path)]==next(row['sha256'] for row in prior_report['reports'] if row['model']==model),'sealed attribution projection')
        curves,row_norm=adjoints(model,consumed)
        columns=old['columns'].astype(int)
        weights=old['weights'];refinement_weights=old['refinement_weights']
        coarse_weights=weights-refinement_weights
        corrections=[];components=[];direct_differences=[];errors=[]
        for node in selection['nodes']:
            guard()
            require(digest(node['path'])==node['sha256'],'original source packet')
            consumed[node['path']]=node['sha256']
            packet=load(node['path'])
            entry=index[(model,node['index'])]
            require(digest(entry['path'])==entry['sha256'],'direct stress receipt')
            consumed[entry['path']]=entry['sha256']
            report=read(entry['path'])
            require(digest(report['path'])==report['sha256'] and report['bitwise_replay'],'captured stress bytes')
            consumed[report['path']]=report['sha256']
            raw_capture=load(report['path'])
            mono,dipole,quad=raw_capture['massless_slots'].astype(int)
            require(np.array_equal(raw_capture['native_vectors'],packet['native_vectors']),'same physical perturbations')
            units=packet['units'];dimension=len(units);compact=packet['inverse'].shape[-1]
            physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
            adjoint=(curves['fine'](float(packet['efold']))*row_norm[:,:,None])[columns]
            first_time,first_hubble=map(float,packet['reference_background'][11:13])
            second_time,second_hubble=map(float,packet['retained_background'][11:13])
            reciprocal=1/(Fraction(first_time)*Fraction(first_hubble))-1/(Fraction(second_time)*Fraction(second_hubble))
            node_corrections=[];node_parts=[];node_differences=[];node_errors=[]
            for branch,name in enumerate(BRANCHES):
                source_record=report['records'][branch]
                require(source_record['branch']==name,'unchanged branch')
                derived=direct_source(source_record['primitives']['reference'],source_record['primitives']['retained'],
                    name,source_record['wave'],source_record['monopole_unit'])
                require(derived['rate'].values()==source_record['calculated']['rate'],'exact finite-increment reproducibility')
                inverse=block_diag((csc_matrix(packet['inverse'][branch]),diags(np.ones(dimension-compact))),format='csc')
                endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],
                    float(packet['remote_endpoint']),dimension)
                covectors=physical.T@(inverse.T@splu(endpoint).solve(adjoint[:,branch,:].T,trans='T'))
                difference=packet['difference'][branch,:,0]
                coefficient=covectors[mono]-covectors[quad]*units[mono]/units[quad]
                old_pair=covectors[mono]*difference[mono]+covectors[quad]*difference[quad]
                moment=float(units[quad]*packet['native_vectors'][branch,quad,0])
                damping=-3*covectors[quad]*float(Fraction(moment)/Fraction(float(units[quad]))*reciprocal)
                transferred=coefficient[:,None]*np.array(list(map(float,derived['increment_parts'])))[None,:]
                parts=np.column_stack((old['original'][node['index'],branch]-old_pair,transferred,damping))
                pair_new=np.array([math.fsum([*transferred[column],float(damping[column])]) for column in range(2)])
                pair_change=pair_new-old_pair
                candidate=old['original'][node['index'],branch]+pair_change
                error=float(np.max(abs(parts.sum(axis=-1)-candidate)/old['budget'][branch]))
                require(error<ALGEBRA,'complete source-term decomposition')
                node_corrections.append(pair_change);node_parts.append(parts)
                node_differences.append([float(derived['rate'].delta),float(difference[mono])])
                node_errors.append(error)
            corrections.append(node_corrections);components.append(node_parts)
            direct_differences.append(node_differences);errors.append(node_errors)
            if node['index']%256==0:
                print(model,node['index'],'derived source projection',flush=True)
        corrections=np.array(corrections);components=np.array(components)
        correction_fine=integrate(weights,corrections)
        correction_coarse=integrate(coarse_weights,corrections)
        original_fine=integrate(weights,old['original'])
        original_coarse=integrate(coarse_weights,old['original'])
        original_refinement=integrate(refinement_weights,old['original'])
        candidate_refinement=original_refinement+integrate(refinement_weights,corrections)
        split_refinement=integrate(refinement_weights,components)
        split_fine=integrate(weights,components)
        budget=old['budget'];scale=old['reference_scale']
        closure=float(np.max(abs(split_refinement.sum(axis=-1)-candidate_refinement)/budget))
        require(closure<ALGEBRA,'integrated source-term decomposition')
        for branch,name in enumerate(BRANCHES):
            for column,channel in enumerate(('Pi','delta_massless')):
                selected=(branch,column)
                records.append(dict(model=model,branch=name,channel=channel,
                    original_refinement=float(original_refinement[selected]/budget[selected]),
                    candidate_refinement_same_original_budget=float(candidate_refinement[selected]/budget[selected]),
                    fine_change_over_original_budget=float(correction_fine[selected]/budget[selected]),
                    fine_change_over_reference_scale=float(correction_fine[selected]/scale[selected]),
                    component_refinement_same_budget=(split_refinement[selected]/budget[selected]).tolist(),
                    part_names=['other_coordinates',*derived['part_names'],'clock_damping'],
                    original_budget_reused_for_diagnostic=True,
                    no_candidate_full_control_pass_claimed=True))
        target=output/f'{model}-metric-projection.npz'
        np.savez_compressed(target,coordinate=old['coordinate'],weights=weights,refinement_weights=refinement_weights,
            corrections=corrections,components=components,direct_differences=direct_differences,
            correction_fine=correction_fine,correction_coarse=correction_coarse,
            original_fine=original_fine,original_coarse=original_coarse,
            original_refinement=original_refinement,candidate_refinement=candidate_refinement,
            split_refinement=split_refinement,split_fine=split_fine,budget=budget,reference_scale=scale,
            decomposition_errors=errors)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),points=len(corrections),
            decomposition_max=float(np.max(errors)),integrated_closure=closure))
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'saved calculation preserved')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,records=records,
        no_new_native_calls=True,no_new_history_solve=True,no_source_replacement=True,
        projection_scope='candidate change to massless monopole/quadrupole pair only; original remaining source and original budget',
        no_candidate_full_control_pass_claimed=True,original_bank_grids_tolerances_unchanged=True))
    print('paired full-grid direct metric-source diagnostic projected',flush=True)


if __name__=='__main__':
    main()

