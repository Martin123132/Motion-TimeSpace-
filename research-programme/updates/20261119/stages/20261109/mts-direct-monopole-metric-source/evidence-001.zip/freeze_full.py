from common import *


def main():
    modest()
    audit_path=STAGE/'probe-audit/result.json'
    audit=read(audit_path)
    require(audit['passed'] and audit['branch_cases']==36,'independent frozen probe accepted')
    for path,checksum in audit['consumed'].items():
        require(digest(path)==checksum,'audited inputs preserved')
    index_path=REFINEMENT/LABEL/'points-01/refined-cell03-result.json'
    inputs={str(audit_path):digest(audit_path),str(index_path):digest(index_path),
            str(REFINEMENT/'closeout.json'):digest(REFINEMENT/'closeout.json'),
            str(ROOT/'stress-probe-01/result.json'):digest(ROOT/'stress-probe-01/result.json')}
    require(inputs[str(REFINEMENT/'closeout.json')]=='4db4e7ef2f4b2a1b21969541c632f701eff2fc9427dc8bf2d14c6882356fdc85','parent seal')
    records=read(index_path)
    selected=[]
    for model in ('heavy','cold'):
        case=next(row for row in records['reports'] if row['model']==model)
        nodes=[{key:node[key] for key in ('index','path','sha256')} for node in case['nodes']]
        require([node['index'] for node in nodes]==list(range(len(nodes))),'complete original source grid')
        selected.append(dict(model=model,nodes=nodes))
    write(ROOT/'full-freeze.json',dict(passed=True,inputs=inputs,sources=sources(),selections=selected,
        reuse_probe_nodes=18,new_native_points=2024,total_saved_points=2042,
        decision='frozen probe passes; measure full-grid quadrature impact rather than extrapolate sample changes',
        no_new_nodes=True,no_saved_history_reintegration=True,no_source_replacement=True,
        unchanged_gates=[ALGEBRA,GATE],candidate_projection_does_not_requalify_full_source_budget=True))
    print('full saved-grid comparison frozen;18 probes reused,2024 additional stress captures',flush=True)


if __name__=='__main__':
    main()

