from common import *
from decimal import Decimal,localcontext
import numpy as np


def main():
    modest()
    output=STAGE/'balance-audit'
    output.mkdir(exist_ok=False)
    path=ROOT/'stress-balance-01/result.json'
    report=read(path)
    require(report['passed'] and report['scalar_flow_defects_measured_not_set_to_zero'],'completed explicit balance')
    consumed={str(path):digest(path)}
    for name in ('sources','consumed'):
        for source,checksum in report[name].items():
            require(digest(source)==checksum,'balance input/source unchanged')
            consumed[source]=checksum
    captures=read(ROOT/'stress-full-01/result.json')
    capture_index={(row['model'],row['index']):row for row in captures['reports']}
    reports=[];count=0
    with localcontext() as context:
        context.prec=90
        convert=lambda value:Decimal.from_float(float(value))
        for result in report['reports']:
            model=result['model']
            require(digest(result['path'])==result['sha256'] and digest(result['primitives'])==result['primitives_sha256'],'balance outputs unchanged')
            consumed[result['path']]=result['sha256'];consumed[result['primitives']]=result['primitives_sha256']
            packet=load(result['path']);primitives=read(result['primitives'])
            identity_error=0.;native_scalar_error=0.;flow_compare_error=0.
            background_max=np.zeros((2,2,2))
            background_scales=np.zeros((2,2,2))
            maximum_flow_term=0.
            for diagnostic in primitives:
                entry=capture_index[(model,diagnostic['index'])]
                require(digest(entry['path'])==entry['sha256'],'original stress receipt')
                capture=read(entry['path'])
                require(digest(capture['path'])==capture['sha256'],'original raw stress packet')
                consumed[capture['path']]=capture['sha256']
                branch=('gr','poisson-spatial').index(diagnostic['branch'])
                record=capture['records'][branch]
                wave=convert(record['wave'])
                for side_index,side in enumerate(('reference','retained')):
                    original=record['primitives'][side]
                    hubble=convert(original['H'])
                    metadata=list(map(convert,original['metadata']))
                    observed=list(map(convert,original['observed']))
                    terms=[list(map(convert,row)) for row in original['terms']]
                    scale=metadata[0]
                    native_z=observed[5]-3*observed[3]/(2*wave**2)
                    for field_index,start in enumerate((4,14)):
                        field,velocity,field_rate,velocity_rate,mass,perturbation,perturbation_rate=metadata[start:start+7]
                        frequency_sq=(scale*mass)**2
                        perturbation_acceleration=-2*hubble*perturbation_rate-(wave**2+frequency_sq)*perturbation-wave*native_z*velocity
                        density=velocity*perturbation_rate+frequency_sq*field*perturbation
                        pressure=velocity*perturbation_rate-frequency_sq*field*perturbation
                        current=wave*velocity*perturbation
                        density_rate=velocity_rate*perturbation_rate+velocity*perturbation_acceleration+frequency_sq*((2*hubble*field+field_rate)*perturbation+field*perturbation_rate)
                        current_rate=wave*(velocity_rate*perturbation+velocity*perturbation_rate)
                        field_defect=field_rate-velocity
                        acceleration_defect=velocity_rate+2*hubble*velocity+frequency_sq*field
                        energy_defect=acceleration_defect*perturbation_rate+frequency_sq*field_defect*perturbation
                        momentum_defect=wave*acceleration_defect*perturbation
                        energy_left=density_rate+hubble*(density+3*pressure)+wave*current+wave*native_z*velocity**2
                        momentum_left=current_rate+2*hubble*current-wave*pressure
                        energy_scale=max(abs(density_rate)+abs(hubble*(density+3*pressure))+abs(wave*current)+abs(wave*native_z*velocity**2),Decimal('1e-80'))
                        momentum_scale=max(abs(current_rate)+abs(2*hubble*current)+abs(wave*pressure),Decimal('1e-80'))
                        identity=max(float(abs(energy_left-energy_defect)/energy_scale),float(abs(momentum_left-momentum_defect)/momentum_scale))
                        native=max(float(abs(density_rate-terms[5+field_index][3])/energy_scale),
                                   float(abs(current_rate-terms[5+field_index][4])/momentum_scale))
                        name='slow' if field_index==0 else 'heavy'
                        compared=max(float(abs(energy_defect-convert(diagnostic['density_'+name+'_defect'][side_index]))/energy_scale),
                                     float(abs(momentum_defect-convert(diagnostic['current_'+name+'_defect'][side_index]))/momentum_scale))
                        require(max(identity,native,compared)<ALGEBRA,'independent scalar stress-divergence identity and native rate')
                        identity_error=max(identity_error,identity)
                        native_scalar_error=max(native_scalar_error,native)
                        flow_compare_error=max(flow_compare_error,compared)
                        scales=[max(abs(field_rate)+abs(velocity),Decimal('1e-80')),
                                max(abs(velocity_rate)+abs(2*hubble*velocity)+abs(frequency_sq*field),Decimal('1e-80'))]
                        for derivative,defect in enumerate((field_defect,acceleration_defect)):
                            background_max[field_index,side_index,derivative]=max(background_max[field_index,side_index,derivative],float(abs(defect)))
                            background_scales[field_index,side_index,derivative]=max(background_scales[field_index,side_index,derivative],float(abs(defect)/scales[derivative]))
                        count+=1
            weighted=np.einsum('n,nbcp->bcp',packet['refinement_weights'],packet['components'])
            fine=np.einsum('n,nbcp->bcp',packet['weights'],packet['components'])
            weight_error=max(float(np.max(abs(weighted-packet['refinement'])/packet['budget'][:,:,None])),
                float(np.max(abs(fine-packet['fine'])/packet['budget'][:,:,None])))
            require(weight_error<ALGEBRA,'independent component accumulation')
            reports.append(dict(model=model,passed=True,independent_scalar_cases=len(primitives)*4,
                identity_max=identity_error,native_scalar_rate_max=native_scalar_error,
                flow_report_max=flow_compare_error,component_integral_max=weight_error,
                background_defect_max=background_max.tolist(),
                normalized_background_defect_max=background_scales.tolist(),
                axes=['field:slow/heavy','background:reference/retained','defect:field_rate/acceleration']))
    require(count==16336,'all source nodes, branches, backgrounds and two scalar slots audited')
    require(all(digest(source)==checksum for source,checksum in consumed.items()),'source evidence preserved')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,
        independent_scalar_cases=count,no_new_native_calls=True,no_source_replacement=True,
        ward_identity_scope='retained linear scalar stress with explicit background-flow residuals; native approximation residuals retained separately'))
    print(json.dumps(dict(passed=True,scalar_cases=count,reports=reports)),flush=True)


if __name__=='__main__':
    main()

