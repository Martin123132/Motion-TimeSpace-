from fractions import Fraction


def rational(value):
    return value if isinstance(value,Fraction) else Fraction(value if isinstance(value,int) else float(value))


class Pair:
    def __init__(self,reference,retained,delta=None):
        self.reference=rational(reference)
        self.retained=rational(retained)
        self.delta=self.reference-self.retained if delta is None else delta
        if self.delta!=self.reference-self.retained:
            raise ArithmeticError('finite increment identity failed')

    @property
    def mean(self):
        return (self.reference+self.retained)/2

    @staticmethod
    def cast(value):
        return value if isinstance(value,Pair) else Pair(value,value)

    def __add__(self,other):
        other=self.cast(other)
        return Pair(self.reference+other.reference,self.retained+other.retained,self.delta+other.delta)

    __radd__=__add__

    def __neg__(self):
        return Pair(-self.reference,-self.retained,-self.delta)

    def __sub__(self,other):
        return self+-self.cast(other)

    def __rsub__(self,other):
        return self.cast(other)+-self

    def __mul__(self,other):
        other=self.cast(other)
        return Pair(self.reference*other.reference,self.retained*other.retained,
                    self.mean*other.delta+other.mean*self.delta)

    __rmul__=__mul__

    def __truediv__(self,other):
        other=self.cast(other)
        return Pair(self.reference/other.reference,self.retained/other.retained,
                    (other.mean*self.delta-self.mean*other.delta)/(other.reference*other.retained))

    def __rtruediv__(self,other):
        return self.cast(other)/self

    def values(self):
        return [float(self.reference),float(self.retained),float(self.delta)]


def direct_source(reference,retained,branch,wave,monopole_unit):
    get=lambda name:Pair(reference[name],retained[name])
    observed=[Pair(first,second) for first,second in zip(reference['observed'],retained['observed'])]
    terms=[[Pair(first,second) for first,second in zip(first_row,second_row)]
           for first_row,second_row in zip(reference['terms'],retained['terms'])]
    metadata=[Pair(first,second) for first,second in zip(reference['metadata'],retained['metadata'])]
    hubble=get('H');alpha=get('alpha');dipole=get('dipole')
    if alpha.delta or dipole.delta:
        raise ValueError('fixed native perturbation state required')
    wave=rational(wave);unit=rational(monopole_unit)
    density,current,anisotropy=observed[2:5]
    enthalpy=observed[0]+observed[1]
    quadrature_enthalpy=sum(row[5] for row in terms)-terms[4][5]+metadata[3]
    native_z=observed[5]-Fraction(3,2)*current/(wave*wave)
    density_base=sum(row[3] for row in terms)+wave*quadrature_enthalpy*native_z
    current_rate=sum(row[4] for row in terms)
    hubble_rate=hubble*get('H_N')
    gravity_rate=hubble*get('gravity_N')
    gravity=3*hubble*enthalpy/(2*wave*wave)
    if branch=='gr':
        phi=-density/(2*wave*wave)-3*hubble*current/(2*wave*wave*wave)
        psi=phi-anisotropy/(wave*wave)
        alpha_rate=psi-hubble*alpha
        phi_base=-density_base/(2*wave*wave)-3*(hubble_rate*current+hubble*current_rate)/(2*wave*wave*wave)
    elif branch=='poisson-spatial':
        psi=-density/(2*wave*wave)+gravity*alpha
        phi=psi
        alpha_rate=psi-hubble*alpha
        phi_base=-density_base/(2*wave*wave)+gravity_rate*alpha+gravity*alpha_rate
    else:
        raise ValueError('unsupported branch')
    denominator=1+3*quadrature_enthalpy/(2*wave*wave)
    if min(denominator.reference,denominator.retained)<=0:
        raise ValueError('positive metric denominator required')
    numerator_parts=[wave*alpha,-3*phi_base/wave,-3*hubble_rate*alpha/wave,-3*hubble*alpha_rate/wave]
    numerator=sum(numerator_parts)
    expansion=numerator/denominator
    rate=-wave*(dipole+Fraction(4,3)*expansion)/hubble/unit
    inverse_hubble=1/hubble
    divisor=denominator*hubble
    product=divisor.reference*divisor.retained
    split=[-wave*dipole.reference*inverse_hubble.delta/unit]
    split.extend(-4*wave/(3*unit)*divisor.mean*part.delta/product for part in numerator_parts)
    split.append(4*wave/(3*unit)*numerator.mean*divisor.delta/product)
    if sum(split)!=rate.delta:
        raise ArithmeticError('direct monopole finite-increment split failed')
    return dict(rate=rate,expansion=expansion,denominator=denominator,numerator=numerator,
                phi=phi,psi=psi,alpha_rate=alpha_rate,density_base=density_base,
                quadrature_enthalpy=quadrature_enthalpy,hubble_rate=hubble_rate,
                increment_parts=split,
                part_names=['dipole_inverse_H','fixed_alpha','phi_rate_base','H_rate_alpha',
                            'H_alpha_rate','metric_denominator_H'])

