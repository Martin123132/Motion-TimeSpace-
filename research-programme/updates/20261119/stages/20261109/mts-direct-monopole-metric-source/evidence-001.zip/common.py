import hashlib
import json
import os
import sys
from pathlib import Path
from datetime import datetime, timezone

for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS','BLIS_NUM_THREADS'):
    os.environ[variable]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
STAGE=Path(__file__).resolve().parent
POST=STAGE.parent
REFINEMENT=POST/'mts-third-cell-quadrature-refinement-20261109'
THIRD_CELL=POST/'mts-background-response-third-cell-20261109'
SECOND_CELL=POST/'mts-background-response-second-cell-20261109'
FIRST_CELL=POST/'mts-phase-quadrature-refinement-20261109'
CONDITION_STAGE=POST/'mts-observable-background-source-conditioning-20261109'
PHASE_RESPONSE=POST/'mts-phase-resolved-background-response-20261109'
sys.path.insert(1,str(PHASE_RESPONSE))
TIME_STAGE=POST/'mts-native-background-time-derivative-20261109'
sys.path.insert(1,str(TIME_STAGE))
FRAME_STAGE=POST/'mts-common-frame-background-forcing-20261109'
sys.path.insert(1,str(FRAME_STAGE))
RESPONSE_STAGE=POST/'mts-accumulated-correction-feedback-20261109'
FEEDBACK_STAGE=POST/'mts-correction-feedback-source-20261109'
ACCUM_STAGE=POST/'mts-accumulated-clock-residual-20261108'
CLOCK_STAGE=POST/'mts-clock-weighted-forcing-primitive-20261108'
sys.path.insert(1,str(CLOCK_STAGE))
sys.path.insert(1,str(ACCUM_STAGE))
sys.path.insert(1,str(RESPONSE_STAGE))
sys.path.insert(1,str(FEEDBACK_STAGE))
LABEL=sys.argv[1] if len(sys.argv)==2 else 'summary'
if LABEL not in ('half','balanced','double','summary'):
    raise ValueError('owned family required')
ROOT=STAGE/LABEL
COMPLETED=POST/'mts-original-mode-reference-completion-20261108'
CONTINUATION=POST/'mts-original-mode-next-reference-packet-20261108'
REAL_SERIES=POST/'mts-original-mode-real-series-extension-20261108'
CONTIGUOUS=POST/'mts-contiguous-mode-extension-20261108'
REMAINDER=POST/'mts-derived-correlated-transport-remainder-20261108'
CORRELATED=POST/'mts-invariant-correlated-early-transport-20261108'
TRANSPORT=POST/'mts-early-matched-mean-transport-20261108'
MATCHING=POST/'mts-cold-original-mode-matching-20261108'
TUBE=POST/'mts-cold-coupled-background-envelope-20261108'
EXACT=POST/'mts-cold-exact-coupled-jets-20261108'
FREE=POST/'mts-cold-clock-thermal-generator-20261108'
FULL=POST/'mts-cold-full-metric-envelope-20261108'
METRIC=POST/'mts-cold-metric-tube-20261108'
ANALYTIC=POST/'mts-cold-analytic-phase-20261108'
ENERGY=POST/'mts-cold-energy-remainder-20261108'
COLD=POST/'mts-cold-coupled-coefficients-20261107'
PHASE=POST/'mts-correlated-relative-phase-mean-20261107'
ADAPTER=POST/'mts-background-operator-bridge-20261107'
JOINT=POST/'mts-joint-relative-metric-20261107'
RELATIVE=POST/'mts-relative-phase-perturbations-20261107'
COLD_BACKGROUND=POST/'mts-cold-background-extension-20261107'
CHANNELS=POST/'mts-metric-channel-factorization-20261107'
GAIN=POST/'mts-cold-adapted-metric-gain-20261107'
ENVELOPE=POST/'mts-coupled-energy-envelope-20261107'
ORIGINAL_WAVES=POST/'mts-newton-wavelength-bounds-20261107'
ORIGINAL_POISSON=POST/'mts-independent-poisson-evolution-20261107'
ORIGINAL_ADJOINT=POST/'mts-newton-feedback-adjoint-20261107'
ORIGINAL_PRIMITIVE=POST/'mts-metric-time-primitive-20261107'
POISSON=ORIGINAL_POISSON if LABEL=='balanced' else ORIGINAL_WAVES/LABEL
ADJOINT=ORIGINAL_ADJOINT if LABEL=='balanced' else ORIGINAL_WAVES/LABEL
PRIMITIVE=ORIGINAL_PRIMITIVE if LABEL=='balanced' else ORIGINAL_WAVES/LABEL/'primitive'
SEALED=POST/'mts-native-rest-action-feedback-20261107'
PARENT=POST/'mts-joint-gravity-hamiltonian-20261107'
PREVIOUS=POST/'mts-correlated-action-mean-20261107'
TIMECHAIN=POST/'mts-canonical-full-time-chain-20261107'
BACKGROUND=POST/'mts-background-repair-20261107'
SECOND=POST/'mts-second-micromotion-20261107'
BRANCH=POST/'condensate-origin-20261003'
PRIOR=POST/'mts-metric-feedback-20261107'
SOURCE=POST/'mts-direct-tangent-20261107'
HIERARCHY=POST/'mts-retarded-hierarchy-20261107'
NATIVE=BRANCH/'native-heavy-matching-20261007/native'
EARLY=BRANCH/'native-two-field-transfer-20261007'
WAVELENGTH=POST/'mts-derived-wavelength-test-20261107'
WAVES=WAVELENGTH/'inventory-config.json'
BRIDGE=Path('C:/MTS-Data/condensate-origin-20261003/stiff-gas-dense-output-20261027/data/memory-tail-history-20261027/source-readout-bridge-20261102')
ALGEBRA,GATE=1e-10,2e-5
sys.path.extend(str(path) for path in (COMPLETED,CONTINUATION,REAL_SERIES,CONTIGUOUS,REMAINDER,CORRELATED,TRANSPORT,MATCHING,TUBE,EXACT,FREE,FULL,METRIC,ANALYTIC,ENERGY,COLD,PHASE,JOINT,RELATIVE,GAIN,CHANNELS,ENVELOPE,ORIGINAL_WAVES,ORIGINAL_PRIMITIVE,ORIGINAL_ADJOINT,ORIGINAL_POISSON,SEALED,TIMECHAIN,PREVIOUS))


def require(condition,message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def write(path,value):
    with Path(path).open('x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2,allow_nan=False)


WAVE=dict(read(WAVES)['waves']).get(LABEL)


def guard():
    require(datetime.now(timezone.utc)<datetime(2026,11,9,19,15,tzinfo=timezone.utc),'four-hour check-in cutoff')
    for path in (REFINEMENT/'STOP-REQUESTED',THIRD_CELL/'STOP-REQUESTED',SECOND_CELL/'STOP-REQUESTED',FIRST_CELL/'STOP-REQUESTED',CONDITION_STAGE/'STOP-REQUESTED',PHASE_RESPONSE/'STOP-REQUESTED',TIME_STAGE/'STOP-REQUESTED',FRAME_STAGE/'STOP-REQUESTED',RESPONSE_STAGE/'STOP-REQUESTED',FEEDBACK_STAGE/'STOP-REQUESTED',ACCUM_STAGE/'STOP-REQUESTED',CLOCK_STAGE/'STOP-REQUESTED',COMPLETED/'STOP-REQUESTED',STAGE/'STOP-REQUESTED',ROOT/'STOP-REQUESTED',RELATIVE/'STOP-REQUESTED',COLD_BACKGROUND/'STOP-REQUESTED',BRIDGE/'STOP-REQUESTED',BRIDGE.parent/'STOP-REQUESTED',BRIDGE.parent/'execution-v3/STOP-REQUEST.json',BRIDGE/'final-epoch-kinematic-bank/STOP-REQUESTED'):
        require(not path.exists(),'owner hold: '+str(path))


def modest():
    import psutil
    process=psutil.Process()
    process.nice(psutil.BELOW_NORMAL_PRIORITY_CLASS)
    process.cpu_affinity([4])
    guard()


def digest(path):
    result=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            result.update(block)
    return result.hexdigest()


def load(path):
    import numpy as np
    with np.load(path) as packet:
        return {name:packet[name].copy() for name in packet.files}


def sources():
    return {str(path):digest(path) for path in STAGE.iterdir() if path.suffix in ('.py','.ps1','.md')}


def verify_inputs():
    expected={
        REFINEMENT:'4db4e7ef2f4b2a1b21969541c632f701eff2fc9427dc8bf2d14c6882356fdc85',
        THIRD_CELL:'04b2652e013a8c6fc601b0b3f3bb53bbbbbf6cfb0ac1c6dbdd9df506b5d79c9d',
        SECOND_CELL:'7b136ef644add714c2451d75fe72dc5d6032967f382b70ea4d3eee10b8a26c74',
        FIRST_CELL:'f1083895e9ae9ad3962cfe8dc09446023b52c82384f81e52c6ce868e5e537ce9',
        CONDITION_STAGE:'9438eeb1c67ade0164c3b40f8cd2074376563dbf4e67ef1b65de1e33b5790b65',
        PHASE_RESPONSE:'e9605e1c81ad5b48ef790ee5f906cd1c29bf628140cc80f5fdd9b1c6ffbf73d2',
        TIME_STAGE:'4a863cd39702bec298b21b2c00e1e50ced55deb232d1d3a9b5b1269ce5db504d',
        FRAME_STAGE:'c493c716bbc2511e108e142e4ec802d72484728c2d82d29d6f6e374927dddd8f',
        RESPONSE_STAGE:'c16409295629d6cc22a85e5c21460126a0472db04bfe9e288594e271378150b9',
        FEEDBACK_STAGE:'240b11ffa6d55376eb9ba3d5d8dd930010f0786a885d0c05de5fe85ac063f6c9',
        ACCUM_STAGE:'eca00d35284cc1b625726d786852bd337b81d48815c99789d79e6f80d2e418ce',
        CLOCK_STAGE:'9326810b114cd2f4758e95f0d0878eead292678358a09ebc75011bef5a690790',
        COMPLETED:'cca27f5d3d015605ec05fbf07cde372dfcfe2c73c7035da915761ee021473b12',
        CONTINUATION:'ad51bff1451898d45a30ef05561aff0e43761e5c45ef616cbfac5b2f1b16ea75',
        REAL_SERIES:'3ba22a5d39071a0c83c07c1cc8802472c5898c5dd1fd443475a1221ccce9a720',
        CONTIGUOUS:'8593146437412d04d2a1ee90806f85090580a809fb16fc9b60974335f4374f3d',
        REMAINDER:'d14b095f9c0ee9c3f11f3fb69dc185bcac3944d054d7a14d552463aeb6831daf',
        CORRELATED:'18ef599d24a4382fe47634c2bf98eb0c3c1663de83ed0732c79017628db34a2e',
        TRANSPORT:'ba7c097d8015ca0bad8594b4e6be1dffa7b110edbe7d85523392433590d868db',
        MATCHING:'5bdb08a8feeda76c653014ad0568f31531e33b13e0b0053db5e6d6be39b2da86',
        TUBE:'98653ee79c88d7edc20146fadef4017af205f763d21b0036a17dc851dd225a44',
        EXACT:'f267a6f41817a56e15858945d42c30a8dbcf86dfbfa90bf992e393c76a60f712',
        FREE:'6bfd07ec9fd838fdc0146e9bea5a1e67d41bbbf774c475b37e26c7c3e524c813',
        FULL:'d32e7fe4a30e360385814bc2794d6b21b816e5e280ac9794fd876dff21e4272a',
        METRIC:'883d32ff81a0ce099620db0e306cfb115a13ed63aa8be49f395d50339f5fe4f8',
        ANALYTIC:'446cf20750ba1fd7b54854a12284a9adb4cd562cd1cb723dd618347f7643a7d1',
        ENERGY:'5228bde4b21246bbcecb2b4a78772bb81fe43e954c419a61ea97e3718705642a',
        COLD:'2c34fcadb4847aec5dbaf72b292023d5fc3c9647d7e1701fc553bd9bbb5bdb13',
        PHASE:'e8938262d574eb8f4448ba88d37f4158292e202e7232c3133817034e978fee30',
        JOINT:'b5928c32e1a1c58e37c02fe747a8cd776307787ad4d58a3ddc0b2b614c9018a6',
        RELATIVE:'0ed0dc3b0b30e452a9e241057d21ffa6497e16298eace03d5b58ee13a4acab5f',
        COLD_BACKGROUND:'3cf78fb90a99a5b6c6527e29b221bccfd508a7c1df589b62ab47fac8e4df580f',
        CHANNELS:'a16e7c9764cebbadc43dbf729b5f8f86310aea63a5e6b83ab8afc082717f0ed0',
        GAIN:'cd29bc225d756592906efe5c3eb8316c937af9150865fffa9a7b361e43920b5e'}
    records={}
    for folder,seal in expected.items():
        guard()
        require(digest(folder/'closeout.json')==seal,'upstream seal')
        records[str(folder/'closeout.json')]=seal
        for item in read(folder/'closeout.json')['artifacts']:
            if Path(item['path']).suffix in ('.py','.json','.npz') and Path(item['path']).parent==folder:
                require(digest(item['path'])==item['sha256'],'upstream source')
                records[item['path']]=item['sha256']
    for path,seal in read(RELATIVE/'audit-01/result.json')['consumed'].items():
        require(digest(path)==seal,'saved background input')
        records[path]=seal
    owned={str(Path(row['path'])):row['sha256'] for row in read(COLD/'closeout.json')['artifacts']}
    for label in ('half','balanced','double'):
        for relative in ('cold-midpoint-02/heavy-generator.npz','cold-midpoint-02/cold-generator.npz','cold-midpoint-02/result.json','independent-02/result.json'):
            path=COLD/label/relative
            require(str(path) in owned and digest(path)==owned[str(path)],'accepted cold evidence')
            records[str(path)]=owned[str(path)]
    return records



def check_parent():
    return verify_inputs()


OWNED_MANIFESTS={}
def owned(path):
    path=Path(path)
    for parent in (TIME_STAGE,FRAME_STAGE,RESPONSE_STAGE,FEEDBACK_STAGE,ACCUM_STAGE,CLOCK_STAGE,COMPLETED):
        if path.is_relative_to(parent):
            if parent not in OWNED_MANIFESTS:
                OWNED_MANIFESTS[parent]={str(Path(row['path'])):row['sha256'] for row in read(parent/'closeout.json')['artifacts']}
            require(str(path) in OWNED_MANIFESTS[parent],'sealed input ownership '+str(path))
            require(digest(path)==OWNED_MANIFESTS[parent][str(path)],'sealed input bytes '+str(path))
            return path
    raise ValueError('not a declared immediate input '+str(path))
