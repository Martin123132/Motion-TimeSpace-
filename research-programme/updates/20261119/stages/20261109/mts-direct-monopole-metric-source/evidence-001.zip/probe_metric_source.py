from common import *
from native_time_v2 import NativeTimeV2
from native_time import CommonCarrierFibre,correlated,BRANCHES
from monopole_math import direct_source
import numpy as np


def relative_norm(left,right):
    return float(np.linalg.norm(np.asarray(left)-np.asarray(right))/max(
        np.linalg.norm(left),np.linalg.norm(right),1e-80))


def capture(system,efold,vector,branch,massless):
    state=vector*system.units
    evaluated=system.evaluate(efold,state,branch)
    point=system.context['point'](efold).copy()
    raw=system.decode(efold,state)
    physical=system.project(raw)
    observed=system.context['observe'](float(point[11]),physical)
    terms,metadata=system.context['stress'](float(point[11]),physical)
    slopes=system.background_spline(efold,1)
    native_dipole=system.context['position'](int(system.context['signature_values'][4])+1)
    require(np.array_equal(terms,evaluated[5]),'independently read stress equals evaluated stress')
    answer=dict(observed=observed.tolist(),terms=terms.tolist(),metadata=metadata.tolist(),
        H=float(point[12]),H_N=float(slopes[0]),gravity_N=float(slopes[1]),
        alpha=float(state[system.alpha_slot]),dipole=float(physical[native_dipole]))
    return answer,point,evaluated[0]/system.units,evaluated[3]


def collect(model,records,output):
    case=NativeTimeV2(model,'stress-contexts-'+model)
    system=case.system
    require(system.context['signature_values'][12]==1 and system.context['signature_values'][13]==0,'same massless-fluid approximation')
    layout_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-00-source.json')
    layout=read(layout_path)['layout'];massless=layout['massless_all']
    mono,dipole,quad=massless
    require(system.core[mono]==system.context['position'](int(system.context['signature_values'][4])),'monopole native mapping')
    consumed=dict(case.consumed)
    consumed[str(layout_path)]=digest(layout_path)
    reports=[]
    for node in records:
        guard()
        require(digest(node['path'])==node['sha256'],'frozen input unchanged')
        consumed[node['path']]=node['sha256']
        packet=load(node['path'])
        require(np.array_equal(system.units,packet['units']),'unchanged native units')
        efold,theta=float(packet['efold']),float(packet['phase'])
        replay=case.native(efold,theta,packet['native_vectors'])
        for key in ('reference_rates','retained_rates','reference_background','retained_background','native_vectors'):
            require(np.array_equal(replay[key],packet[key]),'bitwise replay of saved '+key)
        captures=[];diagnostics=[]
        case.restore_window()
        try:
            reference=[]
            for branch,name in enumerate(BRANCHES):
                reference.append(capture(system,efold,packet['native_vectors'][branch,:,0],name,massless))
            frozen=case.owner.frozen(efold)
            physical=correlated(frozen,theta)[0] if model=='heavy' else frozen
            state=np.array([efold,physical['values'][0]/(np.exp(efold)*case.owner.saved.masses[0]),*physical['values'][1:]])
            with CommonCarrierFibre(system) as fibre:
                fibre.chart_angle=float(packet['carrier'])
                fibre.carrier_rate=float(packet['carrier_rate'])
                fibre.common_carrier=True
                fibre.install(state,theta)
                retained=[capture(system,efold,packet['native_vectors'][branch,:,0],name,massless)
                    for branch,name in enumerate(BRANCHES)]
        finally:
            case.restore_window()
        raw_arrays={}
        for branch,name in enumerate(BRANCHES):
            first,second=reference[branch],retained[branch]
            for side,result in (('reference',first),('retained',second)):
                primitive,point,rates,info=result
                require(np.array_equal(point,packet[side+'_background']),'same saved background in stress capture')
                require(np.array_equal(rates,packet[side+'_rates'][branch,:,0]),'same saved rate in stress capture')
                for key in ('observed','terms','metadata'):
                    raw_arrays[f'{branch}_{side}_{key}']=np.asarray(primitive[key])
            calculated=direct_source(first[0],second[0],name,system.wave,system.units[mono])
            rate_values=calculated['rate'].values()
            direct_z=calculated['expansion'].values()
            old_rates=[float(packet[side+'_rates'][branch,mono,0]) for side in ('reference','retained')]
            old_delta=float(packet['difference'][branch,mono,0])
            rate_error=max(abs(rate_values[side]-old_rates[side])/max(abs(old_rates[side]),1e-80) for side in range(2))
            z_error=max(abs(direct_z[side]-item[3]['z'])/max(abs(item[3]['z']),1e-80)
                for side,item in enumerate((first,second)))
            require(max(rate_error,z_error)<ALGEBRA,'independently derived source agrees with native rate and geometry')
            delta_scale=max(abs(old_delta),abs(rate_values[2]),1e-80)
            record=dict(model=model,index=node['index'],branch=name,passed=True,
                primitives=dict(reference=first[0],retained=second[0]),
                wave=system.wave,monopole_unit=float(system.units[mono]),
                native_rates=old_rates,native_delta=old_delta,
                calculated={key:value.values() for key,value in calculated.items() if hasattr(value,'values')},
                increment_parts=list(map(float,calculated['increment_parts'])),
                part_names=calculated['part_names'],rate_error=rate_error,z_error=z_error,
                direct_delta_change=rate_values[2]-old_delta,
                direct_delta_relative_change=(rate_values[2]-old_delta)/delta_scale,
                native_input_error_bounded=False,no_source_replacement=True)
            captures.append(record)
        target=output/f'{model}-{node["index"]:04d}.npz'
        np.savez_compressed(target,efold=efold,phase=theta,units=packet['units'],
            reference_background=packet['reference_background'],retained_background=packet['retained_background'],
            native_vectors=packet['native_vectors'],massless_slots=massless,
            **raw_arrays)
        report_path=output/f'{model}-{node["index"]:04d}-result.json'
        result=dict(passed=True,model=model,index=node['index'],path=str(target),sha256=digest(target),
            frozen_source=node['path'],frozen_source_sha256=node['sha256'],bitwise_replay=True,
            records=captures,sources=sources(),consumed=consumed.copy())
        write(report_path,result)
        reports.append(dict(model=model,index=node['index'],path=str(report_path),sha256=digest(report_path)))
        print(model,node['index'],'direct source',[(row['branch'],row['rate_error'],row['direct_delta_relative_change']) for row in captures],flush=True)
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'capture inputs unchanged')
    return reports,consumed


def main():
    modest()
    frozen=read(ROOT/'freeze.json')
    require(frozen['passed'],'frozen diagnostic selection')
    for path,checksum in frozen['inputs'].items():
        require(digest(path)==checksum,'frozen dependencies unchanged')
    output=ROOT/'stress-probe-01'
    output.mkdir(exist_ok=False)
    reports=[];consumed={str(ROOT/'freeze.json'):digest(ROOT/'freeze.json')}
    for selection in frozen['selections']:
        results,paths=collect(selection['model'],selection['nodes'],output)
        reports.extend(results);consumed.update(paths)
    write(output/'result.json',dict(passed=True,reports=reports,consumed=consumed,sources=sources(),
        frozen_before_capture=True,original_bank_grids_tolerances_unchanged=True,
        no_saved_history_reintegration=True,no_source_replacement=True,no_accuracy_pass_claimed=True,
        native_stress_primitives_not_an_inversion_of_monopole_rate=True,
        candidate_arithmetic='exact rational finite increments on native binary stress inputs'))
    print('paired direct monopole metric-source probe complete',flush=True)


if __name__=='__main__':
    main()

