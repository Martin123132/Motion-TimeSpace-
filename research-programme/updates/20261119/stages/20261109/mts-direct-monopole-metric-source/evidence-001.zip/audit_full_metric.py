from common import *
from decimal import Decimal,localcontext
from fractions import Fraction
from monopole_math import direct_source,Pair
import numpy as np


def independent_rate(item,branch,wave,unit):
    convert=lambda value:Decimal.from_float(float(value))
    observed=list(map(convert,item['observed']))
    terms=[list(map(convert,row)) for row in item['terms']]
    metadata=list(map(convert,item['metadata']))
    hubble=convert(item['H']);alpha=convert(item['alpha']);dipole=convert(item['dipole'])
    wave=convert(wave);unit=convert(unit)
    enthalpy=observed[0]+observed[1]
    quadrature=sum(row[5] for index,row in enumerate(terms) if index!=4)+metadata[3]
    shear_source=observed[5]-Decimal(3)*observed[3]/(2*wave**2)
    density_rate=sum(row[3] for row in terms)+wave*quadrature*shear_source
    momentum_rate=sum(row[4] for row in terms)
    hubble_rate=hubble*convert(item['H_N'])
    gravity=3*hubble*enthalpy/(2*wave**2)
    if branch=='gr':
        potential=-(observed[2]+2*observed[4])/(2*wave**2)-3*hubble*observed[3]/(2*wave**3)
        alpha_rate=potential-hubble*alpha
        phi_rate=-(wave*density_rate+3*hubble_rate*observed[3]+3*hubble*momentum_rate)/(2*wave**3)
    elif branch=='poisson-spatial':
        potential=-(observed[2]-3*hubble*enthalpy*alpha)/(2*wave**2)
        alpha_rate=potential-hubble*alpha
        phi_rate=-density_rate/(2*wave**2)+hubble*convert(item['gravity_N'])*alpha+gravity*alpha_rate
    else:
        raise ValueError('unsupported branch')
    denominator=1+3*quadrature/(2*wave**2)
    expansion=(wave**2*alpha-3*(phi_rate+hubble_rate*alpha+hubble*alpha_rate))/(wave*denominator)
    return -wave*(dipole+4*expansion/3)/(hubble*unit),expansion


def main():
    modest()
    output=STAGE/'full-audit'
    output.mkdir(exist_ok=False)
    frozen=read(ROOT/'full-freeze.json')
    report=read(ROOT/'stress-full-01/result.json')
    require(report['passed'] and report['no_source_replacement'],'completed unmodified candidate probe')
    consumed={str(ROOT/'full-freeze.json'):digest(ROOT/'full-freeze.json'),
              str(ROOT/'stress-full-01/result.json'):digest(ROOT/'stress-full-01/result.json')}
    for owner in (frozen,report):
        for collection in ('sources','inputs','consumed'):
            for path,checksum in owner.get(collection,{}).items():
                require(digest(path)==checksum,'immutable probe source/input')
                consumed[path]=checksum
    expected={(item['model'],node['index']):node for item in frozen['selections'] for node in item['nodes']}
    seen=set();rows=[];maxima=dict(rate=0.,geometry=0.,increment=0.)
    with localcontext() as context:
        context.prec=90
        for entry in report['reports']:
            require(digest(entry['path'])==entry['sha256'],'node receipt hash')
            consumed[entry['path']]=entry['sha256']
            node=read(entry['path'])
            key=(node['model'],node['index'])
            require(key in expected and key not in seen,'frozen node coverage without duplicate')
            seen.add(key)
            require(node['bitwise_replay'] and digest(node['path'])==node['sha256'],'native replay and capture')
            consumed[node['path']]=node['sha256']
            packet=load(node['path']);old=load(expected[key]['path'])
            require(np.array_equal(packet['native_vectors'],old['native_vectors']),'same original perturbation states')
            require(len(node['records'])==2,'both metric branches')
            mono=int(packet['massless_slots'][0])
            for branch,record in enumerate(node['records']):
                require(record['branch']==('gr','poisson-spatial')[branch],'branch identity')
                for side in ('reference','retained'):
                    item=record['primitives'][side]
                    for name in ('observed','terms','metadata'):
                        require(np.array_equal(np.array(item[name]),packet[f'{branch}_{side}_{name}']),'raw primitive serialization')
                    require(item['H']==float(old[side+'_background'][12]),'saved background H')
                first,second=record['primitives']['reference'],record['primitives']['retained']
                unit=float(old['units'][mono])
                require(unit==record['monopole_unit'],'original scaling')
                values=[independent_rate(item,record['branch'],record['wave'],unit) for item in (first,second)]
                rates=[float(value[0]) for value in values]
                expansions=[float(value[1]) for value in values]
                increment=float(values[0][0]-values[1][0])
                rate_error=max(abs(rates[index]-record['native_rates'][index])/max(abs(record['native_rates'][index]),1e-80) for index in range(2))
                geometry_error=max(abs(expansions[index]-record['calculated']['expansion'][index])/max(abs(expansions[index]),1e-80) for index in range(2))
                increment_error=abs(increment-record['calculated']['rate'][2])/max(abs(increment),1e-80)
                require(max(rate_error,geometry_error,increment_error)<ALGEBRA,'independent 90-digit metric source')
                require(record['native_rates']==[float(old[side+'_rates'][branch,mono,0]) for side in ('reference','retained')],'original native rates')
                same=direct_source(first,first,record['branch'],record['wave'],unit)
                reverse=direct_source(second,first,record['branch'],record['wave'],unit)
                forward=direct_source(first,second,record['branch'],record['wave'],unit)
                require(same['rate'].delta==0 and reverse['rate'].delta==-forward['rate'].delta,'zero and sign controls')
                require(sum(forward['increment_parts'])==forward['rate'].delta,'exact finite-increment split')
                maxima['rate']=max(maxima['rate'],rate_error)
                maxima['geometry']=max(maxima['geometry'],geometry_error)
                maxima['increment']=max(maxima['increment'],increment_error)
                rows.append(dict(model=node['model'],index=node['index'],branch=record['branch'],passed=True,
                    rate_error=rate_error,geometry_error=geometry_error,increment_error=increment_error,
                    direct_delta_relative_change=record['direct_delta_relative_change']))
    require(seen==set(expected) and len(rows)==4084,'full frozen paired coverage')
    from scipy.sparse import block_diag,csc_matrix,diags
    from scipy.sparse.linalg import splu
    from response_support import adjoints
    from correlated_source import full_endpoint
    projection_path=ROOT/'metric-projection-01/result.json'
    projected=read(projection_path)
    require(projected['passed'] and projected['no_source_replacement'] and projected['no_candidate_full_control_pass_claimed'],'diagnostic-only projection')
    consumed[str(projection_path)]=digest(projection_path)
    for name in ('sources','consumed'):
        for path,checksum in projected[name].items():
            require(digest(path)==checksum,'projection provenance')
            consumed[path]=checksum
    probe_freeze=read(ROOT/'freeze.json')
    capture_index={(item['model'],item['index']):item for item in report['reports']}
    projection_checks=[]
    for projection in projected['reports']:
        model=projection['model']
        require(digest(projection['path'])==projection['sha256'],'candidate projection packet')
        consumed[projection['path']]=projection['sha256']
        packet=load(projection['path'])
        original=load(REFINEMENT/LABEL/'source-attribution-01'/f'{model}-attribution.npz')
        for name in ('weights','refinement_weights','budget','reference_scale'):
            require(np.array_equal(packet[name],original[name]),'original diagnostic scale and measure')
        with localcontext() as context:
            context.prec=90
            def exact_integral(weight,values):
                return np.array([[float(sum(Decimal.from_float(float(amount))*Decimal.from_float(float(value))
                    for amount,value in zip(weight,values[:,branch,column]))) for column in range(2)] for branch in range(2)])
            independent_change=exact_integral(packet['weights'],packet['corrections'])
            independent_refinement=exact_integral(packet['refinement_weights'],original['original']+packet['corrections'])
        integration_error=max(float(np.max(abs(independent_change-packet['correction_fine'])/packet['budget'])),
            float(np.max(abs(independent_refinement-packet['candidate_refinement'])/packet['budget'])))
        require(integration_error<ALGEBRA,'independent high-precision weighted projection')
        curves,row_norm=adjoints(model,consumed)
        samples=next(item['nodes'] for item in probe_freeze['selections'] if item['model']==model)
        map_errors=[]
        for sample in samples:
            source=load(sample['path'])
            receipt=read(capture_index[(model,sample['index'])]['path'])
            captured=load(receipt['path'])
            mono,dipole,quad=captured['massless_slots'].astype(int)
            dimension=len(source['units']);compact=source['inverse'].shape[-1]
            physical=block_diag((csc_matrix(source['physical_core']),diags(source['physical_tail'])),format='csc')
            adjoint=(curves['fine'](float(source['efold']))*row_norm[:,:,None])[original['columns'].astype(int)]
            with localcontext() as context:
                context.prec=90
                for branch,record in enumerate(receipt['records']):
                    rate_ref=independent_rate(record['primitives']['reference'],record['branch'],record['wave'],record['monopole_unit'])[0]
                    rate_ret=independent_rate(record['primitives']['retained'],record['branch'],record['wave'],record['monopole_unit'])[0]
                    difference_mono=rate_ref-rate_ret
                    first_time,first_hubble=map(float,source['reference_background'][11:13])
                    second_time,second_hubble=map(float,source['retained_background'][11:13])
                    convert=lambda value:Decimal.from_float(float(value))
                    reciprocal=1/(convert(first_time)*convert(first_hubble))-1/(convert(second_time)*convert(second_hubble))
                    moment=float(source['units'][quad]*source['native_vectors'][branch,quad,0])
                    difference_quad=-convert(source['units'][mono])/convert(source['units'][quad])*difference_mono-3*convert(moment)/convert(source['units'][quad])*reciprocal
                    delta=np.zeros(dimension)
                    delta[mono]=float(difference_mono)-source['difference'][branch,mono,0]
                    delta[quad]=float(difference_quad)-source['difference'][branch,quad,0]
                    inverse=block_diag((csc_matrix(source['inverse'][branch]),diags(np.ones(dimension-compact))),format='csc')
                    endpoint=full_endpoint(source['endpoint'][branch],source['remote_keys'],source['remote_stream'],float(source['remote_endpoint']),dimension)
                    forward=splu(endpoint).solve(inverse@(physical@delta))
                    value=adjoint[:,branch,:]@forward
                    map_error=float(np.max(abs(value-packet['corrections'][sample['index'],branch])/packet['budget'][branch]))
                    require(map_error<ALGEBRA,'sampled independent forward-map versus native-covector projection')
                    map_errors.append(map_error)
        projection_checks.append(dict(model=model,passed=True,independent_integral_error=integration_error,
            forward_map_checks=len(map_errors),forward_map_error=max(map_errors)))

    require(all(digest(path)==checksum for path,checksum in consumed.items()),'probe evidence preserved')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,rows=rows,maxima=maxima,
        frozen_nodes=2042,branch_cases=4084,zero_controls=4084,sign_controls=4084,
        no_source_replacement=True,no_quadrature_pass_claimed=True,
        scope='independent native stress-to-metric algebra across the saved source grid; not a bound on native primitive accuracy',
        projection_checks=projection_checks))
    print(json.dumps(dict(passed=True,cases=len(rows),maxima=maxima)),flush=True)


if __name__=='__main__':
    main()
