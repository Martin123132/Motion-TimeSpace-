from common import *
import numpy as np


def main():
    modest()
    ROOT.mkdir(exist_ok=False)
    inputs=verify_inputs()
    parent_seal=REFINEMENT/'closeout.json'
    require(digest(parent_seal)=='4db4e7ef2f4b2a1b21969541c632f701eff2fc9427dc8bf2d14c6882356fdc85','previous completed refinement')
    manifest={str(Path(item['path'])):item['sha256'] for item in read(parent_seal)['artifacts']}
    source_path=REFINEMENT/LABEL/'points-01/refined-cell03-result.json'
    require(str(source_path) in manifest and digest(source_path)==manifest[str(source_path)],'sealed source index')
    source=read(source_path)
    selections=[]
    inputs[str(parent_seal)]=digest(parent_seal)
    inputs[str(source_path)]=digest(source_path)
    for model in ('heavy','cold'):
        report=next(row for row in source['reports'] if row['model']==model)
        last=len(report['nodes'])-1
        middle=last//2
        selected=[0,1,2,middle-1,middle,middle+1,last-2,last-1,last]
        require(len(set(selected))==9,'nine predefined nodes')
        records=[]
        for index in selected:
            node=report['nodes'][index]
            require(node['index']==index and digest(node['path'])==node['sha256'],'saved node ownership')
            packet=load(node['path'])
            inputs[node['path']]=node['sha256']
            records.append(dict(index=index,path=node['path'],sha256=node['sha256'],
                efold=float(packet['efold']),phase=float(packet['phase']),inherited_even=index%2==0))
        selections.append(dict(model=model,nodes=records))
    write(ROOT/'freeze.json',dict(passed=True,inputs=inputs,sources=sources(),selections=selections,
        selector='first/middle/last adjacent triples selected before new stress evaluation',
        target_branches=['gr','poisson-spatial'],target_channels=['Pi','delta_massless'],
        unchanged_gates=[ALGEBRA,GATE],no_new_physical_history_solve=True,
        no_source_replacement=True,no_holdout_observational_claim=True,posthoc_source_diagnostic=True))
    print('18 saved source nodes frozen with original bytes and gates',flush=True)


if __name__=='__main__':
    main()

