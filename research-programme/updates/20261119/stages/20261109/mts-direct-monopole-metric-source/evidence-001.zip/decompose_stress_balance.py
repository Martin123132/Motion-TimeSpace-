from common import *
from fractions import Fraction
from monopole_math import Pair,direct_source
from project_metric_source import integrate
from response_support import adjoints,BRANCHES
from correlated_source import full_endpoint
from scipy.sparse import block_diag,csc_matrix,diags
from scipy.sparse.linalg import splu
import numpy as np


def balances(reference,retained,branch,wave,unit):
    wave=Fraction(float(wave));unit=Fraction(float(unit))
    make=lambda first,second:Pair(first,second)
    observed=[make(first,second) for first,second in zip(reference['observed'],retained['observed'])]
    table=[[make(first,second) for first,second in zip(first_row,second_row)]
        for first_row,second_row in zip(reference['terms'],retained['terms'])]
    meta=[make(first,second) for first,second in zip(reference['metadata'],retained['metadata'])]
    hubble=make(reference['H'],retained['H'])
    alpha=make(reference['alpha'],retained['alpha'])
    scale=meta[0]
    native_z=observed[5]-Fraction(3,2)*observed[3]/(wave*wave)
    density=sum(row[0] for row in table)
    current=sum(row[1] for row in table)
    pressure=sum(row[2] for row in table)
    anisotropy=sum(row[6] for row in table)
    quadrature=sum(row[5] for index,row in enumerate(table) if index!=4)+meta[3]
    density_native=sum(row[3] for row in table)+wave*quadrature*native_z
    current_native=sum(row[4] for row in table)
    density_conservative=-hubble*(density+3*pressure)-wave*current+3*hubble*table[1][2]
    current_conservative=-2*hubble*current+wave*pressure-Fraction(2,3)*wave*anisotropy
    density_defects=[];current_defects=[];background_defects=[]
    for start in (4,14):
        field,velocity,field_rate,velocity_rate,mass,perturbation,perturbation_rate=meta[start:start+7]
        field_defect=field_rate-velocity
        acceleration_defect=velocity_rate+2*hubble*velocity+scale*scale*mass*mass*field
        density_defects.append(acceleration_defect*perturbation_rate+scale*scale*mass*mass*field_defect*perturbation)
        current_defects.append(wave*acceleration_defect*perturbation)
        background_defects.append((field_defect,acceleration_defect))
    density_residual=density_native-density_conservative-sum(density_defects)
    current_residual=current_native-current_conservative-sum(current_defects)
    checks=[]
    for side in ('reference','retained'):
        density_scale=sum(abs(getattr(row[3],side)) for row in table)+abs(getattr(wave*quadrature*native_z,side))+abs(getattr(density_conservative,side))
        current_scale=sum(abs(getattr(row[4],side)) for row in table)+abs(getattr(current_conservative,side))
        checks.append([float(abs(getattr(density_residual,side))/max(density_scale,Fraction(1,10**80))),
                       float(abs(getattr(current_residual,side))/max(current_scale,Fraction(1,10**80)))])
    direct=direct_source(reference,retained,branch,float(wave),float(unit))
    require(direct['density_base'].reference==density_native.reference and direct['density_base'].retained==density_native.retained,'same retained density source')
    hubble_rate=direct['hubble_rate']
    if branch=='gr':
        phi_conservative=-density_conservative/(2*wave*wave)-3*(hubble_rate*observed[3]+hubble*current_conservative)/(2*wave*wave*wave)
        phi_defects=[-density_defects[index]/(2*wave*wave)-3*hubble*current_defects[index]/(2*wave*wave*wave) for index in range(2)]
        phi_residual=-density_residual/(2*wave*wave)-3*hubble*current_residual/(2*wave*wave*wave)
    else:
        enthalpy=observed[0]+observed[1]
        gravity=3*hubble*enthalpy/(2*wave*wave)
        gravity_rate=hubble*make(reference['gravity_N'],retained['gravity_N'])
        phi_conservative=-density_conservative/(2*wave*wave)+gravity_rate*alpha+gravity*direct['alpha_rate']
        phi_defects=[-value/(2*wave*wave) for value in density_defects]
        phi_residual=-density_residual/(2*wave*wave)
    divisor=direct['denominator']*hubble
    coefficient=4*divisor.mean/(unit*divisor.reference*divisor.retained)
    source_parts=[coefficient*value.delta for value in (phi_conservative,*phi_defects,phi_residual)]
    require(sum(source_parts)==direct['increment_parts'][2],'exact phi-rate source decomposition')
    return source_parts,checks,dict(density_native=density_native.values(),
        density_conservative=density_conservative.values(),density_slow_defect=density_defects[0].values(),
        density_heavy_defect=density_defects[1].values(),density_residual=density_residual.values(),
        current_native=current_native.values(),current_conservative=current_conservative.values(),
        current_slow_defect=current_defects[0].values(),current_heavy_defect=current_defects[1].values(),
        current_residual=current_residual.values(),
        background_defects=[[value.values() for value in row] for row in background_defects])


def main():
    modest()
    audit=read(STAGE/'full-audit/result.json')
    require(audit['passed'],'independent full-grid direct-source audit')
    output=ROOT/'stress-balance-01'
    output.mkdir(exist_ok=False)
    frozen=read(ROOT/'full-freeze.json')
    captured=read(ROOT/'stress-full-01/result.json')
    source_index={(row['model'],row['index']):row for row in captured['reports']}
    consumed={str(STAGE/'full-audit/result.json'):digest(STAGE/'full-audit/result.json')}
    for path in (FULL/'build-thermal-readout/camb_python.f90',COLD/'build-canonical-stress/MTSTwoField.f90'):
        consumed[str(path)]=digest(path)
    write(output/'freeze.json',dict(sources=sources(),inputs=consumed,
        prediction='species energy/momentum balance with explicit scalar background-flow defects and native baryon rest-mass approximation',
        no_new_native_calls=True,no_source_replacement=True,unchanged_gates=[ALGEBRA,GATE]))
    reports=[];records=[]
    for selected in frozen['selections']:
        model=selected['model']
        projection_path=ROOT/'metric-projection-01'/f'{model}-metric-projection.npz'
        consumed[str(projection_path)]=digest(projection_path)
        projected=load(projection_path)
        attribution=load(REFINEMENT/LABEL/'source-attribution-01'/f'{model}-attribution.npz')
        curves,row_norm=adjoints(model,consumed)
        components=[];checks=[];primitive_records=[]
        for node in selected['nodes']:
            guard()
            entry=source_index[(model,node['index'])]
            require(digest(entry['path'])==entry['sha256'],'saved direct stress result')
            consumed[entry['path']]=entry['sha256']
            result=read(entry['path'])
            require(digest(node['path'])==node['sha256'],'unchanged old physical source')
            consumed[node['path']]=node['sha256']
            packet=load(node['path'])
            captured_packet=load(result['path'])
            mono,dipole,quad=captured_packet['massless_slots'].astype(int)
            dimension=len(packet['units']);compact=packet['inverse'].shape[-1]
            physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
            adjoint=(curves['fine'](float(packet['efold']))*row_norm[:,:,None])[attribution['columns'].astype(int)]
            node_parts=[];node_checks=[]
            for branch,name in enumerate(BRANCHES):
                row=result['records'][branch]
                source_parts,errors,primitive=balances(row['primitives']['reference'],row['primitives']['retained'],
                    name,row['wave'],row['monopole_unit'])
                require(np.max(errors)<ALGEBRA,'derived stress balance with explicit flow defects')
                inverse=block_diag((csc_matrix(packet['inverse'][branch]),diags(np.ones(dimension-compact))),format='csc')
                endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],
                    float(packet['remote_endpoint']),dimension)
                covectors=physical.T@(inverse.T@splu(endpoint).solve(adjoint[:,branch,:].T,trans='T'))
                coefficient=covectors[mono]-covectors[quad]*packet['units'][mono]/packet['units'][quad]
                parts=coefficient[:,None]*np.array(list(map(float,source_parts)))[None,:]
                require(float(np.max(abs(parts.sum(axis=-1)-projected['components'][node['index'],branch,:,3])/projected['budget'][branch]))<ALGEBRA,
                    'same already-derived phi-rate contribution')
                node_parts.append(parts);node_checks.append(errors)
                primitive_records.append(dict(index=node['index'],branch=name,**primitive))
            components.append(node_parts);checks.append(node_checks)
            if node['index']%256==0:
                print(model,node['index'],'scalar-flow stress balance checked',flush=True)
        components=np.array(components);checks=np.array(checks)
        refinement=integrate(projected['refinement_weights'],components)
        fine=integrate(projected['weights'],components)
        closure=float(np.max(abs(refinement.sum(axis=-1)-projected['split_refinement'][:,:,3])/projected['budget']))
        require(closure<ALGEBRA,'integrated stress-balance decomposition')
        target=output/f'{model}-stress-balance.npz'
        np.savez_compressed(target,components=components,checks=checks,refinement=refinement,fine=fine,
            weights=projected['weights'],refinement_weights=projected['refinement_weights'],
            budget=projected['budget'],reference_scale=projected['reference_scale'])
        primitive_path=output/f'{model}-flow-primitives.json'
        write(primitive_path,primitive_records)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),
            primitives=str(primitive_path),primitives_sha256=digest(primitive_path),
            points=len(components),balance_max=np.max(checks,axis=(0,1,2)).tolist(),closure=closure))
        for branch,name in enumerate(BRANCHES):
            for column,channel in enumerate(('Pi','delta_massless')):
                records.append(dict(model=model,branch=name,channel=channel,
                    refinement_over_original_budget=(refinement[branch,column]/projected['budget'][branch,column]).tolist(),
                    fine_over_reference_scale=(fine[branch,column]/projected['reference_scale'][branch,column]).tolist(),
                    part_names=['native_conservative_transport','slow_field_flow_defect','heavy_field_flow_defect','remaining_arithmetic_or_approximation_residual']))
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'saved source evidence unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,records=records,
        no_new_native_calls=True,no_source_replacement=True,
        existing_baryon_and_neutrino_approximations_retained=True,
        scalar_flow_defects_measured_not_set_to_zero=True,
        no_unconditional_conservation_claim=True,original_bank_grids_tolerances_unchanged=True))
    print('saved-source stress balance and scalar-background defect decomposition complete',flush=True)


if __name__=='__main__':
    main()

