from common import *
from decimal import Decimal, localcontext
import numpy as np


def main():
    modest()
    output=ROOT/'composite-feasibility-01'
    output.mkdir(exist_ok=False)
    consumed={}
    reports=[]
    for model in ('heavy','cold'):
        metric_path=DIRECT_SOURCE/LABEL/'metric-projection-01'/f'{model}-metric-projection.npz'
        flow_path=DIRECT_SOURCE/LABEL/'stress-balance-01'/f'{model}-stress-balance.npz'
        attribution_path=REFINEMENT/LABEL/'source-attribution-01'/f'{model}-attribution.npz'
        for path in (metric_path,flow_path,attribution_path):
            consumed[str(path)]=digest(path)
        metric,flow,attribution=load(metric_path),load(flow_path),load(attribution_path)
        require(np.array_equal(metric['refinement_weights'],flow['refinement_weights']),'same old physical quadrature measure')
        remainder=metric['original_refinement']-flow['refinement'][:,:,2]
        exact=np.zeros_like(remainder)
        with localcontext() as context:
            context.prec=90
            make=lambda value:Decimal.from_float(float(value))
            for branch in range(2):
                for channel in range(2):
                    total=sum(make(weight)*(make(source)-make(heavy))
                              for weight,source,heavy in zip(metric['refinement_weights'],
                                  attribution['original'][:,branch,channel],flow['components'][:,branch,channel,2]))
                    exact[branch,channel]=float(total)
        error=float(np.max(abs(exact-remainder)/metric['budget']))
        require(error<ALGEBRA,'independent weighted remainder identity')
        reports.append(dict(model=model,
            original_refinement_over_budget=(metric['original_refinement']/metric['budget']).tolist(),
            removed_heavy_refinement_over_budget=(flow['refinement'][:,:,2]/metric['budget']).tolist(),
            remainder_refinement_over_budget=(exact/metric['budget']).tolist(),
            quadrature_only_margin=(GATE-abs(exact)/metric['budget']).tolist(),
            independent_identity_error=error))
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'old evidence unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,
        identity='I_hybrid = Q_old(S - S_heavy_flow) + Q_segment(S_heavy_flow)',
        diagnostic_only=True,complete_segment_integral_not_yet_calculated=True,
        no_background_equation_replacement=True,no_candidate_pass=True,
        other_error_terms_still_required=True,unchanged_gates=[ALGEBRA,GATE]))
    for report in reports:
        print(report['model'],'remaining refinement/budget',report['remainder_refinement_over_budget'],flush=True)


if __name__=='__main__':
    main()

