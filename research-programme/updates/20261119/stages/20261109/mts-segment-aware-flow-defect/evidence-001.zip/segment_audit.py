from common import *
from decimal import Decimal, localcontext
from scipy.sparse import block_diag, csc_matrix, diags
from scipy.sparse.linalg import splu
from correlated_source import full_endpoint
from response_support import adjoints
import numpy as np


def independent_parts(row):
    with localcontext() as context:
        context.prec = 90
        def number(value):
            return Decimal.from_float(float(value))
        wave, unit = number(row['wave']), number(row['unit'])
        phis, divisors = [], []
        for side in ('reference','retained'):
            source = row[side]
            hubble = number(source['H'])
            table = [[number(value) for value in record] for record in source['terms']]
            meta = [number(value) for value in source['metadata']]
            quadrature = sum(record[5] for index,record in enumerate(table) if index!=4)+meta[3]
            divisor = (1+3*quadrature/(2*wave*wave))*hubble
            fields=[]
            for start in (4,14):
                field, velocity, field_rate, velocity_rate, mass, perturbation, perturbation_rate = meta[start:start+7]
                omega = meta[0]*meta[0]*mass*mass
                field_defect = field_rate-velocity
                velocity_defect = velocity_rate+2*hubble*velocity+omega*field
                density_defect = velocity_defect*perturbation_rate+omega*field_defect*perturbation
                current_defect = wave*velocity_defect*perturbation
                phi = -density_defect/(2*wave*wave)
                if row['branch']=='gr':
                    phi -= 3*hubble*current_defect/(2*wave*wave*wave)
                fields.append(phi)
            phis.append(fields)
            divisors.append(divisor)
        coefficient = 2*(divisors[0]+divisors[1])/(unit*divisors[0]*divisors[1])
        return [float(coefficient*(phis[0][index]-phis[1][index])) for index in range(2)]


def audit(mode):
    modest()
    output = STAGE/(mode+'-audit')
    output.mkdir(exist_ok=False)
    batches = ['probe'] if mode=='probe' else ['probe','remaining']
    reports=[]
    consumed={}
    for batch in batches:
        path=ROOT/'points-01'/(batch+'-result.json')
        result=read(path)
        require(result['passed'],'completed source batch')
        consumed[str(path)]=digest(path)
        consumed.update(result['consumed'])
        reports.extend(result['reports'])
    maximum=0.
    forward_error=0.
    cases=0
    curves={}
    for entry in reports:
        guard()
        require(digest(entry['path'])==entry['sha256'],'saved flow receipt')
        consumed[entry['path']]=entry['sha256']
        result=read(entry['path'])
        for path,checksum in result['sources'].items():
            require(digest(path)==checksum,'executed source unchanged')
        for key in ('path','source','phase'):
            require(digest(result[key])==result['sha256' if key=='path' else key+'_sha256'],'flow point bytes')
            consumed[result[key]]=result['sha256' if key=='path' else key+'_sha256']
        flow=load(result['path'])
        for phase_index, records in enumerate(result['primitive_records']):
            for row in records:
                exact=np.array(independent_parts(row))
                actual=np.array(row['parts'][1:3])
                scale=np.maximum(np.maximum(abs(exact),abs(actual)),1e-80)
                error=float(np.max(abs(exact-actual)/scale))
                require(error<ALGEBRA,'independent 90-digit scalar flow response')
                maximum=max(maximum,error)
                cases+=2
        if mode=='probe':
            packet=load(result['source'])
            model=result['model']
            if model not in curves:
                curves[model]=adjoints(model,consumed)
            splines,row_norm=curves[model]
            dimension=len(packet['units'])
            physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
            compact=packet['inverse'].shape[-1]
            mono,dipole,quad=flow['massless_slots'].astype(int)
            for branch in range(2):
                inverse=block_diag((csc_matrix(packet['inverse'][branch]),diags(np.ones(dimension-compact))),format='csc')
                endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],float(packet['remote_endpoint']),dimension)
                native=np.zeros(dimension)
                native[mono]=1
                native[quad]=-packet['units'][mono]/packet['units'][quad]
                retained=splu(endpoint).solve(inverse@(physical@native))
                adjoint=(splines['fine'](float(packet['efold']))*row_norm[:,:,None])[flow['columns'].astype(int),branch]
                forward=adjoint@retained
                reverse=flow['coefficients'][0,0,branch]
                error=float(np.max(abs(forward-reverse)/np.maximum(np.maximum(abs(forward),abs(reverse)),1e-80)))
                require(error<ALGEBRA,'independent forward versus transpose observable map')
                forward_error=max(forward_error,error)
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'audit inputs unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,points=len(reports),
                                   independent_scalar_cases=cases,arithmetic_error=maximum,forward_map_error=forward_error,
                                   integration_pass_not_implied=True))
    print(mode,len(reports),'points; independent scalar error',maximum,'map error',forward_error,flush=True)

