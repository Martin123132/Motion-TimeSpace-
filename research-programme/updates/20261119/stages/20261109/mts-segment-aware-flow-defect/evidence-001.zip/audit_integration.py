from common import *
from exact_interval_weights import independent_moments
from decimal import Decimal, localcontext
import numpy as np


def exact_sum(weights, values):
    shape=values.shape[1:]
    flattened=values.reshape(len(weights),-1)
    answer=[]
    with localcontext() as context:
        context.prec=90
        for column in range(flattened.shape[1]):
            total=sum(Decimal.from_float(float(weight))*Decimal.from_float(float(value))
                      for weight,value in zip(weights,flattened[:,column]))
            answer.append(float(total))
    return np.array(answer).reshape(shape)


def main():
    modest()
    output=STAGE/'integration-audit'
    output.mkdir(exist_ok=False)
    frozen_path=ROOT/'freeze-01/result.json'
    weights_path=ROOT/'exact-weights-01/result.json'
    result_path=ROOT/'projection-01/result.json'
    frozen,weights,results=read(frozen_path),read(weights_path),read(result_path)
    require(results['passed'],'finished segment projection')
    consumed={str(path):digest(path) for path in (frozen_path,weights_path,result_path)}
    consumed.update(results['consumed'])
    maximum=0.
    map_error=0.
    cases=0
    records=[]
    for report in results['reports']:
        model=report['model']
        require(digest(report['path'])==report['sha256'],'saved projected packet')
        consumed[report['path']]=report['sha256']
        packet=load(report['path'])
        selection=next(item for item in frozen['reports'] if item['model']==model)
        rules=next(item for item in weights['reports'] if item['model']==model)
        grid=load(selection['path'])
        for index in range(selection['nodes']):
            row_path=ROOT/'points-01'/f'{model}-{index:03d}-flow-result.json'
            row=read(row_path)
            flow=load(row['path'])
            for phase_index,primitive_rows in enumerate(row['primitive_records']):
                for primitive in primitive_rows:
                    branch=0 if primitive['branch']=='gr' else 1
                    column=primitive['column']
                    for adjoint in range(3):
                        expected=flow['coefficients'][phase_index,adjoint,branch,:,None]*np.array(primitive['parts'])[None,:]
                        actual=packet['controls'][index,phase_index,adjoint,branch,column]
                        require(np.array_equal(expected,actual),'each isolated part mapped to the intended branch/current/observable')
                        cases+=1
        for ordinal,segment in enumerate(rules['segments']):
            chosen=packet['controls'][segment['indices']]
            for order,rule in enumerate(segment['rules']):
                require(independent_moments(grid['efold'][segment['indices']][rule['local_indices']],
                                            rule['weights'],*segment['range'])<ALGEBRA,'exact-interval moments')
                recomputed=exact_sum(rule['weights'],chosen[rule['local_indices']])
                actual=packet['integrals'][ordinal,order]
                scale=np.maximum(np.maximum(abs(recomputed),abs(actual)),1e-80)
                error=float(np.max(abs(recomputed-actual)/scale))
                require(error<ALGEBRA,'independent 90-digit integral sum')
                maximum=max(maximum,error)
            fine=packet['integrals'][ordinal,2,0,0,:,0]
            middle=packet['integrals'][ordinal,1,0,0,:,0]
            require(np.array_equal(fine-middle,packet['delta'][ordinal]),'fixed 33-minus17 refinement')
        computed=(abs(packet['delta'])+abs(packet['current'])+abs(packet['phase'])+abs(packet['cross'])
                  +abs(packet['adjoint_interp'])+abs(packet['adjoint_step']))
        require(np.array_equal(computed,packet['numerical']),'no omitted declared numerical-control terms')
        for row in report['rows']:
            ordinal=next(index for index,segment in enumerate(rules['segments']) if segment['segment']==row['segment'])
            branch=0 if row['branch']=='gr' else 1
            channel=('Pi','delta_massless').index(row['channel'])
            part=('native_conservative','slow_flow','heavy_flow','residual').index(row['part'])
            calculated=float(computed[ordinal,branch,channel,part]/packet['budget'][branch,channel])
            require(calculated==row['numerical_sum_over_budget'],'table control budget binding')
            require((calculated<GATE)==row['selected_segment_control_pass'],'unchanged gate including failures')
        if model=='cold':
            require(np.count_nonzero(packet['controls'][...,2])==0,'absent baseline heavy field contributes exactly zero')
            require(selection['selected_segments']==selection['overlapping_segments'],'baseline selected coverage')
        else:
            require(selection['selected_segments']==4 and selection['overlapping_segments']==158,'limited MTS selection retained')
        records.append(dict(model=model,segments=selection['selected_segments'],nodes=selection['nodes'],
                            rows=len(report['rows']),covered_fraction=report['covered_fraction']))
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'integration dependencies unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=records,
        mapped_component_cases=cases,independent_sum_relative_error=maximum,original_gate=GATE,
        no_whole_cell_convergence_claim=True,no_source_replacement=True))
    print('independent segment integration and control audit passed',maximum,flush=True)


if __name__=='__main__':
    main()

