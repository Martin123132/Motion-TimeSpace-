from common import *
from controlled_sources_v2 import ControlledPhaseSource
from probe_metric_source import capture
from native_time import CommonCarrierFibre, correlated, BRANCHES
from decompose_stress_balance import balances
from correlated_source import full_endpoint
from scipy.sparse import block_diag, csc_matrix, diags
from scipy.sparse.linalg import splu
import numpy as np


def coefficient(packet, curves, row_norm, columns, massless, efold):
    dimension = len(packet['units'])
    compact = packet['inverse'].shape[-1]
    physical = block_diag((csc_matrix(packet['physical_core']), diags(packet['physical_tail'])), format='csc')
    mono, dipole, quad = massless
    answers = []
    for control in ('fine', 'interpolation-coarse', 'step-coarse'):
        adjoint = (curves[control](efold)*row_norm[:, :, None])[columns]
        branches = []
        for branch in range(2):
            inverse = block_diag((csc_matrix(packet['inverse'][branch]), diags(np.ones(dimension-compact))), format='csc')
            endpoint = full_endpoint(packet['endpoint'][branch], packet['remote_keys'], packet['remote_stream'],
                                     float(packet['remote_endpoint']), dimension)
            covectors = physical.T @ (inverse.T @ splu(endpoint).solve(adjoint[:, branch].T, trans='T'))
            branches.append(covectors[mono]-covectors[quad]*packet['units'][mono]/packet['units'][quad])
        answers.append(branches)
    return np.array(answers)


def stress_pairs(case, packet, theta, massless):
    system = case.system
    efold = float(packet['efold'])
    results = {}
    case.restore_window()
    try:
        for branch, name in enumerate(BRANCHES):
            for column in range(2):
                results[(branch, column, 'reference')] = capture(system, efold, packet['native_vectors'][branch, :, column], name, massless)
        frozen = case.owner.frozen(efold)
        physical = correlated(frozen, theta)[0] if case.model == 'heavy' else frozen
        state = np.array([efold, physical['values'][0]/(np.exp(efold)*case.owner.saved.masses[0]), *physical['values'][1:]])
        with CommonCarrierFibre(system) as fibre:
            fibre.chart_angle = float(packet['carrier'])
            fibre.carrier_rate = float(packet['carrier_rate'])
            fibre.common_carrier = True
            fibre.install(state, theta)
            for branch, name in enumerate(BRANCHES):
                for column in range(2):
                    results[(branch, column, 'retained')] = capture(system, efold, packet['native_vectors'][branch, :, column], name, massless)
    finally:
        case.restore_window()
    records = []
    pieces = np.empty((2, 2, 4))
    for branch, name in enumerate(BRANCHES):
        for column in range(2):
            first, second = [results[(branch, column, side)] for side in ('reference', 'retained')]
            for side, result in zip(('reference', 'retained'), (first, second)):
                require(np.array_equal(result[1], packet[side+'_background']), 'same independent captured background')
                require(np.array_equal(result[2], packet[side+'_rates'][branch, :, column]), 'same independently captured native rates')
            parts, errors, primitive = balances(first[0], second[0], name, system.wave, system.units[massless[0]])
            require(np.max(errors)<ALGEBRA, 'explicit scalar-defect stress balance')
            pieces[branch, column] = list(map(float, parts))
            records.append(dict(branch=name, column=column, reference=first[0], retained=second[0],
                                wave=system.wave, unit=float(system.units[massless[0]]),
                                parts=pieces[branch, column].tolist(), balance_errors=errors, primitive=primitive))
    return pieces, records


def run(mode):
    modest()
    freeze_path = ROOT/'freeze-01/result.json'
    frozen = read(freeze_path)
    require(frozen['passed'], 'frozen segment quadrature')
    for path, checksum in frozen['inputs'].items():
        require(digest(path)==checksum, 'frozen inherited input')
    output = ROOT/'points-01'
    output.mkdir(exist_ok=True)
    destination = output/(mode+'-result.json')
    require(not destination.exists(), 'no rerun completed batch')
    if mode=='remaining':
        require(read(STAGE/'probe-audit/result.json')['passed'], 'independent segment probe accepted')
    consumed = {str(freeze_path):digest(freeze_path)}
    reports = []
    for selection in frozen['reports']:
        model = selection['model']
        require(digest(selection['path'])==selection['sha256'], 'frozen grid bytes')
        grid = load(selection['path'])
        consumed[selection['path']] = selection['sha256']
        probes = sorted({segment['indices'][ordinal] for segment in selection['segments'] for ordinal in (0,16,32)})
        indices = probes if mode=='probe' else [index for index in range(selection['nodes']) if index not in probes]
        case = ControlledPhaseSource(model, 'segments-'+mode)
        layout_path = owned(COMPLETED/LABEL/'source-even-01'/f'{model}-00-source.json')
        massless = read(layout_path)['layout']['massless_all']
        attribution_path = REFINEMENT/LABEL/'source-attribution-01'/f'{model}-attribution.npz'
        attribution = load(attribution_path)
        columns = attribution['columns'].astype(int)
        consumed[str(layout_path)] = digest(layout_path)
        consumed[str(attribution_path)] = digest(attribution_path)
        reused = {entry['index']:entry for entry in selection['reuse']}
        for index in indices:
            guard()
            result_path = output/f'{model}-{index:03d}-flow-result.json'
            require(not result_path.exists(), 'inspect partial batch rather than retry')
            if index in reused:
                report, phase = reused[index]['source'], reused[index]['phase']
                for entry in (report,phase):
                    require(entry['passed'] and digest(entry['path'])==entry['sha256'], 'exact old endpoint reuse')
                was_reused = True
            else:
                report = case.sample(index, grid, output)
                phase = case.phase_control(index, grid, output, report, True)
                was_reused = False
            packet, phase_packet = load(report['path']), load(phase['path'])
            require(float(packet['efold'])==float(grid['efold'][index]), 'same frozen N')
            require(np.array_equal(packet['units'],case.system.units), 'native units fixed')
            consumed[report['path']] = report['sha256']
            consumed[phase['path']] = phase['sha256']
            all_components, all_records, all_coefficients = [], [], []
            for phase_control in ('fine', 'step-coarse'):
                if phase_control=='step-coarse' and model=='heavy':
                    active = {key[4:]:value for key,value in phase_packet.items() if key.startswith('map_')}
                    active.update({key[7:]:value for key,value in phase_packet.items() if key.startswith('native_')})
                    active['units'] = packet['units']
                    theta = float(phase_packet['coarse_phase'])
                else:
                    active = packet
                    theta = float(packet['phase'])
                if phase_control=='step-coarse' and model=='cold':
                    all_components.append(all_components[0].copy())
                    all_records.append(all_records[0])
                    all_coefficients.append(all_coefficients[0].copy())
                    continue
                pieces, primitives = stress_pairs(case, active, theta, massless)
                covector = coefficient(active,case.adjoints,case.row_norm,columns,massless,float(grid['efold'][index]))
                components = np.einsum('abc,bvp->abvcp', covector, pieces)
                all_components.append(components)
                all_records.append(primitives)
                all_coefficients.append(covector)
            target = output/f'{model}-{index:03d}-flow.npz'
            np.savez_compressed(target, components=all_components, coefficients=all_coefficients,
                                efold=grid['efold'][index], massless_slots=massless, columns=columns)
            result = dict(passed=True,model=model,index=index,path=str(target),sha256=digest(target),
                          source=report['path'],source_sha256=report['sha256'],phase=phase['path'],phase_sha256=phase['sha256'],
                          reused_source=was_reused,primitive_records=all_records,
                          no_background_replacement=True,sources=sources())
            write(result_path,result)
            reports.append(dict(model=model,index=index,path=str(result_path),sha256=digest(result_path)))
            print(model,index,'segment flow and paired controls saved',flush=True)
        consumed.update(case.consumed)
    require(all(digest(path)==checksum for path,checksum in consumed.items()), 'consumed evidence unchanged')
    write(destination,dict(passed=True,reports=reports,consumed=consumed,sources=sources(),
                           no_history_solve=True,no_source_replacement=True,unchanged_gates=[ALGEBRA,GATE]))

