from common import *
from fractions import Fraction
from decimal import Decimal, localcontext
import numpy as np


def independent_moments(nodes, weights, left, right):
    with localcontext() as context:
        context.prec = 90
        number = lambda value: Decimal.from_float(float(value))
        start, stop = number(left), number(right)
        width = stop-start
        positions = [(2*number(value)-start-stop)/width for value in nodes]
        normalized_weights = [number(value)*2/width for value in weights]
        previous = [Decimal(1) for value in positions]
        errors = [abs(sum(normalized_weights)-2)]
        current = positions.copy()
        for degree in range(1,len(nodes)):
            integral = sum(weight*value for weight,value in zip(normalized_weights,current))
            errors.append(abs(integral))
            following = [((2*degree+1)*point*value-degree*old)/(degree+1)
                         for point,value,old in zip(positions,current,previous)]
            previous,current = current,following
        return float(max(errors))


def main():
    modest()
    frozen_path = ROOT/'freeze-01/result.json'
    frozen = read(frozen_path)
    output = ROOT/'exact-weights-01'
    output.mkdir(exist_ok=False)
    consumed = {str(frozen_path):digest(frozen_path)}
    reports = []
    for selection in frozen['reports']:
        require(digest(selection['path'])==selection['sha256'],'fixed original nodes')
        consumed[selection['path']]=selection['sha256']
        grid=load(selection['path'])
        segments=[]
        for segment in selection['segments']:
            left,right=map(Fraction,segment['range'])
            selected=grid['efold'][segment['indices']]
            rows=[]
            for original in segment['rules']:
                indices=original['local_indices']
                positions=np.array([float((2*Fraction(float(selected[index]))-left-right)/(right-left)) for index in indices])
                degree=original['count']-1
                matrix=np.polynomial.chebyshev.chebvander(positions,degree).T
                moments=np.array([2/(1-order*order) if order%2==0 else 0. for order in range(degree+1)])
                weights=np.linalg.solve(matrix,moments)*float((right-left)/2)
                error=independent_moments(selected[indices],weights,*segment['range'])
                require(error<ALGEBRA and np.min(weights)>0,'independent exact-interval Legendre moments')
                old_error=independent_moments(selected[indices],original['weights'],*segment['range'])
                rows.append(dict(count=original['count'],local_indices=indices,weights=weights.tolist(),
                                 independent_legendre_error=error,prior_weights_exact_interval_error=old_error,
                                 relative_l1_weight_change=float(np.sum(abs(weights-np.array(original['weights'])))/float(right-left))))
            segments.append(dict(segment=segment['segment'],range=segment['range'],indices=segment['indices'],rules=rows))
        reports.append(dict(model=selection['model'],segments=segments))
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,
          fixed_nodes=True,weights_derived_without_source_values=True,
          reason='normalize to the exact binary endpoint midpoint, not its rounded floating midpoint; independently verify Legendre moments',
          unchanged_gates=[ALGEBRA,GATE]))
    print('exact-interval weights verified independently; original floating weights preserved',flush=True)


if __name__=='__main__':
    main()

