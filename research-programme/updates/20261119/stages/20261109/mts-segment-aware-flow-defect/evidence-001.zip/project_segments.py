from common import *
from math import fsum
import numpy as np


def contract(weights, values):
    flattened=values.reshape(len(weights),-1)
    return np.array([fsum(float(weight)*float(value) for weight,value in zip(weights,flattened[:,column]))
                     for column in range(flattened.shape[1])]).reshape(values.shape[1:])


def main():
    modest()
    require(read(STAGE/'full-audit/result.json')['passed'],'independent source algebra accepted')
    frozen_path=ROOT/'freeze-01/result.json'
    weights_path=ROOT/'exact-weights-01/result.json'
    frozen,weights=read(frozen_path),read(weights_path)
    require(weights['passed'],'exact interval quadrature verified')
    output=ROOT/'projection-01'
    output.mkdir(exist_ok=False)
    consumed={str(frozen_path):digest(frozen_path),str(weights_path):digest(weights_path),
              str(STAGE/'full-audit/result.json'):digest(STAGE/'full-audit/result.json')}
    reports=[]
    for selection in frozen['reports']:
        model=selection['model']
        grid=load(selection['path'])
        controls=[]
        for index in range(selection['nodes']):
            path=ROOT/'points-01'/f'{model}-{index:03d}-flow-result.json'
            result=read(path)
            require(result['passed'] and digest(result['path'])==result['sha256'],'completed flow node')
            consumed[str(path)]=digest(path)
            consumed[result['path']]=result['sha256']
            packet=load(result['path'])
            require(float(packet['efold'])==float(grid['efold'][index]),'exact frozen point')
            controls.append(packet['components'])
        controls=np.array(controls)
        original_path=DIRECT_SOURCE/LABEL/'metric-projection-01'/f'{model}-metric-projection.npz'
        original=load(original_path)
        consumed[str(original_path)]=digest(original_path)
        rule_set=next(item for item in weights['reports'] if item['model']==model)
        integrals=[]
        for segment in rule_set['segments']:
            values=controls[segment['indices']]
            integrals.append([contract(rule['weights'],values[rule['local_indices']]) for rule in segment['rules']])
        integrals=np.array(integrals)
        fine=integrals[:,2,0,0,:,0]
        middle=integrals[:,1,0,0,:,0]
        coarse=integrals[:,0,0,0,:,0]
        delta=fine-middle
        older_delta=middle-coarse
        current=integrals[:,2,0,0,:,1]
        phase=integrals[:,2,1,0,:,0]-fine
        cross=integrals[:,2,1,0,:,1]-current
        adjoint_interp=integrals[:,2,0,1,:,0]-fine
        adjoint_step=integrals[:,2,0,2,:,0]-fine
        numerical=abs(delta)+abs(current)+abs(phase)+abs(cross)+abs(adjoint_interp)+abs(adjoint_step)
        budget=original['budget']
        reference=original['reference_scale']
        target=output/(model+'-segments.npz')
        np.savez_compressed(target,controls=controls,integrals=integrals,fine=fine,delta=delta,older_delta=older_delta,
            current=current,phase=phase,cross=cross,adjoint_interp=adjoint_interp,adjoint_step=adjoint_step,
            numerical=numerical,budget=budget,reference_scale=reference)
        rows=[]
        for ordinal,segment in enumerate(rule_set['segments']):
            for branch,name in enumerate(('gr','poisson')):
                for channel_index,channel in enumerate(('Pi','delta_massless')):
                    for part_index,part in enumerate(('native_conservative','slow_flow','heavy_flow','residual')):
                        key=(ordinal,branch,channel_index,part_index)
                        denominator=budget[branch,channel_index]
                        previous=float(older_delta[key])
                        recent=float(delta[key])
                        rows.append(dict(segment=segment['segment'],branch=name,channel=channel,part=part,
                            fine=float(fine[key]),fine_over_reference=float(fine[key]/reference[branch,channel_index]),
                            difference_17_9_over_budget=previous/denominator,difference_33_17_over_budget=recent/denominator,
                            contraction=abs(recent/previous) if previous!=0 else None,
                            current_over_budget=float(current[key]/denominator),phase_over_budget=float(phase[key]/denominator),
                            cross_over_budget=float(cross[key]/denominator),
                            adjoint_interpolation_over_budget=float(adjoint_interp[key]/denominator),
                            adjoint_step_over_budget=float(adjoint_step[key]/denominator),
                            numerical_sum_over_budget=float(numerical[key]/denominator),
                            selected_segment_control_pass=bool(numerical[key]/denominator<GATE)))
        reports.append(dict(model=model,path=str(target),sha256=digest(target),rows=rows,
            covered_fraction=selection['covered_width']/selection['cell_width'],
            selected_segments=selection['selected_segments'],overlapping_segments=selection['overlapping_segments']))
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'projection evidence unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,
          axis_order='integrals: segment, quadrature(9/17/33), phase, adjoint, branch, current(fine/delta), channel, part',
          quadrature_measure='dN',no_whole_cell_convergence_claim=True,no_source_replacement=True,
          numerical_sums_are_refinement_indicators_not_rigorous_enclosures=True,unchanged_gates=[ALGEBRA,GATE]))
    for report in reports:
        focus=[row for row in report['rows'] if row['part']==('heavy_flow' if report['model']=='heavy' else 'slow_flow')]
        print(report['model'],'selected flow refinement/budget max',max(abs(row['difference_33_17_over_budget']) for row in focus),
              'controls max',max(row['numerical_sum_over_budget'] for row in focus),flush=True)


if __name__=='__main__':
    main()

