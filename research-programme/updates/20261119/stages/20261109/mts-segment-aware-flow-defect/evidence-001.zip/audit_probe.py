from segment_audit import audit

audit('probe')

