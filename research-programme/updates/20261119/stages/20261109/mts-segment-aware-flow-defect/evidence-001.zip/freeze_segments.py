from common import *
from response_support import DenseHistory
from fractions import Fraction
import numpy as np


def rule(nodes, left, right):
    center = (left + right) / 2
    radius = (right - left) / 2
    normalized = (nodes - center) / radius
    matrix = np.polynomial.chebyshev.chebvander(normalized, len(nodes) - 1).T
    moments = np.array([2 / (1 - degree * degree) if degree % 2 == 0 else 0.
                        for degree in range(len(nodes))])
    weights = np.linalg.solve(matrix, moments) * radius
    error = float(np.max(abs(matrix @ (weights / radius) - moments)))
    require(error < ALGEBRA and np.min(weights) > 0, 'positive interpolatory moments')
    return weights, error


def derivative_check(packet, segment, coordinate):
    width = float(packet['segment_end'][segment] - packet['segment_start'][segment])
    local = float((coordinate - packet['segment_start'][segment]) / width)
    values = np.zeros(5)
    rates = np.zeros(5)
    for number, coefficient in enumerate(reversed(packet['coefficients'][segment])):
        values += coefficient
        if number % 2 == 0:
            rates = rates * local + values
            values *= local
        else:
            rates = rates * (1 - local) - values
            values *= 1 - local
    values += packet['segment_initial'][segment]
    errors = []
    for component in range(5):
        polynomial = [Fraction(0)]
        for number, coefficient in enumerate(reversed(packet['coefficients'][segment, :, component])):
            polynomial[0] += Fraction(float(coefficient))
            if number % 2 == 0:
                polynomial = [Fraction(0)] + polynomial
            else:
                polynomial = polynomial + [Fraction(0)]
                for degree in range(len(polynomial) - 1, 0, -1):
                    polynomial[degree] -= polynomial[degree - 1]
        polynomial[0] += Fraction(float(packet['segment_initial'][segment, component]))
        point = Fraction(local)
        exact_value = sum(value * point ** degree for degree, value in enumerate(polynomial))
        exact_rate = sum(degree * value * point ** (degree - 1)
                         for degree, value in enumerate(polynomial) if degree)
        value_scale = sum(abs(value * point ** degree) for degree, value in enumerate(polynomial))
        rate_scale = sum(abs(degree * value * point ** (degree - 1))
                         for degree, value in enumerate(polynomial) if degree)
        errors.extend([float(abs(Fraction(float(values[component])) - exact_value) /
                             max(value_scale, Fraction(1, 10**80))),
                       float(abs(Fraction(float(rates[component])) - exact_rate) /
                             max(rate_scale, Fraction(1, 10**80)))])
    return max(errors)


def main():
    modest()
    inputs = verify_inputs()
    output = ROOT / 'freeze-01'
    output.mkdir(parents=True, exist_ok=False)
    index_path = REFINEMENT / LABEL / 'points-01/refined-cell03-result.json'
    old_index = read(index_path)
    inputs[str(index_path)] = digest(index_path)
    inventory_path = DIRECT_SOURCE / 'DENSE-SEGMENT-INVENTORY.json'
    inventory = read(inventory_path)
    inputs[str(inventory_path)] = digest(inventory_path)
    histories_path = THIRD_CELL / LABEL / 'history-02/result.json'
    histories = read(histories_path)
    inputs[str(histories_path)] = digest(histories_path)
    reports = []
    for item in inventory['reports']:
        model = item['model']
        require(digest(item['path']) == item['sha256'], 'retained dense background bytes')
        inputs[item['path']] = item['sha256']
        packet = load(item['path'])
        left, right = item['range']
        intersections = np.flatnonzero((packet['segment_end'] > left) & (packet['segment_start'] < right))
        offsets = [0, len(intersections)//3, 2*len(intersections)//3, len(intersections)-1] if model == 'heavy' else list(range(len(intersections)))
        selected = intersections[offsets]
        old = next(value for value in old_index['reports'] if value['model'] == model)
        old_lookup = {node['efold']: ordinal for ordinal, node in enumerate(old['nodes'])}
        history_entry = next(value for value in histories['reports'] if value['model'] == model and value['control'] == 'fine')
        require(digest(history_entry['index']) == history_entry['sha256'], 'saved fine current history')
        inputs[history_entry['index']] = history_entry['sha256']
        history = DenseHistory(history_entry['index'])
        segments = []
        coordinates = []
        derivative_error = 0.
        for segment in selected:
            start = max(left, float(packet['segment_start'][segment]))
            stop = min(right, float(packet['segment_end'][segment]))
            center, radius = (start+stop)/2, (stop-start)/2
            nodes = center - radius*np.cos(np.linspace(0, np.pi, 33))
            nodes[0], nodes[-1] = start, stop
            if start == float(packet['segment_start'][segment]) and segment > 0:
                nodes[0] = np.nextafter(start, stop)
            require(np.all(np.diff(nodes) > 0), 'strictly ordered segment nodes')
            native_indices = np.searchsorted(packet['segment_end'], nodes, side='left')
            require(np.all(native_indices == segment), 'native one-sided segment ownership')
            rules = []
            for count in (9, 17, 33):
                stride = 32 // (count - 1)
                weights, error = rule(nodes[::stride], start, stop)
                rules.append(dict(count=count, local_indices=list(range(0, 33, stride)), weights=weights.tolist(), moment_error=error))
            for coordinate in nodes:
                derivative_error = max(derivative_error, derivative_check(packet, int(segment), float(coordinate)))
            indices = list(range(len(coordinates), len(coordinates)+33))
            coordinates.extend(nodes.tolist())
            segments.append(dict(segment=int(segment), range=[start, stop], indices=indices, rules=rules,
                                 left_shift=float(nodes[0]-start), native_left_segment_at_shared_boundary=True))
        require(derivative_error < ALGEBRA, 'independent polynomial differentiation')
        coordinates = np.array(coordinates)
        require(coordinates[0] == left and coordinates[-1] == right, 'same physical cell endpoints')
        require(np.all(np.diff(coordinates)>0), 'unique global points in segment order')
        phases = []
        reused = []
        for ordinal, coordinate in enumerate(coordinates):
            phase = history.state(float(coordinate))[0]
            old_ordinal = old_lookup.get(float(coordinate))
            if old_ordinal is not None:
                node = old['nodes'][old_ordinal]
                require(abs(phase-node['theta']) < ALGEBRA, 'same saved phase for exact reused node')
                phase = node['theta']
                reused.append(dict(index=ordinal, source=node, phase=old['phase_controls'][old_ordinal]))
            phases.append(phase)
        target = output / (model+'-grid.npz')
        np.savez_compressed(target, efold=coordinates, phase=phases, jacobian=np.ones(len(coordinates)))
        reports.append(dict(model=model, path=str(target), sha256=digest(target), segments=segments,
                            nodes=len(coordinates), reuse=reused, overlapping_segments=len(intersections),
                            selected_segments=len(selected), covered_width=sum(value['range'][1]-value['range'][0] for value in segments),
                            cell_width=right-left, polynomial_derivative_error=derivative_error,
                            background_path=item['path'], background_sha256=item['sha256']))
        print(model, len(coordinates), 'frozen nodes;', len(reused), 'reused;', derivative_error, 'derivative error', flush=True)
    require(all(digest(path)==checksum for path, checksum in inputs.items()), 'freeze inputs unchanged')
    write(output/'result.json', dict(passed=True, inputs=inputs, sources=sources(), reports=reports,
          endpoint_policy='right-sided nextafter at each internal segment left edge; weights integrate the full unshifted segment',
          quadrature_coordinate='N=ln(a), no phase Jacobian', history_reintegrations=0,
          no_source_replacement=True, selected_segments_only=True, unchanged_gates=[ALGEBRA,GATE]))


if __name__ == '__main__':
    main()

