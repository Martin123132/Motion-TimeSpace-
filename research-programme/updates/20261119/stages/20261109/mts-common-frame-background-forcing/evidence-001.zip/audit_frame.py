from common import *
import numpy as np
import psutil


def relative(left,right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.linalg.norm(right),1e-80))


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed,accepted,verified={},{},{}
    rows=[]
    counts=dict(nodes=0,branches=0,carrier_checks=0,pullback_checks=0,readout_values=0,terminal_channels=0)

    def hashes(records):
        for path,seal in records.items():
            guard()
            if path not in verified:
                verified[path]=digest(path)
            require(verified[path]==seal,'source bytes '+path)
            consumed[path]=seal

    def accept(path):
        report=read(path)
        require(report['passed'],'accepted result '+str(path))
        for key in ('inputs','sources','consumed'):
            hashes(report.get(key,{}))
        accepted[str(path)]=digest(path)
        return report

    for label in ('half','balanced','double'):
        root=STAGE/label
        native=accept(root/'source-02/result.json')
        reconstructed=accept(root/'bridge-01/result.json')
        require(len(reconstructed['records'])==18,'paired reconstruction coverage')
        for model in ('heavy','cold'):
            nodes=next(item['nodes'] for item in native['reports'] if item['model']==model)
            require([node['index'] for node in nodes]==list(range(0,33,4)),'nine original epochs')
            for node in nodes:
                report=accept(root/'source-02'/f"{model}-{node['index']:02d}-result.json")
                require(report==node,'matrix uses exact node report')
                hashes({report['path']:report['sha256']})
                packet=load(report['path'])
                record=next(item for item in reconstructed['records'] if item['model']==model and item['index']==node['index'])
                hashes({record['path']:record['sha256']})
                bridge=load(record['path'])
                dimension=len(bridge['units'])
                require(packet['retained_vectors'].shape==(2,dimension,6),'full retained vector shape')
                require(bridge['bridge'].shape==bridge['total'].shape==bridge['background'].shape==(2,dimension,6),'complete bridge arrays')
                require(all(np.isfinite(array).all() for array in packet.values()),'finite native packet')
                require(all(np.isfinite(array).all() for array in bridge.values()),'finite bridge packet')
                require(relative(bridge['background'],packet['background_forcing'])<ALGEBRA,'reused background rates')
                require(np.array_equal(packet['reference_readouts']-packet['retained_readouts'],packet['readout_mismatch']),
                        'readout gap not inferred from generator')
                require(record['readout_not_added_to_old_prediction'],'no double counting prior output maps')
                require(report['source_at_original_epochs_only'] and not report['background_mismatch_propagated'],'pointwise source scope')
                for branch,check in enumerate(record['checks']):
                    old_check=report['checks'][branch]
                    require(max(old_check['core_map'],old_check['tail_map'],old_check['map_inverse'])<ALGEBRA,'native map gate')
                    require(len(check['carrier_identity_all_vectors'])==len(check['pullback_all_vectors'])==6,'all vector gates retained')
                    require(max(check['carrier_identity_all_vectors'])<ALGEBRA and max(check['pullback_all_vectors'])<GATE,
                            'unchanged algebra and numerical gates')
                    require(max(check['identity_at_rate_scale'])<ALGEBRA,'common-frame source identity')
                    require(max(abs(np.array(check['pullback_all_vectors'])-old_check['native_pullback']))<ALGEBRA,
                            'reconstructed same native pullback')
                    scale=np.linalg.norm(packet['current'][branch])
                    measures=dict(background_per_state=np.linalg.norm(bridge['background'][branch,:,0])/scale,
                        bridge_per_state=np.linalg.norm(bridge['bridge'][branch,:,0])/scale,
                        total_per_state=np.linalg.norm(bridge['total'][branch,:,0])/scale,
                        remaining_feedback_per_state=np.linalg.norm(packet['feedback_residual'][branch])/scale)
                    require(all(abs(float(value)-check[key])<=ALGEBRA*max(abs(float(value)),1e-80) for key,value in measures.items()),
                            'reported source magnitudes')
                    require(abs(check['background_per_state']-report['background_source_per_state'][branch])
                            <=ALGEBRA*max(check['background_per_state'],1e-80),'native and audit source magnitude')
                    rows.append(dict(label=label,model=model,index=node['index'],efold=record['efold'],**check))
                    counts['branches']+=1
                    counts['carrier_checks']+=6
                    counts['pullback_checks']+=6
                if node['index']==32:
                    prediction_path=owned(RESPONSE_STAGE/label/'comparison-02'/f'{model}-comparison.npz')
                    hashes({str(prediction_path):digest(prediction_path)})
                    scale=load(prediction_path)['reference_scale']
                    expected=packet['readout_mismatch'][:,0]/scale
                    require(relative(expected,bridge['terminal_readout_fraction'])<ALGEBRA,'unchanged reference-output normalization')
                    require(np.array_equal(expected,np.array(record['terminal_readout_fraction'])),'terminal report values')
                    counts['terminal_channels']+=20
                else:
                    require(bridge['terminal_readout_fraction'].size==0,'no terminal interpretation at interior nodes')
                counts['nodes']+=1
                counts['readout_values']+=120
    require(counts==dict(nodes=54,branches=108,carrier_checks=648,pullback_checks=648,readout_values=6480,terminal_channels=120),
            'complete source and verification matrix')
    for path in STAGE.rglob('*freeze.json'):
        freeze=read(path)
        for name in ('inputs','sources','consumed'):
            hashes(freeze.get(name,{}))
    failures=[]
    receipts=list(STAGE.glob('*.start.json'))
    require(len(receipts)==9,'all stage numerical jobs accounted for')
    for path in receipts:
        start=read(path)
        hashes({start['source_path']:start['source_sha256']})
        if path.name=='audit-01.start.json':
            require(start['pid']==os.getpid(),'audit owns its current receipt')
            continue
        end=read(Path(str(path).replace('.start.json','.end.json')))
        require(all(start[key]==end[key] for key in ('pid','created','command')),'same worker identity')
        expected_exit=1 if path.name=='probe-half-01.start.json' else 0
        require(end['exit_code']==expected_exit,'expected process exit')
        if psutil.pid_exists(start['pid']):
            occupant=psutil.Process(start['pid'])
            created=datetime.fromisoformat(start['created'].replace('Z','+00:00')).timestamp()
            require(abs(occupant.create_time()-created)>1,'old owned worker has exited')
        if expected_exit:
            failure=STAGE/'probe-half-01.stderr.log'
            require('FileNotFoundError' in failure.read_text(encoding='utf-8') and 'contexts-heavy' in failure.read_text(encoding='utf-8'),
                    'inspected pre-physics directory setup failure')
            failures.append(dict(path=str(failure),sha256=digest(failure),exit_code=expected_exit))
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode cache')
    summary=[]
    for label in ('half','balanced','double'):
        for model in ('heavy','cold'):
            selected=[item for item in rows if item['label']==label and item['model']==model]
            result=read(STAGE/label/'bridge-01/result.json')
            terminal=next(item for item in result['records'] if item['model']==model and item['index']==32)
            summary.append(dict(label=label,model=model,
                background_range=[min(item['background_per_state'] for item in selected),max(item['background_per_state'] for item in selected)],
                bridge_range=[min(item['bridge_per_state'] for item in selected),max(item['bridge_per_state'] for item in selected)],
                background_over_bridge_min=min(item['background_over_bridge'] for item in selected),
                remaining_feedback_max=max(item['remaining_feedback_per_state'] for item in selected),
                pullback_max=max(max(item['pullback_all_vectors']) for item in selected),
                carrier_identity_max=max(max(item['carrier_identity_all_vectors']) for item in selected),
                identity_rate_max=max(max(item['identity_at_rate_scale']) for item in selected),
                identity_forcing_max=max(max(item['identity_at_forcing_scale']) for item in selected),
                terminal_readout_fraction_max=float(np.max(np.abs(terminal['terminal_readout_fraction'])))))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,records=rows,summary=summary,failed_attempts_preserved=failures,
        original_bank_grids_tolerances_unchanged=True,bridge_retained_not_assumed_zero=True,
        no_new_native_calls_for_bridge=True,background_propagated=False,continuum_bound=False,
        strict_prior_feedback_source_control_resolved=False,github_actions=False))
    print(json.dumps(dict(counts=counts,summary=summary),indent=2),flush=True)


if __name__=='__main__':
    main()

