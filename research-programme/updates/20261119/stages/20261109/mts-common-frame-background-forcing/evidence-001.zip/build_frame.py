from common import *
from frame_source_v2 import Case


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'source-02'
    output.mkdir(parents=True,exist_ok=True)
    write(output/'matrix-freeze.json',dict(inputs=inputs,sources=sources(),indices=list(range(0,33,4)),
        models=['heavy','cold'],algebra=ALGEBRA,gate=GATE,retained_source_and_readout_distinguished=True))
    reports=[]
    for model in ('heavy','cold'):
        case=Case(model,'source-02/matrix-'+model)
        nodes=[]
        for index in range(0,33,4):
            guard()
            path=output/f'{model}-{index:02d}-result.json'
            if path.exists():
                report=read(path)
                require(report['passed'] and digest(report['path'])==report['sha256'],'reuse only qualified node')
                for source,seal in {**report['sources'],**report['consumed']}.items():
                    require(digest(source)==seal,'reused source ownership')
            else:
                require(not (output/f'{model}-{index:02d}-background.npz').exists(),'partial node needs inspection')
                report=case.node(index,output)
            nodes.append(report)
        reports.append(dict(model=model,nodes=nodes))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,
        common_native_carrier=True,background_source_not_propagated=True))


if __name__=='__main__':
    main()

