from common import *
from frame_source_v2 import Case


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'source-02'
    output.mkdir(parents=True,exist_ok=False)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),algebra=ALGEBRA,gate=GATE,
        probe_index=16,independent_vectors=4,common_carrier=True,source_and_readout_separate=True))
    reports=[]
    for model in ('heavy','cold'):
        case=Case(model,'source-02/contexts-'+model)
        reports.append(case.node(16,output))
    write(ROOT/'probe-02-result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports))


if __name__=='__main__':
    main()



