from common import *
from frame_source_v2 import frames, to_native, to_retained, native_map_rate, relative, BRANCHES
from correlated_source import CorrelatedSource
from accumulated_support_v2 import retained_checked
import numpy as np


def main():
    modest()
    output = ROOT / 'bridge-01'
    output.mkdir(exist_ok=False)
    inputs = verify_inputs()
    source_report = read(ROOT / 'source-02/result.json')
    require(source_report['passed'], 'accepted native sources')
    consumed = {str(ROOT / 'source-02/result.json'): digest(ROOT / 'source-02/result.json')}
    frozen_path = owned(COMPLETED / LABEL / 'source-even-01/freeze.json')
    frozen_bank = read(frozen_path)
    consumed[str(frozen_path)] = digest(frozen_path)
    write(output / 'freeze.json', dict(inputs=inputs, sources=sources(), algebra=ALGEBRA, gate=GATE,
        indices=list(range(0,33,4)), original_native_evaluations_reused=True))
    records = []
    for model in ('heavy', 'cold'):
        owner = CorrelatedSource(model)
        source, bank, leading, paths = retained_checked(model)
        consumed.update(paths)
        consumed.update(owner.consumed)
        reference = frozen_bank['metadata'][model]['reference']
        units_list = []
        for entry in reference:
            require(digest(entry['packet']) == entry['sha256'], 'original normalization ownership')
            consumed[entry['packet']] = entry['sha256']
            with np.load(entry['packet']) as packet:
                units_list.append(packet['units'].copy())
                require(abs(float(packet['wave']) / WAVE - 1) < ALGEBRA, 'original reference wavelength')
        units = units_list[0]
        require(np.array_equal(units,units_list[1]) and np.all(units>0), 'same fixed units in both branches')
        prediction_path = owned(RESPONSE_STAGE / LABEL / 'comparison-02' / f'{model}-comparison.npz')
        prediction = load(prediction_path)
        consumed[str(prediction_path)] = digest(prediction_path)
        nodes = next(item['nodes'] for item in source_report['reports'] if item['model']==model)
        require([item['index'] for item in nodes] == list(range(0,33,4)), 'complete saved node panel')
        for report in nodes:
            guard()
            index = report['index']
            ordinal = index//2
            for path, seal in {**report['sources'], **report['consumed']}.items():
                require(digest(path)==seal, 'native source provenance')
            require(digest(report['path'])==report['sha256'], 'native packet bytes')
            consumed[report['path']] = report['sha256']
            saved = load(report['path'])
            paths = [owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-source.json'),
                     owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-mean.npz'),
                     owned(COMPLETED/LABEL/'forcing-02'/f'{model}-{index:02d}-forcing.npz')]
            consumed.update({str(path):digest(path) for path in paths})
            frozen,node,cached = read(paths[0]),load(paths[1]),load(paths[2])
            require(float(saved['efold'])==frozen['efold']==float(bank['efold'][ordinal]), 'unchanged saved epoch')
            require(np.array_equal(saved['current'],cached['state']+saved['first_response']+saved['second_response']),
                    'current state is the saved original mode plus existing corrections')
            frame = frames(owner,frozen,float(saved['theta']),float(saved['carrier']),
                           float(saved['carrier_rate']),units,node,cached)
            bridge,total,recomputed,basis_rates,checks = [],[],[],[],[]
            for branch,entry in enumerate(frame['branches']):
                vectors = saved['retained_vectors'][branch]
                native = saved['native_vectors'][branch]
                require(vectors.shape==(len(units),6) and np.isfinite(vectors).all(), 'full hierarchy and six probes')
                require(np.array_equal(vectors[:,0],saved['current'][branch])
                        and np.array_equal(vectors[:,1],saved['second_response'][branch]), 'probe identities')
                map_error = relative(to_native(frame,entry,vectors),native)
                require(map_error<ALGEBRA, 'same map reconstructed without native reevaluation')
                rate = native_map_rate(frame,entry,vectors,native)
                ret_pull = to_retained(frame,entry,saved['retained_rates'][branch]-rate)
                ref_pull = to_retained(frame,entry,saved['reference_rates'][branch]-rate)
                analytic = entry['mean']@vectors+entry['endpoint_lu'].solve(entry['numerator']@vectors)
                defect = ret_pull-analytic
                whole = ref_pull-analytic
                background = to_retained(frame,entry,saved['reference_rates'][branch]-saved['retained_rates'][branch])
                residual = entry['endpoint_lu'].solve(entry['numerator']@saved['second_response'][branch])
                require(relative(background,saved['background_forcing'][branch])<ALGEBRA, 'same background source')
                require(relative(residual,saved['feedback_residual'][branch])<ALGEBRA, 'same remaining feedback')
                delta = np.zeros_like(native)
                if model=='heavy':
                    slots = frozen['layout']['heavy']
                    raw = native[slots]*units[slots,None]
                    delta[slots] = (float(saved['carrier_rate'])-float(saved['local_carrier_rate']))*np.stack([-raw[1],raw[0]])/units[slots,None]
                carrier_errors = [relative(saved['retained_rates'][branch,:,column],
                                           saved['local_carrier_rates'][branch,:,column]+delta[:,column])
                                  for column in range(6)]
                pullback_errors = [relative(ret_pull[:,column],analytic[:,column]) for column in range(6)]
                require(max(carrier_errors)<ALGEBRA and max(pullback_errors)<GATE, 'unchanged carrier and pullback gates')
                closure = whole-background-defect
                rate_scale = np.maximum(np.maximum(np.linalg.norm(ref_pull,axis=0),np.linalg.norm(ret_pull,axis=0)),1e-80)
                forcing_scale = np.maximum(np.maximum(np.linalg.norm(whole,axis=0),
                                          np.linalg.norm(background,axis=0)+np.linalg.norm(defect,axis=0)),1e-80)
                closure_rate = np.linalg.norm(closure,axis=0)/rate_scale
                closure_forcing = np.linalg.norm(closure,axis=0)/forcing_scale
                require(float(closure_rate.max())<ALGEBRA, 'common-frame identity at operator arithmetic scale')
                state_norm = max(float(np.linalg.norm(saved['current'][branch])),1e-80)
                checks.append(dict(branch=BRANCHES[branch],map_reconstruction=map_error,
                    carrier_identity_all_vectors=carrier_errors,pullback_all_vectors=pullback_errors,
                    identity_at_rate_scale=closure_rate.tolist(),identity_at_forcing_scale=closure_forcing.tolist(),
                    background_per_state=float(np.linalg.norm(background[:,0])/state_norm),
                    bridge_per_state=float(np.linalg.norm(defect[:,0])/state_norm),
                    total_per_state=float(np.linalg.norm(whole[:,0])/state_norm),
                    remaining_feedback_per_state=float(np.linalg.norm(residual)/state_norm),
                    background_over_bridge=float(np.linalg.norm(background[:,0])/max(np.linalg.norm(defect[:,0]),1e-80))))
                bridge.append(defect)
                total.append(whole)
                recomputed.append(background)
                basis_rates.append(rate)
            require(np.array_equal(saved['reference_readouts']-saved['retained_readouts'],saved['readout_mismatch']),
                    'separate readout source')
            terminal = saved['readout_mismatch'][:,0]/prediction['reference_scale'] if index==32 else np.empty((0,))
            target = output/f'{model}-{index:02d}-bridge.npz'
            np.savez_compressed(target,units=units,bridge=bridge,total=total,background=recomputed,native_map_rate=basis_rates,
                                terminal_readout_fraction=terminal)
            records.append(dict(model=model,index=index,efold=float(saved['efold']),checks=checks,
                path=str(target),sha256=digest(target),terminal_readout_fraction=terminal.tolist(),
                readout_not_added_to_old_prediction=True))
            print(LABEL,model,index,'background/bridge',[(item['background_per_state'],item['bridge_per_state']) for item in checks],flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()), 'inputs unchanged after reconstruction')
    write(output/'result.json',dict(passed=True,inputs=inputs,consumed=consumed,sources=sources(),records=records,
        native_evaluations_reused=True,operator_identity_keeps_bridge=True,background_propagated=False,
        forcing_relative_identity_is_diagnostic_not_gate=True,original_bank_grids_tolerances_unchanged=True))


if __name__=='__main__':
    main()

