from common import *
from frame_source import Case


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'source-01'
    output.mkdir(parents=True,exist_ok=False)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),algebra=ALGEBRA,gate=GATE,
        probe_index=16,independent_vectors=4,common_carrier=True,source_and_readout_separate=True))
    reports=[]
    for model in ('heavy','cold'):
        case=Case(model,'source-01/contexts-'+model)
        reports.append(case.node(16,output))
    write(ROOT/'probe-01-result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports))


if __name__=='__main__':
    main()

