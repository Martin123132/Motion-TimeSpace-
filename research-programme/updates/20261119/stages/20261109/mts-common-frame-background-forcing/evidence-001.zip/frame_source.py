from common import *
from feedback_source import fourier, sparse
from accumulated_support_v2 import retained_checked, NAMES
from clock_primitive import KernelBank
from correlated_source import CorrelatedSource
from remainder_source import evaluate_slow, map_defect, physical_map, dense_parts, Directional, parts
from full_metric_math import rows as metric_rows
from matched_cold_fibre import MatchedColdFibre
from matching_source import frozen_source
from physical_energy_map import PhysicalEnergyMap
from adjoint_operator import open_owned
from scipy.sparse import block_diag, diags, eye, csc_matrix
from scipy.sparse.linalg import splu
import ast
import inspect
import math
import numpy as np
import time

BRANCHES=('gr','poisson-spatial')


def sine(value):
    value=Directional.cast(value)
    return Directional(math.sin(value.value),math.cos(value.value)*value.rate)


def cosine(value):
    value=Directional.cast(value)
    return Directional(math.cos(value.value),-math.sin(value.value)*value.rate)


def phase_map_function():
    tree=ast.parse(inspect.getsource(physical_map))
    tree.body[0].name='phase_aware_map'
    count=0
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and isinstance(node.func.value,ast.Name):
            if node.func.value.id=='np' and node.func.attr in ('cos','sin'):
                node.func=ast.Name(id='cosine' if node.func.attr=='cos' else 'sine',ctx=ast.Load())
                count+=1
    require(count==2,'only the two explicit heavy-phase functions differentiated')
    namespace=dict(physical_map.__globals__,sine=sine,cosine=cosine)
    exec(compile(ast.fix_missing_locations(tree),inspect.getfile(physical_map),'exec'),namespace)
    return namespace['phase_aware_map']


PHASE_MAP=phase_map_function()


def relative(left,right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.linalg.norm(right),1e-80))


class CommonCarrierFibre(MatchedColdFibre):
    def phase(self,efold):
        require(abs(efold-self.state[0])<1e-12,'same point for common carrier')
        return self.chart_angle,self.carrier_rate if self.common_carrier else self.mu


def frames(owner,frozen,theta,carrier,carrier_rate,units,node,cached):
    prepared,direct=evaluate_slow(owner,frozen,theta,cached['remote_keys'])
    physical=prepared['physical']
    layout=frozen['layout']
    dimension=len(units)
    compact=layout['size']
    phase_rate=float(prepared['angular'].value)
    values=[Directional(value,rate) for value,rate in zip(physical['values'],prepared['actual_rate'])]
    source=prepared['source']
    base,base_rate=dense_parts(PHASE_MAP(layout,source,frozen['masses'],WAVE,values,Directional(theta,phase_rate)))
    rotation=np.eye(compact)
    rotation_rate=np.zeros_like(rotation)
    if layout['heavy']:
        selected=np.ix_(layout['heavy'],layout['heavy'])
        rotation[selected]=[[np.cos(carrier),np.sin(carrier)],[-np.sin(carrier),np.cos(carrier)]]
        rotation_rate[selected]=carrier_rate*np.array([[-np.sin(carrier),np.cos(carrier)],[-np.cos(carrier),-np.sin(carrier)]])
    mapped=(base@rotation)*units[None,:compact]
    mapped_rate=(base_rate@rotation+base@rotation_rate)*units[None,:compact]
    tail=[]
    tail_rate=[]
    for degree in range(3,193):
        for amount,speed in zip(source['massive'],source['speeds']):
            value,rate=parts(speed*(amount*(2*degree+1)/4)**.5)
            tail.append(value)
            tail_rate.append(rate)
    tail=np.array(tail)*units[layout['core']:]
    tail_rate=np.array(tail_rate)*units[layout['core']:]
    overlap=compact-layout['core']
    physical_frame=block_diag((csc_matrix(mapped),diags(tail[overlap:])),format='csc')
    physical_frame_rate=block_diag((csc_matrix(mapped_rate),diags(tail_rate[overlap:])),format='csc')
    physical_frame.eliminate_zeros()
    physical_frame_rate.eliminate_zeros()
    frame_lu=splu(physical_frame)
    thermal={name:{'value':Directional(item['value'],item['first']),
        'first':Directional(item['first'],item['second']),'second':Directional(item['second'],0.)}
        for name,item in frozen['thermal'].items()}
    metric=metric_rows(layout,fluid=source['fluid'],massive=source['massive'],speeds=source['speeds'],
        external_density=source['density'],external_enthalpy=source['enthalpy'],defect=source['defect'],
        defect_rate=source['defect_first'],sound=thermal['sound']['value'],scale_factor=source['scale'],
        masses=frozen['masses'],wave=WAVE,coordinate=values[0],velocity=values[1],rho=values[2],
        cosine=Directional(np.cos(2*theta),-2*np.sin(2*theta)*phase_rate),
        sine=Directional(np.sin(2*theta),2*np.cos(2*theta)*phase_rate))
    compact_value=fourier(cached['compact_coefficients'],theta,axis=1)
    compact_slow=fourier(cached['compact_slow_coefficients'],theta,axis=1)
    compact_phase=fourier(cached['compact_coefficients'],theta,axis=1,derivative=1)
    scalar=float(fourier(cached['scalar_coefficients'],theta)[0,0])
    scalar_slow=float(fourier(cached['scalar_slow_coefficients'],theta)[0,0])
    scalar_phase=float(fourier(cached['scalar_coefficients'],theta,derivative=1)[0,0])
    maps,_,_=map_defect(physical,theta,prepared['defect'])
    entries=[]
    for branch_index,branch in enumerate(BRANCHES):
        forward_core=np.eye(compact)
        inverse_core=np.eye(compact)
        forward_rate=np.zeros((compact,compact))
        if layout['heavy']:
            forward_value,derivative=dense_parts(metric['maps'][branch]['forward_correction'])
            inverse_value,_=dense_parts(metric['maps'][branch]['inverse_correction'])
            forward_core[layout['heavy']]+=forward_value
            inverse_core[layout['heavy']]+=inverse_value
            forward_rate[layout['heavy']]+=derivative
        forward=block_diag((csc_matrix(forward_core),eye(dimension-compact)),format='csc')
        inverse=block_diag((csc_matrix(inverse_core),eye(dimension-compact)),format='csc')
        forward_derivative=block_diag((csc_matrix(forward_rate),csc_matrix((dimension-compact,dimension-compact))),format='csc')
        correction=sparse(compact_value[branch_index],scalar*cached['remote_stream'],cached['remote_keys'],dimension)
        slow_derivative=sparse(compact_slow[branch_index],scalar_slow*cached['remote_stream']+scalar*cached['remote_stream_rate'],cached['remote_keys'],dimension)
        derivative=sparse(compact_phase[branch_index],scalar_phase*cached['remote_stream'],cached['remote_keys'],dimension)
        endpoint=eye(dimension,format='csc')+correction
        endpoint_rate=slow_derivative+phase_rate*derivative
        endpoint_lu=splu(endpoint)
        mean=sparse(node['mean'][branch_index],node['remote'],node['keys'],dimension)
        actual=sparse(direct['matrix'][branch_index],direct['remote'],node['keys'],dimension)
        defect=block_diag((csc_matrix(maps[branch_index]),csc_matrix((dimension-compact,dimension-compact))),format='csc')
        numerator=actual@correction-correction@mean-slow_derivative+defect@endpoint
        entries.append(dict(forward=forward,inverse=inverse,forward_rate=forward_derivative,endpoint=endpoint,
            endpoint_rate=endpoint_rate,endpoint_lu=endpoint_lu,mean=mean,numerator=numerator))
    return dict(prepared=prepared,physical=physical,frame=physical_frame,frame_rate=physical_frame_rate,
        frame_lu=frame_lu,branches=entries,phase_rate=phase_rate,core=layout['core'],compact=compact)


def to_native(frame,entry,values):
    return frame['frame_lu'].solve(entry['forward']@(entry['endpoint']@values))


def to_retained(frame,entry,values):
    return entry['endpoint_lu'].solve(entry['inverse']@(frame['frame']@values))


def native_map_rate(frame,entry,values,native):
    return frame['frame_lu'].solve(entry['forward_rate']@(entry['endpoint']@values)
        +entry['forward']@(entry['endpoint_rate']@values)-frame['frame_rate']@native)


class Case:
    def __init__(self,model,folder):
        self.model=model
        self.owner=CorrelatedSource(model)
        self.system=open_owned(model,folder)
        require(abs(self.system.wave/WAVE-1)<ALGEBRA,'same retained wavelength')
        self.energy=PhysicalEnergyMap(self.system)
        self.source,self.bank,self.leading,self.consumed=retained_checked(model)
        self.consumed.update(self.owner.consumed)
        slow_path=ACCUM_STAGE/LABEL/'slow-response-01'/f'{model}-fine.npz'
        if model=='cold' and LABEL=='half':
            slow_path=ACCUM_STAGE/LABEL/'baseline-identity-01/cold-fine.npz'
        paths=[owned(slow_path),owned(RESPONSE_STAGE/LABEL/'forward-01'/model/'fine.npz'),
               owned(CLOCK_STAGE/'kernel-bank-01/heavy-kernels.npz')]
        self.slow,self.response,self.kernel_packet=[load(path) for path in paths]
        self.consumed.update({str(path):digest(path) for path in paths})
        self.kernel=KernelBank(self.kernel_packet) if model=='heavy' else None
        require(np.array_equal(self.bank['efold'],self.response['efold']),'same original response grid')

    def node(self,index,output):
        started=time.monotonic()
        system=self.system
        model=self.model
        ordinal=index//2
        efold=float(self.bank['efold'][ordinal])
        theta=float(self.bank['phase'][ordinal])
        paths=[owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-source.json'),
               owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-mean.npz'),
               owned(COMPLETED/LABEL/'forcing-02'/f'{model}-{index:02d}-forcing.npz')]
        frozen,node,cached=read(paths[0]),load(paths[1]),load(paths[2])
        consumed=dict(self.consumed,**{str(path):digest(path) for path in paths})
        require(efold==frozen['efold'] and np.array_equal(cached['state'],self.leading['state'][ordinal]),'same source epoch and original mode')
        carrier,carrier_rate=system.owner.phase(efold) if model=='heavy' else (0.,0.)
        reference_point=system.context['point'](efold).copy()
        frame=frames(self.owner,frozen,theta,carrier,carrier_rate,system.units,node,cached)
        primitive=self.kernel.response(self.source,efold,theta)[1].sum(axis=0) if model=='heavy' else np.zeros_like(cached['state'])
        first=self.slow['eta'][ordinal].sum(axis=0)+primitive
        additional=self.response['response'][ordinal].sum(axis=0)
        current=cached['state']+first+additional
        generator=np.random.default_rng(62181+index)
        random=generator.normal(size=(len(system.units),4))
        random/=np.linalg.norm(random,axis=0)
        vectors=np.stack([np.column_stack([current[branch],additional[branch],random]) for branch in range(2)])
        native=np.array([to_native(frame,entry,vectors[branch]) for branch,entry in enumerate(frame['branches'])])
        native_rates=np.empty_like(native)
        local_rates=np.empty_like(native)
        readouts=np.empty((2,6,len(NAMES)))
        checks=[]
        state=np.array([efold,frame['physical']['values'][0]/(np.exp(efold)*self.owner.saved.masses[0]),
                        *frame['physical']['values'][1:]])
        with CommonCarrierFibre(system) as fibre:
            fibre.chart_angle=carrier
            fibre.carrier_rate=carrier_rate
            fibre.common_carrier=True
            _,maps,_,_,source_paths=frozen_source(fibre,self.energy,state,theta)
            consumed.update(source_paths)
            core=frame['core']
            core_error=relative(frame['frame'][:core,:core].toarray(),maps['transform'])
            tail_error=relative(frame['frame'].diagonal()[core:],maps['tail_weights'])
            require(max(core_error,tail_error)<ALGEBRA,'analytic native-to-physical map equals retained native map')
            retained_point=fibre.current.copy()
            local_mu=fibre.mu
            for branch,entry in enumerate(frame['branches']):
                for column in range(6):
                    guard()
                    rate,values,*_=system.evaluate(efold,native[branch,:,column]*system.units,BRANCHES[branch])
                    native_rates[branch,:,column]=rate/system.units
                    readouts[branch,column]=[values[name] for name in NAMES]
                    fibre.common_carrier=False
                    local_rate,local_values,*_=system.evaluate(efold,native[branch,:,column]*system.units,BRANCHES[branch])
                    local_rates[branch,:,column]=local_rate/system.units
                    fibre.common_carrier=True
                    shift=np.zeros(len(system.units))
                    if model=='heavy':
                        selected=system.slots
                        raw=native[branch,selected,column]*system.units[selected]
                        shift[selected]=(carrier_rate-local_mu)*np.array([-raw[1],raw[0]])/system.units[selected]
                    carrier_error=relative(native_rates[branch,:,column],local_rates[branch,:,column]+shift)
                    require(carrier_error<ALGEBRA,'derived common-carrier connection term')
                    require(relative(readouts[branch,column],np.array([local_values[name] for name in NAMES]))<ALGEBRA,'carrier derivative does not change point observables')
                map_rate=native_map_rate(frame,entry,vectors[branch],native[branch])
                pullback=to_retained(frame,entry,native_rates[branch]-map_rate)
                retained=entry['mean']@vectors[branch]+entry['endpoint_lu'].solve(entry['numerator']@vectors[branch])
                inverse_error=relative(to_retained(frame,entry,native[branch]),vectors[branch])
                errors=[relative(pullback[:,column],retained[:,column]) for column in range(6)]
                checks.append(dict(branch=BRANCHES[branch],map_inverse=inverse_error,native_pullback=errors,
                    core_map=core_error,tail_map=tail_error,carrier_identity=carrier_error))
                require(inverse_error<ALGEBRA and max(errors)<GATE,'common-frame native pullback reproduces retained M+R')
        reference_rates=np.empty_like(native)
        reference_readouts=np.empty_like(readouts)
        mismatch=[]
        residual=[]
        for branch,entry in enumerate(frame['branches']):
            for column in range(6):
                rate,values,*_=system.evaluate(efold,native[branch,:,column]*system.units,BRANCHES[branch])
                reference_rates[branch,:,column]=rate/system.units
                reference_readouts[branch,column]=[values[name] for name in NAMES]
            mismatch.append(to_retained(frame,entry,reference_rates[branch]-native_rates[branch]))
            residual.append(entry['endpoint_lu'].solve(entry['numerator']@additional[branch]))
        mismatch=np.array(mismatch)
        residual=np.array(residual)
        output_delta=reference_readouts-readouts
        target=output/f'{model}-{index:02d}-background.npz'
        np.savez_compressed(target,efold=efold,theta=theta,carrier=carrier,carrier_rate=carrier_rate,local_carrier_rate=local_mu,
            retained_vectors=vectors,native_vectors=native,reference_rates=reference_rates,retained_rates=native_rates,
            local_carrier_rates=local_rates,background_forcing=mismatch,feedback_residual=residual,readout_mismatch=output_delta,
            reference_readouts=reference_readouts,retained_readouts=readouts,reference_background=reference_point,
            retained_background=retained_point,current=current,first_response=first,second_response=additional)
        require(all(digest(path)==seal for path,seal in consumed.items()),'original inputs unchanged')
        report=dict(passed=True,model=model,index=index,efold=efold,path=str(target),sha256=digest(target),consumed=consumed,
            sources=sources(),checks=checks,background_source_per_state=(np.linalg.norm(mismatch[:,:,0],axis=1)/np.linalg.norm(current,axis=1)).tolist(),
            feedback_residual_per_state=(np.linalg.norm(residual,axis=1)/np.linalg.norm(current,axis=1)).tolist(),
            carrier_rate_difference=float(carrier_rate-local_mu) if model=='heavy' else 0.,
            seconds=time.monotonic()-started,source_at_original_epochs_only=True,background_mismatch_propagated=False)
        write(output/f'{model}-{index:02d}-result.json',report)
        print(LABEL,model,index,'common-frame source saved',report['background_source_per_state'],report['feedback_residual_per_state'],flush=True)
        return report

