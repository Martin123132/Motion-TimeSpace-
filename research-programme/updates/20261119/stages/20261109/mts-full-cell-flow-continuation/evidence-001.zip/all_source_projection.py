from common import *
from continuation_audit import integrate, independently_integrate
from response_support import adjoints,NAMES
from math import fsum
import numpy as np


def source_catalog(frozen, completed):
    inherited={entry['index']:entry['flow'] for entry in frozen['reuse'] if 'flow' in entry}
    catalog={}
    for path in sorted(path for parent in (*INHERITED_BATCH_STAGES,STAGE) for path in (parent/LABEL/'batches').glob('batch*-result.json')):
        for segment in read(path)['reports']:
            catalog[segment['ordinal']]=segment['nodes']
    for ordinal in completed:
        if ordinal not in catalog:
            catalog[ordinal]=[dict(inherited[index],index=index) for index in frozen['segments'][ordinal]['indices']]
    return catalog


def verify_contraction(packet, phase, curves, row_norm):
    maximum=0.
    for control,name in enumerate(('fine','interpolation-coarse','step-coarse')):
        covectors=curves[name](float(packet['efold']))*row_norm[:,:,None]
        for values,stored in ((packet['forcing'],packet['projected']),(phase['source_change'],phase['projected'])):
            for branch in range(2):
                for column in range(2):
                    for observable in range(len(NAMES)):
                        terms=covectors[observable,branch]*values[branch,:,column]
                        calculated=fsum(map(float,terms))
                        absolute=fsum(map(float,abs(terms)))
                        error=abs(calculated-float(stored[control,branch,column,observable]))/max(absolute,1e-80)
                        require(error<ALGEBRA,'independent full-source adjoint contraction')
                        maximum=max(maximum,error)
    return maximum


def main():
    modest()
    output=ROOT/'all-source-projection-01'
    output.mkdir(exist_ok=False)
    audit_path=STAGE/'completed-audit/result.json'
    audit=read(audit_path)
    require(audit['passed'],'completed-node independent audit')
    freeze_path=FROZEN_STAGE/LABEL/'freeze-01/result.json'
    frozen=read(freeze_path)
    previous_path=SEGMENT_STAGE/LABEL/'freeze-01/result.json'
    previous=read(previous_path)
    weights_path=SEGMENT_STAGE/LABEL/'exact-weights-01/result.json'
    old_weights=read(weights_path)
    consumed={str(path):digest(path) for path in (audit_path,freeze_path,previous_path,weights_path)}
    reports=[]
    for model in ('heavy','cold'):
        if model=='heavy':
            ordinals=audit['completed_ordinals']
            segments=[frozen['segments'][ordinal] for ordinal in ordinals]
            catalog=source_catalog(frozen,ordinals)
        else:
            selected=next(row for row in previous['reports'] if row['model']=='cold')
            correct=next(row for row in old_weights['reports'] if row['model']=='cold')
            segments=[dict(row,ordinal=ordinal) for ordinal,row in enumerate(correct['segments'])]
            catalog={}
            for segment in segments:
                catalog[segment['ordinal']]=[]
                for index in segment['indices']:
                    path=SEGMENT_STAGE/LABEL/'points-01'/f'cold-{index:03d}-flow-result.json'
                    catalog[segment['ordinal']].append(dict(index=index,path=str(path),sha256=digest(path)))
        curves,row_norm=adjoints(model,consumed)
        reference_path=REFINEMENT/LABEL/'projection-refined-cell03'/f'{model}-projection.npz'
        original=load(reference_path)
        consumed[str(reference_path)]=digest(reference_path)
        controls=[]
        fine_values=[]
        coarse_values=[]
        fine_squares=[]
        coarse_squares=[]
        widths=[]
        triangle=[]
        maximum_dot=0.
        maximum_sum=0.
        packets=[]
        for segment in segments:
            values=[]
            phase_values=[]
            for entry in catalog[segment['ordinal']]:
                require(digest(entry['path'])==entry['sha256'],'completed source receipt')
                consumed[entry['path']]=entry['sha256']
                receipt=read(entry['path'])
                for key in ('source','phase'):
                    require(digest(receipt[key])==receipt[key+'_sha256'],'source/control bytes')
                    consumed[receipt[key]]=receipt[key+'_sha256']
                packet=load(receipt['source'])
                phase=load(receipt['phase'])
                maximum_dot=max(maximum_dot,verify_contraction(packet,phase,curves,row_norm))
                values.append(packet['projected'])
                phase_values.append(phase['projected'])
            values=np.array(values)
            phase_values=np.array(phase_values)
            integrals=[]
            squares=[]
            phase_integrals=[]
            volumes=[]
            for rule in segment['rules']:
                selected_values=values[rule['local_indices']]
                calculated=integrate(rule['weights'],selected_values)
                exact=independently_integrate(rule['weights'],selected_values)
                magnitude=integrate(np.abs(rule['weights']),abs(selected_values))
                error=float(np.max(abs(calculated-exact)/np.maximum(magnitude,1e-80)))
                require(error<ALGEBRA,'independent full-source quadrature')
                maximum_sum=max(maximum_sum,error)
                integrals.append(calculated)
                squares.append(integrate(rule['weights'],selected_values[:,0,:,0]**2))
                phase_integrals.append(integrate(rule['weights'],phase_values[rule['local_indices']]))
                volumes.append(fsum(rule['weights']))
            integrals=np.array(integrals)
            phase_integrals=np.array(phase_integrals)
            width=segment['range'][1]-segment['range'][0]
            require(max(abs(value-width) for value in volumes)/width<ALGEBRA,'correct dN volume with no phase Jacobian')
            fine,coarse=integrals[-1,0,:,0],integrals[-2,0,:,0]
            current=integrals[-1,0,:,1]
            phase_change=phase_integrals[-1,0,:,0]
            cross=phase_integrals[-1,0,:,1]
            interpolation=integrals[-1,1,:,0]-fine
            step=integrals[-1,2,:,0]-fine
            change=np.stack([current,phase_change,cross,current+phase_change+cross,interpolation,step])
            controls.append(change)
            fine_values.append(fine)
            coarse_values.append(coarse)
            fine_squares.append(squares[-1])
            coarse_squares.append(squares[-2])
            widths.append(width)
            triangle.append(abs(fine-coarse)+abs(current)+abs(phase_change)+abs(cross)+abs(interpolation)+abs(step))
            path=output/f'{model}-segment-{segment["ordinal"]:03d}.npz'
            np.savez_compressed(path,integrals=integrals,squares=squares,phase_integrals=phase_integrals,
                                width=width,controls=change,orders=[rule['count'] for rule in segment['rules']])
            packets.append(dict(ordinal=segment['ordinal'],path=str(path),sha256=digest(path)))
        ones=np.ones(len(segments))
        signed=integrate(ones,np.array(fine_values))
        coarse_signed=integrate(ones,np.array(coarse_values))
        volume=fsum(widths)
        budget=np.sqrt(volume*np.maximum(integrate(ones,np.array(fine_squares)),0))
        coarse_budget=np.sqrt(volume*np.maximum(integrate(ones,np.array(coarse_squares)),0))
        changes=integrate(ones,np.array(controls))
        floor=np.maximum(budget,1e-80)
        diagnostics=np.concatenate([(abs(signed-coarse_signed)/floor)[None],
                                    (abs(budget-coarse_budget)/floor)[None],abs(changes)/floor[None]],axis=0)
        inside=abs(signed)<=floor*(1+GATE)
        passes=(np.max(diagnostics,axis=0)<GATE)&inside
        triangle_sum=integrate(ones,np.array(triangle))
        target=output/(model+'-coverage.npz')
        np.savez_compressed(target,signed=signed,coarse_signed=coarse_signed,budget=budget,coarse_budget=coarse_budget,
            changes=changes,diagnostics=diagnostics,passes=passes,inside=inside,reference_scale=original['reference_scale'],
            original_budget=original['fine_cauchy'],volume=volume,triangle=triangle_sum)
        rows=[]
        for branch,name in enumerate(('gr','poisson')):
            for channel,observable in enumerate(NAMES):
                rows.append(dict(branch=name,channel=observable,numerical_comparison_pass=bool(passes[branch,channel]),
                                 diagnostics=diagnostics[:,branch,channel].tolist(),
                                 signed_over_reference=float(signed[branch,channel]/original['reference_scale'][branch,channel]),
                                 triangle_over_original_budget=float(triangle_sum[branch,channel]/max(original['fine_cauchy'][branch,channel],1e-80))))
        reports.append(dict(model=model,path=str(target),sha256=digest(target),segments=packets,
                            segment_count=len(segments),complete_cell=len(segments)==(158 if model=='heavy' else 2),
                            numerical_pass_count=int(np.count_nonzero(passes)),rows=rows,
                            independent_contraction_error=maximum_dot,independent_integral_absolute_scale_error=maximum_sum))
        print(model,'all-source covered-domain checks',np.count_nonzero(passes),'of20;',len(segments),'segments',flush=True)
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'all-source evidence unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,
        channel_names=list(NAMES),diagnostic_names=['quadrature','budget','current','phase','cross','current_and_phase','adjoint_interpolation','adjoint_steps'],
        no_new_native_calls=True,no_new_history_solve=True,no_source_replacement=True,
        current_physical_clock_not_removed=True,extra_phase_jacobian_not_applicable_to_direct_N_measure=True,
        partial_mts_coverage_not_a_whole_cell_pass=True,unchanged_gates=[ALGEBRA,GATE]))


if __name__=='__main__':
    main()



