from full_cell_sources import build

build([40], 'probe')

