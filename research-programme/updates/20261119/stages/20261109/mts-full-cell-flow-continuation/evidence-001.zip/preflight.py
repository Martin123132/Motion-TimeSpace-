from common import *
import full_cell_sources
import continuation_audit
import all_source_projection


def main():
    modest()
    consumed=verify_inputs()
    output=ROOT/'preflight-01'
    output.mkdir(parents=True,exist_ok=False)
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8'),str(path),'exec')
    require(Path(full_cell_sources.__file__).resolve()==FROZEN_STAGE/'full_cell_sources.py','unchanged parent source implementation')
    require(full_cell_sources.ROOT==ROOT and full_cell_sources.FROZEN_STAGE==FROZEN_STAGE,'new ownership, old frozen inputs')
    parent_audit=(FROZEN_STAGE/'full_cell_audit_v2.py').read_text(encoding='utf-8')
    expected=parent_audit.replace(
        "batches=[ROOT/'batches/probe-result.json'] if mode=='probe' else sorted((ROOT/'batches').glob('batch*-result.json'))",
        "batches=[ROOT/'batches/probe-result.json'] if mode=='probe' else sorted(path for parent in (*INHERITED_BATCH_STAGES,STAGE) for path in (parent/LABEL/'batches').glob('batch*-result.json'))")
    require(expected.rstrip()==(STAGE/'continuation_audit.py').read_text(encoding='utf-8').rstrip(),'audit mathematics unchanged')
    parent_projection=(FROZEN_STAGE/'all_source_projection.py').read_text(encoding='utf-8')
    expected=parent_projection.replace("from full_cell_audit_v2 import integrate, independently_integrate",
        "from continuation_audit import integrate, independently_integrate").replace(
        "for path in sorted((ROOT/'batches').glob('batch*-result.json')):",
        "for path in sorted(path for parent in (*INHERITED_BATCH_STAGES,STAGE) for path in (parent/LABEL/'batches').glob('batch*-result.json')):")
    require(expected.rstrip()==(STAGE/'all_source_projection.py').read_text(encoding='utf-8').rstrip(),'complete-source mathematics unchanged')
    manifest={str(Path(row['path']).resolve()):row['sha256'] for row in read(FROZEN_STAGE/'closeout.json')['artifacts']}
    freeze_path=FROZEN_STAGE/LABEL/'freeze-01/result.json'
    parent_path=FROZEN_STAGE/'completed-audit/result.json'
    for path in (freeze_path,parent_path):
        require(digest(path)==manifest[str(path.resolve())],'sealed inherited result')
        consumed[str(path)]=digest(path)
    frozen=read(freeze_path)
    parent=read(parent_path)
    require(frozen['points']==2750 and len(frozen['segments'])==158,'same complete-cell freeze')
    require(parent['completed_ordinals']==list(range(40))+[52,105,157],'exact inherited coverage')
    require(PROBE_SEGMENT==40 and PROBE_SEGMENT not in parent['completed_ordinals'],'first unfinished segment probe')
    require(digest(frozen['path'])==frozen['sha256'],'unchanged complete grid bytes')
    consumed[frozen['path']]=frozen['sha256']
    catalog=all_source_projection.source_catalog(frozen,parent['completed_ordinals'])
    require(sorted(catalog)==parent['completed_ordinals'],'prior catalogue not omitted')
    for number in range(5):
        path=FROZEN_STAGE/LABEL/'batches'/f'batch{number:02d}-result.json'
        require(digest(path)==manifest[str(path.resolve())],'immutable completed prior batch')
        consumed[str(path)]=digest(path)
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'preflight inputs unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,
        inherited_segments=43,inherited_nodes=795,frozen_segments=158,frozen_nodes=2750,
        probe_ordinal=40,physical_code_unchanged=True,complete_prior_catalogue_retained=True,
        no_history_or_native_calls=True,unchanged_gates=[ALGEBRA,GATE]))
    print('continuation adapters checked;43 inherited segments and original full freeze retained',flush=True)


if __name__=='__main__':
    main()

