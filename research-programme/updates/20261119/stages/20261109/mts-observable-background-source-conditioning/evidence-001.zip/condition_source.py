from common import *
from response_support import adjoints, NAMES, BRANCHES
from correlated_source import full_endpoint
from scipy.sparse import block_diag, csc_matrix, diags, eye
from scipy.sparse.linalg import splu
from fractions import Fraction
import math
import numpy as np


PARENT_SEAL='e9605e1c81ad5b48ef790ee5f906cd1c29bf628140cc80f5fdd9b1c6ffbf73d2'


def weights(coordinate):
    result=np.zeros(len(coordinate))
    require(len(coordinate)%2==1, 'complete quadratic panels')
    for start in range(0,len(coordinate)-2,2):
        left=coordinate[start+1]-coordinate[start]
        right=coordinate[start+2]-coordinate[start+1]
        require(left>0 and right>0, 'ordered quadrature')
        result[start]+=(left+right)/6*(2-right/left)
        result[start+1]+=(left+right)**3/(6*left*right)
        result[start+2]+=(left+right)/6*(2-left/right)
    require(np.all(result>0), 'positive frozen quadratic weights')
    return result


def two_diff(left,right):
    high=left-right
    virtual_right=left-high
    virtual_left=high+virtual_right
    return high,(left-virtual_left)+(virtual_right-right)


def compensated(covector,high,low):
    terms=[]
    underflow=0
    tiny=np.finfo(float).tiny
    for factor,main,tail in zip(covector,high,low):
        for value in (main,tail):
            product=float(factor)*float(value)
            residual=math.fma(float(factor),float(value),-product)
            require(math.isfinite(product) and math.isfinite(residual), 'finite product expansion')
            if factor!=0 and value!=0 and abs(product)<tiny:
                underflow+=1
            terms.extend((product,residual))
    return math.fsum(terms),underflow


def rational_dot(covector,left,right):
    total=Fraction(0)
    for factor,first,second in zip(covector,left,right):
        if factor!=0 and first!=second:
            total+=Fraction(float(factor))*(Fraction(float(first))-Fraction(float(second)))
    return total


def relative(left,right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.linalg.norm(right),1e-80))


def local_differences(signal,coordinate,measure,stride):
    differences=[]
    for start in range(0,len(coordinate)-1,4*stride):
        selected=np.arange(start,start+4*stride+1,stride)
        fine=weights(coordinate[selected])*measure[selected]
        coarse=weights(coordinate[selected[::2]])*measure[selected[::2]]
        differences.append(np.einsum('n,nbc->bc',fine,signal[selected])-np.einsum('n,nbc->bc',coarse,signal[selected[::2]]))
    return np.array(differences)


def coordinate_names(layout,dimension):
    names=[f'native[{index}]' for index in range(dimension)]
    for key in ('alpha','cdm','baryon','baryon_velocity'):
        names[layout[key]]=key
    for key in ('photon_all','polar_all','massless_all','slow','heavy'):
        for order,index in enumerate(layout[key]):
            names[index]=f'{key}[{order}]'
    for node,indices in enumerate(layout['massive']):
        for multipole,index in enumerate(indices):
            names[index]=f'massive[node={node},ell={multipole}]'
    for node,indices in enumerate(layout['tail_by_node']):
        for position,index in enumerate(indices):
            names[index]=f'massive-tail[node={node},slot={position}]'
    return names


def main():
    modest()
    require(hasattr(math,'fma'), 'retained Python supports fused product residuals')
    inputs=verify_inputs()
    require(digest(PHASE_RESPONSE/'closeout.json')==PARENT_SEAL, 'accepted first-cell seal')
    inputs[str(PHASE_RESPONSE/'closeout.json')]=PARENT_SEAL
    manifest={str(Path(item['path'])):item['sha256'] for item in read(PHASE_RESPONSE/'closeout.json')['artifacts']}
    consumed={}
    def parent(path):
        path=Path(path)
        key=str(path)
        require(key in manifest and digest(path)==manifest[key], 'immutable first-cell input '+key)
        consumed[key]=manifest[key]
        return path
    output=ROOT/'conditioning-01'
    output.mkdir(parents=True,exist_ok=False)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),models=['heavy','cold'],indices=list(range(257)),
        exact_rational_indices=[0,64,128,192,256],gate=GATE,algebra=ALGEBRA,
        no_new_native_calls=True,no_new_history_solve=True,original_bank_grids_tolerances_unchanged=True))
    source=read(parent(PHASE_RESPONSE/LABEL/'points-01/fine-02-result.json'))
    reports=[]
    rows=[]
    unit=np.finfo(float).eps/2
    for model in ('heavy','cold'):
        projection=load(parent(PHASE_RESPONSE/LABEL/'projection-fine-02'/f'{model}-projection.npz'))
        grid=load(parent(PHASE_RESPONSE/LABEL/'grid-01'/f'{model}-grid.npz'))
        lambda_curves,row_norm=adjoints(model,consumed)
        layout_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-00-source.json')
        consumed[str(layout_path)]=digest(layout_path)
        layout=read(layout_path)['layout']
        case=next(item for item in source['reports'] if item['model']==model)
        physical_weights=weights(grid['coordinate'])*grid['jacobian']
        stable_values=[]
        plain_values=[]
        input_magnitudes=[]
        dot_magnitudes=[]
        subtraction_magnitudes=[]
        algebra_errors=[]
        exact_checks=[]
        low_count=0
        underflow_count=0
        input_terms=source_terms=None
        for node in case['nodes']:
            guard()
            index=node['index']
            packet=load(parent(node['path']))
            require(float(packet['efold'])==grid['efold'][index], 'unchanged point')
            dimension=packet['current'].shape[1]
            compact=packet['forward'].shape[-1]
            physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
            physical_lu=splu(physical)
            require(physical.shape==(dimension,dimension), 'separate physical compact layout')
            adjoint=lambda_curves['fine'](float(packet['efold']))*row_norm[:,:,None]
            if input_terms is None:
                input_terms=np.zeros((2,len(NAMES),dimension))
                source_terms=np.zeros_like(input_terms)
            node_stable=[]
            node_plain=[]
            node_inputs=[]
            node_dot=[]
            node_subtraction=[]
            for branch in range(2):
                forward=block_diag((csc_matrix(packet['forward'][branch]),eye(dimension-compact)),format='csc')
                inverse=block_diag((csc_matrix(packet['inverse'][branch]),eye(dimension-compact)),format='csc')
                endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],float(packet['remote_endpoint']),dimension)
                covectors=physical.T@(inverse.T@splu(endpoint).solve(adjoint[:,branch,:].T,trans='T'))
                recovered=endpoint.T@(forward.T@physical_lu.solve(covectors,trans='T'))
                error=max(relative(recovered[:,column],adjoint[column,branch]) for column in range(len(NAMES)))
                require(error<ALGEBRA, 'independent dual moving-map identity')
                reference=packet['reference_rates'][branch,:,0]
                retained=packet['retained_rates'][branch,:,0]
                high,low=two_diff(reference,retained)
                require(np.array_equal(high,packet['difference'][branch,:,0]), 'same stored subtraction')
                low_count+=int(np.count_nonzero(low))
                plain=covectors.T@high
                stable=[]
                for column in range(len(NAMES)):
                    value,underflows=compensated(covectors[:,column],high,low)
                    stable.append(value)
                    underflow_count+=underflows
                    if index in (0,64,128,192,256):
                        exact=rational_dot(covectors[:,column],reference,retained)
                        exact_error=abs(Fraction(value)-exact)
                        allowance=Fraction(math.ulp(float(exact)))+Fraction(4*dimension)*Fraction(float(np.nextafter(0.,1.)))
                        require(exact_error<=allowance, 'compensated dot agrees with exact rational spot check')
                        exact_checks.append(dict(index=index,branch=BRANCHES[branch],channel=NAMES[column],
                            absolute_error=float(exact_error),ulp_allowance=float(allowance),passed=True))
                stable=np.array(stable)
                magnitude=abs(covectors).T@(abs(reference)+abs(retained))
                dot_magnitude=abs(covectors).T@abs(high)
                subtraction=abs(covectors).T@abs(low)
                old=packet['projected'][0,branch,0]
                backward=float(np.max(abs(plain-old)/np.maximum(dot_magnitude,1e-80)))
                require(backward<ALGEBRA, 'same source contraction at unchanged backward algebra gate')
                algebra_errors.append((error,backward))
                input_terms[branch]+=physical_weights[index]*(abs(covectors).T*(abs(reference)+abs(retained))[None,:])
                source_terms[branch]+=physical_weights[index]*(covectors.T*high[None,:])
                node_stable.append(stable)
                node_plain.append(plain)
                node_inputs.append(magnitude)
                node_dot.append(dot_magnitude)
                node_subtraction.append(subtraction)
            stable_values.append(node_stable)
            plain_values.append(node_plain)
            input_magnitudes.append(node_inputs)
            dot_magnitudes.append(node_dot)
            subtraction_magnitudes.append(node_subtraction)
            if index%32==0:
                print(model,index,'saved-packet dual/source check complete',flush=True)
        stable_values=np.array(stable_values)
        original=projection['projected'][:,0,:,0]
        input_magnitudes=np.array(input_magnitudes)
        dot_magnitudes=np.array(dot_magnitudes)
        subtraction_magnitudes=np.array(subtraction_magnitudes)
        integrated=lambda values:np.einsum('n,nbc->bc',physical_weights,values)
        budget=np.maximum(projection['fine_cauchy'],1e-80)
        rate_sensitivity=integrated(input_magnitudes)/budget
        dot_gamma=(2*dimension+1)*unit/(1-(2*dimension+1)*unit)
        post_subtraction_estimate=(dot_gamma*integrated(dot_magnitudes)+integrated(subtraction_magnitudes))/budget
        arithmetic_change=integrated(stable_values-original)/budget
        local_original=local_differences(original,grid['coordinate'],grid['jacobian'],1)
        local_stable=local_differences(stable_values,grid['coordinate'],grid['jacobian'],1)
        local_previous=local_differences(original,grid['coordinate'],grid['jacobian'],2)
        require(relative(local_original.sum(axis=0),projection['fine_signed']-projection['coarse_signed'])<ALGEBRA,
                'localized quadrature reproduces full refinement difference')
        names=coordinate_names(layout,dimension)
        for branch,branch_name in enumerate(BRANCHES):
            for column,name in enumerate(NAMES):
                local=local_original[:,branch,column]/budget[branch,column]
                order=np.argsort(abs(local))[::-1]
                cumulative=np.cumsum(abs(local)[order])
                support=int(np.searchsorted(cumulative,.9*cumulative[-1])+1) if cumulative[-1]>0 else 0
                source_order=np.argsort(abs(source_terms[branch,column]))[::-1][:8]
                condition_order=np.argsort(input_terms[branch,column])[::-1][:8]
                rows.append(dict(model=model,branch=branch_name,channel=name,
                    input_condition=float(rate_sensitivity[branch,column]),
                    unit_roundoff_rate_sensitivity=float(unit*rate_sensitivity[branch,column]),
                    native_rate_error_bound_claimed=False,
                    post_subtraction_dot_estimate=float(post_subtraction_estimate[branch,column]),
                    compensated_integral_change=float(arithmetic_change[branch,column]),
                    physical_compensated_change=float(integrated(stable_values-original)[branch,column]/projection['reference_scale'][branch,column]),
                    original_refinement_change=float(local.sum()),
                    compensated_refinement_change=float(local_stable[:,branch,column].sum()/budget[branch,column]),
                    prior_refinement_change=float(local_previous[:,branch,column].sum()/budget[branch,column]),
                    local_absolute_refinement=float(abs(local).sum()),
                    panel_count_for_90_percent=support,
                    panels_in_descending_order=[int(value) for value in order],
                    top_source_coordinates=[dict(index=int(value),label=names[value],signed_budget_fraction=float(source_terms[branch,column,value]/budget[branch,column])) for value in source_order],
                    top_condition_coordinates=[dict(index=int(value),label=names[value],unit_roundoff_budget_sensitivity=float(unit*input_terms[branch,column,value]/budget[branch,column])) for value in condition_order]))
        target=output/f'{model}-conditioning.npz'
        np.savez_compressed(target,efold=grid['efold'],coordinate=grid['coordinate'],jacobian=grid['jacobian'],weights=physical_weights,
            original=original,plain=plain_values,compensated=stable_values,input_magnitude=input_magnitudes,
            dot_magnitude=dot_magnitudes,subtraction_magnitude=subtraction_magnitudes,
            local_original=local_original,local_compensated=local_stable,local_previous=local_previous,
            input_terms=input_terms,source_terms=source_terms,algebra_errors=algebra_errors,
            budget=budget,reference_scale=projection['reference_scale'],rate_sensitivity=rate_sensitivity,
            post_subtraction_estimate=post_subtraction_estimate,arithmetic_change=arithmetic_change)
        report=dict(model=model,path=str(target),sha256=digest(target),dimension=dimension,
            subtraction_low_count=low_count,product_underflow_count=underflow_count,
            exact_checks=exact_checks,algebra_max=np.max(algebra_errors,axis=0).tolist(),
            original_bank_grids_tolerances_unchanged=True,compensated_source_only_a_diagnostic=True)
        write(output/f'{model}-result.json',dict(passed=True,consumed=consumed.copy(),sources=sources(),**report))
        reports.append(report)
    require(all(digest(path)==seal for path,seal in consumed.items()), 'saved inputs remained unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,records=rows,
        unchanged_gates=[ALGEBRA,GATE],new_native_calls=0,new_history_integrations=0,
        computed_covectors_held_fixed_for_conditioning=True,native_rate_error_bounded=False,
        first_cell_only=True,original_bank_grids_tolerances_unchanged=True))
    print('paired saved-packet conditioning completed',flush=True)


if __name__=='__main__':
    main()
