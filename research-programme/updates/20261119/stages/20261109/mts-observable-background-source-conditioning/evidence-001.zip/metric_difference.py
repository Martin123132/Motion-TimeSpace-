from common import *
from condition_source import PARENT_SEAL, weights, local_differences
from response_support import adjoints, NAMES, BRANCHES
from correlated_source import full_endpoint
from scipy.sparse import block_diag,csc_matrix,diags,eye
from scipy.sparse.linalg import splu
from fractions import Fraction
import numpy as np


def main():
    modest()
    inputs=verify_inputs()
    require(digest(PHASE_RESPONSE/'closeout.json')==PARENT_SEAL, 'first-cell evidence unchanged')
    inputs[str(PHASE_RESPONSE/'closeout.json')]=PARENT_SEAL
    manifest={str(Path(item['path'])):item['sha256'] for item in read(PHASE_RESPONSE/'closeout.json')['artifacts']}
    consumed={}
    def parent(path):
        key=str(Path(path))
        require(key in manifest and digest(path)==manifest[key], 'same saved source evidence')
        consumed[key]=manifest[key]
        return path
    for path in (ORIGINAL_POISSON/'poisson_driver.py',GAIN/'poisson_driver.py'):
        consumed[str(path)]=digest(path)
    source=read(parent(PHASE_RESPONSE/LABEL/'points-01/fine-02-result.json'))
    condition_path=ROOT/'conditioning-01/result.json'
    condition=read(condition_path)
    require(condition['passed'], 'completed conditioning diagnostic')
    consumed[str(condition_path)]=digest(condition_path)
    output=ROOT/'metric-difference-01'
    output.mkdir(exist_ok=False)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),consumed=consumed.copy(),
        identity='Delta alpha_N=(mean(1/H)*Delta Psi+mean(Psi)*Delta(1/H))/U_alpha',
        evaluation='exact rational arithmetic on saved binary64 inputs',no_native_calls=True,
        original_bank_grids_tolerances_unchanged=True,gate=GATE,algebra=ALGEBRA))
    reports=[]
    rows=[]
    for model in ('heavy','cold'):
        record=next(item for item in condition['reports'] if item['model']==model)
        require(digest(record['path'])==record['sha256'], 'saved compensated integral')
        consumed[record['path']]=record['sha256']
        diagnosed=load(record['path'])
        grid=load(parent(PHASE_RESPONSE/LABEL/'grid-01'/f'{model}-grid.npz'))
        projection=load(parent(PHASE_RESPONSE/LABEL/'projection-fine-02'/f'{model}-projection.npz'))
        layout_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-00-source.json')
        consumed[str(layout_path)]=digest(layout_path)
        slot=read(layout_path)['layout']['alpha']
        curves,row_norm=adjoints(model,consumed)
        case=next(item for item in source['reports'] if item['model']==model)
        changes=[]
        rate_differences=[]
        equation_errors=[]
        alpha_weights=[]
        rational_records=[]
        for node in case['nodes']:
            guard()
            packet=load(parent(node['path']))
            dimension=packet['current'].shape[1]
            compact=packet['forward'].shape[-1]
            physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
            adjoint=curves['fine'](float(packet['efold']))*row_norm[:,:,None]
            node_changes=[]
            node_differences=[]
            node_errors=[]
            node_weights=[]
            unit=Fraction(float(packet['units'][slot]))
            require(unit>0, 'unchanged positive metric coordinate unit')
            hubbles=[Fraction(float(packet[name+'_background'][12])) for name in ('reference','retained')]
            require(all(value>0 for value in hubbles), 'same expanding backgrounds')
            for branch in range(2):
                inverse=block_diag((csc_matrix(packet['inverse'][branch]),eye(dimension-compact)),format='csc')
                endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],float(packet['remote_endpoint']),dimension)
                covectors=physical.T@(inverse.T@splu(endpoint).solve(adjoint[:,branch,:].T,trans='T'))
                alpha=covectors[slot]
                potentials=[Fraction(float(packet[name+'_readouts'][branch,0,NAMES.index('Psi')])) for name in ('reference','retained')]
                state=Fraction(float(packet['native_vectors'][branch,slot,0]))
                rates=[Fraction(float(packet[name+'_rates'][branch,slot,0])) for name in ('reference','retained')]
                errors=[]
                for rate,potential,hubble in zip(rates,potentials,hubbles):
                    expected=potential/(hubble*unit)-state
                    scale=max(abs(potential/(hubble*unit))+abs(state),Fraction(1,10**80))
                    errors.append(float(abs(rate-expected)/scale))
                require(max(errors)<ALGEBRA, 'individual metric rate follows native equation')
                inverse_h=[1/value for value in hubbles]
                direct=(potentials[0]/hubbles[0]-potentials[1]/hubbles[1])/unit
                symmetric=((inverse_h[0]+inverse_h[1])/2*(potentials[0]-potentials[1])
                           +(potentials[0]+potentials[1])/2*(-(hubbles[0]-hubbles[1])/(hubbles[0]*hubbles[1])))/unit
                require(direct==symmetric, 'exact unequal-background product difference identity')
                correction=direct-(rates[0]-rates[1])
                projected=np.array([float(Fraction(float(value))*correction) for value in alpha])
                node_changes.append(projected)
                node_differences.append([float(rates[0]-rates[1]),float(direct),float(correction)])
                node_errors.append(errors)
                node_weights.append(alpha)
                if node['index'] in (0,64,128,192,256):
                    rational_records.append(dict(index=node['index'],branch=BRANCHES[branch],
                        derived_numerator=str(direct.numerator),derived_denominator=str(direct.denominator),
                        correction_numerator=str(correction.numerator),correction_denominator=str(correction.denominator)))
            changes.append(node_changes)
            rate_differences.append(node_differences)
            equation_errors.append(node_errors)
            alpha_weights.append(node_weights)
        changes=np.array(changes)
        corrected=diagnosed['compensated']+changes
        measure=weights(grid['coordinate'])*grid['jacobian']
        integrated=np.einsum('n,nbc->bc',measure,changes)
        candidate_integral=np.einsum('n,nbc->bc',measure,corrected)
        width=float(grid['efold'][-1]-grid['efold'][0])
        budget=np.sqrt(width*np.maximum(np.einsum('n,nbc->bc',measure,corrected**2),0.))
        coarse_measure=weights(grid['coordinate'][::2])*grid['jacobian'][::2]
        coarse_integral=np.einsum('n,nbc->bc',coarse_measure,corrected[::2])
        coarse_budget=np.sqrt(width*np.maximum(np.einsum('n,nbc->bc',coarse_measure,corrected[::2]**2),0.))
        local=local_differences(corrected,grid['coordinate'],grid['jacobian'],1)
        for branch,branch_name in enumerate(BRANCHES):
            for column,name in enumerate(NAMES):
                denominator=max(float(budget[branch,column]),1e-80)
                quadrature=float(abs(candidate_integral[branch,column]-coarse_integral[branch,column])/denominator)
                budget_change=float(abs(budget[branch,column]-coarse_budget[branch,column])/denominator)
                rows.append(dict(model=model,branch=branch_name,channel=name,
                    projected_alpha_change_over_old_budget=float(integrated[branch,column]/diagnosed['budget'][branch,column]),
                    physical_alpha_change=float(integrated[branch,column]/diagnosed['reference_scale'][branch,column]),
                    candidate_quadrature=quadrature,candidate_budget_change=budget_change,
                    two_integration_checks_pass=bool(quadrature<GATE and budget_change<GATE),
                    complete_candidate_validation=False,original_source_modified=False))
        target=output/f'{model}-metric-difference.npz'
        np.savez_compressed(target,changes=changes,corrected=corrected,rate_differences=rate_differences,
            equation_errors=equation_errors,alpha_weights=alpha_weights,integrated=integrated,
            candidate_integral=candidate_integral,budget=budget,coarse_integral=coarse_integral,
            coarse_budget=coarse_budget,local=local)
        report=dict(model=model,path=str(target),sha256=digest(target),rational_records=rational_records,
            maximum_individual_equation_error=float(np.max(equation_errors)),exact_difference_identities=514)
        write(output/f'{model}-result.json',dict(passed=True,sources=sources(),consumed=consumed.copy(),**report))
        reports.append(report)
        print(model,'metric difference derived and compared',report['maximum_individual_equation_error'],flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()), 'all saved inputs unchanged')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,
        reports=reports,records=rows,new_native_calls=0,original_bank_grids_tolerances_unchanged=True,
        physical_potential_and_hubble_errors_not_repaired=True,original_source_modified=False))


if __name__=='__main__':
    main()
