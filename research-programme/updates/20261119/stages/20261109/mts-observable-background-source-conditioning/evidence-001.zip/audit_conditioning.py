from common import *
from condition_source import PARENT_SEAL, weights, local_differences, two_diff, rational_dot, relative
from response_support import adjoints, NAMES, BRANCHES
from correlated_source import full_endpoint
from scipy.integrate import simpson
from scipy.sparse import block_diag,csc_matrix,diags,eye
from scipy.sparse.linalg import splu
from fractions import Fraction
import math
import numpy as np
import psutil


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    require(digest(PHASE_RESPONSE/'closeout.json')==PARENT_SEAL, 'retained phase source immutable')
    inputs[str(PHASE_RESPONSE/'closeout.json')]=PARENT_SEAL
    consumed,verified,accepted={},{},{}
    def hashes(records):
        for path,seal in records.items():
            if path not in verified:
                verified[path]=digest(path)
            require(verified[path]==seal, 'unchanged audited source '+path)
            consumed[path]=seal
    def take(path):
        value=read(path)
        require(value['passed'], 'completed calculation')
        for key in ('inputs','sources','consumed'):
            hashes(value.get(key,{}))
        accepted[str(path)]=digest(path)
        return value
    conditioning=take(ROOT/'conditioning-01/result.json')
    metric=take(ROOT/'metric-difference-01/result.json')
    require(conditioning['new_native_calls']==0 and conditioning['new_history_integrations']==0
            and metric['new_native_calls']==0 and not metric['original_source_modified'], 'same saved calculations')
    counts=dict(points=0,exact_dot_checks=0,metric_identities=0,individual_metric_rates=0,channel_rows=0)
    summary=[]
    source=read(PHASE_RESPONSE/LABEL/'points-01/fine-02-result.json')
    for model in ('heavy','cold'):
        condition_entry=next(item for item in conditioning['reports'] if item['model']==model)
        metric_entry=next(item for item in metric['reports'] if item['model']==model)
        for item in (condition_entry,metric_entry):
            hashes({item['path']:item['sha256']})
        data=load(condition_entry['path'])
        repair=load(metric_entry['path'])
        require(all(np.isfinite(value).all() for value in data.values()) and all(np.isfinite(value).all() for value in repair.values()), 'finite diagnostic arrays')
        grid=load(PHASE_RESPONSE/LABEL/'grid-01'/f'{model}-grid.npz')
        parent=load(PHASE_RESPONSE/LABEL/'projection-fine-02'/f'{model}-projection.npz')
        require(np.array_equal(data['original'],parent['projected'][:,0,:,0]), 'source grid was not replaced')
        measure=weights(grid['coordinate'])*grid['jacobian']
        require(np.array_equal(measure,data['weights']), 'fixed quadrature measure')
        integral=lambda values:simpson(values*grid['jacobian'][:,None,None],x=grid['coordinate'],axis=0)
        change=integral(data['compensated']-data['original'])/data['budget']
        require(relative(change,data['arithmetic_change'])<ALGEBRA, 'independent compensated response integral')
        require(relative(integral(data['input_magnitude'])/data['budget'],data['rate_sensitivity'])<ALGEBRA, 'input condition integral')
        require(relative(data['input_terms'].sum(axis=-1),integral(data['input_magnitude']))<ALGEBRA, 'coordinate conditioning attribution')
        require(relative(data['source_terms'].sum(axis=-1),integral(data['plain']))<ALGEBRA, 'signed source coordinate attribution')
        for actual,signal,stride in ((data['local_original'],data['original'],1),(data['local_compensated'],data['compensated'],1),(data['local_previous'],data['original'],2)):
            recomputed=[]
            for start in range(0,256,4*stride):
                selected=np.arange(start,start+4*stride+1,stride)
                fine=simpson(signal[selected]*grid['jacobian'][selected,None,None],x=grid['coordinate'][selected],axis=0)
                coarse=simpson(signal[selected[::2]]*grid['jacobian'][selected[::2],None,None],x=grid['coordinate'][selected[::2]],axis=0)
                recomputed.append(fine-coarse)
            require(float(np.max(abs(np.array(recomputed)-actual)/data['budget']))<ALGEBRA, 'independent local Simpson discrepancies')
        require(np.array_equal(repair['corrected'],data['compensated']+repair['changes']), 'only derived metric-coordinate change')
        require(relative(integral(repair['changes']),repair['integrated'])<ALGEBRA, 'derived metric source propagation')
        require(relative(integral(repair['corrected']),repair['candidate_integral'])<ALGEBRA, 'candidate integral')
        width=float(grid['efold'][-1]-grid['efold'][0])
        recomputed_budget=np.sqrt(width*np.maximum(integral(repair['corrected']**2),0.))
        require(relative(recomputed_budget,repair['budget'])<ALGEBRA, 'candidate conditional Cauchy expression')
        curves,row_norm=adjoints(model,consumed)
        layout_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-00-source.json')
        hashes({str(layout_path):digest(layout_path)})
        slot=read(layout_path)['layout']['alpha']
        case=next(item for item in source['reports'] if item['model']==model)
        for node in case['nodes']:
            guard()
            hashes({node['path']:node['sha256']})
            packet=load(node['path'])
            index=node['index']
            dimension=packet['current'].shape[1]
            high,low=two_diff(packet['reference_rates'][:,:,0],packet['retained_rates'][:,:,0])
            require(np.array_equal(high,packet['difference'][:,:,0]) and np.count_nonzero(low)==0, 'stored subtraction has no discarded low part')
            unit=Fraction(float(packet['units'][slot]))
            for branch in range(2):
                potentials=[Fraction(float(packet[name+'_readouts'][branch,0,NAMES.index('Psi')])) for name in ('reference','retained')]
                expansion=[Fraction(float(packet[name+'_background'][12])) for name in ('reference','retained')]
                rates=[Fraction(float(packet[name+'_rates'][branch,slot,0])) for name in ('reference','retained')]
                state=Fraction(float(packet['native_vectors'][branch,slot,0]))
                direct=(potentials[0]/expansion[0]-potentials[1]/expansion[1])/unit
                for rate,potential,hubble in zip(rates,potentials,expansion):
                    expected=potential/(hubble*unit)-state
                    scale=max(abs(potential/(hubble*unit))+abs(state),Fraction(1,10**80))
                    require(float(abs(rate-expected)/scale)<ALGEBRA, 'individual native metric equation')
                    counts['individual_metric_rates']+=1
                correction=direct-(rates[0]-rates[1])
                expected=np.array([float(Fraction(float(value))*correction) for value in repair['alpha_weights'][index,branch]])
                require(np.array_equal(expected,repair['changes'][index,branch]), 'exact-rational metric correction contraction')
                require(float(direct)==repair['rate_differences'][index,branch,1], 'derived difference stored without substitution')
                counts['metric_identities']+=1
            if index in (0,64,128,192,256):
                compact=packet['forward'].shape[-1]
                physical=block_diag((csc_matrix(packet['physical_core']),diags(packet['physical_tail'])),format='csc')
                adjoint=curves['fine'](float(packet['efold']))*row_norm[:,:,None]
                for branch in range(2):
                    inverse=block_diag((csc_matrix(packet['inverse'][branch]),eye(dimension-compact)),format='csc')
                    endpoint=full_endpoint(packet['endpoint'][branch],packet['remote_keys'],packet['remote_stream'],float(packet['remote_endpoint']),dimension)
                    dual=physical.T@(inverse.T@splu(endpoint).solve(adjoint[:,branch,:].T,trans='T'))
                    require(np.array_equal(dual[slot],repair['alpha_weights'][index,branch]), 'stored metric dual row')
                    for column in range(len(NAMES)):
                        exact=rational_dot(dual[:,column],packet['reference_rates'][branch,:,0],packet['retained_rates'][branch,:,0])
                        value=data['compensated'][index,branch,column]
                        allowance=Fraction(math.ulp(float(exact)))+Fraction(4*dimension)*Fraction(float(np.nextafter(0.,1.)))
                        require(abs(Fraction(float(value))-exact)<=allowance, 'independent exact dyadic spot check')
                        counts['exact_dot_checks']+=1
            counts['points']+=1
        metric_rows=[row for row in metric['records'] if row['model']==model]
        condition_rows=[row for row in conditioning['records'] if row['model']==model]
        for row in metric_rows:
            branch,column=BRANCHES.index(row['branch']),NAMES.index(row['channel'])
            budget=max(repair['budget'][branch,column],1e-80)
            quadrature=abs(repair['candidate_integral'][branch,column]-repair['coarse_integral'][branch,column])/budget
            change=abs(repair['budget'][branch,column]-repair['coarse_budget'][branch,column])/budget
            require(row['two_integration_checks_pass']==bool(quadrature<GATE and change<GATE), 'unchanged failed integration checks retained')
            require(not row['complete_candidate_validation'] and not row['original_source_modified'], 'diagnostic not silently promoted')
            counts['channel_rows']+=1
        underflow=Fraction(4*dimension)*Fraction(float(np.nextafter(0.,1.)))*Fraction(float(np.sum(measure)))
        underflow_relative=max(float(underflow/Fraction(float(value))) for value in data['budget'].ravel())
        summary.append(dict(model=model,
            compensated_integral_change_max=max(abs(row['compensated_integral_change']) for row in condition_rows),
            compensated_physical_change_max=max(abs(row['physical_compensated_change']) for row in condition_rows),
            rate_input_unit_roundoff_sensitivity_range=[min(row['unit_roundoff_rate_sensitivity'] for row in condition_rows),max(row['unit_roundoff_rate_sensitivity'] for row in condition_rows)],
            post_subtraction_dot_estimate_max=max(row['post_subtraction_dot_estimate'] for row in condition_rows),
            separate_product_underflow_allowance_max=underflow_relative,
            discarded_subtraction_low_components=condition_entry['subtraction_low_count'],
            subnormal_product_count=condition_entry['product_underflow_count'],
            ninety_percent_panel_count_range=[min(row['panel_count_for_90_percent'] for row in condition_rows),max(row['panel_count_for_90_percent'] for row in condition_rows)],
            alpha_change_budget_max=max(abs(row['projected_alpha_change_over_old_budget']) for row in metric_rows),
            alpha_change_physical_max=max(abs(row['physical_alpha_change']) for row in metric_rows),
            alpha_candidate_integration_passes=sum(row['two_integration_checks_pass'] for row in metric_rows),
            alpha_candidate_quad_max=max(row['candidate_quadrature'] for row in metric_rows),
            alpha_candidate_budget_max=max(row['candidate_budget_change'] for row in metric_rows),
            native_rate_input_errors_bounded=False))
    require(counts==dict(points=514,exact_dot_checks=200,metric_identities=1028,individual_metric_rates=2056,channel_rows=40), 'complete paired diagnostic')
    for path in STAGE.glob('*.start.json'):
        start=read(path)
        hashes({start['source_path']:start['source_sha256']})
        phase=path.name.removesuffix('.start.json')
        if phase=='audit-01':
            require(start['pid']==os.getpid(), 'audit worker identity')
            continue
        end=read(STAGE/(phase+'.end.json'))
        require(all(start[key]==end[key] for key in ('pid','created','command')) and end['exit_code']==0, 'completed owned worker')
        if psutil.pid_exists(start['pid']):
            created=datetime.fromisoformat(start['created'].replace('Z','+00:00')).timestamp()
            require(abs(psutil.Process(start['pid']).create_time()-created)>1, 'worker exited')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')), 'no bytecode residue')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,summary=summary,original_bank_grids_tolerances_unchanged=True,
        subtraction_precision_cure_rejected=True,alpha_difference_identity_derived=True,
        alpha_difference_cure_rejected=True,new_native_calls=0,new_history_solves=0,github_actions=False))
    print(json.dumps(dict(counts=counts,summary=summary),indent=2),flush=True)


if __name__=='__main__':
    main()
