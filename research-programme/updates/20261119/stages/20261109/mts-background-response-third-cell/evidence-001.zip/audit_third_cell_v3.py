from common import *
from cell_support import parent
from point_support import checked_point
from audit_phase_v2 import check_frame
from response_support import DenseHistory,adjoints,NAMES,BRANCHES,original_data
from clock_domain import certify
from scipy.integrate import simpson
import math
import numpy as np
import psutil


def relative(left,right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.linalg.norm(right),1e-80))


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed,verified,accepted={},{},{}
    def hashes(records):
        for path,seal in records.items():
            guard()
            if path not in verified:
                verified[path]=digest(path)
            require(verified[path]==seal,'immutable evidence '+path)
            consumed[path]=seal
    def take(path):
        value=read(path)
        require(value.get('passed') or value.get('completed'),'completed result '+str(path))
        for key in ('inputs','sources','consumed'):
            hashes(value.get(key,{}))
        accepted[str(path)]=digest(path)
        return value
    original=(PHASE_RESPONSE/'sample_sources.py').read_text(encoding='utf-8-sig').split('\ndef run(mode,stride):')[0]
    expected=original.replace('if index in (0,256):',"if index in (0,len(grid['efold'])-1):").replace('node_index=0 if index==0 else 4','node_index=8 if index==0 else 12').replace("report_path=ROOT/'history-01/result.json'","report_path=ROOT/'history-02/result.json'")
    require((STAGE/'sample_sources_v2.py').read_text(encoding='utf-8-sig').rstrip()==expected.rstrip(),'only history report and source diagnostic endpoints adapted')
    expected=(PHASE_RESPONSE/'controlled_sources.py').read_text(encoding='utf-8-sig').split('\ndef run(mode,stride):')[0]
    expected=expected.replace('import sample_sources as original','import sample_sources_v2 as original').replace('from sample_sources import PhaseSource','from sample_sources_v2 import PhaseSource')
    require((STAGE/'controlled_sources_v2.py').read_text(encoding='utf-8-sig').rstrip()==expected.rstrip(),'unchanged source-phase cross control')
    expected=(SECOND_CELL/'project_response_v2.py').read_text(encoding='utf-8-sig').replace('original_cell_indices=[4,8]','original_cell_indices=[8,12]')
    require((STAGE/'project_response.py').read_text(encoding='utf-8-sig').rstrip()==expected.rstrip(),'only third-cell metadata adapted; numerical projection unchanged')
    histories=take(ROOT/'history-02/result.json')
    require(len(histories['reports'])==4,'both fine/coarse histories for both models')
    history_freeze=read(ROOT/'history-02/freeze.json')
    require(history_freeze['rtol']==2e-12 and history_freeze['atol']==2e-14
            and history_freeze['controls']==[2048,4096] and history_freeze['original_indices']==[8,10,12]
            and history_freeze['gates']==[ALGEBRA,GATE],'unchanged equation integration controls')
    reference_cache={}
    for row in histories['reports']:
        hashes(row['consumed'])
        hashes({row['index']:row['sha256'],row['sample_path']:row['sample_sha256'],row['parent_index']:row['parent_index_sha256']})
        parent(row['parent_index'])
        expected_parent=SECOND_CELL/LABEL/'history-01'/row['model']/row['control']/'index.json'
        require(Path(row['parent_index'])==expected_parent,'own control inherited, not fine substituted for coarse')
        new,old=DenseHistory(row['index']),DenseHistory(row['parent_index'])
        require(new.index['start']==old.index['stop'] and new.index['steps']==old.index['steps'],'adjacency and original step span')
        require(new.shape==old.shape and np.array_equal(new.normalization,old.normalization),'same channel units')
        require(np.array_equal(new.raw(new.index['start']),old.raw(old.index['stop'])),'exact inherited phase and all state channels')
        for item in new.index['chunks']+old.index['chunks']:
            hashes({item['path']:item['sha256']})
        sample=load(row['sample_path'])
        if row['model'] not in reference_cache:
            original=original_data(row['model'])
            reference_cache[row['model']]=original[2:6]
            hashes(original[-1])
        bank,leading,slow,response=reference_cache[row['model']]
        expected_reference=np.concatenate([leading['state'][4:7,None],slow['eta'][4:7],response['response'][4:7]],axis=1)
        require(np.array_equal(sample['efold'],bank['efold'][4:7]) and np.array_equal(sample['reference_blocks'],expected_reference),'all reference channels belong to the SAME physical epochs')
        require(row['reference_bank_indices']==[4,5,6] and row['incoming_reference_error']<GATE,'repaired epoch preflight before integration')
        for epoch,theta,blocks in zip(sample['efold'],sample['phase'],sample['blocks']):
            actual_phase,actual_blocks=new.state(float(epoch))
            require(actual_phase==theta and np.array_equal(actual_blocks,blocks),'saved physical state reconstructed')
        require(row['phase_error']<ALGEBRA and row['current_error']<GATE and row['dense_roundtrip']<ALGEBRA,'same history accuracy gates')
    grid_report=take(ROOT/'grid-01/result.json')
    take(ROOT/'probe-verification/result.json')
    source=take(ROOT/'points-01/cell03-result.json')
    projection=take(ROOT/'projection-cell03/result.json')
    accumulation=take(ROOT/'accumulation-01/result.json')
    require(not projection['first_original_cell_only'] and projection['original_cell_indices']==[8,12]
            and not projection['whole_history_error_claimed'],'correct third-cell projection scope')
    require(accumulation['original_cell_indices']==[[0,4],[4,8],[8,12]] and not accumulation['continuum_budget_certificate'],'three-cell scope')
    grid_end=read(STAGE/'grid-balanced-01.end.json')
    probe_start=read(STAGE/'probe-balanced-01.start.json')
    require(datetime.fromisoformat(grid_end['finished'])<datetime.fromisoformat(probe_start['created'].replace('Z','+00:00')),'grid frozen before native evaluation')
    probe_end=read(STAGE/'verify-probe-01.end.json')
    for number in range(4):
        start=read(STAGE/f'batch{number:02d}-balanced-01.start.json')
        require(datetime.fromisoformat(probe_end['finished'])<datetime.fromisoformat(start['created'].replace('Z','+00:00')),'probe accepted before bulk')
        batch=take(ROOT/'points-01'/f'batch{number:02d}-result.json')
        for case in batch['reports']:
            grid_entry=next(item for item in grid_report['reports'] if item['model']==case['model'])
            intervals=grid_entry['intervals']
            require([row['index'] for row in case['nodes']]==list(range(number*intervals//4+1,(number+1)*intervals//4+1)),'complete bounded quarter')
    old_source=read(parent(SECOND_CELL/LABEL/'points-01/cell02-result.json'))
    old_projection=read(parent(SECOND_CELL/LABEL/'projection-cell02/result.json'))
    old_accumulation=read(parent(SECOND_CELL/LABEL/'accumulation-01/result.json'))
    counts=dict(history_controls=4,reused_boundary_points=0,new_points=0,phase_controls=0,projected_channels=0,accumulated_channels=0)
    maxima=dict(frame=0.,phase_frame=0.,adjoint_contraction=0.,primitive_refinement=0.,primitive_closure=0.)
    summary=[]
    for model in ('heavy','cold'):
        entry=next(item for item in grid_report['reports'] if item['model']==model)
        hashes({entry['path']:entry['sha256'],entry['phase_path']:entry['phase_sha256']})
        grid=load(entry['path'])
        old_grid=load(parent(SECOND_CELL/LABEL/'grid-01'/f'{model}-grid.npz'))
        spacing=float(np.max(np.diff(old_grid['coordinate'])))
        span=float(grid['coordinate'][-1]-grid['coordinate'][0])
        intervals=4*math.ceil(span/(4*spacing))
        require(intervals==entry['intervals'] and len(grid['efold'])==intervals+1,'grid count derived before sampling')
        require(np.all(np.diff(grid['efold'])>0) and np.max(np.diff(grid['coordinate']))<=spacing*(1+ALGEBRA),'ordered no-coarser integration spacing')
        require(all(grid[key][0]==old_grid[key][-1] for key in old_grid),'exact common boundary and measure')
        history=next(item for item in histories['reports'] if item['model']==model and item['control']=='fine')
        history_index=read(history['index'])
        require(history_index['start']==grid['efold'][0] and history_index['stop']==grid['efold'][-1],'new grid inside saved physical history')
        case=next(item for item in source['reports'] if item['model']==model)
        previous=next(item for item in old_source['reports'] if item['model']==model)
        result=next(item for item in projection['reports'] if item['model']==model)
        hashes({result['path']:result['sha256'],result['clock_path']:result['clock_sha256']})
        projected=load(result['path'])
        old_projected=load(parent(SECOND_CELL/LABEL/'projection-cell02'/f'{model}-projection.npz'))
        old_cumulative=load(parent(SECOND_CELL/LABEL/'accumulation-01'/f'{model}-accumulation.npz'))
        require(np.array_equal(projected['indices'],np.arange(intervals+1)),'complete projected panel')
        require(np.array_equal(projected['reference_scale'],old_projected['reference_scale']),'identical terminal reference')
        certificate,clock_measure,clock_bounds=certify(load(entry['phase_path']),grid,model)
        require(certificate==result['clock'] and np.array_equal(clock_measure,projected['polynomial_jacobian'])
                and np.array_equal(clock_bounds,projected['clock_bounds']),'independent stored-polynomial clock certificate')
        curves,row_norm=adjoints(model,consumed)
        require(len(case['nodes'])==len(case['phase_controls'])==intervals+1,'complete paired source controls')
        for node,control in zip(case['nodes'],case['phase_controls']):
            index=node['index']
            require(control['index']==index and node['model']==control['model']==model,'paired metadata')
            for item in (node,control):
                hashes({item['path']:item['sha256']})
            checked_point(model,index)
            packet,phase=load(node['path']),load(control['path'])
            require(float(packet['efold'])==grid['efold'][index] and float(packet['phase'])==grid['phase'][index]
                    and float(packet['jacobian'])==grid['jacobian'][index],'source on frozen physical coordinates')
            require(np.array_equal(projected['projected'][index],packet['projected'])
                    and np.array_equal(projected['phase_projected'][index],phase['projected']),'same source and phase control projected')
            if index==0:
                for item,original in ((node,previous['nodes'][-1]),(control,previous['phase_controls'][-1])):
                    require(item['reused_shared_boundary'] and item['previous_cell_grid_index']==original['index']
                            and item['path']==original['path'] and item['sha256']==original['sha256'],'immutable shared-boundary reuse')
                    parent(item['path'])
                counts['reused_boundary_points']+=1
            else:
                for item in (node,control):
                    hashes(item['sources']);hashes(item['consumed'])
                hashes({control['profile_report']:control['profile_report_sha256']})
                profile=take(control['profile_report'])
                if model=='heavy':
                    hashes({profile['path']:profile['sha256']})
                require(all(np.isfinite(value).all() for value in packet.values()) and all(np.isfinite(value).all() for value in phase.values()),'finite native packets')
                require(np.array_equal(packet['difference'],packet['reference_rates']-packet['retained_rates']),'native difference sign')
                maxima['frame']=max(maxima['frame'],check_frame(packet,packet['retained_vectors'],packet['native_vectors'],packet['difference'],packet['forcing']))
                if model=='heavy':
                    snapshot={key.removeprefix('map_'):value for key,value in phase.items() if key.startswith('map_')}
                    maxima['phase_frame']=max(maxima['phase_frame'],check_frame(snapshot,packet['retained_vectors'],phase['native_native_vectors'],phase['native_difference'],packet['forcing']+phase['source_change']))
                    require(node['checks']['clock']['minimum_speed']>0 and node['checks']['clock']['contraction_bound']<1,'physical phase clock')
                else:
                    require(np.all(phase['source_change']==0),'only absent baseline phase control is zero')
                for order,name in enumerate(('fine','interpolation-coarse','step-coarse')):
                    adjoint=curves[name](float(packet['efold']))*row_norm[:,:,None]
                    for actual,forcing in ((packet['projected'][order],packet['forcing']),(phase['projected'][order],phase['source_change'])):
                        expected=np.einsum('obd,bdv->bvo',adjoint,forcing)
                        deviation=relative(expected,actual)
                        require(deviation<ALGEBRA,'independent adjoint contraction')
                        maxima['adjoint_contraction']=max(maxima['adjoint_contraction'],deviation)
                for key in ('primitive_refinement','primitive_closure'):
                    require(node['checks'][key]<ALGEBRA,'unchanged phase primitive accuracy')
                    maxima[key]=max(maxima[key],node['checks'][key])
                if index==intervals:
                    require(node['original_map_errors'] is not None and max(node['original_map_errors'])<ALGEBRA,'original source12 endpoint map')
                counts['new_points']+=1
            counts['phase_controls']+=1
        coordinate,jacobian=projected['coordinate'],projected['jacobian']
        values,phases=projected['projected'],projected['phase_projected']
        signal=values[:,0,:,0]
        width=float(grid['efold'][-1]-grid['efold'][0])
        for name,stride in (('fine',1),('coarse',2),('coarser',4)):
            signed=simpson(signal[::stride]*jacobian[::stride,None,None],x=coordinate[::stride],axis=0)
            budget=np.sqrt(width*np.maximum(simpson(signal[::stride]**2*jacobian[::stride,None,None],x=coordinate[::stride],axis=0),0.))
            require(np.array_equal(signed,projected[name+'_signed']) and np.array_equal(budget,projected[name+'_cauchy']),'same source integral and conditional Cauchy expression')
        changes=dict(current=values[:,0,:,1],phase=phases[:,0,:,0],cross=phases[:,0,:,1],
            adjoint_interpolation=values[:,1,:,0]-signal,adjoint_steps=values[:,2,:,0]-signal)
        changes['current_and_phase']=changes['current']+changes['phase']+changes['cross']
        for name,change in changes.items():
            calculated=simpson(change*jacobian[:,None,None],x=coordinate,axis=0)
            require(np.array_equal(calculated,projected['change_'+name]),'unchanged separate control')
        require(np.array_equal(simpson(signal*(clock_measure-jacobian)[:,None,None],x=coordinate,axis=0),projected['change_clock_measure']),'clock measure control')
        volume_error=abs(float(projected['fine_volume'])-width)/width
        rows=[row for row in projection['records'] if row['model']==model]
        require(len(rows)==20,'ten outputs and both branches')
        accumulated_result=next(item for item in accumulation['reports'] if item['model']==model)
        hashes({accumulated_result['path']:accumulated_result['sha256']})
        combined=load(accumulated_result['path'])
        require(np.array_equal(combined['reference_scale'],projected['reference_scale']),'same accumulated physical scale')
        require(np.array_equal(combined['boundaries'],np.r_[old_cumulative['boundaries'],grid['efold'][-1]]),'adjacent source domains without overlap')
        for name in ('fine','coarse','coarser'):
            require(np.array_equal(combined[name+'_signed'],old_cumulative[name+'_signed']+projected[name+'_signed']),'signed cell contributions added')
            require(np.array_equal(combined[name+'_triangle_budget'],old_cumulative[name+'_triangle_budget']+projected[name+'_cauchy']),'conditional budgets added without cancellation')
        change_names=[key for key in projected if key.startswith('change_')]
        for name in change_names:
            require(np.array_equal(combined[name],old_cumulative[name]+projected[name])
                    and np.array_equal(combined[name+'_absolute_sum'],old_cumulative[name+'_absolute_sum']+abs(projected[name])),'signed and conservative numerical controls')
        require(np.array_equal(combined['quadrature_absolute_sum'],old_cumulative['quadrature_absolute_sum']+abs(projected['fine_signed']-projected['coarse_signed'])),'absolute refinement changes retained')
        require(np.array_equal(combined['budget_change_absolute_sum'],old_cumulative['budget_change_absolute_sum']+abs(projected['fine_cauchy']-projected['coarse_cauchy'])),'absolute budget changes retained')
        for row in rows:
            branch,column=BRANCHES.index(row['branch']),NAMES.index(row['channel'])
            index=(branch,column)
            budget=max(float(projected['fine_cauchy'][index]),1e-80)
            diagnostics=dict(quadrature=abs(projected['fine_signed'][index]-projected['coarse_signed'][index])/budget,
                budget=abs(projected['fine_cauchy'][index]-projected['coarse_cauchy'][index])/budget)
            diagnostics.update({name:abs(projected['change_'+name][index])/budget for name in (*changes,'clock_measure')})
            require(all(float(value)==row['diagnostics'][name] for name,value in diagnostics.items()),'unchanged diagnostic values')
            inside=abs(projected['fine_signed'][index])<=budget*(1+GATE)
            passed=bool(max(diagnostics.values())<GATE and volume_error<GATE and inside)
            require(row['numerical_pass']==passed,'failure flags not promoted')
            require(row['physical_contribution_fraction']==float(projected['fine_signed'][index]/projected['reference_scale'][index]),'physical contribution units')
            prior=next(item for item in old_accumulation['records'] if item['model']==model and item['branch']==row['branch'] and item['channel']==row['channel'])
            accumulated=next(item for item in accumulation['records'] if item['model']==model and item['branch']==row['branch'] and item['channel']==row['channel'])
            total_budget=max(float(combined['fine_triangle_budget'][index]),1e-80)
            total_diag=dict(quadrature=float(combined['quadrature_absolute_sum'][index]/total_budget),
                budget=float(combined['budget_change_absolute_sum'][index]/total_budget))
            total_diag.update({name.removeprefix('change_'):float(combined[name+'_absolute_sum'][index]/total_budget) for name in change_names})
            expected=bool(prior['numerical_pass'] and passed and max(total_diag.values())<GATE and abs(combined['fine_signed'][index])<=total_budget*(1+GATE))
            require(total_diag==accumulated['diagnostics'] and accumulated['cell_numerical_passes']==prior['cell_numerical_passes']+[passed]
                    and accumulated['numerical_pass']==expected,'cancellation cannot mask failing cells')
            require(accumulated['physical_contribution_fraction']==float(combined['fine_signed'][index]/combined['reference_scale'][index])
                    and accumulated['physical_budget_fraction']==float(total_budget/combined['reference_scale'][index]),'accumulated physical units')
            counts['projected_channels']+=1;counts['accumulated_channels']+=1
        summary.append(dict(model=model,passed=sum(row['numerical_pass'] for row in rows),
            largest_physical_contribution=max(abs(row['physical_contribution_fraction']) for row in rows),
            largest_physical_budget=max(row['physical_budget_fraction'] for row in rows),
            diagnostic_maxima={name:max(row['diagnostics'][name] for row in rows) for name in rows[0]['diagnostics']},
            accumulated=accumulated_result,clock=certificate,volume_error=volume_error))
    total_new=sum(item['intervals'] for item in grid_report['reports'])
    require(counts==dict(history_controls=4,reused_boundary_points=2,new_points=total_new,phase_controls=total_new+2,projected_channels=40,accumulated_channels=40),'complete scope')
    for path in STAGE.glob('*.start.json'):
        start=read(path)
        hashes({start['source_path']:start['source_sha256']})
        phase=path.name.removesuffix('.start.json')
        if phase=='audit-01':
            require(start['pid']==os.getpid(),'current auditor identity')
            continue
        end=read(STAGE/(phase+'.end.json'))
        require(all(start[key]==end[key] for key in ('pid','created','command')) and end['exit_code']==(1 if phase=='history-balanced-01' else 0),'preserved failed reference check or completed owned worker')
        if psutil.pid_exists(start['pid']):
            created=datetime.fromisoformat(start['created'].replace('Z','+00:00')).timestamp()
            require(abs(psutil.Process(start['pid']).create_time()-created)>1,'owned worker exited')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,maxima=maxima,summary=summary,original_bank_grids_tolerances_unchanged=True,no_response_reset=True,
        all_numerical_controls_pass=all(row['passed']==20 and row['accumulated']['passed']==20 for row in summary),
        failed_reference_attempt_preserved=True,reference_epoch_repair_verified=True,
        original_cell_indices=[8,12],accumulated_cells=[[0,4],[4,8],[8,12]],github_actions=False))
    print(json.dumps(dict(counts=counts,maxima=maxima,summary=summary),indent=2),flush=True)


if __name__=='__main__':
    main()
