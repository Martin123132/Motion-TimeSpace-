from common import *
from response_support import NAMES,BRANCHES
from scipy.integrate import simpson
import numpy as np


def support_count(values,fraction):
    total=float(np.sum(abs(values)))
    if total==0.:
        return 0
    return int(np.searchsorted(np.cumsum(np.sort(abs(values))[::-1]),fraction*total)+1)


def main():
    modest()
    output=ROOT/'quadrature-diagnosis-01'
    output.mkdir(exist_ok=False)
    source_path=ROOT/'projection-cell03/result.json'
    result=read(source_path)
    require(result['completed'],'completed unaltered third-cell projection')
    consumed={str(source_path):digest(source_path)}
    records=[]
    reports=[]
    for entry in result['reports']:
        model=entry['model']
        require(digest(entry['path'])==entry['sha256'],'unchanged projected source')
        consumed[entry['path']]=entry['sha256']
        data=load(entry['path'])
        coordinate=data['coordinate']
        signal=data['projected'][:,0,:,0]
        jacobian=data['jacobian']
        require((len(coordinate)-1)%4==0,'nested complete panel')
        signed=[]
        moment=[]
        for begin in range(0,len(coordinate)-1,4):
            section=slice(begin,begin+5)
            domain=coordinate[section]
            measure=jacobian[section,None,None]
            values=signal[section]
            signed.append(simpson(values*measure,x=domain,axis=0)-simpson((values*measure)[::2],x=domain[::2],axis=0))
            moment.append(simpson(values**2*measure,x=domain,axis=0)-simpson((values**2*measure)[::2],x=domain[::2],axis=0))
        signed=np.array(signed);moment=np.array(moment)
        budget=np.maximum(data['fine_cauchy'],1e-80)
        width=float(data['fine_volume'])
        signed_identity=float(np.max(abs(np.sum(signed,axis=0)-(data['fine_signed']-data['coarse_signed']))/budget))
        moment_identity=float(np.max(abs(width*np.sum(moment,axis=0)-(data['fine_cauchy']**2-data['coarse_cauchy']**2))/budget**2))
        require(signed_identity<ALGEBRA and moment_identity<ALGEBRA,'panel localization reproduces the global refinement change')
        local=[]
        for branch,branch_name in enumerate(BRANCHES):
            for column,name in enumerate(NAMES):
                index=(branch,column)
                row=next(row for row in result['records'] if row['model']==model and row['branch']==branch_name and row['channel']==name)
                latest=abs(data['fine_signed'][index]-data['coarse_signed'][index])
                earlier=abs(data['coarse_signed'][index]-data['coarser_signed'][index])
                latest_budget=abs(data['fine_cauchy'][index]-data['coarse_cauchy'][index])
                earlier_budget=abs(data['coarse_cauchy'][index]-data['coarser_cauchy'][index])
                other_names=[key for key in row['diagnostics'] if key not in ('quadrature','budget')]
                other_pass=all(row['diagnostics'][key]<GATE for key in other_names)
                item=dict(model=model,branch=branch_name,channel=name,numerical_pass=row['numerical_pass'],
                    quadrature=row['diagnostics']['quadrature'],budget_change=row['diagnostics']['budget'],
                    signed_change_ratio=float(latest/earlier) if earlier else None,
                    budget_change_ratio=float(latest_budget/earlier_budget) if earlier_budget else None,
                    physical_quadrature_change=float(latest/data['reference_scale'][index]),
                    physical_budget_change=float(latest_budget/data['reference_scale'][index]),
                    contribution_to_cauchy=float(abs(data['fine_signed'][index])/budget[index]),
                    signed_panels_for_90_percent=support_count(signed[:,branch,column],.9),
                    moment_panels_for_90_percent=support_count(moment[:,branch,column],.9),
                    largest_signed_panel=int(np.argmax(abs(signed[:,branch,column]))),
                    largest_moment_panel=int(np.argmax(abs(moment[:,branch,column]))),
                    other_controls_pass=other_pass,
                    both_changes_shrink=bool(earlier>latest and earlier_budget>latest_budget))
                local.append(item);records.append(item)
        path=output/f'{model}-panel-differences.npz'
        np.savez_compressed(path,coordinate_edges=coordinate[::4],signed_difference=signed,second_moment_difference=moment,
                            reference_scale=data['reference_scale'])
        reports.append(dict(model=model,path=str(path),sha256=digest(path),panels=len(signed),
            signed_identity=signed_identity,moment_identity=moment_identity,
            failing=[row for row in local if not row['numerical_pass']],
            largest_physical_quadrature_change=max(row['physical_quadrature_change'] for row in local)))
    failing=[row for row in records if row['model']=='heavy' and not row['numerical_pass']]
    candidate=bool(failing and all(row['other_controls_pass'] and row['both_changes_shrink'] for row in failing))
    decision='one paired source-quadrature refinement level, retaining all old samples' if candidate else 'inspect nonshrinking controls or other failures before adding source points'
    write(output/'result.json',dict(passed=True,sources=sources(),consumed=consumed,reports=reports,records=records,
        no_new_physical_evaluation=True,original_bank_grids_tolerances_unchanged=True,
        new_accuracy_pass_claimed=False,decision=decision,automatic_new_native_work_started=False))
    print(json.dumps(dict(failing_mts=failing,decision=decision),indent=2),flush=True)


if __name__=='__main__':
    main()
