from common import *
from response_support import *
from native_time_v2 import NativeTimeV2
from native_time import to_native,to_retained,relative,CommonCarrierFibre
from correlated_source import full_average,correlated,full_endpoint
from matching_source import frozen_source
from physical_energy_map import PhysicalEnergyMap
from clock_primitive import phase_clock
from scipy.sparse import block_diag,csc_matrix,diags,eye
from scipy.sparse.linalg import splu
import numpy as np
import time


class PhaseSource(NativeTimeV2):
    def __init__(self,model,mode):
        super().__init__(model,'points-01/contexts-'+mode+'-'+model)
        data=original_data(model)
        self.owner,self.forcing,self.bank,self.leading,self.slow,self.response,self.feedback,self.drift,self.kernel,paths=data
        self.consumed.update(paths)
        self.energy=PhysicalEnergyMap(self.system)
        report_path=ROOT/'history-01/result.json'
        report=read(report_path)
        require(report['passed'],'completed paired current histories')
        self.histories={}
        self.consumed[str(report_path)]=digest(report_path)
        for control in ('fine','step-coarse'):
            item=next(item for item in report['reports'] if item['model']==model and item['control']==control)
            require(digest(item['index'])==item['sha256'],'original current-history index')
            self.consumed[item['index']]=item['sha256']
            self.histories[control]=DenseHistory(item['index'])
        self.adjoints,self.row_norm=adjoints(model,self.consumed)
        self.operator=DualOperator(self.owner,self.bank)

    def current(self,efold,control):
        theta,blocks=self.histories[control].state(efold)
        primitive=self.kernel.response(self.forcing,efold,theta)[1].sum(axis=0) if self.model=='heavy' else np.zeros_like(blocks[0])
        current=blocks.sum(axis=0)+primitive
        return theta,current

    def point_frame(self,efold,theta):
        frozen=self.owner.frozen(efold)
        mean=full_average(frozen,self.model,theta)
        physical=correlated(frozen,theta)[0] if self.model=='heavy' else frozen
        state=np.array([efold,physical['values'][0]/(np.exp(efold)*self.owner.saved.masses[0]),*physical['values'][1:]])
        carrier,rate=self.system.owner.phase(efold) if self.model=='heavy' else (0.,0.)
        self.restore_window()
        try:
            with CommonCarrierFibre(self.system) as fibre:
                fibre.chart_angle=carrier
                fibre.carrier_rate=rate
                fibre.common_carrier=True
                current,maps,point,direct,paths=frozen_source(fibre,self.energy,state,theta)
                self.consumed.update(paths)
        finally:
            self.restore_window()
        dimension=self.dimension
        compact=current['layout']['size']
        matrix=block_diag((csc_matrix(maps['transform']),diags(maps['tail_weights'])),format='csc')
        entries=[]
        forward_values,inverse_values=[],[]
        for branch in range(2):
            forward=np.eye(compact)
            inverse=np.eye(compact)
            slots=current['layout']['heavy']
            if slots:
                forward[slots]+=maps['forward_correction'][branch]
                inverse[slots]+=maps['inverse_correction'][branch]
            endpoint=full_endpoint(mean['endpoint'][branch],mean['remote_keys'],mean['remote_stream'],
                                   float(mean['remote_endpoint']),dimension)
            forward_values.append(forward)
            inverse_values.append(inverse)
            entries.append(dict(forward=block_diag((csc_matrix(forward),eye(dimension-compact)),format='csc'),
                inverse=block_diag((csc_matrix(inverse),eye(dimension-compact)),format='csc'),
                endpoint=endpoint,endpoint_lu=splu(endpoint)))
        value=dict(frame=matrix,frame_lu=splu(matrix),branches=entries)
        snapshot=dict(physical_core=maps['transform'],physical_tail=maps['tail_weights'],forward=forward_values,inverse=inverse_values,
            endpoint=mean['endpoint'],remote_keys=mean['remote_keys'],remote_stream=mean['remote_stream'],
            remote_endpoint=np.array(mean['remote_endpoint']))
        matrix_mean,remote_mean=self.operator.values(efold)
        checks=dict(primitive_refinement=float(mean['phase_refinement']),primitive_closure=float(mean['closure']),
            primitive_bound=float(mean.get('full_primitive_bound',0.)),
            mean_interpolation_relative=relative(matrix_mean,mean['mean']),remote_interpolation_relative=relative(remote_mean,mean['remote']))
        if self.model=='heavy':
            speed,_,bound=phase_clock(self.owner,efold,np.array([theta]))
            checks['clock']=bound
        else:
            checks['clock']=dict(no_heavy_phase=True)
        return value,snapshot,checks

    def sample(self,index,grid,output):
        started=time.monotonic()
        efold,theta=float(grid['efold'][index]),float(grid['phase'][index])
        phase,current=self.current(efold,'fine')
        coarse_phase,coarse=self.current(efold,'step-coarse')
        require(abs(phase-theta)<ALGEBRA,'same physical phase on source and current history')
        frame,snapshot,checks=self.point_frame(efold,theta)
        vectors=np.stack([current,coarse-current],axis=-1)
        native=np.array([to_native(frame,item,vectors[branch]) for branch,item in enumerate(frame['branches'])])
        paired=self.native(efold,theta,native)
        forcing=np.array([to_retained(frame,item,paired['difference'][branch]) for branch,item in enumerate(frame['branches'])])
        projected=[]
        for control in ('fine','interpolation-coarse','step-coarse'):
            adjoint=self.adjoints[control](efold)*self.row_norm[:,:,None]
            projected.append(np.einsum('obd,bdv->bvo',adjoint,forcing))
        original_map=None
        if index in (0,len(grid['efold'])-1):
            node_index=8 if index==0 else 12
            path=owned(FRAME_STAGE/LABEL/'source-02'/f'{self.model}-{node_index:02d}-background.npz')
            self.consumed[str(path)]=digest(path)
            previous=load(path)
            errors=[]
            for branch,item in enumerate(frame['branches']):
                transformed=to_native(frame,item,previous['retained_vectors'][branch])
                errors.append(relative(transformed,previous['native_vectors'][branch]))
            require(max(errors)<ALGEBRA,'new quadrature endpoint map preserves original map')
            original_map=errors
        target=output/f'{self.model}-{index:03d}.npz'
        np.savez_compressed(target,efold=efold,phase=theta,jacobian=grid['jacobian'][index],
            current=current,current_change=coarse-current,retained_vectors=vectors,units=self.system.units,
            forcing=forcing,projected=projected,coarse_phase_error=coarse_phase-phase,
            **snapshot,**{key:value for key,value in paired.items() if key not in ('efold','theta')})
        report=dict(passed=True,model=self.model,index=index,path=str(target),sha256=digest(target),
            efold=efold,theta=theta,seconds=time.monotonic()-started,checks=checks,original_map_errors=original_map,
            phase_time_control=abs(coarse_phase-phase),consumed=self.consumed.copy(),sources=sources())
        write(output/f'{self.model}-{index:03d}-result.json',report)
        print(LABEL,self.model,index,'physical source saved',report['seconds'],'seconds',flush=True)
        return report
