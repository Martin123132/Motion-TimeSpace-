from common import *
from cell_support import parent
from response_support import *
from prepare_grid import PhaseDense
from scipy.optimize import brentq
import math
import numpy as np


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'grid-01'
    output.mkdir(exist_ok=False)
    point_output=ROOT/'points-01'
    point_output.mkdir(exist_ok=False)
    history_path=ROOT/'history-02/result.json'
    histories=read(history_path)
    require(histories['passed'],'completed inherited current histories')
    previous_path=parent(SECOND_CELL/LABEL/'points-01/cell02-result.json')
    previous=read(previous_path)
    consumed={str(history_path):digest(history_path),str(previous_path):digest(previous_path)}
    reports=[]
    for model in ('heavy','cold'):
        owner,forcing,bank,leading,slow,response,feedback,drift,kernel,paths=original_data(model)
        consumed.update(paths)
        old_grid_path=parent(SECOND_CELL/LABEL/'grid-01'/f'{model}-grid.npz')
        consumed[str(old_grid_path)]=digest(old_grid_path)
        old_grid=load(old_grid_path)
        control_histories={}
        for control in ('fine','step-coarse'):
            entry=next(item for item in histories['reports'] if item['model']==model and item['control']==control)
            require(entry['parent_endpoint_state_identical'] and digest(entry['index'])==entry['sha256'],'accepted own-control restart')
            consumed[entry['index']]=entry['sha256']
            control_histories[control]=DenseHistory(entry['index'])
        index=control_histories['fine'].index
        collected={key:[] for key in ('left','right','initial','coefficients')}
        for item in index['chunks']:
            require(digest(item['path'])==item['sha256'],'current dense chunk')
            consumed[item['path']]=item['sha256']
            packet=load(item['path'])
            collected['left'].append(packet['left']);collected['right'].append(packet['right'])
            collected['initial'].append(packet['initial'][:,0]);collected['coefficients'].append(packet['coefficients'][:,:,0])
        polynomial={key:np.concatenate(value) for key,value in collected.items()}
        phase=PhaseDense(polynomial)
        phase_path=output/f'{model}-phase-polynomial.npz'
        np.savez_compressed(phase_path,**polynomial)
        start,stop=index['start'],index['stop']
        require(start==old_grid['efold'][-1] and start==bank['efold'][4] and stop==bank['efold'][6],'adjacent original physical cell')
        start_phase,stop_phase=phase(start),phase(stop)
        require(start_phase==old_grid['phase'][-1],'same inherited fine phase')
        max_spacing=float(np.max(np.diff(old_grid['coordinate'])))
        span=stop_phase-start_phase if model=='heavy' else stop-start
        intervals=4*math.ceil(span/(4*max_spacing))
        require(intervals>=4 and intervals%4==0,'nested phase-derived interval count')
        coordinate=np.linspace(start_phase,stop_phase,intervals+1) if model=='heavy' else np.linspace(start,stop,intervals+1)
        require(float(np.max(np.diff(coordinate)))<=max_spacing*(1+ALGEBRA),'no coarser than qualified integration spacing')
        epochs=np.empty(intervals+1)
        epochs[0],epochs[-1]=start,stop
        phases=coordinate if model=='heavy' else np.zeros_like(coordinate)
        if model=='heavy':
            for position in range(1,intervals):
                epochs[position]=brentq(lambda value:phase(value)-phases[position],epochs[position-1],stop,xtol=5e-324,rtol=4*np.finfo(float).eps)
        else:
            epochs=coordinate.copy()
        speeds=np.array([phase_rate(owner,model,float(efold),float(theta)) for efold,theta in zip(epochs,phases)])
        require(model=='cold' or np.all(speeds>0),'positive sampled phase clock')
        jacobian=1/speeds if model=='heavy' else np.ones_like(speeds)
        phase_error=max(abs(phase(float(efold))-theta) for efold,theta in zip(epochs,phases))
        require(phase_error<ALGEBRA and np.all(np.diff(epochs)>0),'original dense phase inversion')
        grid=dict(efold=epochs,phase=phases,coordinate=coordinate,jacobian=jacobian,speed=speeds)
        require(all(grid[key][0]==old_grid[key][-1] for key in grid),'shared boundary coordinate and measure bitwise identical')
        previous_case=next(item for item in previous['reports'] if item['model']==model)
        node=dict(previous_case['nodes'][-1]);control=dict(previous_case['phase_controls'][-1])
        for item in (node,control):
            parent(item['path']);consumed[item['path']]=item['sha256']
        old_point=load(node['path'])
        currents={}
        for name,history in control_histories.items():
            theta,blocks=history.state(start)
            primitive=kernel.response(forcing,start,theta)[1].sum(axis=0) if model=='heavy' else np.zeros_like(blocks[0])
            currents[name]=blocks.sum(axis=0)+primitive
        require(np.array_equal(currents['fine'],old_point['current'])
                and np.array_equal(currents['step-coarse']-currents['fine'],old_point['current_change']),
                'shared source vectors inherited bitwise for both current controls')
        for item,suffix in ((node,'result'),(control,'phase-result')):
            item.update(previous_cell_grid_index=item['index'],index=0,reused_shared_boundary=True)
            write(point_output/f'{model}-000-{suffix}.json',item)
        target=output/f'{model}-grid.npz'
        np.savez_compressed(target,**grid)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),phase_path=str(phase_path),phase_sha256=digest(phase_path),
            points=intervals+1,intervals=intervals,original_indices=[8,10,12],start=start,stop=stop,
            integration_spacing_limit=max_spacing,actual_maximum_spacing=float(np.max(np.diff(coordinate))),phase_error=float(phase_error),
            probe_indices=[intervals//4,intervals//2,3*intervals//4,intervals],shared_boundary_vectors_and_measure_identical=True))
        print(model,intervals+1,'third-cell points frozen; both control histories and source boundary preserved',flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        native_forcing_on_new_points_not_yet_evaluated=True,no_response_reset=True,original_bank_grids_tolerances_unchanged=True))


if __name__=='__main__':
    main()
