from run_batch_v2 import run

if __name__=='__main__':
    run('batch02',2)
