from common import *


MANIFESTS={}


def parent(path):
    path=Path(path)
    for folder,seal in ((SECOND_CELL,'7b136ef644add714c2451d75fe72dc5d6032967f382b70ea4d3eee10b8a26c74'),
                        (FIRST_CELL,'f1083895e9ae9ad3962cfe8dc09446023b52c82384f81e52c6ce868e5e537ce9'),
                        (PHASE_RESPONSE,'e9605e1c81ad5b48ef790ee5f906cd1c29bf628140cc80f5fdd9b1c6ffbf73d2')):
        if path.is_relative_to(folder):
            if folder not in MANIFESTS:
                require(digest(folder/'closeout.json')==seal,'accepted parent seal')
                MANIFESTS[folder]={str(Path(item['path'])):item['sha256'] for item in read(folder/'closeout.json')['artifacts']}
            require(str(path) in MANIFESTS[folder] and digest(path)==MANIFESTS[folder][str(path)],'unchanged inherited artifact '+str(path))
            return path
    raise ValueError('undeclared immediate cell input '+str(path))
