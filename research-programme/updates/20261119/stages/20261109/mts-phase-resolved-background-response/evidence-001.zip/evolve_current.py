from common import *
from response_support import *
from scipy.integrate import solve_ivp
import time
import gc


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'history-01'
    output.mkdir(parents=True,exist_ok=False)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),models=['heavy','cold'],original_indices=[0,2,4],
        controls=[2048,4096],step_span='original full interval, not shortened-cell span',rtol=2e-12,atol=2e-14,
        channels=['leading','slow-normal','slow-map','feedback-normal','feedback-map'],gates=[ALGEBRA,GATE],
        no_physical_reset=True))
    reports=[]
    for model in ('heavy','cold'):
        owner,source,bank,leading,slow,response,feedback,drift,kernel,consumed=original_data(model)
        operator=DualOperator(owner,bank)
        start,stop=float(bank['efold'][0]),float(bank['efold'][2])
        full_span=float(bank['efold'][-1]-bank['efold'][0])
        shape=(5,2,leading['state'].shape[-1])
        norm=np.linalg.norm(leading['state'][0],axis=1)
        normalization=np.concatenate([np.tile(norm,(3,1)),feedback.normalization],axis=0)
        require(normalization.shape==(5,2) and np.all(normalization>0),'original component normalization')
        initial_state=np.concatenate([leading['state'][0][None],slow['eta'][0],response['response'][0]],axis=0)
        initial=np.r_[bank['phase'][0],(initial_state/normalization[:,:,None]).ravel()]
        for control,steps in (('step-coarse',2048),('fine',4096)):
            guard()
            destination=output/model/control
            destination.mkdir(parents=True,exist_ok=False)
            def rhs(efold,flat):
                guard()
                theta=flat[0]
                state=flat[1:].reshape(shape)
                matrix,remote=operator.values(float(efold))
                derivative=operator.apply(state,matrix,remote)
                derivative[1:3]+=(source(efold,0.) if model=='cold' else drift(efold))/normalization[1:3,:,None]
                derivative[3:]+=feedback(efold,theta)/normalization[3:,:,None]
                return np.r_[phase_rate(owner,model,efold,theta),derivative.ravel()]
            started=time.monotonic()
            solution=solve_ivp(rhs,(start,stop),initial,method='DOP853',rtol=2e-12,atol=2e-14,
                               max_step=full_span/steps,dense_output=True)
            require(solution.success and np.isfinite(solution.y).all(),'original current equations integrated')
            sampled=solution.sol(bank['efold'][:3]).T
            phase_error=float(np.max(abs(sampled[:,0]-bank['phase'][:3])))
            require(phase_error<ALGEBRA,'same inherited physical phase')
            blocks=sampled[:,1:].reshape(3,*shape)*normalization[None,:,:,None]
            old=np.concatenate([leading['state'][:3,None],slow['eta'][:3],response['response'][:3]],axis=1)
            current_error=float(np.max(np.linalg.norm((blocks-old).sum(axis=1),axis=-1)/norm[None]))
            require(current_error<GATE,'reproduces saved carried mode at unchanged physical gate')
            block_error=np.linalg.norm(blocks-old,axis=-1)/np.maximum(np.linalg.norm(old,axis=-1),1e-80)
            chunks=[]
            pieces=solution.sol.interpolants
            for begin in range(0,len(pieces),32):
                selected=pieces[begin:begin+32]
                target=destination/f'chunk-{begin//32:04d}.npz'
                np.savez_compressed(target,left=[item.t_old for item in selected],right=[item.t for item in selected],
                    initial=[item.y_old for item in selected],coefficients=[item.F for item in selected])
                chunks.append(dict(path=str(target),sha256=digest(target)))
            index=destination/'index.json'
            write(index,dict(start=start,stop=stop,shape=shape,normalization=normalization.tolist(),
                right=[item.t for item in pieces],chunks=chunks,method='unaltered DOP853 dense polynomial',steps=steps))
            dense=DenseHistory(index)
            probe_epochs=np.unique(np.r_[bank['efold'][:3],np.linspace(start,stop,17)])
            maximum=0.
            for efold in probe_epochs:
                actual=dense.raw(float(efold))
                expected=solution.sol(float(efold))
                maximum=max(maximum,float(np.linalg.norm(actual-expected)/max(np.linalg.norm(expected),1e-80)))
            require(maximum<ALGEBRA,'saved polynomial reproduces original solver dense output')
            sample_path=destination/'saved-node-check.npz'
            np.savez_compressed(sample_path,efold=bank['efold'][:3],phase=sampled[:,0],blocks=blocks,reference_blocks=old,
                                block_relative_error=block_error)
            record_row=dict(model=model,control=control,index=str(index),sha256=digest(index),sample_path=str(sample_path),
                sample_sha256=digest(sample_path),pieces=len(pieces),nfev=solution.nfev,seconds=time.monotonic()-started,
                dense_roundtrip=maximum,phase_error=phase_error,current_error=current_error,
                same_preparation=bool(np.array_equal(sampled[0],initial)),
                maximum_block_relative_error=float(block_error.max()),consumed=consumed.copy())
            require(record_row['same_preparation'],'no changed incoming state')
            write(destination/'result.json',dict(passed=True,inputs=inputs,sources=sources(),**record_row))
            reports.append(record_row)
            print(LABEL,model,control,'dense current saved',record_row['seconds'],'seconds',record_row['pieces'],'pieces',current_error,flush=True)
            del solution,pieces,dense
            gc.collect()
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,
        reference_physical_predictions_not_read=True,original_bank_grids_tolerances_unchanged=True))


if __name__=='__main__':
    main()

