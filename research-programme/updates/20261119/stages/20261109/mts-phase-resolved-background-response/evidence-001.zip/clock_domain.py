from fractions import Fraction
from math import comb
import numpy as np
from common import require


def polynomial_coefficients(values):
    coefficients=[Fraction(0)]
    for number,value in enumerate(reversed(values)):
        coefficients[0]+=Fraction(float(value))
        if number%2==0:
            coefficients=[Fraction(0),*coefficients]
        else:
            product=[Fraction(0)]*(len(coefficients)+1)
            for index,coefficient in enumerate(coefficients):
                product[index]+=coefficient
                product[index+1]-=coefficient
            coefficients=product
    return coefficients


def lower_float(value):
    result=float(value)
    if Fraction(result)>value:
        result=float(np.nextafter(result,-np.inf))
    return result


def upper_float(value):
    result=float(value)
    if Fraction(result)<value:
        result=float(np.nextafter(result,np.inf))
    return result


def certify(packet,grid,model):
    slopes=[]
    bounds=[]
    extension=Fraction(1)+Fraction(1,2**48)
    for left,right,values in zip(packet['left'],packet['right'],packet['coefficients']):
        width=float(right-left)
        require(width>0,'positive saved dense step')
        exact_width=Fraction(float(right))-Fraction(float(left))
        require(exact_width/Fraction(width)<=extension,'expanded polynomial domain covers exact endpoints')
        coefficients=polynomial_coefficients(values)
        derivative=[index*coefficient for index,coefficient in enumerate(coefficients)][1:]
        degree=len(derivative)-1
        expanded=[coefficient*extension**index/Fraction(width) for index,coefficient in enumerate(derivative)]
        bernstein=[sum((expanded[index]*Fraction(comb(position,index),comb(degree,index)) for index in range(position+1)),Fraction(0))
                   for position in range(degree+1)]
        low,high=min(bernstein),max(bernstein)
        require(low>0 if model=='heavy' else low==high==0,'exact stored-polynomial clock sign')
        bounds.append((lower_float(low),upper_float(high)))
        slopes.append(np.array([float(value/Fraction(width)) for value in derivative]))
    point_rates=[]
    for efold in grid['efold']:
        piece=min(int(np.searchsorted(packet['right'],efold,side='left')),len(slopes)-1)
        local=(efold-packet['left'][piece])/(packet['right'][piece]-packet['left'][piece])
        point_rates.append(np.polynomial.polynomial.polyval(local,slopes[piece]))
    point_rates=np.array(point_rates)
    if model=='heavy':
        require(np.all(point_rates>0),'inverse clock at quadrature points')
        jacobian=1/point_rates
        physical_change=float(np.max(abs(point_rates-grid['speed'])/grid['speed']))
    else:
        jacobian=np.ones_like(point_rates)
        physical_change=0.
    return dict(pieces=len(bounds),lower=min(item[0] for item in bounds),upper=max(item[1] for item in bounds),
                exact_rational_finite_polynomial_certificate=True,original_ODE_continuum_certificate=False,
                phase_derivative_at_nodes_relative_change=physical_change),jacobian,np.array(bounds)

