from common import *
from response_support import *
from scipy.optimize import brentq
import numpy as np


class PhaseDense:
    def __init__(self,packet):
        self.packet=packet

    def __call__(self,efold):
        packet=self.packet
        piece=min(int(np.searchsorted(packet['right'],efold,side='left')),len(packet['right'])-1)
        coordinate=(efold-packet['left'][piece])/(packet['right'][piece]-packet['left'][piece])
        answer=0.
        for number,value in enumerate(reversed(packet['coefficients'][piece])):
            answer+=value
            answer*=coordinate if number%2==0 else 1-coordinate
        return answer+packet['initial'][piece]


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'grid-01'
    output.mkdir(exist_ok=False)
    history_path=ROOT/'history-01/result.json'
    history=read(history_path)
    require(history['passed'],'paired original dense history')
    consumed={str(history_path):digest(history_path)}
    reports=[]
    for model in ('heavy','cold'):
        owner,source,bank,leading,slow,response,feedback,drift,kernel,paths=original_data(model)
        consumed.update(paths)
        record_row=next(item for item in history['reports'] if item['model']==model and item['control']=='fine')
        require(digest(record_row['index'])==record_row['sha256'],'dense history index unchanged')
        index=read(record_row['index'])
        consumed[record_row['index']]=record_row['sha256']
        collected={key:[] for key in ('left','right','initial','coefficients')}
        for chunk in index['chunks']:
            require(digest(chunk['path'])==chunk['sha256'],'original dense chunks')
            consumed[chunk['path']]=chunk['sha256']
            packet=load(chunk['path'])
            collected['left'].append(packet['left'])
            collected['right'].append(packet['right'])
            collected['initial'].append(packet['initial'][:,0])
            collected['coefficients'].append(packet['coefficients'][:,:,0])
        phase_packet={key:np.concatenate(value) for key,value in collected.items()}
        phase=PhaseDense(phase_packet)
        phase_path=output/f'{model}-phase-polynomial.npz'
        np.savez_compressed(phase_path,**phase_packet)
        start,stop=index['start'],index['stop']
        left,right=phase(start),phase(stop)
        phases=np.linspace(left,right,257) if model=='heavy' else np.zeros(257)
        epochs=np.empty(257)
        epochs[0],epochs[-1]=start,stop
        if model=='heavy':
            for position in range(1,256):
                epochs[position]=brentq(lambda efold:phase(efold)-phases[position],epochs[position-1],stop,
                                        xtol=5e-324,rtol=4*np.finfo(float).eps)
        else:
            epochs=np.linspace(start,stop,257)
        require(np.all(np.diff(epochs)>0),'ordered unchanged-domain quadrature points')
        phase_error=float(max(abs(phase(float(efold))-theta) for efold,theta in zip(epochs,phases)))
        require(phase_error<ALGEBRA,'inverse phase grid reproduces saved equation')
        speeds=np.array([phase_rate(owner,model,float(efold),float(theta)) for efold,theta in zip(epochs,phases)])
        require(model=='cold' or np.all(speeds>0),'positive sampled physical clock')
        coordinate=phases if model=='heavy' else epochs
        jacobian=1/speeds if model=='heavy' else np.ones(257)
        target=output/f'{model}-grid.npz'
        np.savez_compressed(target,efold=epochs,phase=phases,coordinate=coordinate,jacobian=jacobian,speed=speeds)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),phase_path=str(phase_path),
            phase_sha256=digest(phase_path),phase_error=phase_error,speed_min=float(speeds.min()),speed_max=float(speeds.max()),
            start=start,stop=stop,points=257,coarse_points=[129,65],positive_clock_at_samples_only=True))
        print(LABEL,model,'phase grid frozen',phase_error,flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        original_physical_input_grids_unchanged=True,quadrature_rule='nested composite Simpson on phase for MTS, N for baseline',
        native_forcing_on_new_points_not_yet_evaluated=True))


if __name__=='__main__':
    main()

