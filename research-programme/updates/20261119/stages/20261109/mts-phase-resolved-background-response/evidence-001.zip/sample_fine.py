from sample_sources import run

if __name__=='__main__':
    run('fine',1)
