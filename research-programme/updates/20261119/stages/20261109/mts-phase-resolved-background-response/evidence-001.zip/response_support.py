from common import *
from accumulated_support_v2 import retained_checked,DualOperator,ProductForcing,NAMES,BRANCHES
from clock_primitive import KernelBank
from feedback_support import FeedbackSource,phase_rate
from correlated_source import CorrelatedSource
from scipy.interpolate import BPoly
import numpy as np


def record(consumed,path):
    path=owned(path)
    consumed[str(path)]=digest(path)
    return path


class DenseHistory:
    def __init__(self,path):
        self.index=read(path)
        self.right=np.array(self.index['right'])
        self.chunk=-1
        self.packet=None
        self.normalization=np.array(self.index['normalization'])
        self.shape=tuple(self.index['shape'])

    def raw(self,efold):
        require(self.index['start']<=efold<=self.index['stop'],'saved dense first-cell domain')
        piece=min(int(np.searchsorted(self.right,efold,side='left')),len(self.right)-1)
        chunk=piece//32
        if self.chunk!=chunk:
            item=self.index['chunks'][chunk]
            require(digest(item['path'])==item['sha256'],'dense chunk unchanged')
            self.packet=load(item['path'])
            self.chunk=chunk
        local=piece%32
        packet=self.packet
        coordinate=(efold-packet['left'][local])/(packet['right'][local]-packet['left'][local])
        answer=np.zeros_like(packet['initial'][local])
        for number,coefficient in enumerate(reversed(packet['coefficients'][local])):
            answer+=coefficient
            answer*=coordinate if number%2==0 else 1-coordinate
        return answer+packet['initial'][local]

    def state(self,efold):
        value=self.raw(float(efold))
        return float(value[0]),value[1:].reshape(self.shape)*self.normalization[:,:,None]


def original_data(model):
    consumed={}
    source,bank,leading,paths=retained_checked(model)
    consumed.update(paths)
    owner=CorrelatedSource(model)
    consumed.update(owner.consumed)
    slow_path=ACCUM_STAGE/LABEL/'slow-response-01'/f'{model}-fine.npz'
    if LABEL=='half' and model=='cold':
        slow_path=ACCUM_STAGE/LABEL/'baseline-identity-01/cold-fine.npz'
    slow=load(record(consumed,slow_path))
    response=load(record(consumed,RESPONSE_STAGE/LABEL/'forward-01'/model/'fine.npz'))
    packet=load(record(consumed,RESPONSE_STAGE/LABEL/'preparation-01'/f'{model}-source.npz'))
    feedback=FeedbackSource(packet)
    drift=ProductForcing(load(record(consumed,ACCUM_STAGE/LABEL/'preparation-03'/f'{model}-q-fine.npz')))
    kernel=KernelBank(load(record(consumed,CLOCK_STAGE/'kernel-bank-01/heavy-kernels.npz'))) if model=='heavy' else None
    return owner,source,bank,leading,slow,response,feedback,drift,kernel,consumed


def adjoints(model,consumed):
    splines={}
    row_norm=None
    for control in ('fine','step-coarse'):
        path=record(consumed,RESPONSE_STAGE/LABEL/'projection-02'/f'{model}-{control}-adjoint-jets.npz')
        packet=load(path)
        derivatives=np.stack([packet['state'],packet['first'],packet['second']],axis=1)
        splines[control]=BPoly.from_derivatives(packet['efold'],list(derivatives))
        if control=='fine':
            splines['interpolation-coarse']=BPoly.from_derivatives(packet['efold'][::2],list(derivatives[::2]))
            row_norm=packet['row_norm']
        else:
            require(np.array_equal(row_norm,packet['row_norm']),'same physical adjoint normalization')
    return splines,row_norm

