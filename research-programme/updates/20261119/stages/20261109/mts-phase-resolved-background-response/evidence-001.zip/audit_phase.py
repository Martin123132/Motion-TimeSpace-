from common import *
from response_support import adjoints, NAMES, BRANCHES
from correlated_source import full_endpoint
from scipy.sparse import block_diag, csc_matrix, diags, eye
import numpy as np
import psutil


def relative(left, right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left), np.linalg.norm(right), 1e-80))


def quadratic_integral(values, coordinate):
    left = np.diff(coordinate)[::2]
    right = np.diff(coordinate)[1::2]
    expand = (slice(None),)+(None,)*(values.ndim-1)
    first = ((left+right)/6*(2-right/left))[expand]
    middle = ((left+right)**3/(6*left*right))[expand]
    last = ((left+right)/6*(2-left/right))[expand]
    return np.sum(first*values[:-2:2]+middle*values[1::2]+last*values[2::2], axis=0)


def check_frame(snapshot, vectors, native, difference, forcing):
    dimension = vectors.shape[1]
    compact = snapshot['physical_core'].shape[0]
    physical = block_diag((csc_matrix(snapshot['physical_core']), diags(snapshot['physical_tail'])), format='csc')
    errors = []
    for branch in range(2):
        forward = block_diag((csc_matrix(snapshot['forward'][branch]), eye(dimension-compact)), format='csc')
        inverse = block_diag((csc_matrix(snapshot['inverse'][branch]), eye(dimension-compact)), format='csc')
        endpoint = full_endpoint(snapshot['endpoint'][branch], snapshot['remote_keys'], snapshot['remote_stream'],
                                 float(snapshot['remote_endpoint']), dimension)
        for column in range(2):
            errors.append(relative(physical@native[branch, :, column], forward@(endpoint@vectors[branch, :, column])))
            errors.append(relative(endpoint@forcing[branch, :, column], inverse@(physical@difference[branch, :, column])))
    require(max(errors)<ALGEBRA, 'independent source and moving-frame identities')
    return max(errors)


def main():
    modest()
    output = STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs = verify_inputs()
    consumed, accepted, verified = {}, {}, {}
    counts = dict(histories=0, source_points=0, phase_controls=0, projection_rows=0)
    maxima = dict(frame=0., phase_frame=0., projection=0., primitive_refinement=0., primitive_closure=0.)

    def hashes(records):
        for path, seal in records.items():
            guard()
            if path not in verified:
                verified[path] = digest(path)
            require(verified[path]==seal, 'unchanged input '+path)
            consumed[path] = seal

    def take(path):
        value = read(path)
        require(value.get('passed') or value.get('completed'), 'complete report '+str(path))
        for key in ('inputs', 'sources', 'consumed'):
            hashes(value.get(key, {}))
        accepted[str(path)] = digest(path)
        return value

    history = take(ROOT/'history-01/result.json')
    freeze = read(ROOT/'history-01/freeze.json')
    require(freeze['gates']==[ALGEBRA, GATE] and freeze['controls']==[2048, 4096]
            and freeze['rtol']==2e-12 and freeze['atol']==2e-14 and freeze['no_physical_reset'], 'original preparation and numerical controls')
    for entry in history['reports']:
        hashes(entry['consumed'])
        hashes({entry['index']:entry['sha256'], entry['sample_path']:entry['sample_sha256']})
        index = read(entry['index'])
        for chunk in index['chunks']:
            hashes({chunk['path']:chunk['sha256']})
        require(entry['same_preparation'] and entry['dense_roundtrip']<ALGEBRA
                and entry['phase_error']<ALGEBRA and entry['current_error']<GATE, 'dense current qualification')
        require(index['shape'][0:2]==[5, 2] and index['shape'][2]>=1000, 'full hierarchy and paired metric branches')
        counts['histories'] += 1
    grid_report = take(ROOT/'grid-01/result.json')
    coarse = take(ROOT/'points-01/coarse-result.json')
    middle = take(ROOT/'points-01/middle-02-result.json')
    fine = take(ROOT/'points-01/fine-02-result.json')
    require(fine['source_phase_time_control'] and fine['current_phase_cross_term_retained'], 'source and current phase control retained')
    grid_end = read(STAGE/'grid-balanced-01.end.json')
    source_start = read(STAGE/'coarse-balanced-01.start.json')
    require(datetime.fromisoformat(grid_end['finished'])<datetime.fromisoformat(source_start['created'].replace('Z','+00:00')), 'quadrature frozen before native source sampling')
    for model in ('heavy', 'cold'):
        grid_item = next(item for item in grid_report['reports'] if item['model']==model)
        hashes({grid_item['path']:grid_item['sha256'], grid_item['phase_path']:grid_item['phase_sha256']})
        grid = load(grid_item['path'])
        require(len(grid['efold'])==257 and np.all(np.diff(grid['efold'])>0), 'ordered fixed grid')
        if model=='heavy':
            require(np.all(grid['speed']>0) and np.array_equal(grid['jacobian'], 1/grid['speed']), 'physical clock measure')
        else:
            require(np.all(grid['phase']==0) and np.all(grid['jacobian']==1), 'baseline has no heavy clock')
        by_index = {}
        for result, stride in ((coarse,4), (middle,2), (fine,1)):
            case = next(item for item in result['reports'] if item['model']==model)
            require([item['index'] for item in case['nodes']]==list(range(0,257,stride)), 'complete nested panel')
            for node in case['nodes']:
                if node['index'] in by_index:
                    require(node['sha256']==by_index[node['index']]['sha256'], 'old source points reused without overwrite')
                by_index[node['index']] = node
        case = next(item for item in fine['reports'] if item['model']==model)
        splines, row_norm = adjoints(model, consumed)
        require(len(case['phase_controls'])==257, 'complete phase-control coverage')
        for node, control in zip(case['nodes'],case['phase_controls']):
            require(node['index']==control['index'] and node['model']==control['model']==model, 'paired point ownership')
            for entry in (node,control):
                hashes({entry['path']:entry['sha256']})
                hashes(entry['sources'])
                hashes(entry['consumed'])
            hashes({control['profile_report']:control['profile_report_sha256']})
            profile = take(control['profile_report'])
            require(profile['index']==node['index'] and profile['model']==model, 'same parent profile')
            if model=='heavy':
                hashes({profile['path']:profile['sha256']})
            packet, phase = load(node['path']), load(control['path'])
            for data in (packet,phase):
                require(all(np.isfinite(value).all() for value in data.values()), 'finite source arrays')
            require(float(packet['efold'])==grid['efold'][node['index']] and float(packet['phase'])==grid['phase'][node['index']], 'source on frozen phase grid')
            require(np.array_equal(packet['difference'],packet['reference_rates']-packet['retained_rates']), 'native difference sign')
            require(np.array_equal(packet['readout_difference'],packet['reference_readouts']-packet['retained_readouts']), 'output difference sign')
            require(np.array_equal(packet['retained_vectors'],np.stack([packet['current'],packet['current_change']],axis=-1)), 'fine state and current-change vectors')
            maxima['frame'] = max(maxima['frame'], check_frame(packet, packet['retained_vectors'], packet['native_vectors'], packet['difference'], packet['forcing']))
            if model=='heavy':
                snapshot = {key.removeprefix('map_'):value for key,value in phase.items() if key.startswith('map_')}
                require(np.array_equal(phase['native_difference'],phase['native_reference_rates']-phase['native_retained_rates']), 'coarse-phase native difference')
                maxima['phase_frame'] = max(maxima['phase_frame'], check_frame(snapshot,packet['retained_vectors'],phase['native_native_vectors'],phase['native_difference'],packet['forcing']+phase['source_change']))
                require(node['checks']['clock']['minimum_speed']>0 and node['checks']['clock']['contraction_bound']<1, 'original all-phase clock gate at saved epochs')
            else:
                require(np.all(phase['source_change']==0) and np.all(phase['readout_change']==0), 'absent phase control only, not absent physical background difference')
            for order, name in enumerate(('fine','interpolation-coarse','step-coarse')):
                adjoint = splines[name](float(packet['efold']))*row_norm[:,:,None]
                for actual, source in ((packet['projected'][order],packet['forcing']), (phase['projected'][order],phase['source_change'])):
                    expected = np.einsum('obd,bdv->bvo',adjoint,source)
                    deviation = relative(actual,expected)
                    require(deviation<ALGEBRA, 'direct saved-adjoint contraction')
                    maxima['projection'] = max(maxima['projection'],deviation)
            for key in ('primitive_refinement','primitive_closure'):
                maxima[key] = max(maxima[key],node['checks'][key])
            if node['original_map_errors'] is not None:
                require(max(node['original_map_errors'])<ALGEBRA, 'endpoint map matches previous source stage')
            counts['source_points'] += 1
            counts['phase_controls'] += 1
    summaries = []
    for mode in ('middle-02','fine-02'):
        result = take(ROOT/('projection-'+mode)/'result.json')
        require(result['first_original_cell_only'] and result['final_saved_epoch_adjoint_reused']
                and not result['whole_history_error_claimed'] and not result['continuum_budget_certificate'], 'projection scope remains explicit')
        for entry in result['reports']:
            hashes({entry['path']:entry['sha256'],entry['clock_path']:entry['clock_sha256']})
            packet = load(entry['path'])
            coordinate, jacobian = packet['coordinate'], packet['jacobian']
            grid = load(next(row['path'] for row in grid_report['reports'] if row['model']==entry['model']))
            width = float(grid['efold'][-1]-grid['efold'][0])
            signals = packet['projected'][:,0,:,0]
            for name,stride in (('fine',1),('coarse',2),('coarser',4)):
                domain, measure = coordinate[::stride], jacobian[::stride,None,None]
                signed = quadratic_integral(signals[::stride]*measure,domain)
                budget = np.sqrt(width*np.maximum(quadratic_integral(signals[::stride]**2*measure,domain),0.))
                require(relative(signed,packet[name+'_signed'])<ALGEBRA and relative(budget,packet[name+'_cauchy'])<ALGEBRA, 'independent quadratic-rule integration')
            changes = dict(current=packet['projected'][:,0,:,1],phase=packet['phase_projected'][:,0,:,0],cross=packet['phase_projected'][:,0,:,1])
            changes['current_and_phase'] = changes['current']+changes['phase']+changes['cross']
            changes['adjoint_interpolation'] = packet['projected'][:,1,:,0]-signals
            changes['adjoint_steps'] = packet['projected'][:,2,:,0]-signals
            for name,values in changes.items():
                expected = quadratic_integral(values*jacobian[:,None,None],coordinate)
                require(relative(expected,packet['change_'+name])<ALGEBRA, 'separate integrated response control')
            measure_change = quadratic_integral(signals*(packet['polynomial_jacobian']-jacobian)[:,None,None],coordinate)
            require(relative(measure_change,packet['change_clock_measure'])<ALGEBRA, 'inverse-clock measure control')
            budget = np.maximum(packet['fine_cauchy'],1e-80)
            volume_error = abs(float(packet['fine_volume'])-width)/width
            rows = [row for row in result['records'] if row['model']==entry['model']]
            require(len(rows)==20, 'two branches and ten observables')
            for row in rows:
                branch,column = BRANCHES.index(row['branch']),NAMES.index(row['channel'])
                diagnostics = dict(quadrature=float(abs(packet['fine_signed'][branch,column]-packet['coarse_signed'][branch,column])/budget[branch,column]),
                    budget=float(abs(packet['fine_cauchy'][branch,column]-packet['coarse_cauchy'][branch,column])/budget[branch,column]))
                diagnostics.update({name:float(abs(packet['change_'+name][branch,column])/budget[branch,column]) for name in (*changes,'clock_measure')})
                require(relative(np.array(list(diagnostics.values())),np.array([row['diagnostics'][key] for key in diagnostics]))<ALGEBRA, 'unchanged diagnostic definitions')
                inside = abs(packet['fine_signed'][branch,column])<=budget[branch,column]*(1+GATE)
                passes = bool(max(diagnostics.values())<GATE and volume_error<GATE and inside)
                require(row['numerical_pass']==passes and row['cauchy_check']==bool(inside), 'retain failing numerical checks')
                counts['projection_rows'] += 1
            summaries.append(dict(mode=mode,model=entry['model'],points=entry['points'],passed=sum(row['numerical_pass'] for row in rows),
                largest_physical_contribution=max(abs(row['physical_contribution_fraction']) for row in rows),
                largest_physical_budget=max(row['physical_budget_fraction'] for row in rows),
                control_maxima={name:max(row['diagnostics'][name] for row in rows) for name in rows[0]['diagnostics']},
                physical_control_maxima={name:max(abs(row['physical_control_changes'][name]) for row in rows) for name in rows[0]['physical_control_changes']},
                clock=entry['clock'],volume_error=volume_error))
        require(result['all_numerical_controls_pass']==all(row['numerical_pass'] for row in result['records']), 'qualified status matches all observations')
    require(counts==dict(histories=4,source_points=514,phase_controls=514,projection_rows=80), 'complete first-cell experiment')
    workers = []
    for path in sorted(STAGE.glob('*.start.json')):
        start = read(path)
        hashes({start['source_path']:start['source_sha256']})
        phase = path.name.removesuffix('.start.json')
        if phase=='audit-01':
            require(start['pid']==os.getpid(), 'current audit identity')
            continue
        end = read(STAGE/(phase+'.end.json'))
        require(all(start[key]==end[key] for key in ('pid','created','command')) and end['exit_code']==0, 'completed owned worker identity')
        if psutil.pid_exists(start['pid']):
            created = datetime.fromisoformat(start['created'].replace('Z','+00:00')).timestamp()
            require(abs(psutil.Process(start['pid']).create_time()-created)>1, 'owned worker has exited')
        workers.append(phase)
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')), 'no bytecode caches')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,maxima=maxima,summary=summaries,completed_workers=workers,
        all_fine_numerical_controls_pass=all(row['passed']==20 for row in summaries if row['mode']=='fine-02'),
        first_cell_only=True,full_hierarchy_preserved=True,original_bank_grids_tolerances_unchanged=True,
        continuum_certificate=False,github_actions=False))
    print(json.dumps(dict(counts=counts,maxima=maxima,summary=summaries),indent=2),flush=True)


if __name__=='__main__':
    main()
