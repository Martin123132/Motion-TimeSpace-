from common import *
from accumulated_support_v2 import retained_checked,relative
from clock_primitive import KernelBank,basis
from remainder_source import evaluate_slow,map_defect
from correlated_source import CorrelatedSource,correlated
from scipy.sparse import coo_matrix,eye
from scipy.sparse.linalg import spsolve
import numpy as np
import time

BRANCHES=('gr','poisson-spatial')


def sparse(core,remote,keys,dimension):
    indices=np.indices(core.shape)
    rows=np.concatenate([indices[0].ravel(),keys[:,0]])
    columns=np.concatenate([indices[1].ravel(),keys[:,1]])
    return coo_matrix((np.concatenate([core.ravel(),remote]),(rows,columns)),shape=(dimension,dimension)).tocsc()


def fourier(coefficients,theta,axis=0,derivative=0):
    count=coefficients.shape[axis]
    modes=np.fft.fftfreq(count,d=1/count)
    weights=np.exp(2j*modes*theta)*(2j*modes)**derivative
    return np.tensordot(weights,np.moveaxis(coefficients,axis,0),axes=(0,0)).real


def sparse_norm_bound(keys,weights,dimension):
    absolute=abs(weights)
    return float(np.sqrt(np.bincount(keys[:,0],absolute,minlength=dimension).max()*np.bincount(keys[:,1],absolute,minlength=dimension).max()))


def compute_node(model,index,output):
    started=time.monotonic()
    owner=CorrelatedSource(model)
    frozen_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-source.json')
    node_path=owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-mean.npz')
    original_path=owned(COMPLETED/LABEL/'forcing-02'/f'{model}-{index:02d}-forcing.npz')
    slow_path=ACCUM_STAGE/LABEL/'slow-response-01'/f'{model}-fine.npz'
    if model=='cold' and LABEL=='half':
        slow_path=ACCUM_STAGE/LABEL/'baseline-identity-01/cold-fine.npz'
    owned(slow_path)
    kernel_path=owned(CLOCK_STAGE/'kernel-bank-01/heavy-kernels.npz')
    source,bank,leading,paths=retained_checked(model)
    consumed={str(path):digest(path) for path in (frozen_path,node_path,original_path,slow_path,kernel_path)}
    consumed.update(paths)
    consumed.update(owner.consumed)
    frozen,node,cached,slow=read(frozen_path),load(node_path),load(original_path),load(slow_path)
    bank_index=index//2
    efold=float(frozen['efold'])
    require(efold==float(bank['efold'][bank_index]) and efold==float(slow['efold'][bank_index]),'original source/slow epochs match without interpolation')
    require(np.array_equal(cached['state'],leading['state'][bank_index]),'same original leading mode at source node')
    dimension=source.shape[-1]
    compact=frozen['layout']['size']
    keys=cached['remote_keys']
    require(np.array_equal(keys,node['keys']),'unchanged full hierarchy links')
    stream=cached['remote_stream']
    stream_rate=cached['remote_stream_rate']
    count=len(cached['angular'])
    require(count==(256 if model=='heavy' else 1),'all original retained phase nodes')
    angles=np.arange(count)*np.pi/count
    kernel=KernelBank(load(kernel_path)) if model=='heavy' else None
    if model=='heavy':
        primitive=(basis(angles,kernel.modes,kernel.sine)@kernel.kernel(efold)@source.spline(efold)).reshape(count,*source.shape).sum(axis=1)
    else:
        primitive=np.zeros((count,2,dimension))
    delta=slow['eta'][bank_index].sum(axis=0)[None,:,:]+primitive
    modes=np.fft.fftfreq(count,d=1/count)
    compact_values=np.fft.ifft(cached['compact_coefficients']*count,axis=1).real
    compact_theta=np.fft.ifft(cached['compact_coefficients']*(2j*modes[None,:,None,None])*count,axis=1).real
    compact_slow=np.fft.ifft(cached['compact_slow_coefficients']*count,axis=1).real
    scalar=np.fft.ifft(cached['scalar_coefficients']*count,axis=0).real[:,0,0]
    scalar_theta=np.fft.ifft(cached['scalar_coefficients']*(2j*modes[:,None,None])*count,axis=0).real[:,0,0]
    scalar_slow=np.fft.ifft(cached['scalar_slow_coefficients']*count,axis=0).real[:,0,0]
    expected=np.stack([np.fft.ifft(cached[name]*count,axis=0).real for name in ('normal_coefficients','map_coefficients')],axis=1)
    leading_action=np.zeros_like(expected)
    feedback=np.zeros_like(expected)
    core_indices=np.indices((compact,compact))
    structural=coo_matrix((np.ones(compact**2+len(keys)),(np.concatenate([core_indices[0].ravel(),keys[:,0]]),
        np.concatenate([core_indices[1].ravel(),keys[:,1]]))),shape=(dimension,dimension)).tocsr()
    structural.data[:]=1.
    structural=structural+structural@structural
    structural.eliminate_zeros()
    numerator_rows,numerator_columns=structural.nonzero()
    numerator_keys=np.column_stack([numerator_rows,numerator_columns])
    numerator_values=np.empty((count,2,len(numerator_rows)))
    mean=[sparse(node['mean'][branch],node['remote'],keys,dimension) for branch in range(2)]
    identity=eye(dimension,format='csc')
    inverse_errors=[]
    map_cache=[]
    for phase_index,theta in enumerate(angles):
        guard()
        physical=correlated(frozen,float(theta))[0] if model=='heavy' else frozen
        maps,_,_=map_defect(physical,float(theta),cached['background_defect'][phase_index])
        map_cache.append(maps)
        for branch in range(2):
            correction=sparse(compact_values[branch,phase_index],scalar[phase_index]*stream,keys,dimension)
            derivative=sparse(compact_theta[branch,phase_index],scalar_theta[phase_index]*stream,keys,dimension)
            slow_derivative=sparse(compact_slow[branch,phase_index],scalar_slow[phase_index]*stream+scalar[phase_index]*stream_rate,keys,dimension)
            actual=mean[branch]+cached['angular'][phase_index]*derivative
            endpoint=identity+correction
            map_operator=sparse(maps[branch],np.zeros(len(keys)),keys,dimension)
            normal=actual@correction-correction@mean[branch]-slow_derivative
            mapped=map_operator@endpoint
            numerator=normal+mapped
            captured=np.asarray(numerator[numerator_rows,numerator_columns]).ravel()
            numerator_values[phase_index,branch]=captured
            restored=coo_matrix((captured,(numerator_rows,numerator_columns)),shape=(dimension,dimension)).tocsc()
            require(not np.count_nonzero((numerator-restored).data),'complete numerator sparse support')
            vectors=np.column_stack([normal@cached['state'][branch],mapped@cached['state'][branch],
                normal@delta[phase_index,branch],mapped@delta[phase_index,branch]])
            solved=spsolve(endpoint,vectors)
            inverse_error=relative(endpoint@solved,vectors)
            require(inverse_error<ALGEBRA,'full endpoint inverse, not compact truncation')
            inverse_errors.append(inverse_error)
            leading_action[phase_index,:,branch]=solved[:,:2].T
            feedback[phase_index,:,branch]=solved[:,2:].T
        if phase_index%64==0:
            print(LABEL,model,index,'derived feedback phase',phase_index,'of',count,flush=True)
    source_checks=[]
    feedback_scale=np.max(np.linalg.norm(feedback,axis=-1),axis=0)
    original_scale=np.max(np.linalg.norm(expected,axis=-1),axis=0)
    for component in range(2):
        for branch in range(2):
            error=float(np.max(np.linalg.norm(leading_action[:,component,branch]-expected[:,component,branch],axis=-1))/max(original_scale[component,branch],1e-80))
            require(error<GATE,'reconstructed operator reproduces entire saved first source before new feedback')
            source_checks.append(dict(component=component,branch=BRANCHES[branch],relative=error))
    feedback_coefficients=np.fft.fft(feedback,axis=0)/count
    numerator_coefficients=np.fft.rfft(numerator_values,axis=0)/count
    numerator_norms=np.linalg.norm(numerator_coefficients,axis=-1)
    weights=np.full(len(numerator_coefficients),2.)
    weights[0]=1.
    if count%2==0:
        weights[-1]=1.
    numerator_bound=weights@numerator_norms
    remote_bound=sparse_norm_bound(keys,stream,dimension)
    correction_bound=np.sum(np.linalg.norm(cached['compact_coefficients'],axis=(-2,-1)),axis=1)+float(np.sum(abs(cached['scalar_coefficients'][:,0,0])))*remote_bound
    finite_bounds=[float(numerator_bound[branch]/(1-correction_bound[branch])) if correction_bound[branch]<1 else None for branch in range(2)]
    bounds_checks=[]
    for branch,bound in enumerate(finite_bounds):
        if bound is not None:
            ratio=np.linalg.norm(feedback[:,:,branch].sum(axis=1),axis=-1)/np.maximum(np.linalg.norm(delta[:,branch],axis=-1),1e-80)
            require(np.max(ratio)<=bound*(1+ALGEBRA)+1e-80,'derived finite-polynomial bound covers all retained source nodes')
            bounds_checks.append(dict(branch=BRANCHES[branch],maximum_directional_gain=float(np.max(ratio)),finite_operator_bound=bound))
    independent=[]
    for theta in (.213,1.157,2.62):
        guard()
        prepared,direct=evaluate_slow(owner,frozen,theta,keys)
        maps,_,_=map_defect(prepared['physical'],theta,prepared['defect'])
        compact_value=fourier(cached['compact_coefficients'],theta,axis=1)
        compact_rate=fourier(cached['compact_slow_coefficients'],theta,axis=1)
        compact_phase=fourier(cached['compact_coefficients'],theta,axis=1,derivative=1)
        scalar_value=float(fourier(cached['scalar_coefficients'],theta)[0,0])
        scalar_rate=float(fourier(cached['scalar_slow_coefficients'],theta)[0,0])
        scalar_phase=float(fourier(cached['scalar_coefficients'],theta,derivative=1)[0,0])
        current_delta=slow['eta'][bank_index].sum(axis=0)+(kernel.response(source,efold,theta)[1].sum(axis=0) if model=='heavy' else 0.)
        predicted=fourier(feedback_coefficients,theta)
        for branch in range(2):
            correction=sparse(compact_value[branch],scalar_value*stream,keys,dimension)
            derivative=sparse(compact_phase[branch],scalar_phase*stream,keys,dimension)
            slow_derivative=sparse(compact_rate[branch],scalar_rate*stream+scalar_value*stream_rate,keys,dimension)
            endpoint=identity+correction
            reconstructed=mean[branch]+(prepared['angular'].value if model=='heavy' else 1.)*derivative
            actual=sparse(direct['matrix'][branch],direct['remote'],keys,dimension)
            generator_error=float(np.linalg.norm((reconstructed-actual).data)/max(np.linalg.norm(actual.data),1e-80))
            require(generator_error<ALGEBRA,'independent original source generator reconstruction')
            map_operator=sparse(maps[branch],np.zeros(len(keys)),keys,dimension)
            normal=actual@correction-correction@mean[branch]-slow_derivative
            mapped=map_operator@endpoint
            actual_feedback=spsolve(endpoint,np.column_stack([normal@current_delta[branch],mapped@current_delta[branch]])).T
            errors=[]
            for component in range(2):
                error=float(np.linalg.norm(predicted[component,branch]-actual_feedback[component])/max(feedback_scale[component,branch],1e-80))
                require(error<GATE,'independent physical-source feedback prediction, no fitted coefficients')
                errors.append(error)
            independent.append(dict(theta=theta,branch=BRANCHES[branch],generator=generator_error,feedback=errors))
    refinement=[]
    if count==256:
        coarse=np.fft.fft(feedback[::2],axis=0)/128
        for theta in (float(bank['phase'][bank_index]),.213,1.157,2.62):
            difference=fourier(feedback_coefficients,theta)-fourier(coarse,theta)
            errors=np.linalg.norm(difference,axis=-1)/np.maximum(feedback_scale,1e-80)
            require(np.max(errors)<GATE,'128/256 complete phase feedback refinement')
            refinement.append(dict(theta=theta,relative=errors.tolist()))
    path=output/f'{model}-{index:02d}-feedback.npz'
    np.savez_compressed(path,efold=efold,theta=bank['phase'][bank_index],feedback=feedback,feedback_coefficients=feedback_coefficients,
        leading_action=leading_action,expected_leading=expected,delta_s=delta,angles=angles,
        numerator_keys=numerator_keys,numerator_coefficients=numerator_coefficients,numerator_norms=numerator_norms,
        correction_bound=correction_bound,numerator_bound=numerator_bound,original_state=cached['state'])
    require(all(digest(path)==seal for path,seal in consumed.items()),'retained inputs unchanged')
    report=dict(passed=True,model=model,index=index,efold=efold,path=str(path),sha256=digest(path),
        consumed=consumed,sources=sources(),source_checks=source_checks,independent=independent,refinement=refinement,
        correction_bound=correction_bound.tolist(),finite_operator_bound=finite_bounds,operator_checks=bounds_checks,
        maximum_inverse_error=max(inverse_errors),maximum_feedback_per_state=(feedback_scale/np.linalg.norm(cached['state'],axis=-1)[None,:]).tolist(),
        maximum_first_source_per_state=(original_scale/np.linalg.norm(cached['state'],axis=-1)[None,:]).tolist(),
        seconds=time.monotonic()-started,finite_interpolant_bound_only=True,uniform_time_bound_claimed=False,full_history_error_claimed=False)
    write(output/f'{model}-{index:02d}-result.json',report)
    print(LABEL,model,index,'feedback source qualified',report['seconds'],report['finite_operator_bound'],flush=True)
    return report
