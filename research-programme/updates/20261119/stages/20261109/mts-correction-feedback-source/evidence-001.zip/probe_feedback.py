from common import *
from feedback_source import compute_node


def main():
    modest()
    output=ROOT/'feedback-01'
    output.mkdir(parents=True,exist_ok=False)
    inputs=verify_inputs()
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),indices=list(range(0,33,4)),phase_count=256,
        independent_angles=[.213,1.157,2.62],algebra=ALGEBRA,gate=GATE,original_physical_inputs_unchanged=True))
    reports=[compute_node(model,16,output) for model in ('heavy','cold')]
    write(ROOT/'probe-01-result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports))


if __name__=='__main__':
    main()
