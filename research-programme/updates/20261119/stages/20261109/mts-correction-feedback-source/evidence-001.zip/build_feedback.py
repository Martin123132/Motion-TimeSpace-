from common import *
from feedback_source import compute_node


def main():
    modest()
    output=ROOT/'feedback-01'
    inputs=verify_inputs()
    if not output.exists():
        output.mkdir(parents=True,exist_ok=False)
        write(output/'freeze.json',dict(inputs=inputs,sources=sources(),indices=list(range(0,33,4)),phase_count=256,
            independent_angles=[.213,1.157,2.62],algebra=ALGEBRA,gate=GATE,original_physical_inputs_unchanged=True))
    reports=[]
    for model in ('heavy','cold'):
        nodes=[]
        for index in range(0,33,4):
            guard()
            path=output/f'{model}-{index:02d}-result.json'
            if path.exists():
                report=read(path)
                require(report['passed'] and digest(report['path'])==report['sha256'],'reuse only accepted completed node')
                for source,seal in report['sources'].items():
                    require(digest(source)==seal,'cached node code unchanged')
                for source,seal in report['consumed'].items():
                    require(digest(source)==seal,'cached node inputs unchanged')
            else:
                require(not (output/f'{model}-{index:02d}-feedback.npz').exists(),'partial node requires inspection; do not overwrite')
                report=compute_node(model,index,output)
            nodes.append(report)
        reports.append(dict(model=model,nodes=nodes))
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,all_original_nodes=True,
        full_feedback_not_fitted=True,uniform_continuum_bound=False))


if __name__=='__main__':
    main()
