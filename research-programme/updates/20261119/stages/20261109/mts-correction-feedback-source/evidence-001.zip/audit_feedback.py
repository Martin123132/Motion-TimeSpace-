from common import *
import numpy as np

BRANCHES = ('gr', 'poisson-spatial')


def close(actual, expected, message):
    actual, expected = np.asarray(actual), np.asarray(expected)
    scale = max(float(np.max(abs(expected))), 1e-80)
    require(float(np.max(abs(actual - expected))) / scale < ALGEBRA, message)


def main():
    modest()
    output = STAGE / 'audit'
    output.mkdir(exist_ok=False)
    inputs = verify_inputs()
    consumed, accepted, verified = {}, {}, {}
    rows = []
    counts = dict(nodes=0, source_checks=0, direct_generators=0,
                  direct_feedback=0, phase_refinements=0, finite_bounds=0)

    def check_hashes(records):
        for path, seal in records.items():
            guard()
            if path not in verified:
                require(digest(path) == seal, 'frozen bytes: ' + path)
                verified[path] = seal
            require(verified[path] == seal, 'consistent source ownership: ' + path)
            consumed[path] = seal

    for label in ('half', 'balanced', 'double'):
        root = STAGE / label / 'feedback-01'
        summary_path = root / 'result.json'
        summary = read(summary_path)
        require(summary['passed'] and summary['all_original_nodes'], 'completed family')
        check_hashes(summary['inputs'])
        check_hashes(summary['sources'])
        accepted[str(summary_path)] = digest(summary_path)
        require([item['model'] for item in summary['reports']] == ['heavy', 'cold'], 'paired models')
        for family in summary['reports']:
            model = family['model']
            require([item['index'] for item in family['nodes']] == list(range(0, 33, 4)), 'nine original source epochs')
            for report in family['nodes']:
                guard()
                index = report['index']
                report_path = root / f'{model}-{index:02d}-result.json'
                require(read(report_path) == report, 'summary matches original accepted node')
                accepted[str(report_path)] = digest(report_path)
                require(report['passed'] and report['finite_interpolant_bound_only']
                        and not report['uniform_time_bound_claimed']
                        and not report['full_history_error_claimed'], 'correct limited claim scope')
                check_hashes(report['sources'])
                check_hashes(report['consumed'])
                check_hashes({report['path']: report['sha256']})
                packet = load(report['path'])
                original_path = COMPLETED / label / 'forcing-02' / f'{model}-{index:02d}-forcing.npz'
                original = load(original_path)
                require(str(original_path) in report['consumed'], 'original packet owned by source calculation')
                phase_count = 256 if model == 'heavy' else 1
                dimension = original['state'].shape[-1]
                require(packet['feedback'].shape == (phase_count, 2, 2, dimension), 'full feedback dimension')
                require(packet['delta_s'].shape == (phase_count, 2, dimension), 'full correction dimension')
                require(np.array_equal(packet['original_state'], original['state']), 'unchanged original state')
                require(float(packet['efold']) == report['efold'], 'same original epoch')
                require(np.array_equal(packet['angles'], np.arange(phase_count) * np.pi / phase_count), 'same phase grid')
                for name, value in packet.items():
                    require(np.all(np.isfinite(value)), 'finite packet: ' + name)
                expected = np.stack([np.fft.ifft(original[name] * phase_count, axis=0).real
                                     for name in ('normal_coefficients', 'map_coefficients')], axis=1)
                close(packet['expected_leading'], expected, 'old source reconstructed independently')
                scale = np.max(np.linalg.norm(expected, axis=-1), axis=0)
                errors = np.max(np.linalg.norm(packet['leading_action'] - expected, axis=-1), axis=0) / np.maximum(scale, 1e-80)
                require(np.max(errors) < GATE, 'old source regression gate')
                require(len(report['source_checks']) == 4, 'complete component/source matrix')
                for entry in report['source_checks']:
                    close(errors[entry['component'], BRANCHES.index(entry['branch'])], entry['relative'], 'recorded source regression')
                close(packet['feedback_coefficients'], np.fft.fft(packet['feedback'], axis=0) / phase_count, 'complete feedback Fourier representation')
                support = packet['numerator_keys']
                require(support.ndim == 2 and support.shape[1] == 2 and np.min(support) >= 0
                        and np.max(support) < dimension and len(np.unique(support, axis=0)) == len(support), 'unique full numerator support')
                require(packet['numerator_coefficients'].shape == (phase_count // 2 + 1, 2, len(support)), 'full real Fourier numerator')
                norms = np.linalg.norm(packet['numerator_coefficients'], axis=-1)
                close(norms, packet['numerator_norms'], 'independent coefficient Frobenius norms')
                weights = np.full(len(norms), 2.)
                weights[0] = 1.
                if phase_count % 2 == 0:
                    weights[-1] = 1.
                numerator_bound = weights @ norms
                close(numerator_bound, packet['numerator_bound'], 'independent finite numerator triangle bound')
                keys = original['remote_keys']
                absolute = abs(original['remote_stream'])
                row_sum = np.bincount(keys[:, 0], weights=absolute, minlength=dimension)
                col_sum = np.bincount(keys[:, 1], weights=absolute, minlength=dimension)
                remote_bound = np.sqrt(np.max(row_sum) * np.max(col_sum))
                correction_bound = np.linalg.norm(original['compact_coefficients'], axis=(-2, -1)).sum(axis=1)
                correction_bound += np.abs(original['scalar_coefficients'][:, 0, 0]).sum() * remote_bound
                close(correction_bound, packet['correction_bound'], 'independent full primitive bound')
                close(correction_bound, report['correction_bound'], 'reported primitive bound')
                require(np.all(correction_bound < 1), 'retained primitive Neumann condition')
                finite_bound = numerator_bound / (1 - correction_bound)
                close(finite_bound, report['finite_operator_bound'], 'independent all-phase finite-interpolant bound')
                gains = np.max(np.linalg.norm(packet['feedback'].sum(axis=1), axis=-1)
                               / np.maximum(np.linalg.norm(packet['delta_s'], axis=-1), 1e-80), axis=0)
                require(np.all(gains <= finite_bound * (1 + ALGEBRA) + 1e-80), 'finite operator bounds cover computed directions')
                for branch, entry in enumerate(report['operator_checks']):
                    require(entry['branch'] == BRANCHES[branch], 'consistent branch order')
                    close(gains[branch], entry['maximum_directional_gain'], 'independent directional gain')
                state_norm = np.linalg.norm(packet['original_state'], axis=-1)[None, :]
                feedback_scale = np.max(np.linalg.norm(packet['feedback'], axis=-1), axis=0)
                feedback_per_state = feedback_scale / state_norm
                source_per_state = scale / state_norm
                close(feedback_per_state, report['maximum_feedback_per_state'], 'feedback normalization')
                close(source_per_state, report['maximum_first_source_per_state'], 'first-source normalization')
                if model == 'cold':
                    require(np.count_nonzero(original['compact_coefficients']) == 0
                            and np.count_nonzero(original['scalar_coefficients']) == 0, 'baseline phase absence')
                    require(np.count_nonzero(packet['feedback'][:, 0]) == 0, 'baseline normal-form control')
                require(len(report['independent']) == 6, 'three off-grid physical phase checks per branch')
                for entry in report['independent']:
                    require(entry['theta'] in (.213, 1.157, 2.62)
                            and entry['generator'] < ALGEBRA
                            and len(entry['feedback']) == 2
                            and max(entry['feedback']) < GATE, 'direct field-equation prediction gates')
                require(len(report['refinement']) == (4 if model == 'heavy' else 0), 'paired phase refinement coverage')
                for entry in report['refinement']:
                    require(np.max(entry['relative']) < GATE, 'unchanged phase-refinement tolerance')
                require(report['maximum_inverse_error'] < ALGEBRA, 'full sparse inverse residual')
                ratios = [[float(feedback_scale[component, branch] / scale[component, branch])
                           if scale[component, branch] else None for branch in range(2)] for component in range(2)]
                rows.append(dict(label=label, model=model, index=index, efold=report['efold'],
                                 correction_bound=correction_bound.tolist(), finite_operator_bound=finite_bound.tolist(),
                                 feedback_per_state=feedback_per_state.tolist(), first_source_per_state=source_per_state.tolist(),
                                 feedback_to_first_source=ratios, maximum_source_regression=float(np.max(errors)),
                                 maximum_generator_error=max(item['generator'] for item in report['independent']),
                                 maximum_direct_feedback_error=max(max(item['feedback']) for item in report['independent']),
                                 maximum_phase_refinement=max((float(np.max(item['relative'])) for item in report['refinement']), default=0.),
                                 maximum_inverse_error=report['maximum_inverse_error']))
                counts['nodes'] += 1
                counts['source_checks'] += 4
                counts['direct_generators'] += 6
                counts['direct_feedback'] += 12
                counts['phase_refinements'] += 4 * len(report['refinement'])
                counts['finite_bounds'] += 2
                print('audited', label, model, index, flush=True)
                del packet, original

    require(counts == dict(nodes=54, source_checks=216, direct_generators=324, direct_feedback=648,
                           phase_refinements=432, finite_bounds=108), 'complete planned coverage')
    for path in STAGE.rglob('freeze.json'):
        frozen = read(path)
        check_hashes(frozen['sources'])
        check_hashes(frozen['inputs'])
    expected_workers = {'probe-half-01', 'feedback-half-01', 'feedback-balanced-01', 'feedback-double-01'}
    actual_workers = {path.name.removesuffix('.start.json') for path in STAGE.glob('*.start.json')}
    require(actual_workers == expected_workers | {'audit-01'}, 'all task workers tracked')
    for phase in expected_workers:
        start, end = read(STAGE / f'{phase}.start.json'), read(STAGE / f'{phase}.end.json')
        require(start['pid'] == end['pid'] and start['created'] == end['created']
                and start['command'] == end['command'] and end['exit_code'] == 0, 'successful exact task identity')
        check_hashes({start['source_path']: start['source_sha256']})
    require(not list(STAGE.glob('*.not-started.json')), 'no missing planned computation')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'), str(path), 'exec', dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')), 'no bytecode residue')
    write(output / 'result.json', dict(passed=True, inputs=inputs, sources=sources(),
                                      consumed=consumed, accepted_results=accepted, rows=rows, counts=counts,
                                      failed_attempts_preserved=[], compiler_receipts=[],
                                      original_inputs_and_tolerances_unchanged=True,
                                      fixed_epoch_finite_interpolant_bound=True,
                                      continuous_physical_source_certificate=False,
                                      full_history_error_claimed=False, github_actions=False))
    print('complete paired correction-feedback source audit passed', counts, flush=True)


if __name__ == '__main__':
    main()

