from common import *
from point_support import checked_point


def main():
    modest()
    inputs=verify_inputs()
    grid=read(ROOT/'grid-01/result.json')
    consumed={}
    for mode in ('probe','batch00','batch01','batch02','batch03'):
        path=ROOT/'points-01'/(mode+'-result.json')
        require(read(path)['passed'],'complete source batch '+mode)
        consumed[str(path)]=digest(path)
    reports=[]
    for entry in grid['reports']:
        nodes=[];controls=[]
        for index in range(entry['points']):
            report,phase=checked_point(entry['model'],index)
            nodes.append(report);controls.append(phase)
            for item in (report,phase):
                consumed[item['path']]=item['sha256']
        reports.append(dict(model=entry['model'],nodes=nodes,phase_controls=controls))
    write(ROOT/'points-01/cell02-result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        source_phase_time_control=True,current_phase_cross_term_retained=True,
        shared_boundary_points_reused=2,original_bank_grids_tolerances_unchanged=True))
    print('second-cell source panel assembled with inherited boundary, no response reset',flush=True)


if __name__=='__main__':
    main()
