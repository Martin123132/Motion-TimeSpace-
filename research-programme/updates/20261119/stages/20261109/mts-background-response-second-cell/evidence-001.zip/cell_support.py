from common import *


MANIFESTS={}


def parent(path):
    path=Path(path)
    for folder,seal in ((FIRST_CELL,'f1083895e9ae9ad3962cfe8dc09446023b52c82384f81e52c6ce868e5e537ce9'),
                        (PHASE_RESPONSE,'e9605e1c81ad5b48ef790ee5f906cd1c29bf628140cc80f5fdd9b1c6ffbf73d2')):
        if path.is_relative_to(folder):
            if folder not in MANIFESTS:
                require(digest(folder/'closeout.json')==seal,'accepted parent seal')
                MANIFESTS[folder]={str(Path(item['path'])):item['sha256'] for item in read(folder/'closeout.json')['artifacts']}
            require(str(path) in MANIFESTS[folder] and digest(path)==MANIFESTS[folder][str(path)],'unchanged inherited artifact '+str(path))
            return path
    raise ValueError('undeclared immediate cell input '+str(path))


def checked_point(model,index):
    output=ROOT/'points-01'
    report=read(output/f'{model}-{index:04d}-result.json')
    phase=read(output/f'{model}-{index:04d}-phase-result.json')
    require(report['passed'] and phase['passed'] and report['index']==phase['index']==index,'completed owned cell point')
    for item in (report,phase):
        require(item['model']==model and digest(item['path'])==item['sha256'],'same source/control bytes')
    if index!=0:
        require(digest(phase['profile_report'])==phase['profile_report_sha256'],'saved profile receipt')
        profile=read(phase['profile_report'])
        require(profile['passed'] and profile['model']==model and profile['index']==index,'owned profile')
        if model=='heavy':
            require(digest(profile['path'])==profile['sha256'],'profile unchanged')
    return report,phase
