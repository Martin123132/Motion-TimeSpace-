from run_batch import run

if __name__=='__main__':
    run('batch00',0)
