from common import *


def checked_point(model,index):
    output=ROOT/'points-01'
    report=read(output/f'{model}-{index:03d}-result.json')
    phase=read(output/f'{model}-{index:03d}-phase-result.json')
    require(report['passed'] and phase['passed'] and report['index']==phase['index']==index,'completed owned cell point')
    for item in (report,phase):
        require(item['model']==model and digest(item['path'])==item['sha256'],'source/control bytes')
    if index!=0:
        require(digest(phase['profile_report'])==phase['profile_report_sha256'],'profile receipt')
        profile=read(phase['profile_report'])
        require(profile['passed'] and profile['index']==index and profile['model']==model,'source profile ownership')
        if model=='heavy':
            require(digest(profile['path'])==profile['sha256'],'profile bytes')
    else:
        require(report['reused_shared_boundary'] and phase['reused_shared_boundary'],'inherited boundary explicitly recorded')
    return report,phase
