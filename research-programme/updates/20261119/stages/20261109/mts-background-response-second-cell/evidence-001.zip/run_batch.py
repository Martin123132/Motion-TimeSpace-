from common import *
from controlled_sources import ControlledPhaseSource
from point_support import checked_point


def run(mode,quarter=None):
    modest()
    inputs=verify_inputs()
    output=ROOT/'points-01'
    grid_path=ROOT/'grid-01/result.json'
    frozen=read(grid_path)
    require(frozen['passed'],'qualified inherited current and frozen grid')
    if mode!='probe':
        require(read(ROOT/'probe-verification/result.json')['passed'],'second-cell probe qualified')
    selections={entry['model']:(entry['probe_indices'] if mode=='probe' else list(range(quarter*entry['intervals']//4+1,(quarter+1)*entry['intervals']//4+1))) for entry in frozen['reports']}
    write(output/(mode+'-freeze.json'),dict(inputs=inputs,sources=sources(),grid_path=str(grid_path),grid_sha256=digest(grid_path),
        selections=selections,mode=mode,original_phase_nodes=256,unchanged_gates=[ALGEBRA,GATE]))
    reports=[]
    for model in ('heavy','cold'):
        entry=next(item for item in frozen['reports'] if item['model']==model)
        require(digest(entry['path'])==entry['sha256'],'frozen second-cell points')
        grid=load(entry['path'])
        case=None
        nodes=[]
        controls=[]
        for index in selections[model]:
            guard()
            path=output/f'{model}-{index:03d}-result.json'
            if path.exists():
                report,phase=checked_point(model,index)
            else:
                require(not (output/f'{model}-{index:03d}.npz').exists() and not (output/f'{model}-{index:03d}-profile.npz').exists(),
                        'partial source needs inspection')
                if (datetime(2026,11,9,13,0,tzinfo=timezone.utc)-datetime.now(timezone.utc)).total_seconds()<300:
                    write(output/(mode+'-safe-stop.json'),dict(completed=False,model=model,next_index=index,reason='safe four-hour reserve'))
                    return
                if case is None:
                    case=ControlledPhaseSource(model,mode)
                report=case.sample(index,grid,output)
                phase=case.phase_control(index,grid,output,report,True)
                checked_point(model,index)
            nodes.append(report);controls.append(phase)
        reports.append(dict(model=model,nodes=nodes,phase_controls=controls))
    write(output/(mode+'-result.json'),dict(passed=True,inputs=inputs,sources=sources(),reports=reports,
        source_phase_time_control=True,current_phase_cross_term_retained=True,original_bank_grids_tolerances_unchanged=True))
