from common import *
import numpy as np
import psutil


def error(left,right):
    return float(np.linalg.norm(left-right)/max(np.linalg.norm(left),np.linalg.norm(right),1e-80))


def main():
    modest()
    output=STAGE/'audit'
    output.mkdir(exist_ok=False)
    inputs=verify_inputs()
    consumed,accepted,verified={},{},{}
    summaries=[]
    counts=dict(models=0,endpoints=0,stencil_packets=0,heldout_native_packets=0,stable_endpoints=0)

    def hashes(records):
        for path,seal in records.items():
            guard()
            if path not in verified:
                verified[path]=digest(path)
            require(verified[path]==seal,'immutable input '+path)
            consumed[path]=seal

    def take(path):
        value=read(path)
        require(value.get('passed') or value.get('completed'),'completed report '+str(path))
        for key in ('inputs','sources','consumed'):
            hashes(value.get(key,{}))
        accepted[str(path)]=digest(path)
        return value

    waves=dict(read(WAVES)['waves'])
    for label in ('half','balanced','double'):
        root=STAGE/label
        prepared=take(root/'prediction-02/result.json')
        tested=take(root/'test-02/result.json')
        cancellation=take(root/'cancellation-02/result.json')
        require(prepared['predictions_frozen_before_direct_interior_test'],'frozen-test ordering declaration')
        prepare_end=read(STAGE/f'prepare-{label}-02.end.json')
        test_start=read(STAGE/f'test-{label}-02.start.json')
        require(datetime.fromisoformat(prepare_end['finished'])<datetime.fromisoformat(test_start['created'].replace('Z','+00:00')),
                'predictor finished before direct target worker')
        for model in ('heavy','cold'):
            frozen=next(item for item in prepared['reports'] if item['model']==model)
            result=next(item for item in tested['reports'] if item['model']==model)
            hashes(frozen['consumed'])
            hashes(result['consumed'])
            hashes({frozen['path']:frozen['sha256'],result['path']:result['sha256']})
            prediction=load(frozen['path'])
            comparison=load(result['path'])
            require(max(frozen['map_control'])<ALGEBRA and max(result['map_control'])<ALGEBRA,'independent saved-map routes')
            for reused in frozen['reused_endpoints']:
                hashes({reused['report']:reused['sha256']})
                require(reused['reproduction']<ALGEBRA,'accepted native center reproduced after window restoration')
            endpoints=[]
            for index in (0,4):
                base=root/'prediction-02'
                if not (base/f'{model}-{index:02d}-result.json').exists():
                    base=root/'prediction-01'
                report=take(base/f'{model}-{index:02d}-result.json')
                hashes({report['path']:report['sha256']})
                hashes(report['native_packets'])
                jets=load(report['path'])
                require(np.array_equal(jets['vectors'],prediction['vectors']),'same fixed probes')
                require(jets['derivative'].shape[:2]==(3,2) and jets['derivative'].shape[-1]==5,'three frozen derivative levels')
                require(report['phase_control']['error']<ALGEBRA and report['phase_control']['divisions']==[32,64],
                        'unchanged local phase equation and controls')
                points={}
                for ordinal,offset in ((0,-2.),(1,-1.),(2,-.5),(3,-.25),(5,.25),(6,.5),(7,1.),(8,2.)):
                    path=base/f'{model}-{index:02d}-offset-{ordinal:02d}.npz'
                    packet=load(path)
                    require(np.array_equal(packet['native_vectors'],jets['native']),'fixed encoded vectors for total native derivative')
                    require(np.array_equal(packet['reference_rates']-packet['retained_rates'],packet['difference']),'native difference sign')
                    require(np.array_equal(packet['reference_readouts']-packet['retained_readouts'],packet['readout_difference']),'native readout sign')
                    points[offset]=packet
                    counts['stencil_packets']+=1
                for level,divisor in enumerate((1,2,4)):
                    offset=1/divisor
                    for key,target in (('difference','native_derivative'),('readout_difference','native_output_derivative')):
                        derivative=(-points[2*offset][key]+8*points[offset][key]-8*points[-offset][key]+points[-2*offset][key])/(12*float(jets['step'])/divisor)
                        require(error(derivative,jets[target][level])<ALGEBRA,'independent native finite derivative')
                endpoints.append(jets)
                counts['endpoints']+=1
                if model=='heavy':
                    stable=next(item for item in cancellation['reports'] if item['index']==index)
                    hashes({stable['path']:stable['sha256']})
                    fixed=load(stable['path'])
                    require(np.array_equal(fixed['original_derivative'],jets['derivative']),'same unmodified original jets')
                    scale=np.maximum(np.max(np.linalg.norm(fixed['derivative'],axis=2),axis=0),1e-80)
                    changes=np.linalg.norm(np.diff(fixed['derivative'],axis=0),axis=2)/scale
                    require(error(changes,fixed['changes'])<ALGEBRA,'recomputed cancellation controls')
                    require(stable['derivative_resolved']==bool(changes[-1].max()<GATE),'unresolved precision stays unresolved')
                    center=load(base/f'{model}-{index:02d}-center.npz')
                    all_packets=[center,*points.values()]
                    layout=read(COMPLETED/label/'source-even-01'/f'{model}-{index:02d}-source.json')['layout']
                    with np.load(COMPLETED/label/'source-even-01'/f'{model}-{index:02d}-mean.npz') as unused:
                        pass
                    frozen_source=read(COMPLETED/label/'source-even-01'/f'{model}-{index:02d}-source.json')
                    units=jets['units']
                    slots=layout['heavy']
                    matter=layout['cdm']
                    for packet in all_packets:
                        amplitude=packet['native_vectors'][:,slots[0]]*units[slots[0]]+1j*packet['native_vectors'][:,slots[1]]*units[slots[1]]
                        phase=float(packet['carrier'])
                        for name in ('reference','retained'):
                            background=packet[name+'_background']
                            scale_value=float(background[10])
                            omega=scale_value*frozen_source['masses'][1]
                            gamma=waves[label]**2/(2*omega*background[12])
                            cdm_rate=packet[name+'_rates'][:,matter]*units[matter]
                            expected=1j*(float(packet['carrier_rate'])-omega/background[12]-gamma)*amplitude
                            expected+=(1.5-1j*gamma)*np.exp(2j*phase)*amplitude.conjugate()
                            expected+=1j*scale_value*background[3]/np.sqrt(omega)*np.exp(1j*phase)*cdm_rate
                            actual=packet[name+'_rates'][:,slots[0]]*units[slots[0]]+1j*packet[name+'_rates'][:,slots[1]]*units[slots[1]]
                            require(error(expected,actual)<ALGEBRA,'heavy equation and CDM metric reconstruction checked individually')
                    require(stable['full_rate_identity_max']<ALGEBRA,'general unequal-scale cancellation identity')
                    counts['stable_endpoints']+=1
            left,right=endpoints
            length=float(right['efold']-left['efold'])
            coordinate=float((prediction['efold']-left['efold'])/length)
            weights=(2*coordinate**3-3*coordinate**2+1,(coordinate**3-2*coordinate**2+coordinate)*length,
                     -2*coordinate**3+3*coordinate**2,(coordinate**3-coordinate**2)*length)
            for key,derivative,target in (('value','derivative','predicted'),('output_value','output_derivative','output_predicted')):
                recalculated=weights[0]*left[key]+weights[1]*left[derivative]+weights[2]*right[key]+weights[3]*right[derivative]
                require(error(recalculated,prediction[target])<ALGEBRA,'frozen endpoint Hermite coefficients')
            native=load(root/'test-02'/f'{model}-interior-native.npz')
            small=load(root/'test-02'/f'{model}-small-native.npz')
            counts['heldout_native_packets']+=2
            source_error=np.linalg.norm(prediction['predicted']-comparison['actual'][None],axis=2)/prediction['source_scale'][None]
            output_error=np.linalg.norm(prediction['output_predicted']-native['readout_difference'][None],axis=-1)/prediction['output_scale'][None]
            small_error=np.linalg.norm(prediction['small_predicted']-small['difference'][None],axis=2)/prediction['small_scale'][None]
            small_output=np.linalg.norm(prediction['small_output_predicted']-small['readout_difference'][None],axis=-1)/prediction['small_output_scale'][None]
            for name,values in (('source_error',source_error),('output_error',output_error),('small_error',small_error),('small_output_error',small_output)):
                require(error(values,comparison[name])<ALGEBRA,'independent prediction diagnostics')
            require(result['finest_source_prediction_pass']==bool(source_error[-1].max()<GATE)
                    and result['finest_output_prediction_pass']==bool(output_error[-1].max()<GATE),'failed prediction flags retained')
            old_path=owned(RESPONSE_STAGE/label/'comparison-02'/f'{model}-comparison.npz')
            hashes({str(old_path):digest(old_path)})
            physical_scale=load(old_path)['reference_scale']
            output_absolute=np.max(abs(prediction['output_predicted'][:,:,:1]-native['readout_difference'][None,:,:1])/physical_scale[None,:,None,:],axis=(1,2,3))
            derivative_prediction_change=np.linalg.norm(np.diff(prediction['predicted'],axis=0),axis=2)/prediction['source_scale'][None]
            summaries.append(dict(label=label,model=model,phase_span=float(prediction['phase_span']),
                interior_source_by_derivative_level=np.max(source_error,axis=(1,2)).tolist(),
                interior_readout_by_derivative_level=np.max(output_error,axis=(1,2)).tolist(),
                readout_prediction_error_on_prior_physical_scale=output_absolute.tolist(),
                zero_endpoint_readout_scales=int(np.count_nonzero(prediction['output_scale']==1e-80)),
                derivative_change_effect_on_prediction=np.max(derivative_prediction_change,axis=(1,2)).tolist(),
                local_source_by_derivative_level=np.max(small_error,axis=(1,2)).tolist(),
                source_derivative_resolved=result['source_derivative_resolved'],
                readout_derivative_resolved=result['readout_derivative_resolved'],
                finest_source_prediction_pass=result['finest_source_prediction_pass'],
                finest_output_prediction_pass=result['finest_output_prediction_pass']))
            counts['models']+=1
    require(counts==dict(models=6,endpoints=12,stencil_packets=96,heldout_native_packets=12,stable_endpoints=6),'complete paired derivative experiment')
    starts=list(STAGE.glob('*.start.json'))
    require(len(starts)==13,'complete owned numerical job coverage')
    failed={'prepare-half-01','test-half-01','cancellation-half-01'}
    for path in starts:
        start=read(path)
        hashes({start['source_path']:start['source_sha256']})
        phase=path.name.removesuffix('.start.json')
        if phase=='audit-01':
            require(start['pid']==os.getpid(),'current audit worker')
            continue
        end=read(STAGE/(phase+'.end.json'))
        require(all(start[key]==end[key] for key in ('pid','created','command')),'worker identity')
        require(end['exit_code']==(1 if phase in failed else 0),'inspected terminal state')
        if psutil.pid_exists(start['pid']):
            created=datetime.fromisoformat(start['created'].replace('Z','+00:00')).timestamp()
            require(abs(psutil.Process(start['pid']).create_time()-created)>1,'task-owned worker exited')
    for path in STAGE.glob('*.py'):
        compile(path.read_text(encoding='utf-8-sig'),str(path),'exec',dont_inherit=True)
    require(not list(STAGE.rglob('__pycache__')),'no bytecode residue')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,accepted_results=accepted,
        counts=counts,summary=summaries,failed_attempts_preserved=sorted(failed),original_gates_and_banks_unchanged=True,
        all_interpolation_checks_pass=all(item['finest_source_prediction_pass'] and item['finest_output_prediction_pass'] for item in summaries),
        derivative_convergence_proven=False,actual_source_history_propagated=False,github_actions=False))
    print(json.dumps(dict(counts=counts,summary=summaries),indent=2),flush=True)


if __name__=='__main__':
    main()

