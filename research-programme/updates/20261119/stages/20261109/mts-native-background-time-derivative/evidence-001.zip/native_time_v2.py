from native_time import *
from matching_source import frozen_source
from physical_energy_map import PhysicalEnergyMap
from correlated_source import full_endpoint
from scipy.sparse import block_diag,diags,eye,csc_matrix
from scipy.sparse.linalg import splu
import ctypes


class NativeTimeV2(NativeTime):
    def restore_window(self):
        system=self.system
        signature=np.ascontiguousarray(system.context['signature_values'],dtype=np.int32)
        system.context['lib'].mts_operator_window(float(system.background['times'][-1]),
            signature.ctypes.data_as(ctypes.POINTER(ctypes.c_int)))

    def native(self,efold,theta,vectors):
        require(float(self.system.background['efold'][0])<=efold<=float(self.system.background['efold'][-1]),
                'original saved background domain only')
        self.restore_window()
        try:
            return super().native(efold,theta,vectors)
        finally:
            self.restore_window()

    def direct_frame(self,index):
        ordinal=index//2
        efold,theta=float(self.bank['efold'][ordinal]),float(self.bank['phase'][ordinal])
        paths=[owned(COMPLETED/LABEL/'source-even-01'/f'{self.model}-{index:02d}-source.json'),
               owned(COMPLETED/LABEL/'source-even-01'/f'{self.model}-{index:02d}-mean.npz')]
        self.consumed.update({str(path):digest(path) for path in paths})
        frozen,node=read(paths[0]),load(paths[1])
        physical=correlated(frozen,theta)[0] if self.model=='heavy' else frozen
        state=np.array([efold,physical['values'][0]/(np.exp(efold)*self.owner.saved.masses[0]),*physical['values'][1:]])
        carrier,rate=self.system.owner.phase(efold) if self.model=='heavy' else (0.,0.)
        energy=PhysicalEnergyMap(self.system)
        self.restore_window()
        try:
            with CommonCarrierFibre(self.system) as fibre:
                fibre.chart_angle=carrier
                fibre.carrier_rate=rate
                fibre.common_carrier=True
                current,maps,point,direct,source_paths=frozen_source(fibre,energy,state,theta)
                self.consumed.update(source_paths)
        finally:
            self.restore_window()
        dimension=self.dimension
        compact=current['layout']['size']
        physical_frame=block_diag((csc_matrix(maps['transform']),diags(maps['tail_weights'])),format='csc')
        entries=[]
        for branch in range(2):
            forward=np.eye(compact)
            inverse=np.eye(compact)
            slots=current['layout']['heavy']
            if slots:
                forward[slots]+=maps['forward_correction'][branch]
                inverse[slots]+=maps['inverse_correction'][branch]
            endpoint=full_endpoint(node['endpoint'][branch],node['keys'],node['remote_stream'],float(node['remote_endpoint']),dimension)
            entries.append(dict(forward=block_diag((csc_matrix(forward),eye(dimension-compact)),format='csc'),
                inverse=block_diag((csc_matrix(inverse),eye(dimension-compact)),format='csc'),
                endpoint=endpoint,endpoint_lu=splu(endpoint)))
        return efold,theta,dict(frame=physical_frame,frame_lu=splu(physical_frame),branches=entries)

    def frame(self,index):
        return self.direct_frame(index) if index==2 else super().frame(index)

    def map_control(self):
        efold,theta,analytic=super().frame(0)
        other_efold,other_theta,direct=self.direct_frame(0)
        require(efold==other_efold and theta==other_theta,'same original direct-map control')
        errors=[]
        for branch in range(2):
            first=to_native(analytic,analytic['branches'][branch],self.vectors[branch])
            second=to_native(direct,direct['branches'][branch],self.vectors[branch])
            errors.append(relative(first,second))
        require(max(errors)<ALGEBRA,'direct saved endpoint map matches earlier Fourier map')
        return errors

