from common import *
from native_time import NativeTime,to_native,to_retained
import numpy as np


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'test-01'
    output.mkdir(exist_ok=False)
    freeze_path=ROOT/'prediction-01/result.json'
    frozen=read(freeze_path)
    require(frozen['passed'] and frozen['predictions_frozen_before_direct_interior_test'],'frozen forward prediction')
    consumed={str(freeze_path):digest(freeze_path)}
    for path,seal in frozen['sources'].items():
        require(digest(path)==seal,'frozen implementation')
    reports=[]
    for model in ('heavy','cold'):
        entry=next(item for item in frozen['reports'] if item['model']==model)
        require(digest(entry['path'])==entry['sha256'],'unchanged prediction')
        consumed[entry['path']]=entry['sha256']
        prediction=load(entry['path'])
        case=NativeTime(model,'test-01/context-'+model)
        require(np.array_equal(case.vectors,prediction['vectors']),'same fixed retained test vectors')
        efold,theta,frame=case.frame(2)
        require(efold==float(prediction['efold']),'preselected target')
        native=np.array([to_native(frame,item,case.vectors[branch]) for branch,item in enumerate(frame['branches'])])
        actual=case.native(efold,theta,native)
        value=np.array([to_retained(frame,item,actual['difference'][branch]) for branch,item in enumerate(frame['branches'])])
        source_error=np.linalg.norm(prediction['predicted']-value[None],axis=2)/prediction['source_scale'][None]
        output_error=np.linalg.norm(prediction['output_predicted']-actual['readout_difference'][None],axis=-1)/prediction['output_scale'][None]
        np.savez_compressed(output/f'{model}-interior-native.npz',**actual)
        probe=case.native(float(prediction['small_efold']),float(prediction['small_phase']),prediction['small_native'])
        small_error=np.linalg.norm(prediction['small_predicted']-probe['difference'][None],axis=2)/prediction['small_scale'][None]
        small_output_error=np.linalg.norm(prediction['small_output_predicted']-probe['readout_difference'][None],axis=-1)/prediction['small_output_scale'][None]
        np.savez_compressed(output/f'{model}-small-native.npz',**probe)
        jet_records=[]
        derivative_errors=[]
        output_derivative_errors=[]
        for index in (0,4):
            path=ROOT/'prediction-01'/f'{model}-{index:02d}-jets.npz'
            jets=load(path)
            consumed[str(path)]=digest(path)
            scale=np.maximum(np.max(np.linalg.norm(jets['derivative'],axis=2),axis=0),1e-80)
            output_scale=np.maximum(np.max(np.linalg.norm(jets['output_derivative'],axis=-1),axis=0),1e-80)
            errors=np.linalg.norm(np.diff(jets['derivative'],axis=0),axis=2)/scale
            output_errors=np.linalg.norm(np.diff(jets['output_derivative'],axis=0),axis=-1)/output_scale
            derivative_errors.append(errors)
            output_derivative_errors.append(output_errors)
            jet_records.append(dict(index=index,step=float(jets['step']),phase_control=float(jets['phase_control']),
                source_derivative_changes=errors.tolist(),readout_derivative_changes=output_errors.tolist(),
                source_derivative_resolved=bool(errors[-1].max()<GATE),readout_derivative_resolved=bool(output_errors[-1].max()<GATE)))
        target=output/f'{model}-comparison.npz'
        np.savez_compressed(target,actual=value,source_error=source_error,output_error=output_error,
            small_error=small_error,small_output_error=small_output_error,derivative_changes=derivative_errors,
            readout_derivative_changes=output_derivative_errors)
        reports.append(dict(model=model,path=str(target),sha256=digest(target),consumed=case.consumed.copy(),
            phase_span=float(prediction['phase_span']),jets=jet_records,
            source_errors=source_error.tolist(),output_errors=output_error.tolist(),
            small_source_errors=small_error.tolist(),small_output_errors=small_output_error.tolist(),
            finest_source_prediction_pass=bool(source_error[-1].max()<GATE),
            finest_output_prediction_pass=bool(output_error[-1].max()<GATE),
            finest_small_source_pass=bool(small_error[-1].max()<GATE),
            finest_small_output_pass=bool(small_output_error[-1].max()<GATE),
            source_derivative_resolved=all(item['source_derivative_resolved'] for item in jet_records),
            readout_derivative_resolved=all(item['readout_derivative_resolved'] for item in jet_records)))
        print(LABEL,model,'phase span',float(prediction['phase_span']),'interior source',float(source_error[-1].max()),
              'interior readout',float(output_error[-1].max()),'local source',float(small_error[-1].max()),
              'jet changes',max(item['source_derivative_changes'][-1][branch][column] for item in jet_records for branch in range(2) for column in range(5)),flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'frozen predictions and saved inputs preserved')
    write(output/'result.json',dict(completed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        all_prediction_checks_pass=all(item['finest_source_prediction_pass'] and item['finest_output_prediction_pass'] for item in reports),
        fixed_tolerances=True,observational_holdout=False,new_parameter_fits=False,
        actual_current_source_history_propagated=False,failed_controls_preserved=True))


if __name__=='__main__':
    main()

