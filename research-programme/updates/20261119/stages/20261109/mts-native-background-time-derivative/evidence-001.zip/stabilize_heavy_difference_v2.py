from common import *
from frame_source_v2 import frames,to_native,to_retained,native_map_rate,relative
from correlated_source import CorrelatedSource
import numpy as np


def stable_difference(packet,units,layout,mass):
    reference=packet['reference_background']
    retained=packet['retained_background']
    require(reference[10]>0 and retained[10]>0 and mass>0,'positive original scales and mass')
    scale_reference=float(reference[10])
    scale_retained=float(retained[10])
    omega_reference=scale_reference*mass
    omega_retained=scale_retained*mass
    inverse_omega_difference=(omega_retained-omega_reference)/(omega_reference*omega_retained)
    inverse_omega_average=.5*(1/omega_reference+1/omega_retained)
    carrier=float(packet['carrier'])
    slots=layout['heavy']
    matter=layout['cdm']
    require(len(slots)==2,'same heavy encoded slots')
    native=packet['native_vectors']
    amplitude=native[:,slots[0]]*units[slots[0]]+1j*native[:,slots[1]]*units[slots[1]]
    inverse_difference=(retained[12]-reference[12])/(reference[12]*retained[12])
    inverse_average=.5*(1/reference[12]+1/retained[12])
    omega_difference=omega_reference-omega_retained
    frequency_difference=.5*(omega_reference+omega_retained)*inverse_difference+inverse_average*omega_difference
    gamma_difference=WAVE**2/2*(inverse_omega_average*inverse_difference+inverse_average*inverse_omega_difference)
    factor_reference=scale_reference/np.sqrt(omega_reference)
    factor_retained=scale_retained/np.sqrt(omega_retained)
    factor_difference=(scale_reference-scale_retained)/(mass*(factor_reference+factor_retained))
    velocity_reference=-packet['reference_rates'][:,matter]*units[matter]/WAVE
    velocity_retained=-packet['retained_rates'][:,matter]*units[matter]/WAVE
    product_difference=.5*(reference[3]+retained[3])*(velocity_reference-velocity_retained)
    product_difference+=.5*(velocity_reference+velocity_retained)*(reference[3]-retained[3])
    product_average=.5*(reference[3]*velocity_reference+retained[3]*velocity_retained)
    metric_difference=.5*(factor_reference+factor_retained)*product_difference+product_average*factor_difference
    difference=-1j*(frequency_difference+gamma_difference)*amplitude
    difference-=1j*gamma_difference*np.exp(2j*carrier)*amplitude.conjugate()
    difference-=1j*WAVE*np.exp(1j*carrier)*metric_difference
    result=packet['difference'].copy()
    result[:,slots[0]]=difference.real/units[slots[0]]
    result[:,slots[1]]=difference.imag/units[slots[1]]
    rate_scale=np.maximum(np.maximum(np.linalg.norm(packet['reference_rates'],axis=1),
                                    np.linalg.norm(packet['retained_rates'],axis=1)),1e-80)
    agreement=np.linalg.norm(result-packet['difference'],axis=1)/rate_scale
    require(float(agreement.max())<ALGEBRA,'derived cancellation matches native equations at full-rate scale')
    return result,agreement


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'cancellation-02'
    output.mkdir(exist_ok=False)
    owner=CorrelatedSource('heavy')
    consumed=owner.consumed.copy()
    reports=[]
    model='heavy'
    for index in (0,4):
        base=ROOT/'prediction-02'
        if not (base/f'{model}-{index:02d}-jets.npz').exists():
            base=ROOT/'prediction-01'
        report_path=base/f'{model}-{index:02d}-result.json'
        report=read(report_path)
        require(report['passed'] and digest(report['path'])==report['sha256'],'accepted endpoint jets')
        consumed[str(report_path)]=digest(report_path)
        consumed[report['path']]=report['sha256']
        jets=load(report['path'])
        units=jets['units']
        paths=[owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-source.json'),
               owned(COMPLETED/LABEL/'source-even-01'/f'{model}-{index:02d}-mean.npz'),
               owned(COMPLETED/LABEL/'forcing-02'/f'{model}-{index:02d}-forcing.npz')]
        frozen,node,cached=read(paths[0]),load(paths[1]),load(paths[2])
        consumed.update({str(path):digest(path) for path in paths})
        center_path=base/f'{model}-{index:02d}-center.npz'
        center=load(center_path)
        consumed[str(center_path)]=digest(center_path)
        frame=frames(owner,frozen,float(jets['theta']),float(center['carrier']),float(center['carrier_rate']),units,node,cached)
        center_difference,center_agreement=stable_difference(center,units,frozen['layout'],frozen['masses'][1])
        points={}
        agreement_records=[]
        for ordinal,offset in ((0,-2.),(1,-1.),(2,-.5),(3,-.25),(5,.25),(6,.5),(7,1.),(8,2.)):
            path=base/f'{model}-{index:02d}-offset-{ordinal:02d}.npz'
            require(digest(path)==report['native_packets'][str(path)],'same native stencil packet')
            consumed[str(path)]=digest(path)
            packet=load(path)
            difference,agreement=stable_difference(packet,units,frozen['layout'],frozen['masses'][1])
            points[offset]=difference
            agreement_records.append(dict(offset=offset,maximum_full_rate_discrepancy=float(agreement.max())))
        value=np.array([to_retained(frame,entry,center_difference[branch,:,:5]) for branch,entry in enumerate(frame['branches'])])
        derivatives=[]
        for divisor in (1,2,4):
            step=float(jets['step'])/divisor
            offset=1/divisor
            derivative=(-points[2*offset]+8*points[offset]-8*points[-offset]+points[-2*offset])/(12*step)
            branch_values=[]
            for branch,entry in enumerate(frame['branches']):
                term=to_retained(frame,entry,derivative[branch]+center_difference[branch,:,5:])
                native_value=to_native(frame,entry,value[branch])
                moving=to_retained(frame,entry,native_map_rate(frame,entry,value[branch],native_value))
                branch_values.append(term-moving)
            derivatives.append(branch_values)
        derivatives=np.array(derivatives)
        scale=np.maximum(np.max(np.linalg.norm(derivatives,axis=2),axis=0),1e-80)
        errors=np.linalg.norm(np.diff(derivatives,axis=0),axis=2)/scale
        native_scale=np.maximum(np.max(np.linalg.norm(jets['derivative'],axis=2),axis=0),1e-80)
        original_errors=np.linalg.norm(np.diff(jets['derivative'],axis=0),axis=2)/native_scale
        target=output/f'{index:02d}-jets.npz'
        np.savez_compressed(target,value=value,derivative=derivatives,changes=errors,original_changes=original_errors,
                            original_value=jets['value'],original_derivative=jets['derivative'],center_agreement=center_agreement)
        reports.append(dict(index=index,path=str(target),sha256=digest(target),original_changes=original_errors.tolist(),
            changes=errors.tolist(),full_rate_identity_max=max(float(center_agreement.max()),max(item['maximum_full_rate_discrepancy'] for item in agreement_records)),
            stencil_checks=agreement_records,derivative_resolved=bool(errors[-1].max()<GATE),
            current_mode_derivative_resolved=bool(errors[-1,:,0].max()<GATE)))
        print(LABEL,index,'original derivative change',float(original_errors[-1].max()),'stable',float(errors[-1].max()),
              'current mode',float(errors[-1,:,0].max()),flush=True)
    require(all(digest(path)==seal for path,seal in consumed.items()),'only saved data used')
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),consumed=consumed,reports=reports,
        heavy_equation_identity_checked=True,baseline_unchanged=True,all_stencils_reused=True,
        frozen_predictions_not_replaced=True,no_new_native_evaluation=True,derivative_resolution_claimed=all(item['derivative_resolved'] for item in reports)))


if __name__=='__main__':
    main()
