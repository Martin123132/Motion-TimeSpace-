from common import *
from native_time import NativeTime,hermite
import numpy as np


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'prediction-01'
    output.mkdir(parents=True,exist_ok=False)
    write(output/'freeze.json',dict(inputs=inputs,sources=sources(),endpoint_indices=[0,4],target_index=2,
        finite_difference_divisors=[1,2,4],step_rule='min(interval/32, 0.02/max(abs(phase_rate),1))',
        local_probe_offset='h/7; not a derivative stencil point',gate=GATE,algebra=ALGEBRA,
        new_interior_operator_evaluation_not_read=True))
    reports=[]
    for model in ('heavy','cold'):
        case=NativeTime(model,'prediction-01/context-'+model)
        left=case.endpoint(0,output)
        right=case.endpoint(4,output)
        length=float(right['efold']-left['efold'])
        target=float(case.bank['efold'][1])
        local=(target-float(left['efold']))/length
        require(0<local<1,'unused original interior source epoch')
        values=hermite(left['value'],right['value'],left['derivative'],right['derivative'],local,length)
        readouts=hermite(left['output_value'],right['output_value'],left['output_derivative'],right['output_derivative'],local,length)
        delta=float(left['small_probe_efold']-left['efold'])
        small=left['native_value']+delta*left['native_derivative']
        small_readout=left['native_output_value']+delta*left['native_output_derivative']
        target_path=output/f'{model}-prediction.npz'
        np.savez_compressed(target_path,efold=target,vectors=case.vectors,predicted=values,output_predicted=readouts,
            source_scale=np.maximum(np.maximum(np.linalg.norm(left['value'],axis=1),np.linalg.norm(right['value'],axis=1)),1e-80),
            output_scale=np.maximum(np.maximum(np.linalg.norm(left['output_value'],axis=-1),np.linalg.norm(right['output_value'],axis=-1)),1e-80),
            small_efold=left['small_probe_efold'],small_phase=left['small_probe_phase'],small_native=left['native'],
            small_predicted=small,small_output_predicted=small_readout,
            small_scale=np.maximum(np.linalg.norm(left['native_value'],axis=1),1e-80),
            small_output_scale=np.maximum(np.linalg.norm(left['native_output_value'],axis=-1),1e-80),
            phase_span=right['theta']-left['theta'],left_efold=left['efold'],right_efold=right['efold'])
        reports.append(dict(model=model,path=str(target_path),sha256=digest(target_path),phase_span=float(right['theta']-left['theta']),
            local_coordinate=local,consumed=case.consumed.copy()))
        print(LABEL,model,'prediction frozen, phase span',reports[-1]['phase_span'],flush=True)
    write(output/'result.json',dict(passed=True,inputs=inputs,sources=sources(),reports=reports,
        predictions_frozen_before_direct_interior_test=True,physical_current_history_not_propagated=True))


if __name__=='__main__':
    main()

