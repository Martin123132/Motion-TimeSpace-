from common import *
from frame_source_v2 import frames,to_native,to_retained,native_map_rate,CommonCarrierFibre,BRANCHES,relative
from accumulated_support_v2 import retained_checked,NAMES
from correlated_source import CorrelatedSource,correlated,reconstruct
from adjoint_operator import open_owned
from scipy.integrate import solve_ivp
import numpy as np


class NativeTime:
    def __init__(self,model,folder):
        self.model=model
        self.owner=CorrelatedSource(model)
        (ROOT/folder).mkdir(parents=True,exist_ok=False)
        self.system=open_owned(model,folder)
        self.source,self.bank,self.leading,self.consumed=retained_checked(model)
        self.consumed.update(self.owner.consumed)
        self.dimension=len(self.system.units)
        require(abs(self.system.wave/WAVE-1)<ALGEBRA,'unchanged original wave')
        parent=owned(FRAME_STAGE/LABEL/'source-02'/f'{model}-00-background.npz')
        self.parent=load(parent)
        self.consumed[str(parent)]=digest(parent)
        self.vectors=self.parent['retained_vectors'][:,:,[0,2,3,4,5]].copy()

    def frame(self,index):
        ordinal=index//2
        efold=float(self.bank['efold'][ordinal])
        theta=float(self.bank['phase'][ordinal])
        paths=[owned(COMPLETED/LABEL/'source-even-01'/f'{self.model}-{index:02d}-source.json'),
               owned(COMPLETED/LABEL/'source-even-01'/f'{self.model}-{index:02d}-mean.npz'),
               owned(COMPLETED/LABEL/'forcing-02'/f'{self.model}-{index:02d}-forcing.npz')]
        self.consumed.update({str(path):digest(path) for path in paths})
        frozen,node,cached=read(paths[0]),load(paths[1]),load(paths[2])
        require(efold==frozen['efold'],'same original source epoch')
        carrier,rate=self.system.owner.phase(efold) if self.model=='heavy' else (0.,0.)
        frame=frames(self.owner,frozen,theta,carrier,rate,self.system.units,node,cached)
        return efold,theta,frame

    def phase_rhs(self,efold,state):
        guard()
        if self.model=='cold':
            return [0.]
        background=self.owner.saved.mean(efold)
        scalar=background['slow'][0]
        external=background['external'][0]
        omega=np.exp(efold)*self.owner.saved.masses[1]
        rebuilt=reconstruct(float(background['heavy'][0]),float(external[0]),float(external[1]),
                            float(scalar[0]),float(scalar[1]),omega,state[0])
        return [omega/float(rebuilt['hubble'])-1.5*np.sin(2*state[0])]

    def local_phases(self,efold,theta,step):
        offsets=step*np.array([-2.,-1.,-.5,-.25,0.,.25,.5,1.,2.,1/7])
        values=[]
        counts=[]
        for divisions in (32,64):
            solved={}
            evaluations=0
            for sign in (-1.,1.):
                solution=solve_ivp(self.phase_rhs,(efold,efold+sign*2*step),[theta],
                    method='DOP853',rtol=2e-12,atol=2e-14,max_step=2*step/divisions,dense_output=True)
                require(solution.success,'local phase equation solve')
                solved[sign]=solution
                evaluations+=solution.nfev
            phases=np.array([theta if shift==0 else solved[float(np.sign(shift))].sol(efold+shift)[0] for shift in offsets])
            values.append(phases)
            counts.append(evaluations)
        error=float(np.max(abs(values[1]-values[0])))
        require(error<ALGEBRA,'same saved phase with local step control')
        return offsets,values[1],dict(error=error,nfev=counts,rtol=2e-12,atol=2e-14,divisions=[32,64])

    def native(self,efold,theta,vectors):
        system=self.system
        count=vectors.shape[-1]
        require(vectors.shape[:2]==(2,self.dimension),'same full native coordinates')
        reference_rates=np.empty_like(vectors)
        retained_rates=np.empty_like(vectors)
        reference_readouts=np.empty((2,count,len(NAMES)))
        retained_readouts=np.empty_like(reference_readouts)
        carrier,rate=system.owner.phase(efold) if self.model=='heavy' else (0.,0.)
        point=system.context['point'](efold).copy()
        for branch,name in enumerate(BRANCHES):
            for column in range(count):
                answer=system.evaluate(efold,vectors[branch,:,column]*system.units,name)
                reference_rates[branch,:,column]=answer[0]/system.units
                reference_readouts[branch,column]=[answer[1][key] for key in NAMES]
        frozen=self.owner.frozen(efold)
        physical=correlated(frozen,theta)[0] if self.model=='heavy' else frozen
        state=np.array([efold,physical['values'][0]/(np.exp(efold)*self.owner.saved.masses[0]),*physical['values'][1:]])
        with CommonCarrierFibre(system) as fibre:
            fibre.chart_angle=carrier
            fibre.carrier_rate=rate
            fibre.common_carrier=True
            fibre.install(state,theta)
            retained_point=fibre.current.copy()
            for branch,name in enumerate(BRANCHES):
                for column in range(count):
                    guard()
                    answer=system.evaluate(efold,vectors[branch,:,column]*system.units,name)
                    retained_rates[branch,:,column]=answer[0]/system.units
                    retained_readouts[branch,column]=[answer[1][key] for key in NAMES]
        return dict(efold=np.array(efold),theta=np.array(theta),native_vectors=vectors,
                    reference_rates=reference_rates,retained_rates=retained_rates,
                    difference=reference_rates-retained_rates,readout_difference=reference_readouts-retained_readouts,
                    reference_readouts=reference_readouts,retained_readouts=retained_readouts,
                    reference_background=point,retained_background=retained_point,carrier=np.array(carrier),carrier_rate=np.array(rate))

    def endpoint(self,index,output):
        efold,theta,frame=self.frame(index)
        width=float(self.bank['efold'][2]-self.bank['efold'][0])
        angular=abs(float(self.phase_rhs(efold,[theta])[0]))
        step=min(width/32,.02/max(angular,1.))
        offsets,phases,phase_check=self.local_phases(efold,theta,step)
        native=np.array([to_native(frame,entry,self.vectors[branch]) for branch,entry in enumerate(frame['branches'])])
        native_rate=np.array([native_map_rate(frame,entry,self.vectors[branch],native[branch])
                              for branch,entry in enumerate(frame['branches'])])
        center=self.native(efold,theta,np.concatenate([native,native_rate],axis=2))
        np.savez_compressed(output/f'{self.model}-{index:02d}-center.npz',**center)
        points={}
        paths={}
        for ordinal,(offset,phase) in enumerate(zip(offsets[:9],phases[:9])):
            if offset==0:
                continue
            packet=self.native(efold+float(offset),float(phase),native)
            target=output/f'{self.model}-{index:02d}-offset-{ordinal:02d}.npz'
            np.savez_compressed(target,**packet)
            points[float(offset/step)]=packet
            paths[str(target)]=digest(target)
        coefficients=[]
        for divisor in (1,2,4):
            displacement=1/divisor
            coefficients.append({key:(-points[2*displacement][key]+8*points[displacement][key]
                -8*points[-displacement][key]+points[-2*displacement][key])/(12*step/divisor)
                for key in ('difference','readout_difference')})
        value=np.array([to_retained(frame,entry,center['difference'][branch,:,:5]) for branch,entry in enumerate(frame['branches'])])
        rate_values=[]
        output_rates=[]
        connection=[]
        for coefficient in coefficients:
            branch_rates=[]
            branch_connection=[]
            for branch,entry in enumerate(frame['branches']):
                term=to_retained(frame,entry,coefficient['difference'][branch]+center['difference'][branch,:,5:])
                mapped_value=to_native(frame,entry,value[branch])
                moving=to_retained(frame,entry,native_map_rate(frame,entry,value[branch],mapped_value))
                branch_rates.append(term-moving)
                branch_connection.append(moving)
            rate_values.append(branch_rates)
            connection.append(branch_connection)
            output_rates.append(coefficient['readout_difference']+center['readout_difference'][:,5:])
        target=output/f'{self.model}-{index:02d}-jets.npz'
        np.savez_compressed(target,efold=efold,theta=theta,step=step,vectors=self.vectors,units=self.system.units,
            value=value,derivative=rate_values,output_value=center['readout_difference'][:,:5],
            output_derivative=output_rates,connection=connection,native=native,native_rate=native_rate,
            native_value=center['difference'][:,:,:5],native_derivative=np.array([item['difference'] for item in coefficients]),
            native_output_value=center['readout_difference'][:,:5],
            native_output_derivative=np.array([item['readout_difference'] for item in coefficients]),
            small_probe_efold=efold+step/7,small_probe_phase=phases[-1],phase_control=phase_check['error'])
        paths[str(output/f'{self.model}-{index:02d}-center.npz')]=digest(output/f'{self.model}-{index:02d}-center.npz')
        write(output/f'{self.model}-{index:02d}-result.json',dict(passed=True,model=self.model,index=index,path=str(target),
              sha256=digest(target),native_packets=paths,phase_control=phase_check,consumed=self.consumed.copy(),sources=sources(),
              derivative_method='fourth-order centered native-equation derivative at h,h/2,h/4; no residual fitting',
              derivative_convergence_not_assumed=True))
        return load(target)


def hermite(left,right,derivative_left,derivative_right,coordinate,length):
    return ((2*coordinate**3-3*coordinate**2+1)*left+(coordinate**3-2*coordinate**2+coordinate)*length*derivative_left
            +(-2*coordinate**3+3*coordinate**2)*right+(coordinate**3-coordinate**2)*length*derivative_right)

