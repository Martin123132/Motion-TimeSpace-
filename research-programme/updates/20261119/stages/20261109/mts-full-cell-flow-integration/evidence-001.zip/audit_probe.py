from full_cell_audit import audit

audit('probe')

