from common import *
from response_support import DenseHistory
from exact_interval_weights import independent_moments
from fractions import Fraction
import numpy as np


def make_rule(nodes,left,right):
    start,stop=Fraction(left),Fraction(right)
    positions=np.array([float((2*Fraction(float(value))-start-stop)/(stop-start)) for value in nodes])
    matrix=np.polynomial.chebyshev.chebvander(positions,len(nodes)-1).T
    moments=np.array([2/(1-degree*degree) if degree%2==0 else 0. for degree in range(len(nodes))])
    weights=np.linalg.solve(matrix,moments)*float((stop-start)/2)
    error=independent_moments(nodes,weights,left,right)
    require(error<ALGEBRA and np.min(weights)>0,'exact binary interval moments')
    return weights,error


def main():
    modest()
    inputs=verify_inputs()
    output=ROOT/'freeze-01'
    output.mkdir(parents=True,exist_ok=False)
    prior_path=SEGMENT_STAGE/LABEL/'freeze-01/result.json'
    prior=read(prior_path)
    inputs[str(prior_path)]=digest(prior_path)
    previous=next(row for row in prior['reports'] if row['model']=='heavy')
    require(digest(previous['path'])==previous['sha256'],'retained selected nodes')
    old_grid=load(previous['path'])
    inputs[previous['path']]=previous['sha256']
    background=load(previous['background_path'])
    require(digest(previous['background_path'])==previous['background_sha256'],'same dense background')
    inputs[previous['background_path']]=previous['background_sha256']
    selected={segment['segment']:segment for segment in previous['segments']}
    prior_flow={}
    for index,efold in enumerate(old_grid['efold']):
        path=SEGMENT_STAGE/LABEL/'points-01'/f'heavy-{index:03d}-flow-result.json'
        value=read(path)
        require(value['passed'] and digest(value['path'])==value['sha256'],'accepted prior flow node')
        prior_flow[float(efold)]=dict(path=str(path),sha256=digest(path),index=index)
        inputs[str(path)]=digest(path)
    old_index_path=REFINEMENT/LABEL/'points-01/refined-cell03-result.json'
    old_index=next(row for row in read(old_index_path)['reports'] if row['model']=='heavy')
    inputs[str(old_index_path)]=digest(old_index_path)
    original_lookup={row['efold']:index for index,row in enumerate(old_index['nodes'])}
    histories_path=THIRD_CELL/LABEL/'history-02/result.json'
    history_entry=next(row for row in read(histories_path)['reports'] if row['model']=='heavy' and row['control']=='fine')
    require(digest(history_entry['index'])==history_entry['sha256'],'same saved fine history')
    inputs[str(histories_path)]=digest(histories_path)
    inputs[history_entry['index']]=history_entry['sha256']
    history=DenseHistory(history_entry['index'])
    left,right=float(old_grid['efold'][0]),float(old_grid['efold'][-1])
    intersect=np.flatnonzero((background['segment_end']>left)&(background['segment_start']<right))
    require(len(intersect)==158,'full original segment coverage')
    segments=[]
    efolds=[]
    for ordinal,native_index in enumerate(intersect):
        start=max(left,float(background['segment_start'][native_index]))
        stop=min(right,float(background['segment_end'][native_index]))
        if int(native_index) in selected:
            nodes=old_grid['efold'][selected[int(native_index)]['indices']].copy()
        else:
            center,radius=(start+stop)/2,(stop-start)/2
            nodes=(center-radius*np.cos(np.linspace(0,np.pi,33)))[::2]
            nodes[0],nodes[-1]=start,stop
            if start==float(background['segment_start'][native_index]) and native_index>0:
                nodes[0]=np.nextafter(start,stop)
        require(np.all(np.searchsorted(background['segment_end'],nodes,side='left')==native_index),'same native segment at all nodes')
        rules=[]
        for count in ([9,17,33] if len(nodes)==33 else [9,17]):
            stride=(len(nodes)-1)//(count-1)
            local_indices=list(range(0,len(nodes),stride))
            weights,error=make_rule(nodes[local_indices],start,stop)
            rules.append(dict(count=count,local_indices=local_indices,weights=weights.tolist(),independent_legendre_error=error))
        indices=list(range(len(efolds),len(efolds)+len(nodes)))
        efolds.extend(nodes.tolist())
        segments.append(dict(ordinal=ordinal,segment=int(native_index),range=[start,stop],indices=indices,rules=rules,
                             inherited_33_node_panel=int(native_index) in selected))
    require(all(first['range'][1]==second['range'][0] for first,second in zip(segments,segments[1:])),'no interval gaps or overlaps')
    require(segments[0]['range'][0]==left and segments[-1]['range'][1]==right,'original cell endpoints')
    efolds=np.array(efolds)
    require(np.all(np.diff(efolds)>0),'unique ordered actual evaluation points')
    phases=[]
    reuse=[]
    for index,efold in enumerate(efolds):
        phase=history.state(float(efold))[0]
        if float(efold) in prior_flow:
            row=prior_flow[float(efold)]
            require(abs(phase-float(old_grid['phase'][row['index']]))<ALGEBRA,'same physical phase at inherited source')
            phase=float(old_grid['phase'][row['index']])
            reuse.append(dict(index=index,flow=row))
        elif float(efold) in original_lookup:
            old=original_lookup[float(efold)]
            source,control=old_index['nodes'][old],old_index['phase_controls'][old]
            require(abs(phase-source['theta'])<ALGEBRA,'same physical phase at original source')
            phase=source['theta']
            reuse.append(dict(index=index,source=source,phase=control))
        phases.append(phase)
    grid_path=output/'heavy-grid.npz'
    np.savez_compressed(grid_path,efold=efolds,phase=phases,jacobian=np.ones(len(efolds)))
    batches=[dict(batch=ordinal//8,segment_ordinals=list(range(ordinal,min(ordinal+8,len(segments)))))
             for ordinal in range(0,len(segments),8)]
    require(all(digest(path)==checksum for path,checksum in inputs.items()),'fixed evidence unchanged')
    write(output/'result.json',dict(passed=True,sources=sources(),inputs=inputs,model='heavy',path=str(grid_path),
          sha256=digest(grid_path),segments=segments,batches=batches,reuse=reuse,points=len(efolds),
          reused_flow_points=sum('flow' in row for row in reuse),new_flow_points=len(efolds)-sum('flow' in row for row in reuse),
          baseline_heavy_field_absent=True,baseline_control_source=str(SEGMENT_STAGE/LABEL/'projection-01/result.json'),
          probe_segment_ordinal=1,measure='dN',no_history_reintegration=True,no_source_replacement=True,
          full_cell_freeze_not_a_completion_claim=True,unchanged_gates=[ALGEBRA,GATE]))
    print('full freeze:',len(segments),'segments;',len(efolds),'nodes;',sum('flow' in row for row in reuse),'inherited flow nodes',flush=True)


if __name__=='__main__':
    main()

