from common import *
from controlled_sources_v2 import ControlledPhaseSource
from segment_sources import coefficient, stress_pairs
import numpy as np


def checked_entry(entry, index, grid, consumed):
    require(digest(entry['path'])==entry['sha256'],'completed node receipt unchanged')
    consumed[entry['path']]=entry['sha256']
    result=read(entry['path'])
    require(result['passed'] and result['model']=='heavy','same MTS flow point')
    for key in ('path','source','phase'):
        checksum=result['sha256' if key=='path' else key+'_sha256']
        require(digest(result[key])==checksum,'completed node bytes')
        consumed[result[key]]=checksum
    source=load(result['source'])
    flow=load(result['path'])
    require(float(flow['efold'])==float(grid['efold'][index])==float(source['efold']),'same frozen N')
    require(float(source['phase'])==float(grid['phase'][index]),'same frozen physical phase')
    for path,checksum in result['sources'].items():
        require(digest(path)==checksum,'unchanged executed source')
    return dict(index=index,path=entry['path'],sha256=entry['sha256'],reused=True)


def build(ordinals, tag):
    modest()
    freeze_path=FROZEN_STAGE/LABEL/'freeze-01/result.json'
    frozen=read(freeze_path)
    require(frozen['passed'],'complete full-cell node freeze')
    for path,checksum in frozen['inputs'].items():
        require(digest(path)==checksum,'freeze evidence unchanged')
    require(digest(frozen['path'])==frozen['sha256'],'same frozen quadrature nodes')
    grid=load(frozen['path'])
    output=ROOT/'batches'
    output.mkdir(parents=True,exist_ok=True)
    result_path=output/(tag+'-result.json')
    require(not result_path.exists(),'inspect completed batch instead of rerunning')
    if tag!='probe':
        require(read(STAGE/'probe-audit/result.json')['passed'],'independent new-segment probe accepted')
    consumed={str(freeze_path):digest(freeze_path),frozen['path']:frozen['sha256']}
    reuse={entry['index']:entry for entry in frozen['reuse']}
    case=ControlledPhaseSource('heavy',tag)
    layout_path=owned(COMPLETED/LABEL/'source-even-01/heavy-00-source.json')
    massless=read(layout_path)['layout']['massless_all']
    attribution_path=REFINEMENT/LABEL/'source-attribution-01/heavy-attribution.npz'
    columns=load(attribution_path)['columns'].astype(int)
    consumed[str(layout_path)]=digest(layout_path)
    consumed[str(attribution_path)]=digest(attribution_path)
    reports=[]
    for ordinal in ordinals:
        segment=frozen['segments'][ordinal]
        folder=ROOT/'segments'/f'{ordinal:03d}-{segment["segment"]}'
        folder.mkdir(parents=True,exist_ok=True)
        entries=[]
        for index in segment['indices']:
            guard()
            target_report=folder/f'heavy-{index:03d}-flow-result.json'
            if index in reuse and 'flow' in reuse[index]:
                entries.append(checked_entry(reuse[index]['flow'],index,grid,consumed))
                continue
            if target_report.exists():
                entries.append(checked_entry(dict(path=str(target_report),sha256=digest(target_report)),index,grid,consumed))
                continue
            require(not list(folder.glob(f'heavy-{index:03d}*')),'partial unsigned point: inspect before continuing')
            if index in reuse and 'source' in reuse[index]:
                report,phase=reuse[index]['source'],reuse[index]['phase']
                for item in (report,phase):
                    require(item['passed'] and digest(item['path'])==item['sha256'],'saved native source reuse')
                was_reused=True
            else:
                report=case.sample(index,grid,folder)
                phase=case.phase_control(index,grid,folder,report,True)
                was_reused=False
            packet,phase_packet=load(report['path']),load(phase['path'])
            require(float(packet['efold'])==float(grid['efold'][index]),'same new frozen N')
            require(np.array_equal(packet['units'],case.system.units),'same native units')
            consumed[report['path']]=report['sha256']
            consumed[phase['path']]=phase['sha256']
            all_components,all_records,all_coefficients=[],[],[]
            for phase_control in ('fine','step-coarse'):
                if phase_control=='fine':
                    active,theta=packet,float(packet['phase'])
                else:
                    active={key[4:]:value for key,value in phase_packet.items() if key.startswith('map_')}
                    active.update({key[7:]:value for key,value in phase_packet.items() if key.startswith('native_')})
                    active['units']=packet['units']
                    theta=float(phase_packet['coarse_phase'])
                pieces,primitives=stress_pairs(case,active,theta,massless)
                covector=coefficient(active,case.adjoints,case.row_norm,columns,massless,float(grid['efold'][index]))
                all_components.append(np.einsum('abc,bvp->abvcp',covector,pieces))
                all_records.append(primitives)
                all_coefficients.append(covector)
            target=folder/f'heavy-{index:03d}-flow.npz'
            np.savez_compressed(target,components=all_components,coefficients=all_coefficients,
                                efold=grid['efold'][index],massless_slots=massless,columns=columns)
            result=dict(passed=True,model='heavy',index=index,path=str(target),sha256=digest(target),
                        source=report['path'],source_sha256=report['sha256'],phase=phase['path'],phase_sha256=phase['sha256'],
                        reused_source=was_reused,primitive_records=all_records,
                        no_background_replacement=True,sources=sources())
            write(target_report,result)
            entries.append(dict(index=index,path=str(target_report),sha256=digest(target_report),reused=False))
            print(tag,'segment',ordinal,'point',index,'saved',flush=True)
        reports.append(dict(ordinal=ordinal,segment=segment['segment'],nodes=entries))
        print(tag,'SEGMENT',ordinal,'COMPLETE',len(entries),flush=True)
    consumed.update(case.consumed)
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'batch dependencies unchanged')
    write(result_path,dict(passed=True,sources=sources(),consumed=consumed,tag=tag,reports=reports,
                          no_history_solve=True,no_source_replacement=True,unchanged_gates=[ALGEBRA,GATE]))
    print(tag,'BATCH COMPLETE',len(reports),'segments',flush=True)


def batch(number):
    frozen=read(FROZEN_STAGE/LABEL/'freeze-01/result.json')
    selection=next(row for row in frozen['batches'] if row['batch']==number)
    build(selection['segment_ordinals'],f'batch{number:02d}')

