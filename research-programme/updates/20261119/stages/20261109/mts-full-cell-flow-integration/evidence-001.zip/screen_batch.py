from common import *
from full_cell_audit_v2 import integrate
import numpy as np


def screen(number):
    modest()
    tag=f'batch{number:02d}'
    batch_path=ROOT/'batches'/(tag+'-result.json')
    batch=read(batch_path)
    require(batch['passed'],'completed bounded batch')
    frozen_path=FROZEN_STAGE/LABEL/'freeze-01/result.json'
    frozen=read(frozen_path)
    original_path=DIRECT_SOURCE/LABEL/'metric-projection-01/heavy-metric-projection.npz'
    original=load(original_path)
    budget=original['budget']
    output=ROOT/'screens'
    output.mkdir(exist_ok=True)
    consumed={str(batch_path):digest(batch_path),str(frozen_path):digest(frozen_path),str(original_path):digest(original_path)}
    rows=[]
    for report in batch['reports']:
        segment=frozen['segments'][report['ordinal']]
        require([entry['index'] for entry in report['nodes']]==segment['indices'],'complete frozen segment')
        values=[]
        for entry in report['nodes']:
            require(digest(entry['path'])==entry['sha256'],'saved node receipt')
            consumed[entry['path']]=entry['sha256']
            node=read(entry['path'])
            require(digest(node['path'])==node['sha256'],'saved flow values')
            consumed[node['path']]=node['sha256']
            values.append(load(node['path'])['components'])
        values=np.array(values)
        integrals=np.array([integrate(rule['weights'],values[rule['local_indices']]) for rule in segment['rules']])
        fine=integrals[-1,0,0,:,0,:,2]
        previous=integrals[-2,0,0,:,0,:,2]
        current=integrals[-1,0,0,:,1,:,2]
        phase=integrals[-1,1,0,:,0,:,2]-fine
        cross=integrals[-1,1,0,:,1,:,2]-current
        interpolation=integrals[-1,0,1,:,0,:,2]-fine
        step=integrals[-1,0,2,:,0,:,2]-fine
        indicator=abs(fine-previous)+abs(current)+abs(phase)+abs(cross)+abs(interpolation)+abs(step)
        rows.append(dict(ordinal=report['ordinal'],indicator_over_budget=(indicator/budget).tolist(),
                         passed=bool(np.all(indicator/budget<GATE))))
    require(all(digest(path)==checksum for path,checksum in consumed.items()),'screen inputs unchanged')
    write(output/(tag+'-result.json'),dict(passed=True,numerical_pass=all(row['passed'] for row in rows),
        rows=rows,consumed=consumed,sources=sources(),gate=GATE,independent_audit_still_required=True))
    print(tag,'numerical screen',all(row['passed'] for row in rows),'maximum',
          max(np.max(row['indicator_over_budget']) for row in rows),flush=True)

