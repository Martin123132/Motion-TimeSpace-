from full_cell_audit_v2 import audit

audit('completed')

