from full_cell_sources import build

build([1], 'probe')

