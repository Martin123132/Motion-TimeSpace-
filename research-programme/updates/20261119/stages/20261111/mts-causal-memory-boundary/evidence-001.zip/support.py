import importlib.util
from pathlib import Path
from time import monotonic

ROOT=Path(__file__).resolve().parent
POST=ROOT.parent
PREVIOUS=POST/'mts-canonical-matching-state-20261111'
GENERAL=POST/'mts-general-k-carrier-and-late-chart-20261110'
specification=importlib.util.spec_from_file_location('causal_foundation',GENERAL/'common.py')
foundation=importlib.util.module_from_spec(specification)
specification.loader.exec_module(foundation)
foundation.ROOT=ROOT
foundation.PREVIOUS=PREVIOUS
foundation.START=monotonic()
for name in ('read','write','digest','require','guard','worker','exited','json','GATE','ALGEBRA'):
    globals()[name]=getattr(foundation,name)
BRANCH=POST/'condensate-origin-20261003'
EARLY=BRANCH/'native-two-field-transfer-20261007'
SPECTRUM=BRANCH/'resolved-matter-spectrum-20261007'


def verify(mapping):
    for name,expected in mapping.items():
        guard()
        require(digest(name)==expected,'unchanged '+name)
