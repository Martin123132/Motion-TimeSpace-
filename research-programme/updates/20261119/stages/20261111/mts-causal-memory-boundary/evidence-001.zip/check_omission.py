from support import *
import numpy as np


def main():
    with worker('omission'):
        inputs=read(ROOT/'frozen-inputs.json')['hashes']
        verify(inputs)
        require(digest(ROOT/'memory-transport.npz')==read(ROOT/'transport-validation.json')['packet_sha256'],'saved transport packet')
        with np.load(ROOT/'memory-transport.npz',allow_pickle=False) as saved:
            weights=saved['weights']; mean=saved['mean']; operator=saved['operator']; forcing=saved['forcing']
            mapping=saved['source_map']; mapping_prime=saved['source_map_prime']
            initial_rates=np.einsum('nij,j->ni',operator,mean)+forcing
            no_history=np.einsum('nij,j->ni',mapping_prime,mean)+np.einsum('nij,nj->ni',mapping,initial_rates)
            projected=np.tensordot(weights,no_history,axes=(0,0))
            actual=saved['total_source_rate']
            errors=abs(projected-actual)/np.maximum(abs(projected),abs(actual))
        require(np.isfinite(errors).all(),'finite diagnostic')
        write('omission-rate-diagnostic.json',dict(post_result_diagnostic=True,new_acceptance_gate=False,description='Drop initial unresolved history but retain the same mean, current self-gravity and rest source. This differs from dropping only a final readout term.',source_order=['density','current','pressure'],zero_history_initial_rate=projected.tolist(),preparation_rate=actual.tolist(),relative_errors=errors.tolist(),unchanged_tolerance=GATE,passes=(errors<=GATE).tolist(),frozen_short_endpoint_omission_still_passes=True,packet_sha256=digest(ROOT/'memory-transport.npz'),script_sha256=digest(ROOT/'check_omission.py')))
        verify(inputs)
        print(json.dumps(dict(errors=errors.tolist(),passes=(errors<=GATE).tolist())))


if __name__=='__main__':
    main()
