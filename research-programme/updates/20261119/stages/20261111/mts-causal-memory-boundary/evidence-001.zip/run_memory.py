from support import *
import sys
import numpy as np
import scipy
from scipy.interpolate import CubicSpline
from scipy.integrate import solve_ivp
from scipy.linalg import expm


def load(path):
    with np.load(path,allow_pickle=False) as packet:
        return {name:packet[name] for name in packet.files}


def average(weights,values):
    return np.tensordot(weights,values,axes=(0,0))


def compare(checks,name,actual,reference,gate=ALGEBRA,normalization=None):
    actual,reference=np.asarray(actual),np.asarray(reference)
    require(np.isfinite(actual).all() and np.isfinite(reference).all(),'finite '+name)
    difference=float(np.max(abs(actual-reference)))
    scale=float(max(np.max(abs(actual)),np.max(abs(reference)))) if normalization is None else float(normalization)
    error=difference/scale if scale else (0. if not difference else float('inf'))
    require(np.isfinite(error),'defined '+name)
    checks[name]=dict(error=error,absolute_difference=difference,normalization=scale,tolerance=gate,passed=bool(error<=gate))
    return error


def freeze():
    require(digest(PREVIOUS/'closeout.json')=='3667cd9bb606e33478daebd348490d1d9d70261fbdae78418110eba20d876dcd','verified matching closeout')
    prior=read(PREVIOUS/'closeout.json')
    paths=[PREVIOUS/'closeout.json']
    for name in ('matching-state.npz','carrier-initial-state.npz','matching-validation.json','carrier-validation.json','frozen-inputs.json'):
        path=PREVIOUS/name
        require(digest(path)==prior['artifacts'][name]['sha256'],'sealed matching '+name)
        paths.append(path)
    original=read(PREVIOUS/'frozen-inputs.json')['inputs']
    for path in (EARLY/'runs/backgrounds/heavy.npz',SPECTRUM/'runs/exact-grid/chunk-0384.npz',EARLY/'runs/final-bg8-start/cold.npz'):
        require(digest(path)==original[str(path)],'original preparation '+str(path))
        paths.append(path)
    paths.extend(ROOT/name for name in ('PROTOCOL.md','DERIVATION.md','support.py','run_memory.py'))
    hashes={str(path):digest(path) for path in paths}
    write('frozen-inputs.json',dict(hashes=hashes,python=sys.version,numpy=np.__version__,scipy=scipy.__version__,gate=GATE,algebra=ALGEBRA,horizon='1/(32*max(mu_i))',time_steps=[16,32],rtol=1e-10,atol=1e-12))
    return hashes


def scalar_block(source,table,normalization,force):
    scale=source['a']; hubble=source['H']; beta=scale/normalization
    efold=table['heavy_efold']; query=np.log(scale)
    require(np.all(query>=efold[0]) and np.all(query<=efold[-1]),'background interpolation inside saved domain')
    field_spline=CubicSpline(efold,table['phi_h'],bc_type='natural')
    velocity_spline=CubicSpline(efold,table['phidot_h'],bc_type='natural')
    field=field_spline(query); velocity=velocity_spline(query)
    field_prime=hubble*field_spline(query,1); velocity_prime=hubble*velocity_spline(query,1)
    mass2=(scale*float(table['heavy_mass_mpc']))**2
    perturbation=source['mts_dphi_h']; speed=source['mts_dphidot_h']
    field_defect=field_prime-velocity
    velocity_defect=velocity_prime+2*hubble*velocity+mass2*field
    background=np.column_stack((field,velocity)); perturbations=np.column_stack((perturbation,speed))
    moments=beta[:,None]*np.einsum('ni,nj->nij',background,perturbations).reshape((-1,4))
    background_moments=beta[:,None]*np.einsum('ni,nj->nij',background,background).reshape((-1,4))
    amplitude=field**2+velocity**2/mass2
    require(np.min(amplitude)>0 and np.min(hubble)>0,'regular background')
    field_row=np.column_stack((field,np.zeros(len(field)),velocity/mass2,np.zeros(len(field))))/amplitude[:,None]
    speed_row=np.column_stack((np.zeros(len(field)),field,np.zeros(len(field)),velocity/mass2))/amplitude[:,None]
    operator=np.zeros((len(field),4,4))
    operator[:,0,0]=hubble; operator[:,0,1]=1.; operator[:,0,2]=1.
    operator[:,1,0]=-(mass2+25.); operator[:,1,1]=-hubble; operator[:,1,3]=1.
    operator[:,2,0]=-mass2; operator[:,2,2]=-hubble; operator[:,2,3]=1.
    operator[:,3,1]=-mass2; operator[:,3,2]=-(mass2+25.); operator[:,3,3]=-3*hubble
    defect_operator=np.stack((field_defect[:,None]*field_row,field_defect[:,None]*speed_row,velocity_defect[:,None]*field_row,velocity_defect[:,None]*speed_row),axis=1)
    source_map=np.zeros((len(field),3,4)); source_map[:,0,0]=mass2; source_map[:,0,3]=1.; source_map[:,1,2]=5.; source_map[:,2,0]=-mass2; source_map[:,2,3]=1.
    source_map_prime=np.zeros_like(source_map); source_map_prime[:,0,0]=2*hubble*mass2; source_map_prime[:,2,0]=-2*hubble*mass2
    force_column=np.column_stack((np.zeros(len(field)),background_moments[:,1],np.zeros(len(field)),background_moments[:,3]))
    self_gravity=-np.einsum('ni,nj->nij',force_column,source_map[:,0,:])/(2*hubble*beta)[:,None,None]
    operator+=defect_operator+self_gravity
    rest=force-source['mts_drho_h']/(10*hubble)
    forcing=-5*rest[:,None]*force_column
    perturbation_prime=np.column_stack((speed,-2*hubble*speed-(mass2+25)*perturbation-5*force*velocity))
    background_prime=np.column_stack((field_prime,velocity_prime))
    direct_rate=hubble[:,None]*moments+beta[:,None]*(np.einsum('ni,nj->nij',background_prime,perturbations)+np.einsum('ni,nj->nij',background,perturbation_prime)).reshape((-1,4))
    return dict(moments=moments,operator=operator,forcing=forcing,source_map=source_map,source_map_prime=source_map_prime,direct_rate=direct_rate,mass2=mass2,rest=rest,self_gravity=self_gravity,field_row=field_row,speed_row=speed_row,beta=beta,perturbation=perturbation,speed=speed)


def split_rhs(operator,forcing,weights,mean,unresolved):
    mean_operator=average(weights,operator); mean_force=average(weights,forcing)
    memory_rate=np.einsum('nij,nj->ni',operator,unresolved)
    projected_memory=average(weights,memory_rate)
    mean_rate=mean_operator@mean+projected_memory+mean_force
    unresolved_rate=np.einsum('nij,j->ni',operator-mean_operator,mean)+memory_rate-projected_memory+forcing-mean_force
    return mean_rate,unresolved_rate


def main():
    with worker('memory'):
        hashes=freeze()
        saved=load(PREVIOUS/'matching-state.npz')
        carrier=load(PREVIOUS/'carrier-initial-state.npz')
        packet=load(SPECTRUM/'runs/exact-grid/chunk-0384.npz')
        table=load(EARLY/'runs/backgrounds/heavy.npz')
        selected=int(np.flatnonzero(packet['modes']==5.)[0]); indices=saved['indices']; weights=saved['weights']
        values=packet['values'][selected,indices]
        source={str(name):values[:,column] for column,name in enumerate(packet['names'])}
        block=scalar_block(source,table,float(saved['density0']),saved['force'])
        moments,operator,forcing=block['moments'],block['operator'],block['forcing']
        source_map,source_map_prime=block['source_map'],block['source_map_prime']
        mean=average(weights,moments); unresolved=moments-mean
        mean_rate,unresolved_rate=split_rhs(operator,forcing,weights,mean,unresolved)
        local_rate=np.einsum('nij,nj->ni',operator,moments)+forcing
        physical_sources=np.einsum('nij,nj->ni',source_map,moments)
        physical_rates=np.einsum('nij,nj->ni',source_map_prime,moments)+np.einsum('nij,nj->ni',source_map,local_rate)
        mean_map,mean_map_prime=average(weights,source_map),average(weights,source_map_prime)
        memory=average(weights,np.einsum('nij,nj->ni',source_map,unresolved))
        memory_prime=average(weights,np.einsum('nij,nj->ni',source_map_prime,unresolved)+np.einsum('nij,nj->ni',source_map,unresolved_rate))
        reconstructed_rate=mean_map_prime@mean+mean_map@mean_rate+memory_prime
        checks={}
        compare(checks,'weight_sum',weights.sum(),1.)
        compare(checks,'coherent_field_readout',np.einsum('ni,ni->n',block['field_row'],moments),block['beta']*block['perturbation'])
        compare(checks,'coherent_speed_readout',np.einsum('ni,ni->n',block['speed_row'],moments),block['beta']*block['speed'])
        compare(checks,'current_self_gravity_product_rule',local_rate,block['direct_rate'])
        compare(checks,'nonzero_mean_memory_rate',mean_rate,average(weights,block['direct_rate']))
        compare(checks,'full_resolved_unresolved_rate',mean_rate+unresolved_rate,block['direct_rate'])
        compare(checks,'unresolved_initial_zero_mean',average(weights,unresolved),np.zeros(4),normalization=float(np.max(abs(moments))))
        compare(checks,'unresolved_rate_zero_mean',average(weights,unresolved_rate),np.zeros(4),normalization=float(np.max(abs(local_rate))))
        compare(checks,'initial_total_source',mean_map@mean+memory,carrier['full_sources'])
        compare(checks,'source_map_memory_derivative',reconstructed_rate,average(weights,physical_rates))
        compare(checks,'retained_equation_owned_rate',reconstructed_rate,saved['projected_source_rate'],GATE)
        for index,label in enumerate(('density','current','pressure')):
            compare(checks,'source_'+label,(mean_map@mean+memory)[index],saved['retained_sources'][index],GATE)
            compare(checks,'rate_'+label,reconstructed_rate[index],saved['projected_source_rate'][index],GATE)
        cold_values=read(PREVIOUS/'matching-validation.json')['cold']
        cold_packet=load(EARLY/'runs/final-bg8-start/cold.npz')
        cold_selected=int(np.flatnonzero(cold_packet['modes']==5.)[0])
        cold_native=cold_packet['values'][cold_selected,indices]
        cold_density=cold_values['normalization']*cold_native[:,cold_packet['names'].tolist().index('delta_cdm')]
        cold_prime=-5*cold_values['normalization']*saved['cold_force']
        cold_mean=average(weights,cold_density); cold_memory=cold_density-cold_mean
        compare(checks,'cold_initial',cold_mean,cold_values['density'])
        compare(checks,'cold_equation_rate',average(weights,cold_prime),cold_values['projected_rate'])
        compare(checks,'cold_history_memory_mean',average(weights,cold_memory),0.,normalization=float(np.max(abs(cold_density))))
        times=packet['conformal_time'][indices]
        require(np.all(np.diff(times)>0),'ordered saved conformal times')
        lags=times[-1]-times
        require(np.min(lags)==0 and np.max(lags)>0,'nonnegative causal lags')
        center_tau=float(np.interp(float(saved['center']),source['a'],times))
        availability=dict(center_scale=float(saved['center']),left_scale=float(source['a'][0]),right_scale=float(source['a'][-1]),left_conformal_time=float(times[0]),right_conformal_time=float(times[-1]),center_conformal_time_interpolated=center_tau,availability_delay_from_center=float(times[-1]-center_tau),maximum_lag=float(np.max(lags)),future_of_center_samples=int(np.sum(source['a']>float(saved['center']))),new_native_boundary_capture=False)
        preflight_passed=all(value['passed'] for value in checks.values())
        write('boundary-validation.json',dict(passed=preflight_passed,checks=checks,mean_moment=mean.tolist(),memory_sources=memory.tolist(),memory_source_rate=memory_prime.tolist(),total_source_rate=reconstructed_rate.tolist(),mean_memory_force=average(weights,np.einsum('nij,nj->ni',operator,unresolved)).tolist(),causal_availability=availability,original_carrier_memory=carrier['memory_sources'].tolist(),memory_coordinates_differ=True))
        require(preflight_passed,'initial boundary source and rate checks')
        horizon=float(1/(32*np.max(np.sqrt(block['mass2']))))
        full_width=4
        initial=np.r_[mean,unresolved.ravel()]
        scale=np.tile(np.maximum(np.max(abs(moments),axis=0),np.max(abs(local_rate),axis=0)*horizon),len(weights)+1)
        require(np.all(scale>0),'nonzero inherited control scaling')
        def rhs(time,normalized):
            guard()
            state=normalized*scale
            resolved_rate,tail_rate=split_rhs(operator,forcing,weights,state[:4],state[4:].reshape((-1,4)))
            return np.r_[resolved_rate,tail_rate.ravel()]/scale
        reference=np.empty_like(moments)
        for index in range(len(weights)):
            if index%100==0:
                guard()
            augmented=np.zeros((5,5)); augmented[:4,:4]=operator[index]; augmented[:4,4]=forcing[index]
            reference[index]=(expm(augmented*horizon)@np.r_[moments[index],1.])[:4]
        direct_sources=average(weights,np.einsum('nij,nj->ni',source_map,reference))
        runs=[]; output={}
        for steps in (16,32):
            solved=solve_ivp(rhs,(0.,horizon),initial/scale,method='DOP853',rtol=1e-10,atol=1e-12,max_step=horizon/steps,t_eval=[0.,horizon])
            require(solved.success,'completed frozen memory control')
            final=solved.y[:,-1]*scale
            reconstructed=final[:4]+final[4:].reshape((-1,4))
            final_sources=average(weights,np.einsum('nij,nj->ni',source_map,reconstructed))
            report={}
            compare(report,'node_state',reconstructed,reference,GATE)
            compare(report,'unresolved_zero_mean',average(weights,final[4:].reshape((-1,4))),np.zeros(4),ALGEBRA,normalization=float(np.max(abs(reference))))
            for index,label in enumerate(('density','current','pressure')):
                compare(report,'source_'+label,final_sources[index],direct_sources[index],GATE)
            runs.append(dict(steps=steps,nfev=solved.nfev,passed=all(value['passed'] for value in report.values()),checks=report,sources=final_sources.tolist()))
            output['final_step'+str(steps)]=final
        refinement={}
        compare(refinement,'paired_steps',output['final_step16'],output['final_step32'],GATE)
        no_initial=np.r_[mean,np.zeros_like(unresolved).ravel()]
        missing=solve_ivp(rhs,(0.,horizon),no_initial/scale,method='DOP853',rtol=1e-10,atol=1e-12,max_step=horizon/32,t_eval=[horizon])
        require(missing.success,'completed deliberate zero-memory control')
        missing_final=missing.y[:,-1]*scale
        missing_nodes=missing_final[:4]+missing_final[4:].reshape((-1,4))
        missing_sources=average(weights,np.einsum('nij,nj->ni',source_map,missing_nodes))
        negatives={}
        for index,label in enumerate(('density','current','pressure')):
            compare(negatives,'zero_initial_memory_'+label,missing_sources[index],direct_sources[index],GATE)
        cold_control=average(weights,cold_density+horizon*cold_prime)
        compare(refinement,'cold_frozen_transport',cold_control,cold_mean+horizon*average(weights,cold_prime),GATE)
        path=ROOT/'memory-transport.npz'
        with path.open('xb') as stream:
            np.savez_compressed(stream,indices=indices,weights=weights,times=times,lags=lags,initial_moments=moments,operator=operator,forcing=forcing,self_gravity=block['self_gravity'],source_map=source_map,source_map_prime=source_map_prime,mean=mean,unresolved=unresolved,mean_rate=mean_rate,unresolved_rate=unresolved_rate,memory_sources=memory,memory_source_rate=memory_prime,total_source_rate=reconstructed_rate,reference_nodes=reference,reference_sources=direct_sources,zero_initial_memory_sources=missing_sources,initial=initial,horizon=horizon,**output)
        verify(hashes)
        result=dict(passed=all(run['passed'] for run in runs) and all(value['passed'] for value in refinement.values()),horizon=horizon,runs=runs,refinement=refinement,negative_controls=negatives,packet_sha256=digest(path),actual_late_run=False,full_rest_dynamics_evolved=False,control='Frozen local coefficient/other-species source control, not physical coupled cosmological propagation.',new_fitted_parameters=0)
        write('transport-validation.json',result)
        print(json.dumps(dict(boundary_passed=preflight_passed,boundary_checks=len(checks),transport_passed=result['passed'],memory_source_rate=memory_prime.tolist(),total_source_rate=reconstructed_rate.tolist(),causal_availability=availability,runs=runs,negative_controls=negatives),indent=2))


if __name__=='__main__':
    main()
