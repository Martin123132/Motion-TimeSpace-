from support import *
import numpy as np

def main():
    with worker('live-generator'):
        density0 = 2.479342985570997e-8
        wave = 5.
        with np.load(ROOT / 'heavy-right-edge-capture.npz', allow_pickle=False) as capture, np.load(ROOT / 'heavy-right-edge-steps64.npz', allow_pickle=False) as run:
            first = int(capture['signature'][0, 2]) - 1 + 2
            dimension = run['state'].shape[1]
            block = slice(dimension - 4, dimension)
            moments, rates, source_rates, independent_rates, operator_rows = [], [], [], [], []
            clocks = []
            for index in range(len(run['clock'])):
                scale, rate, hubble, dilation = run['extra'][index]
                field, velocity, field_n, velocity_n, mass2, omega = run['jets'][index, 1]
                beta = scale / density0
                raw = run['state'][index, block]
                raw_prime = run['rhs'][index, block]
                factors = beta * np.array([1., omega, omega, omega**2])
                relative_rates = rate * np.array([1., 1 + mass2 / omega**2, 1 + mass2 / omega**2, 1 + 2 * mass2 / omega**2])
                moment = factors * raw
                native_rate = factors * raw_prime + relative_rates * moment
                amplitude = field**2 + velocity**2 / mass2
                recovery_u = np.array([field, 0, velocity / mass2, 0]) / amplitude
                recovery_w = np.array([0, field, 0, velocity / mass2]) / amplitude
                field_defect = rate * field_n - velocity
                velocity_defect = rate * velocity_n + 2 * hubble * velocity + mass2 * field
                defect = np.array([field_defect * recovery_u, field_defect * recovery_w, velocity_defect * recovery_u, velocity_defect * recovery_w])
                free = np.array([[rate, 1., 1., 0.], [-(mass2 + wave**2), rate - 2 * hubble, 0., 1.], [-mass2, 0., rate - 2 * hubble, 1.], [0., -mass2, -(mass2 + wave**2), rate - 4 * hubble]])
                source_map = np.array([[mass2, 0., 0., 1.], [0., 0., wave, 0.], [-mass2, 0., 0., 1.]])
                source_map_prime = np.array([[2 * rate * mass2, 0., 0., 0.], [0., 0., 0., 0.], [-2 * rate * mass2, 0., 0., 0.]])
                gravity = np.array([0., beta * field * velocity, 0., beta * velocity**2])
                operator = free + defect - np.outer(gravity, source_map[0]) / (2 * hubble * beta)
                zeta = dilation - (source_map[0] @ moment) / (2 * wave * hubble * beta)
                calculated_rate = operator @ moment - wave * zeta * gravity
                primitive = run['vector'][index, first:first + 2]
                primitive_prime = run['derivative'][index, first:first + 2]
                field_prime, velocity_prime = rate * field_n, rate * velocity_n
                independent = beta * (rate * np.outer([field, velocity], primitive) + np.outer([field_prime, velocity_prime], primitive) + np.outer([field, velocity], primitive_prime)).ravel()
                moments.append(moment)
                rates.append(calculated_rate)
                independent_rates.append(independent)
                source_rates.append(source_map_prime @ moment + source_map @ calculated_rate)
                operator_rows.append(operator)
                clocks.append([rate, hubble, rate - hubble])
                require(comparison(calculated_rate, native_rate, ALGEBRA)['passed'], 'current product chart derivative')
            moments = np.array(moments)
            rates = np.array(rates)
            independent_rates = np.array(independent_rates)
            checks = {str(index): comparison(rates[:, index], independent_rates[:, index], ALGEBRA) for index in range(4)}
            require(all(row['passed'] for row in checks.values()), 'actual-clock self-gravity generator')
            write('live-generator-check.json', dict(passed=True, checks=checks, max_relative_clock_defect=float(np.max(np.abs(np.array(clocks)[:, 2] / np.array(clocks)[:, 1]))), physical_hubble_not_replaced_by_interpolation_rate=True, same_bank=True, rest_metric_live=True))
            np.savez_compressed(ROOT / 'live-generator.npz', clock=run['clock'], moments=moments, rates=rates, independent_rates=independent_rates, source_rates=source_rates, operators=operator_rows, clock_comparison=clocks)
            print(json.dumps(dict(passed=True, components=len(checks), worst=max(row['relative'] or 0 for row in checks.values()))), flush=True)

if __name__ == '__main__':
    main()
