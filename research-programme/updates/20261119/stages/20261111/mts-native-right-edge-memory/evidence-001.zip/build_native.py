from support import *
import ast

def main():
    source = POST / 'mts-native-source-conservation-20261110/build_native.py'
    require(digest(source) == read(source.parent / 'closeout.json')['artifacts']['build_native.py']['sha256'], 'sealed serial builder')
    changes = []
    class Adapt(ast.NodeTransformer):
        def visit_ImportFrom(self, node):
            if node.module == 'source_support':
                node.module = 'support'
                changes.append('support')
            return node
        def visit_Set(self, node):
            if all(isinstance(value, ast.Constant) for value in node.elts) and {value.value for value in node.elts} == {'fortran/MTSTwoField.f90', 'camb/mts.py'}:
                changes.append('capture_selector_only')
                return ast.Set(elts=[ast.Constant('fortran/camb_python.f90')])
            return self.generic_visit(node)
    tree = Adapt().visit(ast.parse(source.read_text(encoding='utf-8')))
    require(changes == ['support', 'capture_selector_only'], 'bounded private builder adaptation')
    namespace = dict(__file__=__file__, __name__='right_edge_builder')
    exec(compile(ast.fix_missing_locations(tree), str(source), 'exec'), namespace)
    namespace['main']()

if __name__ == '__main__':
    main()
