from support import *
import argparse
import ast
import ctypes
import numpy as np
from scipy.integrate import solve_ivp

def columns(actual, expected, tolerance=GATE):
    return {str(index): comparison(actual[:, index], expected[:, index], tolerance) for index in range(expected.shape[1])}

def passed(groups):
    return all(row['passed'] for group in groups.values() for row in group.values())

def worst(groups):
    return {name: max((row['relative'] or 0 for row in group.values()), default=0) for name, group in groups.items()}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('cold', 'heavy'))
    args = parser.parse_args()
    label = args.case + '-right-edge'
    with worker(label):
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        build = read(ROOT / 'native-build-result.json')
        require(build['state'] == 'completed' and build['temporary_mapping_removed'], 'private native build')
        require(all(exited(row['identity'])['exited'] for row in build['children']), 'compiler children exited')
        local = ROOT / 'native'
        require(digest(local / 'camb/cambdll.dll') == build['dll_sha256'], 'frozen native binary')
        source = SPECTRUM / 'runs/exact-grid/chunk-0384.npz' if args.case == 'heavy' else EARLY / 'runs/final-bg8-start/cold.npz'
        with np.load(source, allow_pickle=False) as packet:
            saved = {name: packet[name].copy() for name in packet.files}
        table = EARLY / 'runs/backgrounds' / (args.case + '.npz')
        factory_path = MATCHING / 'matching_common.py'
        observer_path = POST / 'mts-metric-feedback-20261107/observer.dll'
        paths = [Path(__file__), ROOT / 'support.py', source, table, factory_path, observer_path, local / 'camb/cambdll.dll']
        write(label + '-frozen.json', {str(path): digest(path) for path in paths})
        sys.path.insert(0, str(local))
        import camb
        from camb.mts import MTSTwoField
        sys.path.append(str(BRANCH / 'radiation-and-slow-field-transfer-20261007'))
        import radiation_common
        require(Path(camb.__file__).resolve().parent == local / 'camb', 'isolated CAMB')
        factory = next(node for node in ast.parse(factory_path.read_text()).body if isinstance(node, ast.FunctionDef) and node.name == 'params_for')
        namespace = dict(np=np, previous=radiation_common, MTSTwoField=MTSTwoField)
        exec(compile(ast.Module(body=[factory], type_ignores=[]), str(factory_path), 'exec'), namespace)
        params = namespace['params_for'](table)
        observer = ctypes.CDLL(str(observer_path))
        callback = ctypes.cast(observer.source_func_, ctypes.c_void_p)
        library = ctypes.CDLL(str(local / 'camb/cambdll.dll'))
        reset, copy, initialize, pack, evaluate = [getattr(library, name) for name in ('mts_early_reset', 'mts_early_copy', 'mts_phase_init', 'mts_phase_pack', 'mts_phase_evaluate')]
        for function in (reset, copy, initialize, pack, evaluate):
            function.restype = None
        reset.argtypes = initialize.argtypes = []
        copy.argtypes = [ctypes.c_int, ctypes.c_int] + [ctypes.c_void_p] * 11
        pack.argtypes = [ctypes.c_double, ctypes.c_int] + [ctypes.c_void_p] * 3
        evaluate.argtypes = [ctypes.c_double, ctypes.c_int] + [ctypes.c_void_p] * 8

        def scalar(name, family='early'):
            return ctypes.c_int.in_dll(library, 'mts_' + family + '_' + name)

        def pointers(*arrays):
            return [ctypes.c_void_p(value.ctypes.data) for value in arrays]

        native = camb.get_background(params)
        try:
            clock = np.ascontiguousarray(native.conformal_time(1 / saved['requested_scale'] - 1, tol=1e-10))
            require(np.array_equal(clock, saved['conformal_time']), 'original native clock exactly retained')
            modes = np.ascontiguousarray(saved['modes'])
            selected = int(np.flatnonzero(modes == 5.)[0])
            lower, upper = 2892, 2900
            require(clock[lower] == 89.70491681253633 if args.case == 'heavy' else True, 'actual right-edge clock')
            names = list(camb.model.evolve_names)
            native.Params.Accuracy.IntTolBoost = 6
            native.Params.Accuracy.lAccuracyBoost = 4
            output = np.zeros((len(modes), len(clock), len(names) + 30))
            reset()
            scalar('target_index').value = selected + 1
            scalar('begin').value, scalar('end').value = lower + 1, upper + 1
            print(json.dumps(dict(case=args.case, capture='started', modes=len(modes), target_index=selected, interval=[lower, upper])), flush=True)
            code = camb.results.CAMB_TimeEvolution(ctypes.byref(native), ctypes.byref(ctypes.c_int(len(modes))), modes, ctypes.byref(ctypes.c_int(len(clock))), clock, ctypes.byref(ctypes.c_int(output.shape[-1])), output, ctypes.byref(ctypes.c_int(30)), ctypes.byref(callback))
            metadata = {name: scalar(name).value for name in ('count', 'nvar', 'active', 'status')}
            write(label + '-native-status.json', dict(code=int(code), **metadata))
            require(code == 0 and metadata['status'] == 2 and metadata['count'] == upper - lower + 1, 'full native capture')
            samples, allocated, active = metadata['count'], metadata['nvar'], metadata['active']
            captured = {name: np.zeros((samples, allocated)) for name in ('reference', 'restarted', 'derivative_reference', 'derivative_restarted')}
            captured.update({name: np.zeros((samples, 40)) for name in ('observation_reference', 'observation_restarted')})
            captured.update({name: np.zeros((samples, 23)) for name in ('cache_reference', 'cache_restarted')})
            captured['cache_mask'] = np.zeros((samples, 23), dtype=np.int32)
            captured['signature'] = np.zeros((samples, 96), dtype=np.int32)
            captured['clock'] = np.zeros(samples)
            copy(allocated, samples, *pointers(*captured.values()))
            np.savez_compressed(ROOT / (label + '-capture.npz'), **captured, modes=modes, requested_scale=saved['requested_scale'], full_clock=clock, selected=selected, standard=output[selected, :, :len(names)], names=names)
            parity = {str(mode): {str(name): comparison(output[mode, :, names.index(str(name))], saved['values'][mode, :, index]) for index, name in enumerate(saved['names'])} for mode in range(len(modes))}
            write(label + '-preparation-parity.json', dict(passed=passed(parity), checks=parity, worst=worst(parity), same_modes=True, same_clock=True, candidate_background_used=False))
            require(passed(parity), 'original preparation parity')
            cache_indices = np.flatnonzero(captured['cache_mask'][0])
            restart = dict(state=columns(captured['restarted'][:, :active], captured['reference'][:, :active]), source=columns(captured['observation_restarted'], captured['observation_reference']), derivative=columns(captured['derivative_restarted'][:, :active], captured['derivative_reference'][:, :active]), cache=columns(captured['cache_restarted'][:, cache_indices], captured['cache_reference'][:, cache_indices]))
            write(label + '-restart-check.json', dict(passed=passed(restart), checks=restart, worst=worst(restart)))
            require(passed(restart), 'native restart checks')
            signature_mask = np.ones(96, dtype=bool)
            if np.all(captured['signature'][:, 11] == 1):
                signature_mask[5] = False
            require(np.all(captured['signature'][:, signature_mask] == captured['signature'][0, signature_mask]), 'active regime fixed')
            initialize()
            require(scalar('status', 'phase').value == 1, 'live phase owner')
            dimension, kept, fields = [scalar(name, 'phase').value for name in ('dimension', 'kept', 'fields')]
            first = int(captured['signature'][0, 2]) - 1
            kept_indices = np.array([index for index in range(active) if not first <= index < first + 2 * fields])
            times = captured['clock']
            reference = np.zeros((samples, dimension))
            reference_jets = np.zeros((samples, 2, 6))
            for index, tau in enumerate(times):
                pack(tau, dimension, *pointers(captured['reference'][index], reference[index], reference_jets[index]))
            sizes = dict(rhs=(dimension,), observation=(40,), vector=(allocated,), derivative=(allocated,), cache=(23,), jets=(2, 6), extra=(4,))

            def sample(tau, state):
                guard()
                values = {name: np.zeros(shape) for name, shape in sizes.items()}
                state = np.ascontiguousarray(state)
                evaluate(float(tau), dimension, *pointers(state, *values.values()))
                require(scalar('status', 'phase').value == 1, 'native phase RHS')
                require(all(np.isfinite(value).all() for value in values.values()), 'finite current-state evaluation')
                return values

            direct = {name: [] for name in sizes}
            expected = []
            for index, tau in enumerate(times):
                values = sample(tau, reference[index])
                for name in sizes:
                    direct[name].append(values[name])
                derivative = list(captured['derivative_reference'][index, kept_indices])
                for component in range(fields):
                    field, velocity, field_first, velocity_first, mass2, omega = values['jets'][component]
                    rate = values['extra'][1]
                    background = np.array([field, velocity / omega])
                    background_first = np.array([rate * field_first, rate * velocity_first / omega - rate * mass2 * velocity / omega**3])
                    original = first + 2 * component
                    perturbation = np.array([captured['reference'][index, original], captured['reference'][index, original + 1] / omega])
                    perturbation_first = np.array([captured['derivative_reference'][index, original], captured['derivative_reference'][index, original + 1] / omega - rate * mass2 * captured['reference'][index, original + 1] / omega**3])
                    derivative.extend((np.outer(background_first, perturbation) + np.outer(background, perturbation_first)).ravel())
                expected.append(derivative)
            direct = {name: np.array(value) for name, value in direct.items()}
            expected = np.array(expected)
            algebra = dict(state=columns(direct['vector'][:, :active], captured['reference'][:, :active], ALGEBRA), source=columns(direct['observation'], captured['observation_reference'], ALGEBRA), rhs=columns(direct['rhs'], expected, ALGEBRA), cache=columns(direct['cache'][:, cache_indices], captured['cache_reference'][:, cache_indices], ALGEBRA))
            write(label + '-algebra.json', dict(passed=passed(algebra), checks=algebra, worst=worst(algebra), dimension=dimension, kept=kept, fields=fields))
            require(passed(algebra), 'same-state source, rest and product-rule RHS')
            base = sample(times[0], reference[0])
            cdm_index = int(np.flatnonzero(kept_indices == 1)[0])
            changed = reference[0].copy()
            amplitude = max(abs(changed[cdm_index]), 1.) / 4
            changed[cdm_index] += amplitude
            kicked = sample(times[0], changed)
            predicted_z = base['observation'][12] * amplitude / (2 * 5. * base['extra'][2])
            feedback = dict(cdm_to_metric=comparison(kicked['extra'][3] - base['extra'][3], predicted_z, ALGEBRA))
            for component in range(fields):
                jet = base['jets'][component]
                background = np.array([jet[0], jet[1] / jet[5]])
                expected_change = np.outer(background, np.array([0., -5. * predicted_z * background[1]])).ravel()
                section = slice(kept + 4 * component, kept + 4 * component + 4)
                feedback['metric_to_phase_' + str(component)] = comparison(kicked['rhs'][section] - base['rhs'][section], expected_change, ALGEBRA)
            if fields == 2:
                changed = reference[0].copy()
                changed[kept + 4:kept + 8] *= 1.25
                kicked = sample(times[0], changed)
                expected_density = base['observation'][37] / 4
                expected_current = base['observation'][39] / 4
                feedback['phase_to_metric'] = comparison(kicked['extra'][3] - base['extra'][3], expected_density / (2 * 5. * base['extra'][2]), ALGEBRA)
                feedback['phase_to_momentum_constraint'] = comparison(kicked['derivative'][0] - base['derivative'][0], expected_current / 2, ALGEBRA)
            write(label + '-feedback.json', dict(passed=all(row['passed'] for row in feedback.values()), checks=feedback))
            require(all(row['passed'] for row in feedback.values()), 'current-rest and metric feedback')
            normalization = np.max(abs(reference), axis=0)
            normalization[normalization == 0] = 1.
            runs, states = {}, {}
            for steps in (32, 64):
                def rhs(tau, normalized):
                    return sample(tau, normalized * normalization)['rhs'] / normalization
                solution = solve_ivp(rhs, (times[0], times[-1]), reference[0] / normalization, method='DOP853', t_eval=times, rtol=1e-10, atol=1e-12, max_step=(times[-1] - times[0]) / steps)
                require(solution.success and solution.y.shape == (dimension, samples), 'short physical continuation')
                state = solution.y.T * normalization
                observed = {name: [] for name in sizes}
                for tau, row in zip(times, state):
                    values = sample(tau, row)
                    for name in sizes:
                        observed[name].append(values[name])
                observed = {name: np.array(value) for name, value in observed.items()}
                checks = dict(state=columns(observed['vector'][:, :active], captured['reference'][:, :active]), source=columns(observed['observation'], captured['observation_reference']), derivative=columns(observed['derivative'][:, :active], captured['derivative_reference'][:, :active]), moment=columns(state[:, kept:], reference[:, kept:]), cache=columns(observed['cache'][:, cache_indices], captured['cache_reference'][:, cache_indices]))
                physicality = {}
                for component in range(fields):
                    background = np.column_stack([observed['jets'][:, component, 0], observed['jets'][:, component, 1] / observed['jets'][:, component, 5]])
                    moment = state[:, kept + 4 * component:kept + 4 * component + 4].reshape(-1, 2, 2)
                    recovered = np.einsum('tij,ti->tj', moment, background) / np.sum(background**2, axis=1)[:, None]
                    remainder = (moment - background[:, :, None] * recovered[:, None, :]).reshape(-1, 4)
                    for entry in range(4):
                        index = kept + 4 * component + entry
                        physicality[str(index)] = comparison(remainder[:, entry] + reference[:, index], reference[:, index])
                checks['physicality'] = physicality
                path = ROOT / (label + '-steps' + str(steps) + '.npz')
                np.savez_compressed(path, state=state, reference=reference, clock=times, expected_rhs=expected, kept_indices=kept_indices, **observed)
                runs[str(steps)] = dict(passed=passed(checks), checks=checks, worst=worst(checks), evaluations=solution.nfev, packet_sha256=digest(path))
                states[steps] = observed
                print(json.dumps(dict(case=args.case, steps=steps, passed=passed(checks), worst=worst(checks), evaluations=solution.nfev)), flush=True)
            refinement = dict(source=columns(states[32]['observation'], states[64]['observation']), state=columns(states[32]['vector'][:, :active], states[64]['vector'][:, :active]), derivative=columns(states[32]['derivative'][:, :active], states[64]['derivative'][:, :active]))
            outcome = dict(passed=all(row['passed'] for row in runs.values()) and passed(refinement), runs=runs, refinement=refinement, boundary_index=lower, boundary_tau=float(times[0]), boundary_a=float(direct['extra'][0, 0]), end_tau=float(times[-1]), dimension=dimension, kept=kept, fields=fields, live_rest=True, prescribed_rest_history=False, temporal_average_closure_claim=False)
            write(label + '-result.json', outcome)
            require(outcome['passed'], 'coupled continuation acceptance')
            check_hashes(read(label_path := ROOT / (label + '-frozen.json')))
        finally:
            reset()
            cleared = scalar('status', 'phase').value == 0 and scalar('count').value == 0
            del native
            write(label + '-owner-release.json', dict(cleared=cleared, native_reference_released=True))
            require(cleared, 'native capture and phase owner released')

if __name__ == '__main__':
    main()
