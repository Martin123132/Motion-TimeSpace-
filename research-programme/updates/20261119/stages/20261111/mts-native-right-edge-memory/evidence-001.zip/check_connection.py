from support import *
import importlib.util
import numpy as np

def main():
    with worker('connection'):
        previous_paths = [POST / 'mts-canonical-matching-state-20261111/carrier-initial-state.npz', PREVIOUS / 'memory-transport.npz', POST / 'mts-general-k-carrier-and-late-chart-20261110/general_k_model.py']
        write('connection-frozen.json', {str(path): digest(path) for path in previous_paths})
        require(digest(previous_paths[0]) == read(previous_paths[0].parent / 'closeout.json')['artifacts'][previous_paths[0].name]['sha256'], 'sealed carrier initialization')
        carrier = np.load(previous_paths[0], allow_pickle=False)
        memory = np.load(previous_paths[1], allow_pickle=False)
        spec = importlib.util.spec_from_file_location('retained_general_k', previous_paths[2])
        model = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(model)
        require(np.array_equal(carrier['indices'], memory['indices']) and np.array_equal(carrier['weights'], memory['weights']), 'same saved history functional')
        require(carrier['indices'][-1] == 2892 and memory['lags'][-1] == 0, 'last history node is the new physical boundary')
        density0 = 2.479342985570997e-8
        records = {}
        with np.load(ROOT / 'heavy-right-edge-capture.npz', allow_pickle=False) as capture, np.load(ROOT / 'heavy-right-edge-steps64.npz', allow_pickle=False) as run:
            first = int(capture['signature'][0, 2]) - 1
            primitive = capture['reference'][0, first + 2:first + 4]
            values = {name: run[name][0] for name in ('extra', 'jets')}
            mapping = model.geometry(values, density0, 5.)
            beta = mapping['beta']
            mass2 = values['jets'][1, 4]
            field, velocity = values['jets'][1, :2]
            source = beta * run['observation'][0, [37, 39, 38]]
            zeta = values['extra'][3] - source[0] / (2 * 5. * values['extra'][2] * beta)
            current_carrier = np.linalg.solve(mapping['transform'], np.r_[mapping['mapping'] @ primitive, zeta])
            current_moments = beta * np.outer([field, velocity], primitive).ravel()
            source_map = np.array([[mass2, 0, 0, 1], [0, 0, 5., 0], [-mass2, 0, 0, 1]])
            checks = {
                'primitive_endpoint': comparison(primitive, carrier['primitive'][-1]),
                'history_moment_endpoint': comparison(current_moments, memory['initial_moments'][-1]),
                'carrier_endpoint': comparison(current_carrier, carrier['phase_corrected_coordinates'][-1]),
                'rest_endpoint': comparison(zeta, carrier['rest'][-1]),
                'instantaneous_source_map': comparison(source_map @ current_moments, source, ALGEBRA),
                'instantaneous_carrier_source': comparison(model.source_rows(field, velocity, np.sqrt(mass2), beta, 5.) @ (mapping['mapping'] @ primitive), source, ALGEBRA),
                'nonzero_history_memory_identity': comparison(carrier['mean_source_map'] @ carrier['initial_slow_carrier'] + carrier['memory_sources'], carrier['full_sources'], ALGEBRA),
                'moment_mean_boundary_identity': comparison(memory['mean'] + memory['unresolved'][-1], current_moments),
                'carrier_mean_boundary_identity': comparison(carrier['initial_slow_carrier'] + carrier['unresolved_preparation'][-1], current_carrier),
            }
            required = all(row['passed'] for row in checks.values())
            records.update(passed=required, checks=checks, current_source=source.tolist(), historical_center_source=carrier['full_sources'].tolist(), source_difference=(source - carrier['full_sources']).tolist(), current_carrier=current_carrier.tolist(), current_zeta=float(zeta), right_edge_tau=float(run['clock'][0]), source_center_not_relabelled=True)
            np.savez_compressed(ROOT / 'causal-boundary-connection.npz', physical_state=capture['reference'][0], phase_state=run['state'][0], current_moments=current_moments, current_carrier=current_carrier, current_sources=source, historical_sources=carrier['full_sources'], historical_carrier=carrier['initial_slow_carrier'], nonzero_history_memory=carrier['memory_sources'], endpoint_unresolved=carrier['unresolved_preparation'][-1], original_indices=carrier['indices'], original_weights=carrier['weights'])
            write('causal-boundary-connection.json', records)
            require(required, 'native current state agrees with prepared history endpoint and exact readouts')
        for case in ('cold', 'heavy'):
            require(read(ROOT / (case + '-right-edge-result.json'))['passed'], 'paired evolution result')
            require(exited(read(ROOT / (case + '-right-edge-start.json')))['exited'], 'numerical worker exited')
            require(read(ROOT / (case + '-right-edge-owner-release.json'))['cleared'], 'native owner released')
        check_hashes(read(ROOT / 'connection-frozen.json'))
        check_hashes(read(ROOT / 'frozen-inputs.json'))
        print(json.dumps(dict(passed=records['passed'], checks=len(records['checks']), worst=max(row['relative'] or 0 for row in records['checks'].values()), current_source=records['current_source'], historical_source=records['historical_center_source'])), flush=True)

if __name__ == '__main__':
    main()
