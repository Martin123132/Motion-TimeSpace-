from support import *
import shutil

def main():
    with worker('bootstrap'):
        expected = 'd34fd32fd672d5c6d4886b31208b42f72408a3fe331abcc93438b193af5dc4b0'
        require(digest(PREVIOUS / 'closeout.json') == expected, 'latest sealed stage')
        require(not (ROOT / 'native').exists(), 'new private destination')
        copied = {}
        for relative in read(COUPLED / 'native-bootstrap-result.json')['copied_source_hashes']:
            source = NATIVE / relative
            destination = ROOT / 'native' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            copied[relative] = digest(source)
            require(digest(destination) == copied[relative], 'source copy')
        write('native-bootstrap-result.json', dict(copied_source_hashes=copied, original=str(NATIVE), completed=True))
        inputs = [PREVIOUS / name for name in ('closeout.json', 'memory-transport.npz', 'boundary-validation.json')]
        inputs += [SPECTRUM / 'runs/exact-grid/chunk-0384.npz', EARLY / 'runs/final-bg8-start/cold.npz', EARLY / 'runs/backgrounds/heavy.npz', EARLY / 'runs/backgrounds/cold.npz', MATCHING / 'matching_common.py', COUPLED / 'run_coupled.py', COUPLED / 'coupled_math.py']
        write('frozen-inputs.json', {str(path): digest(path) for path in inputs})
        print(json.dumps(dict(copied=len(copied), frozen=len(inputs))), flush=True)

if __name__ == '__main__':
    main()
