from matching_support import *
from prepare_state import load, columns, background, metric, recover_force
import numpy as np
import mpmath as mp


def scalar(value):
    return mp.mpf(float(value))


def matrix(values):
    return mp.matrix([[scalar(value) for value in row] for row in values])


def maximum(values):
    return max(abs(value) for value in values)


def average(weights, values):
    result=mp.zeros(2)
    for weight, value in zip(weights, values):
        result += weight*value
    return result


def operator(hubble, mass2, wave2=0):
    return mp.matrix([[0,1],[-mass2-wave2,-2*hubble]])


def sources(value, mass2):
    return mp.matrix([value[1,1]+mass2*value[0,0],5*value[1,0],value[1,1]-mass2*value[0,0]])


def evaluate(digits, packet, source, fields, force):
    with mp.workdps(digits):
        weights=[scalar(value) for value in packet['weights']]
        hubble=[scalar(value) for value in source['H']]
        force=[scalar(value) for value in force]
        beta=[scalar(value) for value in source['a']/float(packet['density0'])]
        masses=[scalar(value) for value in fields[4]]
        mass0=scalar(packet['mass0']); mass02=mass0**2
        hubble0=mp.fsum(weight*value for weight,value in zip(weights,hubble))
        force0=mp.fsum(weight*value for weight,value in zip(weights,force))
        operator_bg0=operator(hubble0,mass02)
        operator_u0=operator(hubble0,mass02,25)
        forcing0=mp.matrix([[0,0],[0,-5*force0]])
        originals_bg=[]; originals_u=[]; rates_bg=[]; rates_u=[]
        correlations_bg=[]; correlations_u=[]; force_correlations=[]; representations_bg=[]; representations_u=[]
        for index in range(len(weights)):
            if index%100==0:
                guard()
            field,velocity,field_n,velocity_n=[scalar(values[index]) for values in fields[:4]]
            perturbation=scalar(source['mts_dphi_h'][index]); speed=scalar(source['mts_dphidot_h'][index])
            background_vector=mp.matrix([field,velocity]); perturbation_vector=mp.matrix([perturbation,speed])
            expansion=hubble[index]; normalization=beta[index]; mass2=masses[index]
            operator_bg=operator(expansion,mass2); operator_u=operator(expansion,mass2,25)
            forcing=mp.matrix([[0,0],[0,-5*force[index]]])
            defect=mp.matrix([expansion*field_n-velocity,expansion*velocity_n+2*expansion*velocity+mass2*field])
            background_moment=normalization*background_vector*background_vector.T
            cross_moment=normalization*background_vector*perturbation_vector.T
            representation_bg=normalization*(defect*background_vector.T+background_vector*defect.T)
            representation_u=normalization*defect*perturbation_vector.T
            rate_bg=expansion*background_moment+operator_bg*background_moment+background_moment*operator_bg.T+representation_bg
            rate_u=expansion*cross_moment+operator_bg*cross_moment+cross_moment*operator_u.T+background_moment*forcing.T+representation_u
            originals_bg.append(background_moment); originals_u.append(cross_moment)
            rates_bg.append(rate_bg); rates_u.append(rate_u)
            correlations_bg.append((expansion-hubble0)*background_moment+(operator_bg-operator_bg0)*background_moment+background_moment*(operator_bg-operator_bg0).T)
            correlations_u.append((expansion-hubble0)*cross_moment+(operator_bg-operator_bg0)*cross_moment+cross_moment*(operator_u-operator_u0).T)
            force_correlations.append(background_moment*(forcing-forcing0).T)
            representations_bg.append(representation_bg); representations_u.append(representation_u)
        mean_bg=average(weights,originals_bg); mean_u=average(weights,originals_u)
        matched_bg=mean_bg.copy(); matched_u=mean_u.copy()
        matched_bg[0,0]=mp.fsum(weight*mass2*value[0,0]/mass02 for weight,mass2,value in zip(weights,masses,originals_bg))
        matched_u[0,0]=mp.fsum(weight*mass2*value[0,0]/mass02 for weight,mass2,value in zip(weights,masses,originals_u))
        correction_bg=matched_bg-mean_bg; correction_u=matched_u-mean_u
        correction_bg_prime=mp.zeros(2); correction_u_prime=mp.zeros(2)
        for weight,mass2,expansion,bg,cross,bg_prime,cross_prime in zip(weights,masses,hubble,originals_bg,originals_u,rates_bg,rates_u):
            ratio=mass2/mass02
            correction_bg_prime[0,0]+=weight*((ratio-1)*bg_prime[0,0]+2*(expansion-hubble0)*ratio*bg[0,0])
            correction_u_prime[0,0]+=weight*((ratio-1)*cross_prime[0,0]+2*(expansion-hubble0)*ratio*cross[0,0])
        projected_bg=average(weights,rates_bg)+correction_bg_prime
        projected_u=average(weights,rates_u)+correction_u_prime
        bare_bg=hubble0*matched_bg+operator_bg0*matched_bg+matched_bg*operator_bg0.T
        bare_u=hubble0*matched_u+operator_bg0*matched_u+matched_u*operator_u0.T+matched_bg*forcing0.T
        connection_bg=correction_bg_prime-(hubble0*correction_bg+operator_bg0*correction_bg+correction_bg*operator_bg0.T)
        connection_u=correction_u_prime-(hubble0*correction_u+operator_bg0*correction_u+correction_u*operator_u0.T+correction_bg*forcing0.T)
        parts_bg=[average(weights,correlations_bg),average(weights,representations_bg),connection_bg]
        parts_u=[average(weights,correlations_u),average(weights,force_correlations),average(weights,representations_u),connection_u]
        checks={}
        for label, projected, bare, parts in [('background',projected_bg,bare_bg,parts_bg),('cross',projected_u,bare_u,parts_u)]:
            summed=mp.zeros(2)
            for part in parts:
                summed+=part
            denominator=max(sum(abs(part[row,column]) for part in parts) for row in range(2) for column in range(2))
            error=maximum(projected-bare-summed)/denominator
            checks[label+'_residual_decomposition']=dict(error=mp.nstr(error,25),passed=bool(error<=ALGEBRA),tolerance=ALGEBRA)
        drift=mp.matrix([2*hubble0*mass02*matched_u[0,0],0,-2*hubble0*mass02*matched_u[0,0]])
        projected_source=sources(projected_u,mass02)+drift
        bare_source=sources(bare_u,mass02)+drift
        rate_errors=[abs(left-right)/max(abs(left),abs(right)) for left,right in zip(projected_source,bare_source)]
        def array(value):
            return [[mp.nstr(value[row,column],40) for column in range(value.cols)] for row in range(value.rows)]
        return dict(digits=digits,checks=checks,projected_source_rate=array(projected_source),bare_source_rate=array(bare_source),rate_relative_errors=[mp.nstr(value,30) for value in rate_errors],residual_bg_parts=[array(value) for value in parts_bg],residual_u_parts=[array(value) for value in parts_u],residual_bg=array(projected_bg-bare_bg),residual_u=array(projected_u-bare_u))


def main():
    with worker('precision-v2'):
        inputs=read(ROOT/'frozen-inputs.json')['inputs']
        verify_inputs(inputs)
        extra={str(ROOT/name):digest(ROOT/name) for name in ('PRECISION-AND-CARRIER-PROTOCOL.md','check_precision_v2.py','matching-state.npz','matching-validation.json')}
        require(extra[str(ROOT/'matching-state.npz')]==read(ROOT/'matching-validation.json')['packet_sha256'],'completed packet')
        write('precision-v2-frozen-inputs.json',extra)
        packet=load(ROOT/'matching-state.npz')
        source=columns(load(SPECTRUM/'runs/exact-grid/chunk-0384.npz'),packet['indices'])
        table=load(EARLY/'runs/backgrounds/heavy.npz')
        fields=(*background(table,source['a'],'h'),(source['a']*float(table['heavy_mass_mpc']))**2)
        results=[evaluate(digits,packet,source,fields,packet['force']) for digits in (60,90)]
        with mp.workdps(100):
            convergence=max(abs(mp.mpf(first)-mp.mpf(second)) for first,second in zip(results[0]['rate_relative_errors'],results[1]['rate_relative_errors']))
        passed=all(check['passed'] for result in results for check in result['checks'].values()) and convergence<ALGEBRA
        verify_inputs(inputs); verify_inputs(extra)
        write('precision-validation.json',dict(passed=bool(passed),results=results,precision_convergence=str(convergence),replaces_only=['background_residual_decomposition','cross_residual_decomposition'],original_validation_retained=True,late_evolution_eligible=False,new_late_evolution=False))
        print(json.dumps(dict(passed=bool(passed),precision_convergence=str(convergence),rate_relative_errors=results[-1]['rate_relative_errors'],checks=results[-1]['checks']),indent=2))


if __name__=='__main__':
    main()
