from matching_support import *
from prepare_state import load, columns, background, compare, avg, sealed_artifact, metric
import importlib.util
import numpy as np


def main():
    with worker('carrier'):
        inputs=read(ROOT/'frozen-inputs.json')['inputs']
        verify_inputs(inputs)
        model_path=sealed_artifact(LAST,'general_k_model.py')
        extra={str(path):digest(path) for path in [model_path,ROOT/'PRECISION-AND-CARRIER-PROTOCOL.md',ROOT/'derive_carrier_initialization.py',ROOT/'matching-state.npz',ROOT/'matching-validation.json',ROOT/'precision-validation.json']}
        require(extra[str(ROOT/'matching-state.npz')]==read(ROOT/'matching-validation.json')['packet_sha256'],'initial packet unchanged')
        require(read(ROOT/'precision-validation.json')['passed'],'precision identity checks')
        write('carrier-frozen-inputs.json',extra)
        spec=importlib.util.spec_from_file_location('retained_general_k',model_path)
        model=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(model)
        packet=load(ROOT/'matching-state.npz')
        source=columns(load(SPECTRUM/'runs/exact-grid/chunk-0384.npz'),packet['indices'])
        table=load(EARLY/'runs/backgrounds/heavy.npz')
        field,velocity,unused_field_n,unused_velocity_n=background(table,source['a'],'h')
        mass=source['a']*float(table['heavy_mass_mpc'])
        beta=source['a']/float(packet['density0'])
        hubble,eta,alpha,potential,lapse=metric(source)
        theta=np.arctan2(-velocity/mass,field)
        energy=beta*(velocity**2+mass**2*field**2)/2
        rest=packet['force']-source['mts_drho_h']/(10*hubble)
        weights=packet['weights']
        parameters=np.column_stack((mass,hubble,energy,beta))
        primitive=np.column_stack((source['mts_dphi_h'],source['mts_dphidot_h']))
        mappings=[]; transforms=[]; rows=[]; coordinates=[]; conditions=[]
        for index in range(len(weights)):
            if index%100==0:
                guard()
            mapping=model.primitive_map(field[index],velocity[index],mass[index],beta[index],5.)
            transform=np.eye(3)+model.micromotion(theta[index],parameters[index],5.)
            source_rows=model.source_rows(field[index],velocity[index],mass[index],beta[index],5.)
            coordinates.append(np.linalg.solve(transform,np.r_[mapping@primitive[index],rest[index]]))
            mappings.append(mapping); transforms.append(transform); rows.append(source_rows)
            conditions.append(np.linalg.cond(transform))
        mappings,transforms,rows,coordinates=map(np.array,(mappings,transforms,rows,coordinates))
        extended_maps=rows@transforms[:,:2,:]
        transformed=np.einsum('nij,nj->ni',transforms,coordinates)
        primitive_readout=np.einsum('nij,nj->ni',rows,np.einsum('nij,nj->ni',mappings,primitive))
        coordinate_readout=np.einsum('nij,nj->ni',extended_maps,coordinates)
        original_sources=beta[:,None]*np.column_stack((source['mts_drho_h'],source['mts_q_h'],source['mts_dp_h']))
        checks={}
        compare(checks,'normal_coordinate_roundtrip',transformed[:,:2],np.einsum('nij,nj->ni',mappings,primitive))
        compare(checks,'rest_coordinate_unchanged',coordinates[:,2],rest)
        compare(checks,'native_force_split',rest+original_sources[:,0]/(10*hubble*beta),packet['force'])
        compare(checks,'primitive_source_rows',primitive_readout,original_sources,GATE)
        compare(checks,'corrected_carrier_source_rows',coordinate_readout,primitive_readout)
        initial=avg(weights,coordinates)
        unresolved=coordinates-initial
        averaged_map=avg(weights,extended_maps)
        resolved_sources=averaged_map@initial
        memory_sources=avg(weights,np.einsum('nij,nj->ni',extended_maps,unresolved))
        covariance_sources=avg(weights,np.einsum('nij,nj->ni',extended_maps-averaged_map,unresolved))
        full_sources=avg(weights,coordinate_readout)
        compare(checks,'unresolved_zero_projected_mean',avg(weights,unresolved),np.zeros(3),scale=float(np.max(abs(coordinates))))
        compare(checks,'source_covariance_identity',memory_sources,covariance_sources,scale=float(np.max(abs(full_sources))))
        compare(checks,'resolved_plus_memory_readout',resolved_sources+memory_sources,full_sources)
        omissions={}
        for index,label in enumerate(('density','current','pressure')):
            compare(checks,'matched_'+label,full_sources[index],packet['retained_sources'][index],GATE)
            compare(omissions,'without_memory_'+label,resolved_sources[index],full_sources[index],GATE)
        canonical_offset=np.column_stack((-3*eta*beta*velocity**2,5*alpha*beta*velocity**2,-3*eta*beta*velocity**2-2*alpha*beta*mass**2*field*velocity))
        canonical_sources=resolved_sources+memory_sources+avg(weights,canonical_offset)
        compare(checks,'canonical_full_preparation',canonical_sources,packet['projected_canonical'],GATE)
        uncorrected_coordinates=np.column_stack((np.einsum('nij,nj->ni',mappings,primitive),rest))
        uncorrected_mean=avg(weights,uncorrected_coordinates)
        conditions=np.array(conditions)
        require(np.isfinite(conditions).all() and np.max(conditions)<1e6,'invertible retained micromotion')
        cold=read(ROOT/'matching-validation.json')['cold']
        cold_initial=np.array([cold['density'],0.,0.])
        cold_rate=np.array([cold['projected_rate'],0.,0.])
        output=ROOT/'carrier-initial-state.npz'
        with output.open('xb') as stream:
            np.savez_compressed(stream,indices=packet['indices'],weights=weights,scale=source['a'],theta=theta,parameters=parameters,normal_maps=mappings,transforms=transforms,source_maps=extended_maps,mean_source_map=averaged_map,primitive=primitive,phase_corrected_coordinates=coordinates,initial_slow_carrier=initial,unresolved_preparation=unresolved,rest=rest,full_sources=full_sources,resolved_sources=resolved_sources,memory_sources=memory_sources,canonical_offset=canonical_offset,canonical_sources=canonical_sources,uncorrected_mean=uncorrected_mean,cold_initial=cold_initial,cold_rate=cold_rate)
        verify_inputs(inputs); verify_inputs(extra)
        result=dict(passed=all(check['passed'] for check in checks.values()),checks=checks,omission_tests=omissions,initial_slow_carrier=initial.tolist(),uncorrected_mean=uncorrected_mean.tolist(),micromotion_mean_shift=(initial-uncorrected_mean).tolist(),resolved_sources=resolved_sources.tolist(),memory_sources=memory_sources.tolist(),full_sources=full_sources.tolist(),canonical_sources=canonical_sources.tolist(),maximum_transform_condition=float(np.max(conditions)),node_count=len(weights),nonzero_unresolved_preparation=bool(np.any(unresolved!=0)),cold_initial=cold_initial.tolist(),cold_rate=cold_rate.tolist(),new_fitted_parameters=0,packet_sha256=digest(output),late_evolution_eligible=False,new_late_evolution=False,scope='Preparation-owned carrier mean and node-resolved initial memory; not a closed two-number late restart or a positive ensemble inference. Dropping the memory is tested, never assumed.')
        write('carrier-validation.json',result)
        print(json.dumps({key:result[key] for key in ('passed','initial_slow_carrier','micromotion_mean_shift','resolved_sources','memory_sources','full_sources','maximum_transform_condition','omission_tests')},indent=2))


if __name__=='__main__':
    main()
