from matching_support import *
import numpy as np
from datetime import datetime, timezone


def main():
    with worker('finish'):
        verify_inputs(read(ROOT/'frozen-inputs.json')['inputs'])
        for name in ('precision-frozen-inputs.json','precision-v2-frozen-inputs.json','carrier-frozen-inputs.json'):
            verify_inputs(read(ROOT/name))
        original=read(ROOT/'matching-validation.json')
        precision=read(ROOT/'precision-validation.json')
        carrier=read(ROOT/'carrier-validation.json')
        expected_physical={'background_projected_rate','cross_projected_rate','projected_density_rate','projected_pressure_rate'}
        expected_precision={'background_residual_decomposition','cross_residual_decomposition'}
        failures={name for name,value in original['checks'].items() if not value['passed']}
        require(failures==expected_physical|expected_precision,'exact preserved failures')
        require(precision['passed'] and all(value['passed'] for result in precision['results'] for value in result['checks'].values()),'unchanged high-precision identity tests')
        require(set(precision['replaces_only'])==expected_precision,'no physical failure replaced')
        require(original['positive_background'] and original['checks']['inherited_background_weight']['passed'],'preparation-owned positive moment representative')
        require(carrier['passed'] and all(value['passed'] for value in carrier['checks'].values()),'carrier initial readouts')
        require({name for name,value in carrier['omission_tests'].items() if not value['passed']}=={'without_memory_current','without_memory_pressure'},'memory omission actually detected')
        require(not original['late_evolution_eligible'] and not carrier['late_evolution_eligible'],'late gate stays closed')
        require(not original['new_late_evolution'] and not carrier['new_late_evolution'],'no claimed unrun late evolution')
        require(digest(ROOT/'matching-state.npz')==original['packet_sha256'],'moment packet hash')
        require(digest(ROOT/'carrier-initial-state.npz')==carrier['packet_sha256'],'carrier packet hash')
        with np.load(ROOT/'carrier-initial-state.npz',allow_pickle=False) as packet:
            require(len(packet['indices'])==902 and np.array_equal(packet['indices'],np.arange(1991,2893)),'unchanged original nodes')
            require(np.count_nonzero(packet['weights']<0)==429,'signed projector retained')
            recovered=np.sum(packet['weights'][:,None]*np.matmul(packet['source_maps'],packet['phase_corrected_coordinates'][:,:,None])[:,:,0],axis=0)
            errors=abs(recovered-packet['full_sources'])/np.maximum(abs(recovered),abs(packet['full_sources']))
            require(np.max(errors)<ALGEBRA,'independent nodewise source contraction')
            require(np.all(packet['cold_initial'][1:]==0) and np.all(packet['cold_rate'][1:]==0),'cold dust current and pressure')
        receipts=[]
        for path in sorted(ROOT.glob('*-start.json')):
            if path.name=='finish-start.json':
                continue
            owner=read(path)
            ending=read(path.with_name(path.name.replace('-start.json','-end.json')))
            require(exited(owner),'prior owned process exited '+path.name)
            require(owner['pid']==ending['pid'] and owner['created']==ending['created'],'receipt identity '+path.name)
            receipts.append(dict(start=path.name,pid=owner['pid'],created=owner['created'],state=ending['state'],exited=True))
        for path in ROOT.glob('*.py'):
            compile(path.read_text(encoding='utf-8'),str(path),'exec')
        require(not (ROOT/'__pycache__').exists(),'no compiled cache')
        write('final-validation.json',dict(utc=datetime.now(timezone.utc).isoformat(),passed=True,accepted_initial_checks=38,retained_physical_rate_failures=sorted(expected_physical),carrier_checks=len(carrier['checks']),precision_identity_evaluations=4,independent_contraction_max_relative_error=float(np.max(errors)),late_evolution_run=False,goal_complete=False,prior_worker_receipts=receipts))
    artifacts={path.name:dict(sha256=digest(path),bytes=path.stat().st_size) for path in sorted(ROOT.iterdir()) if path.is_file() and path.name not in ('closeout.json','CLEANUP-VERIFIED.json')}
    write('closeout.json',dict(state='matching_preparation_recovered_memory_required',utc=datetime.now(timezone.utc).isoformat(),initial_carrier_and_memory_derived=True,bare_local_shortcut_rejected=True,new_late_evolution=False,goal_complete=False,artifacts=artifacts))
    print(json.dumps(dict(closeout_sha256=digest(ROOT/'closeout.json'),artifacts=len(artifacts),passed=True,late_evolution_run=False)))


if __name__=='__main__':
    main()
