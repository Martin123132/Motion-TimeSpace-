import importlib.util
from pathlib import Path
from time import monotonic

ROOT = Path(__file__).resolve().parent
POST = ROOT.parent
LAST = POST / "mts-general-k-carrier-and-late-chart-20261110"
specification = importlib.util.spec_from_file_location("matching_foundation", LAST / "common.py")
foundation = importlib.util.module_from_spec(specification)
specification.loader.exec_module(foundation)
foundation.ROOT = ROOT
foundation.PREVIOUS = LAST
foundation.START = monotonic()
for name in ("read","write","digest","require","guard","worker","exited","json","np","GATE","ALGEBRA"):
    if hasattr(foundation,name):
        globals()[name] = getattr(foundation,name)

BRANCH = POST / "condensate-origin-20261003"
SPECTRUM = BRANCH / "resolved-matter-spectrum-20261007"
EARLY = BRANCH / "native-two-field-transfer-20261007"
LATE = POST / "mts-late-hierarchy-port-20261110"
MATCHING = BRANCH / "native-heavy-matching-20261007"


def verify_inputs(mapping):
    for path, expected in mapping.items():
        guard()
        require(digest(path)==expected,"unchanged input "+path)
